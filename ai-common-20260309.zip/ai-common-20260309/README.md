# ai-common

Shared AI workflows, agents, and tools for Copilot-powered development.

## Quick Start

### 1. Set up a target repo

Copy the foundation layer and the workflows you need into your repo’s `.github/` folder. See [compose.md](compose.md) for step-by-step instructions, quick-compose one-liners, and Bash/PowerShell examples.

### 2. Install tool dependencies

Each tool manages its own dependencies. Install only what you need:

```bash
cd tools/nodemcp   && npm install   # MCP server framework (required for docsearch/splunk)
cd tools/mcps/docsearch && npm install   # Docsearch provider
cd tools/pr-review && npm install   # PR review pipeline
```

### 3. Run tools

Launcher scripts in `tools/` auto-detect missing dependencies and install them:

| What | Windows | Unix |
|------|---------|------|
| PR review | `tools\review.bat [--simple\|--complex]` | `tools/review.sh` |
| Docsearch MCP | `tools\mcp-docsearch.bat` | `tools/mcp-docsearch.sh` |
| Splunk MCP | `tools\mcp-splunk.bat` | `tools/mcp-splunk.sh` |
| All MCP providers | `tools\nodemcp.bat` | `tools/nodemcp.sh` |

Or run directly with Node:

```bash
node tools/pr-review/cli.js --help
node tools/nodemcp/cli.js --provider tools/mcps/docsearch --verbose
node tools/mcps/docsearch/ingest-dir.js --src examples/docsearch/solution-designs --store ./my-index
```

## What's in the Box

### Workflows

Composable Copilot agent packages. Each workflow lives in `workflows/<name>/.github/` and merges cleanly into a target repo's `.github/` folder.

| Workflow | Purpose | Agents |
|----------|---------|--------|
| **repo-init** | Foundation layer — `copilot-instructions.md` and `instructions/` templates with `<!-- TODO -->` placeholders | Always copied first |
| **repo-scanner** | Scans a repo and auto-populates instruction files. Delegates to sub-agents for structure, build, testing, patterns, domain, CI/CD. | Repository Scanner |
| **task-development** | Multi-phase feature development with session boundaries: analyse → plan → implement. | Task Analysis → Task Planning → Task Implementation |
| **code-review** | Runs the pr-review pipeline and presents findings interactively. Quick, standard, and deep modes. | Code Review |
| **e2e-test-automation** | Three-phase E2E test pipeline: test case generation → test planning → test implementation. Framework-agnostic; requires project-specific skills. | UI Test Case Generation → UI Test Planning → UI Test Implementation |
| **defect-triage** | Autonomous bug triage and root cause analysis using Splunk MCP and DocSearch MCP. Produces structured JSON with root cause, impacted components, and JIRA-ready content. | Triage Coordinator → Log Investigator / Doc Researcher → Root Cause Analyzer |

Agents are selected from the **agents dropdown** in VS Code Chat, or via `/agent` in Copilot CLI. See each workflow's README for details.

> When a skill or prompt is used by 3+ workflows, promote it to a shared location. See [compose.md](compose.md) for the promotion pattern.

### Tools

Standalone tools and MCP servers. Used by workflows via skills, or directly from the command line.

| Tool | Description | Docs |
|------|-------------|------|
| **nodemcp** | MCP server framework — modular provider system, STDIO + HTTP transports, session management | [README](tools/nodemcp/README.md) |
| **docsearch** | Reverse HyDE document search — generates hypothetical queries at index time for better semantic matching | [README](tools/mcps/docsearch/README.md) |
| **splunk** | Splunk MCP provider — search, monitoring, log analysis via authenticated sessions | [README](tools/mcps/splunk/README.md) |
| **browser-automation** | Browser automation MCP provider — navigate, click, extract, screenshot via Edge/Chrome | [README](tools/mcps/browser-automation/README.md) |
| **pr-review** | AI-powered PR review pipeline — multi-stage code review with AST analysis and configurable prompts | [README](tools/pr-review/README.md) |

### Examples

| Path | Description |
|------|-------------|
| `examples/docsearch/solution-designs/` | Solution design documents (core-banking, entitlements, workflow) — example content for docsearch ingestion |
| `examples/docsearch/store.*` | Pre-built search index — query immediately without running ingestion |

See [examples/docsearch/README.md](examples/docsearch/README.md) for usage.

## Repository Structure

```
workflows/
├── repo-init/              # Foundation — always copied first
├── repo-scanner/           # Scans repo → populates instructions
├── task-development/       # Analyse → Plan → Implement
├── code-review/            # AI-powered code review
├── e2e-test-automation/    # E2E test generation pipeline
└── defect-triage/          # Bug triage & root cause analysis

tools/
├── nodemcp/                # MCP server framework
├── mcps/
│   ├── docsearch/          # Reverse HyDE document search
│   │   └── models/         # ONNX embedding model (shipped)
│   ├── splunk/             # Splunk search & analytics
│   └── browser-automation/ # Browser automation
├── pr-review/              # PR review pipeline
├── review.bat/sh           # Launcher: pr-review
├── mcp-docsearch.bat/sh    # Launcher: docsearch MCP
├── mcp-splunk.bat/sh       # Launcher: splunk MCP
└── nodemcp.bat/sh          # Launcher: all MCP providers

examples/
├── docsearch/              # Example content & pre-built index
│   ├── solution-designs/   # Indexable documents
│   └── store.idx / .docs   # Pre-built demo index
└── test-ets-restassured/   # Pre-built skills for Selenium + RestAssured

compose.md                  # How to assemble workflows into a target repo
```
