@echo off
REM PR Review Wrapper Script for Windows
REM Usage: review.bat [options] [--base <branch>] [--output <file>] [directory]
REM 
REM Options:
REM   --simple       Use fast/small model for quick reviews
REM   --complex      Use large/capable model for thorough reviews
REM   --verbose      Show detailed debug output
REM   --no-cache     Disable response caching
REM   --clear-cache  Clear all cached responses before running
REM   --no-bitbucket Skip Bitbucket PR comment integration
REM   --base <branch> Set the base branch for diff comparison
REM   --output <file> Write review output to a file instead of stdout
REM   --help         Show this help message
REM
REM Examples:
REM   review.bat --complex --base master ./src
REM   review.bat --simple --base develop .
REM   review.bat --complex --base master --output review.txt
REM   review.bat --verbose

setlocal EnableDelayedExpansion

REM Get the directory where this script is located
set "SCRIPT_DIR=%~dp0"

REM Initialize variables
set "PR_ARGS="
set "TARGET_DIR="
set "NEXT_IS_BASE="
set "NEXT_IS_OUTPUT="
set "OUTPUT_FILE="

REM Parse arguments
:parse_args
if "%~1"=="" goto :done_parsing

if "%NEXT_IS_BASE%"=="1" (
    set "PR_BASE_BRANCH=%~1"
    set "NEXT_IS_BASE="
    shift
    goto :parse_args
)

if "%NEXT_IS_OUTPUT%"=="1" (
    set "OUTPUT_FILE=%~1"
    set "NEXT_IS_OUTPUT="
    shift
    goto :parse_args
)

if "%~1"=="--base" (
    set "NEXT_IS_BASE=1"
    shift
    goto :parse_args
)

if "%~1"=="-b" (
    set "NEXT_IS_BASE=1"
    shift
    goto :parse_args
)

if "%~1"=="--output" (
    set "NEXT_IS_OUTPUT=1"
    shift
    goto :parse_args
)

REM Check if argument starts with -- or - (it's an option)
echo %~1 | findstr /r "^-" >nul
if %errorlevel%==0 (
    set "PR_ARGS=!PR_ARGS! %~1"
    shift
    goto :parse_args
)

REM Otherwise it's the target directory
set "TARGET_DIR=%~1"
shift
goto :parse_args

:done_parsing

REM Check if pr-review dependencies are installed, if not install them
if not exist "%SCRIPT_DIR%pr-review\node_modules\" (
    echo Installing pr-review dependencies...
    pushd "%SCRIPT_DIR%pr-review\"
    if errorlevel 1 (
        echo Error: Cannot find pr-review directory
        exit /b 1
    )
    call npm install
    popd
)

REM If target directory specified, change to it
if not "%TARGET_DIR%"=="" (
    if exist "%TARGET_DIR%" (
        pushd "%TARGET_DIR%"
        if errorlevel 1 (
            echo Error: Cannot change to directory: %TARGET_DIR%
            exit /b 1
        )
    ) else (
        echo Error: Directory does not exist: %TARGET_DIR%
        exit /b 1
    )
)

REM Run the pr-review CLI
if not "%OUTPUT_FILE%"=="" (
    set "PR_REVIEW_OUTPUT_FILE=%OUTPUT_FILE%"
)
node "%SCRIPT_DIR%pr-review\cli.js" %PR_ARGS%
set "EXIT_CODE=!errorlevel!"

REM Return to original directory if we changed
if not "%TARGET_DIR%"=="" (
    popd
)

exit /b %EXIT_CODE%
