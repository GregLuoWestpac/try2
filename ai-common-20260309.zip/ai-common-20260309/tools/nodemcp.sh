#!/bin/bash
#
# NodeMCP Wrapper Script for Unix/Linux/macOS
# Usage: nodemcp.sh [options]
#
# Options:
#   --all                   Load all available providers (default)
#   --layers <providers>    Comma-separated list of providers
#   --transport <type>      Transport: stdio (default) or http
#   --port <number>         HTTP port (default: 3100)
#   --require-auth          Require authentication for HTTP
#   --verbose               Enable verbose logging
#   --help                  Show help
#
# Examples:
#   nodemcp.sh --all
#   nodemcp.sh --layers splunk
#   nodemcp.sh --layers splunk,jira --transport http --port 3100

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Check if nodemcp dependencies are installed, if not install them
if [[ ! -d "${SCRIPT_DIR}/nodemcp/node_modules" ]]; then
    echo "Installing nodemcp dependencies..."
    (cd "${SCRIPT_DIR}/nodemcp" && npm install)
fi

# Run the nodemcp CLI
exec node "${SCRIPT_DIR}/nodemcp/cli.js" "$@"
