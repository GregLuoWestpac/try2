@echo off
REM MCP DocSearch Server - Reverse HyDE Document Search
REM Usage: mcp-docsearch.bat [options]
REM
REM Options:
REM   --transport <type>      Transport: stdio (default) or http
REM   --port <number>         HTTP port (default: 3100)
REM   --require-auth          Require authentication for HTTP
REM   --verbose               Enable verbose logging
REM   --help                  Show help
REM
REM Environment Variables:
REM   DOCSEARCH_STORE_PATH          Directory for vector store files (required)
REM   DOCSEARCH_EMBEDDING_PROVIDER  Embedding provider: local (default) or openai
REM   DOCSEARCH_COMPLETIONS_PROVIDER  Completions provider: copilot (default) or openai
REM   OPENAI_API_KEY                Required if using openai providers
REM
REM Examples:
REM   mcp-docsearch.bat
REM   mcp-docsearch.bat --verbose
REM   mcp-docsearch.bat --transport http --port 3200

setlocal

REM Get the directory where this script is located
set "SCRIPT_DIR=%~dp0"

REM Check if nodemcp dependencies are installed
if not exist "%SCRIPT_DIR%nodemcp\node_modules\" (
    echo Installing nodemcp dependencies...
    pushd "%SCRIPT_DIR%nodemcp\"
    if errorlevel 1 (
        echo Error: Cannot find nodemcp directory
        exit /b 1
    )
    call npm install
    popd
)

REM Check if docsearch dependencies are installed
if not exist "%SCRIPT_DIR%mcps\docsearch\node_modules\" (
    echo Installing docsearch dependencies...
    pushd "%SCRIPT_DIR%mcps\docsearch\"
    if errorlevel 1 (
        echo Error: Cannot find docsearch directory
        exit /b 1
    )
    call npm install
    popd
)

REM Run nodemcp with docsearch provider
node "%SCRIPT_DIR%nodemcp\cli.js" --provider "%SCRIPT_DIR%mcps\docsearch" %*
