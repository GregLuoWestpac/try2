#!/bin/bash
#
# MCP Jira Server - Jira Issue Tracking
# Usage: mcp-jira.sh [options]
#
# Options:
#   --transport <type>      Transport: stdio (default) or http
#   --port <number>         HTTP port (default: 3100)
#   --require-auth          Require authentication for HTTP
#   --verbose               Enable verbose logging
#   --help                  Show help
#
# Environment Variables:
#   JIRA_HOST                Jira base URL (e.g., https://your-domain.atlassian.net)
#   JIRA_EMAIL               Jira email (for API token auth)
#   JIRA_API_TOKEN           Jira API token
#   JIRA_BEARER_TOKEN        Bearer token (alternative)
#   JIRA_SSO_EMAIL           SSO email for Microsoft Entra ID login
#   JIRA_SSO_PASSWORD        SSO password (held in memory only)
#
# Examples:
#   mcp-jira.sh
#   mcp-jira.sh --verbose
#   mcp-jira.sh --transport http --port 3300

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Check if nodemcp dependencies are installed
if [[ ! -d "${SCRIPT_DIR}/nodemcp/node_modules" ]]; then
    echo "Installing nodemcp dependencies..."
    (cd "${SCRIPT_DIR}/nodemcp" && npm install)
fi

# Run nodemcp with jira layer only
exec node "${SCRIPT_DIR}/nodemcp/cli.js" --layers jira "$@"
