@echo off
REM NodeMCP Wrapper Script for Windows
REM Usage: nodemcp.bat [options]
REM 
REM Options:
REM   --all                   Load all available providers (default)
REM   --layers <providers>    Comma-separated list of providers
REM   --transport <type>      Transport: stdio (default) or http
REM   --port <number>         HTTP port (default: 3100)
REM   --require-auth          Require authentication for HTTP
REM   --verbose               Enable verbose logging
REM   --help                  Show help
REM
REM Examples:
REM   nodemcp.bat --all
REM   nodemcp.bat --layers splunk
REM   nodemcp.bat --layers splunk,jira --transport http --port 3100

setlocal

REM Get the directory where this script is located
set "SCRIPT_DIR=%~dp0"

REM Check if nodemcp dependencies are installed, if not install them
if not exist "%SCRIPT_DIR%nodemcp\node_modules\" (
    echo Installing nodemcp dependencies...
    pushd "%SCRIPT_DIR%nodemcp\"
    if errorlevel 1 (
        echo Error: Cannot find nodemcp directory
        exit /b 1
    )
    call npm install
    popd
)

REM Run the nodemcp CLI
node "%SCRIPT_DIR%nodemcp\cli.js" %*
