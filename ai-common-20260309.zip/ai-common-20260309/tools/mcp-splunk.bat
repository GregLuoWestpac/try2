@echo off
REM MCP Splunk Server - Splunk Search and Analytics
REM Usage: mcp-splunk.bat [options]
REM
REM Options:
REM   --transport <type>      Transport: stdio (default) or http
REM   --port <number>         HTTP port (default: 3100)
REM   --require-auth          Require authentication for HTTP
REM   --verbose               Enable verbose logging
REM   --help                  Show help
REM
REM Environment Variables:
REM   SPLUNK_HOST              Splunk server URL (e.g., https://splunk.example.com:8089)
REM   SPLUNK_USERNAME          Splunk username
REM   SPLUNK_PASSWORD          Splunk password
REM   SPLUNK_TOKEN             Splunk bearer token (alternative to username/password)
REM
REM Examples:
REM   mcp-splunk.bat
REM   mcp-splunk.bat --verbose
REM   mcp-splunk.bat --transport http --port 3300

setlocal

REM Get the directory where this script is located
set "SCRIPT_DIR=%~dp0"

REM Check if nodemcp dependencies are installed
if not exist "%SCRIPT_DIR%nodemcp\node_modules\" (
    echo Installing nodemcp dependencies...
    pushd "%SCRIPT_DIR%nodemcp\"
    if errorlevel 1 (
        echo Error: Cannot find nodemcp directory
        exit /b 1
    )
    call npm install
    popd
)

REM Run nodemcp with splunk layer only
node "%SCRIPT_DIR%nodemcp\cli.js" --layers splunk %*
