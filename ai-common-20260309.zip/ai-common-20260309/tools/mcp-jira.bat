@echo off
REM MCP Jira Server - Jira Issue Tracking
REM Usage: mcp-jira.bat [options]
REM
REM Options:
REM   --transport <type>      Transport: stdio (default) or http
REM   --port <number>         HTTP port (default: 3100)
REM   --require-auth          Require authentication for HTTP
REM   --verbose               Enable verbose logging
REM   --help                  Show help
REM
REM Environment Variables:
REM   JIRA_HOST                Jira base URL (e.g., https://your-domain.atlassian.net)
REM   JIRA_EMAIL               Jira email (for API token auth)
REM   JIRA_API_TOKEN           Jira API token
REM   JIRA_BEARER_TOKEN        Bearer token (alternative)
REM   JIRA_SSO_EMAIL           SSO email for Microsoft Entra ID login
REM   JIRA_SSO_PASSWORD        SSO password (held in memory only)
REM
REM Examples:
REM   mcp-jira.bat
REM   mcp-jira.bat --verbose
REM   mcp-jira.bat --transport http --port 3300

setlocal

REM Get the directory where this script is located
set "SCRIPT_DIR=%~dp0"

REM Check if nodemcp dependencies are installed
if not exist "%SCRIPT_DIR%nodemcp\node_modules\" (
    echo Installing nodemcp dependencies...
    pushd "%SCRIPT_DIR%nodemcp\"
    if errorlevel 1 (
        echo Error: Cannot find nodemcp directory
        exit /b 1
    )
    call npm install
    popd
)

REM Run nodemcp with jira layer only
node "%SCRIPT_DIR%nodemcp\cli.js" --layers jira %*
