#!/bin/bash
#
# PR Review Wrapper Script for Unix/Linux/macOS
# Usage: review.sh [options] [--base <branch>] [--output <file>] [directory]
#
# Options:
#   --simple       Use fast/small model for quick reviews
#   --complex      Use large/capable model for thorough reviews
#   --verbose      Show detailed debug output
#   --no-cache     Disable response caching
#   --clear-cache  Clear all cached responses before running
#   --no-bitbucket Skip Bitbucket PR comment integration
#   --base <branch> Set the base branch for diff comparison
#   --output <file> Write review output to a file instead of stdout
#   --help         Show this help message
#
# Examples:
#   review.sh --complex --base master ./src
#   review.sh --simple --base develop .
#   review.sh --complex --base master --output review.txt
#   review.sh --verbose

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Initialize variables
PR_ARGS=()
TARGET_DIR=""
OUTPUT_FILE=""

# Parse arguments
while [[ $# -gt 0 ]]; do
    case "$1" in
        --base|-b)
            if [[ -n "$2" && ! "$2" =~ ^- ]]; then
                export PR_BASE_BRANCH="$2"
                shift 2
            else
                echo "Error: --base requires a branch name"
                exit 1
            fi
            ;;
        --output)
            if [[ -n "$2" && ! "$2" =~ ^- ]]; then
                OUTPUT_FILE="$2"
                shift 2
            else
                echo "Error: --output requires a filename"
                exit 1
            fi
            ;;
        --simple|--complex|--verbose|-v|--no-cache|--clear-cache|--no-bitbucket|--help|-h)
            PR_ARGS+=("$1")
            shift
            ;;
        -*)
            echo "Unknown option: $1"
            exit 1
            ;;
        *)
            # Non-option argument is the target directory
            TARGET_DIR="$1"
            shift
            ;;
    esac
done

# Check if pr-review dependencies are installed, if not install them
if [[ ! -d "${SCRIPT_DIR}/pr-review/node_modules" ]]; then
    echo "Installing pr-review dependencies..."
    (cd "${SCRIPT_DIR}/pr-review" && npm install)
fi

# If target directory specified, change to it
if [[ -n "$TARGET_DIR" ]]; then
    if [[ -d "$TARGET_DIR" ]]; then
        cd "$TARGET_DIR" || {
            echo "Error: Cannot change to directory: $TARGET_DIR"
            exit 1
        }
    else
        echo "Error: Directory does not exist: $TARGET_DIR"
        exit 1
    fi
fi

# Run the pr-review CLI
if [[ -n "$OUTPUT_FILE" ]]; then
    export PR_REVIEW_OUTPUT_FILE="$OUTPUT_FILE"
fi
node "${SCRIPT_DIR}/pr-review/cli.js" "${PR_ARGS[@]}"
