# mv-mcpjira — Jira MCP Server

MCP server providing Jira tools for issue tracking, sprint management, and project workflows. Built with the official `@modelcontextprotocol/sdk` TypeScript SDK.

## Tools

### Issues

| Tool | Description |
|------|-------------|
| `get_issue` | Get Jira issue details by issue key |
| `search_issues` | Search Jira issues using JQL |
| `create_issue` | Create a new Jira issue |
| `update_issue` | Update Jira issue fields |

### Comments

| Tool | Description |
|------|-------------|
| `add_comment` | Add a comment to an issue |
| `get_comments` | Get comments for an issue |

### Transitions & Assignment

| Tool | Description |
|------|-------------|
| `transition_issue` | Transition an issue to a new status |
| `get_transitions` | Get available transitions for an issue |
| `assign_issue` | Assign/reassign an issue |

### Issue Links

| Tool | Description |
|------|-------------|
| `link_issues` | Create a link between two issues |
| `get_issue_links` | Get all links for an issue |
| `get_subtasks` | Get subtasks for a parent issue |

### Boards & Sprints

| Tool | Description |
|------|-------------|
| `get_boards` | List agile boards |
| `get_sprints` | List sprints for a board |
| `get_sprint_issues` | Get issues in a sprint |
| `move_to_sprint` | Move issues to a sprint |

### Projects & Metadata

| Tool | Description |
|------|-------------|
| `get_projects` | List accessible Jira projects |
| `get_project_statuses` | Get statuses for a project |
| `get_issue_types` | Get issue types for a project |

### Users

| Tool | Description |
|------|-------------|
| `find_users` | Find users by query |
| `get_changelogs` | Get change history for an issue |

## Configuration

Create a config file at `~/.jira_mcp.local.yaml`:

### API Token Auth (Jira Cloud)

```yaml
jira:
  host: https://your-domain.atlassian.net
  verify_ssl: true
  api_version: "3"
  auth:
    email: your-email@example.com
    api_token: "your-api-token"
```

### Bearer Token Auth

```yaml
jira:
  host: https://jira.example.com
  verify_ssl: true
  api_version: "2"
  auth:
    bearer_token: "your-bearer-token"
```

### Session Cookie Auth (Jira Server/DC)

```yaml
jira:
  host: https://jira.example.com
  verify_ssl: true
  api_version: "2"
  session:
    jsessionid: "your-jsessionid"
    atlassian_xsrf_token: "your-xsrf-token"
```

## Usage

### Via npx

```bash
npx @mesh-tenant-multiverse-ui-common/mv-mcpjira
```

### VS Code MCP Configuration

Add to `.vscode/mcp.json`:

```json
{
  "servers": {
    "jira": {
      "command": "npx",
      "args": ["@mesh-tenant-multiverse-ui-common/mv-mcpjira"]
    }
  }
}
```

## Development

```bash
npm install
npm run build
npm start
```
