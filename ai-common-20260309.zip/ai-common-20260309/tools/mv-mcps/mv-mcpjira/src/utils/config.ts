import fs from 'node:fs';
import path from 'node:path';
import yaml from 'js-yaml';
import type { JiraConfig, ClientState } from '../types/index.js';

/**
 * Load config from ~/.jira_mcp.local.yaml and return a ClientState.
 * Falls back to env vars if config file is not found.
 */
export function loadConfig(): ClientState {
  const configPath = path.join(
    process.env.HOME || process.env.USERPROFILE || '',
    '.jira_mcp.local.yaml'
  );

  const state: ClientState = {
    host: '',
    port: 443,
    protocol: 'https',
    verifySsl: true,
    apiVersion: '2',
    basicAuth: null,
    bearerToken: null,
    cookies: {},
  };

  let config: JiraConfig | null = null;

  try {
    if (fs.existsSync(configPath)) {
      const content = fs.readFileSync(configPath, 'utf-8');
      config = yaml.load(content) as JiraConfig;
      console.error(`[mv-mcpjira] Loaded config from ${configPath}`);
    }
  } catch (e) {
    console.error(
      `[mv-mcpjira] Failed to load config: ${(e as Error).message}`
    );
  }

  if (!config?.jira) {
    console.error('[mv-mcpjira] No jira config found in config file');
    return state;
  }

  const jira = config.jira;

  // Host
  if (jira.host) {
    const url = new URL(jira.host);
    state.host = url.hostname;
    state.port = url.port
      ? Number(url.port)
      : url.protocol === 'https:'
        ? 443
        : 80;
    state.protocol = url.protocol.replace(':', '') as 'https' | 'http';
    state.verifySsl = jira.verify_ssl !== false;

    const isCloud = state.host.includes('atlassian.net');
    state.apiVersion = jira.api_version || (isCloud ? '3' : '2');
  }

  // Auth
  if (jira.auth) {
    if (jira.auth.email && jira.auth.api_token) {
      state.basicAuth = Buffer.from(
        `${jira.auth.email}:${jira.auth.api_token}`
      ).toString('base64');
    }
    if (jira.auth.bearer_token) {
      state.bearerToken = jira.auth.bearer_token;
    }
  }

  // Session cookies
  if (jira.session) {
    if (jira.session.cloud_session_token) {
      state.cookies['cloud.session.token'] = jira.session.cloud_session_token;
    }
    if (jira.session.tenant_token) {
      state.cookies['tenant.session.token'] = jira.session.tenant_token;
    }
    if (jira.session.atl_xsrf_token) {
      state.cookies['atl.xsrf.token'] = jira.session.atl_xsrf_token;
    }
    if (jira.session.jsessionid) {
      state.cookies['JSESSIONID'] = jira.session.jsessionid;
    }
    if (jira.session.atlassian_xsrf_token) {
      state.cookies['atlassian.xsrf.token'] = jira.session.atlassian_xsrf_token;
    }
    if (jira.session.cookies && typeof jira.session.cookies === 'object') {
      Object.assign(state.cookies, jira.session.cookies);
    }
  }

  return state;
}
