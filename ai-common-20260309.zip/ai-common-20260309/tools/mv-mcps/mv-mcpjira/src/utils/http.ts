import https from 'node:https';
import http from 'node:http';
import type { ClientState } from '../types/index.js';

function buildAuthHeaders(state: ClientState): Record<string, string> {
  if (state.basicAuth) {
    return { Authorization: `Basic ${state.basicAuth}` };
  }

  if (state.bearerToken) {
    return { Authorization: `Bearer ${state.bearerToken}` };
  }

  // Cookie-based auth
  const headers: Record<string, string> = {};
  const cookieParts: string[] = [];
  for (const [name, value] of Object.entries(state.cookies)) {
    if (value) cookieParts.push(`${name}=${value}`);
  }

  if (cookieParts.length > 0) {
    headers['Cookie'] = cookieParts.join('; ');
  }

  if (
    state.cookies['atl.xsrf.token'] ||
    state.cookies['atlassian.xsrf.token']
  ) {
    headers['X-Atlassian-Token'] = 'no-check';
  }

  return headers;
}

/** Encode a path segment to prevent path traversal */
function encodeSegment(value: string): string {
  return encodeURIComponent(String(value));
}

/**
 * Make an HTTP request to the Jira API.
 */
export async function jiraRequest(
  state: ClientState,
  method: string,
  apiPath: string,
  body?: unknown
): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const isWrite =
      method === 'POST' || method === 'PUT' || method === 'DELETE';
    let bodyStr = '';

    if (body && isWrite) {
      bodyStr = JSON.stringify(body);
    }

    const authHeaders = buildAuthHeaders(state);

    const options: https.RequestOptions = {
      hostname: state.host,
      port: state.port,
      path: apiPath,
      method,
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        ...authHeaders,
      },
      rejectUnauthorized: state.verifySsl,
    };

    if (isWrite && bodyStr) {
      (options.headers as Record<string, string>)['Content-Length'] = String(
        Buffer.byteLength(bodyStr)
      );
    }

    const proto = state.protocol === 'https' ? https : http;

    const req = proto.request(options, res => {
      let data = '';

      res.on('data', (chunk: string) => {
        data += chunk;
      });

      res.on('end', () => {
        if (res.statusCode && res.statusCode >= 400) {
          let errorMessage = `HTTP ${res.statusCode}`;
          try {
            const parsed = JSON.parse(data);
            errorMessage =
              parsed.errorMessages?.[0] ||
              parsed.message ||
              parsed.error ||
              errorMessage;
          } catch {
            errorMessage = data.substring(0, 200) || errorMessage;
          }
          reject(new Error(errorMessage));
          return;
        }

        if (res.statusCode === 204 || !data) {
          resolve({});
          return;
        }

        try {
          resolve(JSON.parse(data));
        } catch {
          resolve(data);
        }
      });
    });

    req.setTimeout(30000, () => {
      req.destroy(new Error('Request timeout after 30s'));
    });

    req.on('error', (error: Error) => {
      reject(new Error(error.message || String(error)));
    });

    if (isWrite && bodyStr) {
      req.write(bodyStr);
    }

    req.end();
  });
}

// Convenience helpers wrapping jiraRequest

export function encodePathSegment(value: string): string {
  return encodeSegment(value);
}
