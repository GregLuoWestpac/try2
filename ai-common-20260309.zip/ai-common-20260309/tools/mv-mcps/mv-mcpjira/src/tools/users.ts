import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { jiraRequest, encodePathSegment } from '../utils/http.js';
import type { ClientState } from '../types/index.js';

export function registerUserTools(server: McpServer, state: ClientState): void {
  server.registerTool(
    'find_users',
    {
      description: 'Find users by query (for assignment).',
      inputSchema: z.object({
        query: z.string().describe('Search query (name/email)'),
        start_at: z.number().optional().describe('Pagination startAt'),
        max_results: z.number().optional().describe('Max results'),
      }),
    },
    async ({ query, start_at, max_results }) => {
      const params: Record<string, string> = { query };
      if (max_results !== undefined) params.maxResults = String(max_results);
      if (start_at !== undefined) params.startAt = String(start_at);
      const qs = new URLSearchParams(params).toString();
      const result = await jiraRequest(
        state,
        'GET',
        `/rest/api/${state.apiVersion}/user/search?${qs}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_changelogs',
    {
      description: 'Get change history (changelog) for an issue.',
      inputSchema: z.object({
        key: z.string().describe('Issue key'),
        start_at: z.number().optional().describe('Pagination startAt'),
        max_results: z.number().optional().describe('Max results'),
      }),
    },
    async ({ key, start_at, max_results }) => {
      const params: Record<string, string> = {};
      if (start_at !== undefined) params.startAt = String(start_at);
      if (max_results !== undefined) params.maxResults = String(max_results);
      const qs = new URLSearchParams(params).toString();
      const result = await jiraRequest(
        state,
        'GET',
        `/rest/api/${state.apiVersion}/issue/${encodePathSegment(key)}/changelog${qs ? '?' + qs : ''}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );
}
