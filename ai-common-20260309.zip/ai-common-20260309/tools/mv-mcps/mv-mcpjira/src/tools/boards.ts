import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { jiraRequest, encodePathSegment } from '../utils/http.js';
import type { ClientState } from '../types/index.js';

export function registerBoardTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'get_boards',
    {
      description: 'List agile boards.',
      inputSchema: z.object({
        project: z
          .string()
          .optional()
          .describe('Project key or ID to filter boards'),
        type: z.enum(['scrum', 'kanban']).optional().describe('Board type'),
        name: z.string().optional().describe('Filter by board name'),
        start_at: z.number().optional().describe('Pagination startAt'),
        max_results: z.number().optional().describe('Max results'),
      }),
    },
    async ({ project, type, name, start_at, max_results }) => {
      const params: Record<string, string> = {};
      if (project) params.projectKeyOrId = project;
      if (type) params.type = type;
      if (name) params.name = name;
      params.startAt = String(start_at || 0);
      params.maxResults = String(max_results || 50);
      const qs = new URLSearchParams(params).toString();
      const result = await jiraRequest(
        state,
        'GET',
        `/rest/agile/1.0/board?${qs}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_sprints',
    {
      description: 'List sprints for a board.',
      inputSchema: z.object({
        board_id: z.number().describe('Board ID'),
        state: z
          .enum(['future', 'active', 'closed'])
          .optional()
          .describe('Sprint state filter'),
        start_at: z.number().optional().describe('Pagination startAt'),
        max_results: z.number().optional().describe('Max results'),
      }),
    },
    async ({ board_id, state: sprintState, start_at, max_results }) => {
      const params: Record<string, string> = {};
      if (sprintState) params.state = sprintState;
      params.startAt = String(start_at || 0);
      params.maxResults = String(max_results || 50);
      const qs = new URLSearchParams(params).toString();
      const result = await jiraRequest(
        state,
        'GET',
        `/rest/agile/1.0/board/${encodePathSegment(String(board_id))}/sprint?${qs}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_sprint_issues',
    {
      description: 'Get issues in a sprint.',
      inputSchema: z.object({
        sprint_id: z.number().describe('Sprint ID'),
        jql: z.string().optional().describe('Optional additional JQL filter'),
        fields: z.array(z.string()).optional().describe('Fields to include'),
        start_at: z.number().optional().describe('Pagination startAt'),
        max_results: z.number().optional().describe('Max results'),
      }),
    },
    async ({ sprint_id, jql, fields, start_at, max_results }) => {
      const params: Record<string, string> = {};
      if (jql) params.jql = jql;
      if (fields) params.fields = fields.join(',');
      params.startAt = String(start_at || 0);
      params.maxResults = String(max_results || 50);
      const qs = new URLSearchParams(params).toString();
      const result = await jiraRequest(
        state,
        'GET',
        `/rest/agile/1.0/sprint/${encodePathSegment(String(sprint_id))}/issue?${qs}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'move_to_sprint',
    {
      description: 'Move one or more issues to a sprint.',
      inputSchema: z.object({
        sprint_id: z.number().describe('Sprint ID'),
        issues: z.array(z.string()).describe('Issue keys to move'),
      }),
    },
    async ({ sprint_id, issues }) => {
      await jiraRequest(
        state,
        'POST',
        `/rest/agile/1.0/sprint/${encodePathSegment(String(sprint_id))}/issue`,
        { issues }
      );
      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(
              { status: 'moved', sprintId: sprint_id, issues },
              null,
              2
            ),
          },
        ],
      };
    }
  );
}
