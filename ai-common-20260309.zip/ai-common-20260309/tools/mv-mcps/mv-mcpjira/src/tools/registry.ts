import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ClientState } from '../types/index.js';
import { registerIssueTools } from './issues.js';
import { registerCommentTools } from './comments.js';
import { registerTransitionTools } from './transitions.js';
import { registerLinkTools } from './links.js';
import { registerBoardTools } from './boards.js';
import { registerProjectTools } from './projects.js';
import { registerUserTools } from './users.js';

export function registerAllTools(server: McpServer, state: ClientState): void {
  registerIssueTools(server, state);
  registerCommentTools(server, state);
  registerTransitionTools(server, state);
  registerLinkTools(server, state);
  registerBoardTools(server, state);
  registerProjectTools(server, state);
  registerUserTools(server, state);
}
