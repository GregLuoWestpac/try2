import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { jiraRequest, encodePathSegment } from '../utils/http.js';
import type { ClientState } from '../types/index.js';

export function registerIssueTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'get_issue',
    {
      description: 'Get Jira issue details by issue key (e.g., PROJ-123).',
      inputSchema: z.object({
        key: z.string().describe('Issue key'),
        fields: z
          .array(z.string())
          .optional()
          .describe('Fields to include (optional)'),
        expand: z
          .array(z.string())
          .optional()
          .describe('Expand options (optional)'),
      }),
    },
    async ({ key, fields, expand }) => {
      const params: Record<string, string> = {};
      if (fields) params.fields = fields.join(',');
      if (expand) params.expand = expand.join(',');
      const qs = new URLSearchParams(params).toString();
      const path = `/rest/api/${state.apiVersion}/issue/${encodePathSegment(key)}${qs ? '?' + qs : ''}`;
      const result = await jiraRequest(state, 'GET', path);
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'search_issues',
    {
      description: 'Search Jira issues using JQL.',
      inputSchema: z.object({
        jql: z.string().describe('JQL query'),
        start_at: z
          .number()
          .optional()
          .describe('Pagination startAt (default: 0)'),
        max_results: z
          .number()
          .optional()
          .describe('Max results (default: 50)'),
        fields: z
          .array(z.string())
          .optional()
          .describe('Fields to include (optional)'),
        expand: z
          .array(z.string())
          .optional()
          .describe('Expand options (optional)'),
      }),
    },
    async ({ jql, start_at, max_results, fields, expand }) => {
      const body: Record<string, unknown> = {
        jql,
        startAt: start_at || 0,
        maxResults: max_results || 50,
      };
      if (fields) body.fields = fields;
      if (expand) body.expand = expand;
      const result = await jiraRequest(
        state,
        'POST',
        `/rest/api/${state.apiVersion}/search`,
        body
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'create_issue',
    {
      description: 'Create a new Jira issue.',
      inputSchema: z.object({
        fields: z
          .record(z.string(), z.unknown())
          .describe(
            'Issue fields payload (fields.*). Must include project, issuetype, summary.'
          ),
      }),
    },
    async ({ fields }) => {
      const result = await jiraRequest(
        state,
        'POST',
        `/rest/api/${state.apiVersion}/issue`,
        { fields }
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'update_issue',
    {
      description: 'Update Jira issue fields.',
      inputSchema: z.object({
        key: z.string().describe('Issue key'),
        fields: z
          .record(z.string(), z.unknown())
          .describe('Fields to set (fields.*).'),
      }),
    },
    async ({ key, fields }) => {
      await jiraRequest(
        state,
        'PUT',
        `/rest/api/${state.apiVersion}/issue/${encodePathSegment(key)}`,
        { fields }
      );
      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify({ status: 'updated', key }, null, 2),
          },
        ],
      };
    }
  );
}
