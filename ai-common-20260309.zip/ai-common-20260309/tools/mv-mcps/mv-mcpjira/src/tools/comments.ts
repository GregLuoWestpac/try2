import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { jiraRequest, encodePathSegment } from '../utils/http.js';
import type { ClientState } from '../types/index.js';

export function registerCommentTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'add_comment',
    {
      description: 'Add a comment to an issue.',
      inputSchema: z.object({
        key: z.string().describe('Issue key'),
        comment: z.string().describe('Comment text'),
      }),
    },
    async ({ key, comment }) => {
      const commentBody =
        state.apiVersion === '3'
          ? {
              body: {
                type: 'doc',
                version: 1,
                content: [
                  {
                    type: 'paragraph',
                    content: [{ type: 'text', text: comment }],
                  },
                ],
              },
            }
          : { body: comment };
      const result = await jiraRequest(
        state,
        'POST',
        `/rest/api/${state.apiVersion}/issue/${encodePathSegment(key)}/comment`,
        commentBody
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_comments',
    {
      description: 'Get comments for an issue.',
      inputSchema: z.object({
        key: z.string().describe('Issue key'),
        start_at: z.number().optional().describe('Pagination startAt'),
        max_results: z.number().optional().describe('Max results'),
        order_by: z.string().optional().describe('Order by (e.g., created)'),
      }),
    },
    async ({ key, start_at, max_results, order_by }) => {
      const params: Record<string, string> = {};
      if (start_at !== undefined) params.startAt = String(start_at);
      if (max_results !== undefined) params.maxResults = String(max_results);
      if (order_by) params.orderBy = order_by;
      const qs = new URLSearchParams(params).toString();
      const result = await jiraRequest(
        state,
        'GET',
        `/rest/api/${state.apiVersion}/issue/${encodePathSegment(key)}/comment${qs ? '?' + qs : ''}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );
}
