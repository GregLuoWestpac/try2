import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { jiraRequest, encodePathSegment } from '../utils/http.js';
import type { ClientState } from '../types/index.js';

export function registerLinkTools(server: McpServer, state: ClientState): void {
  server.registerTool(
    'link_issues',
    {
      description: 'Create a link between two issues.',
      inputSchema: z.object({
        type: z.string().describe('Link type name (e.g., "Blocks", "Relates")'),
        inward_issue: z.string().describe('Inward issue key'),
        outward_issue: z.string().describe('Outward issue key'),
      }),
    },
    async ({ type, inward_issue, outward_issue }) => {
      await jiraRequest(
        state,
        'POST',
        `/rest/api/${state.apiVersion}/issueLink`,
        {
          type: { name: type },
          inwardIssue: { key: inward_issue },
          outwardIssue: { key: outward_issue },
        }
      );
      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(
              {
                status: 'linked',
                type,
                inwardIssue: inward_issue,
                outwardIssue: outward_issue,
              },
              null,
              2
            ),
          },
        ],
      };
    }
  );

  server.registerTool(
    'get_issue_links',
    {
      description: 'Get all issue links for an issue.',
      inputSchema: z.object({
        key: z.string().describe('Issue key'),
      }),
    },
    async ({ key }) => {
      const params: Record<string, string> = { fields: 'issuelinks' };
      const qs = new URLSearchParams(params).toString();
      const issue = (await jiraRequest(
        state,
        'GET',
        `/rest/api/${state.apiVersion}/issue/${encodePathSegment(key)}?${qs}`
      )) as { fields?: { issuelinks?: unknown[] } };
      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(
              { issueLinks: issue.fields?.issuelinks || [] },
              null,
              2
            ),
          },
        ],
      };
    }
  );

  server.registerTool(
    'get_subtasks',
    {
      description: 'Get subtasks for a parent issue.',
      inputSchema: z.object({
        key: z.string().describe('Issue key'),
      }),
    },
    async ({ key }) => {
      const params: Record<string, string> = { fields: 'subtasks' };
      const qs = new URLSearchParams(params).toString();
      const issue = (await jiraRequest(
        state,
        'GET',
        `/rest/api/${state.apiVersion}/issue/${encodePathSegment(key)}?${qs}`
      )) as { fields?: { subtasks?: unknown[] } };
      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(
              { subtasks: issue.fields?.subtasks || [] },
              null,
              2
            ),
          },
        ],
      };
    }
  );
}
