import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { jiraRequest, encodePathSegment } from '../utils/http.js';
import type { ClientState } from '../types/index.js';

export function registerTransitionTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'transition_issue',
    {
      description: 'Transition an issue to a new status by transition ID.',
      inputSchema: z.object({
        key: z.string().describe('Issue key'),
        transition_id: z.string().describe('Transition ID'),
      }),
    },
    async ({ key, transition_id }) => {
      await jiraRequest(
        state,
        'POST',
        `/rest/api/${state.apiVersion}/issue/${encodePathSegment(key)}/transitions`,
        { transition: { id: transition_id } }
      );
      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(
              { status: 'transitioned', key, transitionId: transition_id },
              null,
              2
            ),
          },
        ],
      };
    }
  );

  server.registerTool(
    'get_transitions',
    {
      description: 'Get available transitions for an issue.',
      inputSchema: z.object({
        key: z.string().describe('Issue key'),
      }),
    },
    async ({ key }) => {
      const result = await jiraRequest(
        state,
        'GET',
        `/rest/api/${state.apiVersion}/issue/${encodePathSegment(key)}/transitions`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'assign_issue',
    {
      description: 'Assign/reassign an issue to a user accountId.',
      inputSchema: z.object({
        key: z.string().describe('Issue key'),
        account_id: z.string().describe('Atlassian accountId'),
      }),
    },
    async ({ key, account_id }) => {
      await jiraRequest(
        state,
        'PUT',
        `/rest/api/${state.apiVersion}/issue/${encodePathSegment(key)}/assignee`,
        { accountId: account_id }
      );
      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(
              { status: 'assigned', key, accountId: account_id },
              null,
              2
            ),
          },
        ],
      };
    }
  );
}
