import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { jiraRequest, encodePathSegment } from '../utils/http.js';
import type { ClientState } from '../types/index.js';

export function registerProjectTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'get_projects',
    {
      description: 'List accessible Jira projects.',
      inputSchema: z.object({
        expand: z.array(z.string()).optional().describe('Expand options'),
        start_at: z.number().optional().describe('Pagination startAt'),
        max_results: z.number().optional().describe('Max results'),
      }),
    },
    async ({ expand, start_at, max_results }) => {
      const params: Record<string, string> = {};
      if (expand) params.expand = expand.join(',');
      params.startAt = String(start_at || 0);
      params.maxResults = String(max_results || 50);
      const qs = new URLSearchParams(params).toString();
      const result = await jiraRequest(
        state,
        'GET',
        `/rest/api/${state.apiVersion}/project/search?${qs}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_project_statuses',
    {
      description: 'Get statuses for a project (workflows by issue type).',
      inputSchema: z.object({
        project: z.string().describe('Project key or ID'),
      }),
    },
    async ({ project }) => {
      const result = await jiraRequest(
        state,
        'GET',
        `/rest/api/${state.apiVersion}/project/${encodePathSegment(project)}/statuses`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_issue_types',
    {
      description: 'Get issue types for a project.',
      inputSchema: z.object({
        project: z.string().describe('Project key or ID'),
      }),
    },
    async ({ project }) => {
      const result = (await jiraRequest(
        state,
        'GET',
        `/rest/api/${state.apiVersion}/project/${encodePathSegment(project)}`
      )) as { issueTypes?: unknown[] };
      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(
              { issueTypes: result.issueTypes || [] },
              null,
              2
            ),
          },
        ],
      };
    }
  );
}
