#!/usr/bin/env node

/**
 * mv-mcpjira — Jira MCP Server
 *
 * Starts a stdio-based MCP server providing Jira tools for issue tracking,
 * sprint management, and project workflows.
 * Built with the official @modelcontextprotocol/sdk TypeScript SDK.
 *
 * Usage:
 *   npx @mesh-tenant-multiverse-ui-common/mv-mcpjira
 */

import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { loadConfig } from './utils/config.js';
import { createServer } from './server.js';

async function main() {
  const state = loadConfig();

  if (!state.host) {
    console.error(
      '[mv-mcpjira] ERROR: No Jira host configured in ~/.jira_mcp.local.yaml'
    );
    process.exit(1);
  }

  const server = createServer(state);
  const transport = new StdioServerTransport();
  await server.connect(transport);

  console.error(
    `[mv-mcpjira] Server ready (STDIO transport, host: ${state.protocol}://${state.host}:${state.port})`
  );
}

main().catch(error => {
  console.error('Failed to start mv-mcpjira:', error);
  process.exit(1);
});
