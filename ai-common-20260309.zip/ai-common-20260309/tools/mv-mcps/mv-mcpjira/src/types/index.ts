export interface JiraConfig {
  jira?: {
    host?: string;
    verify_ssl?: boolean;
    api_version?: string;
    auth?: {
      email?: string;
      api_token?: string;
      bearer_token?: string;
    };
    session?: {
      cloud_session_token?: string;
      tenant_token?: string;
      atl_xsrf_token?: string;
      jsessionid?: string;
      atlassian_xsrf_token?: string;
      cookies?: Record<string, string>;
      obtained_at?: string;
    };
    sso?: {
      email?: string;
      headless?: boolean;
      timeout_seconds?: number;
    };
  };
  keepalive?: {
    enabled?: boolean;
    interval_seconds?: number;
  };
}

export interface ClientState {
  host: string;
  port: number;
  protocol: 'https' | 'http';
  verifySsl: boolean;
  apiVersion: string;
  basicAuth: string | null;
  bearerToken: string | null;
  cookies: Record<string, string>;
}

export interface RequestOptions {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  path: string;
  body?: unknown;
}
