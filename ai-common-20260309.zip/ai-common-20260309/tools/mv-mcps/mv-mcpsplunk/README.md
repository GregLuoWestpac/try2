# mv-mcpsplunk

MCP server for Splunk — search, monitor, and diagnose with Splunk.

## What It Does

Provides an MCP (Model Context Protocol) server that exposes Splunk tools for use with AI assistants like GitHub Copilot, Claude Code, and other MCP-compatible clients.

### Available Tools

- **Session management**: `start_session`, `reset_session`, `sso_login`, `authenticate`
- **Search operations**: `search`, `search_oneshot`, `get_search_job`, `get_search_results`
- **Saved searches**: `get_saved_searches`, `run_saved_search`
- **System monitoring**: `get_server_info`, `get_indexes`
- **KV Store**: `get_kvstore_collections`, `get_kvstore_data`

## Prerequisites

- **Node.js** (v18 or higher)
- **Splunk Enterprise/Cloud** instance with API access
- **Edge or Chrome browser** (for SSO login only)

## Installation

No installation needed — run directly with `npx`:

```bash
npx @mesh-tenant-multiverse-ui-common/mv-mcpsplunk
```

## Configuration

Create a config file at `~/.splunk_mcp.local.yaml`:

```yaml
splunk:
  host: "https://your-instance.splunkcloud.com/"
  verify_ssl: true
  sso:
    email: "your.email@company.com"
```

Or use environment variables:
- `SPLUNK_HOST` — Splunk host URL
- `SPLUNK_TOKEN` — Splunk auth token
- `SPLUNK_USERNAME` / `SPLUNK_PASSWORD` — Basic auth credentials
- `SPLUNK_SSO_EMAIL` — SSO email
- `SPLUNK_SSO_PASSWORD` — SSO password (for headless login)

## VS Code MCP Configuration

Add to your VS Code `settings.json`:

```json
{
  "mcp": {
    "servers": {
      "splunk": {
        "command": "npx",
        "args": ["@mesh-tenant-multiverse-ui-common/mv-mcpsplunk"]
      }
    }
  }
}
```

## Command Options

```
npx @mesh-tenant-multiverse-ui-common/mv-mcpsplunk [options]

Options:
  --verbose, -v   Enable verbose logging to stderr
  --help, -h      Show help message
```
