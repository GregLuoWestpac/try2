import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ClientState } from '../types/index.js';
import { registerSessionTools } from './session.js';
import { registerSearchTools } from './search.js';
import { registerIndexTools } from './indexes.js';
import { registerDiagnosticTools } from './diagnostics.js';
import { registerSavedSearchTools } from './saved-searches.js';
import { registerSystemTools } from './system.js';

export function registerAllTools(server: McpServer, state: ClientState): void {
  registerSessionTools(server, state);
  registerSearchTools(server, state);
  registerIndexTools(server, state);
  registerDiagnosticTools(server, state);
  registerSavedSearchTools(server, state);
  registerSystemTools(server, state);
}
