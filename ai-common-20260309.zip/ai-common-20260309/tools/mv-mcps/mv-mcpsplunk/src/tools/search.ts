import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ClientState } from '../types/index.js';
import { splunkRequest, parseSearchResults } from '../utils/http.js';
import { ensureAuthenticated } from '../utils/auth.js';

export function registerSearchTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'search',
    {
      description:
        'Execute a Splunk search query (SPL). Returns a search job ID for async searches, or results for fast queries.',
      inputSchema: z.object({
        query: z
          .string()
          .describe('SPL search query (e.g., "index=main error | head 10")'),
        earliest_time: z
          .string()
          .optional()
          .describe('Start time (e.g., "-1h", "-7d", "2024-01-01T00:00:00")'),
        latest_time: z
          .string()
          .optional()
          .describe('End time (e.g., "now", "-1h", "2024-01-02T00:00:00")'),
        max_results: z
          .number()
          .optional()
          .describe('Maximum number of results to return (default: 100)'),
        exec_mode: z
          .enum(['normal', 'blocking', 'oneshot'])
          .optional()
          .describe('Execution mode'),
      }),
    },
    async ({ query, earliest_time, latest_time, max_results, exec_mode }) => {
      await ensureAuthenticated(state);

      const searchQuery = query.startsWith('search ')
        ? query
        : `search ${query}`;
      const mode = exec_mode || 'blocking';
      const params: Record<string, string | number> = {
        search: searchQuery,
        earliest_time: earliest_time || '-24h',
        latest_time: latest_time || 'now',
        max_count: max_results || 100,
        exec_mode: mode,
        output_mode: 'json',
      };

      const response = (await splunkRequest(
        state,
        'POST',
        '/services/search/jobs',
        params
      )) as {
        sid?: string;
      };

      if (mode === 'blocking' || mode === 'oneshot') {
        const sid = response.sid;
        if (sid) {
          const results = await splunkRequest(
            state,
            'GET',
            `/services/search/jobs/${sid}/results`,
            { count: max_results || 100, output_mode: 'json' }
          );
          return {
            content: [
              {
                type: 'text' as const,
                text: JSON.stringify(parseSearchResults(results), null, 2),
              },
            ],
          };
        }
      }

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(
              { sid: response.sid, status: 'created' },
              null,
              2
            ),
          },
        ],
      };
    }
  );

  server.registerTool(
    'search_oneshot',
    {
      description:
        'Execute a one-shot Splunk search that blocks until complete. Best for quick queries.',
      inputSchema: z.object({
        query: z.string().describe('SPL search query'),
        earliest_time: z
          .string()
          .optional()
          .describe('Start time (default: -1h)'),
        latest_time: z.string().optional().describe('End time (default: now)'),
        max_results: z
          .number()
          .optional()
          .describe('Maximum results (default: 1000)'),
      }),
    },
    async ({ query, earliest_time, latest_time, max_results }) => {
      await ensureAuthenticated(state);

      const searchQuery = query.startsWith('search ')
        ? query
        : `search ${query}`;
      const response = await splunkRequest(
        state,
        'POST',
        '/services/search/jobs/export',
        {
          search: searchQuery,
          earliest_time: earliest_time || '-1h',
          latest_time: latest_time || 'now',
          max_count: max_results || 1000,
          output_mode: 'json',
        }
      );

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(parseSearchResults(response), null, 2),
          },
        ],
      };
    }
  );

  server.registerTool(
    'get_search_status',
    {
      description: 'Check the status of an asynchronous search job.',
      inputSchema: z.object({
        sid: z.string().describe('Search job ID returned from search command'),
      }),
    },
    async ({ sid }) => {
      await ensureAuthenticated(state);

      const response = (await splunkRequest(
        state,
        'GET',
        `/services/search/jobs/${sid}`,
        { output_mode: 'json' }
      )) as { entry?: Array<{ content?: Record<string, unknown> }> };

      const job = response.entry?.[0]?.content || {};
      const result = {
        sid,
        status: job.dispatchState,
        isDone: job.isDone,
        isFailed: job.isFailed,
        resultCount: job.resultCount,
        eventCount: job.eventCount,
        doneProgress: job.doneProgress,
        runDuration: job.runDuration,
      };

      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_search_results',
    {
      description: 'Get results from a completed search job.',
      inputSchema: z.object({
        sid: z.string().describe('Search job ID'),
        offset: z
          .number()
          .optional()
          .describe('Starting offset for pagination (default: 0)'),
        count: z
          .number()
          .optional()
          .describe('Number of results to return (default: 100)'),
        output_mode: z
          .enum(['json', 'csv', 'xml'])
          .optional()
          .describe('Output format'),
      }),
    },
    async ({ sid, offset, count, output_mode }) => {
      await ensureAuthenticated(state);

      const response = await splunkRequest(
        state,
        'GET',
        `/services/search/jobs/${sid}/results`,
        {
          offset: offset || 0,
          count: count || 100,
          output_mode: output_mode || 'json',
        }
      );

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(parseSearchResults(response), null, 2),
          },
        ],
      };
    }
  );

  server.registerTool(
    'cancel_search',
    {
      description: 'Cancel a running search job.',
      inputSchema: z.object({
        sid: z.string().describe('Search job ID to cancel'),
      }),
    },
    async ({ sid }) => {
      await ensureAuthenticated(state);

      await splunkRequest(
        state,
        'POST',
        `/services/search/jobs/${sid}/control`,
        { action: 'cancel', output_mode: 'json' }
      );

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify({ sid, status: 'cancelled' }, null, 2),
          },
        ],
      };
    }
  );

  server.registerTool(
    'search_export',
    {
      description:
        'Export large search results. Returns results in streaming format.',
      inputSchema: z.object({
        query: z.string().describe('SPL search query'),
        earliest_time: z.string().optional().describe('Start time'),
        latest_time: z.string().optional().describe('End time'),
        output_mode: z
          .enum(['json', 'csv', 'xml'])
          .optional()
          .describe('Output format'),
      }),
    },
    async ({ query, earliest_time, latest_time, output_mode }) => {
      await ensureAuthenticated(state);

      const searchQuery = query.startsWith('search ')
        ? query
        : `search ${query}`;
      const response = await splunkRequest(
        state,
        'POST',
        '/services/search/jobs/export',
        {
          search: searchQuery,
          earliest_time: earliest_time || '-24h',
          latest_time: latest_time || 'now',
          output_mode: output_mode || 'json',
        }
      );

      return {
        content: [
          {
            type: 'text' as const,
            text:
              typeof response === 'string'
                ? response
                : JSON.stringify(response, null, 2),
          },
        ],
      };
    }
  );
}
