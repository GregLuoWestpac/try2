import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ClientState } from '../types/index.js';
import { splunkRequest, parseSearchResults } from '../utils/http.js';
import { ensureAuthenticated } from '../utils/auth.js';

export function registerDiagnosticTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'find_errors',
    {
      description:
        'Search for errors in logs. Automatically searches for common error patterns.',
      inputSchema: z.object({
        index: z
          .string()
          .optional()
          .describe('Index to search (default: main)'),
        earliest_time: z
          .string()
          .optional()
          .describe('Start time (default: -1h)'),
        latest_time: z.string().optional().describe('End time (default: now)'),
        severity: z
          .enum(['ERROR', 'WARN', 'FATAL', 'CRITICAL', 'ALL'])
          .optional()
          .describe('Error severity level'),
        application: z
          .string()
          .optional()
          .describe('Filter by application/service name'),
        host: z.string().optional().describe('Filter by host'),
        max_results: z
          .number()
          .optional()
          .describe('Maximum results (default: 50)'),
      }),
    },
    async ({
      index,
      earliest_time,
      latest_time,
      severity,
      application,
      host,
      max_results,
    }) => {
      await ensureAuthenticated(state);

      const idx = index || 'main';
      const sev = severity || 'ERROR';
      const severityFilter =
        sev === 'ALL'
          ? '(ERROR OR WARN OR FATAL OR CRITICAL OR Exception)'
          : sev;

      let query = `search index=${idx} ${severityFilter}`;
      if (application) query += ` application="${application}"`;
      if (host) query += ` host="${host}"`;
      query += ' | head ' + (max_results || 50);
      query += ' | table _time, host, source, sourcetype, _raw';

      const response = await splunkRequest(
        state,
        'POST',
        '/services/search/jobs/export',
        {
          search: query,
          earliest_time: earliest_time || '-1h',
          latest_time: latest_time || 'now',
          max_count: max_results || 50,
          output_mode: 'json',
        }
      );

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(parseSearchResults(response), null, 2),
          },
        ],
      };
    }
  );

  server.registerTool(
    'find_exceptions',
    {
      description: 'Search for exceptions and stack traces in logs.',
      inputSchema: z.object({
        index: z
          .string()
          .optional()
          .describe('Index to search (default: main)'),
        earliest_time: z
          .string()
          .optional()
          .describe('Start time (default: -1h)'),
        exception_type: z
          .string()
          .optional()
          .describe(
            'Specific exception type to search for (e.g., NullPointerException)'
          ),
        application: z
          .string()
          .optional()
          .describe('Filter by application name'),
        max_results: z
          .number()
          .optional()
          .describe('Maximum results (default: 20)'),
      }),
    },
    async ({
      index,
      earliest_time,
      exception_type,
      application,
      max_results,
    }) => {
      await ensureAuthenticated(state);

      const idx = index || 'main';
      const exceptionPattern =
        exception_type || 'Exception OR Traceback OR "stack trace" OR Error:';

      let query = `search index=${idx} (${exceptionPattern})`;
      if (application) query += ` application="${application}"`;
      query += ' | head ' + (max_results || 20);
      query += ' | table _time, host, source, _raw';

      const response = await splunkRequest(
        state,
        'POST',
        '/services/search/jobs/export',
        {
          search: query,
          earliest_time: earliest_time || '-1h',
          latest_time: 'now',
          output_mode: 'json',
        }
      );

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(parseSearchResults(response), null, 2),
          },
        ],
      };
    }
  );

  server.registerTool(
    'analyze_latency',
    {
      description: 'Analyze response times and latency patterns in logs.',
      inputSchema: z.object({
        index: z.string().describe('Index to search'),
        latency_field: z
          .string()
          .optional()
          .describe(
            'Field containing latency/duration value (default: duration)'
          ),
        earliest_time: z
          .string()
          .optional()
          .describe('Start time (default: -1h)'),
        latest_time: z.string().optional().describe('End time (default: now)'),
        group_by: z
          .string()
          .optional()
          .describe('Field to group statistics by (e.g., endpoint, host)'),
        threshold_ms: z
          .number()
          .optional()
          .describe('Highlight latencies above this threshold in ms'),
      }),
    },
    async ({ index, latency_field, earliest_time, latest_time, group_by }) => {
      await ensureAuthenticated(state);

      const field = latency_field || 'duration';
      const groupBy = group_by || 'host';

      let query = `search index=${index} ${field}=*`;
      query += ` | stats avg(${field}) as avg_latency, max(${field}) as max_latency, min(${field}) as min_latency, p95(${field}) as p95_latency, count by ${groupBy}`;
      query += ' | sort -avg_latency';

      const response = await splunkRequest(
        state,
        'POST',
        '/services/search/jobs/export',
        {
          search: query,
          earliest_time: earliest_time || '-1h',
          latest_time: latest_time || 'now',
          output_mode: 'json',
        }
      );

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(parseSearchResults(response), null, 2),
          },
        ],
      };
    }
  );

  server.registerTool(
    'trace_transaction',
    {
      description:
        'Trace a transaction or request across multiple log sources using a transaction ID.',
      inputSchema: z.object({
        transaction_id: z
          .string()
          .describe('Transaction/correlation/request ID to trace'),
        index: z
          .string()
          .optional()
          .describe('Index to search (default: * for all)'),
        id_field: z
          .string()
          .optional()
          .describe(
            'Field name containing the transaction ID (default: auto-detect)'
          ),
        earliest_time: z
          .string()
          .optional()
          .describe('Start time (default: -24h)'),
      }),
    },
    async ({ transaction_id, index, earliest_time }) => {
      await ensureAuthenticated(state);

      const idx = index || '*';
      const txId = transaction_id;

      let query = `search index=${idx} ("${txId}" OR transaction_id="${txId}" OR correlation_id="${txId}" OR request_id="${txId}" OR trace_id="${txId}")`;
      query += ' | sort _time | table _time, host, source, sourcetype, _raw';

      const response = await splunkRequest(
        state,
        'POST',
        '/services/search/jobs/export',
        {
          search: query,
          earliest_time: earliest_time || '-24h',
          latest_time: 'now',
          max_count: 500,
          output_mode: 'json',
        }
      );

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(parseSearchResults(response), null, 2),
          },
        ],
      };
    }
  );

  server.registerTool(
    'correlate_events',
    {
      description:
        'Correlate events across multiple sources within a time window.',
      inputSchema: z.object({
        search_terms: z
          .string()
          .describe('Search terms to find related events'),
        index: z.string().optional().describe('Index to search (default: *)'),
        time_window: z
          .string()
          .optional()
          .describe('Time window for correlation (default: 5m)'),
        earliest_time: z.string().optional().describe('Start time'),
        group_by: z
          .string()
          .optional()
          .describe('Field to correlate on (e.g., host, user)'),
      }),
    },
    async ({ search_terms, index, time_window, earliest_time, group_by }) => {
      await ensureAuthenticated(state);

      const idx = index || '*';
      const groupBy = group_by || 'host';

      let query = `search index=${idx} ${search_terms}`;
      query += ` | bin _time span=${time_window || '5m'}`;
      query += ` | stats count, values(source) as sources, values(sourcetype) as sourcetypes by _time, ${groupBy}`;
      query += ' | sort _time';

      const response = await splunkRequest(
        state,
        'POST',
        '/services/search/jobs/export',
        {
          search: query,
          earliest_time: earliest_time || '-1h',
          latest_time: 'now',
          output_mode: 'json',
        }
      );

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(parseSearchResults(response), null, 2),
          },
        ],
      };
    }
  );

  server.registerTool(
    'get_field_summary',
    {
      description: 'Get summary statistics for a specific field in the data.',
      inputSchema: z.object({
        field: z.string().describe('Field name to analyze'),
        index: z
          .string()
          .optional()
          .describe('Index to search (default: main)'),
        earliest_time: z
          .string()
          .optional()
          .describe('Start time (default: -1h)'),
        top_values: z
          .number()
          .optional()
          .describe('Number of top values to show (default: 10)'),
      }),
    },
    async ({ field, index, earliest_time, top_values }) => {
      await ensureAuthenticated(state);

      const idx = index || 'main';
      const topN = top_values || 10;

      let query = `search index=${idx} ${field}=*`;
      query += ` | stats count, dc(${field}) as unique_values, values(${field}) as sample_values by index`;
      query += ` | append [search index=${idx} ${field}=* | top ${topN} ${field}]`;

      const response = await splunkRequest(
        state,
        'POST',
        '/services/search/jobs/export',
        {
          search: query,
          earliest_time: earliest_time || '-1h',
          latest_time: 'now',
          output_mode: 'json',
        }
      );

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(parseSearchResults(response), null, 2),
          },
        ],
      };
    }
  );
}
