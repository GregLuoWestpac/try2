import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ClientState } from '../types/index.js';
import { splunkRequest, parseSearchResults } from '../utils/http.js';
import { ensureAuthenticated } from '../utils/auth.js';

export function registerIndexTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'list_indexes',
    {
      description:
        'List all available Splunk indexes with their status and event counts.',
      inputSchema: z.object({
        filter: z
          .string()
          .optional()
          .describe('Filter indexes by name pattern'),
      }),
    },
    async ({ filter }) => {
      await ensureAuthenticated(state);

      const response = (await splunkRequest(
        state,
        'GET',
        '/services/data/indexes',
        { output_mode: 'json', count: 0 }
      )) as {
        entry?: Array<{
          name: string;
          content?: Record<string, unknown>;
        }>;
      };

      let indexes = (response.entry || []).map(entry => ({
        name: entry.name,
        totalEventCount: entry.content?.totalEventCount,
        currentDBSizeMB: entry.content?.currentDBSizeMB,
        maxDataSizeMB: entry.content?.maxDataSizeMB,
        disabled: entry.content?.disabled,
      }));

      if (filter) {
        const regex = new RegExp(filter, 'i');
        indexes = indexes.filter(idx => regex.test(idx.name));
      }

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify({ indexes }, null, 2),
          },
        ],
      };
    }
  );

  server.registerTool(
    'get_index_info',
    {
      description: 'Get detailed information about a specific index.',
      inputSchema: z.object({
        index: z.string().describe('Name of the index'),
      }),
    },
    async ({ index }) => {
      await ensureAuthenticated(state);

      const response = (await splunkRequest(
        state,
        'GET',
        `/services/data/indexes/${index}`,
        { output_mode: 'json' }
      )) as {
        entry?: Array<{ name: string; content?: Record<string, unknown> }>;
      };

      const entry = response.entry?.[0];
      if (!entry) {
        throw new Error(`Index not found: ${index}`);
      }

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(
              { name: entry.name, ...entry.content },
              null,
              2
            ),
          },
        ],
      };
    }
  );

  server.registerTool(
    'list_sourcetypes',
    {
      description: 'List all sourcetypes in an index or across all indexes.',
      inputSchema: z.object({
        index: z
          .string()
          .optional()
          .describe('Limit to specific index (optional)'),
        earliest_time: z
          .string()
          .optional()
          .describe('Start time for sourcetype discovery'),
      }),
    },
    async ({ index, earliest_time }) => {
      await ensureAuthenticated(state);

      let query = 'search ';
      query += index ? `index=${index} ` : 'index=* ';
      query += '| stats count by sourcetype | sort -count';

      const searchQuery = query.startsWith('search ')
        ? query
        : `search ${query}`;
      const response = await splunkRequest(
        state,
        'POST',
        '/services/search/jobs/export',
        {
          search: searchQuery,
          earliest_time: earliest_time || '-24h',
          latest_time: 'now',
          output_mode: 'json',
        }
      );

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(parseSearchResults(response), null, 2),
          },
        ],
      };
    }
  );

  server.registerTool(
    'get_earliest_time',
    {
      description: 'Get the timestamp of the earliest event in an index.',
      inputSchema: z.object({
        index: z.string().describe('Index name'),
        sourcetype: z
          .string()
          .optional()
          .describe('Optional sourcetype filter'),
      }),
    },
    async ({ index, sourcetype }) => {
      await ensureAuthenticated(state);

      const query = `search index=${index}${sourcetype ? ` sourcetype=${sourcetype}` : ''} | head 1 | eval earliest=_time | table earliest`;
      const response = await splunkRequest(
        state,
        'POST',
        '/services/search/jobs/export',
        {
          search: query,
          earliest_time: '0',
          latest_time: 'now',
          max_count: 1,
          output_mode: 'json',
        }
      );

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(parseSearchResults(response), null, 2),
          },
        ],
      };
    }
  );

  server.registerTool(
    'get_latest_time',
    {
      description:
        'Get the timestamp of the latest/most recent event in an index.',
      inputSchema: z.object({
        index: z.string().describe('Index name'),
        sourcetype: z
          .string()
          .optional()
          .describe('Optional sourcetype filter'),
      }),
    },
    async ({ index, sourcetype }) => {
      await ensureAuthenticated(state);

      const query = `search index=${index}${sourcetype ? ` sourcetype=${sourcetype}` : ''} | head 1 | eval latest=_time | table latest`;
      const response = await splunkRequest(
        state,
        'POST',
        '/services/search/jobs/export',
        {
          search: query,
          earliest_time: '-24h',
          latest_time: 'now',
          max_count: 1,
          output_mode: 'json',
        }
      );

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(parseSearchResults(response), null, 2),
          },
        ],
      };
    }
  );

  server.registerTool(
    'get_event_count',
    {
      description: 'Get the count of events in an index for a time range.',
      inputSchema: z.object({
        index: z.string().describe('Index name'),
        earliest_time: z
          .string()
          .optional()
          .describe('Start time (default: -24h)'),
        latest_time: z.string().optional().describe('End time (default: now)'),
        sourcetype: z
          .string()
          .optional()
          .describe('Optional sourcetype filter'),
        host: z.string().optional().describe('Optional host filter'),
      }),
    },
    async ({ index, earliest_time, latest_time, sourcetype, host }) => {
      await ensureAuthenticated(state);

      let query = `search index=${index}`;
      if (sourcetype) query += ` sourcetype=${sourcetype}`;
      if (host) query += ` host=${host}`;
      query += ' | stats count';

      const response = await splunkRequest(
        state,
        'POST',
        '/services/search/jobs/export',
        {
          search: query,
          earliest_time: earliest_time || '-24h',
          latest_time: latest_time || 'now',
          output_mode: 'json',
        }
      );

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(parseSearchResults(response), null, 2),
          },
        ],
      };
    }
  );
}
