import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ClientState } from '../types/index.js';
import { splunkRequest } from '../utils/http.js';
import { ensureAuthenticated } from '../utils/auth.js';

export function registerSystemTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'get_server_info',
    {
      description:
        'Get Splunk server information including version, build, and license info.',
      inputSchema: z.object({}),
    },
    async () => {
      await ensureAuthenticated(state);

      const response = (await splunkRequest(
        state,
        'GET',
        '/services/server/info',
        { output_mode: 'json' }
      )) as { entry?: Array<{ content?: Record<string, unknown> }> };

      const info = response.entry?.[0]?.content || {};
      const result = {
        serverName: info.serverName,
        version: info.version,
        build: info.build,
        os: info.os_name,
        cpuArch: info.cpu_arch,
        licenseState: info.licenseState,
        isFree: info.isFree,
        isTrial: info.isTrial,
      };

      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'check_health',
    {
      description: 'Check Splunk system health and status.',
      inputSchema: z.object({
        component: z
          .enum(['indexer', 'search_head', 'forwarder', 'all'])
          .optional()
          .describe('Specific component to check'),
      }),
    },
    async () => {
      await ensureAuthenticated(state);

      const response = (await splunkRequest(
        state,
        'GET',
        '/services/server/health/splunkd/details',
        { output_mode: 'json' }
      )) as { entry?: Array<{ content?: Record<string, unknown> }> };

      const health = response.entry?.[0]?.content || {};
      const result = {
        overallHealth: health.health,
        features: health.features,
      };

      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );
}
