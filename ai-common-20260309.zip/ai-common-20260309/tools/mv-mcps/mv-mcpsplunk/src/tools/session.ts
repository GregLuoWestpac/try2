import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ClientState } from '../types/index.js';
import {
  isAuthenticated,
  authenticate,
  authenticateWithToken,
  updateTokens,
  setHost,
  ping,
  startKeepAlive,
  stopKeepAlive,
  getSsoConfig,
  logout,
} from '../utils/auth.js';
import { loadConfig, saveTokensToConfig } from '../utils/config.js';
import { quickValidate } from '../utils/token-validator.js';
import { performSsoLogin } from '../utils/sso.js';

export function registerSessionTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'start_session',
    {
      description:
        'Start a new Splunk session. Call this before other Splunk operations to initialize the connection.',
      inputSchema: z.object({
        host: z
          .string()
          .optional()
          .describe(
            'Splunk host URL (e.g., https://splunk.example.com:8089). Uses SPLUNK_HOST env var if not provided.'
          ),
        verify_ssl: z
          .boolean()
          .optional()
          .describe('Whether to verify SSL certificates (default: true)'),
        load_config: z
          .boolean()
          .optional()
          .describe(
            'Load configuration from .splunk_mcp.local.yaml file (default: true)'
          ),
      }),
    },
    async ({ host, verify_ssl, load_config: loadCfg }) => {
      // Try to load from config file first
      if (loadCfg !== false) {
        const configState = loadConfig();
        if (configState.host) {
          Object.assign(state, configState);

          if (isAuthenticated(state)) {
            const splunkUrl = `${state.protocol}://${state.host}${state.port ? ':' + state.port : ''}`;
            const valid = await quickValidate({
              host: splunkUrl,
              session: {
                session_key: state.sessionKey!,
                csrf_token: state.csrfToken,
                session_id: state.cookies?.session_id_8443 || null,
              },
            });

            if (valid) {
              return {
                content: [
                  {
                    type: 'text' as const,
                    text: JSON.stringify(
                      {
                        status: 'session_started',
                        host: `${state.protocol}://${state.host}:${state.port}`,
                        message:
                          'Splunk session started from config file. Already authenticated.',
                        keepalive: state.keepAliveEnabled
                          ? 'enabled'
                          : 'disabled',
                      },
                      null,
                      2
                    ),
                  },
                ],
              };
            }

            // Tokens expired
            return {
              content: [
                {
                  type: 'text' as const,
                  text: JSON.stringify(
                    {
                      status: 'session_started_unauthenticated',
                      host: `${state.protocol}://${state.host}:${state.port}`,
                      message:
                        'Config loaded but tokens are expired. Use authenticate or sso_login to re-authenticate.',
                    },
                    null,
                    2
                  ),
                },
              ],
            };
          }
        }
      }

      const hostUrl = host || process.env.SPLUNK_HOST;
      if (!hostUrl) {
        return {
          content: [
            {
              type: 'text' as const,
              text: JSON.stringify(
                {
                  error:
                    'No Splunk host provided. Set SPLUNK_HOST environment variable or provide host parameter.',
                },
                null,
                2
              ),
            },
          ],
        };
      }

      setHost(state, hostUrl, verify_ssl !== false);
      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(
              {
                status: 'session_started',
                host: hostUrl,
                message:
                  'Splunk session started. Use authenticate or sso_login to log in.',
              },
              null,
              2
            ),
          },
        ],
      };
    }
  );

  server.registerTool(
    'reset_session',
    {
      description:
        'Reset the current Splunk session, clearing all state and authentication.',
      inputSchema: z.object({}),
    },
    async () => {
      logout(state);
      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(
              {
                status: 'session_reset',
                message: 'Splunk session has been reset.',
              },
              null,
              2
            ),
          },
        ],
      };
    }
  );

  server.registerTool(
    'session_keepalive',
    {
      description:
        'Manage session keep-alive to prevent token expiration. Can start, stop, or check keep-alive status.',
      inputSchema: z.object({
        action: z
          .enum(['start', 'stop', 'status', 'ping'])
          .describe('Action to perform'),
        interval_seconds: z
          .number()
          .optional()
          .describe('Keep-alive ping interval in seconds (default: 300)'),
      }),
    },
    async ({ action, interval_seconds }) => {
      let result: Record<string, unknown>;

      switch (action) {
        case 'start':
          startKeepAlive(state, interval_seconds || 300);
          result = {
            status: 'keepalive_started',
            interval: interval_seconds || 300,
            message: `Keep-alive started with ${interval_seconds || 300}s interval`,
          };
          break;
        case 'stop':
          stopKeepAlive(state);
          result = {
            status: 'keepalive_stopped',
            message: 'Keep-alive stopped',
          };
          break;
        case 'status':
          result = {
            enabled: state.keepAliveEnabled,
            message: state.keepAliveEnabled
              ? 'Keep-alive is active'
              : 'Keep-alive is not running',
          };
          break;
        case 'ping':
          try {
            const pingResult = await ping(state);
            result = { ...pingResult, status: 'alive' };
          } catch (e) {
            result = { status: 'failed', error: (e as Error).message };
          }
          break;
        default:
          result = { error: `Unknown action: ${action}` };
      }

      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'authenticate',
    {
      description:
        'Authenticate with Splunk using username/password or token. Required before running searches.',
      inputSchema: z.object({
        username: z
          .string()
          .optional()
          .describe(
            'Splunk username. Uses SPLUNK_USERNAME env var if not provided.'
          ),
        password: z
          .string()
          .optional()
          .describe(
            'Splunk password. Uses SPLUNK_PASSWORD env var if not provided.'
          ),
        token: z
          .string()
          .optional()
          .describe(
            'Bearer token for authentication. Uses SPLUNK_TOKEN env var if not provided.'
          ),
      }),
    },
    async ({ username, password, token }) => {
      const tkn = token || process.env.SPLUNK_TOKEN;
      if (tkn) {
        await authenticateWithToken(state, tkn);
        return {
          content: [
            {
              type: 'text' as const,
              text: JSON.stringify(
                { status: 'authenticated', method: 'token' },
                null,
                2
              ),
            },
          ],
        };
      }

      const user = username || process.env.SPLUNK_USERNAME;
      const pass = password || process.env.SPLUNK_PASSWORD;

      if (!user || !pass) {
        return {
          content: [
            {
              type: 'text' as const,
              text: JSON.stringify(
                {
                  error:
                    'No credentials provided. Set SPLUNK_USERNAME/SPLUNK_PASSWORD or SPLUNK_TOKEN.',
                },
                null,
                2
              ),
            },
          ],
        };
      }

      const result = await authenticate(state, user, pass);
      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(
              {
                status: 'authenticated',
                method: 'password',
                sessionKey: result.sessionKey,
              },
              null,
              2
            ),
          },
        ],
      };
    }
  );

  server.registerTool(
    'update_tokens',
    {
      description:
        'Update session tokens without restarting the server. Updates tokens in memory, saves to config file, and restarts keep-alive. Use this when your session tokens have expired.',
      inputSchema: z.object({
        session_key: z
          .string()
          .describe('Main session key (splunkd_8443 cookie value)'),
        csrf_token: z
          .string()
          .describe('CSRF token (splunkweb_csrf_token_8443 cookie value)'),
        lb_cookie: z
          .string()
          .optional()
          .describe('Load balancer cookie (LB cookie value)'),
        session_id: z
          .string()
          .optional()
          .describe('Session ID (session_id_8443 cookie value)'),
        restart_keepalive: z
          .boolean()
          .optional()
          .describe('Restart keep-alive after updating tokens (default: true)'),
        keepalive_interval: z
          .number()
          .optional()
          .describe('Keep-alive interval in seconds (default: 300)'),
      }),
    },
    async ({
      session_key,
      csrf_token,
      lb_cookie,
      session_id,
      restart_keepalive,
      keepalive_interval,
    }) => {
      const tokens = { session_key, csrf_token, lb_cookie, session_id };
      const result = updateTokens(state, tokens, true);

      if (restart_keepalive !== false) {
        stopKeepAlive(state);
        startKeepAlive(state, keepalive_interval || 300);
        result.keepalive = 'restarted';
        result.keepalive_interval = keepalive_interval || 300;
      }

      try {
        const pingResult = await ping(state);
        result.verified = true;
        result.serverName = pingResult.serverName;
      } catch (e) {
        result.verified = false;
        result.verification_error = (e as Error).message;
      }

      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'sso_login',
    {
      description:
        'Authenticate with Splunk via Microsoft SSO. Opens a browser to drive the SAML login flow, handles MFA, and extracts session cookies. Use when tokens are expired or for initial setup.',
      inputSchema: z.object({
        email: z
          .string()
          .optional()
          .describe(
            'SSO email address. Uses SPLUNK_SSO_EMAIL env var or config if not provided.'
          ),
        password: z
          .string()
          .optional()
          .describe(
            'SSO password. Will prompt via MCP elicitation if not provided. Never saved to disk.'
          ),
        headless: z
          .boolean()
          .optional()
          .describe(
            'Run browser in headless mode (default: true). Set false to see the browser during login.'
          ),
        mfa_code: z
          .string()
          .optional()
          .describe(
            'MFA verification code, if using TOTP/SMS. For number-matching MFA, approve on your phone instead.'
          ),
      }),
    },
    async ({ email, password, headless, mfa_code }) => {
      if (!state.host) {
        return {
          content: [
            {
              type: 'text' as const,
              text: JSON.stringify(
                {
                  error:
                    'No Splunk host configured. Call start_session first or set SPLUNK_HOST.',
                },
                null,
                2
              ),
            },
          ],
        };
      }

      const ssoConfig = getSsoConfig(state);
      const resolvedEmail = email || ssoConfig.email;
      const resolvedPassword =
        password || process.env.SPLUNK_SSO_PASSWORD || ssoConfig.password;

      if (!resolvedEmail) {
        return {
          content: [
            {
              type: 'text' as const,
              text: JSON.stringify(
                {
                  error:
                    'SSO email is required. Set SPLUNK_SSO_EMAIL env var, add sso.email to config, or provide it as a parameter.',
                },
                null,
                2
              ),
            },
          ],
        };
      }

      if (!resolvedPassword) {
        return {
          content: [
            {
              type: 'text' as const,
              text: JSON.stringify(
                {
                  error:
                    'SSO password is required. Set SPLUNK_SSO_PASSWORD env var, add sso.password to config, or provide it as a parameter.',
                },
                null,
                2
              ),
            },
          ],
        };
      }

      try {
        const tokens = await performSsoLogin(
          {
            splunkUrl: ssoConfig.splunkUrl,
            headless: headless ?? ssoConfig.headless,
            timeoutSeconds: ssoConfig.timeoutSeconds,
          },
          {
            email: resolvedEmail,
            password: resolvedPassword,
            mfaCode: mfa_code,
          }
        );

        const result = updateTokens(state, tokens, true);
        stopKeepAlive(state);
        startKeepAlive(state, 300);

        try {
          const pingResult = await ping(state);
          result.verified = true;
          result.serverName = pingResult.serverName;
        } catch (e) {
          result.verified = false;
          result.verification_error = (e as Error).message;
        }

        result.sso_login = 'success';
        result.email = resolvedEmail;

        return {
          content: [
            { type: 'text' as const, text: JSON.stringify(result, null, 2) },
          ],
        };
      } catch (e) {
        return {
          content: [
            {
              type: 'text' as const,
              text: JSON.stringify(
                {
                  error: `SSO login failed: ${(e as Error).message}`,
                  sso_login: 'failed',
                },
                null,
                2
              ),
            },
          ],
        };
      }
    }
  );
}
