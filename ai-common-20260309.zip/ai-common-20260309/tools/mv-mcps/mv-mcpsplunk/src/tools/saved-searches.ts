import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ClientState } from '../types/index.js';
import { splunkRequest, parseSearchResults } from '../utils/http.js';
import { ensureAuthenticated } from '../utils/auth.js';

export function registerSavedSearchTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'list_saved_searches',
    {
      description: 'List all saved searches/reports available to the user.',
      inputSchema: z.object({
        app: z.string().optional().describe('Filter by app context'),
        owner: z.string().optional().describe('Filter by owner'),
      }),
    },
    async ({ app, owner }) => {
      await ensureAuthenticated(state);

      let apiPath = '/services/saved/searches';
      if (app) {
        apiPath = `/servicesNS/${owner || '-'}/${app}/saved/searches`;
      }

      const response = (await splunkRequest(state, 'GET', apiPath, {
        output_mode: 'json',
        count: 0,
      })) as {
        entry?: Array<{
          name: string;
          content?: Record<string, unknown>;
        }>;
      };

      const savedSearches = (response.entry || []).map(entry => ({
        name: entry.name,
        description: entry.content?.description,
        search: entry.content?.search,
        isScheduled: entry.content?.is_scheduled,
        nextScheduledTime: entry.content?.next_scheduled_time,
      }));

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify({ savedSearches }, null, 2),
          },
        ],
      };
    }
  );

  server.registerTool(
    'run_saved_search',
    {
      description: 'Execute a saved search by name.',
      inputSchema: z.object({
        name: z.string().describe('Name of the saved search'),
        earliest_time: z.string().optional().describe('Override earliest time'),
        latest_time: z.string().optional().describe('Override latest time'),
        trigger_actions: z
          .boolean()
          .optional()
          .describe('Whether to trigger alert actions (default: false)'),
      }),
    },
    async ({ name, earliest_time, latest_time, trigger_actions }) => {
      await ensureAuthenticated(state);

      const params: Record<string, string | number | boolean> = {
        output_mode: 'json',
        'dispatch.now': true,
      };

      if (earliest_time) params['dispatch.earliest_time'] = earliest_time;
      if (latest_time) params['dispatch.latest_time'] = latest_time;
      if (trigger_actions) params.trigger_actions = 1;

      const response = (await splunkRequest(
        state,
        'POST',
        `/services/saved/searches/${encodeURIComponent(name)}/dispatch`,
        params
      )) as { sid?: string };

      const sid = response.sid;
      if (sid) {
        // Wait for completion and get results
        const timeout = 60000;
        const startTime = Date.now();

        while (Date.now() - startTime < timeout) {
          const statusResponse = (await splunkRequest(
            state,
            'GET',
            `/services/search/jobs/${sid}`,
            { output_mode: 'json' }
          )) as { entry?: Array<{ content?: Record<string, unknown> }> };

          const job = statusResponse.entry?.[0]?.content || {};
          if (job.isDone) {
            const results = await splunkRequest(
              state,
              'GET',
              `/services/search/jobs/${sid}/results`,
              { count: 100, output_mode: 'json' }
            );
            return {
              content: [
                {
                  type: 'text' as const,
                  text: JSON.stringify(parseSearchResults(results), null, 2),
                },
              ],
            };
          }

          if (job.isFailed) {
            throw new Error(`Search failed: ${sid}`);
          }

          await new Promise(resolve => setTimeout(resolve, 1000));
        }

        throw new Error(`Search timed out: ${sid}`);
      }

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(response, null, 2),
          },
        ],
      };
    }
  );

  server.registerTool(
    'list_alerts',
    {
      description: 'List recent triggered alerts.',
      inputSchema: z.object({
        earliest_time: z
          .string()
          .optional()
          .describe('Start time for alert list (default: -24h)'),
        severity: z
          .enum(['low', 'medium', 'high', 'critical'])
          .optional()
          .describe('Filter by severity'),
        max_results: z
          .number()
          .optional()
          .describe('Maximum alerts to return (default: 50)'),
      }),
    },
    async ({ max_results }) => {
      await ensureAuthenticated(state);

      const response = (await splunkRequest(
        state,
        'GET',
        '/services/alerts/fired_alerts',
        {
          output_mode: 'json',
          count: max_results || 50,
        }
      )) as {
        entry?: Array<{
          name: string;
          content?: Record<string, unknown>;
        }>;
      };

      const alerts = (response.entry || []).map(entry => ({
        name: entry.name,
        triggeredTime: entry.content?.trigger_time,
        severity: entry.content?.severity,
        resultCount: entry.content?.triggered_alert_count,
      }));

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify({ alerts }, null, 2),
          },
        ],
      };
    }
  );

  server.registerTool(
    'get_alert_details',
    {
      description: 'Get detailed information about a specific triggered alert.',
      inputSchema: z.object({
        alert_id: z.string().describe('Alert ID or name'),
      }),
    },
    async ({ alert_id }) => {
      await ensureAuthenticated(state);

      const response = (await splunkRequest(
        state,
        'GET',
        `/services/alerts/fired_alerts/${encodeURIComponent(alert_id)}`,
        { output_mode: 'json' }
      )) as {
        entry?: Array<{ name: string; content?: Record<string, unknown> }>;
      };

      const entry = response.entry?.[0];
      if (!entry) {
        throw new Error(`Alert not found: ${alert_id}`);
      }

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(
              { name: entry.name, ...entry.content },
              null,
              2
            ),
          },
        ],
      };
    }
  );
}
