import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ClientState } from './types/index.js';
import { registerAllTools } from './tools/index.js';

export function createServer(state: ClientState): McpServer {
  const server = new McpServer({
    name: 'mv-mcpsplunk',
    version: '1.0.0',
  });

  registerAllTools(server, state);

  return server;
}
