#!/usr/bin/env node

/**
 * mv-mcpsplunk — Splunk MCP Server
 *
 * Starts a stdio-based MCP server providing Splunk tools for searching,
 * monitoring, and diagnosing issues with Splunk Enterprise/Cloud.
 * Built with the official @modelcontextprotocol/sdk TypeScript SDK.
 *
 * Usage:
 *   npx @mesh-tenant-multiverse-ui-common/mv-mcpsplunk
 */

import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { loadConfig } from './utils/config.js';
import { createServer } from './server.js';

async function main() {
  const state = loadConfig();

  if (!state.host) {
    console.error(
      '[mv-mcpsplunk] WARNING: No Splunk host configured in ~/.splunk_mcp.local.yaml. Use start_session to configure.'
    );
  }

  const server = createServer(state);
  const transport = new StdioServerTransport();
  await server.connect(transport);

  console.error(
    `[mv-mcpsplunk] Server ready (STDIO transport${state.host ? `, host: ${state.protocol}://${state.host}:${state.port}` : ''})`
  );
}

main().catch(error => {
  console.error('Failed to start mv-mcpsplunk:', error);
  process.exit(1);
});
