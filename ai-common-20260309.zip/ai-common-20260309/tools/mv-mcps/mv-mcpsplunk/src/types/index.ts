export interface SplunkConfig {
  splunk?: {
    host?: string;
    verify_ssl?: boolean;
    session?: {
      session_key?: string;
      csrf_token?: string;
      lb_cookie?: string;
      session_id?: string;
      obtained_at?: string;
    };
    sso?: {
      email?: string;
      password?: string;
      headless?: boolean;
      timeout_seconds?: number;
    };
  };
  keepalive?: {
    enabled?: boolean;
    interval_seconds?: number;
  };
}

export interface ClientState {
  host: string;
  port: number;
  protocol: 'https' | 'http';
  verifySsl: boolean;
  sessionKey: string | null;
  bearerToken: string | null;
  csrfToken: string | null;
  cookies: Record<string, string>;
  isSplunkCloud: boolean;
  keepAliveInterval: ReturnType<typeof setInterval> | null;
  keepAliveEnabled: boolean;
  ssoConfig: SsoConfig;
  tokenObtainedAt: Date | null;
}

export interface SsoConfig {
  email: string | null;
  password: string | null;
  headless: boolean;
  timeoutSeconds: number;
}

export interface TokenSet {
  session_key: string;
  csrf_token: string | null;
  lb_cookie: string | null;
  session_id: string | null;
}

export interface ValidationResult {
  success: boolean;
  message: string;
  serverInfo?: {
    serverName?: string;
    version?: string;
    build?: string;
    os_name?: string;
    cpu_arch?: string;
    licenseState?: string;
    isFree?: boolean;
    isTrial?: boolean;
  } | null;
}
