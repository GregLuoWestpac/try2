/**
 * Token Validator
 *
 * Validates Splunk session tokens by making a test API call.
 * Ported from mv-splunklogin/src/token-validator.js (standalone, no external imports).
 */

import https from 'node:https';
import type { ValidationResult } from '../types/index.js';

interface TokenValidationConfig {
  host: string;
  session: {
    session_key: string;
    csrf_token?: string | null;
    session_id?: string | null;
  };
}

/**
 * Validate Splunk session tokens by testing against the server.
 */
export async function validateTokens(
  config: TokenValidationConfig,
  verbose = false
): Promise<ValidationResult> {
  const log = verbose
    ? (...args: unknown[]) => console.error('[TokenValidator]', ...args)
    : () => {};

  if (!config?.host) {
    throw new Error('Host URL is required');
  }

  if (!config?.session?.session_key) {
    throw new Error('Session key is required');
  }

  const { host, session } = config;
  const { session_key, csrf_token, session_id } = session;

  log('Validating tokens against:', host);

  let url: URL;
  try {
    url = new URL(host);
  } catch {
    throw new Error(`Invalid host URL: ${host}`);
  }

  return new Promise((resolve, reject) => {
    const options: https.RequestOptions = {
      hostname: url.hostname,
      port: url.port || 443,
      path: '/en-US/splunkd/__raw/services/server/info?output_mode=json',
      method: 'GET',
      headers: {
        Authorization: `Splunk ${session_key}`,
        Cookie: `splunkd_8443=${session_key}; session_id_8443=${session_id || ''}; splunkweb_csrf_token_8443=${csrf_token || ''}`,
        'X-Splunk-Form-Key': csrf_token || '',
        'Content-Type': 'application/json',
      },
      rejectUnauthorized: true,
    };

    log('Making test request to:', options.path);

    const req = https.request(options, res => {
      let data = '';

      res.on('data', (chunk: string) => {
        data += chunk;
      });

      res.on('end', () => {
        log('Response status:', res.statusCode, res.statusMessage);

        if (res.statusCode === 200) {
          try {
            const jsonData = JSON.parse(data);
            const serverInfo = jsonData.entry?.[0]?.content;

            log('✅ Token validation successful');

            resolve({
              success: true,
              message: 'Tokens validated successfully',
              serverInfo: serverInfo || null,
            });
          } catch {
            log('⚠️  Got 200 but failed to parse JSON');
            resolve({
              success: true,
              message: 'Tokens validated (got 200 OK)',
              serverInfo: null,
            });
          }
        } else if (res.statusCode === 401) {
          log('❌ Token validation failed: Unauthorized (401)');
          reject(
            new Error(
              'Token validation failed: Unauthorized (401). Tokens may be expired or invalid.'
            )
          );
        } else {
          log('❌ Token validation failed:', res.statusCode, res.statusMessage);
          reject(
            new Error(
              `Token validation failed: HTTP ${res.statusCode} - ${res.statusMessage}`
            )
          );
        }
      });
    });

    req.on('error', (error: Error) => {
      log('❌ Request error:', error.message);
      reject(new Error(`Token validation failed: ${error.message}`));
    });

    req.setTimeout(10000, () => {
      log('❌ Request timeout after 10 seconds');
      req.destroy();
      reject(new Error('Token validation timeout after 10 seconds'));
    });

    req.end();
  });
}

/**
 * Quick validation — returns true if tokens are valid, false otherwise.
 */
export async function quickValidate(
  config: TokenValidationConfig,
  verbose = false
): Promise<boolean> {
  try {
    const result = await validateTokens(config, verbose);
    return result.success;
  } catch {
    if (verbose) {
      console.error('[TokenValidator] Validation failed');
    }
    return false;
  }
}
