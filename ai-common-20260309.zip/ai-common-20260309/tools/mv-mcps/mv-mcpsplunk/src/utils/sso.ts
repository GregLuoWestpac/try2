/**
 * Splunk SSO Authentication Flow
 *
 * Drives a headless Edge/Chrome browser through the Splunk Cloud SAML SSO flow:
 * Splunk login → Microsoft Entra ID → MFA → session cookie extraction.
 *
 * Uses puppeteer-core to automate the browser.
 */

import puppeteer, {
  type Page,
  type Browser,
  type ElementHandle,
} from 'puppeteer-core';
import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';
import type { TokenSet } from '../types/index.js';

// Microsoft login page selectors
const SELECTORS = {
  emailInput: 'input[name="loginfmt"]',
  emailInputFallback: 'input[type="email"][name="loginfmt"]',
  emailNextButton: 'input[type="submit"][value="Next"]',
  emailNextButtonFallback: '#idSIButton9',
  passwordInput: 'input[type="password"][name="passwd"]',
  passwordInputFallback: 'input[name="passwd"]',
  passwordSubmitButton: 'input[type="submit"][value="Sign in"]',
  passwordSubmitButtonFallback: '#idSIButton9',
  mfaDisplayNumber: '#idRichContext_DisplaySign',
  mfaDisplayNumberFallback: '#displaySign',
  mfaCodeInput: 'input[name="otc"]',
  mfaCodeInputFallback: '#idTxtBx_SAOTCC_OTC',
  mfaCodeSubmit: 'input[type="submit"][value="Verify"]',
  mfaCodeSubmitFallback: '#idSubmit_SAOTCC_Continue',
  staySignedInYes: 'input[type="submit"][value="Yes"]',
  staySignedInYesFallback: '#idSIButton9',
  staySignedInNo: 'input[type="button"][value="No"]',
  kmsiPage: '#KmsiDescription',
  usernameError: '#usernameError',
  passwordError: '#passwordError',
  loginError: '#error',
};

const SPLUNK_COOKIES = {
  sessionKey: 'splunkd_8443',
  csrfToken: 'splunkweb_csrf_token_8443',
  lbCookie: 'LB',
  sessionId: 'session_id_8443',
};

interface SsoOptions {
  splunkUrl: string;
  headless?: boolean;
  timeoutSeconds?: number;
  verbose?: boolean;
  executablePath?: string;
}

interface AuthenticateOptions {
  email: string;
  password: string;
  mfaCode?: string;
  maxRetries?: number;
}

/**
 * Find Edge or Chrome executable on the system.
 */
function findBrowser(): string {
  const edgePaths =
    process.platform === 'win32'
      ? [
          path.join(
            process.env.LOCALAPPDATA || '',
            'Microsoft',
            'Edge',
            'Application',
            'msedge.exe'
          ),
          'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
          'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
        ]
      : process.platform === 'darwin'
        ? ['/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge']
        : ['/usr/bin/microsoft-edge', '/usr/bin/microsoft-edge-stable'];

  const chromePaths =
    process.platform === 'win32'
      ? [
          path.join(
            process.env.LOCALAPPDATA || '',
            'Google',
            'Chrome',
            'Application',
            'chrome.exe'
          ),
          'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
          'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
        ]
      : process.platform === 'darwin'
        ? ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome']
        : ['/usr/bin/google-chrome', '/usr/bin/google-chrome-stable'];

  for (const p of [...edgePaths, ...chromePaths]) {
    try {
      if (fs.existsSync(p)) return p;
    } catch {
      /* ignore */
    }
  }

  return edgePaths[0]; // fallback
}

/**
 * Try to find an element using primary selector, then fallback.
 */
async function findElement(
  page: Page,
  primary: string,
  fallback?: string,
  timeout = 5000
): Promise<ElementHandle | null> {
  try {
    await page.waitForSelector(primary, { timeout });
    return await page.$(primary);
  } catch {
    if (fallback) {
      try {
        await page.waitForSelector(fallback, { timeout: 3000 });
        return await page.$(fallback);
      } catch {
        /* both failed */
      }
    }
    return null;
  }
}

/**
 * Navigate to Splunk login (redirects to Microsoft SSO).
 */
async function navigateToLogin(
  page: Page,
  splunkUrl: string
): Promise<'login_page' | 'already_authenticated'> {
  await page.goto(splunkUrl, { waitUntil: 'networkidle2', timeout: 45000 });

  try {
    const result = await Promise.race([
      page
        .waitForSelector(SELECTORS.emailInput, { timeout: 20000 })
        .then(() => 'email_page' as const),
      page
        .waitForSelector(SELECTORS.passwordInput, { timeout: 20000 })
        .then(() => 'password_page' as const),
      page
        .waitForFunction(
          (hostname: string) =>
            window.location.hostname.includes(hostname) &&
            window.location.pathname.includes('/app/'),
          { timeout: 20000 },
          new URL(splunkUrl).hostname
        )
        .then(() => 'splunk_dashboard' as const),
    ]);

    if (result === 'splunk_dashboard') return 'already_authenticated';
    return 'login_page';
  } catch {
    const url = page.url();
    const splunkHost = new URL(splunkUrl).hostname;
    if (
      url.includes(splunkHost) &&
      !url.includes('login.microsoftonline.com')
    ) {
      return 'already_authenticated';
    }
    throw new Error(`Failed to reach login page. Current URL: ${url}`);
  }
}

/**
 * Enter email on Microsoft login page.
 */
async function enterEmail(page: Page, email: string): Promise<void> {
  await page.waitForSelector(SELECTORS.emailInput, {
    visible: true,
    timeout: 10000,
  });
  await page.type(SELECTORS.emailInput, email, { delay: 50 });

  const nextBtn = await findElement(
    page,
    SELECTORS.emailNextButton,
    SELECTORS.emailNextButtonFallback
  );
  if (nextBtn) {
    await nextBtn.click();
  } else {
    await page.keyboard.press('Enter');
  }

  try {
    await Promise.race([
      page.waitForSelector(SELECTORS.passwordInput, {
        visible: true,
        timeout: 10000,
      }),
      page.waitForSelector(SELECTORS.usernameError, {
        visible: true,
        timeout: 10000,
      }),
    ]);
  } catch {
    throw new Error('Timed out waiting for password page after email entry');
  }

  const emailError = await page.$(SELECTORS.usernameError);
  if (emailError) {
    const errorText = await page.evaluate(
      (el: Element) => el.textContent,
      emailError
    );
    throw new Error(`Email error: ${errorText?.trim()}`);
  }
}

/**
 * Enter password on Microsoft login page.
 */
async function enterPassword(page: Page, password: string): Promise<void> {
  await page.waitForSelector(SELECTORS.passwordInput, {
    visible: true,
    timeout: 10000,
  });
  await page.type(SELECTORS.passwordInput, password, { delay: 30 });

  const signInBtn = await findElement(
    page,
    SELECTORS.passwordSubmitButton,
    SELECTORS.passwordSubmitButtonFallback
  );
  if (signInBtn) {
    await signInBtn.click();
  } else {
    await page.keyboard.press('Enter');
  }

  // Wait for MFA, "Stay signed in", error, or redirect
  try {
    await Promise.race([
      page.waitForSelector(SELECTORS.mfaDisplayNumber, {
        visible: true,
        timeout: 15000,
      }),
      page.waitForSelector(SELECTORS.mfaDisplayNumberFallback, {
        visible: true,
        timeout: 15000,
      }),
      page.waitForSelector(SELECTORS.mfaCodeInput, {
        visible: true,
        timeout: 15000,
      }),
      page.waitForSelector(SELECTORS.kmsiPage, {
        visible: true,
        timeout: 15000,
      }),
      page.waitForSelector(SELECTORS.passwordError, {
        visible: true,
        timeout: 15000,
      }),
      page.waitForFunction(
        () => window.location.hostname.includes('splunkcloud.com'),
        { timeout: 15000 }
      ),
    ]);
  } catch {
    // Timeout OK — check state in next step
  }

  const passwordError = await page.$(SELECTORS.passwordError);
  if (passwordError) {
    const errorText = await page.evaluate(
      (el: Element) => el.textContent,
      passwordError
    );
    throw new Error(`Password error: ${errorText?.trim()}`);
  }
}

/**
 * Wait for MFA to complete.
 */
async function waitForMFACompletion(
  page: Page,
  timeoutMs: number
): Promise<void> {
  try {
    await Promise.race([
      page.waitForSelector(SELECTORS.kmsiPage, {
        visible: true,
        timeout: timeoutMs,
      }),
      page.waitForFunction(
        () => !window.location.hostname.includes('login.microsoftonline.com'),
        { timeout: timeoutMs }
      ),
    ]);
  } catch {
    throw new Error(
      `MFA timed out after ${timeoutMs / 1000}s. Please approve the request and try again.`
    );
  }
}

/**
 * Handle MFA challenge.
 */
async function handleMFA(
  page: Page,
  mfaCode: string | undefined,
  timeoutMs: number
): Promise<void> {
  const numberEl =
    (await page.$(SELECTORS.mfaDisplayNumber)) ||
    (await page.$(SELECTORS.mfaDisplayNumberFallback));
  const codeInput = await page.$(SELECTORS.mfaCodeInput);

  if (numberEl) {
    // Number matching MFA
    const number = await page.evaluate(
      (el: Element) => el.textContent?.trim(),
      numberEl
    );
    console.error(
      `\n${'='.repeat(60)}\n🔐 MFA NUMBER: ${number}\nApprove the request on your Microsoft Authenticator app.\n${'='.repeat(60)}\n`
    );
    await waitForMFACompletion(page, timeoutMs);
  } else if (codeInput) {
    // Code entry MFA
    if (!mfaCode) {
      throw new Error(
        'MFA code is required but not provided. Provide it via the mfa_code parameter.'
      );
    }
    await page.type(SELECTORS.mfaCodeInput, mfaCode, { delay: 50 });
    const verifyButton = await page.$(SELECTORS.mfaCodeSubmit);
    if (verifyButton) await verifyButton.click();
    await waitForMFACompletion(page, timeoutMs);
  }
  // No MFA detected — continue
}

/**
 * Handle "Stay signed in?" interstitial.
 */
async function handleStaySignedIn(page: Page): Promise<void> {
  const kmsi = await page.$(SELECTORS.kmsiPage);
  if (kmsi) {
    const yesButton = await page.$(SELECTORS.staySignedInYes);
    if (yesButton) {
      await yesButton.click();
      await page
        .waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 })
        .catch(() => {});
    }
  }
}

/**
 * Wait for Splunk session to be established.
 */
async function waitForSplunkSession(
  page: Page,
  splunkUrl: string
): Promise<void> {
  try {
    await page.waitForFunction(
      (hostname: string) => window.location.hostname.includes(hostname),
      { timeout: 30000 },
      new URL(splunkUrl).hostname
    );
  } catch {
    const url = page.url();
    if (!url.includes(new URL(splunkUrl).hostname)) {
      throw new Error(`Failed to reach Splunk after SSO. Current URL: ${url}`);
    }
  }
  // Give cookies time to settle
  await new Promise(resolve => setTimeout(resolve, 2000));
}

/**
 * Extract session cookies from the browser.
 */
async function extractCookies(page: Page): Promise<TokenSet> {
  const cookies = await page.cookies();
  const cookieMap: Record<string, string> = {};
  for (const c of cookies) {
    cookieMap[c.name] = c.value;
  }

  const sessionKey = cookieMap[SPLUNK_COOKIES.sessionKey];
  const csrfToken = cookieMap[SPLUNK_COOKIES.csrfToken];
  const lbCookie = cookieMap[SPLUNK_COOKIES.lbCookie];
  const sessionId = cookieMap[SPLUNK_COOKIES.sessionId];

  if (!sessionKey) {
    throw new Error(
      'Failed to extract session key cookie (splunkd_8443). Authentication may have failed.'
    );
  }

  return {
    session_key: sessionKey,
    csrf_token: csrfToken || null,
    lb_cookie: lbCookie || null,
    session_id: sessionId || null,
  };
}

/**
 * Perform SSO login flow.
 * Drives a browser through Microsoft SSO and returns Splunk session tokens.
 */
export async function performSsoLogin(
  ssoOptions: SsoOptions,
  authOptions: AuthenticateOptions
): Promise<TokenSet> {
  const {
    splunkUrl,
    headless = true,
    timeoutSeconds = 120,
    executablePath,
  } = ssoOptions;

  const { email, password, mfaCode, maxRetries = 1 } = authOptions;

  if (!email) throw new Error('SSO email is required');
  if (!password) throw new Error('SSO password is required');
  if (!splunkUrl) throw new Error('Splunk URL is required');

  const browserPath = executablePath || findBrowser();
  const timeoutMs = timeoutSeconds * 1000;

  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    let browser: Browser | null = null;
    let userDataDir: string | null = null;

    try {
      userDataDir = path.join(os.tmpdir(), `splunk-sso-${Date.now()}`);

      browser = await puppeteer.launch({
        executablePath: browserPath,
        headless,
        userDataDir,
        args: [
          '--no-first-run',
          '--no-default-browser-check',
          '--disable-extensions',
          '--disable-popup-blocking',
        ],
        defaultViewport: { width: 1280, height: 720 },
      });

      const page = await browser.newPage();

      const loginState = await navigateToLogin(page, splunkUrl);

      if (loginState === 'already_authenticated') {
        await waitForSplunkSession(page, splunkUrl);
        return await extractCookies(page);
      }

      await enterEmail(page, email);
      await enterPassword(page, password);
      await handleMFA(page, mfaCode, timeoutMs);
      await handleStaySignedIn(page);
      await waitForSplunkSession(page, splunkUrl);
      return await extractCookies(page);
    } catch (e) {
      lastError = e as Error;
    } finally {
      if (browser) {
        try {
          await browser.close();
        } catch {
          /* ignore */
        }
      }
      if (userDataDir) {
        try {
          fs.rmSync(userDataDir, { recursive: true, force: true });
        } catch {
          /* ignore */
        }
      }
    }
  }

  throw lastError || new Error('SSO login failed');
}
