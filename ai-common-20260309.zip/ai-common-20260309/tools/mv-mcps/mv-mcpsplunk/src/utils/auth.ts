import type { ClientState, TokenSet } from '../types/index.js';
import { splunkRequest } from './http.js';
import { quickValidate } from './token-validator.js';
import { saveTokensToConfig } from './config.js';

/**
 * Check if the state has authentication credentials.
 */
export function isAuthenticated(state: ClientState): boolean {
  return !!(state.sessionKey || state.bearerToken);
}

/**
 * Ensure the state is authenticated by validating tokens against the Splunk server.
 * Reads from ~/.splunk_mcp.local.yaml and validates. Throws if invalid.
 */
export async function ensureAuthenticated(state: ClientState): Promise<void> {
  if (!state.host) {
    throw new Error(
      'No Splunk host configured. Call start_session first or set SPLUNK_HOST.'
    );
  }

  if (!isAuthenticated(state)) {
    throw new Error(
      'Not authenticated. Use start_session, authenticate, or sso_login to connect to Splunk.'
    );
  }

  const splunkUrl = `${state.protocol}://${state.host}${state.port ? ':' + state.port : ''}`;
  const isValid = await quickValidate({
    host: splunkUrl,
    session: {
      session_key: state.sessionKey!,
      csrf_token: state.csrfToken,
      session_id: state.cookies?.session_id_8443 || null,
    },
  });

  if (!isValid) {
    throw new Error(
      'Session tokens are expired or invalid. Use start_session, authenticate, or sso_login to re-authenticate.'
    );
  }
}

/**
 * Authenticate with username/password.
 */
export async function authenticate(
  state: ClientState,
  username: string,
  password: string
): Promise<{ sessionKey: string }> {
  const response = (await splunkRequest(state, 'POST', '/services/auth/login', {
    username,
    password,
    output_mode: 'json',
  })) as { sessionKey?: string };

  if (response.sessionKey) {
    state.sessionKey = response.sessionKey;
    return { sessionKey: '***' };
  }

  throw new Error('Authentication failed: No session key returned');
}

/**
 * Authenticate with bearer token.
 */
export async function authenticateWithToken(
  state: ClientState,
  token: string
): Promise<{ status: string }> {
  state.bearerToken = token;

  try {
    await getServerInfo(state);
    return { status: 'authenticated' };
  } catch (error) {
    state.bearerToken = null;
    throw new Error('Token authentication failed: ' + (error as Error).message);
  }
}

/**
 * Update session tokens in state, save to config, and optionally restart keep-alive.
 */
export function updateTokens(
  state: ClientState,
  tokens: Partial<TokenSet>,
  save = true
): Record<string, unknown> {
  if (tokens.session_key) {
    state.sessionKey = tokens.session_key;
    state.cookies.splunkd_8443 = tokens.session_key;
  }
  if (tokens.csrf_token) {
    state.csrfToken = tokens.csrf_token;
    state.cookies.splunkweb_csrf_token_8443 = tokens.csrf_token;
  }
  if (tokens.lb_cookie) {
    state.cookies.LB = tokens.lb_cookie;
  }
  if (tokens.session_id) {
    state.cookies.session_id_8443 = tokens.session_id;
  }

  state.tokenObtainedAt = new Date();

  if (save) {
    saveTokensToConfig({
      session_key: tokens.session_key ?? undefined,
      csrf_token: tokens.csrf_token ?? undefined,
      lb_cookie: tokens.lb_cookie ?? undefined,
      session_id: tokens.session_id ?? undefined,
    });
  }

  return { status: 'tokens_updated', authenticated: isAuthenticated(state) };
}

/**
 * Ping the server to keep session alive.
 */
export async function ping(
  state: ClientState
): Promise<{ status: string; serverName?: string }> {
  const response = (await splunkRequest(state, 'GET', '/services/server/info', {
    output_mode: 'json',
  })) as { entry?: Array<{ content?: { serverName?: string } }> };

  return {
    status: 'alive',
    serverName: response.entry?.[0]?.content?.serverName,
  };
}

/**
 * Start keep-alive pings.
 */
export function startKeepAlive(
  state: ClientState,
  intervalSeconds = 300
): void {
  stopKeepAlive(state);

  state.keepAliveEnabled = true;
  const intervalMs = intervalSeconds * 1000;

  state.keepAliveInterval = setInterval(async () => {
    try {
      await ping(state);
    } catch {
      // keep-alive ping failed silently
    }
  }, intervalMs);

  if (state.keepAliveInterval.unref) {
    state.keepAliveInterval.unref();
  }
}

/**
 * Stop keep-alive pings.
 */
export function stopKeepAlive(state: ClientState): void {
  if (state.keepAliveInterval) {
    clearInterval(state.keepAliveInterval);
    state.keepAliveInterval = null;
    state.keepAliveEnabled = false;
  }
}

/**
 * Logout and clear session.
 */
export function logout(state: ClientState): void {
  stopKeepAlive(state);
  state.sessionKey = null;
  state.bearerToken = null;
  state.csrfToken = null;
  state.cookies = {};
}

/**
 * Set the Splunk host on state.
 */
export function setHost(
  state: ClientState,
  hostUrl: string,
  verifySsl = true
): void {
  const url = new URL(hostUrl);
  state.host = url.hostname;
  state.isSplunkCloud = state.host.includes('splunkcloud.com');
  const defaultPort = state.isSplunkCloud ? 443 : 8089;
  state.port = url.port ? Number(url.port) : defaultPort;
  state.protocol = url.protocol.replace(':', '') as 'https' | 'http';
  state.verifySsl = verifySsl;
}

/**
 * Get server info.
 */
export async function getServerInfo(
  state: ClientState
): Promise<Record<string, unknown>> {
  const response = (await splunkRequest(state, 'GET', '/services/server/info', {
    output_mode: 'json',
  })) as { entry?: Array<{ content?: Record<string, unknown> }> };

  const info = response.entry?.[0]?.content || {};
  return {
    serverName: info.serverName,
    version: info.version,
    build: info.build,
    os: info.os_name,
    cpuArch: info.cpu_arch,
    licenseState: info.licenseState,
    isFree: info.isFree,
    isTrial: info.isTrial,
  };
}

/**
 * Get SSO config from state with env var fallbacks.
 */
export function getSsoConfig(state: ClientState): {
  email: string | null;
  password: string | null;
  headless: boolean;
  timeoutSeconds: number;
  splunkUrl: string;
} {
  return {
    email: state.ssoConfig.email || process.env.SPLUNK_SSO_EMAIL || null,
    password:
      state.ssoConfig.password || process.env.SPLUNK_SSO_PASSWORD || null,
    headless: state.ssoConfig.headless,
    timeoutSeconds: state.ssoConfig.timeoutSeconds || 120,
    splunkUrl: `${state.protocol}://${state.host}${state.port ? ':' + state.port : ''}`,
  };
}
