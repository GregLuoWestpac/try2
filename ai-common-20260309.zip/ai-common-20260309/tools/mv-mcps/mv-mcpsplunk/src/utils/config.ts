import fs from 'node:fs';
import path from 'node:path';
import yaml from 'js-yaml';
import type { SplunkConfig, ClientState } from '../types/index.js';

/**
 * Find the config file in standard locations.
 */
function findConfigFile(): string | null {
  const searchPaths = [
    path.join(
      process.env.HOME || process.env.USERPROFILE || '',
      '.splunk_mcp.local.yaml'
    ),
    path.join(process.cwd(), '.splunk_mcp.local.yaml'),
  ];

  for (const cfgPath of searchPaths) {
    try {
      if (fs.existsSync(cfgPath)) {
        return cfgPath;
      }
    } catch {
      // ignore
    }
  }
  return null;
}

/**
 * Load config from ~/.splunk_mcp.local.yaml and return a ClientState.
 */
export function loadConfig(): ClientState {
  const state: ClientState = {
    host: '',
    port: 8089,
    protocol: 'https',
    verifySsl: true,
    sessionKey: null,
    bearerToken: null,
    csrfToken: null,
    cookies: {},
    isSplunkCloud: false,
    keepAliveInterval: null,
    keepAliveEnabled: false,
    ssoConfig: {
      email: null,
      password: null,
      headless: true,
      timeoutSeconds: 120,
    },
    tokenObtainedAt: null,
  };

  const configPath = findConfigFile();
  if (!configPath) {
    console.error('[mv-mcpsplunk] No config file found');
    return state;
  }

  let config: SplunkConfig | null = null;
  try {
    const content = fs.readFileSync(configPath, 'utf-8');
    config = yaml.load(content) as SplunkConfig;
    console.error(`[mv-mcpsplunk] Loaded config from ${configPath}`);
  } catch (e) {
    console.error(
      `[mv-mcpsplunk] Failed to load config: ${(e as Error).message}`
    );
    return state;
  }

  if (!config?.splunk) {
    console.error('[mv-mcpsplunk] No splunk config found in config file');
    return state;
  }

  const splunk = config.splunk;

  // Host
  if (splunk.host) {
    const url = new URL(splunk.host);
    state.host = url.hostname;
    state.isSplunkCloud = state.host.includes('splunkcloud.com');
    const defaultPort = state.isSplunkCloud ? 443 : 8089;
    state.port = url.port ? Number(url.port) : defaultPort;
    state.protocol = url.protocol.replace(':', '') as 'https' | 'http';
    state.verifySsl = splunk.verify_ssl !== false;
  }

  // Session tokens
  if (splunk.session) {
    if (splunk.session.session_key) {
      state.sessionKey = splunk.session.session_key;
    }
    if (splunk.session.csrf_token) {
      state.csrfToken = splunk.session.csrf_token;
    }
    state.cookies = {
      splunkd_8443: splunk.session.session_key || '',
      splunkweb_csrf_token_8443: splunk.session.csrf_token || '',
      LB: splunk.session.lb_cookie || '',
      session_id_8443: splunk.session.session_id || '',
    };
    if (splunk.session.obtained_at) {
      state.tokenObtainedAt = new Date(splunk.session.obtained_at);
    }
  }

  // SSO config
  if (splunk.sso) {
    state.ssoConfig = {
      email: splunk.sso.email || null,
      password: splunk.sso.password || null,
      headless: splunk.sso.headless !== false,
      timeoutSeconds: splunk.sso.timeout_seconds || 120,
    };
  }

  return state;
}

/**
 * Save updated tokens to the config file.
 */
export function saveTokensToConfig(tokens: {
  session_key?: string;
  csrf_token?: string;
  lb_cookie?: string;
  session_id?: string;
}): boolean {
  const configPath = findConfigFile();
  if (!configPath) return false;

  let config: SplunkConfig;
  try {
    const content = fs.readFileSync(configPath, 'utf-8');
    config = yaml.load(content) as SplunkConfig;
  } catch {
    return false;
  }

  if (!config) config = {};
  if (!config.splunk) config.splunk = {};
  if (!config.splunk.session) config.splunk.session = {};

  if (tokens.session_key)
    config.splunk.session.session_key = tokens.session_key;
  if (tokens.csrf_token) config.splunk.session.csrf_token = tokens.csrf_token;
  if (tokens.lb_cookie) config.splunk.session.lb_cookie = tokens.lb_cookie;
  if (tokens.session_id) config.splunk.session.session_id = tokens.session_id;
  config.splunk.session.obtained_at = new Date().toISOString();

  try {
    const yamlContent = yaml.dump(config, { lineWidth: -1 });
    fs.writeFileSync(configPath, yamlContent, 'utf-8');
    return true;
  } catch {
    return false;
  }
}
