import https from 'node:https';
import http from 'node:http';
import type { ClientState } from '../types/index.js';

/**
 * Build URL path for Splunk API.
 * Splunk Cloud requires /en-US/splunkd/__raw prefix.
 */
function buildPath(state: ClientState, apiPath: string): string {
  if (state.isSplunkCloud) {
    return `/en-US/splunkd/__raw${apiPath}`;
  }
  return apiPath;
}

/**
 * Build authentication headers based on auth type.
 * Splunk Cloud uses cookies + CSRF, Enterprise uses Bearer/Splunk token.
 */
function buildAuthHeaders(state: ClientState): Record<string, string> {
  if (state.isSplunkCloud && state.csrfToken && state.sessionKey) {
    return {
      Cookie: `splunkd_8443=${state.sessionKey}; splunkweb_csrf_token_8443=${state.csrfToken}`,
      'X-Splunk-Form-Key': state.csrfToken,
      'X-Requested-With': 'XMLHttpRequest',
    };
  }

  if (state.bearerToken) {
    return { Authorization: `Bearer ${state.bearerToken}` };
  }

  if (state.sessionKey) {
    return { Authorization: `Splunk ${state.sessionKey}` };
  }

  return {};
}

/**
 * Parse search results into a clean format.
 */
export function parseSearchResults(
  response: unknown
): { results: unknown[]; resultCount: number } | unknown {
  if (typeof response === 'string') {
    const lines = response.trim().split('\n').filter(Boolean);
    const results: unknown[] = [];

    for (const line of lines) {
      try {
        const parsed = JSON.parse(line);
        if (parsed.result) {
          results.push(parsed.result);
        }
      } catch {
        // Skip unparseable lines
      }
    }

    return { results, resultCount: results.length };
  }

  if (
    response &&
    typeof response === 'object' &&
    'results' in response &&
    Array.isArray((response as { results: unknown[] }).results)
  ) {
    const r = response as { results: unknown[] };
    return { results: r.results, resultCount: r.results.length };
  }

  return response;
}

/**
 * Make an HTTP request to the Splunk REST API.
 */
export async function splunkRequest(
  state: ClientState,
  method: string,
  apiPath: string,
  params: Record<string, string | number | boolean | undefined> = {}
): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const isPost = method === 'POST';
    let body = '';
    let pathWithQuery = apiPath;

    // Filter out undefined params
    const cleanParams: Record<string, string> = {};
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined) cleanParams[k] = String(v);
    }

    if (isPost) {
      body = new URLSearchParams(cleanParams).toString();
    } else {
      const queryString = new URLSearchParams(cleanParams).toString();
      if (queryString) {
        pathWithQuery += '?' + queryString;
      }
    }

    const fullPath = buildPath(state, pathWithQuery);
    const authHeaders = buildAuthHeaders(state);

    const options: https.RequestOptions = {
      hostname: state.host,
      port: state.port,
      path: fullPath,
      method,
      headers: {
        Accept: 'application/json',
        ...authHeaders,
      },
      rejectUnauthorized: state.verifySsl,
    };

    if (isPost) {
      (options.headers as Record<string, string>)['Content-Type'] =
        'application/x-www-form-urlencoded';
      (options.headers as Record<string, string>)['Content-Length'] = String(
        Buffer.byteLength(body)
      );
    }

    const proto = state.protocol === 'https' ? https : http;

    const req = proto.request(options, res => {
      let data = '';

      res.on('data', (chunk: string) => {
        data += chunk;
      });

      res.on('end', () => {
        if (res.statusCode && res.statusCode >= 400) {
          let errorMessage = `HTTP ${res.statusCode}`;
          try {
            const parsed = JSON.parse(data);
            errorMessage =
              parsed.messages?.[0]?.text || parsed.error || errorMessage;
          } catch {
            errorMessage = data.substring(0, 200) || errorMessage;
          }

          if (res.statusCode === 401 || res.statusCode === 303) {
            const err = new Error(errorMessage) as Error & {
              statusCode: number;
              isAuthError: boolean;
            };
            err.statusCode = res.statusCode;
            err.isAuthError = true;
            reject(err);
            return;
          }

          reject(new Error(errorMessage));
          return;
        }

        try {
          resolve(JSON.parse(data));
        } catch {
          resolve(data);
        }
      });
    });

    req.setTimeout(30000, () => {
      req.destroy(new Error('Request timeout after 30s'));
    });

    req.on('error', (error: Error) => {
      reject(new Error(error.message || String(error)));
    });

    if (isPost && body) {
      req.write(body);
    }

    req.end();
  });
}
