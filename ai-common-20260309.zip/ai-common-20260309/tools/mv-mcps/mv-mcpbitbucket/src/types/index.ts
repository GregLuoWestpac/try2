export interface BitbucketConfig {
  bitbucket?: {
    host?: string;
    verify_ssl?: boolean;
    auth?: {
      http_access_token?: string;
      bearer_token?: string;
      username?: string;
      password?: string;
    };
    session?: {
      cookies?: Record<string, string>;
      obtained_at?: string;
    };
  };
  keepalive?: {
    enabled?: boolean;
    interval_seconds?: number;
  };
}

export interface ClientState {
  host: string;
  port: number;
  protocol: 'https' | 'http';
  verifySsl: boolean;
  apiBase: string;
  buildStatusBase: string;
  bearerToken: string | null;
  httpAccessToken: string | null;
  basicAuth: string | null;
  cookies: Record<string, string>;
  keepAliveInterval: ReturnType<typeof setInterval> | null;
  keepAliveEnabled: boolean;
  tokenObtainedAt: Date | null;
}
