import type { ClientState } from '../types/index.js';
import { bitbucketRequest } from './http.js';

export function setHost(
  state: ClientState,
  hostUrl: string,
  verifySsl = true
): void {
  const url = new URL(hostUrl);
  state.host = url.hostname;
  state.port = url.port
    ? Number(url.port)
    : url.protocol === 'https:'
      ? 443
      : 80;
  state.protocol = url.protocol.replace(':', '') as 'https' | 'http';
  state.verifySsl = verifySsl;

  if (!verifySsl) {
    console.error(
      '[mv-mcpbitbucket] ⚠️  WARNING: SSL verification is DISABLED.'
    );
  }
  if (state.protocol === 'http') {
    console.error(
      '[mv-mcpbitbucket] ⚠️  WARNING: Using plain HTTP — credentials in cleartext.'
    );
  }

  const contextPath = url.pathname.replace(/\/+$/, '');
  state.apiBase = `${contextPath}/rest/api/1.0`;
  state.buildStatusBase = `${contextPath}/rest/build-status/1.0`;
}

export function setHttpAccessToken(state: ClientState, token: string): void {
  state.httpAccessToken = token;
}

export function setBearerToken(state: ClientState, token: string): void {
  state.bearerToken = token;
}

export function setBasicAuth(
  state: ClientState,
  username: string,
  password: string
): void {
  state.basicAuth = Buffer.from(`${username}:${password}`).toString('base64');
}

export function isAuthenticated(state: ClientState): boolean {
  return !!(
    state.basicAuth ||
    state.bearerToken ||
    state.httpAccessToken ||
    state.cookies['JSESSIONID']
  );
}

export async function ping(
  state: ClientState
): Promise<{ version?: string; displayName?: string }> {
  const result = (await bitbucketRequest(
    state,
    'GET',
    `${state.apiBase}/application-properties`
  )) as { version?: string; displayName?: string };
  return { version: result.version, displayName: result.displayName };
}

export function logout(state: ClientState): void {
  stopKeepAlive(state);
  state.basicAuth = null;
  state.bearerToken = null;
  state.httpAccessToken = null;
  state.cookies = {};
}

export function startKeepAlive(
  state: ClientState,
  intervalSeconds = 300
): void {
  stopKeepAlive(state);
  state.keepAliveEnabled = true;

  state.keepAliveInterval = setInterval(async () => {
    try {
      await ping(state);
    } catch {
      // keep-alive ping failed — ignore
    }
  }, intervalSeconds * 1000);

  if (state.keepAliveInterval.unref) {
    state.keepAliveInterval.unref();
  }
}

export function stopKeepAlive(state: ClientState): void {
  if (state.keepAliveInterval) {
    clearInterval(state.keepAliveInterval);
    state.keepAliveInterval = null;
    state.keepAliveEnabled = false;
  }
}
