import https from 'node:https';
import http from 'node:http';
import type { ClientState } from '../types/index.js';

function buildAuthHeaders(state: ClientState): Record<string, string> {
  if (state.httpAccessToken) {
    return { Authorization: `Bearer ${state.httpAccessToken}` };
  }
  if (state.bearerToken) {
    return { Authorization: `Bearer ${state.bearerToken}` };
  }
  if (state.basicAuth) {
    return { Authorization: `Basic ${state.basicAuth}` };
  }

  const cookieParts: string[] = [];
  for (const [name, value] of Object.entries(state.cookies)) {
    if (value) cookieParts.push(`${name}=${value}`);
  }
  const headers: Record<string, string> = {};
  if (cookieParts.length > 0) {
    headers['Cookie'] = cookieParts.join('; ');
  }
  return headers;
}

/** Encode a single path segment to prevent path traversal. */
export function encodeSegment(value: string | number): string {
  return encodeURIComponent(String(value));
}

/** Build a query string from an object, omitting undefined values. */
export function buildQueryString(
  params: Record<string, string | number | boolean | undefined>
): string {
  const clean: Record<string, string> = {};
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined) clean[k] = String(v);
  }
  const qs = new URLSearchParams(clean).toString();
  return qs ? `?${qs}` : '';
}

/**
 * Make an HTTP request to the Bitbucket Server REST API.
 */
export async function bitbucketRequest(
  state: ClientState,
  method: string,
  apiPath: string,
  body: unknown = null
): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const isWrite =
      method === 'POST' || method === 'PUT' || method === 'DELETE';
    let bodyStr = '';

    if (body && isWrite) {
      bodyStr = JSON.stringify(body);
    }

    const authHeaders = buildAuthHeaders(state);

    const options: https.RequestOptions = {
      hostname: state.host,
      port: state.port,
      path: apiPath,
      method,
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        ...authHeaders,
      },
      rejectUnauthorized: state.verifySsl,
    };

    if (isWrite && bodyStr) {
      (options.headers as Record<string, string>)['Content-Length'] = String(
        Buffer.byteLength(bodyStr)
      );
    }

    const proto = state.protocol === 'https' ? https : http;

    const req = proto.request(options, res => {
      let data = '';

      res.on('data', (chunk: string) => {
        data += chunk;
      });

      res.on('end', () => {
        if (res.statusCode && res.statusCode >= 400) {
          let errorMessage = `HTTP ${res.statusCode}`;
          try {
            const parsed = JSON.parse(data);
            const errors = parsed.errors || [];
            errorMessage = errors[0]?.message || parsed.message || errorMessage;
          } catch {
            errorMessage = data.substring(0, 200) || errorMessage;
          }

          if (res.statusCode === 401 || res.statusCode === 403) {
            const err = new Error(errorMessage) as Error & {
              statusCode: number;
              isAuthError: boolean;
            };
            err.statusCode = res.statusCode;
            err.isAuthError = true;
            reject(err);
            return;
          }

          reject(new Error(errorMessage));
          return;
        }

        if (res.statusCode === 204 || !data) {
          resolve({});
          return;
        }

        try {
          resolve(JSON.parse(data));
        } catch {
          resolve(data);
        }
      });
    });

    req.setTimeout(30000, () => {
      req.destroy(new Error('Request timeout after 30s'));
    });

    req.on('error', (error: Error) => {
      reject(new Error(error.message || String(error)));
    });

    if (isWrite && bodyStr) {
      req.write(bodyStr);
    }

    req.end();
  });
}
