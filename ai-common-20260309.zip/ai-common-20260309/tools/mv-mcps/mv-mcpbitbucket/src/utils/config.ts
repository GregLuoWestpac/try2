import fs from 'node:fs';
import path from 'node:path';
import yaml from 'js-yaml';
import type { BitbucketConfig, ClientState } from '../types/index.js';

function findConfigFile(): string | null {
  const searchPaths = [
    path.join(process.cwd(), '.bitbucket_mcp.local.yaml'),
    path.join(
      process.env.HOME || process.env.USERPROFILE || '',
      '.bitbucket_mcp.local.yaml'
    ),
  ];

  for (const cfgPath of searchPaths) {
    try {
      if (fs.existsSync(cfgPath)) {
        return cfgPath;
      }
    } catch {
      // ignore
    }
  }
  return null;
}

/** Create a default empty ClientState. */
export function createDefaultState(): ClientState {
  return {
    host: '',
    port: 443,
    protocol: 'https',
    verifySsl: true,
    apiBase: '/rest/api/1.0',
    buildStatusBase: '/rest/build-status/1.0',
    bearerToken: null,
    httpAccessToken: null,
    basicAuth: null,
    cookies: {},
    keepAliveInterval: null,
    keepAliveEnabled: false,
    tokenObtainedAt: null,
  };
}

/**
 * Load config from .bitbucket_mcp.local.yaml and populate a ClientState.
 */
export function loadConfig(state?: ClientState): ClientState {
  const s = state ?? createDefaultState();

  const configPath = findConfigFile();
  if (!configPath) {
    console.error('[mv-mcpbitbucket] No config file found');
    return s;
  }

  let config: BitbucketConfig | null = null;
  try {
    const content = fs.readFileSync(configPath, 'utf-8');
    config = yaml.load(content) as BitbucketConfig;
    console.error(`[mv-mcpbitbucket] Loaded config from ${configPath}`);
  } catch (e) {
    console.error(
      `[mv-mcpbitbucket] Failed to load config: ${(e as Error).message}`
    );
    return s;
  }

  if (!config?.bitbucket) {
    console.error('[mv-mcpbitbucket] No bitbucket section in config file');
    return s;
  }

  const bb = config.bitbucket;

  // Host
  if (bb.host) {
    const url = new URL(bb.host);
    s.host = url.hostname;
    s.port = url.port ? Number(url.port) : url.protocol === 'https:' ? 443 : 80;
    s.protocol = url.protocol.replace(':', '') as 'https' | 'http';
    s.verifySsl = bb.verify_ssl !== false;
    const contextPath = url.pathname.replace(/\/+$/, '');
    s.apiBase = `${contextPath}/rest/api/1.0`;
    s.buildStatusBase = `${contextPath}/rest/build-status/1.0`;
  }

  // Auth
  if (bb.auth) {
    if (bb.auth.http_access_token) {
      s.httpAccessToken = bb.auth.http_access_token;
    }
    if (bb.auth.bearer_token) {
      s.bearerToken = bb.auth.bearer_token;
    }
    if (bb.auth.username && process.env.BITBUCKET_PASSWORD) {
      s.basicAuth = Buffer.from(
        `${bb.auth.username}:${process.env.BITBUCKET_PASSWORD}`
      ).toString('base64');
    }
  }

  // Session cookies
  if (bb.session?.cookies && typeof bb.session.cookies === 'object') {
    Object.assign(s.cookies, bb.session.cookies);
  }
  if (bb.session?.obtained_at) {
    s.tokenObtainedAt = new Date(bb.session.obtained_at);
  }

  // Keepalive
  if (config.keepalive?.enabled) {
    // Caller should start keepalive after loading config
  }

  return s;
}
