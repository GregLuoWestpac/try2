#!/usr/bin/env node

/**
 * mv-mcpbitbucket — Bitbucket MCP Server
 *
 * Starts a stdio-based MCP server providing Bitbucket tools for repository
 * management, pull requests, branches, commits, and build status.
 * Built with the official @modelcontextprotocol/sdk TypeScript SDK.
 *
 * Usage:
 *   npx @mesh-tenant-multiverse-ui-common/mv-mcpbitbucket
 */

import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { loadConfig } from './utils/config.js';
import { createServer } from './server.js';

async function main() {
  const state = loadConfig();

  if (!state.host) {
    console.error(
      '[mv-mcpbitbucket] WARNING: No Bitbucket host configured. Use start_session to configure.'
    );
  }

  const server = createServer(state);
  const transport = new StdioServerTransport();
  await server.connect(transport);

  console.error(
    `[mv-mcpbitbucket] Server ready (STDIO transport${state.host ? `, host: ${state.protocol}://${state.host}:${state.port}` : ''})`
  );
}

main().catch(error => {
  console.error('Failed to start mv-mcpbitbucket:', error);
  process.exit(1);
});
