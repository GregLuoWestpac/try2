import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ClientState } from '../types/index.js';
import {
  isAuthenticated,
  setHost,
  setHttpAccessToken,
  setBearerToken,
  setBasicAuth,
  ping,
  logout,
} from '../utils/auth.js';
import { loadConfig } from '../utils/config.js';

export function registerSessionTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'start_session',
    {
      description:
        'Start a new Bitbucket session. Call this before other Bitbucket operations to initialize the connection.',
      inputSchema: z.object({
        host: z
          .string()
          .optional()
          .describe(
            'Bitbucket host URL (e.g., https://bitbucket.example.com). Uses BITBUCKET_HOST env var if not provided.'
          ),
        verify_ssl: z
          .boolean()
          .optional()
          .describe('Whether to verify SSL certificates (default: true)'),
        load_config: z
          .boolean()
          .optional()
          .describe(
            'Load configuration from .bitbucket_mcp.local.yaml file (default: true)'
          ),
      }),
    },
    async ({ host, verify_ssl, load_config: loadCfg }) => {
      if (loadCfg !== false) {
        loadConfig(state);
        if (state.host && isAuthenticated(state)) {
          return {
            content: [
              {
                type: 'text' as const,
                text: JSON.stringify(
                  {
                    status: 'session_started',
                    host: `${state.protocol}://${state.host}:${state.port}`,
                    message:
                      'Bitbucket session started from config file. Already authenticated.',
                    keepalive: state.keepAliveEnabled ? 'enabled' : 'disabled',
                  },
                  null,
                  2
                ),
              },
            ],
          };
        }
      }

      const hostUrl = host || process.env.BITBUCKET_HOST;
      if (!hostUrl) {
        return {
          content: [
            {
              type: 'text' as const,
              text: JSON.stringify(
                {
                  error:
                    'No Bitbucket host provided. Set BITBUCKET_HOST environment variable or provide host parameter.',
                },
                null,
                2
              ),
            },
          ],
        };
      }

      setHost(state, hostUrl, verify_ssl !== false);
      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(
              {
                status: 'session_started',
                host: hostUrl,
                message:
                  'Bitbucket session started. Use authenticate to log in.',
              },
              null,
              2
            ),
          },
        ],
      };
    }
  );

  server.registerTool(
    'reset_session',
    {
      description:
        'Reset the current Bitbucket session, clearing all runtime authentication.',
      inputSchema: z.object({}),
    },
    async () => {
      logout(state);
      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(
              {
                status: 'session_reset',
                message: 'Bitbucket session has been reset.',
              },
              null,
              2
            ),
          },
        ],
      };
    }
  );

  server.registerTool(
    'authenticate',
    {
      description:
        'Authenticate with Bitbucket using an HTTP access token (recommended) or bearer token.',
      inputSchema: z.object({
        http_access_token: z
          .string()
          .optional()
          .describe(
            'Bitbucket HTTP access token (personal or project). Uses BITBUCKET_TOKEN env var if not provided.'
          ),
        bearer_token: z
          .string()
          .optional()
          .describe(
            'Bearer token for authentication. Uses BITBUCKET_BEARER_TOKEN env var if not provided.'
          ),
        session_id: z
          .string()
          .optional()
          .describe('Session ID for storing auth (optional)'),
      }),
    },
    async ({ http_access_token, bearer_token }) => {
      const httpToken = http_access_token || process.env.BITBUCKET_TOKEN;
      if (httpToken) {
        setHttpAccessToken(state, httpToken);
        await ping(state);
        return {
          content: [
            {
              type: 'text' as const,
              text: JSON.stringify(
                { status: 'authenticated', method: 'http_access_token' },
                null,
                2
              ),
            },
          ],
        };
      }

      const bearer = bearer_token || process.env.BITBUCKET_BEARER_TOKEN;
      if (bearer) {
        setBearerToken(state, bearer);
        await ping(state);
        return {
          content: [
            {
              type: 'text' as const,
              text: JSON.stringify(
                { status: 'authenticated', method: 'bearer' },
                null,
                2
              ),
            },
          ],
        };
      }

      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify(
              {
                error:
                  'No credentials provided. Provide http_access_token (or set BITBUCKET_TOKEN), bearer_token (BITBUCKET_BEARER_TOKEN).',
              },
              null,
              2
            ),
          },
        ],
      };
    }
  );
}
