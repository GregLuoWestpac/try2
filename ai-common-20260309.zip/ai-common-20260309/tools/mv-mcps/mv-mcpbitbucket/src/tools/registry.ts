import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ClientState } from '../types/index.js';
import { registerSessionTools } from './session.js';
import { registerRepositoryTools } from './repositories.js';
import { registerPullRequestTools } from './pull-requests.js';
import { registerPrCommentTools } from './pr-comments.js';
import { registerCommitTools } from './commits.js';
import { registerBuildStatusTools } from './build-status.js';

export function registerAllTools(server: McpServer, state: ClientState): void {
  registerSessionTools(server, state);
  registerRepositoryTools(server, state);
  registerPullRequestTools(server, state);
  registerPrCommentTools(server, state);
  registerCommitTools(server, state);
  registerBuildStatusTools(server, state);
}
