import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ClientState } from '../types/index.js';
import {
  bitbucketRequest,
  encodeSegment,
  buildQueryString,
} from '../utils/http.js';

export function registerBuildStatusTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'get_build_status',
    {
      description: 'Get build statuses for a commit (CI/CD pipeline results).',
      inputSchema: z.object({
        commit_id: z.string().describe('Full commit SHA'),
        start: z.number().optional().describe('Pagination start index'),
        limit: z
          .number()
          .optional()
          .describe('Max results per page (default: 25)'),
      }),
    },
    async ({ commit_id, start, limit }) => {
      const qs = buildQueryString({ start, limit: limit ?? 25 });
      const result = await bitbucketRequest(
        state,
        'GET',
        `${state.buildStatusBase}/commits/${encodeSegment(commit_id)}${qs}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'set_build_status',
    {
      description:
        'Post a build status for a commit (e.g., from a CI pipeline).',
      inputSchema: z.object({
        commit_id: z.string().describe('Full commit SHA'),
        state: z
          .enum(['SUCCESSFUL', 'FAILED', 'INPROGRESS'])
          .describe('Build state'),
        key: z.string().describe('Unique build key (e.g., pipeline name)'),
        url: z.string().describe('URL to the build result'),
        name: z.string().optional().describe('Display name for the build'),
        description: z.string().optional().describe('Build description'),
      }),
    },
    async ({ commit_id, state: buildState, key, url, name, description }) => {
      const data: Record<string, unknown> = {
        state: buildState,
        key,
        url,
      };
      if (name) data.name = name;
      if (description) data.description = description;
      const result = await bitbucketRequest(
        state,
        'POST',
        `${state.buildStatusBase}/commits/${encodeSegment(commit_id)}`,
        data
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );
}
