import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ClientState } from '../types/index.js';
import {
  bitbucketRequest,
  encodeSegment,
  buildQueryString,
} from '../utils/http.js';

export function registerCommitTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'get_commits',
    {
      description:
        'List commits for a repository, optionally between two refs or for a specific file path.',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
        since: z
          .string()
          .optional()
          .describe('Commit ID or ref to start from (exclusive)'),
        until: z
          .string()
          .optional()
          .describe(
            'Commit ID or ref to go up to (inclusive, defaults to default branch HEAD)'
          ),
        path: z.string().optional().describe('File path to filter commits by'),
        start: z.number().optional().describe('Pagination start index'),
        limit: z
          .number()
          .optional()
          .describe('Max results per page (default: 25)'),
      }),
    },
    async ({ project, repo, since, until, path, start, limit }) => {
      const qs = buildQueryString({
        since,
        until,
        path,
        start,
        limit: limit ?? 25,
      });
      const result = await bitbucketRequest(
        state,
        'GET',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/commits${qs}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_commit',
    {
      description: 'Get details of a single commit by its commit ID.',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
        commit_id: z.string().describe('Full or abbreviated commit SHA'),
      }),
    },
    async ({ project, repo, commit_id }) => {
      const result = await bitbucketRequest(
        state,
        'GET',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/commits/${encodeSegment(commit_id)}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_file_content',
    {
      description:
        'Get file content at a specific ref or path in a repository.',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
        path: z.string().describe('File path within the repository'),
        at: z
          .string()
          .optional()
          .describe(
            'Branch, tag, or commit to read from (defaults to default branch)'
          ),
        start: z
          .number()
          .optional()
          .describe('Pagination start (for large files)'),
        limit: z.number().optional().describe('Max lines to return'),
      }),
    },
    async ({ project, repo, path: filePath, at, start, limit }) => {
      const qs = buildQueryString({ at, start, limit });
      const encodedPath = filePath.split('/').map(encodeURIComponent).join('/');
      const result = await bitbucketRequest(
        state,
        'GET',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/browse/${encodedPath}${qs}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );
}
