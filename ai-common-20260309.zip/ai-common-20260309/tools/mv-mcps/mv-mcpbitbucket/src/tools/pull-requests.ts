import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ClientState } from '../types/index.js';
import {
  bitbucketRequest,
  encodeSegment,
  buildQueryString,
} from '../utils/http.js';

export function registerPullRequestTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'search_pull_requests',
    {
      description:
        'List pull requests for a repository, with optional filters by state, direction, and branch.',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
        state: z
          .enum(['OPEN', 'MERGED', 'DECLINED', 'ALL'])
          .optional()
          .describe('PR state filter'),
        direction: z
          .enum(['INCOMING', 'OUTGOING'])
          .optional()
          .describe('Filter by direction'),
        at: z
          .string()
          .optional()
          .describe(
            'Fully-qualified branch ref to filter (e.g., refs/heads/master)'
          ),
        order: z.enum(['NEWEST', 'OLDEST']).optional().describe('Sort order'),
        start: z.number().optional().describe('Pagination start index'),
        limit: z
          .number()
          .optional()
          .describe('Max results per page (default: 25)'),
      }),
    },
    async ({
      project,
      repo,
      state: prState,
      direction,
      at,
      order,
      start,
      limit,
    }) => {
      const qs = buildQueryString({
        state: prState,
        direction,
        at,
        order,
        start,
        limit: limit ?? 25,
      });
      const result = await bitbucketRequest(
        state,
        'GET',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/pull-requests${qs}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_pull_request',
    {
      description: 'Get details of a specific pull request by ID.',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
        pr_id: z.number().describe('Pull request ID'),
      }),
    },
    async ({ project, repo, pr_id }) => {
      const result = await bitbucketRequest(
        state,
        'GET',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/pull-requests/${encodeSegment(pr_id)}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_pull_request_diff',
    {
      description: 'Get the diff for a pull request.',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
        pr_id: z.number().describe('Pull request ID'),
        context_lines: z
          .number()
          .optional()
          .describe('Number of context lines around changes (default: 10)'),
        with_comments: z
          .boolean()
          .optional()
          .describe('Include comments in diff (default: false)'),
      }),
    },
    async ({ project, repo, pr_id, context_lines, with_comments }) => {
      const qs = buildQueryString({
        contextLines: context_lines,
        withComments: with_comments,
      });
      const result = await bitbucketRequest(
        state,
        'GET',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/pull-requests/${encodeSegment(pr_id)}/diff${qs}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_pull_request_activities',
    {
      description:
        'Get the activity feed for a pull request (comments, approvals, merges, status changes).',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
        pr_id: z.number().describe('Pull request ID'),
        start: z.number().optional().describe('Pagination start index'),
        limit: z
          .number()
          .optional()
          .describe('Max results per page (default: 25)'),
      }),
    },
    async ({ project, repo, pr_id, start, limit }) => {
      const qs = buildQueryString({ start, limit: limit ?? 25 });
      const result = await bitbucketRequest(
        state,
        'GET',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/pull-requests/${encodeSegment(pr_id)}/activities${qs}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'create_pull_request',
    {
      description: 'Create a new pull request.',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
        title: z.string().describe('PR title'),
        description: z
          .string()
          .optional()
          .describe('PR description (optional)'),
        from_ref: z
          .string()
          .describe('Source branch (e.g., feature/my-branch)'),
        to_ref: z.string().describe('Target branch (e.g., master)'),
        reviewers: z
          .array(z.string())
          .optional()
          .describe('List of reviewer usernames'),
      }),
    },
    async ({
      project,
      repo,
      title,
      description,
      from_ref,
      to_ref,
      reviewers,
    }) => {
      const data: Record<string, unknown> = {
        title,
        fromRef: {
          id: `refs/heads/${from_ref}`,
          repository: { slug: repo, project: { key: project } },
        },
        toRef: {
          id: `refs/heads/${to_ref}`,
          repository: { slug: repo, project: { key: project } },
        },
      };
      if (description) data.description = description;
      if (reviewers && reviewers.length > 0) {
        data.reviewers = reviewers.map(u => ({ user: { name: u } }));
      }
      const result = await bitbucketRequest(
        state,
        'POST',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/pull-requests`,
        data
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'update_pull_request',
    {
      description:
        'Update a pull request (title, description, reviewers, or target branch).',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
        pr_id: z.number().describe('Pull request ID'),
        title: z.string().optional().describe('New title'),
        description: z.string().optional().describe('New description'),
        to_ref: z.string().optional().describe('New target branch'),
        reviewers: z
          .array(z.string())
          .optional()
          .describe('Updated list of reviewer usernames'),
        version: z
          .number()
          .optional()
          .describe('Current PR version (for optimistic locking)'),
      }),
    },
    async ({
      project,
      repo,
      pr_id,
      title,
      description,
      to_ref,
      reviewers,
      version,
    }) => {
      // Fetch existing PR to merge fields
      const existing = (await bitbucketRequest(
        state,
        'GET',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/pull-requests/${encodeSegment(pr_id)}`
      )) as Record<string, unknown>;

      const data: Record<string, unknown> = {
        id: pr_id,
        version: version !== undefined ? version : existing.version,
        title: title || existing.title,
        description:
          description !== undefined ? description : existing.description,
        toRef: to_ref ? { id: `refs/heads/${to_ref}` } : existing.toRef,
      };
      if (reviewers) {
        data.reviewers = reviewers.map(u => ({ user: { name: u } }));
      } else {
        data.reviewers = existing.reviewers;
      }

      const result = await bitbucketRequest(
        state,
        'PUT',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/pull-requests/${encodeSegment(pr_id)}`,
        data
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'merge_pull_request',
    {
      description: 'Merge a pull request.',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
        pr_id: z.number().describe('Pull request ID'),
        version: z
          .number()
          .optional()
          .describe('Current PR version (for optimistic locking)'),
        message: z.string().optional().describe('Merge commit message'),
        strategy: z
          .enum([
            'merge-commit',
            'rebase-no-ff',
            'rebase-ff-only',
            'squash',
            'squash-ff-only',
          ])
          .optional()
          .describe('Merge strategy'),
      }),
    },
    async ({ project, repo, pr_id, version, message, strategy }) => {
      const qs = buildQueryString({
        version,
      });
      const body: Record<string, unknown> = {};
      if (message) body.message = message;
      if (strategy) body.strategyId = strategy;
      const result = await bitbucketRequest(
        state,
        'POST',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/pull-requests/${encodeSegment(pr_id)}/merge${qs}`,
        body
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );
}
