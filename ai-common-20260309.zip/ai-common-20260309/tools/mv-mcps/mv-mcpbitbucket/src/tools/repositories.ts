import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ClientState } from '../types/index.js';
import {
  bitbucketRequest,
  encodeSegment,
  buildQueryString,
} from '../utils/http.js';

export function registerRepositoryTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'get_projects',
    {
      description: 'List accessible Bitbucket projects.',
      inputSchema: z.object({
        start: z
          .number()
          .optional()
          .describe('Pagination start index (default: 0)'),
        limit: z
          .number()
          .optional()
          .describe('Max results per page (default: 25)'),
      }),
    },
    async ({ start, limit }) => {
      const qs = buildQueryString({ start, limit: limit ?? 25 });
      const result = await bitbucketRequest(
        state,
        'GET',
        `${state.apiBase}/projects${qs}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_repos',
    {
      description: 'List repositories, optionally filtered by project key.',
      inputSchema: z.object({
        project: z
          .string()
          .optional()
          .describe(
            'Project key to filter repositories (optional; lists all repos if omitted)'
          ),
        start: z
          .number()
          .optional()
          .describe('Pagination start index (default: 0)'),
        limit: z
          .number()
          .optional()
          .describe('Max results per page (default: 25)'),
      }),
    },
    async ({ project, start, limit }) => {
      const qs = buildQueryString({ start, limit: limit ?? 25 });
      const base = project
        ? `${state.apiBase}/projects/${encodeSegment(project)}/repos`
        : `${state.apiBase}/repos`;
      const result = await bitbucketRequest(state, 'GET', `${base}${qs}`);
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_repo',
    {
      description: 'Get details of a specific repository.',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
      }),
    },
    async ({ project, repo }) => {
      const result = await bitbucketRequest(
        state,
        'GET',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_branches',
    {
      description: 'List branches for a repository.',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
        filter: z
          .string()
          .optional()
          .describe('Filter branches by name substring'),
        order_by: z
          .enum(['ALPHABETICAL', 'MODIFICATION'])
          .optional()
          .describe('Order results'),
        start: z.number().optional().describe('Pagination start index'),
        limit: z
          .number()
          .optional()
          .describe('Max results per page (default: 25)'),
      }),
    },
    async ({ project, repo, filter, order_by, start, limit }) => {
      const qs = buildQueryString({
        filterText: filter,
        orderBy: order_by,
        start,
        limit: limit ?? 25,
      });
      const result = await bitbucketRequest(
        state,
        'GET',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/branches${qs}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_tags',
    {
      description: 'List tags for a repository.',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
        filter: z.string().optional().describe('Filter tags by name substring'),
        order_by: z
          .enum(['ALPHABETICAL', 'MODIFICATION'])
          .optional()
          .describe('Order results'),
        start: z.number().optional().describe('Pagination start index'),
        limit: z
          .number()
          .optional()
          .describe('Max results per page (default: 25)'),
      }),
    },
    async ({ project, repo, filter, order_by, start, limit }) => {
      const qs = buildQueryString({
        filterText: filter,
        orderBy: order_by,
        start,
        limit: limit ?? 25,
      });
      const result = await bitbucketRequest(
        state,
        'GET',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/tags${qs}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'get_default_branch',
    {
      description: 'Get the default branch for a repository.',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
      }),
    },
    async ({ project, repo }) => {
      const result = await bitbucketRequest(
        state,
        'GET',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/default-branch`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );
}
