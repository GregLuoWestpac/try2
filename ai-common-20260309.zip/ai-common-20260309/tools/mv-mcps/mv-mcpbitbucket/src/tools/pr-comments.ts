import { z } from 'zod/v4';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ClientState } from '../types/index.js';
import {
  bitbucketRequest,
  encodeSegment,
  buildQueryString,
} from '../utils/http.js';

export function registerPrCommentTools(
  server: McpServer,
  state: ClientState
): void {
  server.registerTool(
    'get_pull_request_comments',
    {
      description: 'Get all comments on a pull request.',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
        pr_id: z.number().describe('Pull request ID'),
        start: z.number().optional().describe('Pagination start index'),
        limit: z
          .number()
          .optional()
          .describe('Max results per page (default: 25)'),
      }),
    },
    async ({ project, repo, pr_id, start, limit }) => {
      const qs = buildQueryString({ start, limit: limit ?? 25 });
      const result = await bitbucketRequest(
        state,
        'GET',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/pull-requests/${encodeSegment(pr_id)}/comments${qs}`
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'add_pull_request_comment',
    {
      description: 'Add a general or inline comment to a pull request.',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
        pr_id: z.number().describe('Pull request ID'),
        text: z.string().describe('Comment text'),
        parent_id: z
          .number()
          .optional()
          .describe('Parent comment ID (for replies)'),
        file_path: z
          .string()
          .optional()
          .describe('File path for inline comment'),
        line: z.number().optional().describe('Line number for inline comment'),
        line_type: z
          .enum(['ADDED', 'REMOVED', 'CONTEXT'])
          .optional()
          .describe('Line type for inline comment'),
        file_type: z
          .enum(['FROM', 'TO'])
          .optional()
          .describe('File type for inline comment'),
      }),
    },
    async ({
      project,
      repo,
      pr_id,
      text,
      parent_id,
      file_path,
      line,
      line_type,
      file_type,
    }) => {
      const data: Record<string, unknown> = { text };
      if (parent_id) {
        data.parent = { id: parent_id };
      }
      if (file_path) {
        const anchor: Record<string, unknown> = {
          path: file_path,
          srcPath: file_path,
        };
        if (line !== undefined) anchor.line = line;
        if (line_type) anchor.lineType = line_type;
        if (file_type) anchor.fileType = file_type;
        data.anchor = anchor;
      }
      const result = await bitbucketRequest(
        state,
        'POST',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/pull-requests/${encodeSegment(pr_id)}/comments`,
        data
      );
      return {
        content: [
          { type: 'text' as const, text: JSON.stringify(result, null, 2) },
        ],
      };
    }
  );

  server.registerTool(
    'approve_pull_request',
    {
      description: 'Approve a pull request as the current authenticated user.',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
        pr_id: z.number().describe('Pull request ID'),
      }),
    },
    async ({ project, repo, pr_id }) => {
      await bitbucketRequest(
        state,
        'POST',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/pull-requests/${encodeSegment(pr_id)}/approve`
      );
      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify({ status: 'approved', pr_id }, null, 2),
          },
        ],
      };
    }
  );

  server.registerTool(
    'decline_pull_request',
    {
      description: 'Decline a pull request.',
      inputSchema: z.object({
        project: z.string().describe('Project key'),
        repo: z.string().describe('Repository slug'),
        pr_id: z.number().describe('Pull request ID'),
        version: z
          .number()
          .optional()
          .describe('Current PR version (for optimistic locking)'),
      }),
    },
    async ({ project, repo, pr_id, version }) => {
      const body: Record<string, unknown> = {};
      if (version !== undefined) body.version = version;
      await bitbucketRequest(
        state,
        'POST',
        `${state.apiBase}/projects/${encodeSegment(project)}/repos/${encodeSegment(repo)}/pull-requests/${encodeSegment(pr_id)}/decline`,
        body
      );
      return {
        content: [
          {
            type: 'text' as const,
            text: JSON.stringify({ status: 'declined', pr_id }, null, 2),
          },
        ],
      };
    }
  );
}
