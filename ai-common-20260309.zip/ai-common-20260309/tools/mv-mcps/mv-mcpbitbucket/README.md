# mv-mcpbitbucket

MCP server for Bitbucket — repositories, pull requests, branches, and builds.

## What It Does

Provides an MCP (Model Context Protocol) server that exposes Bitbucket Server/Data Center tools for use with AI assistants like GitHub Copilot, Claude Code, and other MCP-compatible clients.

### Available Tools

- **Session management**: `start_session`, `reset_session`, `authenticate`
- **Repository operations**: `get_repos`, `get_repo`, `get_branches`, `get_tags`, `get_default_branch`
- **Pull request operations**: `search_pull_requests`, `get_pull_request`, `get_pull_request_diff`, `get_pull_request_activities`, `create_pull_request`, `update_pull_request`, `merge_pull_request`
- **PR review & comments**: `get_pull_request_comments`, `add_pull_request_comment`, `approve_pull_request`, `decline_pull_request`
- **Commit & file operations**: `get_commits`, `get_commit`, `get_file_content`
- **Build status**: `get_build_status`, `set_build_status`
- **Project & user**: `get_projects`

## Prerequisites

- **Node.js** (v18 or higher)
- **Bitbucket Server/Data Center** instance with API access

## Installation

No installation needed — run directly with `npx`:

```bash
npx @mesh-tenant-multiverse-ui-common/mv-mcpbitbucket
```

## Configuration

Create a config file at `~/.bitbucket_mcp.local.yaml`:

```yaml
bitbucket:
  host: "https://bitbucket.example.com"
  verify_ssl: true
```

Or use environment variables:
- `BITBUCKET_HOST` — Bitbucket host URL
- `BITBUCKET_TOKEN` — HTTP access token (recommended)
- `BITBUCKET_BEARER_TOKEN` — Bearer token

## VS Code MCP Configuration

Add to your VS Code `settings.json`:

```json
{
  "mcp": {
    "servers": {
      "bitbucket": {
        "command": "npx",
        "args": ["@mesh-tenant-multiverse-ui-common/mv-mcpbitbucket"]
      }
    }
  }
}
```

## Command Options

```
npx @mesh-tenant-multiverse-ui-common/mv-mcpbitbucket [options]

Options:
  --verbose, -v   Enable verbose logging to stderr
  --help, -h      Show help message
```
