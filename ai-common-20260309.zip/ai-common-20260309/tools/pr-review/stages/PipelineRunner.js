/**
 * PipelineRunner - Orchestrates the PR review pipeline
 * Dependency Inversion: Depends on abstractions (stage interface)
 * Open/Closed: New stages can be added via configuration
 */

const ConfigLoader = require('./ConfigLoader');
const DiffProvider = require('./DiffProvider');
const PipelineStage = require('./PipelineStage');
const PurposeStage = require('./PurposeStage');
const ReportFormatter = require('./ReportFormatter');
const CacheManager = require('./CacheManager');
const InputTransformationPipeline = require('../transformations/InputTransformationPipeline');
const DiffContextBuilder = require('../transformations/DiffContextBuilder');
const functionBoundaryExpansion = require('../transformations/functionBoundaryExpansion');
const importStatementInjection = require('../transformations/importStatementInjection');
const classOrComponentHeaderInclusion = require('../transformations/classOrComponentHeaderInclusion');

class PipelineRunner {
  constructor(basePath, options = {}) {
    this.basePath = basePath;
    this.options = options;
    this.modelTier = options.modelTier || 'default';
    this.verbose = options.verbose || false;
    this.useCache = options.cache !== false; // Cache enabled by default
    this.configLoader = new ConfigLoader(basePath);
    this.diffProvider = null;
    this.cacheManager = null;
    this.formatter = null;
    this.stages = [];
    this.config = null;
  }

  /**
   * Log message if verbose mode is enabled
   */
  log(message, data = null) {
    if (this.verbose) {
      const timestamp = new Date().toISOString().split('T')[1].slice(0, 12);
      console.log(`[${timestamp}] ${message}`);
      if (data !== null) {
        if (typeof data === 'string') {
          console.log(`             ${data.substring(0, 200)}${data.length > 200 ? '...' : ''}`);
        } else {
          console.log(`             ${JSON.stringify(data, null, 2).substring(0, 200)}`);
        }
      }
    }
  }

  /**
   * Output message always (for user-facing progress info)
   */
  info(message) {
    console.log(message);
  }

  /**
   * Initialize the pipeline
   */
  initialize() {
    this.info('\n🤖 Starting Agentic PR Review Pipeline...\n');
    this.log('Initializing pipeline...');
    
    // Load configuration
    this.log('Loading configuration from config.json and .ai_flags');
    this.config = this.configLoader.getConfig();
    this.log('AI Flags:', this.config.aiFlags);

    // Initialize DiffProvider with Bitbucket config from loaded settings
    const bitbucketConfig = this.config.pipeline.bitbucket || {};
    this.diffProvider = new DiffProvider({
      bitbucketToken: bitbucketConfig.token,
      bitbucketBaseUrl: bitbucketConfig.baseUrl || undefined,
    });
    
    // Get selected model configuration
    const modelConfig = this.getModelConfig();
    this.log('Model config:', modelConfig);
    this.info(`📋 Using AI Model: ${modelConfig.name}`);
    
    // Initialize cache manager
    if (this.useCache) {
      const cacheConfig = this.config.pipeline.cache || {};
      this.cacheManager = new CacheManager(this.basePath, {
        verbose: this.verbose,
        enabled: true,
        ttlHours: cacheConfig.ttlHours || 24,
      });
      this.cacheManager.pruneExpired();
      const stats = this.cacheManager.getStats();
      this.log(`Cache: ${stats.totalEntries} entries, TTL: ${cacheConfig.ttlHours || 24}h`);
      this.info(`💾 Cache: ${stats.totalEntries} cached reviews available`);
    } else {
      this.log('Cache disabled');
      this.info('💾 Cache: Disabled');
    }
    
    // Initialize formatter with output options
    this.formatter = new ReportFormatter(this.config.pipeline.output || {});

    // Create stage instances with model config and cache
    this.log(`Creating ${this.config.pipeline.stages.length} pipeline stages`);
    const enabledStages = this.config.pipeline.stages.filter(s => s.enabled);
    this.info(`📊 Pipeline stages: ${enabledStages.length} enabled\n`);
    
    this.stages = this.config.pipeline.stages.map(stageConfig => {
      this.log(`  - Stage: ${stageConfig.id} (enabled: ${stageConfig.enabled})`);
      const StageClass = stageConfig.id === '0_purpose' ? PurposeStage : PipelineStage;
      return new StageClass(stageConfig, this.basePath, { 
        modelConfig,
        verbose: this.verbose,
        cacheManager: this.cacheManager,
      });
    });

    this.log('Pipeline initialized');
    return this;
  }

  /**
   * Get model configuration based on tier selection
   */
  getModelConfig() {
    const aiConfig = this.config.pipeline.ai || {};
    const models = aiConfig.models || {};
    const tier = this.modelTier;
    
    if (models[tier]) {
      return {
        ...models[tier],
        command: aiConfig.command || 'copilot',
      };
    }
    
    // Fallback to default
    return {
      name: 'default',
      flag: '',
      command: aiConfig.command || 'copilot',
    };
  }

  /**
   * Check if pipeline should run
   */
  shouldRun() {
    const { aiFlags } = this.config;
    
    // Check if any PR review flags are enabled
    if (!aiFlags.ai_pr_approvals && !aiFlags.ai_pr_comments) {
      return {
        run: false,
        reason: 'PR review is disabled in .ai_flags (ai_pr_approvals and ai_pr_comments are false)',
      };
    }

    // Check if on base branch
    const currentBranch = this.diffProvider.getCurrentBranch();
    const baseBranch = this.diffProvider.baseBranch;
    
    if (currentBranch === baseBranch) {
      return {
        run: false,
        reason: `On base branch (${baseBranch}), skipping PR review`,
      };
    }

    // Check if there are any enabled stages
    const enabledStages = this.stages.filter(s => s.enabled);
    if (enabledStages.length === 0) {
      return {
        run: false,
        reason: 'No stages enabled in configuration',
      };
    }

    return { run: true };
  }

  /**
   * Execute all pipeline stages
   */
  async execute() {
    const results = [];
    const metadata = this.getMetadata();

    this.log('Checking if pipeline should run...');
    
    // Check if we should run
    const runCheck = this.shouldRun();
    if (!runCheck.run) {
      this.log(`Pipeline will not run: ${runCheck.reason}`);
      console.log(runCheck.reason);
      return { results: [], metadata, skipped: true, reason: runCheck.reason };
    }

    this.log('Getting git diff...');
    this.log(`Base branch: ${this.diffProvider.baseBranch}`);
    this.info(`🔍 Analyzing changes (base: ${this.diffProvider.baseBranch})\n`);
    
    // Get full diff for reference
    const fullDiff = this.diffProvider.getFullDiff();
    
    if (!fullDiff || fullDiff.trim().length === 0) {
      this.log('No diff content found');
      console.log('No changes detected, skipping review');
      return { results: [], metadata, skipped: true, reason: 'No changes detected' };
    }

    this.log(`Diff size: ${fullDiff.length} characters`);
    const changedFiles = this.diffProvider.getChangedFiles();
    this.info(`📁 Files changed: ${changedFiles.length}\n`);


    // Execute each stage
    let stageNum = 0;
    const enabledStages = this.stages.filter(s => s.enabled);
    
    for (const stage of this.stages) {
      if (!stage.enabled) continue;
      
      stageNum++;
      this.info(`[${stageNum}/${enabledStages.length} - ${stage.name}] Running stage...`);
      this.log(`\n>>> Starting stage: ${stage.name} (${stage.id})`);
      
      try {
        // Get diff filtered by stage's file patterns
        this.log(`  File patterns: ${stage.filePatterns.join(', ')}`);
        const diffResult = this.diffProvider.getDiffForPatterns(stage.filePatterns);
        const stageDiff = diffResult.diff;
        const stageFiles = diffResult.files;
        this.log(`  Stage diff size: ${stageDiff ? stageDiff.length : 0} characters`);
        this.log(`  Matching files: ${stageFiles.length}`);
        
        // Apply input transformations to the stage diff
        const transformedDiff = this.applyInputTransformations(stageDiff);
        this.log(`  Transformed diff size: ${transformedDiff ? transformedDiff.length : 0} characters`);
        
        // Compute cumulative file content hash for cache invalidation
        const fileContentHash = this.diffProvider.getFileContentHash(stageFiles);
        this.log(`  File content hash: ${fileContentHash || '(empty)'}`);

        // Execute stage with file list and content hash for cache invalidation
        this.log(`  Executing stage...`);
        const result = await stage.execute(transformedDiff, stageFiles, fileContentHash);
        this.log(`  Stage complete: success=${result.success}, duration=${result.duration}ms`);
        
        // Show completion status
        const statusIcon = result.success ? '✅' : '❌';
        const cachedText = result.cached ? ' (Cached)' : '';
        const statusMsg = result.skipped ? '⏭️  Skipped' : (result.success ? `Complete${cachedText}` : 'Failed');
        this.info(`[${stageNum}/${enabledStages.length} - ${stage.name}] ${statusIcon} ${statusMsg} (${(result.duration / 1000).toFixed(1)}s)\n`);
        
        results.push(result);

        // Check if we should continue after failure
        if (!result.success && !this.config.pipeline.pipeline.continueOnStageFailure) {
          this.log(`  Stage failed and continueOnStageFailure=false, stopping pipeline`);
          this.info('⚠️  Pipeline stopped due to stage failure\n');
          break;
        }
      } catch (error) {
        this.log(`  Stage threw error: ${error.message}`);
        this.info(`[${stageNum}/${enabledStages.length} - ${stage.name}] ❌ Error: ${error.message}\n`);
        
        results.push({
          stageId: stage.id,
          stageName: stage.name,
          success: false,
          error: error.message,
          output: '',
          duration: 0,
          skipped: false,
        });

        if (!this.config.pipeline.pipeline.continueOnStageFailure) {
          this.info('⚠️  Pipeline stopped due to stage error\n');
          break;
        }
      }
    }

    this.log(`\nPipeline execution complete. ${results.length} stages processed.`);
    this.info('✨ Pipeline execution complete\n');

    // Read purpose text saved by the PurposeStage
    const purposeText = PurposeStage.readPurposeText(this.basePath);
    return { results, metadata, skipped: false, purposeText };
  }

  /**
   * Run the full pipeline and output report
   */
  async run() {
    const result = await this.runWithOutput();
    return result.exitCode;
  }

  /**
   * Run the full pipeline, output report, and return results for further processing
   */
  async runWithOutput() {
    try {
      this.initialize();

      const { results, metadata, skipped, reason, purposeText } = await this.execute();

      if (skipped) {
        console.log(`\nPipeline skipped: ${reason}\n`);
        return { 
          exitCode: 0, 
          reportOutput: null, 
          config: this.config,
          currentBranch: this.diffProvider.getCurrentBranch(),
        };
      }

      // Format and output the report
      const report = this.formatter.formatReport(results, metadata, purposeText);
      console.log(report);

      // Bitbucket integration
      await this.handleBitbucketIntegration(report, metadata, results, purposeText);

      // Return exit code based on results
      const hasFailures = results.some(r => !r.success && !r.skipped);
      
      const exitCode = (hasFailures && this.config.pipeline.pipeline.failOnError) ? 1 : 0;

      return {
        exitCode,
        reportOutput: report,
        config: this.config,
        currentBranch: this.diffProvider.getCurrentBranch(),
      };
    } catch (error) {
      const errorReport = this.formatter.formatError(error);
      console.error(errorReport);
      return { 
        exitCode: 1, 
        reportOutput: null, 
        config: this.config,
        currentBranch: null,
      };
    }
  }

  /**
   * Handle Bitbucket integration - prompt and post review
   */
  async handleBitbucketIntegration(report, metadata, results, purposeText) {
    // Check if Bitbucket was disabled via CLI flag
    if (this.options.noBitbucket) {
      this.log('Bitbucket integration disabled via --no-bitbucket flag');
      return;
    }

    const BitbucketClient = require('./BitbucketClient');
    const bitbucketConfig = this.config.pipeline.bitbucket || {};
    
    // Check if Bitbucket integration is enabled
    if (!bitbucketConfig.enabled) {
      this.log('Bitbucket integration disabled in config');
      return;
    }

    this.log('Bitbucket integration enabled, checking configuration...');
    
    // Initialize Bitbucket client
    const client = new BitbucketClient(bitbucketConfig, { verbose: this.verbose });
    
    // Check if token is available
    if (!client.hasToken()) {
      console.log(BitbucketClient.getTokenInstructions());
      return;
    }

    try {
      // Find PR for current branch
      const currentBranch = metadata.branch;
      this.info(`\n🔗 Looking for open PR for branch: ${currentBranch}...`);
      
      const pr = await client.findPRByBranch(currentBranch);
      
      if (!pr) {
        this.info(`ℹ️  No open PR found for branch ${currentBranch}\n`);
        return;
      }

      this.info(`📝 Found PR #${pr.id}: ${pr.title}`);
      
      // Prompt user if autoPrompt is enabled
      if (bitbucketConfig.autoPrompt !== false) {
        const readline = require('readline');
        const rl = readline.createInterface({
          input: process.stdin,
          output: process.stdout
        });

        const answer = await new Promise(resolve => {
          rl.question('\n❓ Post review to Bitbucket PR? (y/n): ', resolve);
        });
        rl.close();

        if (answer.toLowerCase() !== 'y' && answer.toLowerCase() !== 'yes') {
          this.info('⏭️  Skipped posting to Bitbucket\n');
          return;
        }
      }

      // If the full report exceeds Bitbucket's comment limit, re-render without LOW severity issues
      let finalReport = report;
      if (client.wouldExceedLimit(finalReport)) {
        this.info('📏 Review exceeds Bitbucket comment limit — omitting Low severity issues...');
        const filteredResults = results.map(r => {
          if (!r.parsed?.issues) return r;
          return {
            ...r,
            parsed: {
              ...r.parsed,
              issues: r.parsed.issues.filter(i => i.severity !== 'LOW'),
            },
          };
        });
        finalReport = this.formatter.formatReport(filteredResults, metadata, purposeText);
        finalReport += '\n\n⚠️ To reduce the size of this comment, Low severity issues have been omitted.';
      }

      // Post/update comment on PR
      this.info('📤 Posting review to Bitbucket...');
      const result = await client.upsertReviewComment(pr.id, finalReport);
      
      if (result.action === 'updated') {
        this.info(`✅ Updated existing review comment on PR #${pr.id}`);
      } else {
        this.info(`✅ Posted new review comment on PR #${pr.id}`);
      }
      
      this.info(`🔗 View PR: ${pr.url}\n`);
      
    } catch (error) {
      this.log(`Bitbucket error: ${error.message}`);
      console.error(`\n⚠️  Failed to post to Bitbucket: ${error.message}\n`);
    }
  }

  /**
   * Get metadata for the report
   */
  getMetadata() {
    const modelConfig = this.getModelConfig();
    const changedFiles = this.diffProvider.getChangedFiles();
    return {
      branch: this.diffProvider.getCurrentBranch(),
      baseBranch: this.diffProvider.baseBranch,
      filesChanged: changedFiles.length,
      files: changedFiles,
      timestamp: this.formatLocalTimestamp(new Date()),
      model: modelConfig.name,
      modelTier: this.modelTier,
    };
  }

  /**
   * Format timestamp in local timezone
   */
  formatLocalTimestamp(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    
    // Get timezone offset
    const offset = -date.getTimezoneOffset();
    const offsetHours = String(Math.floor(Math.abs(offset) / 60)).padStart(2, '0');
    const offsetMinutes = String(Math.abs(offset) % 60).padStart(2, '0');
    const offsetSign = offset >= 0 ? '+' : '-';
    
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds} ${offsetSign}${offsetHours}:${offsetMinutes}`;
  }

  /**
   * Create transformation pipeline from config
   */
  createTransformationPipeline() {
    const transformationConfigs = this.config?.pipeline?.inputTransformations || this.config?.inputTransformations || [];
    
    if (transformationConfigs.length === 0) {
      return null;
    }

    const transformationMap = {
      function_boundary_expansion: functionBoundaryExpansion,
      import_statement_injection: importStatementInjection,
      class_or_component_header_inclusion: classOrComponentHeaderInclusion,
    };

    const transformations = transformationConfigs
      .filter((cfg) => cfg.enabled !== false)
      .map((cfg) => {
        const transformModule = transformationMap[cfg.id];
        if (!transformModule) {
          this.log(`Unknown transformation: ${cfg.id}`);
          return null;
        }

        return {
          id: cfg.id,
          enabled: cfg.enabled !== false,
          transform: (ctx) => transformModule.transform(ctx, cfg.config || {}),
        };
      })
      .filter((t) => t !== null);

    return new InputTransformationPipeline(transformations);
  }

  /**
   * Apply input transformations to diff text
   */
  applyInputTransformations(diffText) {
    if (!diffText || diffText.trim().length === 0) {
      return diffText;
    }

    const pipeline = this.createTransformationPipeline();
    
    if (!pipeline) {
      return diffText;
    }

    try {
      this.log(
        `Applying ${pipeline.transformations.length} input transformation(s)...`,
        pipeline.transformations.map((t) => t.id)
      );

      // Build diff context
      this.log('Building diff context...');
      const ctx = DiffContextBuilder.buildDiffContext({
        rawDiffText: diffText,
        mergeBase: this.diffProvider.getMergeBase(),
        head: 'HEAD',
      });

      // Run pipeline
      const transformedCtx = pipeline.run(ctx);
      this.log(`Appended context blocks: ${transformedCtx.appendedContextBlocks.length}`);

      // Return final diff with appended context
      return pipeline.getFinalDiffText(transformedCtx);
    } catch (error) {
      this.log(`Input transformation failed: ${error.message}`);
      // Degrade gracefully - return original diff
      return diffText;
    }
  }
}

module.exports = PipelineRunner;
