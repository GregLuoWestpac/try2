/**
 * ReportFormatter - Single Responsibility: Format pipeline output
 * Handles all output formatting for the review report
 */

class ReportFormatter {
  constructor(options = {}) {
    this.showTimings = options.showTimings !== false;
    this.showSummary = options.showSummary !== false;
    this.lineWidth = 70;
  }

  /**
   * Format the complete pipeline report
   */
  formatReport(results, metadata = {}, purposeText = '') {
    const lines = [];

    // Header with executive summary
    lines.push(this.formatHeader(metadata, results, purposeText));
    lines.push('');

    // Stage results (skip the purpose stage from detailed results)
    for (const result of results) {
      if (result.stageId === '0_purpose') continue;
      lines.push(this.formatStageResult(result));
      lines.push('');
    }

    // Issues summary across all stages
    lines.push(this.formatIssuesSummary(results));
    lines.push('');

    // Summary
    if (this.showSummary) {
      lines.push(this.formatSummary(results, metadata));
    }

    return lines.join('\n');
  }

  /**
   * Format report header with executive summary
   */
  formatHeader(metadata, results = [], purposeText = '') {
    const lines = [];
    lines.push(this.divider('='));
    lines.push(this.center('PR REVIEW PIPELINE REPORT'));
    lines.push(this.divider('='));
    lines.push('');
    
    if (metadata.branch) {
      lines.push(`Branch:      ${metadata.branch}`);
    }
    if (metadata.baseBranch) {
      lines.push(`Base:        ${metadata.baseBranch}`);
    }
    if (metadata.filesChanged !== undefined) {
      lines.push(`Files:       ${metadata.filesChanged} changed`);
    }
    if (metadata.model) {
      lines.push(`Model:       ${metadata.model} (${metadata.modelTier})`);
    }
    if (metadata.timestamp) {
      lines.push(`Timestamp:   ${metadata.timestamp}`);
    }

    // List changed files (truncate if too many to keep report under Bitbucket's 32K limit)
    if (metadata.files && metadata.files.length > 0) {
      const MAX_FILES_LISTED = 30;
      const filesToShow = metadata.files.filter(f => !f.includes('node_modules/'));
      lines.push('');
      lines.push('Changed Files:');
      const displayFiles = filesToShow.slice(0, MAX_FILES_LISTED);
      for (const file of displayFiles) {
        lines.push(`  • ${file}`);
      }
      const hidden = metadata.files.length - displayFiles.length;
      if (hidden > 0) {
        lines.push(`  … and ${hidden} more files (${metadata.files.length - filesToShow.length} node_modules files hidden)`);
      }
    }

    // High-level executive summary
    const executiveSummary = this.formatExecutiveSummary(results, purposeText);
    if (executiveSummary) {
      lines.push('');
      lines.push(executiveSummary);
    }

    return lines.join('\n');
  }

  /**
   * Format executive summary with purpose of change and high priority issues
   */
  formatExecutiveSummary(results, purposeText = '') {
    if ((!results || results.length === 0) && !purposeText) {
      return '';
    }

    // Collect all HIGH severity issues across all stages
    const highIssues = [];
    for (const result of results) {
      if (result.parsed?.issues) {
        for (const issue of result.parsed.issues) {
          if (issue.severity === 'HIGH') {
            highIssues.push({ ...issue, stage: result.stageName });
          }
        }
      }
    }

    const lines = [];
    lines.push(this.divider('-'));
    lines.push(this.center('EXECUTIVE SUMMARY'));
    lines.push(this.divider('-'));

    // Purpose of Change section
    if (purposeText) {
      lines.push('');
      lines.push('Purpose of Change:');
      lines.push(`   ${purposeText}`);
      lines.push('');
    }

    if (highIssues.length === 0) {
      lines.push('');
      lines.push('✅ No high-priority issues identified.');
      lines.push('');
    } else {
      lines.push('');
      lines.push(`⚠️  ${highIssues.length} HIGH PRIORITY ISSUE${highIssues.length > 1 ? 'S' : ''} REQUIRE ATTENTION:`);
      lines.push('');
      
      for (let i = 0; i < highIssues.length; i++) {
        const issue = highIssues[i];
        lines.push(`${i + 1}. [${issue.stage}] ${issue.category || 'Issue'}`);
        if (issue.file) {
          lines.push(`   File: ${issue.file}${issue.line ? `:${issue.line}` : ''}`);
        }
        lines.push(this.wrapText(`Issue: ${issue.issue}`, '   '));
        lines.push(this.wrapText(`Fix: ${issue.suggestion}`, '   '));
        lines.push('');
      }
    }

    return lines.join('\n');
  }

  /**
   * Format a single stage result using parsed JSON
   */
  formatStageResult(result) {
    const lines = [];
    
    // Stage header
    const status = this.getStatusIcon(result);
    const cached = result.cached ? ' [CACHED]' : '';
    const timing = this.showTimings ? ` (${result.duration}ms)` : '';
    
    lines.push(this.divider('-'));
    lines.push(`${status} ${result.stageName}${cached}${timing}`);
    lines.push(this.divider('-'));

    if (result.skipped) {
      lines.push(`   Skipped: ${result.parsed?.summary || result.output}`);
      return lines.join('\n');
    }
    
    if (result.error) {
      lines.push(`   ERROR: ${result.error}`);
      return lines.join('\n');
    }

    // Use parsed JSON if available
    const parsed = result.parsed;
    if (parsed && (parsed.issues?.length > 0 || parsed.observations?.length > 0)) {
      // Show issues
      if (parsed.issues && parsed.issues.length > 0) {
        for (const issue of parsed.issues) {
          lines.push('');
          lines.push(`   ${this.getSeverityIcon(issue.severity)} [${issue.severity}] ${issue.category || 'issue'}`);
          if (issue.file) {
            lines.push(`      File: ${issue.file}${issue.line ? `:${issue.line}` : ''}`);
          }
          lines.push(this.wrapText(`Issue: ${issue.issue}`, '      '));
          lines.push(this.wrapText(`Fix: ${issue.suggestion}`, '      '));
          if (issue.reference) {
            lines.push(this.wrapText(`Ref: ${issue.reference}`, '      '));
          }
          if (issue.wcag) {
            lines.push(`      WCAG: ${issue.wcag}`);
          }
        }
      }

      // Show observations
      if (parsed.observations && parsed.observations.length > 0) {
        lines.push('');
        lines.push('   Observations:');
        for (const obs of parsed.observations) {
          const icon = obs.type === 'positive' ? '✓' : obs.type === 'suggestion' ? '💡' : '•';
          lines.push(this.wrapText(`${icon} ${obs.description}`, '   '));
        }
      }

      // Show summary
      if (parsed.summary) {
        lines.push('');
        lines.push(`   Summary: ${parsed.summary}`);
      }
    } else if (parsed?.summary) {
      // No issues, just summary
      lines.push(`   ${parsed.passed ? '✓' : '✗'} ${parsed.summary}`);
    } else if (parsed?.rawOutput) {
      // Fallback to raw output if JSON parsing failed
      const indentedOutput = parsed.rawOutput
        .substring(0, 500)
        .split('\n')
        .map(line => `   ${line}`)
        .join('\n');
      lines.push(indentedOutput);
    } else {
      // Final fallback
      lines.push(`   ✓ Review complete`);
    }

    return lines.join('\n');
  }

  /**
   * Format issues summary across all stages
   */
  formatIssuesSummary(results) {
    const lines = [];
    
    // Collect all issues
    const allIssues = [];
    for (const result of results) {
      if (result.parsed?.issues) {
        for (const issue of result.parsed.issues) {
          allIssues.push({ ...issue, stage: result.stageName });
        }
      }
    }

    if (allIssues.length === 0) {
      return '';
    }

    lines.push(this.divider('='));
    lines.push(this.center('ALL ISSUES'));
    lines.push(this.divider('='));

    // Group by severity
    const high = allIssues.filter(i => i.severity === 'HIGH');
    const medium = allIssues.filter(i => i.severity === 'MEDIUM');
    const low = allIssues.filter(i => i.severity === 'LOW');

    lines.push('');
    lines.push(`   🔴 HIGH:   ${high.length}`);
    lines.push(`   🟡 MEDIUM: ${medium.length}`);
    lines.push(`   🟢 LOW:    ${low.length}`);

    // List high severity issues with full details
    if (high.length > 0) {
      lines.push('');
      lines.push('   High Severity Issues:');
      for (let i = 0; i < high.length; i++) {
        const issue = high[i];
        lines.push('');
        lines.push(`   ${i + 1}. 🔴 [${issue.stage}] ${issue.category || 'Issue'}`);
        if (issue.file) {
          lines.push(`      File: ${issue.file}${issue.line ? `:${issue.line}` : ''}`);
        }
        lines.push(this.wrapText(`Issue: ${issue.issue}`, '      '));
        if (issue.suggestion) {
          lines.push(this.wrapText(`Fix: ${issue.suggestion}`, '      '));
        }
      }
    }

    // List medium severity issues
    if (medium.length > 0) {
      lines.push('');
      lines.push('   Medium Severity Issues:');
      for (let i = 0; i < medium.length; i++) {
        const issue = medium[i];
        lines.push('');
        lines.push(`   ${i + 1}. 🟡 [${issue.stage}] ${issue.category || 'Issue'}`);
        if (issue.file) {
          lines.push(`      File: ${issue.file}${issue.line ? `:${issue.line}` : ''}`);
        }
        lines.push(this.wrapText(`Issue: ${issue.issue}`, '      '));
        if (issue.suggestion) {
          lines.push(this.wrapText(`Fix: ${issue.suggestion}`, '      '));
        }
      }
    }

    return lines.join('\n');
  }

  /**
   * Format summary section
   */
  formatSummary(results, metadata) {
    const lines = [];
    
    const passed = results.filter(r => r.success && !r.skipped).length;
    const skipped = results.filter(r => r.skipped).length;
    const failed = results.filter(r => !r.success).length;
    const cached = results.filter(r => r.cached).length;
    const totalTime = results.reduce((sum, r) => sum + (r.duration || 0), 0);

    // Count issues across all stages
    let totalIssues = 0;
    let highIssues = 0;
    let reviewPassed = true;
    
    for (const result of results) {
      if (result.parsed?.issues) {
        totalIssues += result.parsed.issues.length;
        highIssues += result.parsed.issues.filter(i => i.severity === 'HIGH').length;
      }
      if (result.parsed?.passed === false) {
        reviewPassed = false;
      }
    }

    lines.push(this.divider('='));
    lines.push(this.center('SUMMARY'));
    lines.push(this.divider('='));
    lines.push('');
    lines.push(`   Stages Run:     ${passed}`);
    lines.push(`   Stages Cached:  ${cached}`);
    lines.push(`   Stages Skipped: ${skipped}`);
    lines.push(`   Stages Failed:  ${failed}`);
    lines.push('');
    lines.push(`   Total Issues:   ${totalIssues}`);
    lines.push(`   High Severity:  ${highIssues}`);
    
    if (this.showTimings) {
      lines.push(`   Total Time:     ${totalTime}ms`);
    }
    
    lines.push('');

    if (failed > 0) {
      lines.push(`   Status: ❌ PIPELINE FAILED`);
    } else if (highIssues > 0) {
      lines.push(`   Status: ⚠️  REVIEW COMPLETE - ${highIssues} HIGH SEVERITY ISSUES`);
    } else if (totalIssues > 0) {
      lines.push(`   Status: ✅ REVIEW COMPLETE - ${totalIssues} issues to address`);
    } else {
      lines.push(`   Status: ✅ REVIEW PASSED - No issues found`);
    }

    lines.push('');
    lines.push(this.divider('='));

    return lines.join('\n');
  }

  /**
   * Get status icon for a result
   */
  getStatusIcon(result) {
    if (result.skipped) return '⏭️ ';
    if (!result.success) return '❌';
    if (result.parsed?.passed === false) return '⚠️ ';
    return '✅';
  }

  /**
   * Get severity icon
   */
  getSeverityIcon(severity) {
    switch (severity) {
      case 'HIGH': return '🔴';
      case 'MEDIUM': return '🟡';
      case 'LOW': return '🟢';
      default: return '•';
    }
  }

  /**
   * Word-wrap text to fit within maxWidth, preserving an indent prefix on continuation lines.
   */
  wrapText(text, indent = '      ', maxWidth = 0) {
    const width = maxWidth || this.lineWidth;
    if (!text || (indent.length + text.length) <= width) {
      return indent + text;
    }

    const words = text.split(/\s+/);
    const lines = [];
    let currentLine = indent;

    for (const word of words) {
      if (currentLine === indent) {
        // First word on the line — always add it
        currentLine += word;
      } else if ((currentLine.length + 1 + word.length) <= width) {
        currentLine += ' ' + word;
      } else {
        lines.push(currentLine);
        currentLine = indent + word;
      }
    }

    if (currentLine.length > indent.length) {
      lines.push(currentLine);
    }

    return lines.join('\n');
  }

  /**
   * Create a divider line
   */
  divider(char = '-') {
    return char.repeat(this.lineWidth);
  }

  /**
   * Center text within line width
   */
  center(text) {
    const padding = Math.max(0, Math.floor((this.lineWidth - text.length) / 2));
    return ' '.repeat(padding) + text;
  }

  /**
   * Format pipeline results as structured JSON for machine consumption.
   * Used by --output json and the code-review workflow skill.
   */
  formatJSON(results, metadata, skipped = false, reason = null, purposeText = '') {
    if (skipped) {
      return {
        status: 'skipped',
        reason: reason || 'Pipeline did not run',
        model: metadata.model || null,
        modelTier: metadata.modelTier || null,
        branch: metadata.branch || null,
        baseBranch: metadata.baseBranch || null,
        filesChanged: metadata.filesChanged || 0,
        files: metadata.files || [],
        timestamp: metadata.timestamp || null,
        stages: [],
        summary: { errors: 0, warnings: 0, info: 0, passed: 0, failed: 0, skipped: 0, cached: 0, totalDuration: 0 },
      };
    }

    let totalHigh = 0;
    let totalMedium = 0;
    let totalLow = 0;

    const stages = results.map(r => {
      const issues = (r.parsed?.issues || []).map(issue => ({
        severity: (issue.severity || 'LOW').toLowerCase(),
        category: issue.category || null,
        file: issue.file || null,
        line: issue.line || null,
        issue: issue.issue || issue.description || '',
        suggestion: issue.suggestion || null,
        reference: issue.reference || null,
      }));

      for (const issue of issues) {
        if (issue.severity === 'high') totalHigh++;
        else if (issue.severity === 'medium') totalMedium++;
        else totalLow++;
      }

      const observations = (r.parsed?.observations || []).map(obs => ({
        type: obs.type || 'info',
        description: obs.description || '',
      }));

      let status = 'completed';
      if (r.skipped) status = 'skipped';
      else if (r.cached) status = 'cached';
      else if (!r.success) status = 'failed';

      return {
        id: r.stageId,
        name: r.stageName,
        status,
        duration: r.duration || 0,
        passed: r.parsed?.passed !== false,
        issues,
        observations,
        summary: r.parsed?.summary || null,
        error: r.error || null,
      };
    });

    const passed = results.filter(r => r.success && !r.skipped).length;
    const failed = results.filter(r => !r.success).length;
    const skippedCount = results.filter(r => r.skipped).length;
    const cached = results.filter(r => r.cached).length;
    const hasHighIssues = totalHigh > 0;

    return {
      status: failed > 0 ? 'failed' : (hasHighIssues ? 'warning' : 'passed'),
      purposeOfChange: purposeText || null,
      model: metadata.model || null,
      modelTier: metadata.modelTier || null,
      branch: metadata.branch || null,
      baseBranch: metadata.baseBranch || null,
      filesChanged: metadata.filesChanged || 0,
      files: metadata.files || [],
      timestamp: metadata.timestamp || null,
      stages,
      summary: {
        errors: totalHigh,
        warnings: totalMedium,
        info: totalLow,
        passed,
        failed,
        skipped: skippedCount,
        cached,
        totalDuration: results.reduce((sum, r) => sum + (r.duration || 0), 0),
      },
    };
  }

  /**
   * Format error report for stderr
   */
  formatError(error, context = {}) {
    const lines = [];
    lines.push(this.divider('!'));
    lines.push('PIPELINE ERROR');
    lines.push(this.divider('!'));
    lines.push('');
    lines.push(`Error: ${error.message}`);
    
    if (context.stage) {
      lines.push(`Stage: ${context.stage}`);
    }
    
    if (error.stack && process.env.DEBUG) {
      lines.push('');
      lines.push('Stack trace:');
      lines.push(error.stack);
    }

    lines.push('');
    lines.push(this.divider('!'));

    return lines.join('\n');
  }
}

module.exports = ReportFormatter;
