/**
 * DiffProvider - Single Responsibility: Provide git diff information
 * Handles all git operations for retrieving change information
 */

const { execSync } = require('child_process');

class DiffProvider {
  constructor(options = {}) {
    this.encoding = 'utf8';
    this.options = options;
    this.baseBranch =
      options.baseBranch ||
      process.env.PR_BASE_BRANCH ||
      this.detectDefaultBranch();

    // Guard: prevent comparing a branch against itself
    const currentBranch = this.getCurrentBranch();
    const normalised = this.baseBranch.replace(/^origin\//, '');
    if (currentBranch === normalised) {
      throw new Error(
        `Base branch "${this.baseBranch}" is the same as the current branch "${currentBranch}". ` +
          `Specify a different base branch with --base (e.g. --base master).`
      );
    }

    // Ensure we compare against the latest remote version of the base branch
    this.baseBranch = this.resolveRemoteBase(this.baseBranch);
  }

  /**
   * Fetch the base branch from origin and return the remote ref (origin/<branch>)
   * so diffs always compare against the up-to-date remote, not a stale local copy.
   * Falls back to the original ref if fetch fails or the ref is not a branch name.
   */
  resolveRemoteBase(baseBranch) {
    // Skip for relative refs (HEAD~N), SHAs, or refs already pointing to origin
    if (
      /^HEAD[~^]|^[0-9a-f]{7,40}$/i.test(baseBranch) ||
      baseBranch.startsWith('origin/')
    ) {
      return baseBranch;
    }

    try {
      execSync(`git fetch origin ${baseBranch}`, {
        encoding: this.encoding,
        stdio: ['pipe', 'pipe', 'pipe'],
      });
      // Verify the remote ref exists
      execSync(`git rev-parse --verify origin/${baseBranch}`, {
        encoding: this.encoding,
        stdio: ['pipe', 'pipe', 'pipe'],
      });
      return `origin/${baseBranch}`;
    } catch (e) {
      // Fetch failed (offline, no remote, etc.) — fall back to local ref
      return baseBranch;
    }
  }

  /**
   * Try to detect the base branch from an open Bitbucket PR for the current branch.
   * Uses curl via execSync to keep the constructor synchronous.
   * Returns the PR's target branch name, or null if unavailable.
   */
  detectBaseBranchFromBitbucket() {
    // Resolve token
    const token =
      this.options.bitbucketToken ||
      process.env.BITBUCKET_PAT ||
      process.env.BITBUCKET_TOKEN ||
      process.env.PR_REVIEW_BITBUCKET_TOKEN;

    if (!token) return null;

    // Detect project and repo from git remote
    let project, repo;
    try {
      const remoteUrl = execSync('git remote get-url origin', {
        encoding: this.encoding,
        timeout: 5000,
        stdio: ['pipe', 'pipe', 'pipe'],
      }).trim();

      if (!remoteUrl) return null;

      // HTTPS: https://host/scm/PROJECT/repo.git
      const httpsMatch = remoteUrl.match(
        /\/scm\/([^/]+)\/([^/.]+?)(?:\.git)?$/i
      );
      if (httpsMatch) {
        project = httpsMatch[1].toUpperCase();
        repo = httpsMatch[2];
      }
      // SSH: ssh://git@host:port/PROJECT/repo.git or git@host:PROJECT/repo.git
      if (!project) {
        const sshMatch = remoteUrl.match(/\/([^/]+)\/([^/.]+?)(?:\.git)?$/i);
        if (sshMatch) {
          project = sshMatch[1].toUpperCase();
          repo = sshMatch[2];
        }
      }
      if (!project) {
        const shortMatch = remoteUrl.match(/:([^/]+)\/([^/.]+?)(?:\.git)?$/i);
        if (shortMatch) {
          project = shortMatch[1].toUpperCase();
          repo = shortMatch[2];
        }
      }

      if (!project || !repo) return null;

      // Resolve base URL
      let baseUrl =
        this.options.bitbucketBaseUrl || process.env.BITBUCKET_BASE_URL;

      if (!baseUrl) {
        // Derive from git remote hostname
        let hostname;
        const urlMatch = remoteUrl.match(/:\/\/[^@]*@?([^:/]+)/);
        if (urlMatch) {
          hostname = urlMatch[1];
        } else {
          const shortHostMatch = remoteUrl.match(/@([^:]+):/);
          if (shortHostMatch) hostname = shortHostMatch[1];
        }
        if (hostname) {
          baseUrl = `https://${hostname}`;
        }
      }

      if (!baseUrl) return null;

      // Get current branch
      const currentBranch = this.getCurrentBranch();
      if (!currentBranch || currentBranch === 'HEAD') return null;

      // Query Bitbucket API for open PRs
      const apiUrl = `${baseUrl}/rest/api/1.0/projects/${project}/repos/${repo}/pull-requests?state=OPEN&limit=100`;
      const curlCmd = `curl -s -k -H "Authorization: Bearer ${token}" "${apiUrl}"`;
      const response = execSync(curlCmd, {
        encoding: this.encoding,
        timeout: 10000,
        stdio: ['pipe', 'pipe', 'pipe'],
        shell: true,
      });

      const data = JSON.parse(response);
      if (!data || !data.values) return null;

      // Find PR where fromRef matches current branch
      const pr = data.values.find(
        pr => pr.fromRef && pr.fromRef.displayId === currentBranch
      );

      if (pr && pr.toRef && pr.toRef.displayId) {
        return pr.toRef.displayId;
      }
    } catch (e) {
      // Any failure — silently fall back to heuristic detection
    }

    return null;
  }

  /**
   * Auto-detect the default branch (main, master, develop, ERM feature branches, etc.)
   */
  detectDefaultBranch() {
    // Try Bitbucket PR base branch first
    const bitbucketBase = this.detectBaseBranchFromBitbucket();
    if (bitbucketBase) return bitbucketBase;
    const standardCandidates = ['main', 'master', 'develop', 'development'];
    const ermCandidates = [];

    // Detect ERM feature branches (format: feature/XXX-202X-ERM, e.g. feature/May-2026-ERM)
    try {
      const branchOutput = execSync('git branch -a', {
        encoding: this.encoding,
        stdio: ['pipe', 'pipe', 'pipe'],
      });
      const ermPattern = /feature\/\w+-202\d-ERM$/i;
      const branches = branchOutput
        .trim()
        .split('\n')
        .map(b => b.trim().replace(/^\* /, ''));
      const seen = new Set(standardCandidates);
      for (const branch of branches) {
        if (ermPattern.test(branch)) {
          const cleanBranch = branch.replace(/^remotes\/origin\//, '');
          if (!seen.has(cleanBranch)) {
            seen.add(cleanBranch);
            ermCandidates.push(cleanBranch);
          }
        }
      }
    } catch (e) {
      // Ignore – could not list branches
    }

    // If ERM branches exist, check if the current branch descends from one.
    // Prefer the ERM branch whose merge-base with HEAD is the most recent
    // (i.e. closest ancestor), since that's the true parent branch.
    if (ermCandidates.length > 0) {
      let bestErm = null;
      let bestTimestamp = -1;

      for (const erm of ermCandidates) {
        try {
          execSync(`git rev-parse --verify ${erm}`, {
            encoding: this.encoding,
            stdio: ['pipe', 'pipe', 'pipe'],
          });
          const mergeBase = execSync(`git merge-base ${erm} HEAD`, {
            encoding: this.encoding,
            stdio: ['pipe', 'pipe', 'pipe'],
          }).trim();
          const timestamp = parseInt(
            execSync(`git log -1 --format=%ct ${mergeBase}`, {
              encoding: this.encoding,
              stdio: ['pipe', 'pipe', 'pipe'],
            }).trim(),
            10
          );
          if (timestamp > bestTimestamp) {
            bestTimestamp = timestamp;
            bestErm = erm;
          }
        } catch (e) {
          // Branch doesn't exist locally or merge-base failed, skip
        }
      }

      if (bestErm) {
        return bestErm;
      }
    }

    const candidates = [...standardCandidates, ...ermCandidates];

    // Check remote origin HEAD branch
    let remoteDefaultBranch = null;
    try {
      const remote = execSync(
        'git remote show origin 2>/dev/null | grep "HEAD branch"',
        {
          encoding: this.encoding,
          stdio: ['pipe', 'pipe', 'pipe'],
          shell: true,
        }
      );
      const match = remote.match(/HEAD branch:\s*(\S+)/);
      if (match) remoteDefaultBranch = match[1];
    } catch (e) {
      // Ignore
    }

    // If remote HEAD branch matches a candidate, prefer it
    if (remoteDefaultBranch && candidates.includes(remoteDefaultBranch)) {
      return remoteDefaultBranch;
    }

    // Otherwise fall back to first locally-existing candidate
    for (const branch of candidates) {
      try {
        execSync(`git rev-parse --verify ${branch}`, {
          encoding: this.encoding,
          stdio: ['pipe', 'pipe', 'pipe'],
        });
        return branch;
      } catch (e) {
        // Branch doesn't exist, try next
      }
    }

    // Fallback: try to get from remote origin
    try {
      const remote = execSync(
        'git remote show origin 2>nul | findstr /C:"HEAD branch"',
        {
          encoding: this.encoding,
          stdio: ['pipe', 'pipe', 'pipe'],
          shell: true,
        }
      );
      const match = remote.match(/HEAD branch:\s*(\S+)/);
      if (match) return match[1];
    } catch (e) {
      // Ignore
    }

    // Ultimate fallback
    return 'HEAD~10';
  }

  /**
   * Get current branch name
   */
  getCurrentBranch() {
    try {
      return execSync('git rev-parse --abbrev-ref HEAD', {
        encoding: this.encoding,
      }).trim();
    } catch (error) {
      throw new Error(`Failed to get current branch: ${error.message}`);
    }
  }

  /**
   * Get merge base between current branch and base branch
   */
  getMergeBase() {
    try {
      return execSync(`git merge-base ${this.baseBranch} HEAD`, {
        encoding: this.encoding,
        stdio: ['pipe', 'pipe', 'pipe'],
      }).trim();
    } catch (error) {
      // Fallback to HEAD~1 if merge-base fails
      return 'HEAD~1';
    }
  }

  /**
   * Get list of changed files
   */
  getChangedFiles() {
    try {
      const mergeBase = this.getMergeBase();
      const output = execSync(
        `git diff --ignore-cr-at-eol --name-only ${mergeBase} HEAD`,
        {
          encoding: this.encoding,
          stdio: ['pipe', 'pipe', 'pipe'],
        }
      );
      return output.trim().split('\n').filter(Boolean);
    } catch (error) {
      return [];
    }
  }

  /**
   * Get diff content for specific file patterns
   * Returns object with diff and matching file list for cache invalidation
   */
  getDiffForPatterns(patterns = ['*']) {
    try {
      const mergeBase = this.getMergeBase();
      const changedFiles = this.getChangedFiles();

      // Filter files by patterns
      const matchingFiles = this.filterFilesByPatterns(changedFiles, patterns);

      if (matchingFiles.length === 0) {
        return { diff: null, files: [] };
      }

      // Get diff for matching files
      const filesArg = matchingFiles.map(f => `"${f}"`).join(' ');
      const diff = execSync(
        `git diff --ignore-cr-at-eol ${mergeBase} HEAD -- ${filesArg}`,
        {
          encoding: this.encoding,
          maxBuffer: 10 * 1024 * 1024,
          stdio: ['pipe', 'pipe', 'pipe'],
        }
      );

      return { diff, files: matchingFiles };
    } catch (error) {
      return { diff: null, files: [] };
    }
  }

  /**
   * Get full diff content
   */
  getFullDiff() {
    try {
      const mergeBase = this.getMergeBase();
      return execSync(`git diff --ignore-cr-at-eol ${mergeBase} HEAD`, {
        encoding: this.encoding,
        maxBuffer: 10 * 1024 * 1024,
        stdio: ['pipe', 'pipe', 'pipe'],
      });
    } catch (error) {
      // Fallback
      try {
        return execSync('git diff --ignore-cr-at-eol HEAD~1 HEAD', {
          encoding: this.encoding,
          stdio: ['pipe', 'pipe', 'pipe'],
        });
      } catch (e) {
        return '';
      }
    }
  }

  /**
   * Compute a cumulative hash of file contents at HEAD for cache invalidation.
   * Uses git blob SHAs which change whenever file content changes.
   */
  getFileContentHash(files) {
    if (!files || files.length === 0) {
      return '';
    }

    try {
      const crypto = require('crypto');
      const filesArg = files.map(f => `"${f}"`).join(' ');
      const output = execSync(`git ls-tree HEAD -- ${filesArg}`, {
        encoding: this.encoding,
        stdio: ['pipe', 'pipe', 'pipe'],
      });
      return crypto.createHash('sha256').update(output).digest('hex').substring(0, 16);
    } catch (e) {
      return '';
    }
  }

  /**
   * Get diff summary/stats
   */
  getDiffStats() {
    try {
      const mergeBase = this.getMergeBase();
      return execSync(`git diff --ignore-cr-at-eol --stat ${mergeBase} HEAD`, {
        encoding: this.encoding,
        stdio: ['pipe', 'pipe', 'pipe'],
      });
    } catch (error) {
      return '';
    }
  }

  /**
   * Filter files by glob-like patterns
   */
  filterFilesByPatterns(files, patterns) {
    if (patterns.includes('*')) {
      return files;
    }

    return files.filter(file => {
      return patterns.some(pattern => {
        // Simple pattern matching
        const regex = this.patternToRegex(pattern);
        return regex.test(file);
      });
    });
  }

  /**
   * Convert simple glob pattern to regex
   */
  patternToRegex(pattern) {
    const escaped = pattern
      .replace(/[.+^${}()|[\]\\]/g, '\\$&')
      .replace(/\*/g, '.*')
      .replace(/\?/g, '.');
    return new RegExp(escaped + '$', 'i');
  }
}

module.exports = DiffProvider;
