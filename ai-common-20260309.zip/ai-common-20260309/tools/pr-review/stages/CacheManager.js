/**
 * CacheManager - Handles caching of PR review responses
 * Single Responsibility: Store and retrieve cached review responses
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class CacheManager {
  constructor(basePath, options = {}) {
    this.cacheDir = path.join(basePath, '.cache');
    this.cacheFile = path.join(this.cacheDir, 'review_cache.json');
    this.verbose = options.verbose || false;
    this.enabled = options.enabled !== false;
    this.ttlHours = options.ttlHours || 24; // Cache expires after 24 hours by default
    
    this.cache = this.loadCache();
  }

  /**
   * Log message if verbose mode is enabled
   */
  log(message) {
    if (this.verbose) {
      const timestamp = new Date().toISOString().split('T')[1].slice(0, 12);
      console.log(`[${timestamp}] [Cache] ${message}`);
    }
  }

  /**
   * Ensure cache directory exists
   */
  ensureCacheDir() {
    if (!fs.existsSync(this.cacheDir)) {
      fs.mkdirSync(this.cacheDir, { recursive: true });
    }
  }

  /**
   * Load cache from file
   */
  loadCache() {
    try {
      if (fs.existsSync(this.cacheFile)) {
        const content = fs.readFileSync(this.cacheFile, 'utf8');
        const cache = JSON.parse(content);
        this.log(`Loaded cache with ${Object.keys(cache.entries || {}).length} entries`);
        return cache;
      }
    } catch (e) {
      this.log(`Failed to load cache: ${e.message}`);
    }
    
    return { version: 1, entries: {} };
  }

  /**
   * Save cache to file
   */
  saveCache() {
    try {
      this.ensureCacheDir();
      fs.writeFileSync(this.cacheFile, JSON.stringify(this.cache, null, 2), 'utf8');
      this.log('Cache saved');
    } catch (e) {
      this.log(`Failed to save cache: ${e.message}`);
    }
  }

  /**
   * Generate hash for prompt + diff content + file list
   * Including file list ensures cache invalidates when different files are reviewed
   */
  generateHash(prompt, diff, fileList = [], fileContentHash = '') {
    const files = Array.isArray(fileList) ? fileList.sort().join('\n') : '';
    const content = `${prompt}\n---FILES---\n${files}\n---CONTENT_HASH---\n${fileContentHash}\n---DIFF---\n${diff}`;
    return crypto.createHash('sha256').update(content).digest('hex').substring(0, 16);
  }

  /**
   * Check if a cached response exists and is valid
   */
  get(stageId, prompt, diff, fileList = [], fileContentHash = '') {
    if (!this.enabled) {
      return null;
    }

    const hash = this.generateHash(prompt, diff, fileList, fileContentHash);
    const key = `${stageId}:${hash}`;
    const entry = this.cache.entries[key];

    if (!entry) {
      this.log(`Cache MISS for ${stageId} (no entry)`);
      return null;
    }

    // Check TTL
    const age = Date.now() - entry.timestamp;
    const maxAge = this.ttlHours * 60 * 60 * 1000;
    
    if (age > maxAge) {
      this.log(`Cache MISS for ${stageId} (expired: ${Math.round(age / 3600000)}h old)`);
      delete this.cache.entries[key];
      return null;
    }

    this.log(`Cache HIT for ${stageId} (${Math.round(age / 60000)}min old, ${entry.fileCount || 0} files)`);
    return entry.response;
  }

  /**
   * Store a response in cache
   */
  set(stageId, prompt, diff, response, fileList = [], fileContentHash = '') {
    if (!this.enabled) {
      return;
    }

    const hash = this.generateHash(prompt, diff, fileList, fileContentHash);
    const key = `${stageId}:${hash}`;

    this.cache.entries[key] = {
      stageId,
      hash,
      timestamp: Date.now(),
      response,
      promptLength: prompt.length,
      diffLength: diff.length,
      fileCount: fileList.length,
      files: fileList.slice(0, 20), // Store first 20 files for debugging
    };

    this.log(`Cached response for ${stageId} (${fileList.length} files)`);
    this.saveCache();
  }

  /**
   * Clear all cached entries
   */
  clear() {
    this.cache.entries = {};
    this.saveCache();
    this.log('Cache cleared');
  }

  /**
   * Clear expired entries
   */
  pruneExpired() {
    const maxAge = this.ttlHours * 60 * 60 * 1000;
    const now = Date.now();
    let pruned = 0;

    for (const key of Object.keys(this.cache.entries)) {
      const entry = this.cache.entries[key];
      if (now - entry.timestamp > maxAge) {
        delete this.cache.entries[key];
        pruned++;
      }
    }

    if (pruned > 0) {
      this.log(`Pruned ${pruned} expired entries`);
      this.saveCache();
    }

    return pruned;
  }

  /**
   * Get cache statistics
   */
  getStats() {
    const entries = Object.values(this.cache.entries);
    const now = Date.now();
    
    return {
      totalEntries: entries.length,
      oldestEntry: entries.length > 0 
        ? Math.round((now - Math.min(...entries.map(e => e.timestamp))) / 3600000) 
        : 0,
      newestEntry: entries.length > 0
        ? Math.round((now - Math.max(...entries.map(e => e.timestamp))) / 60000)
        : 0,
      totalSize: entries.reduce((sum, e) => sum + (e.response?.length || 0), 0),
    };
  }
}

module.exports = CacheManager;
