/**
 * PurposeStage - Generates an executive summary describing the purpose of the change.
 * Runs as the first pipeline stage and saves its output to .temp/purpose.txt.
 */

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const PipelineStage = require('./PipelineStage');

class PurposeStage extends PipelineStage {
  constructor(config, basePath, options = {}) {
    super(config, basePath, options);
    this.outputFile = path.join(basePath, '.temp', 'purpose.txt');
  }

  /**
   * Execute the purpose stage — produces plain text, not JSON.
   */
  async execute(diffContent, fileList = [], fileContentHash = '') {
    const result = await super.execute(diffContent, fileList, fileContentHash);

    // Extract plain-text purpose from the AI response
    const purposeText = this.extractPurposeText(result);

    // Persist to disk so downstream stages/tools can read it back
    this.savePurposeText(purposeText);

    // Attach the purpose text to the result for in-memory consumers
    result.purposeText = purposeText;

    return result;
  }

  /**
   * Override invokeCopilot — the base class now pipes via stdin which works
   * for this stage too. Override only to skip the aggressive thinking filter
   * and preserve plain-text output.
   */
  async invokeCopilot(prompt) {
    const { command, flag } = this.modelConfig;
    const modelArg = flag || '';
    const cmdString = `${command} ${modelArg} -s --no-ask-user --deny-tool write --deny-tool edit --deny-tool create`;

    this.log(`Executing: ${cmdString} (prompt via stdin, ${prompt.length} chars)`);

    return new Promise((resolve, reject) => {
      let settled = false;
      const settle = (fn, value) => {
        if (!settled) { settled = true; fn(value); }
      };

      const proc = spawn(cmdString, [], {
        shell: true,
        windowsHide: true,
        stdio: ['pipe', 'pipe', 'pipe'],
        cwd: path.dirname(this.basePath),
      });

      let stdout = '';
      let stderr = '';

      proc.stdout.on('data', (data) => { stdout += data.toString(); });
      proc.stderr.on('data', (data) => { stderr += data.toString(); });

      proc.on('close', (code) => {
        clearTimeout(timeoutId);
        this.log(`Command completed with code ${code}, stdout: ${stdout.length} chars`);

        // Plain text — just trim, no aggressive thinking filter
        const output = (stdout || stderr || '').trim();

        if (code === 0 || output.length > 0) {
          settle(resolve, output);
        } else {
          this.log(`stderr: ${stderr.substring(0, 500)}`);
          settle(reject, new Error(`Copilot CLI failed with code ${code}: ${stderr.substring(0, 500)}`));
        }
      });

      proc.on('error', (err) => {
        clearTimeout(timeoutId);
        this.log(`Spawn error: ${err.message}`);
        settle(reject, new Error(`Copilot CLI not available: ${err.message}`));
      });

      const timeoutId = setTimeout(() => {
        this.log(`Command timed out after ${this.timeout}ms`);
        proc.kill();
        settle(reject, new Error(`Copilot CLI timed out after ${this.timeout}ms`));
      }, this.timeout);

      // Pipe the full prompt via stdin and close
      proc.stdin.write(prompt);
      proc.stdin.end();
    });
  }

  /**
   * Extract clean plain-text purpose from the stage result.
   * The prompt asks for plain text, but the base class tries JSON parsing.
   * We prefer rawOutput or the original output string.
   */
  extractPurposeText(result) {
    if (!result.success || result.skipped) {
      return '';
    }

    // If JSON parsing produced a rawOutput (plain text fallback), use that
    if (result.parsed?.rawOutput) {
      return result.parsed.rawOutput.trim();
    }

    // If parsed summary exists and there are no issues, the AI may have
    // wrapped its answer in the JSON schema — pull the summary
    if (result.parsed?.summary && result.parsed.summary !== 'Review complete' &&
        result.parsed.summary !== 'No output' &&
        result.parsed.summary !== 'Could not parse structured response') {
      return result.parsed.summary.trim();
    }

    // Last resort: use raw output, stripping any accidental JSON wrapper
    const raw = (result.output || '').trim();
    return raw;
  }

  /**
   * Save purpose text to .temp/purpose.txt
   */
  savePurposeText(text) {
    try {
      const dir = path.dirname(this.outputFile);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(this.outputFile, text, 'utf8');
      this.log(`Purpose text saved to ${this.outputFile}`);
    } catch (err) {
      this.log(`Failed to save purpose text: ${err.message}`);
    }
  }

  /**
   * Read previously saved purpose text (static helper for other stages)
   */
  static readPurposeText(basePath) {
    try {
      const filePath = path.join(basePath, '.temp', 'purpose.txt');
      if (fs.existsSync(filePath)) {
        return fs.readFileSync(filePath, 'utf8').trim();
      }
    } catch (err) {
      // Ignore read errors
    }
    return '';
  }
}

module.exports = PurposeStage;
