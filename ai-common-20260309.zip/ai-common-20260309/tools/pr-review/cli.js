#!/usr/bin/env node

/**
 * PR Review Bot CLI
 * Command-line interface for running the PR review pipeline
 */

const path = require('path');
const fs = require('fs');
const PipelineRunner = require('./stages/PipelineRunner');

// If PR_REVIEW_OUTPUT_FILE is set, tee all stdout to the file while preserving
// normal terminal output (encoding, interactivity, colors).
let _outputFileStream = null;
if (process.env.PR_REVIEW_OUTPUT_FILE) {
  _outputFileStream = fs.createWriteStream(process.env.PR_REVIEW_OUTPUT_FILE, { encoding: 'utf8' });
  const _origStdoutWrite = process.stdout.write.bind(process.stdout);
  process.stdout.write = function (chunk, encoding, callback) {
    _outputFileStream.write(chunk, encoding);
    return _origStdoutWrite(chunk, encoding, callback);
  };
}

// Auto-load BITBUCKET_PAT from shell profile if not already set.
// Supports macOS (.zshrc), Linux (.bashrc), and Windows (PowerShell profile).
// Falls back to .github/.env file if shell profile doesn't provide it.
function loadEnvFromShellProfile() {
  const os = require('os');
  const { execSync } = require('child_process');
  const homeDir = os.homedir();
  const platform = os.platform();

  // Determine the shell profile file and command based on OS
  let profilePath;
  let shellCommand;

  if (platform === 'win32') {
    // Windows: read from PowerShell profile
    const psProfile = path.join(
      homeDir,
      'Documents',
      'PowerShell',
      'Microsoft.PowerShell_profile.ps1'
    );
    const psProfileLegacy = path.join(
      homeDir,
      'Documents',
      'WindowsPowerShell',
      'Microsoft.PowerShell_profile.ps1'
    );
    profilePath = fs.existsSync(psProfile)
      ? psProfile
      : fs.existsSync(psProfileLegacy)
      ? psProfileLegacy
      : null;

    if (profilePath) {
      // Extract variable assignments from PowerShell profile
      try {
        const content = fs.readFileSync(profilePath, 'utf8');
        // Match: $env:BITBUCKET_PAT = "value" or $env:BITBUCKET_TOKEN = "value"
        const regex =
          /\$env:(BITBUCKET_PAT|BITBUCKET_TOKEN)\s*=\s*["']([^"']*)["']/gi;
        let match;
        while ((match = regex.exec(content)) !== null) {
          const key = match[1];
          const value = match[2];
          if (!process.env[key]) {
            process.env[key] = value;
          }
        }
      } catch (e) {
        // Ignore read errors
      }
    }
  } else {
    // macOS / Linux: source the appropriate shell profile
    const shell = process.env.SHELL || '/bin/bash';
    const isZsh = shell.includes('zsh');

    if (isZsh) {
      profilePath = path.join(homeDir, '.zshrc');
    } else {
      profilePath = path.join(homeDir, '.bashrc');
    }

    if (profilePath && fs.existsSync(profilePath)) {
      const varsToLoad = ['BITBUCKET_PAT', 'BITBUCKET_TOKEN'];
      for (const varName of varsToLoad) {
        if (!process.env[varName]) {
          try {
            // Source the profile and print the variable
            const cmd = isZsh
              ? `zsh -c 'source ${profilePath} 2>/dev/null && echo "\${${varName}}"'`
              : `bash -c 'source ${profilePath} 2>/dev/null && echo "\${${varName}}"'`;
            const value = execSync(cmd, {
              encoding: 'utf8',
              timeout: 5000,
            }).trim();
            if (value) {
              process.env[varName] = value;
            }
          } catch (e) {
            // Ignore errors from sourcing profile
          }
        }
      }
    }
  }
}

// Load BITBUCKET_PAT from shell profile (cross-platform)
if (!process.env.BITBUCKET_PAT && !process.env.BITBUCKET_TOKEN) {
  loadEnvFromShellProfile();
}

// Fallback: load from .github/.env if it exists (for additional env vars)
const envPath = path.resolve(process.cwd(), '.github', '.env');
if (fs.existsSync(envPath)) {
  try {
    require('dotenv').config({ path: envPath, override: false });
  } catch (e) {
    // dotenv not available — use simple manual parser as fallback
    const envContent = fs.readFileSync(envPath, 'utf8');
    for (const line of envContent.split('\n')) {
      const trimmed = line.trim();
      if (trimmed && !trimmed.startsWith('#')) {
        const eqIndex = trimmed.indexOf('=');
        if (eqIndex > 0) {
          const key = trimmed.slice(0, eqIndex).trim();
          let value = trimmed.slice(eqIndex + 1).trim();
          if (
            (value.startsWith('"') && value.endsWith('"')) ||
            (value.startsWith("'") && value.endsWith("'"))
          ) {
            value = value.slice(1, -1);
          }
          if (!process.env[key]) {
            process.env[key] = value;
          }
        }
      }
    }
  }
}

// Check if review is globally disabled via environment
if (process.env.PR_REVIEW_ENABLED === 'false') {
  console.log('PR Review is disabled (PR_REVIEW_ENABLED=false)');
  process.exit(0);
}

// Parse command line arguments
function parseArgs() {
  const args = process.argv.slice(2);
  const options = {
    verbose: false,
    cache: true,
    clearCache: false,
    modelTier: 'default',
    noBitbucket: false,
    noFail: false,
    output: 'text',
    help: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    switch (arg) {
      case '--verbose':
      case '-v':
        options.verbose = true;
        break;

      case '--no-cache':
        options.cache = false;
        break;

      case '--clear-cache':
        options.clearCache = true;
        break;

      case '--simple':
        options.modelTier = 'simple';
        break;

      case '--complex':
        options.modelTier = 'complex';
        break;

      case '--no-bitbucket':
        options.noBitbucket = true;
        break;

      case '--no-fail':
        options.noFail = true;
        break;

      case '--output':
      case '-o':
        if (i + 1 < args.length) {
          const fmt = args[++i].toLowerCase();
          if (fmt !== 'text' && fmt !== 'json') {
            console.error('Error: --output must be "text" or "json"');
            process.exit(1);
          }
          options.output = fmt;
        } else {
          console.error('Error: --output requires a value (text, json)');
          process.exit(1);
        }
        break;

      case '--model':
      case '-m':
        if (i + 1 < args.length) {
          options.modelTier = args[++i];
        } else {
          console.error(
            'Error: --model requires a value (simple, default, complex)'
          );
          process.exit(1);
        }
        break;

      case '--help':
      case '-h':
        options.help = true;
        break;

      default:
        console.error(`Unknown option: ${arg}`);
        options.help = true;
        break;
    }
  }

  return options;
}

// Show help message
function showHelp() {
  const ConfigLoader = require('./stages/ConfigLoader');
  const basePath = __dirname;

  // Load config to show actual model names
  let modelInfo = '';
  try {
    const configLoader = new ConfigLoader(basePath);
    const config = configLoader.getConfig();
    const models = config.pipeline.ai?.models || {};

    // Build model tier descriptions with actual model names
    const tiers = ['simple', 'default', 'complex'];
    const modelDescriptions = tiers
      .map(tier => {
        if (models[tier]) {
          const model = models[tier];
          return `  ${tier.padEnd(10)} - ${model.name} (${model.description})`;
        }
        return `  ${tier.padEnd(10)} - Not configured`;
      })
      .join('\n');

    modelInfo = `\nModel Tiers:\n${modelDescriptions}\n`;
  } catch (error) {
    // Fallback if config can't be loaded
    modelInfo = `\nModel Tiers:
  simple    - Fast, cost-effective model
  default   - Balanced model (default)
  complex   - Most capable model
`;
  }

  console.log(`
PR Review Bot - Automated Pull Request Review

Usage: node cli.js [options]

Options:
  --simple             Use fast/small model for quick reviews
  --complex            Use large/capable model for thorough reviews
  -m, --model <tier>   Select AI model tier (simple, default, complex)
  -v, --verbose        Enable verbose logging
  --no-cache           Disable caching of AI reviews
  --clear-cache        Clear all cached responses before running
  --no-bitbucket       Skip Bitbucket PR comment integration
  --no-fail            Exit 0 on error (for git-hook use)
  -o, --output <fmt>   Output format: text (default) or json
  -h, --help           Show this help message

Examples:
  node cli.js                           # Run with default settings
  node cli.js --simple                  # Fast review
  node cli.js --complex                 # Thorough review
  node cli.js --verbose                 # Run with verbose logging
  node cli.js --no-cache                # Run without caching
  node cli.js --clear-cache             # Clear cache, then run
  node cli.js --no-bitbucket            # Skip Bitbucket integration
  node cli.js --no-fail                 # Don't block on errors (git-hook safe)
  node cli.js --model complex           # Use most capable model
  node cli.js --output json              # Machine-readable JSON output
${modelInfo}
Environment Variables:
  PR_REVIEW_*         - Override any config value (e.g., PR_REVIEW_AI_PR_APPROVALS=true)

Configuration:
  Priority: ENV vars > ./pr_review_bot.yaml.local > ~/.pr_review_bot.yaml.local > tools/pr-review/config.yaml
`);
}

// Main execution
async function main() {
  // Helper to flush output file before exiting
  function exitProcess(code) {
    if (_outputFileStream) {
      console.log(`\nReview also written to: ${process.env.PR_REVIEW_OUTPUT_FILE}`);
      _outputFileStream.end(() => process.exit(code));
    } else {
      process.exit(code);
    }
  }

  const options = parseArgs();

  if (options.help) {
    showHelp();
    exitProcess(0);
  }

  const basePath = __dirname;

  // Handle --clear-cache option
  if (options.clearCache) {
    const CacheManager = require('./stages/CacheManager');
    const cacheManager = new CacheManager(basePath, { verbose: true });
    cacheManager.clear();
    console.log('Cache cleared.');
  }

  try {
    const pipeline = new PipelineRunner(basePath, options);

    if (options.output === 'json') {
      // JSON output mode — suppress console, emit structured JSON
      const origLog = console.log;
      const origError = console.error;
      console.log = () => {};
      console.error = () => {};

      try {
        pipeline.initialize();
        const { results, metadata, skipped, reason, purposeText } = await pipeline.execute();
        console.log = origLog;
        console.error = origError;

        const ReportFormatter = require('./stages/ReportFormatter');
        const formatter = new ReportFormatter(
          pipeline.config?.pipeline?.output || {}
        );
        const json = formatter.formatJSON(results, metadata, skipped, reason, purposeText);
        process.stdout.write(JSON.stringify(json, null, 2) + '\n');
        exitProcess(
          json.summary.failed > 0 &&
            pipeline.config?.pipeline?.pipeline?.failOnError
            ? 1
            : 0
        );
      } catch (err) {
        console.log = origLog;
        console.error = origError;
        const errorJson = {
          status: 'error',
          error: err.message,
          stages: [],
          summary: {
            errors: 0,
            warnings: 0,
            info: 0,
            passed: 0,
            failed: 1,
            skipped: 0,
            cached: 0,
          },
        };
        process.stdout.write(JSON.stringify(errorJson, null, 2) + '\n');
        exitProcess(options.noFail ? 0 : 1);
      }
      return;
    }

    const exitCode = await pipeline.run();
    exitProcess(exitCode);
  } catch (error) {
    console.error(`Fatal error: ${error.message}`);
    if (options.verbose) {
      console.error(error.stack);
    }
    // --no-fail: exit 0 on error (for git-hook use)
    exitProcess(options.noFail ? 0 : 1);
  }
}

// Run if executed directly
if (require.main === module) {
  main();
}

module.exports = { parseArgs, showHelp };
