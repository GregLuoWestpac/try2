/**
 * LineInclusionTracker - Shared cross-transformer line deduplication
 *
 * Tracks which (filePath, lineNumber) pairs are already represented in the
 * output that will be sent to the AI model.  Every transformer checks the
 * tracker before appending context blocks so that the same source lines are
 * never duplicated across transformers.
 *
 * Line numbers are 1-indexed to match unified-diff / editor conventions.
 */

class LineInclusionTracker {
  /**
   * @param {Object} [options]
   * @param {number} [options.coverageThreshold=0.8] - Skip a proposed block
   *   when this fraction (0-1) of its lines are already tracked.
   */
  constructor(options = {}) {
    /** @type {Map<string, Set<number>>} filePath → included line numbers */
    this._included = new Map();

    /** @type {number} 0-1; blocks at or above this coverage are skipped */
    this.coverageThreshold = options.coverageThreshold ?? 0.8;
  }

  // -----------------------------------------------------------
  // Low-level mutation
  // -----------------------------------------------------------

  /**
   * Mark a single line as included.
   * @param {string} filePath
   * @param {number} lineNum  1-indexed
   */
  markLine(filePath, lineNum) {
    let set = this._included.get(filePath);
    if (!set) {
      set = new Set();
      this._included.set(filePath, set);
    }
    set.add(lineNum);
  }

  /**
   * Mark a contiguous range [startLine, endLine] as included.
   * @param {string} filePath
   * @param {number} startLine  1-indexed, inclusive
   * @param {number} endLine    1-indexed, inclusive
   */
  markRange(filePath, startLine, endLine) {
    for (let i = startLine; i <= endLine; i++) {
      this.markLine(filePath, i);
    }
  }

  // -----------------------------------------------------------
  // Seeding from diff hunks
  // -----------------------------------------------------------

  /**
   * Pre-populate the tracker with lines that are already visible in the
   * unified diff (context lines + added lines).
   *
   * @param {string} filePath
   * @param {Array}  hunks  Parsed hunk objects from DiffContextBuilder
   */
  seedFromHunks(filePath, hunks) {
    for (const hunk of hunks) {
      let newLine = hunk.newStart;
      for (const line of hunk.lines) {
        if (line.startsWith('+') && !line.startsWith('+++')) {
          // Added line — has a "new" line number
          this.markLine(filePath, newLine);
          newLine++;
        } else if (line.startsWith('-') && !line.startsWith('---')) {
          // Removed line — old-side only, no new line number
        } else {
          // Context line — has a "new" line number
          this.markLine(filePath, newLine);
          newLine++;
        }
      }
    }
  }

  // -----------------------------------------------------------
  // Queries
  // -----------------------------------------------------------

  /**
   * Check whether a single line is already tracked.
   */
  hasLine(filePath, lineNum) {
    const set = this._included.get(filePath);
    return set ? set.has(lineNum) : false;
  }

  /**
   * Return the fraction of [startLine, endLine] that is already tracked.
   * @returns {number} 0.0 – 1.0
   */
  getRangeCoverage(filePath, startLine, endLine) {
    if (startLine > endLine) return 1.0;
    const total = endLine - startLine + 1;
    let covered = 0;
    for (let i = startLine; i <= endLine; i++) {
      if (this.hasLine(filePath, i)) covered++;
    }
    return covered / total;
  }

  /**
   * Return the line numbers in [startLine, endLine] NOT yet tracked.
   * @returns {number[]}
   */
  getNewLinesInRange(filePath, startLine, endLine) {
    const newLines = [];
    for (let i = startLine; i <= endLine; i++) {
      if (!this.hasLine(filePath, i)) {
        newLines.push(i);
      }
    }
    return newLines;
  }

  // -----------------------------------------------------------
  // Block-level convenience
  // -----------------------------------------------------------

  /**
   * Attempt to register a context block.
   *
   * If the block's line range is already sufficiently covered (≥ threshold),
   * the block is rejected (returns null).  Otherwise the novel (not-yet-tracked)
   * lines are extracted, marked as included, and a trimmed block descriptor is
   * returned containing only the new content.
   *
   * @param {string} filePath
   * @param {number} startLine  1-indexed, inclusive
   * @param {number} endLine    1-indexed, inclusive
   * @param {string} name       Human-readable block label
   * @param {string} content    Source text of the block
   * @param {number} [threshold]  Override the instance-level coverageThreshold
   * @returns {Object|null} Block object or null if redundant
   */
  tryAddBlock(filePath, startLine, endLine, name, content, threshold) {
    const t = threshold ?? this.coverageThreshold;
    const coverage = this.getRangeCoverage(filePath, startLine, endLine);

    if (coverage >= t) {
      return null; // Sufficiently covered already
    }

    // Trim: emit only the novel lines to avoid partial overlaps
    const contentLines = content.split('\n');
    const novelRanges = this._getNovelContiguousRanges(filePath, startLine, endLine);

    if (novelRanges.length === 0) {
      return null;
    }

    // Build trimmed content from the contiguous novel ranges.
    // Clamp indices to content bounds since content may not span the full range
    // (e.g. truncation markers, synthetic blocks).
    const trimmedParts = [];
    let trimmedStart = novelRanges[0].start;
    let trimmedEnd = novelRanges[novelRanges.length - 1].end;

    for (const range of novelRanges) {
      const sliceStart = Math.max(0, range.start - startLine);
      const sliceEnd = Math.min(range.end - startLine + 1, contentLines.length);
      if (sliceStart < sliceEnd) {
        trimmedParts.push(contentLines.slice(sliceStart, sliceEnd).join('\n'));
      }
    }

    // If trimming produced no usable content (e.g. range falls outside content
    // bounds), fall back to the full original content.
    if (trimmedParts.length === 0) {
      this.markRange(filePath, startLine, endLine);
      return { name, file: filePath, content, startLine, endLine };
    }

    // If ranges are non-contiguous, join with an elision marker
    const trimmedContent = trimmedParts.join('\n  // ... (lines already in context) ...\n');

    // Mark the full range so subsequent transformers see all lines as covered
    this.markRange(filePath, startLine, endLine);

    return {
      name,
      file: filePath,
      content: trimmedContent,
      startLine: trimmedStart,
      endLine: trimmedEnd,
    };
  }

  /**
   * Return contiguous ranges of novel (not-yet-tracked) lines within
   * [startLine, endLine].
   * @returns {Array<{start: number, end: number}>}
   */
  _getNovelContiguousRanges(filePath, startLine, endLine) {
    const ranges = [];
    let rangeStart = null;

    for (let i = startLine; i <= endLine; i++) {
      if (!this.hasLine(filePath, i)) {
        if (rangeStart === null) rangeStart = i;
      } else {
        if (rangeStart !== null) {
          ranges.push({ start: rangeStart, end: i - 1 });
          rangeStart = null;
        }
      }
    }

    if (rangeStart !== null) {
      ranges.push({ start: rangeStart, end: endLine });
    }

    return ranges;
  }
}

module.exports = LineInclusionTracker;
