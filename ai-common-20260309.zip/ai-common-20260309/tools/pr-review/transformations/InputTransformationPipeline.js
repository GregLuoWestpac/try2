/**
 * InputTransformationPipeline - Orchestrates input transformations
 */

const LineInclusionTracker = require('./LineInclusionTracker');

class InputTransformationPipeline {
  constructor(transformations = [], options = {}) {
    this.transformations = transformations;
    this.maxTotalAppendedBytes = options.maxTotalAppendedBytes || 50000; // 50KB default
    this.maxAppendedBytesPerFile = options.maxAppendedBytesPerFile ?? Infinity;
  }

  /**
   * Run the pipeline on a DiffContext
   * @param {Object} ctx - DiffContext
   * @returns {Object} Transformed DiffContext
   */
  run(ctx) {
    let currentCtx = { ...ctx };

    // Ensure lineTracker is always present so transformers never fall back
    // to the no-dedup code path.
    if (!currentCtx.lineTracker) {
      currentCtx.lineTracker = new LineInclusionTracker();
    }

    for (const transformation of this.transformations) {
      // Skip disabled transformations
      if (transformation.enabled === false) {
        continue;
      }

      try {
        // Run transformation
        currentCtx = transformation.transform(currentCtx);
      } catch (error) {
        // Degrade gracefully - log error but continue
        console.error(`Transformation ${transformation.id} failed:`, error.message);
      }
    }

    currentCtx.appendedContextBlocks = this.enforceByteLimit(
      this.mergeOverlappingBlocks(
        this.dedupeBlocks(currentCtx.appendedContextBlocks)
      )
    );

    return currentCtx;
  }

  dedupeBlocks(blocks) {
    const seen = new Set();
    const deduped = [];

    for (const block of blocks || []) {
      if (!block) continue;
      const key = `${block.name}\n${block.file}\n${block.content}`;
      if (seen.has(key)) continue;
      seen.add(key);
      deduped.push(block);
    }

    // Sort by (file, startLine) to preserve source code order
    deduped.sort((a, b) => {
      const fileCmp = (a.file || '').localeCompare(b.file || '');
      if (fileCmp !== 0) return fileCmp;
      return (a.startLine || 0) - (b.startLine || 0);
    });

    return deduped;
  }

  /**
   * Merge blocks with overlapping or adjacent line ranges for the same file.
   * Blocks are assumed to be sorted by (file, startLine) from dedupeBlocks().
   */
  mergeOverlappingBlocks(blocks) {
    if (!blocks || blocks.length <= 1) return blocks || [];

    const merged = [];
    let current = { ...blocks[0] };

    for (let i = 1; i < blocks.length; i++) {
      const next = blocks[i];

      // Only merge blocks from the same file that have valid line ranges
      if (
        next.file === current.file &&
        current.startLine != null && current.endLine != null &&
        next.startLine != null && next.endLine != null &&
        next.startLine <= current.endLine + 1 // overlapping or adjacent
      ) {
        // Merge: extend range, concatenate content (avoiding duplication)
        const newEnd = Math.max(current.endLine, next.endLine);
        const names = current.name === next.name
          ? current.name
          : `${current.name} + ${next.name}`;
        current = {
          name: names,
          file: current.file,
          content: current.content + '\n' + next.content,
          startLine: current.startLine,
          endLine: newEnd,
        };
      } else {
        merged.push(current);
        current = { ...next };
      }
    }

    merged.push(current);
    return merged;
  }

  /**
   * Enforce max total appended bytes limit (and per-file appended byte limit)
   */
  enforceByteLimit(blocks) {
    const limited = [];
    let totalBytes = 0;
    const perFileBytes = new Map();

    for (const block of blocks || []) {
      const blockText = this.formatBlock(block);
      const blockBytes = Buffer.byteLength(blockText, 'utf-8');

      const fileKey = block.file || '';
      const fileBytesSoFar = perFileBytes.get(fileKey) || 0;
      if (fileBytesSoFar + blockBytes > this.maxAppendedBytesPerFile) {
        continue;
      }

      if (totalBytes + blockBytes <= this.maxTotalAppendedBytes) {
        limited.push(block);
        totalBytes += blockBytes;
        perFileBytes.set(fileKey, fileBytesSoFar + blockBytes);
      } else {
        // Stop adding blocks once limit is reached
        break;
      }
    }

    return limited;
  }

  /**
   * Format a single block for byte calculation
   */
  formatBlock(block) {
    return `\n\n--- Related Context: ${block.name} ---\nFile: ${block.file}\n${block.content}\n--- End Related Context ---\n`;
  }

  /**
   * Format all appended blocks as a string
   */
  formatAppendedBlocks(blocks) {
    return blocks.map((block) => this.formatBlock(block)).join('');
  }

  /**
   * Get the final transformed diff text
   */
  getFinalDiffText(ctx) {
    const appendedText = this.formatAppendedBlocks(ctx.appendedContextBlocks);
    return ctx.rawDiffText + appendedText;
  }
}

module.exports = InputTransformationPipeline;
