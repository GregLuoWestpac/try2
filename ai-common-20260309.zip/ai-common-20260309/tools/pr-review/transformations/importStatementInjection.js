/**
 * importStatementInjection - Adds import/export context from top of file
 */

const GitTextProvider = require('./GitTextProvider');

class ImportStatementInjection {
  /**
   * Transform context by adding import statements
   */
  static transform(ctx, config = {}) {
    const maxLines = config.maxLines || 80;
    const includeExportBlock = config.includeExportBlock || false;

    for (const file of ctx.files) {
      // Only process JS/TS files
      if (!this.isJavaScriptFile(file.languageId)) {
        continue;
      }

      // Skip new files — the diff already contains the full file content
      if (file.isNewFile) {
        continue;
      }

      const afterText = file.afterText || new GitTextProvider(ctx.mergeBase, ctx.head).getAfterText(file.path);
      if (!afterText) {
        continue;
      }

      file.afterText = afterText;

      // Extract imports
      const importResult = this.extractImports(afterText, maxLines);
      
      if (importResult) {
        const block = ctx.lineTracker.tryAddBlock(
          file.path,
          importResult.startLine,
          importResult.endLine,
          'Imports',
          importResult.content
        );

        if (block) {
          ctx.appendedContextBlocks.push(block);
        }
      }

      // Extract exports if requested
      if (includeExportBlock) {
        const exportResult = this.extractExports(afterText, maxLines);
        if (exportResult) {
          const block = ctx.lineTracker.tryAddBlock(
            file.path,
            exportResult.startLine,
            exportResult.endLine,
            'Exports',
            exportResult.content
          );

          if (block) {
            ctx.appendedContextBlocks.push(block);
          }
        }
      }
    }

    return ctx;
  }

  /**
   * Check if file is JavaScript/TypeScript
   */
  static isJavaScriptFile(languageId) {
    return ['javascript', 'javascriptreact', 'typescript', 'typescriptreact'].includes(
      languageId
    );
  }

  /**
   * Extract import statements from top of file
   * @returns {{ content: string, startLine: number, endLine: number } | null}
   */
  static extractImports(text, maxLines) {
    const lines = text.split('\n');
    const importLines = [];
    let inImportBlock = false;
    let firstImportIdx = -1;
    let lastImportIdx = -1;

    for (let idx = 0; idx < lines.length; idx++) {
      const line = lines[idx];
      const trimmed = line.trim();
      
      // Start of import
      if (trimmed.startsWith('import ')) {
        inImportBlock = true;
        if (firstImportIdx === -1) firstImportIdx = idx;
        lastImportIdx = idx;
        importLines.push(line);
      }
      // Continuation of multi-line import
      else if (inImportBlock && !trimmed.startsWith('//') && trimmed) {
        lastImportIdx = idx;
        importLines.push(line);
        // Check if this line ends the import statement
        if (trimmed.endsWith(';') || trimmed.endsWith("';") || trimmed.endsWith('";')) {
          inImportBlock = false;
        }
      }
      // Empty line or comment - continue if we're in import section
      else if (trimmed === '' || trimmed.startsWith('//') || trimmed.startsWith('/*')) {
        if (importLines.length > 0) {
          lastImportIdx = idx;
          importLines.push(line);
        }
      }
      // Non-import statement found after imports
      else if (importLines.length > 0) {
        break;
      }

      // Stop if we've exceeded maxLines
      if (importLines.length >= maxLines) {
        importLines.push('... truncated ...');
        break;
      }
    }

    if (importLines.length === 0) return null;

    return {
      content: importLines.join('\n'),
      startLine: firstImportIdx + 1,  // 1-indexed
      endLine: lastImportIdx + 1,     // 1-indexed
    };
  }

  /**
   * Extract export statements
   * @returns {{ content: string, startLine: number, endLine: number } | null}
   */
  static extractExports(text, maxLines) {
    const lines = text.split('\n');
    const exportLines = [];
    let firstExportIdx = -1;
    let lastExportIdx = -1;

    for (let idx = 0; idx < lines.length; idx++) {
      const line = lines[idx];
      if (line.trim().startsWith('export ')) {
        if (firstExportIdx === -1) firstExportIdx = idx;
        lastExportIdx = idx;
        exportLines.push(line);
        
        if (exportLines.length >= maxLines) {
          exportLines.push('... truncated ...');
          break;
        }
      }
    }

    if (exportLines.length === 0) return null;

    return {
      content: exportLines.join('\n'),
      startLine: firstExportIdx + 1,  // 1-indexed
      endLine: lastExportIdx + 1,     // 1-indexed
    };
  }
}

module.exports = ImportStatementInjection;
