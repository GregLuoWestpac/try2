/**
 * classOrComponentHeaderInclusion - Adds class/component header context
 */

const GitTextProvider = require('./GitTextProvider');

class ClassOrComponentHeaderInclusion {
  /**
   * Transform context by adding class/component headers
   */
  static transform(ctx, config = {}) {
    const maxHeaderLines = config.maxHeaderLines || 3;
    const scanWindowLines = config.scanWindowLines || 200;

    for (const file of ctx.files) {
      // Only process JS/TS files
      if (!this.isJavaScriptFile(file.languageId)) {
        continue;
      }

      // Skip new files — the diff already contains the full file content
      if (file.isNewFile) {
        continue;
      }

      const afterText = file.afterText || new GitTextProvider(ctx.mergeBase, ctx.head).getAfterText(file.path);
      if (!afterText) {
        continue;
      }

      file.afterText = afterText;

      // Track which headers we've already added for this file
      const addedHeaders = new Set();

      for (const hunk of file.hunks) {
        // Find changed lines in this hunk
        const changedLines = this.extractChangedLines(hunk);
        
        for (const lineNum of changedLines) {
          // Try to find class/component header
          const header = this.findHeader(afterText, lineNum, scanWindowLines, maxHeaderLines);
          
          if (header) {
            const headerKey = `${header.type}:${header.name}`;
            if (!addedHeaders.has(headerKey)) {
              addedHeaders.add(headerKey);
              const blockName = header.type === 'class' ? 'Class Header' : 'Component Header';

              const block = ctx.lineTracker.tryAddBlock(
                file.path,
                header.startLine,
                header.endLine,
                `${blockName} (${header.name})`,
                header.content
              );

              if (block) {
                ctx.appendedContextBlocks.push(block);
              }
            }
            break; // Only add one header per hunk
          }
        }
      }
    }

    return ctx;
  }

  /**
   * Check if file is JavaScript/TypeScript
   */
  static isJavaScriptFile(languageId) {
    return ['javascript', 'javascriptreact', 'typescript', 'typescriptreact'].includes(
      languageId
    );
  }

  /**
   * Extract changed line numbers from a hunk
   */
  static extractChangedLines(hunk) {
    const changedLines = [];
    let currentLine = hunk.newStart;

    for (const line of hunk.lines) {
      if (line.startsWith('+') && !line.startsWith('+++')) {
        changedLines.push(currentLine);
        currentLine++;
      } else if (!line.startsWith('-')) {
        currentLine++;
      }
    }

    return changedLines;
  }

  /**
   * Find class or component header above a given line
   * @returns {{ type: string, name: string, content: string, startLine: number, endLine: number } | null}
   */
  static findHeader(text, lineNum, scanWindowLines, maxHeaderLines) {
    const lines = text.split('\n');
    
    if (lineNum > lines.length) {
      return null;
    }

    const startScan = Math.max(0, lineNum - scanWindowLines - 1);
    
    // Search backward for class or component declaration
    for (let i = lineNum - 1; i >= startScan; i--) {
      const line = lines[i];
      
      // Match class declaration
      const classMatch = line.match(/^\s*class\s+(\w+)(\s+extends\s+\w+)?/);
      if (classMatch) {
        const name = classMatch[1];
        const { content, endIdx } = this.extractHeaderLinesWithRange(lines, i, maxHeaderLines);
        return {
          type: 'class',
          name,
          content,
          startLine: i + 1,     // 1-indexed
          endLine: endIdx + 1,   // 1-indexed
        };
      }

      // Match function component (capitalized name)
      const funcMatch = line.match(/^\s*(export\s+)?(default\s+)?function\s+([A-Z]\w+)\s*\(/);
      if (funcMatch) {
        const name = funcMatch[3];
        const { content, endIdx } = this.extractHeaderLinesWithRange(lines, i, maxHeaderLines);
        return {
          type: 'component',
          name,
          content,
          startLine: i + 1,
          endLine: endIdx + 1,
        };
      }

      // Match const/let component (arrow function with capitalized name)
      const constMatch = line.match(/^\s*(export\s+)?(const|let)\s+([A-Z]\w+)\s*=\s*(\(.*\)|.*)\s*=>/);
      if (constMatch) {
        const name = constMatch[3];
        const { content, endIdx } = this.extractHeaderLinesWithRange(lines, i, maxHeaderLines);
        return {
          type: 'component',
          name,
          content,
          startLine: i + 1,
          endLine: endIdx + 1,
        };
      }
    }

    return null;
  }

  /**
   * Extract header lines (may span multiple lines) — returns just the content string
   * (kept for backward compatibility)
   */
  static extractHeaderLines(lines, startLine, maxLines) {
    const { content } = this.extractHeaderLinesWithRange(lines, startLine, maxLines);
    return content;
  }

  /**
   * Extract header lines with start/end index info
   * @returns {{ content: string, endIdx: number }}  endIdx is 0-indexed
   */
  static extractHeaderLinesWithRange(lines, startLine, maxLines) {
    const headerLines = [];
    let endIdx = startLine;
    
    for (let i = startLine; i < Math.min(lines.length, startLine + maxLines); i++) {
      headerLines.push(lines[i]);
      endIdx = i;
      
      // Stop if we hit the opening brace
      if (lines[i].includes('{')) {
        break;
      }
    }

    return {
      content: headerLines.join('\n'),
      endIdx,
    };
  }
}

module.exports = ClassOrComponentHeaderInclusion;
