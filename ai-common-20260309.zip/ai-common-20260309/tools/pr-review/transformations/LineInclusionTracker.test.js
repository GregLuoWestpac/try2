/**
 * Unit tests for LineInclusionTracker
 */

const LineInclusionTracker = require('./LineInclusionTracker');

describe('LineInclusionTracker', () => {
  let tracker;

  beforeEach(() => {
    tracker = new LineInclusionTracker();
  });

  // -----------------------------------------------------------
  // markLine / hasLine
  // -----------------------------------------------------------

  test('T040: markLine and hasLine track individual lines', () => {
    tracker.markLine('a.ts', 5);
    tracker.markLine('a.ts', 10);

    expect(tracker.hasLine('a.ts', 5)).toBe(true);
    expect(tracker.hasLine('a.ts', 10)).toBe(true);
    expect(tracker.hasLine('a.ts', 6)).toBe(false);
    expect(tracker.hasLine('b.ts', 5)).toBe(false);
  });

  // -----------------------------------------------------------
  // markRange
  // -----------------------------------------------------------

  test('T041: markRange marks contiguous range', () => {
    tracker.markRange('a.ts', 3, 7);

    expect(tracker.hasLine('a.ts', 2)).toBe(false);
    expect(tracker.hasLine('a.ts', 3)).toBe(true);
    expect(tracker.hasLine('a.ts', 5)).toBe(true);
    expect(tracker.hasLine('a.ts', 7)).toBe(true);
    expect(tracker.hasLine('a.ts', 8)).toBe(false);
  });

  // -----------------------------------------------------------
  // seedFromHunks
  // -----------------------------------------------------------

  test('T042: seedFromHunks marks added and context lines', () => {
    const hunks = [
      {
        newStart: 10,
        lines: [
          ' context line',    // line 10 — context
          '+added line 1',    // line 11 — added
          '+added line 2',    // line 12 — added
          '-removed line',    // no new-side line
          ' another ctx',     // line 13 — context
        ],
      },
    ];

    tracker.seedFromHunks('file.ts', hunks);

    expect(tracker.hasLine('file.ts', 10)).toBe(true);  // context
    expect(tracker.hasLine('file.ts', 11)).toBe(true);  // added
    expect(tracker.hasLine('file.ts', 12)).toBe(true);  // added
    expect(tracker.hasLine('file.ts', 13)).toBe(true);  // context
    expect(tracker.hasLine('file.ts', 9)).toBe(false);  // before hunk
    expect(tracker.hasLine('file.ts', 14)).toBe(false); // after hunk
  });

  test('T043: seedFromHunks handles new file (all + lines)', () => {
    const hunks = [
      {
        newStart: 1,
        lines: [
          '+line 1',
          '+line 2',
          '+line 3',
          '+line 4',
          '+line 5',
        ],
      },
    ];

    tracker.seedFromHunks('newfile.ts', hunks);

    for (let i = 1; i <= 5; i++) {
      expect(tracker.hasLine('newfile.ts', i)).toBe(true);
    }
    expect(tracker.hasLine('newfile.ts', 0)).toBe(false);
    expect(tracker.hasLine('newfile.ts', 6)).toBe(false);
  });

  test('T044: seedFromHunks handles multiple hunks', () => {
    const hunks = [
      { newStart: 1, lines: ['+line 1', '+line 2'] },
      { newStart: 20, lines: [' ctx', '+new', ' ctx'] },
    ];

    tracker.seedFromHunks('f.ts', hunks);

    expect(tracker.hasLine('f.ts', 1)).toBe(true);
    expect(tracker.hasLine('f.ts', 2)).toBe(true);
    expect(tracker.hasLine('f.ts', 3)).toBe(false);
    expect(tracker.hasLine('f.ts', 20)).toBe(true);
    expect(tracker.hasLine('f.ts', 21)).toBe(true);
    expect(tracker.hasLine('f.ts', 22)).toBe(true);
  });

  // -----------------------------------------------------------
  // getRangeCoverage
  // -----------------------------------------------------------

  test('T045: getRangeCoverage returns correct fraction', () => {
    tracker.markRange('a.ts', 1, 10);

    expect(tracker.getRangeCoverage('a.ts', 1, 10)).toBe(1.0);
    expect(tracker.getRangeCoverage('a.ts', 5, 15)).toBe(6 / 11); // 5-10 covered, 11-15 not
    expect(tracker.getRangeCoverage('a.ts', 11, 20)).toBe(0.0);
    expect(tracker.getRangeCoverage('b.ts', 1, 10)).toBe(0.0);
  });

  test('T046: getRangeCoverage returns 1.0 for inverted range', () => {
    expect(tracker.getRangeCoverage('a.ts', 10, 5)).toBe(1.0);
  });

  // -----------------------------------------------------------
  // getNewLinesInRange
  // -----------------------------------------------------------

  test('T047: getNewLinesInRange returns only uncovered lines', () => {
    tracker.markRange('a.ts', 3, 7);

    const newLines = tracker.getNewLinesInRange('a.ts', 5, 10);
    expect(newLines).toEqual([8, 9, 10]);
  });

  // -----------------------------------------------------------
  // tryAddBlock
  // -----------------------------------------------------------

  test('T048: tryAddBlock returns block when coverage below threshold', () => {
    tracker.markRange('a.ts', 1, 3);  // 3 lines covered

    // Propose block for lines 1-10 → 30% coverage → below 0.8 threshold
    // Content must have 10 lines to match the line range
    const lines = Array.from({ length: 10 }, (_, i) => `line ${i + 1}`);
    const block = tracker.tryAddBlock('a.ts', 1, 10, 'Test Block', lines.join('\n'));

    expect(block).not.toBeNull();
    expect(block.name).toBe('Test Block');
    expect(block.file).toBe('a.ts');
    // Trimmed: only novel lines (4-10) are included
    const outputLines = block.content.split('\n');
    expect(outputLines[0]).toBe('line 4');
    expect(outputLines).not.toContain('line 1');
    expect(outputLines).not.toContain('line 3');
    expect(block.content).toContain('line 4');
    expect(block.content).toContain('line 10');
    expect(block.startLine).toBe(4);
    expect(block.endLine).toBe(10);

    // Lines 1-10 should now all be marked
    for (let i = 1; i <= 10; i++) {
      expect(tracker.hasLine('a.ts', i)).toBe(true);
    }
  });

  test('T049: tryAddBlock returns null when coverage meets threshold', () => {
    tracker.markRange('a.ts', 1, 10);  // All 10 lines covered

    // Propose block for lines 1-10 → 100% coverage → above 0.8
    const block = tracker.tryAddBlock('a.ts', 1, 10, 'Test Block', 'content');
    expect(block).toBeNull();
  });

  test('T050: tryAddBlock respects custom threshold', () => {
    tracker.markRange('a.ts', 1, 5);

    // Lines 1-10: 50% covered. Default threshold 0.8 → should accept
    const block1 = tracker.tryAddBlock('a.ts', 1, 10, 'B1', 'c', 0.4);
    // 50% >= 40% → should reject
    expect(block1).toBeNull();
  });

  test('T051: tryAddBlock with zero coverage always accepts', () => {
    const block = tracker.tryAddBlock('z.ts', 1, 5, 'Block', 'content');
    expect(block).not.toBeNull();
    expect(block.startLine).toBe(1);
    expect(block.endLine).toBe(5);
  });

  test('T052: tryAddBlock prevents second overlapping block', () => {
    // First block: lines 1-20 — accepted
    const b1 = tracker.tryAddBlock('a.ts', 1, 20, 'B1', 'first');
    expect(b1).not.toBeNull();

    // Second block: lines 5-25 — 16 of 21 lines covered = 76% < 0.8 → accepted
    const b2 = tracker.tryAddBlock('a.ts', 5, 25, 'B2', 'second');
    expect(b2).not.toBeNull();

    // Third block: lines 1-25 — all 25 covered → rejected
    const b3 = tracker.tryAddBlock('a.ts', 1, 25, 'B3', 'third');
    expect(b3).toBeNull();
  });

  // -----------------------------------------------------------
  // Custom coverageThreshold on constructor
  // -----------------------------------------------------------

  test('T053: constructor coverageThreshold overrides default', () => {
    const strict = new LineInclusionTracker({ coverageThreshold: 0.5 });
    strict.markRange('a.ts', 1, 5);

    // 5 of 10 lines = 50% → meets 0.5 threshold → rejected
    const block = strict.tryAddBlock('a.ts', 1, 10, 'B', 'c');
    expect(block).toBeNull();
  });

  // -----------------------------------------------------------
  // Cross-file isolation
  // -----------------------------------------------------------

  test('T054: tracking is isolated per file', () => {
    tracker.markRange('a.ts', 1, 100);

    expect(tracker.getRangeCoverage('a.ts', 1, 10)).toBe(1.0);
    expect(tracker.getRangeCoverage('b.ts', 1, 10)).toBe(0.0);

    const block = tracker.tryAddBlock('b.ts', 1, 10, 'B', 'c');
    expect(block).not.toBeNull();
  });

  // -----------------------------------------------------------
  // Line-level trimming
  // -----------------------------------------------------------

  test('T055: tryAddBlock trims to only novel lines in middle gap', () => {
    // Lines 1-3 and 8-10 already tracked
    tracker.markRange('a.ts', 1, 3);
    tracker.markRange('a.ts', 8, 10);

    // Propose block covering lines 1-10
    const content = Array.from({ length: 10 }, (_, i) => `line ${i + 1}`).join('\n');
    const block = tracker.tryAddBlock('a.ts', 1, 10, 'Block', content);

    expect(block).not.toBeNull();
    const outputLines = block.content.split('\n').filter(l => !l.includes('already in context'));
    // Only lines 4-7 should be in the output as real content
    expect(outputLines).toContain('line 4');
    expect(outputLines).toContain('line 7');
    expect(outputLines).not.toContain('line 1');
    expect(outputLines).not.toContain('line 2');
    expect(outputLines).not.toContain('line 3');
    expect(outputLines).not.toContain('line 8');
  });

  test('T056: tryAddBlock emits elision markers between non-contiguous novel ranges', () => {
    // Track lines 4-6 (gap in the middle)
    tracker.markRange('a.ts', 4, 6);

    // Propose block covering lines 1-10
    const content = Array.from({ length: 10 }, (_, i) => `line ${i + 1}`).join('\n');
    const block = tracker.tryAddBlock('a.ts', 1, 10, 'Block', content);

    expect(block).not.toBeNull();
    // Should have elision marker between the two novel ranges
    expect(block.content).toContain('already in context');
  });

  test('T057: tryAddBlock returns full block when no lines are tracked', () => {
    const content = 'line 1\nline 2\nline 3';
    const block = tracker.tryAddBlock('a.ts', 1, 3, 'Block', content);

    expect(block).not.toBeNull();
    expect(block.content).toBe(content);
    expect(block.startLine).toBe(1);
    expect(block.endLine).toBe(3);
  });
});
