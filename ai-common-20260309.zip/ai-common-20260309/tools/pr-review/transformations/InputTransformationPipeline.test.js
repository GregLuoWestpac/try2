/**
 * Unit tests for InputTransformationPipeline
 */

const InputTransformationPipeline = require('./InputTransformationPipeline');
const DiffContextBuilder = require('./DiffContextBuilder');

describe('InputTransformationPipeline', () => {
  describe('no-op behavior', () => {
    test('T006: is a no-op when config missing', () => {
      const rawDiffText = 'diff --git a/test.js b/test.js';
      const ctx = DiffContextBuilder.buildDiffContext({
        rawDiffText,
        mergeBase: 'abc123',
        head: 'HEAD',
      });

      const pipeline = new InputTransformationPipeline([]);
      const result = pipeline.run(ctx);

      expect(result.rawDiffText).toBe(rawDiffText);
      expect(result.appendedContextBlocks).toEqual([]);
    });

    test('T006: is a no-op when transformations array is empty', () => {
      const rawDiffText = 'diff --git a/test.js b/test.js';
      const ctx = DiffContextBuilder.buildDiffContext({
        rawDiffText,
        mergeBase: 'abc123',
        head: 'HEAD',
      });

      const pipeline = new InputTransformationPipeline([]);
      const result = pipeline.run(ctx);

      expect(result.rawDiffText).toBe(rawDiffText);
    });
  });

  describe('enabled/disabled transformations', () => {
    test('T007: skips disabled transformations', () => {
      const rawDiffText = 'diff --git a/test.js b/test.js';
      const ctx = DiffContextBuilder.buildDiffContext({
        rawDiffText,
        mergeBase: 'abc123',
        head: 'HEAD',
      });

      const mockTransform1 = jest.fn((context) => context);
      const mockTransform2 = jest.fn((context) => context);

      const transformations = [
        {
          id: 'transform1',
          enabled: true,
          transform: mockTransform1,
        },
        {
          id: 'transform2',
          enabled: false,
          transform: mockTransform2,
        },
      ];

      const pipeline = new InputTransformationPipeline(transformations);
      pipeline.run(ctx);

      expect(mockTransform1).toHaveBeenCalledTimes(1);
      expect(mockTransform2).not.toHaveBeenCalled();
    });
  });

  describe('bounded output', () => {
    test('T008: enforces max total appended bytes', () => {
      const rawDiffText = 'diff --git a/test.js b/test.js';
      const ctx = DiffContextBuilder.buildDiffContext({
        rawDiffText,
        mergeBase: 'abc123',
        head: 'HEAD',
      });

      // Create a transform that appends a large block
      const largeContent = 'x'.repeat(10000);
      const mockTransform = jest.fn((context) => {
        context.appendedContextBlocks.push({
          name: 'Large Block',
          file: 'test.js',
          content: largeContent,
        });
        return context;
      });

      const transformations = [
        {
          id: 'largeTransform',
          enabled: true,
          transform: mockTransform,
        },
      ];

      const pipeline = new InputTransformationPipeline(transformations, {
        maxTotalAppendedBytes: 5000,
      });
      const result = pipeline.run(ctx);

      // The output should be limited
      const appendedText = pipeline.formatAppendedBlocks(result.appendedContextBlocks);
      expect(appendedText.length).toBeLessThanOrEqual(5000);
    });

    test('T029: deduplicates identical appendedContextBlocks deterministically', () => {
      const rawDiffText = 'diff --git a/test.js b/test.js';
      const ctx = DiffContextBuilder.buildDiffContext({
        rawDiffText,
        mergeBase: 'abc123',
        head: 'HEAD',
      });

      const block = {
        name: 'Imports',
        file: 'src/a.ts',
        content: 'import x from "y";'
      };

      const t1 = {
        id: 't1',
        enabled: true,
        transform: (c) => {
          c.appendedContextBlocks.push({ ...block });
          return c;
        },
      };

      const t2 = {
        id: 't2',
        enabled: true,
        transform: (c) => {
          c.appendedContextBlocks.push({ ...block });
          return c;
        },
      };

      const pipeline = new InputTransformationPipeline([t1, t2]);
      const result = pipeline.run(ctx);

      expect(result.appendedContextBlocks).toHaveLength(1);
      expect(result.appendedContextBlocks[0]).toEqual(block);

      const finalText = pipeline.getFinalDiffText(result);
      expect(finalText.split('--- Related Context:').length - 1).toBe(1);
    });

    test('T030: deduplication preserves order (first occurrence wins)', () => {
      const rawDiffText = 'diff --git a/test.js b/test.js';
      const ctx = DiffContextBuilder.buildDiffContext({
        rawDiffText,
        mergeBase: 'abc123',
        head: 'HEAD',
      });

      const blockA = { name: 'A', file: 'a', content: '1' };
      const blockB = { name: 'B', file: 'b', content: '2' };

      const t1 = { id: 't1', transform: (c) => (c.appendedContextBlocks.push(blockA), c) };
      const t2 = { id: 't2', transform: (c) => (c.appendedContextBlocks.push(blockB), c) };
      const t3 = { id: 't3', transform: (c) => (c.appendedContextBlocks.push({ ...blockA }), c) };

      const pipeline = new InputTransformationPipeline([t1, t2, t3]);
      const result = pipeline.run(ctx);

      expect(result.appendedContextBlocks).toEqual([blockA, blockB]);
    });

    test('T055: merges overlapping blocks from different transformers', () => {
      const rawDiffText = 'diff --git a/test.js b/test.js';
      const ctx = DiffContextBuilder.buildDiffContext({
        rawDiffText,
        mergeBase: 'abc123',
        head: 'HEAD',
      });

      // Two transformers add overlapping blocks for the same file
      const t1 = {
        id: 't1',
        transform: (c) => {
          c.appendedContextBlocks.push({
            name: 'Func A',
            file: 'src/a.ts',
            startLine: 1,
            endLine: 10,
            content: 'line1\nline2\nline3\nline4\nline5\nline6\nline7\nline8\nline9\nline10',
          });
          return c;
        },
      };

      const t2 = {
        id: 't2',
        transform: (c) => {
          c.appendedContextBlocks.push({
            name: 'Func B',
            file: 'src/a.ts',
            startLine: 8,
            endLine: 15,
            content: 'line8\nline9\nline10\nline11\nline12\nline13\nline14\nline15',
          });
          return c;
        },
      };

      const pipeline = new InputTransformationPipeline([t1, t2]);
      const result = pipeline.run(ctx);

      // Overlapping blocks should be merged into one
      const blocksForA = result.appendedContextBlocks.filter((b) => b.file === 'src/a.ts');
      expect(blocksForA).toHaveLength(1);
      expect(blocksForA[0].startLine).toBe(1);
      expect(blocksForA[0].endLine).toBe(15);
      expect(blocksForA[0].name).toContain('Func A');
      expect(blocksForA[0].name).toContain('Func B');
    });

    test('T056: does not merge non-overlapping blocks', () => {
      const rawDiffText = 'diff --git a/test.js b/test.js';
      const ctx = DiffContextBuilder.buildDiffContext({
        rawDiffText,
        mergeBase: 'abc123',
        head: 'HEAD',
      });

      const t1 = {
        id: 't1',
        transform: (c) => {
          c.appendedContextBlocks.push({
            name: 'Block A',
            file: 'src/a.ts',
            startLine: 1,
            endLine: 5,
            content: 'a\nb\nc\nd\ne',
          });
          c.appendedContextBlocks.push({
            name: 'Block B',
            file: 'src/a.ts',
            startLine: 20,
            endLine: 25,
            content: 'f\ng\nh\ni\nj\nk',
          });
          return c;
        },
      };

      const pipeline = new InputTransformationPipeline([t1]);
      const result = pipeline.run(ctx);

      const blocksForA = result.appendedContextBlocks.filter((b) => b.file === 'src/a.ts');
      expect(blocksForA).toHaveLength(2);
    });

    test('T057: pipeline auto-creates lineTracker when missing', () => {
      const rawDiffText = 'diff --git a/test.js b/test.js';
      const ctx = DiffContextBuilder.buildDiffContext({
        rawDiffText,
        mergeBase: 'abc123',
        head: 'HEAD',
      });

      // Ensure lineTracker is initially present from builder,
      // remove it to test auto-creation
      delete ctx.lineTracker;
      expect(ctx.lineTracker).toBeUndefined();

      const mockTransform = jest.fn((context) => {
        // lineTracker should have been created by pipeline
        expect(context.lineTracker).toBeDefined();
        expect(typeof context.lineTracker.tryAddBlock).toBe('function');
        return context;
      });

      const pipeline = new InputTransformationPipeline([
        { id: 't1', enabled: true, transform: mockTransform },
      ]);
      pipeline.run(ctx);

      expect(mockTransform).toHaveBeenCalledTimes(1);
    });

    test('T027: enforces per-file appended byte limit', () => {
      const rawDiffText = 'diff --git a/test.js b/test.js';
      const ctx = DiffContextBuilder.buildDiffContext({
        rawDiffText,
        mergeBase: 'abc123',
        head: 'HEAD',
      });

      const t1 = {
        id: 't1',
        transform: (c) => {
          c.appendedContextBlocks.push({ name: 'X', file: 'a.ts', content: 'x'.repeat(1000) });
          c.appendedContextBlocks.push({ name: 'Y', file: 'a.ts', content: 'y'.repeat(1000) });
          c.appendedContextBlocks.push({ name: 'Z', file: 'b.ts', content: 'z'.repeat(1000) });
          return c;
        },
      };

      const pipeline = new InputTransformationPipeline([t1], {
        maxAppendedBytesPerFile: 1200,
        maxTotalAppendedBytes: 100000,
      });

      const result = pipeline.run(ctx);
      const fileABytes = Buffer.byteLength(
        pipeline.formatAppendedBlocks(result.appendedContextBlocks.filter((b) => b.file === 'a.ts')),
        'utf-8'
      );
      expect(fileABytes).toBeLessThanOrEqual(1200);
    });
  });
});
