/**
 * functionBoundaryExpansion - Adds full enclosing function context
 */

const GitTextProvider = require('./GitTextProvider');

class FunctionBoundaryExpansion {
  /**
   * Transform context by adding function boundary information
   */
  static transform(ctx, config = {}) {
    const maxFunctionLines = config.maxFunctionLines || 200;
    const fallbackContextLines = config.fallbackContextLines || 20;

    for (const file of ctx.files) {
      // Only process JS/TS files
      if (!this.isJavaScriptFile(file.languageId)) {
        continue;
      }

      // Skip new files — the diff already contains the full file content
      if (file.isNewFile) {
        continue;
      }

      // Prefer already-populated afterText from DiffContextBuilder
      const afterText = file.afterText || new GitTextProvider(ctx.mergeBase, ctx.head).getAfterText(file.path);
      if (!afterText) {
        continue;
      }

      file.afterText = afterText;

      // Track which functions/windows we've already added for this file
      // (kept as fast-path dedup; lineTracker provides cross-transformer dedup)
      const addedFunctions = new Set();
      const addedWindows = new Set();

      for (const hunk of file.hunks) {
        // Find changed lines in this hunk
        const changedLines = this.extractChangedLines(hunk);
        
        for (const lineNum of changedLines) {
          // Try to find enclosing function
          const funcInfo = this.findEnclosingFunction(afterText, lineNum);
          
          if (funcInfo && funcInfo.lineCount <= maxFunctionLines) {
            // Deduplicate by function start line
            const funcKey = `${funcInfo.startLine}`;
            if (addedFunctions.has(funcKey)) continue;
            addedFunctions.add(funcKey);

            const block = ctx.lineTracker.tryAddBlock(
              file.path,
              funcInfo.startLine,
              funcInfo.endLine,
              `Function Boundary (${funcInfo.name})`,
              funcInfo.content
            );

            if (block) {
              ctx.appendedContextBlocks.push(block);
            }
          } else {
            // Deduplicate fallback windows by their start line (quantized)
            const windowStart = Math.max(0, lineNum - fallbackContextLines);
            const windowKey = `${windowStart}`;
            if (addedWindows.has(windowKey)) continue;
            addedWindows.add(windowKey);

            const windowContext = this.extractWindowContext(
              afterText,
              lineNum,
              fallbackContextLines
            );
            const wStartLine = Math.max(1, lineNum - fallbackContextLines);
            const wEndLine = Math.min(afterText.split('\n').length, lineNum + fallbackContextLines);

            const block = ctx.lineTracker.tryAddBlock(
              file.path,
              wStartLine,
              wEndLine,
              'Fallback Context',
              windowContext
            );

            if (block) {
              ctx.appendedContextBlocks.push(block);
            }
          }
        }
      }
    }

    return ctx;
  }

  /**
   * Check if file is JavaScript/TypeScript
   */
  static isJavaScriptFile(languageId) {
    return ['javascript', 'javascriptreact', 'typescript', 'typescriptreact'].includes(
      languageId
    );
  }

  /**
   * Extract changed line numbers from a hunk
   */
  static extractChangedLines(hunk) {
    const changedLines = [];
    let currentLine = hunk.newStart;

    for (const line of hunk.lines) {
      if (line.startsWith('+') && !line.startsWith('+++')) {
        changedLines.push(currentLine);
        currentLine++;
      } else if (!line.startsWith('-')) {
        currentLine++;
      }
    }

    return changedLines;
  }

  /**
   * Find enclosing function for a given line number
   */
  static findEnclosingFunction(text, lineNum) {
    const lines = text.split('\n');
    
    if (lineNum > lines.length) {
      return null;
    }

    // Control flow keywords that should not be treated as function names
    const controlFlowKeywords = new Set([
      'if', 'else', 'for', 'while', 'switch', 'try', 'catch', 'finally', 'do',
    ]);

    // Search backward for function declaration
    let funcStartLine = -1;
    let funcName = 'anonymous';
    
    for (let i = lineNum - 1; i >= 0; i--) {
      const line = lines[i];
      
      // Match function declarations
      const funcMatch = line.match(/^\s*(export\s+)?(async\s+)?(function\s+(\w+)|const\s+(\w+)\s*=.*function|(\w+)\s*:\s*function|\(.*\)\s*=>|(\w+)\s*\(.*\)\s*\{)/);
      
      if (funcMatch) {
        const candidateName = funcMatch[4] || funcMatch[5] || funcMatch[6] || funcMatch[7] || 'anonymous';
        // Skip control flow statements mistakenly matched as functions
        if (controlFlowKeywords.has(candidateName)) {
          continue;
        }
        funcStartLine = i;
        funcName = candidateName;
        break;
      }
    }

    if (funcStartLine === -1) {
      return null;
    }

    // Find matching closing brace
    let braceCount = 0;
    let funcEndLine = -1;
    
    for (let i = funcStartLine; i < lines.length; i++) {
      const line = lines[i];
      
      for (const char of line) {
        if (char === '{') braceCount++;
        if (char === '}') braceCount--;
        
        if (braceCount === 0 && i > funcStartLine) {
          funcEndLine = i;
          break;
        }
      }
      
      if (funcEndLine !== -1) break;
    }

    if (funcEndLine === -1) {
      return null;
    }

    const lineCount = funcEndLine - funcStartLine + 1;
    const content = lines.slice(funcStartLine, funcEndLine + 1).join('\n');

    return {
      name: funcName,
      lineCount,
      content,
      startLine: funcStartLine + 1,
      endLine: funcEndLine + 1,
    };
  }

  /**
   * Extract a window of context around a line
   */
  static extractWindowContext(text, lineNum, windowSize) {
    const lines = text.split('\n');
    const startLine = Math.max(0, lineNum - windowSize - 1);
    const endLine = Math.min(lines.length, lineNum + windowSize);
    
    return lines.slice(startLine, endLine).join('\n');
  }
}

module.exports = FunctionBoundaryExpansion;
