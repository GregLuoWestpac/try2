/**
 * Unit tests for functionBoundaryExpansion transformation
 */

const functionBoundaryExpansion = require('./functionBoundaryExpansion');
const DiffContextBuilder = require('./DiffContextBuilder');
const GitTextProvider = require('./GitTextProvider');

jest.mock('./GitTextProvider');

describe('functionBoundaryExpansion', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('T009: appends full enclosing function for changed line', () => {
    const afterText = `const x = 1;

function foo() {
  const a = 1;
  const b = 2;
  const c = 3;
  const d = 4;
  const e = 5;
  const f = 6;
  const g = 7;
  const h = 8;
  return a + b + c + d + e + f + g + h;
}

const y = 2;`;

    const rawDiffText = `diff --git a/src/test.js b/src/test.js
index 1234567..abcdefg 100644
--- a/src/test.js
+++ b/src/test.js
@@ -7,6 +7,7 @@
   const e = 5;
   const f = 6;
+  const f2 = 66;
   const g = 7;`;

    GitTextProvider.mockImplementation(() => ({
      getAfterText: jest.fn(() => afterText),
      getBeforeText: jest.fn(() => ''),
    }));

    const ctx = DiffContextBuilder.buildDiffContext({
      rawDiffText,
      mergeBase: 'abc123',
      head: 'HEAD',
    });

    const config = { maxFunctionLines: 200, fallbackContextLines: 20 };
    const result = functionBoundaryExpansion.transform(ctx, config);

    expect(result.appendedContextBlocks.length).toBeGreaterThan(0);
    const block = result.appendedContextBlocks[0];
    expect(block.content).toContain('function foo()');
    expect(block.content).toContain('return a + b + c + d + e + f + g + h');
  });

  test('T010: skips when function exceeds maxFunctionLines', () => {
    const lines = [];
    lines.push('function largeFunc() {');
    for (let i = 0; i < 250; i++) {
      lines.push(`  const x${i} = ${i};`);
    }
    lines.push('}');
    const afterText = lines.join('\n');

    const rawDiffText = `diff --git a/src/test.js b/src/test.js
@@ -100,6 +100,7 @@
   const x50 = 50;
+  const newLine = 99;
   const x51 = 51;`;

    GitTextProvider.mockImplementation(() => ({
      getAfterText: jest.fn(() => afterText),
      getBeforeText: jest.fn(() => ''),
    }));

    const ctx = DiffContextBuilder.buildDiffContext({
      rawDiffText,
      mergeBase: 'abc123',
      head: 'HEAD',
    });

    const config = { maxFunctionLines: 50, fallbackContextLines: 20 };
    const result = functionBoundaryExpansion.transform(ctx, config);

    // Should fallback to window context
    if (result.appendedContextBlocks.length > 0) {
      const block = result.appendedContextBlocks[0];
      expect(block.name).toContain('Fallback Context');
    }
  });

  test('T011: fallback window excerpt when no function boundary found', () => {
    const afterText = `const x = 1;
const y = 2;
const z = 3;
const a = 4;
const b = 5;`;

    const rawDiffText = `diff --git a/src/test.js b/src/test.js
@@ -2,3 +2,4 @@
 const y = 2;
+const y2 = 22;
 const z = 3;`;

    GitTextProvider.mockImplementation(() => ({
      getAfterText: jest.fn(() => afterText),
      getBeforeText: jest.fn(() => ''),
    }));

    const ctx = DiffContextBuilder.buildDiffContext({
      rawDiffText,
      mergeBase: 'abc123',
      head: 'HEAD',
    });

    const config = { maxFunctionLines: 200, fallbackContextLines: 3 };
    const result = functionBoundaryExpansion.transform(ctx, config);

    expect(result.appendedContextBlocks.length).toBeGreaterThan(0);
    const block = result.appendedContextBlocks[0];
    expect(block.name).toContain('Fallback Context');
    expect(block.content).toBeTruthy();
  });

  test('T012: never alters original diff +/- lines', () => {
    const afterText = 'function foo() {\n  return 1;\n}';
    const rawDiffText = `diff --git a/src/test.js b/src/test.js
@@ -1,2 +1,3 @@
 function foo() {
+  const x = 1;
   return 1;`;

    GitTextProvider.mockImplementation(() => ({
      getAfterText: jest.fn(() => afterText),
      getBeforeText: jest.fn(() => ''),
    }));

    const ctx = DiffContextBuilder.buildDiffContext({
      rawDiffText,
      mergeBase: 'abc123',
      head: 'HEAD',
    });

    const config = { maxFunctionLines: 200, fallbackContextLines: 20 };
    const result = functionBoundaryExpansion.transform(ctx, config);

    // Original diff should be unchanged
    expect(result.rawDiffText).toBe(rawDiffText);
  });

  test('T031: uses file.afterText from context (no extra git read)', () => {
    GitTextProvider.mockImplementation(() => {
      throw new Error('GitTextProvider should not be constructed');
    });

    const afterText = `function foo() {
  const a = 1;
  const b = 2;
  return a + b;
}`;

    const LineInclusionTracker = require('./LineInclusionTracker');
    const ctx = {
      rawDiffText: 'diff --git a/src/a.ts b/src/a.ts',
      mergeBase: 'abc123',
      head: 'HEAD',
      appendedContextBlocks: [],
      lineTracker: new LineInclusionTracker(),
      files: [
        {
          path: 'src/a.ts',
          languageId: 'typescript',
          beforeText: null,
          afterText,
          hunks: [
            {
              newStart: 2,
              lines: ['+  const c = 3;'],
            },
          ],
        },
      ],
    };

    const result = functionBoundaryExpansion.transform(ctx, {
      maxFunctionLines: 200,
      fallbackContextLines: 20,
    });

    expect(GitTextProvider).not.toHaveBeenCalled();
    expect(result.appendedContextBlocks.length).toBeGreaterThan(0);
    expect(result.appendedContextBlocks[0].content).toContain('function foo()');
  });
});
