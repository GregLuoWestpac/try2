#!/bin/bash
#
# MCP DocSearch Server - Reverse HyDE Document Search
# Usage: mcp-docsearch.sh [options]
#
# Options:
#   --transport <type>      Transport: stdio (default) or http
#   --port <number>         HTTP port (default: 3100)
#   --require-auth          Require authentication for HTTP
#   --verbose               Enable verbose logging
#   --help                  Show help
#
# Environment Variables:
#   DOCSEARCH_STORE_PATH          Directory for vector store files (required)
#   DOCSEARCH_EMBEDDING_PROVIDER  Embedding provider: local (default) or openai
#   DOCSEARCH_COMPLETIONS_PROVIDER  Completions provider: copilot (default) or openai
#   OPENAI_API_KEY                Required if using openai providers
#
# Examples:
#   mcp-docsearch.sh
#   mcp-docsearch.sh --verbose
#   mcp-docsearch.sh --transport http --port 3200

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Check if nodemcp dependencies are installed
if [[ ! -d "${SCRIPT_DIR}/nodemcp/node_modules" ]]; then
    echo "Installing nodemcp dependencies..."
    (cd "${SCRIPT_DIR}/nodemcp" && npm install)
fi

# Check if docsearch dependencies are installed
if [[ ! -d "${SCRIPT_DIR}/mcps/docsearch/node_modules" ]]; then
    echo "Installing docsearch dependencies..."
    (cd "${SCRIPT_DIR}/mcps/docsearch" && npm install)
fi

# Run nodemcp with docsearch provider
exec node "${SCRIPT_DIR}/nodemcp/cli.js" --provider "${SCRIPT_DIR}/mcps/docsearch" "$@"
