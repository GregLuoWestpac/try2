#!/bin/bash
#
# MCP Splunk Server - Splunk Search and Analytics
# Usage: mcp-splunk.sh [options]
#
# Options:
#   --transport <type>      Transport: stdio (default) or http
#   --port <number>         HTTP port (default: 3100)
#   --require-auth          Require authentication for HTTP
#   --verbose               Enable verbose logging
#   --help                  Show help
#
# Environment Variables:
#   SPLUNK_HOST              Splunk server URL (e.g., https://splunk.example.com:8089)
#   SPLUNK_USERNAME          Splunk username
#   SPLUNK_PASSWORD          Splunk password
#   SPLUNK_TOKEN             Splunk bearer token (alternative to username/password)
#
# Examples:
#   mcp-splunk.sh
#   mcp-splunk.sh --verbose
#   mcp-splunk.sh --transport http --port 3300

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Check if nodemcp dependencies are installed
if [[ ! -d "${SCRIPT_DIR}/nodemcp/node_modules" ]]; then
    echo "Installing nodemcp dependencies..."
    (cd "${SCRIPT_DIR}/nodemcp" && npm install)
fi

# Run nodemcp with splunk layer only
exec node "${SCRIPT_DIR}/nodemcp/cli.js" --layers splunk "$@"
