#!/usr/bin/env node

/**
 * Mockoon Generator CLI
 *
 * Commands:
 *   from-feature                Full pipeline: Confluence → feature → CAP API → swagger → mockoon
 *   fetch <api-name>            Fetch swagger from Schema Discovery registry
 *   generate <swagger-path>     Generate mockoon-data.json from a swagger file
 *   fetch-and-generate <api>    Fetch swagger then generate mockoon data in one step
 *   validate [mockoon-path]     Validate mockoon-data.json structure
 *
 * Options:
 *   --confluence, -c <url>      Confluence page URL (EXP→CAP mapping page)
 *   --feature, -f <name>        Feature name to generate (e.g., "account-list", "Interest and Tax")
 *   --mapping <file>            Local mapping file instead of Confluence URL (pre-fetched markdown)
 *   --output, -o <path>         Output path for mockoon-data.json (default: api/env/sit-w1c2/mockoon-data.json)
 *   --merge                     Merge into existing mockoon-data.json (default: true)
 *   --replace                   Replace existing routes for same API
 *   --swagger-dir <path>        Directory for fetched swagger files (default: swagger-output/)
 *   --dry-run                   Show what would be generated without writing files
 *   --verbose, -v               Verbose logging
 *   --help, -h                  Show help
 *
 * Usage:
 *   # Full pipeline: Confluence page + feature name → mockoon data
 *   node cli.js from-feature -c "https://confluence.srv.westpac.com.au/pages/viewpage.action?pageId=2296173304" -f "account-list"
 *
 *   # Using a local mapping file instead of Confluence
 *   node cli.js from-feature --mapping confluence-export.md -f "Interest and Tax"
 *
 *   # Direct: already know the CAP API
 *   node cli.js fetch-and-generate cap-prodsvcadm-proddealacctadm-instl-arrngmntsvcng-v1
 *
 *   # Just generate from existing swagger
 *   node cli.js generate swagger-output/wdp-cap-.../openapi.yaml --merge
 */

const path = require('path');
const fs = require('fs');

// ─── Argument Parsing ────────────────────────────────────────────

function parseArgs() {
  const args = process.argv.slice(2);
  const options = {
    command: null,
    target: null,
    confluence: null,
    feature: null,
    mapping: null,
    output: 'api/env/sit-w1c2/mockoon-data.json',
    merge: true,
    replace: false,
    swaggerDir: 'swagger-output',
    dryRun: false,
    verbose: false,
    help: false,
    endpoint: null,
  };

  let positionalIndex = 0;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    switch (arg) {
      case '--confluence':
      case '-c':
        options.confluence = args[++i];
        break;
      case '--feature':
      case '-f':
        options.feature = args[++i];
        break;
      case '--mapping':
        options.mapping = args[++i];
        break;
      case '--output':
      case '-o':
        options.output = args[++i];
        break;
      case '--merge':
        options.merge = true;
        options.replace = false;
        break;
      case '--replace':
        options.replace = true;
        break;
      case '--swagger-dir':
        options.swaggerDir = args[++i];
        break;
      case '--dry-run':
        options.dryRun = true;
        break;
      case '--verbose':
      case '-v':
        options.verbose = true;
        break;
      case '--help':
      case '-h':
        options.help = true;
        break;
      default:
        if (arg.startsWith('--endpoint=')) {
          options.endpoint = arg.split('=')[1];
        } else if (arg.startsWith('--confluence=')) {
          options.confluence = arg.split('=').slice(1).join('=');
        } else if (arg.startsWith('--feature=')) {
          options.feature = arg.split('=').slice(1).join('=');
        } else if (arg.startsWith('--mapping=')) {
          options.mapping = arg.split('=').slice(1).join('=');
        } else if (arg.startsWith('-')) {
          console.error(`Unknown option: ${arg}`);
          options.help = true;
        } else {
          if (positionalIndex === 0) {
            options.command = arg;
          } else if (positionalIndex === 1) {
            options.target = arg;
          }
          positionalIndex++;
        }
        break;
    }
  }

  return options;
}

// ─── Help ────────────────────────────────────────────────────────

function showHelp() {
  console.log(`
Mockoon Generator — Generate mock data from CAP API swagger specs

Usage:
  node cli.js <command> [target] [options]

Commands:
  from-feature                    Full pipeline: Confluence → feature → swagger → mockoon
  fetch <api-name>                Fetch swagger from Schema Discovery registry
  generate <swagger-path>         Generate mockoon-data.json from a swagger file
  fetch-and-generate <api-name>   Fetch then generate in one step
  validate [mockoon-path]         Validate mockoon-data.json structure
  list-features                   List all features from a Confluence mapping page

Options:
  -c, --confluence <url>          Confluence page URL with EXP→CAP mapping
  -f, --feature <name>            Feature name to generate for
  --mapping <file>                Local mapping file (alternative to Confluence URL)
  -o, --output <path>             Output path (default: api/env/sit-w1c2/mockoon-data.json)
  --merge                         Merge into existing file (default)
  --replace                       Replace routes for same API base path
  --swagger-dir <path>            Swagger output dir (default: swagger-output/)
  --endpoint=<name>               Generate only a specific endpoint
  --dry-run                       Preview without writing
  -v, --verbose                   Verbose logging
  -h, --help                      Show this help

Examples:
  # Full pipeline: Confluence + feature → mockoon data
  node cli.js from-feature -c "https://confluence.srv.westpac.com.au/...?pageId=2296173304" -f "account-list"

  # Using local mapping file instead of Confluence
  node cli.js from-feature --mapping confluence-export.md -f "Interest and Tax"

  # List all features from a Confluence page
  node cli.js list-features -c "https://confluence.srv.westpac.com.au/...?pageId=2296173304"

  # Direct: already know the CAP API name
  node cli.js fetch-and-generate cap-prodsvcadm-proddealacctadm-instl-arrngmntsvcng-v1

  # Just generate from existing swagger
  node cli.js generate swagger-output/wdp-cap-.../openapi.yaml --merge

  # Validate
  node cli.js validate api/env/sit-w1c2/mockoon-data.json
`);
}

// ─── Command Handlers ────────────────────────────────────────────

async function handleFromFeature(options) {
  if (!options.confluence && !options.mapping) {
    console.error('Error: Either --confluence <url> or --mapping <file> is required.');
    console.error('Usage: node cli.js from-feature -c <confluence-url> -f <feature-name>');
    process.exit(1);
  }

  if (!options.feature) {
    console.error('Error: --feature <name> is required.');
    console.error('Usage: node cli.js from-feature -c <confluence-url> -f <feature-name>');
    console.error('\nTo see available features, run:');
    console.error('  node cli.js list-features -c <confluence-url>');
    process.exit(1);
  }

  const { resolveFeature } = require('./lib/featureResolver');

  // Step 1: Resolve feature → CAP API
  console.log('📋 Step 1: Resolving feature from mapping...\n');

  let mappingContent = null;
  if (options.mapping) {
    if (!fs.existsSync(options.mapping)) {
      console.error(`Error: Mapping file not found: ${options.mapping}`);
      process.exit(1);
    }
    mappingContent = fs.readFileSync(options.mapping, 'utf8');
  }

  const resolution = await resolveFeature(
    options.confluence || '',
    options.feature,
    {
      repoRoot: process.cwd(),
      verbose: options.verbose,
      mappingContent,
    }
  );

  if (!resolution.success) {
    console.error(`\n❌ ${resolution.error}`);
    process.exit(1);
  }

  console.log(`   Feature:      ${resolution.feature}`);
  console.log(`   CAP API:      ${resolution.capApi}`);
  console.log(`   CAP Endpoint: ${resolution.capEndpoint}`);
  console.log(`   EXP Endpoint: ${resolution.expEndpoint}`);
  console.log(`   Method:       ${resolution.method}`);

  // Step 2: Fetch swagger for the CAP API
  console.log('\n📥 Step 2: Fetching CAP API swagger...\n');

  const { fetchSwagger } = require('./lib/fetchSwagger');
  const fetchResult = await fetchSwagger(resolution.capApi, {
    outputDir: options.swaggerDir,
    verbose: options.verbose,
    dryRun: options.dryRun,
  });

  if (!fetchResult.success) {
    console.error(`\n❌ Swagger fetch failed: ${fetchResult.error}`);
    process.exit(1);
  }

  console.log(`   ✅ Fetched: ${fetchResult.outputPath}`);
  console.log(`   Title: ${fetchResult.metadata.title}`);
  console.log(`   Endpoints: ${fetchResult.metadata.endpoints.length}`);

  // Step 3: Generate mockoon data
  console.log('\n⚙️  Step 3: Generating mockoon data...\n');

  const { generateMockoon } = require('./lib/generateMockoon');
  const genResult = await generateMockoon(fetchResult.outputPath, {
    outputPath: options.output,
    merge: options.merge,
    replace: options.replace,
    endpoint: options.endpoint,
    verbose: options.verbose,
    dryRun: options.dryRun,
  });

  if (!genResult.success) {
    console.error(`\n❌ Generation failed: ${genResult.error}`);
    process.exit(1);
  }

  // Step 4: Report
  console.log(`\n✅ Mockoon data ${genResult.action}: ${options.output}`);
  console.log(`   Feature:   ${resolution.feature}`);
  console.log(`   CAP API:   ${resolution.capApi}`);
  console.log(`   Routes:    ${genResult.routesAdded} added, ${genResult.routesTotal} total`);
  console.log(`   Responses: ${genResult.responsesAdded} generated`);

  if (genResult.triggerValues && genResult.triggerValues.length > 0) {
    console.log(`\n🎯 Test with these trigger values:`);
    genResult.triggerValues.forEach(tv => {
      console.log(`   ${tv.field}: "${tv.value}" → ${tv.scenario}`);
    });
  }

  console.log(`\n💡 Validate: node cli.js validate ${options.output}`);
}

async function handleListFeatures(options) {
  if (!options.confluence && !options.mapping) {
    console.error('Error: Either --confluence <url> or --mapping <file> is required.');
    process.exit(1);
  }

  const { resolveFeature } = require('./lib/featureResolver');

  let mappingContent = null;
  if (options.mapping) {
    if (!fs.existsSync(options.mapping)) {
      console.error(`Error: Mapping file not found: ${options.mapping}`);
      process.exit(1);
    }
    mappingContent = fs.readFileSync(options.mapping, 'utf8');
  }

  const resolution = await resolveFeature(
    options.confluence || '',
    null, // No feature name = list all
    {
      repoRoot: process.cwd(),
      verbose: options.verbose,
      mappingContent,
    }
  );

  if (!resolution.success && !resolution.allMappings) {
    console.error(`\n❌ ${resolution.error}`);
    process.exit(1);
  }

  const mappings = resolution.allMappings || [];
  console.log(`\n📋 Found ${mappings.length} features:\n`);
  console.log('  Feature                          │ CAP API                              │ Endpoint');
  console.log('  ─────────────────────────────────┼──────────────────────────────────────┼─────────────');

  for (const m of mappings) {
    const feature = (m.feature || m.expEndpoint || '?').padEnd(33);
    const capApi = (m.capApi || '?').padEnd(37);
    const endpoint = m.capEndpoint || '?';
    console.log(`  ${feature}│ ${capApi}│ ${endpoint}`);
  }

  console.log(`\n💡 Generate: node cli.js from-feature -c <url> -f "<feature-name>"`);
}

async function handleFetch(options) {
  if (!options.target) {
    console.error('Error: API name required. Usage: node cli.js fetch <api-name>');
    process.exit(1);
  }

  const { fetchSwagger } = require('./lib/fetchSwagger');
  const result = await fetchSwagger(options.target, {
    outputDir: options.swaggerDir,
    verbose: options.verbose,
    dryRun: options.dryRun,
  });

  if (result.success) {
    console.log(`\n✅ Swagger saved: ${result.outputPath}`);
    console.log(`📌 Title: ${result.metadata.title}`);
    console.log(`🔢 Version: ${result.metadata.version}`);
    console.log(`📍 Base Path: ${result.metadata.basePath}`);
    console.log(`🔗 Endpoints (${result.metadata.endpoints.length}):`);
    result.metadata.endpoints.forEach(ep => console.log(`     ${ep}`));
    console.log(`\n💡 Next: node cli.js generate ${result.outputPath}`);
  } else {
    console.error(`\n❌ Failed: ${result.error}`);
    process.exit(1);
  }
}

async function handleGenerate(options) {
  if (!options.target) {
    console.error('Error: Swagger file path required. Usage: node cli.js generate <swagger-path>');
    process.exit(1);
  }

  if (!fs.existsSync(options.target)) {
    console.error(`Error: Swagger file not found: ${options.target}`);
    process.exit(1);
  }

  const { generateMockoon } = require('./lib/generateMockoon');
  const result = await generateMockoon(options.target, {
    outputPath: options.output,
    merge: options.merge,
    replace: options.replace,
    endpoint: options.endpoint,
    verbose: options.verbose,
    dryRun: options.dryRun,
  });

  if (result.success) {
    console.log(`\n✅ Mockoon data ${result.action}: ${options.output}`);
    console.log(`📊 Routes: ${result.routesAdded} added, ${result.routesTotal} total`);
    console.log(`📋 Responses: ${result.responsesAdded} generated`);

    if (result.triggerValues && result.triggerValues.length > 0) {
      console.log(`\n🎯 Test with these trigger values:`);
      result.triggerValues.forEach(tv => {
        console.log(`   ${tv.field}: "${tv.value}" → ${tv.scenario}`);
      });
    }
  } else {
    console.error(`\n❌ Failed: ${result.error}`);
    process.exit(1);
  }
}

async function handleFetchAndGenerate(options) {
  if (!options.target) {
    console.error('Error: API name required. Usage: node cli.js fetch-and-generate <api-name>');
    process.exit(1);
  }

  console.log('📥 Step 1: Fetching swagger...\n');
  const { fetchSwagger } = require('./lib/fetchSwagger');
  const fetchResult = await fetchSwagger(options.target, {
    outputDir: options.swaggerDir,
    verbose: options.verbose,
    dryRun: options.dryRun,
  });

  if (!fetchResult.success) {
    console.error(`\n❌ Fetch failed: ${fetchResult.error}`);
    process.exit(1);
  }

  console.log(`✅ Fetched: ${fetchResult.outputPath}\n`);
  console.log('⚙️  Step 2: Generating mockoon data...\n');
  options.target = fetchResult.outputPath;
  await handleGenerate(options);
}

async function handleValidate(options) {
  const mockoonPath = options.target || options.output;

  if (!fs.existsSync(mockoonPath)) {
    console.error(`Error: File not found: ${mockoonPath}`);
    process.exit(1);
  }

  const { validateMockoon } = require('./lib/validateMockoon');
  const result = validateMockoon(mockoonPath, { verbose: options.verbose });

  if (result.valid) {
    console.log(`\n✅ Valid mockoon-data.json`);
    console.log(`   Routes: ${result.stats.routes}`);
    console.log(`   Responses: ${result.stats.responses}`);
    console.log(`   Rules: ${result.stats.rules}`);
    if (result.warnings.length > 0) {
      console.log(`\n⚠️  Warnings:`);
      result.warnings.forEach(w => console.log(`   • ${w}`));
    }
  } else {
    console.error(`\n❌ Validation failed:`);
    result.errors.forEach(err => console.error(`   • ${err}`));
    process.exit(1);
  }
}

// ─── Main ────────────────────────────────────────────────────────

async function main() {
  const options = parseArgs();

  if (options.help || !options.command) {
    showHelp();
    process.exit(options.help ? 0 : 1);
  }

  switch (options.command) {
    case 'from-feature':
      await handleFromFeature(options);
      break;
    case 'list-features':
      await handleListFeatures(options);
      break;
    case 'fetch':
      await handleFetch(options);
      break;
    case 'generate':
      await handleGenerate(options);
      break;
    case 'fetch-and-generate':
      await handleFetchAndGenerate(options);
      break;
    case 'validate':
      await handleValidate(options);
      break;
    default:
      console.error(`Unknown command: ${options.command}`);
      showHelp();
      process.exit(1);
  }
}

if (require.main === module) {
  main().catch(err => {
    console.error(`\n❌ Fatal: ${err.message}`);
    if (process.env.DEBUG) console.error(err.stack);
    process.exit(1);
  });
}

module.exports = { parseArgs, showHelp };