/**
 * NodeMCP - Model Context Protocol Server Framework
 * 
 * Main entry point for programmatic usage.
 * 
 * Features:
 * - Full MCP protocol support (2025-06-18)
 * - Middleware pipeline for request processing
 * - Resource subscriptions and notifications
 * - Background task execution (SEP-1686)
 * - Context system for bidirectional communication
 * - JWT and API key authentication
 * - Testing utilities
 */

// Core
const MCPServer = require('./core/MCPServer');
const ProviderManager = require('./core/ProviderManager');
const BaseProvider = require('./core/BaseProvider');
const SessionManager = require('./core/SessionManager');
const SubscriptionManager = require('./core/SubscriptionManager');
const { TaskManager, Task, TaskStatus } = require('./core/TaskManager');
const Context = require('./core/Context');

// Transports
const StdioTransport = require('./transports/StdioTransport');
const HttpTransport = require('./transports/HttpTransport');

// Middleware
const {
  MiddlewareManager,
  LoggingMiddleware,
  RateLimitMiddleware,
  ErrorMiddleware,
  MetricsMiddleware,
  MCPError,
  ValidationError,
  NotFoundError,
  AuthError,
} = require('./core/middleware');

// Authentication
const {
  BaseAuthProvider,
  JWTAuthProvider,
  APIKeyAuthProvider,
  AuthMiddleware,
} = require('./core/auth');

// Completions
const {
  BaseCompletionsProvider,
  CopilotCliCompletionsProvider,
  OpenAICompletionsProvider,
  createCompletionsProvider,
  getAvailableProviders: getAvailableCompletionsProviders,
} = require('./core/completions');

// Helpers
const helpers = require('./core/helpers');

// Testing utilities
const testing = require('./test/index');

module.exports = {
  // Core
  MCPServer,
  ProviderManager,
  BaseProvider,
  SessionManager,
  SubscriptionManager,
  TaskManager,
  Task,
  TaskStatus,
  Context,
  
  // Transports
  StdioTransport,
  HttpTransport,
  
  // Middleware
  MiddlewareManager,
  LoggingMiddleware,
  RateLimitMiddleware,
  ErrorMiddleware,
  MetricsMiddleware,
  MCPError,
  ValidationError,
  NotFoundError,
  AuthError,
  
  // Authentication
  BaseAuthProvider,
  JWTAuthProvider,
  APIKeyAuthProvider,
  AuthMiddleware,
  
  // Completions
  BaseCompletionsProvider,
  CopilotCliCompletionsProvider,
  OpenAICompletionsProvider,
  createCompletionsProvider,
  getAvailableCompletionsProviders,
  
  // Helpers
  helpers,
  ...helpers,
  
  // Testing
  testing,
};

