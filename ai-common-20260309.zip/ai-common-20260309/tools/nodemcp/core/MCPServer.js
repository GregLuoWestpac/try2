/**
 * MCP Server Core
 * 
 * Implements the Model Context Protocol server following the 2025-06-18 specification.
 * Handles JSON-RPC 2.0 messages, lifecycle management, and capability negotiation.
 * 
 * Features:
 * - Full middleware pipeline support
 * - Resource subscriptions
 * - Background task execution (SEP-1686)
 * - Context system for bidirectional communication
 * - Batch request support
 */

const { v4: uuidv4 } = require('uuid');
const SessionManager = require('./SessionManager');
const SubscriptionManager = require('./SubscriptionManager');
const { TaskManager } = require('./TaskManager');
const { MiddlewareManager } = require('./middleware');
const Context = require('./Context');

const PROTOCOL_VERSION = '2025-06-18';

class MCPServer {
  constructor(options = {}) {
    this.name = options.name || 'nodemcp';
    this.version = options.version || '1.0.0';
    this.providerManager = options.providerManager;
    this.verbose = options.verbose || false;
    
    // Core managers
    this.sessionManager = new SessionManager({ verbose: this.verbose });
    this.subscriptionManager = new SubscriptionManager({ verbose: this.verbose });
    this.middlewareManager = new MiddlewareManager({ verbose: this.verbose });
    this.taskManager = new TaskManager({
      verbose: this.verbose,
      notifyFn: (notification, sessionId) => this.sendNotificationToSession(notification, sessionId),
    });
    
    this.transport = null;
    this.initialized = false;
    this.negotiatedVersion = null;
    this.clientCapabilities = {};
    this.pendingResponses = new Map(); // For tracking server-initiated requests
    
    this.log = this.verbose 
      ? (...args) => console.error('[MCPServer]', ...args)
      : () => {};
  }

  /**
   * Add middleware to the request pipeline
   */
  use(middleware) {
    this.middlewareManager.use(middleware);
    return this;
  }

  /**
   * Start the MCP server with the given transport
   */
  async start(transport) {
    this.transport = transport;
    
    // Set up message handler
    this.transport.onMessage(async (message, context) => {
      return this.handleMessage(message, context);
    });

    // Start the transport
    await this.transport.start();
    
    this.log('MCP server started');
  }

  /**
   * Stop the MCP server
   */
  async stop() {
    // Shutdown task manager
    await this.taskManager.shutdown();
    
    // Shutdown providers
    if (this.providerManager) {
      await this.providerManager.shutdown();
    }
    
    // Stop transport
    if (this.transport) {
      await this.transport.stop();
    }
    
    // Destroy all sessions
    await this.sessionManager.destroyAllSessions();
    
    // Clear subscriptions
    this.subscriptionManager.clear();
    
    this.log('MCP server stopped');
  }

  /**
   * Handle incoming JSON-RPC message (supports batch requests)
   */
  async handleMessage(message, context = {}) {
    this.log('Received message:', JSON.stringify(message).substring(0, 200));

    // Handle batch requests
    if (Array.isArray(message)) {
      const responses = await Promise.all(
        message.map(msg => this.handleSingleMessage(msg, context))
      );
      // Filter out null responses (from notifications)
      return responses.filter(r => r !== null);
    }

    return this.handleSingleMessage(message, context);
  }

  /**
   * Handle a single JSON-RPC message
   */
  async handleSingleMessage(message, context = {}) {
    // Validate JSON-RPC format
    if (message.jsonrpc !== '2.0') {
      return this.createError(message.id, -32600, 'Invalid Request: must be JSON-RPC 2.0');
    }

    // Handle notification (no response expected)
    if (message.id === undefined && message.method) {
      await this.handleNotification(message, context);
      return null;
    }

    // Handle request
    if (message.method) {
      const response = await this.handleRequest(message, context);
      this.log('Sending response:', JSON.stringify(response).substring(0, 500));
      return response;
    }

    // Handle response (from client to server requests)
    if (message.result !== undefined || message.error !== undefined) {
      this.handleResponse(message, context);
      return null;
    }

    return this.createError(message.id, -32600, 'Invalid Request');
  }

  /**
   * Handle JSON-RPC request
   */
  async handleRequest(request, context) {
    const { id, method, params = {} } = request;

    // Execute through middleware pipeline
    return this.middlewareManager.execute(request, context, async (req, ctx) => {
      return this.routeRequest(req, ctx);
    });
  }

  /**
   * Route request to appropriate handler
   */
  async routeRequest(request, context) {
    const { id, method, params = {} } = request;

    try {
      switch (method) {
        case 'initialize':
          return this.handleInitialize(id, params, context);
        
        case 'shutdown':
          return this.handleShutdown(id, params, context);
        
        case 'ping':
          return this.createResult(id, {});
        
        case 'tools/list':
          return this.handleToolsList(id, params, context);
        
        case 'tools/call':
          return this.handleToolsCall(id, params, context);
        
        case 'resources/list':
          return this.handleResourcesList(id, params, context);
        
        case 'resources/read':
          return this.handleResourcesRead(id, params, context);
        
        case 'resources/templates/list':
          return this.handleResourceTemplatesList(id, params, context);
        
        case 'resources/subscribe':
          return this.handleResourceSubscribe(id, params, context);
        
        case 'resources/unsubscribe':
          return this.handleResourceUnsubscribe(id, params, context);
        
        case 'prompts/list':
          return this.handlePromptsList(id, params, context);
        
        case 'prompts/get':
          return this.handlePromptsGet(id, params, context);
        
        case 'tasks/create':
          return this.handleTaskCreate(id, params, context);
        
        case 'tasks/get':
          return this.handleTaskGet(id, params, context);
        
        case 'tasks/list':
          return this.handleTaskList(id, params, context);
        
        case 'tasks/cancel':
          return this.handleTaskCancel(id, params, context);
        
        case 'logging/setLevel':
          return this.handleLoggingSetLevel(id, params, context);
        
        default:
          return this.createError(id, -32601, `Method not found: ${method}`);
      }
    } catch (error) {
      this.log('Error handling request:', error);
      return this.createError(id, -32603, `Internal error: ${error.message}`);
    }
  }

  /**
   * Handle notification (no response)
   */
  async handleNotification(notification, context) {
    const { method, params = {} } = notification;

    switch (method) {
      case 'initialized':
      case 'notifications/initialized':
        this.log('Client initialized');
        break;
      
      case 'notifications/cancelled':
        // Handle cancellation - cancel any pending task
        this.log('Request cancelled:', params.requestId);
        if (params.requestId) {
          this.taskManager.cancelTask(params.requestId);
        }
        break;
      
      case 'notifications/roots/listChanged':
        this.log('Roots list changed');
        break;
      
      default:
        this.log('Unknown notification:', method);
    }
  }

  /**
   * Handle response from client (for server-initiated requests like sampling)
   */
  handleResponse(response, context) {
    const pending = this.pendingResponses.get(response.id);
    if (pending) {
      this.pendingResponses.delete(response.id);
      if (response.error) {
        pending.reject(new Error(response.error.message));
      } else {
        pending.resolve(response.result);
      }
    }
    this.log('Received response:', response.id);
  }

  /**
   * Handle shutdown request
   */
  async handleShutdown(id, params, context) {
    this.log('Shutdown requested');
    
    // Clean up session resources
    if (context.sessionId) {
      this.subscriptionManager.unsubscribeAll(context.sessionId);
      this.sessionManager.destroySession(context.sessionId);
    }
    
    return this.createResult(id, { success: true });
  }

  /**
   * Handle initialize request
   */
  async handleInitialize(id, params, context) {
    const { protocolVersion, capabilities = {}, clientInfo = {} } = params;

    this.log('Initialize request from:', clientInfo.name, clientInfo.version);
    this.log('Client capabilities:', JSON.stringify(capabilities));

    // Store client capabilities for feature negotiation
    this.clientCapabilities = capabilities;

    // Version negotiation - we support 2025-06-18
    const supportedVersions = ['2025-06-18', '2025-03-26', '2024-11-05'];
    this.negotiatedVersion = supportedVersions.includes(protocolVersion) 
      ? protocolVersion 
      : PROTOCOL_VERSION;

    // Create session for HTTP transport
    let sessionId = null;
    if (this.transport.type === 'http') {
      sessionId = uuidv4();
      this.sessionManager.createSession(sessionId);
      context.sessionId = sessionId;
    }

    // Build server capabilities based on what we support
    const serverCapabilities = {
      tools: {
        listChanged: true,
      },
      resources: {
        subscribe: true,
        listChanged: true,
      },
      prompts: {
        listChanged: true,
      },
      logging: {},
    };

    // Add experimental capabilities (tasks is not in standard spec)
    const experimental = {};
    
    // Add tasks capability if enabled (under experimental per MCP spec)
    if (this.taskManager) {
      experimental.tasks = {
        create: true,
        list: true,
        get: true,
        cancel: true,
      };
    }

    // Only add experimental if there are experimental capabilities
    if (Object.keys(experimental).length > 0) {
      serverCapabilities.experimental = experimental;
    }

    // Add sampling capability if client supports it
    if (capabilities.sampling) {
      serverCapabilities.sampling = {};
    }

    this.initialized = true;

    const result = {
      protocolVersion: this.negotiatedVersion,
      capabilities: serverCapabilities,
      serverInfo: {
        name: this.name,
        version: this.version,
      },
    };

    // Include session ID in response for HTTP transport
    const response = this.createResult(id, result);
    if (sessionId) {
      response._sessionId = sessionId;
    }

    return response;
  }

  /**
   * Handle tools/list request
   */
  async handleToolsList(id, params, context) {
    const allTools = this.providerManager.getAllTools();
    
    return this.createResult(id, {
      tools: allTools.map(tool => ({
        name: tool.name,
        description: tool.description,
        inputSchema: tool.inputSchema,
      })),
    });
  }

  /**
   * Handle tools/call request
   */
  async handleToolsCall(id, params, context) {
    const { name, arguments: args = {} } = params;

    // Find the tool
    const toolInfo = this.providerManager.findTool(name);
    if (!toolInfo) {
      return this.createError(id, -32602, `Tool not found: ${name}`);
    }

    const { provider, tool } = toolInfo;

    // Get or create session for stateful providers
    let session = null;
    if (provider.isStateful()) {
      session = this.sessionManager.getSession(context.sessionId);
      if (!session) {
        session = this.sessionManager.createSession(context.sessionId || uuidv4());
      }
    }

    // Create context for the tool
    const toolContext = new Context({
      session,
      transport: this.transport,
      sessionId: context.sessionId,
      requestId: id,
      verbose: this.verbose,
    });

    try {
      // Execute the tool
      const result = await tool.handler(args, {
        session,
        provider,
        sessionManager: this.sessionManager,
        context: toolContext,
        ctx: toolContext, // Alias for convenience
      });

      return this.createResult(id, {
        content: Array.isArray(result?.content) ? result.content : [
          {
            type: 'text',
            text: typeof result === 'string' ? result : JSON.stringify(result, null, 2),
          },
        ],
        ...(result?.isError && { isError: true }),
        ...(result?.structuredContent && { structuredContent: result.structuredContent }),
      });
    } catch (error) {
      this.log('Tool execution error:', error);
      return this.createResult(id, {
        content: [
          {
            type: 'text',
            text: `Error: ${error.message}`,
          },
        ],
        isError: true,
      });
    }
  }

  /**
   * Handle resources/list request
   */
  async handleResourcesList(id, params, context) {
    const allResources = this.providerManager.getAllResources();
    
    // Filter out templates - only return static resources
    const staticResources = allResources.filter(r => r.uri && !r.uriTemplate);
    
    return this.createResult(id, {
      resources: staticResources,
    });
  }

  /**
   * Handle resources/templates/list request
   */
  async handleResourceTemplatesList(id, params, context) {
    const allResources = this.providerManager.getAllResources();
    
    // Filter to only templates
    const templates = allResources.filter(r => r.uriTemplate);
    
    return this.createResult(id, {
      resourceTemplates: templates.map(r => ({
        uriTemplate: r.uriTemplate,
        name: r.name,
        description: r.description,
        mimeType: r.mimeType,
      })),
    });
  }

  /**
   * Handle resources/read request
   */
  async handleResourcesRead(id, params, context) {
    const { uri } = params;

    const resourceInfo = this.providerManager.findResource(uri);
    if (!resourceInfo) {
      return this.createError(id, -32602, `Resource not found: ${uri}`);
    }

    const { provider, resource } = resourceInfo;

    try {
      const content = await resource.handler(uri, { provider });
      
      return this.createResult(id, {
        contents: Array.isArray(content) ? content : [content],
      });
    } catch (error) {
      return this.createError(id, -32603, `Error reading resource: ${error.message}`);
    }
  }

  /**
   * Handle resources/subscribe request
   */
  async handleResourceSubscribe(id, params, context) {
    const { uri } = params;

    if (!context.sessionId) {
      return this.createError(id, -32602, 'Subscriptions require a session');
    }

    // Verify resource exists
    const resourceInfo = this.providerManager.findResource(uri);
    if (!resourceInfo) {
      return this.createError(id, -32602, `Resource not found: ${uri}`);
    }

    this.subscriptionManager.subscribe(uri, context.sessionId);
    
    return this.createResult(id, { success: true });
  }

  /**
   * Handle resources/unsubscribe request
   */
  async handleResourceUnsubscribe(id, params, context) {
    const { uri } = params;

    if (!context.sessionId) {
      return this.createError(id, -32602, 'Subscriptions require a session');
    }

    const removed = this.subscriptionManager.unsubscribe(uri, context.sessionId);
    
    return this.createResult(id, { success: removed });
  }

  /**
   * Notify subscribers of a resource change
   */
  async notifyResourceUpdated(uri) {
    await this.subscriptionManager.notifySubscribers(uri, async (sessionId) => {
      await this.sendNotificationToSession({
        jsonrpc: '2.0',
        method: 'notifications/resources/updated',
        params: { uri },
      }, sessionId);
    });
  }

  /**
   * Handle prompts/list request
   */
  async handlePromptsList(id, params, context) {
    const allPrompts = this.providerManager.getAllPrompts();
    
    return this.createResult(id, {
      prompts: allPrompts,
    });
  }

  /**
   * Handle prompts/get request
   */
  async handlePromptsGet(id, params, context) {
    const { name, arguments: args = {} } = params;

    const promptInfo = this.providerManager.findPrompt(name);
    if (!promptInfo) {
      return this.createError(id, -32602, `Prompt not found: ${name}`);
    }

    const { provider, prompt } = promptInfo;

    try {
      const messages = await prompt.handler(args, { provider });
      
      return this.createResult(id, {
        description: prompt.description,
        messages: Array.isArray(messages) ? messages : [messages],
      });
    } catch (error) {
      return this.createError(id, -32603, `Error getting prompt: ${error.message}`);
    }
  }

  /**
   * Handle tasks/create request
   */
  async handleTaskCreate(id, params, context) {
    const { tool, arguments: args = {} } = params;

    // Find the tool
    const toolInfo = this.providerManager.findTool(tool);
    if (!toolInfo) {
      return this.createError(id, -32602, `Tool not found: ${tool}`);
    }

    const { provider, tool: toolDef } = toolInfo;

    // Get or create session
    let session = null;
    if (provider.isStateful()) {
      session = this.sessionManager.getSession(context.sessionId);
      if (!session) {
        session = this.sessionManager.createSession(context.sessionId || uuidv4());
      }
    }

    // Create the task
    const task = this.taskManager.createTask({
      tool,
      arguments: args,
      sessionId: context.sessionId,
      executor: async (taskArgs, taskContext) => {
        // Create context for the tool
        const toolContext = new Context({
          session,
          transport: this.transport,
          sessionId: context.sessionId,
          requestId: taskContext.taskId,
          verbose: this.verbose,
        });

        // Execute the tool
        const result = await toolDef.handler(taskArgs, {
          session,
          provider,
          sessionManager: this.sessionManager,
          context: toolContext,
          ctx: toolContext,
          taskContext, // Includes reportProgress and isCancelled
        });

        return result;
      },
    });

    return this.createResult(id, { taskId: task.id });
  }

  /**
   * Handle tasks/get request
   */
  async handleTaskGet(id, params, context) {
    const { taskId } = params;

    const task = this.taskManager.getTask(taskId);
    if (!task) {
      return this.createError(id, -32602, `Task not found: ${taskId}`);
    }

    return this.createResult(id, { task: task.toJSON() });
  }

  /**
   * Handle tasks/list request
   */
  async handleTaskList(id, params, context) {
    const tasks = this.taskManager.listTasks(context.sessionId);
    
    return this.createResult(id, { tasks });
  }

  /**
   * Handle tasks/cancel request
   */
  async handleTaskCancel(id, params, context) {
    const { taskId } = params;

    const success = this.taskManager.cancelTask(taskId);
    
    return this.createResult(id, { success });
  }

  /**
   * Handle logging/setLevel request
   */
  async handleLoggingSetLevel(id, params, context) {
    const { level } = params;
    
    const validLevels = ['debug', 'info', 'notice', 'warning', 'error', 'critical', 'alert', 'emergency'];
    if (!validLevels.includes(level)) {
      return this.createError(id, -32602, `Invalid log level: ${level}`);
    }

    // Store log level in session
    if (context.sessionId) {
      this.sessionManager.setSessionData(context.sessionId, 'logLevel', level);
    }

    this.log('Log level set to:', level);
    
    return this.createResult(id, { success: true });
  }

  /**
   * Send notification to client
   */
  async sendNotification(method, params = {}) {
    if (this.transport) {
      await this.transport.send({
        jsonrpc: '2.0',
        method,
        params,
      });
    }
  }

  /**
   * Send notification to a specific session
   */
  async sendNotificationToSession(notification, sessionId) {
    if (this.transport) {
      await this.transport.send(notification, sessionId);
    }
  }

  /**
   * Send a request to the client and wait for response
   * Used for server-initiated requests like sampling
   */
  async sendRequest(method, params, sessionId = null, timeout = 30000) {
    if (!this.transport) {
      throw new Error('No transport available');
    }

    const requestId = uuidv4();
    const request = {
      jsonrpc: '2.0',
      id: requestId,
      method,
      params,
    };

    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        this.pendingResponses.delete(requestId);
        reject(new Error('Request timeout'));
      }, timeout);

      this.pendingResponses.set(requestId, {
        resolve: (result) => {
          clearTimeout(timeoutId);
          resolve(result);
        },
        reject: (error) => {
          clearTimeout(timeoutId);
          reject(error);
        },
      });

      this.transport.send(request, sessionId).catch(err => {
        clearTimeout(timeoutId);
        this.pendingResponses.delete(requestId);
        reject(err);
      });
    });
  }

  /**
   * Get the middleware manager for custom configuration
   */
  getMiddlewareManager() {
    return this.middlewareManager;
  }

  /**
   * Get the subscription manager
   */
  getSubscriptionManager() {
    return this.subscriptionManager;
  }

  /**
   * Get the task manager
   */
  getTaskManager() {
    return this.taskManager;
  }

  /**
   * Get the session manager
   */
  getSessionManager() {
    return this.sessionManager;
  }

  /**
   * Create JSON-RPC result response
   */
  createResult(id, result) {
    return {
      jsonrpc: '2.0',
      id,
      result,
    };
  }

  /**
   * Create JSON-RPC error response
   */
  createError(id, code, message, data = undefined) {
    return {
      jsonrpc: '2.0',
      id,
      error: {
        code,
        message,
        ...(data !== undefined && { data }),
      },
    };
  }
}

module.exports = MCPServer;
