/**
 * Base Provider
 * 
 * Abstract base class for all MCP providers.
 * Providers extend this class to add tools, resources, and prompts.
 */

class BaseProvider {
  constructor(options = {}) {
    this.basePath = options.basePath;
    this.verbose = options.verbose || false;
    this.tools = [];
    this.resources = [];
    this.prompts = [];
    this._stateful = false;
    
    this.log = this.verbose
      ? (...args) => console.error(`[${this.constructor.name}]`, ...args)
      : () => {};
  }

  /**
   * Initialize the provider (override in subclass)
   */
  async initialize() {
    // Override in subclass
  }

  /**
   * Shutdown the provider (override in subclass)
   */
  async shutdown() {
    // Override in subclass
  }

  /**
   * Mark this provider as stateful (maintains session state)
   */
  setStateful(stateful) {
    this._stateful = stateful;
  }

  /**
   * Check if this provider is stateful
   */
  isStateful() {
    return this._stateful;
  }

  /**
   * Register a tool
   */
  registerTool(tool) {
    this.validateTool(tool);
    this.tools.push(tool);
    this.log(`Registered tool: ${tool.name}`);
  }

  /**
   * Validate tool definition and normalize the schema
   */
  validateTool(tool) {
    if (!tool.name) {
      throw new Error('Tool must have a name');
    }
    if (!tool.description) {
      throw new Error(`Tool ${tool.name} must have a description`);
    }
    if (!tool.handler || typeof tool.handler !== 'function') {
      throw new Error(`Tool ${tool.name} must have a handler function`);
    }
    if (!tool.inputSchema) {
      tool.inputSchema = { type: 'object', properties: {} };
    }

    // Normalize schema: move property-level "required: true" to object-level "required" array
    this.normalizeSchema(tool.inputSchema);
  }

  /**
   * Normalize JSON Schema to be MCP-compliant
   * Moves property-level "required: true" to the object's "required" array
   */
  normalizeSchema(schema) {
    if (!schema || schema.type !== 'object' || !schema.properties) {
      return;
    }

    const requiredFields = [];

    for (const [propName, propSchema] of Object.entries(schema.properties)) {
      if (propSchema && propSchema.required === true) {
        requiredFields.push(propName);
        delete propSchema.required;
      }
      // Also remove "required: false" if present
      if (propSchema && propSchema.required === false) {
        delete propSchema.required;
      }
    }

    // Merge with existing required array if present
    if (requiredFields.length > 0) {
      const existingRequired = Array.isArray(schema.required) ? schema.required : [];
      schema.required = [...new Set([...existingRequired, ...requiredFields])];
    }
  }

  /**
   * Register a resource
   */
  registerResource(resource) {
    this.validateResource(resource);
    this.resources.push(resource);
    this.log(`Registered resource: ${resource.uri || resource.uriTemplate}`);
  }

  /**
   * Validate resource definition
   */
  validateResource(resource) {
    if (!resource.uri && !resource.uriTemplate) {
      throw new Error('Resource must have a uri or uriTemplate');
    }
    if (!resource.name) {
      throw new Error('Resource must have a name');
    }
    if (!resource.handler || typeof resource.handler !== 'function') {
      throw new Error(`Resource ${resource.name} must have a handler function`);
    }
  }

  /**
   * Register a prompt
   */
  registerPrompt(prompt) {
    this.validatePrompt(prompt);
    this.prompts.push(prompt);
    this.log(`Registered prompt: ${prompt.name}`);
  }

  /**
   * Validate prompt definition
   */
  validatePrompt(prompt) {
    if (!prompt.name) {
      throw new Error('Prompt must have a name');
    }
    if (!prompt.handler || typeof prompt.handler !== 'function') {
      throw new Error(`Prompt ${prompt.name} must have a handler function`);
    }
  }

  /**
   * Get all registered tools
   */
  getTools() {
    return this.tools;
  }

  /**
   * Get all registered resources
   */
  getResources() {
    return this.resources;
  }

  /**
   * Get all registered prompts
   */
  getPrompts() {
    return this.prompts;
  }

  /**
   * Create a tool definition helper
   */
  createTool(name, description, inputSchema, handler) {
    return {
      name,
      description,
      inputSchema: {
        type: 'object',
        ...inputSchema,
      },
      handler,
    };
  }

  /**
   * Create an input schema property helper
   */
  prop(type, description, options = {}) {
    return {
      type,
      description,
      ...options,
    };
  }

  /**
   * String property helper
   */
  stringProp(description, options = {}) {
    return this.prop('string', description, options);
  }

  /**
   * Number property helper
   */
  numberProp(description, options = {}) {
    return this.prop('number', description, options);
  }

  /**
   * Boolean property helper
   */
  booleanProp(description, options = {}) {
    return this.prop('boolean', description, options);
  }

  /**
   * Array property helper
   */
  arrayProp(description, items, options = {}) {
    return this.prop('array', description, { items, ...options });
  }

  /**
   * Enum property helper
   */
  enumProp(description, values, options = {}) {
    return this.prop('string', description, { enum: values, ...options });
  }
}

module.exports = BaseProvider;
