/**
 * Rate Limiting Middleware
 * 
 * Limits the number of requests per time window to prevent abuse.
 */

class RateLimitMiddleware {
  constructor(options = {}) {
    this.maxRequests = options.maxRequests || 100;
    this.windowMs = options.windowMs || 60000; // 1 minute default
    this.keyFn = options.keyFn || ((request, context) => context.sessionId || 'anonymous');
    this.requests = new Map();
    
    // Cleanup old entries periodically
    this.cleanupInterval = setInterval(() => this.cleanup(), this.windowMs);
  }

  async process(request, context, next) {
    const key = this.keyFn(request, context);
    const now = Date.now();
    
    // Get request history for this key
    let history = this.requests.get(key);
    if (!history) {
      history = [];
      this.requests.set(key, history);
    }
    
    // Remove old requests outside the window
    const cutoff = now - this.windowMs;
    while (history.length > 0 && history[0] < cutoff) {
      history.shift();
    }
    
    // Check if over limit
    if (history.length >= this.maxRequests) {
      return {
        jsonrpc: '2.0',
        id: request.id,
        error: {
          code: -32000,
          message: 'Rate limit exceeded',
          data: {
            limit: this.maxRequests,
            windowMs: this.windowMs,
            retryAfter: Math.ceil((history[0] + this.windowMs - now) / 1000),
          },
        },
      };
    }
    
    // Record this request
    history.push(now);
    
    return await next();
  }

  cleanup() {
    const now = Date.now();
    const cutoff = now - this.windowMs;
    
    for (const [key, history] of this.requests) {
      while (history.length > 0 && history[0] < cutoff) {
        history.shift();
      }
      if (history.length === 0) {
        this.requests.delete(key);
      }
    }
  }

  shutdown() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }
  }
}

module.exports = RateLimitMiddleware;
