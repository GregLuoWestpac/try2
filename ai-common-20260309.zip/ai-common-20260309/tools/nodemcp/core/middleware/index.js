/**
 * Middleware Module
 * 
 * Exports all middleware classes for the MCP server.
 */

const MiddlewareManager = require('./MiddlewareManager');
const LoggingMiddleware = require('./LoggingMiddleware');
const RateLimitMiddleware = require('./RateLimitMiddleware');
const { ErrorMiddleware, MCPError, ValidationError, NotFoundError, AuthError } = require('./ErrorMiddleware');
const MetricsMiddleware = require('./MetricsMiddleware');

module.exports = {
  MiddlewareManager,
  LoggingMiddleware,
  RateLimitMiddleware,
  ErrorMiddleware,
  MetricsMiddleware,
  // Error classes
  MCPError,
  ValidationError,
  NotFoundError,
  AuthError,
};
