/**
 * Error Handling Middleware
 * 
 * Catches and formats errors consistently across all requests.
 * Must be the first middleware in the chain to catch all errors.
 */

class ErrorMiddleware {
  constructor(options = {}) {
    this.logFn = options.logFn || console.error;
    this.includeStack = options.includeStack || false;
    this.errorHandlers = new Map();
  }

  /**
   * Register a custom error handler for a specific error type
   */
  registerHandler(errorClass, handler) {
    this.errorHandlers.set(errorClass, handler);
  }

  async process(request, context, next) {
    try {
      return await next();
    } catch (error) {
      return this.handleError(request, error);
    }
  }

  handleError(request, error) {
    // Check for custom error handlers
    for (const [errorClass, handler] of this.errorHandlers) {
      if (error instanceof errorClass) {
        return handler(request, error);
      }
    }

    // Log the error
    this.logFn(`[ErrorMiddleware] ${error.message}`);
    if (this.includeStack && error.stack) {
      this.logFn(error.stack);
    }

    // Determine error code based on error type
    let code = -32603; // Internal error
    let message = error.message || 'Internal error';

    if (error.code && typeof error.code === 'number') {
      code = error.code;
    }

    // Create standardized error response
    const response = {
      jsonrpc: '2.0',
      id: request.id,
      error: {
        code,
        message,
      },
    };

    // Include additional data if available
    if (error.data) {
      response.error.data = error.data;
    } else if (this.includeStack && error.stack) {
      response.error.data = { stack: error.stack };
    }

    return response;
  }
}

/**
 * Custom MCP Error class with code support
 */
class MCPError extends Error {
  constructor(code, message, data = undefined) {
    super(message);
    this.name = 'MCPError';
    this.code = code;
    this.data = data;
  }
}

/**
 * Validation Error - for invalid parameters
 */
class ValidationError extends MCPError {
  constructor(message, details = undefined) {
    super(-32602, message, details);
    this.name = 'ValidationError';
  }
}

/**
 * NotFound Error - for missing resources/tools/prompts
 */
class NotFoundError extends MCPError {
  constructor(type, name) {
    super(-32602, `${type} not found: ${name}`, { type, name });
    this.name = 'NotFoundError';
  }
}

/**
 * AuthError - for authentication/authorization failures
 */
class AuthError extends MCPError {
  constructor(message, reason = undefined) {
    super(-32000, message, reason ? { reason } : undefined);
    this.name = 'AuthError';
  }
}

module.exports = {
  ErrorMiddleware,
  MCPError,
  ValidationError,
  NotFoundError,
  AuthError,
};
