/**
 * Middleware Manager
 * 
 * Implements a middleware pipeline for request/response processing.
 * Middleware can intercept, modify, or short-circuit requests.
 */

class MiddlewareManager {
  constructor(options = {}) {
    this.verbose = options.verbose || false;
    this.middlewares = [];
    
    this.log = this.verbose
      ? (...args) => console.error('[MiddlewareManager]', ...args)
      : () => {};
  }

  /**
   * Add middleware to the pipeline
   */
  use(middleware) {
    if (typeof middleware.process !== 'function') {
      throw new Error('Middleware must have a process method');
    }
    this.middlewares.push(middleware);
    this.log(`Added middleware: ${middleware.constructor.name}`);
  }

  /**
   * Remove middleware from the pipeline
   */
  remove(middleware) {
    const index = this.middlewares.indexOf(middleware);
    if (index !== -1) {
      this.middlewares.splice(index, 1);
      return true;
    }
    return false;
  }

  /**
   * Clear all middleware
   */
  clear() {
    this.middlewares = [];
  }

  /**
   * Execute the middleware pipeline
   * @param {Object} request - The incoming request
   * @param {Object} context - Request context
   * @param {Function} handler - The final request handler
   * @returns {Object} The response
   */
  async execute(request, context, handler) {
    let index = 0;

    const next = async () => {
      if (index < this.middlewares.length) {
        const middleware = this.middlewares[index++];
        this.log(`Executing middleware: ${middleware.constructor.name}`);
        return await middleware.process(request, context, next);
      }
      // All middleware executed, call the handler
      return await handler(request, context);
    };

    return await next();
  }

  /**
   * Get middleware count
   */
  getMiddlewareCount() {
    return this.middlewares.length;
  }
}

module.exports = MiddlewareManager;
