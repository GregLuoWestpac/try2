/**
 * Logging Middleware
 * 
 * Logs incoming requests and outgoing responses with timing information.
 */

class LoggingMiddleware {
  constructor(options = {}) {
    this.logFn = options.logFn || console.error;
    this.prefix = options.prefix || '[MCP]';
    this.includeParams = options.includeParams !== false;
    this.includeResult = options.includeResult || false;
  }

  async process(request, context, next) {
    const startTime = Date.now();
    const { id, method, params } = request;
    
    // Log request
    let logMsg = `${this.prefix} ${method}`;
    if (id !== undefined) logMsg += ` [${id}]`;
    if (this.includeParams && params) {
      const paramStr = JSON.stringify(params);
      logMsg += ` ${paramStr.length > 100 ? paramStr.substring(0, 100) + '...' : paramStr}`;
    }
    this.logFn(logMsg);

    try {
      const response = await next();
      const duration = Date.now() - startTime;

      // Log response
      if (response && response.error) {
        this.logFn(`${this.prefix} ${method} [${id}] ERROR (${duration}ms): ${response.error.message}`);
      } else {
        let resultMsg = `${this.prefix} ${method} [${id}] OK (${duration}ms)`;
        if (this.includeResult && response && response.result) {
          const resultStr = JSON.stringify(response.result);
          resultMsg += ` ${resultStr.length > 100 ? resultStr.substring(0, 100) + '...' : resultStr}`;
        }
        this.logFn(resultMsg);
      }

      return response;
    } catch (error) {
      const duration = Date.now() - startTime;
      this.logFn(`${this.prefix} ${method} [${id}] EXCEPTION (${duration}ms): ${error.message}`);
      throw error;
    }
  }
}

module.exports = LoggingMiddleware;
