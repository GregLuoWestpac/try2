/**
 * Metrics Middleware
 * 
 * Collects metrics about request processing for monitoring.
 */

class MetricsMiddleware {
  constructor(options = {}) {
    this.metrics = {
      requests: new Map(), // method -> count
      errors: new Map(),   // method -> count
      latency: new Map(),  // method -> array of durations
      totalRequests: 0,
      totalErrors: 0,
    };
    this.maxLatencySamples = options.maxLatencySamples || 1000;
    this.onMetric = options.onMetric || null; // callback for each metric
  }

  async process(request, context, next) {
    const { method } = request;
    const startTime = Date.now();

    this.metrics.totalRequests++;
    this.metrics.requests.set(method, (this.metrics.requests.get(method) || 0) + 1);

    try {
      const response = await next();
      const duration = Date.now() - startTime;

      // Track latency
      this.recordLatency(method, duration);

      // Track errors
      if (response && response.error) {
        this.metrics.totalErrors++;
        this.metrics.errors.set(method, (this.metrics.errors.get(method) || 0) + 1);
      }

      // Emit metric if callback provided
      if (this.onMetric) {
        this.onMetric({
          method,
          duration,
          success: !response?.error,
          timestamp: Date.now(),
        });
      }

      return response;
    } catch (error) {
      const duration = Date.now() - startTime;
      this.recordLatency(method, duration);
      this.metrics.totalErrors++;
      this.metrics.errors.set(method, (this.metrics.errors.get(method) || 0) + 1);
      throw error;
    }
  }

  recordLatency(method, duration) {
    let latencies = this.metrics.latency.get(method);
    if (!latencies) {
      latencies = [];
      this.metrics.latency.set(method, latencies);
    }
    latencies.push(duration);
    
    // Keep only the last N samples
    if (latencies.length > this.maxLatencySamples) {
      latencies.shift();
    }
  }

  /**
   * Get aggregated metrics
   */
  getMetrics() {
    const latencyStats = {};
    
    for (const [method, latencies] of this.metrics.latency) {
      if (latencies.length > 0) {
        const sorted = [...latencies].sort((a, b) => a - b);
        latencyStats[method] = {
          count: latencies.length,
          min: sorted[0],
          max: sorted[sorted.length - 1],
          avg: Math.round(latencies.reduce((a, b) => a + b, 0) / latencies.length),
          p50: sorted[Math.floor(sorted.length * 0.5)],
          p95: sorted[Math.floor(sorted.length * 0.95)],
          p99: sorted[Math.floor(sorted.length * 0.99)],
        };
      }
    }

    return {
      totalRequests: this.metrics.totalRequests,
      totalErrors: this.metrics.totalErrors,
      errorRate: this.metrics.totalRequests > 0 
        ? (this.metrics.totalErrors / this.metrics.totalRequests * 100).toFixed(2) + '%'
        : '0%',
      requestsByMethod: Object.fromEntries(this.metrics.requests),
      errorsByMethod: Object.fromEntries(this.metrics.errors),
      latencyByMethod: latencyStats,
    };
  }

  /**
   * Reset all metrics
   */
  reset() {
    this.metrics = {
      requests: new Map(),
      errors: new Map(),
      latency: new Map(),
      totalRequests: 0,
      totalErrors: 0,
    };
  }
}

module.exports = MetricsMiddleware;
