/**
 * Context
 * 
 * Provides bidirectional communication capabilities for tools, resources, and prompts.
 * Enables sampling (LLM requests), elicitation (user input), and logging to clients.
 */

const { v4: uuidv4 } = require('uuid');

class Context {
  constructor(options = {}) {
    this.session = options.session;
    this.transport = options.transport;
    this.sessionId = options.sessionId;
    this.requestId = options.requestId;
    this.state = options.session?.data?.contextState || {};
    this.pendingRequests = new Map();
    this.verbose = options.verbose || false;
    
    this.log = this.verbose
      ? (...args) => console.error('[Context]', ...args)
      : () => {};
  }

  /**
   * Request LLM sampling from the client
   * @param {Object} options - Sampling options
   * @param {Array} options.messages - Messages to send to the LLM
   * @param {string} options.systemPrompt - Optional system prompt
   * @param {number} options.maxTokens - Maximum tokens to generate
   * @param {number} options.temperature - Sampling temperature
   * @param {Array} options.stopSequences - Stop sequences
   * @param {Object} options.modelPreferences - Model preference hints
   * @returns {Object} Sampling result with content and model info
   */
  async sample(options = {}) {
    if (!this.transport) {
      throw new Error('Sampling requires bidirectional transport');
    }

    const {
      messages,
      systemPrompt,
      maxTokens = 1000,
      temperature = 0.7,
      stopSequences = [],
      modelPreferences = {},
    } = options;

    // Validate messages
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      throw new Error('Sampling requires at least one message');
    }

    const requestId = uuidv4();
    const request = {
      jsonrpc: '2.0',
      id: requestId,
      method: 'sampling/createMessage',
      params: {
        messages: messages.map(msg => this.formatMessage(msg)),
        maxTokens,
        temperature,
        ...(systemPrompt && { systemPrompt }),
        ...(stopSequences.length > 0 && { stopSequences }),
        ...(Object.keys(modelPreferences).length > 0 && { modelPreferences }),
      },
    };

    this.log('Sending sampling request:', requestId);
    
    return await this.sendRequest(request);
  }

  /**
   * Convenience method for simple text sampling
   * @param {string} prompt - The prompt text
   * @param {Object} options - Additional options
   * @returns {string} The generated text
   */
  async sampleText(prompt, options = {}) {
    const result = await this.sample({
      messages: [{ role: 'user', content: prompt }],
      ...options,
    });
    
    if (result.content && result.content.type === 'text') {
      return result.content.text;
    }
    return result;
  }

  /**
   * Request user input via the client
   * @param {Object} options - Elicitation options
   * @param {string} options.message - Message to display to user
   * @param {Object} options.requestedSchema - JSON schema for expected input
   * @returns {Object} User input result
   */
  async elicit(options = {}) {
    if (!this.transport) {
      throw new Error('Elicitation requires bidirectional transport');
    }

    const {
      message,
      requestedSchema = { type: 'object', properties: {} },
    } = options;

    if (!message) {
      throw new Error('Elicitation requires a message');
    }

    const requestId = uuidv4();
    const request = {
      jsonrpc: '2.0',
      id: requestId,
      method: 'elicitation/create',
      params: {
        message,
        requestedSchema,
      },
    };

    this.log('Sending elicitation request:', requestId);
    
    return await this.sendRequest(request);
  }

  /**
   * Convenience method for simple text elicitation
   * @param {string} prompt - The prompt to show the user
   * @returns {string} The user's text input
   */
  async elicitText(prompt) {
    const result = await this.elicit({
      message: prompt,
      requestedSchema: {
        type: 'object',
        properties: {
          text: { type: 'string' },
        },
        required: ['text'],
      },
    });
    
    return result.action === 'accept' ? result.content?.text : null;
  }

  /**
   * Convenience method for yes/no elicitation
   * @param {string} prompt - The question to ask
   * @returns {boolean|null} true for yes, false for no, null if cancelled
   */
  async elicitConfirmation(prompt) {
    const result = await this.elicit({
      message: prompt,
      requestedSchema: {
        type: 'object',
        properties: {
          confirmed: { type: 'boolean' },
        },
        required: ['confirmed'],
      },
    });
    
    return result.action === 'accept' ? result.content?.confirmed : null;
  }

  /**
   * Send a log message to the client
   * @param {string} level - Log level (debug, info, notice, warning, error, critical, alert, emergency)
   * @param {string} message - Log message
   * @param {Object} data - Additional log data
   */
  async sendLog(level, message, data = {}) {
    if (!this.transport) {
      // Fall back to console if no transport
      console.error(`[${level.toUpperCase()}] ${message}`, data);
      return;
    }

    const validLevels = ['debug', 'info', 'notice', 'warning', 'error', 'critical', 'alert', 'emergency'];
    if (!validLevels.includes(level)) {
      level = 'info';
    }

    const notification = {
      jsonrpc: '2.0',
      method: 'notifications/message',
      params: {
        level,
        logger: 'server',
        data: {
          message,
          ...data,
          timestamp: new Date().toISOString(),
        },
      },
    };

    await this.transport.send(notification, this.sessionId);
  }

  /**
   * Convenience logging methods
   */
  async debug(message, data = {}) { await this.sendLog('debug', message, data); }
  async info(message, data = {}) { await this.sendLog('info', message, data); }
  async notice(message, data = {}) { await this.sendLog('notice', message, data); }
  async warning(message, data = {}) { await this.sendLog('warning', message, data); }
  async error(message, data = {}) { await this.sendLog('error', message, data); }

  /**
   * Report progress for long-running operations
   * @param {number} progress - Progress value (0-1 or 0-100)
   * @param {number} total - Total value (if using absolute progress)
   * @param {string} message - Optional progress message
   */
  async reportProgress(progress, total = null, message = null) {
    if (!this.transport || !this.requestId) {
      return;
    }

    // Normalize progress to 0-1 range
    let normalizedProgress = progress;
    if (total !== null) {
      normalizedProgress = progress / total;
    } else if (progress > 1) {
      normalizedProgress = progress / 100;
    }

    const notification = {
      jsonrpc: '2.0',
      method: 'notifications/progress',
      params: {
        progressToken: this.requestId,
        progress: normalizedProgress,
        total: 1,
        ...(message && { message }),
      },
    };

    await this.transport.send(notification, this.sessionId);
  }

  /**
   * Get state value
   * @param {string} key - State key
   * @param {any} defaultValue - Default value if key not found
   * @returns {any} The state value
   */
  getState(key, defaultValue = undefined) {
    return this.state.hasOwnProperty(key) ? this.state[key] : defaultValue;
  }

  /**
   * Set state value
   * @param {string} key - State key
   * @param {any} value - Value to set
   */
  setState(key, value) {
    this.state[key] = value;
    
    // Persist to session if available
    if (this.session) {
      this.session.data.contextState = this.state;
    }
  }

  /**
   * Delete state value
   * @param {string} key - State key
   */
  deleteState(key) {
    delete this.state[key];
    
    if (this.session) {
      this.session.data.contextState = this.state;
    }
  }

  /**
   * Clear all state
   */
  clearState() {
    this.state = {};
    
    if (this.session) {
      this.session.data.contextState = {};
    }
  }

  /**
   * Send a request to the client and wait for response
   * @private
   */
  async sendRequest(request) {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pendingRequests.delete(request.id);
        reject(new Error('Request timeout'));
      }, 30000); // 30 second timeout

      this.pendingRequests.set(request.id, { resolve, reject, timeout });
      
      this.transport.send(request, this.sessionId).catch(err => {
        clearTimeout(timeout);
        this.pendingRequests.delete(request.id);
        reject(err);
      });
    });
  }

  /**
   * Handle a response from the client
   * Called by the server when receiving a response message
   */
  handleResponse(response) {
    const pending = this.pendingRequests.get(response.id);
    if (pending) {
      clearTimeout(pending.timeout);
      this.pendingRequests.delete(response.id);
      
      if (response.error) {
        pending.reject(new Error(response.error.message));
      } else {
        pending.resolve(response.result);
      }
    }
  }

  /**
   * Format a message for sampling
   * @private
   */
  formatMessage(msg) {
    if (typeof msg === 'string') {
      return { role: 'user', content: { type: 'text', text: msg } };
    }
    
    // Normalize content format
    let content = msg.content;
    if (typeof content === 'string') {
      content = { type: 'text', text: content };
    }
    
    return {
      role: msg.role || 'user',
      content,
    };
  }
}

module.exports = Context;
