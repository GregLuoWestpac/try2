/**
 * Result Helpers
 * 
 * Helper functions for creating standardized MCP responses.
 * Simplifies tool response creation with common content types.
 */

/**
 * Create a text result
 * @param {string} text - The text content
 * @param {Object} options - Additional options
 * @returns {Object} MCP tool result
 */
function textResult(text, options = {}) {
  return {
    content: [{ type: 'text', text: String(text) }],
    ...options,
  };
}

/**
 * Create a JSON result
 * @param {Object} data - The data to serialize
 * @param {Object} options - Additional options
 * @returns {Object} MCP tool result
 */
function jsonResult(data, options = {}) {
  return {
    content: [{
      type: 'text',
      text: JSON.stringify(data, null, 2),
    }],
    ...options,
  };
}

/**
 * Create an image result
 * @param {string|Buffer} data - Base64 encoded data or Buffer
 * @param {string} mimeType - MIME type (e.g., 'image/png')
 * @param {Object} options - Additional options
 * @returns {Object} MCP tool result
 */
function imageResult(data, mimeType = 'image/png', options = {}) {
  const base64Data = Buffer.isBuffer(data) ? data.toString('base64') : data;
  return {
    content: [{
      type: 'image',
      data: base64Data,
      mimeType,
    }],
    ...options,
  };
}

/**
 * Create an error result
 * @param {string|Error} error - Error message or Error object
 * @param {Object} options - Additional options
 * @returns {Object} MCP tool result with isError flag
 */
function errorResult(error, options = {}) {
  const message = error instanceof Error ? error.message : String(error);
  return {
    content: [{ type: 'text', text: message }],
    isError: true,
    ...options,
  };
}

/**
 * Create a resource content result
 * @param {Object} resource - Resource details
 * @param {Object} options - Additional options
 * @returns {Object} MCP tool result
 */
function resourceResult(resource, options = {}) {
  return {
    content: [{
      type: 'resource',
      resource: {
        uri: resource.uri,
        mimeType: resource.mimeType || 'application/octet-stream',
        text: resource.text,
        ...(resource.blob && { blob: resource.blob }),
      },
    }],
    ...options,
  };
}

/**
 * Create a multi-content result
 * @param {Array} contents - Array of content items
 * @param {Object} options - Additional options
 * @returns {Object} MCP tool result
 */
function multiResult(contents, options = {}) {
  return {
    content: contents.map(item => {
      if (typeof item === 'string') {
        return { type: 'text', text: item };
      }
      return item;
    }),
    ...options,
  };
}

/**
 * Create a structured result with both content and structured data
 * @param {Object} data - Structured data (JSON serializable)
 * @param {string} summary - Human-readable summary
 * @param {Object} options - Additional options
 * @returns {Object} MCP tool result with structuredContent
 */
function structuredResult(data, summary = null, options = {}) {
  const text = summary || `Result: ${JSON.stringify(data)}`;
  return {
    content: [{ type: 'text', text }],
    structuredContent: data,
    ...options,
  };
}

/**
 * Create a message for prompts
 * @param {string} role - Message role ('user' or 'assistant')
 * @param {string|Object} content - Message content
 * @returns {Object} MCP message
 */
function message(role, content) {
  if (typeof content === 'string') {
    return {
      role,
      content: { type: 'text', text: content },
    };
  }
  return { role, content };
}

/**
 * Create a user message
 * @param {string|Object} content - Message content
 * @returns {Object} MCP message
 */
function userMessage(content) {
  return message('user', content);
}

/**
 * Create an assistant message
 * @param {string|Object} content - Message content
 * @returns {Object} MCP message
 */
function assistantMessage(content) {
  return message('assistant', content);
}

/**
 * Create resource content for resources/read response
 * @param {string} uri - Resource URI
 * @param {string|Object} content - Resource content
 * @param {Object} options - Additional options
 * @returns {Object} Resource content
 */
function resourceContent(uri, content, options = {}) {
  const isText = typeof content === 'string';
  return {
    uri,
    mimeType: options.mimeType || (isText ? 'text/plain' : 'application/json'),
    ...(isText ? { text: content } : { text: JSON.stringify(content, null, 2) }),
  };
}

/**
 * Create a text content item
 * @param {string} text - Text content
 * @returns {Object} Content item
 */
function textContent(text) {
  return { type: 'text', text: String(text) };
}

/**
 * Create an image content item
 * @param {string|Buffer} data - Base64 data or Buffer
 * @param {string} mimeType - MIME type
 * @returns {Object} Content item
 */
function imageContent(data, mimeType = 'image/png') {
  const base64Data = Buffer.isBuffer(data) ? data.toString('base64') : data;
  return { type: 'image', data: base64Data, mimeType };
}

module.exports = {
  // Tool results
  textResult,
  jsonResult,
  imageResult,
  errorResult,
  resourceResult,
  multiResult,
  structuredResult,
  
  // Prompt messages
  message,
  userMessage,
  assistantMessage,
  
  // Resource content
  resourceContent,
  
  // Content items
  textContent,
  imageContent,
};
