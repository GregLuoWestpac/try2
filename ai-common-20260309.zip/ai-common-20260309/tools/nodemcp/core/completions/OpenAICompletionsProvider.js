/**
 * OpenAI API Completions Provider
 * 
 * Uses OpenAI API (or compatible APIs) for LLM completions.
 */

const https = require('https');
const BaseCompletionsProvider = require('./BaseCompletionsProvider');

class OpenAICompletionsProvider extends BaseCompletionsProvider {
  constructor(options = {}) {
    super(options);
    
    this.apiKey = options.apiKey || process.env.OPENAI_API_KEY;
    this.baseUrl = options.baseUrl || process.env.OPENAI_BASE_URL || 'https://api.openai.com';
    this.defaultModel = options.model || process.env.OPENAI_MODEL || 'gpt-4o-mini';
    this.defaultMaxTokens = options.maxTokens || 4096;
    this.defaultTemperature = options.temperature || 0.7;
    this.defaultTimeout = options.timeout || 60000;
  }

  async initialize() {
    if (!this.apiKey) {
      this.log('Warning: No API key configured');
    }
    await super.initialize();
  }

  /**
   * Get a completion from OpenAI API
   */
  async complete(prompt, options = {}) {
    if (!this.apiKey) {
      return {
        success: false,
        content: '',
        error: 'No API key configured',
      };
    }

    const model = options.model || this.defaultModel;
    const maxTokens = options.maxTokens || this.defaultMaxTokens;
    const temperature = options.temperature ?? this.defaultTemperature;
    const timeout = options.timeout || this.defaultTimeout;
    const systemPrompt = options.systemPrompt || 'You are a helpful assistant.';

    const messages = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: prompt },
    ];

    try {
      const response = await this._makeRequest('/v1/chat/completions', {
        model,
        messages,
        max_tokens: maxTokens,
        temperature,
      }, timeout);

      const content = response.choices?.[0]?.message?.content || '';
      
      return {
        success: true,
        content,
        metadata: {
          model: response.model,
          usage: response.usage,
          finishReason: response.choices?.[0]?.finish_reason,
        },
      };

    } catch (error) {
      this.log('Completion failed:', error.message);
      return {
        success: false,
        content: '',
        error: error.message,
      };
    }
  }

  /**
   * Make HTTP request to OpenAI API
   */
  _makeRequest(endpoint, body, timeout) {
    return new Promise((resolve, reject) => {
      const url = new URL(endpoint, this.baseUrl);
      const postData = JSON.stringify(body);

      const options = {
        hostname: url.hostname,
        port: url.port || 443,
        path: url.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Length': Buffer.byteLength(postData),
        },
        timeout,
      };

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => { data += chunk; });
        res.on('end', () => {
          try {
            const json = JSON.parse(data);
            if (res.statusCode >= 400) {
              reject(new Error(json.error?.message || `API error: ${res.statusCode}`));
            } else {
              resolve(json);
            }
          } catch (e) {
            reject(new Error(`Failed to parse response: ${e.message}`));
          }
        });
      });

      req.on('error', (e) => reject(e));
      req.on('timeout', () => {
        req.destroy();
        reject(new Error('Request timeout'));
      });

      req.write(postData);
      req.end();
    });
  }

  /**
   * Check if API is available
   */
  async isAvailable() {
    return this.initialized && !!this.apiKey;
  }

  getInfo() {
    return {
      ...super.getInfo(),
      hasApiKey: !!this.apiKey,
      baseUrl: this.baseUrl,
      defaultModel: this.defaultModel,
    };
  }
}

module.exports = OpenAICompletionsProvider;
