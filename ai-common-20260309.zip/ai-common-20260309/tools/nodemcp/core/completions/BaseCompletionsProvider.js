/**
 * Base Completions Provider
 * 
 * Abstract base class for LLM completions providers.
 * Providers can use different backends (Copilot CLI, OpenAI API, local models, etc.)
 * without tight coupling to any specific implementation.
 */

class BaseCompletionsProvider {
  constructor(options = {}) {
    this.verbose = options.verbose || false;
    this.initialized = false;
    
    this.log = this.verbose
      ? (...args) => console.error(`[${this.constructor.name}]`, ...args)
      : () => {};
  }

  /**
   * Initialize the provider
   * @returns {Promise<void>}
   */
  async initialize() {
    this.initialized = true;
  }

  /**
   * Shutdown the provider
   * @returns {Promise<void>}
   */
  async shutdown() {
    this.initialized = false;
  }

  /**
   * Get a completion from the LLM
   * 
   * @param {string} prompt - The prompt to send
   * @param {object} options - Completion options
   * @param {string} options.model - Model to use (provider-specific)
   * @param {number} options.maxTokens - Maximum tokens in response
   * @param {number} options.temperature - Temperature (0.0-2.0)
   * @param {string} options.systemPrompt - System prompt (if supported)
   * @param {number} options.timeout - Timeout in milliseconds
   * @returns {Promise<CompletionResult>}
   */
  async complete(prompt, options = {}) {
    throw new Error('complete() must be implemented by subclass');
  }

  /**
   * Get a structured JSON completion
   * 
   * @param {string} prompt - The prompt
   * @param {object} schema - Expected JSON schema (for validation)
   * @param {object} options - Completion options
   * @returns {Promise<object>} Parsed JSON response
   */
  async completeJSON(prompt, schema = null, options = {}) {
    const result = await this.complete(prompt, options);
    
    if (!result.success) {
      throw new Error(result.error || 'Completion failed');
    }
    
    // Try to extract JSON from the response
    const jsonMatch = result.content.match(/```json\s*([\s\S]*?)\s*```/) ||
                      result.content.match(/\{[\s\S]*\}/) ||
                      result.content.match(/\[[\s\S]*\]/);
    
    if (!jsonMatch) {
      throw new Error('No JSON found in response');
    }
    
    const jsonStr = jsonMatch[1] || jsonMatch[0];
    return JSON.parse(jsonStr);
  }

  /**
   * Get multiple completions (for variety/voting)
   * 
   * @param {string} prompt - The prompt
   * @param {number} n - Number of completions
   * @param {object} options - Completion options
   * @returns {Promise<CompletionResult[]>}
   */
  async completeN(prompt, n = 3, options = {}) {
    const results = [];
    for (let i = 0; i < n; i++) {
      results.push(await this.complete(prompt, options));
    }
    return results;
  }

  /**
   * Check if the provider is available/ready
   * @returns {Promise<boolean>}
   */
  async isAvailable() {
    return this.initialized;
  }

  /**
   * Get provider info
   * @returns {object}
   */
  getInfo() {
    return {
      name: this.constructor.name,
      initialized: this.initialized,
    };
  }
}

/**
 * Completion result structure
 * @typedef {object} CompletionResult
 * @property {boolean} success - Whether the completion succeeded
 * @property {string} content - The completion content
 * @property {string} [error] - Error message if failed
 * @property {object} [metadata] - Additional metadata (tokens, model, etc.)
 */

module.exports = BaseCompletionsProvider;
