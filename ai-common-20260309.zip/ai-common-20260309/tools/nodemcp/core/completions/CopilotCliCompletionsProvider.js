/**
 * Copilot CLI Completions Provider
 * 
 * Uses GitHub Copilot CLI for LLM completions.
 * Spawns copilot CLI process with restricted tool access for safe completions.
 */

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const BaseCompletionsProvider = require('./BaseCompletionsProvider');

class CopilotCliCompletionsProvider extends BaseCompletionsProvider {
  constructor(options = {}) {
    super(options);
    
    // CLI command (default: 'copilot')
    this.command = options.command || process.env.COPILOT_CLI_COMMAND || 'copilot';
    
    // Model configuration
    this.models = options.models || {
      simple: '--model gpt-4.1',
      default: '--model claude-sonnet-4.5',
      complex: '--model claude-opus-4.5',
    };
    this.defaultModel = options.defaultModel || 'default';
    
    // Temp directory for prompt files
    this.tempDir = options.tempDir || path.join(os.tmpdir(), 'nodemcp-completions');
    
    // Default timeout (2 minutes)
    this.defaultTimeout = options.timeout || 120000;
    
    // Tool permissions
    this.allowedTools = options.allowedTools || ['view'];
    this.deniedTools = options.deniedTools || ['write', 'edit', 'create', 'powershell', 'bash'];
  }

  async initialize() {
    // Create temp directory
    if (!fs.existsSync(this.tempDir)) {
      fs.mkdirSync(this.tempDir, { recursive: true });
      this.log('Created temp directory:', this.tempDir);
    }
    
    // Verify copilot CLI is available
    try {
      await this._verifyCliAvailable();
      this.log('Copilot CLI verified');
    } catch (error) {
      this.log('Warning: Copilot CLI verification failed:', error.message);
    }
    
    await super.initialize();
  }

  async shutdown() {
    // Clean up temp files
    if (fs.existsSync(this.tempDir)) {
      const files = fs.readdirSync(this.tempDir);
      for (const file of files) {
        try {
          fs.unlinkSync(path.join(this.tempDir, file));
        } catch (e) {
          // Ignore cleanup errors
        }
      }
    }
    
    await super.shutdown();
  }

  /**
   * Verify copilot CLI is available
   */
  async _verifyCliAvailable() {
    return new Promise((resolve, reject) => {
      const proc = spawn(this.command, ['--version'], {
        shell: true,
        stdio: ['pipe', 'pipe', 'pipe'],
        timeout: 5000,
      });
      
      let stdout = '';
      proc.stdout.on('data', (data) => { stdout += data; });
      
      proc.on('close', (code) => {
        if (code === 0) {
          resolve(stdout.trim());
        } else {
          reject(new Error(`Copilot CLI exited with code ${code}`));
        }
      });
      
      proc.on('error', (err) => {
        reject(new Error(`Failed to spawn copilot CLI: ${err.message}`));
      });
    });
  }

  /**
   * Get a completion from Copilot CLI
   */
  async complete(prompt, options = {}) {
    const model = options.model || this.defaultModel;
    const timeout = options.timeout || this.defaultTimeout;
    const requestId = `req-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    
    // For now, always pass prompt inline (temp file approach has permission issues with nested CLI)
    const promptFile = path.join(this.tempDir, `prompt-${requestId}.md`);
    const usePromptFile = false; // Disabled: prompt.length > 1000 || prompt.includes('\n');
    
    try {
      let cliPrompt;
      
      if (usePromptFile) {
        fs.writeFileSync(promptFile, prompt, 'utf-8');
        // Use posix path for the CLI
        const promptFilePosix = promptFile.split(path.sep).join('/');
        cliPrompt = `Read "${promptFilePosix}" and follow the instructions within. Output your response directly.`;
        this.log('Using prompt file:', promptFile);
      } else {
        // Truncate very long prompts to avoid shell issues
        const maxInlineLength = 12000;
        cliPrompt = prompt.length > maxInlineLength 
          ? prompt.slice(0, maxInlineLength) + '\n...[truncated]'
          : prompt;
      }
      
      // Build CLI command
      const modelArg = this.models[model] || this.models[this.defaultModel] || '';
      const escapedPrompt = this._escapePrompt(cliPrompt);
      
      // Build tool permissions
      const toolArgs = [
        ...this.allowedTools.map(t => `--allow-tool ${t}`),
        ...this.deniedTools.map(t => `--deny-tool ${t}`),
      ].join(' ');
      
      // Add path permissions so CLI can read prompt files from temp directory
      const pathArgs = usePromptFile ? `--allow-all-paths --add-dir "${this.tempDir}"` : '';
      
      const cmdString = `${this.command} ${modelArg} -s --no-ask-user ${toolArgs} ${pathArgs} -p "${escapedPrompt}"`;
      // Debug: write command to file
      const debugFile = path.join(os.tmpdir(), 'copilot-cli-debug.txt');
      fs.writeFileSync(debugFile, `=== ${new Date().toISOString()} ===\nPROMPT LENGTH: ${prompt.length}\nCLI PROMPT LENGTH: ${cliPrompt.length}\nESCAPED PROMPT LENGTH: ${escapedPrompt.length}\nCMD LENGTH: ${cmdString.length}\n\n--- ORIGINAL PROMPT ---\n${prompt}\n\n--- CLI PROMPT ---\n${cliPrompt}\n\n--- CMD STRING ---\n${cmdString}\n`);
      this.log('Debug written to:', debugFile);
      this.log('Executing full command:');
      this.log(cmdString);
      
      const result = await this._executeCommand(cmdString, timeout);
      
      // Clean up thinking blocks and extract response
      const cleanedContent = this._cleanResponse(result.stdout);
      
      return {
        success: true,
        content: cleanedContent,
        metadata: {
          model,
          requestId,
          exitCode: result.code,
          rawLength: result.stdout.length,
          cleanedLength: cleanedContent.length,
        },
      };
      
    } catch (error) {
      this.log('Completion failed:', error.message);
      return {
        success: false,
        content: '',
        error: error.message,
        metadata: { requestId },
      };
      
    } finally {
      // Clean up prompt file
      if (usePromptFile && fs.existsSync(promptFile)) {
        try {
          fs.unlinkSync(promptFile);
        } catch (e) {
          // Ignore
        }
      }
    }
  }

  /**
   * Execute CLI command with timeout
   */
  _executeCommand(cmdString, timeout) {
    return new Promise((resolve, reject) => {
      const proc = spawn(cmdString, [], {
        shell: true,
        windowsHide: true,
        stdio: ['pipe', 'pipe', 'pipe'],
      });
      
      let stdout = '';
      let stderr = '';
      let killed = false;
      
      const timer = setTimeout(() => {
        killed = true;
        proc.kill('SIGKILL');
        reject(new Error(`Command timed out after ${timeout}ms`));
      }, timeout);
      
      proc.stdout.on('data', (data) => { stdout += data; });
      proc.stderr.on('data', (data) => { stderr += data; });
      
      proc.on('close', (code) => {
        clearTimeout(timer);
        if (killed) return;
        
        if (code !== 0 && !stdout) {
          reject(new Error(`Command failed with code ${code}: ${stderr}`));
        } else {
          resolve({ code, stdout, stderr });
        }
      });
      
      proc.on('error', (err) => {
        clearTimeout(timer);
        reject(new Error(`Failed to spawn process: ${err.message}`));
      });
    });
  }

  /**
   * Escape prompt for shell
   */
  _escapePrompt(prompt) {
    // Escape special characters for shell
    // CRITICAL: newlines must be escaped for inline -p "..." to work
    return prompt
      .replace(/\\/g, '\\\\')
      .replace(/"/g, '\\"')
      .replace(/\$/g, '\\$')
      .replace(/`/g, '\\`')
      .replace(/\r\n/g, '\\n')
      .replace(/\n/g, '\\n')
      .replace(/\r/g, '\\n');
  }

  /**
   * Clean response by removing thinking blocks and other artifacts
   */
  _cleanResponse(response) {
    let cleaned = response;
    
    // Remove common thinking/reasoning blocks
    const thinkingPatterns = [
      /^<thinking>[\s\S]*?<\/thinking>\n*/gm,
      /^<antThinking>[\s\S]*?<\/antThinking>\n*/gm,
      /^<reasoning>[\s\S]*?<\/reasoning>\n*/gm,
      /^Let me think[^]*?(?=\n\n|\n[A-Z])/gm,
      /^I'll analyze[^]*?(?=\n\n|\n[A-Z])/gm,
    ];
    
    for (const pattern of thinkingPatterns) {
      cleaned = cleaned.replace(pattern, '');
    }
    
    return cleaned.trim();
  }

  /**
   * Get provider info
   */
  getInfo() {
    return {
      ...super.getInfo(),
      command: this.command,
      models: Object.keys(this.models),
      defaultModel: this.defaultModel,
    };
  }
}

module.exports = CopilotCliCompletionsProvider;
