/**
 * Completions Providers
 * 
 * Factory and exports for LLM completions providers.
 * Provides a unified interface for different completion backends.
 */

const BaseCompletionsProvider = require('./BaseCompletionsProvider');
const CopilotCliCompletionsProvider = require('./CopilotCliCompletionsProvider');
const OpenAICompletionsProvider = require('./OpenAICompletionsProvider');

/**
 * Create a completions provider based on type
 * 
 * @param {string} type - Provider type: 'copilot', 'openai', or 'auto'
 * @param {object} options - Provider options
 * @returns {BaseCompletionsProvider}
 */
function createCompletionsProvider(type = 'auto', options = {}) {
  const providerType = type.toLowerCase();
  
  switch (providerType) {
    case 'copilot':
    case 'copilot-cli':
      return new CopilotCliCompletionsProvider(options);
      
    case 'openai':
    case 'api':
      return new OpenAICompletionsProvider(options);
      
    case 'auto':
    default:
      // Auto-select based on available configuration
      // Prefer Copilot CLI if no OpenAI API key
      if (process.env.OPENAI_API_KEY && !process.env.PREFER_COPILOT_CLI) {
        return new OpenAICompletionsProvider(options);
      }
      return new CopilotCliCompletionsProvider(options);
  }
}

/**
 * Get available provider types
 */
function getAvailableProviders() {
  return [
    { type: 'copilot', name: 'Copilot CLI', description: 'GitHub Copilot CLI for completions' },
    { type: 'openai', name: 'OpenAI API', description: 'OpenAI API (or compatible)' },
  ];
}

module.exports = {
  BaseCompletionsProvider,
  CopilotCliCompletionsProvider,
  OpenAICompletionsProvider,
  createCompletionsProvider,
  getAvailableProviders,
};
