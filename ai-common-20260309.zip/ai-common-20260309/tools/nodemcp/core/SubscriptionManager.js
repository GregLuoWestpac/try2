/**
 * Subscription Manager
 * 
 * Manages resource subscriptions and notifications.
 * Allows clients to subscribe to resource changes and receive updates.
 */

const { v4: uuidv4 } = require('uuid');

class SubscriptionManager {
  constructor(options = {}) {
    this.verbose = options.verbose || false;
    this.subscriptions = new Map(); // uri -> Set of { sessionId, subscriptionId }
    this.sessionSubscriptions = new Map(); // sessionId -> Set of uris
    
    this.log = this.verbose
      ? (...args) => console.error('[SubscriptionManager]', ...args)
      : () => {};
  }

  /**
   * Subscribe to a resource
   * @param {string} uri - Resource URI to subscribe to
   * @param {string} sessionId - Session ID of the subscriber
   * @returns {string} Subscription ID
   */
  subscribe(uri, sessionId) {
    const subscriptionId = uuidv4();
    
    // Add to uri -> subscriptions map
    if (!this.subscriptions.has(uri)) {
      this.subscriptions.set(uri, new Set());
    }
    this.subscriptions.get(uri).add({ sessionId, subscriptionId });
    
    // Add to session -> uris map
    if (!this.sessionSubscriptions.has(sessionId)) {
      this.sessionSubscriptions.set(sessionId, new Set());
    }
    this.sessionSubscriptions.get(sessionId).add(uri);
    
    this.log(`Subscription created: ${subscriptionId} for ${uri} (session: ${sessionId})`);
    
    return subscriptionId;
  }

  /**
   * Unsubscribe from a resource
   * @param {string} uri - Resource URI to unsubscribe from
   * @param {string} sessionId - Session ID of the subscriber
   * @returns {boolean} True if subscription was removed
   */
  unsubscribe(uri, sessionId) {
    const uriSubscriptions = this.subscriptions.get(uri);
    if (!uriSubscriptions) return false;
    
    let removed = false;
    for (const sub of uriSubscriptions) {
      if (sub.sessionId === sessionId) {
        uriSubscriptions.delete(sub);
        removed = true;
        break;
      }
    }
    
    // Clean up empty sets
    if (uriSubscriptions.size === 0) {
      this.subscriptions.delete(uri);
    }
    
    // Update session subscriptions
    const sessionSubs = this.sessionSubscriptions.get(sessionId);
    if (sessionSubs) {
      sessionSubs.delete(uri);
      if (sessionSubs.size === 0) {
        this.sessionSubscriptions.delete(sessionId);
      }
    }
    
    if (removed) {
      this.log(`Subscription removed for ${uri} (session: ${sessionId})`);
    }
    
    return removed;
  }

  /**
   * Unsubscribe all subscriptions for a session
   * @param {string} sessionId - Session ID
   */
  unsubscribeAll(sessionId) {
    const uris = this.sessionSubscriptions.get(sessionId);
    if (!uris) return;
    
    for (const uri of uris) {
      const uriSubs = this.subscriptions.get(uri);
      if (uriSubs) {
        for (const sub of uriSubs) {
          if (sub.sessionId === sessionId) {
            uriSubs.delete(sub);
          }
        }
        if (uriSubs.size === 0) {
          this.subscriptions.delete(uri);
        }
      }
    }
    
    this.sessionSubscriptions.delete(sessionId);
    this.log(`All subscriptions removed for session: ${sessionId}`);
  }

  /**
   * Get all subscribers for a resource
   * @param {string} uri - Resource URI
   * @returns {Array} Array of { sessionId, subscriptionId }
   */
  getSubscribers(uri) {
    const subs = this.subscriptions.get(uri);
    return subs ? Array.from(subs) : [];
  }

  /**
   * Check if a session is subscribed to a resource
   * @param {string} uri - Resource URI
   * @param {string} sessionId - Session ID
   * @returns {boolean}
   */
  isSubscribed(uri, sessionId) {
    const subs = this.subscriptions.get(uri);
    if (!subs) return false;
    
    for (const sub of subs) {
      if (sub.sessionId === sessionId) {
        return true;
      }
    }
    return false;
  }

  /**
   * Get all URIs a session is subscribed to
   * @param {string} sessionId - Session ID
   * @returns {Array} Array of URIs
   */
  getSessionSubscriptions(sessionId) {
    const uris = this.sessionSubscriptions.get(sessionId);
    return uris ? Array.from(uris) : [];
  }

  /**
   * Notify subscribers of a resource change
   * @param {string} uri - Resource URI that changed
   * @param {Function} notifyFn - Function to call for each subscriber: (sessionId) => void
   */
  async notifySubscribers(uri, notifyFn) {
    const subs = this.subscriptions.get(uri);
    if (!subs || subs.size === 0) return;
    
    this.log(`Notifying ${subs.size} subscriber(s) of change to ${uri}`);
    
    const notifications = [];
    for (const sub of subs) {
      notifications.push(notifyFn(sub.sessionId, sub.subscriptionId));
    }
    
    await Promise.allSettled(notifications);
  }

  /**
   * Get subscription statistics
   */
  getStats() {
    let totalSubscriptions = 0;
    for (const subs of this.subscriptions.values()) {
      totalSubscriptions += subs.size;
    }
    
    return {
      totalResources: this.subscriptions.size,
      totalSubscriptions,
      totalSessions: this.sessionSubscriptions.size,
    };
  }

  /**
   * Clear all subscriptions
   */
  clear() {
    this.subscriptions.clear();
    this.sessionSubscriptions.clear();
    this.log('All subscriptions cleared');
  }
}

module.exports = SubscriptionManager;
