/**
 * Configuration
 * 
 * Configuration management for NodeMCP servers.
 * Supports environment variables, config files, and programmatic configuration.
 */

const fs = require('fs');
const path = require('path');

/**
 * Default configuration values
 */
const DEFAULTS = {
  name: 'nodemcp',
  version: '1.0.0',
  transport: 'stdio',
  host: '127.0.0.1',
  port: 3100,
  sessionTimeout: 30 * 60 * 1000, // 30 minutes
  verbose: false,
  
  // Rate limiting
  rateLimit: {
    enabled: false,
    maxRequests: 100,
    windowMs: 60000,
  },
  
  // Authentication
  auth: {
    enabled: false,
    type: null, // 'jwt', 'apikey', 'bearer'
  },
  
  // Middleware
  middleware: {
    logging: false,
    metrics: false,
    errorHandling: true,
  },
  
  // Tasks
  tasks: {
    enabled: true,
    maxConcurrent: 10,
    timeout: 5 * 60 * 1000, // 5 minutes
  },
};

class Config {
  constructor(options = {}) {
    // Start with defaults
    this.config = { ...DEFAULTS };
    
    // Apply options
    this.merge(options);
  }

  /**
   * Merge configuration options
   */
  merge(options) {
    for (const [key, value] of Object.entries(options)) {
      if (value !== undefined) {
        if (typeof value === 'object' && !Array.isArray(value) && value !== null) {
          this.config[key] = { ...this.config[key], ...value };
        } else {
          this.config[key] = value;
        }
      }
    }
  }

  /**
   * Get a configuration value
   */
  get(key, defaultValue = undefined) {
    const keys = key.split('.');
    let value = this.config;
    
    for (const k of keys) {
      if (value === undefined || value === null) {
        return defaultValue;
      }
      value = value[k];
    }
    
    return value !== undefined ? value : defaultValue;
  }

  /**
   * Set a configuration value
   */
  set(key, value) {
    const keys = key.split('.');
    let obj = this.config;
    
    for (let i = 0; i < keys.length - 1; i++) {
      const k = keys[i];
      if (!obj[k]) obj[k] = {};
      obj = obj[k];
    }
    
    obj[keys[keys.length - 1]] = value;
  }

  /**
   * Get all configuration
   */
  getAll() {
    return { ...this.config };
  }

  /**
   * Load configuration from a JSON file
   */
  static fromFile(filePath) {
    const absolutePath = path.resolve(filePath);
    
    if (!fs.existsSync(absolutePath)) {
      throw new Error(`Config file not found: ${absolutePath}`);
    }
    
    const content = fs.readFileSync(absolutePath, 'utf-8');
    const data = JSON.parse(content);
    
    return new Config(data);
  }

  /**
   * Load configuration from environment variables
   */
  static fromEnv(prefix = 'MCP_') {
    const config = new Config();
    
    const envMappings = {
      [`${prefix}NAME`]: 'name',
      [`${prefix}VERSION`]: 'version',
      [`${prefix}TRANSPORT`]: 'transport',
      [`${prefix}HOST`]: 'host',
      [`${prefix}PORT`]: ['port', parseInt],
      [`${prefix}SESSION_TIMEOUT`]: ['sessionTimeout', parseInt],
      [`${prefix}VERBOSE`]: ['verbose', v => v === 'true' || v === '1'],
      [`${prefix}RATE_LIMIT_ENABLED`]: ['rateLimit.enabled', v => v === 'true' || v === '1'],
      [`${prefix}RATE_LIMIT_MAX`]: ['rateLimit.maxRequests', parseInt],
      [`${prefix}RATE_LIMIT_WINDOW`]: ['rateLimit.windowMs', parseInt],
      [`${prefix}AUTH_ENABLED`]: ['auth.enabled', v => v === 'true' || v === '1'],
      [`${prefix}AUTH_TYPE`]: 'auth.type',
      [`${prefix}LOGGING`]: ['middleware.logging', v => v === 'true' || v === '1'],
      [`${prefix}METRICS`]: ['middleware.metrics', v => v === 'true' || v === '1'],
      [`${prefix}TASK_MAX_CONCURRENT`]: ['tasks.maxConcurrent', parseInt],
      [`${prefix}TASK_TIMEOUT`]: ['tasks.timeout', parseInt],
    };
    
    for (const [envKey, mapping] of Object.entries(envMappings)) {
      const value = process.env[envKey];
      if (value !== undefined) {
        if (Array.isArray(mapping)) {
          const [configKey, transform] = mapping;
          config.set(configKey, transform(value));
        } else {
          config.set(mapping, value);
        }
      }
    }
    
    return config;
  }

  /**
   * Create configuration from CLI arguments
   */
  static fromArgs(args) {
    const config = new Config();
    
    if (args.transport) config.set('transport', args.transport);
    if (args.host) config.set('host', args.host);
    if (args.port) config.set('port', args.port);
    if (args.verbose !== undefined) config.set('verbose', args.verbose);
    if (args.requireAuth !== undefined) config.set('auth.enabled', args.requireAuth);
    
    return config;
  }

  /**
   * Merge multiple configs (later configs override earlier)
   */
  static merge(...configs) {
    const result = new Config();
    
    for (const config of configs) {
      if (config instanceof Config) {
        result.merge(config.getAll());
      } else {
        result.merge(config);
      }
    }
    
    return result;
  }

  /**
   * Validate configuration
   */
  validate() {
    const errors = [];
    
    if (!['stdio', 'http'].includes(this.get('transport'))) {
      errors.push(`Invalid transport: ${this.get('transport')}`);
    }
    
    const port = this.get('port');
    if (typeof port !== 'number' || port < 1 || port > 65535) {
      errors.push(`Invalid port: ${port}`);
    }
    
    if (this.get('auth.enabled') && !this.get('auth.type')) {
      errors.push('Auth type required when auth is enabled');
    }
    
    if (errors.length > 0) {
      throw new Error(`Configuration errors:\n${errors.join('\n')}`);
    }
    
    return true;
  }
}

module.exports = Config;
