/**
 * Provider Manager
 * 
 * Discovers, loads, and manages MCP providers from the mcps/ directory.
 * Aggregates tools, resources, and prompts from all loaded providers.
 */

const fs = require('fs');
const path = require('path');

class ProviderManager {
  constructor(mcpsPath, options = {}) {
    // Always use absolute paths
    this.mcpsPath = path.resolve(mcpsPath);
    this.verbose = options.verbose || false;
    this.providers = new Map();
    
    this.log = this.verbose
      ? (...args) => console.error('[ProviderManager]', ...args)
      : () => {};
  }

  /**
   * Discover available providers in the mcps directory
   */
  async discoverProviders() {
    const providers = [];

    if (!fs.existsSync(this.mcpsPath)) {
      this.log('MCPs directory does not exist:', this.mcpsPath);
      return providers;
    }

    const entries = fs.readdirSync(this.mcpsPath, { withFileTypes: true });

    for (const entry of entries) {
      if (entry.isDirectory()) {
        const providerPath = path.join(this.mcpsPath, entry.name);
        const indexPath = path.join(providerPath, 'index.js');
        const packagePath = path.join(providerPath, 'package.json');

        if (fs.existsSync(indexPath)) {
          let metadata = { name: entry.name };
          
          if (fs.existsSync(packagePath)) {
            try {
              const pkg = JSON.parse(fs.readFileSync(packagePath, 'utf-8'));
              metadata = {
                name: pkg.name || entry.name,
                version: pkg.version,
                description: pkg.description,
              };
            } catch (e) {
              // Ignore package.json parse errors
            }
          }

          providers.push({
            id: entry.name,
            path: providerPath,
            ...metadata,
          });
        }
      }
    }

    this.log('Discovered providers:', providers.map(p => p.id).join(', '));
    return providers;
  }

  /**
   * Load all available providers
   */
  async loadAllProviders() {
    const discovered = await this.discoverProviders();
    
    for (const providerInfo of discovered) {
      await this.loadProvider(providerInfo.id);
    }
  }

  /**
   * Load specific providers by name
   */
  async loadProviders(names) {
    for (const name of names) {
      await this.loadProvider(name);
    }
  }

  /**
   * Load a single provider by name
   */
  async loadProvider(name) {
    const providerPath = path.join(this.mcpsPath, name);
    const indexPath = path.join(providerPath, 'index.js');

    if (!fs.existsSync(indexPath)) {
      throw new Error(`Provider not found: ${name}`);
    }

    try {
      const ProviderClass = require(indexPath);
      const provider = new ProviderClass({
        basePath: providerPath,
        verbose: this.verbose,
      });

      // Initialize the provider
      await provider.initialize();

      this.providers.set(name, provider);
      this.log(`Loaded provider: ${name}`);

    } catch (error) {
      this.log(`Failed to load provider ${name}:`, error.message);
      throw error;
    }
  }

  /**
   * Load a provider from an absolute path
   */
  async loadProviderFromPath(providerPath) {
    const indexPath = path.join(providerPath, 'index.js');
    const name = path.basename(providerPath);

    if (!fs.existsSync(indexPath)) {
      throw new Error(`Provider not found at path: ${providerPath}`);
    }

    try {
      const ProviderClass = require(indexPath);
      const provider = new ProviderClass({
        basePath: providerPath,
        verbose: this.verbose,
      });

      // Initialize the provider
      await provider.initialize();

      this.providers.set(name, provider);
      this.log(`Loaded provider from path: ${name} (${providerPath})`);

    } catch (error) {
      this.log(`Failed to load provider from ${providerPath}:`, error.message);
      throw error;
    }
  }

  /**
   * Get the number of loaded providers
   */
  getProviderCount() {
    return this.providers.size;
  }

  /**
   * Get all tools from all providers
   */
  getAllTools() {
    const tools = [];

    for (const [providerName, provider] of this.providers) {
      const providerTools = provider.getTools();
      for (const tool of providerTools) {
        tools.push({
          ...tool,
          // Prefix tool name with provider for uniqueness
          name: `${providerName}_${tool.name}`,
          _providerName: providerName,
          _originalName: tool.name,
        });
      }
    }

    return tools;
  }

  /**
   * Find a tool by full name (provider_toolname)
   */
  findTool(fullName) {
    for (const [providerName, provider] of this.providers) {
      const prefix = `${providerName}_`;
      if (fullName.startsWith(prefix)) {
        const toolName = fullName.substring(prefix.length);
        const tools = provider.getTools();
        const tool = tools.find(t => t.name === toolName);
        if (tool) {
          return { provider, tool };
        }
      }
    }
    return null;
  }

  /**
   * Get all resources from all providers
   */
  getAllResources() {
    const resources = [];

    for (const [providerName, provider] of this.providers) {
      const providerResources = provider.getResources();
      resources.push(...providerResources);
    }

    return resources;
  }

  /**
   * Find a resource by URI
   */
  findResource(uri) {
    for (const [providerName, provider] of this.providers) {
      const resources = provider.getResources();
      const resource = resources.find(r => {
        // Check if URI matches or is a template match
        if (r.uri === uri) return true;
        if (r.uriTemplate) {
          // Simple template matching
          const pattern = r.uriTemplate.replace(/\{[^}]+\}/g, '[^/]+');
          const regex = new RegExp(`^${pattern}$`);
          return regex.test(uri);
        }
        return false;
      });
      if (resource) {
        return { provider, resource };
      }
    }
    return null;
  }

  /**
   * Get all prompts from all providers
   */
  getAllPrompts() {
    const prompts = [];

    for (const [providerName, provider] of this.providers) {
      const providerPrompts = provider.getPrompts();
      for (const prompt of providerPrompts) {
        prompts.push({
          ...prompt,
          name: `${providerName}_${prompt.name}`,
          _providerName: providerName,
          _originalName: prompt.name,
        });
      }
    }

    return prompts;
  }

  /**
   * Find a prompt by full name
   */
  findPrompt(fullName) {
    for (const [providerName, provider] of this.providers) {
      const prefix = `${providerName}_`;
      if (fullName.startsWith(prefix)) {
        const promptName = fullName.substring(prefix.length);
        const prompts = provider.getPrompts();
        const prompt = prompts.find(p => p.name === promptName);
        if (prompt) {
          return { provider, prompt };
        }
      }
    }
    return null;
  }

  /**
   * Get a specific provider by name
   */
  getProvider(name) {
    return this.providers.get(name);
  }

  /**
   * Shutdown all providers
   */
  async shutdown() {
    for (const [name, provider] of this.providers) {
      try {
        await provider.shutdown();
        this.log(`Shutdown provider: ${name}`);
      } catch (error) {
        this.log(`Error shutting down provider ${name}:`, error.message);
      }
    }
    this.providers.clear();
  }
}

module.exports = ProviderManager;
