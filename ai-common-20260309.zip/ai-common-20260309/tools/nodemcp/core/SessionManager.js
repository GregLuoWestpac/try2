/**
 * Session Manager
 * 
 * Manages stateful sessions for MCP providers.
 * Handles session creation, retrieval, and cleanup.
 */

const { v4: uuidv4 } = require('uuid');

class SessionManager {
  constructor(options = {}) {
    this.verbose = options.verbose || false;
    this.sessions = new Map();
    this.sessionTimeout = options.sessionTimeout || 30 * 60 * 1000; // 30 minutes
    
    this.log = this.verbose
      ? (...args) => console.error('[SessionManager]', ...args)
      : () => {};

    // Start cleanup interval
    this.cleanupInterval = setInterval(() => this.cleanupExpiredSessions(), 60000);
  }

  /**
   * Create a new session
   */
  createSession(id = null) {
    const sessionId = id || uuidv4();
    
    const session = {
      id: sessionId,
      createdAt: Date.now(),
      lastAccessedAt: Date.now(),
      data: {},
      providerData: new Map(),
    };

    this.sessions.set(sessionId, session);
    this.log(`Created session: ${sessionId}`);

    return session;
  }

  /**
   * Get a session by ID
   */
  getSession(sessionId) {
    if (!sessionId) return null;

    const session = this.sessions.get(sessionId);
    if (session) {
      session.lastAccessedAt = Date.now();
    }
    return session;
  }

  /**
   * Get or create a session
   */
  getOrCreateSession(sessionId) {
    let session = this.getSession(sessionId);
    if (!session) {
      session = this.createSession(sessionId);
    }
    return session;
  }

  /**
   * Set session data
   */
  setSessionData(sessionId, key, value) {
    const session = this.getSession(sessionId);
    if (session) {
      session.data[key] = value;
      return true;
    }
    return false;
  }

  /**
   * Get session data
   */
  getSessionData(sessionId, key) {
    const session = this.getSession(sessionId);
    if (session) {
      return session.data[key];
    }
    return undefined;
  }

  /**
   * Set provider-specific session data
   */
  setProviderData(sessionId, providerName, key, value) {
    const session = this.getSession(sessionId);
    if (session) {
      if (!session.providerData.has(providerName)) {
        session.providerData.set(providerName, {});
      }
      session.providerData.get(providerName)[key] = value;
      return true;
    }
    return false;
  }

  /**
   * Get provider-specific session data
   */
  getProviderData(sessionId, providerName, key) {
    const session = this.getSession(sessionId);
    if (session && session.providerData.has(providerName)) {
      const providerData = session.providerData.get(providerName);
      return key ? providerData[key] : providerData;
    }
    return key ? undefined : {};
  }

  /**
   * Clear provider data for a session
   */
  clearProviderData(sessionId, providerName) {
    const session = this.getSession(sessionId);
    if (session) {
      session.providerData.delete(providerName);
      return true;
    }
    return false;
  }

  /**
   * Destroy a session
   */
  destroySession(sessionId) {
    if (this.sessions.has(sessionId)) {
      this.sessions.delete(sessionId);
      this.log(`Destroyed session: ${sessionId}`);
      return true;
    }
    return false;
  }

  /**
   * Destroy all sessions
   */
  async destroyAllSessions() {
    const count = this.sessions.size;
    this.sessions.clear();
    this.log(`Destroyed ${count} session(s)`);
  }

  /**
   * Clean up expired sessions
   */
  cleanupExpiredSessions() {
    const now = Date.now();
    let cleaned = 0;

    for (const [sessionId, session] of this.sessions) {
      if (now - session.lastAccessedAt > this.sessionTimeout) {
        this.sessions.delete(sessionId);
        cleaned++;
      }
    }

    if (cleaned > 0) {
      this.log(`Cleaned up ${cleaned} expired session(s)`);
    }
  }

  /**
   * Get session count
   */
  getSessionCount() {
    return this.sessions.size;
  }

  /**
   * Shutdown the session manager
   */
  shutdown() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }
    this.sessions.clear();
  }
}

module.exports = SessionManager;
