/**
 * Task Manager
 * 
 * Manages background task execution for long-running operations.
 * Implements SEP-1686 (MCP Tasks) for asynchronous tool execution.
 */

const { v4: uuidv4 } = require('uuid');

/**
 * Task status enum
 */
const TaskStatus = {
  QUEUED: 'queued',
  RUNNING: 'running',
  COMPLETED: 'completed',
  FAILED: 'failed',
  CANCELLED: 'cancelled',
};

/**
 * Task class representing a single background task
 */
class Task {
  constructor(options) {
    this.id = options.id || uuidv4();
    this.tool = options.tool;
    this.arguments = options.arguments || {};
    this.sessionId = options.sessionId;
    this.status = TaskStatus.QUEUED;
    this.progress = null;
    this.result = null;
    this.error = null;
    this.createdAt = new Date().toISOString();
    this.startedAt = null;
    this.completedAt = null;
    this.cancelRequested = false;
  }

  toJSON() {
    return {
      id: this.id,
      tool: this.tool,
      status: this.status,
      progress: this.progress,
      result: this.result,
      error: this.error,
      createdAt: this.createdAt,
      startedAt: this.startedAt,
      completedAt: this.completedAt,
    };
  }
}

/**
 * Task Manager class
 */
class TaskManager {
  constructor(options = {}) {
    this.verbose = options.verbose || false;
    this.maxConcurrentTasks = options.maxConcurrentTasks || 10;
    this.taskTimeout = options.taskTimeout || 5 * 60 * 1000; // 5 minutes default
    
    this.tasks = new Map(); // taskId -> Task
    this.runningCount = 0;
    this.queue = []; // Tasks waiting to run
    this.notifyFn = options.notifyFn || null; // Function to send notifications
    
    this.log = this.verbose
      ? (...args) => console.error('[TaskManager]', ...args)
      : () => {};
  }

  /**
   * Create a new task
   * @param {Object} options - Task options
   * @param {string} options.tool - Tool name to execute
   * @param {Object} options.arguments - Tool arguments
   * @param {string} options.sessionId - Session ID
   * @param {Function} options.executor - Function to execute the task
   * @returns {Task} The created task
   */
  createTask(options) {
    const task = new Task({
      tool: options.tool,
      arguments: options.arguments,
      sessionId: options.sessionId,
    });
    
    this.tasks.set(task.id, task);
    this.log(`Task created: ${task.id} for tool ${task.tool}`);
    
    // Schedule execution
    this.scheduleTask(task, options.executor);
    
    return task;
  }

  /**
   * Schedule a task for execution
   * @private
   */
  async scheduleTask(task, executor) {
    if (this.runningCount >= this.maxConcurrentTasks) {
      this.queue.push({ task, executor });
      this.log(`Task ${task.id} queued (${this.queue.length} in queue)`);
      return;
    }
    
    await this.runTask(task, executor);
  }

  /**
   * Run a task
   * @private
   */
  async runTask(task, executor) {
    this.runningCount++;
    task.status = TaskStatus.RUNNING;
    task.startedAt = new Date().toISOString();
    
    this.log(`Task ${task.id} started`);
    await this.sendNotification(task, 'status');
    
    // Set up timeout
    const timeoutId = setTimeout(() => {
      if (task.status === TaskStatus.RUNNING) {
        task.status = TaskStatus.FAILED;
        task.error = { message: 'Task timeout' };
        task.completedAt = new Date().toISOString();
        this.sendNotification(task, 'status');
      }
    }, this.taskTimeout);
    
    try {
      // Create a progress reporter for the task
      const progressReporter = (progress, total = null, message = null) => {
        task.progress = total !== null ? progress / total : progress;
        this.sendNotification(task, 'progress', { progress: task.progress, message });
      };
      
      // Check if cancelled before starting
      if (task.cancelRequested) {
        task.status = TaskStatus.CANCELLED;
        task.completedAt = new Date().toISOString();
        await this.sendNotification(task, 'status');
        return;
      }
      
      // Execute the task
      const result = await executor(task.arguments, {
        taskId: task.id,
        reportProgress: progressReporter,
        isCancelled: () => task.cancelRequested,
      });
      
      clearTimeout(timeoutId);
      
      // Check if cancelled during execution
      if (task.cancelRequested) {
        task.status = TaskStatus.CANCELLED;
      } else {
        task.status = TaskStatus.COMPLETED;
        task.result = result;
      }
      task.completedAt = new Date().toISOString();
      
      this.log(`Task ${task.id} ${task.status}`);
      await this.sendNotification(task, 'status');
      
    } catch (error) {
      clearTimeout(timeoutId);
      
      task.status = TaskStatus.FAILED;
      task.error = {
        message: error.message,
        code: error.code,
      };
      task.completedAt = new Date().toISOString();
      
      this.log(`Task ${task.id} failed: ${error.message}`);
      await this.sendNotification(task, 'status');
      
    } finally {
      this.runningCount--;
      this.processQueue();
    }
  }

  /**
   * Process the next task in the queue
   * @private
   */
  processQueue() {
    if (this.queue.length > 0 && this.runningCount < this.maxConcurrentTasks) {
      const { task, executor } = this.queue.shift();
      this.runTask(task, executor);
    }
  }

  /**
   * Send a notification about task status/progress
   * @private
   */
  async sendNotification(task, type, data = {}) {
    if (!this.notifyFn) return;
    
    const notification = {
      jsonrpc: '2.0',
      method: type === 'progress' 
        ? 'notifications/progress' 
        : 'notifications/tasks/status',
      params: type === 'progress'
        ? {
            progressToken: task.id,
            progress: data.progress,
            total: 1,
            ...(data.message && { message: data.message }),
          }
        : {
            taskId: task.id,
            status: task.status,
            ...(task.result && { result: task.result }),
            ...(task.error && { error: task.error }),
          },
    };
    
    try {
      await this.notifyFn(notification, task.sessionId);
    } catch (error) {
      this.log(`Failed to send notification for task ${task.id}:`, error.message);
    }
  }

  /**
   * Get a task by ID
   * @param {string} taskId - Task ID
   * @returns {Task|null}
   */
  getTask(taskId) {
    return this.tasks.get(taskId) || null;
  }

  /**
   * List tasks, optionally filtered by session
   * @param {string} sessionId - Optional session ID filter
   * @returns {Array} Array of tasks
   */
  listTasks(sessionId = null) {
    const tasks = [];
    for (const task of this.tasks.values()) {
      if (!sessionId || task.sessionId === sessionId) {
        tasks.push(task.toJSON());
      }
    }
    return tasks;
  }

  /**
   * Cancel a task
   * @param {string} taskId - Task ID
   * @returns {boolean} True if task was cancelled
   */
  cancelTask(taskId) {
    const task = this.tasks.get(taskId);
    if (!task) return false;
    
    // Can only cancel queued or running tasks
    if (task.status !== TaskStatus.QUEUED && task.status !== TaskStatus.RUNNING) {
      return false;
    }
    
    task.cancelRequested = true;
    
    // If queued, remove from queue and mark as cancelled
    if (task.status === TaskStatus.QUEUED) {
      const queueIndex = this.queue.findIndex(q => q.task.id === taskId);
      if (queueIndex !== -1) {
        this.queue.splice(queueIndex, 1);
      }
      task.status = TaskStatus.CANCELLED;
      task.completedAt = new Date().toISOString();
      this.sendNotification(task, 'status');
    }
    
    this.log(`Task ${taskId} cancel requested`);
    return true;
  }

  /**
   * Clean up old completed/failed tasks
   * @param {number} maxAge - Maximum age in milliseconds
   */
  cleanup(maxAge = 60 * 60 * 1000) { // 1 hour default
    const cutoff = Date.now() - maxAge;
    let cleaned = 0;
    
    for (const [taskId, task] of this.tasks) {
      if (task.completedAt) {
        const completedTime = new Date(task.completedAt).getTime();
        if (completedTime < cutoff) {
          this.tasks.delete(taskId);
          cleaned++;
        }
      }
    }
    
    if (cleaned > 0) {
      this.log(`Cleaned up ${cleaned} old task(s)`);
    }
  }

  /**
   * Get task statistics
   */
  getStats() {
    let queued = 0, running = 0, completed = 0, failed = 0, cancelled = 0;
    
    for (const task of this.tasks.values()) {
      switch (task.status) {
        case TaskStatus.QUEUED: queued++; break;
        case TaskStatus.RUNNING: running++; break;
        case TaskStatus.COMPLETED: completed++; break;
        case TaskStatus.FAILED: failed++; break;
        case TaskStatus.CANCELLED: cancelled++; break;
      }
    }
    
    return {
      total: this.tasks.size,
      queued,
      running,
      completed,
      failed,
      cancelled,
      queueLength: this.queue.length,
    };
  }

  /**
   * Shutdown the task manager
   */
  async shutdown() {
    // Cancel all queued tasks
    for (const { task } of this.queue) {
      task.status = TaskStatus.CANCELLED;
      task.completedAt = new Date().toISOString();
    }
    this.queue = [];
    
    // Mark running tasks as cancelled
    for (const task of this.tasks.values()) {
      if (task.status === TaskStatus.RUNNING) {
        task.cancelRequested = true;
      }
    }
    
    this.log('Task manager shutdown');
  }
}

module.exports = {
  TaskManager,
  Task,
  TaskStatus,
};
