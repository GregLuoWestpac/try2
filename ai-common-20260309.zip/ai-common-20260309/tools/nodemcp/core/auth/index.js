/**
 * Auth Module
 * 
 * Exports all authentication classes.
 */

const BaseAuthProvider = require('./BaseAuthProvider');
const JWTAuthProvider = require('./JWTAuthProvider');
const APIKeyAuthProvider = require('./APIKeyAuthProvider');
const AuthMiddleware = require('./AuthMiddleware');

module.exports = {
  BaseAuthProvider,
  JWTAuthProvider,
  APIKeyAuthProvider,
  AuthMiddleware,
};
