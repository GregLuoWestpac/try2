/**
 * Base Auth Provider
 * 
 * Abstract base class for authentication providers.
 */

class BaseAuthProvider {
  constructor(options = {}) {
    this.verbose = options.verbose || false;
    this.log = this.verbose
      ? (...args) => console.error(`[${this.constructor.name}]`, ...args)
      : () => {};
  }

  /**
   * Validate an access token
   * @param {string} token - The token to validate
   * @returns {Object} { valid: boolean, claims?: Object, error?: string }
   */
  async validateToken(token) {
    throw new Error('validateToken must be implemented');
  }

  /**
   * Extract user info from a validated token
   * @param {Object} claims - Token claims
   * @returns {Object} User info
   */
  getUserInfo(claims) {
    return {
      id: claims.sub,
      email: claims.email,
      name: claims.name,
      roles: claims.roles || [],
    };
  }

  /**
   * Check if a user has required permissions
   * @param {Object} claims - Token claims
   * @param {Array} requiredPermissions - Required permissions
   * @returns {boolean}
   */
  hasPermissions(claims, requiredPermissions) {
    const userPermissions = claims.permissions || claims.scope?.split(' ') || [];
    return requiredPermissions.every(p => userPermissions.includes(p));
  }

  /**
   * Check if a user has required roles
   * @param {Object} claims - Token claims
   * @param {Array} requiredRoles - Required roles
   * @returns {boolean}
   */
  hasRoles(claims, requiredRoles) {
    const userRoles = claims.roles || [];
    return requiredRoles.every(r => userRoles.includes(r));
  }
}

module.exports = BaseAuthProvider;
