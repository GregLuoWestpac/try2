/**
 * Auth Middleware
 * 
 * Middleware that validates authentication tokens and attaches user context.
 */

class AuthMiddleware {
  constructor(options = {}) {
    this.provider = options.provider;
    this.required = options.required !== false; // Auth required by default
    this.requiredPermissions = options.requiredPermissions || [];
    this.requiredRoles = options.requiredRoles || [];
    this.extractToken = options.extractToken || this.defaultExtractToken;
    this.verbose = options.verbose || false;
    
    this.log = this.verbose
      ? (...args) => console.error('[AuthMiddleware]', ...args)
      : () => {};
  }

  async process(request, context, next) {
    // Extract token from context
    const token = this.extractToken(context);
    
    // If no token and auth required, reject
    if (!token && this.required) {
      this.log('Authentication required but no token provided');
      return {
        jsonrpc: '2.0',
        id: request.id,
        error: {
          code: -32000,
          message: 'Authentication required',
          data: { reason: 'no_token' },
        },
      };
    }

    // If token provided, validate it
    if (token && this.provider) {
      const result = await this.provider.validateToken(token);
      
      if (!result.valid) {
        this.log('Token validation failed:', result.error);
        return {
          jsonrpc: '2.0',
          id: request.id,
          error: {
            code: -32000,
            message: 'Authentication failed',
            data: { reason: result.error },
          },
        };
      }

      // Check required permissions
      if (this.requiredPermissions.length > 0) {
        if (!this.provider.hasPermissions(result.claims, this.requiredPermissions)) {
          this.log('Insufficient permissions');
          return {
            jsonrpc: '2.0',
            id: request.id,
            error: {
              code: -32000,
              message: 'Insufficient permissions',
              data: { required: this.requiredPermissions },
            },
          };
        }
      }

      // Check required roles
      if (this.requiredRoles.length > 0) {
        if (!this.provider.hasRoles(result.claims, this.requiredRoles)) {
          this.log('Insufficient roles');
          return {
            jsonrpc: '2.0',
            id: request.id,
            error: {
              code: -32000,
              message: 'Insufficient roles',
              data: { required: this.requiredRoles },
            },
          };
        }
      }

      // Attach user info to context
      context.auth = {
        authenticated: true,
        claims: result.claims,
        user: this.provider.getUserInfo(result.claims),
      };
    } else {
      // No token, mark as unauthenticated
      context.auth = {
        authenticated: false,
        claims: null,
        user: null,
      };
    }

    return await next();
  }

  /**
   * Default token extraction from context
   */
  defaultExtractToken(context) {
    // Try authorization header
    if (context.authToken) {
      return context.authToken;
    }
    
    // Try headers if available
    if (context.headers?.authorization) {
      const auth = context.headers.authorization;
      if (auth.startsWith('Bearer ')) {
        return auth.substring(7);
      }
    }
    
    return null;
  }
}

module.exports = AuthMiddleware;
