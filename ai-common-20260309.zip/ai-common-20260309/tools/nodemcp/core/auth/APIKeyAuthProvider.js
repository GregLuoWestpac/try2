/**
 * API Key Auth Provider
 * 
 * Simple authentication using API keys.
 */

const crypto = require('crypto');

class APIKeyAuthProvider {
  constructor(options = {}) {
    this.keys = new Map(); // key -> { name, permissions, roles, metadata }
    this.hashKeys = options.hashKeys !== false; // Hash stored keys by default
    this.verbose = options.verbose || false;
    
    this.log = this.verbose
      ? (...args) => console.error('[APIKeyAuthProvider]', ...args)
      : () => {};

    // Load keys from options
    if (options.keys) {
      for (const [key, data] of Object.entries(options.keys)) {
        this.addKey(key, data);
      }
    }

    // Load from environment
    this.loadFromEnv();
  }

  /**
   * Load API keys from environment variables
   * Format: MCP_API_KEY_<NAME>=<key>
   */
  loadFromEnv() {
    for (const [envKey, value] of Object.entries(process.env)) {
      if (envKey.startsWith('MCP_API_KEY_')) {
        const name = envKey.substring(12).toLowerCase();
        this.addKey(value, { name, permissions: ['*'], roles: ['api-user'] });
        this.log(`Loaded API key from env: ${name}`);
      }
    }
  }

  /**
   * Add an API key
   */
  addKey(key, data = {}) {
    const storageKey = this.hashKeys ? this.hashKey(key) : key;
    this.keys.set(storageKey, {
      name: data.name || 'unnamed',
      permissions: data.permissions || [],
      roles: data.roles || [],
      metadata: data.metadata || {},
      createdAt: new Date().toISOString(),
    });
  }

  /**
   * Remove an API key
   */
  removeKey(key) {
    const storageKey = this.hashKeys ? this.hashKey(key) : key;
    return this.keys.delete(storageKey);
  }

  /**
   * Hash a key for secure storage
   */
  hashKey(key) {
    return crypto.createHash('sha256').update(key).digest('hex');
  }

  /**
   * Validate an API key
   */
  async validateToken(key) {
    if (!key) {
      return { valid: false, error: 'No API key provided' };
    }

    const storageKey = this.hashKeys ? this.hashKey(key) : key;
    const keyData = this.keys.get(storageKey);

    if (!keyData) {
      this.log('Invalid API key attempted');
      return { valid: false, error: 'Invalid API key' };
    }

    this.log('API key validated:', keyData.name);
    
    return {
      valid: true,
      claims: {
        sub: keyData.name,
        name: keyData.name,
        permissions: keyData.permissions,
        roles: keyData.roles,
        type: 'api-key',
        ...keyData.metadata,
      },
    };
  }

  /**
   * Extract user info from claims
   */
  getUserInfo(claims) {
    return {
      id: claims.sub,
      name: claims.name,
      roles: claims.roles || [],
      permissions: claims.permissions || [],
      type: 'api-key',
    };
  }

  /**
   * Check permissions
   */
  hasPermissions(claims, requiredPermissions) {
    const userPermissions = claims.permissions || [];
    
    // Wildcard permission grants all
    if (userPermissions.includes('*')) {
      return true;
    }
    
    return requiredPermissions.every(p => userPermissions.includes(p));
  }

  /**
   * Check roles
   */
  hasRoles(claims, requiredRoles) {
    const userRoles = claims.roles || [];
    return requiredRoles.every(r => userRoles.includes(r));
  }

  /**
   * Generate a new API key
   */
  static generateKey(length = 32) {
    return crypto.randomBytes(length).toString('base64url');
  }
}

module.exports = APIKeyAuthProvider;
