/**
 * JWT Auth Provider
 * 
 * Authentication provider for JWT (JSON Web Token) validation.
 * Supports HS256, RS256, and other common algorithms.
 */

const crypto = require('crypto');

class JWTAuthProvider {
  constructor(options = {}) {
    this.secret = options.secret || process.env.JWT_SECRET;
    this.publicKey = options.publicKey || process.env.JWT_PUBLIC_KEY;
    this.algorithms = options.algorithms || ['HS256'];
    this.issuer = options.issuer;
    this.audience = options.audience;
    this.clockTolerance = options.clockTolerance || 60; // seconds
    this.verbose = options.verbose || false;
    
    this.log = this.verbose
      ? (...args) => console.error('[JWTAuthProvider]', ...args)
      : () => {};
  }

  /**
   * Validate a JWT token
   * @param {string} token - The JWT token to validate
   * @returns {Object} { valid: boolean, claims?: Object, error?: string }
   */
  async validateToken(token) {
    try {
      // Split the token
      const parts = token.split('.');
      if (parts.length !== 3) {
        return { valid: false, error: 'Invalid token format' };
      }

      const [headerB64, payloadB64, signatureB64] = parts;

      // Decode header
      const header = JSON.parse(this.base64UrlDecode(headerB64));
      
      // Check algorithm
      if (!this.algorithms.includes(header.alg)) {
        return { valid: false, error: `Unsupported algorithm: ${header.alg}` };
      }

      // Verify signature
      const isValid = this.verifySignature(headerB64, payloadB64, signatureB64, header.alg);
      if (!isValid) {
        return { valid: false, error: 'Invalid signature' };
      }

      // Decode and validate payload
      const claims = JSON.parse(this.base64UrlDecode(payloadB64));
      
      // Check expiration
      const now = Math.floor(Date.now() / 1000);
      if (claims.exp && now > claims.exp + this.clockTolerance) {
        return { valid: false, error: 'Token expired' };
      }

      // Check not-before
      if (claims.nbf && now < claims.nbf - this.clockTolerance) {
        return { valid: false, error: 'Token not yet valid' };
      }

      // Check issuer
      if (this.issuer && claims.iss !== this.issuer) {
        return { valid: false, error: 'Invalid issuer' };
      }

      // Check audience
      if (this.audience) {
        const aud = Array.isArray(claims.aud) ? claims.aud : [claims.aud];
        if (!aud.includes(this.audience)) {
          return { valid: false, error: 'Invalid audience' };
        }
      }

      this.log('Token validated successfully for:', claims.sub);
      return { valid: true, claims };

    } catch (error) {
      this.log('Token validation error:', error.message);
      return { valid: false, error: error.message };
    }
  }

  /**
   * Verify the token signature
   * @private
   */
  verifySignature(headerB64, payloadB64, signatureB64, algorithm) {
    const data = `${headerB64}.${payloadB64}`;
    const signature = this.base64UrlToBuffer(signatureB64);

    switch (algorithm) {
      case 'HS256':
        return this.verifyHMAC(data, signature, 'sha256');
      case 'HS384':
        return this.verifyHMAC(data, signature, 'sha384');
      case 'HS512':
        return this.verifyHMAC(data, signature, 'sha512');
      case 'RS256':
        return this.verifyRSA(data, signature, 'sha256');
      case 'RS384':
        return this.verifyRSA(data, signature, 'sha384');
      case 'RS512':
        return this.verifyRSA(data, signature, 'sha512');
      default:
        throw new Error(`Unsupported algorithm: ${algorithm}`);
    }
  }

  /**
   * Verify HMAC signature
   * @private
   */
  verifyHMAC(data, signature, hash) {
    if (!this.secret) {
      throw new Error('Secret required for HMAC verification');
    }
    const expected = crypto.createHmac(hash, this.secret).update(data).digest();
    return crypto.timingSafeEqual(signature, expected);
  }

  /**
   * Verify RSA signature
   * @private
   */
  verifyRSA(data, signature, hash) {
    if (!this.publicKey) {
      throw new Error('Public key required for RSA verification');
    }
    const verifier = crypto.createVerify(`RSA-${hash.toUpperCase()}`);
    verifier.update(data);
    return verifier.verify(this.publicKey, signature);
  }

  /**
   * Base64URL decode to string
   * @private
   */
  base64UrlDecode(str) {
    let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
    const pad = base64.length % 4;
    if (pad) {
      base64 += '='.repeat(4 - pad);
    }
    return Buffer.from(base64, 'base64').toString('utf8');
  }

  /**
   * Base64URL decode to Buffer
   * @private
   */
  base64UrlToBuffer(str) {
    let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
    const pad = base64.length % 4;
    if (pad) {
      base64 += '='.repeat(4 - pad);
    }
    return Buffer.from(base64, 'base64');
  }

  /**
   * Extract user info from claims
   */
  getUserInfo(claims) {
    return {
      id: claims.sub,
      email: claims.email,
      name: claims.name || claims.preferred_username,
      roles: claims.roles || claims.groups || [],
      permissions: claims.permissions || claims.scope?.split(' ') || [],
    };
  }

  /**
   * Check if claims have required permissions
   */
  hasPermissions(claims, requiredPermissions) {
    const userPermissions = claims.permissions || claims.scope?.split(' ') || [];
    return requiredPermissions.every(p => userPermissions.includes(p));
  }

  /**
   * Check if claims have required roles
   */
  hasRoles(claims, requiredRoles) {
    const userRoles = claims.roles || claims.groups || [];
    return requiredRoles.every(r => userRoles.includes(r));
  }
}

module.exports = JWTAuthProvider;
