#!/usr/bin/env node

/**
 * NodeMCP CLI - Model Context Protocol Server
 * 
 * A modular MCP server that supports multiple providers and transports.
 * Compatible with GitHub Copilot, Claude Code, and other MCP clients.
 * 
 * Usage:
 *   nodemcp [options]
 * 
 * Options:
 *   --all                   Load all available providers (default)
 *   --layers <providers>    Comma-separated list of providers
 *   --transport <type>      Transport: stdio (default) or http
 *   --port <number>         HTTP port (default: 3100)
 *   --host <address>        HTTP host (default: 127.0.0.1)
 *   --require-auth          Require authentication for HTTP
 *   --verbose               Enable verbose logging
 *   --help                  Show help
 */

const path = require('path');
const MCPServer = require('./core/MCPServer');
const ProviderManager = require('./core/ProviderManager');
const StdioTransport = require('./transports/StdioTransport');
const HttpTransport = require('./transports/HttpTransport');

// Parse command line arguments
function parseArgs() {
  const args = process.argv.slice(2);
  const options = {
    all: false,
    layers: [],
    providers: [], // Additional provider paths
    transport: 'stdio',
    port: 3100,
    host: '127.0.0.1',
    requireAuth: false,
    verbose: false,
    help: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    switch (arg) {
      case '--all':
        options.all = true;
        break;

      case '--layers':
        if (args[i + 1] && !args[i + 1].startsWith('-')) {
          options.layers = args[++i].split(',').map(s => s.trim());
        }
        break;

      case '--provider':
      case '-p':
        if (args[i + 1] && !args[i + 1].startsWith('-')) {
          options.providers.push(args[++i]);
        }
        break;

      case '--transport':
        if (args[i + 1] && !args[i + 1].startsWith('-')) {
          options.transport = args[++i];
        }
        break;

      case '--port':
        if (args[i + 1] && !args[i + 1].startsWith('-')) {
          options.port = parseInt(args[++i], 10);
        }
        break;

      case '--host':
        if (args[i + 1] && !args[i + 1].startsWith('-')) {
          options.host = args[++i];
        }
        break;

      case '--require-auth':
        options.requireAuth = true;
        break;

      case '--verbose':
      case '-v':
        options.verbose = true;
        break;

      case '--help':
      case '-h':
        options.help = true;
        break;
    }
  }

  // Default to all if no layers or providers specified
  if (options.layers.length === 0 && options.providers.length === 0) {
    options.all = true;
  }

  return options;
}

function showHelp() {
  console.log(`
NodeMCP - Model Context Protocol Server Framework

Usage: nodemcp [options]

Options:
  --all                   Load all available providers (default)
  --layers <providers>    Comma-separated list of providers to load
                          Example: --layers splunk,docsearch
  --provider <path>, -p   Load a provider from a specific path
                          Can be used multiple times
  --transport <type>      Transport type: stdio (default) or http
  --port <number>         HTTP server port (default: 3100)
  --host <address>        HTTP server host (default: 127.0.0.1)
  --require-auth          Require Bearer token authentication for HTTP
  --verbose, -v           Enable verbose logging
  --help, -h              Show this help message

Examples:
  nodemcp                             # Run with all providers via STDIO
  nodemcp --layers splunk             # Run with Splunk provider only
  nodemcp --layers docsearch -v       # Run DocSearch with verbose logging
  nodemcp --transport http            # Run HTTP server on port 3100
  nodemcp --layers splunk,docsearch   # Run with multiple providers
  nodemcp -p ./my-provider            # Load custom provider from path

Transports:
  stdio     Standard input/output (default)
            Best for: GitHub Copilot, Claude Code local
            
  http      HTTP with optional SSE streaming
            Best for: Remote connections, web-based clients
            URL: http://<host>:<port>/mcp

Providers:
  splunk        Splunk search and monitoring
  docsearch     Reverse HyDE document search
  jira          Jira issue tracking (coming soon)
  artifactory   Artifactory artifact management (coming soon)
  bitbucket     Bitbucket code repositories (coming soon)
`);
}

async function main() {
  const options = parseArgs();

  if (options.help) {
    showHelp();
    process.exit(0);
  }

  // Set up logging
  const log = options.verbose
    ? (...args) => console.error('[NodeMCP]', ...args)
    : () => {};

  log('Starting NodeMCP server...');
  log('Options:', JSON.stringify(options, null, 2));

  try {
    // Initialize provider manager
    // mcps directory is at tools/mcps (sibling to nodemcp)
    const mcpsPath = path.join(__dirname, '..', 'mcps');
    const providerManager = new ProviderManager(mcpsPath, { verbose: options.verbose });

    // Load providers from --layers
    if (options.all) {
      await providerManager.loadAllProviders();
    } else if (options.layers.length > 0) {
      await providerManager.loadProviders(options.layers);
    }

    // Load providers from --provider paths
    for (const providerPath of options.providers) {
      const resolvedPath = path.resolve(providerPath);
      log(`Loading provider from path: ${resolvedPath}`);
      await providerManager.loadProviderFromPath(resolvedPath);
    }

    log(`Loaded ${providerManager.getProviderCount()} provider(s)`);

    // Create MCP server
    const server = new MCPServer({
      name: 'nodemcp',
      version: '1.0.0',
      providerManager,
      verbose: options.verbose,
    });

    // Create transport
    let transport;
    if (options.transport === 'http') {
      transport = new HttpTransport({
        port: options.port,
        host: options.host,
        requireAuth: options.requireAuth,
        verbose: options.verbose,
      });
    } else {
      transport = new StdioTransport({
        verbose: options.verbose,
      });
    }

    // Start server with transport
    await server.start(transport);

    if (options.transport === 'http') {
      // Always show HTTP startup message
      console.error(`[NodeMCP] HTTP server listening on http://${options.host}:${options.port}/mcp`);
    } else {
      // Always show STDIO ready message so user knows server is running
      console.error(`[NodeMCP] Server ready (STDIO transport, ${providerManager.getProviderCount()} provider(s) loaded)`);
      console.error('[NodeMCP] Waiting for MCP client connection...');
    }

    log('Use --verbose for detailed logging');

    // Handle shutdown
    process.on('SIGINT', async () => {
      log('Shutting down...');
      await server.stop();
      process.exit(0);
    });

    process.on('SIGTERM', async () => {
      log('Shutting down...');
      await server.stop();
      process.exit(0);
    });

  } catch (error) {
    console.error('Failed to start NodeMCP:', error.message);
    if (options.verbose) {
      console.error(error.stack);
    }
    process.exit(1);
  }
}

main();
