/**
 * STDIO Transport
 * 
 * Implements the MCP STDIO transport for local communication.
 * Messages are newline-delimited JSON-RPC 2.0 messages over stdin/stdout.
 */

const readline = require('readline');

class StdioTransport {
  constructor(options = {}) {
    this.verbose = options.verbose || false;
    this.type = 'stdio';
    this.messageHandler = null;
    this.rl = null;
    
    this.log = this.verbose
      ? (...args) => console.error('[StdioTransport]', ...args)
      : () => {};
  }

  /**
   * Set the message handler callback
   */
  onMessage(handler) {
    this.messageHandler = handler;
  }

  /**
   * Start the STDIO transport
   */
  async start() {
    // Create readline interface for stdin
    this.rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
      terminal: false,
    });

    // Handle incoming lines
    this.rl.on('line', async (line) => {
      await this.handleLine(line);
    });

    // Handle stdin close
    this.rl.on('close', () => {
      this.log('STDIO input closed');
      process.exit(0);
    });

    // Handle errors
    process.stdin.on('error', (error) => {
      this.log('STDIO error:', error.message);
    });

    this.log('STDIO transport started');
  }

  /**
   * Handle incoming line of data
   */
  async handleLine(line) {
    line = line.trim();
    if (!line) return;

    this.log('Received:', line.substring(0, 200) + (line.length > 200 ? '...' : ''));

    try {
      const message = JSON.parse(line);
      
      if (this.messageHandler) {
        const response = await this.messageHandler(message, {});
        
        if (response !== null) {
          await this.send(response);
        }
      }
    } catch (error) {
      this.log('Error parsing message:', error.message);
      
      // Send parse error response
      await this.send({
        jsonrpc: '2.0',
        id: null,
        error: {
          code: -32700,
          message: 'Parse error: ' + error.message,
        },
      });
    }
  }

  /**
   * Send a message via stdout
   */
  async send(message) {
    const json = JSON.stringify(message);
    this.log('Sending:', json.substring(0, 200) + (json.length > 200 ? '...' : ''));
    
    // Write to stdout with newline delimiter
    process.stdout.write(json + '\n');
  }

  /**
   * Stop the STDIO transport
   */
  async stop() {
    if (this.rl) {
      this.rl.close();
    }
    this.log('STDIO transport stopped');
  }
}

module.exports = StdioTransport;
