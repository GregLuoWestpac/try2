/**
 * HTTP Transport
 * 
 * Implements the MCP Streamable HTTP transport for remote communication.
 * Supports POST for requests and optional SSE for streaming responses.
 */

const http = require('http');
const { v4: uuidv4 } = require('uuid');

class HttpTransport {
  constructor(options = {}) {
    this.port = options.port || 3100;
    this.host = options.host || '127.0.0.1';
    this.requireAuth = options.requireAuth || false;
    this.verbose = options.verbose || false;
    this.type = 'http';
    
    this.messageHandler = null;
    this.server = null;
    this.sessions = new Map();
    this.sseClients = new Map();
    
    this.log = this.verbose
      ? (...args) => console.error('[HttpTransport]', ...args)
      : () => {};
  }

  /**
   * Set the message handler callback
   */
  onMessage(handler) {
    this.messageHandler = handler;
  }

  /**
   * Start the HTTP server
   */
  async start() {
    return new Promise((resolve, reject) => {
      this.server = http.createServer((req, res) => {
        this.handleRequest(req, res);
      });

      this.server.on('error', (error) => {
        this.log('HTTP server error:', error.message);
        reject(error);
      });

      this.server.listen(this.port, this.host, () => {
        this.log(`HTTP server listening on http://${this.host}:${this.port}`);
        resolve();
      });
    });
  }

  /**
   * Handle incoming HTTP request
   */
  async handleRequest(req, res) {
    const url = new URL(req.url, `http://${this.host}:${this.port}`);
    
    // Always log incoming requests for debugging
    console.error(`[HttpTransport] ${req.method} ${url.pathname}`);
    
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, Accept, Mcp-Session-Id, MCP-Protocol-Version');
    res.setHeader('Access-Control-Expose-Headers', 'Mcp-Session-Id');

    // Handle preflight
    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }

    // Only handle /mcp endpoint
    if (url.pathname !== '/mcp') {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Not Found' }));
      return;
    }

    // Validate Origin header for security (prevent DNS rebinding)
    const origin = req.headers['origin'];
    if (origin && !this.isAllowedOrigin(origin)) {
      res.writeHead(403, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Forbidden: Invalid origin' }));
      return;
    }

    // Check authentication if required
    if (this.requireAuth && !this.isAuthenticated(req)) {
      res.writeHead(401, { 
        'Content-Type': 'application/json',
        'WWW-Authenticate': 'Bearer',
      });
      res.end(JSON.stringify({ error: 'Unauthorized' }));
      return;
    }

    // Route by method
    switch (req.method) {
      case 'POST':
        await this.handlePost(req, res);
        break;
      case 'GET':
        await this.handleGet(req, res);
        break;
      case 'DELETE':
        await this.handleDelete(req, res);
        break;
      default:
        res.writeHead(405, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Method Not Allowed' }));
    }
  }

  /**
   * Handle POST request (JSON-RPC message)
   */
  async handlePost(req, res) {
    const sessionId = req.headers['mcp-session-id'];
    const acceptHeader = req.headers['accept'] || '';
    
    // Read request body
    let body = '';
    for await (const chunk of req) {
      body += chunk;
    }

    if (!body) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Bad Request: Empty body' }));
      return;
    }

    let message;
    try {
      message = JSON.parse(body);
    } catch (error) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        jsonrpc: '2.0',
        id: null,
        error: { code: -32700, message: 'Parse error' },
      }));
      return;
    }

    this.log('Received POST:', JSON.stringify(message).substring(0, 200));

    // Handle the message
    if (this.messageHandler) {
      const context = { sessionId };
      const response = await this.messageHandler(message, context);

      if (response === null) {
        // Notification or response - no response needed
        res.writeHead(202);
        res.end();
        return;
      }

      // Check if response has a session ID (from initialize)
      if (response._sessionId) {
        res.setHeader('Mcp-Session-Id', response._sessionId);
        delete response._sessionId;
      }

      // Check if client accepts SSE
      const supportsSSE = acceptHeader.includes('text/event-stream');
      
      if (supportsSSE && this.shouldUseSSE(message)) {
        // Stream response via SSE
        await this.sendSSEResponse(res, response);
      } else {
        // Send JSON response
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(response));
      }
    }
  }

  /**
   * Handle GET request (SSE stream for server-initiated messages)
   */
  async handleGet(req, res) {
    const sessionId = req.headers['mcp-session-id'];
    const acceptHeader = req.headers['accept'] || '';

    if (!acceptHeader.includes('text/event-stream')) {
      res.writeHead(406, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Not Acceptable: Must accept text/event-stream' }));
      return;
    }

    // Set up SSE stream
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    });

    const clientId = uuidv4();
    this.sseClients.set(clientId, { res, sessionId });

    this.log(`SSE client connected: ${clientId}`);

    // Send initial comment to keep connection alive
    res.write(': connected\n\n');

    // Handle client disconnect
    req.on('close', () => {
      this.sseClients.delete(clientId);
      this.log(`SSE client disconnected: ${clientId}`);
    });
  }

  /**
   * Handle DELETE request (terminate session)
   */
  async handleDelete(req, res) {
    const sessionId = req.headers['mcp-session-id'];

    if (sessionId && this.sessions.has(sessionId)) {
      this.sessions.delete(sessionId);
      res.writeHead(204);
      res.end();
    } else {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Session not found' }));
    }
  }

  /**
   * Send response via SSE
   */
  async sendSSEResponse(res, response) {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    });

    const eventId = uuidv4();
    const data = JSON.stringify(response);
    
    res.write(`id: ${eventId}\n`);
    res.write(`data: ${data}\n\n`);
    res.end();
  }

  /**
   * Determine if we should use SSE for this request
   */
  shouldUseSSE(message) {
    // Use SSE for long-running operations like tools/call or tasks
    const sseEnabledMethods = ['tools/call', 'tasks/create'];
    return sseEnabledMethods.includes(message.method);
  }

  /**
   * Check if origin is allowed
   */
  isAllowedOrigin(origin) {
    // Allow localhost origins
    if (origin.includes('localhost') || origin.includes('127.0.0.1')) {
      return true;
    }
    // Add more allowed origins as needed
    return false;
  }

  /**
   * Check if request is authenticated
   */
  isAuthenticated(req) {
    const authHeader = req.headers['authorization'];
    
    if (!authHeader) {
      return false;
    }

    // Check for Bearer token
    if (authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      // Validate token - in production, verify against your auth system
      return token.length > 0;
    }

    return false;
  }

  /**
   * Send a message to connected SSE clients
   */
  async send(message, sessionId = null) {
    const data = JSON.stringify(message);
    
    for (const [clientId, client] of this.sseClients) {
      if (!sessionId || client.sessionId === sessionId) {
        try {
          const eventId = uuidv4();
          client.res.write(`id: ${eventId}\n`);
          client.res.write(`data: ${data}\n\n`);
        } catch (error) {
          this.log(`Error sending to client ${clientId}:`, error.message);
          this.sseClients.delete(clientId);
        }
      }
    }
  }

  /**
   * Stop the HTTP server
   */
  async stop() {
    return new Promise((resolve) => {
      // Close all SSE connections
      for (const [clientId, client] of this.sseClients) {
        try {
          client.res.end();
        } catch (e) {
          // Ignore
        }
      }
      this.sseClients.clear();

      if (this.server) {
        this.server.close(() => {
          this.log('HTTP server stopped');
          resolve();
        });
      } else {
        resolve();
      }
    });
  }
}

module.exports = HttpTransport;
