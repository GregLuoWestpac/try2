/**
 * Test Utilities
 * 
 * Helper functions and assertions for testing MCP servers.
 */

const TestClient = require('./TestClient');
const MemoryTransport = require('./MemoryTransport');

/**
 * Create a test environment with server and client
 * @param {Object} server - MCP server instance
 * @param {Object} options - Options
 * @returns {Object} Test environment
 */
async function createTestEnv(server, options = {}) {
  const transport = new MemoryTransport({ verbose: options.verbose });
  const client = new TestClient(server);
  
  // Initialize client
  await client.initialize(options.clientInfo, options.capabilities);
  
  return {
    server,
    transport,
    client,
    cleanup: async () => {
      await client.shutdown().catch(() => {});
    },
  };
}

/**
 * Assert that a tool exists
 * @param {TestClient} client - Test client
 * @param {string} toolName - Expected tool name
 */
async function assertToolExists(client, toolName) {
  const tools = await client.listTools();
  const tool = tools.find(t => t.name === toolName);
  if (!tool) {
    throw new Error(`Tool not found: ${toolName}`);
  }
  return tool;
}

/**
 * Assert that a resource exists
 * @param {TestClient} client - Test client
 * @param {string} uri - Expected resource URI
 */
async function assertResourceExists(client, uri) {
  const resources = await client.listResources();
  const resource = resources.find(r => r.uri === uri || r.uriTemplate === uri);
  if (!resource) {
    throw new Error(`Resource not found: ${uri}`);
  }
  return resource;
}

/**
 * Assert that a prompt exists
 * @param {TestClient} client - Test client
 * @param {string} promptName - Expected prompt name
 */
async function assertPromptExists(client, promptName) {
  const prompts = await client.listPrompts();
  const prompt = prompts.find(p => p.name === promptName);
  if (!prompt) {
    throw new Error(`Prompt not found: ${promptName}`);
  }
  return prompt;
}

/**
 * Assert tool result contains expected text
 * @param {Object} result - Tool result
 * @param {string} expectedText - Text to find
 */
function assertResultContains(result, expectedText) {
  const text = result.content
    .filter(c => c.type === 'text')
    .map(c => c.text)
    .join('\n');
  
  if (!text.includes(expectedText)) {
    throw new Error(`Expected result to contain "${expectedText}", got: ${text}`);
  }
}

/**
 * Assert tool result is not an error
 * @param {Object} result - Tool result
 */
function assertNotError(result) {
  if (result.isError) {
    const errorText = result.content
      .filter(c => c.type === 'text')
      .map(c => c.text)
      .join('\n');
    throw new Error(`Unexpected error: ${errorText}`);
  }
}

/**
 * Assert tool result is an error
 * @param {Object} result - Tool result
 * @param {string} expectedMessage - Expected error message (optional)
 */
function assertIsError(result, expectedMessage = null) {
  if (!result.isError) {
    throw new Error('Expected error result');
  }
  
  if (expectedMessage) {
    const errorText = result.content
      .filter(c => c.type === 'text')
      .map(c => c.text)
      .join('\n');
    if (!errorText.includes(expectedMessage)) {
      throw new Error(`Expected error message "${expectedMessage}", got: ${errorText}`);
    }
  }
}

/**
 * Create a mock provider for testing
 * @param {string} name - Provider name
 * @param {Object} definition - Provider definition
 * @returns {Object} Mock provider instance
 */
function createMockProvider(name, definition = {}) {
  const BaseProvider = require('../core/BaseProvider');
  
  class MockProvider extends BaseProvider {
    constructor(options) {
      super(options);
      this.name = name;
      
      // Register tools
      if (definition.tools) {
        for (const tool of definition.tools) {
          this.registerTool(tool);
        }
      }
      
      // Register resources
      if (definition.resources) {
        for (const resource of definition.resources) {
          this.registerResource(resource);
        }
      }
      
      // Register prompts
      if (definition.prompts) {
        for (const prompt of definition.prompts) {
          this.registerPrompt(prompt);
        }
      }
    }
    
    async initialize() {
      if (definition.initialize) {
        await definition.initialize.call(this);
      }
    }
    
    async shutdown() {
      if (definition.shutdown) {
        await definition.shutdown.call(this);
      }
    }
  }
  
  return MockProvider;
}

/**
 * Run a test with timeout
 * @param {Function} testFn - Test function
 * @param {number} timeout - Timeout in milliseconds
 */
async function withTimeout(testFn, timeout = 5000) {
  return Promise.race([
    testFn(),
    new Promise((_, reject) => 
      setTimeout(() => reject(new Error('Test timeout')), timeout)
    ),
  ]);
}

module.exports = {
  TestClient,
  MemoryTransport,
  createTestEnv,
  assertToolExists,
  assertResourceExists,
  assertPromptExists,
  assertResultContains,
  assertNotError,
  assertIsError,
  createMockProvider,
  withTimeout,
};
