/**
 * Test Client
 * 
 * A test client for testing MCP servers without network transport.
 * Useful for unit testing providers and server functionality.
 */

class TestClient {
  constructor(server) {
    this.server = server;
    this.requestId = 0;
    this.sessionId = null;
    this.initialized = false;
    this.serverCapabilities = null;
  }

  /**
   * Initialize the client
   * @param {Object} clientInfo - Client information
   * @param {Object} capabilities - Client capabilities
   * @returns {Object} Initialize result with server capabilities
   */
  async initialize(clientInfo = {}, capabilities = {}) {
    const response = await this.sendRequest('initialize', {
      protocolVersion: '2025-06-18',
      capabilities: {
        roots: { listChanged: true },
        sampling: {},
        ...capabilities,
      },
      clientInfo: {
        name: 'test-client',
        version: '1.0.0',
        ...clientInfo,
      },
    });

    this.serverCapabilities = response.capabilities;
    this.initialized = true;

    // Send initialized notification
    await this.sendNotification('notifications/initialized');

    return response;
  }

  /**
   * List all available tools
   * @returns {Array} Array of tool definitions
   */
  async listTools() {
    const response = await this.sendRequest('tools/list');
    return response.tools;
  }

  /**
   * Call a tool
   * @param {string} name - Tool name
   * @param {Object} args - Tool arguments
   * @returns {Object} Tool result
   */
  async callTool(name, args = {}) {
    const response = await this.sendRequest('tools/call', {
      name,
      arguments: args,
    });
    return response;
  }

  /**
   * Call a tool and extract text content
   * @param {string} name - Tool name
   * @param {Object} args - Tool arguments
   * @returns {string} Text content from result
   */
  async callToolText(name, args = {}) {
    const result = await this.callTool(name, args);
    if (result.isError) {
      throw new Error(result.content[0]?.text || 'Tool error');
    }
    return result.content
      .filter(c => c.type === 'text')
      .map(c => c.text)
      .join('\n');
  }

  /**
   * List all available resources
   * @returns {Array} Array of resource definitions
   */
  async listResources() {
    const response = await this.sendRequest('resources/list');
    return response.resources;
  }

  /**
   * List all resource templates
   * @returns {Array} Array of resource template definitions
   */
  async listResourceTemplates() {
    const response = await this.sendRequest('resources/templates/list');
    return response.resourceTemplates;
  }

  /**
   * Read a resource
   * @param {string} uri - Resource URI
   * @returns {Object} Resource content
   */
  async readResource(uri) {
    const response = await this.sendRequest('resources/read', { uri });
    return response.contents;
  }

  /**
   * Read a resource and return text content
   * @param {string} uri - Resource URI
   * @returns {string} Text content
   */
  async readResourceText(uri) {
    const contents = await this.readResource(uri);
    return contents.map(c => c.text).join('\n');
  }

  /**
   * Subscribe to a resource
   * @param {string} uri - Resource URI
   * @returns {Object} Subscription result
   */
  async subscribeResource(uri) {
    return await this.sendRequest('resources/subscribe', { uri });
  }

  /**
   * Unsubscribe from a resource
   * @param {string} uri - Resource URI
   * @returns {Object} Unsubscribe result
   */
  async unsubscribeResource(uri) {
    return await this.sendRequest('resources/unsubscribe', { uri });
  }

  /**
   * List all available prompts
   * @returns {Array} Array of prompt definitions
   */
  async listPrompts() {
    const response = await this.sendRequest('prompts/list');
    return response.prompts;
  }

  /**
   * Get a prompt
   * @param {string} name - Prompt name
   * @param {Object} args - Prompt arguments
   * @returns {Object} Prompt result with messages
   */
  async getPrompt(name, args = {}) {
    return await this.sendRequest('prompts/get', {
      name,
      arguments: args,
    });
  }

  /**
   * Create a background task
   * @param {string} tool - Tool name
   * @param {Object} args - Tool arguments
   * @returns {Object} Task creation result
   */
  async createTask(tool, args = {}) {
    return await this.sendRequest('tasks/create', {
      tool,
      arguments: args,
    });
  }

  /**
   * Get task status
   * @param {string} taskId - Task ID
   * @returns {Object} Task status
   */
  async getTask(taskId) {
    return await this.sendRequest('tasks/get', { taskId });
  }

  /**
   * List all tasks
   * @returns {Array} Array of tasks
   */
  async listTasks() {
    const response = await this.sendRequest('tasks/list');
    return response.tasks;
  }

  /**
   * Cancel a task
   * @param {string} taskId - Task ID
   * @returns {Object} Cancellation result
   */
  async cancelTask(taskId) {
    return await this.sendRequest('tasks/cancel', { taskId });
  }

  /**
   * Ping the server
   * @returns {Object} Ping response
   */
  async ping() {
    return await this.sendRequest('ping');
  }

  /**
   * Shutdown the connection
   */
  async shutdown() {
    await this.sendRequest('shutdown');
  }

  /**
   * Send a JSON-RPC request
   * @param {string} method - Method name
   * @param {Object} params - Method parameters
   * @returns {Object} Result
   */
  async sendRequest(method, params = {}) {
    const request = {
      jsonrpc: '2.0',
      id: ++this.requestId,
      method,
      params,
    };

    const context = { sessionId: this.sessionId };
    const response = await this.server.handleMessage(request, context);

    // Handle session ID from initialize
    if (response._sessionId) {
      this.sessionId = response._sessionId;
      delete response._sessionId;
    }

    if (response.error) {
      const error = new Error(response.error.message);
      error.code = response.error.code;
      error.data = response.error.data;
      throw error;
    }

    return response.result;
  }

  /**
   * Send a JSON-RPC notification
   * @param {string} method - Method name
   * @param {Object} params - Method parameters
   */
  async sendNotification(method, params = {}) {
    const notification = {
      jsonrpc: '2.0',
      method,
      params,
    };

    const context = { sessionId: this.sessionId };
    await this.server.handleMessage(notification, context);
  }
}

module.exports = TestClient;
