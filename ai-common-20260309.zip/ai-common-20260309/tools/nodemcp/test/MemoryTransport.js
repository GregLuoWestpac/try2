/**
 * Memory Transport
 * 
 * In-memory transport for testing MCP servers without network overhead.
 */

class MemoryTransport {
  constructor(options = {}) {
    this.type = 'memory';
    this.verbose = options.verbose || false;
    this.messageHandler = null;
    this.sentMessages = []; // Track sent messages for assertions
    this.notifications = []; // Track notifications
    
    this.log = this.verbose
      ? (...args) => console.error('[MemoryTransport]', ...args)
      : () => {};
  }

  /**
   * Set the message handler callback
   */
  onMessage(handler) {
    this.messageHandler = handler;
  }

  /**
   * Start the transport (no-op for memory)
   */
  async start() {
    this.log('Memory transport started');
  }

  /**
   * Stop the transport
   */
  async stop() {
    this.log('Memory transport stopped');
  }

  /**
   * Send a message (simulates server-to-client)
   * @param {Object} message - Message to send
   * @param {string} sessionId - Target session
   */
  async send(message, sessionId = null) {
    this.log('Sending message:', JSON.stringify(message).substring(0, 100));
    this.sentMessages.push({ message, sessionId, timestamp: Date.now() });
    
    // Track notifications separately
    if (!message.id && message.method) {
      this.notifications.push({ message, sessionId, timestamp: Date.now() });
    }
  }

  /**
   * Simulate receiving a message from client
   * @param {Object} message - Message to receive
   * @param {Object} context - Request context
   * @returns {Object} Response from server
   */
  async receive(message, context = {}) {
    if (!this.messageHandler) {
      throw new Error('No message handler set');
    }
    return await this.messageHandler(message, context);
  }

  /**
   * Get all sent messages
   * @returns {Array} Array of sent messages
   */
  getSentMessages() {
    return this.sentMessages;
  }

  /**
   * Get all notifications
   * @returns {Array} Array of notifications
   */
  getNotifications() {
    return this.notifications;
  }

  /**
   * Get notifications by method
   * @param {string} method - Notification method
   * @returns {Array} Matching notifications
   */
  getNotificationsByMethod(method) {
    return this.notifications.filter(n => n.message.method === method);
  }

  /**
   * Clear sent messages and notifications
   */
  clear() {
    this.sentMessages = [];
    this.notifications = [];
  }

  /**
   * Wait for a specific notification
   * @param {string} method - Notification method to wait for
   * @param {number} timeout - Timeout in milliseconds
   * @returns {Object} The notification
   */
  async waitForNotification(method, timeout = 5000) {
    const startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
      const matching = this.getNotificationsByMethod(method);
      if (matching.length > 0) {
        return matching[matching.length - 1].message;
      }
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    
    throw new Error(`Timeout waiting for notification: ${method}`);
  }
}

module.exports = MemoryTransport;
