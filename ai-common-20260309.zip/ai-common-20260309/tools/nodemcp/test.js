/**
 * NodeMCP Test Script
 * 
 * Tests the MCP server by sending JSON-RPC messages via stdin
 */

const { spawn } = require('child_process');
const path = require('path');
const readline = require('readline');

const cliPath = path.join(__dirname, 'cli.js');

// Start the MCP server
const server = spawn('node', [cliPath, '--layers', 'splunk'], {
  stdio: ['pipe', 'pipe', 'pipe'],
});

// Handle stderr for logging
server.stderr.on('data', (data) => {
  // Suppress verbose logging for cleaner test output
});

// Read responses from stdout
const rl = readline.createInterface({
  input: server.stdout,
  terminal: false,
});

const responses = [];

rl.on('line', (line) => {
  try {
    const response = JSON.parse(line);
    responses.push(response);
    console.log('Response:', JSON.stringify(response, null, 2));
  } catch (e) {
    console.log('Raw:', line);
  }
});

// Send a message to the server
function send(message) {
  console.log('\nSending:', JSON.stringify(message));
  server.stdin.write(JSON.stringify(message) + '\n');
}

// Run tests
async function runTests() {
  console.log('=== NodeMCP Protocol Test ===\n');

  // Wait for server to start
  await new Promise(resolve => setTimeout(resolve, 1000));

  // Test 1: Initialize
  console.log('\n--- Test 1: Initialize ---');
  send({
    jsonrpc: '2.0',
    id: 1,
    method: 'initialize',
    params: {
      protocolVersion: '2025-06-18',
      capabilities: {},
      clientInfo: {
        name: 'test-client',
        version: '1.0.0',
      },
    },
  });

  await new Promise(resolve => setTimeout(resolve, 500));

  // Test 2: Send initialized notification
  console.log('\n--- Test 2: Initialized Notification ---');
  send({
    jsonrpc: '2.0',
    method: 'notifications/initialized',
  });

  await new Promise(resolve => setTimeout(resolve, 200));

  // Test 3: List tools
  console.log('\n--- Test 3: List Tools ---');
  send({
    jsonrpc: '2.0',
    id: 2,
    method: 'tools/list',
    params: {},
  });

  await new Promise(resolve => setTimeout(resolve, 500));

  // Test 4: Ping
  console.log('\n--- Test 4: Ping ---');
  send({
    jsonrpc: '2.0',
    id: 3,
    method: 'ping',
    params: {},
  });

  await new Promise(resolve => setTimeout(resolve, 200));

  // Test 5: Call a tool (start_session)
  console.log('\n--- Test 5: Call Tool (start_session) ---');
  send({
    jsonrpc: '2.0',
    id: 4,
    method: 'tools/call',
    params: {
      name: 'splunk_start_session',
      arguments: {
        host: 'https://splunk.example.com:8089',
      },
    },
  });

  await new Promise(resolve => setTimeout(resolve, 500));

  // Give time for responses
  await new Promise(resolve => setTimeout(resolve, 1000));

  console.log('\n=== Test Complete ===');
  console.log(`Received ${responses.length} responses`);
  
  server.stdin.end();
  server.kill();
  process.exit(0);
}

runTests().catch(console.error);
