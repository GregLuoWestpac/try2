/**
 * DocSearch Provider Test
 * 
 * Tests the Reverse HyDE document search functionality
 * using the local embedding provider (no API key required)
 */

const DocSearchProvider = require('./index');
const ReverseHyDEEngine = require('./ReverseHyDEEngine');
const { VectorStore } = require('./vectorstore');
const { LocalEmbeddingProvider } = require('./embeddings');
const fs = require('fs');
const path = require('path');

const TEST_DIR = path.resolve(__dirname, '..', '..', '..', 'examples', 'docsearch', '.test-data');

async function cleanup() {
  if (fs.existsSync(TEST_DIR)) {
    fs.rmSync(TEST_DIR, { recursive: true });
  }
}

async function testVectorStore() {
  console.log('\n=== Testing VectorStore ===');
  
  const storePath = path.join(TEST_DIR, 'test-store');
  const store = new VectorStore();
  
  await store.open(storePath);
  console.log('✓ Store opened');

  // Add vectors
  const dim = 128;
  const embedding1 = new Float32Array(dim).fill(0.1);
  const embedding2 = new Float32Array(dim).fill(0.2);
  
  await store.add('doc1', {
    content: 'Hello world document',
    metadata: { title: 'Test Doc 1' },
    hypotheticalQueries: ['hello query', 'world query']
  }, [embedding1, embedding2]);
  console.log('✓ Document added');

  // Verify stats
  const stats = await store.stats();
  console.log('✓ Stats:', { docs: stats.documentCount, vectors: stats.vectorCount });

  // Search
  const queryEmb = new Float32Array(dim).fill(0.15);
  const results = await store.search(queryEmb, 5);
  console.log('✓ Search returned', results.length, 'results');
  console.log('  Top result:', { docId: results[0]?.docId, score: results[0]?.score?.toFixed(4) });

  // Get document
  const doc = await store.get('doc1');
  console.log('✓ Get document:', doc?.content?.slice(0, 30));

  // List documents
  const docIds = await store.list();
  console.log('✓ List documents:', docIds);

  // Delete
  await store.delete('doc1');
  const listAfter = await store.list();
  console.log('✓ Delete - remaining docs:', listAfter.length);

  await store.close();
  console.log('✓ Store closed');
}

async function testLocalEmbedding() {
  console.log('\n=== Testing LocalEmbeddingProvider ===');
  
  const provider = new LocalEmbeddingProvider({ dimension: 256 });
  await provider.initialize();
  console.log('✓ Provider initialized, dimension:', provider.dimension);

  // Single embedding
  const emb1 = await provider.embed('Hello world, this is a test document');
  console.log('✓ Single embedding length:', emb1.length);

  // Batch embedding
  const embs = await provider.embedBatch([
    'First document about cats',
    'Second document about dogs',
    'Third document about cats and dogs'
  ]);
  console.log('✓ Batch embeddings:', embs.length, 'vectors');

  // Similar texts should have similar embeddings
  const catEmb = await provider.embed('cats are cute pets');
  const dogEmb = await provider.embed('dogs are loyal pets');
  const carEmb = await provider.embed('cars are vehicles for transportation');

  const cosineSim = (a, b) => {
    let dot = 0, normA = 0, normB = 0;
    for (let i = 0; i < a.length; i++) {
      dot += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    return dot / (Math.sqrt(normA) * Math.sqrt(normB));
  };

  console.log('  cat-dog similarity:', cosineSim(catEmb, dogEmb).toFixed(4));
  console.log('  cat-car similarity:', cosineSim(catEmb, carEmb).toFixed(4));
  console.log('  (cat-dog should be > cat-car for good embeddings)');
}

async function testReverseHyDEEngine() {
  console.log('\n=== Testing ReverseHyDEEngine (local mode) ===');
  
  const engine = new ReverseHyDEEngine({
    storePath: path.join(TEST_DIR, 'hyde-store'),
    embeddingProvider: 'local',
    numQueries: 3
  });

  await engine.initialize();
  console.log('✓ Engine initialized');

  // Test document ingestion with fallback query extraction
  const result = await engine.ingest({
    id: 'test-doc-1',
    content: `
      JavaScript is a programming language commonly used for web development.
      It supports object-oriented, functional, and event-driven programming paradigms.
      Node.js allows running JavaScript on the server side.
      Modern frameworks like React and Vue use JavaScript for building user interfaces.
    `,
    metadata: { type: 'tutorial', topic: 'javascript' }
  });

  console.log('✓ Document ingested');
  console.log('  Doc ID:', result.docId);
  console.log('  Hypothetical queries:', result.hypotheticalQueries.length);
  console.log('  Sample queries:', result.hypotheticalQueries.slice(0, 2));

  // Add another document
  await engine.ingest({
    id: 'test-doc-2',
    content: `
      Python is an interpreted high-level programming language.
      It emphasizes code readability with significant indentation.
      Python supports multiple programming paradigms including procedural, object-oriented, and functional.
      It is widely used for data science, machine learning, and automation.
    `,
    metadata: { type: 'tutorial', topic: 'python' }
  });
  console.log('✓ Second document ingested');

  // Query
  const searchResults = await engine.query('What language is used for web development?', { k: 5 });
  console.log('✓ Search completed');
  console.log('  Results:', searchResults.length);
  for (const r of searchResults) {
    console.log(`    ${r.docId}: score=${r.score.toFixed(4)}, matched="${r.matchedQuery?.slice(0, 50)}..."`);
  }

  // Stats
  const stats = await engine.stats();
  console.log('✓ Stats:', { docs: stats.documentCount, vectors: stats.vectorCount });

  await engine.close();
  console.log('✓ Engine closed');
}

async function testDocSearchProvider() {
  console.log('\n=== Testing DocSearchProvider ===');
  
  // Set environment for local embedding
  process.env.DOCSEARCH_EMBEDDING_PROVIDER = 'local';
  
  const provider = new DocSearchProvider({
    storePath: path.join(TEST_DIR, 'provider-store'),
    embeddingProvider: 'local',
    numQueries: 3,
    verbose: true
  });

  await provider.initialize();
  console.log('✓ Provider initialized with', provider.tools.length, 'tools');
  console.log('  Tools:', provider.tools.map(t => t.name).join(', '));

  // Create mock context
  const mockContext = {};

  // Test ingest tool
  const ingestResult = await provider.tools.find(t => t.name === 'ingest').handler({
    content: 'MCP (Model Context Protocol) is a protocol for AI models to interact with external tools and resources.',
    id: 'mcp-doc',
    metadata: { topic: 'protocol' }
  }, mockContext);
  console.log('✓ Ingest result:', { status: ingestResult.status, docId: ingestResult.docId });

  // Test query tool
  const queryResult = await provider.tools.find(t => t.name === 'query').handler({
    query: 'What is MCP?',
    k: 5
  }, mockContext);
  console.log('✓ Query result:', { count: queryResult.resultCount });

  // Test stats tool
  const statsResult = await provider.tools.find(t => t.name === 'stats').handler({}, mockContext);
  console.log('✓ Stats result:', { 
    docs: statsResult.documentCount, 
    vectors: statsResult.vectorCount,
    provider: statsResult.embeddingProvider
  });

  // Test list tool
  const listResult = await provider.tools.find(t => t.name === 'list').handler({}, mockContext);
  console.log('✓ List result:', listResult.docIds);

  // Test get tool
  const getResult = await provider.tools.find(t => t.name === 'get').handler({
    doc_id: 'mcp-doc'
  }, mockContext);
  console.log('✓ Get result:', { docId: getResult.docId, hasContent: !!getResult.content });

  // Test delete tool
  const deleteResult = await provider.tools.find(t => t.name === 'delete').handler({
    doc_id: 'mcp-doc'
  }, mockContext);
  console.log('✓ Delete result:', deleteResult);

  await provider.shutdown();
  console.log('✓ Provider shutdown');
}

async function main() {
  console.log('DocSearch Provider Tests');
  console.log('========================');
  console.log('Test directory:', TEST_DIR);

  try {
    await cleanup();
    fs.mkdirSync(TEST_DIR, { recursive: true });

    await testVectorStore();
    await testLocalEmbedding();
    await testReverseHyDEEngine();
    await testDocSearchProvider();

    console.log('\n✅ All tests passed!');
  } catch (error) {
    console.error('\n❌ Test failed:', error);
    process.exit(1);
  } finally {
    await cleanup();
  }
}

main();
