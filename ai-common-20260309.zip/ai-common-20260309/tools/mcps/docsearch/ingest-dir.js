#!/usr/bin/env node

//
// DocSearch Directory Ingestion CLI
//
// Ingests all documents from a directory into a docsearch index.
//
// Usage:
//   node ingest-dir.js --src <directory> [options]
//
// Options:
//   --src <path>          Source directory containing documents (required)
//   --pattern <glob>      File pattern to match (default: **/*.md)
//   --store <path>        Index store path (required, or set DOCSEARCH_STORE_PATH env)
//   --source-name <name>  Source collection name for metadata (default: directory name)
//   --queries <n>         Hypothetical queries per document (default: 5)
//   --clear               Clear existing index before ingesting
//   --verbose             Enable verbose logging
//   --help                Show help
//
// Examples:
//   node ingest-dir.js --src ../../../examples/docsearch/solution-designs
//   node ingest-dir.js --src /path/to/docs --store ./my-index --clear
//   node ingest-dir.js --src ./docs --pattern "**/*.txt" --source-name api-docs
//

const path = require('node:path');
const fs = require('node:fs');
const ReverseHyDEEngine = require('./ReverseHyDEEngine');

function parseArgs() {
  const args = process.argv.slice(2);
  const options = {
    src: null,
    pattern: '**/*.md',
    store: null,
    sourceName: null,
    queries: 5,
    clear: false,
    verbose: false,
    help: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    switch (arg) {
      case '--src':
        i++;
        options.src = args[i];
        break;
      case '--pattern':
        i++;
        options.pattern = args[i];
        break;
      case '--store':
        i++;
        options.store = args[i];
        break;
      case '--source-name':
        i++;
        options.sourceName = args[i];
        break;
      case '--queries':
        i++;
        options.queries = Number.parseInt(args[i], 10);
        break;
      case '--clear':
        options.clear = true;
        break;
      case '--verbose':
      case '-v':
        options.verbose = true;
        break;
      case '--help':
      case '-h':
        options.help = true;
        break;
    }
  }

  return options;
}

function showHelp() {
  console.log(`
DocSearch Directory Ingestion

Usage: node ingest-dir.js --src <directory> [options]

Options:
  --src <path>          Source directory containing documents (required)
  --pattern <glob>      File pattern to match (default: **/*.md)
  --store <path>        Index store path (required, or set DOCSEARCH_STORE_PATH)
  --source-name <name>  Source collection name for metadata
  --queries <n>         Hypothetical queries per document (default: 5)
  --clear               Clear existing index before ingesting
  --verbose, -v         Enable verbose logging
  --help, -h            Show this help

Examples:
  node ingest-dir.js --src ../../../examples/docsearch/solution-designs
  node ingest-dir.js --src /path/to/docs --store ./my-index --clear
  `);
}

/**
 * Recursively find files matching a pattern
 */
function findFiles(dir, pattern) {
  const results = [];
  const ext = pattern.includes('.') ? pattern.split('.').pop() : null;
  const recursive = pattern.includes('**');

  const walk = (currentDir) => {
    const entries = fs.readdirSync(currentDir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(currentDir, entry.name);
      if (entry.isDirectory() && recursive) {
        walk(fullPath);
      } else if (entry.isFile()) {
        if (!ext || entry.name.endsWith(`.${ext}`)) {
          results.push(fullPath);
        }
      }
    }
  };

  walk(dir);
  return results.sort((a, b) => a.localeCompare(b));
}

/**
 * Extract first markdown heading as title
 */
function extractTitle(content) {
  const match = content.match(/^#\s+(.+)$/m);
  return match ? match[1].trim() : null;
}

async function main() {
  const options = parseArgs();

  if (options.help) {
    showHelp();
    process.exit(0);
  }

  if (!options.src) {
    console.error('Error: --src <directory> is required');
    showHelp();
    process.exit(1);
  }

  // Resolve store path: --store flag > env var
  if (!options.store) {
    options.store = process.env.DOCSEARCH_STORE_PATH;
  }
  if (!options.store) {
    console.error('Error: --store <path> is required (or set DOCSEARCH_STORE_PATH env var)');
    showHelp();
    process.exit(1);
  }

  const srcDir = path.resolve(options.src);
  if (!fs.existsSync(srcDir)) {
    console.error(`Error: Directory not found: ${srcDir}`);
    process.exit(1);
  }

  const sourceName = options.sourceName || path.basename(srcDir);

  console.log(`\nDocSearch Directory Ingestion`);
  console.log(`${'─'.repeat(40)}`);
  console.log(`Source:     ${srcDir}`);
  console.log(`Pattern:    ${options.pattern}`);
  console.log(`Collection: ${sourceName}`);
  console.log(`Store:      ${options.store}`);
  if (options.clear) console.log(`Clear:      yes (existing index will be cleared)`);
  console.log();

  // Find files
  const files = findFiles(srcDir, options.pattern);
  if (files.length === 0) {
    console.log('No matching files found.');
    process.exit(0);
  }
  console.log(`Found ${files.length} file(s)\n`);

  // Initialize engine
  const engineOptions = {
    storePath: path.resolve(options.store),
    numQueries: options.queries,
    verbose: options.verbose,
  };

  const engine = new ReverseHyDEEngine(engineOptions);
  await engine.initialize();

  // Clear if requested
  if (options.clear) {
    await engine.clear();
    console.log('Index cleared.\n');
  }

  // Ingest files
  let ingested = 0;
  let failed = 0;
  let skipped = 0;

  for (let i = 0; i < files.length; i++) {
    const filePath = files[i];
    const relativePath = path.relative(srcDir, filePath);
    const progress = `[${i + 1}/${files.length}]`;

    try {
      const content = fs.readFileSync(filePath, 'utf-8');
      if (!content.trim()) {
        console.log(`${progress} SKIP  ${relativePath} (empty)`);
        skipped++;
        continue;
      }

      const category = path.dirname(relativePath) === '.'
        ? sourceName
        : path.dirname(relativePath).split(path.sep)[0];
      const filename = path.basename(filePath, path.extname(filePath));

      /** @type {Promise<{vectorCount: number}>} */
      const ingestResult = engine.ingest({
        id: `${sourceName}/${relativePath}`,
        content,
        metadata: {
          source: sourceName,
          category,
          filename,
          relativePath,
          title: extractTitle(content) || filename
        }
      }, {
        numQueries: options.queries
      });
      const result = await ingestResult;

      console.log(`${progress} OK    ${relativePath} → ${result.vectorCount} vectors`);
      ingested++;
    } catch (err) {
      console.error(`${progress} FAIL  ${relativePath}: ${err.message}`);
      failed++;
    }
  }

  // Summary
  console.log(`\n${'─'.repeat(40)}`);
  console.log(`Done. Ingested: ${ingested}, Failed: ${failed}, Skipped: ${skipped}`);

  const stats = await engine.stats();
  console.log(`Index: ${stats.documentCount} documents, ${stats.vectorCount} vectors`);
  console.log(`Store: ${stats.indexPath}`);

  await engine.close();
}

main().catch(err => {
  console.error('Fatal error:', err.message);
  process.exit(1);
});
