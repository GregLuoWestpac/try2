/**
 * VectorStore - Two-Phase File-Mapped Vector Storage
 * 
 * Architecture:
 * - In-memory index (.idx): Memory-mapped embeddings for fast similarity search
 * - On-disk documents (.docs): Random-access document storage
 * 
 * File Format:
 * 
 * Index File (.idx):
 *   Header (64 bytes):
 *     - Magic: "RHYDE001" (8 bytes)
 *     - Version: uint32 LE (4 bytes)
 *     - Dimension: uint32 LE (4 bytes)
 *     - Count: uint32 LE (4 bytes)
 *     - Reserved: 44 bytes
 *   
 *   Vector Entries:
 *     - ID: 36 bytes (UUID)
 *     - DocOffset: uint64 LE (8 bytes)
 *     - DocLength: uint32 LE (4 bytes)
 *     - QueryIndex: uint16 LE (2 bytes)
 *     - Embedding: float32[dimension] (dimension * 4 bytes)
 * 
 * Document Store (.docs):
 *   Per Document:
 *     - Length: uint32 LE (4 bytes)
 *     - JSON payload
 */

const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const MAGIC = 'RHYDE001';
const VERSION = 1;
const HEADER_SIZE = 64;
const ID_SIZE = 36;
const ENTRY_FIXED_SIZE = ID_SIZE + 8 + 4 + 2; // ID + offset + length + queryIndex

class VectorStore {
  constructor(options = {}) {
    this.basePath = null;
    this.indexPath = null;
    this.docsPath = null;
    this.dimension = options.dimension || 0;
    this.vectors = new Map(); // id -> { embedding, docOffset, docLength, queryIndex }
    this.docIndex = new Map(); // docId -> { offset, length }
    this.isDirty = false;
    this.docsHandle = null;
    this.docsWriteOffset = 0;
  }

  /**
   * Open or create a vector store at the given directory path.
   * Creates store.idx and store.docs inside the directory.
   */
  async open(basePath) {
    if (!fs.existsSync(basePath)) {
      fs.mkdirSync(basePath, { recursive: true });
    }

    this.basePath = path.join(basePath, 'store');
    this.indexPath = this.basePath + '.idx';
    this.docsPath = this.basePath + '.docs';

    // Load existing index or create new
    if (fs.existsSync(this.indexPath)) {
      await this._loadIndex();
    }

    // Open docs file for append/read
    if (fs.existsSync(this.docsPath)) {
      const stat = fs.statSync(this.docsPath);
      this.docsWriteOffset = stat.size;
    } else {
      fs.writeFileSync(this.docsPath, Buffer.alloc(0));
      this.docsWriteOffset = 0;
    }

    this.docsHandle = fs.openSync(this.docsPath, 'r+');
  }

  /**
   * Load index from file into memory
   */
  async _loadIndex() {
    const buffer = fs.readFileSync(this.indexPath);
    
    // Validate header
    const magic = buffer.toString('utf8', 0, 8);
    if (magic !== MAGIC) {
      throw new Error(`Invalid index file: bad magic "${magic}"`);
    }

    const version = buffer.readUInt32LE(8);
    if (version !== VERSION) {
      throw new Error(`Unsupported index version: ${version}`);
    }

    this.dimension = buffer.readUInt32LE(12);
    const count = buffer.readUInt32LE(16);

    const entrySize = ENTRY_FIXED_SIZE + (this.dimension * 4);
    let offset = HEADER_SIZE;

    for (let i = 0; i < count; i++) {
      const id = buffer.toString('utf8', offset, offset + ID_SIZE).replace(/\0+$/, '');
      offset += ID_SIZE;

      const docOffset = buffer.readBigUInt64LE(offset);
      offset += 8;

      const docLength = buffer.readUInt32LE(offset);
      offset += 4;

      const queryIndex = buffer.readUInt16LE(offset);
      offset += 2;

      const embedding = new Float32Array(this.dimension);
      for (let j = 0; j < this.dimension; j++) {
        embedding[j] = buffer.readFloatLE(offset);
        offset += 4;
      }

      this.vectors.set(id, {
        embedding,
        docOffset: Number(docOffset),
        docLength,
        queryIndex
      });
    }
  }

  /**
   * Save index to file
   */
  async _saveIndex() {
    if (!this.isDirty) return;

    const count = this.vectors.size;
    const entrySize = ENTRY_FIXED_SIZE + (this.dimension * 4);
    const buffer = Buffer.alloc(HEADER_SIZE + (count * entrySize));

    // Write header
    buffer.write(MAGIC, 0, 8, 'utf8');
    buffer.writeUInt32LE(VERSION, 8);
    buffer.writeUInt32LE(this.dimension, 12);
    buffer.writeUInt32LE(count, 16);

    // Write entries
    let offset = HEADER_SIZE;
    for (const [id, entry] of this.vectors) {
      // Write ID (padded to 36 bytes)
      buffer.write(id.padEnd(ID_SIZE, '\0'), offset, ID_SIZE, 'utf8');
      offset += ID_SIZE;

      buffer.writeBigUInt64LE(BigInt(entry.docOffset), offset);
      offset += 8;

      buffer.writeUInt32LE(entry.docLength, offset);
      offset += 4;

      buffer.writeUInt16LE(entry.queryIndex, offset);
      offset += 2;

      for (let j = 0; j < this.dimension; j++) {
        buffer.writeFloatLE(entry.embedding[j], offset);
        offset += 4;
      }
    }

    fs.writeFileSync(this.indexPath, buffer);
    this.isDirty = false;
  }

  /**
   * Close the store, flushing any changes
   */
  async close() {
    await this._saveIndex();
    if (this.docsHandle !== null) {
      fs.closeSync(this.docsHandle);
      this.docsHandle = null;
    }
  }

  /**
   * Add a document with its embedding vectors
   * 
   * @param {string} docId - Document ID
   * @param {object} docData - Document data { content, metadata, hypotheticalQueries }
   * @param {Float32Array[]} embeddings - Array of embeddings (one per hypothetical query)
   */
  async add(docId, docData, embeddings) {
    if (embeddings.length === 0) {
      throw new Error('At least one embedding required');
    }

    // Set dimension from first embedding if not set
    if (this.dimension === 0) {
      this.dimension = embeddings[0].length;
    }

    // Validate embedding dimensions
    for (const emb of embeddings) {
      if (emb.length !== this.dimension) {
        throw new Error(`Embedding dimension mismatch: expected ${this.dimension}, got ${emb.length}`);
      }
    }

    // Delete existing if present
    await this.delete(docId);

    // Prepare document payload
    const payload = JSON.stringify({
      id: docId,
      content: docData.content,
      metadata: docData.metadata || {},
      hypotheticalQueries: docData.hypotheticalQueries || [],
      timestamp: Date.now()
    });
    const payloadBuffer = Buffer.from(payload, 'utf8');

    // Write document to docs file
    const lengthBuffer = Buffer.alloc(4);
    lengthBuffer.writeUInt32LE(payloadBuffer.length);
    
    const docOffset = this.docsWriteOffset;
    fs.writeSync(this.docsHandle, lengthBuffer, 0, 4, docOffset);
    fs.writeSync(this.docsHandle, payloadBuffer, 0, payloadBuffer.length, docOffset + 4);
    
    const totalLength = 4 + payloadBuffer.length;
    this.docsWriteOffset += totalLength;

    // Add vectors to index (one per hypothetical query)
    for (let i = 0; i < embeddings.length; i++) {
      const vectorId = `${docId}:${i}`;
      this.vectors.set(vectorId, {
        embedding: embeddings[i],
        docOffset,
        docLength: totalLength,
        queryIndex: i
      });
    }

    this.isDirty = true;
  }

  /**
   * Search for k nearest neighbors
   * 
   * @param {Float32Array} queryEmbedding - Query vector
   * @param {number} k - Number of results
   * @param {object} options - Search options
   * @returns {Array} Array of { docId, score, document }
   */
  async search(queryEmbedding, k = 10, options = {}) {
    if (queryEmbedding.length !== this.dimension) {
      throw new Error(`Query dimension mismatch: expected ${this.dimension}, got ${queryEmbedding.length}`);
    }

    // Calculate cosine similarity with all vectors
    const scores = [];
    const seenDocs = new Map(); // docOffset -> best score

    for (const [vectorId, entry] of this.vectors) {
      const score = this._cosineSimilarity(queryEmbedding, entry.embedding);
      
      // Keep best score per document
      const existing = seenDocs.get(entry.docOffset);
      if (!existing || score > existing.score) {
        seenDocs.set(entry.docOffset, {
          vectorId,
          score,
          docOffset: entry.docOffset,
          docLength: entry.docLength,
          queryIndex: entry.queryIndex
        });
      }
    }

    // Sort by score descending
    const sorted = Array.from(seenDocs.values())
      .sort((a, b) => b.score - a.score)
      .slice(0, k);

    // Load documents
    const results = [];
    for (const entry of sorted) {
      const doc = await this._readDocument(entry.docOffset, entry.docLength);
      results.push({
        docId: doc.id,
        score: entry.score,
        matchedQueryIndex: entry.queryIndex,
        matchedQuery: doc.hypotheticalQueries?.[entry.queryIndex] || null,
        document: doc
      });
    }

    return results;
  }

  /**
   * Read document from docs file
   */
  async _readDocument(offset, length) {
    const buffer = Buffer.alloc(length);
    fs.readSync(this.docsHandle, buffer, 0, length, offset);
    
    const payloadLength = buffer.readUInt32LE(0);
    const payload = buffer.toString('utf8', 4, 4 + payloadLength);
    
    return JSON.parse(payload);
  }

  /**
   * Calculate cosine similarity between two vectors
   */
  _cosineSimilarity(a, b) {
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < a.length; i++) {
      dotProduct += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }

    const magnitude = Math.sqrt(normA) * Math.sqrt(normB);
    if (magnitude === 0) return 0;
    
    return dotProduct / magnitude;
  }

  /**
   * Delete a document and its vectors
   */
  async delete(docId) {
    // Find all vectors for this document
    const toDelete = [];
    for (const [vectorId, entry] of this.vectors) {
      if (vectorId.startsWith(docId + ':') || vectorId === docId) {
        toDelete.push(vectorId);
      }
    }

    if (toDelete.length > 0) {
      for (const vectorId of toDelete) {
        this.vectors.delete(vectorId);
      }
      this.isDirty = true;
      return true;
    }

    return false;
  }

  /**
   * Get a document by ID
   */
  async get(docId) {
    // Find any vector for this document
    for (const [vectorId, entry] of this.vectors) {
      if (vectorId.startsWith(docId + ':')) {
        return await this._readDocument(entry.docOffset, entry.docLength);
      }
    }
    return null;
  }

  /**
   * List all document IDs
   */
  async list() {
    const docs = new Set();
    for (const vectorId of this.vectors.keys()) {
      const docId = vectorId.split(':')[0];
      docs.add(docId);
    }
    return Array.from(docs);
  }

  /**
   * Get store statistics
   */
  async stats() {
    const docIds = await this.list();
    return {
      documentCount: docIds.length,
      vectorCount: this.vectors.size,
      dimension: this.dimension,
      indexPath: this.indexPath,
      docsPath: this.docsPath,
      indexSize: fs.existsSync(this.indexPath) ? fs.statSync(this.indexPath).size : 0,
      docsSize: fs.existsSync(this.docsPath) ? fs.statSync(this.docsPath).size : 0
    };
  }

  /**
   * Clear all documents
   */
  async clear() {
    this.vectors.clear();
    this.isDirty = true;
    
    // Truncate docs file
    if (this.docsHandle !== null) {
      fs.ftruncateSync(this.docsHandle, 0);
      this.docsWriteOffset = 0;
    }

    await this._saveIndex();
  }

  /**
   * Flush changes to disk
   */
  async flush() {
    await this._saveIndex();
    if (this.docsHandle !== null) {
      fs.fsyncSync(this.docsHandle);
    }
  }
}

module.exports = VectorStore;
