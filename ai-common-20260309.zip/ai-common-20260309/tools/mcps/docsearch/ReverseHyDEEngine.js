/**
 * Reverse HyDE Engine
 * 
 * Implements Reverse Hypothetical Document Embeddings:
 * 
 * Traditional HyDE: Query → Generate hypothetical document → Embed → Search
 * Reverse HyDE: Document → Generate hypothetical queries → Embed queries → Match real query
 * 
 * Benefits:
 * - Better semantic matching (queries match queries, not query-to-document)
 * - Pre-computation at index time (faster search)
 * - Multiple hypothetical queries per document capture different aspects
 */

const { VectorStore } = require('./vectorstore');
const { createEmbeddingProvider } = require('./embeddings');
const { v4: uuidv4 } = require('uuid');

// Import completions provider from nodemcp core
let createCompletionsProvider;
try {
  createCompletionsProvider = require('../../nodemcp').createCompletionsProvider;
} catch (e) {
  // Fallback: try relative path
  try {
    createCompletionsProvider = require('../../nodemcp/core/completions').createCompletionsProvider;
  } catch (e2) {
    // Last resort: inline null provider
    createCompletionsProvider = null;
  }
}

class ReverseHyDEEngine {
  constructor(options = {}) {
    this.options = options;
    this.verbose = options.verbose || false;
    this.storePath = options.storePath;
    if (!this.storePath) {
      throw new Error('storePath is required — pass it in options or set DOCSEARCH_STORE_PATH env var.');
    }
    this.embeddingType = options.embeddingProvider || process.env.DOCSEARCH_EMBEDDING_PROVIDER || 'local';
    this.numQueries = options.numQueries || parseInt(process.env.DOCSEARCH_HYDE_QUERIES || '5', 10);
    
    // Completions provider configuration
    this.completionsProviderType = options.completionsProvider || process.env.DOCSEARCH_COMPLETIONS_PROVIDER || 'copilot';
    this.completionsProvider = null;
    
    this.vectorStore = new VectorStore();
    this.embeddingProvider = null;
    this.initialized = false;
    
    // Logging helper
    this.log = this.verbose 
      ? (...args) => console.error('[ReverseHyDE]', ...args)
      : () => {};
  }



  /**
   * Initialize the engine
   */
  async initialize() {
    if (this.initialized) return;

    this.log('Initializing Reverse HyDE engine...');
    this.log('  Store path:', this.storePath);
    this.log('  Embedding provider:', this.embeddingType);
    this.log('  Completions provider:', this.completionsProviderType);
    this.log('  Hypothetical queries per doc:', this.numQueries);

    // Create embedding provider
    this.embeddingProvider = createEmbeddingProvider(this.embeddingType, {
      apiKey: this.options.embeddingApiKey || process.env.OPENAI_API_KEY,
      model: this.options.embeddingModel,
      verbose: this.verbose
    });
    await this.embeddingProvider.initialize();

    this.log('  Embedding dimension:', this.embeddingProvider.dimension);

    // Create completions provider for query generation
    if (createCompletionsProvider) {
      this.completionsProvider = createCompletionsProvider(this.completionsProviderType, {
        verbose: this.verbose,
        ...this.options.completionsOptions
      });
      await this.completionsProvider.initialize();
      this.log('  Completions provider ready:', this.completionsProvider.getInfo().name);
    } else {
      this.log('  Completions provider: none (will use fallback extraction)');
    }

    // Open vector store
    await this.vectorStore.open(this.storePath);

    this.log('Engine initialized');
    this.initialized = true;
  }

  /**
   * Ensure engine is initialized
   */
  async _ensureInitialized() {
    if (!this.initialized) {
      await this.initialize();
    }
  }

  /**
   * Ingest a document with Reverse HyDE
   * 
   * @param {object} document - Document to ingest { id?, content, metadata? }
   * @param {object} options - Ingestion options
   * @returns {object} Ingestion result
   */
  async ingest(document, options = {}) {
    await this._ensureInitialized();

    const docId = document.id || uuidv4();
    const content = document.content;
    const metadata = document.metadata || {};

    if (!content || content.trim().length === 0) {
      throw new Error('Document content is required');
    }

    // Generate hypothetical queries for the document
    const numQueries = options.numQueries || this.numQueries;
    const hypotheticalQueries = await this.generateHypotheticalQueries(content, numQueries);

    // Embed all hypothetical queries
    const embeddings = await this.embeddingProvider.embedBatch(hypotheticalQueries);

    // Store document with embeddings
    await this.vectorStore.add(docId, {
      content,
      metadata,
      hypotheticalQueries
    }, embeddings);

    // Flush to disk
    await this.vectorStore.flush();

    return {
      docId,
      hypotheticalQueries,
      vectorCount: embeddings.length
    };
  }

  /**
   * Ingest multiple documents
   */
  async ingestBatch(documents, options = {}) {
    await this._ensureInitialized();

    const results = [];
    for (const doc of documents) {
      try {
        const result = await this.ingest(doc, options);
        results.push({ success: true, ...result });
      } catch (error) {
        results.push({
          success: false,
          docId: doc.id,
          error: error.message
        });
      }
    }

    return results;
  }

  /**
   * Generate hypothetical queries for a document using completions provider
   */
  async generateHypotheticalQueries(content, numQueries = 5) {
    // If no completions provider, use fallback directly
    if (!this.completionsProvider) {
      this.log('No completions provider, using key phrase extraction');
      return this._extractKeyPhrases(content, numQueries);
    }

    // Truncate content if too long
    const maxContentLength = 8000;
    const truncatedContent = content.length > maxContentLength
      ? content.slice(0, maxContentLength) + '...[truncated]'
      : content;

    const prompt = `You are a search query generator. Given the following document, generate ${numQueries} diverse search queries that a user might use to find this document.

The queries should:
1. Cover different aspects and topics in the document
2. Vary in specificity (some broad, some specific)
3. Use natural language as a user would type
4. Be standalone (not referencing the document)

Document:
---
${truncatedContent}
---

Generate exactly ${numQueries} search queries, one per line. Output ONLY the queries, no numbering or explanation.`;

    try {
      this.log('Generating hypothetical queries via', this.completionsProviderType);
      const result = await this.completionsProvider.complete(prompt, {
        model: 'simple', // Use simpler/faster model for query generation
        timeout: 60000,
      });
      
      if (!result.success) {
        throw new Error(result.error || 'Completion failed');
      }
      
      const queries = result.content
        .split('\n')
        .map(q => q.trim())
        .filter(q => q.length > 0 && q.length < 200) // Filter out non-query lines
        .map(q => q.replace(/^\d+[\.\)]\s*/, '')) // Remove numbering like "1. " or "1) "
        .slice(0, numQueries);

      this.log('Generated', queries.length, 'hypothetical queries');
      
      // Ensure we have at least one query
      if (queries.length === 0) {
        return this._extractKeyPhrases(content, numQueries);
      }

      return queries;
    } catch (error) {
      this.log('Query generation failed, using fallback:', error.message);
      return this._extractKeyPhrases(content, numQueries);
    }
  }

  /**
   * Fallback: extract key phrases from content
   */
  _extractKeyPhrases(content, numPhrases) {
    // Simple extraction based on sentences and word frequency
    const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 10);
    const phrases = [];

    // Take first sentence (usually summary)
    if (sentences.length > 0) {
      phrases.push(sentences[0].trim().slice(0, 100));
    }

    // Sample other sentences
    for (let i = 1; i < Math.min(sentences.length, numPhrases); i++) {
      const idx = Math.floor(i * sentences.length / numPhrases);
      phrases.push(sentences[idx].trim().slice(0, 100));
    }

    // Ensure we have at least one phrase
    if (phrases.length === 0) {
      phrases.push(content.slice(0, 100));
    }

    return phrases.slice(0, numPhrases);
  }

  /**
   * Query the document store
   * 
   * @param {string} query - Search query
   * @param {object} options - Search options { k, threshold }
   * @returns {Array} Search results
   */
  async query(query, options = {}) {
    await this._ensureInitialized();

    const k = options.k || 10;
    const threshold = options.threshold || 0.0;

    // Embed the query
    const queryEmbedding = await this.embeddingProvider.embed(query);

    // Search vector store
    const results = await this.vectorStore.search(queryEmbedding, k, options);

    // Filter by threshold
    return results.filter(r => r.score >= threshold).map(r => ({
      docId: r.docId,
      score: r.score,
      matchedQuery: r.matchedQuery,
      content: r.document.content,
      metadata: r.document.metadata,
      timestamp: r.document.timestamp
    }));
  }

  /**
   * Delete a document
   */
  async delete(docId) {
    await this._ensureInitialized();
    const deleted = await this.vectorStore.delete(docId);
    if (deleted) {
      await this.vectorStore.flush();
    }
    return deleted;
  }

  /**
   * Get a document by ID
   */
  async get(docId) {
    await this._ensureInitialized();
    return await this.vectorStore.get(docId);
  }

  /**
   * List all document IDs
   */
  async list() {
    await this._ensureInitialized();
    return await this.vectorStore.list();
  }

  /**
   * Get store statistics
   */
  async stats() {
    await this._ensureInitialized();
    const storeStats = await this.vectorStore.stats();
    return {
      ...storeStats,
      embeddingProvider: this.embeddingType,
      embeddingDimension: this.embeddingProvider.dimension,
      completionsProvider: this.completionsProvider ? this.completionsProviderType : 'none',
      numQueriesPerDoc: this.numQueries
    };
  }

  /**
   * Clear all documents
   */
  async clear() {
    await this._ensureInitialized();
    await this.vectorStore.clear();
  }

  /**
   * Close the engine
   */
  async close() {
    if (this.initialized) {
      await this.vectorStore.close();
      if (this.completionsProvider) {
        await this.completionsProvider.shutdown();
      }
      this.initialized = false;
    }
  }
}

module.exports = ReverseHyDEEngine;
