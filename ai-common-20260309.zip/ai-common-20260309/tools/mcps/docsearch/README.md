# DocSearch MCP Provider

A **Reverse HyDE (Hypothetical Document Embeddings)** document search provider for NodeMCP.

## What is Reverse HyDE?

Traditional HyDE generates a hypothetical document from a query, then embeds that to search:
```
Query → Generate hypothetical document → Embed document → Search
```

**Reverse HyDE** inverts this process - it generates hypothetical queries from documents during indexing:
```
Document → Generate hypothetical queries → Embed queries → (stored)
Real Query → Embed query → Match against hypothetical queries → Return documents
```

### Benefits

1. **Better semantic matching**: Queries match queries, not query-to-document
2. **Pre-computation**: Heavy LLM work happens at index time, not search time
3. **Multiple perspectives**: Each document generates multiple hypothetical queries capturing different aspects
4. **Faster search**: Only embedding comparison at query time

## Quick Start

```bash
# Start the MCP server with docsearch
cd tools/nodemcp
node cli.js --provider ../mcps/docsearch --verbose

# Install dependencies (ONNX runtime is included in package.json)
cd tools/mcps/docsearch
npm install
```

### CLI Ingestion

Ingest a directory of documents without starting the MCP server:

```bash
cd tools/mcps/docsearch

# Ingest markdown files from a directory
node ingest-dir.js --src ../../../examples/docsearch/solution-designs \
                   --store ../../../examples/docsearch --clear

# Options
node ingest-dir.js --help
```

| Flag | Description | Default |
|------|-------------|---------|
| `--src <path>` | Source directory (required) | - |
| `--store <path>` | Store directory (or `DOCSEARCH_STORE_PATH`) | - |
| `--pattern <glob>` | File pattern | `**/*.md` |
| `--source-name <name>` | Collection name for metadata | directory name |
| `--queries <n>` | Hypothetical queries per document | `5` |
| `--clear` | Clear index before ingesting | `false` |
| `--verbose` | Enable debug logging | `false` |

## Embedding Modes

### Neural Embeddings (Default)
When `onnxruntime-node` is installed (included in `package.json`), the provider uses the **all-MiniLM-L6-v2** sentence transformer model shipped at `models/all-MiniLM-L6-v2/`:

```
[LocalEmbedding] Loading ONNX model from tools/mcps/docsearch/models/all-MiniLM-L6-v2/model.onnx
[LocalEmbedding] Using ONNX neural model for high-quality embeddings
```

The model is committed with the tool and loaded from the `models/` directory. No download is attempted — corporate network restrictions block HuggingFace mirrors.

### Hash-Based Embeddings (Fallback)
If `onnxruntime-node` is not available, falls back to hash-based embeddings:
- No external dependencies required
- Uses character n-grams and word frequency
- Lower quality but works immediately

### OpenAI Embeddings (Alternative)
For highest quality, use OpenAI's embedding API:

```bash
export DOCSEARCH_EMBEDDING_PROVIDER=openai
export OPENAI_API_KEY=sk-...
```

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    DocSearch MCP Provider                        │
│  Tools: ingest, ingest_batch, ingest_directory, query,          │
│         get, delete, update, list, clear, stats,                │
│         generate_queries                                        │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                    ReverseHyDEEngine                            │
│  - Generate hypothetical queries from documents                  │
│  - Embed queries using embedding provider                        │
│  - Search by matching real query to hypothetical queries         │
│  - Completions via Copilot CLI (default) or OpenAI              │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                    VectorStore (2-Phase)                        │
│  ┌─────────────────────┐  ┌───────────────────────────────────┐ │
│  │  In-Memory Index    │  │  On-Disk Document Store           │ │
│  │  (store.idx)        │  │  (store.docs)                     │ │
│  │  - Embeddings       │  │  - Full document content          │ │
│  │  - Vector IDs       │  │  - Metadata                       │ │
│  │  Memory-efficient   │  │  - Hypothetical queries           │ │
│  └─────────────────────┘  └───────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

## Storage

`DOCSEARCH_STORE_PATH` is a **directory path**. The VectorStore creates two files inside it:

```
<DOCSEARCH_STORE_PATH>/
  store.idx    # Binary index — embeddings, vector IDs, offsets
  store.docs   # Document content, metadata, generated queries
```

## Installation

The DocSearch provider is included with NodeMCP. To use it:

```javascript
const DocSearchProvider = require('@ai-common/mcp-docsearch');
const { MCPServer } = require('@ai-common/nodemcp');

const server = new MCPServer();
server.addProvider(new DocSearchProvider({
  storePath: './my-index',         // Directory for store.idx + store.docs
  embeddingProvider: 'local',      // Default — ONNX neural model, no API key
  numQueries: 5,
  verbose: true
}));
```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `DOCSEARCH_STORE_PATH` | Directory for vector store files (required) | - |
| `DOCSEARCH_EMBEDDING_PROVIDER` | Embedding provider: `local` or `openai` | `local` |
| `DOCSEARCH_COMPLETIONS_PROVIDER` | Completions provider: `copilot` or `openai` | `copilot` |
| `DOCSEARCH_HYDE_QUERIES` | Number of hypothetical queries per document | `5` |
| `OPENAI_API_KEY` | OpenAI API key (required for openai providers) | - |

### Constructor Options

```javascript
new DocSearchProvider({
  storePath: string,          // Directory for index storage
  embeddingProvider: string,  // 'local' (ONNX) or 'openai'
  numQueries: number,         // Hypothetical queries per doc (default: 5)
  verbose: boolean            // Enable debug logging
})
```

## MCP Tools

### Document Ingestion

#### `ingest`
Ingest a single document into the search index.

```json
{
  "content": "Document text content...",
  "id": "optional-doc-id",
  "metadata": { "title": "My Document", "author": "John" },
  "num_queries": 5
}
```

#### `ingest_batch`
Ingest multiple documents at once.

```json
{
  "documents": [
    { "content": "First doc...", "metadata": { "title": "Doc 1" } },
    { "content": "Second doc...", "id": "doc-2" }
  ]
}
```

#### `ingest_directory`
Ingest all files from a directory.

```json
{
  "directory": "/path/to/docs",
  "pattern": "**/*.md",
  "source_name": "my-docs",
  "clear": false
}
```

### Search

#### `query`
Search for documents using semantic similarity.

```json
{
  "query": "How do I configure authentication?",
  "k": 10,
  "threshold": 0.5
}
```

Response includes:
- `docId`: Document identifier
- `score`: Similarity score (0-1)
- `matchedQuery`: The hypothetical query that matched
- `content`: Document content preview
- `metadata`: Document metadata

### Document Management

#### `get`
Retrieve a document by ID.

```json
{ "doc_id": "my-document-id" }
```

#### `delete`
Delete a document from the index.

```json
{ "doc_id": "my-document-id" }
```

#### `update`
Update an existing document (delete + re-ingest).

```json
{
  "doc_id": "my-document-id",
  "content": "Updated content...",
  "metadata": { "title": "Updated Title" }
}
```

#### `list`
List all document IDs.

```json
{ "limit": 100, "offset": 0 }
```

#### `clear`
Clear all documents (requires confirmation).

```json
{ "confirm": true }
```

### Utilities

#### `stats`
Get index statistics: document count, vector count, storage sizes, embedding configuration.

#### `generate_queries`
Preview hypothetical queries without ingesting.

```json
{
  "content": "Document content...",
  "num_queries": 5
}
```

## Example Usage

```javascript
// Ingest documents
await mcp.call('docsearch_ingest', {
  content: `
    # Authentication Guide
    
    To authenticate with our API, you need to:
    1. Generate an API key in the dashboard
    2. Include the key in the Authorization header
    3. All requests must use HTTPS
  `,
  metadata: {
    title: 'Authentication Guide',
    category: 'security'
  }
});

// Search
const results = await mcp.call('docsearch_query', {
  query: 'How do I get an API key?',
  k: 5
});
```

## Performance Considerations

1. **Index Size**: Each document creates N vectors (where N = num_queries). Consider this for storage planning.

2. **Ingestion Speed**: Query generation calls Copilot CLI (or OpenAI) per document. Use `ingest_directory` or `ingest-dir.js` for batch processing.

3. **Search Speed**: Linear scan over vectors. For >100k vectors, consider adding HNSW index.

4. **Memory Usage**: Index file is loaded into memory. Size = `vectors × dimension × 4 bytes`.

## License

MIT
