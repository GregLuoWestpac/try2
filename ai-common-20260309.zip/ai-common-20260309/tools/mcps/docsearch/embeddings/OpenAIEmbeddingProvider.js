/**
 * OpenAI Embedding Provider
 * 
 * Uses OpenAI's embedding API to generate embeddings.
 * Supports text-embedding-3-small (1536 dimensions) and text-embedding-3-large (3072 dimensions)
 */

const BaseEmbeddingProvider = require('./BaseEmbeddingProvider');
const https = require('https');

class OpenAIEmbeddingProvider extends BaseEmbeddingProvider {
  constructor(options = {}) {
    super(options);
    this.apiKey = options.apiKey || process.env.OPENAI_API_KEY;
    this.model = options.model || 'text-embedding-3-small';
    this.baseUrl = options.baseUrl || 'https://api.openai.com';
    
    // Dimension by model
    this._dimension = this.model === 'text-embedding-3-large' ? 3072 : 1536;
  }

  async initialize() {
    if (!this.apiKey) {
      throw new Error('OpenAI API key required. Set OPENAI_API_KEY environment variable.');
    }
  }

  /**
   * Generate embedding for a single text
   */
  async embed(text) {
    const embeddings = await this.embedBatch([text]);
    return embeddings[0];
  }

  /**
   * Generate embeddings for multiple texts
   */
  async embedBatch(texts) {
    if (texts.length === 0) return [];

    const response = await this._request('/v1/embeddings', {
      model: this.model,
      input: texts
    });

    // Sort by index to ensure correct order
    const sorted = response.data.sort((a, b) => a.index - b.index);
    
    return sorted.map(item => {
      const embedding = new Float32Array(item.embedding);
      return this.normalize(embedding);
    });
  }

  /**
   * Make HTTP request to OpenAI API
   */
  async _request(path, body) {
    return new Promise((resolve, reject) => {
      const url = new URL(path, this.baseUrl);
      const data = JSON.stringify(body);

      const options = {
        hostname: url.hostname,
        port: url.port || 443,
        path: url.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Length': Buffer.byteLength(data)
        }
      };

      const req = https.request(options, (res) => {
        let responseData = '';
        
        res.on('data', (chunk) => {
          responseData += chunk;
        });

        res.on('end', () => {
          try {
            const json = JSON.parse(responseData);
            if (res.statusCode >= 400) {
              reject(new Error(json.error?.message || `HTTP ${res.statusCode}`));
            } else {
              resolve(json);
            }
          } catch (e) {
            reject(new Error(`Invalid JSON response: ${responseData.slice(0, 200)}`));
          }
        });
      });

      req.on('error', reject);
      req.write(data);
      req.end();
    });
  }
}

module.exports = OpenAIEmbeddingProvider;
