/**
 * Base Embedding Provider Interface
 * 
 * Defines the interface for embedding providers.
 * Implementations must provide embed() and embedBatch() methods.
 */

class BaseEmbeddingProvider {
  constructor(options = {}) {
    this.options = options;
    this._dimension = 0;
  }

  /**
   * Get the embedding dimension
   */
  get dimension() {
    return this._dimension;
  }

  /**
   * Initialize the provider
   */
  async initialize() {
    // Override in subclass
  }

  /**
   * Generate embedding for a single text
   * 
   * @param {string} text - Text to embed
   * @returns {Float32Array} Embedding vector
   */
  async embed(text) {
    throw new Error('embed() must be implemented by subclass');
  }

  /**
   * Generate embeddings for multiple texts
   * 
   * @param {string[]} texts - Array of texts to embed
   * @returns {Float32Array[]} Array of embedding vectors
   */
  async embedBatch(texts) {
    // Default implementation: call embed() for each text
    const embeddings = [];
    for (const text of texts) {
      embeddings.push(await this.embed(text));
    }
    return embeddings;
  }

  /**
   * Normalize a vector to unit length
   */
  normalize(vector) {
    let norm = 0;
    for (let i = 0; i < vector.length; i++) {
      norm += vector[i] * vector[i];
    }
    norm = Math.sqrt(norm);
    
    if (norm === 0) return vector;
    
    const normalized = new Float32Array(vector.length);
    for (let i = 0; i < vector.length; i++) {
      normalized[i] = vector[i] / norm;
    }
    return normalized;
  }
}

module.exports = BaseEmbeddingProvider;
