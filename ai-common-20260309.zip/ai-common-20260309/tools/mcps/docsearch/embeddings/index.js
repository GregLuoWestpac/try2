const BaseEmbeddingProvider = require('./BaseEmbeddingProvider');
const OpenAIEmbeddingProvider = require('./OpenAIEmbeddingProvider');
const LocalEmbeddingProvider = require('./LocalEmbeddingProvider');

/**
 * Create an embedding provider based on configuration
 */
function createEmbeddingProvider(type, options = {}) {
  switch (type) {
    case 'openai':
      return new OpenAIEmbeddingProvider(options);
    case 'local':
      return new LocalEmbeddingProvider(options);
    default:
      throw new Error(`Unknown embedding provider type: ${type}`);
  }
}

module.exports = {
  BaseEmbeddingProvider,
  OpenAIEmbeddingProvider,
  LocalEmbeddingProvider,
  createEmbeddingProvider
};
