/**
 * Local Embedding Provider
 * 
 * Uses ONNX Runtime with a sentence-transformer model for 
 * high-quality local embeddings without requiring external API calls.
 * 
 * Model: all-MiniLM-L6-v2 (384 dimensions)
 * - Small and fast
 * - Good quality for semantic search
 * - Shipped at models/all-MiniLM-L6-v2/ (committed with the tool)
 * 
 * Falls back to hash-based embeddings if ONNX is unavailable.
 */

const BaseEmbeddingProvider = require('./BaseEmbeddingProvider');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// Model configuration - uses ONNX model with fallback mirrors
const MODEL_NAME = 'all-MiniLM-L6-v2';
const MODEL_DIMENSION = 384;



const MODEL_FILES = {
  model: {
    path: '/sentence-transformers/all-MiniLM-L6-v2/resolve/main/onnx/model.onnx',
    filename: 'model.onnx',
    size: 90405214 // ~90MB (full model)
  },
  tokenizer: {
    path: '/sentence-transformers/all-MiniLM-L6-v2/resolve/main/tokenizer.json',
    filename: 'tokenizer.json',
    size: 466062
  },
  config: {
    path: '/sentence-transformers/all-MiniLM-L6-v2/resolve/main/config.json', 
    filename: 'config.json',
    size: 612
  }
};


class LocalEmbeddingProvider extends BaseEmbeddingProvider {
  constructor(options = {}) {
    super(options);
    this._dimension = MODEL_DIMENSION;
    this.verbose = options.verbose || false;
    this.modelDir = options.modelDir || this._getDefaultModelDir();
    this.useOnnx = false;
    this.onnxSession = null;
    this.tokenizer = null;
    this.ngramSize = options.ngramSize || 3;
    
    // Logging helper
    this.log = this.verbose 
      ? (...args) => console.error('[LocalEmbedding]', ...args)
      : () => {};
  }

  _getDefaultModelDir() {
    // Models are shipped with the tool — no download, no home directory fallback
    return path.join(__dirname, '..', 'models', MODEL_NAME);
  }

  async initialize() {
    this.log('Initializing local embedding provider...');
    
    // Check if onnxruntime-node is available
    let hasOnnx = false;
    try {
      require.resolve('onnxruntime-node');
      hasOnnx = true;
    } catch (e) {
      hasOnnx = false;
    }

    if (hasOnnx) {
      // Try to load ONNX model for higher quality embeddings
      try {
        await this._ensureModelDownloaded();
        await this._loadOnnxModel();
        this.useOnnx = true;
        console.error('[LocalEmbedding] Using ONNX neural model for high-quality embeddings');
      } catch (error) {
        console.error('[LocalEmbedding] ONNX model load failed:', error.message);
        console.error('[LocalEmbedding] Falling back to hash-based embeddings');
        this.useOnnx = false;
      }
    } else {
      console.error('[LocalEmbedding] Using hash-based embeddings (install onnxruntime-node for neural embeddings)');
      this.useOnnx = false;
    }
  }

  /**
   * Verify model files are present in the tool's models/ directory
   */
  async _ensureModelDownloaded() {
    const missing = Object.values(MODEL_FILES).filter(file => {
      const filePath = path.join(this.modelDir, file.filename);
      return !fs.existsSync(filePath);
    });

    if (missing.length === 0) {
      this.log('Model files present');
      return;
    }

    throw new Error(
      `ONNX model files missing from ${this.modelDir}: ${missing.map(f => f.filename).join(', ')}. ` +
      `Models must be committed at tools/mcps/docsearch/models/${MODEL_NAME}/.`
    );
  }

  /**
   * Load ONNX model and tokenizer
   */
  async _loadOnnxModel() {
    // Try to load onnxruntime-node
    let ort;
    try {
      ort = require('onnxruntime-node');
    } catch (e) {
      throw new Error('onnxruntime-node not installed. Install with: npm install onnxruntime-node');
    }

    // Load model
    const modelPath = path.join(this.modelDir, 'model.onnx');
    this.log('Loading ONNX model from', modelPath);
    this.onnxSession = await ort.InferenceSession.create(modelPath);

    // Load tokenizer
    const tokenizerPath = path.join(this.modelDir, 'tokenizer.json');
    this.log('Loading tokenizer from', tokenizerPath);
    const tokenizerData = JSON.parse(fs.readFileSync(tokenizerPath, 'utf8'));
    this.tokenizer = this._createSimpleTokenizer(tokenizerData);
  }

  /**
   * Create a simple tokenizer from tokenizer.json
   */
  _createSimpleTokenizer(tokenizerData) {
    const vocab = tokenizerData.model?.vocab || {};
    const wordToId = new Map(Object.entries(vocab));
    
    // Get special tokens
    const clsToken = tokenizerData.added_tokens?.find(t => t.content === '[CLS]')?.id || 101;
    const sepToken = tokenizerData.added_tokens?.find(t => t.content === '[SEP]')?.id || 102;
    const padToken = tokenizerData.added_tokens?.find(t => t.content === '[PAD]')?.id || 0;
    const unkToken = wordToId.get('[UNK]') || 100;

    return {
      encode: (text, maxLength = 128) => {
        // Simple WordPiece-like tokenization
        const words = text.toLowerCase().replace(/[^\w\s]/g, ' ').split(/\s+/).filter(w => w);
        const tokens = [clsToken];

        for (const word of words) {
          if (tokens.length >= maxLength - 1) break;
          
          // Try to find the word or its pieces
          if (wordToId.has(word)) {
            tokens.push(wordToId.get(word));
          } else {
            // Try subword tokenization
            let remaining = word;
            let isFirst = true;
            
            while (remaining.length > 0 && tokens.length < maxLength - 1) {
              let found = false;
              
              for (let len = Math.min(remaining.length, 10); len > 0; len--) {
                const piece = isFirst ? remaining.slice(0, len) : '##' + remaining.slice(0, len);
                
                if (wordToId.has(piece)) {
                  tokens.push(wordToId.get(piece));
                  remaining = remaining.slice(len);
                  isFirst = false;
                  found = true;
                  break;
                }
              }
              
              if (!found) {
                tokens.push(unkToken);
                remaining = remaining.slice(1);
                isFirst = false;
              }
            }
          }
        }

        tokens.push(sepToken);

        // Pad to maxLength
        const inputIds = new BigInt64Array(maxLength);
        const attentionMask = new BigInt64Array(maxLength);
        const tokenTypeIds = new BigInt64Array(maxLength);

        for (let i = 0; i < maxLength; i++) {
          if (i < tokens.length) {
            inputIds[i] = BigInt(tokens[i]);
            attentionMask[i] = 1n;
          } else {
            inputIds[i] = BigInt(padToken);
            attentionMask[i] = 0n;
          }
          tokenTypeIds[i] = 0n;
        }

        return { inputIds, attentionMask, tokenTypeIds };
      }
    };
  }

  /**
   * Generate embedding for a single text
   */
  async embed(text) {
    if (this.useOnnx && this.onnxSession) {
      return await this._embedOnnx(text);
    }
    return this._embedHash(text);
  }

  /**
   * Generate embedding using ONNX model
   */
  async _embedOnnx(text) {
    const ort = require('onnxruntime-node');
    
    // Tokenize
    const { inputIds, attentionMask, tokenTypeIds } = this.tokenizer.encode(text);

    // Create tensors
    const feeds = {
      input_ids: new ort.Tensor('int64', inputIds, [1, inputIds.length]),
      attention_mask: new ort.Tensor('int64', attentionMask, [1, attentionMask.length]),
      token_type_ids: new ort.Tensor('int64', tokenTypeIds, [1, tokenTypeIds.length])
    };

    // Run inference
    const results = await this.onnxSession.run(feeds);
    
    // Get sentence embedding (mean pooling of last hidden state)
    const lastHiddenState = results.last_hidden_state || results.output_0;
    const embedding = this._meanPooling(lastHiddenState.data, attentionMask, inputIds.length);

    return this.normalize(embedding);
  }

  /**
   * Mean pooling over token embeddings
   */
  _meanPooling(data, attentionMask, seqLength) {
    const embedding = new Float32Array(this._dimension);
    let validTokens = 0;

    for (let i = 0; i < seqLength; i++) {
      if (attentionMask[i] === 1n) {
        for (let j = 0; j < this._dimension; j++) {
          embedding[j] += data[i * this._dimension + j];
        }
        validTokens++;
      }
    }

    if (validTokens > 0) {
      for (let j = 0; j < this._dimension; j++) {
        embedding[j] /= validTokens;
      }
    }

    return embedding;
  }

  /**
   * Hash-based embedding fallback
   */
  _embedHash(text) {
    const embedding = new Float32Array(this._dimension);
    
    if (!text || text.trim().length === 0) {
      return this.normalize(embedding);
    }

    // Normalize text
    const normalized = text.toLowerCase().replace(/[^\w\s]/g, ' ').trim();
    const words = normalized.split(/\s+/).filter(w => w.length > 0);
    
    // Feature extraction (ensure integer indices)
    const third = Math.floor(this._dimension / 3);
    this._addNgramFeatures(embedding, normalized, 0, third);
    this._addWordFeatures(embedding, words, third, third);
    this._addSemanticFeatures(embedding, words, third * 2, this._dimension - (third * 2));

    return this.normalize(embedding);
  }

  /**
   * Add character n-gram features
   */
  _addNgramFeatures(embedding, text, offset, size) {
    for (let i = 0; i <= text.length - this.ngramSize; i++) {
      const ngram = text.slice(i, i + this.ngramSize);
      const hash = this._hash(ngram);
      const idx = offset + (hash % size);
      embedding[idx] += 1.0;
    }
  }

  /**
   * Add word-level features (TF-like)
   */
  _addWordFeatures(embedding, words, offset, size) {
    const wordCounts = new Map();
    for (const word of words) {
      wordCounts.set(word, (wordCounts.get(word) || 0) + 1);
    }

    for (const [word, count] of wordCounts) {
      const hash = this._hash(word);
      const idx = offset + (hash % size);
      // Log-scaled term frequency
      embedding[idx] += Math.log(1 + count);
    }
  }

  /**
   * Add semantic-style features using word pairs and position
   */
  _addSemanticFeatures(embedding, words, offset, size) {
    // Bigram features
    for (let i = 0; i < words.length - 1; i++) {
      const bigram = words[i] + ' ' + words[i + 1];
      const hash = this._hash(bigram);
      const idx = offset + (hash % size);
      embedding[idx] += 0.5;
    }

    // Position-weighted word features
    for (let i = 0; i < words.length; i++) {
      const posWeight = 1.0 - (i / words.length) * 0.5; // Earlier words weighted higher
      const hash = this._hash('pos:' + words[i]);
      const idx = offset + (hash % size);
      embedding[idx] += posWeight;
    }
  }

  /**
   * Simple hash function returning positive integer
   */
  _hash(str) {
    const hash = crypto.createHash('md5').update(str).digest();
    return hash.readUInt32LE(0);
  }

  /**
   * Generate embeddings for multiple texts (batch)
   */
  async embedBatch(texts) {
    // ONNX doesn't easily support batching in our simple setup
    // So we process one by one
    const embeddings = [];
    for (const text of texts) {
      embeddings.push(await this.embed(text));
    }
    return embeddings;
  }
}

module.exports = LocalEmbeddingProvider;
