/**
 * DocSearch MCP Provider
 * 
 * A Reverse HyDE document search provider for NodeMCP.
 * 
 * Reverse HyDE: Instead of embedding documents directly, we generate
 * hypothetical queries for each document and embed those. At search time,
 * we match the real query against these hypothetical queries for better
 * semantic matching.
 * 
 * Features:
 * - Document ingestion with automatic query generation
 * - Semantic search using vector similarity
 * - Local file-based vector store (2-phase: memory index + disk documents)
 * - Local embedding model (downloads automatically on first use)
 * - Optional OpenAI embeddings for higher quality
 */

const BaseProvider = require('../../nodemcp/core/BaseProvider');
const ReverseHyDEEngine = require('./ReverseHyDEEngine');
const path = require('path');
const fs = require('fs');

class DocSearchProvider extends BaseProvider {
  constructor(options = {}) {
    super(options);
    this.setStateful(true);
    
    // Configuration from options, environment, or config.json
    this.storePath = options.storePath || process.env.DOCSEARCH_STORE_PATH;

    // Fall back to storePath from config.json
    if (!this.storePath && this.basePath) {
      const configPath = path.join(this.basePath, 'config.json');
      if (fs.existsSync(configPath)) {
        try {
          const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
          if (config.storage && config.storage.storePath) {
            this.storePath = path.resolve(this.basePath, config.storage.storePath);
          }
        } catch (e) {
          console.warn(`Warning: could not parse ${configPath}: ${e.message}`);
        }
      }
    }
    this.embeddingProvider = options.embeddingProvider || process.env.DOCSEARCH_EMBEDDING_PROVIDER || 'local';
    this.numQueries = options.numQueries || parseInt(process.env.DOCSEARCH_HYDE_QUERIES || '5', 10);
    
    if (!this.storePath) {
      throw new Error(
        'DocSearch store path is required. Set DOCSEARCH_STORE_PATH environment variable, ' +
        'pass --store <path> to the CLI, or provide storePath in options.'
      );
    }

    this.engine = null;
  }

  /**
   * Get or create engine for session
   */
  async getEngine(context) {
    // Use session-specific engine if available
    if (context?.session) {
      let engine = context.sessionManager?.getProviderData(context.session.id, 'docsearch', 'engine');
      if (!engine) {
        engine = new ReverseHyDEEngine({
          storePath: this.storePath,
          embeddingProvider: this.embeddingProvider,
          numQueries: this.numQueries,
          verbose: this.verbose
        });
        await engine.initialize();
        context.sessionManager?.setProviderData(context.session.id, 'docsearch', 'engine', engine);
      }
      return engine;
    }

    // Use global engine
    if (!this.engine) {
      this.engine = new ReverseHyDEEngine({
        storePath: this.storePath,
        embeddingProvider: this.embeddingProvider,
        numQueries: this.numQueries,
        verbose: this.verbose
      });
      await this.engine.initialize();
    }
    return this.engine;
  }

  async initialize() {
    this.log('Initializing DocSearch provider');
    this.log(`Store path: ${this.storePath}`);
    this.log(`Embedding provider: ${this.embeddingProvider}`);
    this.log(`Hypothetical queries per document: ${this.numQueries}`);
    
    this.registerAllTools();
  }

  async shutdown() {
    if (this.engine) {
      await this.engine.close();
    }
  }

  registerAllTools() {
    // =====================
    // DOCUMENT INGESTION
    // =====================

    this.registerTool({
      name: 'ingest',
      description: `Ingest a document into the Reverse HyDE search index. The document will be processed to generate hypothetical search queries, which are then embedded for semantic search. This enables better query-document matching by comparing queries to queries rather than queries to documents.`,
      inputSchema: {
        type: 'object',
        properties: {
          content: this.stringProp('The document content to ingest', { required: true }),
          id: this.stringProp('Optional document ID. If not provided, a UUID will be generated.'),
          metadata: {
            type: 'object',
            description: 'Optional metadata to associate with the document (e.g., title, source, author)',
            additionalProperties: true
          },
          num_queries: this.numberProp('Number of hypothetical queries to generate (default: 5)')
        },
        required: ['content']
      },
      handler: async (args, context) => {
        const engine = await this.getEngine(context);
        
        try {
          const result = await engine.ingest({
            id: args.id,
            content: args.content,
            metadata: args.metadata
          }, {
            numQueries: args.num_queries
          });

          return {
            status: 'ingested',
            docId: result.docId,
            hypotheticalQueries: result.hypotheticalQueries,
            vectorCount: result.vectorCount,
            message: `Document ingested with ${result.vectorCount} hypothetical query embeddings`
          };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'ingest_batch',
      description: 'Ingest multiple documents at once into the Reverse HyDE search index.',
      inputSchema: {
        type: 'object',
        properties: {
          documents: {
            type: 'array',
            description: 'Array of documents to ingest',
            items: {
              type: 'object',
              properties: {
                id: { type: 'string', description: 'Optional document ID' },
                content: { type: 'string', description: 'Document content' },
                metadata: { type: 'object', description: 'Optional metadata' }
              },
              required: ['content']
            },
            required: true
          },
          num_queries: this.numberProp('Number of hypothetical queries per document (default: 5)')
        },
        required: ['documents']
      },
      handler: async (args, context) => {
        const engine = await this.getEngine(context);
        
        try {
          const results = await engine.ingestBatch(args.documents, {
            numQueries: args.num_queries
          });

          const succeeded = results.filter(r => r.success).length;
          const failed = results.filter(r => !r.success).length;

          return {
            status: 'batch_complete',
            total: results.length,
            succeeded,
            failed,
            results
          };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'ingest_directory',
      description: 'Ingest all documents from a directory into the search index. Reads files matching a glob pattern, extracts metadata from file paths (directory becomes category), and ingests each file.',
      inputSchema: {
        type: 'object',
        properties: {
          directory: this.stringProp('Absolute or relative path to directory containing documents', { required: true }),
          pattern: this.stringProp('Glob pattern for files to match (default: **/*.md)'),
          source_name: this.stringProp('Source collection name, used as metadata tag (e.g. "solution-designs")'),
          num_queries: this.numberProp('Number of hypothetical queries per document (default: 5)'),
          clear_existing: this.booleanProp('Clear the entire index before ingesting (default: false)')
        },
        required: ['directory']
      },
      handler: async (args, context) => {
        const engine = await this.getEngine(context);
        const fs = require('fs');

        try {
          const dir = path.resolve(args.directory);
          if (!fs.existsSync(dir)) {
            return { error: `Directory not found: ${dir}` };
          }

          const pattern = args.pattern || '**/*.md';
          const sourceName = args.source_name || path.basename(dir);

          // Clear if requested
          if (args.clear_existing) {
            await engine.clear();
          }

          // Recursively find matching files
          const files = this._findFiles(dir, pattern);

          if (files.length === 0) {
            return { status: 'no_files', directory: dir, pattern, message: 'No matching files found' };
          }

          const results = [];
          for (const filePath of files) {
            try {
              const content = fs.readFileSync(filePath, 'utf-8');
              if (!content.trim()) {
                results.push({ file: filePath, status: 'skipped', reason: 'empty' });
                continue;
              }

              const relativePath = path.relative(dir, filePath);
              const category = path.dirname(relativePath) === '.' ? sourceName : path.dirname(relativePath).split(path.sep)[0];
              const filename = path.basename(filePath, path.extname(filePath));

              const result = await engine.ingest({
                id: `${sourceName}/${relativePath}`,
                content,
                metadata: {
                  source: sourceName,
                  category,
                  filename,
                  relativePath,
                  title: this._extractTitle(content) || filename
                }
              }, {
                numQueries: args.num_queries
              });

              results.push({ file: relativePath, status: 'ingested', docId: result.docId, vectors: result.vectorCount });
            } catch (err) {
              results.push({ file: filePath, status: 'failed', error: err.message });
            }
          }

          const ingested = results.filter(r => r.status === 'ingested').length;
          const failed = results.filter(r => r.status === 'failed').length;
          const skipped = results.filter(r => r.status === 'skipped').length;

          return {
            status: 'complete',
            directory: dir,
            pattern,
            source: sourceName,
            summary: { total: files.length, ingested, failed, skipped },
            results
          };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    // =====================
    // SEARCH / QUERY
    // =====================

    this.registerTool({
      name: 'query',
      description: `Search for documents using semantic similarity. The query is embedded and compared against the hypothetical queries generated for each document. Returns ranked results with relevance scores.`,
      inputSchema: {
        type: 'object',
        properties: {
          query: this.stringProp('The search query', { required: true }),
          k: this.numberProp('Maximum number of results to return (default: 10)'),
          threshold: this.numberProp('Minimum similarity score threshold (0.0-1.0, default: 0.0)')
        },
        required: ['query']
      },
      handler: async (args, context) => {
        const engine = await this.getEngine(context);
        
        try {
          const results = await engine.query(args.query, {
            k: args.k || 10,
            threshold: args.threshold || 0.0
          });

          return {
            query: args.query,
            resultCount: results.length,
            results: results.map((r, i) => ({
              rank: i + 1,
              docId: r.docId,
              score: Math.round(r.score * 1000) / 1000,
              matchedQuery: r.matchedQuery,
              content: r.content.slice(0, 500) + (r.content.length > 500 ? '...' : ''),
              metadata: r.metadata
            }))
          };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    // =====================
    // DOCUMENT MANAGEMENT
    // =====================

    this.registerTool({
      name: 'get',
      description: 'Retrieve a specific document by its ID.',
      inputSchema: {
        type: 'object',
        properties: {
          doc_id: this.stringProp('The document ID to retrieve', { required: true })
        },
        required: ['doc_id']
      },
      handler: async (args, context) => {
        const engine = await this.getEngine(context);
        
        try {
          const doc = await engine.get(args.doc_id);
          
          if (!doc) {
            return { error: 'Document not found', docId: args.doc_id };
          }

          return {
            docId: doc.id,
            content: doc.content,
            metadata: doc.metadata,
            hypotheticalQueries: doc.hypotheticalQueries,
            timestamp: doc.timestamp
          };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'delete',
      description: 'Delete a document from the search index.',
      inputSchema: {
        type: 'object',
        properties: {
          doc_id: this.stringProp('The document ID to delete', { required: true })
        },
        required: ['doc_id']
      },
      handler: async (args, context) => {
        const engine = await this.getEngine(context);
        
        try {
          const deleted = await engine.delete(args.doc_id);
          
          return {
            status: deleted ? 'deleted' : 'not_found',
            docId: args.doc_id
          };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'list',
      description: 'List all document IDs in the search index.',
      inputSchema: {
        type: 'object',
        properties: {
          limit: this.numberProp('Maximum number of IDs to return'),
          offset: this.numberProp('Offset for pagination')
        }
      },
      handler: async (args, context) => {
        const engine = await this.getEngine(context);
        
        try {
          let docIds = await engine.list();
          const total = docIds.length;

          // Apply pagination
          if (args.offset) {
            docIds = docIds.slice(args.offset);
          }
          if (args.limit) {
            docIds = docIds.slice(0, args.limit);
          }

          return {
            total,
            count: docIds.length,
            offset: args.offset || 0,
            docIds
          };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'clear',
      description: 'Clear all documents from the search index. This action is irreversible.',
      inputSchema: {
        type: 'object',
        properties: {
          confirm: this.booleanProp('Must be true to confirm deletion', { required: true })
        },
        required: ['confirm']
      },
      handler: async (args, context) => {
        if (!args.confirm) {
          return { error: 'Confirmation required. Set confirm=true to clear all documents.' };
        }

        const engine = await this.getEngine(context);
        
        try {
          const statsBefore = await engine.stats();
          await engine.clear();

          return {
            status: 'cleared',
            documentsDeleted: statsBefore.documentCount,
            vectorsDeleted: statsBefore.vectorCount
          };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    // =====================
    // INDEX INFORMATION
    // =====================

    this.registerTool({
      name: 'stats',
      description: 'Get statistics about the document search index.',
      inputSchema: {
        type: 'object',
        properties: {}
      },
      handler: async (args, context) => {
        const engine = await this.getEngine(context);
        
        try {
          const stats = await engine.stats();

          return {
            documentCount: stats.documentCount,
            vectorCount: stats.vectorCount,
            avgVectorsPerDoc: stats.documentCount > 0 
              ? Math.round(stats.vectorCount / stats.documentCount * 10) / 10 
              : 0,
            embeddingDimension: stats.embeddingDimension,
            embeddingProvider: stats.embeddingProvider,
            numQueriesPerDoc: stats.numQueriesPerDoc,
            storage: {
              indexPath: stats.indexPath,
              docsPath: stats.docsPath,
              indexSizeBytes: stats.indexSize,
              docsSizeBytes: stats.docsSize,
              totalSizeBytes: stats.indexSize + stats.docsSize,
              indexSizeMB: Math.round(stats.indexSize / 1024 / 1024 * 100) / 100,
              docsSizeMB: Math.round(stats.docsSize / 1024 / 1024 * 100) / 100
            }
          };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    // =====================
    // UTILITY
    // =====================

    this.registerTool({
      name: 'update',
      description: 'Update an existing document. This is equivalent to delete + ingest.',
      inputSchema: {
        type: 'object',
        properties: {
          doc_id: this.stringProp('The document ID to update', { required: true }),
          content: this.stringProp('The new document content', { required: true }),
          metadata: {
            type: 'object',
            description: 'New metadata (replaces existing)',
            additionalProperties: true
          },
          num_queries: this.numberProp('Number of hypothetical queries to generate (default: 5)')
        },
        required: ['doc_id', 'content']
      },
      handler: async (args, context) => {
        const engine = await this.getEngine(context);
        
        try {
          // Delete existing
          await engine.delete(args.doc_id);

          // Ingest new version
          const result = await engine.ingest({
            id: args.doc_id,
            content: args.content,
            metadata: args.metadata
          }, {
            numQueries: args.num_queries
          });

          return {
            status: 'updated',
            docId: result.docId,
            hypotheticalQueries: result.hypotheticalQueries,
            vectorCount: result.vectorCount
          };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'generate_queries',
      description: 'Generate hypothetical search queries for a document without ingesting it. Useful for previewing what queries will be generated.',
      inputSchema: {
        type: 'object',
        properties: {
          content: this.stringProp('The document content', { required: true }),
          num_queries: this.numberProp('Number of hypothetical queries to generate (default: 5)')
        },
        required: ['content']
      },
      handler: async (args, context) => {
        const engine = await this.getEngine(context);
        
        try {
          const queries = await engine.generateHypotheticalQueries(
            args.content, 
            args.num_queries || 5
          );

          return {
            queryCount: queries.length,
            hypotheticalQueries: queries
          };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.log(`Registered ${this.tools.length} DocSearch tools`);
  }

  /**
   * Recursively find files matching a simple glob pattern
   * Supports: *.ext, **\/*.ext
   */
  _findFiles(dir, pattern) {
    const fs = require('fs');
    const results = [];
    const ext = pattern.includes('.') ? pattern.split('.').pop() : null;
    const recursive = pattern.includes('**');

    const walk = (currentDir) => {
      const entries = fs.readdirSync(currentDir, { withFileTypes: true });
      for (const entry of entries) {
        const fullPath = path.join(currentDir, entry.name);
        if (entry.isDirectory() && recursive) {
          walk(fullPath);
        } else if (entry.isFile()) {
          if (!ext || entry.name.endsWith(`.${ext}`)) {
            results.push(fullPath);
          }
        }
      }
    };

    walk(dir);
    return results.sort();
  }

  /**
   * Extract title from markdown content (first # heading)
   */
  _extractTitle(content) {
    const match = content.match(/^#\s+(.+)$/m);
    return match ? match[1].trim() : null;
  }
}

module.exports = DocSearchProvider;
