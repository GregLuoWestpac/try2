/**
 * Bitbucket Client
 *
 * HTTP client for interacting with the Bitbucket Server / Data Center REST API (1.0).
 * Handles authentication, session management, and API calls.
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

let yaml;
try {
  yaml = require('js-yaml');
} catch (e) {
  yaml = null;
}

class BitbucketClient {
  constructor(options = {}) {
    this.verbose = options.verbose || false;
    this.host = null;
    this.port = 443;
    this.protocol = 'https';
    this.verifySsl = true;
    this.bearerToken = null;
    this.httpAccessToken = null;
    this.basicAuth = null;
    this.cookies = {};
    this.keepAliveInterval = null;
    this.keepAliveEnabled = false;
    this.tokenObtainedAt = null;
    this.apiBase = '/rest/api/1.0';

    this.log = this.verbose
      ? (...args) => console.error('[BitbucketClient]', ...args)
      : () => {};
  }

  // =====================
  // CONFIG & AUTH
  // =====================

  loadConfig(configPath = null) {
    if (!yaml) {
      this.log('js-yaml not installed, cannot load YAML config');
      return null;
    }

    const searchPaths = configPath ? [configPath] : [
      path.join(process.cwd(), '.bitbucket_mcp.local.yaml'),
      path.join(__dirname, '..', '..', '.bitbucket_mcp.local.yaml'),
      path.join(process.env.HOME || process.env.USERPROFILE || '', '.bitbucket_mcp.local.yaml'),
    ];

    for (const cfgPath of searchPaths) {
      try {
        if (fs.existsSync(cfgPath)) {
          const content = fs.readFileSync(cfgPath, 'utf-8');
          const config = yaml.load(content);
          this.log(`Loaded config from ${cfgPath}`);
          return config;
        }
      } catch (e) {
        this.log(`Failed to load config from ${cfgPath}: ${e.message}`);
      }
    }

    this.log('No config file found');
    return null;
  }

  initFromConfig(configPath = null) {
    const config = this.loadConfig(configPath);
    if (!config || !config.bitbucket) {
      return false;
    }

    const bb = config.bitbucket;

    if (bb.host) {
      this.setHost(bb.host, bb.verify_ssl !== false);
    }

    if (bb.auth) {
      if (bb.auth.http_access_token) {
        this.httpAccessToken = bb.auth.http_access_token;
        this.log('Loaded HTTP access token from config');
      }
      if (bb.auth.bearer_token) {
        this.bearerToken = bb.auth.bearer_token;
        this.log('Loaded bearer token from config');
      }
      if (bb.auth.username && bb.auth.password) {
        // Password must come from env var (BITBUCKET_PASSWORD) — not config file
        this.log('WARNING: Plaintext password in config file is ignored for security. Use BITBUCKET_PASSWORD env var instead.');
        if (process.env.BITBUCKET_PASSWORD) {
          this.setBasicAuth(bb.auth.username, process.env.BITBUCKET_PASSWORD);
          this.log('Loaded basic auth with password from env var');
        } else {
          this.log('Skipping basic auth: set BITBUCKET_PASSWORD env var to use username/password auth');
        }
      } else if (bb.auth.username && process.env.BITBUCKET_PASSWORD) {
        this.setBasicAuth(bb.auth.username, process.env.BITBUCKET_PASSWORD);
        this.log('Loaded basic auth from config username + env var password');
      }
    }

    if (bb.session) {
      if (bb.session.cookies && typeof bb.session.cookies === 'object') {
        this.cookies = { ...this.cookies, ...bb.session.cookies };
      }
      if (bb.session.obtained_at) {
        this.tokenObtainedAt = new Date(bb.session.obtained_at);
      }
    }

    if (config.keepalive && config.keepalive.enabled) {
      this.startKeepAlive(config.keepalive.interval_seconds || 300);
    }

    return true;
  }

  setHost(hostUrl, verifySsl = true) {
    const url = new URL(hostUrl);
    this.host = url.hostname;
    this.port = url.port || (url.protocol === 'https:' ? 443 : 80);
    this.protocol = url.protocol.replace(':', '');
    this.verifySsl = verifySsl;
    if (!verifySsl) {
      console.error('[BitbucketClient] ⚠️  WARNING: SSL certificate verification is DISABLED. This exposes connections to man-in-the-middle attacks. Set verify_ssl: true in production.');
    }
    if (this.protocol === 'http') {
      console.error('[BitbucketClient] ⚠️  WARNING: Using plain HTTP (no TLS). Authentication credentials will be transmitted in cleartext. Use HTTPS in production.');
    }
    // Bitbucket Server may be mounted at a context path (e.g. /bitbucket)
    const contextPath = url.pathname.replace(/\/+$/, '');
    this.apiBase = `${contextPath}/rest/api/1.0`;
    this.buildStatusBase = `${contextPath}/rest/build-status/1.0`;
    this.log(`Host set to ${this.protocol}://${this.host}:${this.port} (apiBase: ${this.apiBase})`);
  }

  setBasicAuth(username, password) {
    this.basicAuth = Buffer.from(`${username}:${password}`).toString('base64');
    this.log('Basic auth configured');
  }

  setBearerToken(token) {
    this.bearerToken = token;
    this.log('Bearer token configured');
  }

  setHttpAccessToken(token) {
    this.httpAccessToken = token;
    this.log('HTTP access token configured');
  }

  startKeepAlive(intervalSeconds = 300) {
    if (this.keepAliveInterval) {
      this.stopKeepAlive();
    }
    this.keepAliveEnabled = true;
    const intervalMs = intervalSeconds * 1000;
    this.log(`Starting keep-alive with ${intervalSeconds}s interval`);

    this.keepAliveInterval = setInterval(async () => {
      try {
        await this.ping();
        this.log('Keep-alive ping successful');
      } catch (e) {
        this.log(`Keep-alive ping failed: ${e.message}`);
      }
    }, intervalMs);

    if (this.keepAliveInterval.unref) {
      this.keepAliveInterval.unref();
    }
  }

  stopKeepAlive() {
    if (this.keepAliveInterval) {
      clearInterval(this.keepAliveInterval);
      this.keepAliveInterval = null;
      this.keepAliveEnabled = false;
      this.log('Keep-alive stopped');
    }
  }

  async ping() {
    const response = await this.request('GET', `${this.apiBase}/application-properties`);
    return { status: 'alive', version: response.version, displayName: response.displayName };
  }

  async logout() {
    this.stopKeepAlive();
    this.basicAuth = null;
    this.bearerToken = null;
    this.httpAccessToken = null;
    this.cookies = {};
    this.log('Logged out');
  }

  isAuthenticated() {
    return !!(
      this.basicAuth ||
      this.bearerToken ||
      this.httpAccessToken ||
      this.cookies['JSESSIONID']
    );
  }

  async isTokenExpired() {
    if (!this.isAuthenticated()) return true;
    try {
      await this.ping();
      return false;
    } catch (e) {
      this.log(`Token check failed: ${e.message}`);
      return true;
    }
  }

  // =====================
  // BITBUCKET API METHODS
  // =====================

  /** Encode path segments to prevent path traversal */
  _encodeSegment(value) {
    return encodeURIComponent(String(value));
  }

  // --- Repositories ---

  async getProjects(options = {}) {
    const params = {};
    if (options.start !== undefined) params.start = options.start;
    if (options.limit) params.limit = options.limit;
    const qs = new URLSearchParams(params).toString();
    return await this.request('GET', `${this.apiBase}/projects${qs ? '?' + qs : ''}`);
  }

  async getRepos(projectKey, options = {}) {
    const params = {};
    if (options.start !== undefined) params.start = options.start;
    if (options.limit) params.limit = options.limit;
    const qs = new URLSearchParams(params).toString();
    const base = projectKey
      ? `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos`
      : `${this.apiBase}/repos`;
    return await this.request('GET', `${base}${qs ? '?' + qs : ''}`);
  }

  async getRepo(projectKey, repoSlug) {
    return await this.request('GET', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}`);
  }

  async getBranches(projectKey, repoSlug, options = {}) {
    const params = {};
    if (options.filterText) params.filterText = options.filterText;
    if (options.orderBy) params.orderBy = options.orderBy;
    if (options.start !== undefined) params.start = options.start;
    if (options.limit) params.limit = options.limit;
    const qs = new URLSearchParams(params).toString();
    return await this.request('GET', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/branches${qs ? '?' + qs : ''}`);
  }

  async getTags(projectKey, repoSlug, options = {}) {
    const params = {};
    if (options.filterText) params.filterText = options.filterText;
    if (options.orderBy) params.orderBy = options.orderBy;
    if (options.start !== undefined) params.start = options.start;
    if (options.limit) params.limit = options.limit;
    const qs = new URLSearchParams(params).toString();
    return await this.request('GET', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/tags${qs ? '?' + qs : ''}`);
  }

  async getDefaultBranch(projectKey, repoSlug) {
    return await this.request('GET', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/default-branch`);
  }

  // --- Pull Requests ---

  async getPullRequests(projectKey, repoSlug, options = {}) {
    const params = {};
    if (options.state) params.state = options.state;
    if (options.direction) params.direction = options.direction;
    if (options.at) params.at = options.at;
    if (options.order) params.order = options.order;
    if (options.start !== undefined) params.start = options.start;
    if (options.limit) params.limit = options.limit;
    if (options.withAttributes !== undefined) params.withAttributes = options.withAttributes;
    if (options.withProperties !== undefined) params.withProperties = options.withProperties;
    const qs = new URLSearchParams(params).toString();
    return await this.request('GET', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/pull-requests${qs ? '?' + qs : ''}`);
  }

  async getPullRequest(projectKey, repoSlug, prId) {
    return await this.request('GET', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/pull-requests/${this._encodeSegment(prId)}`);
  }

  async getPullRequestDiff(projectKey, repoSlug, prId, options = {}) {
    const params = {};
    if (options.contextLines !== undefined) params.contextLines = options.contextLines;
    if (options.withComments !== undefined) params.withComments = options.withComments;
    const qs = new URLSearchParams(params).toString();
    return await this.request('GET', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/pull-requests/${this._encodeSegment(prId)}/diff${qs ? '?' + qs : ''}`);
  }

  async getPullRequestActivities(projectKey, repoSlug, prId, options = {}) {
    const params = {};
    if (options.start !== undefined) params.start = options.start;
    if (options.limit) params.limit = options.limit;
    const qs = new URLSearchParams(params).toString();
    return await this.request('GET', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/pull-requests/${this._encodeSegment(prId)}/activities${qs ? '?' + qs : ''}`);
  }

  async createPullRequest(projectKey, repoSlug, data) {
    return await this.request('POST', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/pull-requests`, data);
  }

  async updatePullRequest(projectKey, repoSlug, prId, data) {
    return await this.request('PUT', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/pull-requests/${this._encodeSegment(prId)}`, data);
  }

  async mergePullRequest(projectKey, repoSlug, prId, options = {}) {
    const params = {};
    if (options.version !== undefined) params.version = options.version;
    const qs = new URLSearchParams(params).toString();
    const body = {};
    if (options.message) body.message = options.message;
    if (options.strategyId) body.strategyId = options.strategyId;
    return await this.request('POST', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/pull-requests/${this._encodeSegment(prId)}/merge${qs ? '?' + qs : ''}`, body);
  }

  // --- PR Review & Comments ---

  async getPullRequestComments(projectKey, repoSlug, prId, options = {}) {
    const params = {};
    if (options.start !== undefined) params.start = options.start;
    if (options.limit) params.limit = options.limit;
    const qs = new URLSearchParams(params).toString();
    return await this.request('GET', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/pull-requests/${this._encodeSegment(prId)}/comments${qs ? '?' + qs : ''}`);
  }

  async addPullRequestComment(projectKey, repoSlug, prId, data) {
    return await this.request('POST', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/pull-requests/${this._encodeSegment(prId)}/comments`, data);
  }

  async approvePullRequest(projectKey, repoSlug, prId) {
    return await this.request('POST', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/pull-requests/${this._encodeSegment(prId)}/approve`);
  }

  async declinePullRequest(projectKey, repoSlug, prId, options = {}) {
    const body = {};
    if (options.version !== undefined) body.version = options.version;
    return await this.request('POST', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/pull-requests/${this._encodeSegment(prId)}/decline`, body);
  }

  // --- Commits & Files ---

  async getCommits(projectKey, repoSlug, options = {}) {
    const params = {};
    if (options.since) params.since = options.since;
    if (options.until) params.until = options.until;
    if (options.path) params.path = options.path;
    if (options.start !== undefined) params.start = options.start;
    if (options.limit) params.limit = options.limit;
    const qs = new URLSearchParams(params).toString();
    return await this.request('GET', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/commits${qs ? '?' + qs : ''}`);
  }

  async getCommit(projectKey, repoSlug, commitId) {
    return await this.request('GET', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/commits/${this._encodeSegment(commitId)}`);
  }

  async getFileContent(projectKey, repoSlug, filePath, options = {}) {
    const params = {};
    if (options.at) params.at = options.at;
    if (options.start !== undefined) params.start = options.start;
    if (options.limit) params.limit = options.limit;
    const qs = new URLSearchParams(params).toString();
    const encodedPath = filePath.split('/').map(encodeURIComponent).join('/');
    return await this.request('GET', `${this.apiBase}/projects/${this._encodeSegment(projectKey)}/repos/${this._encodeSegment(repoSlug)}/browse/${encodedPath}${qs ? '?' + qs : ''}`);
  }

  // --- Build Status ---

  async getBuildStatus(commitId, options = {}) {
    const params = {};
    if (options.start !== undefined) params.start = options.start;
    if (options.limit) params.limit = options.limit;
    const qs = new URLSearchParams(params).toString();
    return await this.request('GET', `${this.buildStatusBase}/commits/${this._encodeSegment(commitId)}${qs ? '?' + qs : ''}`);
  }

  async setBuildStatus(commitId, data) {
    return await this.request('POST', `${this.buildStatusBase}/commits/${this._encodeSegment(commitId)}`, data);
  }

  // =====================
  // HTTP REQUEST
  // =====================

  _buildAuthHeaders() {
    if (this.httpAccessToken) {
      return { 'Authorization': `Bearer ${this.httpAccessToken}` };
    }

    if (this.bearerToken) {
      return { 'Authorization': `Bearer ${this.bearerToken}` };
    }

    if (this.basicAuth) {
      return { 'Authorization': `Basic ${this.basicAuth}` };
    }

    const cookieParts = [];
    for (const [name, value] of Object.entries(this.cookies)) {
      if (value) cookieParts.push(`${name}=${value}`);
    }

    const headers = {};
    if (cookieParts.length > 0) {
      headers['Cookie'] = cookieParts.join('; ');
    }

    return headers;
  }

  async request(method, apiPath, body = null) {
    return new Promise((resolve, reject) => {
      const isWrite = method === 'POST' || method === 'PUT' || method === 'DELETE';
      let bodyStr = '';

      if (body && isWrite) {
        bodyStr = JSON.stringify(body);
      }

      const authHeaders = this._buildAuthHeaders();

      const options = {
        hostname: this.host,
        port: this.port,
        path: apiPath,
        method,
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          ...authHeaders,
        },
        rejectUnauthorized: this.verifySsl,
      };

      if (isWrite && bodyStr) {
        options.headers['Content-Length'] = Buffer.byteLength(bodyStr);
      }

      this.log(`${method} ${apiPath}`);

      const protocol = this.protocol === 'https' ? https : http;

      const req = protocol.request(options, (res) => {
        let data = '';

        res.on('data', chunk => {
          data += chunk;
        });

        res.on('end', () => {
          this.log(`Response: ${res.statusCode} (${data.length} bytes)`);

          if (res.statusCode >= 400) {
            let errorMessage = `HTTP ${res.statusCode}`;
            try {
              const parsed = JSON.parse(data);
              const errors = parsed.errors || [];
              errorMessage = errors[0]?.message || parsed.message || errorMessage;
            } catch (e) {
              errorMessage = data.substring(0, 200) || errorMessage;
            }

            if (res.statusCode === 401 || res.statusCode === 403) {
              const err = new Error(errorMessage);
              err.statusCode = res.statusCode;
              err.isAuthError = true;
              reject(err);
              return;
            }

            const err = new Error(errorMessage);
            err.statusCode = res.statusCode;
            reject(err);
            return;
          }

          if (res.statusCode === 204 || !data) {
            resolve({});
            return;
          }

          try {
            resolve(JSON.parse(data));
          } catch (e) {
            resolve(data);
          }
        });
      });

      req.setTimeout(30000, () => {
        req.destroy(new Error('Request timeout after 30s'));
      });

      req.on('error', (error) => {
        const errorMsg = error.message || error.code || error.toString();
        this.log('Request error:', errorMsg);
        reject(new Error(errorMsg));
      });

      if (isWrite && bodyStr) {
        req.write(bodyStr);
      }

      req.end();
    });
  }
}

module.exports = BitbucketClient;
