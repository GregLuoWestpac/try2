# Bitbucket MCP Provider

MCP provider for Bitbucket Server / Data Center. Provides 25 tools for repository browsing, pull request management, commit inspection, and CI build status.

## Configuration

### Environment Variables

| Variable | Description | Required |
|---|---|---|
| `BITBUCKET_HOST` | Bitbucket base URL (e.g., `https://bitbucket.example.com`) | Yes (or config) |
| `BITBUCKET_TOKEN` | HTTP access token (personal or project) | No |
| `BITBUCKET_BEARER_TOKEN` | Bearer token (alternative auth) | No |

### Config File (`.bitbucket_mcp.local.yaml`)

The provider searches for this file in:
1. Current working directory
2. Project root (two levels up from `tools/mcps/bitbucket/`)
3. Home directory (`$HOME` / `$USERPROFILE`)

> Security note: Do **NOT** store plaintext passwords in config files on disk. Prefer `BITBUCKET_TOKEN` (environment variable) for authentication.

```yaml
bitbucket:
  host: https://bitbucket.example.com
  verify_ssl: true
  auth:
    # Preferred: HTTP access token (personal or project-level)
    http_access_token: <your-token>
    # Alternative: bearer token
    # bearer_token: <bearer-token>
keepalive:
  enabled: true
  interval_seconds: 300
```

## Authentication

The provider supports:
- **HTTP access token** (`authenticate http_access_token=...`) — recommended for Bitbucket Server
- **Bearer token** (`authenticate bearer_token=...`)
- **Basic auth** (`authenticate username=... password=...`) — least preferred

> Note: HTTP access tokens (created in Bitbucket → Manage Account → HTTP access tokens) are the recommended auth method. They can be scoped to specific permissions.

## Available Tools (25)

### Session Management
- `start_session` — Initialize connection (host, SSL, load config)
- `reset_session` — Clear session state and auth
- `authenticate` — Authenticate via token or credentials

### Repository Operations
- `get_repos` — List repositories (optionally by project)
- `get_repo` — Get repository details
- `get_branches` — List branches (with optional filter)
- `get_tags` — List tags (with optional filter)
- `get_default_branch` — Get the default branch

### Pull Request Operations
- `search_pull_requests` — List/search PRs (by state, direction, branch)
- `get_pull_request` — Get PR details by ID
- `get_pull_request_diff` — Get the diff for a PR
- `get_pull_request_activities` — Get PR activity feed
- `create_pull_request` — Create a new PR
- `update_pull_request` — Update PR title/description/reviewers
- `merge_pull_request` — Merge a PR (with strategy selection)

### PR Review & Comments
- `get_pull_request_comments` — Get all comments on a PR
- `add_pull_request_comment` — Add general or inline comment
- `approve_pull_request` — Approve a PR
- `decline_pull_request` — Decline a PR

### Commit & File Operations
- `get_commits` — List commits (between refs or for a path)
- `get_commit` — Get single commit details
- `get_file_content` — Get file content at a ref

### Build Status
- `get_build_status` — Get CI build statuses for a commit
- `set_build_status` — Post a build status for a commit

### Projects
- `get_projects` — List accessible Bitbucket projects

## Usage Examples

```text
# Start session (host from env/config)
bitbucket_start_session

# Authenticate with HTTP access token
bitbucket_authenticate http_access_token="..."

# List repos in a project
bitbucket_get_repos project="MYPROJ"

# Get open pull requests
bitbucket_search_pull_requests project="MYPROJ" repo="my-repo" state="OPEN"

# Get PR diff
bitbucket_get_pull_request_diff project="MYPROJ" repo="my-repo" pr_id=42

# Create a PR
bitbucket_create_pull_request project="MYPROJ" repo="my-repo" title="Add feature X" from_ref="feature/x" to_ref="master" reviewers='["jsmith"]'

# Approve a PR
bitbucket_approve_pull_request project="MYPROJ" repo="my-repo" pr_id=42

# Merge a PR with squash strategy
bitbucket_merge_pull_request project="MYPROJ" repo="my-repo" pr_id=42 strategy="squash"

# Get file content at a branch
bitbucket_get_file_content project="MYPROJ" repo="my-repo" path="src/index.js" at="develop"

# Check build status
bitbucket_get_build_status commit_id="abc123def456..."
```

## MCP Server Configuration

### VS Code (GitHub Copilot)

```json
{
  "github.copilot.chat.mcpServers": {
    "bitbucket": {
      "command": "node",
      "args": ["${workspaceFolder}/tools/nodemcp/cli.js", "--layers", "bitbucket"],
      "env": {
        "BITBUCKET_HOST": "https://bitbucket.example.com",
        "BITBUCKET_TOKEN": "your-http-access-token"
      }
    }
  }
}
```

### Claude Code

```json
{
  "mcpServers": {
    "bitbucket": {
      "command": "node",
      "args": ["/path/to/ai-common/tools/nodemcp/cli.js", "--layers", "bitbucket"],
      "env": {
        "BITBUCKET_HOST": "https://bitbucket.example.com",
        "BITBUCKET_TOKEN": "your-http-access-token"
      }
    }
  }
}
```
