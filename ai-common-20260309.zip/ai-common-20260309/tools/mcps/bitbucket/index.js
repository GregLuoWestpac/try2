/**
 * Bitbucket MCP Provider
 *
 * A stateful provider for interacting with Bitbucket Server / Data Center.
 * Provides tools for repositories, pull requests, branches, commits, and builds.
 */

const BaseProvider = require('../../nodemcp/core/BaseProvider');
const BitbucketClient = require('./BitbucketClient');

class BitbucketProvider extends BaseProvider {
  constructor(options = {}) {
    super(options);
    this.setStateful(true);
    this.client = null;
  }

  async initialize() {
    this.log('Initializing Bitbucket provider');
    this.registerAllTools();
  }

  async shutdown() {
    if (this.client) {
      await this.client.logout();
    }
  }

  getClient(context) {
    const session = context.session;
    if (!session) {
      // Cache the stateless client to avoid re-reading config on every tool call
      if (!this._statelessClient) {
        this._statelessClient = new BitbucketClient({ verbose: this.verbose });
        this._statelessClient.initFromConfig();
      }
      return this._statelessClient;
    }

    let client = context.sessionManager.getProviderData(session.id, 'bitbucket', 'client');
    if (!client) {
      client = new BitbucketClient({ verbose: this.verbose });
      client.initFromConfig();
      context.sessionManager.setProviderData(session.id, 'bitbucket', 'client', client);
    }
    return client;
  }

  registerAllTools() {
    // =====================
    // SESSION MANAGEMENT
    // =====================

    this.registerTool({
      name: 'start_session',
      description: 'Start a new Bitbucket session. Call this before other Bitbucket operations to initialize the connection.',
      inputSchema: {
        type: 'object',
        properties: {
          host: this.stringProp('Bitbucket host URL (e.g., https://bitbucket.example.com). Uses BITBUCKET_HOST env var if not provided.'),
          verify_ssl: this.booleanProp('Whether to verify SSL certificates (default: true)'),
          load_config: this.booleanProp('Load configuration from .bitbucket_mcp.local.yaml file (default: true)'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);

        if (args.load_config !== false) {
          const configLoaded = client.initFromConfig();
          if (configLoaded && client.isAuthenticated()) {
            return {
              status: 'session_started',
              host: `${client.protocol}://${client.host}:${client.port}`,
              message: 'Bitbucket session started from config file. Already authenticated.',
              keepalive: client.keepAliveEnabled ? 'enabled' : 'disabled',
            };
          }
        }

        const host = args.host || process.env.BITBUCKET_HOST;
        if (!host) {
          return { error: 'No Bitbucket host provided. Set BITBUCKET_HOST environment variable or provide host parameter.' };
        }

        client.setHost(host, args.verify_ssl !== false);
        return {
          status: 'session_started',
          host,
          message: 'Bitbucket session started. Use authenticate to log in.',
        };
      },
    });

    this.registerTool({
      name: 'reset_session',
      description: 'Reset the current Bitbucket session, clearing all state and authentication.',
      inputSchema: { type: 'object', properties: {} },
      handler: async (args, context) => {
        const client = this.getClient(context);
        client.stopKeepAlive();
        if (context.session) {
          context.sessionManager.clearProviderData(context.session.id, 'bitbucket');
        }
        return { status: 'session_reset', message: 'Bitbucket session has been reset.' };
      },
    });

    this.registerTool({
      name: 'authenticate',
      description: 'Authenticate with Bitbucket using an HTTP access token (recommended), bearer token, or username/password.',
      inputSchema: {
        type: 'object',
        properties: {
          http_access_token: this.stringProp('Bitbucket HTTP access token (personal or project). Uses BITBUCKET_TOKEN env var if not provided.'),
          bearer_token: this.stringProp('Bearer token for authentication. Uses BITBUCKET_BEARER_TOKEN env var if not provided.'),
          username: this.stringProp('Username for basic auth.'),
          password: this.stringProp('Password for basic auth.'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);

        const httpToken = args.http_access_token || process.env.BITBUCKET_TOKEN;
        if (httpToken) {
          client.setHttpAccessToken(httpToken);
          await client.ping();
          return { status: 'authenticated', method: 'http_access_token' };
        }

        const bearer = args.bearer_token || process.env.BITBUCKET_BEARER_TOKEN;
        if (bearer) {
          client.setBearerToken(bearer);
          await client.ping();
          return { status: 'authenticated', method: 'bearer' };
        }

        if (args.username && args.password) {
          client.setBasicAuth(args.username, args.password);
          await client.ping();
          return { status: 'authenticated', method: 'basic', username: args.username };
        }

        return { error: 'No credentials provided. Provide http_access_token (or set BITBUCKET_TOKEN), bearer_token (BITBUCKET_BEARER_TOKEN), or username + password.' };
      },
    });

    // =====================
    // REPOSITORY OPERATIONS
    // =====================

    this.registerTool({
      name: 'get_repos',
      description: 'List repositories, optionally filtered by project key.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key to filter repositories (optional; lists all repos if omitted)'),
          start: this.numberProp('Pagination start index (default: 0)'),
          limit: this.numberProp('Max results per page (default: 25)'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getRepos(args.project, {
          start: args.start,
          limit: args.limit || 25,
        });
      },
    });

    this.registerTool({
      name: 'get_repo',
      description: 'Get details of a specific repository.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
        },
        required: ['project', 'repo'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getRepo(args.project, args.repo);
      },
    });

    this.registerTool({
      name: 'get_branches',
      description: 'List branches for a repository.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
          filter: this.stringProp('Filter branches by name substring'),
          order_by: this.enumProp('Order results', ['ALPHABETICAL', 'MODIFICATION']),
          start: this.numberProp('Pagination start index'),
          limit: this.numberProp('Max results per page (default: 25)'),
        },
        required: ['project', 'repo'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getBranches(args.project, args.repo, {
          filterText: args.filter,
          orderBy: args.order_by,
          start: args.start,
          limit: args.limit || 25,
        });
      },
    });

    this.registerTool({
      name: 'get_tags',
      description: 'List tags for a repository.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
          filter: this.stringProp('Filter tags by name substring'),
          order_by: this.enumProp('Order results', ['ALPHABETICAL', 'MODIFICATION']),
          start: this.numberProp('Pagination start index'),
          limit: this.numberProp('Max results per page (default: 25)'),
        },
        required: ['project', 'repo'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getTags(args.project, args.repo, {
          filterText: args.filter,
          orderBy: args.order_by,
          start: args.start,
          limit: args.limit || 25,
        });
      },
    });

    this.registerTool({
      name: 'get_default_branch',
      description: 'Get the default branch for a repository.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
        },
        required: ['project', 'repo'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getDefaultBranch(args.project, args.repo);
      },
    });

    // =====================
    // PULL REQUEST OPERATIONS
    // =====================

    this.registerTool({
      name: 'search_pull_requests',
      description: 'List pull requests for a repository, with optional filters by state, direction, and branch.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
          state: this.enumProp('PR state filter', ['OPEN', 'MERGED', 'DECLINED', 'ALL']),
          direction: this.enumProp('Filter by direction', ['INCOMING', 'OUTGOING']),
          at: this.stringProp('Fully-qualified branch ref to filter (e.g., refs/heads/master)'),
          order: this.enumProp('Sort order', ['NEWEST', 'OLDEST']),
          start: this.numberProp('Pagination start index'),
          limit: this.numberProp('Max results per page (default: 25)'),
        },
        required: ['project', 'repo'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getPullRequests(args.project, args.repo, {
          state: args.state,
          direction: args.direction,
          at: args.at,
          order: args.order,
          start: args.start,
          limit: args.limit || 25,
        });
      },
    });

    this.registerTool({
      name: 'get_pull_request',
      description: 'Get details of a specific pull request by ID.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
          pr_id: this.numberProp('Pull request ID', { required: true }),
        },
        required: ['project', 'repo', 'pr_id'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getPullRequest(args.project, args.repo, args.pr_id);
      },
    });

    this.registerTool({
      name: 'get_pull_request_diff',
      description: 'Get the diff for a pull request.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
          pr_id: this.numberProp('Pull request ID', { required: true }),
          context_lines: this.numberProp('Number of context lines around changes (default: 10)'),
          with_comments: this.booleanProp('Include comments in diff (default: false)'),
        },
        required: ['project', 'repo', 'pr_id'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getPullRequestDiff(args.project, args.repo, args.pr_id, {
          contextLines: args.context_lines,
          withComments: args.with_comments,
        });
      },
    });

    this.registerTool({
      name: 'get_pull_request_activities',
      description: 'Get the activity feed for a pull request (comments, approvals, merges, status changes).',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
          pr_id: this.numberProp('Pull request ID', { required: true }),
          start: this.numberProp('Pagination start index'),
          limit: this.numberProp('Max results per page (default: 25)'),
        },
        required: ['project', 'repo', 'pr_id'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getPullRequestActivities(args.project, args.repo, args.pr_id, {
          start: args.start,
          limit: args.limit || 25,
        });
      },
    });

    this.registerTool({
      name: 'create_pull_request',
      description: 'Create a new pull request.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
          title: this.stringProp('PR title', { required: true }),
          description: this.stringProp('PR description (optional)'),
          from_ref: this.stringProp('Source branch (e.g., feature/my-branch)', { required: true }),
          to_ref: this.stringProp('Target branch (e.g., master)', { required: true }),
          reviewers: this.arrayProp('List of reviewer usernames', { type: 'string' }),
        },
        required: ['project', 'repo', 'title', 'from_ref', 'to_ref'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        const data = {
          title: args.title,
          fromRef: { id: `refs/heads/${args.from_ref}`, repository: { slug: args.repo, project: { key: args.project } } },
          toRef: { id: `refs/heads/${args.to_ref}`, repository: { slug: args.repo, project: { key: args.project } } },
        };
        if (args.description) data.description = args.description;
        if (args.reviewers && args.reviewers.length > 0) {
          data.reviewers = args.reviewers.map(u => ({ user: { name: u } }));
        }
        return await client.createPullRequest(args.project, args.repo, data);
      },
    });

    this.registerTool({
      name: 'update_pull_request',
      description: 'Update a pull request (title, description, reviewers, or target branch).',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
          pr_id: this.numberProp('Pull request ID', { required: true }),
          title: this.stringProp('New title'),
          description: this.stringProp('New description'),
          to_ref: this.stringProp('New target branch'),
          reviewers: this.arrayProp('Updated list of reviewer usernames', { type: 'string' }),
          version: this.numberProp('Current PR version (for optimistic locking)'),
        },
        required: ['project', 'repo', 'pr_id'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        const existing = await client.getPullRequest(args.project, args.repo, args.pr_id);
        const data = {
          id: args.pr_id,
          version: args.version !== undefined ? args.version : existing.version,
          title: args.title || existing.title,
          description: args.description !== undefined ? args.description : existing.description,
          toRef: args.to_ref ? { id: `refs/heads/${args.to_ref}` } : existing.toRef,
        };
        if (args.reviewers) {
          data.reviewers = args.reviewers.map(u => ({ user: { name: u } }));
        } else {
          data.reviewers = existing.reviewers;
        }
        return await client.updatePullRequest(args.project, args.repo, args.pr_id, data);
      },
    });

    this.registerTool({
      name: 'merge_pull_request',
      description: 'Merge a pull request.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
          pr_id: this.numberProp('Pull request ID', { required: true }),
          version: this.numberProp('Current PR version (for optimistic locking)'),
          message: this.stringProp('Merge commit message'),
          strategy: this.enumProp('Merge strategy', ['merge-commit', 'rebase-no-ff', 'rebase-ff-only', 'squash', 'squash-ff-only']),
        },
        required: ['project', 'repo', 'pr_id'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.mergePullRequest(args.project, args.repo, args.pr_id, {
          version: args.version,
          message: args.message,
          strategyId: args.strategy,
        });
      },
    });

    // =====================
    // PR REVIEW & COMMENTS
    // =====================

    this.registerTool({
      name: 'get_pull_request_comments',
      description: 'Get all comments on a pull request.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
          pr_id: this.numberProp('Pull request ID', { required: true }),
          start: this.numberProp('Pagination start index'),
          limit: this.numberProp('Max results per page (default: 25)'),
        },
        required: ['project', 'repo', 'pr_id'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getPullRequestComments(args.project, args.repo, args.pr_id, {
          start: args.start,
          limit: args.limit || 25,
        });
      },
    });

    this.registerTool({
      name: 'add_pull_request_comment',
      description: 'Add a general or inline comment to a pull request.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
          pr_id: this.numberProp('Pull request ID', { required: true }),
          text: this.stringProp('Comment text', { required: true }),
          parent_id: this.numberProp('Parent comment ID (for replies)'),
          file_path: this.stringProp('File path for inline comment'),
          line: this.numberProp('Line number for inline comment'),
          line_type: this.enumProp('Line type for inline comment', ['ADDED', 'REMOVED', 'CONTEXT']),
          file_type: this.enumProp('File type for inline comment', ['FROM', 'TO']),
        },
        required: ['project', 'repo', 'pr_id', 'text'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        const data = { text: args.text };
        if (args.parent_id) {
          data.parent = { id: args.parent_id };
        }
        if (args.file_path) {
          data.anchor = {
            path: args.file_path,
            srcPath: args.file_path,
          };
          if (args.line !== undefined) data.anchor.line = args.line;
          if (args.line_type) data.anchor.lineType = args.line_type;
          if (args.file_type) data.anchor.fileType = args.file_type;
        }
        return await client.addPullRequestComment(args.project, args.repo, args.pr_id, data);
      },
    });

    this.registerTool({
      name: 'approve_pull_request',
      description: 'Approve a pull request as the current authenticated user.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
          pr_id: this.numberProp('Pull request ID', { required: true }),
        },
        required: ['project', 'repo', 'pr_id'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        await client.approvePullRequest(args.project, args.repo, args.pr_id);
        return { status: 'approved', pr_id: args.pr_id };
      },
    });

    this.registerTool({
      name: 'decline_pull_request',
      description: 'Decline a pull request.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
          pr_id: this.numberProp('Pull request ID', { required: true }),
          version: this.numberProp('Current PR version (for optimistic locking)'),
        },
        required: ['project', 'repo', 'pr_id'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        await client.declinePullRequest(args.project, args.repo, args.pr_id, {
          version: args.version,
        });
        return { status: 'declined', pr_id: args.pr_id };
      },
    });

    // =====================
    // COMMIT & FILE OPERATIONS
    // =====================

    this.registerTool({
      name: 'get_commits',
      description: 'List commits for a repository, optionally between two refs or for a specific file path.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
          since: this.stringProp('Commit ID or ref to start from (exclusive)'),
          until: this.stringProp('Commit ID or ref to go up to (inclusive, defaults to default branch HEAD)'),
          path: this.stringProp('File path to filter commits by'),
          start: this.numberProp('Pagination start index'),
          limit: this.numberProp('Max results per page (default: 25)'),
        },
        required: ['project', 'repo'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getCommits(args.project, args.repo, {
          since: args.since,
          until: args.until,
          path: args.path,
          start: args.start,
          limit: args.limit || 25,
        });
      },
    });

    this.registerTool({
      name: 'get_commit',
      description: 'Get details of a single commit by its commit ID.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
          commit_id: this.stringProp('Full or abbreviated commit SHA', { required: true }),
        },
        required: ['project', 'repo', 'commit_id'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getCommit(args.project, args.repo, args.commit_id);
      },
    });

    this.registerTool({
      name: 'get_file_content',
      description: 'Get file content at a specific ref or path in a repository.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key', { required: true }),
          repo: this.stringProp('Repository slug', { required: true }),
          path: this.stringProp('File path within the repository', { required: true }),
          at: this.stringProp('Branch, tag, or commit to read from (defaults to default branch)'),
          start: this.numberProp('Pagination start (for large files)'),
          limit: this.numberProp('Max lines to return'),
        },
        required: ['project', 'repo', 'path'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getFileContent(args.project, args.repo, args.path, {
          at: args.at,
          start: args.start,
          limit: args.limit,
        });
      },
    });

    // =====================
    // BUILD STATUS
    // =====================

    this.registerTool({
      name: 'get_build_status',
      description: 'Get build statuses for a commit (CI/CD pipeline results).',
      inputSchema: {
        type: 'object',
        properties: {
          commit_id: this.stringProp('Full commit SHA', { required: true }),
          start: this.numberProp('Pagination start index'),
          limit: this.numberProp('Max results per page (default: 25)'),
        },
        required: ['commit_id'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getBuildStatus(args.commit_id, {
          start: args.start,
          limit: args.limit || 25,
        });
      },
    });

    this.registerTool({
      name: 'set_build_status',
      description: 'Post a build status for a commit (e.g., from a CI pipeline).',
      inputSchema: {
        type: 'object',
        properties: {
          commit_id: this.stringProp('Full commit SHA', { required: true }),
          state: this.enumProp('Build state', ['SUCCESSFUL', 'FAILED', 'INPROGRESS'], { required: true }),
          key: this.stringProp('Unique build key (e.g., pipeline name)', { required: true }),
          url: this.stringProp('URL to the build result', { required: true }),
          name: this.stringProp('Display name for the build'),
          description: this.stringProp('Build description'),
        },
        required: ['commit_id', 'state', 'key', 'url'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        const data = {
          state: args.state,
          key: args.key,
          url: args.url,
        };
        if (args.name) data.name = args.name;
        if (args.description) data.description = args.description;
        return await client.setBuildStatus(args.commit_id, data);
      },
    });

    // =====================
    // PROJECT & USER
    // =====================

    this.registerTool({
      name: 'get_projects',
      description: 'List accessible Bitbucket projects.',
      inputSchema: {
        type: 'object',
        properties: {
          start: this.numberProp('Pagination start index'),
          limit: this.numberProp('Max results per page (default: 25)'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getProjects({
          start: args.start,
          limit: args.limit || 25,
        });
      },
    });

    this.log(`Registered ${this.tools.length} Bitbucket tools`);
  }
}

module.exports = BitbucketProvider;
