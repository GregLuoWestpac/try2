/**
 * Splunk MCP Provider
 * 
 * A stateful provider for interacting with Splunk Enterprise/Cloud.
 * Provides tools for searching, monitoring, and diagnosing issues.
 */

const BaseProvider = require('../../nodemcp/core/BaseProvider');
const SplunkClient = require('./SplunkClient');
const SplunkAuthFlow = require('./SplunkAuthFlow');

class SplunkProvider extends BaseProvider {
  constructor(options = {}) {
    super(options);
    this.setStateful(true); // Splunk sessions are stateful
    this.client = null;
  }

  async initialize() {
    this.log('Initializing Splunk provider');
    this.registerAllTools();
  }

  async shutdown() {
    if (this.client) {
      await this.client.logout();
    }
  }

  /**
   * Get or create client for session
   */
  getClient(context) {
    const session = context.session;
    if (!session) {
      // No session - create a new client and init from config
      const client = new SplunkClient({ verbose: this.verbose });
      client.initFromConfig();
      return client;
    }

    // Get client from session or create new one
    let client = context.sessionManager.getProviderData(session.id, 'splunk', 'client');
    if (!client) {
      client = new SplunkClient({ verbose: this.verbose });
      // Always initialize from config for new clients
      client.initFromConfig();
      context.sessionManager.setProviderData(session.id, 'splunk', 'client', client);
    }
    return client;
  }

  /**
   * Perform SSO login flow using browser automation.
   * Obtains credentials via env vars, config, or MCP elicitation, then drives
   * the Microsoft SSO flow and extracts Splunk session cookies.
   * 
   * @param {SplunkClient} client - The Splunk client to update tokens on
   * @param {Object} context - MCP context for elicitation
   * @param {Object} overrides - Optional overrides for email/password/headless
   * @returns {Object} Result with status and token info
   */
  async _performSsoLogin(client, context, overrides = {}) {
    const ssoConfig = client.getSsoConfig();

    // Resolve email: override > env > config > elicit
    let email = overrides.email || ssoConfig.email;
    if (!email && context) {
      try {
        const result = await context.elicit({
          message: 'Enter your SSO email address for Splunk login:',
          requestedSchema: {
            type: 'object',
            properties: {
              email: { type: 'string', title: 'SSO Email', format: 'email' },
            },
            required: ['email'],
          },
        });
        email = result.action === 'accept' ? result.content?.email : null;
      } catch (e) {
        this.log(`Email elicitation failed: ${e.message}`);
      }
    }
    if (!email) {
      return { error: 'SSO email is required. Set SPLUNK_SSO_EMAIL env var, add sso.email to config, or provide it as a parameter.' };
    }

    // Resolve password: override > env > config > elicit > console prompt
    let password = overrides.password || process.env.SPLUNK_SSO_PASSWORD || ssoConfig.password;
    if (!password && context) {
      try {
        const result = await context.elicit({
          message: `Enter your password for ${email}:`,
          requestedSchema: {
            type: 'object',
            properties: {
              password: { type: 'string', title: 'Password' },
            },
            required: ['password'],
          },
        });
        password = result.action === 'accept' ? result.content?.password : null;
      } catch (e) {
        this.log(`Password elicitation failed: ${e.message}`);
      }
    }
    if (!password) {
      // Last resort: prompt on the MCP server console (stdin)
      try {
        password = await this._promptPasswordFromConsole(email);
      } catch (e) {
        this.log(`Console password prompt failed: ${e.message}`);
      }
    }
    if (!password) {
      return { error: 'SSO password is required. Set SPLUNK_SSO_PASSWORD env var, add sso.password to config, or provide it as a parameter.' };
    }

    const headless = overrides.headless !== undefined ? overrides.headless : ssoConfig.headless;

    // Run the auth flow
    const authFlow = new SplunkAuthFlow({
      splunkUrl: ssoConfig.splunkUrl,
      headless,
      timeoutSeconds: ssoConfig.timeoutSeconds,
      verbose: this.verbose,
    });

    try {
      if (context) {
        try { await context.info('Starting SSO login flow...'); } catch (e) { /* ignore */ }
      }

      const tokens = await authFlow.authenticate({ email, password, mfaCode: overrides.mfaCode, context });

      // Update client with new tokens
      const result = client.updateTokens(tokens, true);

      // Restart keep-alive
      client.stopKeepAlive();
      client.startKeepAlive(300);

      // Verify the tokens work
      try {
        const pingResult = await client.ping();
        result.verified = true;
        result.serverName = pingResult.serverName;
      } catch (e) {
        result.verified = false;
        result.verification_error = e.message;
      }

      result.sso_login = 'success';
      result.email = email;
      return result;
    } catch (e) {
      return { error: `SSO login failed: ${e.message}`, sso_login: 'failed' };
    }
  }

  /**
   * Prompt for password on the MCP server console (stdin).
   * Used as a last resort when no password is available from config, env, or elicitation.
   */
  _promptPasswordFromConsole(email) {
    return new Promise((resolve, reject) => {
      const readline = require('readline');
      const rl = readline.createInterface({
        input: process.stdin,
        output: process.stderr,
      });

      console.error(`\n${'='.repeat(60)}`);
      console.error(`🔐 SSO password required for ${email}`);
      console.error(`${'='.repeat(60)}`);

      rl.question('Password: ', (answer) => {
        rl.close();
        if (answer && answer.trim()) {
          resolve(answer.trim());
        } else {
          reject(new Error('No password entered'));
        }
      });

      // Timeout after 60 seconds
      setTimeout(() => {
        rl.close();
        reject(new Error('Password prompt timed out'));
      }, 60000);
    });
  }

  /**
   * Register all Splunk tools
   */
  registerAllTools() {
    // =====================
    // SESSION MANAGEMENT
    // =====================
    
    this.registerTool({
      name: 'start_session',
      description: 'Start a new Splunk session. Call this before other Splunk operations to initialize the connection.',
      inputSchema: {
        type: 'object',
        properties: {
          host: this.stringProp('Splunk host URL (e.g., https://splunk.example.com:8089). Uses SPLUNK_HOST env var if not provided.'),
          verify_ssl: this.booleanProp('Whether to verify SSL certificates (default: true)'),
          load_config: this.booleanProp('Load configuration from .splunk_mcp.local.yaml file (default: true)'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        
        // Try to load from config file first
        if (args.load_config !== false) {
          const configLoaded = client.initFromConfig();
          if (configLoaded && client.isAuthenticated()) {
            // Verify tokens are still valid
            const expired = await client.isTokenExpired();
            if (!expired) {
              return { 
                status: 'session_started',
                host: `${client.protocol}://${client.host}:${client.port}`,
                message: 'Splunk session started from config file. Already authenticated.',
                keepalive: client.keepAliveEnabled ? 'enabled' : 'disabled',
              };
            }

            // Tokens are expired — try SSO auto-login
            this.log('Tokens expired, attempting SSO re-authentication');
            if (context) {
              try { await context.info('Session tokens expired. Starting SSO re-authentication...'); } catch (e) { /* ignore */ }
            }
            const ssoResult = await this._performSsoLogin(client, context);
            if (ssoResult.error) {
              return {
                status: 'session_started_unauthenticated',
                host: `${client.protocol}://${client.host}:${client.port}`,
                message: `Config loaded but tokens expired. SSO login failed: ${ssoResult.error}. Use sso_login or update_tokens to re-authenticate.`,
                sso_attempted: true,
              };
            }
            return {
              status: 'session_started',
              host: `${client.protocol}://${client.host}:${client.port}`,
              message: 'Splunk session started. Tokens were expired and have been refreshed via SSO.',
              sso_login: 'success',
              keepalive: client.keepAliveEnabled ? 'enabled' : 'disabled',
            };
          }
        }
        
        const host = args.host || process.env.SPLUNK_HOST;
        
        if (!host) {
          return { error: 'No Splunk host provided. Set SPLUNK_HOST environment variable or provide host parameter.' };
        }

        client.setHost(host, args.verify_ssl !== false);
        return { 
          status: 'session_started',
          host: host,
          message: 'Splunk session started. Use authenticate or sso_login to log in.',
        };
      },
    });

    this.registerTool({
      name: 'reset_session',
      description: 'Reset the current Splunk session, clearing all state and authentication.',
      inputSchema: { type: 'object', properties: {} },
      handler: async (args, context) => {
        const client = this.getClient(context);
        client.stopKeepAlive();
        if (context.session) {
          context.sessionManager.clearProviderData(context.session.id, 'splunk');
        }
        return { status: 'session_reset', message: 'Splunk session has been reset.' };
      },
    });

    this.registerTool({
      name: 'session_keepalive',
      description: 'Manage session keep-alive to prevent token expiration. Can start, stop, or check keep-alive status.',
      inputSchema: {
        type: 'object',
        properties: {
          action: this.enumProp('Action to perform', ['start', 'stop', 'status', 'ping'], { required: true }),
          interval_seconds: this.numberProp('Keep-alive ping interval in seconds (default: 300)'),
        },
        required: ['action'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        
        switch (args.action) {
          case 'start':
            client.startKeepAlive(args.interval_seconds || 300);
            return { 
              status: 'keepalive_started', 
              interval: args.interval_seconds || 300,
              message: `Keep-alive started with ${args.interval_seconds || 300}s interval`,
            };
          
          case 'stop':
            client.stopKeepAlive();
            return { status: 'keepalive_stopped', message: 'Keep-alive stopped' };
          
          case 'status':
            return { 
              enabled: client.keepAliveEnabled,
              message: client.keepAliveEnabled ? 'Keep-alive is active' : 'Keep-alive is not running',
            };
          
          case 'ping':
            try {
              const result = await client.ping();
              return { status: 'alive', ...result };
            } catch (e) {
              return { status: 'failed', error: e.message };
            }
          
          default:
            return { error: `Unknown action: ${args.action}` };
        }
      },
    });

    this.registerTool({
      name: 'authenticate',
      description: 'Authenticate with Splunk using username/password or token. Required before running searches.',
      inputSchema: {
        type: 'object',
        properties: {
          username: this.stringProp('Splunk username. Uses SPLUNK_USERNAME env var if not provided.'),
          password: this.stringProp('Splunk password. Uses SPLUNK_PASSWORD env var if not provided.'),
          token: this.stringProp('Bearer token for authentication. Uses SPLUNK_TOKEN env var if not provided.'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        
        const token = args.token || process.env.SPLUNK_TOKEN;
        if (token) {
          await client.authenticateWithToken(token);
          return { status: 'authenticated', method: 'token' };
        }

        const username = args.username || process.env.SPLUNK_USERNAME;
        const password = args.password || process.env.SPLUNK_PASSWORD;

        if (!username || !password) {
          return { error: 'No credentials provided. Set SPLUNK_USERNAME/SPLUNK_PASSWORD or SPLUNK_TOKEN.' };
        }

        const result = await client.authenticate(username, password);
        return { status: 'authenticated', method: 'password', sessionKey: result.sessionKey ? '***' : undefined };
      },
    });

    this.registerTool({
      name: 'update_tokens',
      description: 'Update session tokens without restarting the server. Updates tokens in memory, saves to config file, and restarts keep-alive. Use this when your session tokens have expired.',
      inputSchema: {
        type: 'object',
        properties: {
          session_key: this.stringProp('Main session key (splunkd_8443 cookie value)', { required: true }),
          csrf_token: this.stringProp('CSRF token (splunkweb_csrf_token_8443 cookie value)', { required: true }),
          lb_cookie: this.stringProp('Load balancer cookie (LB cookie value)'),
          session_id: this.stringProp('Session ID (session_id_8443 cookie value)'),
          restart_keepalive: this.booleanProp('Restart keep-alive after updating tokens (default: true)'),
          keepalive_interval: this.numberProp('Keep-alive interval in seconds (default: 300)'),
        },
        required: ['session_key', 'csrf_token'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        
        // Update tokens in memory and config file
        const tokens = {
          session_key: args.session_key,
          csrf_token: args.csrf_token,
          lb_cookie: args.lb_cookie,
          session_id: args.session_id,
        };
        
        const result = client.updateTokens(tokens, true);
        
        // Restart keep-alive if requested (default: true)
        if (args.restart_keepalive !== false) {
          client.stopKeepAlive();
          client.startKeepAlive(args.keepalive_interval || 300);
          result.keepalive = 'restarted';
          result.keepalive_interval = args.keepalive_interval || 300;
        }
        
        // Verify the new tokens work by pinging the server
        try {
          const pingResult = await client.ping();
          result.verified = true;
          result.serverName = pingResult.serverName;
        } catch (e) {
          result.verified = false;
          result.verification_error = e.message;
        }
        
        return result;
      },
    });

    this.registerTool({
      name: 'sso_login',
      description: 'Authenticate with Splunk via Microsoft SSO. Opens a browser to drive the SAML login flow, handles MFA, and extracts session cookies. Use when tokens are expired or for initial setup.',
      inputSchema: {
        type: 'object',
        properties: {
          email: this.stringProp('SSO email address. Uses SPLUNK_SSO_EMAIL env var or config if not provided.'),
          password: this.stringProp('SSO password. Will prompt via MCP elicitation if not provided. Never saved to disk.'),
          headless: this.booleanProp('Run browser in headless mode (default: true). Set false to see the browser during login.'),
          mfa_code: this.stringProp('MFA verification code, if using TOTP/SMS. For number-matching MFA, approve on your phone instead.'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);

        if (!client.host) {
          return { error: 'No Splunk host configured. Call start_session first or set SPLUNK_HOST.' };
        }

        const result = await this._performSsoLogin(client, context, {
          email: args.email,
          password: args.password,
          headless: args.headless,
          mfaCode: args.mfa_code,
        });

        return result;
      },
    });

    // =====================
    // SEARCH OPERATIONS
    // =====================

    this.registerTool({
      name: 'search',
      description: 'Execute a Splunk search query (SPL). Returns a search job ID for async searches, or results for fast queries.',
      inputSchema: {
        type: 'object',
        properties: {
          query: this.stringProp('SPL search query (e.g., "index=main error | head 10")', { required: true }),
          earliest_time: this.stringProp('Start time (e.g., "-1h", "-7d", "2024-01-01T00:00:00")'),
          latest_time: this.stringProp('End time (e.g., "now", "-1h", "2024-01-02T00:00:00")'),
          max_results: this.numberProp('Maximum number of results to return (default: 100)'),
          exec_mode: this.enumProp('Execution mode', ['normal', 'blocking', 'oneshot'], { default: 'normal' }),
        },
        required: ['query'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.search({
          query: args.query,
          earliest_time: args.earliest_time || '-24h',
          latest_time: args.latest_time || 'now',
          max_results: args.max_results || 100,
          exec_mode: args.exec_mode || 'blocking',
        });
      },
    });

    this.registerTool({
      name: 'search_oneshot',
      description: 'Execute a one-shot Splunk search that blocks until complete. Best for quick queries.',
      inputSchema: {
        type: 'object',
        properties: {
          query: this.stringProp('SPL search query', { required: true }),
          earliest_time: this.stringProp('Start time (default: -1h)'),
          latest_time: this.stringProp('End time (default: now)'),
          max_results: this.numberProp('Maximum results (default: 1000)'),
        },
        required: ['query'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.searchOneshot({
          query: args.query,
          earliest_time: args.earliest_time || '-1h',
          latest_time: args.latest_time || 'now',
          max_results: args.max_results || 1000,
        });
      },
    });

    this.registerTool({
      name: 'get_search_status',
      description: 'Check the status of an asynchronous search job.',
      inputSchema: {
        type: 'object',
        properties: {
          sid: this.stringProp('Search job ID returned from search command', { required: true }),
        },
        required: ['sid'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getSearchStatus(args.sid);
      },
    });

    this.registerTool({
      name: 'get_search_results',
      description: 'Get results from a completed search job.',
      inputSchema: {
        type: 'object',
        properties: {
          sid: this.stringProp('Search job ID', { required: true }),
          offset: this.numberProp('Starting offset for pagination (default: 0)'),
          count: this.numberProp('Number of results to return (default: 100)'),
          output_mode: this.enumProp('Output format', ['json', 'csv', 'xml'], { default: 'json' }),
        },
        required: ['sid'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getSearchResults(args.sid, {
          offset: args.offset || 0,
          count: args.count || 100,
          output_mode: args.output_mode || 'json',
        });
      },
    });

    this.registerTool({
      name: 'cancel_search',
      description: 'Cancel a running search job.',
      inputSchema: {
        type: 'object',
        properties: {
          sid: this.stringProp('Search job ID to cancel', { required: true }),
        },
        required: ['sid'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.cancelSearch(args.sid);
      },
    });

    this.registerTool({
      name: 'search_export',
      description: 'Export large search results. Returns results in streaming format.',
      inputSchema: {
        type: 'object',
        properties: {
          query: this.stringProp('SPL search query', { required: true }),
          earliest_time: this.stringProp('Start time'),
          latest_time: this.stringProp('End time'),
          output_mode: this.enumProp('Output format', ['json', 'csv', 'xml'], { default: 'json' }),
        },
        required: ['query'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.searchExport({
          query: args.query,
          earliest_time: args.earliest_time || '-24h',
          latest_time: args.latest_time || 'now',
          output_mode: args.output_mode || 'json',
        });
      },
    });

    // =====================
    // INDEX & DATA OPERATIONS
    // =====================

    this.registerTool({
      name: 'list_indexes',
      description: 'List all available Splunk indexes with their status and event counts.',
      inputSchema: {
        type: 'object',
        properties: {
          filter: this.stringProp('Filter indexes by name pattern'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.listIndexes(args.filter);
      },
    });

    this.registerTool({
      name: 'get_index_info',
      description: 'Get detailed information about a specific index.',
      inputSchema: {
        type: 'object',
        properties: {
          index: this.stringProp('Name of the index', { required: true }),
        },
        required: ['index'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getIndexInfo(args.index);
      },
    });

    this.registerTool({
      name: 'list_sourcetypes',
      description: 'List all sourcetypes in an index or across all indexes.',
      inputSchema: {
        type: 'object',
        properties: {
          index: this.stringProp('Limit to specific index (optional)'),
          earliest_time: this.stringProp('Start time for sourcetype discovery'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.listSourcetypes(args.index, args.earliest_time);
      },
    });

    this.registerTool({
      name: 'get_earliest_time',
      description: 'Get the timestamp of the earliest event in an index.',
      inputSchema: {
        type: 'object',
        properties: {
          index: this.stringProp('Index name', { required: true }),
          sourcetype: this.stringProp('Optional sourcetype filter'),
        },
        required: ['index'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        const query = `search index=${args.index}${args.sourcetype ? ` sourcetype=${args.sourcetype}` : ''} | head 1 | eval earliest=_time | table earliest`;
        return await client.searchOneshot({ query, earliest_time: '0', latest_time: 'now', max_results: 1 });
      },
    });

    this.registerTool({
      name: 'get_latest_time',
      description: 'Get the timestamp of the latest/most recent event in an index.',
      inputSchema: {
        type: 'object',
        properties: {
          index: this.stringProp('Index name', { required: true }),
          sourcetype: this.stringProp('Optional sourcetype filter'),
        },
        required: ['index'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        const query = `search index=${args.index}${args.sourcetype ? ` sourcetype=${args.sourcetype}` : ''} | head 1 | eval latest=_time | table latest`;
        return await client.searchOneshot({ query, earliest_time: '-24h', latest_time: 'now', max_results: 1 });
      },
    });

    this.registerTool({
      name: 'get_event_count',
      description: 'Get the count of events in an index for a time range.',
      inputSchema: {
        type: 'object',
        properties: {
          index: this.stringProp('Index name', { required: true }),
          earliest_time: this.stringProp('Start time (default: -24h)'),
          latest_time: this.stringProp('End time (default: now)'),
          sourcetype: this.stringProp('Optional sourcetype filter'),
          host: this.stringProp('Optional host filter'),
        },
        required: ['index'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        let query = `search index=${args.index}`;
        if (args.sourcetype) query += ` sourcetype=${args.sourcetype}`;
        if (args.host) query += ` host=${args.host}`;
        query += ' | stats count';
        
        return await client.searchOneshot({
          query,
          earliest_time: args.earliest_time || '-24h',
          latest_time: args.latest_time || 'now',
        });
      },
    });

    // =====================
    // DEBUGGING & DIAGNOSTICS
    // =====================

    this.registerTool({
      name: 'find_errors',
      description: 'Search for errors in logs. Automatically searches for common error patterns.',
      inputSchema: {
        type: 'object',
        properties: {
          index: this.stringProp('Index to search (default: main)'),
          earliest_time: this.stringProp('Start time (default: -1h)'),
          latest_time: this.stringProp('End time (default: now)'),
          severity: this.enumProp('Error severity level', ['ERROR', 'WARN', 'FATAL', 'CRITICAL', 'ALL'], { default: 'ERROR' }),
          application: this.stringProp('Filter by application/service name'),
          host: this.stringProp('Filter by host'),
          max_results: this.numberProp('Maximum results (default: 50)'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        const index = args.index || 'main';
        const severity = args.severity || 'ERROR';
        
        let severityFilter = '';
        if (severity === 'ALL') {
          severityFilter = '(ERROR OR WARN OR FATAL OR CRITICAL OR Exception)';
        } else {
          severityFilter = severity;
        }

        let query = `search index=${index} ${severityFilter}`;
        if (args.application) query += ` application="${args.application}"`;
        if (args.host) query += ` host="${args.host}"`;
        query += ' | head ' + (args.max_results || 50);
        query += ' | table _time, host, source, sourcetype, _raw';

        return await client.searchOneshot({
          query,
          earliest_time: args.earliest_time || '-1h',
          latest_time: args.latest_time || 'now',
          max_results: args.max_results || 50,
        });
      },
    });

    this.registerTool({
      name: 'find_exceptions',
      description: 'Search for exceptions and stack traces in logs.',
      inputSchema: {
        type: 'object',
        properties: {
          index: this.stringProp('Index to search (default: main)'),
          earliest_time: this.stringProp('Start time (default: -1h)'),
          exception_type: this.stringProp('Specific exception type to search for (e.g., NullPointerException)'),
          application: this.stringProp('Filter by application name'),
          max_results: this.numberProp('Maximum results (default: 20)'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        const index = args.index || 'main';
        
        let exceptionPattern = args.exception_type || 'Exception OR Traceback OR "stack trace" OR Error:';
        let query = `search index=${index} (${exceptionPattern})`;
        if (args.application) query += ` application="${args.application}"`;
        query += ' | head ' + (args.max_results || 20);
        query += ' | table _time, host, source, _raw';

        return await client.searchOneshot({
          query,
          earliest_time: args.earliest_time || '-1h',
          latest_time: args.latest_time || 'now',
        });
      },
    });

    this.registerTool({
      name: 'analyze_latency',
      description: 'Analyze response times and latency patterns in logs.',
      inputSchema: {
        type: 'object',
        properties: {
          index: this.stringProp('Index to search', { required: true }),
          latency_field: this.stringProp('Field containing latency/duration value (default: duration)'),
          earliest_time: this.stringProp('Start time (default: -1h)'),
          latest_time: this.stringProp('End time (default: now)'),
          group_by: this.stringProp('Field to group statistics by (e.g., endpoint, host)'),
          threshold_ms: this.numberProp('Highlight latencies above this threshold in ms'),
        },
        required: ['index'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        const field = args.latency_field || 'duration';
        const groupBy = args.group_by || 'host';
        
        let query = `search index=${args.index} ${field}=*`;
        query += ` | stats avg(${field}) as avg_latency, max(${field}) as max_latency, min(${field}) as min_latency, p95(${field}) as p95_latency, count by ${groupBy}`;
        query += ' | sort -avg_latency';

        return await client.searchOneshot({
          query,
          earliest_time: args.earliest_time || '-1h',
          latest_time: args.latest_time || 'now',
        });
      },
    });

    this.registerTool({
      name: 'trace_transaction',
      description: 'Trace a transaction or request across multiple log sources using a transaction ID.',
      inputSchema: {
        type: 'object',
        properties: {
          transaction_id: this.stringProp('Transaction/correlation/request ID to trace', { required: true }),
          index: this.stringProp('Index to search (default: * for all)'),
          id_field: this.stringProp('Field name containing the transaction ID (default: auto-detect)'),
          earliest_time: this.stringProp('Start time (default: -24h)'),
        },
        required: ['transaction_id'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        const index = args.index || '*';
        const txId = args.transaction_id;
        
        // Try common transaction ID field names
        let query = `search index=${index} ("${txId}" OR transaction_id="${txId}" OR correlation_id="${txId}" OR request_id="${txId}" OR trace_id="${txId}")`;
        query += ' | sort _time | table _time, host, source, sourcetype, _raw';

        return await client.searchOneshot({
          query,
          earliest_time: args.earliest_time || '-24h',
          latest_time: args.latest_time || 'now',
          max_results: 500,
        });
      },
    });

    this.registerTool({
      name: 'correlate_events',
      description: 'Correlate events across multiple sources within a time window.',
      inputSchema: {
        type: 'object',
        properties: {
          search_terms: this.stringProp('Search terms to find related events', { required: true }),
          index: this.stringProp('Index to search (default: *)'),
          time_window: this.stringProp('Time window for correlation (default: 5m)'),
          earliest_time: this.stringProp('Start time'),
          group_by: this.stringProp('Field to correlate on (e.g., host, user)'),
        },
        required: ['search_terms'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        const index = args.index || '*';
        const groupBy = args.group_by || 'host';
        
        let query = `search index=${index} ${args.search_terms}`;
        query += ` | bin _time span=${args.time_window || '5m'}`;
        query += ` | stats count, values(source) as sources, values(sourcetype) as sourcetypes by _time, ${groupBy}`;
        query += ' | sort _time';

        return await client.searchOneshot({
          query,
          earliest_time: args.earliest_time || '-1h',
          latest_time: args.latest_time || 'now',
        });
      },
    });

    this.registerTool({
      name: 'get_field_summary',
      description: 'Get summary statistics for a specific field in the data.',
      inputSchema: {
        type: 'object',
        properties: {
          field: this.stringProp('Field name to analyze', { required: true }),
          index: this.stringProp('Index to search (default: main)'),
          earliest_time: this.stringProp('Start time (default: -1h)'),
          top_values: this.numberProp('Number of top values to show (default: 10)'),
        },
        required: ['field'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        const index = args.index || 'main';
        const topN = args.top_values || 10;
        
        let query = `search index=${index} ${args.field}=*`;
        query += ` | stats count, dc(${args.field}) as unique_values, values(${args.field}) as sample_values by index`;
        query += ` | append [search index=${index} ${args.field}=* | top ${topN} ${args.field}]`;

        return await client.searchOneshot({
          query,
          earliest_time: args.earliest_time || '-1h',
          latest_time: args.latest_time || 'now',
        });
      },
    });

    // =====================
    // SAVED SEARCHES & ALERTS
    // =====================

    this.registerTool({
      name: 'list_saved_searches',
      description: 'List all saved searches/reports available to the user.',
      inputSchema: {
        type: 'object',
        properties: {
          app: this.stringProp('Filter by app context'),
          owner: this.stringProp('Filter by owner'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.listSavedSearches(args.app, args.owner);
      },
    });

    this.registerTool({
      name: 'run_saved_search',
      description: 'Execute a saved search by name.',
      inputSchema: {
        type: 'object',
        properties: {
          name: this.stringProp('Name of the saved search', { required: true }),
          earliest_time: this.stringProp('Override earliest time'),
          latest_time: this.stringProp('Override latest time'),
          trigger_actions: this.booleanProp('Whether to trigger alert actions (default: false)'),
        },
        required: ['name'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.runSavedSearch(args.name, {
          earliest_time: args.earliest_time,
          latest_time: args.latest_time,
          trigger_actions: args.trigger_actions || false,
        });
      },
    });

    this.registerTool({
      name: 'list_alerts',
      description: 'List recent triggered alerts.',
      inputSchema: {
        type: 'object',
        properties: {
          earliest_time: this.stringProp('Start time for alert list (default: -24h)'),
          severity: this.enumProp('Filter by severity', ['low', 'medium', 'high', 'critical']),
          max_results: this.numberProp('Maximum alerts to return (default: 50)'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.listAlerts({
          earliest_time: args.earliest_time || '-24h',
          severity: args.severity,
          max_results: args.max_results || 50,
        });
      },
    });

    this.registerTool({
      name: 'get_alert_details',
      description: 'Get detailed information about a specific triggered alert.',
      inputSchema: {
        type: 'object',
        properties: {
          alert_id: this.stringProp('Alert ID or name', { required: true }),
        },
        required: ['alert_id'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getAlertDetails(args.alert_id);
      },
    });

    // =====================
    // SYSTEM INFORMATION
    // =====================

    this.registerTool({
      name: 'get_server_info',
      description: 'Get Splunk server information including version, build, and license info.',
      inputSchema: { type: 'object', properties: {} },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getServerInfo();
      },
    });

    this.registerTool({
      name: 'check_health',
      description: 'Check Splunk system health and status.',
      inputSchema: {
        type: 'object',
        properties: {
          component: this.enumProp('Specific component to check', ['indexer', 'search_head', 'forwarder', 'all'], { default: 'all' }),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.checkHealth(args.component || 'all');
      },
    });

    this.log(`Registered ${this.tools.length} Splunk tools`);
  }
}

module.exports = SplunkProvider;
