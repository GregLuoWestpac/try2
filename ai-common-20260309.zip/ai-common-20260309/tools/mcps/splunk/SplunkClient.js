/**
 * Splunk Client
 * 
 * HTTP client for interacting with the Splunk REST API.
 * Handles authentication, session management, and API calls.
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

// Try to load js-yaml, but handle gracefully if not installed
let yaml;
try {
  yaml = require('js-yaml');
} catch (e) {
  yaml = null;
}

class SplunkClient {
  constructor(options = {}) {
    this.verbose = options.verbose || false;
    this.host = null;
    this.port = 8089;
    this.protocol = 'https';
    this.verifySsl = true;
    this.sessionKey = null;
    this.bearerToken = null;
    this.csrfToken = null;  // CSRF token for Splunk Cloud
    this.cookies = {};  // Store cookies for web session auth
    this.keepAliveInterval = null;
    this.keepAliveEnabled = false;
    this.isSplunkCloud = false;  // Detect Splunk Cloud vs Enterprise
    this.ssoConfig = {};  // SSO configuration (email, headless, timeout)
    this.tokenObtainedAt = null;  // When session tokens were obtained
    
    this.log = this.verbose
      ? (...args) => console.error('[SplunkClient]', ...args)
      : () => {};
  }

  /**
   * Load configuration from .splunk_mcp.local.yaml file
   */
  loadConfig(configPath = null) {
    if (!yaml) {
      this.log('js-yaml not installed, cannot load YAML config');
      return null;
    }

    // Search for config file in multiple locations
    const searchPaths = configPath ? [configPath] : [
      path.join(process.cwd(), '.splunk_mcp.local.yaml'),
      path.join(__dirname, '..', '..', '.splunk_mcp.local.yaml'),
      path.join(process.env.HOME || process.env.USERPROFILE || '', '.splunk_mcp.local.yaml'),
    ];

    for (const cfgPath of searchPaths) {
      try {
        if (fs.existsSync(cfgPath)) {
          const content = fs.readFileSync(cfgPath, 'utf-8');
          const config = yaml.load(content);
          this.log(`Loaded config from ${cfgPath}`);
          return config;
        }
      } catch (e) {
        this.log(`Failed to load config from ${cfgPath}: ${e.message}`);
      }
    }

    this.log('No config file found');
    return null;
  }

  /**
   * Initialize from config file
   */
  initFromConfig(configPath = null) {
    const config = this.loadConfig(configPath);
    if (!config || !config.splunk) {
      return false;
    }

    const splunk = config.splunk;
    
    // Set host
    if (splunk.host) {
      this.setHost(splunk.host, splunk.verify_ssl !== false);
    }

    // Load session tokens
    if (splunk.session) {
      if (splunk.session.session_key) {
        this.sessionKey = splunk.session.session_key;
        this.log('Loaded session key from config');
      }
      
      // Store CSRF token for Splunk Cloud
      if (splunk.session.csrf_token) {
        this.csrfToken = splunk.session.csrf_token;
        this.log('Loaded CSRF token from config');
      }
      
      // Store cookies for web session authentication
      this.cookies = {
        splunkd_8443: splunk.session.session_key,
        splunkweb_csrf_token_8443: splunk.session.csrf_token,
        LB: splunk.session.lb_cookie,
        session_id_8443: splunk.session.session_id,
      };

      // Track when tokens were obtained
      if (splunk.session.obtained_at) {
        this.tokenObtainedAt = new Date(splunk.session.obtained_at);
        this.log(`Tokens obtained at: ${this.tokenObtainedAt.toISOString()}`);
      }
    }

    // Load SSO configuration
    if (splunk.sso) {
      this.ssoConfig = {
        email: splunk.sso.email || null,
        password: splunk.sso.password || null,
        headless: splunk.sso.headless !== false,
        timeoutSeconds: splunk.sso.timeout_seconds || 120,
      };
      this.log(`SSO config loaded (email: ${this.ssoConfig.email || 'not set'})`);
    }

    // Setup keep-alive if configured
    if (config.keepalive && config.keepalive.enabled) {
      this.startKeepAlive(config.keepalive.interval_seconds || 300);
    }

    return true;
  }

  /**
   * Start session keep-alive pings
   */
  startKeepAlive(intervalSeconds = 300) {
    if (this.keepAliveInterval) {
      this.stopKeepAlive();
    }

    this.keepAliveEnabled = true;
    const intervalMs = intervalSeconds * 1000;
    
    this.log(`Starting keep-alive with ${intervalSeconds}s interval`);
    
    this.keepAliveInterval = setInterval(async () => {
      try {
        await this.ping();
        this.log('Keep-alive ping successful');
      } catch (e) {
        this.log(`Keep-alive ping failed: ${e.message}`);
      }
    }, intervalMs);

    // Don't prevent process exit
    if (this.keepAliveInterval.unref) {
      this.keepAliveInterval.unref();
    }
  }

  /**
   * Stop session keep-alive pings
   */
  stopKeepAlive() {
    if (this.keepAliveInterval) {
      clearInterval(this.keepAliveInterval);
      this.keepAliveInterval = null;
      this.keepAliveEnabled = false;
      this.log('Keep-alive stopped');
    }
  }

  /**
   * Ping the server to keep session alive
   */
  async ping() {
    // Use a lightweight endpoint to verify session
    const response = await this.request('GET', '/services/server/info', {
      output_mode: 'json',
    });
    return { status: 'alive', serverName: response.entry?.[0]?.content?.serverName };
  }

  /**
   * Set the Splunk host
   */
  setHost(hostUrl, verifySsl = true) {
    const url = new URL(hostUrl);
    this.host = url.hostname;
    this.isSplunkCloud = this.host.includes('splunkcloud.com');
    // Splunk Cloud uses port 443, on-prem Splunk uses 8089 by default
    const defaultPort = this.isSplunkCloud ? 443 : 8089;
    this.port = url.port || defaultPort;
    this.protocol = url.protocol.replace(':', '');
    this.verifySsl = verifySsl;
    this.log(`Host set to ${this.protocol}://${this.host}:${this.port} (Splunk Cloud: ${this.isSplunkCloud})`);
  }

  /**
   * Authenticate with username/password
   */
  async authenticate(username, password) {
    this.log('Authenticating with username/password');
    
    const response = await this.request('POST', '/services/auth/login', {
      username,
      password,
      output_mode: 'json',
    });

    if (response.sessionKey) {
      this.sessionKey = response.sessionKey;
      this.log('Authentication successful');
      return { sessionKey: '***' };
    }

    throw new Error('Authentication failed: No session key returned');
  }

  /**
   * Authenticate with bearer token
   */
  async authenticateWithToken(token) {
    this.bearerToken = token;
    this.log('Set bearer token for authentication');
    
    // Verify token by getting server info
    try {
      await this.getServerInfo();
      this.log('Token authentication verified');
      return { status: 'authenticated' };
    } catch (error) {
      this.bearerToken = null;
      throw new Error('Token authentication failed: ' + error.message);
    }
  }

  /**
   * Update session tokens and optionally save to config file
   */
  updateTokens(tokens, saveToConfig = true) {
    if (tokens.session_key) {
      this.sessionKey = tokens.session_key;
      this.cookies.splunkd_8443 = tokens.session_key;
    }
    if (tokens.csrf_token) {
      this.csrfToken = tokens.csrf_token;
      this.cookies.splunkweb_csrf_token_8443 = tokens.csrf_token;
    }
    if (tokens.lb_cookie) {
      this.cookies.LB = tokens.lb_cookie;
    }
    if (tokens.session_id) {
      this.cookies.session_id_8443 = tokens.session_id;
    }

    this.tokenObtainedAt = new Date();
    this.log('Tokens updated in memory');

    if (saveToConfig) {
      this.saveTokensToConfig(tokens);
    }

    return { status: 'tokens_updated', authenticated: this.isAuthenticated() };
  }

  /**
   * Save tokens to the config file
   */
  saveTokensToConfig(tokens) {
    if (!yaml) {
      this.log('js-yaml not installed, cannot save config');
      return false;
    }

    // Find existing config file
    const searchPaths = [
      path.join(process.cwd(), '.splunk_mcp.local.yaml'),
      path.join(__dirname, '..', '..', '.splunk_mcp.local.yaml'),
      path.join(process.env.HOME || process.env.USERPROFILE || '', '.splunk_mcp.local.yaml'),
    ];

    let configPath = null;
    let config = null;

    for (const cfgPath of searchPaths) {
      try {
        if (fs.existsSync(cfgPath)) {
          const content = fs.readFileSync(cfgPath, 'utf-8');
          config = yaml.load(content);
          configPath = cfgPath;
          break;
        }
      } catch (e) {
        this.log(`Failed to read config from ${cfgPath}: ${e.message}`);
      }
    }

    if (!configPath || !config) {
      this.log('No config file found to update');
      return false;
    }

    // Update session tokens
    if (!config.splunk) config.splunk = {};
    if (!config.splunk.session) config.splunk.session = {};

    if (tokens.session_key) config.splunk.session.session_key = tokens.session_key;
    if (tokens.csrf_token) config.splunk.session.csrf_token = tokens.csrf_token;
    if (tokens.lb_cookie) config.splunk.session.lb_cookie = tokens.lb_cookie;
    if (tokens.session_id) config.splunk.session.session_id = tokens.session_id;
    config.splunk.session.obtained_at = new Date().toISOString();

    try {
      const yamlContent = yaml.dump(config, { lineWidth: -1 });
      fs.writeFileSync(configPath, yamlContent, 'utf-8');
      this.log(`Tokens saved to ${configPath}`);
      return true;
    } catch (e) {
      this.log(`Failed to save config: ${e.message}`);
      return false;
    }
  }

  /**
   * Logout and clear session
   */
  async logout() {
    this.stopKeepAlive();
    this.sessionKey = null;
    this.bearerToken = null;
    this.cookies = {};
    this.log('Logged out');
  }

  /**
   * Check if authenticated
   */
  isAuthenticated() {
    return !!(this.sessionKey || this.bearerToken);
  }

  /**
   * Check if the current session token is expired by making a lightweight request.
   * @returns {boolean} true if expired or not authenticated
   */
  async isTokenExpired() {
    if (!this.isAuthenticated()) return true;

    try {
      await this.request('GET', '/services/server/info', { output_mode: 'json' });
      return false;
    } catch (e) {
      this.log(`Token check failed: ${e.message}`);
      return true;
    }
  }

  /**
   * Get the SSO configuration
   */
  getSsoConfig() {
    return {
      email: this.ssoConfig.email || process.env.SPLUNK_SSO_EMAIL || null,
      password: this.ssoConfig.password || process.env.SPLUNK_SSO_PASSWORD || null,
      headless: this.ssoConfig.headless !== false,
      timeoutSeconds: this.ssoConfig.timeoutSeconds || 120,
      splunkUrl: `${this.protocol}://${this.host}${this.port ? ':' + this.port : ''}`,
    };
  }

  /**
   * Execute a search
   */
  async search(options) {
    const { query, earliest_time, latest_time, max_results, exec_mode } = options;

    const params = {
      search: query.startsWith('search ') ? query : `search ${query}`,
      earliest_time,
      latest_time,
      max_count: max_results,
      exec_mode: exec_mode || 'blocking',
      output_mode: 'json',
    };

    const response = await this.request('POST', '/services/search/jobs', params);

    // For blocking mode, get results immediately
    if (exec_mode === 'blocking' || exec_mode === 'oneshot') {
      const sid = response.sid;
      return await this.getSearchResults(sid, { count: max_results });
    }

    return { sid: response.sid, status: 'created' };
  }

  /**
   * Execute a one-shot search (blocking, returns results directly)
   */
  async searchOneshot(options) {
    const { query, earliest_time, latest_time, max_results } = options;

    const params = {
      search: query.startsWith('search ') ? query : `search ${query}`,
      earliest_time: earliest_time || '-1h',
      latest_time: latest_time || 'now',
      max_count: max_results || 1000,
      output_mode: 'json',
    };

    // Use the export endpoint for one-shot searches
    const response = await this.request('POST', '/services/search/jobs/export', params);
    return this.parseSearchResults(response);
  }

  /**
   * Get search job status
   */
  async getSearchStatus(sid) {
    const response = await this.request('GET', `/services/search/jobs/${sid}`, {
      output_mode: 'json',
    });

    const job = response.entry?.[0]?.content || {};
    return {
      sid,
      status: job.dispatchState,
      isDone: job.isDone,
      isFailed: job.isFailed,
      resultCount: job.resultCount,
      eventCount: job.eventCount,
      doneProgress: job.doneProgress,
      runDuration: job.runDuration,
    };
  }

  /**
   * Get search results
   */
  async getSearchResults(sid, options = {}) {
    const { offset = 0, count = 100, output_mode = 'json' } = options;

    const response = await this.request('GET', `/services/search/jobs/${sid}/results`, {
      offset,
      count,
      output_mode,
    });

    return this.parseSearchResults(response);
  }

  /**
   * Cancel a search job
   */
  async cancelSearch(sid) {
    await this.request('POST', `/services/search/jobs/${sid}/control`, {
      action: 'cancel',
      output_mode: 'json',
    });
    return { sid, status: 'cancelled' };
  }

  /**
   * Export search results
   */
  async searchExport(options) {
    const { query, earliest_time, latest_time, output_mode } = options;

    const params = {
      search: query.startsWith('search ') ? query : `search ${query}`,
      earliest_time: earliest_time || '-24h',
      latest_time: latest_time || 'now',
      output_mode: output_mode || 'json',
    };

    return await this.request('POST', '/services/search/jobs/export', params);
  }

  /**
   * List indexes
   */
  async listIndexes(filter) {
    const response = await this.request('GET', '/services/data/indexes', {
      output_mode: 'json',
      count: 0, // Get all
    });

    let indexes = (response.entry || []).map(entry => ({
      name: entry.name,
      totalEventCount: entry.content?.totalEventCount,
      currentDBSizeMB: entry.content?.currentDBSizeMB,
      maxDataSizeMB: entry.content?.maxDataSizeMB,
      disabled: entry.content?.disabled,
    }));

    if (filter) {
      const regex = new RegExp(filter, 'i');
      indexes = indexes.filter(idx => regex.test(idx.name));
    }

    return { indexes };
  }

  /**
   * Get index info
   */
  async getIndexInfo(indexName) {
    const response = await this.request('GET', `/services/data/indexes/${indexName}`, {
      output_mode: 'json',
    });

    const entry = response.entry?.[0];
    if (!entry) {
      throw new Error(`Index not found: ${indexName}`);
    }

    return {
      name: entry.name,
      ...entry.content,
    };
  }

  /**
   * List sourcetypes
   */
  async listSourcetypes(index, earliest_time) {
    let query = 'search ';
    if (index) {
      query += `index=${index} `;
    } else {
      query += 'index=* ';
    }
    query += '| stats count by sourcetype | sort -count';

    return await this.searchOneshot({
      query,
      earliest_time: earliest_time || '-24h',
      latest_time: 'now',
    });
  }

  /**
   * List saved searches
   */
  async listSavedSearches(app, owner) {
    const params = {
      output_mode: 'json',
      count: 0,
    };

    let path = '/services/saved/searches';
    if (app) {
      path = `/servicesNS/${owner || '-'}/${app}/saved/searches`;
    }

    const response = await this.request('GET', path, params);

    return {
      savedSearches: (response.entry || []).map(entry => ({
        name: entry.name,
        description: entry.content?.description,
        search: entry.content?.search,
        isScheduled: entry.content?.is_scheduled,
        nextScheduledTime: entry.content?.next_scheduled_time,
      })),
    };
  }

  /**
   * Run a saved search
   */
  async runSavedSearch(name, options = {}) {
    const params = {
      output_mode: 'json',
      'dispatch.now': true,
    };

    if (options.earliest_time) {
      params['dispatch.earliest_time'] = options.earliest_time;
    }
    if (options.latest_time) {
      params['dispatch.latest_time'] = options.latest_time;
    }
    if (options.trigger_actions) {
      params.trigger_actions = 1;
    }

    const response = await this.request('POST', `/services/saved/searches/${encodeURIComponent(name)}/dispatch`, params);

    const sid = response.sid;
    if (sid) {
      // Wait for completion and get results
      return await this.waitForSearchAndGetResults(sid);
    }

    return response;
  }

  /**
   * Wait for search to complete and get results
   */
  async waitForSearchAndGetResults(sid, timeout = 60000) {
    const startTime = Date.now();

    while (Date.now() - startTime < timeout) {
      const status = await this.getSearchStatus(sid);
      
      if (status.isDone) {
        return await this.getSearchResults(sid);
      }

      if (status.isFailed) {
        throw new Error(`Search failed: ${sid}`);
      }

      // Wait before checking again
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    throw new Error(`Search timed out: ${sid}`);
  }

  /**
   * List alerts
   */
  async listAlerts(options = {}) {
    const response = await this.request('GET', '/services/alerts/fired_alerts', {
      output_mode: 'json',
      count: options.max_results || 50,
    });

    return {
      alerts: (response.entry || []).map(entry => ({
        name: entry.name,
        triggeredTime: entry.content?.trigger_time,
        severity: entry.content?.severity,
        resultCount: entry.content?.triggered_alert_count,
      })),
    };
  }

  /**
   * Get alert details
   */
  async getAlertDetails(alertId) {
    const response = await this.request('GET', `/services/alerts/fired_alerts/${encodeURIComponent(alertId)}`, {
      output_mode: 'json',
    });

    const entry = response.entry?.[0];
    if (!entry) {
      throw new Error(`Alert not found: ${alertId}`);
    }

    return {
      name: entry.name,
      ...entry.content,
    };
  }

  /**
   * Get server info
   */
  async getServerInfo() {
    const response = await this.request('GET', '/services/server/info', {
      output_mode: 'json',
    });

    const info = response.entry?.[0]?.content || {};
    return {
      serverName: info.serverName,
      version: info.version,
      build: info.build,
      os: info.os_name,
      cpuArch: info.cpu_arch,
      licenseState: info.licenseState,
      isFree: info.isFree,
      isTrial: info.isTrial,
    };
  }

  /**
   * Check system health
   */
  async checkHealth(component = 'all') {
    const response = await this.request('GET', '/services/server/health/splunkd/details', {
      output_mode: 'json',
    });

    const health = response.entry?.[0]?.content || {};
    return {
      overallHealth: health.health,
      features: health.features,
    };
  }

  /**
   * Parse search results into a clean format
   */
  parseSearchResults(response) {
    if (typeof response === 'string') {
      // Handle newline-delimited JSON (export format)
      const lines = response.trim().split('\n').filter(Boolean);
      const results = [];
      
      for (const line of lines) {
        try {
          const parsed = JSON.parse(line);
          if (parsed.result) {
            results.push(parsed.result);
          }
        } catch (e) {
          // Skip unparseable lines
        }
      }
      
      return { results, resultCount: results.length };
    }

    if (response.results) {
      return { results: response.results, resultCount: response.results.length };
    }

    return response;
  }

  /**
   * Build URL path for Splunk API
   * Splunk Cloud requires /en-US/splunkd/__raw prefix
   * @private
   */
  _buildPath(apiPath) {
    if (this.isSplunkCloud) {
      return `/en-US/splunkd/__raw${apiPath}`;
    }
    return apiPath;
  }

  /**
   * Build authentication headers
   * Splunk Cloud uses cookies + CSRF, Enterprise uses Bearer/Splunk token
   * @private
   */
  _buildAuthHeaders() {
    if (this.isSplunkCloud && this.csrfToken && this.sessionKey) {
      return {
        'Cookie': `splunkd_8443=${this.sessionKey}; splunkweb_csrf_token_8443=${this.csrfToken}`,
        'X-Splunk-Form-Key': this.csrfToken,
        'X-Requested-With': 'XMLHttpRequest'
      };
    }
    
    if (this.bearerToken) {
      return { 'Authorization': `Bearer ${this.bearerToken}` };
    }
    
    if (this.sessionKey) {
      return { 'Authorization': `Splunk ${this.sessionKey}` };
    }
    
    return {};
  }

  /**
   * Make HTTP request to Splunk API
   */
  async request(method, path, params = {}) {
    return new Promise((resolve, reject) => {
      const isPost = method === 'POST';
      let body = '';
      let queryString = '';

      if (isPost) {
        body = new URLSearchParams(params).toString();
      } else {
        queryString = new URLSearchParams(params).toString();
        if (queryString) {
          path += '?' + queryString;
        }
      }

      // Apply Splunk Cloud path prefix
      const fullPath = this._buildPath(path);

      // Build auth headers based on auth type
      const authHeaders = this._buildAuthHeaders();

      const options = {
        hostname: this.host,
        port: this.port,
        path: fullPath,
        method,
        headers: {
          'Accept': 'application/json',
          ...authHeaders,
        },
        rejectUnauthorized: this.verifySsl,
      };

      if (isPost) {
        options.headers['Content-Type'] = 'application/x-www-form-urlencoded';
        options.headers['Content-Length'] = Buffer.byteLength(body);
      }

      this.log(`${method} ${fullPath}`);

      const protocol = this.protocol === 'https' ? https : http;
      
      const req = protocol.request(options, (res) => {
        let data = '';
        
        res.on('data', chunk => {
          data += chunk;
        });

        res.on('end', () => {
          this.log(`Response: ${res.statusCode} (${data.length} bytes)`);

          if (res.statusCode >= 400) {
            let errorMessage = `HTTP ${res.statusCode}`;
            try {
              const parsed = JSON.parse(data);
              errorMessage = parsed.messages?.[0]?.text || parsed.error || errorMessage;
            } catch (e) {
              errorMessage = data.substring(0, 200) || errorMessage;
            }

            // Detect expired/invalid session for SSO re-auth
            if (res.statusCode === 401 || res.statusCode === 303) {
              const err = new Error(errorMessage);
              err.statusCode = res.statusCode;
              err.isAuthError = true;
              reject(err);
              return;
            }

            reject(new Error(errorMessage));
            return;
          }

          // Try to parse JSON
          try {
            const parsed = JSON.parse(data);
            resolve(parsed);
          } catch (e) {
            // Return raw data if not JSON
            resolve(data);
          }
        });
      });

      req.on('error', (error) => {
        const errorMsg = error.message || error.code || error.toString();
        this.log('Request error:', errorMsg);
        reject(new Error(errorMsg));
      });

      if (isPost && body) {
        req.write(body);
      }

      req.end();
    });
  }
}

module.exports = SplunkClient;
