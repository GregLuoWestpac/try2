# Splunk MCP Provider

A stateful MCP provider for interacting with Splunk Enterprise and Splunk Cloud.

## Features

- **Session Management** - Maintain authenticated sessions with Splunk
- **SSO Login** - Automated Microsoft Entra ID SSO with MFA support
- **Search** - Execute SPL queries and get results
- **Monitoring** - Check indexes, sourcetypes, and system health
- **Debugging** - Analyze logs, errors, and performance issues
- **Saved Searches** - Manage and execute saved searches
- **Alerts** - View and manage alerts

## Quick Start

```bash
# Start the MCP server
node tools/nodemcp/cli.js --layers splunk

# Or with multiple providers
node tools/nodemcp/cli.js --layers splunk,jira
```

**MCP client configuration (e.g., VS Code `settings.json`):**

```json
{
  "command": "node",
  "args": ["path/to/ai-common/tools/nodemcp/cli.js", "--layers", "splunk"]
}
```

## Configuration

The provider supports multiple configuration methods. Settings are resolved with the following priority (highest wins):

1. **Tool parameters** (passed directly to each tool call)
2. **Environment variables**
3. **Config file** (`.splunk_mcp.local.yaml`)

### Environment Variables

| Variable | Description | Required |
|---|---|---|
| `SPLUNK_HOST` | Splunk host URL (e.g., `https://instance.splunkcloud.com`) | Yes (or config file) |
| `SPLUNK_TOKEN` | Bearer token for authentication | No |
| `SPLUNK_USERNAME` | Username for native Splunk auth | No |
| `SPLUNK_PASSWORD` | Password for native Splunk auth | No |
| `SPLUNK_SSO_EMAIL` | SSO email for Microsoft Entra ID login | No |
| `SPLUNK_SSO_PASSWORD` | SSO password (held in memory only) | No |

```bash
# Minimal setup with SSO
export SPLUNK_HOST=https://your-instance.splunkcloud.com
export SPLUNK_SSO_EMAIL=user@company.com
export SPLUNK_SSO_PASSWORD=your-password

# Or with a bearer token (no SSO needed)
export SPLUNK_HOST=https://your-splunk:8089
export SPLUNK_TOKEN=your-bearer-token

# Or with native Splunk credentials
export SPLUNK_HOST=https://your-splunk:8089
export SPLUNK_USERNAME=admin
export SPLUNK_PASSWORD=changeme
```

### Config File (`.splunk_mcp.local.yaml`)

The provider searches for this file in the following locations (first match wins):

1. Current working directory
2. Project root (two levels up from `tools/mcps/splunk/`)
3. Home directory (`$HOME` / `$USERPROFILE`)

```yaml
splunk:
  host: https://your-instance.splunkcloud.com
  verify_ssl: false                    # Skip SSL verification (default: true)
  sso:
    email: user@company.com            # SSO email for automated login
    password: your-password            # SSO password (optional — will prompt if not set)
    headless: true                     # Hide browser during login (default: true)
    timeout_seconds: 120               # Max time to wait for MFA approval (default: 120)
  session:                             # Auto-populated after successful SSO login
    session_key: <auto-populated>      # splunkd_8443 cookie
    csrf_token: <auto-populated>       # splunkweb_csrf_token_8443 cookie
    lb_cookie: <auto-populated>        # Load balancer cookie
    session_id: <auto-populated>       # session_id_8443 cookie
    obtained_at: <auto-populated>      # ISO 8601 timestamp of last token refresh
keepalive:
  enabled: true                        # Enable periodic keep-alive pings (default: false)
  interval_seconds: 300                # Ping interval in seconds (default: 300)
```

> **Note:** The `session` block is managed automatically — tokens are saved after each successful SSO login and reused on subsequent sessions. You should not need to edit these values manually.

## Authentication

The provider supports four authentication methods:

### 1. SSO (Microsoft Entra ID) — Recommended for Splunk Cloud

Automated browser-driven SAML SSO with MFA support. Uses `puppeteer-core` to drive a headless Edge or Chrome browser.

**Password resolution chain** (first match wins):
1. Tool parameter (`password` argument to `sso_login`)
2. Environment variable (`SPLUNK_SSO_PASSWORD`)
3. Config file (`splunk.sso.password`)
4. MCP client elicitation (interactive prompt if supported by client)
5. Console stdin prompt (prompts in the MCP server terminal)

```
# Trigger SSO login — password resolved automatically from config/env
splunk_sso_login

# Or provide credentials explicitly
splunk_sso_login email="user@company.com" password="secret"
```

### 2. Bearer Token

For Splunk instances with API token support.

```
splunk_authenticate token="your-bearer-token"
```

Or set `SPLUNK_TOKEN` environment variable.

### 3. Username/Password (Native)

For Splunk Enterprise with native authentication.

```
splunk_authenticate username="admin" password="changeme"
```

Or set `SPLUNK_USERNAME` and `SPLUNK_PASSWORD` environment variables.

### 4. Manual Token Update

If you have session cookies from your browser, you can paste them directly:

```
splunk_update_tokens session_key="..." csrf_token="..."
```

### Splunk Cloud vs Enterprise

The provider auto-detects the deployment type by hostname:
- **Splunk Cloud** (`*.splunkcloud.com`): Uses cookie-based auth with CSRF tokens, path prefix `/en-US/splunkd/__raw`
- **Splunk Enterprise**: Uses `Authorization: Splunk <sessionKey>` or `Bearer <token>` headers

## SSO Login Flow

For Splunk Cloud instances with Microsoft Entra ID (Azure AD) SSO:

1. **Auto-detection**: `start_session` checks if stored tokens are expired and automatically triggers SSO
2. **Explicit login**: Use `sso_login` to manually trigger the SSO flow at any time
3. **Browser automation**: A headless Edge/Chrome browser drives the SAML flow:
   - Navigates to Splunk Cloud → redirected to Microsoft login
   - Enters email and password automatically
   - Handles MFA: displays the number-matching code via MCP elicitation or in the server console
   - Extracts session cookies after successful authentication
4. **Token persistence**: Tokens are saved to `.splunk_mcp.local.yaml` and keep-alive is restarted

### MFA Support

- **Number matching** (Authenticator push): The 2-digit number is displayed via MCP elicitation and printed to the MCP server console (stderr). Approve on your phone.
- **TOTP/SMS code**: You're prompted to enter the verification code via MCP elicitation or tool parameter (`mfa_code`)
- **No MFA**: If MFA is not required, the flow completes automatically

### Browser Requirements

The SSO flow requires Edge or Chrome to be installed. The provider auto-detects the browser path:
- **Windows**: `msedge.exe` → `chrome.exe` (checks `%LOCALAPPDATA%`, `Program Files`, `Program Files (x86)`)
- **macOS**: `/Applications/Microsoft Edge.app` → `/Applications/Google Chrome.app`
- **Linux**: `/usr/bin/microsoft-edge` → `/usr/bin/google-chrome`

### Troubleshooting SSO

- Set `headless: false` in config (or pass `headless=false` to `sso_login`) to watch the browser during login
- Ensure Edge or Chrome is installed — the provider auto-detects the browser path
- If MCP elicitation is not supported by your client, the MFA number is printed to the MCP server console (stderr)
- Check the MCP server console output for diagnostic messages

### Keep-Alive

To prevent session tokens from expiring during long idle periods, enable keep-alive:

```yaml
# In .splunk_mcp.local.yaml
keepalive:
  enabled: true
  interval_seconds: 300   # Ping every 5 minutes
```

Or manage it at runtime:
```
splunk_session_keepalive action="start"
splunk_session_keepalive action="status"
splunk_session_keepalive action="stop"
```

Keep-alive calls `GET /services/server/info` periodically to refresh the session.

## Available Tools

### Session Management
- `start_session` - Start a new Splunk session (auto-triggers SSO if tokens expired)
- `reset_session` - Reset/clear current session
- `authenticate` - Authenticate with Splunk native credentials or bearer token
- `sso_login` - Authenticate via Microsoft SSO (browser-automated SAML + MFA)
- `update_tokens` - Manually update session tokens (fallback if SSO is unavailable)
- `session_keepalive` - Manage session keep-alive pings

### Search Operations
- `search` - Execute a Splunk search query (async or blocking)
- `search_oneshot` - Execute a one-shot search (blocking, best for quick queries)
- `search_export` - Export large search results (streaming)
- `get_search_status` - Check status of an async search job
- `get_search_results` - Get results from a completed search
- `cancel_search` - Cancel a running search

### Index & Data Operations  
- `list_indexes` - List all available indexes with stats
- `get_index_info` - Get detailed info about an index
- `list_sourcetypes` - List sourcetypes in an index
- `get_earliest_time` - Get earliest event time in index
- `get_latest_time` - Get latest event time in index
- `get_event_count` - Get event count for a time range

### Debugging & Diagnostics
- `find_errors` - Search for errors in logs
- `find_exceptions` - Search for exceptions/stack traces
- `analyze_latency` - Analyze response time/latency
- `trace_transaction` - Trace a transaction by ID across sources
- `correlate_events` - Correlate events across sources in a time window
- `get_field_summary` - Get summary statistics for a field

### Saved Searches & Alerts
- `list_saved_searches` - List saved searches/reports
- `run_saved_search` - Execute a saved search by name
- `list_alerts` - List triggered alerts
- `get_alert_details` - Get details of a specific alert

### System Information
- `get_server_info` - Get Splunk server version, build, and license info
- `check_health` - Check Splunk system health and status

## Usage Examples

```
# Start a session (auto-authenticates via SSO if tokens expired)
splunk_start_session

# Explicitly trigger SSO login (password from config/env)
splunk_sso_login

# SSO login with visible browser for debugging
splunk_sso_login headless=false

# SSO login with explicit credentials
splunk_sso_login email="user@company.com" password="secret"

# Authenticate with native credentials (non-SSO Splunk)
splunk_authenticate username="admin" password="changeme"

# Search for errors in the last hour
splunk_find_errors index="main" earliest_time="-1h" severity="ERROR"

# Execute a custom SPL query
splunk_search query="index=web status>=500 | stats count by host"

# One-shot search (blocking, returns results immediately)
splunk_search_oneshot query="index=main | head 10" earliest_time="-15m"

# Trace a specific transaction
splunk_trace_transaction transaction_id="abc-123" index="transactions"

# Check system health
splunk_check_health
```
