/**
 * Splunk SSO Authentication Flow
 * 
 * Drives a headless Edge/Chrome browser through the Splunk Cloud SAML SSO flow:
 * Splunk login → Microsoft Entra ID → MFA → session cookie extraction.
 * 
 * Uses puppeteer-core to automate the browser and MCP context elicitation
 * to communicate MFA challenges back to the user.
 */

const puppeteer = require('puppeteer-core');
const path = require('path');
const fs = require('fs');
const os = require('os');

// Microsoft login page selectors (primary + fallback for resilience)
const SELECTORS = {
  // Email entry page
  emailInput: 'input[name="loginfmt"]',
  emailInputFallback: 'input[type="email"][name="loginfmt"]',
  emailNextButton: 'input[type="submit"][value="Next"]',
  emailNextButtonFallback: '#idSIButton9',

  // Password entry page
  passwordInput: 'input[type="password"][name="passwd"]',
  passwordInputFallback: 'input[name="passwd"]',
  passwordSubmitButton: 'input[type="submit"][value="Sign in"]',
  passwordSubmitButtonFallback: '#idSIButton9',

  // MFA - number matching
  mfaDisplayNumber: '#idRichContext_DisplaySign',
  mfaDisplayNumberFallback: '#displaySign',

  // MFA - code entry (TOTP / SMS)
  mfaCodeInput: 'input[name="otc"]',
  mfaCodeInputFallback: '#idTxtBx_SAOTCC_OTC',
  mfaCodeSubmit: 'input[type="submit"][value="Verify"]',
  mfaCodeSubmitFallback: '#idSubmit_SAOTCC_Continue',

  // "Stay signed in?" interstitial
  staySignedInYes: 'input[type="submit"][value="Yes"]',
  staySignedInYesFallback: '#idSIButton9',
  staySignedInNo: 'input[type="button"][value="No"]',
  kmsiPage: '#KmsiDescription',

  // Error messages
  usernameError: '#usernameError',
  passwordError: '#passwordError',
  loginError: '#error',
};

// Splunk session cookie names
const SPLUNK_COOKIES = {
  sessionKey: 'splunkd_8443',
  csrfToken: 'splunkweb_csrf_token_8443',
  lbCookie: 'LB',
  sessionId: 'session_id_8443',
};

class SplunkAuthFlow {
  constructor(options = {}) {
    this.splunkUrl = options.splunkUrl;
    this.headless = options.headless !== false; // default true
    this.timeoutMs = (options.timeoutSeconds || 120) * 1000;
    this.verbose = options.verbose || false;
    this.browser = null;
    this.page = null;

    this.log = this.verbose
      ? (...args) => console.error('[SplunkAuthFlow]', ...args)
      : () => {};

    this.executablePath = options.executablePath || this._findBrowser();
  }

  /**
   * Try to find an element using primary selector, falling back to fallback selector
   * @param {string} primary - Primary CSS selector
   * @param {string} [fallback] - Fallback CSS selector
   * @param {Object} [opts] - waitForSelector options
   * @returns {ElementHandle|null}
   */
  async _findElement(primary, fallback, opts = {}) {
    const timeout = opts.timeout || 5000;
    try {
      await this.page.waitForSelector(primary, { ...opts, timeout });
      return await this.page.$(primary);
    } catch (e) {
      if (fallback) {
        try {
          await this.page.waitForSelector(fallback, { ...opts, timeout: 3000 });
          this.log(`Used fallback selector: ${fallback}`);
          return await this.page.$(fallback);
        } catch (e2) { /* both failed */ }
      }
      return null;
    }
  }

  /**
   * Find Edge or Chrome executable
   */
  _findBrowser() {
    const edgePaths = process.platform === 'win32' ? [
      path.join(process.env.LOCALAPPDATA || '', 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
      'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
      'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    ] : process.platform === 'darwin' ? [
      '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
    ] : [
      '/usr/bin/microsoft-edge',
      '/usr/bin/microsoft-edge-stable',
    ];

    const chromePaths = process.platform === 'win32' ? [
      path.join(process.env.LOCALAPPDATA || '', 'Google', 'Chrome', 'Application', 'chrome.exe'),
      'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
      'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    ] : process.platform === 'darwin' ? [
      '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    ] : [
      '/usr/bin/google-chrome',
      '/usr/bin/google-chrome-stable',
    ];

    for (const p of [...edgePaths, ...chromePaths]) {
      try {
        if (fs.existsSync(p)) {
          this.log(`Found browser: ${p}`);
          return p;
        }
      } catch (e) { /* ignore */ }
    }

    return edgePaths[0]; // fallback — will error on launch
  }

  /**
   * Main authentication entry point.
   * Drives the full SSO flow and returns extracted session tokens.
   * 
   * @param {Object} options
   * @param {string} options.email - User's SSO email
   * @param {string} options.password - User's password (never persisted)
   * @param {Object} [options.context] - MCP Context for elicitation (optional)
   * @param {number} [options.maxRetries] - Max retry attempts on failure (default: 1)
   * @returns {Object} { session_key, csrf_token, lb_cookie, session_id }
   */
  async authenticate(options = {}) {
    const { email, password, mfaCode, context, maxRetries = 1 } = options;

    if (!email) throw new Error('SSO email is required');
    if (!password) throw new Error('SSO password is required');
    if (!this.splunkUrl) throw new Error('Splunk URL is required');

    let lastError = null;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        if (attempt > 0) {
          this.log(`Retry attempt ${attempt}/${maxRetries}`);
          if (context) {
            try { await context.info(`SSO login retry attempt ${attempt}...`); } catch (e) { /* ignore */ }
          }
        }

        await this._launchBrowser();
        const loginState = await this._navigateToLogin();
        
        if (loginState === 'already_authenticated') {
          // SSO auto-completed (Windows integrated auth / cached credentials)
          this.log('SSO auto-completed, extracting cookies directly');
          await this._waitForSplunkSession(context);
          const tokens = await this._extractCookies();
          return tokens;
        }

        // Full login flow required
        await this._enterEmail(email);
        await this._enterPassword(password, context);
        await this._handleMFA(context, mfaCode);
        await this._handleStaySignedIn();
        await this._waitForSplunkSession(context);
        const tokens = await this._extractCookies();
        return tokens;
      } catch (e) {
        lastError = e;
        this.log(`Attempt ${attempt} failed: ${e.message}`);
      } finally {
        await this._cleanup();
      }
    }

    throw lastError;
  }

  /**
   * Launch the browser instance
   */
  async _launchBrowser() {
    this.log(`Launching browser (headless: ${this.headless})`);

    // Use a temp user data dir so we don't pollute the user's profile
    const userDataDir = path.join(os.tmpdir(), `splunk-sso-${Date.now()}`);

    this.browser = await puppeteer.launch({
      executablePath: this.executablePath,
      headless: this.headless,
      userDataDir,
      args: [
        '--no-first-run',
        '--no-default-browser-check',
        '--disable-extensions',
        '--disable-popup-blocking',
      ],
      defaultViewport: { width: 1280, height: 720 },
    });

    this.page = await this.browser.newPage();

    // Store userDataDir for cleanup
    this._userDataDir = userDataDir;
  }

  /**
   * Navigate to Splunk Cloud login, which will redirect to Microsoft SSO.
   * @returns {string} 'login_page' if Microsoft login appeared, 'already_authenticated' if redirected straight to Splunk
   */
  async _navigateToLogin() {
    this.log(`Navigating to ${this.splunkUrl}`);

    await this.page.goto(this.splunkUrl, {
      waitUntil: 'networkidle2',
      timeout: 45000,
    });

    // Wait for either Microsoft login page or Splunk dashboard
    try {
      const result = await Promise.race([
        this.page.waitForSelector(SELECTORS.emailInput, { timeout: 20000 }).then(() => 'email_page'),
        this.page.waitForSelector(SELECTORS.passwordInput, { timeout: 20000 }).then(() => 'password_page'),
        this.page.waitForFunction(
          (hostname) => window.location.hostname.includes(hostname) && window.location.pathname.includes('/app/'),
          { timeout: 20000 },
          new URL(this.splunkUrl).hostname
        ).then(() => 'splunk_dashboard'),
      ]);

      if (result === 'splunk_dashboard') {
        this.log('SSO auto-completed — already redirected to Splunk dashboard');
        return 'already_authenticated';
      }

      this.log(`Microsoft login page loaded (state: ${result})`);
      return 'login_page';
    } catch (e) {
      // Check current URL to determine state
      const url = this.page.url();
      const splunkHost = new URL(this.splunkUrl).hostname;
      if (url.includes(splunkHost) && !url.includes('login.microsoftonline.com')) {
        this.log('Appears to be authenticated — on Splunk site');
        return 'already_authenticated';
      }
      throw new Error(`Failed to reach login page or Splunk. Current URL: ${url}`);
    }
  }

  /**
   * Enter email address on Microsoft login page
   */
  async _enterEmail(email) {
    const maskedEmail = email.replace(/^[^@]+/, '***');
    this.log(`Entering email: ${maskedEmail}`);

    await this.page.waitForSelector(SELECTORS.emailInput, { visible: true, timeout: 10000 });
    await this.page.type(SELECTORS.emailInput, email, { delay: 50 });

    // Click Next (try primary, then fallback selector)
    const nextBtn = await this._findElement(
      SELECTORS.emailNextButton, SELECTORS.emailNextButtonFallback, { visible: true }
    );
    if (nextBtn) {
      await nextBtn.click();
    } else {
      // Last resort: press Enter
      await this.page.keyboard.press('Enter');
    }

    // Wait for either password page or error
    try {
      await Promise.race([
        this.page.waitForSelector(SELECTORS.passwordInput, { visible: true, timeout: 10000 }),
        this.page.waitForSelector(SELECTORS.usernameError, { visible: true, timeout: 10000 }),
      ]);
    } catch (e) {
      throw new Error('Timed out waiting for password page after email entry');
    }

    // Check for email error
    const emailError = await this.page.$(SELECTORS.usernameError);
    if (emailError) {
      const errorText = await this.page.evaluate(el => el.textContent, emailError);
      throw new Error(`Email error: ${errorText.trim()}`);
    }

    this.log('Email accepted, password page loaded');
  }

  /**
   * Enter password on Microsoft login page
   */
  async _enterPassword(password, context) {
    this.log('Entering password');

    await this.page.waitForSelector(SELECTORS.passwordInput, { visible: true, timeout: 10000 });
    await this.page.type(SELECTORS.passwordInput, password, { delay: 30 });

    // Click Sign In (try primary, then fallback selector)
    const signInBtn = await this._findElement(
      SELECTORS.passwordSubmitButton, SELECTORS.passwordSubmitButtonFallback, { visible: true }
    );
    if (signInBtn) {
      await signInBtn.click();
    } else {
      await this.page.keyboard.press('Enter');
    }

    // Wait for MFA page, "Stay signed in", error, or direct redirect
    await this._waitForPostPassword();

    // Check for password error
    const passwordError = await this.page.$(SELECTORS.passwordError);
    if (passwordError) {
      const errorText = await this.page.evaluate(el => el.textContent, passwordError);
      throw new Error(`Password error: ${errorText.trim()}`);
    }

    this.log('Password accepted');
  }

  /**
   * Wait for the page to transition after password entry
   */
  async _waitForPostPassword() {
    try {
      await Promise.race([
        // MFA number matching (primary + fallback)
        this.page.waitForSelector(SELECTORS.mfaDisplayNumber, { visible: true, timeout: 15000 }),
        this.page.waitForSelector(SELECTORS.mfaDisplayNumberFallback, { visible: true, timeout: 15000 }),
        // MFA code entry
        this.page.waitForSelector(SELECTORS.mfaCodeInput, { visible: true, timeout: 15000 }),
        // "Stay signed in?" page
        this.page.waitForSelector(SELECTORS.kmsiPage, { visible: true, timeout: 15000 }),
        // Password error
        this.page.waitForSelector(SELECTORS.passwordError, { visible: true, timeout: 15000 }),
        // Direct redirect to Splunk (no MFA)
        this.page.waitForFunction(
          () => window.location.hostname.includes('splunkcloud.com'),
          { timeout: 15000 }
        ),
      ]);
    } catch (e) {
      // Timeout is OK — we'll check the page state in the next step
      this.log('Post-password wait completed (possibly timed out)');
    }
  }

  /**
   * Handle MFA challenge.
   * Detects the MFA type and communicates with the user via MCP context.
   */
  async _handleMFA(context, mfaCode = null) {
    // Check if we're on an MFA page (try primary then fallback for number matching)
    const numberEl = await this.page.$(SELECTORS.mfaDisplayNumber) 
      || await this.page.$(SELECTORS.mfaDisplayNumberFallback);
    const codeInput = await this.page.$(SELECTORS.mfaCodeInput);

    if (numberEl) {
      await this._handleNumberMatching(numberEl, context);
    } else if (codeInput) {
      await this._handleCodeEntry(context, mfaCode);
    } else {
      this.log('No MFA challenge detected — may have been skipped or already approved');
      return;
    }
  }

  /**
   * Handle number-matching MFA (Microsoft Authenticator push with number)
   */
  async _handleNumberMatching(numberEl, context) {
    const number = await this.page.evaluate(el => el.textContent.trim(), numberEl);
    this.log(`MFA number matching — display number: ${number}`);

    const message = `🔐 Microsoft MFA: Approve the sign-in request on your Authenticator app.\n\nSelect number: **${number}**`;

    // Always log MFA number to stderr so it's visible in the MCP server console
    console.error(`\n${'='.repeat(60)}\n🔐 MFA NUMBER: ${number}\nApprove the request on your Microsoft Authenticator app.\n${'='.repeat(60)}\n`);

    // Try MCP elicitation, fall back to logging
    if (context) {
      try {
        await context.elicit({
          message,
          requestedSchema: {
            type: 'object',
            properties: {
              acknowledged: {
                type: 'boolean',
                title: 'I have approved the request on my phone',
              },
            },
          },
        });
      } catch (e) {
        // Elicitation not supported — log the number and wait
        this.log(`Elicitation failed (${e.message}), logging MFA number`);
        try { await context.info(message); } catch (e2) { /* ignore */ }
      }
    }

    // Wait for MFA to complete — page will navigate away
    this.log('Waiting for MFA approval...');
    await this._waitForMFACompletion();
  }

  /**
   * Handle code-entry MFA (TOTP or SMS)
   */
  async _handleCodeEntry(context, mfaCode = null) {
    this.log('MFA code entry required');

    // Use pre-supplied MFA code if available
    let code = mfaCode || null;

    if (!code && context) {
      try {
        const result = await context.elicit({
          message: '🔐 Microsoft MFA: Enter the verification code from your authenticator app or SMS.',
          requestedSchema: {
            type: 'object',
            properties: {
              code: {
                type: 'string',
                title: 'Verification code',
                pattern: '^[0-9]{4,8}$',
              },
            },
            required: ['code'],
          },
        });
        code = result.action === 'accept' ? result.content?.code : null;
      } catch (e) {
        this.log(`Elicitation failed: ${e.message}`);
      }
    }

    if (!code) {
      throw new Error('MFA code is required but could not be obtained. Provide it via the mfa_code parameter of the sso_login tool, or use an MCP client that supports elicitation.');
    }

    // Enter the code
    await this.page.type(SELECTORS.mfaCodeInput, code, { delay: 50 });

    // Click verify
    const verifyButton = await this.page.$(SELECTORS.mfaCodeSubmit);
    if (verifyButton) {
      await verifyButton.click();
    }

    await this._waitForMFACompletion();
  }

  /**
   * Wait for MFA to complete — either redirect away from login.microsoftonline.com
   * or arrive at "Stay signed in?" page
   */
  async _waitForMFACompletion() {
    try {
      await Promise.race([
        this.page.waitForSelector(SELECTORS.kmsiPage, { visible: true, timeout: this.timeoutMs }),
        this.page.waitForFunction(
          () => !window.location.hostname.includes('login.microsoftonline.com'),
          { timeout: this.timeoutMs }
        ),
      ]);
      this.log('MFA completed');
    } catch (e) {
      throw new Error(`MFA timed out after ${this.timeoutMs / 1000}s. Please approve the request and try again.`);
    }
  }

  /**
   * Handle "Stay signed in?" interstitial — click Yes
   */
  async _handleStaySignedIn() {
    const kmsi = await this.page.$(SELECTORS.kmsiPage);
    if (kmsi) {
      this.log('Handling "Stay signed in?" prompt — clicking Yes');
      const yesButton = await this.page.$(SELECTORS.staySignedInYes);
      if (yesButton) {
        await yesButton.click();
        // Wait for navigation after clicking
        await this.page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 }).catch(() => {});
      }
    }
  }

  /**
   * Wait for Splunk session to be established (SAML callback completed)
   */
  async _waitForSplunkSession(context) {
    this.log('Waiting for Splunk session...');

    try {
      await this.page.waitForFunction(
        (hostname) => window.location.hostname.includes(hostname),
        { timeout: 30000 },
        new URL(this.splunkUrl).hostname
      );
    } catch (e) {
      // Check if we're already there
      const url = this.page.url();
      if (!url.includes(new URL(this.splunkUrl).hostname)) {
        throw new Error(`Failed to reach Splunk after SSO. Current URL: ${url}`);
      }
    }

    // Give a moment for cookies to settle
    await new Promise(resolve => setTimeout(resolve, 2000));

    this.log(`Splunk session established. URL: ${this.page.url()}`);
  }

  /**
   * Extract session cookies from the browser
   */
  async _extractCookies() {
    this.log('Extracting session cookies');

    const cookies = await this.page.cookies();
    const cookieMap = {};
    for (const c of cookies) {
      cookieMap[c.name] = c.value;
    }

    const sessionKey = cookieMap[SPLUNK_COOKIES.sessionKey];
    const csrfToken = cookieMap[SPLUNK_COOKIES.csrfToken];
    const lbCookie = cookieMap[SPLUNK_COOKIES.lbCookie];
    const sessionId = cookieMap[SPLUNK_COOKIES.sessionId];

    if (!sessionKey) {
      this.log('Available cookies:', Object.keys(cookieMap).join(', '));
      throw new Error('Failed to extract session key cookie (splunkd_8443). Authentication may have failed.');
    }

    if (!csrfToken) {
      this.log('Warning: CSRF token not found — some operations may fail');
    }

    this.log('Cookies extracted successfully');
    return {
      session_key: sessionKey,
      csrf_token: csrfToken || null,
      lb_cookie: lbCookie || null,
      session_id: sessionId || null,
    };
  }

  /**
   * Clean up browser and temp files
   */
  async _cleanup() {
    if (this.browser) {
      try {
        await this.browser.close();
        this.log('Browser closed');
      } catch (e) {
        this.log(`Browser close error: ${e.message}`);
      }
      this.browser = null;
      this.page = null;
    }

    // Clean up temp user data dir
    if (this._userDataDir) {
      try {
        fs.rmSync(this._userDataDir, { recursive: true, force: true });
        this.log('Temp user data dir cleaned up');
      } catch (e) {
        this.log(`Cleanup warning: ${e.message}`);
      }
      this._userDataDir = null;
    }
  }
}

module.exports = SplunkAuthFlow;
