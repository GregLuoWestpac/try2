const SplunkClient = require('./SplunkClient');
const client = new SplunkClient({ verbose: true });
client.initFromConfig();

const txId = process.argv[2] || '9a71f1da-d4be-40fd-a6cd-aa6181b23af3';

(async () => {
  try {
    const query = `search index=* ("${txId}" OR transaction_id="${txId}" OR correlation_id="${txId}" OR request_id="${txId}" OR trace_id="${txId}") | sort _time | table _time, host, source, sourcetype, _raw | head 50`;
    
    console.log('Searching for:', txId);
    const result = await client.searchOneshot({
      query: query,
      earliest_time: '-7d',
      latest_time: 'now',
      max_results: 50
    });
    console.log(JSON.stringify(result, null, 2));
  } catch (e) {
    console.error('Error:', e.message);
    console.error(e.stack);
  }
})();
