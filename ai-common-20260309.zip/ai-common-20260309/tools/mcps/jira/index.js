/**
 * Jira MCP Provider
 * 
 * A stateful provider for interacting with Jira (Cloud/Server).
 * Provides tools for searching, creating, and managing issues and agile objects.
 */

const BaseProvider = require('../../nodemcp/core/BaseProvider');
const JiraClient = require('./JiraClient');
const JiraAuthFlow = require('./JiraAuthFlow');

class JiraProvider extends BaseProvider {
  constructor(options = {}) {
    super(options);
    this.setStateful(true);
    this.client = null;
  }

  async initialize() {
    this.log('Initializing Jira provider');
    this.registerAllTools();
  }

  async shutdown() {
    if (this.client) {
      await this.client.logout();
    }
  }

  getClient(context) {
    const session = context.session;
    if (!session) {
      // Cache the stateless client to avoid re-reading config on every tool call
      if (!this._statelessClient) {
        this._statelessClient = new JiraClient({ verbose: this.verbose });
        this._statelessClient.initFromConfig();
      }
      return this._statelessClient;
    }

    let client = context.sessionManager.getProviderData(session.id, 'jira', 'client');
    if (!client) {
      client = new JiraClient({ verbose: this.verbose });
      client.initFromConfig();
      context.sessionManager.setProviderData(session.id, 'jira', 'client', client);
    }
    return client;
  }

  async _promptPasswordFromConsole(email) {
    // In MCP server context, stdin is the JSON-RPC transport — reading from it corrupts the protocol.
    if (!process.stdin.isTTY) {
      throw new Error('Cannot prompt for password: stdin is not a TTY (likely an MCP transport). Use JIRA_SSO_PASSWORD env var or MCP elicitation instead.');
    }

    return new Promise((resolve, reject) => {
      const readline = require('readline');

      console.error(`\n${'='.repeat(60)}`);
      console.error(`🔐 SSO password required for ${email}`);
      console.error(`${'='.repeat(60)}`);

      const rl = readline.createInterface({ input: process.stdin, output: process.stderr, terminal: true });
      rl.stdoutMuted = true;
      rl._writeToOutput = function _writeToOutput(stringToWrite) {
        if (rl.stdoutMuted) {
          rl.output.write('*');
        } else {
          rl.output.write(stringToWrite);
        }
      };

      let done = false;
      const finish = (err, value) => {
        if (done) return;
        done = true;
        try { rl.close(); } catch (e) { /* ignore */ }
        if (err) reject(err);
        else resolve(value);
      };

      const timer = setTimeout(() => {
        clearTimeout(timer);
        finish(new Error('Password prompt timed out'));
      }, 60000);

      rl.question('Password: ', (answer) => {
        clearTimeout(timer);
        console.error();
        const trimmed = (answer || '').trim();
        if (trimmed) finish(null, trimmed);
        else finish(new Error('No password entered'));
      });
    });
  }

  /**
   * Perform SSO login flow using browser automation.
   */
  async _performSsoLogin(client, ctx, overrides = {}) {
    const ssoConfig = client.getSsoConfig();

    let email = overrides.email || ssoConfig.email;
    if (!email && ctx) {
      try {
        const result = await ctx.elicit({
          message: 'Enter your SSO email address for Jira login:',
          requestedSchema: {
            type: 'object',
            properties: { email: { type: 'string', title: 'SSO Email', format: 'email' } },
            required: ['email'],
          },
        });
        email = result.action === 'accept' ? result.content?.email : null;
      } catch (e) {
        this.log(`Email elicitation failed: ${e.message}`);
      }
    }
    if (!email) {
      return { error: 'SSO email is required. Set JIRA_SSO_EMAIL env var, add jira.sso.email to config, or provide it as a parameter.' };
    }

    if (ssoConfig.password) {
      this.log('WARNING: jira.sso.password in config is insecure; prefer JIRA_SSO_PASSWORD env var, MCP elicitation, or the console prompt.');
    }

    let password = overrides.password || process.env.JIRA_SSO_PASSWORD || ssoConfig.password;
    if (!password && ctx) {
      try {
        const result = await ctx.elicit({
          message: `Enter your password for ${email}:`,
          requestedSchema: {
            type: 'object',
            properties: { password: { type: 'string', title: 'Password' } },
            required: ['password'],
          },
        });
        password = result.action === 'accept' ? result.content?.password : null;
      } catch (e) {
        this.log(`Password elicitation failed: ${e.message}`);
      }
    }
    if (!password) {
      try {
        password = await this._promptPasswordFromConsole(email);
      } catch (e) {
        this.log(`Console password prompt failed: ${e.message}`);
      }
    }
    if (!password) {
      return { error: 'SSO password is required. Set JIRA_SSO_PASSWORD env var, provide it as a parameter, or enter it when prompted.' };
    }

    const headless = overrides.headless !== undefined ? overrides.headless : ssoConfig.headless;

    const authFlow = new JiraAuthFlow({
      jiraUrl: ssoConfig.jiraUrl,
      headless,
      timeoutSeconds: ssoConfig.timeoutSeconds,
      verbose: this.verbose,
    });

    try {
      if (ctx) {
        try { await ctx.info('Starting Jira SSO login flow...'); } catch (e) { /* ignore */ }
      }

      const tokens = await authFlow.authenticate({ email, password, mfaCode: overrides.mfaCode, context: ctx });

      const result = client.updateTokens(tokens, true);

      client.stopKeepAlive();
      client.startKeepAlive(300);

      try {
        const pingResult = await client.ping();
        result.verified = true;
        result.user = pingResult.user;
      } catch (e) {
        result.verified = false;
        result.verification_error = e.message;
      }

      result.sso_login = 'success';
      result.email = email;
      return result;
    } catch (e) {
      return { error: `SSO login failed: ${e.message}`, sso_login: 'failed' };
    }
  }

  registerAllTools() {
    // =====================
    // SESSION MANAGEMENT
    // =====================

    this.registerTool({
      name: 'start_session',
      description: 'Start a new Jira session. Call this before other Jira operations to initialize the connection.',
      inputSchema: {
        type: 'object',
        properties: {
          host: this.stringProp('Jira host URL (e.g., https://your-domain.atlassian.net). Uses JIRA_HOST env var if not provided.'),
          verify_ssl: this.booleanProp('Whether to verify SSL certificates (default: true)'),
          load_config: this.booleanProp('Load configuration from .jira_mcp.local.yaml file (default: true)'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);

        if (args.load_config !== false) {
          const configLoaded = client.initFromConfig();
          if (configLoaded && client.isAuthenticated()) {
            const expired = await client.isTokenExpired();
            if (!expired) {
              return {
                status: 'session_started',
                host: `${client.protocol}://${client.host}:${client.port}`,
                message: 'Jira session started from config file. Already authenticated.',
                keepalive: client.keepAliveEnabled ? 'enabled' : 'disabled',
              };
            }

            this.log('Tokens expired, attempting SSO re-authentication');
            if (context?.ctx) {
              try { await context.ctx.info('Session tokens expired. Starting SSO re-authentication...'); } catch (e) { /* ignore */ }
            }
            const ssoResult = await this._performSsoLogin(client, context?.ctx);
            if (ssoResult.error) {
              return {
                status: 'session_started_unauthenticated',
                host: `${client.protocol}://${client.host}:${client.port}`,
                message: `Config loaded but tokens expired. SSO login failed: ${ssoResult.error}. Use jira_sso_login or jira_authenticate to re-authenticate.`,
                sso_attempted: true,
              };
            }

            return {
              status: 'session_started',
              host: `${client.protocol}://${client.host}:${client.port}`,
              message: 'Jira session started. Tokens were expired and have been refreshed via SSO.',
              sso_login: 'success',
              keepalive: client.keepAliveEnabled ? 'enabled' : 'disabled',
            };
          }
        }

        const host = args.host || process.env.JIRA_HOST;
        if (!host) {
          return { error: 'No Jira host provided. Set JIRA_HOST environment variable or provide host parameter.' };
        }

        client.setHost(host, args.verify_ssl !== false);
        return {
          status: 'session_started',
          host,
          message: 'Jira session started. Use authenticate or sso_login to log in.',
        };
      },
    });

    this.registerTool({
      name: 'reset_session',
      description: 'Reset the current Jira session, clearing all state and authentication.',
      inputSchema: { type: 'object', properties: {} },
      handler: async (args, context) => {
        const client = this.getClient(context);
        client.stopKeepAlive();
        if (context.session) {
          context.sessionManager.clearProviderData(context.session.id, 'jira');
        }
        return { status: 'session_reset', message: 'Jira session has been reset.' };
      },
    });

    this.registerTool({
      name: 'sso_login',
      description: 'Authenticate with Jira via Microsoft SSO. Opens a browser to drive the login flow, handles MFA, and extracts session cookies.',
      inputSchema: {
        type: 'object',
        properties: {
          email: this.stringProp('SSO email address. Uses JIRA_SSO_EMAIL env var or config if not provided.'),
          password: this.stringProp('SSO password. Will prompt via MCP elicitation if not provided. Never saved to disk.'),
          headless: this.booleanProp('Run browser in headless mode (default: true). Set false to see the browser during login.'),
          mfa_code: this.stringProp('MFA verification code, if using TOTP/SMS. For number-matching MFA, approve on your phone instead.'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        if (!client.host) {
          return { error: 'No Jira host configured. Call start_session first or set JIRA_HOST.' };
        }

        return await this._performSsoLogin(client, context?.ctx, {
          email: args.email,
          password: args.password,
          headless: args.headless,
          mfaCode: args.mfa_code,
        });
      },
    });

    this.registerTool({
      name: 'authenticate',
      description: 'Authenticate with Jira using API token (Basic) or bearer token.',
      inputSchema: {
        type: 'object',
        properties: {
          email: this.stringProp('Jira user email for API token auth. Uses JIRA_EMAIL env var if not provided.'),
          api_token: this.stringProp('Jira API token. Uses JIRA_API_TOKEN env var if not provided.'),
          bearer_token: this.stringProp('Bearer token for authentication. Uses JIRA_BEARER_TOKEN env var if not provided.'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);

        const bearer = args.bearer_token || process.env.JIRA_BEARER_TOKEN;
        if (bearer) {
          client.bearerToken = bearer;
          await client.ping();
          return { status: 'authenticated', method: 'bearer' };
        }

        const email = args.email || process.env.JIRA_EMAIL;
        const token = args.api_token || process.env.JIRA_API_TOKEN;
        if (!email || !token) {
          return { error: 'No credentials provided. Provide email+api_token (or set JIRA_EMAIL/JIRA_API_TOKEN), or provide bearer_token (JIRA_BEARER_TOKEN).' };
        }

        client.setBasicAuth(email, token);
        await client.ping();
        return { status: 'authenticated', method: 'api_token', email: email.replace(/^[^@]+/, '***') };
      },
    });

    // =====================
    // ISSUE OPERATIONS
    // =====================

    this.registerTool({
      name: 'get_issue',
      description: 'Get Jira issue details by issue key (e.g., PROJ-123).',
      inputSchema: {
        type: 'object',
        properties: {
          key: this.stringProp('Issue key', { required: true }),
          fields: this.arrayProp('Fields to include (optional)', { type: 'string' }),
          expand: this.arrayProp('Expand options (optional)', { type: 'string' }),
        },
        required: ['key'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getIssue(args.key, { fields: args.fields, expand: args.expand });
      },
    });

    this.registerTool({
      name: 'search_issues',
      description: 'Search Jira issues using JQL.',
      inputSchema: {
        type: 'object',
        properties: {
          jql: this.stringProp('JQL query', { required: true }),
          start_at: this.numberProp('Pagination startAt (default: 0)'),
          max_results: this.numberProp('Max results (default: 50)'),
          fields: this.arrayProp('Fields to include (optional)', { type: 'string' }),
          expand: this.arrayProp('Expand options (optional)', { type: 'string' }),
        },
        required: ['jql'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.searchIssues({
          jql: args.jql,
          startAt: args.start_at || 0,
          maxResults: args.max_results || 50,
          fields: args.fields,
          expand: args.expand,
        });
      },
    });

    this.registerTool({
      name: 'create_issue',
      description: 'Create a new Jira issue.',
      inputSchema: {
        type: 'object',
        properties: {
          fields: this.prop('object', 'Issue fields payload (fields.*). Must include project, issuetype, summary.', { required: true }),
        },
        required: ['fields'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.createIssue(args.fields);
      },
    });

    this.registerTool({
      name: 'update_issue',
      description: 'Update Jira issue fields.',
      inputSchema: {
        type: 'object',
        properties: {
          key: this.stringProp('Issue key', { required: true }),
          fields: this.prop('object', 'Fields to set (fields.*).', { required: true }),
        },
        required: ['key', 'fields'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.updateIssue(args.key, args.fields);
      },
    });

    this.registerTool({
      name: 'add_comment',
      description: 'Add a comment to an issue.',
      inputSchema: {
        type: 'object',
        properties: {
          key: this.stringProp('Issue key', { required: true }),
          comment: this.stringProp('Comment text', { required: true }),
        },
        required: ['key', 'comment'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.addComment(args.key, args.comment);
      },
    });

    this.registerTool({
      name: 'get_comments',
      description: 'Get comments for an issue.',
      inputSchema: {
        type: 'object',
        properties: {
          key: this.stringProp('Issue key', { required: true }),
          start_at: this.numberProp('Pagination startAt'),
          max_results: this.numberProp('Max results'),
          order_by: this.stringProp('Order by (e.g., created)'),
        },
        required: ['key'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getComments(args.key, {
          startAt: args.start_at,
          maxResults: args.max_results,
          orderBy: args.order_by,
        });
      },
    });

    this.registerTool({
      name: 'transition_issue',
      description: 'Transition an issue to a new status by transition ID.',
      inputSchema: {
        type: 'object',
        properties: {
          key: this.stringProp('Issue key', { required: true }),
          transition_id: this.stringProp('Transition ID', { required: true }),
        },
        required: ['key', 'transition_id'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.transitionIssue(args.key, args.transition_id);
      },
    });

    this.registerTool({
      name: 'assign_issue',
      description: 'Assign/reassign an issue to a user accountId.',
      inputSchema: {
        type: 'object',
        properties: {
          key: this.stringProp('Issue key', { required: true }),
          account_id: this.stringProp('Atlassian accountId', { required: true }),
        },
        required: ['key', 'account_id'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.assignIssue(args.key, args.account_id);
      },
    });

    // =====================
    // LINKING & RELATIONS
    // =====================

    this.registerTool({
      name: 'link_issues',
      description: 'Create a link between two issues.',
      inputSchema: {
        type: 'object',
        properties: {
          type: this.stringProp('Link type name (e.g., "Blocks", "Relates")', { required: true }),
          inward_issue: this.stringProp('Inward issue key', { required: true }),
          outward_issue: this.stringProp('Outward issue key', { required: true }),
        },
        required: ['type', 'inward_issue', 'outward_issue'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.linkIssues(args.type, args.inward_issue, args.outward_issue);
      },
    });

    this.registerTool({
      name: 'get_issue_links',
      description: 'Get all issue links for an issue.',
      inputSchema: {
        type: 'object',
        properties: {
          key: this.stringProp('Issue key', { required: true }),
        },
        required: ['key'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getIssueLinks(args.key);
      },
    });

    this.registerTool({
      name: 'get_subtasks',
      description: 'Get subtasks for a parent issue.',
      inputSchema: {
        type: 'object',
        properties: {
          key: this.stringProp('Issue key', { required: true }),
        },
        required: ['key'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getSubtasks(args.key);
      },
    });

    // =====================
    // SPRINT & BOARD
    // =====================

    this.registerTool({
      name: 'get_boards',
      description: 'List agile boards.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key or ID to filter boards'),
          type: this.enumProp('Board type', ['scrum', 'kanban']),
          name: this.stringProp('Filter by board name'),
          start_at: this.numberProp('Pagination startAt'),
          max_results: this.numberProp('Max results'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getBoards({
          projectKeyOrId: args.project,
          type: args.type,
          name: args.name,
          startAt: args.start_at,
          maxResults: args.max_results,
        });
      },
    });

    this.registerTool({
      name: 'get_sprints',
      description: 'List sprints for a board.',
      inputSchema: {
        type: 'object',
        properties: {
          board_id: this.numberProp('Board ID', { required: true }),
          state: this.enumProp('Sprint state filter', ['future', 'active', 'closed']),
          start_at: this.numberProp('Pagination startAt'),
          max_results: this.numberProp('Max results'),
        },
        required: ['board_id'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getSprints(args.board_id, {
          state: args.state,
          startAt: args.start_at,
          maxResults: args.max_results,
        });
      },
    });

    this.registerTool({
      name: 'get_sprint_issues',
      description: 'Get issues in a sprint.',
      inputSchema: {
        type: 'object',
        properties: {
          sprint_id: this.numberProp('Sprint ID', { required: true }),
          jql: this.stringProp('Optional additional JQL filter'),
          fields: this.arrayProp('Fields to include', { type: 'string' }),
          start_at: this.numberProp('Pagination startAt'),
          max_results: this.numberProp('Max results'),
        },
        required: ['sprint_id'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getSprintIssues(args.sprint_id, {
          jql: args.jql,
          fields: args.fields,
          startAt: args.start_at,
          maxResults: args.max_results,
        });
      },
    });

    this.registerTool({
      name: 'move_to_sprint',
      description: 'Move one or more issues to a sprint.',
      inputSchema: {
        type: 'object',
        properties: {
          sprint_id: this.numberProp('Sprint ID', { required: true }),
          issues: this.arrayProp('Issue keys to move', { type: 'string' }, { required: true }),
        },
        required: ['sprint_id', 'issues'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.moveToSprint(args.sprint_id, args.issues);
      },
    });

    // =====================
    // PROJECT & METADATA
    // =====================

    this.registerTool({
      name: 'get_projects',
      description: 'List accessible Jira projects.',
      inputSchema: {
        type: 'object',
        properties: {
          expand: this.arrayProp('Expand options', { type: 'string' }),
          start_at: this.numberProp('Pagination startAt'),
          max_results: this.numberProp('Max results'),
        },
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getProjects({
          expand: args.expand,
          startAt: args.start_at,
          maxResults: args.max_results,
        });
      },
    });

    this.registerTool({
      name: 'get_project_statuses',
      description: 'Get statuses for a project (workflows by issue type).',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key or ID', { required: true }),
        },
        required: ['project'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getProjectStatuses(args.project);
      },
    });

    this.registerTool({
      name: 'get_issue_types',
      description: 'Get issue types for a project.',
      inputSchema: {
        type: 'object',
        properties: {
          project: this.stringProp('Project key or ID', { required: true }),
        },
        required: ['project'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getIssueTypes(args.project);
      },
    });

    // =====================
    // USER & WORKFLOW
    // =====================

    this.registerTool({
      name: 'get_transitions',
      description: 'Get available transitions for an issue.',
      inputSchema: {
        type: 'object',
        properties: {
          key: this.stringProp('Issue key', { required: true }),
        },
        required: ['key'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getTransitions(args.key);
      },
    });

    this.registerTool({
      name: 'find_users',
      description: 'Find users by query (for assignment).',
      inputSchema: {
        type: 'object',
        properties: {
          query: this.stringProp('Search query (name/email)', { required: true }),
          start_at: this.numberProp('Pagination startAt'),
          max_results: this.numberProp('Max results'),
        },
        required: ['query'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.findUsers(args.query, {
          startAt: args.start_at,
          maxResults: args.max_results,
        });
      },
    });

    this.registerTool({
      name: 'get_changelogs',
      description: 'Get change history (changelog) for an issue.',
      inputSchema: {
        type: 'object',
        properties: {
          key: this.stringProp('Issue key', { required: true }),
          start_at: this.numberProp('Pagination startAt'),
          max_results: this.numberProp('Max results'),
        },
        required: ['key'],
      },
      handler: async (args, context) => {
        const client = this.getClient(context);
        return await client.getChangelogs(args.key, {
          startAt: args.start_at,
          maxResults: args.max_results,
        });
      },
    });

    this.log(`Registered ${this.tools.length} Jira tools`);
  }
}

module.exports = JiraProvider;
