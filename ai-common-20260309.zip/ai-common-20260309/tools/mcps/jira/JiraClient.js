/**
 * Jira Client
 * 
 * HTTP client for interacting with the Jira REST API (v2 and Agile).
 * Handles authentication, session management, and API calls.
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

let yaml;
try {
  yaml = require('js-yaml');
} catch (e) {
  yaml = null;
}

class JiraClient {
  constructor(options = {}) {
    this.verbose = options.verbose || false;
    this.host = null;
    this.port = 443;
    this.protocol = 'https';
    this.verifySsl = true;
    this.apiToken = null;
    this.basicAuth = null; // base64(email:apiToken)
    this.bearerToken = null;
    this.cloudSessionToken = null;
    this.cookies = {};
    this.keepAliveInterval = null;
    this.keepAliveEnabled = false;
    this.isCloud = false;
    this.ssoConfig = {};
    this.tokenObtainedAt = null;
    this.apiVersion = '3'; // Jira Cloud uses v3, Server uses v2

    this.log = this.verbose
      ? (...args) => console.error('[JiraClient]', ...args)
      : () => {};
  }

  /**
   * Load configuration from .jira_mcp.local.yaml file
   */
  loadConfig(configPath = null) {
    if (!yaml) {
      this.log('js-yaml not installed, cannot load YAML config');
      return null;
    }

    const searchPaths = configPath ? [configPath] : [
      path.join(process.cwd(), '.jira_mcp.local.yaml'),
      path.join(__dirname, '..', '..', '.jira_mcp.local.yaml'),
      path.join(process.env.HOME || process.env.USERPROFILE || '', '.jira_mcp.local.yaml'),
    ];

    for (const cfgPath of searchPaths) {
      try {
        if (fs.existsSync(cfgPath)) {
          const content = fs.readFileSync(cfgPath, 'utf-8');
          const config = yaml.load(content);
          this.log(`Loaded config from ${cfgPath}`);
          return config;
        }
      } catch (e) {
        this.log(`Failed to load config from ${cfgPath}: ${e.message}`);
      }
    }

    this.log('No config file found');
    return null;
  }

  /**
   * Initialize from config file
   */
  initFromConfig(configPath = null) {
    const config = this.loadConfig(configPath);
    if (!config || !config.jira) {
      return false;
    }

    const jira = config.jira;

    if (jira.host) {
      this.setHost(jira.host, jira.verify_ssl !== false);
    }

    if (jira.api_version) {
      this.apiVersion = jira.api_version;
    }

    // Load auth
    if (jira.auth) {
      if (jira.auth.email && jira.auth.api_token) {
        this.setBasicAuth(jira.auth.email, jira.auth.api_token);
        this.log('Loaded basic auth from config');
      }
      if (jira.auth.bearer_token) {
        this.bearerToken = jira.auth.bearer_token;
        this.log('Loaded bearer token from config');
      }
    }

    // Load session tokens (from SSO)
    if (jira.session) {
      if (jira.session.cloud_session_token) {
        this.cloudSessionToken = jira.session.cloud_session_token;
        this.cookies['cloud.session.token'] = jira.session.cloud_session_token;
        this.log('Loaded cloud session token from config');
      }
      if (jira.session.tenant_token) {
        this.cookies['tenant.session.token'] = jira.session.tenant_token;
      }
      if (jira.session.atl_xsrf_token) {
        this.cookies['atl.xsrf.token'] = jira.session.atl_xsrf_token;
      }

      // Jira Server/DC session cookies
      if (jira.session.jsessionid) {
        this.cookies['JSESSIONID'] = jira.session.jsessionid;
        this.log('Loaded JSESSIONID from config');
      }
      if (jira.session.atlassian_xsrf_token) {
        this.cookies['atlassian.xsrf.token'] = jira.session.atlassian_xsrf_token;
      }
      if (jira.session.cookies && typeof jira.session.cookies === 'object') {
        this.cookies = { ...this.cookies, ...jira.session.cookies };
      }

      if (jira.session.obtained_at) {
        this.tokenObtainedAt = new Date(jira.session.obtained_at);
        this.log(`Tokens obtained at: ${this.tokenObtainedAt.toISOString()}`);
      }
    }

    // Load SSO configuration
    if (jira.sso) {
      this.ssoConfig = {
        email: jira.sso.email || null,
        // Password must come from env var (JIRA_SSO_PASSWORD) or MCP elicitation — never from config file
        password: null,
        headless: jira.sso.headless !== false,
        timeoutSeconds: jira.sso.timeout_seconds || 120,
      };
      if (jira.sso.password) {
        this.log('WARNING: jira.sso.password in config file is ignored for security. Use JIRA_SSO_PASSWORD env var or MCP elicitation instead.');
      }
      this.log(`SSO config loaded (email: ${this.ssoConfig.email || 'not set'})`);
    }

    if (config.keepalive && config.keepalive.enabled) {
      this.startKeepAlive(config.keepalive.interval_seconds || 300);
    }

    return true;
  }

  /**
   * Set the Jira host
   */
  setHost(hostUrl, verifySsl = true) {
    const url = new URL(hostUrl);
    this.host = url.hostname;
    this.isCloud = this.host.includes('atlassian.net');
    this.port = url.port || (url.protocol === 'https:' ? 443 : 80);
    this.protocol = url.protocol.replace(':', '');
    this.verifySsl = verifySsl;
    this.apiVersion = this.isCloud ? '3' : '2';
    if (!verifySsl) {
      console.error('[JiraClient] ⚠️  WARNING: SSL certificate verification is DISABLED. This exposes connections to man-in-the-middle attacks. Set verify_ssl: true in production.');
    }
    if (this.protocol === 'http') {
      console.error('[JiraClient] ⚠️  WARNING: Using plain HTTP (no TLS). Authentication credentials will be transmitted in cleartext. Use HTTPS in production.');
    }
    this.log(`Host set to ${this.protocol}://${this.host}:${this.port} (Cloud: ${this.isCloud}, API v${this.apiVersion})`);
  }

  /**
   * Set basic auth (email + API token)
   */
  setBasicAuth(email, apiToken) {
    this.basicAuth = Buffer.from(`${email}:${apiToken}`).toString('base64');
    this.apiToken = apiToken;
    this.log('Basic auth configured');
  }

  /**
   * Start session keep-alive pings
   */
  startKeepAlive(intervalSeconds = 300) {
    if (this.keepAliveInterval) {
      this.stopKeepAlive();
    }

    this.keepAliveEnabled = true;
    const intervalMs = intervalSeconds * 1000;

    this.log(`Starting keep-alive with ${intervalSeconds}s interval`);

    this._keepAliveFailures = 0;
    this.sessionExpired = false;

    this.keepAliveInterval = setInterval(async () => {
      try {
        await this.ping();
        this._keepAliveFailures = 0;
        this.log('Keep-alive ping successful');
      } catch (e) {
        this._keepAliveFailures++;
        this.log(`Keep-alive ping failed (${this._keepAliveFailures}/3): ${e.message}`);
        if (this._keepAliveFailures >= 3) {
          this.log('Keep-alive: 3 consecutive failures — session likely expired, stopping keep-alive');
          this.sessionExpired = true;
          this.stopKeepAlive();
        }
      }
    }, intervalMs);

    if (this.keepAliveInterval.unref) {
      this.keepAliveInterval.unref();
    }
  }

  stopKeepAlive() {
    if (this.keepAliveInterval) {
      clearInterval(this.keepAliveInterval);
      this.keepAliveInterval = null;
      this.keepAliveEnabled = false;
      this.log('Keep-alive stopped');
    }
  }

  async ping() {
    const response = await this.request('GET', `/rest/api/${this.apiVersion}/myself`);
    return { status: 'alive', user: response.displayName || response.name };
  }

  /**
   * Update session tokens and optionally save to config file
   */
  updateTokens(tokens, saveToConfig = true) {
    // Prefer explicit token fields, but also accept full cookie maps (Jira Server/DC).
    if (tokens.cloud_session_token) {
      this.cloudSessionToken = tokens.cloud_session_token;
      this.cookies['cloud.session.token'] = tokens.cloud_session_token;
    }
    if (tokens.tenant_token) {
      this.cookies['tenant.session.token'] = tokens.tenant_token;
    }
    if (tokens.atl_xsrf_token) {
      this.cookies['atl.xsrf.token'] = tokens.atl_xsrf_token;
    }

    // Jira Server/DC cookies
    if (tokens.jsessionid) {
      this.cookies['JSESSIONID'] = tokens.jsessionid;
    }
    if (tokens.atlassian_xsrf_token) {
      this.cookies['atlassian.xsrf.token'] = tokens.atlassian_xsrf_token;
    }

    if (tokens.all_cookies && typeof tokens.all_cookies === 'object') {
      this.cookies = { ...this.cookies, ...tokens.all_cookies };

      // If the SSO flow returned a Jira Cloud cookie map, capture cloud.session.token too.
      if (!this.cloudSessionToken && this.cookies['cloud.session.token']) {
        this.cloudSessionToken = this.cookies['cloud.session.token'];
      }
    }

    this.tokenObtainedAt = new Date();
    this.log('Tokens updated in memory');

    if (saveToConfig) {
      this.saveTokensToConfig(tokens);
    }

    return { status: 'tokens_updated', authenticated: this.isAuthenticated() };
  }

  saveTokensToConfig(tokens) {
    if (!yaml) {
      this.log('js-yaml not installed, cannot save config');
      return false;
    }

    const searchPaths = [
      path.join(process.cwd(), '.jira_mcp.local.yaml'),
      path.join(__dirname, '..', '..', '.jira_mcp.local.yaml'),
      path.join(process.env.HOME || process.env.USERPROFILE || '', '.jira_mcp.local.yaml'),
    ];

    let configPath = null;
    let config = null;

    for (const cfgPath of searchPaths) {
      try {
        if (fs.existsSync(cfgPath)) {
          const content = fs.readFileSync(cfgPath, 'utf-8');
          config = yaml.load(content);
          configPath = cfgPath;
          break;
        }
      } catch (e) {
        this.log(`Failed to read config from ${cfgPath}: ${e.message}`);
      }
    }

    if (!configPath || !config) {
      this.log('No config file found to update');
      return false;
    }

    if (!config.jira) config.jira = {};
    if (!config.jira.session) config.jira.session = {};

    if (tokens.cloud_session_token) config.jira.session.cloud_session_token = tokens.cloud_session_token;
    if (tokens.tenant_token) config.jira.session.tenant_token = tokens.tenant_token;
    if (tokens.atl_xsrf_token) config.jira.session.atl_xsrf_token = tokens.atl_xsrf_token;

    // Jira Server/DC
    if (tokens.jsessionid) config.jira.session.jsessionid = tokens.jsessionid;
    if (tokens.atlassian_xsrf_token) config.jira.session.atlassian_xsrf_token = tokens.atlassian_xsrf_token;
    // Only persist Jira-scoped cookies, not the full browser cookie jar
    if (tokens.all_cookies && typeof tokens.all_cookies === 'object' && this.host) {
      const jiraHost = this.host.toLowerCase();
      const filtered = {};
      for (const [name, value] of Object.entries(tokens.all_cookies)) {
        // Only keep cookies with names matching known Jira session cookie patterns
        if (/^(JSESSIONID|atlassian|cloud\.session|tenant\.session|atl\.xsrf)/i.test(name)) {
          filtered[name] = value;
        }
      }
      if (Object.keys(filtered).length > 0) {
        config.jira.session.cookies = filtered;
      }
    }

    config.jira.session.obtained_at = new Date().toISOString();

    try {
      const warningHeader =
        '# WARNING: This file may contain sensitive Jira session tokens/cookies.\n' +
        '# Treat it like a password: do not commit it, and restrict access to it.\n\n';

      const yamlContent = yaml.dump(config, { lineWidth: -1 });
      fs.writeFileSync(configPath, warningHeader + yamlContent, 'utf-8');

      // Best-effort hardening: ensure the file is only readable/writable by the current user (POSIX).
      try {
        fs.chmodSync(configPath, 0o600);
      } catch (e) {
        // chmod is POSIX-only and fails on Windows — warn prominently
        if (process.platform === 'win32') {
          this.log(`WARNING: Cannot restrict file permissions on Windows. Ensure ${configPath} is not accessible to other users. Consider using Windows file properties to restrict access.`);
        } else {
          this.log(`WARNING: Failed to set restrictive permissions on ${configPath}: ${e.message}`);
        }
      }

      this.log(`Tokens saved to ${configPath}`);
      return true;
    } catch (e) {
      this.log(`Failed to save config: ${e.message}`);
      return false;
    }
  }

  async logout() {
    this.stopKeepAlive();
    this.basicAuth = null;
    this.bearerToken = null;
    this.cloudSessionToken = null;
    this.apiToken = null;
    this.cookies = {};
    this.log('Logged out');
  }

  isAuthenticated() {
    return !!(
      this.basicAuth ||
      this.bearerToken ||
      this.cloudSessionToken ||
      this.cookies['JSESSIONID'] ||
      this.cookies['cloud.session.token']
    );
  }

  async isTokenExpired() {
    if (!this.isAuthenticated()) return true;

    try {
      await this.request('GET', `/rest/api/${this.apiVersion}/myself`);
      return false;
    } catch (e) {
      this.log(`Token check failed: ${e.message}`);
      return true;
    }
  }

  getSsoConfig() {
    return {
      email: this.ssoConfig.email || process.env.JIRA_SSO_EMAIL || null,
      password: this.ssoConfig.password || process.env.JIRA_SSO_PASSWORD || null,
      headless: this.ssoConfig.headless !== false,
      timeoutSeconds: this.ssoConfig.timeoutSeconds || 120,
      jiraUrl: `${this.protocol}://${this.host}${this.port !== 443 && this.port !== 80 ? ':' + this.port : ''}`,
    };
  }

  // =====================
  // JIRA API METHODS
  // =====================

  /** Encode path segments to prevent path traversal */
  _encodeSegment(value) {
    return encodeURIComponent(String(value));
  }

  /**
   * Get issue by key
   */
  async getIssue(issueKey, options = {}) {
    const params = {};
    if (options.fields) params.fields = options.fields.join(',');
    if (options.expand) params.expand = options.expand.join(',');
    const qs = new URLSearchParams(params).toString();
    const path = `/rest/api/${this.apiVersion}/issue/${this._encodeSegment(issueKey)}${qs ? '?' + qs : ''}`;
    return await this.request('GET', path);
  }

  /**
   * Search issues using JQL
   */
  async searchIssues(options) {
    const body = {
      jql: options.jql,
      startAt: options.startAt || 0,
      maxResults: options.maxResults || 50,
    };
    if (options.fields) body.fields = options.fields;
    if (options.expand) body.expand = options.expand;
    return await this.request('POST', `/rest/api/${this.apiVersion}/search`, body);
  }

  /**
   * Create a new issue
   */
  async createIssue(fields) {
    return await this.request('POST', `/rest/api/${this.apiVersion}/issue`, { fields });
  }

  /**
   * Update an issue
   */
  async updateIssue(issueKey, fields, options = {}) {
    const body = {};
    if (fields) body.fields = fields;
    if (options.update) body.update = options.update;
    await this.request('PUT', `/rest/api/${this.apiVersion}/issue/${this._encodeSegment(issueKey)}`, body);
    return { status: 'updated', key: issueKey };
  }

  /**
   * Add a comment to an issue
   */
  async addComment(issueKey, body) {
    const commentBody = this.apiVersion === '3'
      ? { body: { type: 'doc', version: 1, content: [{ type: 'paragraph', content: [{ type: 'text', text: body }] }] } }
      : { body };
    return await this.request('POST', `/rest/api/${this.apiVersion}/issue/${this._encodeSegment(issueKey)}/comment`, commentBody);
  }

  /**
   * Get comments for an issue
   */
  async getComments(issueKey, options = {}) {
    const params = {};
    if (options.startAt !== undefined) params.startAt = options.startAt;
    if (options.maxResults) params.maxResults = options.maxResults;
    if (options.orderBy) params.orderBy = options.orderBy;
    const qs = new URLSearchParams(params).toString();
    return await this.request('GET', `/rest/api/${this.apiVersion}/issue/${this._encodeSegment(issueKey)}/comment${qs ? '?' + qs : ''}`);
  }

  /**
   * Transition an issue
   */
  async transitionIssue(issueKey, transitionId, fields = null) {
    const body = { transition: { id: transitionId } };
    if (fields) body.fields = fields;
    await this.request('POST', `/rest/api/${this.apiVersion}/issue/${this._encodeSegment(issueKey)}/transitions`, body);
    return { status: 'transitioned', key: issueKey, transitionId };
  }

  /**
   * Get available transitions for an issue
   */
  async getTransitions(issueKey) {
    return await this.request('GET', `/rest/api/${this.apiVersion}/issue/${this._encodeSegment(issueKey)}/transitions`);
  }

  /**
   * Assign an issue
   */
  async assignIssue(issueKey, accountId) {
    await this.request('PUT', `/rest/api/${this.apiVersion}/issue/${this._encodeSegment(issueKey)}/assignee`, { accountId });
    return { status: 'assigned', key: issueKey, accountId };
  }

  /**
   * Link two issues
   */
  async linkIssues(type, inwardIssue, outwardIssue) {
    await this.request('POST', `/rest/api/${this.apiVersion}/issueLink`, {
      type: { name: type },
      inwardIssue: { key: inwardIssue },
      outwardIssue: { key: outwardIssue },
    });
    return { status: 'linked', type, inwardIssue, outwardIssue };
  }

  /**
   * Get issue links
   */
  async getIssueLinks(issueKey) {
    const issue = await this.getIssue(issueKey, { fields: ['issuelinks'] });
    return { issueLinks: issue.fields?.issuelinks || [] };
  }

  /**
   * Get subtasks of an issue
   */
  async getSubtasks(issueKey) {
    const issue = await this.getIssue(issueKey, { fields: ['subtasks'] });
    return { subtasks: issue.fields?.subtasks || [] };
  }

  /**
   * Get agile boards
   */
  async getBoards(options = {}) {
    const params = {};
    if (options.projectKeyOrId) params.projectKeyOrId = options.projectKeyOrId;
    if (options.type) params.type = options.type;
    if (options.name) params.name = options.name;
    params.startAt = options.startAt || 0;
    params.maxResults = options.maxResults || 50;
    const qs = new URLSearchParams(params).toString();
    return await this.request('GET', `/rest/agile/1.0/board?${qs}`);
  }

  /**
   * Get sprints for a board
   */
  async getSprints(boardId, options = {}) {
    const params = {};
    if (options.state) params.state = options.state;
    params.startAt = options.startAt || 0;
    params.maxResults = options.maxResults || 50;
    const qs = new URLSearchParams(params).toString();
    return await this.request('GET', `/rest/agile/1.0/board/${this._encodeSegment(boardId)}/sprint?${qs}`);
  }

  /**
   * Get issues in a sprint
   */
  async getSprintIssues(sprintId, options = {}) {
    const params = {};
    if (options.jql) params.jql = options.jql;
    if (options.fields) params.fields = options.fields.join(',');
    params.startAt = options.startAt || 0;
    params.maxResults = options.maxResults || 50;
    const qs = new URLSearchParams(params).toString();
    return await this.request('GET', `/rest/agile/1.0/sprint/${this._encodeSegment(sprintId)}/issue?${qs}`);
  }

  /**
   * Move issues to a sprint
   */
  async moveToSprint(sprintId, issueKeys) {
    await this.request('POST', `/rest/agile/1.0/sprint/${this._encodeSegment(sprintId)}/issue`, {
      issues: issueKeys,
    });
    return { status: 'moved', sprintId, issues: issueKeys };
  }

  /**
   * Get accessible projects
   */
  async getProjects(options = {}) {
    const params = {};
    if (options.expand) params.expand = options.expand.join(',');
    params.startAt = options.startAt || 0;
    params.maxResults = options.maxResults || 50;
    const qs = new URLSearchParams(params).toString();
    return await this.request('GET', `/rest/api/${this.apiVersion}/project/search?${qs}`);
  }

  /**
   * Get project statuses
   */
  async getProjectStatuses(projectIdOrKey) {
    return await this.request('GET', `/rest/api/${this.apiVersion}/project/${this._encodeSegment(projectIdOrKey)}/statuses`);
  }

  /**
   * Get issue types for a project
   */
  async getIssueTypes(projectIdOrKey) {
    const project = await this.request('GET', `/rest/api/${this.apiVersion}/project/${this._encodeSegment(projectIdOrKey)}`);
    return { issueTypes: project.issueTypes || [] };
  }

  /**
   * Search for users
   */
  async findUsers(query, options = {}) {
    const params = { query };
    if (options.maxResults) params.maxResults = options.maxResults;
    if (options.startAt) params.startAt = options.startAt;
    const qs = new URLSearchParams(params).toString();
    return await this.request('GET', `/rest/api/${this.apiVersion}/user/search?${qs}`);
  }

  /**
   * Get issue changelog
   */
  async getChangelogs(issueKey, options = {}) {
    const params = {};
    if (options.startAt !== undefined) params.startAt = options.startAt;
    if (options.maxResults) params.maxResults = options.maxResults;
    const qs = new URLSearchParams(params).toString();
    return await this.request('GET', `/rest/api/${this.apiVersion}/issue/${this._encodeSegment(issueKey)}/changelog?${qs}`);
  }

  // =====================
  // HTTP REQUEST
  // =====================

  _buildAuthHeaders() {
    if (this.basicAuth) {
      return { 'Authorization': `Basic ${this.basicAuth}` };
    }

    if (this.bearerToken) {
      return { 'Authorization': `Bearer ${this.bearerToken}` };
    }

    // Cookie-based auth: Jira Cloud (cloud.session.token) and Jira Server/DC (JSESSIONID)
    const cookieParts = [];
    for (const [name, value] of Object.entries(this.cookies)) {
      if (value) cookieParts.push(`${name}=${value}`);
    }

    const headers = {};
    if (cookieParts.length > 0) {
      headers['Cookie'] = cookieParts.join('; ');
    }

    if (this.cookies['atl.xsrf.token'] || this.cookies['atlassian.xsrf.token']) {
      headers['X-Atlassian-Token'] = 'no-check';
    }

    return headers;
  }

  async request(method, apiPath, body = null) {
    return new Promise((resolve, reject) => {
      const isWrite = method === 'POST' || method === 'PUT' || method === 'DELETE';
      let bodyStr = '';

      if (body && isWrite) {
        bodyStr = JSON.stringify(body);
      }

      const authHeaders = this._buildAuthHeaders();

      const options = {
        hostname: this.host,
        port: this.port,
        path: apiPath,
        method,
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          ...authHeaders,
        },
        rejectUnauthorized: this.verifySsl,
      };

      if (isWrite && bodyStr) {
        options.headers['Content-Length'] = Buffer.byteLength(bodyStr);
      }

      this.log(`${method} ${apiPath}`);

      const protocol = this.protocol === 'https' ? https : http;

      const req = protocol.request(options, (res) => {
        let data = '';

        res.on('data', chunk => {
          data += chunk;
        });

        res.on('end', () => {
          this.log(`Response: ${res.statusCode} (${data.length} bytes)`);

          if (res.statusCode >= 400) {
            let errorMessage = `HTTP ${res.statusCode}`;
            try {
              const parsed = JSON.parse(data);
              errorMessage = parsed.errorMessages?.[0] || parsed.message || parsed.error || errorMessage;
            } catch (e) {
              errorMessage = data.substring(0, 200) || errorMessage;
            }

            if (res.statusCode === 401 || res.statusCode === 403) {
              const err = new Error(errorMessage);
              err.statusCode = res.statusCode;
              err.isAuthError = true;
              reject(err);
              return;
            }

            const err = new Error(errorMessage);
            err.statusCode = res.statusCode;
            reject(err);
            return;
          }

          // 204 No Content
          if (res.statusCode === 204 || !data) {
            resolve({});
            return;
          }

          try {
            resolve(JSON.parse(data));
          } catch (e) {
            resolve(data);
          }
        });
      });

      req.setTimeout(30000, () => {
        req.destroy(new Error('Request timeout after 30s'));
      });

      req.on('error', (error) => {
        const errorMsg = error.message || error.code || error.toString();
        this.log('Request error:', errorMsg);
        reject(new Error(errorMsg));
      });

      if (isWrite && bodyStr) {
        req.write(bodyStr);
      }

      req.end();
    });
  }
}

module.exports = JiraClient;
