/**
 * Jira SSO Authentication Flow
 * 
 * Drives a headless Edge/Chrome browser through the Jira Cloud SAML SSO flow:
 * Jira login → Microsoft Entra ID → MFA → session cookie extraction.
 * 
 * Uses puppeteer-core to automate the browser and MCP context elicitation
 * to communicate MFA challenges back to the user.
 */

const puppeteer = require('puppeteer-core');
const path = require('path');
const fs = require('fs');
const os = require('os');

// Microsoft login page selectors (primary + fallback for resilience)
const MS_SELECTORS = {
  emailInput: 'input[name="loginfmt"]',
  emailInputFallback: 'input[type="email"][name="loginfmt"]',
  emailNextButton: 'input[type="submit"][value="Next"]',
  emailNextButtonFallback: '#idSIButton9',

  passwordInput: 'input[type="password"][name="passwd"]',
  passwordInputFallback: 'input[name="passwd"]',
  passwordSubmitButton: 'input[type="submit"][value="Sign in"]',
  passwordSubmitButtonFallback: '#idSIButton9',

  mfaDisplayNumber: '#idRichContext_DisplaySign',
  mfaDisplayNumberFallback: '#displaySign',

  mfaCodeInput: 'input[name="otc"]',
  mfaCodeInputFallback: '#idTxtBx_SAOTCC_OTC',
  mfaCodeSubmit: 'input[type="submit"][value="Verify"]',
  mfaCodeSubmitFallback: '#idSubmit_SAOTCC_Continue',

  staySignedInYes: 'input[type="submit"][value="Yes"]',
  staySignedInYesFallback: '#idSIButton9',
  staySignedInNo: 'input[type="button"][value="No"]',
  kmsiPage: '#KmsiDescription',

  usernameError: '#usernameError',
  passwordError: '#passwordError',
  loginError: '#error',
};

// Atlassian login selectors (for Atlassian ID flow)
const ATLASSIAN_SELECTORS = {
  emailInput: '#username',
  emailSubmit: '#login-submit',
  passwordInput: '#password',
  passwordSubmit: '#login-submit',
  ssoRedirectButton: '#login-submit',
};

// Jira session cookie names
// Jira Cloud typically uses cloud.session.token; Jira Server/Data Center uses JSESSIONID.
const JIRA_COOKIES = {
  cloudSession: 'cloud.session.token',
  tenantToken: 'tenant.session.token',
  atlToken: 'atl.xsrf.token',

  // Jira Server/DC cookies
  jsessionid: 'JSESSIONID',
  atlassianXsrf: 'atlassian.xsrf.token',
};

class JiraAuthFlow {
  constructor(options = {}) {
    this.jiraUrl = options.jiraUrl;
    this.headless = options.headless !== false;
    this.timeoutMs = (options.timeoutSeconds || 120) * 1000;
    this.verbose = options.verbose || false;
    this.browser = null;
    this.page = null;

    this.log = this.verbose
      ? (...args) => console.error('[JiraAuthFlow]', ...args)
      : () => {};

    this.executablePath = options.executablePath || this._findBrowser();
  }

  /**
   * Try to find an element using primary selector, falling back to fallback selector
   */
  async _findElement(primary, fallback, opts = {}) {
    const timeout = opts.timeout || 5000;
    try {
      await this.page.waitForSelector(primary, { ...opts, timeout });
      return await this.page.$(primary);
    } catch (e) {
      if (fallback) {
        try {
          await this.page.waitForSelector(fallback, { ...opts, timeout: 3000 });
          this.log(`Used fallback selector: ${fallback}`);
          return await this.page.$(fallback);
        } catch (e2) { /* both failed */ }
      }
      return null;
    }
  }

  /**
   * Find Edge or Chrome executable
   */
  _findBrowser() {
    const edgePaths = process.platform === 'win32' ? [
      path.join(process.env.LOCALAPPDATA || '', 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
      'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
      'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    ] : process.platform === 'darwin' ? [
      '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
    ] : [
      '/usr/bin/microsoft-edge',
      '/usr/bin/microsoft-edge-stable',
    ];

    const chromePaths = process.platform === 'win32' ? [
      path.join(process.env.LOCALAPPDATA || '', 'Google', 'Chrome', 'Application', 'chrome.exe'),
      'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
      'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    ] : process.platform === 'darwin' ? [
      '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    ] : [
      '/usr/bin/google-chrome',
      '/usr/bin/google-chrome-stable',
    ];

    for (const p of [...edgePaths, ...chromePaths]) {
      try {
        if (fs.existsSync(p)) {
          this.log(`Found browser: ${p}`);
          return p;
        }
      } catch (e) { /* ignore */ }
    }

    // No browser found — return null so _launchBrowser can throw a descriptive error
    return null;
  }

  /**
   * Main authentication entry point.
   * Drives the full SSO flow and returns extracted session tokens.
   * 
   * @param {Object} options
   * @param {string} options.email - User's SSO email
   * @param {string} options.password - User's password (never persisted)
   * @param {string} [options.mfaCode] - MFA code for TOTP/SMS
   * @param {Object} [options.context] - MCP Context for elicitation (optional)
   * @param {number} [options.maxRetries] - Max retry attempts on failure (default: 1)
   * @returns {Object} { cloud_session_token, tenant_token, atl_xsrf_token }
   */
  async authenticate(options = {}) {
    const { email, password, mfaCode, context, maxRetries = 1 } = options;

    if (!email) throw new Error('SSO email is required');
    if (!password) throw new Error('SSO password is required');
    if (!this.jiraUrl) throw new Error('Jira URL is required');

    let lastError = null;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        if (attempt > 0) {
          this.log(`Retry attempt ${attempt}/${maxRetries}`);
          if (context) {
            try { await context.info(`SSO login retry attempt ${attempt}...`); } catch (e) { /* ignore */ }
          }
        }

        await this._launchBrowser();
        const loginState = await this._navigateToLogin();

        if (loginState === 'already_authenticated') {
          this.log('Already authenticated, extracting cookies directly');
          const tokens = await this._extractCookies();
          return tokens;
        }

        if (loginState === 'jira_server_login') {
          // Jira Server/DC native login
          const username = email.includes('@') ? email.split('@')[0] : email;
          await this._enterJiraServerCredentials(username, password);
        } else if (loginState === 'atlassian_login') {
          // Atlassian ID login — may redirect to Microsoft SSO
          await this._enterAtlassianEmail(email);
          // Check if we got redirected to Microsoft SSO or Atlassian password page
          const nextState = await this._detectPostAtlassianEmail();
          if (nextState === 'microsoft_sso') {
            await this._enterMicrosoftPassword(password, context);
            await this._handleMFA(context, mfaCode);
            await this._handleStaySignedIn();
          } else {
            await this._enterAtlassianPassword(password);
          }
        } else {
          // Direct Microsoft SSO flow
          await this._enterMicrosoftEmail(email);
          await this._enterMicrosoftPassword(password, context);
          await this._handleMFA(context, mfaCode);
          await this._handleStaySignedIn();
        }

        await this._waitForJiraSession(context);
        const tokens = await this._extractCookies();
        return tokens;
      } catch (e) {
        lastError = e;
        this.log(`Attempt ${attempt} failed: ${e.message}`);
      } finally {
        await this._cleanup();
      }
    }

    throw lastError;
  }

  async _launchBrowser() {
    if (!this.executablePath) {
      throw new Error('No Chrome or Edge browser found. Install one or set executablePath in options.');
    }

    this.log(`Launching browser (headless: ${this.headless})`);

    // Clean up stale temp directories from previous crashed sessions (older than 1 hour)
    try {
      const tmpDir = os.tmpdir();
      const entries = fs.readdirSync(tmpDir);
      const staleThreshold = Date.now() - 60 * 60 * 1000;
      for (const entry of entries) {
        if (entry.startsWith('jira-sso-')) {
          const fullPath = path.join(tmpDir, entry);
          try {
            const stat = fs.statSync(fullPath);
            if (stat.isDirectory() && stat.mtimeMs < staleThreshold) {
              fs.rmSync(fullPath, { recursive: true, force: true });
              this.log(`Cleaned up stale temp dir: ${entry}`);
            }
          } catch (e) { /* ignore individual cleanup errors */ }
        }
      }
    } catch (e) {
      this.log(`Stale temp dir cleanup warning: ${e.message}`);
    }

    const crypto = require('crypto');
    const userDataDir = path.join(os.tmpdir(), `jira-sso-${crypto.randomBytes(8).toString('hex')}`);

    this.browser = await puppeteer.launch({
      executablePath: this.executablePath,
      headless: this.headless,
      userDataDir,
      args: [
        '--no-first-run',
        '--no-default-browser-check',
        '--disable-extensions',
        '--disable-popup-blocking',
      ],
      defaultViewport: { width: 1280, height: 720 },
    });

    this.page = await this.browser.newPage();
    this._userDataDir = userDataDir;
  }

  /**
   * Navigate to Jira, which will redirect to SSO (Cloud) or show the native login form (Server/DC).
   * @returns {string} 'atlassian_login' | 'microsoft_sso' | 'jira_server_login' | 'already_authenticated'
   */
  async _navigateToLogin() {
    this.log(`Navigating to ${this.jiraUrl}`);

    await this.page.goto(this.jiraUrl, {
      waitUntil: 'networkidle2',
      timeout: 45000,
    });

    try {
      const result = await Promise.race([
        // Atlassian ID login page (Cloud)
        this.page.waitForSelector(ATLASSIAN_SELECTORS.emailInput, { timeout: 20000 }).then(() => 'atlassian_login'),
        // Microsoft SSO page directly
        this.page.waitForSelector(MS_SELECTORS.emailInput, { timeout: 20000 }).then(() => 'microsoft_sso'),
        this.page.waitForSelector(MS_SELECTORS.passwordInput, { timeout: 20000 }).then(() => 'microsoft_sso_password'),
        // Jira Server/DC native login form
        this.page.waitForSelector('#login-form-username', { timeout: 20000 }).then(() => 'jira_server_login'),
        // Already on Jira dashboard
        this.page.waitForFunction(
          (hostname) => window.location.hostname.includes(hostname) &&
            (window.location.pathname.includes('/jira') || window.location.pathname.includes('/browse') || window.location.pathname === '/'),
          { timeout: 20000 },
          new URL(this.jiraUrl).hostname
        ).then(() => 'jira_dashboard'),
      ]);

      if (result === 'jira_dashboard') {
        this.log('Already authenticated — on Jira dashboard');
        return 'already_authenticated';
      }

      if (result === 'microsoft_sso_password') {
        this.log('Microsoft SSO password page loaded directly');
        return 'microsoft_sso';
      }

      this.log(`Login page loaded (state: ${result})`);
      return result;
    } catch (e) {
      const url = this.page.url();
      const jiraHost = new URL(this.jiraUrl).hostname;

      // Jira Server/DC often lands on login.jsp without any Atlassian Cloud or Microsoft SSO markers.
      if (url.includes('login.jsp') || url.includes('permissionViolation') || url.includes('os_destination=')) {
        return 'jira_server_login';
      }

      if (url.includes(jiraHost) && !url.includes('login.microsoftonline.com') && !url.includes('id.atlassian.com')) {
        this.log('Appears to be authenticated — on Jira site');
        return 'already_authenticated';
      }
      throw new Error(`Failed to reach login page or Jira. Current URL: ${url}`);
    }
  }

  /**
   * Enter email on Atlassian ID login page
   */
  async _enterAtlassianEmail(email) {
    this.log(`Entering email on Atlassian login: ${email.replace(/^[^@]+/, '***')}`);
    await this.page.waitForSelector(ATLASSIAN_SELECTORS.emailInput, { visible: true, timeout: 10000 });
    await this.page.type(ATLASSIAN_SELECTORS.emailInput, email, { delay: 50 });
    await this.page.click(ATLASSIAN_SELECTORS.emailSubmit);
    await new Promise(resolve => setTimeout(resolve, 3000));
  }

  /**
   * Detect whether Atlassian email submission redirected to Microsoft SSO or Atlassian password
   */
  async _detectPostAtlassianEmail() {
    try {
      const result = await Promise.race([
        this.page.waitForSelector(MS_SELECTORS.emailInput, { timeout: 10000 }).then(() => 'microsoft_sso'),
        this.page.waitForSelector(MS_SELECTORS.passwordInput, { timeout: 10000 }).then(() => 'microsoft_sso'),
        this.page.waitForSelector(ATLASSIAN_SELECTORS.passwordInput, { timeout: 10000 }).then(() => 'atlassian_password'),
      ]);
      this.log(`Post-email state: ${result}`);
      return result;
    } catch (e) {
      this.log('Post-email detection timed out, assuming Microsoft SSO');
      return 'microsoft_sso';
    }
  }

  /**
   * Enter password on Atlassian ID password page
   */
  async _enterAtlassianPassword(password) {
    this.log('Entering Atlassian password');
    await this.page.waitForSelector(ATLASSIAN_SELECTORS.passwordInput, { visible: true, timeout: 10000 });
    await this.page.type(ATLASSIAN_SELECTORS.passwordInput, password, { delay: 30 });
    await this.page.click(ATLASSIAN_SELECTORS.passwordSubmit);
    await new Promise(resolve => setTimeout(resolve, 3000));
  }

  /**
   * Jira Server/DC native login (login.jsp)
   */
  async _enterJiraServerCredentials(username, password) {
    const masked = username.replace(/.(?=.{2})/g, '*');
    this.log(`Entering Jira Server username: ${masked}`);

    await this.page.waitForSelector('#login-form-username', { visible: true, timeout: 15000 });
    await this.page.type('#login-form-username', username, { delay: 30 });
    await this.page.waitForSelector('#login-form-password', { visible: true, timeout: 15000 });
    await this.page.type('#login-form-password', password, { delay: 30 });

    const submit = await this.page.$('#login-form-submit');
    if (submit) {
      await submit.click();
    } else {
      await this.page.keyboard.press('Enter');
    }

    // Wait for either navigation away from login.jsp or an error message.
    await Promise.race([
      this.page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 }).catch(() => {}),
      new Promise(resolve => setTimeout(resolve, 5000)),
    ]);

    const url = this.page.url();
    if (url.includes('login.jsp')) {
      // Common login error container
      const error = await this.page.$('#login-form-error, .aui-message-error, .error');
      if (error) {
        const errorText = await this.page.evaluate(el => el.textContent, error);
        throw new Error(`Jira Server login failed: ${(errorText || '').trim()}`);
      }
      throw new Error('Jira Server login did not leave login.jsp (check credentials or SSO configuration)');
    }

    this.log('Jira Server login submitted successfully');
  }

  /**
   * Enter email on Microsoft login page
   */
  async _enterMicrosoftEmail(email) {
    const maskedEmail = email.replace(/^[^@]+/, '***');
    this.log(`Entering Microsoft email: ${maskedEmail}`);

    await this.page.waitForSelector(MS_SELECTORS.emailInput, { visible: true, timeout: 10000 });
    await this.page.type(MS_SELECTORS.emailInput, email, { delay: 50 });

    const nextBtn = await this._findElement(
      MS_SELECTORS.emailNextButton, MS_SELECTORS.emailNextButtonFallback, { visible: true }
    );
    if (nextBtn) {
      await nextBtn.click();
    } else {
      await this.page.keyboard.press('Enter');
    }

    try {
      await Promise.race([
        this.page.waitForSelector(MS_SELECTORS.passwordInput, { visible: true, timeout: 10000 }),
        this.page.waitForSelector(MS_SELECTORS.usernameError, { visible: true, timeout: 10000 }),
      ]);
    } catch (e) {
      throw new Error('Timed out waiting for password page after email entry');
    }

    const emailError = await this.page.$(MS_SELECTORS.usernameError);
    if (emailError) {
      const errorText = await this.page.evaluate(el => el.textContent, emailError);
      throw new Error(`Email error: ${errorText.trim()}`);
    }

    this.log('Email accepted, password page loaded');
  }

  /**
   * Enter password on Microsoft login page
   */
  async _enterMicrosoftPassword(password, context) {
    this.log('Entering Microsoft password');

    await this.page.waitForSelector(MS_SELECTORS.passwordInput, { visible: true, timeout: 10000 });
    await this.page.type(MS_SELECTORS.passwordInput, password, { delay: 30 });

    const signInBtn = await this._findElement(
      MS_SELECTORS.passwordSubmitButton, MS_SELECTORS.passwordSubmitButtonFallback, { visible: true }
    );
    if (signInBtn) {
      await signInBtn.click();
    } else {
      await this.page.keyboard.press('Enter');
    }

    await this._waitForPostPassword();

    const passwordError = await this.page.$(MS_SELECTORS.passwordError);
    if (passwordError) {
      const errorText = await this.page.evaluate(el => el.textContent, passwordError);
      throw new Error(`Password error: ${errorText.trim()}`);
    }

    this.log('Password accepted');
  }

  async _waitForPostPassword() {
    try {
      await Promise.race([
        this.page.waitForSelector(MS_SELECTORS.mfaDisplayNumber, { visible: true, timeout: 15000 }),
        this.page.waitForSelector(MS_SELECTORS.mfaDisplayNumberFallback, { visible: true, timeout: 15000 }),
        this.page.waitForSelector(MS_SELECTORS.mfaCodeInput, { visible: true, timeout: 15000 }),
        this.page.waitForSelector(MS_SELECTORS.kmsiPage, { visible: true, timeout: 15000 }),
        this.page.waitForSelector(MS_SELECTORS.passwordError, { visible: true, timeout: 15000 }),
        this.page.waitForFunction(
          () => window.location.hostname.includes('atlassian.net') || window.location.hostname.includes('atlassian.com'),
          { timeout: 15000 }
        ),
      ]);
    } catch (e) {
      this.log('Post-password wait completed (possibly timed out)');
    }
  }

  async _handleMFA(context, mfaCode = null) {
    const numberEl = await this.page.$(MS_SELECTORS.mfaDisplayNumber)
      || await this.page.$(MS_SELECTORS.mfaDisplayNumberFallback);
    const codeInput = await this.page.$(MS_SELECTORS.mfaCodeInput);

    if (numberEl) {
      await this._handleNumberMatching(numberEl, context);
    } else if (codeInput) {
      await this._handleCodeEntry(context, mfaCode);
    } else {
      this.log('No MFA challenge detected — may have been skipped or already approved');
      return;
    }
  }

  async _handleNumberMatching(numberEl, context) {
    const number = await this.page.evaluate(el => el.textContent.trim(), numberEl);
    this.log(`MFA number matching — display number: ${number}`);

    const message = `🔐 Microsoft MFA: Approve the sign-in request on your Authenticator app.\n\nSelect number: **${number}**`;

    console.error(`\n${'='.repeat(60)}\n🔐 MFA NUMBER: ${number}\nApprove the request on your Microsoft Authenticator app.\n${'='.repeat(60)}\n`);

    if (context) {
      try {
        await context.elicit({
          message,
          requestedSchema: {
            type: 'object',
            properties: {
              acknowledged: {
                type: 'boolean',
                title: 'I have approved the request on my phone',
              },
            },
          },
        });
      } catch (e) {
        this.log(`Elicitation failed (${e.message}), logging MFA number`);
        try { await context.info(message); } catch (e2) { /* ignore */ }
      }
    }

    this.log('Waiting for MFA approval...');
    await this._waitForMFACompletion();
  }

  async _handleCodeEntry(context, mfaCode = null) {
    this.log('MFA code entry required');

    let code = mfaCode || null;

    if (!code && context) {
      try {
        const result = await context.elicit({
          message: '🔐 Microsoft MFA: Enter the verification code from your authenticator app or SMS.',
          requestedSchema: {
            type: 'object',
            properties: {
              code: {
                type: 'string',
                title: 'Verification code',
                pattern: '^[0-9]{4,8}$',
              },
            },
            required: ['code'],
          },
        });
        code = result.action === 'accept' ? result.content?.code : null;
      } catch (e) {
        this.log(`Elicitation failed: ${e.message}`);
      }
    }

    if (!code) {
      throw new Error('MFA code is required but could not be obtained. Provide it via the mfa_code parameter of the sso_login tool, or use an MCP client that supports elicitation.');
    }

    await this.page.type(MS_SELECTORS.mfaCodeInput, code, { delay: 50 });
    const verifyButton = await this.page.$(MS_SELECTORS.mfaCodeSubmit);
    if (verifyButton) {
      await verifyButton.click();
    }

    await this._waitForMFACompletion();
  }

  async _waitForMFACompletion() {
    try {
      await Promise.race([
        this.page.waitForSelector(MS_SELECTORS.kmsiPage, { visible: true, timeout: this.timeoutMs }),
        this.page.waitForFunction(
          () => !window.location.hostname.includes('login.microsoftonline.com'),
          { timeout: this.timeoutMs }
        ),
      ]);
      this.log('MFA completed');
    } catch (e) {
      throw new Error(`MFA timed out after ${this.timeoutMs / 1000}s. Please approve the request and try again.`);
    }
  }

  async _handleStaySignedIn() {
    const kmsi = await this.page.$(MS_SELECTORS.kmsiPage);
    if (kmsi) {
      this.log('Handling "Stay signed in?" prompt — clicking Yes');
      const yesButton = await this.page.$(MS_SELECTORS.staySignedInYes);
      if (yesButton) {
        await yesButton.click();
        await this.page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 }).catch(() => {});
      }
    }
  }

  /**
   * Wait for Jira session to be established after SSO
   */
  async _waitForJiraSession(context) {
    this.log('Waiting for Jira session...');

    const jiraHost = new URL(this.jiraUrl).hostname;

    try {
      await this.page.waitForFunction(
        (hostname) => window.location.hostname.includes(hostname),
        { timeout: 30000 },
        jiraHost
      );
    } catch (e) {
      const url = this.page.url();
      if (!url.includes(jiraHost)) {
        throw new Error(`Failed to reach Jira after SSO. Current URL: ${url}`);
      }
    }

    // Give a moment for cookies to settle
    await new Promise(resolve => setTimeout(resolve, 2000));
    this.log(`Jira session established. URL: ${this.page.url()}`);
  }

  /**
   * Extract session cookies from the browser
   */
  async _extractCookies() {
    this.log('Extracting session cookies');

    const cookies = await this.page.cookies();
    const cookieMap = {};
    for (const c of cookies) {
      cookieMap[c.name] = c.value;
    }

    const cloudSessionToken = cookieMap[JIRA_COOKIES.cloudSession];
    const tenantToken = cookieMap[JIRA_COOKIES.tenantToken];
    const atlToken = cookieMap[JIRA_COOKIES.atlToken];

    // Jira Server/DC cookies
    const jsessionid = cookieMap[JIRA_COOKIES.jsessionid];
    const atlassianXsrfToken = cookieMap[JIRA_COOKIES.atlassianXsrf];

    if (!cloudSessionToken && !jsessionid) {
      this.log('Available cookies:', Object.keys(cookieMap).join(', '));
      this.log('Warning: no Jira session cookie found (cloud.session.token or JSESSIONID)');
    }

    this.log('Cookies extracted successfully');
    return {
      cloud_session_token: cloudSessionToken || null,
      tenant_token: tenantToken || null,
      atl_xsrf_token: atlToken || null,
      jsessionid: jsessionid || null,
      atlassian_xsrf_token: atlassianXsrfToken || null,
      all_cookies: cookieMap,
    };
  }

  async _cleanup() {
    if (this.browser) {
      try {
        await this.browser.close();
        this.log('Browser closed');
      } catch (e) {
        this.log(`Browser close error: ${e.message}`);
      }
      this.browser = null;
      this.page = null;
    }

    if (this._userDataDir) {
      try {
        fs.rmSync(this._userDataDir, { recursive: true, force: true });
        this.log('Temp user data dir cleaned up');
      } catch (e) {
        this.log(`Cleanup warning: ${e.message}`);
      }
      this._userDataDir = null;
    }
  }
}

module.exports = JiraAuthFlow;
