# Jira MCP Provider

A stateful MCP provider for interacting with Jira (Cloud/Server): issues, comments, transitions, projects, boards, and sprints.

## Quick Start

```bash
# Start the MCP server (Jira only)
node tools/nodemcp/cli.js --layers jira

# Or with multiple providers
node tools/nodemcp/cli.js --layers splunk,jira
```

**MCP client configuration (e.g., VS Code `settings.json`):**

```json
{
  "command": "node",
  "args": ["path/to/ai-common/tools/nodemcp/cli.js", "--layers", "jira"]
}
```

## Configuration

Settings are resolved with the following priority (highest wins):

1. Tool parameters
2. Environment variables
3. Config file (`.jira_mcp.local.yaml`)

### Environment Variables

| Variable | Description | Required |
|---|---|---|
| `JIRA_HOST` | Jira base URL (e.g., `https://your-domain.atlassian.net`) | Yes (or config) |
| `JIRA_EMAIL` | Email (for API token / Basic auth) | No |
| `JIRA_API_TOKEN` | API token (for API token / Basic auth) | No |
| `JIRA_BEARER_TOKEN` | Bearer token (alternative auth) | No |
| `JIRA_SSO_EMAIL` | SSO email for Microsoft Entra ID login | No |
| `JIRA_SSO_PASSWORD` | SSO password (held in memory only) | No |

### Config File (`.jira_mcp.local.yaml`)

The provider searches for this file in:
1. Current working directory
2. Project root (two levels up from `tools/mcps/jira/`)
3. Home directory (`$HOME` / `$USERPROFILE`)

> Security note: Do **NOT** store plaintext passwords in config files on disk. Prefer `JIRA_SSO_PASSWORD` (environment variable), MCP elicitation, or the console prompt.

```yaml
jira:
  host: https://your-domain.atlassian.net
  verify_ssl: true
  sso:
    email: user@company.com
    # Do NOT store passwords here. Use JIRA_SSO_PASSWORD or you will be prompted.
    headless: true
    timeout_seconds: 120
  session:                             # auto-populated after successful SSO login (sensitive)
    cloud_session_token: <auto>
    tenant_token: <auto>
    atl_xsrf_token: <auto>
    obtained_at: <auto>
  auth:                                # optional alternative to SSO
    email: user@company.com
    api_token: <api-token>
    bearer_token: <bearer-token>
keepalive:
  enabled: true
  interval_seconds: 300
```

## Authentication

The provider supports:
- **SSO via browser automation** (`jira_sso_login`) using `puppeteer-core`
- **API token auth** (`jira_authenticate`) using Basic auth (`email:apiToken`)
- **Bearer token auth** (`jira_authenticate bearer_token=...`)

> Note: Jira Cloud API token auth is often the simplest option for automation; SSO is useful when you need to reuse a web session or when API tokens are unavailable.

## Available Tools (25)

### Session Management
- `start_session`
- `reset_session`
- `sso_login`
- `authenticate`

### Issue Operations
- `get_issue`
- `search_issues`
- `create_issue`
- `update_issue`
- `add_comment`
- `get_comments`
- `transition_issue`
- `assign_issue`

### Linking & Relations
- `link_issues`
- `get_issue_links`
- `get_subtasks`

### Sprint & Board
- `get_boards`
- `get_sprints`
- `get_sprint_issues`
- `move_to_sprint`

### Project & Metadata
- `get_projects`
- `get_project_statuses`
- `get_issue_types`

### User & Workflow
- `get_transitions`
- `find_users`
- `get_changelogs`

## Usage Examples

```text
# Start session (host from env/config)
jira_start_session

# Authenticate with API token
jira_authenticate email="user@company.com" api_token="..."

# Search with JQL
jira_search_issues jql="project = PROJ AND statusCategory != Done ORDER BY updated DESC"

# Get issue
jira_get_issue key="PROJ-123"

# Add comment
jira_add_comment key="PROJ-123" comment="Investigating this now."

# Transitions
jira_get_transitions key="PROJ-123"
jira_transition_issue key="PROJ-123" transition_id="31"
```
