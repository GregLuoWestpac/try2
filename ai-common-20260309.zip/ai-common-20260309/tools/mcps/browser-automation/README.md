# Browser Automation MCP Provider

Remote control browsers (Edge/Chrome) using MCP (Model Context Protocol).

## Features

- **Navigation**: Navigate to URLs, go back/forward, reload
- **Element Interaction**: Click, type, hover using CSS/XPath selectors
- **Content Extraction**: Get text, HTML, attributes, take screenshots
- **Console Messages**: Capture and read browser console output
- **Cookies**: Get, set, and delete cookies
- **JavaScript Execution**: Run arbitrary JavaScript in page context
- **Page Information**: Get title, URL, viewport info

## Prerequisites

Microsoft Edge or Google Chrome must be installed. The provider uses puppeteer-core to connect to Chromium-based browsers.

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `EDGE_EXECUTABLE_PATH` | Path to browser executable | Auto-detected |
| `EDGE_HEADLESS` | Run in headless mode | `false` |
| `EDGE_DEVTOOLS` | Open DevTools automatically | `false` |

### Usage with NodeMCP

```bash
# Start the MCP server with Browser Automation provider
node tools/nodemcp/cli.js --layers browser-automation
```

### Client Configuration

**VS Code / Copilot:**
```json
{
  "mcpServers": {
    "browser-automation": {
      "command": "node",
      "args": ["path/to/tools/nodemcp/cli.js", "--layers", "browser-automation"]
    }
  }
}
```

## Tools

### Session Management

- `start_session` - Launch Edge browser and create a session
- `close_session` - Close the browser session
- `get_session_info` - Get current session information

### Navigation

- `navigate` - Navigate to a URL
- `go_back` - Navigate back in history
- `go_forward` - Navigate forward in history
- `reload` - Reload the current page

### Element Interaction

- `click` - Click an element by selector
- `type` - Type text into an element
- `hover` - Hover over an element
- `focus` - Focus an element
- `select` - Select option(s) in a dropdown
- `clear` - Clear input field content

### Content & Information

- `get_text` - Get text content of element(s)
- `get_html` - Get HTML content of element(s)
- `get_attribute` - Get attribute value of an element
- `get_page_info` - Get page title, URL, viewport
- `screenshot` - Take a screenshot (full page or element)
- `get_elements` - Query multiple elements and get their info

### Console & Network

- `get_console_messages` - Get captured console messages
- `clear_console_messages` - Clear captured console messages

### Cookies

- `get_cookies` - Get cookies (all or by name)
- `set_cookie` - Set a cookie
- `delete_cookies` - Delete cookies

### JavaScript

- `evaluate` - Execute JavaScript in page context

### Waiting

- `wait_for_selector` - Wait for element to appear
- `wait_for_navigation` - Wait for navigation to complete
- `wait` - Wait for specified milliseconds

## Examples

### Basic Navigation and Interaction

```javascript
// Start browser session
await browser_automation_start_session({ headless: false });

// Navigate to a page
await browser_automation_navigate({ url: 'https://example.com' });

// Click a button
await browser_automation_click({ selector: '#submit-button' });

// Type into a form field
await browser_automation_type({ selector: '#search-input', text: 'hello world' });

// Get text content
const text = await browser_automation_get_text({ selector: '.result' });

// Take a screenshot
const screenshot = await browser_automation_screenshot({ full_page: true });
```

### Working with Cookies

```javascript
// Get all cookies
const cookies = await browser_automation_get_cookies({});

// Set a cookie
await browser_automation_set_cookie({ 
  name: 'session_id', 
  value: 'abc123',
  domain: 'example.com'
});

// Delete specific cookies
await browser_automation_delete_cookies({ names: ['session_id'] });
```

### Console Messages

```javascript
// Navigate to a page that logs to console
await browser_automation_navigate({ url: 'https://example.com' });

// Get console messages
const messages = await browser_automation_get_console_messages({});
// Returns: [{ type: 'log', text: '...', timestamp: '...' }, ...]
```

### JavaScript Evaluation

```javascript
// Execute JavaScript and get result
const result = await browser_automation_evaluate({
  expression: 'document.querySelectorAll("a").length'
});
// Returns: { result: 42 }

// Execute with arguments
const result = await browser_automation_evaluate({
  expression: '(a, b) => a + b',
  args: [1, 2]
});
// Returns: { result: 3 }
```
