/**
 * Browser Automation MCP Provider
 * 
 * Remote control browsers (Edge/Chrome) via MCP.
 * Uses puppeteer-core to connect to Chromium-based browsers.
 */

const BaseProvider = require('../../nodemcp/core/BaseProvider');
const puppeteer = require('puppeteer-core');
const path = require('path');
const fs = require('fs');

class BrowserAutomationProvider extends BaseProvider {
  constructor(options = {}) {
    super(options);
    this.setStateful(true);
    
    this.executablePath = options.executablePath || process.env.EDGE_EXECUTABLE_PATH || this._findEdge();
    this.defaultHeadless = options.headless ?? (process.env.EDGE_HEADLESS === 'true');
    this.defaultDevtools = options.devtools ?? (process.env.EDGE_DEVTOOLS === 'true');
    
    this.browser = null;
    this.page = null;
    this.consoleMessages = [];
  }

  _findEdge() {
    const paths = process.platform === 'win32' ? [
      'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
      'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
      `${process.env.LOCALAPPDATA}\\Microsoft\\Edge\\Application\\msedge.exe`
    ] : process.platform === 'darwin' ? [
      '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge'
    ] : [
      '/usr/bin/microsoft-edge',
      '/usr/bin/microsoft-edge-stable'
    ];
    
    for (const p of paths) {
      if (fs.existsSync(p)) return p;
    }
    return paths[0];
  }

  async _getPage(context) {
    if (context?.session) {
      const page = context.sessionManager?.getProviderData(context.session.id, 'browser-automation', 'page');
      if (page) return page;
    }
    if (this.page) return this.page;
    throw new Error('No browser session. Call start_session first.');
  }

  async _getBrowser(context) {
    if (context?.session) {
      return context.sessionManager?.getProviderData(context.session.id, 'browser-automation', 'browser');
    }
    return this.browser;
  }

  async _getConsoleMessages(context) {
    if (context?.session) {
      return context.sessionManager?.getProviderData(context.session.id, 'browser-automation', 'consoleMessages') || [];
    }
    return this.consoleMessages;
  }

  async initialize() {
    this.log('Initializing Browser Automation provider');
    this.log(`Edge path: ${this.executablePath}`);

    // Session Management
    this.registerTool({
      name: 'start_session',
      description: 'Launch Edge browser and create a new session.',
      inputSchema: {
        type: 'object',
        properties: {
          headless: this.booleanProp('Run in headless mode (default: false)'),
          devtools: this.booleanProp('Open DevTools automatically'),
          width: this.numberProp('Viewport width (default: 1280)'),
          height: this.numberProp('Viewport height (default: 720)'),
          url: this.stringProp('Initial URL to navigate to')
        }
      },
      handler: async (args, context) => {
        try {
          const browser = await puppeteer.launch({
            executablePath: this.executablePath,
            headless: args.headless ?? this.defaultHeadless,
            devtools: args.devtools ?? this.defaultDevtools,
            defaultViewport: { width: args.width || 1280, height: args.height || 720 }
          });

          const page = await browser.newPage();
          const consoleMessages = [];

          page.on('console', msg => {
            consoleMessages.push({
              type: msg.type(),
              text: msg.text(),
              timestamp: new Date().toISOString()
            });
          });

          if (context?.session) {
            context.sessionManager?.setProviderData(context.session.id, 'browser-automation', 'browser', browser);
            context.sessionManager?.setProviderData(context.session.id, 'browser-automation', 'page', page);
            context.sessionManager?.setProviderData(context.session.id, 'browser-automation', 'consoleMessages', consoleMessages);
          } else {
            this.browser = browser;
            this.page = page;
            this.consoleMessages = consoleMessages;
          }

          if (args.url) await page.goto(args.url, { waitUntil: 'domcontentloaded' });

          return { status: 'started', url: page.url() };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'close_session',
      description: 'Close the browser session.',
      inputSchema: { type: 'object', properties: {} },
      handler: async (args, context) => {
        try {
          const browser = await this._getBrowser(context);
          if (browser) await browser.close();
          
          if (context?.session) {
            context.sessionManager?.setProviderData(context.session.id, 'browser-automation', 'browser', null);
            context.sessionManager?.setProviderData(context.session.id, 'browser-automation', 'page', null);
          } else {
            this.browser = null;
            this.page = null;
          }
          return { status: 'closed' };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'get_session_info',
      description: 'Get current browser session information.',
      inputSchema: { type: 'object', properties: {} },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          const viewport = page.viewport();
          return {
            url: page.url(),
            title: await page.title(),
            viewport: { width: viewport.width, height: viewport.height }
          };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    // Navigation
    this.registerTool({
      name: 'navigate',
      description: 'Navigate to a URL.',
      inputSchema: {
        type: 'object',
        properties: {
          url: this.stringProp('URL to navigate to', { required: true }),
          wait_until: this.enumProp('When to consider navigation complete', ['load', 'domcontentloaded', 'networkidle0', 'networkidle2'])
        },
        required: ['url']
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          await page.goto(args.url, { waitUntil: args.wait_until || 'domcontentloaded' });
          return { status: 'navigated', url: page.url(), title: await page.title() };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'go_back',
      description: 'Navigate back in browser history.',
      inputSchema: { type: 'object', properties: {} },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          await page.goBack();
          return { status: 'navigated_back', url: page.url() };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'go_forward',
      description: 'Navigate forward in browser history.',
      inputSchema: { type: 'object', properties: {} },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          await page.goForward();
          return { status: 'navigated_forward', url: page.url() };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'reload',
      description: 'Reload the current page.',
      inputSchema: { type: 'object', properties: {} },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          await page.reload();
          return { status: 'reloaded', url: page.url() };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    // Element Interaction
    this.registerTool({
      name: 'click',
      description: 'Click an element by CSS selector or XPath.',
      inputSchema: {
        type: 'object',
        properties: {
          selector: this.stringProp('CSS selector or XPath (prefix with xpath=)', { required: true }),
          button: this.enumProp('Mouse button', ['left', 'right', 'middle']),
          click_count: this.numberProp('Number of clicks (1=single, 2=double)')
        },
        required: ['selector']
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          const selector = args.selector.startsWith('xpath=') ? `::-p-xpath(${args.selector.slice(6)})` : args.selector;
          await page.click(selector, { button: args.button || 'left', clickCount: args.click_count || 1 });
          return { status: 'clicked', selector: args.selector };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'type',
      description: 'Type text into an input element.',
      inputSchema: {
        type: 'object',
        properties: {
          selector: this.stringProp('CSS selector of input element', { required: true }),
          text: this.stringProp('Text to type', { required: true }),
          delay: this.numberProp('Delay between keystrokes in ms'),
          clear_first: this.booleanProp('Clear existing content before typing')
        },
        required: ['selector', 'text']
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          
          // Wait for element to be ready
          await page.waitForSelector(args.selector, { visible: true, timeout: 5000 });
          
          if (args.clear_first) {
            await page.click(args.selector, { clickCount: 3 });
            await page.keyboard.press('Backspace');
            await page.waitForFunction(
              (sel) => document.querySelector(sel)?.value === '',
              { timeout: 2000 },
              args.selector
            ).catch(() => {}); // Ignore if element doesn't have value property
          }
          
          await page.type(args.selector, args.text, { delay: args.delay || 0 });
          
          // Wait for the value to be set
          await page.waitForFunction(
            (sel, text) => {
              const el = document.querySelector(sel);
              return el && (el.value?.includes(text) || el.textContent?.includes(text));
            },
            { timeout: 5000 },
            args.selector,
            args.text
          ).catch(() => {}); // Some elements don't have value
          
          return { status: 'typed', selector: args.selector, text: args.text };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'hover',
      description: 'Hover over an element.',
      inputSchema: {
        type: 'object',
        properties: {
          selector: this.stringProp('CSS selector', { required: true })
        },
        required: ['selector']
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          await page.hover(args.selector);
          return { status: 'hovered', selector: args.selector };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'focus',
      description: 'Focus an element.',
      inputSchema: {
        type: 'object',
        properties: {
          selector: this.stringProp('CSS selector', { required: true })
        },
        required: ['selector']
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          await page.focus(args.selector);
          return { status: 'focused', selector: args.selector };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'select',
      description: 'Select option(s) in a dropdown.',
      inputSchema: {
        type: 'object',
        properties: {
          selector: this.stringProp('CSS selector of select element', { required: true }),
          values: this.arrayProp('Values to select', { type: 'string' }, { required: true })
        },
        required: ['selector', 'values']
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          const selected = await page.select(args.selector, ...args.values);
          return { status: 'selected', selector: args.selector, selected };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'press_key',
      description: 'Press a keyboard key.',
      inputSchema: {
        type: 'object',
        properties: {
          key: this.stringProp('Key to press (e.g., Enter, Tab, Escape, ArrowDown)', { required: true })
        },
        required: ['key']
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          await page.keyboard.press(args.key);
          return { status: 'pressed', key: args.key };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    // Content & Information
    this.registerTool({
      name: 'get_text',
      description: 'Get text content of element(s).',
      inputSchema: {
        type: 'object',
        properties: {
          selector: this.stringProp('CSS selector', { required: true }),
          all: this.booleanProp('Get text from all matching elements')
        },
        required: ['selector']
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          if (args.all) {
            const texts = await page.$$eval(args.selector, els => els.map(el => el.textContent.trim()));
            return { texts, count: texts.length };
          } else {
            const text = await page.$eval(args.selector, el => el.textContent.trim());
            return { text };
          }
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'get_html',
      description: 'Get HTML content of an element.',
      inputSchema: {
        type: 'object',
        properties: {
          selector: this.stringProp('CSS selector (omit for full page)'),
          outer: this.booleanProp('Get outer HTML including element itself (default: inner)')
        }
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          if (!args.selector) {
            const html = await page.content();
            return { html };
          }
          const prop = args.outer ? 'outerHTML' : 'innerHTML';
          const html = await page.$eval(args.selector, (el, p) => el[p], prop);
          return { html };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'get_attribute',
      description: 'Get attribute value of an element.',
      inputSchema: {
        type: 'object',
        properties: {
          selector: this.stringProp('CSS selector', { required: true }),
          attribute: this.stringProp('Attribute name', { required: true })
        },
        required: ['selector', 'attribute']
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          const value = await page.$eval(args.selector, (el, attr) => el.getAttribute(attr), args.attribute);
          return { attribute: args.attribute, value };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'get_page_info',
      description: 'Get page title, URL, and viewport information.',
      inputSchema: { type: 'object', properties: {} },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          const viewport = page.viewport();
          return {
            url: page.url(),
            title: await page.title(),
            viewport: { width: viewport.width, height: viewport.height }
          };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'screenshot',
      description: 'Take a screenshot of the page or an element.',
      inputSchema: {
        type: 'object',
        properties: {
          selector: this.stringProp('CSS selector to screenshot specific element'),
          full_page: this.booleanProp('Capture full scrollable page'),
          path: this.stringProp('File path to save screenshot'),
          format: this.enumProp('Image format', ['png', 'jpeg', 'webp'])
        }
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          const options = {
            fullPage: args.full_page,
            type: args.format || 'png',
            encoding: args.path ? undefined : 'base64'
          };
          if (args.path) options.path = args.path;

          let data;
          if (args.selector) {
            const element = await page.$(args.selector);
            if (!element) return { error: 'Element not found' };
            data = await element.screenshot(options);
          } else {
            data = await page.screenshot(options);
          }

          if (args.path) {
            return { status: 'saved', path: args.path };
          }
          return { base64: data, format: options.type };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'get_elements',
      description: 'Query multiple elements and get their basic info.',
      inputSchema: {
        type: 'object',
        properties: {
          selector: this.stringProp('CSS selector', { required: true }),
          limit: this.numberProp('Max elements to return (default: 20)')
        },
        required: ['selector']
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          const limit = args.limit || 20;
          const elements = await page.$$eval(args.selector, (els, max) => {
            return els.slice(0, max).map((el, i) => ({
              index: i,
              tagName: el.tagName.toLowerCase(),
              id: el.id || null,
              className: el.className || null,
              text: el.textContent?.trim().slice(0, 100) || null
            }));
          }, limit);
          return { count: elements.length, elements };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    // Console Messages
    this.registerTool({
      name: 'get_console_messages',
      description: 'Get captured browser console messages.',
      inputSchema: {
        type: 'object',
        properties: {
          type: this.enumProp('Filter by message type', ['log', 'info', 'warn', 'error', 'debug']),
          limit: this.numberProp('Max messages to return')
        }
      },
      handler: async (args, context) => {
        try {
          let messages = await this._getConsoleMessages(context);
          if (args.type) messages = messages.filter(m => m.type === args.type);
          if (args.limit) messages = messages.slice(-args.limit);
          return { count: messages.length, messages };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'clear_console_messages',
      description: 'Clear captured console messages.',
      inputSchema: { type: 'object', properties: {} },
      handler: async (args, context) => {
        try {
          if (context?.session) {
            context.sessionManager?.setProviderData(context.session.id, 'browser-automation', 'consoleMessages', []);
          } else {
            this.consoleMessages.length = 0;
          }
          return { status: 'cleared' };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    // Cookies
    this.registerTool({
      name: 'get_cookies',
      description: 'Get browser cookies.',
      inputSchema: {
        type: 'object',
        properties: {
          urls: this.arrayProp('URLs to get cookies for (default: current page)', { type: 'string' })
        }
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          const cookies = await page.cookies(...(args.urls || []));
          return { count: cookies.length, cookies };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'set_cookie',
      description: 'Set a browser cookie.',
      inputSchema: {
        type: 'object',
        properties: {
          name: this.stringProp('Cookie name', { required: true }),
          value: this.stringProp('Cookie value', { required: true }),
          domain: this.stringProp('Cookie domain'),
          path: this.stringProp('Cookie path'),
          expires: this.numberProp('Expiration timestamp (seconds since epoch)'),
          http_only: this.booleanProp('HTTP only flag'),
          secure: this.booleanProp('Secure flag'),
          same_site: this.enumProp('SameSite attribute', ['Strict', 'Lax', 'None'])
        },
        required: ['name', 'value']
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          const cookie = {
            name: args.name,
            value: args.value,
            domain: args.domain,
            path: args.path || '/',
            expires: args.expires,
            httpOnly: args.http_only,
            secure: args.secure,
            sameSite: args.same_site
          };
          Object.keys(cookie).forEach(k => cookie[k] === undefined && delete cookie[k]);
          await page.setCookie(cookie);
          return { status: 'set', cookie: { name: args.name, value: args.value } };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'delete_cookies',
      description: 'Delete browser cookies.',
      inputSchema: {
        type: 'object',
        properties: {
          names: this.arrayProp('Cookie names to delete (omit to delete all)', { type: 'string' })
        }
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          if (args.names && args.names.length > 0) {
            const cookies = await page.cookies();
            const toDelete = cookies.filter(c => args.names.includes(c.name));
            await page.deleteCookie(...toDelete);
            return { status: 'deleted', count: toDelete.length };
          } else {
            const client = await page.createCDPSession();
            await client.send('Network.clearBrowserCookies');
            return { status: 'cleared_all' };
          }
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    // JavaScript Evaluation
    this.registerTool({
      name: 'evaluate',
      description: 'Execute JavaScript in the page context.',
      inputSchema: {
        type: 'object',
        properties: {
          expression: this.stringProp('JavaScript expression or function to evaluate', { required: true }),
          args: this.arrayProp('Arguments to pass to function', {})
        },
        required: ['expression']
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          const fn = new Function('return ' + args.expression)();
          const result = typeof fn === 'function' 
            ? await page.evaluate(fn, ...(args.args || []))
            : await page.evaluate(args.expression);
          return { result };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    // Waiting
    this.registerTool({
      name: 'wait_for_selector',
      description: 'Wait for an element to appear in the DOM.',
      inputSchema: {
        type: 'object',
        properties: {
          selector: this.stringProp('CSS selector', { required: true }),
          timeout: this.numberProp('Timeout in milliseconds (default: 30000)'),
          visible: this.booleanProp('Wait for element to be visible'),
          hidden: this.booleanProp('Wait for element to be hidden/removed')
        },
        required: ['selector']
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          await page.waitForSelector(args.selector, {
            timeout: args.timeout || 30000,
            visible: args.visible,
            hidden: args.hidden
          });
          return { status: 'found', selector: args.selector };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'wait_for_navigation',
      description: 'Wait for navigation to complete.',
      inputSchema: {
        type: 'object',
        properties: {
          timeout: this.numberProp('Timeout in milliseconds (default: 30000)'),
          wait_until: this.enumProp('When to consider navigation complete', ['load', 'domcontentloaded', 'networkidle0', 'networkidle2'])
        }
      },
      handler: async (args, context) => {
        try {
          const page = await this._getPage(context);
          await page.waitForNavigation({
            timeout: args.timeout || 30000,
            waitUntil: args.wait_until || 'domcontentloaded'
          });
          return { status: 'navigation_complete', url: page.url() };
        } catch (error) {
          return { error: error.message };
        }
      }
    });

    this.registerTool({
      name: 'wait',
      description: 'Wait for specified milliseconds.',
      inputSchema: {
        type: 'object',
        properties: {
          ms: this.numberProp('Milliseconds to wait', { required: true })
        },
        required: ['ms']
      },
      handler: async (args, context) => {
        await new Promise(r => setTimeout(r, args.ms));
        return { status: 'waited', ms: args.ms };
      }
    });

    this.log(`Registered ${this.tools.length} Browser Automation tools`);
  }

  async shutdown() {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
      this.page = null;
    }
  }
}

module.exports = BrowserAutomationProvider;
