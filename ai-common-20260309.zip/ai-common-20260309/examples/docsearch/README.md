# DocSearch Examples

Example content and pre-built indexes for the [DocSearch MCP Provider](../../tools/mcps/docsearch/).

## Contents

### `solution-designs/`

A collection of solution design documents covering core banking, entitlements, payments, and workflow domains. These serve as:

- **Example input** — demonstrates what kind of content can be indexed
- **Shared reference** — teams can copy these to their own projects for semantic search

### `store.idx` / `store.docs`

Pre-built search index generated from the solution-designs content. Allows immediate querying without running ingestion first.

## Usage

### Search the pre-built index

```bash
# Start docsearch MCP server pointing at the example index
cd tools/nodemcp
DOCSEARCH_STORE_PATH=../../examples/docsearch node cli.js --provider ../mcps/docsearch --verbose
```

### Build your own index from these documents

```bash
cd tools/mcps/docsearch
node ingest-dir.js --src ../../../examples/docsearch/solution-designs --source-name solution-designs --store ./my-index
```

### Ingest your own content

```bash
cd tools/mcps/docsearch
node ingest-dir.js --src /path/to/your/documents --source-name my-project-docs --store ./my-index
```

## Adding More Example Content

Create a new subdirectory alongside `solution-designs/`:

```
examples/docsearch/
├── solution-designs/     # existing
├── api-specs/            # your new collection
├── store.idx             # binary index
└── store.docs            # document content
```

Then ingest it:

```bash
node ingest-dir.js --src ../../../examples/docsearch/api-specs --source-name api-specs
```
