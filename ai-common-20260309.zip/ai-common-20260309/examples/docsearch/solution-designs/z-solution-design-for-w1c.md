# z. Solution design for W1C

## Table of Contents
- [Vision](#vision)
- [Version control in Confluence](#version-control-in-confluence)
- [Repository for raw material](#repository-for-raw-material)
- [How to deal with updates](#how-to-deal-with-updates)
- [Solution designer responsibility](#solution-designer-responsibility)
- [SELC RACI responsibility for Solution Designers](#selc-raci-responsibility-for-solution-designers)
- [Detailed Technical Design (DTD)](#detailed-technical-design-dtd)
- [Program details](#program-details)
- [Recruitment template](#recruitment-template)

---

## Vision

Solution design is the most current version from a design perspective.

**Solution design:**
- Tells a story end to end where people can follow the flow: Sequence diagram
- Explains each component: Description of why they are needed
- Only contains the sections that are relevant to the specific design. This means that there are no empty sections or sections included but filled in with the text N/A
- Template found here: 01. What to cover in Solution Design
- Captures what is relevant from a SELC perspective but follows it to the intent rather than the word

---

## Version control in Confluence

Confluence history will be used for version control. Comments will be left at the following timings:

### When a design is ready to be reviewed
The following items will be captured:
- Release
- Status: In Review
- High-level as to what is changing as a part of the release

### Updated based on the review
The following items will be captured:
- Release
- What has been updated

### When a design has been approved
The following items will be captured:
- Release
- Status: Approved

> There is no need to leave a comment when the design is In Progress.

---

## Repository for raw material

- All diagrams either on a location in Confluence
- GitBash repository

---

## How to deal with updates

When the design changes then the old version can be added into an expand section - people reading the page can then expand this to read the section.

Depending on the use case this might cover all of the design (if the changes are made all over the place) or it might be sufficient to only do this for the section that is changing if only 2-3 sections are changing.

This will be up to the discretion of the Solution designer to make this call - can of course be done after consulting their colleagues to come up with the best approach.

---

## Solution designer responsibility

For CCMP since it's a project over $1M, Solution designers have the following responsibility:

| Responsible | Consulted | Informed |
|-------------|-----------|----------|
| For ensuring completeness of the Deliverable | To provide input, Review the deliverable | Of the deliverable |

### Detailed Technical Design Templates

| Responsible | Consulted | Informed |
|-------------|-----------|----------|
| Detailed Technical Design, DTD: Word, Prototype Evaluation Report | Budgetary Guidance, Proof of Concept, Non-Functional Requirements Document (if applicable), Non-TEP Estimate, Functional Specification Document | Architecture Change Definition, Solutions Options, Infrastructure Technical Solution Architecture (if applicable) |

---

## SELC RACI responsibility for Solution Designers

Responsibility for Solution designer according to: SELC RACI (Projects over $1M)

> Plus sign probably means "if applicable"

| Phase | Deliverable | Role | RACI | RACI - Longer Description |
|-------|-------------|------|------|---------------------------|
| Initiation | Architecture Change Definition | Solution Designer | I | Informed of the deliverable |
| Initiation | Budgetary Guidance | Solution Designer | C | Consulted to provide input and review the deliverable |
| Initiation | Infrastructure Technical Solution Architecture | Solution Designer | I+ | Informed of the deliverable |
| Initiation | Non-Functional Requirements Document | Solution Designer | C+ | Consulted to provide input and review the deliverable |
| Initiation | Non-TEP Estimate | Solution Designer | C+ | Consulted to provide input and review the deliverable |
| Initiation | Proof of Concept | Solution Designer | C | Consulted to provide input and review the deliverable |
| Initiation | Solutions Options | Solution Designer | I | Informed of the deliverable |
| Design | Detailed Technical Design | Solution Designer | R | Responsible for ensuring completeness of the Deliverable |
| Design | Functional Specification Document | Solution Designer | C+ | Consulted to provide input and review the deliverable |
| Design | Prototype Evaluation Report | Solution Designer | R | Responsible for ensuring completeness of the Deliverable |

---

## Detailed Technical Design (DTD)

DTD is mandatory for all projects except for infrastructure only project that can use the ITSA.

See:
- 2.1 Deliverables#2.1Deliverables-2.1DTD
- 3.2 Deliverables#3.2Deliverables-3.2DTD

---

## Program details

| Field | Value |
|-------|-------|
| Program Name | Corporate Cash Management Platform |
| Project | Corporate Cash Management Platform Tech |
| Project ID | PR223065 |
| Project Cost Centre | 163344 |
| Investment ID | INS223056 |

---

## Recruitment template

### Rationale
We need solution designers to help with doing solution design within the Cash platform program.

### Impact if not approved
Inability to deliver on Cash platform program to the project planned milestones.

### Deliverables

Solution designer will be accountable for end to end design to support the technical architecture definition. Responsibilities will include:

- Liaising with the product owners and delivery lead to ensure that the scope of the feature are deliverable components
- Draft and get approval for detailed technical design (e2e) - including feedback from various stakeholders and engaging with vendors
- Ensure that the design meets business requirements and aligns to technical solution architecture
- Ensure that any issues discovered during design are captured and resolved
- Take ownership for driving decisions that are needed to complete the design
- Participate in review sessions of other solution designers work and give feedback using Confluence
- Evaluate risks to the integrity of solutions including availability, performance, servicing and compliance of the business and technology services impacted
