# Account Reconciliation v1.0

| Version | 32 |
|---------|-----|
| Status | COMPLETED |
| Baseline Date | 23 Jun 2025 |

## Glossary

| Abbreviation | Expansion |
|--------------|-----------|
| GCM | Group Customer Master |
| AR | Arrangement |
| BaaS | Banking-as-a-Service |
| CCMP | Corporate Cash Management Platform |
| GCM-I | Group Customer Master - Informatica |

## Overview

- Account data in GCM should be in synchronization with data in 10x
- Data in these systems should be reconciled at predefined frequencies to ensure account data in GCM is latest
- As part of resynchronization flow, GCM-I only updates account data in GCM
- Exceptions will be logged in GCM in case account has to be created in this flow

## Scope

| Ref | Description |
|-----|-------------|
| S-001 | Account Reconciliation (ART-1962) |
| S-002 | Monthly Reconciliation (10x - GCM) |

## Assumptions

| Ref | Description |
|-----|-------------|
| A-001 | Subscriptions of yet to be established customers of other brands in 10x will be included in AR file |

## Key Design Decisions

| Ref | Decision | Rationale |
|-----|----------|-----------|
| KDD-01 | Segregation of data between BaaS and CCMP | GCM will define new patterns for identifier fields in the files for CCMP platform |

## Solution Design

### Block Diagram

Account Resync for Beta Release Block Diagram shows the data flow between 10x, Sterling, and GCM.

## Integration Impacts

| Source | Type | Destination | Frequency | Details |
|--------|------|-------------|-----------|---------|
| 10x | Batch | Sterling | Daily | New folders created in Sterling for 10x to place files |
| Sterling | Batch | GCM | Daily | New folders created in GCM for Sterling to place files |

## Application/System Changes

| System | Change Details |
|--------|----------------|
| 10x | Generate and transfer AR file as per design & requirements |
| Sterling | Transfer files to new location, create directories |
| GCM | Create directories, process files to load data into GCM |

## Error Handling

| Error Scenario | Failure Point | Severity | Behaviour | Remediation |
|----------------|---------------|----------|-----------|-------------|
| File Generation Failure | 10x | ERROR | Sterling and GCM don't receive files as per SLAs | 10x Support raises Zendesk ticket including CCMP Ops team |
| Location Access Failure | Sterling | ERROR | 10x can't access Sterling location | 10x Support contacts CCMP Ops team |
| Location Access Failure | GCM | ERROR | Sterling can't access GCM location | Sterling Ops works with GCM Ops |
| Files' Syntax Issue | 10x | ERROR | Format/structure not as per requirements | GCM Ops notifies CCMP Ops |
| Account Record Creation | GCM-I | ERROR | Couldn't identify account record in GCM | GCM-I logs exception and proceeds |
| Provisioned Status Record | GCM-I | ERROR | Record with "Provisioned" status found | GCM-I logs exception and proceeds |

## Key Fields

| File Name | Field Name | Description |
|-----------|------------|-------------|
| AR IFF File | AR_NM | Not populated |
| AR IFF File | AR_ALIAS_NM | Subscription name populated |
| AR IFF File | AR_LCS_TP_ID | Defaults to "Active" or "Inactive" based on mapping |

## File Specifications

| Source | Destination | Details |
|--------|-------------|---------|
| 10x | GCM | Format and syntax of AR file same as BaaS files |
