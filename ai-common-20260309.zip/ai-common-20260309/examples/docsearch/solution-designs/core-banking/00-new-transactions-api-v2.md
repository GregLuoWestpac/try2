# New Transactions API v2

## Usage Notes

`PUT /v2/transactions/{correlationId}` - This endpoint provides the capability to create transactions on accounts.

## Definition

### Account Types

- **Customer Account** - The Account which a customer/s holds
- **Internal Accounts**
  - **Suspense** - Used where a payment has not reached terminal status. The payment has encountered a temporary holding position until it can be resolved to a Customer Account or applied to P&L
  - **Nostro** - Represents a tracked balance on an account that is representative of a holding off-platform (e.g. Scheme Holding)

### Principles

1. **Two-sided transactions**: Movement of funds where both Credit and Debit sides are known and both legs are present in the atomic invocation:
   - Customer (Dr) ↔ Customer (Cr)
   - Suspense (Dr) → Customer (Cr)
   - Suspense (Dr) ↔ Suspense (Cr)

2. **One-sided transactions**: Movement of funds where a Nostro is involved (e.g. Scheme Holding), only one leg is present in the atomic interaction:
   - Customer (Dr/Cr)
   - Suspense (Dr/Cr)

The Ledger provides a declarative means to ensure that single sided transactions can be standardised across all tenancies.

## Request Interface Specification

### Generic Headers & Parameters

| Parameter | Description |
|-----------|-------------|
| correlationKey | UUID representing the collection of transactions on this atomic interaction |
| Posted-Timestamp | n/a |
| balanceCheck | True - Used to ensure Customer account has sufficient available balance before Dr |
| Idempotency-Key | UUID representing the retry-safe mechanism for timeout/unknown failures |

## Two-Sided Transactions

### Scenarios

| Scenario | Description | API Template | Debit Scheme | Debit Type | Credit Scheme | Credit Type |
|----------|-------------|--------------|--------------|------------|---------------|-------------|
| On-Me | CCMP customer transferring funds between their own accounts | Customer to Customer | BOOK | ACCT | BOOK | ACCT |
| On-Platform | CCMP customer paying funds to a different CCMP customer | Customer to Customer | BOOK | BKTR | BOOK | BKTR |
| On-Platform Return | Solicited return request from one CCMP customer to another | Customer to Customer | BOOK | RTR | BOOK | RTR |
| NPP To-Us Exception | Incoming NPP payment from suspense to customer | Suspense to CR Customer | BOOK | TRF | BOOK | TRF |
| NPP PayTo On-Platform | PayTo Direct Debit mandate payment initiation | Customer to Customer | BOOK | DDT | BOOK | DDT |
| NPP PayTo On-Platform Return | Return of a PayTo Direct Debit payment | Customer to Customer | BOOK | RDD | BOOK | RDD |

### Transaction Codes

| Flow | Debit Code | Credit Code |
|------|------------|-------------|
| On-Me | PMNT.IRCT.BOOK | PMNT.RRCT.BOOK |
| On-Platform | PMNT.IRCT.DMCT | PMNT.RRCT.DMCT |
| On-Platform Return | PMNT.RRCT.RRTN | PMNT.IRCT.RRTN |
| PayTo Direct Debit | PMNT.RDDT.PMDD | PMNT.IDDT.PMDD |
| PayTo DD Return | PMNT.IDDT.RCDD | PMNT.RDDT.RCDD |

## One-Sided Transactions

### Scenarios

| Scenario | Description | Template | Scheme | Type | Transaction Code |
|----------|-------------|----------|--------|------|------------------|
| NPP To-Us | Incoming NPP payment crediting CCMP customer | Customer Credit | NPP | TRF | PMNT.RRCT.DMCT |
| NPP To-Us Exception | Incoming NPP placed into Exception Hold | Suspense Credit | NPP | TRF | PMNT.RRCT.DMCT |
| NPP Outbound Return | Return payment to originating FI | Customer Debit | NPP | RTR | PMNT.RRCT.RRTN |
| NPP Off-Us | Outgoing NPP payment from CCMP customer | Customer Debit | NPP | TRF | PMNT.IRCT.DMCT |
| NPP Off-Us Reversal | Failed outgoing NPP returned to customer | Customer Credit | NPP | RJCT | PMNT.IRCT.RIMB |
| NPP Inbound Return | OFI returns previously sent funds | Customer Credit | NPP | RTR | PMNT.IRCT.RRTN |
| NPP PayTo Biller | CCMP customer credited via PayTo DD | Customer Credit | NPP | DDT | PMNT.IDDT.PMDD |
| NPP PayTo Payer | CCMP customer debited via PayTo DD | Customer Debit | NPP | DDT | PMNT.RDDT.PMDD |
| NPP Bulk Debit | Bulk amount debited for bulk NPP | Customer Debit | NPP | BTCH | PMNT.IRCT.DMCT |
| NPP Bulk On-Us | On-us credit from bulk NPP | Customer Credit | NPP | BTCH | PMNT.RRCT.DMCT |

### API Template Parameters

| Parameter | Customer Credit | Customer Debit | Suspense Credit | Suspense Debit |
|-----------|-----------------|----------------|-----------------|----------------|
| indicator | CREDIT | DEBIT | CREDIT | DEBIT |
| subscriptionKey | Account subkey | Account subkey | Suspense subkey | Suspense subkey |
| transactionStatus | POSTED | POSTED | POSTED | POSTED |
| currency | AUD | AUD | AUD | AUD |

### Internal Accounts Metadata

Required only when Suspense Account is being Debited or Credited:

| Field | Description |
|-------|-------------|
| amountPendingClearing | n/a - 10x controls suspense lifecycle for ConsoleUI |
| suspenseStatus | n/a - 10x controls suspense lifecycle for ConsoleUI |
| customerPartyKey | Previously presented partyKey |
| customerSubscriptionKey | Previously presented subscriptionKey |
| customerTransactionKey | Previously presented transactionKey |
| parentTransaction.transactionKey | Reference to original Suspense transaction |

## Response Interface Specification

### Customer Account Response

| Parameter | Description |
|-----------|-------------|
| balanceDetails | Balance details post-transaction |
| balanceDetails.availableBalance.amount | Available balance amount |
| balanceDetails.availableBalance.currency | Currency (AUD) |
| balanceDetails.availableBalance.indicator | CREDIT/DEBIT |
| balanceDetails.postedBalance.amount | Posted balance amount |
| balanceDetails.creditLimit.amount | Credit limit (if applicable) |
| balanceDetails.minimumHoldingAmount | Minimum holding requirement |
| balanceDetails.maximumBalance | Maximum balance limit |
