# Platform Configuration

This section contains platform configuration and standards documentation for the 10x/W1C platform.

## 01. API Patterns and Standards

- **01. SC: B2B** - Business-to-Business API standards
- **02. SC: Domain Driven Design for Services** - Service design patterns using DDD

## 02. Tenants

- **01. Configuration** - Tenant configuration documentation

## 03. CI/CD

- **SD: 10x Change Notification** - Change notification solution design

## BaaS Shutdown Components

Documentation for shutdown procedures of Banking-as-a-Service components:

- **ForgeRock Migration - SSO Changes** - Single Sign-On migration changes
- **BaaS Shutdown - Feedzai** - Fraud detection system shutdown
- **BaaS Shutdown - FrankieOne** - Identity verification shutdown
- **BaaS Shutdown - BPAY** - BPAY integration shutdown
- **BaaS Shutdown - Customers' Status Synchronisation Uplift** - Customer status sync changes
  - Manual Steps for Files Exchange and Preparation
- **BaaS Shutdown - Indue (NPP)** - NPP provider shutdown
- **BaaS Shutdown - Card Rails (Mastercard Scheme)** - Card scheme shutdown

## 04. Event Driven Design

- **01. Strict Ordering of Ledger Events** - Event ordering requirements

## 06. 10x Bank Manager

- **New Roles Addition in IT Store** - Role management for Bank Manager

## 99. Discovery

- **01. 10x Event Ingestion - Tactical** - Tactical approach for event ingestion
- **02. SD: 10x Event Ingestion - Multi-path Streaming** - Multi-path streaming solution design
