# Account Synchronisation v1.0

| Version | 82 |
|---------|-----|
| Status | COMPLETED |
| Baseline Date | 23 Jun 2025 |

## Glossary

| Abbreviation | Expansion |
|--------------|-----------|
| GCM | Group Customer Master |
| WDP | Westpac Digital Platform |
| API | Application Programming Interface |
| B2B | Business-to-Business |
| CCMP | Customer Cash Management Platform |
| DDEP | Data Driven Experience Platform |
| TDM | Treasury Data Management |
| EIG | Enterprise Information Gateway |
| EDW | Enterprise Data Warehouse |
| NR | NetReveal |
| CIM | Customer Information Management |
| ADLS2 | Azure Data Lake Storage Gen2 |

## Overview

- Account created/updated/closed in 10x will be synchronised to GCM in real time
- Manual activities employed to update GCM in earlier releases will be replaced by smart code
- Triggering of account functions (Account Opening, Update, Closure) will be done manually for the release
- Party and account states maintained across systems are shown in Support Documents

## Scope

| Ref | Description |
|-----|-------------|
| S-001 | Account Synchronisation (ART-1283) |
| S-002 | Link Account (10x to GCM) |
| S-003 | Maintain Account (10x to GCM) |

### Out of Scope

- Monthly Reconciliation (10x - GCM)

## Risks

| Ref | Description | Notes |
|-----|-------------|-------|
| R-001 | Access of system-to-system APIs (Ambassador) depends on upstream systems' authorization | In current APIs, 10x doesn't do authorization |
| R-002 | Transition of party | Using 10x B2B API, party's state can be transitioned to any predefined one |

## Assumptions, Constraints & Dependencies

| Ref | Type | Description |
|-----|------|-------------|
| A-001 | Assumption | client-subscription-event-v003 schema and lifecycle will be identical between build and runtime |
| A-002 | Assumption | No changes required to existing data flows to downstream with respect to account |
| A-003 | Assumption | GCM CIM team will manually create XREF linkage in GCM from GCM UI |
| A-004 | Assumption | Salesforce will be used as Servicing portal |
| A-005 | Assumption | Customers should have been established in 10x before opening an account |
| D-001 | Dependency | 10x B2B APIs' headers have to work as per released documentation |
| D-002 | Dependency | Decision on how funds need to be moved out of account when closing it |

## Key Design Decisions

| Ref | Decision | Rationale |
|-----|----------|-----------|
| KDD-001 | Execution of 10x APIs from Postman | In the absence of a servicing portal/orchestration service layer |
| KDD-002 | Synchronisation of account address to GCM | Account address isn't mandatory in GCM but is a good-to-have |

## Technical Debts

| Ref | Description | Impacted Components |
|-----|-------------|---------------------|
| TD-001 | Execution of 10x APIs from Postman | Account Provisioning - will be replaced by servicing portal/orchestration layer |

## Solution Design

### Block Diagram

Account Synchronisation Block Diagram shows the flow between systems.

### Sequence Diagrams

1. **Account Opening Activity** - Shows the flow for opening new accounts
2. **Update Account Details Activity** - Shows the flow for updating accounts
3. **Account Closing Activity** - Shows the flow for closing accounts

### State Transition Diagram

- Depicts how party and subscription states transition in 10x
- Corresponding GCM state is mentioned for each 10x state in scope
- For targeted release, only specific states will be in use
- Transitions controlled from Postman for target release

## Integration Impacts

| Source | Integration Type | Destination | Frequency |
|--------|------------------|-------------|-----------|
| Postman | Real time | 10x | Ad hoc |
| 10x | Real time | GCM | Real time |

## Application/System Changes

| System | Change Details |
|--------|----------------|
| Postman | Edit existing scripts to call 10x B2B APIs for Create/Update/Close Subscription |
| 10x | Expose required APIs via B2B Gateway, Uplift GCM Adapter |
| WDP | Uplift existing 10x Partner Proxy and Partner APIs |
| GCM | No change - stores values passed from 10x |

## Error Handling

| Error Scenario | Failure Point | Severity | Remediation |
|----------------|---------------|----------|-------------|
| Manual intervention of API calls | Postman | ERROR | Manual analysis of API error codes |
| WDP APIs not responding | WDP | ERROR | 10x maintains dead letter queue, GCM Adapter retries |

## 10x Action & WDP API Mapping

| Action in 10x | WDP API | API Path | HTTP Method |
|---------------|---------|----------|-------------|
| CREATE SUBSCRIPTION | ptr-partner-vendor-westpac-10xcustarrngmntmgt-v2 | /arrangementProfiles | POST |
| UPDATE SUBSCRIPTION ATTRIBUTES | ptr-partner-vendor-westpac-10xcustarrngmntmgt-v2 | /arrangements/arrangementID | PATCH |
| CLOSE SUBSCRIPTION | ptr-partner-vendor-westpac-10xcustarrngmntmgt-v2 | /arrangements/arrangementId/do/terminate | POST |

## Key Fields

| Operation | Field Name | Description |
|-----------|------------|-------------|
| All operations | brandSilo | 10x passes "WPAC" for all business parties linked to Artemis |
| Create/Update | aliasName | 10x populates subscription's name |
| Create | customerType | Default "Organisation" for business customers |
