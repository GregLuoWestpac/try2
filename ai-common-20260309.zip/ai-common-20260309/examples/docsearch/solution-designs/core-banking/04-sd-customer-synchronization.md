# Customer Synchronization

## Release Scope

| Release Name | Version | Release Date |
|--------------|---------|--------------|
| ERM 25E3 | May 2025 | Corporate Cash Management Platform |

## RACI

| Role | Account |
|------|---------|
| Responsible - Solution Designer | Sailendra Mouli Meka |
| Consulted - Solution Architect | Robin Fitzgerald |
| Consulted - Integration Architect | Stuart Murdoch |
| Informed - IT Delivery Manager | Karthik Damodaran |
| Informed - Engineering Lead | Mark Nguyen |

## Impacted System Summary

| System | Status | Description |
|--------|--------|-------------|
| 10x (A00A46) | ⭐ Change | Customer Snapshot Listener will be uplifted to extract specific attributes |
| GCM (A0028E) | 🔵 Existing | Publishes customer data updates to Customer Snapshot Event Topic |

**Legend:** ⭐ Change | 🟩 New | 🔵 Existing Implementation | ⬜ Decommission

## RAID

| Ref | Type | Description |
|-----|------|-------------|
| D-001 | Dependency | Customer should have a reference to 10x in GCM |
| R-001 | Risk | Application of right filters in downstream queries to identify CCMP customers |
| A-001 | Assumption | businessType field for a business party made optional in 10x |
| A-002 | Assumption | emailAddress field made optional in Create business party API |

## Scope

| Ref | Description |
|-----|-------------|
| S-001 | ART-1282.01 - GCM synchronization for active 10x customers |
| S-002 | ART-1282.02 - GCM updates for inactive 10x customers |
| S-003 | ART-1282.14 - Automated Purging process |

## Solution Overview

- Customer data stored in 10x needs to be updated whenever corresponding data in GCM is changed
- Westpac downstream systems should receive the changes done to customer data in GCM
- Data will be synchronized from GCM to 10x over a **near real-time** pattern

## Block Diagram

Near Real-time Customer Synchronisation between GCM and 10x

### Solution Explanation

1. Any create/update of customer data in GCM generates events with full snapshot of the customer
2. Flow: GCM → MQ → MQ Listener → Kafka Topic
3. Events in Customer Snapshot Event Topic contain full data snapshot of the customer
4. OrganisationUpdated event contains full snapshot of Organisation customers

### Customer Snapshot Listener (10x)

- Processes OrganisationUpdated event of Customer Snapshot Event Topic
- Also processes ArrangementUpdated event
- Consumes events only if conditions are met:
  - `/header/eventType` = 'OrganisationUpdated'
  - `/header/brandSilo` = 'WPAC'
  - `/organisationUpdated/externalSystemCustomerReferences[]/externalSystemId` = 'A00A46'

### Redis Cache for Out-of-Sequence Events

- Subset of successfully updated customers' data stored in Redis cache
- Key: CISKey
- Value:
```json
{
  "demographicDetails_modificationId": "string",
  "externalSystemCustomerReferences_modificationId": "string"
}
```
- Data in cache lives for 24 hours only
- Listener compares modification IDs to detect out-of-sequence events

### API Integration

- Customer Snapshot Events Listener invokes **Replace a business party** endpoint in 10x Party Service Proxy API
- Takes values from event and prepares request for proxy API

## Integration Impacts

| Source | Type | Destination | Frequency | Details |
|--------|------|-------------|-----------|---------|
| GCM | Near Real-time | MESH | For every customer create/update | Existing integration |
| MESH | Real-time | 10x | For every customer update | Existing integration |

## Security Aspects

- Customer Snapshot Events Listener API implements 10x x-apiKey workaround for invoking 10x Party Service Proxy API

## Error Handling

| # | Error Scenario | Failure Point | Severity | Behaviour | Remediation |
|---|----------------|---------------|----------|-----------|-------------|
| 1 | Events Lost in Transmission | GCM | INFO | Customer data not in sync | End of day reconciliation batch |
| 2 | Out of Sequence Events | GCM | INFO | Customer data not in sync | End of day reconciliation + Redis cache check |
| 3 | Event Unconsumed | GCM | INFO | Customer data not in sync | End of day reconciliation |
| 4 | 10x Proxy API Unavailable | MESH Gateway | ERROR | HTTP 500/503 | Retry 3 times, then dead letter queue |
| 5 | Replace Business Party API Unavailable | 10x | ERROR | HTTP 500 | Retry 3 times, then dead letter queue |
| 6 | Party Not Found in 10x | 10x | ERROR | HTTP 404 | No retry, reconciliation will capture |

## Operational Impacts

- Technology Operations team receives email alerts when API request is placed in Customer Snapshot Listener's dead letter topic

## References

- ART-1282: Customer Synchronisation (Combined)
- Customer Synchronisation Data Mapping - 10X/GCM Interface
- ART-5069 Legal Entity & Email Address Fields Rationale
