# Finance And Reporting

This section contains solution design documents for Finance and Reporting capabilities in the W1C platform.

## Reference Documents (00 series)

- **00 - 10X Downstream Interface Flows** - Interface flows to downstream systems
- **00 - 10X GL Posting Transaction Flows** - General Ledger posting transaction flows
- **00 - 10X to Oracle GL Mapping Details** - Mapping between 10x and Oracle GL
- **00 - Interface Specifications (Finance & Reporting)** - File specifications including:
  - 10X TLM File specifications
  - DE Release TLM File
  - EDW Semantic Table - YTNX_Tran_GL_Code_Block
  - FAH Balance (BAL) File
  - FAH Fee Reward Accrual (FRA) File
  - FAH Interest Accrued (IA) File
  - FAH Transaction (TRX) File
  - TDM Accounts Publish Table
  - TDM GL Detail Publish Table
- **00 - Scheme, Type & Transaction Code Combinations**
- **00 - TLM HC Transaction Reconciliations** - Including accounts for:
  - 10X CCMP NPP Exception Hold
  - 10X General Suspense
  - 10X Platform FTH Clearing
  - 10X Platform Internal Clearing
  - 10X Platform NPP Clearing
  - 10X To DE Settlement Tran
  - RBA FSS
- **00 - Treasury Flows**
- **00 - Unified 10X Ledger**

## NPP Payment Solution Designs (01 series)

- **01.01.SD** - CCMP On-Me, On-Us, NPP-In & NPP-Out Using Postman
- **01.02.SD** - CCMP Inbound & Outbound NPP Payment Exceptions Using Postman
- **01.03.SD** - CCMP NPP Payment Returns & Rejects
- **01.04.SD** - CCMP NPP PayTo (Direct Debits)
- **01.05.SD** - CCMP NPP Bulk

## Interest & Account Solution Designs

- **02.SD** - Interest Adjustments - Credit Interest
- **04.SD** - CTA Non-Interest Bearing
- **07.SD** - Phase 1 - CTA Debit Interest Unarranged (Ingest all Accrued Interest Event Fields)
- **11.SD** - Effective Interest Rate

## Regulatory & Reporting Solution Designs

- **06.SD** - Data for Regulatory/Statutory reporting obligations
- **09.SD** - Daily WHT reporting and Monthly WHT Reconciliation Report
- **10.SD** - Finance Reporting - Customer Balance & Accrued Interest Variance Report
- **12.SD** - TLM & OGL Traceability
- **14.SD** - Business Account WHT Refund
- **24.SD** - Credit Regulatory Reporting
- **25.SD** - QTFN and AIIR Reports for Organisation Customers Interim Solution
- **26.SD** - QTFN Report for Organisation Customers Target Solution - ABN Code Only
- **27.SD** - AIIR Report for Organisation Customers Target Solution
- **33.SD** - QTFN Report for Organisation Customers Target Solution - Inclusion of TFN Code

## GL & Product Configuration

- **13.SD** - CIA & CTA New GL Product Codes
- **15.SD** - CIA Retail Look Through Accounts
- **16.SD** - WBC downstream separation of BaaS to W1C

## Ledger & Integration Solution Designs

- **18.01.SD** - Unified Ledger Phase 1 (FIS NPP Payments)
- **19.01.SD** - CTA & CIA Overdrafts (Part 1 - Excluding Credit Systems)
- **20.SD** - New Event Ingestion FEB25 & MAY25 ERM
- **21.SD** - BaaS Winddown - MAY25 ERM
- **22.SD** - Target State TLM Reconciliation for Direct Entry (DE)
- **23.SD** - Simplified Ledger - FAH Alignment Changes
- **28.SD** - Simplified Ledger - DE Suspense Set Up & Other Sundry Items for Nov25 ERM
- **29.SD** - TLM LC Input File Fix Post AUG25 ERM
- **SD: 10x Kafka Integration** - Kafka event file sizing and NFR requirements

## Account & Statement Solution Designs

- **17.SD** - Account Statement (PDF & Electronic)

## Product Features

- **30.01.SD** - Product Switching - Finance & Treasury
- **30.02.SD** - Sundry Items - FEB26 ERM
- **32.SD** - Foreign Currency Accounts (FCA) and limits
- **34.SD** - Arranged Overdrafts Line Fee & Line Fee Refund
- **35.SD** - Inward RTGS & Inward ITT Payments via FTH
- **XX.SD** - Near Real-time Treasury Reporting

## Key Acronyms

| Acronym | Meaning |
|---------|---------|
| TLM | Transaction Lifecycle Management |
| OGL | Oracle General Ledger |
| FAH | Finance Accounting Hub |
| WHT | Withholding Tax |
| CTA | Call Transaction Account |
| CIA | Cash Investment Account |
| NPP | New Payments Platform |
| FTH | FIS Transaction Hub |
| QTFN | Quarterly Tax File Number |
| AIIR | Annual Investment Income Report |
| TDM | Treasury Data Management |
| EDW | Enterprise Data Warehouse |
