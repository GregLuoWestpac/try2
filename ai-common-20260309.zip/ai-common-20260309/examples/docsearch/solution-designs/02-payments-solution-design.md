# 02. Payments Solution design

## ACD References

- CCMP Payments - FIS Hosting ACD
- ACD for 10x Integration (Architecture On a Page)
- CCMP Data - Data Solution ACD
- W1C Payment Mesh Portfolio

## Pre-requisites

### Account Cache

A component within CBIS FIS (A013D9) called Account cache. Can be updated by batch or API.

**Account cache usages:**

1. **Account Location lookup service** - finds which account host the account belongs to when deciding which adapter to use for posting
2. **Eligibility check:**
   - Whether the account can receive account postings
   - Whether the account is eligible for the payment scheme
   - Extra check for NPP: Whether the account is eligible for the related Business service
3. **Account number and BSB to Subscription key lookup** - Subscription key is an internal identifier within 10X used to identify an account

### Related Solution Designs

- 01. SD: Account Cache - API for Create and Update
- 02. SD: Account Cache - Batch synch and Re-synch to fix data discrepancies
- Cache vs 10X directly
- Detailed NFR: for Account Cache

## To-Us NPP

### Happy Path Sequence Diagram
NPP-INB-CT-101 All Pass

### Clearing Request To-Us
Inbound clearing request flow

### Settlement Notification To-Us
Inbound settlement notification flow

## On-Me
Internal payment flows between accounts on the same platform

## Off-Us NPP

### Sequence Diagram
NPP-OUTB-CT-101 All Pass - Outbound NPP payment flow

## Systems

### 10X (A00A46)
Account host and Payment Engine for DE. Is the customer ledger. Has multiple tenants, with specific tenancy for WIB - Cash Platform.

### Account Cache
Component within CBIS FIS (A013D9). Updated by batch or API. Provides account lookup, eligibility checking, and subscription key mapping.

### ATLAS (A016F9)
Accounts & Transactions & Ledger Aggregated Store - Operational Data Store modelling data from 10x. Curates product, subscription and transactional data for consumption by channels.

### BIS
Gets files from applications and passes them to Trading Bank - acts as an interface.

### BVA (NPP Product)
Bank Visibility Application - UI for NPP Product from FIS (A013D9).

### CBIS
Core Banking Integration Services - FIS product solution (A013D9):
- Manages integration of payments systems to core banking
- Provides account lookup/cache/stand-in functionality
- Integrates with any payment system (NPP/POM) and core banking solution
- Decouples payment management from account posting

**Adapters:**
- PRA - Product Rules Adapter for posting eligibility
- PBA - Product Behaviour Adapter for accounting entry behavior
- AVA - Account Validator Adapter for account validations

### DDEP (A006B2)
Data warehouse and file processing

### Direct Entry (A00003)
Transfers DE files to coin network. Routes W1C BSBs to 10X for DE payments.

### EBIP
Enterprise Batch Integration Platform - data extraction using Informatica IICS with CDI and CMI services.

### EDW (A0036B)
Three layers:
- Source image (exact source copy)
- Core (consumption layer, foundational data model)
- Semantic model (specific data model for system interfaces)

### EIG (A00278)
File transfer and transformations. Used heavily in TLM flows.

### FAH (A00506)
Oracle Financials Account Hub. Receives all transactions (except accrued interest from 10X). Maps to GL line items and posts as consolidated posting.

### FTH
Account host isolation and payment pre-processor. Performs Fraud, Credit check, balance check, account validation.

### GL
General ledger - maintains balance and receives transactions.

### MPS Product (MMS)
Mandate Payment Services / Mandate Management Services - FIS MPS product component supporting:
- Create, Amend, Recall, View mandates

### PAG (A00605)
Payment Gateway - interface between Participant back-office and Basic Infrastructure. Exchanges ISO 20022 messages over IBM MQ. Manages clearing and settlement flow orchestration.

### PEX (NPP Product)
Payment Execution System for NPP - scheme specific back-office execution system (A013D9).

### PODS (A0154A)
Payment Operational Data Store - ingests payment events from FIS for long history retention. FIS Payments stores only 28 days.

Services:
- Payment status and history from FIS
- Event matching and data reconciliation
- End of Day posting to FAH and GL for NPP
- Audit, investigations, customer enquiries

### POM
Payment Order Management - FIS product (A013D9):
- Receives payment requests via REST APIs
- Prepares payment for execution
- Orchestrates posting of funds
- Selects appropriate PEX
- Routes to payment execution system
- Provides Payment Status Reports

### Qvalent
Third party partner (GTS owned):
- Gopher - integration with Mesh API services
- Quickstream - UI for institutional customers
- Payway - UI for business banking customers
