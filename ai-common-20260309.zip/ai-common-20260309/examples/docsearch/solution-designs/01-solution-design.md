# 01. Solution design

## Table of Contents
- [WoW Solution design](#wow-solution-design)
- [Solution design](#solution-design)
  - [Naming standard](#naming-standard)
  - [Definition of ready to pick up a piece of work](#definition-of-ready-to-pick-up-a-piece-of-work)
  - [Template](#template)
  - [Confluence space](#confluence-space)
  - [JIRA Tasks](#jira-tasks)
  - [RACI Outline](#raci-outline)
- [Feature design work](#feature-design-work)
- [Impacted System Summary](#impacted-system-summary)
- [NFR](#nfr)

---

## WoW Solution design

## Solution design

### Naming standard

Example: `01. SD: Local Lookup - Create and Update`

| Component | Description |
|-----------|-------------|
| `01.` | So that the solution design appears in a numbered list |
| `SD:` | So that you can tell that it's a solution design from within JIRA |
| `Local Lookup - Create and Update` | Whatever makes logical sense to you to explain what you are solving for |

### Definition of ready to pick up a piece of work

This is the definition for the Payment's squad:

- Business requirements approved
- ACD Integration diagram completed detailing all the components within a flow
- Key questions resolved
- One set of DA review done

### Template

- [01. What to cover in Solution Design](01-what-to-cover-in-solution-design.md)

### Confluence space

- [01. Solution design](01-solution-design.md)

### JIRA Tasks

| Task | Description | Acceptance Criteria / DoD |
|------|-------------|---------------------------|
| Draft Solution Design | - Identify key stakeholders identified for engagement<br>- Draft Solution design according to template [01. What to cover in Solution Design](01-what-to-cover-in-solution-design.md) | - Solution design drafted on Confluence<br>- Feature Jira id is added to solution design<br>- Key dependencies discovered and communicated<br>- Key stakeholders to resolve dependencies engaged and allocated |
| Baseline Solution Design | Solution design baselined, this includes:<br>- Close out outstanding questions<br>- Resolved key dependencies | - Solution design baselined on Confluence<br>- Key dependencies resolved<br>- Outstanding questions closed out |
| Review Solution Design | - Review/Walkthrough with key stakeholders, see the details for the squad: [04. RACI Solution Design](04-raci-solution-design.md)<br>- Incorporate Stakeholder Review and clarifications | - Solution design shared with stakeholders<br>- Stakeholder review comments and clarifications incorporated |
| Approve Solution Design | Obtain approval according to RACI: [04. RACI Solution Design](04-raci-solution-design.md) | Solution design approved according to RACI |
| NFRs | Complete NFRs | Complete NFRs - Feature Level Requirements |

### RACI Outline

This outlines who has what type of responsibility for the Solution design.

| Responsible | Accountable | Consulted | Informed |
|-------------|-------------|-----------|----------|
| Solution designer | Sponsor (or delegate) | - Business Owner<br>- Project Manager / Initiative Lead<br>- Business Analyst<br>- Architecture Practice (multiple roles) aligns to Value Chain Mapping (VCM) | Testing Practice |

**Definitions:**
- **Responsible**: For ensuring completeness of the Deliverable
- **Accountable**: Approving and Signing off the Deliverable
- **Consulted**: To provide input and review the deliverable
- **Informed**: Of the deliverable

## Feature design work

1. [01. Solution Design e2e](01-solution-design-e2e.md)
2. [02. Payments Solution design](02-payments-solution-design.md)
3. [03. Channel / Cash Portal Solution Design](03-channel-cash-portal-solution-design.md)
4. [04. Entitlements - Solution Design artefacts](04-entitlements-solution-design-artefacts.md)
5. [05. Capabilities](05-capabilities.md)
6. [06. Workflow](06-workflow.md)
7. [07. PODS Payments Operational Data Store](07-pods-payments-operational-data-store.md)
8. [08. ATLAS](08-atlas.md)
9. [09. Platform Admin Console (PAC)](09-platform-admin-console-pac.md)
10. [10. Liquidity Management Console](10-liquidity-management-console.md)
11. [Experience API Design Pattern](experience-api-design-pattern.md)
12. [z. Solution design for W1C](z-solution-design-for-w1c.md)

## Impacted System Summary

See: [01. Impacted System Summary](01-impacted-system-summary.md)

## NFR

| Document Type | Document Locations |
|---------------|-------------------|
| NFR: Platform Level | NFRs |
| NFR: Feature Level | PI-9 (ERM 25E2 - Feb 2025) Feature Level Consolidated NFRs |
| NFR - Vendor Systems | NFR Vendor Systems |
| Service Level Objectives (SLO) | Service Level Objectives - W1C |
| Rate Limiting in Mesh Gateways (Axway and Kong) | Rate Limiting in Mesh Gateways (Axway and Kong) |
