# Experience API Design Pattern

Considerations for Creating an Experience API Layer for generating a proper error-free mesh redux artifacts.

---

## URL Pattern Guidelines

To prevent issues when generating Mesh Redux artifacts, ensure that the final path segment of each endpoint is unique across all API operations.

### Example of Incorrect URL Patterns

| Operation | URL |
|-----------|-----|
| Updating a beneficiary | POST /beneficiary/id |
| Retrieving a beneficiary | GET /beneficiaries/id |

> Even if the above endpoints follow RESTful principles, use different resource names, and use different HTTP methods, they may not generate Redux artifacts properly since the last path segment is the same. (You'll find redux selector references use the same name for 2 different endpoints in HOCs)

### Example of Correct URL Patterns

To ensure proper artifact generation, modify the endpoint paths to include distinct final segments:

| Operation | URL |
|-----------|-----|
| Updating a beneficiary | POST /beneficiaries/update |
| Retrieving a beneficiary | GET /beneficiaries/details |

Or follow the recommended pattern given below.

---

## Including Entity in API Responses

Every API response should include an entity, and the entity name (a.k.a schemaKey) must match the last path segment of the corresponding endpoint.

### Example

**Endpoint:** `GET /beneficiaryDetails`

**Expected Response:**
```json
{
    "entities": {
        "beneficiaryDetails": {
            "nickname": "john",
            "accountType": "PayID"
        }
    }
}
```

> Here, `beneficiaryDetails` is the schemaKey and the same name is used to generate selectors files, so the name of the selector files and the reference in the HOC should be EXACTLY SAME.

---

## API Response Structure

API calls are triggered from UI by dispatching a redux action and the API response is handled by Mesh framework. The framework expects the response to be in a certain structure (normalized) for it to be parsed and populated into the redux store.

### Example

```json
{
  "entities": {
    "customerDetails": [
      {
        "address": "culpa dolore ea veniam labore magna deserunt Lore",
        "city": "velit est",
        "country": "fugiat occaecat proident",
        "name": "non velit sunt",
        "customerType": "mollit est anim ad",
        "id": "1234"
      }
    ]
  },
  "result": {
    "customerDetails": [
      1234
    ]
  }
}
```

> **NOTE:** The `id` above is just a UUID generated in the experience API as part of normalising response. More info: 6.3.5 Normalize Responses

> Entity name should match the resource in path: `GET: /customerDetails`

---

## Recommended URL Patterns for Experience API Layer

To ensure proper Mesh Redux artifact generation and maintain consistency, use clear and distinct endpoint names for each operation.

### Preferred URL Patterns

| Operation | HTTP Method | URL Pattern |
|-----------|-------------|-------------|
| Create a beneficiary | POST | /beneficiaryCreate |
| Retrieve the beneficiary list | POST | /beneficiaryList |
| Update a beneficiary | PUT | /beneficiaryUpdate |
| Retrieve a beneficiary | POST | /beneficiaryDetails |
| Delete/Archive beneficiaries | PATCH/POST | /beneficiaryArchive (ISG doesn't recommend PATCH) |
| Approve a beneficiary | POST | /approvalWorkflowConsent |
| Retrieve a list by something | POST | /divisionListByAccountGroup |
| Retrieve a list with additional info | POST | /divisionListWithAccountGroups |
| Create a payment for new bene | POST | /paymentCreateForNewBeneficiary |

### Lookup Pattern

For lookups, below pattern won't work, since both URLs end with `/lookup`:

```
alias/lookup
bsb/lookup
```

Instead use the following pattern:

```
aliasLookup
bsbLookup
```

---

## Swagger Directory Structure

### common

Common data definitions which can be reused in current MFE ONLY, use mv-common when possible.

Example: `AccountGroupModel`

### entities

Entity used in the response, reuse common/mv-common definitions + id.

Example (`accountGroup.yaml`):
```yaml
AccountGroup:
  type: object
  description: Account group details
  allOf:
    - $ref: '../mv-common/definitions.yaml#/AccountGroup'
    - $ref: '../mv-common/definitions.yaml#/MeshEntityId'
```

Example: `AccountGroupEntity`

### mv-common (CDM - Common Data Model)

Common definitions which can be reused across 2 or more MFEs. Don't update locally, always update in multiverse-ui-common repo and pull.

Follow Mesh recommendations and build upon it - Common Data Types

Example: `AccountGroupModel`

### requests

Request definitions - usually reuse common/mv-common definitions.

Example: `AccountGroupRequest`

### resources

REST resource definitions - uses definitions from requests & responses.

Example: `AccountGroupResource`

### responses

Response definitions - uses entities.

Example: `AccountGroupResponse`

---

## References

Refer to these for more patterns from MESH:

- Real Time Solution Patterns
  - Example: Pattern 9: Paging, Sorting and Filtering
- How to Use OpenAPI 3.0 - Development guide
- How to Validate a Contract Using Spectral
