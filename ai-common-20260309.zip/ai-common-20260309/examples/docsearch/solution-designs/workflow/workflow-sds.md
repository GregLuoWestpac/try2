# Workflow Solution Designs

## Solution Design Roadmap

| # | Solution Design | Release |
|---|-----------------|---------|
| 1 | Servicing OFI Inbound Payment Returns - Solicited & Unsolicited | AUG 24 |
| 2 | Servicing OFI Outbound Payment Returns - Solicited and Unsolicited | AUG 24 |
| 3 | Initiate returns for Inbound investigations | AUG 24, NOV 24, FEB 25, AUG 25 |
| 4 | Uplift 'Initiate Return' to check NPP Service Eligibility | MAY 25 |
| 5 | CCMP Staff Channels & Entitlements - Beta Release OneAccess | AUG 24, NOV 25 |
| 6 | MQ Listener Payments Details Enrichment from PODS for TLM Case | AUG 24, NOV 24, FEB 25 |
| 7 | Payment Search and Transaction details (Domestic RTGS Inwards, IHVP Inwards, NPP) | NOV 25, FEB 26, MAY 26 |
| 8 | Partial Annual Interest Statement Generation | FEB 26 |
| 9 | Overdraft (Arranged & IDOL) Limits and Pricing | FEB 26 |
| 10 | On-Platform Fee & Interest Re-directions and Refunds | MAY 26 |
| 11 | Liquidity Management Decisioning System | NOV 25, MAY 26 |
| 12 | Foreign Currency Account Product | MAY 26 |

## Key Workflows

### Payment Returns
- OFI (Originating Financial Institution) Inbound Payment Returns
- OFI Outbound Payment Returns
- Inbound investigation returns
- NPP Service Eligibility checking

### Staff & Entitlements
- CCMP Staff Channels & Entitlements
- Beta Release OneAccess integration

### Payment Processing
- MQ Listener for payment details enrichment from PODS
- Payment Search and Transaction details across channels (RTGS, IHVP, NPP)

### Account Management
- Partial Annual Interest Statement Generation
- Overdraft Limits and Pricing (Arranged & IDOL)
- Fee & Interest Re-directions and Refunds

### Treasury
- Liquidity Management Decisioning System
- Foreign Currency Account Product
