# 09. Platform Admin Console (PAC)

## API Integration Solution Overview

*[See Confluence for diagram]*

---

## Components

| Journey | Component Type | Component Name | Component Id | Support URL |
|---------|---------------|----------------|--------------|-------------|
| Credit Interest Overrides (create & update) | MFE | Galaxy Account | galaxy-account | https://mesh.westpac.com.au/components/microFrontends/galaxy-account |
| | API | WASH Account Cap API | cap-prodsvcadm-proddealacctadm-10xacctsvcng-v1 | https://mesh.westpac.com.au/components/apis/cap-prodsvcadm-proddealacctadm-10xacctsvcng-v1 |
| | Service Proxy | 10x Subscriptions Service Proxy | inf-bnkng-acct-custacct-subcrptn10x-v1 | https://mesh.westpac.com.au/components/service-proxies/inf-bnkng-acct-custacct-subcrptn10x-v1 |
| | Service Proxy | 10x Interest Service Proxy | interest-10x-v1 | https://mesh.westpac.com.au/components/service-proxies/interest-10x-v1 |
| Update Account Designator | MFE | Galaxy Account | galaxy-account | https://mesh.westpac.com.au/components/microFrontends/galaxy-account |
| | API | WASH Account Cap API | cap-prodsvcadm-proddealacctadm-10xacctsvcng-v1 | https://mesh.westpac.com.au/components/apis/cap-prodsvcadm-proddealacctadm-10xacctsvcng-v1 |
| | Service Proxy | 10x Subscriptions Service Proxy | inf-bnkng-acct-custacct-subcrptn10x-v1 | https://mesh.westpac.com.au/components/service-proxies/inf-bnkng-acct-custacct-subcrptn10x-v1 |

---

## Error Scenario Details

### Update Account Name

| MC Type | MC Subtype | Endpoint | TYPE | HTTP Method |
|---------|------------|----------|------|-------------|
| w1caccountpac | updateaccname | exp/staff/galaxy/accountpac/v2/accounts/accountName | Update account name | PUT |

Link to Error handling SD: Staff Maintain Account Designator Error Handling

### Maintain Account Indicators

| MC Type | MC Subtype | Endpoint | TYPE | HTTP Method |
|---------|------------|----------|------|-------------|
| w1caccountpac | addaccindicators | exp/staff/galaxy/accountpac/v2/accounts/accountIndicators | Maintain account indicators | PUT |

Link to Error Handling SD: [2025 AUG ERM] 03.1 SD Staff Maintain account indicators / tags at an account level

### Create Interest Override

| MC Type | MC Subtype | Endpoint | TYPE | HTTP Method |
|---------|------------|----------|------|-------------|
| w1caccountpac | addcrintoverrides | exp/staff/galaxy/accountpac/v2/creditInterestRates/override | Create interest override | POST |

### Update Interest Override

| MC Type | MC Subtype | Endpoint | TYPE | HTTP Method |
|---------|------------|----------|------|-------------|
| w1caccountpac | updatecrintoverrides | exp/staff/galaxy/accountpac/v2/creditInterestRates/overrides/terms | Update interest override | POST |

### Account Opening

| MC Type | MC Subtype | Endpoint | TYPE | HTTP Method |
|---------|------------|----------|------|-------------|
| w1caccountpac | addaccorder | exp/staff/galaxy/accountpac/v2/orders/accountCreate | Account opening | POST |

### Account Block/Unblock

| MC Type | MC Subtype | Endpoint | TYPE | HTTP Method |
|---------|------------|----------|------|-------------|
| w1caccountpac | addaccblockstatus | exp/staff/galaxy/accountpac/v2/accounts/accountsBlockUnblock | Account block/unblock | POST |

### Account Closure

| MC Type | MC Subtype | Endpoint | TYPE | HTTP Method |
|---------|------------|----------|------|-------------|
| w1caccountpac | updateaccclosure | exp/staff/galaxy/accountpac/v2/orders/accountClose | Account closure | POST |
