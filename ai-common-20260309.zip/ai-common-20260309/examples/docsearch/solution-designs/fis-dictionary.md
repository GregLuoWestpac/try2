# FIS Dictionary

## FIS Components

### BVA - Bank Visibility Application
UI to FIS NPP (PEX).

### CBIS - Core Banking Interface System
A product solution from FIS that:
- Manages integration of payments systems to talk to one or more core banking systems (can talk to 10X)
- Provides functionality for account lookup/cache/stand-in for core banking systems
- Integrates with any payment system (NPP/POM) and any core banking solution
- Acts as an integration layer, providing banks a cost-effective way of decoupling management and execution of payments from actual posting to accounts

#### Product Adaptors by FIS
Standard product interfaces for specific business functions:
- **PRA** - Product Rules Adapter: Provides mechanism for CBIS to better determine posting eligibility for posting to an account
- **PBA** - Product Behaviour Adapter: Provides mechanism for CBIS to better determine correct behaviour for functionalities for individual accounting entries
- **AVA** - Account Validator Adapter: Provides mechanism for CBIS to execute validations against provided accounts via Account Eligibility Entries

#### Custom Adapters by FIS
Can be used to customise interfaces when transformation is needed. An example is a 10x adapter.

### CCTI - Customer Credit Transfer Initiation
CCTI API is a POM API for payment initiation of a credit transfer.

### DLQ - Dead Letter Queue
Lets you set aside and isolate messages that can't be processed correctly to determine why their processing didn't succeed.

### FSIS - Fraud and Sanctions Integration Service
A product solution from FIS that:
- Integrates to one/many scanning systems via API adaptors such as PRM for fraud check and NetReveal for sanctions check
- Produces business events to notify the results

### MPS - Mandated Payment Service
A product solution from FIS providing capabilities to process mandate management services and mandated payment initiation requests:
- **MMS** - An independently deployable microservice within MPS Product, that provides mandate management services
- **MPIR** - An independently deployable microservice within MPS Product, that provides payment management services for mandate payment initiation requests

### NA - New Architecture
New FIS architecture for real-time products requiring high throughput, availability, resiliency and flexibility. POM, FSIS and MPS products are built on NA.

### NFT - Non-Functional Tests
Refers to non-functional tests such as volume, performance, resiliency, fail-over, etc. Also refers to FIS test environment used for non-functional testing of the FIS solution.

### NPP - FIS NPP Product
A product solution from FIS (a.k.a FIS NPP or NPP Product) which serves as the payment execution engine (PEX) for the NPP scheme payments:
- **NPP Product Core** - FIS core NPP Product component
- **NPP Product Overlay** - Project specific configuration for the NPP Product component

### On-us
FIS uses these type of wording to describe: on-me and on-me platform. See Payment Scenario Definitions for more details.

### OVA - Operations Visual Applications
User interface for operational control.

### OPF - Open Payment Framework
A product framework with well-defined objects which are put together in building a specific product. FIS NPP and CBIS products are built on OPF. Handles real-time and batch.

### PAI - Process Accounting Instruction
Allows the payment system to invoke accounting processing to CBIS. This can also be called a dry-run, which is a posting eligibility check to determine whether the account posting will be successful or not. This is called from NPP Product on the Inbound clearing request.

### PACCTELI - Process Account Eligibility
Invoked with intention to enrich payment with information about account or account owner, and to validate whether given account can be used in given use-case.

### PDS - Project Definition Study
A series of workshops to showcase product features and technology in order to understand project requirements and analyse gaps, culminating in a structured document.

### PDE - Possible Duplicate
BO or OFI can include this flag in the request to notify the recipient that this payment is a possible duplicate. Refer to NPP scheme BO considerations and NPP procedures document for more details.

### PEX - Payment Execution System
Scheme specific back-office execution systems such as FIS NPP.

### POM - Payment Order Management
A product solution from FIS with capabilities to manage payment initiation and related business processes. Provides capabilities to process payments and related messages, originated from any channel and destined to any clearing and settlement execution system. Scheme agnostic.

POM capabilities:
- Receives payment requests from front-office or back-office channels via REST APIs
- Prepares payment for execution
- Orchestrates posting of funds, when required
- Selects the appropriate payment execution system (PEX)
- Routes and submits payment to the payment execution system (PEX)
- Provides Payment Status Reports to the originator

### PR - Payment Return
PR API is a POM API for payment initiation of a return.

### PSR - Payment Status Report
Report on the status of a payment.

### U-API - POM Universal API
POM specific API.
