# 07. SD: Staff User Establishment

## Release Scope

**Program:** Corporate Cash Management Platform  
**Project:** Corporate Cash Management Platform Tech

## RACI

| RACI | Role | Entitlements |
|------|------|--------------|
| Responsible | Solution Designer | Zane Zuo |
| | Development Lead | Tai Bello |
| Approval and signing off | Architect | Relevant architect for AIA/ACD |
| Consulted | Business Analyst | Adam Spencer |
| Informed | IT Delivery Lead | - |
| | ISG | Raj Vaishya |
| Reviewed | Product Owner | Sid Shekar |
| | Solution designer | Mark Chan |

## Impacted System Summary

| System | Status | Description |
|--------|--------|-------------|
| Mesh (A008E0) | ⭐ Change | - |
| Ping ELZ (A00CCC) | ⭐ Change | - |
| OneAccess Identity Lifecycle (A00B2C) | ⭐ Change | - |

**Other Systems Referenced:**
- 10x (A00A46), DDEP (A006B2), DETICA (A009F3), Direct Entry (A00003)
- FACE (A002C0), FAH (A00506), FIS (A013D9), GCM (A0028E)
- EDW (A0036B), EIG (A00278), Cash Platform (A014A6), Oracle GL
- PAG (A00605), Sterling (A002D8), TDM (A010E6)
- TLM HC (A0049F), TLM LC (A0049F), Trading Bank (A0004), WIB ETL (A00482)

## Key Decisions

| ID | Status | Date | Decision | Decision Taken | Who |
|----|--------|------|----------|----------------|-----|
| KD_5688_001 | OPEN | 18 Mar 2024 | Provide a SCIM based standard Mesh API for SailPoint to push approved Staff identity information | Allows SailPoint to initiate the push of Staff identity instead of entitlement platform | Adam Oakman, Zane Zuo |
| KD_5688_002 | OPEN | 25 Mar 2024 | AWS Neptune Proxy API role | TBD | - |

**KD_5688_001 Notes:** Pending Stuart Murdoch's integration design pattern to be finalised. ISG is consulted.

## Solution Overview

### Staff User CCMP Portal Access Request and Data Sync Process Flow

The solution covers staff user access request, approval, and data synchronisation between OneAccess (SailPoint) and the Entitlement platform.

## Integration Options

### Option 1: Webhook (Push) - OneAccess Initiated

OneAccess initiates the staff data sync after its CCMP portal access request is approved.

**Pros:**
- OneAccess can initiate push of staff data immediately after approval process is completed
- No dependency on 3rd party system to kick off the staff data sync process
- One API call is sufficient to trigger whole staff data sync process

**Cons:**
- SailPoint only supports SCIM API as the only integration option
- New SCIM API is required to be part of entitlement platform

### Option 2: API (Pull) - Entitlement Initiated

Entitlement initiates the staff data sync only after receiving an indicator from 3rd party system about approved staff CCMP portal access.

**Pros:**
- Entitlement can leverage OneAccess existing Mesh API to pull staff data
- OneAccess doesn't need to make any change to support this solution option

**Cons:**
- Staff salary ID is a dependency for entitlement to pull specific staff data from OneAccess
- OneAccess is the only source to provide staff salary ID for entitlement to trigger the data sync process
- Two API calls are involved in the process instead of one SCIM API call

## References

- Cash Platform Glossary
