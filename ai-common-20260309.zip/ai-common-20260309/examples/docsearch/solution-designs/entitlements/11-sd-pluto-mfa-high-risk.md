# 11. SD: Pluto MFA - High Risk Transaction Additional Authorisation

## Release Scope

**Release:** ERM 25E3 - May 2025  
**Program:** Corporate Cash Management Platform  
**Project:** Corporate Cash Management Platform Tech  
**Project ID:** PR223065

## RACI

| RACI | Role | Entitlements |
|------|------|--------------|
| Responsible | Solution Designer | Jeslin Cyriac |
| Approval and signing off | Architect | Relevant architect for AIA/ACD |
| Consulted | Service Operations Manager | Craig Georgans |
| | IT Business Analyst | Adam Spencer |
| Informed | IT Delivery Lead | Scott Collins |
| | Engineering team | Andrew Sudduk |
| | ISG | Raj Vaishya |
| Reviewed | Product Owner | Sid Shekar |
| | Solution designer | Nitin Korishetty |

## Impacted System Summary

| System | Status | Description |
|--------|--------|-------------|
| 10x (A00A46) | ⭐ Change | - |
| Enterprise Customer IAM, Ping on ELZ (A00CCC) | ⭐ Change | - |

## Key Decisions

| Key Decision | Description |
|--------------|-------------|
| HRTAA Library generic | Will cater to all requests from any consuming app |
| Consuming app callback | Will pass callback function, payload and dispatch function |
| HRTAA callback to Multiverse | Expose callback function for multi-factor scenarios |
| Multiverse token update | Will update the stepped access token |

## User Story Traceability

| User Story | Title | JIRA | Status |
|------------|-------|------|--------|
| ART-36767 | SD for entitlement Library | ART-36767 | Done |

## Technical Debt

| Issue/Risk | Description | Component | Mitigation Date |
|------------|-------------|-----------|-----------------|
| SAFI integration delayed | For May 2025, PDP mimics SAFI callback with Step Up required for all requests | PDP - PingAuth Policy | Before Nov |
| Claim for identifying stepped up user | Ping will share stepped token with claim | Entitlement library | May or later |

## Solution Overview

This solution builds capability in the Pluto platform to enable Step Up for user activities where deemed required from Business, ISG or Digital Security.

When user initiates an activity in W1C or W1, the entitlement engine/Pluto will orchestrate calls between:
- **SAFI** (Stronger Authentication Foundation Infrastructure)
- **BioCatch** (User Behavior based Risk Scoring)
- **Pluto policies** to decide whether user needs to step up

**Assumption:** All PEP and PDP solutions build on existing Pluto Solution Platforms of PingAccess (PEP) and PingAuthorize (PDP).

### Implementation Timeline

| System Integration | Release |
|-------------------|---------|
| Payments Submit, Beneficiaries - all policies challenged at PDP | Aug 2025 |
| BioCatch Integration from PDP | Sep 2025 |
| SAFI Integration from PDP | Nov 2025 |
| Other High Risk Actions | Sep and Nov 2025 |

### Actions Requiring MFA

| Action | Release |
|--------|---------|
| INITIATE_PAYMENT | Aug 2025 |
| INITIATE_TRANSFER | Aug 2025 |
| CREATE_BENEFICIARY | Aug 2025 |
| MODIFY_BENEFICIARY | Aug 2025 |

**Non-Prod:** Amount threshold decides step-up requirement  
**Prod:** All amounts require step-up for May 2025

### Components

| Component | Owner | Changes |
|-----------|-------|---------|
| Entitlement UI Component | Pluto | New |
| Multiverse UI Component | W1 | New |
| Consuming App - Galaxy | Channels W1C | Minor |
| Ping CIAM | IDaaS | Major |
| PEP - PingAccess | IDaaS | Nil |
| PDP - PingAuth | IDaaS/Pluto | Significant (May & Sep) |
| BioCatch | DigiSec | Nil for May, Significant for Sep |
| SAFI | DigiSec | Significant for Sep |
| Exp API | Consuming App | Nil |
| Backend API | API Owner | Nil |

## Response Codes

| Scenario | Between | Response Code | Notes |
|----------|---------|---------------|-------|
| SAFI Approve Step Up | SAFI to PDP | Approve | - |
| | PDP to PEP | 200 or 500 | No changes |
| SAFI Denies | SAFI to PDP | Deny | - |
| | PDP to PEP | 403 | Pending PEP confirmation |
| SAFI Challenges OTP Success | Multiverse to Entitlements | 200 | - |
| | SAFI to PDP | Challenge | - |
| | PDP to PEP | 401 | - |
| SAFI Challenges OTP Cancel | MV to Entitlements | MFA_CANCELLED | `{"code": "MFA_CANCELLED", "message": "User cancel"}` |
| SAFI Challenges OTP Lock | MV to Entitlements | MFA_LOCKED | `{"code": "MFA_LOCKED", "message": "User locked"}` |
| All MV/Ping Errors | - | MFA_ERROR | `{"code": "MFA_ERROR", "message": "Unknown Error"}` |

## Entitlement Component

A React component that can be imported into any MFE:
- Call Multiverse Module when apiStatus is 401
- Handle Callback from Multiverse for different OTP scenarios
- Callback Channel or consuming app with responses for 204, 423 or other required scenarios

## Component Changes

### PDP (Aug 2025)

1. **Validate access_token:** If claim `acr` has value "MFA", do not proceed with Step Up. If missing, proceed with Step Up.

2. **BAU user permission:** If success proceed to Step 2, otherwise respond with BAU error codes.

3. **ACTION validation:** For INITIATE_PAYMENT, INITIATE_TRANSFER (May 2025):
   - **Prod:** Respond with 401
   - **Non-Prod:** If Amount > threshold, respond with 401
   
   Amount identified from payment payload:
   ```json
   "instructedAmount": {
     "amount": "123.00",
     "currency": "AUD"
   }
   ```

4. For all other ACTIONs, behave as BAU.

### Multiverse Component

- Make OTP call and present interface for user to populate OTP
- Update new access token from Ping to user Redux store
- Call SAFI to notify when Step Up is complete

### Consuming App - Galaxy MFEs

Standardise error handling:
- Entitlement library returns error codes 204 and 423
- Calling application expected to handle these scenarios

## Entitlement to Multiverse Parameters

| Parameter | Type | Source | Purpose |
|-----------|------|--------|---------|
| scope | Object | Access token scope | Identify application |
| clientTransactionId | Object | sessionIndex + x-appCorrelationId | Notify call to SAFI |
| SAFITransactionId | Object | PDP response | Notify call to SAFI |
| clientID | String | Access token clientID | Identify client to Ping |
| clientURL | String | callbackBaseUri per environment | Pass to Ping |
| acr_values | String | PDP response | Pass to Ping |
| callback_EntitlementsWidget | Function | (correlationID, access_token, error_object) | Callback from Multiverse |

## NFR

| NFR Metrics | Category | Value | Component |
|-------------|----------|-------|-----------|
| Max Volume | Volume | 4,601,998 daily | All components |
| TPS - Peak | Performance | 2 TPS | All components |
| TPS - Average | Performance | 1 TPS | All components |
| Reliability | Reliability | N/A | PingOne existing, rest in MESH |
| Availability | Availability | No Change | - |
| Monitoring | Monitoring | No Change | - |

### MFA NFR Steps

1. User submits request to PDP
2. PDP calls SAFI (out of May scope)
3. Client side library calls W1 modal initiating Step Up
4. W1 negotiates with PingOne on Step Up
5. User captures TOTP and clicks Submit
6. Client side library calls target API after OTP complete

## Error Handling

| Error Scenario | Description | Severity | Behaviour |
|----------------|-------------|----------|-----------|
| Galaxy can't access HRTAA library | Module load/compile error | High | - |
| HRTAA can't access Multiverse | Module load/compile error | High | - |
| Step up cancelled by user | User cancelled during process | Low | HTTP 204 No Content |
| Step up locked after x attempts | Step up blocked, user can do other transactions | Low | HTTP 423 Resource Locked |

## References

| Document Type | Link |
|---------------|------|
| SAFI API | cap-custsvcmgt-custsecyverifctn-adaptvauth-v2 |
| BioCatch API | cap-nonfinriskclassmgt-cybrriskmgt-bhvrlbiomtrcsbiocatch-v1 |
| W1 Support document | How to Use the Widget (PingMFA-v1) |
| W1 MFA | MFA tasks |
| Ping Solution Design | Solution Design - Westpac One MFA |
| RFC-9470 | https://www.rfc-editor.org/rfc/rfc9470.html |
| SAFI Integration ACD | ACD - PR242944 |
| MFA Step up | Architecture for MFA and Step Up |

## Glossary

See Cash Platform Glossary.
