# 01. SD: User Authorisation

## Document Control

| Version | 0.1 |
|---------|-----|
| Status | Work in progress / Final draft / Final (issued for Sign-off) |
| Baseline Date | 30 June 2023 |

## RACI

| RACI | Role | Person |
|------|------|--------|
| Responsible | Solution Designer | Rajendra Varma, Zane Zuo |
| | Development Lead | TBA |
| Approval and signing off | Technical Lead | Dave Hyland, Adam Oakman |
| Consulted | Service Operations Manager/Systems Manager | TBA |
| Consulted if Applicable | Integration Architect | Amol Chendvankar |
| | IT Business Analyst | Sid Shekar, Adam Spencer |
| | Solution Architect | Dave Hyland, Adam Oakman, Ave Cahyadi |
| Informed | IT Project Manager - Application | Vishal Verma |
| Reviewed | Product Business Analyst | Sid Shekar, Adam Spencer |

## Impacted System Summary

| System | Status | Description |
|--------|--------|-------------|
| WDP UI Framework (A00778) | ⭐ Change | Leverage WDPUI Framework to develop CCMP SPA and MFE for frontend UI/UX |
| Westpac Mesh (A008E0) | ⭐ Change | |
| 10x (A00A46) | ⭐ Change | |
| FIS (A013D9) | ⭐ Change | |
| GCM (A0028E) | Existing | |
| Cash Platform (A014A6) | 🟩 New | |
| PAG (A00605) | Existing | |
| Trading Bank (A0004) | Existing | |
| Ping Federate | Existing | |
| Ping Directory | Existing | |
| Ping Authorise | Existing | |

**Legend:** ⭐ - Change | 🟩 - New | 🔵 - Existing | ⬜ - Decommission

## Key Decisions

| ID | Status | Date | Decision | Decision Taken | Who |
|----|--------|------|----------|----------------|-----|
| KD_01 | Closed | 09 Aug 2023 | Ping Federate act as IdP and SP to authenticate CCMP user with pre-defined username and password | This is a tactical solution designed to meet CCMP Beta delivery scope | Architecture |

## Solution Overview

### Business Use Cases

WIB customer requires the ability to transfer funds in real time from one account to another, both accounts owned by the same customer and hosted within the Cash Platform.

### Customer Journey

The customer initiates a single credit transfer between their own accounts. Channel identifies that both debit and credit accounts belong to the same customer and sends an **On-Me indicator** in the payment request. Cash Platform then makes the On-Me determination and posts both debit and credit to the appropriate accounts held within 10x using a transaction code applicable for On-Me transfers.

## Functional Components and Subcomponents

### Entitlement Check Matrix

| # | Journey | Module | Entitlement | Notes |
|---|---------|--------|-------------|-------|
| 1 | Arrive at 'Cash Portal' landing page | Accounts Module | User RAR has authorization_details.user.claims containing "view all" access to accounts | |
| 2 | Accounts "balance only" view | | User RAR has "balance-only view" access in accounts | |
| 3 | | Payments Module | User RAR has "view all" access to payments | |
| 4 | Payments "action only" view | | User RAR has "action-only view" access to payments | |
| 5 | Make a Payment | | User RAR has "initiate-payment" access to payments | |
| 6 | Make a Transfer | | User RAR has "initiate-transfer" access to payments | |
| 7 | Arrives at 'Manage Accounts' page | | Call entitlement service and run accounts search for organization and user | |
| 12 | User clicks on 'Make a payment' | | User is entitled to Make a Payment | User RAR |
| 13 | Account is enabled for Payments | | Accounts RAR for account has action containing initiate-payment | |
| 14 | User clicks on 'Make a transfer' | | User is entitled to Make a Transfer | User RAR action containing initiate-transfer |
| 16 | Arrives at 'Make a payment' page | | Call entitlement service for accounts that can initiate payment | |
| 22 | Payment within Organisation's daily limit | | Server run check for payment amount | Static attribute check on graph endpoint |
| 23 | Payment within User's daily limit | | Server run check for payment amount | Stretch goal |

### User Access Requirements

**From Account:**
- Search "from" account using account number or name
- Only display payment enabled account
- Only display initiate transfer enabled account
- Only display account belonging to customer user's organisation

**To Field:**
- Search "to" account using account number or name
- Only display receive transfer enabled account
- Only display entitled beneficiary account

**Payment Method:**
- Only display entitled payment method
- Only display organisation entitled payment method

**Limits:**
- User daily limit check - Only allow payment at or below daily limit
- Organisation daily limit check - Only allow payment at or below daily limit

## Component Mapping

| Ref # | Name | Technology/Framework | Description |
|-------|------|---------------------|-------------|
| CM-01 | WDPUI | Framework | |
| CM-02 | NGINX External API Gateway | Technology | |
| CM-03 | NGINX Ingress Controller | Technology | |
| CM-03a | Ping Plug-in | Technology | Simplify authentication and authorization for API services behind API gateway |
| CM-04 | PingFederate | Technology | Identity Provider |
| CM-05 | PingDirectory | Technology | Directory services |
| CM-06 | PingAuthorize | Technology | Authorization engine |
| CM-07 | Neptune DB | Technology | Graph-based datastore for entitlements |
| CM-08 | Gremlin-driver | Framework | Graph traversal language for database agnostic querying |
| CM-09 | Java 11 | Technology | Underpinning technology for microservices |

## Solution Component Change Summary

| # | Component | Change | Details |
|---|-----------|--------|---------|
| 1 | External API Gateway | NEW | gw-nominated_representative / gw-agent - API flow for different user categories |
| 2 | Mesh API Ingress Controller | MODIFY | Configure PingIdentity plugin for PingFederate ELZ, PingAuthorize integration |
| 3 | PingFederate on Ping ELZ | MODIFY | New Mesh provider mediation component configuration |
| 4 | PingAuthorize on Ping CIAM ELZ | MODIFY | New Mesh provider mediation component configuration |

## User Authorisation Sequence

### Technical Components / Services - User Login

| Sequence | Description | API Name | API Layer | Operation |
|----------|-------------|----------|-----------|-----------|
| 1 | User Logs into CCMP SPA with login flow | ccmp-singlepageapplication | UI | GET /ccmp |
| 2 | User click on 'Manage accounts' | ccmp-account-microfrontend | UI | POST /token?rar=accounts |
| 3 | Call RAR token endpoint (accounts) | extGw_pingAuthKong | External gateway | POST /token?rar=accounts |
| 4 | Call RAR token endpoint (accounts) | Ping Authorize | Ping Authorize | POST /token?rar=accounts |
| 5 | Create RAR token | Ping Authorize | PingFed | |
| 6 | Get associated account data | PingFed | | GET /accountContext |
| 7 | Get associated account data | ccmp-account-inf-api | Information | GET /accountContext |
| 13 | Get user accounts | extGw_pingAuthKong | Ext Gateway | GET /accounts |
| 14 | Create Enriched token | PingFed | Ping Federation | |
| 15 | Get enriched account data | ccmp-account-inf-api | Information | GET /accounts |
| 16 | Get enriched account data | graphDb | | |
| 20 | Get user accounts | ccmp-account-exp-api | Experience API | GET /accounts |
| 21 | Evaluate token - policy evaluation for user access | ccmp-account-exp-api | Experience API | |
| 24 | Get account data | ccmp-account-cap-api | Capability | POST /accounts |
| 25 | Search subscriptions Service Proxy | 10x-service-proxy-api | Proxy | POST /accounts |
| 30 | Get accounts by identifiers | col-info-api | Information | POST /accounts |
| 31 | Retrieve account detail and balances | COLs DB | | |
| 35 | Map colInfApi/TB response data to common format | ccmp-account-cap-api | Capability | |
| 38 | Filter accounts | extGw_pingAuth | Ext Gateway | |
| 40 | Screen rendered utilising RAR | ccmp-account-microfrontend | MFE | |

## References

### ACD
- CCMP Entitlements ACD

### AIA
- AIA - CCMP Entitlements

### SOAP/SD
- SOAP: Initiate Payment - Channels
- SOAP: PEP Enablement - Entitlement Integration
- SD - Channel Authentication and Authorisation

### Non-functional Requirements
- Payments Non Functional Requirements

### Security Aspects
- 5.0 Security Architecture
- 04. Entitlements - Solution Design artefacts

### Glossary
- Entitlements and Security Glossary
- Program Glossary

### JIRA Features
- ART-3703: Finalise Solution Design (Initiate Payments) - Done
- ART-3704: ENABLER: ACD for Entitlements - Initiate Payments - Done
