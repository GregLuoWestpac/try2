# 04. SD: Customer User Profile - Foundation

## Release Scope

**Program:** Corporate Cash Management Platform  
**Project:** Corporate Cash Management Platform Tech  
**Project ID:** PR223065  
**Status:** IN REVIEW

## RACI

| RACI | Role | Entitlements |
|------|------|--------------|
| Responsible | Solution Designer | Zane Zuo |
| Approval and signing off | Technical Lead | Dave Hyland, Adam Oakman |
| Consulted | Integration Architect | Amol Chendvankar |
| | IT Business Analyst | Sid Shekar, Adam Spencer |
| | Solution Architect | Dave Hyland, Adam Oakman, Ave Cahyadi |
| Informed | IT Project Manager | Vishal Verma |
| Reviewed | Product Business Analyst | Adam Spencer |
| | Product Owner | Sid Shekar |

## Impacted System Summary

| System | Status | Description |
|--------|--------|-------------|
| Cash Platform (A014A6) | ⭐ Change | Bring organisation structure setup capability into CCMP platform |
| Ping Directory | 🟩 New | Define CCMP platform level organisation and user object schema |
| Ping Federate | ⭐ Change | Connect to Ping Directory to retrieve organisation and user account info |

## Assumptions

| ID | Status | Date | Assumption | Mitigation |
|----|--------|------|------------|------------|
| A_3757_002 | In progress | 21 Aug 2023 | For Beta release, customer user password will be manually generated in Ping | Admin user manually creates through UI |
| A_3757_003 | In progress | 21 Aug 2023 | For Beta release, linkage between customer user profile and organisation | No mitigation |

## Dependencies

| ID | Description | Notes |
|----|-------------|-------|
| D-001 | Availability of IdP (Ping Directory and Ping Federate) | Ping Directory hosts user identity structure and profile |
| D-002 | LDAP organisation and user account object structure design readiness | Defines attributes stored |
| D-003 | Availability of Policy Information Point (PIP) | For Beta, Ping Directory stores organisation and user data |
| D-004 | PKCE configuration to support customer user account and password | Customer user requires pre-defined username/password for login |
| D-005 | Access token contains user authorisation attributes from Ping Federate | Entitlement policy baked into Ping Federate |

## Key Decisions

| ID | Status | Date | Decision | Decision Taken |
|----|--------|------|----------|----------------|
| KD_3757_001 | OPEN | 21 Aug 2023 | For Beta, entitlement policy is that all banking resources are available to customer users | Due to absence of PDP (Ping Authorise) to enforce granular policy |
| KD_3757_003 | OPEN | 21 Aug 2023 | For Beta, organisation/user/account info entered into PIP via IdaaS process | Follows existing operation process defined by IdaaS team |
| KD-3757_004 | OPEN | 21 Aug 2023 | For Beta, customer user profile created in Ping Directory through IdaaS process | Removes dependency on integration between entitlement and GCM |
| KD-3691_001 | OPEN | 21 Aug 2023 | Customer user types (customer user, customer admin, staff user, staff admin) follow architect's IAM domain model | Will be implemented in both IdP and PIP |

## User Story Traceability

### Create Customer User

**User Story:** Create customer user in the entitlements solution when a customer (organisation) needs access.

**Required Attributes:**

| Attribute Name | Source |
|----------------|--------|
| CIS Key | CIS/GCM |
| Customer User Name | GCM |
| Customer User Status | GCM |
| Customer User Entity Type | GCM |
| Customer User Portal Status | Portal/Channel |
| Login ID | Identity Solution |
| Customer (organisation) of the user | Entitlements Solution |
| List of entitlements assigned to the user | Entitlements Solution |

**GCM Field Mapping:**

| Attribute Name | GCM Field Definition | GCM Field Name (IFF) |
|----------------|---------------------|---------------------|
| Customer User Name | TBC | TBC |
| Customer User Entity Type | Involved Party Type | IP_Tp_Id |
| Customer User Status | Life Cycle Status Type | Cst_LCS_Tp_Id |

### Identity Solution Attributes

| Attribute Name | Source |
|----------------|--------|
| Login ID | Identity Solution |
| Password | Identity Solution |
| Customer User name | GCM |
| Customer User Portal status | Portal/Channel |

## Out-of-scope

| ID | Description | Notes |
|----|-------------|-------|
| OOS-001 | Ping Directory and Ping Federate setup and configuration | Infrastructure delivery team responsible |
| OOS-002 | Organisation and user group object design | Entitlement architect covers this |
| OOS-003 | Ping data synchronisation feature setup | Delivered as part of Ping Directory |
| OOS-004 | Data synchronisation | For Beta requires manual entry of customer user details |

## Solution Overview

Customer Users will be established in the Policy Information Point (PIP), in this case Ping Directory (SOAP: CCMP Entitlements - Directory Schema Foundations) in a structure that conforms to the CCMP - Entitlements: Model.

For the Beta release a flat organisation structure is required:
- Single Organisation Unit
- A few accounts
- Single user

For Beta, data will be manually sourced from GCM and entered into the PIP:
- Organisation created as Org-Unit under Org-Entities
- Each account created as Banking Resource linked via attributes to the org-unit
- Both org-unit and accounts have the initiate-payment attribute

### Systems

| System | Description |
|--------|-------------|
| Ping Directory | Entitlement PIP (Policy Information Point) and IdP (Identity Provider) to host organisation, user and account data |
| Ping Federate | Authorisation server providing authentication services |

## Data Model

### IAM Data Model Attributes

| Attribute | Description | LDM Object | LDM Object Element |
|-----------|-------------|------------|-------------------|
| CIS Key | Unique key for every involved party (customer user account) | LDM 1000 for Identity | iamXrefID |
| Customer User First Name | Customer user's first name in GCM | LDM 1100 for Human | iamHumNameFirst |
| Customer User Last Name | Customer user's last name in GCM | LDM 1100 for Human | iamHumNameLast |
| Customer User Status | Customer user account status in GCM | LDM 1000 for Identity | iamStatus |
| Customer User Login ID | Customer user's CCMP portal login id (username) | LDM 1800 for Authentication | iamAuthAliasValues |
| Customer User Password | Customer user's CCMP portal login password | LDM 1800 for Authentication | userPassword |

### Identity Domain Objects

- Identity (1000)
- Human (1100)
- Authentication (1800)

### User Data Requirements

- CIS Key (from GCM)
- First Name (from GCM)
- Last Name (from GCM)
- User Status (from GCM)
- User Portal Status
- Login ID (to be decided)
- Password (generated by identity solution)
- Portal status (Active, Inactive - set for Portal access only)

### RAR - Rich Authorisation Requests

Example RARs for both accounts and organisations for UI rendering:

```json
"authorization_details": [
  {
    "type": "users",
    "users": [
      {
        "id": "4334643",
        "actions": ["view", "manage"]
      }
    ]
  }
]
```

## Integration Diagram

Future integration in and out of Ping Directory will be required to keep the PIP synchronised with Organisation and Account changes in their respective systems of record:

- **Outbound synchronisation:** Ping Directory → Neptune graph database via Ping Data Sync
- **Inbound synchronisation:** 10X and GCM → Ping Directory via customer API and listener

## Operational Impacts

For Beta release, entitlement squad engineer will manually create following records in Ping Directory:
- Organisation details
- User details
- Account details

## References

- ACD - CCMP Entitlements
- CCMP - Entitlements: Model
- AIA - CCMP Entitlements
- Architecture for Customer Users (SOAP)
- Payments Non Functional Requirements
- 5.0 Security Architecture
- Program Glossary
- CCMP - Entitlements: First User Onboarding
- ART-3757: Draft Requirements and Acceptance Criteria - Customer User Profile
