# 00. SD: Setup & Administration

## Document Control

| Version | 0.1 |
|---------|-----|
| Status | Work in progress / Final draft / Final (issued for Sign-off) |
| Baseline Date | 30 June 2023 |

## Change Management Summary

| Release | Version | Summary of Change |
|---------|---------|-------------------|
| Beta | 0.1 | Initial document |

## RACI

| RACI | Role | Person |
|------|------|--------|
| Responsible | Solution Designer | Rajendra Varma, Zane Zuo |
| | Development Lead | TBA |
| Approval and signing off | Technical Lead | Stuart Johnson, Dave Hyland, Adam Oakman |
| Consulted | Service Operations Manager/Systems Manager | TBA |
| Consulted if Applicable | Information Architect | TBA |
| | Integration Architect | Amol Chendvankar |
| | IT Business Analyst | Adam Spencer |
| | Operational Readiness Engineer | TBA |
| | Solution Architect | Dave Hyland, Adam Oakman, Ave Cahyadi |
| Informed | IT Project Manager - Application | Zoe Shirley |
| | Non Production Data Life-cycle Management | TBA |
| Reviewed | Product Business Analyst | The Business analyst that defined the user stories |
| | Product Owner | Dipika Guruprasad or Chris Goldie |
| | Solution designer | One of the Solution designers for peer review |

## Solution Overview

### Business Use Cases

WIB customer requires the ability to transfer funds in real time from one account to another, both accounts owned by the same customer and hosted within the Cash Platform.

### Customer Journey

Channels own the customer journey, but a high-level view is provided here to highlight the request and the response.

The customer initiates a single credit transfer between their own accounts. Channel identifies that both debit and credit accounts belong to the same customer and sends an **On-Me indicator** in the payment request. Cash Platform then makes the On-Me determination based on the indicator and posts both debit and credit to the appropriate accounts held within 10x using a transaction code applicable for On-Me transfers. The synchronous response back to the Channel (and ultimately from the Channel to the end customer) includes the completion of both debit and credit legs.

## Business Process Flow

### Staff Entitlement Define and Approve
[Process diagram placeholder]

### Customer Entitlement Define and Approve
[Process diagram placeholder]

### Lifecycle

| Aspect | Details |
|--------|---------|
| Administration of entitlements | Set up |
| | Maintenance |
| | Ownership |
| | Federation |
| Storage of entitlements | [Details] |
| Enforcement | [Details] |

### Systems

Gives a high-level description for the systems included. Generic system pages can be included from the Solution Design Naming reference. These are referenced within several solution designs so they are meant to give generic information about the system.

## Diagrams

Diagrams and description of such diagrams, for the systems involved include a high-level description - or a reference to documentation about each system.

Depending on the use case this might be:
- Diagram of the systems involved
- Sequence diagram
- PlantUML source (use "Expand" capability with code block for plantUML code)

## User Interfaces

Include references and details on user interfaces:
- OVA: FIS
- Servicing tool
- Reports
- App Dynamics and Splunk (for operations)
- References to work from the Galaxy squad (channel/customer/staff UI)

## Technical Interfaces

Technical interfaces between the different systems - if the details down to field level on how the systems will talk is provided by a downstream system then links to that documentation should be included.

Types:
- Messages
- File specs
- Events mapping

### Mesh APIs

| Availability | Type | Description |
|--------------|------|-------------|
| Private | Only to be used within the Cash Platform domain | |
| Connecting WBC to the world | Pass-through | Endpoint on mesh gateway. Headers: Might change. Request and response: Will be the same. |

## Data Involved

See "6. Data" documentation for reference on what to include.

## References

### ACD
Include a link to the ACD.

### Non-functional Requirements
See: Payments Non Functional Requirements

### Security Aspects
- Security Architecture: 5.0 Security Architecture
- User access: 04. Entitlements - Solution Design artefacts

### Glossary
Reference the Program Glossary for terminology.

### JIRA Feature
- ART-3704: ENABLER: ACD for Entitlements - Initiate Payments (Done)
