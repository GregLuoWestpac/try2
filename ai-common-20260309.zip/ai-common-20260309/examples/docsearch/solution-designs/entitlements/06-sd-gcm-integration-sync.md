# 06. SD: GCM Integration and Sync

## Release Scope

**Program:** Corporate Cash Management Platform  
**Project:** Corporate Cash Management Platform  
**Release:** May-24

## RACI

| RACI | Role | Person |
|------|------|--------|
| Responsible | Solution Designer | Zane Zuo |
| Approval and signing off | Architect | Relevant architect for AIA/ACD |
| Consulted | Integration Architect | Amol Chendvankar |
| | IT Business Analyst | Adam Spencer |
| Informed | IT Delivery Lead | Vishal Verma |
| | Engineering team | Tai Bello |
| | Testing team | Vincent Guan Canterbury |
| | ISG | Raj Vaishya |
| Reviewed | Product Business Analyst | Adam Spencer |
| | Product Owner | Sid Shekar |
| | Solution Designer | Mark Chan |

## Impacted System Summary

| System | Status | Description |
|--------|--------|-------------|
| GCM (A0028E) | 🔵 Existing | Consume existing GCM Customer Snapshot Event Topic via Mesh Kafka Events |
| Mesh (A008E0) | ⭐ Change | New Kafka listener API for receiving events from GCM Mesh Kafka. New INF API to transform data |
| Ping ELZ (A00CCC) | 🔵 Existing | Inject customer organisation associated individual and W1C portal access data |

## Assumptions & Risks

| ID | Type | Description | Notes |
|----|------|-------------|-------|
| A-ART-5687-001 | Assumption | Customer organisation and customer user has valid and unique CIS Key in GCM | Entitlement Kafka listener uses CIS Key as key identifier to filter CCMP organisation |
| A-ART-5687-002 | Assumption | Separate customer organisation onboarding process will validate CIS Key in GCM | Entitlement relies on frontend onboarding process |
| A-ART-5687-003 | Assumption | GCM is the source of truth for CCMP customer organisation and associated individuals | Only considering GCM as master record and data source |
| A-ART-5687-004 | Assumption | GCM can meet entitlement platform defined data update latency criteria | Entitlement must keep customer org users data in sync |
| R-ART-5687-001 | Risk | Lack of information about W1C customer organisation onboarding process | Risk of invalid entitlement solutions |

## Constraints & Dependencies

| ID | Type | Description |
|----|------|-------------|
| D-ART-5687-001 | Dependency | Solution depends on CCMP onboarding process to sync all onboarded customer orgs |
| D-ART-5687-003 | Dependency | Final Ping Directory LDM to store IP, IP-AR relationship |
| D-ART-5687-004 | Dependency | Readiness of GCM integration SOAP document from entitlement squad architect |

## Key Decisions

| ID | Status | Date | Decision | Decision Taken | Who |
|----|--------|------|----------|----------------|-----|
| KD_ART-5687_001 | CLOSED | 02 Nov 2023 | Entitlement GCM integration does not validate customer org CIS Key | GCM as source of truth and master of customer org data | Entitlement Architect |
| KD_ART-5687_002 | CLOSED | 02 Nov 2023 | Requires CCMP specific cross reference | Use CIS Key as identifier for organisation, individual, IP-AR filtering | Solution Designer |
| KD_ART-5687_003 | CLOSED | 02 Nov 2023 | Entitlement only contains subset of GCM data (IP and IP-AR) | Entitlement is not replicating GCM | Entitlement Architect |
| KD_ART-5687_004 | CLOSED | 02 Nov 2023 | One-way sync between GCM and Entitlement. GCM as master | GCM is master record, Entitlement is consumer | Entitlement Architect |
| KD_ART-5687_005 | CLOSED | 02 Nov 2023 | Provide capability to receive updated IP and IP-AR data directly | Covers scenarios if GCM cannot publish updated data | Entitlement Architect |

## Solution Overview

This solution has two major parts:

1. **Technical capability** to allow GCM data flow from GCM into Ping Directory
2. **Data pipeline** to support data transformation and orchestration between GCM and Ping Directory

### Key Components

**GCM - Ping Directory Integration via Mesh APIs:**

1. **Kafka Listener** - Entitlement dedicated Mesh Kafka listener to receive Customer Organisation and associated Individual data plus W1C portal access service records

2. **Data Orchestration CAP API** - Entitlement dedicated Mesh CAP API for:
   - Customer Organisation (IP) data → Graph DB
   - Customer Organisation W1C portal access (IP-AR) data → Graph DB
   - Customer Organisation Associated Individual W1C Portal Access (IP-AR) data → Ping Directory & Graph DB
   - Customer Organisation owned Account (AR) data → Graph DB
   - Customer Organisation and owned Account relationship (IP-AR) data → Graph DB
   - Customer Organisation to Organisation relationship (IP-IP) data → Graph DB

## Out of Scope

- Receiving customer organisation data after onboarding from Workflow system
- Receiving customer organisation account data from 10X
- Receiving inter-organisation relationship data (IP-IP) from GCM
- Modification of existing Customer Identity Registration Management CAP API
- Modification of existing Ping Directory Proxy API
- Any design related to injecting data into Graph DB (AWS Neptune)

## Integration Flow

### Flow A (Account Opening)
1. Orkus as part of account openings calls IROM PUT /resources with new account
2. IROM calls Neptune DB to update account details and set modId = 0

### Flow B (GCM Events)
1. GCM sends arrangement events when accounts created or changed
2. Event listener consumes events and filters where modId > 0 and isDelta is met
3. Listener calls IROM API PUT /resource with accounts satisfying conditions
4. IROM calls Neptune DB to update account details

## NFR Requirements

| NFR Metrics | Category | Metric Value | Component |
|-------------|----------|--------------|-----------|
| Max Volume | Volume | 15,000 Per day | cap-technolsvcopsmgt-identaccsmgt-identregorch-v1 |
| | | 8,000 per day | inf-bnkng-party-custroleplyr-custsnpsht-apichnlentit-v1 |
| Average Volume | Volume | 1,000 per day | Both APIs |
| TPS - Peak | Performance | 2 TPS | CAP API |
| | | 1 TPS | INF API |
| TPS - Average | Performance | 0.5 TPS | Both APIs |
| Latency | Performance | 115 ms | CAP API |

## API Design

### APIs Involved

1. **GCM Customer Snapshot Event Topic Listener INF API** (inf-bnkng-party-custroleplyr-custsnpsht-apiidentregorch-v1)
   - Customer Organisation (IP) data
   - Customer Organisation associated individual (IP) data
   - Customer Organisation W1C portal access (IP-AR) data
   - Customer Organisation Associated Individual W1C Portal Access (IP-AR) data

2. **Data Orchestration CAP API** (cap-technolsvcopsmgt-identaccsmgt-identregorch-v1)
   - Create/Update operations for IP, IP-AR, AR data
   - Routes to Ping Directory and Graph DB

### Data Flow

| Data | Source | Destination |
|------|--------|-------------|
| Customer Organisation (IP) | Workflow System (Create), GCM (Update) | Graph DB |
| Customer Organisation Associated Individual (IP) | Workflow System (Create), GCM (Update) | Ping Directory, Graph DB |
| Customer Organisation W1C portal access (IP-AR) | Workflow System (Create), GCM (Update) | Graph DB |
| Customer Organisation Associated Individual W1C Portal Access (IP-AR) | Workflow System (Create), GCM (Update) | Ping Directory, Graph DB |
| Customer Organisation owned Account (AR) | 10x (Create & Update) | Graph DB |
| Customer Organisation and owned Account relationship (IP-AR) | 10x (Create & Update) | Graph DB |
| Customer Organisation to Organisation relationship (IP-IP) | Workflow System (Create) | Graph DB |

### API Operations

**Register Digital Identity:**
- Endpoint: `/cap/technolsvcopsmgt/accsidentmgt/invpartyidentreg/v2/digitalIdentityRegistrations`
- Method: POST

**Search Digital Identity:**
- Endpoint: `/cap/technolsvcopsmgt/accsidentmgt/invpartyidentreg/v2/digitalIdentityRegistrationSearch`
- Method: GET

**Update Digital Identity:**
- Endpoint: `/cap/technolsvcopsmgt/accsidentmgt/invpartyidentreg/v2/digitalIdentityRegistrations/{iamID}`
- Method: PUT

## Integration Impacts

| Source | Integration Type | Destination | Frequency | Impact |
|--------|-----------------|-------------|-----------|--------|
| Mesh INF API - GCM Customer Snapshot Event Topic | Mesh Kafka Event | Mesh INF API - Kafka Listener | Ad-hoc or daily | Dedicated listener for GCM data |
| Mesh INF API - Kafka Listener | API | Mesh CAP API - Entitlement Data Orchestration | Ad-hoc or daily | Routes to appropriate destinations |
| Mesh CAP API - Entitlement Data Orchestration | API | Mesh INF API - Ping Directory Digital Identity Proxy | Ad-hoc or daily | Injects data into Ping Directory |

## Error Handling

| Error Scenario | Failure Point | Severity | Description |
|----------------|---------------|----------|-------------|
| GCM Kafka Event Topic INF API error | GCM Kafka Event | High | Fail to publish updated GCM data |
| Entitlement GCM Kafka Event Listener INF API error | Listener API | High | Fail to process and send received GCM data |
| Entitlement Data Orchestration and Transformation INF API error | Orchestration API | High | Fail to process received GCM data |
| Involved Party Identity Registration Management CAP API error | CAP API | High | Fail to receive and pass data |
| Ping Directory Digital Identity Proxy INF API error | Proxy API | High | Fail to receive and send data to Ping Directory |

## Technical Debt

- New attribute required to store Customer User Status in GCM to Ping Directory Identity Object
- New attribute required to store Customer Service Arrangement Relationship Type in GCM to Ping Directory Service User Object

## References

| Document Type | Description |
|---------------|-------------|
| Feature Definition | ART-5687 - Entitlements - GCM Integration & Synchronisation |
| Feature Requirement | ART-5998 - Entitlements - GCM Integration and Synchronisation |
| High Level Requirements | ART-6012 - Entitlements - GCM Integration & Sync |
| GCM Integration SOAP | SOAP: CCMP Entitlements - GCM Integration |
| Customer Event Stream API | Customer Event Stream API - Customer Systems Architecture |
| Account Fulfilment E2E | Account Fulfilment E2E Design |
