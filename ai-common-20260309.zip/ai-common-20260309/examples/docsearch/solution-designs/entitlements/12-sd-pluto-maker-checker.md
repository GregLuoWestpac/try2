# 12. SD: Entitlements PLUTO Maker Checker

## Release Scope

**Release:** ERM 25E4 - Aug 2025  
**Program:** Corporate Cash Management Platform  
**Project:** Corporate Cash Management Platform Tech

## RACI

| RACI | Role | Entitlements |
|------|------|--------------|
| Responsible | Solution Designer | Jeslin Cyriac |
| | Development Lead | Andrew Suduk |
| Approval and signing off | Architect | Relevant architect for AIA/ACD |
| Consulted | Delivery Lead | Bryce |
| | IT Business Analyst | Adam Spencer |
| Informed | Testing team | Mahender Shaga |
| | SVP Testing | Adarsh Maheshwari |
| | ISG | Vikram Lamba, Raj Vaishya |
| Reviewed | Product Owner | - |

## Impacted System Summary

| System | Status | Description |
|--------|--------|-------------|
| Digital Service Request (A018DF) | 🟩 New | Application workflow team offering new solution to store approval tasks |
| A00CCC IdaaS Ping | ⭐ Change | Ping making changes to PEP component for orchestration |

## Key Decisions

| Key Decision | Decision Point | Options and Decision | Dated |
|--------------|----------------|----------------------|-------|
| KD-1 | Develop new API Client for XHR/fetch requests | - | - |
| KD-2 | Redirect URI from AuthorisationOrchestrationWidget | - | - |
| KD-3 | Use http 302 or 307 as response from PDP | HTTP 302 - temporary redirect with payload | 11 Mar 2025 |

## User Story Traceability

| User Story | Status |
|------------|--------|
| ART-6068 - Draft High level solution design - Entitlements - Authority Models | Done |
| ART-6069 - Draft Solution Design - Entitlements - Authority Models P2 | Done |
| ART-36060 - NFR for Maker Checker | Done |

## NFR

| Metric | MVP | MMP | Source |
|--------|-----|-----|--------|
| Volume TPS | 3000/day (0.17/sec) | 50,000/day (1.763/sec) | COL |
| Latency PingAuth and PingAccess | 300ms < 95%, 900ms < 99% | Based on Entitlements NFR | - |
| DSR | 300 ms | - | - |
| DR | Not applicable (no new infra) | MESH Topic relies on MESH resilience | - |

### PingAccess Logging

- Headers: x-channelRequestId, x-appCorrelationId, x-messageId
- Flow direction (PingAccess to PingAuth, to GTS GW, to Target API, to Client)
- HTTP code and message code

### PingAuth Logging

Headers: x-appCorrelationId, x-channelRequestId, x-messageId, sessionIndex

**Note:** sessionIndex populated from Customer Access token, empty for Staff.

## Technical Debt

1. User error in case Target API fails is not communicated correctly

## Solution Overview

### Components

| Component | Type | Ownership | Description |
|-----------|------|-----------|-------------|
| Maker Checker MFE/EXP API | MFE and EXP API | Channel | Support Authoriser/Approval UI and backend calls with DSR API |
| AuthProcessOrchestration | Widget and EXP API | Entitlements | Reusable component for MFEs when PDP responds with 302 |
| AuthorisationEventTopic | MESH Kafka Topic | Entitlements | Store terminal state events (APPROVED, REJECTED) |

### Requirements Summary

- Validate authority model for transaction based on user, payload and URI
- Publish terminal events (FULLY APPROVED and REJECTED) to AuthorisationEvents Topic
- Call API to create and patch service requests at DSR
- Call Experience API of Transaction and submit payload to EXP API endpoint
- Respond to Transaction MFE or Maker Check MFE with status (COMPLETED, AUTHORISATION REQUIRED, REJECTED, Errors)
- Minimum or no change to client

## Option 1 (Production Solution)

**Maker:** Submit from Payment MFE  
**Checker:** Submit from Maker Check MFE to instantiate Payment MFE (Payload from redux), user submits from Payment MFE, call to EXP API intercepted by PDP

- PDP makes decisions on all Authority Model
- PEP orchestrates all calls to DSR API (CAP API - gts-authorisations-management-v1 owned by Entitlements)
- All Channel calls (Staff/Customer) must pass x-channelRequestId with TransactionIdentifier and protected-orgId with OrganisationCIS Key

### Pros
- PEP orchestration with DSR and Kafka topic scales better for other channels (Qvalent)

### Cons
- Scripting in PEP done using Groovy script, not owned by Entitlements
- New endpoints need to be whitelisted on PEP
- If target API is CAP API, DSR API must call CAP API instead of PEP
- 6000 character limitation in AdditionalInformation field

## Maker Flow

1. Request hits PDP, validates and identifies maker checker requirement
2. PingAuth generates payload with deny statement to PingAccess
3. If makerRequest.status = PENDING, PingAccess sends payload to GTS CAP API
4. GTS CAP API validates and maps to WAW API payload
5. WAW API response validated and translated by GTS CAP API
6. PingAccess passes response back to client

## Checker Flow

1. User views "Requests raised" and "Requests pending" (pulled from DSR)
2. Channels retrieve information including original GTS CAP API payload
3. User clicks 'Send for Authorisation', calls dummy API POST /approvalWorkflowConsent
4. PingAuth validates and identifies if approver is last approver
5. If last approver, sets makerRequest.status = APPROVED
6. PingAccess forwards payload to GTS CAP API
7. GTS CAP API maps to WAW API (PATCH /approvalWorkflows)
8. If fully approved, PingAccess calls target API with approver's access token
9. PingAccess passes target API response to client

## PingAccess Maker Checker Scripts

| makerChecker.Status | Flow | HTTP Code | Details | Response Code |
|---------------------|------|-----------|---------|---------------|
| NEW | Maker | 401 | - | 8125 |
| PENDING | Checker | 401 | Awaiting more approvals | 8125 |
| APPROVED (GTS success) | Checker | Original EXP API response | EXP API successful | 8120 |
| APPROVED (GTS failed) | Checker | 207 | EXP successful, GTS failed | 8120 + 8135 Partial |
| REJECTED | Checker | 200 | Checker rejected | 8130 |

## Approval/Rejection Flow

### Consent Payload
```json
{
  "approvalWorkflowConsent": {
    "approvalWorkflowId": 1212313,
    "status": "APPROVED/REJECTED"
  }
}
```

## Endpoints for Maker Process

| Release | URL | Method | Action | User Type |
|---------|-----|--------|--------|-----------|
| Aug 2025 | exp/customer/galaxy/payment/v2/payees | POST /payments | INITIATE_PAYMENT, INITIATE_TRANSFER | Customer |
| Aug 2025 | exp/customer/galaxy/beneficiary/v2 | POST /beneficiaryCreate | CREATE_BENEFICIARY | Customer |
| Aug 2025 | exp/customer/galaxy/beneficiary/v2 | POST /beneficiaryUpdate | MODIFY_BENEFICIARY | Customer |

### Approval Endpoints

| Release | URL | Method | Action | User Type |
|---------|-----|--------|--------|-----------|
| Aug 2025 | /exp/customer/widget/galaxymakerchecker/v1/ | POST /approvalWorkflowConsent | AUTHORISE | Customer |

## PingAccess URL Mapping

| Map From | Map To |
|----------|--------|
| authz*/exp/customer/widget/galaxymakerchecker/v1/approvalWorkflowConsent | gw*/cap/gts/authorisations/management/v1/processAuthorisation |
| authz*/exp/customer/widget/galaxymakerchecker/v1/approvalWorkflowList | gw*/exp/widget/galaxymakerchecker/v1/approvalWorkflowList |
| authz*/exp/customer/widget/galaxymakerchecker/v1/approvalWorkflowDetails | gw*/exp/widget/galaxymakerchecker/v1/approvalWorkflowDetails |

**CORS Headers:** x-channelRequestId, protected-orgid

## Status Transitions

### Single Step - 1st Approver

| Action | makerRequest.status | step.status | task.status 1 | task.status 2 |
|--------|---------------------|-------------|---------------|---------------|
| Maker Flow | NEW | NEW | PENDING | PENDING |
| APPROVED 1/2 | PENDING | PENDING | APPROVED | PENDING |
| REJECTED 1/2 | REJECTED | REJECTED | REJECTED | PENDING |

### Single Step - Both Approvers

| Action | makerRequest.status | step.status | task.status 1 | task.status 2 |
|--------|---------------------|-------------|---------------|---------------|
| Maker Flow | NEW | NEW | PENDING | PENDING |
| APPROVED 1/2 | PENDING | PENDING | APPROVED | PENDING |
| REJECTED 2/2 | REJECTED | REJECTED | APPROVED | REJECTED |
| APPROVED 2/2 | APPROVED | APPROVED | APPROVED | APPROVED |

**Note:** For a step, if approvers < minAuthoriser, step.status = PENDING. When approvers APPROVED = minAuthorisers, step.status = APPROVED and maker.status = APPROVED.

## PDP Policy Activities

### New Request
1. Check Authority model - If authoriser exists
2. Add Step and AuthoriserGroup object and details
3. Populate values as per mapping table
4. Update authoriser.taskStatus to PENDING
5. Update existing Step status to PENDING
6. Update makerRequest.status to PENDING
7. Update createdAt and requestCreatedAt
8. Sign and update signature to payload

### Approval/Rejection Process
1. Check Authority model
2. Update step.workflowId from payload
3. Add workflowId to makerRequest.workflowIds array
4. Update authoriser taskStatus to APPROVED or REJECTED
5. Check if Terminal Status (all approved or rejected)
6. Update makerRequest.status (APPROVED or REJECTED)
7. Update Step status if changed
8. Add new Step if required with new authorisers
9. Sign and update signature

## References

- Cash Platform Glossary
