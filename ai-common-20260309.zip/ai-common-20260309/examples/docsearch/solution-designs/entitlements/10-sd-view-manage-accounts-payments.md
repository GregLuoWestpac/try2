# 10. SD: Solution Design for View Accounts, Manage Accounts and Initiate Payments

## Release Scope

**Release:** ERM 25E3 - May 2025  
**Program:** Corporate Cash Management Platform  
**Project:** Corporate Cash Management Platform Tech  
**Project ID:** PR223065

## RACI

| RACI | Role | Entitlements |
|------|------|--------------|
| Responsible | Solution Designer | Jeslin Cyriac |
| Approval and signing off | Architect | Relevant architect for AIA/ACD |
| Consulted | Service Operations Manager | Craig Georgans |
| | IT Business Analyst | Adam Spencer |
| Informed | IT Delivery Lead | Scott Collins |
| | Engineering team | Andrew Sudduk |
| | ISG | Raj Vaishya |
| Reviewed | Product Owner | Sid Shekar |
| | Solution designer | Ujjwal Khare |

## Impacted System Summary

| System | Status | Description |
|--------|--------|-------------|
| 10x (A00A46) | ⭐ Change | - |
| Cash Platform (A014A6) | ⭐ Change | - |
| Ping (A00CCC) | 🟩 New | - |

## Key Decisions

| ID | Statement | Description |
|----|-----------|-------------|
| KEY_01 | Use Server Side library | To abstract complexities of PLUTO PDP Proxy API to channels |
| KEY_02 | Use Mesh Widget Component instead | Mesh doesn't encourage EXP API calling another EXP API |

## Non-Functional Requirements

This feature follows Platform Level NFRs until MVP release (Nov 2025).

## Solution Overview

Channels require users to be authorised to perform certain features and functionalities. Entitlement solution provides **Attribute Based Access Control (ABAC)** to offer fine-grained privileges/permissions to W1/W1C users.

### Entitlement Ecosystem Components

| Component | Description |
|-----------|-------------|
| PEP | Policy Enforcement Point |
| PDP | Policy Decision Point |
| PAP | Policy Administration Point |
| PIP | Policy Information Point |

## In Scope

### View Accounts

Provides fine-grained access controls to secure:
- View Accounts (Account Listing) page in W1C UI
- Transaction Detail page in W1C UI

Transaction Listing (Account Activity Page) and Transaction Detail page have same attribute.

**Note:** There is no attribute control for Account Summary on Account Activity or Transaction Listing.

Enables search, filter and pagination security (e.g., search only returns accounts user has access to AND only returns based on search pattern).

| Policy | Subject | Action | Resource |
|--------|---------|--------|----------|
| View Accounts | Customer User | View Account List | Accounts\Summary |
| View Accounts | Customer User | View Account Details | Accounts\Details |
| View Transactions | Customer User | View Account Transaction List | Accounts\TransactionList |
| View Transactions | Customer User | View Account Transaction Details | Accounts\TransactionDetails |

### Initiate Payments

Provides fine-grained access controls to secure:
- Initiate Payments experience in W1C UI
- Initiate Transfer experience in W1C UI
- Enable secure search of accounts (only return accounts user has access to initiate payments from)

| Policy | Subject | Action | Resource |
|--------|---------|--------|----------|
| Initiate Payment | Customer User | Initiate Payment - Existing bene | Payments\Initiation |
| Initiate Payment | Customer User | Initiate Payment - New bene | Payments\Initiation |
| Initiate Payment | Customer User | Initiate Payment - Transfer | Payments\Initiation |

### Manage Payments

Provides fine-grained access controls to secure:
- View Payments experience in W1C UI

| Policy | Subject | Action | Resource |
|--------|---------|--------|----------|
| View Payment | Customer User | View Payments | Payments\View |

## Out of Scope

### Account Listing for viewAccounts and Payment Listing
- Sorting of BSB and Account numbers
- Pagination during query (PLUTO will share all list accounts for May release)
- Filtering of account response for any account numbers not controlled by policies
- Limitations on number of accounts channels would hold for MVP

### Initiate Payment
- Listing of beneficiaries
- Listing of payment types
- Will not manage display of payment summary
- Will not differentiate between initiate fund transfer and payment

## Query Call

### PDP API Types

| PDP API type | PDP API resource | Mesh functionality |
|--------------|------------------|-------------------|
| query | governance-engine/queries | view account list |
| query | governance-engine/queries | view payments |

### Query Limitations

At most:
- One attribute can be included without values (unbounded)
- Two attributes can be multivalued
- Three attributes can be included in query array, but not all three can be multivalued or unbounded

### Request Payload Format

| Field | Type | Required | Ping Authorize Framework | Example Value |
|-------|------|----------|-------------------------|---------------|
| service | string | no | Service | Mobile.Landing page |
| identityProvider | string | no | Identity Provider | CIAM |
| domain | string | no | Domain | w1c.westpac |
| attributes | map<string, string> | yes | Other Attributes | { "resource": "account:Iud7ta2B0yrG", "action": "create_payment"} |
| action | string | no | Action | Retrieve |

### Server Side Library

The server-side library resides with the experience API and abstracts PDP Proxy API functionality for Channel Server Side calls.

**Function:** `query()`

| Parameter | Data Type | Mandatory | Description |
|-----------|-----------|-----------|-------------|
| subject | string | Y | iamID |
| action | string | Y | VIEW_ACCOUNT |
| resource | string | N | account |

### Attribute Name Changes (Future)

| Current Value | New Value |
|---------------|-----------|
| Accounts.AccountIdRequest | RequestAttributes.AccountId |
| CustomerUser.CustomerUserId | RequestAttributes.CustomerUserId |
| Action | RequestAttributes.RequestAction |

## View Accounts Implementation

### Request Parameters

| # | Group | Parameter | Value | Comment |
|---|-------|-----------|-------|---------|
| 1 | group1 | attribute | "subject" | Referring to user |
| 2 | | attribute.values | <iAMID> | iam id from access token |
| 3 | group2 | attribute | "Action" | Action type |
| 4 | | attribute.values | VIEW_ACCOUNT | Action defined by entitlements |
| 5 | group3 | attribute | "Resource" | Resource type |
| 6 | | attribute.values | account | Resource referred |

### Account List Actions

| Label | Action | Resource |
|-------|--------|----------|
| View Activity | viewTransaction | Accounts.AccountId |
| Make Payments | initiatePayment | Accounts.AccountId |
| Transfer Funds | initiatePayment | Accounts.AccountId |

### Context Sample

```json
{
  "context": {
    "action": ["viewTransactions"],
    "resource": "/account/032002222"
  }
}
```

### Response Scenarios

**Scenario 1 - User has permissions:**
```json
{
  "authorised": true,
  "message": ""
}
```

**Scenario 2 - User has no permissions:**
```json
{
  "authorised": false,
  "message": "You do not have sufficient permission."
}
```

## Initiate Payment Implementation

### Widget Permissions
Permission on widgets uses existing flow - channels call Entitlement library with existing actions.

### Submit Payment
When user clicks "Submit Payment" after UI validations, payment API call is routed via PEP server and payment initiation validation is performed based on payload.

**Changes:**
- PEP Server configured to intercept and route call to PDP
- Validates payment payload against policy
- Based on permit: proceed to FIS; if false, return error message

### Pending Clarifications
- Error message to display to user
- Error message for Payment API rejection
- Embed correlation/request at PDP/PEP to payload/header for traceability

## PLUTO Package Functions

- `PolicyDecisionPoint.authoriseIndividual()`
- `PolicyDecisionPoint.authoriseBatch()`
- `PolicyDecisionPoint.query()`

## Authentication

MESH MFE components store keys (created by IdaaS Team) in MESH secrets in encrypted format. PDP Kubs access secrets manager during deployment process.

## Error Handling

### Query API
PDP Query API returns 200 even for mismatches in action/attribute/resource. Invalid requests return empty "results". PERMIT, DENY, INDETERMINATE, and NOT_APPLICABLE results not included in result.

### Error Codes

| Error Scenario | Description | Failure Point |
|----------------|-------------|---------------|
| 401 | Unauthorized Error | API doesn't have access to Proxy Query |
| 403 | Forbidden Error | API doesn't have permission to Proxy Query |
| 500 | Internal Server Error | JSON format errors |

## References

| Document Type | Link |
|---------------|------|
| Ping Policy Queries | PingAuthorize documentation |
| PDP API Contracts | JSON PDP API request and response flow |
| Action/Value Mapping | Data Mapping for Authorisation |
| IAM SD for access token | Technical Documentation - Establishment of Ping AS |
| MESH engagement | WDPISD-44144 |
| PEP Gateway | Design Specification for Policy Enforcement (IDPM-175) |

## Glossary

See Cash Platform Glossary.
