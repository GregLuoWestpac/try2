# 09. SD: Solution Design for PAP, PDP to connect to Neptune DB

## Release Scope

**Release:** ERM 25E3 - May 2025  
**Program:** Corporate Cash Management Platform  
**Project:** Corporate Cash Management Platform Tech  
**Project ID:** PR223065

## RACI

| RACI | Role | Entitlements |
|------|------|--------------|
| Responsible | Solution Designer | Jeslin Cyriac |
| Approval and signing off | Architect | Relevant architect for AIA/ACD |
| Consulted | Service Operations Manager | Craig Georgans |
| | IT Business Analyst | Adam Spencer |
| Informed | IT Delivery Lead | Scott Collins |
| | Engineering team | Andrew Sudduk |
| | ISG | Raj Vaishya |
| Reviewed | Product Owner | Sid Shekar |
| | Solution designer | Ujjwal Khare |

## Impacted System Summary

| System | Status | Description |
|--------|--------|-------------|
| Ping (A00CC) | ⭐ Change | Changes for Ping ELZ to set up EKS cluster and New Neptune DB |

## User Story Traceability

| User Story | Title | JIRA | Status |
|------------|-------|------|--------|
| ART-16907 | Baseline PIP Solution Design | ART-16907 | Open |

## Solution Overview

This Solution covers the AWS Neptune DB created as part of Entitlement Solution and covers the integration from PAP and PDP perspective.

### Topics Covered

- DB Cluster Design
- DB User roles
- DB Priming for Dev
- DB Authentication

**Note:** This SD will not cover the MESH to Neptune DB design (covered in separate SD).

## DB Cluster Design

AWS offers 99.95% availability for Neptune DB cluster when deployed multi-AZ. Cluster used for W1C will be multi-AZ in production and single AZ in non-prod (other than SVP during SVP timing).

### Read and Write Endpoints

A Neptune cluster will have at least one write instance (called primary instance) and up to 15 read instances. If only 1 instance exists, it acts as both read and write instance.

### Scaling Options

| Type | Description |
|------|-------------|
| Storage Scaling | Auto-scales up to 128 TiB |
| Instance Scaling | Instances can be upgraded to handle throughput and latency |
| Read Scaling | Read replicas handle read requests; Neptune manages load balancing |

All scaling activities can be done without outages and are transparent to clients using DB cluster read endpoint.

### Environment Configuration

| Env | Phase | Write replicas | Read Replicas | AZs | Instance Type | Comments |
|-----|-------|----------------|---------------|-----|---------------|----------|
| DEV | MVP | 1 | 1 initially | Multi/Single AZ | t3.medium | t3/t4 not for production |
| SIT | MVP | 1 | 1 initially | Multi AZ | t3.medium | t3/t4 not for production |
| SVP | MVP | 1 | Scale as needed | Multi AZ | r5.xlarge | Match prod always |
| Prod | MVP | 1 | 1 | Multi AZ | r5.large | - |
| Prod | Scale | 1 | Based on SVP | Multi AZ | r5.xlarge → r5.12xlarge | - |
| Prod | Lookup cache | 1 | Based on SVP | Multi AZ | r6g.large | - |

### Route 53 DNS Configuration

| Description | DNS |
|-------------|-----|
| Read URL (PDP, PAP) | a014a6.rd.a00ccc.aps2.<env>.awselz.westpac.com.au |
| Write URL (MESH) | a014a6.wr.a00ccc.aps2.<env>.awselz.westpac.com.au |

### Environment Endpoints

| ENV | Route 53 | Cluster URL |
|-----|----------|-------------|
| INT (TST04) Read | a014a6-neptune-read.a00ccc.aps2.tst04.awselz.westpac.com.au | a00ccc-tst04-neptune-pluto.cluster-ro-cvgugcaqwuq3.ap-southeast-2.neptune.amazonaws.com |
| INT (TST04) Write | a014a6-neptune-write.a00ccc.aps2.tst04.awselz.westpac.com.au | a00ccc-tst04-neptune-pluto.cluster-cvgugcaqwuq3.ap-southeast-2.neptune.amazonaws.com |
| DEV (DEV06) Read | a014a6-neptune-read.a00ccc.aps2.dev06.awselz.westpac.com.au | - |
| DEV (DEV06) Write | a014a6-neptune-write.a00ccc.aps2.dev06.awselz.westpac.com.au | - |

## DB Authentication using OIDC Federation with AWS IAM

### Overview

- IAM OIDC identity providers describe external IdP services supporting OpenID Connect (OIDC), such as Westpac Ping CIAM ELZ
- Used to establish trust between OIDC-compatible IdP and AWS account
- Useful for Mesh APIs requiring AWS resource access without managing identities
- After creating IAM OIDC identity provider, create one or more IAM roles
- Role is dynamically assigned to federated user authenticated by Ping CIAM ELZ IdP

**Reference URLs:**
- AWS docs: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_providers_create_oidc.html
- Ping CIAM ELZ SIT1 OIDC endpoint: https://internal.a00ccc.aps2.tst01.awselz.westpac.com.au/identity/.well-known/openid-configuration

## DB User Roles

### Use Case 1: Developer Connectivity

Developer uses local client to connect to Neptune DB for creating queries used in PAP query editor.

**Why not use PAP editor:**
- Restrict what PAP account can do
- PAP doesn't provide visual interface for graph DB structure exploration
- PAP results are JSON construct, challenging for developers

### Use Case 2: PAP Connectivity

Staff Users SSO to PAP to create, update or delete policies. PAP connects to PIP (Neptune) to acquire entitlements/mandates for policy testing.

### Use Case 3: PDP Connectivity

Policies are embedded into PDP. When client (user via Galaxy MFE) requests permission to resource, PEP validates and forwards to PDP. PDP accesses PIP to get required entitlements and policies.

### IAM Roles

| IAM Role | Permission | Environment | Comments | Endpoint | Authentication |
|----------|------------|-------------|----------|----------|----------------|
| PLUTOReadWriteDEVOnly | Create, update, delete nodes/edges | DEV, SIT only | For dev query creation | Write | Assumed IAM role with temp token |
| PLUTOReadOnlyPAP | ReadOnly on DB cluster | DEV, SIT | PAP policy testing | Read | Assumed Role for EKS Service Account |
| PLUTOReadOnlyPDP | ReadOnly on DB cluster | ALL | PDP rule validation | Read | Assumed Role for EKS Service Account |
| PLUTOReadWriteIROM | Create, update, delete nodes/edges | ALL | IROM for IP/AR/Org sync via GCM | Write | OIDC |

## DB Priming for Dev

Requirement for DEV and Test team to perform development/testing scenarios with frequent data loads or DB refreshes.

Unlike conventional relational DBs, Neptune DB doesn't offer client for viewing and loading data. Solution: load priming data in CSV format using BitBucket and DEVOPS pipeline.

### Data Load Frequency

| Environment | Frequency | Data Example |
|-------------|-----------|--------------|
| DEV/SIT | Multiple times daily | Dummy organisation, customer entitlements |
| PROD | First time go-live | Westpac organisation and Internal user profiles |
| SVP | Weekly or less | Dummy organisation, customer entitlements at scale |

### Option 1.2: Upload Metadata to Artifactory (Approved)

**High Level Tasks:**
1. Dev/Tester loads CSV with priming data to Artifactory under a00CCC
2. Jenkins pipeline triggers to push file to S3
3. After successful S3 push, pipeline calls AWS API to load data
4. Jenkins refreshes Neptune DB with CSV data from S3
5. Pipeline validates successful completion

## Security Aspects

### Security Groups

| Security Group | Description |
|----------------|-------------|
| SG_PLUTOReadOnlyPAP | IP/CIDR ranges for PAP EKS cluster/pods |
| SG_PLUTOReadOnlyPDP | IP/CIDR ranges for PDP EKS cluster/pods |
| SG_PLUTOReadWriteIROM | IP/CIDR ranges for MESH egress gateways |

## References

| Document Type | Link |
|---------------|------|
| Entitlement DevOps Requirements | ART-16114 |
| Amazon Neptune Database Pattern Design | Public Cloud Services documentation |
| Connectivity Options | Connectivity Options to Neptune DB |
| Neptune Read-only Access | AWS managed policies for Amazon Neptune |
| Sharing Snapshot across cluster | Amazon Neptune documentation |
| Integration Solution | ART-14066: W1C Entitlements Enforcement Integration |

## Glossary

See Cash Platform Glossary.
