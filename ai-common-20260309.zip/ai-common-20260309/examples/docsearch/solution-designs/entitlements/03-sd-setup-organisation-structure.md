# 03. SD: Setup Organisation Structure

## Release Scope

**Program:** Corporate Cash Management Platform  
**Project:** Corporate Cash Management Platform Tech  
**Project ID:** PR223065  
**Status:** IN REVIEW

## RACI

| RACI | Role | Entitlements |
|------|------|--------------|
| Responsible | Solution Designer | Zane Zuo |
| Approval and signing off | Technical Lead | Dave Hyland, Adam Oakman |
| Consulted | Integration Architect | Amol Chendvankar |
| | IT Business Analyst | Sid Shekar, Adam Spencer |
| | Solution Architect | Dave Hyland, Adam Oakman, Ave Cahyadi |
| Informed | IT Project Manager | Vishal Verma |
| Reviewed | Product Business Analyst | Adam Spencer |
| | Product Owner | Sid Shekar |

## Impacted System Summary

| System | Status | Description |
|--------|--------|-------------|
| Cash Platform (A014A6) | ⭐ Change | Bring organisation structure setup capability into CCMP platform |
| Ping Directory | 🟩 New | Store CCMP platform level organisation structure information |
| Ping Federate | ⭐ Change | Connect to Ping Directory to retrieve organisation, user and account information |

## RAID - Risk, Assumptions, Issues and Dependencies

### Risks

| ID | Category | Description | Notes |
|----|----------|-------------|-------|
| R_001 | Security risk | For Beta release, organisation, user and account information will be manually entered | Ping Directory has sufficient user access control mechanisms |
| R_002 | Delivery risk | For Beta release, the Ping Directory is bare minimum infrastructure | No alternative option to replace Ping Directory as IdP |
| R_003 | Design risk | Pending decision about whether having both Ping Directory and Graph Database | Graph Database still considered as part of entitlement platform |

### Assumptions

| ID | Status | Date | Assumption | Mitigation |
|----|--------|------|------------|------------|
| A_3685_001 | In progress | 11 Aug 2023 | For Beta release, Ping Directory plays IdP role and source of truth | No mitigation |
| A_3685_002 | In progress | 11 Aug 2023 | No parent-child organisation structure for Beta release | LDAP group/user object structure design conducted by architecture |
| A_3685_003 | In progress | 11 Aug 2023 | For Beta release, only entity name (legal name) and CIS Key are customer identifiers | Define and configure extra group attributes into PIP |
| A_3685_004 | In progress | 11 Aug 2023 | CIS key is the primary customer identifier for entitlement platform | Introduce additional key into data sync solution |

### Dependencies

| ID | Description | Notes |
|----|-------------|-------|
| D-001 | Availability of IdP (Ping Directory) | Ping Directory is the host to store organisation structure |
| D-002 | LDAP organisation and user account object structure design readiness | Defines what organisation and user account attributes are stored |
| D-003 | Availability of Policy Information Point (PIP) | AWS Neptune Graph DB responsible for storing entitlement platform data |

### Key Decisions

| ID | Status | Date | Decision | Decision Taken |
|----|--------|------|----------|----------------|
| KD_3871_001 | Open | 11 Aug 2023 | Ping Directory selected as PIP component | Use Ping Directory as primary option as IdP and PIP |
| KD_3871_002 | Open | 11 Aug 2023 | Organisation-account linkage is essential | Use single source like GCM to sync organisation and account data |
| KD_3871_003 | Open | 11 Aug 2023 | In target state, organisation's fund transfer entitlement policy in Graph DB | Removes dependency on PDP availability for Beta |
| KD-3685_001 | Open | 11 Aug 2023 | For Beta release, organisation and account info manually created | Removes dependency on integration between entitlement and GCM |
| KD-3685_002 | Open | 11 Aug 2023 | Organisation legal name sourced from Ping Directory | RAR token is carrier of organisation information for frontend |

## User Story Traceability

### Create Customer (Organisation)

**User Story:** Create a customer (organisation) in the entitlements solution when a new customer is onboarded.

**Attributes:**

| Attribute Name | Source |
|----------------|--------|
| CIS Key | CIS/GCM |
| Customer Organisation Name | GCM |
| Customer Organisation Status | GCM |
| Customer Organisation Entity Type | GCM |
| Customer Organisation Portal Status | Portal/Channel |

**Acceptance Criteria:**
- AC1: GIVEN a customer is required to be onboarded to CCMP, WHEN the customer (organisation) is created in the entitlements solution, THEN the relevant attributes are stored.

### Source GCM Data

**GCM Field Mapping:**

| Attribute Name | GCM Field Definition | GCM Field Name (IFF) |
|----------------|---------------------|---------------------|
| Customer Organisation Name | TBC | TBC |
| Customer Organisation Entity Type | Involved Party Type | IP_Tp_Id |
| Customer Organisation Status | Life Cycle Status Type | Cst_LCS_Tp_Id |

### Configure Accounts

**Account Attributes from GCM:**

| Attribute Name | GCM Field Definition | GCM Field Name (IFF) |
|----------------|---------------------|---------------------|
| Unique Id (10X Subscription Key) | Arrangement Number | Unq_Id_Src_Stm |
| Source System Id | GCM Product Key | GCM_Pd_Nm |
| Account Status | Arrangement Status | Ar_LCS_Tp_Id |
| Account Number | Account Number | AR_ACCNT_NUM |
| BSB Number | BSB Number | AR_BSB_NUM |

## Out-of-scope

| ID | Description | Notes |
|----|-------------|-------|
| OOS-001 | Ping Directory and Ping Federate setup and configuration | Infrastructure delivery team responsible |
| OOS-002 | Organisation and user group object design | Entitlement architect covers this |
| OOS-003 | Ping data synchronisation feature setup | Delivered as part of Ping Directory |

## Solution Overview

The solution for organisation structure contains two major components:

1. **Define LDAP attributes** to store organisation and user account information into PIP (Ping Directory) to facilitate user authorisation process.

2. **Define organisation level entitlement policy**, source entitlement platform required organisation and user account data and store it in Policy Information Point (PIP).

### Component Flow

| ID | Description |
|----|-------------|
| A | Ping Federate retrieves user information from Ping Directory to complete user authorisation |
| B | Ping Authorise retrieves organisation, user and account resources from Ping Directory |
| C | Ping Authorise retrieves organisation, user and account data from Graph DB to execute policy |
| D | Ping Authorise sends dynamic fine grain entitlement check result for Ping Federate to issue token |
| E | Ping Federate issues RAR token to frontend page after user authorisation process |
| F | Organisation and associated user, account data from Ping Directory is synchronised to Graph DB |

### Systems

| System | Description |
|--------|-------------|
| Ping Directory | Entitlement PIP (Policy Information Point) and IdP (Identity Provider) to host organisation, user and account data |
| Graph Database (AWS Neptune) | Entitlement PIP to store all entitlement related organisation, user and account data |
| Ping Federate | Authorisation server providing authentication services |
| Ping Authorise | Entitlement PDP (Policy Decision Point) to enforce entitlement policy |

## Logical Data Model (LDM)

### LDM Definition 1200 for Organisation Entity

The majority of elements are either case-insensitive string (CIS) or 'distinguished name' (DN) & may be single valued (SV) or multiple valued (MV).

| Elements | Description | Data type, cardinality & optionality | WBG ASN.1 OID |
|----------|-------------|--------------------------------------|---------------|
| iamOrgCISKey | Unique key generated for every involved party in IP/CIS | CIS, SV, MAY | 1.2.36.7457141.1.1200.1 |
| iamOrgName | Full/Complete Name of Organisation in GCM | CIS, SV, MAY | 1.2.36.7457141.1.1200.2 |
| iamOrgStatusGCM | Organisation's customer life cycle status in GCM | CIS, SV, MAY | 1.2.36.7457141.1.1200.3 |
| iamOrgType | Defines AML customer type in GCM | CIS, SV, MAY | 1.2.36.7457141.1.1200.4 |
| iamOrgPortalAccessStatus | Organisation's CCMP portal access status | CIS, SV, MAY | 1.2.36.7457141.1.1200.5 |

### Data Requirements

**Beta release required:**
- CIS Key
- Legal Name (Entity name)
- GCM Status
- Entity Type
- Organisation Portal Access Status

**User Data:**
- User email
- User password
- User group
- User daily payment limit

**Account Data:**
- Subscription key
- Account balance
- Account payment limit

## Integration Diagram

Future integration in and out of Ping Directory will be required to keep the PIP synchronised with Organisation and Account changes in their respective systems of record:

- **Outbound synchronisation:** Ping Directory → Neptune graph database via Ping Data Sync
- **Inbound synchronisation:** 10X and GCM → Ping Directory via customer API and listener

## Operational Impacts

For Beta release, entitlement squad engineer will manually create following records in Ping Directory:
- Organisation details
- User details
- Account details

## References

- ACD - CCMP Entitlements
- CCMP - Entitlements: Model
- AIA - CCMP Entitlements
- Architecture for Setup Organisation Structure (SOAP)
- Payments Non Functional Requirements
- 5.0 Security Architecture
- Program Glossary
- CCMP - Entitlements: First User Onboarding
