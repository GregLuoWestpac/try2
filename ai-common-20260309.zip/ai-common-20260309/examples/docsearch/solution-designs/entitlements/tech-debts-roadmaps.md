# Tech Debts and Roadmaps

## Tech Debts

| Item | Non Prod | Prod | Comments | Owner |
|------|----------|------|----------|-------|
| Ping_GW JWT authentication | - | - | - | IDaaS |
| JDBC driver | Descoped | Descoped | - | Not Applicable |
| IAM GUID | August | August | Not a debt, future release change driven by Ping/IDaaS changes | Pluto |
| Route 53 for URLs | - | - | Enable to use Route 53 URLs | - |
| HashiCorp authentication | - | - | Not a debt, future release change driven by Ping/IDaaS changes | - |
| SSO | Implemented | Aug | - | - |
| Licence keys for PingAuth | - | - | Automated email for licence key renewals for Ping Auths | - |
| Customer user backdoor entry through MESH Gateway | - | - | Pen testing finding | - |
| Use of Appian entitlements instead of Ping Authorise | - | - | 09 May 2025: Appian entitlements were used as Ping Authorise is not available | - |

## Road Map

| Feature | Comments | Timelines |
|---------|----------|-----------|
| Feature Toggle | Switch on and off a feature | - |
| Logging Improvements | - | - |
| CorrelationID | Propagate correlationId end to end | Aug-Nov |
| Errors | Improvements in observability | - |
| Code Branching and Release | - | Aug-Nov |
| Swimlane or equivalent support | - | Aug-Nov |
| Fallback if Entitlement goes down in prod | - | Aug-Nov |
| Entitlements allow all in diff environments for facilitating testings | - | - |
| S3 bucket for snapshot saving | - | - |
