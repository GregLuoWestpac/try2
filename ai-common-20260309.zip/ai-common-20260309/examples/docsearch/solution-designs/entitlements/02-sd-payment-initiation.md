# 02. SD: Payment Initiation

## Document Control

| Version | 0.1 |
|---------|-----|
| Status | Work in progress |
| Baseline Date | 30 June 2023 |

## RACI

| RACI | Role | Person |
|------|------|--------|
| Responsible | Solution Designer | Rajendra Varma, Zane Zuo |
| Approval and signing off | Technical Lead | Dave Hyland, Adam Oakman |
| Consulted | Integration Architect | Amol Chendvankar |
| | IT Business Analyst | Sid Shekar, Adam Spencer |
| | Solution Architect | Dave Hyland, Adam Oakman, Ave Cahyadi |
| Informed | IT Project Manager | Vishal Verma |

## Impacted System Summary

| System | Status | Description |
|--------|--------|-------------|
| WDP UI Framework (A00778) | ⭐ Change | Leverage WDPUI Framework to develop CCMP SPA and MFE |
| Westpac Mesh (A008E0) | ⭐ Change | |
| 10x (A00A46) | ⭐ Change | |
| FIS (A013D9) | ⭐ Change | |
| GCM (A0028E) | 🔵 Existing | |
| Cash Platform (A014A6) | 🟩 New | |
| Trading Bank (A0004) | 🔵 Existing | |
| Ping Federate | 🟩 New | |
| Ping Directory | 🟩 New | |
| Ping Authorise | 🟩 New | |
| Ping Access | 🟩 New | |

## Solution Overview

### Solution Components

**From Account and Beneficiary (To) Account Search:**
- Required Mesh API endpoint definition
- Relevant data object in Ping Directory to source the account information (IP-AR in GCM)
- Related entitlement object and policy definition (Channel entitlement, Structural entitlement)
- Associated RAR token schema design

**Payment Submission:**
- Required Mesh API endpoint definition
- Related entitlement object and policy definition
- Associated RAR token schema design

**Beneficiaries Manager**

**Payment Limit Check**

### Business Use Cases

WIB customer requires the ability to transfer funds in real time from one account to another, both accounts owned by the different customer and hosted within the Cash Platform.

### Customer Journey

1. User access W1C portal SPA page
2. SPA redirect user to Ping Federate OOB login page if the login session is expired
3. Ping Federate query user's data from Ping Directory and return it back to SPA as part of issued ID and Access (RAR) Token
4. Channel's MFE page sends Mesh EXP API request along with received Access Token through Mesh API Gateway
5. Mesh API Gateway forwards Access (RAR) Token to Ping Authorize for entitlement check
6. Ping Authorize sources data from Ping Directory to complete its entitlement check
7. Ping Authorize sources data from AWS Neptune (Graph DB) to complete its entitlement check
8. Mesh API Gateway validated Channel's Mesh API call and forward it to subsequent CAP or INF APIs
9. Ping Directory sync its records to AWS Neptune (Graph DB) via its DataSync feature

### Entitlement Requirements

- Payment account entitlement check
- Transfer account entitlement check
- Receiver account entitlement check
- User payment entitlement check
- User transfer entitlement check
- User payment method entitlement check
- User daily limit entitlement check
- User entitlement for paying existing beneficiaries
- Organisation daily limit entitlement check
- Organisation account entitlement check
- Organisation existing beneficiaries entitlement check
- Organisation payment methods entitlement check
- Prior payment submission entitlement check
- Prior transfer submission entitlement check

## Component Mapping

| Ref # | Name | Technology | Description |
|-------|------|------------|-------------|
| CM-01 | WDPUI Framework | Framework | |
| CM-02 | NGINX External API Gateway | Technology | |
| CM-03 | NGINX Ingress Controller | Technology | |
| CM-03a | Ping Plug-in | Technology | Simplify authentication and authorization for API services |
| CM-04 | PingFederate | Technology | |
| CM-05 | PingDirectory | Technology | |
| CM-06 | PingAuthorize | Technology | |
| CM-07 | Neptune DB | Technology | Graph based datastore |
| CM-08 | Gremlin-driver | Framework | Graph traversal language |
| CM-09 | Java 11 | Technology | Microservices underpinning |

## Logical Data Model (LDM)

### Identity Domain
| Entity | Example |
|--------|---------|
| Identity (LDM1000) | Test User |
| Org-Entities (LDM1200) | Customer Organisation |
| Org-Unit (LDM1300) | Customer Organisation Finance Department |
| Devices (LDM1600) | Computer, Mobile, etc. |
| Digital Identity (LDM1700) | Email Address, Mobile Number, etc. |

### Channel Domain
| Entity | Example |
|--------|---------|
| Channel (LDM3010) | CCMP |
| Client (LDM3020) | Make-a-payment MFE, Make-a-transfer MFE |
| Application (LDM3030) | Payment, DE/NPP Payment - Off-US, DE/NPP Payment - On-ME |
| Service Role (LDM3200) | executor#payment, executor#transfer, executor#search-account |
| Service Profile (LDM3300) | Payment Profile, Search Account Profile, Search Beneficiary Profile |

### Banking Domain
| Entity | Description |
|--------|-------------|
| Entitlement (LDM2xxx) | |
| Channel Entitlement (LDM2nnn) | |
| Structural Entitlement (LDM2xxx) | |
| Consent (LDMnnnn) | |
| Business Role (LDM3100) | Payment |
| Banking Resource (LDM5100) | |

## Technical Components / Services - 'Make a Payment'

| Seq | Description | API Name | API Layer | Operation |
|-----|-------------|----------|-----------|-----------|
| 1 | User Logs into CCMP SPA with login flow | ccmp-singlepageapplication | UI | GET /ccmp |
| 2 | User click on 'Manage a payment' button | ccmp-payment-microfrontend | UI | GET /pmt |
| 3 | Call RAR token endpoint (initiatePayment) | gw-agent | external gateway | POST /token?rar=initiatePayment |
| 4 | Enforces AuthZ policy and do basic validation | gw-(k)ic-pingId-plugin | internal gateway | POST /token?rar=initiatePayment |
| 5 | Call RAR token endpoint | PingAuthorize | Authorization | POST /token |

## References

### ACD
- CCMP Entitlements ACD

### AIA
- AIA - CCMP Entitlements

### SOAP/SD
- SOAP: Initiate Payment - Channels
- SOAP: PEP Enablement - Entitlement Integration

### Non-functional Requirements
- Payments Non Functional Requirements

### Security Aspects
- 5.0 Security Architecture
- 04. Entitlements - Solution Design artefacts

### Glossary
- Entitlements and Security Glossary
- Program Glossary

### JIRA Feature
- ART-3702: ENABLER: Solution Design for Entitlements - In progress
