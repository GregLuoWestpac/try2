# 08. SD: W1C InChannel Staff Entitlements

## Release Scope

**Release:** May 2024, May 2026  
**Program:** Corporate Cash Management Platform  
**Project:** Corporate Cash Management Platform Tech  
**Project ID:** PR223065  
**Status:** IN PROGRESS / REVIEW / APPROVED

## RACI

| RACI | Role | Entitlements |
|------|------|--------------|
| Responsible | Solution Designer | Jeslin Cyriac |
| Approval and signing off | Architect | Relevant architect for AIA/ACD |
| Consulted | IT Business Analyst | Adam Spencer |
| Informed | IT Delivery Lead | Scott Collins |
| | Engineering team | Tai Bello, Bobby Joseph |
| | ISG | Raj Vaishya |
| Reviewed | Solution designer | Ujjwal Khare |

## Impacted System Summary

| System | Status | Description |
|--------|--------|-------------|
| Cash Platform (A014A6) | 🟩 New | Channels and Workflows will use this component build by Entitlement to check whether user has permission |

## Assumptions & Risks

| Ref # | Type | Description | Notes | Date |
|-------|------|-------------|-------|------|
| A-ART-XXX-001 | Assumption | Authentication of users is not handled by Authorisation/Entitlement Module | Users should be fully authenticated before calling for authorisation | 17 Apr 2024 |
| A-ART-XXX-002 | Assumption | User Type (Staff or Customer) and Role should be passed via the token | Staff Users can have View only or Operator permissions | 17 Apr 2024 |
| A-ART-XXX-003 | Assumption | Action, resource and fine-grained entitlement returns to be separately aligned | - | 18 Apr 2024 |
| A-ART-XXX-004 | Assumption | Only 2 user types (Customer and Staff) in scope | For other user types authorisation is denied | 19 Apr 2024 |
| A-ART-XXX-005 | Assumption | Customers - No fine-grained permission for Customer | Customer is granted Full Access | 19 Apr 2024 |
| A-ART-XXX-006 | Assumption | Staff has only 2 roles: View and Operator | PAC can have Admin Role for PAC Management | 19 Apr 2024 |
| A-ART-XXX-007 | Assumption | Token is issued to user as part of existing authentication module | - | 23 Apr 2024 |
| A-ART-XXX-008 | Assumption | IDP expected to issue Token only to users who have a role in OneAccess | - | 23 Apr 2024 |
| A-ART-XXX-009 | Assumption | For InChannel Solution Entitlement Library expects only one action per request | - | 16 Aug 2024 |

## User Story Traceability

| User Story | Title | MoSCoW | Status |
|------------|-------|--------|--------|
| ART-12474 | Entitlements Library and InChannel Staff Entitlements - Detailed requirements | MUST | Closed |
| ART-12478 | Solution Design for InChannel Staff Entitlement Authorisation | MUST | Closed |
| ART-15593 | Complete Solution Design for new PAC role and logic | MUST | Closed |
| ART-30175 | Add new action in the entitlements UI library | MUST | Closed |

## Non-Functional Requirements

No impact or requirements to NFRs for InChannel Solution as it is a library. The Customer Channel and Staff Channel NFR is applicable.

## Solution Overview

This solution will cater to staff, customer and PAC users to have role based permissions on the CCMP and PAC components, until the Entitlement Solutions is ready. The solution will create a library (similar to jar in Java) in Node.js.

### User Roles

| Role | User Type | Source |
|------|-----------|--------|
| agent | Customer | Ping CIAM |
| A014A6-galaxy-view-only | Staff | Ping Staff |
| A014A6-galaxy-service-and-operations | Staff | Ping Staff |
| A014A6-galaxy-pac-management | PAC Admin | Ping Staff |
| A014A6-galaxy-treasury-operations | Treasury Operations | - |
| A014A6-galaxy-service-management | Staff | Ping Staff |
| A014A6 (CCMP) WIBO PSO NPP Operations | Staff | - |
| A014A6 (CCMP) WIBO Client Services | Client Services | - |
| A014A6 (CCMP) Operations View Only | Operations View Only | - |

### RBAC Structure

```json
{
  "agent": ["viewAccounts", "viewTransactions", "viewPayments", "viewAdvancedPayments", ...],
  "A014A6-galaxy-view-only": ["viewAccounts", "viewTransactions", ...],
  "A014A6-galaxy-service-and-operations": ["viewAccounts", "initiatePayment", ...],
  "A014A6-galaxy-pac-management": ["view", "manage", ...]
}
```

## Context Samples

### View Payments Request
```json
{
  "context": {
    "action": ["viewPayments"],
    "resource": "/accounts"
  }
}
```

### Initiate Payment Request
```json
{
  "context": {
    "actions": ["initiatePaymentReturn"],
    "resource": "/account"
  }
}
```

### Response - Authorized
```json
{
  "authorised": true,
  "message": "Permission granted"
}
```

### Response - Denied
```json
{
  "authorised": false,
  "message": "You do not have sufficient permission."
}
```

## Error Handling

| Error Scenario | Description | Failure Point | Severity | Behaviour |
|----------------|-------------|---------------|----------|-----------|
| 'action' missing | Client failed to pass 'action' in context | Validation | High | Throw "missing action context" |
| 'token' missing | Client failed to pass 'token' in context | Validation | High | Throw "missing token in context" |

## Data Mappings - Authorisation Requests

| UI Feature | Action Value | Error Message | Resource | Release |
|------------|--------------|---------------|----------|---------|
| View Accounts | viewAccounts | You do not have sufficient permission | account | Nov 2024 |
| View Transactions | viewTransactions | You do not have sufficient permission | account | Nov 2024 |
| View Payments | viewPayments | You do not have sufficient permission | account | Nov 2024 |
| Initiate Payment | initiatePayment | You do not have sufficient permission | account | Nov 2024 |
| Initiate Transfer | initiateTransfer | You do not have sufficient permission | account | Nov 2024 |
| Initiate Payment Return | initiatePaymentReturn | You do not have sufficient permission | account | Nov 2024 |
| View Beneficiaries | viewBeneficiaries | You do not have sufficient permission | customer | Nov 2024 |
| Credit Interest Override | overrideCreditInterest | You do not have sufficient permission | account | Nov 2024 |
| PAC user default | view | You do not have sufficient permission | PAC | Nov 2024 |
| Account Opening | openAccount | You do not have sufficient permission | account | Future |
| Account Closure | closeAccount | You do not have sufficient permission | account | Future |
| Block Account | blockAccount | You do not have sufficient permission | account | Future |
| Unblock Account | unblockAccount | You do not have sufficient permission | account | Future |
| Block Customer | blockCustomer | You do not have sufficient permission | customer | Future |
| Unblock Customer | unblockCustomer | You do not have sufficient permission | customer | Future |
| Manage Account Name | manageAccountName | You do not have sufficient permission | account | Feb 2025 |
| Maintain Account Indicators | maintainAccountIndicators | You do not have sufficient permission | account | May 2025 |

## References

| Document Type | Document Link |
|---------------|---------------|
| Solution Design for Account Level Credit Interest | 01. SD: Create And Maintain Account-Level Credit Interest Overrides (Staff) |
| Token Values from Ping Staff | Role values in JWT Token |

## Glossary

See Cash Platform Glossary.
