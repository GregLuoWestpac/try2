# 13. SD: Staff User Management and User Admin

## Release Scope

**Program:** Corporate Cash Management Platform  
**Project:** Corporate Cash Management Platform

## RACI

| RACI | Role | Entitlements |
|------|------|--------------|
| Responsible | Solution Designer | Jeslin Cyriac |
| Approval and signing off | Architect | Relevant architect for AIA/ACD |
| | Integration Architect | Amol Chendvankar |
| Consulted | Delivery Lead | Sid Shekhar |
| | Solution Architect | Adam Oakman |
| | IT Business Analyst | Adam Spencer |
| Informed | Testing team | Mahender Shaga, Suresh |
| | SVP Testing | Kripashankar Mishra |
| | ISG | Raj Vaishya |
| Reviewed | Product Owner | - |

## Impacted System Summary

| System | Status | Description |
|--------|--------|-------------|
| 10x (A00A46) | ⭐ Change | - |

**Other Systems Referenced:**
- DDEP, DETICA, Direct Entry, FACE, FAH, FIS, GCM
- EDW, EIG, Cash Platform (A014A6), Oracle GL
- PAG, Sterling, TDM, TLM HC, TLM LC, Trading Bank, WIB ETL

## Solution Overview

This solution design covers Staff User Management and User Admin functionality within the CCMP entitlements platform.

## Sequence Diagrams

### PDP Query

Sequence diagram represents the staff maker checker flow - applicable to any Staff/PAC/WF maker checker flow. Based on business case, the MFE of the maker changes; rest of flows remain the same.

**Reference:** For details of Maker checker design, see 12.SD: Entitlements PLUTO Maker Checker

### Staff Maker Flow

The maker flow for staff user management integrates with:
- PDP (Policy Decision Point)
- PEP (Policy Enforcement Point)
- DSR (Digital Service Request)
- GTS CAP API

### User Admin Calls

EXP to IROM API integration for user administration functions.

**Reference:** For Checker Flow, see 12.SD: Entitlements PLUTO Maker Checker

## References

- Cash Platform Glossary
- 12.SD: Entitlements PLUTO Maker Checker
