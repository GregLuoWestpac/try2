# 04. Entitlements - Solution Design artefacts

## Solution Design Documents

| # | Document Title |
|---|----------------|
| 00 | SD: Setup & administration |
| 0x | SD: Create Accounts |
| 0x | SD: Manage Payments |
| 01 | SD: User Authorisation |
| 02 | SD: Payment Initiation |
| 03 | SD: Setup Organisation Structure |
| 04 | SD: Customer User Profile - Foundation |
| 05 | SD: View Accounts |
| 06 | SD: GCM Integration and Sync |
| 07 | SD: Staff User Establishment |
| 08 | SD: W1C InChannel Staff Entitlements |
| 09 | SD: Solution Design for PAP, PDP to connect to Neptune DB |
| 10 | SD: Solution Design for view Accounts, manage Accounts and initiate Payments |
| 11 | SD: Pluto - MFA - High Risk Transaction Additional Authorisation |
| 12 | SD: Entitlements PLUTO Maker Checker |
| 13 | SD: Staff User Management and User Admin |

## Tech Debts and RoadMaps

*[See Confluence for details]*
