# Confluence Spider Queue

## Complete

All pages have been processed.

## Done
- https://confluence.srv.westpac.com.au/display/ARTC/01.+Solution+design -> 01-solution-design.md
- https://confluence.srv.westpac.com.au/display/ARTC/01.+Solution+Design+e2e -> 01-solution-design-e2e.md
- https://confluence.srv.westpac.com.au/display/ARTC/02.+Payments+Solution+design -> 02-payments-solution-design.md
- https://confluence.srv.westpac.com.au/pages/viewpage.action?pageId=1433492248 -> (empty page)
- https://confluence.srv.westpac.com.au/display/ARTC/04.+Entitlements+-+Solution+Design+artefacts -> 04-entitlements-solution-design-artefacts.md
- https://confluence.srv.westpac.com.au/display/ARTC/05.+Capabilities -> (placeholder)
- https://confluence.srv.westpac.com.au/display/ARTC/06.+Workflow -> (placeholder)
- https://confluence.srv.westpac.com.au/display/ARTC/07.+PODS+Payments+Operational+Data+Store -> (placeholder)
- https://confluence.srv.westpac.com.au/display/ARTC/08.+ATLAS -> (placeholder)
- https://confluence.srv.westpac.com.au/pages/viewpage.action?pageId=1775441035 -> 09-platform-admin-console-pac.md
- https://confluence.srv.westpac.com.au/display/ARTC/10.+Liquidity+Management+Console -> (placeholder)
- https://confluence.srv.westpac.com.au/display/ARTC/Experience+API+Design+Pattern -> experience-api-design-pattern.md (existing)
- https://confluence.srv.westpac.com.au/display/ARTC/z.+Solution+design+for+W1C -> z-solution-design-for-w1c.md (existing)
- https://confluence.srv.westpac.com.au/display/ARTC/CCMP+Payment+Mesh+Integrations -> (no content)
- https://confluence.srv.westpac.com.au/display/ARTC/FIS+dictionary -> fis-dictionary.md
- https://confluence.srv.westpac.com.au/display/ARTC/Account+Cache+Update+High+Level -> (brief, merged into other docs)
- https://confluence.srv.westpac.com.au/display/ARTC/CBIS+Adaptors -> cbis-adaptors.md
- https://confluence.srv.westpac.com.au/display/ARTC/01.+SD%3A+Account+Cache+-+API+for+Create+and+Update -> 01-sd-account-cache-api-create-update.md

