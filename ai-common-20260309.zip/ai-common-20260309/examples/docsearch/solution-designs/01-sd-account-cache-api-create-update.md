# 01. SD: Account Cache - API for Create and Update

## Release Scope

**Program:** Corporate Cash Management Platform  
**Project:** Corporate Cash Management Platform Tech  
**Project ID:** PR223065

## Scope per ERM

| May 2024 ERM | Feb 2025 ERM | May 2025 ERM |
|--------------|--------------|--------------|
| SCT Single Credit Transfer (sct.01) | PayTo | Suspense account API call |
| Osko Overlay (x2p1.01) | IFTI | Account type population |
| Category Purpose Code | | |

## RACI

| RACI | Role | Person |
|------|------|--------|
| Responsible | Solution Designer | Ellen Hallgren |
| Approval and signing off | Solution Architect | Lance Petley |
| Consulted if Applicable | Integration Architect | Arun Makhija |
| Informed | IT Project Manager - Application | Bill McIntosh |
| Reviewed | Product Business Analyst | Gordon Wong |
| | Product Owner | Dipika Guruprasad |
| | Solution Designer | Mark Chan |

## Impacted System Summary

| System | Status | Summary |
|--------|--------|---------|
| 10x (A00A46) | ⭐ Change | Build the API update adapter within 10X |
| FIS (A013D9) | ⭐ Change | CBIS updates: Introduction of new fields |

**Legend:** ⭐ - Change | 🟩 - New | 🔵 - Existing | ⬜ - Decommission

## Key Decisions

| ID | Status | Date | Decision | Decision Taken |
|----|--------|------|----------|----------------|
| KD_1152_001 | Closed | 26 May 2023 | Will all data be stored within the account cache table within FIS? | Option 1 - Account cache update will be one API call where both 10X Product and FIS receive data |
| KD_1152_003 | Closed | 26 May 2023 | Will update of data within account cache happen via events or API calls? | Preference is API - all integration performed by 10X as a part of their product |
| KD_1152_005 | Closed | 26 May 2023 | What will the product data source? | 10X (No requirement to use GCM) |
| KD_1152_006 | Closed | 26 May 2023 | Will we be using manual file upload for first load into CBIS? | FIS to include manual file upload in costing as an option |
| KD_1152_007 | Closed | 10 Jul 2023 | Will we be using Credit stand-in? | Yes |

## User Story Traceability

### ERM 24E3 - May 2024

| User Story | Title | MoSCoW | Status | In Solution Design |
|------------|-------|--------|--------|-------------------|
| CACHE.01.01 | Process inbound payments | MUST | Closed | Yes |
| CACHE.02.01 | Process outbound payments / transfers | MUST | Closed | Yes |
| CACHE.03.01 | Update Account Cache | MUST | Closed | Yes |
| CACHE.04.01 | Trigger Account Cache Update | MUST | Closed | Yes |
| CACHE.05.03 | Performance | MUST | Closed | Fulfilled by FIS contractual agreement |
| CACHE.05.05 | Scalability | MUST | Closed | Fulfilled by FIS contractual agreement |
| CACHE.05.05 | Availability & Reliability | MUST | Closed | Fulfilled by FIS contractual agreement |
| CACHE.05.06 | Extensibility | MUST | Closed | Yes |

# Solution

## Solution Overview

Cash platform will use a component within CBIS called Account cache. This solution design focuses on how to add and update account information within the account cache using an API call from 10X to FIS through an endpoint registered on the mesh.

### Scenarios in Scope

- **First load of accounts**
- **Intraday via an update service (API Update)**
  - Account has been opened within 10X and reached Active state
  - Accounts should NOT be added to account cache when they are within Provisioned state
- **Update accounts** when they have been updated within 10X
- **Update all accounts attached to a product** when the product is updated within 10X
- **Customer status update** which has triggered the account status to be updated

## Systems

### 10X (A00A46)
Account host and Payment Engine for DE. Is the customer ledger. Has multiple tenants, with a specific tenancy setup for WIB - Cash Platform.

### Account Cache
A component within CBIS FIS (A013D9). The account cache can be updated by batch or API.

**Account Cache Usages:**
1. **Account Location lookup service** - uses the account cache to find out which account host the account belongs to when deciding which adapter to use for posting
2. **Eligibility check:**
   - Whether the account can receive account postings
   - Whether the account is eligible for the payment scheme
   - Extra check for NPP: Whether the account is eligible for the related Business service
3. **Account number and BSB to Subscription key lookup**
   - Subscription key is an internal identifier within 10X used to identify an account
   - Usage: Account Posting

### CBIS - Core Banking Integration Services (A013D9)
A product solution from FIS. For more detailed information see the CBIS documentation.

**Capabilities:**
- Manages integration of payment systems to talk to one or more core banking systems (can talk to 10X)
- Provides functionality for account lookup/cache/stand-in for core banking systems
- Integrates with any payment system (NPP/POM) and any core banking solution
- Acts as an integration layer, providing banks a cost-effective way of decoupling management and execution of payments from actual posting to accounts

**Product Adaptors by FIS:**
- **PRA** - Product Rules Adapter: Determines posting eligibility for posting to an account
- **PBA** - Product Behaviour Adapter: Determines correct behaviour for functionalities for one individual accounting entry
- **AVA** - Account Validator Adapter: Executes validations against provided accounts via Account Eligibility Entries

**Custom Adapters by FIS:**
- Can be used to customise interfaces when transformation is needed (e.g., 10x adapter)

**CBIS CORE:**
- Cannot be changed - all code and no configuration

## Integration

Account Cache API integration connects 10X to FIS through a mesh endpoint.

### Update Mechanisms
1. **Batch** - Refresh of entire Local Lookup
2. **Intraday** - Via an update service (API Update)

### Flow
1. Account created/updated in 10X
2. 10X calls Account Cache API on mesh endpoint
3. FIS CBIS receives request and updates Account Cache
4. Account Cache available for payment processing queries

## Sequence Diagrams

Sequence diagrams are written in PlantUML format. See AccountCacheAPI.puml attachment for source.
