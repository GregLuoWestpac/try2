# CBIS Adaptors

## Basic Concepts

CBIS and its adapters (custom or product) are one package. Calling the right adapter (by the adapter name) is internal to CBIS core. No system other than CBIS core can call it. The adapter is not a separate microservice - it's an extension of CBIS and all bundled into one.

## PRA - Product Rules Adapter

There is an NPP PRA that is built within CBIS as is. The PRA is one per bank.

### Creating PRA for a Bank

The process is as follows:
1. Copy OOTB (Out of the Box)
2. Add a name to it
3. Add more rails with rules as components get created

**Note:** CBIS Rules Adaptor has nothing to do with the product catalogue (this is a Westpac concept) - it has to do with CBIS as a product.

### How to Update Rules

PRA contains the rules in the rules adaptor. These only change when a rule in the validation changes.

## Handling Product Updates When Updating Rails

### Example Scenario
A product adds a new Scheme that needs to be supported.

### Options

#### 1. Account Cache
Within 10X, all accounts are associated with product code → this gets then sent as an update to FIS (OOTB).

#### 2. CBIS Rules Adaptor
Change logic in PRA - this product code is now enabled for NPP.

#### 3. CBIS Product Table
Custom table for all the product codes:
- Eligible for NPP outbound/inbound
- Eligible for business

## Default Adaptor: Posting Eligibility Check

The default adaptor checks for the following conditions:

1. If the related adapter is a GL adapter (`glAdapterFlag = True`)
2. Otherwise:
   - The status of the account to be posted to in the account cache is **OPEN**
   - If the entry is a **DEBIT**, that there are sufficient funds in the account, OR that the account is permitted to go into overdraft
     - This is specified via the `overdraft-allowed` attribute in the supplementary data for the account in the account cache
