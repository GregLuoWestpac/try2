# 01. Solution Design e2e

## Table of Contents
- [Environment alignment](#environment-alignment)
- [Integration points Cash Platform](#integration-points-cash-platform)
- [Internal APIs](#internal-apis)
- [TBC](#tbc)
- [Will not be used](#will-not-be-used)

---

## Environment alignment

| 10X | FIS | Westpac |
|-----|-----|---------|
| INT | SIT | GCM - Dev1, DDEP - Dev, Westpac One Core Channels - SIT (tst02), Westpac One Core Ping - SIT1(tst01), Westpac One Core Mesh - SIT (tst02), Westpac One Core Data (PODS) - SIT (tst01), Westpac One Case Management Appian - TBC, Data Node - TBC |
| E2E | UAT | LSIT |
| SVP | SVP | SVP |
| Prod | Prod | Prod |

---

## Integration points Cash Platform

### CCMP Payment Mesh Integrations

| # | Business Functionality | System | System Function | Type | Hosting | Direction | New/Existing | In scope for PDS | In scope for Beta-1 | Commentary |
|---|------------------------|--------|-----------------|------|---------|-----------|--------------|------------------|---------------------|------------|
| 1 | Funds control | TBC | TBC | REST API (HTTPS) | Service Mesh (WBC AWS ELZ) | - | TBC | No | No | This will handled within the Account Posting call for Beta 1, that will fulfil: Funds check (if insufficient funds, 10x returns error and transaction rejected), Account posting. For releases after Beta 1: How funds control will function within Cash platform is being worked on. |
| 2 | Liquidity control | TBC | TBC | - | - | - | TBC | No | No | Not due for Beta 1 release |
| 3 | Account Posting | 10X | Account Host (Core Banking) | REST API (HTTPS) | Service Mesh (WBC AWS ELZ) | FIS -> WBC | Update API | Yes | Yes | Proxy design: 04. DTD: inf-bnkng-acct-acctentry-txn10x-v1 |
| 4 | Suspense Account Posting - One leg | 10X | Account Host (Core Banking) | REST API (HTTPS) | Service Mesh (WBC AWS ELZ) | FIS -> WBC | New API | Yes | Yes | Proxy design: 04. DTD: inf-bnkng-acct-acctentry-txn10x-v1 |
| 5 | Suspense Account Posting - Suspense to Suspense | 10X | Account Host (Core Banking) | REST API (HTTPS) | Service Mesh (WBC AWS ELZ) | FIS -> WBC | New API | Yes | TBC | - |
| 6 | Suspense Account Posting - Suspense to Customer | 10X | Account Host (Core Banking) | REST API (HTTPS) | Service Mesh (WBC AWS ELZ) | FIS -> WBC | New API | Yes | TBC | - |
| 7 | Dry run - keeping local lookup up to date | 10X | Update Account Cache Account Host (Core Banking) | REST (HTTPS) | Service Mesh (WBC AWS ELZ) | 10X -> FIS | New | Yes | Yes | Updates to local lookup when: A new account is added to 10X, Changes to existing account, Changes to product |
| 8 | Dry run - keeping local lookup up to date | 10X | Update Account Cache Account Host (Core Banking) | Batch | Service Mesh (WBC AWS ELZ) | 10X -> FIS | New | Yes | Yes | Full refresh of the local lookup - To be validated if batch can be used with FIS |

### Sanctions and Fraud

| # | Business Functionality | System | System Function | Type | Hosting | Direction | New/Existing | In scope for PDS | In scope for Beta-1 | Commentary |
|---|------------------------|--------|-----------------|------|---------|-----------|--------------|------------------|---------------------|------------|
| 9 | PaymentInstructionScreeningService API | Netreveal | Sanctions Screening: IFTI RT, Domestic NRT | REST API (HTTPS) | Service Mesh (WBC AWS ELZ) | FIS -> WBC | New Partner API | Yes | No | IFTI: 7b. Initial Request/Response (Proceed/Wait). FIS (FSIS) sends initial request to PaymentInstructionScreening API which determines if payment is IFTI or Non-IFTI. |
| 10 | Hit/NoHit Netreveal response | Netreveal | Sanctions Screening: IFTI RT | MQ | WBC (On-Prem) | WBC -> FIS | New Queue setup | Yes | No | 7c. First Response from NetReveal - Initial response HIT or NOHIT through MQ connection to FIS-FSIS |
| 11 | Final/Outcome Netreveal response | Netreveal | Sanctions Screening: IFTI RT | MQ | WBC (On-Prem) | WBC -> FIS | New Queue setup | Yes | No | 7d. Final Response - Can be APPROVED, DISAPPROVED, or SEIZE |
| 12 | Fraud Check: RT PRM Receive | PRM | Fraud | MQ | WBC (On-Prem) | FIS -> WBC | New Queue setup | Yes | No | Where FSIS places the message on PRM queue |
| 13 | Fraud Check: RT PRM Response | PRM | Fraud | MQ | WBC (On-Prem) | WBC → FIS | New Queue setup | Yes | No | Possible outcomes: Hold, Fraud Reject/Terminate, Fraud Release/Allow |
| 14 | Fraud Check: NRT | PRM | Fraud | MQ | WBC (On-Prem) | FIS -> WBC | TBC | Yes | No | NRT for the fraud outcome when RT response is HOLD |
| 15 | Fraud Check: Trigger for outcome of hold | TBC | Fraud | REST API (HTTPS) | Service Mesh (WBC AWS ELZ) | WBC → FIS | - | - | No | Trigger outcome: Return money to customer OR Funds returned to NPP process flow |

### PAG

| # | Business Functionality | System | System Function | Type | Hosting | Direction | New/Existing | In scope for PDS | In scope for Beta-1 | Commentary |
|---|------------------------|--------|-----------------|------|---------|-----------|--------------|------------------|---------------------|------------|
| 16 | EQ: NPP Payment (PACS) | PAG | Scheme Gateway | MQ | WBC (DMZ On-Prem) | WBC -> FIS | New routing | Yes | Yes | - |
| 17 | RQ: NPP Payment (PACS) | PAG | Scheme Gateway | MQ | WBC (DMZ On-Prem) | FIS -> WBC | New routing | Yes | Yes | - |
| 18 | CEQ: BRDT | PAG | Scheme Gateway | MQ | WBC (DMZ On-Prem) | WBC -> FIS | New routing | Yes | Yes | - |
| 19 | CRQ: BRDT | PAG | Scheme Gateway | MQ | WBC (DMZ On-Prem) | FIS -> WBC | New routing | Yes | Yes | - |
| 20 | Non repudiation Messages | PAG | Scheme Gateway | MQ | WBC (DMZ On-Prem) | - | ??? | TBC | Yes | TBC if new routing or using current NGS integration |
| 21 | EQ: PayTo MPIR | PAG | Scheme Gateway | MQ | WBC (DMZ On-Prem) | WBC -> FIS | New routing | No | No | Not due for Beta 1 release |
| 22 | RQ: PayTo MPIR | PAG | Scheme Gateway | MQ | WBC (DMZ On-Prem) | FIS -> WBC | New routing | No | No | Not due for Beta 1 release |
| 23 | Addressing services | PAG | Scheme Gateway | SOAP | WBC (DMZ On-Prem) | WBC -> FIS | ?? | No | No | Not due for Beta 1 release |
| 24 | MMS (Initiator) | PAG | Scheme Gateway | REST API (HTTPS) | WBC (DMZ On-Prem) | FIS-> PAG | - | No | No | Not due for Beta 1 release |
| 25 | MMS (Payer) | PAG | Scheme Gateway | REST API (HTTPS) | WBC (DMZ On-Prem) | PAG -> FIS | - | No | No | Not due for Beta 1 release |

### Payment FIS Integration

| # | Business Functionality | System | System Function | Type | Hosting | Direction | New/Existing | In scope for PDS | In scope for Beta-1 | Commentary |
|---|------------------------|--------|-----------------|------|---------|-----------|--------------|------------------|---------------------|------------|
| 26 | Payment Instruction Enrichment API | Mesh | Channel Integration | REST API (HTTPS) | Service Mesh (WBC AWS ELZ) | FIS -> WBC | New build ?? | Yes | Yes | POM CT EVE will make the call to the enrichment API |
| 27 | Events consumption | WBC Confluent Kafka | Event Streaming | Kafka | Service Mesh (WBC AWS ELZ) | FIS -> WBC | New build | Yes | Yes | Consume from: POM, NPP Product, MPS, MPIR, MMS, CBIS |
| 28 | POM: Initiate credit transfer | Mesh | Channel Integration | REST API (HTTPS) | Service Mesh (WBC AWS ELZ) | WBC -> FIS | New build | Yes | Yes | pain.001 message |
| 29 | POM: Initiate payment return | Mesh | Channel Integration | REST API (HTTPS) | Service Mesh (WBC AWS ELZ) | WBC -> FIS | New build | Yes | Yes | API for triggering returns to FIS POM |
| 30 | Initiate case investigation message | Mesh | Channel Integration | MQ | Service Mesh (WBC AWS ELZ) | WBC -> FIS | New build | Yes | ??? | Messages Outbound: camt.029, camt.030, camt.035, camt.056 |
| 31 | Receive case investigation message | Mesh | Channel Integration | MQ | Service Mesh (WBC AWS ELZ) | FIS -> WBC | New build | Yes | Yes | Messages Inbound: camt.029, camt.030, camt.035, camt.056 |

### Payment Squad Mesh

| # | Business Functionality | System | Type | Direction | In scope | Commentary |
|---|------------------------|--------|------|-----------|----------|------------|
| 39 | Payment Initiation CAP API | Mesh | REST API (HTTPS) | Channel → MESH → POM | Yes | ART-2127 - On Me / On Platform |
| 40 | CAP API – payment list/history | Mesh | REST API (HTTPS) | Channel → MESH → Data | TBC | ART-4505, ART-6520 |
| 41 | POM Proxy API | Mesh | REST API (HTTPS) | Channel → MESH → POM | Yes | ART-2127 |
| 42 | CBIS Proxy API | Mesh | REST API (HTTPS) | 10X → MESH → CBIS | Yes | ART-1152 - Account Cache |

### Account Squad Mesh

| # | Business Functionality | Direction | Timeline | Commentary |
|---|------------------------|-----------|----------|------------|
| 43 | 2 x Partner api's - existing modify | 10X → WBC | Feb | - |
| 44 | 10x Proxies (Create/Modify customer, Create account, Account list/details/balance) | WBC-> 10X | Feb | - |
| 45 | 1 x new kafka listener, 1 x data store, 1 x inf api, 1 x cap api | WBC-> 10X | - | - |

### Channel Mesh

| # | Business Functionality | Timeline | Commentary |
|---|------------------------|----------|------------|
| 46 | 1 SPA, 3 MFEs (dashboard, account, payment), 3 EXP APIs, CAP API for account lists/details/balance | FEB | - |
| 47 | CAP API – transaction history | May | - |

### Entitlement Mesh

| # | Business Functionality | Timeline | Commentary |
|---|------------------------|----------|------------|
| 48 | Info API for Ping Directory data | FEB/May | - |
| 49 | GCM Kafka Listener, CAP API for XREF, APIs for GCM recon, MFE/EXP API for user entitlements | Later | - |

### File / Other

| # | Business Functionality | System | Type | Direction | New/Existing | Commentary |
|---|------------------------|--------|------|-----------|--------------|------------|
| 50 | Log ingestions | Splunk | Splunk to Splunk streaming | - | New build | TBC with vendor and TechOps |
| 51 | IAM | Ping Identity IdP | HTTPS/REST API | FIS -> WBC | New build | FIS OVA will integrate with Westpac Staff IDP |
| 52 | Service Management | TBC | TBC | - | New build | - |

---

## Internal APIs

- PaymentInstructionScreeningService API
- Payment enrichment
- TBC
- IAM
- Service management
- Funds control
- Liquidity control

---

## Will not be used

| Business Functionality | System | System Function | Reason |
|------------------------|--------|-----------------|--------|
| Payment enquiry API | - | - | Cannot use as it is insufficient and works only on POM status. Events will have to be consumed and reconstructed at CCMP side. |
| Dry run | 10X | Account reachability Account Host (Core Banking) | Program register decision that we will use the Account cache |
| Report transfer | Data Solution | File | TBC Use event mapping or File |
| Entitlements check | Entitlements service | Authorization | Decision made that we will not be making this call |
