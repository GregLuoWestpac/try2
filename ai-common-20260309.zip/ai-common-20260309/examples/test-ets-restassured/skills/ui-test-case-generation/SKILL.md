---
description: Project-specific patterns for UI test case generation (W1C Selenium/Cucumber)
---

# UI Test Case Generation - Project Skill

Project-specific patterns, paths, and conventions for BDD test case generation in this repository.

## CRITICAL RESTRICTIONS

This agent is **READ-ONLY for code**. It must:
- **NEVER** create or edit `.feature` files
- **NEVER** create or edit Java files (step definitions, page objects, etc.)
- **NEVER** modify any source code or test code
- **ONLY** create the output file defined by the agent's CRITICAL RESTRICTIONS

**JIRA Ticket is MANDATORY**: Always require the JIRA ticket number before proceeding.

## Project Context

**Framework**: Selenium WebDriver + Cucumber BDD + Gradle
**Language**: Java 17+
**Test Runner**: Cucumber JUnit

### Instruction Files
Load these for domain context:
- `.github/instructions/project_context.instructions.md` — Domain glossary, business context
- `.github/instructions/repo_overview.instructions.md` — Directory structure, project layout

## Output Paths

| Artifact | Path | Notes |
|----------|------|-------|
| Test Cases | `.docs/agentic-logs/<JIRA-TICKET>/test-cases.md` | See agent CRITICAL RESTRICTIONS |
| Implementation Plan | Created by downstream agents | Not created by this agent |

## Templates

Load the feature template from `.github/skills/shared/templates/feature-template.gherkin` for Gherkin structure reference.

## Feature Files Location

Search for existing steps to maximize reuse:

```
src/test/resources/e2e/features/
├── W1C-ChannelsCustomerPortal/   # Customer portal features
├── W1C-ChannelsStaffPortal/      # Staff portal features
├── NPPPayment/                   # NPP payment features
├── GCM-CCMP/                     # GCM application features
├── W1C-TLM-Portal/               # TLM portal features
└── <Application>/                # Other applications
```

## How to Search for Reusable Steps

### Search Strategy

1. **Identify the target application folder** based on user request
2. **Search for existing .feature files** in that folder
3. **Extract Given/When/Then patterns** from those files
4. **Catalog reusable steps** before writing new scenarios

### Search Commands

Use these search patterns:

```
# Find all feature files for an application
file_search: src/test/resources/e2e/features/<App>/**/*.feature

# Search for specific step patterns
text_search: "Given I retrieve" in src/test/resources/e2e/features/
text_search: "When User" in src/test/resources/e2e/features/<App>/
text_search: "Then user should" in src/test/resources/e2e/features/
```

### Step Extraction Process

1. **Read 2-3 feature files** from the target application
2. **List all unique Given/When/Then steps** found
3. **Identify parameterized patterns** (steps with `<placeholders>` or `{string}`)
4. **Document in the "Reusable Steps" section** of test-cases.md

### Example Search Workflow

```
1. User requests: "Test beneficiary management in Customer Portal"
2. Search: file_search → src/test/resources/e2e/features/W1C-ChannelsCustomerPortal/*.feature
3. Find: Beneficiary.feature, BeneficiaryDetails.feature
4. Read those files and extract steps like:
   - Given I retrieve Customer specific secrets from Vault <VaultScenario> for <User>
   - When User clicks on Payments link and select Beneficiaries
   - Then user should validate the beneficiaries tab
5. Reuse these exact patterns in new scenarios
```

## Target Applications

| Application | Description |
|-------------|-------------|
| Customer Portal | W1C customer-facing banking portal |
| Staff Portal | W1C staff/operator banking portal |
| GCM | Global Cash Management |
| TLM | Transaction Lifecycle Management |
| FIS OVA | FIS Open Virtual Assistant |

## Common Step Patterns

### Authentication/Login Steps
```gherkin
# MANDATORY first step for customer portal tests - retrieves Vault secrets WITH User parameter
Given I retrieve Customer specific secrets from Vault <VaultScenario> for <User>
And User logs in from login page of W1C portal <ScenarioName>

# For API-specific secrets (use AFTER login when API validation is needed)
Given I retrieve W1C API specific secrets from Vault <APIVaultScenario>
```

> **IMPORTANT**: Always use `for <User>` when retrieving customer secrets. The User parameter specifies which test user credentials to retrieve from Vault.

### Navigation Steps
```gherkin
When User searches for the <AccountHolder> on the Customer Search page
When User clicks on Payments link and select Beneficiaries
When user should be navigated to beneficiaries page
```

### Interaction Steps
```gherkin
When user clicks on the first row of the beneficiary tab
When user should able to click on close button
```

### Validation Steps
```gherkin
Then user should validate the beneficiaries tab
Then user able to validate the fields displayed on the beneficiary details page
```

### JIRA Integration Steps
```gherkin
Then For <JiraId> validate result and check status <FinalRunToAddCommentToJira> and <AddComments> to jira
```

## Tag Conventions

| Tag Type | Examples | Purpose |
|----------|----------|---------|
| JIRA | `@PARSIFAL-1995`, `@ART-65820` | Traceability |
| Suite | `@Regression`, `@Smoke`, `@HealthCheck`, `@Shakedown` | Pipeline execution |
| Feature | `@Payments`, `@Beneficiary`, `@Accounts` | Feature grouping |

## Large Task Decomposition (Subagents)

For complex tasks that risk exhausting context, use the `runSubagent` tool.

### When to Use Subagents

| Indicator | Threshold | Action |
|-----------|-----------|--------|
| Number of scenarios | > 8-10 scenarios | Split by flow/feature area |
| User flows | > 2 distinct flows | One subagent per flow |
| JIRA scope | Multiple acceptance criteria | Split by AC group |
| Feature complexity | Multiple modules/pages | Split by page/module |

### Subagent Example Prompts

**Step Discovery Subagent:**
```
"Search for existing Gherkin steps in src/test/resources/e2e/features/W1C-ChannelsCustomerPortal/.
Find all Given/When/Then steps related to [specific flow].
Return a markdown table: | Step Pattern | Source File | Reusable? |"
```

**Happy Path Subagent:**
```
"Generate Gherkin scenarios for the happy path of [flow name].
Application: [app]. JIRA: [ticket]. User role: [role].
Return complete Gherkin with Feature, Background, Scenario Outline, Examples table."
```

**Negative Scenarios Subagent:**
```
"Generate negative/error test scenarios for [validation rules].
Focus on: invalid inputs, boundary conditions, error messages.
Return Gherkin scenarios with @Negative tag."
```

## Test Cases Document Template

Use the following template for the test cases document:

```markdown
# UI Test Case Generation: <JIRA-TICKET>

## JIRA Issue
- Issue: <JIRA-ISSUE>
- Link: https://jira.srv.westpac.com.au/browse/<JIRA-ISSUE>

## Test Summary
Brief description of what functionality is being tested.

## Target Application
- **Application**: Customer Portal / Staff Portal / GCM / TLM / Other
- **Feature Area**: Payments / Accounts / Transactions / etc.
- **User Role**: Customer / Staff / Supervisor / etc.

## Test Scenario Matrix

| ID | Scenario | Type | Priority | Suite Tag |
|----|----------|------|----------|-----------|
| TC01 | Happy path description | Positive | P1-High | @Regression |
| TC02 | Validation error case | Negative | P2-Medium | @Regression |
| TC03 | Edge case description | Edge | P3-Low | @Regression |

## User Flow (Happy Path)

1. **Given** [precondition/initial state]
2. **When** User [action]
3. **And** User [additional action]
4. **Then** [expected outcome]
5. **And** [validation]

## Gherkin Scenarios

### Feature: [Feature Name]

\`\`\`gherkin
@<JIRA-ISSUE> @Regression @<FeatureTag>
Feature: [Feature description in user story format]
  As a [user role]
  I want to [action/capability]
  So that [business value/benefit]

  Background:
    Given [common precondition]

  @TC01
  Scenario Outline: [Happy path scenario name]
    Given [precondition]
    When [user action]
    And [additional action if needed]
    Then [expected result]
    And [validation step]
    Examples:
      | variable1 | variable2 |
      | value1    | value2    |

  @TC02
  Scenario: [Negative scenario name]
    Given [precondition]
    When [invalid/error action]
    Then [error handling/message]
\`\`\`

## Reusable Steps (Existing)

| Step Pattern | Source | Reusable? |
|--------------|--------|-----------|
| `Given I launch openFin for "<userType>" user` | Multiple features | Yes |
| `When User searches for the <AccountHolder>` | Beneficiary.feature | Yes |
| `Then [validation step]` | [source] | [Yes/No] |

## New Steps Required

| Step Pattern | Purpose |
|--------------|---------|
| `Given [new precondition step]` | [Description] |
| `When [new action step]` | [Description] |
| `Then [new validation step]` | [Description] |

## Test Data Requirements

| Data Element | Description | Example |
|--------------|-------------|---------|
| Account Holder | Customer identifier | `accountHolder` |
| Amount | Transaction value | `100.00` |

## Tags

| Tag | Purpose |
|-----|---------|
| `@<JIRA-ISSUE>` | JIRA traceability |
| `@Regression` | Pipeline suite |
| `@<Feature>` | Feature grouping |

## Acceptance Criteria Coverage

| AC# | Acceptance Criteria | Covered By |
|-----|---------------------|------------|
| AC1 | [From JIRA] | TC01 |
| AC2 | [From JIRA] | TC02, TC03 |

## Open Questions
- [ ] [Questions needing clarification]

## Next Steps
1. Review scenarios with stakeholder
2. Proceed to implementation (`ui-test-planning` agent)
```

## Parameterization Best Practices

```gherkin
# Use descriptive placeholder names
Scenario Outline: User can make payment of <amount> to <beneficiary>
  Given the user has a balance of <initial_balance>
  When the user transfers <amount> to <beneficiary>
  Then the new balance is <expected_balance>

  Examples:
    | initial_balance | amount | beneficiary | expected_balance |
    | 1000.00         | 100.00 | John Doe    | 900.00           |
    | 500.00          | 500.00 | Jane Smith  | 0.00             |
```

## Handoff

Once test cases are confirmed, hand off to: `ui-test-planning` agent

The test cases document serves as the contract for implementation planning.
