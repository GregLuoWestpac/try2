package au.com.westpac.dvs.ui.steps;

import au.com.westpac.dvs.ui.pages.<Feature>Page;
import net.thucydides.core.annotations.Step;
import static org.assertj.core.api.Assertions.assertThat;

public class <Feature>Steps {

    <Feature>Page page;

    // ===== NAVIGATION =====
    @Step("Navigate to <feature> page")
    public void navigateToFeaturePage() {
        page.navigateTo();
    }

    // ===== ACTIONS =====
    @Step("Enter value: {0}")
    public void enterValue(String value) {
        page.enterValue(value);
    }

    @Step("Click submit button")
    public void clickSubmit() {
        page.clickSubmit();
    }

    // ===== VERIFICATIONS (assertions here) =====
    @Step("Verify result is: {0}")
    public void verifyResult(String expected) {
        String actual = page.getDisplayedText();
        assertThat(actual)
            .as("Expected result to be '%s' but was '%s'", expected, actual)
            .isEqualTo(expected);
    }
}
