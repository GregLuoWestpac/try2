package au.com.westpac.dvs.ui.glue;

import au.com.westpac.dvs.ui.steps.<Feature>Steps;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class <Feature>Glue {

    @Steps
    <Feature>Steps steps;

    // ===== GIVEN =====
    @Given("user is on the <feature> page")
    public void userIsOnFeaturePage() {
        steps.navigateToFeaturePage();
    }

    // ===== WHEN =====
    @When("user enters {string} in the field")
    public void userEntersValue(String value) {
        steps.enterValue(value);
    }

    @When("user clicks submit")
    public void userClicksSubmit() {
        steps.clickSubmit();
    }

    // ===== THEN =====
    @Then("the result should be {string}")
    public void resultShouldBe(String expected) {
        steps.verifyResult(expected);
    }
}
