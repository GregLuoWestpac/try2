package au.com.westpac.dvs.ui.pages;

import au.com.westpac.dvs.ui.pages.BasePage;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class <Feature>Page extends BasePage {

    // ===== LOCATORS =====
    @FindBy(id = "<element-id>")
    private WebElementFacade elementName;

    @FindBy(css = "[data-testid='<value>']")
    private WebElementFacade anotherElement;

    // ===== NAVIGATION =====
    public void navigateTo() {
        open();
        waitForPageLoad();
    }

    // ===== INTERACTIONS =====
    public void enterValue(String value) {
        elementName.waitUntilVisible().type(value);
    }

    public void clickSubmit() {
        submitButton.waitUntilClickable().click();
    }

    // ===== STATE QUERIES (no assertions) =====
    public String getDisplayedText() {
        return textElement.waitUntilVisible().getText();
    }

    public boolean isElementVisible() {
        return element.isVisible();
    }
}
