package au.com.westpac.dvs.e2e.runners;

import io.cucumber.junit.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
    features = "src/test/resources/e2e/features/<App>/<Feature>.feature",
    glue = {
        "au.com.westpac.dvs.ui.glue",
        "au.com.westpac.dvs.ui.steps"
    },
    tags = "@<SuiteTag> and @<JIRA-ISSUE>",
    plugin = {
        "pretty",
        "html:target/cucumber-reports/<Feature>.html"
    }
)
public class <Feature>Runner {
}
