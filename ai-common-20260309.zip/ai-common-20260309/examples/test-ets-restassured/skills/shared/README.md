# Shared Skills Resources

This folder contains templates and resources shared across multiple skills/agents.

## Templates

Located in `./templates/`:

| Template | Used By | Purpose |
|----------|---------|---------|
| `feature-template.gherkin` | ui-test-case-generation, ui-test-planning | Gherkin feature file structure |
| `pageobject-template.java` | ui-test-planning, ui-test-implementation | Page Object class structure |
| `glue-template.java` | ui-test-planning, ui-test-implementation | Cucumber glue/step definitions |
| `steps-template.java` | ui-test-planning, ui-test-implementation | Serenity steps class structure |
| `runner-template.java` | ui-test-planning, ui-test-implementation | Cucumber test runner configuration |

## Usage

Reference from skill files:
```markdown
Load templates from: `.github/skills/shared/templates/`
```
