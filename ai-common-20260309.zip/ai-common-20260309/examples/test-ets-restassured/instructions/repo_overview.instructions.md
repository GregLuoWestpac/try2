# Repository Overview: W1C Test Automation

## 1. Repository Type

**Type:** Single Package (Gradle Project)

This is a **single-package test automation repository** using Gradle as the build system. It is NOT a monorepo - there is only one `build.gradle` file at the root with no subprojects defined in `settings.gradle`.

### Build System Details
- **Build Tool:** Gradle 5.5
- **Language:** Java 9
- **Project Name:** W1C Test Automation
- **Group ID:** `au.com.westpac.dvs`

---

## 2. Project Purpose

This repository is a **test automation framework** that provides:
- **API Automation** using Rest-Assured framework
- **UI Automation** using Selenium WebDriver with Cucumber BDD
- **End-to-End (E2E) Testing** for multiple applications
- **NPP (New Payments Platform) Testing** including PayTo, SCT, and X2P flows

---

## 3. Directory Structure

### Root Level Files

| File | Purpose |
|------|---------|
| `build.gradle` | Main Gradle build configuration with dependencies, plugins, and tasks |
| `settings.gradle` | Gradle settings - defines project name and plugin repositories |
| `gradle.properties` | Gradle properties including Artifactory credentials and versions |
| `serenity.properties` | Serenity BDD reporting configuration |
| `gradlew` / `gradlew.bat` | Gradle wrapper scripts for Unix/Windows |
| `README.md` | Project documentation and getting started guide |

### Root Level Directories

```
test-ets-restassured/
├── .github/              # GitHub configuration and documentation
├── build/                # Generated build outputs (Serenity reports)
├── gradle/               # Gradle wrapper configuration
├── history/              # Historical data (empty)
├── input/                # XML input files for NPP/PayTo testing
├── libs/                 # External JAR libraries (MQ, Oracle, etc.)
├── source/               # Shell scripts and configuration files
└── src/                  # Main source code and test resources
```

---

## 4. Detailed Directory Breakdown

### `.github/` - GitHub Configuration
```
.github/
├── agents/               # Copilot agent definitions
│   ├── repo-scanner.agent.md
│   ├── repo-scanner-*.agent.md
├── instructions/         # Coding instructions and documentation
│   ├── repo_overview.instructions.md
│   ├── create_new_test.md
│   └── ...
└── copilot-instructions.md
```

### `src/test/` - Main Test Code

#### `src/test/java/au/com/westpac/dvs/` - Java Test Classes
```
dvs/
├── api/                  # API testing components
│   ├── glue/            # Cucumber step definitions for API tests
│   ├── model/           # Data models/POJOs
│   ├── runners/         # Cucumber test runners
│   └── steps/           # Reusable step implementations
├── e2e/                  # End-to-end test runners
│   └── runners/         # E2E Cucumber runners
├── npp/                  # NPP (New Payments Platform) testing
│   ├── glue/            # NPP step definitions
│   ├── model/           # NPP data models
│   ├── pages/           # Page objects for NPP UI
│   ├── parser/          # XML/message parsers
│   ├── payto/           # PayTo specific components
│   ├── runners/         # NPP test runners
│   ├── steps/           # NPP step implementations
│   └── utils/           # NPP utility classes
├── ui/                   # UI testing components
│   ├── glue/            # UI step definitions
│   ├── pages/           # Page Object Model classes
│   ├── steps/           # UI step implementations
│   └── util/            # UI utilities (WebDriver, helpers)
├── atlas/                # ATLAS application testing
├── pods/                 # PODS application testing
├── CCMPRestResponseFactory.java
├── CCMPRestScenarioSteps.java
└── SessionManager.java
```

#### `src/test/resources/` - Test Resources
```
resources/
├── api/                  # API test resources
│   ├── features/        # API Cucumber feature files
│   │   ├── Insights/
│   │   └── Vault/
│   ├── apiInputData/    # API request payloads
│   ├── apiExpectedResult/ # Expected API responses
│   └── testdata/        # API test data files
├── e2e/                  # E2E test resources
│   └── features/        # E2E Cucumber feature files
│       ├── Appian/
│       ├── ATLAS/
│       ├── BankManager/
│       ├── GCM-CCMP/
│       ├── NPPPayment/
│       ├── OpenFin/
│       ├── PODS/
│       ├── W1C-ChannelsCustomerPortal/
│       ├── W1C-ChannelsStaffPortal/
│       ├── W1C-EndToEnd-Journey/
│       ├── W1C-TLM-Portal/
│       └── ...
├── ui/                   # UI test resources
│   └── data/            # Page object locator files (ALL locators stored here)
│       ├── w1cChannelsCustomerObjectLocator.txt
│       ├── w1cChannelsStaffObjectLocator.txt
│       ├── GCMObjectsLocator.txt
│       ├── TLMObjectsLocator.txt
│       ├── AppianObjectsLocator.txt
│       ├── FISOVAObjectsLocator.txt
│       ├── OpenfinObjectsLocator.txt
│       ├── BankManagerObjectsLocator.txt
│       └── PageObjectsLocator.txt
├── testData/            # Static test data (JSON)
│   ├── E2E/
│   ├── INT/
│   └── *.json
├── config/              # Configuration files
│   └── checkstyle/      # Checkstyle rules
├── config.properties    # API test configuration
└── serenity.conf        # Serenity environment configurations
```

### `input/` - NPP Test Input Files
```
input/
├── npp/                  # NPP message input files
│   └── MX/
│       ├── SCT/         # SCT (Single Credit Transfer) XML files
│       └── X2P/         # X2P (Account to Account) XML files
├── payto/               # PayTo test inputs
│   ├── OFFUS/           # Off-us payment scenarios
│   ├── ONUS/            # On-us payment scenarios
│   ├── PAIN1/           # Pain.001 message files
│   ├── PAIN13/          # Pain.013 message files
│   └── PassiveRecipient/
├── P2B/                 # Pay-to-Business inputs
│   └── NGSProxyAPI/
└── XBorder/             # Cross-border payment inputs
    └── XBorderINWARD/
```

### `libs/` - External Libraries
Contains JAR files not available in Maven repositories:
- **IBM MQ JARs** - Message queue connectivity
- **Oracle JDBC** - Database connectivity (`ojdbc8`)
- **SWIFT Parser** - Payment message parsing
- **JSch** - SSH connectivity
- **XMLUnit** - XML comparison
- **Truststore files** - SSL certificates

### `source/` - Scripts and Configuration
```
source/
├── properties/
│   ├── application.conf  # Shell script with utility functions
│   └── configure.ini     # Infrastructure configuration
└── utils/
    └── get_secret.sh     # Secrets retrieval script
```

### `build/` - Generated Outputs
```
build/
└── site/
    └── serenity/         # Serenity BDD HTML reports
```

---

## 5. Key Configuration Files

### `serenity.conf` - Environment Configuration
Located at `src/test/resources/serenity.conf`, contains environment-specific URLs:
- Selenium Grid URLs
- Salesforce URLs
- GCM/TLM Portal URLs
- API base URIs
- Webdriver configuration

### `config.properties` - API Test Config
Located at `src/test/resources/config.properties`:
- API keys and credentials
- Test account numbers
- File paths for test data

### `serenity.properties` - Report Configuration
- Project name
- Screenshot settings
- Report output directory
- Jira integration settings

> **Note:** For detailed framework versions and dependencies, see [testing_approach.instructions.md](testing_approach.instructions.md).

---

## 6. Test Applications Covered

Based on feature files, the following applications are tested:
1. **W1C Channels** - Staff Portal, Customer Portal
2. **Salesforce CCMP** - Customer management
3. **GCM (Global Cash Management)** - Pre/Post testing
4. **NPP Payments** - SCT, X2P, PayTo flows
5. **ATLAS** - Reference data
6. **TLM Portal** - Transaction lifecycle
7. **OpenFin** - Desktop application
8. **Appian** - BPM workflows
9. **Bank Manager** - Banking operations
10. **PODS** - Operations dashboard
11. **DDEP** - Data platform
12. **Vault/Insights API** - API services

> **Note:** For test execution commands and workflows, see [usage_patterns.instructions.md](usage_patterns.instructions.md).

---

## 7. Integration Points

- **Artifactory** - Artifact repository for dependencies and publishing
- **Jira** - Test case management and defect logging
- **HP ALM** - Enterprise test management
- **SonarQube** - Code quality analysis
- **Selenium Grid** - Distributed test execution
- **CyberArk** - Secrets management

> **Note:** For CI/CD configuration and publishing details, see [workflows.instructions.md](workflows.instructions.md).

---

## 8. Project Conventions

### Package Structure
- Base package: `au.com.westpac.dvs`
- Domain modules: `api`, `ui`, `e2e`, `npp`
- Each module follows: `glue/`, `steps/`, `runners/`, `model/`, `pages/`

### Feature File Organization
- API features: `src/test/resources/api/features/`
- E2E features: `src/test/resources/e2e/features/`
- Features grouped by application under respective directories

### Test Data Organization
- Static JSON data: `src/test/resources/testData/`
- XML inputs: `input/` directory
- Environment-specific: Organized by environment name (E2E, INT, etc.)
