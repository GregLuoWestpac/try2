# Workflows & CI/CD Configuration

## Overview

This document describes the CI/CD configuration, versioning scheme, release process, and environment configuration for the W1C Test Automation repository.

---

## 1. CI/CD Platform

### Current Status: **No External CI/CD Pipeline Detected**

The repository does **NOT** have any external CI/CD platform configuration files present:
- ❌ No `.github/workflows/` directory (GitHub Actions)
- ❌ No `Jenkinsfile` (Jenkins)
- ❌ No `.gitlab-ci.yml` (GitLab CI)
- ❌ No `azure-pipelines.yml` (Azure DevOps)
- ❌ No CircleCI, Travis CI, or other CI configurations

### Build Automation: **Gradle-Based**

CI/CD is managed through **Gradle tasks** with the following key plugins:

| Plugin | Version | Purpose |
|--------|---------|---------|
| `net.researchgate.release` | 2.8.0 | Release management (version bumping, tagging) |
| `com.jfrog.artifactory` | 4.13.0 | Publishing artifacts to Artifactory |
| `org.sonarqube` | 3.1.1 | Code quality analysis |
| `au.com.westpac.dvs.jira-test-gradle-plugin` | 1.13 | JIRA test integration |
| `au.com.westpac.alm.result.publish` | 1.5 | ALM result publishing |
| `au.com.westpac.dvs.csv-from-serenity-report` | 1.5 | CSV report generation |
| `net.serenity-bdd.aggregator` | 2.0.43 | Test report aggregation |

---

## 2. Pipeline Configuration

### Available Gradle Tasks

#### Test Execution Tasks
```bash
# Run specific test with tags and environment
./gradlew clean aggregate test --tests "au.com.westpac.dvs.e2e.runners.<RunnerClass>" \
    -Dcucumber.options="--tags @TagName" \
    -Denvironment=<environment> --info
```

#### Reporting Tasks
| Task | Description |
|------|-------------|
| `aggregate` | Aggregates Serenity BDD test reports |
| `zipReport` | Zips Serenity reports from `build/site/serenity` |
| `zipUpTestResults` | Creates timestamped zip file of test results |
| `generateCsvFromSerenityReport` | Generates CSV file from Serenity reports |

#### Publishing Tasks
| Task | Description | Dependencies |
|------|-------------|--------------|
| `publishToJira` | Publishes test results to JIRA | `aggregate` |
| `publishToAlm` | Publishes results to ALM (HP Quality Center) | `generateCsvFromSerenityReport`, `zipUpTestResults`, `almResultPublish` |
| `artifactoryPublish` | Publishes artifacts to Artifactory | - |
| `sonarqube` | Runs SonarQube analysis | - |

#### Release Tasks (from `net.researchgate.release` plugin)
| Task | Description |
|------|-------------|
| `release` | Performs a full release cycle |
| `afterReleaseBuild` | Hook that triggers: `publishToJira`, `publish`, `publishToMavenLocal`, `artifactoryPublish` |

### Code Quality Pipeline
```bash
# Run SonarQube analysis
./gradlew sonarqube \
    -Dsonar.login=<ServiceAccountOrToken> \
    -Dsonar.branch.name=<branch-name>
```

**SonarQube Dashboard:** https://sonar.srv.westpac.com.au/dashboard?id=A00A46_10xSuperCore-test-ets-restassured

---

## 3. Versioning Scheme

### Version Format
```
<major>.<minor>-SNAPSHOT
```

### Current Version
```properties
# From gradle.properties
version=1.0-SNAPSHOT
```

### Release Process Details

The `net.researchgate.release` plugin (v2.8.0) handles versioning:

1. **SNAPSHOT versions** are used during development
2. **Release versions** remove the `-SNAPSHOT` suffix
3. **After release**, version is bumped and `-SNAPSHOT` is re-added

### Maven Coordinates
```groovy
group = 'au.com.westpac.dvs'
name = 'W1C Test Automation'
version = '1.0-SNAPSHOT'
```

---

## 4. Release Process

### Automated Release Flow

```
┌────────────────────────────────────────────────────────────────┐
│                     ./gradlew release                          │
└────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────────────┐
│  1. Verify no uncommitted changes                              │
│  2. Remove -SNAPSHOT from version                              │
│  3. Build and test                                             │
│  4. Create Git tag                                             │
│  5. Commit version changes                                     │
└────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────────────┐
│              afterReleaseBuild (triggered)                     │
│  ├── publishToJira     (depends on: aggregate)                 │
│  ├── publish           (Maven publish)                         │
│  ├── publishToMavenLocal                                       │
│  └── artifactoryPublish                                        │
└────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────────────┐
│  6. Bump version and add -SNAPSHOT                             │
│  7. Commit updated version                                     │
│  8. Push changes and tags                                      │
└────────────────────────────────────────────────────────────────┘
```

### Manual Release Steps
```bash
# 1. Ensure clean working directory
git status

# 2. Run release
./gradlew release

# 3. (Automated) Version updates, tagging, and publishing happen automatically
```

### Artifact Publishing

**Artifactory Repository:**
- URL: `https://artifactory.srv.westpac.com.au/artifactory`
- Repository: `A014A6_W1C-maven-snapshot`

**Published Artifacts:**
- Test results ZIP file (timestamped: `testresults_MM_dd_yyyy_HH_mm.zip`)
- Java components

---

## 5. Environment Configuration

### Environment Selection
Environments are configured via system properties:

```bash
# Set environment at runtime
-Denvironment=<environment-name>

# Or via gradle.properties default
env=IntTenant2
```

### Available Environments

Defined in [serenity.conf](../src/test/resources/serenity.conf):

| Environment | Description |
|-------------|-------------|
| `default` | Base configuration with default URLs |
| `IntTenant2` | Integration tenant 2 (SIT1 environment) |
| `e2eTenant2` | E2E testing tenant |

### Environment-Specific Configuration

#### URLs by Environment

**IntTenant2 (SIT1) URLs:**
| Service | URL |
|---------|-----|
| Staff Portal | `https://one.sit1.ui.westpac.com.au/galaxy/customersearch` |
| Customer Portal | `https://www.sit1.ui.westpac.com.au/applications/multiverse/sit/w1c1/manifest.customer.json` |
| Appian | `https://workorch-sit.westpacgroup.com/suite/sites/one-service-portal` |
| Selenium Grid | `https://seleniumgrid.tst.srv.westpac.com.au/wd/hub` |
| Salesforce | `https://parsifal--venuse2e.my.salesforce.com` |

### Configuration Files

| File | Purpose |
|------|---------|
| [gradle.properties](../gradle.properties) | Build properties, credentials, version |
| [serenity.properties](../serenity.properties) | Serenity BDD & JIRA configuration |
| [serenity.conf](../src/test/resources/serenity.conf) | Environment-specific URLs & WebDriver config |
| [config.properties](../src/test/resources/config.properties) | Test data paths & API keys |
| [configure.ini](../source/properties/configure.ini) | DevOps deployment configuration |

### Secret Management

**CyberArk Integration:**
- Secrets retrieved via CyberArk API
- Configured in [configure.ini](../source/properties/configure.ini)
- Script: [get_secret.sh](../source/utils/get_secret.sh)

**CyberArk Configuration:**
| Environment | App ID | Safe Name |
|-------------|--------|-----------|
| Non-Production | `O4-002-scrt-keystore-A` | `O4-002-scrt-keystore-NPR` |
| Production | `APP-3271-scrt-nppdevop-A` | `APP-3271-scrt-nppdevop-PRD` |

---

## 6. Integration Points

### JIRA Integration
```properties
# serenity.properties
jira.url=https://jira.srv.westpac.com.au
jira.project=ART
```

**Task:** `publishToJira` - Publishes test results with:
- Fix version
- Environment
- Platform
- Defect logging capability

### ALM Integration (HP Quality Center)
```groovy
almResultPublish {
    hostName = 'alm.srv.westpac.com.au'
    domain = 'WIB'
    projectName = 'Parsifal_Program'
}
```

**Task:** `publishToAlm`

### SonarQube Integration
```properties
# gradle.properties
systemProp.sonar.host.url=https://sonar.srv.westpac.com.au
sonar.projectKey=A00A46_10xSuperCore-test-ets-restassured
```

---

## 7. Gradle Wrapper Configuration

```properties
# gradle/wrapper/gradle-wrapper.properties
gradleWrapperVersion=5.5
distributionUrl=https://artifactory.srv.westpac.com.au/artifactory/gradle-distributions/gradle-5.5-bin.zip
```

---

## 8. Recommendations

### Missing CI/CD Components

1. **Consider Adding GitHub Actions:**
   ```yaml
   # .github/workflows/ci.yml
   name: CI Pipeline
   on: [push, pull_request]
   jobs:
     build:
       runs-on: ubuntu-latest
       steps:
         - uses: actions/checkout@v3
         - uses: actions/setup-java@v3
         - run: ./gradlew clean test aggregate
   ```

2. **Automated PR Validation:**
   - Run `checkstyleTest` on PRs
   - Run SonarQube analysis
   - Execute smoke tests

3. **Scheduled Test Runs:**
   - Configure nightly regression test execution
   - Automated report generation and notification

### Security Improvements
- Move credentials from `gradle.properties` to GitHub Secrets or environment variables
- Rotate Artifactory tokens regularly
- Use GitHub's secret scanning

---

## Quick Reference

### Common Commands

```bash
# Run tests with specific tags
./gradlew clean aggregate test --tests "au.com.westpac.dvs.e2e.runners.W1CChannelsStaffPortal" \
    -Dcucumber.options="--tags @OnMe" -Denvironment=IntTenant2

# Generate reports
./gradlew aggregate

# Publish to JIRA
./gradlew publishToJira

# Publish to ALM
./gradlew publishToAlm -Dusername=<user> -Dpassword=<pass> \
    -PtestSetFolder=<folder> -PtestSetName=<name>

# Run SonarQube analysis
./gradlew sonarqube -Dsonar.login=<token> -Dsonar.branch.name=<branch>

# Full release
./gradlew release
```
