# Project Context & Domain Knowledge

## 1. Project Purpose

**W1C Test Automation** is a comprehensive test automation framework designed for testing Westpac's banking and payments systems. The project provides:

- **API Automation** using Rest-Assured framework
- **UI Automation** using Selenium WebDriver with Cucumber BDD
- **End-to-End (E2E) Testing** for multiple banking applications
- **NPP (New Payments Platform) Testing** including PayTo, SCT, and X2P payment flows

### Core Objectives
1. Validate payment processing across Australia's NPP infrastructure
2. Test customer and staff-facing banking portals (W1C Channels)
3. Ensure compliance with ISO 20022 messaging standards
4. Automate regression and smoke testing for banking operations

---

## 2. Business Domain

### Industry Context
- **Domain**: Banking & Financial Services (Australia)
- **Focus Area**: Real-time payments, account management, transaction processing
- **Regulatory Framework**: Australian Payments Network (AusPayNet), Reserve Bank of Australia (RBA)

### Key Business Capabilities Tested
| Capability | Description |
|------------|-------------|
| Real-Time Payments | NPP-based instant payments (SCT, X2P1, OSKO) |
| PayTo Services | Mandate-based payment initiation (pain.001, pain.013) |
| Account Management | Customer account operations, balances, statements |
| Transaction Processing | Inward/outward payments, returns, exceptions |
| Staff Operations | Customer service portal actions, investigations |
| Compliance & Risk | AML checks, fraud detection, sanctions screening |

---

## 3. Terminology Glossary

### Payment Platforms & Schemes

| Term | Full Name | Description |
|------|-----------|-------------|
| **NPP** | New Payments Platform | Australia's real-time payments infrastructure enabling instant fund transfers 24/7/365 |
| **OSKO** | OSKO (by BPAY) | Consumer-facing brand for NPP payments; real-time account-to-account transfers |
| **PayTo** | PayTo Service | NPP overlay service enabling third parties to initiate payments from customer accounts via mandates |
| **SCT** | Single Credit Transfer | Basic NPP payment scheme for standard credit transfers (npp.clear.01-sct.04) |
| **X2P1** | Person-to-Person (Account to Account) | NPP overlay service for peer-to-peer payments with enhanced data (npp.clear.01-x2p1.04) |
| **PayID** | PayID | Alias-based payment addressing (email, phone, ABN) linked to bank accounts |

### Transaction Types

| Term | Description |
|------|-------------|
| **ONUS** | On-Us Transaction - Payment where both debtor and creditor accounts are held at the same financial institution (Westpac) |
| **OFFUS** | Off-Us Transaction - Payment involving external financial institutions |
| **Inward** | Payment received from another financial institution into a Westpac account |
| **Outward** | Payment sent from a Westpac account to another financial institution |
| **OFI** | Other Financial Institution - External bank participating in the payment |
| **WBC** | Westpac Banking Corporation - The bank being tested |

### ISO 20022 Message Types

| Message | Full Name | Purpose |
|---------|-----------|---------|
| **pacs.008** | FI to FI Customer Credit Transfer | Core credit transfer message between financial institutions |
| **pacs.004** | Payment Return | Return of a previously sent payment |
| **pacs.002** | Payment Status Report | Status confirmation/rejection of a payment |
| **pain.001** | Customer Credit Transfer Initiation | Payment initiation request from customer/creditor |
| **pain.013** | Creditor Payment Activation Request | PayTo mandate payment request |
| **camt.** | Cash Management messages | Account reporting and statement messages |

### Financial Institution Identifiers

| BIC Code | Institution |
|----------|-------------|
| **WPACAU2SXXX** / **WPACAU3SXXX** | Westpac Banking Corporation |
| **CTBAAUSNXXX** | Commonwealth Bank of Australia |
| **RSBKAU2SXXX** | Reserve Bank of Australia / Test Institution |
| **CREDITORAGENTBIC** | Placeholder for creditor's financial institution |

### Account & Reference Terms

| Term | Description |
|------|-------------|
| **BSB** | Bank-State-Branch number (6 digits) identifying the branch |
| **BBAN** | Basic Bank Account Number |
| **Dbtr** | Debtor - The party whose account is debited |
| **Cdtr** | Creditor - The party whose account is credited |
| **InstgAgt** | Instructing Agent - FI initiating the payment |
| **InstdAgt** | Instructed Agent - FI receiving the payment instruction |

### Application & Portal Terms

| Term | Description |
|------|-------------|
| **W1C** | Westpac One Core - Core banking platform |
| **TLM** | Transaction Lifecycle Management - Monitoring and investigation system |
| **FIS OVA** | FIS OVA (Open Vision Advantage) - Payment operations and monitoring platform |
| **GCM** | Global Cash Management - Cash management system |
| **CCMP** | Customer Communication Management Platform |
| **PODS** | Payments Operations Dashboard System |
| **OpenFin** | Desktop application container for banking applications |
| **Appian** | BPM (Business Process Management) platform for workflows |

### Test & Technical Terms

| Term | Description |
|------|-------------|
| **PAG Emulator** | Payment Application Gateway Emulator - Simulates NPP message flows |
| **MX Messages** | ISO 20022 XML message format |
| **Vault** | HashiCorp Vault - Secrets management for test credentials |
| **Serenity BDD** | Test framework for BDD-style test automation with rich reporting |
| **Suspense Account** | Holding account for payments that cannot be processed immediately |

### Return & Exception Codes

| Code | Description |
|------|-------------|
| **AC03** | Invalid Creditor Account Number |
| **AC06** | Account Blocked or Closed |
| **FOCR** | Following Cancellation Request - Solicited return reason |
| **W304** | Specific exception handling code |
| **W399** | Specific exception handling code |

### Payment Processing Terms

| Term | Description |
|------|-------------|
| **SttlmMtd** | Settlement Method (CLRG = Clearing) |
| **ChrgBr** | Charge Bearer (SLEV = Service Level) |
| **NbOfTxs** | Number of Transactions |
| **IntrBkSttlmAmt** | Interbank Settlement Amount |
| **IntrBkSttlmDt** | Interbank Settlement Date |
| **Mandate** | PayTo agreement authorizing payment initiation |

---

## 4. Key Business Domains

### 4.1 NPP Payment Processing
Testing the full lifecycle of NPP payments:
- Payment initiation (outward)
- Payment receipt (inward)
- Payment returns (pacs.004)
- Exception handling
- Suspense posting

### 4.2 PayTo Mandate Services
Testing mandate-based payment initiation:
- Mandate creation and activation
- Pain.001 credit transfer initiation
- Pain.013 creditor payment activation
- Mandate amendments and cancellations

### 4.3 Customer Portal (W1C Channels)
Testing customer-facing functionality:
- Account dashboard and balances
- Payment initiation and confirmation
- Transaction history and details
- Beneficiary management

### 4.4 Staff Portal Operations
Testing staff-facing functionality:
- Customer search and lookup
- Payment initiation on behalf of customers
- Return initiation (solicited/unsolicited)
- Transaction investigation

### 4.5 Transaction Lifecycle Management (TLM)
Testing investigation and monitoring:
- Case creation and assignment
- NPP business support workflows
- Sanctions and AML operations
- Digital fraud investigations

### 4.6 Payment Operations (PODS/FIS OVA)
Testing operations dashboards:
- Payment status monitoring
- Interchange tracking
- Exception management
- Reporting and analytics

---

## 5. Data Flow Patterns

### Inward Payment Flow
```
OFI → NPP → Westpac (PAG) → 10x Core → Customer Account
                ↓
         FIS OVA (Monitoring)
                ↓
         TLM (Investigations)
```

### Outward Payment Flow
```
Customer Portal → 10x Core → PAG → NPP → OFI
       ↓
  Staff Portal (if assisted)
       ↓
  FIS OVA (Monitoring)
```

### PayTo Flow
```
Merchant/Creditor → pain.001/pain.013 → NPP MPS → Westpac
                                              ↓
                                    Mandate Validation
                                              ↓
                                    Account Debit (pacs.008)
```

---

## 6. Test Environment Context

| Environment | Purpose |
|-------------|---------|
| **SIT1/IntTenant2** | System Integration Testing |
| **e2eTenant2** | End-to-End Testing |
| **Venus** | 10x Banking Platform instance |

### Key Integration Points
- **10x Insights API** - Transaction validation
- **Vault** - Secrets and credentials
- **Selenium Grid** - Distributed UI testing
- **Artifactory** - Artifact repository
- **Jira** - Test case management
