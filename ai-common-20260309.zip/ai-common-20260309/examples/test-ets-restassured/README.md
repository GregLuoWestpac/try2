# Project Example: test-ets-restassured

Pre-generated GitHub Copilot instructions and skills for a **Selenium + RestAssured** test automation repository (W1C Test Automation).

## What Is This?

This folder contains a complete, ready-to-use set of Copilot customisation files for a real test repo. It includes:

| Folder | Contents |
|--------|----------|
| `instructions/` | 6 instruction files describing the repo's structure, domain, standards, testing patterns, workflows, and usage |
| `skills/` | 3 project-specific skills (`ui-test-case-generation`, `ui-test-planning`, `ui-test-implementation`) plus shared templates |

These files are what the **repo-scanner** workflow would normally generate automatically. In this case, they've been pre-generated so testers can use them immediately without running the scanner themselves.

## How the Normal Flow Works

```
┌───────────────┐      ┌───────────────┐      ┌──────────────────────────┐
│  repo-init    │ ──▶  │ repo-scanner  │ ──▶ │ instructions/ populated  │
│  (templates)  │      │  (agents)     │      │ with repo-specific info  │
└───────────────┘      └───────────────┘      └──────────────────────────┘
```

1. **repo-init** — Copy `workflows/repo-init/.github/` into the target repo. This gives you `copilot-instructions.md` and `instructions/` templates with `<!-- TODO -->` placeholders.
2. **repo-scanner** — Run `@repo-scanner` in Copilot Chat. It scans the codebase and auto-populates the instruction files with discovered structure, patterns, domain context, etc.
3. **Add workflow agents** — Copy the workflow you need (e.g. `workflows/e2e-test-automation/.github/`) to get the agents.

This project example **skips steps 1–2** by providing the already-populated instruction files and skills.

## How to Use This Example

Testers need to copy two things into their test repo's `.github/` folder:

### Step 1: Copy instructions and skills from this example

```powershell
# PowerShell — from ai-common root
$target = "<your-test-repo>"

# Copy instructions
Copy-Item -Recurse -Force "examples/test-ets-restassured/instructions/*" "$target/.github/instructions/"

# Copy skills
Copy-Item -Recurse -Force "examples/test-ets-restassured/skills/*" "$target/.github/skills/"
```

```bash
# Bash — from ai-common root
target="<your-test-repo>"

# Copy instructions
cp -r examples/test-ets-restassured/instructions/* "$target/.github/instructions/"

# Copy skills
cp -r examples/test-ets-restassured/skills/* "$target/.github/skills/"
```

### Step 2: Copy agents from the e2e-test-automation workflow

```powershell
# PowerShell
Copy-Item -Recurse -Force "workflows/e2e-test-automation/.github/*" "$target/.github/"
```

```bash
# Bash
cp -r workflows/e2e-test-automation/.github/* "$target/.github/"
```

This adds the following agents:

| Agent | Purpose |
|-------|---------|
| `ui-test-workflow` | Orchestrates the full workflow end-to-end *(see note below)* |
| `ui-test-case-generation` | Analyses requirements → produces BDD test cases (`test-cases.md`) |
| `ui-test-planning` | Plans implementation → produces `implementation-plan.md` |
| `ui-test-planning-locators` | Sub-agent for Phase 2 — element locator identification |
| `ui-test-planning-code` | Sub-agent for Phases 3–6 — Page/Glue/Steps/Runner design |
| `ui-test-implementation` | Implements the planned test code into actual files |

> **⚠️ Note on `ui-test-workflow`:** While this orchestration agent exists for convenience, it is **not recommended** for direct use. Because it coordinates all three phases in a single conversation, it consumes a very large amount of context — which can degrade output quality and hit token limits on complex test scenarios. Instead, run the agents individually in sequence: `@ui-test-case-generation` → `@ui-test-planning` → `@ui-test-implementation`. This keeps each conversation focused, gives you a checkpoint to review between phases, and produces better results.

### Step 3 (Optional): Copy the foundation layer

If the repo doesn't already have a `copilot-instructions.md`:

```powershell
Copy-Item -Recurse -Force "workflows/repo-init/.github/*" "$target/.github/"
```

## Pre-requisites

Before running the workflow, you need **requirements ready as context** for the test-case-generation agent. The test scenarios are derived directly from acceptance criteria and functional requirements — so the quality of your input directly determines the quality of your generated test cases.

Choose one of the following options to prepare your requirements:

### Option 1: JIRA XML Export (Manual)

Export JIRA tickets as XML and use Copilot to produce a structured requirements file.

1. In JIRA, use the **Issue Navigator** to filter the relevant tickets (e.g. all tickets in an epic, a sprint, or a custom JQL filter). You can export any number of tickets — or an entire epic — in one go.
2. Export the results as **XML** (click `Export` → `XML`)
3. Place the downloaded `.xml` file in your repo (e.g. `.docs/requirements/export.xml`)
4. Ask Copilot to split the bulk export into individual ticket XMLs:

```
Split the JIRA XML export at .docs/requirements/export.xml into individual
ticket XML files. Save each ticket as .docs/requirements/tmp/<TICKET-ID>.xml
```

5. Then ask Copilot to process the individual tickets in batches and generate a consolidated requirements markdown:

```
Analyse the JIRA ticket XMLs in .docs/requirements/tmp/.
Extract all user stories, acceptance criteria, and functional requirements.
Process no more than 10 tickets at a time.
Output a structured markdown file at .docs/requirements/requirements.md
```

> **⚠️ Recommended: ≤ 10 tickets per batch.** Large XML exports can exceed context limits. The split-then-batch approach above handles this automatically — Copilot processes tickets in manageable chunks and merges the results.

The generated `requirements.md` becomes the input context for `@ui-test-case-generation`.

### Option 2: JIRA Fetch Skill (Automated)

Use the `jira-fetch` skill from the **task-development** workflow to pull tickets directly via the JIRA REST API. The skill fetches full ticket details (summary, description, acceptance criteria, comments, attachments) and produces a structured `ticket.md` per ticket.

Once all relevant tickets are fetched, consolidate them into a single requirements file or reference the individual `ticket.md` files as context for `@ui-test-case-generation`.

> **📖 Setup & usage:** See [`workflows/task-development/`](../../workflows/task-development/) for configuration (JIRA PAT, `.env` setup) and skill details.

### Option 3: Browser Automation MCP (Confluence / Swagger)

Use the **browser-automation** MCP tool to navigate to Confluence pages or Swagger UI, extract content from the browser, and generate a requirements markdown file. Optionally ingest extracted content into **docsearch** for semantic search across large document sets.

> **📖 Setup & usage:** See [`tools/mcps/browser-automation/`](../../tools/mcps/browser-automation/) and [`tools/mcps/docsearch/`](../../tools/mcps/docsearch/) for configuration and available MCP tools.

## The Workflow

Once everything is copied, testers run the agents in Copilot Chat in this order:

```
┌────────────────────┐      ┌────────────────────┐      ┌────────────────────┐
│  @ui-test-case-    │      │  @ui-test-          │      │  @ui-test-         │
│  generation        │ ──▶  │  planning           │ ──▶  │  implementation    │
└────────────────────┘      └────────────────────┘      └────────────────────┘
        │                           │                           │
        ▼                           ▼                           ▼
  test-cases.md            implementation-plan.md        Working test files
  (BDD scenarios)          (file paths, locators,        (.feature, Page Objects,
                            code signatures)              Glue, Steps, Runner)
```

Or use `@ui-test-workflow` to orchestrate all three phases automatically — though running them individually is recommended (see note above).

### Artifact Output Location

All planning and design artifacts are written to:

```
.docs/agentic-logs/<JIRA-ISSUE>/
```

where `<JIRA-ISSUE>` is the JIRA ticket ID provided as input (e.g. `PARSIFAL-123`).

> **Note:** Phases 1 and 2 produce documentation artifacts under `.docs/agentic-logs/`. Phase 3 produces actual test code files in the standard `src/test/` source tree. Each agent in the chain reads the previous phase's artifacts from `.docs/agentic-logs/<JIRA-ISSUE>/` as input context.

**Required inputs** (the agent will ask for these):

| Input | Description | Example |
|-------|-------------|---------|
| Functionality | The user flow to test | "PayTo mandate creation" |
| Target Portal | Application under test | Customer Portal, Staff Portal, GCM |
| JIRA Issue | For traceability | `PARSIFAL-123` |
| Suite Tag | Test classification | `@Regression`, `@Smoke` |

## What's in `instructions/`

| File | Content |
|------|---------|
| `project_context.instructions.md` | Domain glossary (NPP, PayTo, ISO 20022), business capabilities, terminology |
| `repo_overview.instructions.md` | Directory structure, build system (Gradle), package layout |
| `development_standards.instructions.md` | Coding conventions, dependency management, configuration patterns |
| `testing_approach.instructions.md` | Test architecture, frameworks (Cucumber BDD, RestAssured, Selenium) |
| `usage_patterns.instructions.md` | Consumer integration patterns, API usage |
| `workflows.instructions.md` | CI/CD pipelines, release process |

## What's in `skills/`

| Skill | Description |
|-------|-------------|
| `ui-test-case-generation/SKILL.md` | Project-specific paths for feature files, step reuse search patterns, output format |
| `ui-test-planning/SKILL.md` | 4-layer architecture (Feature → Glue → Steps → Page), locator storage, implementation file locations |
| `ui-test-implementation/SKILL.md` | Implementation patterns, test execution commands, code templates per layer |
| `shared/templates/` | Java/Gherkin templates — `feature-template.gherkin`, `pageobject-template.java`, `glue-template.java`, `steps-template.java`, `runner-template.java` |