# Composing Workflows

This guide explains how to assemble workflows from `ai-common` into a target repository's `.github/` folder.

## How It Works

Each workflow in `workflows/` is a self-contained package with its own agents, skills, and prompts. They all write into `.github/` subdirectories using **distinct filenames**, so they merge cleanly with no conflicts.

See [README.md](README.md) for the full repository structure.

## Quick Compose

Copy everything in one shot:

**PowerShell:**
```powershell
$t = "<target-repo>"
"repo-init","repo-scanner","task-development","code-review","e2e-test-automation","defect-triage" | ForEach-Object { Copy-Item -Recurse -Force "workflows/$_/.github/*" "$t/.github/" }
Copy-Item "$t/.github/.env.example" "$t/.github/.env"
Add-Content "$t/.gitignore" ".github/.env"
```

**Bash:**
```bash
t="<target-repo>"
for w in repo-init repo-scanner task-development code-review e2e-test-automation defect-triage; do cp -r "workflows/$w/.github/"* "$t/.github/"; done
cp "$t/.github/.env.example" "$t/.github/.env"
echo '.github/.env' >> "$t/.gitignore"
```

Or pick and choose — see the step-by-step below.

## Setup Steps

### 1. Foundation (required)

Copy `workflows/repo-init/.github/` into the target repo's `.github/`.

This provides:
- `copilot-instructions.md` — universal principles and confidence assessment
- `instructions/` — template files with `<!-- TODO -->` placeholders
- `.env.example` — environment variable template (copy to `.env` in same directory)

### 2. Add Workflows (pick what you need)

For each workflow you want, merge its `.github/` contents into the target repo's `.github/`:

**PowerShell (Windows):**
```powershell
# Example: add repo-scanner
Copy-Item -Recurse -Force "workflows/repo-scanner/.github/*" "<target-repo>/.github/"

# Example: add task-development
Copy-Item -Recurse -Force "workflows/task-development/.github/*" "<target-repo>/.github/"

# Example: add code-review
Copy-Item -Recurse -Force "workflows/code-review/.github/*" "<target-repo>/.github/"

# Example: add e2e-test-automation
Copy-Item -Recurse -Force "workflows/e2e-test-automation/.github/*" "<target-repo>/.github/"

# Example: add defect-triage
Copy-Item -Recurse -Force "workflows/defect-triage/.github/*" "<target-repo>/.github/"
```

**Bash (macOS/Linux):**
```bash
# Example: add repo-scanner
cp -r workflows/repo-scanner/.github/* <target-repo>/.github/

# Example: add task-development
cp -r workflows/task-development/.github/* <target-repo>/.github/

# Example: add code-review
cp -r workflows/code-review/.github/* <target-repo>/.github/

# Example: add e2e-test-automation
cp -r workflows/e2e-test-automation/.github/* <target-repo>/.github/

# Example: add defect-triage
cp -r workflows/defect-triage/.github/* <target-repo>/.github/
```

Since each workflow uses unique filenames (e.g., `repo-scanner-*.agent.md`, `task-*.agent.md`, `code-review.agent.md`, `ui-test-*.agent.md`), there are no file conflicts between workflows.

> **Note:** The `e2e-test-automation` workflow ships agents only — it expects project-specific `SKILL.md` files and populated `instructions/` to already exist in the target repo's `.github/`. Use repo-scanner to generate these, or copy pre-built ones from an example (see [Using Project Examples](#using-project-examples) below).

### Using Project Examples

The `examples/` directory contains pre-built instructions and skills for specific projects. These bypass the repo-init + repo-scanner steps by providing already-populated files.

To use an example (e.g., `test-ets-restassured` for a Selenium + RestAssured project):

**PowerShell (Windows):**
```powershell
$t = "<target-repo>"

# Copy pre-built instructions
Copy-Item -Recurse -Force "examples/test-ets-restassured/instructions/*" "$t/.github/instructions/"

# Copy pre-built skills
Copy-Item -Recurse -Force "examples/test-ets-restassured/skills/*" "$t/.github/skills/"
```

**Bash (macOS/Linux):**
```bash
t="<target-repo>"

# Copy pre-built instructions
cp -r examples/test-ets-restassured/instructions/* "$t/.github/instructions/"

# Copy pre-built skills
cp -r examples/test-ets-restassured/skills/* "$t/.github/skills/"
```

| Example | Target Project | Provides | Docs |
|---------|---------------|----------|------|
| `test-ets-restassured` | Selenium + RestAssured test repos (W1C) | `instructions/` + `skills/` (with templates) | [README](examples/test-ets-restassured/README.md) |
| `docsearch` | Docsearch ingestion | Solution design documents + pre-built index | [README](examples/docsearch/README.md) |

### 3. Add Project-Specific Skills (if needed)

Some workflows (like `e2e-test-automation`) require project-specific `SKILL.md` files and populated instructions. You have two options:

- **Generate them:** Run repo-scanner (`@repo-scanner`) against the target repo to auto-populate instruction files
- **Copy from an example:** If a matching example exists in `examples/`, copy its `instructions/` and `skills/` into `.github/` (see [Using Project Examples](#using-project-examples) above)

### 4. Configure Environment

Copy `.env.example` to `.env` (both live in `.github/`) and fill in required values. **Add `.github/.env` to the target repo’s `.gitignore`** — it contains secrets.

```bash
cp <target-repo>/.github/.env.example <target-repo>/.github/.env
echo '.github/.env' >> <target-repo>/.gitignore
```

## Creating a New Workflow

New workflows should follow the established pattern:

```
workflows/<workflow-name>/
└── .github/
    ├── agents/         # Agent definitions (*.agent.md)
    ├── skills/         # Reusable capabilities (SKILL.md per skill)
    └── prompts/        # User-invokable prompt templates (*.prompt.md)
```

**Naming convention:** Prefix all agent files with the workflow name (e.g., `code-review.agent.md`, `task-*.agent.md`, `repo-scanner-*.agent.md`) to avoid collisions when merged.

### Agent Guidelines

- One orchestrator agent per workflow (e.g., `repo-scanner.agent.md`)
- Sub-agents prefixed with the orchestrator name (e.g., `repo-scanner-build.agent.md`)
- Each agent should define its own `tools`, `handoffs`, and `model` in frontmatter
- Include confidence assessment protocol in every agent

### Skill Guidelines

- Each skill gets its own directory with a `SKILL.md`
- Skills are invoked by agents, not directly by users
- Keep skills focused on a single capability

### Prompt Guidelines

- Prompts are user-facing templates (invoked via `@prompt-name`)
- Keep prompts self-contained — they should work without requiring specific agents

## Promoting Skills or Prompts to Shared

When a skill or prompt is used by **3 or more workflows**, promote it to a shared location to avoid duplication and drift:

### When to Promote

| Used by | Action |
|---------|--------|
| 1 workflow | Keep in that workflow's `skills/` or `prompts/` |
| 2 workflows | Duplicate is acceptable — keep in each workflow |
| 3+ workflows | Promote to `workflows/_shared/` |

### How to Promote

1. Create the shared directory:
   ```
   workflows/_shared/.github/
   ├── skills/
   │   └── <skill-name>/
   │       └── SKILL.md
   └── prompts/
       └── <prompt-name>.prompt.md
   ```

2. Move the canonical version into `workflows/_shared/`

3. Remove the copies from individual workflows

4. Update the compose instructions — `_shared/` should be copied **after** `repo-init/` and **before** any specific workflow:

   **PowerShell (Windows):**
   ```powershell
   # 1. Foundation
   Copy-Item -Recurse -Force "workflows/repo-init/.github/*" "<target>/.github/"
   # 2. Shared skills & prompts
   Copy-Item -Recurse -Force "workflows/_shared/.github/*" "<target>/.github/"
   # 3. Workflows
   Copy-Item -Recurse -Force "workflows/repo-scanner/.github/*" "<target>/.github/"
   ```

   **Bash (macOS/Linux):**
   ```bash
   # 1. Foundation
   cp -r workflows/repo-init/.github/* <target>/.github/
   # 2. Shared skills & prompts
   cp -r workflows/_shared/.github/* <target>/.github/
   # 3. Workflows
   cp -r workflows/repo-scanner/.github/* <target>/.github/
   ```

5. Update agent files that reference the skill/prompt — no path changes needed since the merged `.github/` structure is flat

### Promotion Checklist

- [ ] Verify the skill/prompt works identically across all consuming workflows
- [ ] Ensure no workflow-specific logic has crept into the shared version
- [ ] Update this compose guide if the shared layer is being created for the first time
- [ ] Document the shared skill/prompt in `_shared/README.md`

## Adding MCP Tools

MCP servers and external tools live outside the workflow structure:

```
tools/
└── mcps/
    └── <tool-name>/
```

Workflows reference MCP tools via the `tools` field in agent frontmatter. MCP tool setup is independent of workflow composition.
