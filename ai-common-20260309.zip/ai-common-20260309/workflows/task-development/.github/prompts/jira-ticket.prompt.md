---
description: Fetch and display a JIRA ticket's details
---

# JIRA Ticket Fetcher

Fetch the JIRA ticket **{{ticketId}}** and present its details.

## Instructions

1. Read the `JIRA_PAT` value from the `.github/.env` file (strip quotes if present)

2. Execute the command to fetch the ticket:

**PowerShell (Windows):**
```powershell
$pat = "<JIRA_PAT_VALUE>"
$response = Invoke-RestMethod -Uri "https://jira.srv.westpac.com.au/rest/api/2/issue/{{ticketId}}?fields=summary,status,issuetype,priority,assignee,reporter,description,created,updated,labels,components" -Headers @{ Authorization = "Bearer $pat"; "Content-Type" = "application/json" }
$response | ConvertTo-Json -Depth 4
```

**Bash (macOS/Linux):**
```bash
pat="<JIRA_PAT_VALUE>"
curl -s -H "Authorization: Bearer $pat" -H "Content-Type: application/json" \
  "https://jira.srv.westpac.com.au/rest/api/2/issue/{{ticketId}}?fields=summary,status,issuetype,priority,assignee,reporter,description,created,updated,labels,components" | jq '.'
```

3. Parse the JSON response and extract these fields:
   - `key` - The ticket ID (e.g., ART-98452)
   - `fields.summary` - Ticket title
   - `fields.status.name` - Current status
   - `fields.issuetype.name` - Issue type (Bug, Story, etc.)
   - `fields.priority.name` - Priority level
   - `fields.assignee.displayName` - Person assigned
   - `fields.reporter.displayName` - Person who created it
   - `fields.created` - Creation date
   - `fields.updated` - Last update date
   - `fields.description` - Full description text
   - `fields.labels` - Array of labels
   - `fields.components[].name` - Component names

4. Present the information in this format:

## Output Format

```markdown
## [KEY] SUMMARY

| Field | Value |
|-------|-------|
| **Status** | STATUS |
| **Type** | ISSUE_TYPE |
| **Priority** | PRIORITY |
| **Assignee** | ASSIGNEE_NAME |
| **Reporter** | REPORTER_NAME |
| **Created** | FORMATTED_DATE |
| **Updated** | FORMATTED_DATE |

### Description
DESCRIPTION_TEXT (convert JIRA markup to readable text)

### Labels
- LABEL_1
- LABEL_2

### Components
- COMPONENT_1
- COMPONENT_2
```

## Error Handling

- **401 Unauthorized**: PAT may be invalid or expired - regenerate at JIRA profile settings
- **404 Not Found**: Ticket ID doesn't exist or you lack access permissions
- **Connection Failed**: Check VPN/network access to `jira.srv.westpac.com.au`

## Notes

- JIRA Server uses Bearer token authentication with PAT (not Basic Auth like Cloud)
- Description may contain JIRA wiki markup - convert `!image.png!` to `[image]`, `{code}` to code blocks, etc.
