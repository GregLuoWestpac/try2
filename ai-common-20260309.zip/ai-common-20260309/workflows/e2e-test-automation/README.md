# E2E Test Automation Workflow

A composable Copilot agent workflow that automates UI BDD test creation — from requirements analysis through Gherkin scenario design, implementation planning, and code generation.

## Overview

This workflow orchestrates a three-phase pipeline for creating end-to-end UI tests using BDD (Behavior-Driven Development). Specialized agents handle each phase in isolated contexts, preventing context overflow on large tasks.

```
┌────────────────────┐     ┌────────────────────┐     ┌────────────────────┐
│  TEST CASE         │     │  UI TEST           │     │  UI TEST           │
│  GENERATION        │ ──▶ │  PLANNING          │ ──▶ │  IMPLEMENTATION    │
└────────────────────┘     └────────────────────┘     └────────────────────┘
        │                          │                          │
        ▼                          ▼                          ▼
  test-cases.md          implementation-plan.md        Working Test Files
  - BDD scenarios        - Feature file reference      - Feature file
  - Gherkin features     - Locator definitions         - Page Objects
  - Reusable steps       - Code signatures             - Glue/Steps/Runner
```

### Key Design Principles

- **Framework Agnostic** — Agents produce framework-neutral output. Project-specific paths, commands, and patterns are injected via SKILL.md files.
- **Context Efficient** — Each phase runs in isolated subagent contexts to avoid overflow on large tasks.
- **User Checkpoints** — Explicit review gates between phases ensure quality before proceeding.
- **Step Reuse** — Agents search existing feature files to maximize Gherkin step reuse.

## Agents

| Agent | Purpose |
|-------|--------|
| **UI Test Workflow** | Top-level orchestrator — runs all three phases end-to-end with checkpoints |
| **UI Test Case Generation** | Analyzes requirements → BDD Gherkin scenarios (documentation only, no code) |
| **UI Test Planning** | Orchestrates implementation planning, delegates to locator and code sub-agents |
| **UI Test Planning - Locators** | *(sub-agent)* Plans Phase 2 — element locator identification and strategy |
| **UI Test Planning - Code** | *(sub-agent)* Plans Phases 3–6 — Page Object, Glue, Steps, Runner method signatures |
| **UI Test Implementation** | Executes implementation plan — creates all test files via subagents |

### Agent Dependency Graph

```
ui-test-workflow (orchestrator)
├── ui-test-case-generation        → test-cases.md
├── ui-test-planning (orchestrator)
│   ├── ui-test-planning-locators  → Phase 2: Locators
│   └── ui-test-planning-code      → Phases 3-6: Code design
└── ui-test-implementation         → All test files
```

## Usage

### Full Workflow (Recommended)

1. Open the Chat view (`Ctrl+Alt+I`)
2. Select **UI Test Workflow** from the agents dropdown
3. Type your prompt

The agent will ask for these **mandatory** prerequisites before starting:

| Prerequisite | Description | Example |
|--------------|-------------|---------|
| **JIRA Ticket** | Issue ID for traceability | `PARSIFAL-123`, `ART-12345` |
| **Functionality** | User flow or feature to test | "PayTo mandate creation" |
| **Target Application** | Application under test | Customer Portal, Staff Portal, GCM, TLM, FIS OVA |
| **Suite Tag** | Test classification | `@Regression`, `@Smoke`, `@HealthCheck`, `@Shakedown` |

### Individual Agents

Select any phase agent independently from the agents dropdown:

| Agent | When to Use |
|-------|------------|
| **UI Test Case Generation** | Phase 1: Generate BDD scenarios only |
| **UI Test Planning** | Phase 2: Create implementation plan (requires test-cases.md) |
| **UI Test Implementation** | Phase 3: Generate test code (requires implementation-plan.md) |

### Via Copilot CLI

```bash
# Interactive — select from available agents
copilot
> /agent            # pick "UI Test Workflow" from the list

# Programmatic — specify agent and prompt directly
copilot --agent=ui-test-workflow -p "Generate E2E tests for PARSIFAL-123 PayTo mandate creation"
```

## Workflow Phases

### Phase 1: Test Case Generation

The **ui-test-case-generation** agent acts as a Senior BDD Test Analyst:

1. Gathers requirements (functionality, target app, JIRA ticket)
2. Searches existing feature files for reusable Gherkin steps
3. Designs test scenarios (happy path, negative, edge cases, data-driven)
4. Writes `test-cases.md` with full Gherkin scenarios and a scenario matrix

**Output:** `.docs/agentic-logs/<JIRA-ISSUE>/test-cases.md`

> This agent is **read-only for code** — it creates documentation only. No `.feature` files or Java files are created or modified.

### Phase 2: Test Planning

The **ui-test-planning** agent orchestrates a phased plan:

| Sub-Phase | Handler | Output |
|-----------|---------|--------|
| Phase 1: Feature File | Direct (references test-cases.md) | Scenario list and target path |
| Phase 2: Locators | `ui-test-planning-locators` sub-agent | Element locator table with strategies |
| Phase 3–6: Code | `ui-test-planning-code` sub-agent | Method signatures for Page, Glue, Steps, Runner |

**Output:** `.docs/agentic-logs/<JIRA-ISSUE>/implementation-plan.md`

### Phase 3: Implementation

The **ui-test-implementation** agent creates all test files:

- **Feature file** — Gherkin scenarios with tags
- **Locator file** — Element locators (format depends on SKILL.md)
- **Page Object** — UI interaction methods
- **Glue class** — Cucumber step definitions wired to Steps
- **Steps class** — Business logic and assertions
- **Runner class** — Cucumber/JUnit test runner

Each file is implemented by a dedicated subagent that reads only its relevant plan section.

## Adapting to Your Project

This workflow is **framework agnostic**. To use it in a new repository, you need to provide three SKILL.md files that describe your project-specific conventions:

```
.github/skills/
├── ui-test-case-generation/
│   └── SKILL.md    # Feature file locations, step patterns, app-specific conventions
├── ui-test-planning/
│   └── SKILL.md    # File paths, locator storage, layer pattern, method conventions
└── ui-test-implementation/
    └── SKILL.md    # File paths, code templates, framework commands, layer architecture
```

Each SKILL.md should define:

| Section | Purpose |
|---------|---------|
| **File paths** | Where feature files, locators, page objects, glue, steps, and runners live |
| **Layer architecture** | Feature → Glue → Steps → Page (or your project's variant) |
| **Naming conventions** | Class, method, and file naming patterns |
| **Test execution command** | How to run a specific test (Gradle, Maven, npm, etc.) |
| **Locator format** | How element locators are stored (`.txt`, `.json`, annotations, etc.) |
| **Tag conventions** | Suite tags, issue tags, scenario tags |

See `examples/test-ets-restassured/skills/` for a complete reference implementation using Serenity BDD + Cucumber + Selenium.

## Project Structure

```
workflows/e2e-test-automation/
└── .github/
    └── agents/
        ├── ui-test-workflow.agent.md              # Top-level orchestrator
        ├── ui-test-case-generation.agent.md       # Phase 1: BDD scenario generation
        ├── ui-test-planning.agent.md              # Phase 2: Planning orchestrator
        ├── ui-test-planning-locators.agent.md     # Phase 2 sub-agent: Locators
        ├── ui-test-planning-code.agent.md         # Phase 2 sub-agent: Code design
        └── ui-test-implementation.agent.md        # Phase 3: Code generation
```

### Artifacts (created at runtime)

```
.docs/agentic-logs/<JIRA-ISSUE>/
├── test-cases.md              # BDD scenarios and analysis (Phase 1)
└── implementation-plan.md     # Full implementation plan (Phase 2)

src/test/                      # Test files (Phase 3, paths from SKILL.md)
├── resources/
│   └── features/              # .feature files
└── java/
    └── <package>/
        ├── pages/             # Page Objects
        ├── glue/              # Cucumber Glue (step definitions)
        ├── steps/             # Steps (business logic + assertions)
        └── runners/           # JUnit/Cucumber runners
```

## Composing into a Target Repo

Copy the workflow into your repo's `.github/` folder alongside other `ai-common` workflows:

**PowerShell:**
```powershell
Copy-Item -Recurse -Force "workflows/e2e-test-automation/.github/*" "<target-repo>/.github/"
```

**Bash:**
```bash
cp -r workflows/e2e-test-automation/.github/* <target-repo>/.github/
```

Then add your project-specific SKILL.md files under `.github/skills/`. See [compose.md](../../compose.md) for full composition instructions.

## Reference Implementation

The `examples/test-ets-restassured/` directory contains a complete reference showing how a real project configures this workflow:

| Path | Contents |
|------|----------|
| `instructions/` | Project context, development standards, testing approach, usage patterns, CI/CD workflows |
| `skills/ui-test-case-generation/` | Skill file for BDD scenario generation |
| `skills/ui-test-planning/` | Skill file for implementation planning |
| `skills/ui-test-implementation/` | Skill file for code generation (6 phases) |
| `skills/shared/templates/` | Reusable templates: feature, page object, glue, steps, runner |

## Best Practices

### Locator Strategy

| Priority | Type | Reason |
|----------|------|--------|
| 1 | `id` | Unique, stable, fast |
| 2 | `data-testid` | Designed for testing |
| 3 | `name` | Good for form elements |
| 4 | `css` | Faster than XPath |
| 5 | `xpath` | Last resort |

### Gherkin Guidelines

- Use **business language**, not technical jargon
- Write from the **user's perspective**
- Keep steps **atomic** — one action per step
- **Never include locators** or CSS selectors in Gherkin
- Use **Scenario Outline + Examples** for data-driven tests
- Maximize **step reuse** across scenarios

### Test Architecture

- **No assertions in Page Objects** — assertions belong in the Steps layer
- **One action per Page Object method** — keep methods atomic
- **Glue classes are thin** — they delegate to Steps, no business logic
- **Steps own validation** — all assertions and business logic live here
