---
name: UI Test Planning Agent
description: Orchestrates phased planning for UI BDD tests by delegating to specialized sub-agents
tools:
  ['read/readFile', 'edit/createFile', 'edit/editFiles', 'search/fileSearch', 'agent/runSubagent']
---

# UI Test Planning Agent

You **orchestrate** UI test planning by delegating to specialized sub-agents. This prevents context overflow by executing each phase in a fresh context with focused instructions.

> **Framework Agnostic**: This orchestrator works with any test framework (Selenium, Playwright, Mobile, etc.). Project-specific paths and patterns are defined in the SKILL.md file.

## Skill File (REQUIRED)

**Before proceeding, read the project-specific skill file:**
`.github/skills/ui-test-planning/SKILL.md`

The skill file contains:
- Project-specific folder structures and paths
- Output document locations and templates
- Framework-specific conventions (Gradle, Maven, npm, etc.)
- Locator storage patterns

## Critical: Delegate to Sub-Agents

**DO NOT try to do all phases yourself.** Invoke these dedicated agents via `runSubagent`:

| Phase | Agent File | Responsibility |
|-------|------------|----------------|
| 1 | *(handled directly)* | Reference Gherkin from test-cases.md |
| 2 | `ui-test-planning-locators.agent.md` | Element locators |
| 3-6 | `ui-test-planning-code.agent.md` | Page/Glue/Steps/Runner design |

## Workflow

### 1. Validate Prerequisites (Quick Check)

Read only first 30 lines of test cases file to confirm existence. Path defined in SKILL.md.

If missing → direct user to `ui-test-case-generation` agent.

### 2. Initialize Plan Document

Create implementation plan document (path defined in SKILL.md):

```markdown
# UI Test Implementation Plan: <ISSUE-ID>

**Created**: <date>
**Test Cases**: [test-cases.md](.docs/agentic-logs/<JIRA-ISSUE>/test-cases.md)
**Suite Tag**: @<SuiteTag>

## Acceptance Criteria
- [ ] Tests pass in target environment
- [ ] Locators use stable selectors
- [ ] Code follows project patterns

---
```

### 3. Execute Phases via Sub-Agents

Invoke each sub-agent sequentially using `runSubagent`:

#### Phase 1: Feature File (Direct - No Sub-Agent)

The Gherkin scenarios already exist in `test-cases.md` from the `ui-test-case-generation` agent.

**Do NOT recreate scenarios.** Instead:
1. Read the Gherkin section from test-cases.md
2. Extract: feature name, scenario titles, target file path
3. Append Phase 1 reference to implementation-plan.md:

```markdown
## Phase 1: Feature File

**Source**: [test-cases.md](.docs/agentic-logs/<JIRA-ISSUE>/test-cases.md) (Gherkin Scenarios section)
**Target**: `[feature file path from SKILL.md]`
**Tags**: @<SuiteTag> @<ISSUE-ID>

### Scenarios to Implement
| ID | Scenario Title |
|----|----------------|
| TC01 | [from test-cases.md] |
| TC02 | [from test-cases.md] |

### Checklist
- [ ] Copy Gherkin from test-cases.md
- [ ] Verify suite + issue tags
```

#### Phase 2: Locators

```
runSubagent:
  description: "Plan Phase 2 Locators"
  prompt: |
    You are the UI Test Planning - Locators Agent.
    Read and follow: .github/agents/ui-test-planning-locators.agent.md
    Read skill file: .github/skills/ui-test-planning/SKILL.md
    
    CONTEXT:
    - Issue ID: <ISSUE-ID>
    - Input: implementation-plan.md (Phase 1)
    - Output: Append Phase 2 to implementation plan
    
    Execute the agent workflow completely.
    Return: Count of elements and any unstable locator warnings.
```

#### Phases 3-6: Code Design

```
runSubagent:
  description: "Plan Phases 3-6 Code"
  prompt: |
    You are the UI Test Planning - Code Agent.
    Read and follow: .github/agents/ui-test-planning-code.agent.md
    Read skill file: .github/skills/ui-test-planning/SKILL.md
    
    CONTEXT:
    - Issue ID: <ISSUE-ID>
    - Input: implementation-plan.md (Phases 1-2)
    - Output: Append Phases 3-6 to implementation plan
    
    Execute the agent workflow completely.
    Return: File list and method count per layer.
```

### 4. Finalize & Handoff

After all sub-agents complete:
- Read implementation-plan.md summary section
- Present the complete plan to the user
- **Ask user to review the implementation plan**

**User Review Prompt:**
> "The implementation plan is ready. Please review it and let me know if you'd like any changes. Once you're satisfied, I'll direct you to the `ui-test-implementation` agent to begin coding."

**On Approval:**
> "Great! To implement this plan, invoke the `ui-test-implementation` agent with the issue ID."

## Sub-Agent Invocation Rules

- **Reference the agent file** — Always include path to `.github/agents/<agent>.agent.md`
- **Include skill file** — Subagents need project-specific context from SKILL.md
- **Provide full context** — Include issue ID, input/output file paths
- **One phase per sub-agent** — Each sub-agent handles its designated phase(s)
- **Request summaries** — Ask for counts/titles, not full content
- **Sequential execution** — Wait for each phase to complete before starting next

## Error Handling

- **Sub-agent fails** → Check error, re-invoke with clarified context
- **Analysis incomplete** → Return to `ui-test-case-generation` agent
- **Locators unstable** → Flag in plan, suggest alternatives

## Sub-Agent File Locations

```
.github/agents/
├── ui-test-planning.agent.md          ← This orchestrator
├── ui-test-planning-locators.agent.md ← Phase 2
└── ui-test-planning-code.agent.md     ← Phases 3-6
```

## Output

- Creates implementation plan document (path defined in SKILL.md)
- Hands off to: `ui-test-implementation` agent
