# Code Review Workflow

A composable Copilot agent workflow that runs the AI-powered `pr-review` pipeline against your current branch and presents findings interactively.

## Overview

This workflow wraps the `tools/pr-review` CLI, providing a conversational interface for automated code review. It supports three review depths and can optionally post results to Bitbucket.

```
┌────────────────────┐     ┌────────────────────┐     ┌────────────────────┐
│  DETERMINE         │     │  RUN PR-REVIEW     │     │  PRESENT           │
│  PARAMETERS        │ ──▶ │  CLI PIPELINE      │ ──▶ │  FINDINGS          │
└────────────────────┘     └────────────────────┘     └────────────────────┘
        │                          │                          │
        ▼                          ▼                          ▼
  Review depth            JSON results from          Executive summary
  Cache / Bitbucket       multi-stage pipeline       + prioritised issues
```

### Key Design Principles

- **Three Review Depths** — Quick, standard, and deep modes to match change complexity.
- **Interactive Presentation** — Findings are prioritised and the agent offers to fix issues.
- **CLI-Backed** — All analysis is performed by the `pr-review` pipeline; the agent is the interface.

## Agents

| Agent | Purpose |
|-------|--------|
| **Code Review** | Runs the pr-review CLI, interprets results, presents findings interactively |

## Skills

| Skill | Purpose |
|-------|---------|
| **pr-review-cli** | Handles CLI invocation, JSON parsing, and structured output |

## Usage

### Via Agent (Chat View)

1. Open the Chat view (`Ctrl+Alt+I`)
2. Select **Code Review** from the agents dropdown
3. Type your prompt

The agent determines review depth from your request:

| User Intent | CLI Flags | When to Use |
|-------------|-----------|-------------|
| Quick / fast / glance | `--simple` | Small changes, typo fixes |
| Standard / default | _(none)_ | Normal feature work, most PRs |
| Deep / thorough | `--complex` | Architecture changes, large PRs |

### Via Copilot CLI

Custom agents are fully supported in Copilot CLI (the `copilot` command):

```bash
# Interactive — select from available agents
copilot
> /agent            # pick "Code Review" from the list

# Natural language — CLI auto-infers the agent
copilot
> Use the code-review agent to review my changes

# Programmatic — specify agent and prompt directly
copilot --agent=code-review -p "Review my changes"
```

The CLI reads agent files from `.github/agents/` in your repo.

### Example Flows

**Quick review:**
```
[Agent: Code Review]
You: Quick review of my changes
Agent: [runs --simple, presents summary]
```
**Post to Bitbucket:**
```
[Agent: Code Review]
You: Review and post to Bitbucket
Agent: [runs review, posts comments to PR]
```

## Prerequisites

- The workspace must be a **git repository** with changes relative to a base branch
- `tools/pr-review` must be installed (`cd tools/pr-review && npm install`)

### Bitbucket Integration (Optional)

To post reviews to Bitbucket PRs:

1. Add `BITBUCKET_PAT="<your-token>"` to `.github/.env`
2. Configure `pr_review_bot.yaml.local` in repo root or `~/.pr_review_bot.yaml.local`:
   ```yaml
   bitbucket:
     enabled: true
     baseUrl: 'https://bitbucket.example.com'
     project: 'PROJECT_KEY'
     repo: 'repository-slug'
   ```

## Project Structure

```
workflows/code-review/
└── .github/
    ├── agents/
    │   └── code-review.agent.md       # Code review agent
    ├── prompts/
    │   └── code-review.prompt.md      # User-invokable prompt
    └── skills/
        └── pr-review-cli/
            └── SKILL.md               # CLI invocation skill
```

## Composing into a Target Repo

```powershell
Copy-Item -Recurse -Force "workflows/code-review/.github/*" "<target-repo>/.github/"
```

```bash
cp -r workflows/code-review/.github/* <target-repo>/.github/
```

See [compose.md](../../compose.md) for full composition instructions.
