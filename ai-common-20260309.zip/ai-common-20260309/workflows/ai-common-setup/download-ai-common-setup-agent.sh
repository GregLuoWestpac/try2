#!/bin/bash

# Download files from ai-common repository
# This script will override existing files in .github directory
# Can be run from any repository
# Compatible with Git 2.21.0+ (including Windows versions)

BRANCH="master"
REPO_URL="ssh://git@bitbucket.srv.westpac.com.au/a014a6/ai-common.git"
SOURCE_PREFIX="workflows/ai-common-setup/.github"
TARGET_PREFIX=".github"
TEMP_DIR=$(mktemp -d)

echo "Creating directory structure..."
mkdir -p .github/agents
mkdir -p .github/skills/check-pat/scripts
mkdir -p .github/skills/setup-code-review/scripts
mkdir -p .github/skills/setup-mockoon-gen/scripts

echo "Cloning ai-common repository..."
cd "$TEMP_DIR"

# Use basic clone without sparse checkout for Git 2.21.0 compatibility
# --depth 1 and --single-branch are supported in Git 2.21.0
git clone --depth 1 --branch "$BRANCH" --single-branch "$REPO_URL" ai-common 2>&1

if [ $? -ne 0 ]; then
    echo "✗ Failed to clone repository"
    rm -rf "$TEMP_DIR"
    exit 1
fi

echo "Copying files from branch: $BRANCH"

cd - > /dev/null

# Copy all files from the source directory structure
SOURCE_BASE="$TEMP_DIR/ai-common/$SOURCE_PREFIX"

# Copy agent file
if [ -f "$SOURCE_BASE/agents/ai-common-setup.agent.md" ]; then
    echo "Copying: $TARGET_PREFIX/agents/ai-common-setup.agent.md"
    cp "$SOURCE_BASE/agents/ai-common-setup.agent.md" "$TARGET_PREFIX/agents/ai-common-setup.agent.md"
    echo "✓ Successfully copied: $TARGET_PREFIX/agents/ai-common-setup.agent.md"
fi

# Copy all files from check-pat skill
echo "Copying all files from check-pat skill..."
if [ -d "$SOURCE_BASE/skills/check-pat" ]; then
    cp -r "$SOURCE_BASE/skills/check-pat"/* "$TARGET_PREFIX/skills/check-pat/"
    echo "✓ Successfully copied all check-pat skill files"
else
    echo "✗ check-pat skill directory not found"
fi

# Copy all files from setup-code-review skill
echo "Copying all files from setup-code-review skill..."
if [ -d "$SOURCE_BASE/skills/setup-code-review" ]; then
    cp -r "$SOURCE_BASE/skills/setup-code-review"/* "$TARGET_PREFIX/skills/setup-code-review/"
    echo "✓ Successfully copied all setup-code-review skill files"
else
    echo "✗ setup-code-review skill directory not found"
fi

# Copy all files from setup-mockoon-gen skill
echo "Copying all files from setup-mockoon-gen skill..."
if [ -d "$SOURCE_BASE/skills/setup-mockoon-gen" ]; then
    cp -r "$SOURCE_BASE/skills/setup-mockoon-gen"/* "$TARGET_PREFIX/skills/setup-mockoon-gen/"
    echo "✓ Successfully copied all setup-mockoon-gen skill files"
else
    echo "✗ setup-mockoon-gen skill directory not found"
fi

echo "Cleaning up..."
rm -rf "$TEMP_DIR"

echo "Download complete!"