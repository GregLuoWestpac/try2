---
name: check-pat
description: Generic skill to check whether a named token/PAT environment variable is configured in the user's shell profile. Outputs OS-specific setup instructions if the token is not found.
---

# Check PAT/Token Configuration

This skill checks whether a specified token or Personal Access Token (PAT) environment variable is configured in the user's shell profile and provides OS-specific setup instructions if needed.

## Purpose

This skill provides a generic token configuration checker that:

1. Accepts any token/PAT name as a command-line argument
2. Detects the user's operating system (macOS, Linux, Windows)
3. Sources the appropriate shell profile to check environment variables
4. Verifies if the specified token is configured
5. Outputs brief confirmation if the token is set
6. Outputs full OS-specific setup instructions from TEMPLATE.md if the token is not set

## When to Use

Use this skill when you need to:

- Verify that a required token (e.g., BITBUCKET_PAT, JIRA_PAT, GITHUB_TOKEN) is configured
- Provide setup instructions for tokens that are missing
- Check token configuration across different operating systems
- Integrate token verification into setup workflows or agents

## Usage

```bash
node .github/skills/check-pat/scripts/check-pat.js <TOKEN_NAME>
```

**Examples:**

```bash
# Check Bitbucket PAT
node .github/skills/check-pat/scripts/check-pat.js BITBUCKET_PAT

# Check Jira PAT
node .github/skills/check-pat/scripts/check-pat.js JIRA_PAT

# Check GitHub token
node .github/skills/check-pat/scripts/check-pat.js GITHUB_TOKEN
```

## How It Works

### Input Format

The aggregation script accepts a JSON input with the following structure:

```json
{
  "results": [
    {
      "skillName": "setup-code-review",
      "skillPath": ".github/skills/setup-code-review",
      "setupOutput": {
        "success": true,
        "message": "Setup and sync completed successfully",
        "os": "darwin",
        "repoName": "galaxy-payment-microfrontend",
        "filesUpdated": {
          "toolsPrReview": true,
          "codeReviewAgent": true,
          "codeReviewPrompt": true,
          "prReviewCliSkill": true,
          "configFile": true
        },
        "dependenciesInstalled": true,
        "errors": []
      }
    }
    // Additional skills can be included in the array
  ]
}
```

### Multi-Skill Support

When multiple skills are included in the results array, the aggregator:

1. **Generates a table of contents** - Creates clickable links to each skill section (only for 2+ skills)
2. **Adds visual separation** - Uses double separators (`---\n---\n`) between skill sections
3. **Includes anchor points** - Adds HTML div anchors for navigation
4. **Consolidates errors** - Combines all errors from all skills into a single error summary section

Example with multiple skills:

```json
{
  "results": [
    {
      "skillName": "setup-code-review",
      "skillPath": ".github/skills/setup-code-review",
      "setupOutput": {
        /* ... */
      }
    },
    {
      "skillName": "setup-another-tool",
      "skillPath": ".github/skills/setup-another-tool",
      "setupOutput": {
        /* ... */
      }
    }
  ]
}
```

Output structure for multiple skills:

```
# 🚀 AI Common Setup Complete!

Setup completed for 2 skills.

## 📑 Setup Summary

The following tools were set up:

- [setup-code-review](#setup-code-review)
- [setup-another-tool](#setup-another-tool)

---

# Code Review Setup & Sync Complete! 🎉
[... full setup-code-review template ...]

---
---

<div id="setup-another-tool"></div>

# Another Tool Setup Complete! 🔧
[... full setup-another-tool template ...]

---

## ⚠️ Errors Encountered (if any)

- **setup-code-review**: Error message here
- **setup-another-tool**: Another error here
```

### Template Substitution Rules

The script substitutes placeholders in TEMPLATE.md files using these patterns:

#### Basic Substitution

- `{repo_name}` → Value from `setupOutput.repoName`
- `{config_status}` → "✅ Created" if successful, "❌ Failed" otherwise
- `{deps_status}` → "✅ Installed" if successful, "❌ Failed" otherwise

#### Boolean Status Fields

For any boolean field in `setupOutput.filesUpdated`:

- `{sync_<field_name>}` → "✅ Synced" if true, "❌ Failed" otherwise

Examples:

- `{sync_tools_pr_review}` → "✅ Synced" if `setupOutput.filesUpdated.toolsPrReview === true`
- `{sync_code_review_agent}` → "✅ Synced" if `setupOutput.filesUpdated.codeReviewAgent === true`

#### OS-Specific Substitution

- `{os_name}` → "macOS" for "darwin", "Linux" for "linux", "Windows" for "win32"
- `{os_instructions}` → OS-specific content block

For `{os_instructions}`, the script looks for OS-specific sections in the template marked with:

```markdown
<!-- OS:darwin -->

macOS-specific instructions here

<!-- /OS:darwin -->

<!-- OS:linux -->

Linux-specific instructions here

<!-- /OS:linux -->

<!-- OS:win32 -->

Windows-specific instructions here

<!-- /OS:win32 -->
```

Only the matching OS section is included in the final output.

### Output Format

The script outputs a formatted markdown document combining all skill templates with their placeholders substituted.

## Workflow

### Step 1: Collect Setup Results

After running setup scripts, collect their JSON outputs into a results array:

```javascript
const results = [
  {
    skillName: 'setup-code-review',
    skillPath: '.github/skills/setup-code-review',
    setupOutput: {
      /* JSON from setup script */
    },
  },
  // ... more results if multiple skills were run
];
```

### Step 2: Run the Aggregation Script

Execute the aggregation script with the collected results:

```bash
node .github/skills/setup-summary/scripts/aggregate.js
```

Pass the results via stdin as JSON:

```bash
echo '{"results":[...]}' | node .github/skills/setup-summary/scripts/aggregate.js
```

Or save to a file and redirect:

```bash
node .github/skills/setup-summary/scripts/aggregate.js < results.json
```

### Step 3: Check BITBUCKET_PAT Configuration

After displaying the aggregated setup results, run the PAT check script:

```bash
node .github/skills/setup-summary/scripts/check-pat.js
```

The script will:

1. Detect the operating system (macOS, Linux, Windows)
2. Source the appropriate shell profile using the cross-platform pattern from `.husky/pre-push`:
   - zsh: `~/.zshrc`
   - bash: `~/.bashrc`
   - macOS fallback: `~/.zshrc`
   - Generic Unix: `~/.profile`
   - Windows: PowerShell environment
3. Check if `BITBUCKET_PAT` environment variable is set
4. If the PAT is set: output a brief confirmation message
5. If the PAT is NOT set: read `TEMPLATE.md` (in this skill's folder), substitute placeholders, and output full configuration instructions

**Output format:**

- **When PAT is set**: Brief confirmation markdown (e.g., "✅ BITBUCKET_PAT is already configured")
- **When PAT is NOT set**: Full formatted markdown from `TEMPLATE.md` with OS-specific instructions

### Step 4: Present the Output

echo '{"results":[...]}' | node .github/skills/setup-summary/scripts/aggregate.js

````

Or save to a file and redirect:

```bash
node .github/skills/setup-summary/scripts/aggregate.js < results.json
````

### Step 4: Present the Output

Display both outputs to the user:

1. First, the aggregated setup results from Step 2 (formatted templates from all setup skills)
2. Then, the PAT check result from Step 3 (either confirmation or configuration instructions)

The script outputs formatted markdown to stdout. Display this to the user as the final summary of all setup operations.

## PAT Check Script (check-pat.js)

### Purpose

The `scripts/check-pat.js` script sources the user's shell profile and checks if the BITBUCKET_PAT environment variable is configured. It only displays configuration instructions if the PAT is not set, avoiding unnecessary noise when the user has already configured it.

### Usage

```bash
node .github/skills/setup-summary/scripts/check-pat.js
```

### How It Works

1. **Detect OS**: Uses `os.platform()` to determine the operating system (darwin, linux, win32)
2. **Source shell profile**: Spawns a shell that sources the appropriate profile:
   - Checks `$ZSH_VERSION` → source `~/.zshrc`
   - Checks `$BASH_VERSION` → source `~/.bashrc`
   - macOS fallback → source `~/.zshrc`
   - Generic Unix → source `~/.profile`
   - Windows → check PowerShell environment
3. **Check PAT**: After sourcing, checks if `$BITBUCKET_PAT` (or `$env:BITBUCKET_PAT` on Windows) has a value
4. **Output results**:
   - If PAT is set: outputs brief confirmation markdown
   - If PAT is NOT set: reads `TEMPLATE.md`, substitutes `{os_name}` and `{os_instructions}`, outputs full PAT configuration instructions

### Output Examples

**When PAT is configured:**

```markdown
---

## ✅ BITBUCKET_PAT Configuration

Your Bitbucket Personal Access Token is already configured in your shell profile.

The PR review bot is ready to post comments to Bitbucket pull requests.
```

**When PAT is NOT configured:**

Full TEMPLATE.md content with:

- OS-specific setup instructions
- How to get a Bitbucket PAT
- Security reminders

### Template File (TEMPLATE.md)

This skill has its own `TEMPLATE.md` file (at `.github/skills/setup-summary/TEMPLATE.md`) that contains:

- `🔐 Configure Bitbucket Personal Access Token` section
- OS-specific instructions marked with `<!-- OS:darwin -->`, `<!-- OS:linux -->`, `<!-- OS:win32 -->` blocks
- `🔑 How to Get Your Bitbucket PAT` section (Bitbucket URL, token creation steps)
- `⚠️ Security Reminders` section

This template is read by `check-pat.js` (NOT by `aggregate.js`) and is used only when the PAT is not configured.

## Error Handling

If any setup script fails:

- The aggregation still processes successful results
- Failed skills show "❌ Failed" for their status fields
- Errors from `setupOutput.errors` array are included in the output
- A summary section lists all errors at the end

## Example Usage

```javascript
// After running setup-code-review
const codeReviewOutput = JSON.parse(/* output from setup.js */);

// Prepare input for aggregator
const aggregatorInput = {
  results: [
    {
      skillName: 'setup-code-review',
      skillPath: '.github/skills/setup-code-review',
      setupOutput: codeReviewOutput,
    },
  ],
};

// Run aggregator
// echo '...' | node .github/skills/setup-summary/scripts/aggregate.js
```

## Template Requirements

For this skill to work correctly, each setup skill's TEMPLATE.md must:

1. Use the standardized placeholder format (`{placeholder_name}`)
2. Mark OS-specific sections with `<!-- OS:osname -->` comments
3. Use camelCase for boolean field placeholders (e.g., `{sync_tools_pr_review}`)

## Integration with ai-common-setup Agent

The ai-common-setup agent should:

1. **Phase 1**: Execute requested setup scripts and capture their JSON outputs
2. **Phase 2**: Build the results array and invoke the aggregation script (`aggregate.js`) with the results
3. **Phase 3**: Run the PAT check script (`check-pat.js`) and display its output
4. Display both the aggregated summary (Phase 2) and the PAT check result (Phase 3) to the user

This ensures a consistent, professional presentation regardless of which or how many setup skills were run, and only shows PAT configuration instructions when necessary.
