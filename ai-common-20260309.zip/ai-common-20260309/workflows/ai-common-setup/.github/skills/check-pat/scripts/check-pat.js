#!/usr/bin/env node

/**
 * Check Token Configuration
 *
 * This script checks if a named token/PAT is set in the user's shell profile.
 *
 * Workflow:
 * 1. Get token name from command line argument
 * 2. Detect OS
 * 3. Source the appropriate shell profile
 * 4. Check if the token environment variable is set
 * 5. If set: output brief confirmation
 *    If not set: read TEMPLATE.md, substitute placeholders, output full token setup instructions
 *
 * Usage:
 *   node check-pat.js <TOKEN_NAME>
 *
 * Examples:
 *   node check-pat.js BITBUCKET_PAT
 *   node check-pat.js JIRA_PAT
 *
 * Output: Markdown to stdout (suitable for display to user)
 * Progress logs: stderr
 */

const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");
const os = require("os");

// OS name mapping
const OS_NAMES = {
  darwin: "macOS",
  linux: "Linux",
  win32: "Windows",
};

/**
 * Extract OS-specific content from template
 */
function extractOsContent(template, osType) {
  const osPattern = new RegExp(
    `<!-- OS:${osType} -->([\\s\\S]*?)<!-- /OS:${osType} -->`,
    "g",
  );

  const match = osPattern.exec(template);
  return match ? match[1].trim() : "";
}

/**
 * Remove all OS-specific comment blocks from template
 */
function removeOsBlocks(template) {
  return template.replace(/<!-- OS:\w+ -->[\s\S]*?<!-- \/OS:\w+ -->/g, "");
}

/**
 * Substitute placeholders in template
 */
function substitutePlaceholders(template, osType, tokenName) {
  let result = template;

  // Token name (apply first, globally)
  result = result.replace(/{token_name}/g, tokenName);

  // OS name
  const osName = OS_NAMES[osType] || osType || "Unknown";
  result = result.replace(/{os_name}/g, osName);

  // OS-specific instructions (extract after token_name substitution)
  const osInstructions = extractOsContent(result, osType);
  result = result.replace(/{os_instructions}/g, osInstructions);

  // Remove remaining OS blocks
  result = removeOsBlocks(result);

  return result;
}

/**
 * Check if a named token is set in the shell environment
 */
function checkToken(tokenName) {
  if (!tokenName) {
    console.error("Error: Token name is required\n");
    console.error("Usage: node check-pat.js <TOKEN_NAME>\n");
    console.error("Example: node check-pat.js BITBUCKET_PAT\n");
    return 1;
  }

  const osType = os.platform();

  console.error(`=== Checking ${tokenName} Configuration ===\n`);
  console.error(`Detected OS: ${OS_NAMES[osType] || osType}\n`);

  try {
    let checkCommand;

    if (osType === "win32") {
      // Windows: Detect if running in Git Bash or PowerShell
      // Git Bash sets BASH_VERSION, PowerShell doesn't
      const isGitBash =
        process.env.BASH_VERSION || process.env.SHELL?.includes("bash");

      if (isGitBash) {
        console.error("Environment: Git Bash detected\n");
        // Git Bash on Windows: check bash profiles
        checkCommand = `
          bash -c '
            [ -f "$HOME/.bash_profile" ] && source "$HOME/.bash_profile" 2>/dev/null
            [ -f "$HOME/.bashrc" ] && source "$HOME/.bashrc" 2>/dev/null
            [ -f "$HOME/.profile" ] && source "$HOME/.profile" 2>/dev/null
            echo "$${tokenName}"
          '
        `;
      } else {
        console.error("Environment: PowerShell detected\n");
        // PowerShell: Check PowerShell environment
        checkCommand = `powershell -Command "if ($env:${tokenName}) { Write-Output $env:${tokenName} } else { Write-Output '' }"`;
      }
    } else {
      // Unix-like: Source shell profile then check token
      // Use the cross-platform shell profile sourcing pattern from .husky/pre-push
      checkCommand = `
        if [ -n "$ZSH_VERSION" ]; then
          [ -f "$HOME/.zshrc" ] && source "$HOME/.zshrc" 2>/dev/null
        elif [ -n "$BASH_VERSION" ]; then
          [ -f "$HOME/.bash_profile" ] && source "$HOME/.bash_profile" 2>/dev/null
          [ -f "$HOME/.bashrc" ] && source "$HOME/.bashrc" 2>/dev/null
        elif [ "$(uname)" = "Darwin" ]; then
          [ -f "$HOME/.zshrc" ] && source "$HOME/.zshrc" 2>/dev/null
        elif [ -f "$HOME/.profile" ]; then
          source "$HOME/.profile" 2>/dev/null
        fi
        echo "$${tokenName}"
      `;
    }

    const result = execSync(checkCommand, {
      encoding: "utf8",
      shell:
        osType === "win32" &&
        !(process.env.BASH_VERSION || process.env.SHELL?.includes("bash"))
          ? "powershell.exe"
          : "/bin/bash",
      stdio: ["pipe", "pipe", "pipe"],
    }).trim();

    if (result && result.length > 0) {
      // Token is set
      console.error(`✓ ${tokenName} is configured\n`);
      console.log("---\n");
      console.log(`## ✅ ${tokenName} Configuration\n`);
      console.log(
        `Your ${tokenName} is already configured in your shell profile.\n`,
      );
      return 0;
    }
  } catch (error) {
    console.error(`⚠ Error checking ${tokenName}: ${error.message}`);
    console.error("Assuming token is not set...\n");
  }

  // Token is not set - output full instructions from TEMPLATE.md
  console.error(`⚠ ${tokenName} is not configured\n`);
  console.error("Reading token configuration template...\n");

  try {
    const templatePath = path.join(__dirname, "../TEMPLATE.md");

    if (!fs.existsSync(templatePath)) {
      console.error(`Error: Template not found at ${templatePath}`);
      console.log("---\n");
      console.log(`## ⚠️ ${tokenName} Not Configured\n`);
      console.log(
        `Please set the ${tokenName} environment variable in your shell profile.\n`,
      );
      return 1;
    }

    const template = fs.readFileSync(templatePath, "utf8");
    const formatted = substitutePlaceholders(template, osType, tokenName);

    console.error("✓ Template processed\n");
    console.log("---\n");
    console.log(formatted);

    return 0;
  } catch (error) {
    console.error(`Error reading template: ${error.message}\n`);
    console.log("---\n");
    console.log(`## ⚠️ ${tokenName} Not Configured\n`);
    console.log(`Error: ${error.message}\n`);
    return 1;
  }
}

// Main entry point
if (require.main === module) {
  const tokenName = process.argv[2];
  const exitCode = checkToken(tokenName);
  process.exit(exitCode);
}

// Export for testing
module.exports = {
  checkToken,
  substitutePlaceholders,
  extractOsContent,
  removeOsBlocks,
};
