## 🔐 Configure Token

To enable token-based authentication, you need to set your token as an environment variable in your shell profile.

### Your Operating System: **{os_name}**

{os_instructions}

<!-- OS:darwin -->

**For macOS:**

Add this line to your shell configuration file (`~/.zshrc`, `~/.bashrc`, or `~/.bash_profile`):

```bash
export {token_name}="your_token_here"
```

Then reload your shell:

```bash
source ~/.zshrc  # or source ~/.bashrc
```

<!-- /OS:darwin -->

<!-- OS:linux -->

**For Linux:**

Add this line to your shell configuration file (`~/.bashrc` or `~/.zshrc`):

```bash
export {token_name}="your_token_here"
```

Then reload your shell:

```bash
source ~/.bashrc  # or source ~/.zshrc
```

<!-- /OS:linux -->

<!-- OS:win32 -->

**For Windows:**

**PowerShell (Recommended):**

Add to your PowerShell profile (`$PROFILE`):

```powershell
$env:{token_name} = "your_token_here"
```

**Command Prompt:**

```cmd
setx {token_name} "your_token_here"
```

Restart your terminal after setting the variable.

<!-- /OS:win32 -->

---

## ⚠️ Security Reminders

- **Never commit** your {token_name} to version control
- The token should **only** be set via environment variable
- If you accidentally commit a token, **revoke it immediately**
- Store the token securely and do not share it with others

---

Need help? Check the documentation or ask for assistance! 🚀
