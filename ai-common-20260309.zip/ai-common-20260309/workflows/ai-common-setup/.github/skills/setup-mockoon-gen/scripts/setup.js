#!/usr/bin/env node

/**
 * Setup & Sync script for Mockoon Generator tools
 *
 * This script automates:
 * 1. Detecting the current repo name from git remote
 * 2. Downloading latest mockoon-gen tools from the central ai-common repository
 *    - tools/mockoon-gen/
 *    - .github/agents/generate-mockoon.agent.md
 *    - .github/agents/fetch-swagger.agent.md
 *    - .github/skills/mockoon-gen-cli/
 * 3. Replacing local copies with the downloaded versions
 * 4. Installing dependencies in tools/mockoon-gen/
 * 5. Updating .gitignore for swagger-output/ and cache files
 *
 * Downloads use git SSH (git clone --depth 1).
 * No BITBUCKET_PAT required — uses existing SSH credentials.
 *
 * Returns JSON output for parsing by the agent.
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const os = require('os');

// Determine project root (4 levels up from this script)
const projectRoot = path.resolve(__dirname, '../../../..');

const AI_COMMON_SSH_URL = 'ssh://git@bitbucket.srv.westpac.com.au/a014a6/ai-common.git';
const AI_COMMON_BRANCH = 'master';

// Mapping: source path in ai-common → destination path in project root
const FILE_MAPPINGS = [
  {
    id: 'toolsMockoonGen',
    src: 'tools/mockoon-gen',
    dest: 'tools/mockoon-gen',
    type: 'directory',
  },
  {
    id: 'generateMockoonAgent',
    src: 'workflows/mockoon-gen/.github/agents/generate-mockoon.agent.md',
    dest: '.github/agents/generate-mockoon.agent.md',
    type: 'file',
  },
  {
    id: 'fetchSwaggerAgent',
    src: 'workflows/mockoon-gen/.github/agents/fetch-swagger.agent.md',
    dest: '.github/agents/fetch-swagger.agent.md',
    type: 'file',
  },
  {
    id: 'mockoonGenCliSkill',
    src: 'workflows/mockoon-gen/.github/skills/mockoon-gen-cli',
    dest: '.github/skills/mockoon-gen-cli',
    type: 'directory',
  },
];

const result = {
  success: false,
  message: '',
  os: os.platform(),
  repoName: '',
  filesUpdated: {
    toolsMockoonGen: false,
    generateMockoonAgent: false,
    fetchSwaggerAgent: false,
    mockoonGenCliSkill: false,
    gitignore: false,
  },
  dependenciesInstalled: false,
  errors: [],
};

// ─── Helpers ──────────────────────────────────────────────────────

function shellExec(cmd, opts = {}) {
  const defaults = {
    cwd: projectRoot,
    stdio: 'pipe',
    shell: os.platform() === 'win32' ? 'powershell.exe' : '/bin/bash',
    encoding: 'utf8',
  };
  return execSync(cmd, { ...defaults, ...opts });
}

function rmrf(dir) {
  if (fs.existsSync(dir)) {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

function copyDir(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

// ─── Step 1: Detect repo name ────────────────────────────────────

function detectRepoName() {
  try {
    const remoteUrl = shellExec('git remote get-url origin').trim();
    const match = remoteUrl.match(/\/([^/]+?)(?:\.git)?$/);
    if (match && match[1]) {
      result.repoName = match[1];
      return match[1];
    }
    throw new Error(`Could not parse repo name from remote URL: ${remoteUrl}`);
  } catch (error) {
    result.errors.push(`Repo name detection failed: ${error.message}`);
    return null;
  }
}

// ─── Step 2: Download from ai-common ─────────────────────────────

function downloadFromAiCommon() {
  const tempDir = path.join(os.tmpdir(), `ai-common-mockoon-sync-${Date.now()}`);

  try {
    console.error('  Cloning ai-common (shallow clone, depth 1) into temp dir...');

    const sparsePaths = FILE_MAPPINGS.map(m => m.src);

    const cloneCmd = [
      'git clone --depth 1',
      `--branch ${AI_COMMON_BRANCH}`,
      `"${AI_COMMON_SSH_URL}"`,
      `"${tempDir}"`,
    ].join(' ');

    shellExec(cloneCmd, { stdio: 'inherit' });

    // Verify at least one expected path exists
    const anyExists = sparsePaths.some(p => fs.existsSync(path.join(tempDir, p)));
    if (!anyExists) {
      throw new Error(
        'Clone completed but none of the expected paths were found. ' +
        'Verify the ai-common repository structure.'
      );
    }

    return tempDir;
  } catch (error) {
    rmrf(tempDir);
    result.errors.push(`Download from ai-common failed: ${error.message}`);
    return null;
  }
}

// ─── Step 3: Replace local files ─────────────────────────────────

function replaceLocalFiles(tempDir) {
  for (const mapping of FILE_MAPPINGS) {
    const srcPath = path.join(tempDir, mapping.src);
    const destPath = path.join(projectRoot, mapping.dest);

    try {
      if (!fs.existsSync(srcPath)) {
        console.error(`  ⚠ Source not found in ai-common: ${mapping.src} — skipping`);
        continue;
      }

      if (mapping.type === 'directory') {
        rmrf(destPath);
        copyDir(srcPath, destPath);
        console.error(`  ✓ Replaced directory: ${mapping.dest}`);
      } else {
        fs.mkdirSync(path.dirname(destPath), { recursive: true });
        fs.copyFileSync(srcPath, destPath);
        console.error(`  ✓ Replaced file: ${mapping.dest}`);
      }

      result.filesUpdated[mapping.id] = true;
    } catch (error) {
      result.errors.push(`Failed to replace ${mapping.dest}: ${error.message}`);
    }
  }
}

// ─── Step 4: Install dependencies ────────────────────────────────

function installDependencies() {
  const mockoonGenDir = path.join(projectRoot, 'tools/mockoon-gen');

  try {
    if (!fs.existsSync(mockoonGenDir)) {
      throw new Error(`Mockoon gen directory not found at: ${mockoonGenDir}`);
    }

    const packageJsonPath = path.join(mockoonGenDir, 'package.json');
    if (!fs.existsSync(packageJsonPath)) {
      throw new Error(`package.json not found at: ${packageJsonPath}`);
    }

    let installCommand;
    if (os.platform() === 'darwin') {
      installCommand = 'source ~/.zshrc 2>/dev/null || true; nvm use 22 2>/dev/null || true; cd tools/mockoon-gen && npm install';
    } else if (os.platform() === 'win32') {
      installCommand = 'cd tools\\mockoon-gen && npm install';
    } else {
      installCommand = 'source ~/.bashrc 2>/dev/null || true; cd tools/mockoon-gen && npm install';
    }

    shellExec(installCommand, { cwd: projectRoot, stdio: 'inherit' });
    result.dependenciesInstalled = true;
    return true;
  } catch (error) {
    result.errors.push(`Dependency installation failed: ${error.message}`);
    return false;
  }
}

// ─── Step 5: Update .gitignore ───────────────────────────────────

function updateGitignore() {
  const gitignorePath = path.join(projectRoot, '.gitignore');

  const linesToManage = [
    '# Mockoon generator cache and fetched swagger files',
    'tools/mockoon-gen/.cache/',
    'swagger-output/',
  ];

  const sectionToAppend = `# Mockoon generator cache and fetched swagger files
tools/mockoon-gen/.cache/
swagger-output/
`;

  try {
    let content = '';

    if (fs.existsSync(gitignorePath)) {
      content = fs.readFileSync(gitignorePath, 'utf8');
    }

    let lines = content.split('\n');

    // Remove existing managed entries
    const originalLineCount = lines.length;
    lines = lines.filter(line => {
      const trimmed = line.trim();
      return !linesToManage.some(entry => trimmed === entry.trim());
    });

    const linesRemoved = originalLineCount - lines.length;
    content = lines.join('\n').trimEnd();

    if (content.length > 0) {
      content += '\n\n';
    }

    content += sectionToAppend;

    fs.writeFileSync(gitignorePath, content, 'utf8');

    if (linesRemoved > 0) {
      console.error(`  ✓ Removed ${linesRemoved} existing entries and added fresh section to .gitignore`);
    } else {
      console.error('  ✓ Added mockoon-gen section to .gitignore');
    }

    result.filesUpdated.gitignore = true;
    return true;
  } catch (error) {
    result.errors.push(`.gitignore update failed: ${error.message}`);
    return false;
  }
}

// ─── Main ────────────────────────────────────────────────────────

function main() {
  console.error('=== Mockoon Generator Setup & Sync ===\n');

  // Step 1
  console.error('Step 1: Detecting repository name...');
  const repoName = detectRepoName();
  if (!repoName) {
    result.success = false;
    result.message = result.errors.join('; ');
    console.log(JSON.stringify(result, null, 2));
    process.exit(1);
  }
  console.error(`  ✓ Repository: ${repoName}\n`);

  // Step 2
  console.error('Step 2: Downloading latest tools from ai-common...');
  const tempDir = downloadFromAiCommon();
  if (!tempDir) {
    result.success = false;
    result.message = result.errors.join('; ');
    console.log(JSON.stringify(result, null, 2));
    process.exit(1);
  }
  console.error('  ✓ Download complete\n');

  // Step 3
  console.error('Step 3: Replacing local files...');
  replaceLocalFiles(tempDir);
  console.error('');

  // Step 4
  console.error('Step 4: Installing dependencies in tools/mockoon-gen/...');
  const depsSuccess = installDependencies();
  if (!depsSuccess) {
    console.error('  ⚠ Dependency installation failed (non-fatal)\n');
  } else {
    console.error('  ✓ Dependencies installed\n');
  }

  // Step 5
  console.error('Step 5: Updating .gitignore...');
  updateGitignore();
  console.error('');

  // Step 6: Clean up
  console.error('Step 6: Cleaning up...');
  rmrf(tempDir);
  console.error('  ✓ Temp files removed\n');

  // Determine success
  const criticalUpdates = ['toolsMockoonGen'];
  const allCriticalDone = criticalUpdates.every(k => result.filesUpdated[k]);

  if (allCriticalDone) {
    result.success = true;
    result.message = 'Mockoon generator setup and sync completed successfully';
    console.error('=== Setup and sync completed successfully! ===\n');
  } else {
    result.success = false;
    result.message = `Some updates failed: ${result.errors.join('; ')}`;
    console.error('=== Setup completed with errors ===\n');
  }

  // JSON output to stdout
  console.log(JSON.stringify(result, null, 2));
  process.exit(result.success ? 0 : 1);
}

main();