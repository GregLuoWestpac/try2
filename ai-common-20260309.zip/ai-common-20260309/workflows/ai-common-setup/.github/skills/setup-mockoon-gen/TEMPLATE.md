# Mockoon Generator Setup & Sync Complete! 🎉

The Mockoon mock data generator tools have been synced from the central **ai-common** repository.

## 📦 Repository Detected

- **Repo name**: `{repo_name}`

---

## ✅ Files Synced from ai-common

| Component              | Destination                                | Status                        |
| ---------------------- | ------------------------------------------ | ----------------------------- |
| Mockoon Gen CLI tools  | `tools/mockoon-gen/`                       | {sync_tools_mockoon_gen}      |
| Generate Mockoon Agent | `.github/agents/generate-mockoon.agent.md` | {sync_generate_mockoon_agent} |
| Fetch Swagger Agent    | `.github/agents/fetch-swagger.agent.md`    | {sync_fetch_swagger_agent}    |
| Mockoon Gen CLI Skill  | `.github/skills/mockoon-gen-cli/`          | {sync_mockoon_gen_cli_skill}  |

---

## ✅ Local Configuration

### Dependencies Installed

- **Directory**: `tools/mockoon-gen/`
- **Status**: {deps_status}

### .gitignore Updated

- `swagger-output/` — Fetched swagger specs (ephemeral, re-fetchable)
- `tools/mockoon-gen/.cache/` — Generator cache

---

## 🚀 Quick Start

### Fetch a CAP API swagger spec:

```bash
node tools/mockoon-gen/cli.js fetch <cap-api-name>
```

### Generate mockoon data:

```bash
node tools/mockoon-gen/cli.js generate swagger-output/<component>/openapi.yaml
```

### Or do both in one step:

```bash
node tools/mockoon-gen/cli.js fetch-and-generate <cap-api-name> -o api/env/dev-w1c2/mockoon-data.json
```

### Via Copilot Chat:

1. Attach `generate-mockoon.agent.md` as context
2. Type: "Generate mockoon data for cap-prodsvcadm-..."

---

## Additional Resources

- **CLI Documentation**: `tools/mockoon-gen/cli.js --help`
- **Skill Documentation**: `.github/skills/mockoon-gen-cli/SKILL.md`
- **Generate Mockoon Agent**: `.github/agents/generate-mockoon.agent.md`
- **Fetch Swagger Agent**: `.github/agents/fetch-swagger.agent.md`

---

## ⚠️ Notes

- The `swagger-output/` directory is git-ignored — fetched specs are ephemeral
- The `mockoon-data.json` output file **should** be committed — it's the actual mock data
- The synced tools, agents, and skills **should** be committed — they are shared with the team
- No PAT required — swagger fetcher uses HTTPS to the public schema registry

---

## 🔄 Re-running This Setup

Re-run at any time to pull the latest mockoon generator from ai-common. Simply invoke the **ai-common-setup** agent again with "setup mockoon".

---

Need help? Check the documentation or ask for assistance! 🚀
