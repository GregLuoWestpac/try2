---
name: setup-mockoon-gen
description: Sets up and syncs the Mockoon Generator tools from the central ai-common repository. Use when the user asks to initialize, set up, or update the mockoon generator tooling.
---

# Setup & Sync Mockoon Generator Tools

This skill automates the full setup and synchronisation of the Mockoon mock data generator from the central **ai-common** Bitbucket repository.

## When to Use

Use this skill when the user:

- Asks to set up the mockoon generator
- Wants to initialize mock data generation tools
- Needs to update or sync mockoon-gen from upstream
- Says "setup mockoon", "update mockoon gen", "sync mockoon", or similar

## What Gets Synced

The script downloads from `ssh://git@bitbucket.srv.westpac.com.au/a014a6/ai-common.git` (branch `master`):

| Source in ai-common                                              | Destination in project                     |
| ---------------------------------------------------------------- | ------------------------------------------ |
| `tools/mockoon-gen/`                                             | `tools/mockoon-gen/`                       |
| `workflows/mockoon-gen/.github/agents/generate-mockoon.agent.md` | `.github/agents/generate-mockoon.agent.md` |
| `workflows/mockoon-gen/.github/agents/fetch-swagger.agent.md`    | `.github/agents/fetch-swagger.agent.md`    |
| `workflows/mockoon-gen/.github/skills/mockoon-gen-cli/`          | `.github/skills/mockoon-gen-cli/`          |

Additionally, the script:

- Installs npm dependencies in `tools/mockoon-gen/`
- Updates `.gitignore` to exclude `swagger-output/` and cache files

## Prerequisites

- **Git SSH access** to `bitbucket.srv.westpac.com.au`
- **Node.js v22**

## Workflow

### Step 1: Run the Setup Script

```bash
node .github/skills/setup-mockoon-gen/scripts/setup.js
```

### Step 2: Parse Script Output

JSON output to stdout:

```json
{
  "success": true,
  "message": "Mockoon generator setup and sync completed successfully",
  "os": "darwin",
  "repoName": "galaxy-accountworkflows-microfrontend",
  "filesUpdated": {
    "toolsMockoonGen": true,
    "generateMockoonAgent": true,
    "fetchSwaggerAgent": true,
    "mockoonGenCliSkill": true,
    "gitignore": true
  },
  "dependenciesInstalled": true,
  "errors": []
}
```

### Step 3: Display Results

Use the TEMPLATE.md with placeholder substitution.

## Error Handling

- **SSH auth error** — Ensure SSH key is registered with Bitbucket
- **Node.js version** — Node.js v22 required
- **Missing paths** — Skipped items reported in `errors` array
- **npm install fails** — Check that `tools/mockoon-gen/package.json` exists
