---
name: setup-code-review
description: Sets up and syncs the code review agent, tools, prompts, and skills from the central ai-common repository. Use this skill when the user asks to initialize, set up, update, or sync the code review tooling.
---

# Setup & Sync Code Review Tools

This skill automates the full setup and synchronisation of code review tooling from the central **ai-common** Bitbucket repository. Every invocation downloads the latest versions, replaces local copies, generates the local configuration file, and installs dependencies.

## When to Use

Use this skill when the user:

- Asks to set up the code review agent
- Wants to initialise the PR review bot
- Needs to update or sync code review tools from upstream
- Says "setup code review", "update code review", "sync code review tools", or similar

## What Gets Synced

The script downloads from `ssh://git@bitbucket.srv.westpac.com.au/a014a6/ai-common.git` (branch `master`):

| Source in ai-common                                           | Destination in project                  |
| ------------------------------------------------------------- | --------------------------------------- |
| `tools/pr-review/`                                            | `tools/pr-review/`                      |
| `workflows/code-review/.github/agents/code-review.agent.md`   | `.github/agents/code-review.agent.md`   |
| `workflows/code-review/.github/prompts/code-review.prompt.md` | `.github/prompts/code-review.prompt.md` |
| `workflows/code-review/.github/skills/pr-review-cli/`         | `.github/skills/pr-review-cli/`         |

Additionally, the script:

- Creates/updates `pr_review_bot.yaml.local` with the auto-detected repository name
- Installs npm dependencies in `tools/pr-review/`

## Prerequisites

- **Git SSH access** to `bitbucket.srv.westpac.com.au` — the script uses SSH (no BITBUCKET_PAT required for download)
- **Node.js v22**

## Workflow

### Step 1: Run the Setup Script

Execute the [setup script](./scripts/setup.js) to perform the full setup and sync:

**Command:**

```bash
node .github/skills/setup-code-review/scripts/setup.js
```

The script will:

1. **Detect the repo name** — parses `git remote get-url origin` to extract the repository slug (e.g. `galaxy-payment-microfrontend`)
2. **Download from ai-common** — uses `git clone --depth 1 --filter=blob:none --sparse` with sparse-checkout to fetch only the required files/folders
3. **Replace local files** — removes existing copies and replaces them with the downloaded versions
4. **Create/update config** — writes `pr_review_bot.yaml.local` with the detected repo name
5. **Install dependencies** — runs `npm install` inside `tools/pr-review/`
6. **Update .gitignore** — adds entries for PR review cache and local config
7. **Setup pre-push hook** — configures `.husky/pre-push` to run automated code review before each push (requires `.husky` directory)
8. **Clean up** — removes the temporary clone directory

### Step 2: Parse Script Output

The setup script outputs JSON to stdout in the format:

```json
{
  "success": true,
  "message": "Setup and sync completed successfully",
  "os": "darwin",
  "repoName": "galaxy-payment-microfrontend",
  "filesUpdated": {
    "toolsPrReview": true,
    "codeReviewAgent": true,
    "codeReviewPrompt": true,
    "prReviewCliSkill": true,
    "configFile": true
  },
  "dependenciesInstalled": true,
  "errors": []
}
```

### Step 3: Display Results

The setup script's JSON output should be passed to the ai-common-setup agent, which will aggregate all setup results and display them to the user using the setup-summary skill.

This skill does not handle individual result display — that responsibility belongs to the ai-common-setup agent and the setup-summary aggregation process.

## Important Notes

- The setup script requires **SSH access** to Bitbucket — ensure your SSH key is registered
- Node.js v22 is required
- The `pr_review_bot.yaml.local` file is git-ignored to prevent accidental commits
- The synced files (`tools/pr-review/`, agents, prompts, skills) **should** be committed — they are shared with the team
- Each run of this skill fetches the **latest** versions from the `master` branch of ai-common
- Configuration of environment variables (e.g., BITBUCKET_PAT) is handled by the setup-summary skill, not by this skill

## Pre-Push Hook Setup

The pre-push hook is automatically configured during the main setup process (Step 7). It configures `.husky/pre-push` to run automated code review before each push.

**Automatic Setup:**
The main setup script (`setup.js`) automatically calls the pre-push setup script as part of the workflow.

**Manual Setup (for troubleshooting):**
```bash
node .github/skills/setup-code-review/scripts/setup-pre-push.js
```

**What it does:**
- Validates current `.husky/pre-push` configuration
- Updates if needed (missing, incorrect, or outdated)
- Preserves custom content outside the managed AI-COMMON-MANAGED section
- Returns JSON with status (`success`, `action`, `message`)

**Prerequisites:** `.husky` directory must exist (`npx husky install`)

## Error Handling

If the setup script fails:

1. **SSH authentication error** — Ensure your SSH key is registered with Bitbucket (`ssh -T git@bitbucket.srv.westpac.com.au`)
2. **Sparse checkout fails** — The script uses `git clone --depth 1 --filter=blob:none --sparse`; verify git version ≥ 2.25
3. **Node.js version** — Node.js v22 is required; check with `node -v`
4. **Missing paths in ai-common** — If a source path doesn't exist, that item is skipped (non-fatal) and reported in the JSON output
5. **Dependency install fails** — Check that `tools/pr-review/package.json` exists after sync

The script will provide specific error messages in the JSON output's `errors` array to help diagnose issues.

If the pre-push setup script fails:

1. **`.husky` directory not found** — Run `npx husky install` to initialize Husky
2. **Permission errors** — Ensure you have write access to `.husky/pre-push`
3. **Validation/update script errors** — Check that `validate-pre-push.js` and `update-pre-push.js` exist in the scripts directory
