#!/usr/bin/env node

/**
 * Test Suite for Pre-Push Hook Setup
 * 
 * Tests the setup-pre-push.js script with various scenarios to ensure
 * it correctly validates and updates the .husky/pre-push hook.
 * 
 * This script:
 * 1. Backs up the current pre-push file
 * 2. Runs tests with different pre-push configurations
 * 3. Validates the output and resulting file state
 * 4. Cleans up all test artifacts
 * 5. Restores the original pre-push file
 * 
 * Usage:
 *   node .github/skills/setup-code-review/scripts/test-setup-pre-push.js
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Paths
const repoRoot = path.resolve(__dirname, '../../../..');
const huskyDir = path.join(repoRoot, '.husky');
const prePushPath = path.join(huskyDir, 'pre-push');
const backupPath = path.join(huskyDir, '.pre-push.test-backup');
const setupScriptPath = path.join(__dirname, 'setup-pre-push.js');

// Required template for comparison
const REQUIRED_TEMPLATE = `# Source shell profile (cross-platform, sh -e safe)
# Using subshell + || true to prevent sh -e from aborting on non-zero exits
if [ -n "$ZSH_VERSION" ]; then
\t[ -f "$HOME/.zshrc" ] && (. "$HOME/.zshrc" 2>/dev/null) || true
elif [ -n "$BASH_VERSION" ]; then
\t# Bash: check .bash_profile first (common in Git Bash on Windows), then .bashrc
\t[ -f "$HOME/.bash_profile" ] && (. "$HOME/.bash_profile" 2>/dev/null) || true
\t[ -f "$HOME/.bashrc" ] && (. "$HOME/.bashrc" 2>/dev/null) || true
else
\tcase "$(uname -s)" in
\t\tDarwin*) [ -f "$HOME/.zshrc" ] && (. "$HOME/.zshrc" 2>/dev/null) || true ;;
\t\t*)       [ -f "$HOME/.profile" ] && (. "$HOME/.profile" 2>/dev/null) || true ;;
\tesac
fi

echo "🔍 Running automated code review before push..."
node tools/pr-review/cli.js --no-fail
echo "✅ Code review complete. Results posted to Bitbucket PR (if applicable)."`;

const SECTION_START_MARKER = '# AI-COMMON-MANAGED: Code Review (DO NOT EDIT MANUALLY)';
const SECTION_END_MARKER = '# END AI-COMMON-MANAGED';

// Test results
let testResults = {
  total: 0,
  passed: 0,
  failed: 0,
  details: []
};

// ─── Helper Functions ────────────────────────────────────────────────

function backupPrePush() {
  if (fs.existsSync(prePushPath)) {
    fs.copyFileSync(prePushPath, backupPath);
    console.log('✓ Backed up existing pre-push file');
  } else {
    console.log('ℹ No existing pre-push file to backup');
  }
}

function restorePrePush() {
  if (fs.existsSync(backupPath)) {
    fs.copyFileSync(backupPath, prePushPath);
    fs.unlinkSync(backupPath);
    console.log('✓ Restored original pre-push file');
  } else {
    // No backup means there was no original file - remove the test file
    if (fs.existsSync(prePushPath)) {
      fs.unlinkSync(prePushPath);
      console.log('✓ Removed test pre-push file (no original existed)');
    }
  }
}

function runSetupScript() {
  try {
    const output = execSync(`node "${setupScriptPath}"`, {
      cwd: repoRoot,
      encoding: 'utf8',
      stdio: ['pipe', 'pipe', 'pipe']
    });
    return JSON.parse(output);
  } catch (error) {
    // The script may exit with non-zero status on failure
    if (error.stdout) {
      try {
        return JSON.parse(error.stdout);
      } catch (parseError) {
        throw new Error(`Failed to parse setup script output: ${error.stdout}`);
      }
    }
    throw error;
  }
}

function readPrePushFile() {
  if (!fs.existsSync(prePushPath)) {
    return null;
  }
  return fs.readFileSync(prePushPath, 'utf-8');
}

function writePrePushFile(content) {
  fs.writeFileSync(prePushPath, content, 'utf-8');
}

function deletePrePushFile() {
  if (fs.existsSync(prePushPath)) {
    fs.unlinkSync(prePushPath);
  }
}

function extractManagedSection(content) {
  const startIdx = content.indexOf(SECTION_START_MARKER);
  const endIdx = content.indexOf(SECTION_END_MARKER);
  
  if (startIdx === -1 || endIdx === -1) {
    return null;
  }
  
  const sectionStart = startIdx + SECTION_START_MARKER.length;
  return content.substring(sectionStart, endIdx).trim();
}

function normalizeWhitespace(str) {
  return str.replace(/\t/g, '    ').trim();
}

function contentMatches(content) {
  const managedSection = extractManagedSection(content);
  if (!managedSection) return false;
  
  const normalizedManaged = normalizeWhitespace(managedSection);
  const normalizedTemplate = normalizeWhitespace(REQUIRED_TEMPLATE);
  
  const templateLines = normalizedTemplate.split('\n').filter(l => l.trim());
  const managedLines = normalizedManaged.split('\n').filter(l => l.trim());
  
  return (
    templateLines.length === managedLines.length &&
    templateLines.every((line, idx) => line === managedLines[idx])
  );
}

// ─── Test Functions ──────────────────────────────────────────────────

function runTest(testName, setupFn, expectedResult, validationFn) {
  testResults.total++;
  console.log(`\n🧪 Test ${testResults.total}: ${testName}`);
  
  try {
    // Setup the test scenario
    setupFn();
    
    // Run the setup script
    const result = runSetupScript();
    
    // Validate the result
    const resultMatches = (
      result.success === expectedResult.success &&
      result.action === expectedResult.action
    );
    
    if (!resultMatches) {
      testResults.failed++;
      testResults.details.push({
        test: testName,
        status: 'FAILED',
        reason: 'Result mismatch',
        expected: expectedResult,
        actual: { success: result.success, action: result.action, message: result.message }
      });
      console.log(`❌ FAILED: Result mismatch`);
      console.log(`   Expected: success=${expectedResult.success}, action="${expectedResult.action}"`);
      console.log(`   Got: success=${result.success}, action="${result.action}"`);
      return false;
    }
    
    // Run additional validation if provided
    if (validationFn) {
      const validationResult = validationFn();
      if (!validationResult.valid) {
        testResults.failed++;
        testResults.details.push({
          test: testName,
          status: 'FAILED',
          reason: validationResult.reason
        });
        console.log(`❌ FAILED: ${validationResult.reason}`);
        return false;
      }
    }
    
    testResults.passed++;
    testResults.details.push({
      test: testName,
      status: 'PASSED'
    });
    console.log(`✅ PASSED`);
    return true;
    
  } catch (error) {
    testResults.failed++;
    testResults.details.push({
      test: testName,
      status: 'FAILED',
      reason: `Exception: ${error.message}`
    });
    console.log(`❌ FAILED: ${error.message}`);
    return false;
  }
}

// ─── Test Scenarios ──────────────────────────────────────────────────

function test1_missingFile() {
  runTest(
    'Missing file - should create with managed section',
    () => {
      deletePrePushFile();
    },
    { success: true, action: 'created' },
    () => {
      const content = readPrePushFile();
      if (!content) {
        return { valid: false, reason: 'File was not created' };
      }
      if (!content.includes(SECTION_START_MARKER)) {
        return { valid: false, reason: 'Missing section markers' };
      }
      if (!contentMatches(content)) {
        return { valid: false, reason: 'Content does not match template' };
      }
      return { valid: true };
    }
  );
}

function test2_missingLines() {
  runTest(
    'Missing lines - should update with complete template',
    () => {
      // Create file with missing bash_profile lines
      const incompleteContent = `# Source shell profile (cross-platform, sh -e safe)
# Using subshell + || true to prevent sh -e from aborting on non-zero exits
if [ -n "$ZSH_VERSION" ]; then
\t[ -f "$HOME/.zshrc" ] && (. "$HOME/.zshrc" 2>/dev/null) || true
elif [ -n "$BASH_VERSION" ]; then
\t[ -f "$HOME/.bashrc" ] && (. "$HOME/.bashrc" 2>/dev/null) || true
else
\tcase "$(uname -s)" in
\t\tDarwin*) [ -f "$HOME/.zshrc" ] && (. "$HOME/.zshrc" 2>/dev/null) || true ;;
\t\t*)       [ -f "$HOME/.profile" ] && (. "$HOME/.profile" 2>/dev/null) || true ;;
\tesac
fi

echo "🔍 Running automated code review before push..."
node tools/pr-review/cli.js --no-fail
echo "✅ Code review complete. Results posted to Bitbucket PR (if applicable)."`;
      writePrePushFile(incompleteContent);
    },
    { success: true, action: 'replaced' },
    () => {
      const content = readPrePushFile();
      if (!contentMatches(content)) {
        return { valid: false, reason: 'Content does not include all required lines' };
      }
      return { valid: true };
    }
  );
}

function test3_noMarkersCorrectContent() {
  runTest(
    'No markers, correct content - should add markers',
    () => {
      writePrePushFile(REQUIRED_TEMPLATE);
    },
    { success: true, action: 'added_markers' },
    () => {
      const content = readPrePushFile();
      if (!content.includes(SECTION_START_MARKER)) {
        return { valid: false, reason: 'Markers were not added' };
      }
      if (!contentMatches(content)) {
        return { valid: false, reason: 'Content was modified incorrectly' };
      }
      return { valid: true };
    }
  );
}

function test4_withMarkersCorrectContent() {
  runTest(
    'With markers, correct content - should validate (no changes)',
    () => {
      const content = `${SECTION_START_MARKER}\n${REQUIRED_TEMPLATE}\n${SECTION_END_MARKER}\n`;
      writePrePushFile(content);
    },
    { success: true, action: 'validated' },
    () => {
      const content = readPrePushFile();
      if (!contentMatches(content)) {
        return { valid: false, reason: 'Content should not have changed' };
      }
      return { valid: true };
    }
  );
}

function test5_withMarkersIncorrectContent() {
  runTest(
    'With markers, incorrect content - should replace',
    () => {
      const incorrectContent = `${SECTION_START_MARKER}
# Old content here
echo "Old script"
${SECTION_END_MARKER}
`;
      writePrePushFile(incorrectContent);
    },
    { success: true, action: 'updated' },
    () => {
      const content = readPrePushFile();
      if (!contentMatches(content)) {
        return { valid: false, reason: 'Content was not updated correctly' };
      }
      return { valid: true };
    }
  );
}

function test6_customContentBefore() {
  runTest(
    'Custom content before managed section - should preserve',
    () => {
      const content = `# Custom pre-push setup
echo "Custom script before"

${SECTION_START_MARKER}
# Old content
${SECTION_END_MARKER}
`;
      writePrePushFile(content);
    },
    { success: true, action: 'updated' },
    () => {
      const content = readPrePushFile();
      if (!content.includes('Custom pre-push setup')) {
        return { valid: false, reason: 'Custom content before was not preserved' };
      }
      if (!contentMatches(content)) {
        return { valid: false, reason: 'Managed section was not updated correctly' };
      }
      return { valid: true };
    }
  );
}

function test7_customContentAfter() {
  runTest(
    'Custom content after managed section - should preserve',
    () => {
      const content = `${SECTION_START_MARKER}
# Old content
${SECTION_END_MARKER}

# Custom cleanup
echo "Custom script after"
`;
      writePrePushFile(content);
    },
    { success: true, action: 'updated' },
    () => {
      const content = readPrePushFile();
      if (!content.includes('Custom cleanup')) {
        return { valid: false, reason: 'Custom content after was not preserved' };
      }
      if (!contentMatches(content)) {
        return { valid: false, reason: 'Managed section was not updated correctly' };
      }
      return { valid: true };
    }
  );
}

function test8_corruptedContent() {
  runTest(
    'Corrupted content - should replace with managed section',
    () => {
      const corruptedContent = `# Corrupted pre-push hook
echo "This is broken"
exit 1
`;
      writePrePushFile(corruptedContent);
    },
    { success: true, action: 'appended' },
    () => {
      const content = readPrePushFile();
      if (!content.includes(SECTION_START_MARKER)) {
        return { valid: false, reason: 'Managed section was not added' };
      }
      if (!contentMatches(content)) {
        return { valid: false, reason: 'Managed section content is incorrect' };
      }
      return { valid: true };
    }
  );
}

// ─── Main Test Runner ────────────────────────────────────────────────

function main() {
  console.log('=== Pre-Push Hook Setup Test Suite ===\n');
  
  // Check prerequisites
  if (!fs.existsSync(huskyDir)) {
    console.error('❌ Error: .husky directory not found');
    console.error('   Please run: npx husky install');
    process.exit(1);
  }
  
  // Backup existing pre-push file
  backupPrePush();
  
  try {
    // Run all tests
    test1_missingFile();
    test2_missingLines();
    test3_noMarkersCorrectContent();
    test4_withMarkersCorrectContent();
    test5_withMarkersIncorrectContent();
    test6_customContentBefore();
    test7_customContentAfter();
    test8_corruptedContent();
    
    // Print summary
    console.log('\n=== Test Results ===');
    console.log(`Total: ${testResults.total}`);
    console.log(`Passed: ${testResults.passed} ✅`);
    console.log(`Failed: ${testResults.failed} ❌`);
    
    if (testResults.failed > 0) {
      console.log('\n=== Failed Tests ===');
      testResults.details
        .filter(d => d.status === 'FAILED')
        .forEach(d => {
          console.log(`\n❌ ${d.test}`);
          console.log(`   Reason: ${d.reason}`);
          if (d.expected) {
            console.log(`   Expected: ${JSON.stringify(d.expected)}`);
            console.log(`   Actual: ${JSON.stringify(d.actual)}`);
          }
        });
    }
    
  } finally {
    // Always restore the original file
    restorePrePush();
  }
  
  console.log('\n✓ Cleanup complete - original pre-push file restored');
  
  // Exit with appropriate code
  process.exit(testResults.failed === 0 ? 0 : 1);
}

main();
