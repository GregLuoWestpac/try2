#!/usr/bin/env node

/**
 * Pre-Push Hook Setup
 * 
 * Validates and configures the .husky/pre-push hook for automated code review.
 * This script is called by the setup-code-review skill as part of the code review setup workflow.
 * 
 * What it does:
 * 1. Validates the current pre-push hook configuration
 * 2. Updates the hook if needed (missing, incorrect, or outdated)
 * 3. Preserves any custom content outside the managed section
 * 4. Returns structured JSON output
 * 
 * Usage:
 *   node .github/skills/setup-code-review/scripts/setup-pre-push.js
 * 
 * Output: JSON object with setup status and details
 */

const fs = require('fs');
const path = require('path');

// Required content template for the managed section
const REQUIRED_TEMPLATE = `# Source shell profile (cross-platform, sh -e safe)
# Using subshell + || true to prevent sh -e from aborting on non-zero exits
if [ -n "$ZSH_VERSION" ]; then
\t[ -f "$HOME/.zshrc" ] && (. "$HOME/.zshrc" 2>/dev/null) || true
elif [ -n "$BASH_VERSION" ]; then
\t# Bash: check .bash_profile first (common in Git Bash on Windows), then .bashrc
\t[ -f "$HOME/.bash_profile" ] && (. "$HOME/.bash_profile" 2>/dev/null) || true
\t[ -f "$HOME/.bashrc" ] && (. "$HOME/.bashrc" 2>/dev/null) || true
else
\tcase "$(uname -s)" in
\t\tDarwin*) [ -f "$HOME/.zshrc" ] && (. "$HOME/.zshrc" 2>/dev/null) || true ;;
\t\t*)       [ -f "$HOME/.profile" ] && (. "$HOME/.profile" 2>/dev/null) || true ;;
\tesac
fi

echo "🔍 Running automated code review before push..."
node tools/pr-review/cli.js --no-fail
echo "✅ Code review complete. Results posted to Bitbucket PR (if applicable)."`;

const SECTION_START_MARKER = '# AI-COMMON-MANAGED: Code Review (DO NOT EDIT MANUALLY)';
const SECTION_END_MARKER = '# END AI-COMMON-MANAGED';

function findRepoRoot() {
  let dir = process.cwd();
  while (dir !== path.parse(dir).root) {
    if (fs.existsSync(path.join(dir, '.git'))) {
      return dir;
    }
    dir = path.dirname(dir);
  }
  return process.cwd();
}

function validatePrePushHook(repoRoot, prePushPath) {
  const result = {
    valid: false,
    fileExists: false,
    hasMarkers: false,
    contentMatches: false
  };

  // Check if .husky directory exists
  const huskyDir = path.join(repoRoot, '.husky');
  if (!fs.existsSync(huskyDir)) {
    return { ...result, error: '.husky directory not found' };
  }

  // Check if pre-push file exists
  if (!fs.existsSync(prePushPath)) {
    return { ...result, error: 'pre-push file does not exist' };
  }
  result.fileExists = true;

  // Read current file content
  const currentContent = fs.readFileSync(prePushPath, 'utf-8');
  
  // Check for section markers
  const hasStartMarker = currentContent.includes(SECTION_START_MARKER);
  const hasEndMarker = currentContent.includes(SECTION_END_MARKER);
  result.hasMarkers = hasStartMarker && hasEndMarker;

  // Extract managed section if markers exist
  let managedSection = '';
  if (result.hasMarkers) {
    const startIdx = currentContent.indexOf(SECTION_START_MARKER);
    const endIdx = currentContent.indexOf(SECTION_END_MARKER);
    
    if (startIdx !== -1 && endIdx !== -1 && endIdx > startIdx) {
      const sectionStart = startIdx + SECTION_START_MARKER.length;
      managedSection = currentContent.substring(sectionStart, endIdx).trim();
    }
  } else {
    // No markers - check if entire file matches template
    managedSection = currentContent.trim();
  }

  // Normalize whitespace for comparison
  const normalizeWhitespace = (str) => str.replace(/\t/g, '    ').trim();
  const normalizedManaged = normalizeWhitespace(managedSection);
  const normalizedTemplate = normalizeWhitespace(REQUIRED_TEMPLATE);

  // Compare content with better diagnostics - line by line
  const templateLines = normalizedTemplate.split('\n').filter(l => l.trim());
  const managedLines = normalizedManaged.split('\n').filter(l => l.trim());

  // Check if all template lines are present and in correct order
  result.contentMatches = (
    templateLines.length === managedLines.length &&
    templateLines.every((line, idx) => line === managedLines[idx])
  );
  
  // Only consider it valid if content matches AND markers are present
  result.valid = result.contentMatches && result.hasMarkers;

  // Add diagnostics for debugging (optional)
  if (!result.contentMatches && process.env.DEBUG) {
    result.missingLines = templateLines.filter(line => 
      !managedLines.includes(line)
    );
    result.extraLines = managedLines.filter(line =>
      !templateLines.includes(line)
    );
  }

  return result;
}

function updatePrePushHook(repoRoot, prePushPath) {
  const result = {
    success: false,
    action: '',
    message: ''
  };

  const huskyDir = path.join(repoRoot, '.husky');
  
  // Check if .husky directory exists
  if (!fs.existsSync(huskyDir)) {
    result.message = '.husky directory not found. Please run: npx husky install';
    return result;
  }

  let newContent = '';
  let fileExists = fs.existsSync(prePushPath);

  if (fileExists) {
    // File exists - read and update
    const currentContent = fs.readFileSync(prePushPath, 'utf-8');
    
    // Check for markers
    const hasStartMarker = currentContent.includes(SECTION_START_MARKER);
    const hasEndMarker = currentContent.includes(SECTION_END_MARKER);

    if (hasStartMarker && hasEndMarker) {
      // Markers exist - replace content between them
      const startIdx = currentContent.indexOf(SECTION_START_MARKER);
      const endIdx = currentContent.indexOf(SECTION_END_MARKER) + SECTION_END_MARKER.length;
      
      const beforeSection = currentContent.substring(0, startIdx);
      const afterSection = currentContent.substring(endIdx);
      
      const managedSection = `${SECTION_START_MARKER}\n${REQUIRED_TEMPLATE}\n${SECTION_END_MARKER}`;
      
      newContent = beforeSection + managedSection + afterSection;
      result.action = 'updated';
      result.message = 'Updated managed section while preserving other content';
    } else {
      // No markers - look for existing code review section and replace it
      const normalizeWhitespace = (str) => str.replace(/\t/g, '    ').trim();
      const normalizedCurrent = normalizeWhitespace(currentContent);
      const normalizedTemplate = normalizeWhitespace(REQUIRED_TEMPLATE);
      
      if (normalizedCurrent === normalizedTemplate) {
        // Content matches but no markers - add markers around it
        newContent = `${SECTION_START_MARKER}\n${REQUIRED_TEMPLATE}\n${SECTION_END_MARKER}\n`;
        result.action = 'added_markers';
        result.message = 'Added section markers to existing correct content';
      } else {
        // Content doesn't match - look for code review section by key indicators
        const keyLine = 'echo "🔍 Running automated code review before push..."';
        const lines = currentContent.split('\n');
        let sectionStart = -1;
        let sectionEnd = -1;
        
        for (let i = 0; i < lines.length; i++) {
          if (lines[i].includes(keyLine)) {
            // Found the code review section - find boundaries
            for (let j = i - 1; j >= 0; j--) {
              const line = lines[j].trim();
              if (line.includes('# Source shell profile') || line.startsWith('if [ -n "$ZSH_VERSION"')) {
                sectionStart = line.includes('# Source shell profile') ? j : (j > 0 && lines[j-1].trim().includes('# Source shell profile') ? j - 1 : j);
                break;
              }
              if (j === 0 || (line === '' && j < i - 15)) {
                sectionStart = j === 0 ? 0 : j + 1;
                break;
              }
            }
            
            for (let j = i + 1; j < lines.length; j++) {
              if (lines[j].includes('Code review complete')) {
                sectionEnd = j + 1;
                break;
              }
            }
            break;
          }
        }
        
        if (sectionStart >= 0 && sectionEnd > sectionStart) {
          // Found section - replace it
          const beforeSection = lines.slice(0, sectionStart).join('\n');
          const afterSection = lines.slice(sectionEnd).join('\n');
          
          const prefix = beforeSection.trim() ? beforeSection.trim() + '\n\n' : '';
          const suffix = afterSection.trim() ? '\n\n' + afterSection : '';
          
          newContent = `${prefix}${SECTION_START_MARKER}\n${REQUIRED_TEMPLATE}\n${SECTION_END_MARKER}${suffix}`;
          result.action = 'replaced';
          result.message = 'Replaced existing code review section with updated template and markers';
        } else {
          // Could not identify section - append
          const separator = currentContent.trim().endsWith('\n') ? '\n' : '\n\n';
          newContent = currentContent.trim() + separator + 
                       `${SECTION_START_MARKER}\n${REQUIRED_TEMPLATE}\n${SECTION_END_MARKER}\n`;
          result.action = 'appended';
          result.message = 'Appended managed section (could not identify existing section to replace)';
        }
      }
    }
  } else {
    // File doesn't exist - create with managed section only
    newContent = `${SECTION_START_MARKER}\n${REQUIRED_TEMPLATE}\n${SECTION_END_MARKER}\n`;
    result.action = 'created';
    result.message = 'Created new pre-push hook with code review section';
  }

  // Write the file
  try {
    fs.writeFileSync(prePushPath, newContent, 'utf-8');
    
    // Make executable on Unix-like systems
    if (process.platform !== 'win32') {
      try {
        fs.chmodSync(prePushPath, 0o755);
        result.message += ' (made executable)';
      } catch (chmodErr) {
        result.message += ' (warning: could not make executable - run: chmod +x .husky/pre-push)';
      }
    }
    
    result.success = true;
  } catch (writeErr) {
    result.message = `Failed to write file: ${writeErr.message}`;
    return result;
  }

  return result;
}

function setupPrePushHook() {
  const result = {
    success: false,
    action: '',
    message: '',
    filePath: ''
  };

  try {
    const repoRoot = findRepoRoot();
    const prePushPath = path.join(repoRoot, '.husky', 'pre-push');
    result.filePath = prePushPath;

    // Step 1: Validate current configuration
    const validation = validatePrePushHook(repoRoot, prePushPath);
    
    if (validation.error === '.husky directory not found') {
      result.message = '.husky directory not found. Please initialize Husky first by running: npx husky install';
      return result;
    }

    // Step 2: If validation passed, we're done
    if (validation.valid) {
      result.success = true;
      result.action = 'validated';
      result.message = 'Pre-push hook is already configured correctly. No changes needed.';
      return result;
    }

    // Step 3: Validation failed - update the hook
    const update = updatePrePushHook(repoRoot, prePushPath);
    
    result.success = update.success;
    result.action = update.action;
    result.message = update.message;
    
    return result;
  } catch (error) {
    result.message = `Setup failed: ${error.message}`;
    return result;
  }
}

// Main execution
try {
  const result = setupPrePushHook();
  console.log(JSON.stringify(result, null, 2));
  process.exit(result.success ? 0 : 1);
} catch (error) {
  console.error(JSON.stringify({
    success: false,
    error: error.message,
    stack: error.stack
  }, null, 2));
  process.exit(1);
}
