#!/usr/bin/env node

/**
 * Setup & Sync script for Code Review tools
 *
 * This script automates:
 * 1. Detecting the current repo name from git remote
 * 2. Downloading latest code review tools from the central ai-common repository
 *    - tools/pr-review/
 *    - .github/agents/code-review.agent.md
 *    - .github/prompts/code-review.prompt.md
 *    - .github/skills/pr-review-cli/
 * 3. Replacing local copies with the downloaded versions
 * 4. Creating/updating pr_review_bot.yaml.local with the detected repo name
 * 5. Installing dependencies in tools/pr-review/
 *
 * Downloads use git SSH (git clone --depth 1 + sparse-checkout).
 * No BITBUCKET_PAT required — uses existing SSH credentials.
 *
 * Returns JSON output for parsing by the agent.
 */

const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");
const os = require("os");

// Determine project root (4 levels up from this script)
const projectRoot = path.resolve(__dirname, "../../../..");

const AI_COMMON_SSH_URL =
  "ssh://git@bitbucket.srv.westpac.com.au/a014a6/ai-common.git";
const AI_COMMON_BRANCH = "master";

// Mapping: source path in ai-common → destination path in project root
const FILE_MAPPINGS = [
  {
    id: "toolsPrReview",
    src: "tools/pr-review",
    dest: "tools/pr-review",
    type: "directory",
  },
  {
    id: "codeReviewAgent",
    src: "workflows/code-review/.github/agents/code-review.agent.md",
    dest: ".github/agents/code-review.agent.md",
    type: "file",
  },
  {
    id: "codeReviewPrompt",
    src: "workflows/code-review/.github/prompts/code-review.prompt.md",
    dest: ".github/prompts/code-review.prompt.md",
    type: "file",
  },
  {
    id: "prReviewCliSkill",
    src: "workflows/code-review/.github/skills/pr-review-cli",
    dest: ".github/skills/pr-review-cli",
    type: "directory",
  },
];

const CONFIG_TEMPLATE = `# PR Review Bot Configuration
# This file configures the automated PR review pipeline and Bitbucket integration.
# Place this file at the repo root or in your home directory (~/.pr_review_bot.yaml.local).

# ── Bitbucket Integration ─────────────────────────────────────────
bitbucket:
  enabled: true
  baseUrl: 'https://bitbucket.srv.westpac.com.au'
  project: 'WDP'
  repo: '{repo_name}'
  autoPrompt: false  # Set to false to auto-post in pre-push hook without prompting

# ── Review Pipeline Settings ──────────────────────────────────────
# These can be overridden via CLI flags (--simple, --complex, --no-cache)

# cache:
#   enabled: true
#   ttl: 3600  # Cache lifetime in seconds

# model:
#   tier: 'default'  # Options: simple, default, complex
`;

const result = {
  success: false,
  message: "",
  os: os.platform(),
  repoName: "",
  filesUpdated: {
    toolsPrReview: false,
    codeReviewAgent: false,
    codeReviewPrompt: false,
    prReviewCliSkill: false,
    configFile: false,
    gitignore: false,
    prePushHook: false,
  },
  dependenciesInstalled: false,
  errors: [],
};

// ─── Helpers ──────────────────────────────────────────────────────

function shellExec(cmd, opts = {}) {
  const defaults = {
    cwd: projectRoot,
    stdio: "pipe",
    shell: os.platform() === "win32" ? "powershell.exe" : "/bin/bash",
    encoding: "utf8",
  };
  return execSync(cmd, { ...defaults, ...opts });
}

/**
 * Recursively delete a directory (rm -rf equivalent)
 */
function rmrf(dir) {
  if (fs.existsSync(dir)) {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

/**
 * Recursively copy a directory
 */
function copyDir(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

// ─── Step 1: Detect repo name ────────────────────────────────────

function detectRepoName() {
  try {
    const remoteUrl = shellExec("git remote get-url origin").trim();
    // Parse repo slug from URLs like:
    //   ssh://git@bitbucket.srv.westpac.com.au/wdp/galaxy-payment-microfrontend.git
    //   https://bitbucket.srv.westpac.com.au/scm/ui-www/galaxy-payment-microfrontend.git
    const match = remoteUrl.match(/\/([^/]+?)(?:\.git)?$/);
    if (match && match[1]) {
      result.repoName = match[1];
      return match[1];
    }
    throw new Error(`Could not parse repo name from remote URL: ${remoteUrl}`);
  } catch (error) {
    result.errors.push(`Repo name detection failed: ${error.message}`);
    return null;
  }
}

// ─── Step 2: Download from ai-common ─────────────────────────────

function downloadFromAiCommon() {
  const tempDir = path.join(os.tmpdir(), `ai-common-sync-${Date.now()}`);

  try {
    console.error(
      "  Cloning ai-common (shallow clone, depth 1) into temp dir...",
    );

    // Collect all top-level paths for verification
    const sparsePaths = FILE_MAPPINGS.map((m) => m.src);

    // Use simple shallow clone for compatibility with older Git versions
    // (Git < 2.25 doesn't support --sparse flag)
    const cloneCmd = [
      "git clone --depth 1",
      `--branch ${AI_COMMON_BRANCH}`,
      `"${AI_COMMON_SSH_URL}"`,
      `"${tempDir}"`,
    ].join(" ");

    shellExec(cloneCmd, { stdio: "inherit" });

    // Verify at least one expected path exists
    const anyExists = sparsePaths.some((p) =>
      fs.existsSync(path.join(tempDir, p)),
    );
    if (!anyExists) {
      throw new Error(
        "Clone completed but none of the expected paths were found. " +
          "Verify the ai-common repository structure.",
      );
    }

    return tempDir;
  } catch (error) {
    // Clean up on failure
    rmrf(tempDir);
    result.errors.push(`Download from ai-common failed: ${error.message}`);
    return null;
  }
}

// ─── Step 3: Replace local files ─────────────────────────────────

function replaceLocalFiles(tempDir) {
  for (const mapping of FILE_MAPPINGS) {
    const srcPath = path.join(tempDir, mapping.src);
    const destPath = path.join(projectRoot, mapping.dest);

    try {
      if (!fs.existsSync(srcPath)) {
        console.error(
          `  ⚠ Source not found in ai-common: ${mapping.src} — skipping`,
        );
        continue;
      }

      if (mapping.type === "directory") {
        // Remove existing directory entirely, then copy fresh
        rmrf(destPath);
        copyDir(srcPath, destPath);
        console.error(`  ✓ Replaced directory: ${mapping.dest}`);
      } else {
        // Ensure parent directory exists
        fs.mkdirSync(path.dirname(destPath), { recursive: true });
        fs.copyFileSync(srcPath, destPath);
        console.error(`  ✓ Replaced file: ${mapping.dest}`);
      }

      result.filesUpdated[mapping.id] = true;
    } catch (error) {
      result.errors.push(`Failed to replace ${mapping.dest}: ${error.message}`);
    }
  }
}

// ─── Step 4: Create/update pr_review_bot.yaml.local ──────────────

function createConfigFile(repoName) {
  const targetPath = path.join(projectRoot, "pr_review_bot.yaml.local");

  try {
    const content = CONFIG_TEMPLATE.replace("{repo_name}", repoName);
    fs.writeFileSync(targetPath, content, "utf8");
    result.filesUpdated.configFile = true;
    return true;
  } catch (error) {
    result.errors.push(`Config file creation failed: ${error.message}`);
    return false;
  }
}

// ─── Step 5: Install dependencies ────────────────────────────────

function installDependencies() {
  const prReviewDir = path.join(projectRoot, "tools/pr-review");

  try {
    if (!fs.existsSync(prReviewDir)) {
      throw new Error(`PR review directory not found at: ${prReviewDir}`);
    }

    const packageJsonPath = path.join(prReviewDir, "package.json");
    if (!fs.existsSync(packageJsonPath)) {
      throw new Error(`package.json not found at: ${packageJsonPath}`);
    }

    // Build the install command based on OS
    let installCommand;
    if (os.platform() === "darwin") {
      installCommand =
        "source ~/.zshrc 2>/dev/null || true; nvm use 22 2>/dev/null || true; cd tools/pr-review && npm install";
    } else if (os.platform() === "win32") {
      installCommand = "cd tools\\pr-review && npm install";
    } else {
      installCommand =
        "source ~/.bashrc 2>/dev/null || true; cd tools/pr-review && npm install";
    }

    shellExec(installCommand, { cwd: projectRoot, stdio: "inherit" });
    result.dependenciesInstalled = true;
    return true;
  } catch (error) {
    result.errors.push(`Dependency installation failed: ${error.message}`);
    return false;
  }
}

// ─── Step 6: Update .gitignore ───────────────────────────────────

function updateGitignore() {
  const gitignorePath = path.join(projectRoot, ".gitignore");

  // Lines to remove and then append at the bottom
  const linesToManage = [
    "# Environment files",
    ".github/.env",
    "# PR Review cache and local config",
    "tools/pr-review/.cache/",
    "tools/pr-review/.temp/",
    "pr_review_bot.yaml.local",
  ];

  const sectionToAppend = `# Environment files
.github/.env

# PR Review cache and local config
tools/pr-review/.cache/
tools/pr-review/.temp/
pr_review_bot.yaml.local
`;

  try {
    let content = "";

    // Read existing .gitignore or start with empty string
    if (fs.existsSync(gitignorePath)) {
      content = fs.readFileSync(gitignorePath, "utf8");
    }

    // Split content into lines
    let lines = content.split("\n");

    // Remove any existing lines that match our managed entries
    const originalLineCount = lines.length;
    lines = lines.filter((line) => {
      const trimmed = line.trim();
      return !linesToManage.some((entry) => trimmed === entry.trim());
    });

    const linesRemoved = originalLineCount - lines.length;

    // Rejoin the lines and trim trailing whitespace/newlines
    content = lines.join("\n").trimEnd();

    // Add exactly one blank line before appending the new section (if content exists)
    if (content.length > 0) {
      content += "\n\n";
    }

    // Append the section at the bottom
    content += sectionToAppend;

    fs.writeFileSync(gitignorePath, content, "utf8");

    if (linesRemoved > 0) {
      console.error(
        `  ✓ Removed ${linesRemoved} existing entries and added fresh section to .gitignore`,
      );
    } else {
      console.error("  ✓ Added section to .gitignore");
    }

    result.filesUpdated.gitignore = true;
    return true;
  } catch (error) {
    result.errors.push(`.gitignore update failed: ${error.message}`);
    return false;
  }
}

// ─── Main ────────────────────────────────────────────────────────

function main() {
  console.error("=== Code Review Setup & Sync ===\n");

  // Step 1: Detect repo name
  console.error("Step 1: Detecting repository name...");
  const repoName = detectRepoName();
  if (!repoName) {
    result.success = false;
    result.message = result.errors.join("; ");
    console.log(JSON.stringify(result, null, 2));
    process.exit(1);
  }
  console.error(`  ✓ Repository: ${repoName}\n`);

  // Step 2: Download from ai-common
  console.error("Step 2: Downloading latest tools from ai-common...");
  const tempDir = downloadFromAiCommon();
  if (!tempDir) {
    result.success = false;
    result.message = result.errors.join("; ");
    console.log(JSON.stringify(result, null, 2));
    process.exit(1);
  }
  console.error("  ✓ Download complete\n");

  // Step 3: Replace local files
  console.error("Step 3: Replacing local files...");
  replaceLocalFiles(tempDir);
  console.error("");

  // Step 4: Create/update config
  console.error("Step 4: Creating/updating pr_review_bot.yaml.local...");
  const configSuccess = createConfigFile(repoName);
  if (!configSuccess) {
    console.error("  ⚠ Config file creation failed (non-fatal)\n");
  } else {
    console.error("  ✓ Configuration file ready\n");
  }

  // Step 5: Install dependencies
  console.error("Step 5: Installing dependencies in tools/pr-review/...");
  const depsSuccess = installDependencies();
  if (!depsSuccess) {
    console.error("  ⚠ Dependency installation failed (non-fatal)\n");
  } else {
    console.error("  ✓ Dependencies installed\n");
  }

  // Step 6: Update .gitignore
  console.error("Step 6: Updating .gitignore...");
  const gitignoreSuccess = updateGitignore();
  if (!gitignoreSuccess) {
    console.error("  ⚠ .gitignore update failed (non-fatal)\n");
  } else {
    console.error("");
  }

  // Step 7: Setup pre-push hook
  console.error("Step 7: Setting up pre-push hook...");
  const prePushSetupPath = path.join(__dirname, "setup-pre-push.js");
  try {
    const prePushOutput = shellExec(`node "${prePushSetupPath}"`, {
      stdio: "pipe",
    });
    const prePushResult = JSON.parse(prePushOutput);

    if (prePushResult.success) {
      result.filesUpdated.prePushHook = true;
      console.error(`  ✓ ${prePushResult.message}`);
    } else {
      result.errors.push(`Pre-push setup: ${prePushResult.message}`);
      console.error(`  ⚠ Pre-push setup failed: ${prePushResult.message}`);
    }
  } catch (error) {
    result.errors.push(`Pre-push setup failed: ${error.message}`);
    console.error(`  ⚠ Pre-push setup failed (non-fatal)`);
  }
  console.error("");

  // Step 8: Clean up temp dir
  console.error("Step 8: Cleaning up...");
  rmrf(tempDir);
  console.error("  ✓ Temp files removed\n");

  // Determine overall success
  const criticalUpdates = ["toolsPrReview"];
  const allCriticalDone = criticalUpdates.every((k) => result.filesUpdated[k]);

  if (allCriticalDone) {
    result.success = true;
    result.message = "Setup and sync completed successfully";
    console.error("=== Setup and sync completed successfully! ===\n");
  } else {
    result.success = false;
    result.message = `Some updates failed: ${result.errors.join("; ")}`;
    console.error("=== Setup completed with errors ===\n");
  }

  // Output JSON for agent parsing (to stdout)
  console.log(JSON.stringify(result, null, 2));
  process.exit(result.success ? 0 : 1);
}

main();
