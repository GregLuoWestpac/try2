# Code Review Setup & Sync Complete! 🎉

The code review tools have been synced from the central **ai-common** repository.

## 📦 Repository Detected

- **Repo name**: `{repo_name}`

---

## ✅ Files Synced from ai-common

| Component           | Destination                             | Status                     |
| ------------------- | --------------------------------------- | -------------------------- |
| PR Review CLI tools | `tools/pr-review/`                      | {sync_tools_pr_review}     |
| Code Review Agent   | `.github/agents/code-review.agent.md`   | {sync_code_review_agent}   |
| Code Review Prompt  | `.github/prompts/code-review.prompt.md` | {sync_code_review_prompt}  |
| PR Review CLI Skill | `.github/skills/pr-review-cli/`         | {sync_pr_review_cli_skill} |
| Pre-Push Hook       | `.husky/pre-push`                       | {sync_pre_push_hook}       |

---

## ✅ Local Configuration

### Configuration File

- **File**: `pr_review_bot.yaml.local`
- **Location**: Project root
- **Status**: {config_status}

The configuration file has been created with `repo: '{repo_name}'` pre-filled.

### Dependencies Installed

- **Directory**: `tools/pr-review/`
- **Status**: {deps_status}

---

## Additional Resources

- **PR Review CLI Documentation**: `tools/pr-review/README.md`
- **Configuration Reference**: `pr_review_bot.yaml.local` (local config file)
- **Skill Documentation**: `.github/skills/setup-code-review/SKILL.md`

---

## ⚠️ Security Reminders

- The `pr_review_bot.yaml.local` file is git-ignored by default
- The synced files (tools, agents, prompts, skills) **should** be committed — they are shared with the team
- Never commit sensitive credentials or tokens to version control

---

## 🔄 Re-running This Setup

You can re-run this setup at any time to pull the latest code review tools from ai-common. Simply invoke the **ai-common-setup** agent again — it will download and replace all files with the latest versions from the `master` branch.

---

Need help? Check the documentation or ask for assistance! 🚀
