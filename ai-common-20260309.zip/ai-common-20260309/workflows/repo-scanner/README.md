# Repo Scanner Workflow

A composable Copilot agent workflow that scans a repository and auto-populates `.github/instructions/` files with discovered project context.

## Overview

This workflow orchestrates a suite of specialised sub-agents that each analyse a different aspect of the codebase. Each sub-agent writes its findings into the corresponding instruction file created by repo-init.

```
┌──────────────────────────────────────────────────────────┐
│                   REPO SCANNER (orchestrator)            │
│                                                          │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐   │
│  │ Structure│ │  Build   │ │ Testing  │ │ Patterns │   │
│  │ Scanner  │ │ Scanner  │ │ Scanner  │ │ Scanner  │   │
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘   │
│       │             │            │             │         │
│  ┌────┴─────┐ ┌────┴─────┐ ┌────┴─────┐ ┌────┴─────┐   │
│  │ Domain  │ │Workflows│ │Westpac UI│ │Multiverse│   │
│  │ Scanner │ │ Scanner │ │ Scanner  │ │UI Scanner│   │
│  └─────────┘ └─────────┘ └─────────┘ └─────────┘   │
└──────────────────────────────────────────────────────────┘
                          │
                          ▼
              .github/instructions/ (populated)
```

### Key Design Principles

- **Sub-Agent Delegation** — Each scanner focuses on a single concern, preventing context overflow.
- **Idempotent** — Can be re-run safely; sub-agents overwrite their sections in instruction files.
- **Conditional Scanners** — UI-specific scanners (Westpac UI, Multiverse UI) only run when relevant dependencies are detected.
- **Extensible** — Additional library-specific scanners (e.g. Mesh) can be added following the same pattern as the Westpac UI and Multiverse UI scanners: create a `repo-scanner-<library>.agent.md` sub-agent and a corresponding fetch skill.

## Agents

| Agent | Purpose |
|-------|---------|
| **Repository Scanner** | Top-level orchestrator — delegates to all sub-agents |
| **Structure Scanner** | Analyses repo layout → `repo_overview.instructions.md` |
| **Build & Dependencies** | Analyses build system → `development_standards.instructions.md` |
| **Testing Scanner** | Analyses test setup → `testing_approach.instructions.md` |
| **Patterns Scanner** | Analyses code conventions → `development_standards.instructions.md` |
| **Domain Scanner** | Analyses domain context → `project_context.instructions.md` + `usage_patterns.instructions.md` |
| **Workflows Scanner** | Analyses CI/CD → `workflows.instructions.md` |
| **Westpac UI Scanner** | *(conditional)* Analyses `@westpac/ui` usage → `westpac-ui.instructions.md` |
| **Multiverse UI Scanner** | *(conditional)* Analyses `multiverse-ui-common-library` usage → `multiverse-ui.instructions.md` |

## Skills

| Skill | Purpose |
|-------|---------|
| **westpac-ui-fetch** | Fetches Westpac UI component documentation |
| **multiverse-ui-fetch** | Fetches Multiverse UI component documentation |

## Usage

### Full Scan

1. Open the Chat view (`Ctrl+Alt+I`)
2. Select **Repository Scanner** from the agents dropdown
3. Type your prompt (e.g., "Scan this repository")

The orchestrator runs all applicable sub-agents sequentially. Conditional scanners are skipped if their dependencies aren't detected.

### Individual Sub-Agents

The orchestrator provides handoff buttons for individual scans:

- **Run Structure Scan** — Repo layout and organisation
- **Run Build Scan** — Dependencies and build system
- **Run Testing Scan** — Test framework and patterns
- **Run Patterns Scan** — Code conventions and style
- **Run Domain Scan** — Business context and usage
- **Run Workflows Scan** — CI/CD and release process

### Example Flow

```
[Agent: Repository Scanner]
You: Scan this repository
Agent: [assesses confidence, begins scanning]
  → Structure Scanner: analyses folder layout
  → Build Scanner: reads package.json / pom.xml / build.gradle
  → Testing Scanner: discovers test config and patterns
  → Patterns Scanner: identifies naming conventions
  → Domain Scanner: extracts business terminology
  → Workflows Scanner: reads CI/CD pipeline configs
Agent: Scan complete. All instruction files have been populated.
```

## Prerequisites

- The target repo must have the **repo-init** foundation layer copied first (provides the template instruction files)
- The workspace must be open in VS Code with the target repo

### Via Copilot CLI

```bash
# Interactive — select agent from list
copilot
> /agent            # pick "Repository Scanner"

# Programmatic
copilot --agent=repo-scanner -p "Scan this repository"
```

## Project Structure

```
workflows/repo-scanner/
└── .github/
    ├── agents/
    │   ├── repo-scanner.agent.md              # Orchestrator
    │   ├── repo-scanner-structure.agent.md    # Repo layout
    │   ├── repo-scanner-build.agent.md        # Build & dependencies
    │   ├── repo-scanner-testing.agent.md      # Test framework
    │   ├── repo-scanner-patterns.agent.md     # Code conventions
    │   ├── repo-scanner-domain.agent.md       # Business domain
    │   ├── repo-scanner-workflows.agent.md    # CI/CD pipelines
    │   ├── repo-scanner-westpac-ui.agent.md   # Westpac UI (conditional)
    │   └── repo-scanner-multiverse-ui.agent.md # Multiverse UI (conditional)
    └── skills/
        ├── westpac-ui-fetch/
        │   └── SKILL.md                       # Westpac UI docs fetcher
        └── multiverse-ui-fetch/
            └── SKILL.md                       # Multiverse UI docs fetcher
```

### Artifacts (created at runtime)

```
.github/instructions/
├── repo_overview.instructions.md          # ← Structure Scanner
├── development_standards.instructions.md  # ← Build + Patterns Scanners
├── testing_approach.instructions.md       # ← Testing Scanner
├── project_context.instructions.md        # ← Domain Scanner
├── usage_patterns.instructions.md         # ← Domain Scanner
├── workflows.instructions.md             # ← Workflows Scanner
├── westpac-ui.instructions.md            # ← Westpac UI Scanner (if applicable)
└── multiverse-ui.instructions.md         # ← Multiverse UI Scanner (if applicable)
```

## Composing into a Target Repo

Requires the **repo-init** foundation layer first. See [compose.md](../../compose.md) for copy commands and full composition instructions.
