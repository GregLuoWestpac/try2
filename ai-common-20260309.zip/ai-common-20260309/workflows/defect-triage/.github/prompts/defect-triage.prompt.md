---
description: Start a defect triage and root cause analysis investigation
---

# Defect Triage

Investigate and triage the following defect: **{{defect_identifier}}**

## Instructions

1. Parse the defect identifier provided above. It may be any of:
   - A CorrelationID, TraceID, or RequestID
   - A service name (optionally with a datetime range)
   - A stack trace or error message
   - A JIRA ticket reference
   - Any combination of the above

2. Begin the autonomous triage workflow:
   - **Log Investigation** — Search Splunk for errors, exceptions, traces, and correlated events
   - **Documentation Research** — Search internal docs and codebase for service architecture, runbooks, and known issues
   - **Root Cause Analysis** — Synthesize evidence into a structured analysis

3. Produce the structured JSON output with:
   - Title and description of the defect
   - Impacted components
   - Analysis steps taken
   - Splunk queries used
   - Root cause determination
   - Reproduction steps
   - JIRA-ready ticket content

4. Pause at confidence checkpoints if confidence drops below 8/10 and ask for clarification.
