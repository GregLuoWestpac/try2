---
description: Collecting and formatting triage evidence into structured JSON output
---

# Evidence Collection Skill

Instructions for collecting, organizing, and formatting triage evidence into the structured JSON output schema used by the defect-triage workflow.

## Usage

This skill is invoked by `root-cause-analyzer.agent.md` to produce the final structured triage output.

## Prerequisites

- Evidence from the Log Investigator (Splunk findings)
- Evidence from the Doc Researcher (documentation findings)
- Root cause analysis completed

## Output Schema

The final output must conform to this JSON schema:

```json
{
  "title": "string — Brief defect title (max 120 characters)",
  "description": "string — Detailed description of the defect, its impact, and observed behavior",
  "components_impacted": ["string — List of affected services, databases, queues, or infrastructure components"],
  "analysis_steps": ["string — Ordered list of investigation steps taken, from input parsing to conclusion"],
  "splunk_queries": ["string — Actual SPL queries executed during investigation (not hypothetical)"],
  "root_cause": "string — Detailed root cause explanation with evidence chain",
  "reproduction_steps": ["string — Ordered steps to reproduce the defect"],
  "jira_title": "string — JIRA ticket title in format: [SERVICE] Brief actionable description",
  "jira_description": "string — Full JIRA description with h2 sections in JIRA wiki markup"
}
```

## Instructions

### Step 1: Validate Evidence Completeness

Before assembling the output, verify evidence coverage:

| Field | Evidence Source | Required |
|-------|---------------|----------|
| `title` | Derived from root cause analysis | ✅ Yes |
| `description` | Synthesized from all evidence | ✅ Yes |
| `components_impacted` | Log Investigator (transaction traces, error hosts) | ✅ Yes |
| `analysis_steps` | Both investigators (chronological) | ✅ Yes |
| `splunk_queries` | Log Investigator (recorded queries) | ✅ Yes |
| `root_cause` | Root Cause Analyzer hypothesis | ✅ Yes |
| `reproduction_steps` | Derived from evidence + documentation | ⚠️ Best effort |
| `jira_title` | Derived from root cause | ✅ Yes |
| `jira_description` | Synthesized from all evidence | ✅ Yes |

If any required field cannot be populated with evidence, request re-investigation before proceeding.

### Step 2: Assemble Each Field

#### `title`
- Keep under 120 characters
- Include the primary service/component name
- Describe the observable symptom, not the implementation detail
- **Good:** "Payment service returns HTTP 503 under sustained load"
- **Bad:** "NullPointerException in PaymentProcessor.java line 142"

#### `description`
- Start with what the defect IS (observable behavior)
- Describe the impact on users/systems
- Include when it occurs (conditions, frequency)
- Note the environment if relevant
- 2-4 sentences, factual and evidence-based

#### `components_impacted`
- List every service, database, queue, or infrastructure component affected
- Include both the component where the error originates AND downstream components
- Use consistent naming (service identifiers, not hostnames)
- Order: primary component first, then downstream

#### `analysis_steps`
- Chronological list of investigation actions taken
- Start with input parsing, end with root cause determination
- Each step should be a complete sentence
- Include what was found at each step (not just what was searched)
- Example: "Searched Splunk index app_logs for correlation ID abc-123; found 47 matching events across 3 hosts"

#### `splunk_queries`
- Include ONLY actual SPL queries that were executed
- Do NOT include hypothetical queries or templates
- Each query should be a complete, runnable SPL string
- Include the queries that produced the most relevant evidence
- Order by investigation sequence

#### `root_cause`
- Single detailed paragraph explaining the root cause
- Must connect cause → effect → impact in a clear chain
- Reference specific evidence (error messages, timestamps, services)
- Classify the root cause type (code defect, configuration, infrastructure, dependency, data, deployment)
- Be specific — avoid vague statements like "something went wrong"

#### `reproduction_steps`
- Numbered steps from initial setup to defect manifestation
- Include prerequisites (environment, data state, configuration)
- Each step should be actionable and specific
- Include expected vs. actual behavior at the final step
- If reproduction is uncertain, prefix with "Approximate reproduction:" and note assumptions

#### `jira_title`
- Format: `[SERVICE-NAME] Brief actionable description`
- Max 200 characters
- Describe the problem, not the fix
- Use the primary impacted service name in brackets

#### `jira_description`
- Use JIRA wiki markup (h2. for headings, * for bullets, {code} for code blocks)
- Required sections:
  - `h2. Summary` — One paragraph overview
  - `h2. Environment` — Service, environment, time of occurrence
  - `h2. Root Cause` — Detailed explanation
  - `h2. Impact` — Components affected, user impact, severity
  - `h2. Evidence` — Splunk queries and key log snippets
  - `h2. Reproduction Steps` — Numbered list
  - `h2. Recommended Fix` — Suggested remediation approach
  - `h2. Related` — Known issues, runbooks, documentation references

### Step 3: Quality Validation

Before returning the JSON, validate:

| Check | Criteria |
|-------|----------|
| **Schema compliance** | All 9 fields present with correct types |
| **Evidence backing** | Every claim in `root_cause` traces to evidence in `analysis_steps` |
| **Query accuracy** | All `splunk_queries` were actually executed (not fabricated) |
| **Completeness** | `components_impacted` includes all services from the transaction trace |
| **Actionability** | `reproduction_steps` are specific enough to attempt reproduction |
| **JIRA readiness** | `jira_title` and `jira_description` can be pasted directly into JIRA |
| **Consistency** | `title`, `jira_title`, and `description` tell the same story |
| **No speculation** | All assertions are evidence-based; uncertainties are explicitly noted |

### Step 4: Format the JSON

Output the JSON with proper formatting:
- Use 2-space indentation
- Escape special characters in strings (newlines as `\n`, quotes as `\"`)
- JIRA description uses `\n` for line breaks within the string
- Arrays should contain at least one element (no empty arrays)
- Verify the JSON is valid and parseable

## Error Handling

| Scenario | Action |
|----------|--------|
| Missing Splunk evidence | Request Log Investigator re-investigation; do not fabricate queries |
| Missing documentation evidence | Proceed with Splunk evidence only; note documentation gap |
| Cannot determine root cause | Set `root_cause` to describe the most likely hypothesis with confidence level |
| Cannot determine reproduction | Set `reproduction_steps` to best approximation with "[Approximate]" prefix |
| Conflicting evidence | Note both interpretations in `root_cause`; recommend further investigation |

## Notes

- The JSON output is the primary deliverable of the entire triage workflow
- Every field must be traceable to evidence collected during investigation
- Do not include speculative information without clearly labeling it as such
- The JIRA description should be self-contained — a reader should understand the defect without needing to access Splunk
- Splunk queries should be re-runnable by anyone with Splunk access to verify the findings
