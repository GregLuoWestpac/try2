---
description: Step-by-step Splunk log investigation methodology for defect triage
---

# Splunk Investigation Skill

Step-by-step investigation methodology for searching and analyzing Splunk logs during defect triage using the Splunk MCP tools.

## Usage

This skill is invoked by `log-investigator.agent.md` to perform systematic Splunk log investigation.

## Prerequisites

- The Splunk MCP server must be running and configured as a tool in the agent's toolset
- Splunk authentication credentials must be available (token, username/password, or SSO)
- Network access to the Splunk instance

## Instructions

### Step 1: Establish Connection

Start a Splunk session and authenticate:

**Using Token Auth:**
1. Call `splunk_start_session` to initialize the connection
2. Call `splunk_authenticate` with the configured credentials
3. Call `splunk_session_keepalive` with action `start` to prevent session timeout

**Using SSO Auth:**
1. Call `splunk_start_session` to initialize the connection
2. Call `splunk_sso_login` to authenticate via Microsoft SSO
3. Call `splunk_session_keepalive` with action `start` to prevent session timeout

**Verify** the connection is healthy with `splunk_check_health`.

### Step 2: Discover Relevant Indexes

Identify which indexes contain data relevant to the defect:

1. Call `splunk_list_indexes` to get all available indexes
2. Present the index list to the user and ask which are relevant
3. For each selected index:
   - Call `splunk_get_event_count` with the defect time range to verify data exists
   - Call `splunk_list_sourcetypes` to understand what data types are available
   - Call `splunk_get_latest_time` to verify the index has recent data

**Index Selection Heuristics:**
- Look for indexes matching the service name (e.g., `service-a-logs`, `app-service-a`)
- Check common index naming patterns: `app_logs`, `error_logs`, `infra_logs`, `audit_logs`
- Ask the user if unsure — index names vary across organizations

### Step 3: Execute Targeted Searches

Execute searches in order of specificity (most targeted first):

#### 3a: Correlation ID Search (if ID provided)
```spl
index=<index> "<correlation_id>"
| sort _time
| head 200
| table _time host source sourcetype _raw
```

Use `splunk_search_oneshot` for quick results.

#### 3b: Service Error Search
```spl
index=<index> sourcetype=<type> service="<service_name>"
  (ERROR OR FATAL OR CRITICAL OR Exception)
| sort _time
| head 100
| table _time host source level message
```

Or use `splunk_find_errors` with parameters:
- `index`: selected index
- `application`: service name
- `earliest_time`: defect time range start
- `latest_time`: defect time range end
- `severity`: ERROR (or ALL for broader search)

#### 3c: Exception/Stack Trace Search
Use `splunk_find_exceptions` with parameters:
- `index`: selected index
- `application`: service name (if known)
- `exception_type`: specific exception class (if known from error message)
- `earliest_time`: defect time range start

#### 3d: Transaction Tracing
Use `splunk_trace_transaction` with:
- `transaction_id`: the correlation/trace/request ID
- `index`: `*` (search all indexes) or specific index
- `earliest_time`: defect time range start

This reveals the full transaction flow across multiple services.

#### 3e: Event Correlation
Use `splunk_correlate_events` with:
- `search_terms`: key error terms or service identifiers
- `group_by`: `host` or `service` to find related events
- `time_window`: `5m` (start narrow, broaden if needed)

#### 3f: Latency Analysis
Use `splunk_analyze_latency` with:
- `index`: selected index
- `group_by`: `endpoint` or `host`
- `threshold_ms`: expected latency threshold (e.g., 5000)

### Step 4: Pattern and Frequency Analysis

Determine if the defect is isolated or recurring:

**Frequency Over Time:**
```spl
index=<index> "<error_pattern>"
| timechart span=1h count
```

**Distribution by Host/Service:**
```spl
index=<index> "<error_pattern>"
| stats count by host, sourcetype
| sort -count
```

**Field Value Analysis:**
Use `splunk_get_field_summary` on fields like:
- `status_code` or `http_status`
- `error_code`
- `service_name` or `application`
- `host`

### Step 5: Record All Queries

**CRITICAL:** Record every SPL query executed during the investigation. These queries are included in the final triage output so the defect can be re-investigated.

Format each query with its purpose:
```
1. index=app_logs "abc-123" | sort _time | head 200
   → Found 47 events matching correlation ID

2. index=app_logs service=service-a ERROR earliest=-24h
   → Found 312 error events, 89% ServiceUnavailableException
```

## Error Handling

| Scenario | Detection | Resolution |
|----------|-----------|------------|
| Authentication failure | Auth tool returns 401/403 | Try SSO login; check if token expired; ask user for credentials |
| Index not found | Search returns "index not found" | Call `splunk_list_indexes` to verify name; ask user |
| No results | Search returns 0 events | Broaden time range; try wildcard index `*`; check sourcetype filter |
| Search timeout | Status shows timeout after 5 min | Simplify query; reduce time range; add `| head 1000` |
| Rate limiting | Too many concurrent searches | Cancel pending searches; space out queries; use oneshot mode |
| Permission denied | 403 on specific index | Note the index is restricted; try alternative indexes; inform user |

## Notes

- Prefer `splunk_search_oneshot` for quick targeted queries (< 60 seconds expected)
- Use `splunk_search` (async) for complex queries that may take longer
- Use `splunk_search_export` for large result sets (> 1000 events)
- Always include a `| head` or `| table` to limit results and select relevant fields
- Time ranges: use `-1h`, `-24h`, `-7d` for relative; `2024-01-01T00:00:00` for absolute
- The `_raw` field contains the full log message — useful for stack traces
- Group `stats` queries help identify patterns faster than raw event browsing
