# Defect Triage Workflow

An autonomous bug triage and root cause analysis workflow using Splunk MCP and DocSearch MCP. Receives defect identifiers and produces structured JSON output with root cause analysis, impacted components, and JIRA-ready ticket content.

## Overview

This workflow orchestrates a multi-agent pipeline for investigating and triaging production defects. Specialist agents handle log investigation, documentation research, and root cause analysis in a coordinated flow.

```
┌────────────────────┐     ┌────────────────────┐     ┌────────────────────┐
│  LOG               │     │  DOC               │     │  ROOT CAUSE        │
│  INVESTIGATOR      │     │  RESEARCHER         │     │  ANALYZER          │
└────────┬───────────┘     └────────┬───────────┘     └────────┬───────────┘
         │                          │                          │
         ▼                          ▼                          ▼
   Splunk Findings           Doc Findings              Structured JSON
   - Errors/exceptions       - Architecture             - Root cause
   - Transaction traces      - Runbooks                 - JIRA ticket
   - Correlated events       - Known issues             - Reproduction steps
         │                          │                          │
         └──────────────┬───────────┘──────────────────────────┘
                        ▼
              ┌──────────────────┐
              │  TRIAGE          │
              │  COORDINATOR     │ ◀── User input (defect identifiers)
              └──────────────────┘
                        │
                        ▼
                 Triage Report (JSON)
```

### Key Design Principles

- **Autonomous with Checkpoints** — Runs end-to-end automatically but pauses if confidence drops below 8/10
- **Evidence-Based** — Every assertion in the output traces to Splunk queries or documentation sources
- **Dynamic Index Discovery** — Agents discover Splunk indexes at runtime and ask the user which to search
- **Dual Documentation Sources** — Searches both internal team docs (via DocSearch) and codebase for context
- **JIRA-Ready Output** — Produces structured JSON that includes ready-to-create JIRA ticket content

## Agents

| Agent | Entry Point | Purpose |
|-------|-------------|---------|
| **Triage Coordinator** | `@triage-coordinator` | Orchestrator — receives defect input, delegates to specialists, assembles final output |
| **Log Investigator** | *(specialist)* | Splunk log investigation — searches, traces, and correlates events |
| **Doc Researcher** | *(specialist)* | Documentation search — finds architecture, runbooks, and known issues |
| **Root Cause Analyzer** | *(specialist)* | Evidence synthesis — determines root cause, produces structured JSON |

### Agent Handoff Flow

```
triage-coordinator (receives defect input)
├── log-investigator        → Splunk findings
├── doc-researcher          → Documentation findings
└── root-cause-analyzer     → Structured JSON output
         └── (may re-delegate to log-investigator or doc-researcher if evidence is insufficient)
```

## Usage

### Quick Start (Recommended)

Use the prompt template to start a triage:

```
@defect-triage defect_identifier="CorrelationID: abc-123-def-456"
```

Or invoke the coordinator directly:

```
@triage-coordinator
```

### Accepted Defect Identifiers

| Input Type | Example |
|------------|---------|
| CorrelationID | `abc-123-def-456` |
| TraceID | `trace-789-xyz` |
| Service name | `payment-service` |
| Service + datetime | `payment-service 2024-01-15 14:30` |
| Stack trace | `NullPointerException at com.example.PaymentProcessor.process(...)` |
| Error message | `HTTP 503 Service Unavailable from /api/payments` |
| JIRA reference | `PROJ-1234` |
| Combined | `payment-service CorrelationID: abc-123 between 14:00-15:00` |

## Output Schema

The workflow produces a structured JSON object:

```json
{
  "title": "Brief defect title",
  "description": "Detailed description of the defect and its impact",
  "components_impacted": ["service-a", "service-b"],
  "analysis_steps": ["Step 1: ...", "Step 2: ..."],
  "splunk_queries": ["index=app_logs ... | head 100"],
  "root_cause": "Detailed root cause explanation",
  "reproduction_steps": ["Step 1: ...", "Step 2: ..."],
  "jira_title": "[SERVICE] Actionable defect title",
  "jira_description": "Full JIRA description with h2 sections"
}
```

| Field | Type | Description |
|-------|------|-------------|
| `title` | string | Brief defect title (max 120 chars) |
| `description` | string | Detailed description with impact and behavior |
| `components_impacted` | string[] | All affected services, databases, queues |
| `analysis_steps` | string[] | Chronological investigation steps taken |
| `splunk_queries` | string[] | Actual SPL queries executed (re-runnable) |
| `root_cause` | string | Evidence-backed root cause explanation |
| `reproduction_steps` | string[] | Steps to reproduce the defect |
| `jira_title` | string | JIRA-ready ticket title |
| `jira_description` | string | JIRA-ready description in wiki markup |

## Prerequisites

### MCP Servers

The Splunk and DocSearch MCP servers must be running before starting a triage:

**Splunk MCP** (required):
```powershell
# Windows
tools\mcp-splunk.bat
```
```bash
# macOS/Linux
tools/mcp-splunk.sh
```

**DocSearch MCP** (optional but recommended):
```powershell
# Windows
tools\mcp-docsearch.bat
```
```bash
# macOS/Linux
tools/mcp-docsearch.sh
```

### Authentication

- **Splunk:** Token auth, username/password, or Microsoft SSO (the agent handles auth as part of the workflow)
- **DocSearch:** No auth required, but documents must be ingested beforehand

### DocSearch Document Ingestion

For best results, ingest relevant documentation before running the triage:

```
# Ingest team runbooks
@docsearch_ingest_directory path="/docs/runbooks"

# Ingest service architecture docs
@docsearch_ingest_directory path="/docs/architecture"
```

## Project Structure

```
workflows/defect-triage/
├── README.md
└── .github/
    ├── agents/
    │   ├── triage-coordinator.agent.md    # Orchestrator
    │   ├── log-investigator.agent.md      # Splunk specialist
    │   ├── doc-researcher.agent.md        # DocSearch specialist
    │   └── root-cause-analyzer.agent.md   # Analysis specialist
    ├── prompts/
    │   └── defect-triage.prompt.md        # Quick-start prompt template
    └── skills/
        ├── splunk-investigation/
        │   └── SKILL.md                   # Splunk investigation methodology
        └── evidence-collection/
            └── SKILL.md                   # Output formatting and schema
```

## Composing into a Target Repo

Copy the workflow into your repo's `.github/` folder:

**PowerShell:**
```powershell
Copy-Item -Recurse -Force "workflows/defect-triage/.github/*" "<target-repo>/.github/"
```

**Bash:**
```bash
cp -r workflows/defect-triage/.github/* <target-repo>/.github/
```

See [compose.md](../../compose.md) for full composition instructions.

## Workflow Phases

### Phase 1: Input Parsing
The Triage Coordinator receives and normalizes defect identifiers. If input is ambiguous, it asks clarifying questions.

### Phase 2: Log Investigation
The Log Investigator connects to Splunk, discovers relevant indexes (with user input), and executes systematic searches: correlation ID lookup, error search, exception search, transaction tracing, event correlation, and latency analysis.

### Phase 3: Documentation Research
The Doc Researcher searches DocSearch for service architecture, runbooks, known issues, and dependencies. Also searches the local codebase for error handling, configurations, and integration points.

### Phase 4: Root Cause Analysis
The Root Cause Analyzer synthesizes all evidence into a timeline, isolates the fault boundary, forms and tests hypotheses, and selects the most likely root cause. It then assembles the structured JSON output.

### Phase 5: Output Assembly
The Triage Coordinator presents the final structured JSON to the user with a human-readable summary and options to refine, re-investigate, or create a JIRA ticket.
