---
applyTo: "**"
description: CI/CD, release, and contribution workflows
---

# Workflows

## Branch Strategy

<!-- TODO: Document branching strategy -->

**Branch naming:**
<!-- Example: `feature/PROJ-123-short-description` -->

## Pull Request Process

<!-- TODO: Document PR requirements -->

**PR requirements:**
- Link to JIRA ticket
- All CI checks pass
- Code review approval

## Versioning

<!-- TODO: Document versioning scheme (e.g., SemVer) -->

## Release Workflow

<!-- TODO: Document release steps -->

## CI/CD Pipeline

<!-- TODO: Document pipeline stages and configuration files -->

## Commit Message Format

<!-- TODO: Document commit conventions (e.g., Conventional Commits) -->
<!-- Example: `feat:`, `fix:`, `docs:`, `refactor:`, `test:`, `chore:` -->
