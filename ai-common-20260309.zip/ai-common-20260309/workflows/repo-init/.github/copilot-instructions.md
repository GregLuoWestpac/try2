﻿# Copilot Instructions

## Confidence Assessment

Before making any changes, assess your understanding on a scale of 0-10:

| Score | Action |
|-------|--------|
| **0-5** | Stop. Ask clarifying questions before proceeding. |
| **6-8** | Pause. Ask targeted questions to fill knowledge gaps. |
| **9-10** | Proceed with implementation. |

**Factors to consider:**
- Is the scope clearly defined?
- Do I understand the expected outcome?
- Are there ambiguous requirements?
- Do I have sufficient context?

**Do NOT make edits until confidence >= 8.**

## Project Documentation

Read `.github/instructions/` files for project context:

| File | Content |
|------|---------|
| `repo_overview.instructions.md` | Repository structure |
| `project_context.instructions.md` | Domain and terminology |
| `development_standards.instructions.md` | Conventions and build system |
| `testing_approach.instructions.md` | Testing patterns |
| `workflows.instructions.md` | CI/CD and release process |
| `usage_patterns.instructions.md` | Consumer integration |

## Principles

1. **Ask before assuming** — When in doubt, ask.
2. **Investigate before acting** — Read files before making changes.
3. **Incremental progress** — Small, verifiable steps over large sweeping changes.
4. **Update documentation** — Keep instruction files current with codebase changes.
5. **Reuse over create** — Prefer existing components, utilities, and patterns over creating new ones.

