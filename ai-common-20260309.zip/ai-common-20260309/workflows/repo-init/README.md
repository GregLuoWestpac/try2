# Repo Init Workflow

The foundation layer for all Copilot agent workflows. Provides `copilot-instructions.md` and template instruction files that other workflows depend on.

## Overview

This workflow is **always copied first** when composing workflows into a target repository. It establishes the universal Copilot behaviour (confidence assessment, principles) and creates placeholder instruction files that are later populated by repo-scanner or manually.

```
┌────────────────────┐     ┌────────────────────┐
│  COPY REPO-INIT    │     │  POPULATE          │
│  INTO TARGET REPO  │ ──▶ │  INSTRUCTION FILES │
└────────────────────┘     └────────────────────┘
        │                          │
        ▼                          ▼
  copilot-instructions.md    Run repo-scanner or
  instructions/ templates    fill manually
  .env.example
```

### What It Provides

| File | Purpose |
|------|---------|
| `copilot-instructions.md` | Universal principles — confidence assessment protocol, investigation-first approach |
| `instructions/*.instructions.md` | Template files with `<!-- TODO -->` placeholders for project-specific content |
| `.env.example` | Environment variable template (copy to `.env`, add to `.gitignore`) |

### Instruction File Templates

| Template | Content |
|----------|---------|
| `repo_overview.instructions.md` | Repository structure and organisation |
| `project_context.instructions.md` | Domain, terminology, business context |
| `development_standards.instructions.md` | Conventions, build system, dependencies |
| `testing_approach.instructions.md` | Testing framework and patterns |
| `usage_patterns.instructions.md` | Consumer integration and usage |
| `workflows.instructions.md` | CI/CD and release process |

## Usage

1. Copy foundation into target repo (see [compose.md](../../compose.md))
2. Configure environment:
   ```bash
   cp <target-repo>/.github/.env.example <target-repo>/.github/.env
   echo '.github/.env' >> <target-repo>/.gitignore
   ```
3. Populate instruction files — choose one:
   - **Automated:** Add repo-scanner workflow → select **Repository Scanner** from agents dropdown
   - **Manual:** Replace `<!-- TODO -->` placeholders in each `instructions/*.instructions.md`

## Project Structure

```
workflows/repo-init/
└── .github/
    ├── copilot-instructions.md                    # Universal Copilot principles
    ├── .env.example                               # Environment variable template
    └── instructions/
        ├── repo_overview.instructions.md          # Repository structure
        ├── project_context.instructions.md        # Domain context
        ├── development_standards.instructions.md  # Conventions & build
        ├── testing_approach.instructions.md       # Testing patterns
        ├── usage_patterns.instructions.md         # Consumer integration
        └── workflows.instructions.md              # CI/CD & release
```

This is the **first** workflow copied into any target repo. All other workflows assume these files exist. See [compose.md](../../compose.md) for full composition instructions.
