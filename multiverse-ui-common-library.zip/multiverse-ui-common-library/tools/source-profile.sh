#!/bin/sh
# Cross-platform shell profile sourcing script
# Detects current shell/OS and sources appropriate profile file
# Compatible with: Windows PowerShell, Windows Git Bash, macOS Zsh, Linux Bash
#
# Usage: . ./tools/source-profile.sh && <your-command>
#        source ./tools/source-profile.sh && <your-command>
#
# IMPORTANT: Profile files must be sourced directly in the current shell (not in subshells)
# to ensure environment variables like PATH are exported and available to subsequent commands.
#
# ✓ Correct:   [ -f "$HOME/.zshrc" ] && . "$HOME/.zshrc" 2>/dev/null || true
# ✗ Incorrect: [ -f "$HOME/.zshrc" ] && (. "$HOME/.zshrc" 2>/dev/null) || true
#              ^ Parentheses create a subshell, preventing variable exports

# Detect and source profile based on shell type
# Source directly in current shell (not subshells) to export environment variables
# Use || true to prevent errors from stopping execution

if [ -n "$PSVersionTable" ]; then
    # Windows PowerShell detected
    # Note: PowerShell profile sourcing in POSIX shell context
    if [ -f "$PROFILE" ]; then
        . "$PROFILE" 2>/dev/null || true
    fi
elif [ -n "$ZSH_VERSION" ]; then
    # Zsh detected (common on macOS)
    [ -f "$HOME/.zshrc" ] && . "$HOME/.zshrc" 2>/dev/null || true
elif [ -n "$BASH_VERSION" ]; then
    # Bash detected (Windows Git Bash, Linux, or macOS)
    # Try .bash_profile first (common on macOS and Git Bash on Windows)
    [ -f "$HOME/.bash_profile" ] && . "$HOME/.bash_profile" 2>/dev/null || true
    # Fall back to .bashrc if .bash_profile doesn't exist
    [ -f "$HOME/.bashrc" ] && . "$HOME/.bashrc" 2>/dev/null || true
else
    # Generic POSIX shell or unknown shell - use OSTYPE as fallback
    case "${OSTYPE:-unknown}" in
        darwin*)
            # macOS - try zsh first, then bash
            [ -f "$HOME/.zshrc" ] && . "$HOME/.zshrc" 2>/dev/null || true
            [ -f "$HOME/.bash_profile" ] && . "$HOME/.bash_profile" 2>/dev/null || true
            ;;
        linux*)
            # Linux - typically uses bash
            [ -f "$HOME/.bashrc" ] && . "$HOME/.bashrc" 2>/dev/null || true
            ;;
        msys*|mingw*|cygwin*)
            # Git Bash on Windows
            [ -f "$HOME/.bash_profile" ] && . "$HOME/.bash_profile" 2>/dev/null || true
            [ -f "$HOME/.bashrc" ] && . "$HOME/.bashrc" 2>/dev/null || true
            ;;
        *)
            # Unknown - try common profile files
            [ -f "$HOME/.profile" ] && . "$HOME/.profile" 2>/dev/null || true
            ;;
    esac
fi

# Exit successfully even if no profile was found
true
