# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.231.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.230.1...v1.231.0) (2026-02-18)

### 🚀 Features

- update footer margin | ART-89786 ([c866e44](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c866e44299f003e89e91f17a1a70c6141839284c))

## [1.230.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.230.0...v1.230.1) (2026-02-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.230.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.229.1...v1.230.0) (2026-02-16)

### 🚀 Features

- update mv util intent params | ART-97842 ([0162320](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/016232062d4e763198ca9263820716b3292dc6f9))

## [1.229.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.229.0...v1.229.1) (2026-02-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.229.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.228.0...v1.229.0) (2026-02-12)

### 🚀 Features

- add prefixWithISOCurrency function to format currency values | ART-85171 ([4c899f9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4c899f964708889b2dc98ed62290830a4ed8c0c9))

## [1.228.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.227.0...v1.228.0) (2026-02-12)

### 🚀 Features

- add todo comment for future feature | ART-88591 ([4269222](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/426922200e1aa6590f04857fef0241a790efb1b7))
- enhance prefixWithISOCurrency to format values | ART-85171 ([7437beb](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7437beb0e7585525f4b481fc860f88e4066febf5))
- move error messages to constants file and small refactor | ART-88591 ([951e304](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/951e3041f661851d8e9928205b6d53e395b1f60c))
- refactor code to take external validation for error scenarios | ART-88591 ([a2e8272](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a2e8272745f5c5086466a7418f90a5d8e74e9fe8))
- remove unused variable | ART-88591 ([68f4288](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/68f42885e751bf055c0a6a3c1516fe041642c61e))
- show currency symbol instead of code | ART-88591 ([d824e15](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d824e15053b1a2d6769a4768d38c77ca7fe2ce82))
- small code refactor for error scenarios and add test file | ART-88591 ([97b2110](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/97b211066f7de9c848633eca59feccfea98ea5cb))
- update prop name and added variable | ART-88591 ([8674205](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8674205971bd3c1589cfc00e3ed20649b23496e6))
- update props and add switch case | ART-88591 ([c36ea2b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c36ea2bcb5140dcfe1184d768527aa7afdd0c0fa))
- update readme file | ART-88591 ([df85b59](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/df85b593652ad5fe7a41961af00c1ceedd340b09))
- update type definitions and constants | ART-88591 ([3c216d2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3c216d22fd22e45ebe95921acdcffda9d2bc2b82))
- uplift amount range component for treasury page | ART-88591 ([333149a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/333149aedf52451d2ca1e267e242f30a00ca44cf))
- uplift currency string formatting for treasury page | ART-88591 ([51e2822](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/51e2822b1f8c263c587e5007981a3578c53941c9))

### 💥 Bug Fixes

- add default for switch statement | ART-88591 ([e7ea3c7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e7ea3c7051ef8f4f277c40f93576e3fdf6078ea5))
- update test to pass build | ART-88591 ([9576230](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/957623090088f4d3e38b575bb0cba0dd268d2468))

## [1.227.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.226.2...v1.227.0) (2026-02-11)

### 🚀 Features

- add prefixWithISOCurrency function with tests for supported currencies | ART-85171 ([eee5e8b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/eee5e8bcef1bb48f3b7ad268545962936855d4aa))

## [1.226.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.226.1...v1.226.2) (2026-02-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.226.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.226.0...v1.226.1) (2026-02-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.226.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.225.5...v1.226.0) (2026-02-06)

### 🚀 Features

- add pageContext in data | ART-98468 ([02d8c0e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/02d8c0e44e7ca320858c18536b435228b6d87755))
- add pagecontext name in orgId | ART-98468 ([e6d42fb](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e6d42fbdc3e7119e0646eb74a19a83810b085bb2))

## [1.225.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.225.4...v1.225.5) (2026-02-05)

### 💥 Bug Fixes

- normaliseData | ART-98641 ([c57049c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c57049cd7faf15e72c8dd71fb1c604923f2effc1))

## [1.225.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.225.3...v1.225.4) (2026-02-05)

### 💥 Bug Fixes

- add missing MVCheckboxController export to index file | ART-98630 ([b592726](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b59272662c8b5a536da300741e4d9bc98efb17c0))

## [1.225.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.225.2...v1.225.3) (2026-02-05)

### 💥 Bug Fixes

- reset x-auth to not be a required header | ART-98393 ([3351311](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/335131168e255feee92734ffe0b747f0716ba898))

## [1.225.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.225.1...v1.225.2) (2026-02-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.225.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.225.0...v1.225.1) (2026-02-05)

### 💥 Bug Fixes

- enhance trimText function and integrate maximumLength handling in MVInputController | ART-98630 ([2657671](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/26576714fa5d13f75e8d57012da8d668f54d6ff5))
- set x-auth header to required | ART-98393 ([d0b14af](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d0b14af9f69a75196db9bfb372cfda373aa5ecdf))
- update transaction parameters to include amount range queries | ART-96550 ([dd7cd5b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/dd7cd5ba1307a951c1bc0cf0a2a1521b8836891d))

## [1.225.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.9...v1.225.0) (2026-02-04)

### 🚀 Features

- add utils for encrypting/decrypting with sdek | ART-84491 ([8070d4e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8070d4e1e034b1cbdca834f7a72cecb3cd8f028c))

### 💥 Bug Fixes

- change types for parameters | ART-84491 ([56cbf23](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/56cbf233289f19a443663220d22134ce5f47cc77))
- pass crypto functions as params | ART-84491 ([f5cf8c0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f5cf8c0d5af528604cce91669e8f54b93a65e3f5))

## [1.224.9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.8...v1.224.9) (2026-02-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.224.8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.7...v1.224.8) (2026-02-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.224.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.6...v1.224.7) (2026-02-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.224.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.5...v1.224.6) (2026-01-30)

### 💥 Bug Fixes

- reverting the currency changes | ART-98062 ([f5d72aa](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f5d72aa81d6f808b1313b665d1d74e07cd158f1a))

## [1.224.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.4...v1.224.5) (2026-01-30)

### 💥 Bug Fixes

- correct margin change | ART-98065 ([074fe71](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/074fe712ac281a4fe9c4d2156105cb969eccb809))
- update heading margins to prevent text overlap on windows | ART-98065 ([2ae75e4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2ae75e413885c298a6f898c11e048c701a9e9037))

## [1.224.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.3...v1.224.4) (2026-01-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.224.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.2...v1.224.3) (2026-01-30)

### 💥 Bug Fixes

- fixed the unit test | ART-98062 ([1a973a7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1a973a72675dbce67474d6d60331cad856a58c80))
- update package lock json | ART-98062 ([e3ead2d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e3ead2deb4d35be33a0a936b4cc97dc2353bad51))
- updated the default currency from formdata | ART-98062 ([ee2cc8d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ee2cc8db111c4f225a34eeab1c2ecc8740da5163))

## [1.224.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.1...v1.224.2) (2026-01-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.224.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.0...v1.224.1) (2026-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.224.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.223.3...v1.224.0) (2026-01-29)

### 🚀 Features

- update mv currency | ART-88675 ([282490b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/282490b67720306b312f6e6b3d528e4c7ee5db6d))
- update mv currency with balanceAmount input | ART-88675 ([a896ad3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a896ad3b0161648bb063ff8d44e9062079e8d6c3))

### 💥 Bug Fixes

- excluding divisionName from downstream req body for create bene | ART-98062 ([53350c9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/53350c9033e219391748c235b8214da6162f6386))

## [1.223.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.223.2...v1.223.3) (2026-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.223.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.223.1...v1.223.2) (2026-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.223.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.223.0...v1.223.1) (2026-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.223.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.222.0...v1.223.0) (2026-01-28)

### 🚀 Features

- account group name min length update | ART-68107 ([cedeb47](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cedeb47bf6391364ca03506c490d84b2c98150ee))
- integrate UserIdScheme enum into alias lookup handler for improved user identification | ART-98215 ([9754acc](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9754acc06a1221970da21f44b767f4d893c5c52a))
- refactor alias lookup handler to improve session and user counter logic | ART-98215 ([2ebe78b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2ebe78b3a2c52f517f6593e896ef8e095452a4da))
- **ui-galaxy:** swagger changes | ART-98171 ([c69db20](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c69db20bf5eaa8bc4f3a91921938a3bdd2c5dec3))

### 💥 Bug Fixes

- refactor error handling in getAliasLookupByPayIdAndTypeHandler to improve session ID counter logic | ART-98215 ([dce52d6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/dce52d6130bf7a0ac255c26abcef372d5f68c998))

## [1.222.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.221.6...v1.222.0) (2026-01-26)

### 🚀 Features

- export supported currency | ART-85294 ([960d6c3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/960d6c357269188b37c8616ad4a5e4e06d7337a1))

## [1.221.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.221.5...v1.221.6) (2026-01-25)

### 💥 Bug Fixes

- updated the import | ART-98173 ([25c8e7d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/25c8e7ddd62538164463088db989b7dd020d270b))

## [1.221.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.221.4...v1.221.5) (2026-01-25)

### 💥 Bug Fixes

- updated divisionName maxLength to 70 | ART-98062 ([35fc3dc](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/35fc3dc57817091f11c4026afbbde85c3c459086))
- updated the entity name | ART-98173 ([3497b90](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3497b90ee5e8e7d40c5c3ad64fc4a6fad8df38f6))
- updated the handlers | ART-98173 ([c985a4d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c985a4d33cb9fe06a4bfd8ec11b39e5d2cbf81f1))
- updated the pageSizeQueryParam to 10 | ART-98062 ([1cb5b0b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1cb5b0b56a24cfb5c28731c3adf909b84572904d))

## [1.221.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.221.3...v1.221.4) (2026-01-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.221.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.221.2...v1.221.3) (2026-01-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.221.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.221.1...v1.221.2) (2026-01-22)

### 🚀 Features

- added entitlement fields for payment and transfer requests| ART-93501 ([4bcc4b5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4bcc4b5966cb9b02d94601f5a927ee3ab72fa908))

### 💥 Bug Fixes

- addressing comments ([8599f6d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8599f6dd1a70cc7a320ad8fb8fe743b0fca1c063))
- avoid allOf by flattening request schemas as MEP validator doesn’t flatten allOf ([2c5589b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2c5589bc96397911a938ecf3430a1e37fb83aa4a))
- beneficiaryType no longer requited for debitorAgent ([ea1a7d3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ea1a7d394ca4b8b5d354b3cd9c5986514626d34b))
- renamed with Model suffiix ([bc1f2a3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bc1f2a3afc0475a426e64f984863b7e97fa15194))

## [1.221.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.221.0...v1.221.1) (2026-01-21)

### 🚀 Features

- update currenyCode requirement | ART-89540 ([3a38b6c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3a38b6cad74d1da5a2c8e9e2e3998b2723db8e02))

## [1.221.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.220.0...v1.221.0) (2026-01-19)

### 🚀 Features

- add currency support function and array object | feature/ART-88675 ([07001c5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/07001c59352ec491426ede064dfabd2fd531c01f))

## [1.220.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.219.10...v1.220.0) (2026-01-19)

### 🚀 Features

- update cookie name from pmData to W1AddnAuthorisation | ART-97784 ([d12b60f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d12b60fbb75e05826a82ff97ac39da43ab55c984))

## [1.219.10](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.219.9...v1.219.10) (2026-01-19)

### 💥 Bug Fixes

- added previous classes used | ART-84954 ([0a1c9cd](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0a1c9cd845417ef2739df051b355ecb4b25df504))

## [1.219.9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.219.8...v1.219.9) (2026-01-14)

### 💥 Bug Fixes

- update test cases according to the payload changes | ART-97745 ([90afbc1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/90afbc1d768107e674fe2ac28d811e5616b5fcc8))

## [1.219.8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.219.7...v1.219.8) (2026-01-13)

### 💥 Bug Fixes

- remove legalName field from alias lookup response and unit test fix | ART-88711 ([9fb5853](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9fb5853613d7d7c5418350f91cf755ed1b5d9cb7))
- removed a duplicate folder which may created by accident | ART-97745 ([9253f22](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9253f22103b655f32ebaa4d0ad691b35bfbcd1eb))

## [1.219.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.219.6...v1.219.7) (2026-01-13)

### 💥 Bug Fixes

- add type definition in index.d.ts | ART-97745 ([d37d38b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d37d38b7b9d43f1038b2c8bf0a1e8b87e339cb65))

## [1.219.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.219.5...v1.219.6) (2026-01-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.219.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.219.4...v1.219.5) (2026-01-13)

### 💥 Bug Fixes

- flat currencyAmount object | ART-97745 ([f9dbe1f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f9dbe1f503a328375c49b092514dc8c6eee0a1ee))

## [1.219.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.219.3...v1.219.4) (2026-01-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.219.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.219.2...v1.219.3) (2026-01-13)

### 💥 Bug Fixes

- update validation logic to restrict amount range for greater than 99999999999.99 || ART-96550 ([c2a72f3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c2a72f3aedd9ae3609b26b236dac4dda32ee1704))

## [1.219.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.219.1...v1.219.2) (2025-12-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.219.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.219.0...v1.219.1) (2025-12-19)

### 🚀 Features

- added new variable definition for service level | ART-78336 ([3b42207](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3b42207b88ef008a046e5c22eab9ef038f505e5b))
- added texAccountStatus | ART-87862 ([ec240a6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ec240a6d454b32f2b6e807c98da55492e458082f))
- changed anyOf | ART-87862 ([230e475](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/230e47583b504307cb7f54955c1dfad88112d5d1))

### 💥 Bug Fixes

- add back deleted files | ART-88711 ([9b541f6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9b541f66f1babf412fa5f9f318b3533504b1ee0e))
- update package-lock.json | ART-88711 ([a1eb9c7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a1eb9c71fb355a7e7cb9003e26324b8fdfd725fb))

## [1.219.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.218.0...v1.219.0) (2025-12-19)

### 🚀 Features

- move query string parameters to request body define in common definition | ART-66803 ([9ebadb7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9ebadb7017cdd93cc700c12e9adfa87b270186b4))
- add isNewPayee field to supplementary Data Object | ART-74258 ([8c7aa67](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8c7aa67fa02546a40969cff0a41c7a23ca149789))
- add mv-crypto package, add enrpytion function | ART-84491 ([70955e7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/70955e7f67f3c27899f0ed6482b9752e12b0dc0e))
- add organisation legal and alias name definitions | ART-87615 ([442d4ad](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/442d4ad6e43f1dd92175ab45b09a9bc75a792f21))
- add Percentage type definition and update TierBandRate to use it | ART-86714 ([845c1b9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/845c1b9378b95c18fbd670ebaa24a1476ee014e3))
- add transaction search fields to swagger common definition | ART-66803 ([4ccab58](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4ccab58a0058706e3c8cd219bb27d3cd1ebb240d))
- added division object swagger fields to approval workflow api|ART-84850 ([da545b4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/da545b4d86e1d2fee036d2b131619674e7ab28b6))
- adding SearchCriteria in definitions | ART-70479 ([b431cfa](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b431cfa0a15c9a3eab69d89dcbb569af6b08ec32))
- adding SearchCriteria in definitions | ART-70479 ([14f5dae](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/14f5dae225b72c6fec918913ab583c233f393579))
- address PR comments file | ART-66803 ([d87cbef](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d87cbef269dc3923dde4c31ebbace370c1f03d44))
- address PR comments file | ART-66803 ([4763154](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/476315402ab3ded789e24b4d3ac43aadd999fe58))
- **ART-70051:** add common accountGroup definition ([133b7b4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/133b7b46f6a443e2ec18d82d2c1fdaf6f8c4569a))
- change in Ben status swagger as per new backend updated types ([16cc972](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/16cc97261746cb4ee6be4f8ca130f7d35c36c24b))
- **exp-galaxy:** fix missing tokens| ART-68836 ([9db5e05](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9db5e0563eb7a691ce2de1ee0f0dedc95ae5b846))
- **exp-galaxy:** swagger changes for post paymentsv2| ART-68836 ([a21558f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a21558f0270a40b64f68ebcd6085b415e00061da))
- **exp-galaxy:** swagger changes for post paymentsv2| ART-68836 ([f84b955](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f84b955ddb9e622e09f2b02f13cd76fc90f3810b))
- **exp-galaxy:** swagger changes for post paymentsv2| ART-68836 ([92fd38a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/92fd38ab34eb70f9bdd62e631e6f4a1e8f988681))
- **exp-payments:** add divisions object with ex| ART-84847 ([66192f8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/66192f8a39f6813897aa0068fb44b4119af2cf90))
- **exp-payments:** add divisions object with ex| ART-84847 ([2319ed5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2319ed554c33036511c80ea29b27188c69942041))
- **exp-payments:** add divisions object with ex| ART-84847 ([aaa820a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/aaa820a293a7def0e67443ede3fdfbb775561db9))
- **exp-payments:** add divisions object| ART-84847 ([14522f0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/14522f0fe06f8dd9bc1014ff26c01bfe4d814ad8))
- **exp-payments:** add divisions object| ART-84847 ([e947481](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e94748104e10b7566a1bb349e9e6eab3cd224fed))
- **exp-payments:** add divisions object| ART-84847 ([29e71b3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/29e71b36bfba5266c4bd286c343553ab123d28ba))
- **exp-payments:** add divisions object| ART-84847 ([664334c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/664334cbf7f3738894ef7f39971f5355136b9229))
- **exp-payments:** add divisions object| ART-84847 ([e1738f2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e1738f24c3dfa31516a7ff6080b8407e7dcf2a76))
- index file update for dependency upgrade | ART-84849 ([f45ecbf](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f45ecbfe1b50c29c8f5ae544165bc131e5ccfc75))
- modification in BeneficiaryDetails_LPS | ART-84849 ([065a2b6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/065a2b6b8bdc5cf254651464c9c0299c3889556c))
- move query string parameters to common parameters file | ART-66803 ([9b0b3ff](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9b0b3ffada9abee65a1e90c2506e42d1e12bcdf9))
- move query string parameters to common parameters file | ART-66803 ([f9763dc](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f9763dc89353695d7ea8b74baee71a70451076e3))
- move query string parameters to common parameters file | ART-66803 ([6a57df7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6a57df7bc97527eb1670e7cb5376bd0b9f347a76))
- move query string parameters to common parameters file | ART-66803 ([fb8cac3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fb8cac31297ee76504398b1ae1af6b6dc39115eb))
- move query string parameters to common parameters file | ART-66803 ([d76a74e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d76a74e3d8c4de7c590ad762bc4f442867d6f1d3))
- moved divisionId into query param | ART-66873 ([861561d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/861561d1945b9490107ce2be0dfbc5e6b367e8a3))
- pdp query function for Divisions | ART-84849 ([6770cd9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6770cd961078eaaa0c3afce13a6475889860c0ec))
- update beneficiary response object | ART-84849 ([1bad3e9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1bad3e9715ee86115eb4abc50efe5ef04aed2fc3))
- update definitions in YAML | ART-86714 ([5340948](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/53409485acf61070452cb8187101cc450ebc93e5))
- update PaymentTypeInformation references in definitions.yaml | ART-86714 ([4ca7f09](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4ca7f09e809c1a425cb680abc28e68a81d7b06bd))
- updated mv input to accept type | ART-84488 ([ac5279e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ac5279e3d5bc255c0372c6b0480ad240645edba9))
- updated pdp query result to match response object | ART-84849 ([fe6bf9c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fe6bf9c1bc341940b786cde36f92e53a0997ba49))
- updated pdpquery functions | ART-84849 ([8ccbccd](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8ccbccdf20488d5eb715ce857811a5451a2e6227))
- updated type | ART-84488 ([6e8f1a0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6e8f1a0c8f2e18bbeaa39751c1959fd0ca58e729))

### 💥 Bug Fixes

- change to common data models ([b0712e0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b0712e03df297c4d1d1baee007cb7e3f7aa4af7d))
- change to common data models ([cf3f135](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cf3f1352f78825385fd14284e6dfddfd915bbc8e))
- change to common data models ([d58b119](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d58b11995f113f5de2253842f617487b84483b65))
- change to common data models ([f55a72d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f55a72d95a6f0196c49e3f4cdb042fe9ae6d3419))
- missing swagger changes to the feature/Feb-2026-ERM branch ([45328e4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/45328e48d85f827b0f745117b11e7c7c4f5d062f))
- remove hardcoded public key | ART-84491 ([a6c3dec](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a6c3decd0d01b8af22a06a211bb4ba52c440675e))
- remove mv-crypto declerations from library package | ART-84491 ([912b42a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/912b42a88956e30eed72f452535b954eb80944d3))
- remove separate swagger definition for boolean type | ART-74258 ([207e010](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/207e01003172b6442765b90ba72ae8e0623a83e1))
- update package lock | ART-84491 ([1d6a800](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1d6a8004caca5e902db63b67e06e0bb400d42289))
- update package-lock.json | ART-88711 ([f261104](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f26110403a46feb6a78957b6de7454db12fb92ad))
- update references for supplementary data object in payment definition | ART-74258 ([43a07b8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/43a07b85fa998f23daed8859c2574766308b9fc3))
- wrong names | ART-66803 ([9e57b1b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9e57b1b3711fc1b39486713e74154835946a50a1))

## [1.218.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.217.1...v1.218.0) (2025-12-18)

### 🚀 Features

- rename currency field to currencyCode JIRA:ART-89540 ([832731a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/832731a1be744f05ad419f2b983d369925b1eab1))

## [1.217.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.217.0...v1.217.1) (2025-12-17)

### 💥 Bug Fixes

- added bottom padding for success banner | ART-84954 ([94dff18](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/94dff18bf1730601fa62f2740ca5e4488541266a))

## [1.217.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.216.0...v1.217.0) (2025-12-17)

### 🚀 Features

- add common params in mv swagger | ART-68107 ([cf8326d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cf8326d2b67bfc3bad955a749564c24aee7137bd))
- add MeshEntityId for reuse ([d2bf939](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d2bf9390f0cae5366e11ac62678f3d74322e0be4))
- build fix - updated package.lock.json | ART-84849 ([6384562](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/63845629558dbd358730dbeeb3a73c1eb9f8d3a4))
- package lock update | ART-84849 ([4e60fd0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4e60fd022eef902e7f58dfc53e3803e0a0a8737e))
- remove common params in mv swagger | ART-68107 ([d415086](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d415086dd4a65b3901b3dfee2bd49fef89679938))
- remove vulnerability fields from alias lookup API response | ART-88711 ([cc5bd72](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cc5bd7277580f0d3e9d23650dcbdd1be74a4ff4f))
- update aliasType in transformAliasLookupExpResponse to use PAYID_TYPE | ART-88711 ([e847f16](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e847f16aa637094352fc657466f1b78a98492a41))
- uplife accountlist pdp function to support divisions | ART-84849 ([fd70655](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fd70655df882d72edd0658a7c4700b0a52c1dc7a))
- uplife accountlist pdp function to support divisions | ART-84849 ([d154bb3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d154bb338576a9ec60b994520464d294c7d96273))

### 💥 Bug Fixes

- update package-lock.json ([8380aae](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8380aae5620ea30fc57dcc0f13fba6d94442f844))

## [1.216.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.215.1...v1.216.0) (2025-12-15)

### 🚀 Features

- add product switch sub type constant | ART-78294 ([be32ada](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/be32ada2eb58ff54fba81aaab31c15796ea3c937))

## [1.215.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.215.0...v1.215.1) (2025-12-09)

### 💥 Bug Fixes

- re-add InputGroupProps to MVCurrencyController | ART-83263 ([042fb9e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/042fb9ed4fffc00712747392ea78844c5f9dbfd5))

## [1.215.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.214.0...v1.215.0) (2025-12-09)

### 🚀 Features

- migrate Feb2026 inputs to standard | ART-83263 ([156b6bf](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/156b6bf3fde0a94313420005132ec2463d941902))

### 💥 Bug Fixes

- fix package.json resolutions/overrides | ART-83623 ([d4be81f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d4be81f4a3301bf1700ce6b8210f278d294ef328))
- update imports | ART-83263 ([7bc282e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7bc282eea67366347fadfb01e0c7bcabac28d570))

## [1.214.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.213.0...v1.214.0) (2025-12-09)

### 🚀 Features

- secondary label for accrued interest labels | ART-87937 ([ef81f49](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ef81f49dd812a3be332dafeba94a6600bca3303f))
- updated package-lock | ART-87937 ([aa69bec](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/aa69bec553bdc47d49c7f3782ef56ec4856473b5))

## [1.213.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.212.0...v1.213.0) (2025-12-04)

### 🚀 Features

- added detectInjectionVulnerability generic function in mv-inject-checker inorder to check input vulnerability at xapi layer ([4fced00](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4fced00a1549f2c9186114972415ecaf4d9a7c53))

## [1.212.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.211.0...v1.212.0) (2025-12-02)

### 🚀 Features

- pdpquery function updates to suppport division | ART-70051 ([4031504](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/40315044f2daa99d14888abed15ab1cdddecfdb1))

## [1.211.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.210.3...v1.211.0) (2025-11-25)

### 🚀 Features

- add spread and operator fields to TierBandRate definition | ART-67771 ([813efde](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/813efde4c715de2d0f2ba128a15528b683893eb8))
- update MVRefresh to handle last successfule date and time display | ART-66871 ([501aa4b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/501aa4becb523e728ef0fd91b0f09cbb3a9ae440))

## [1.210.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.210.2...v1.210.3) (2025-11-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.210.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.210.1...v1.210.2) (2025-11-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.210.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.210.0...v1.210.1) (2025-11-18)

### 🚀 Features

- add 409 error response | ART-73883 ([391e41f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/391e41fef02be6b3b2ecde01c607b062f848e946))

## [1.210.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.209.2...v1.210.0) (2025-11-13)

### 🚀 Features

- add onChange prop to MVSelectController for handling selection change | ART-70047 ([a72dbc0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a72dbc054f80092129fbefd149dc04ba34fbcc93))

## [1.209.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.209.1...v1.209.2) (2025-11-12)

### 🚀 Features

- remove duplicate collapsible comp | ART-67808 ([268bb09](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/268bb09f4e545294da9beb6058682ec5fb73736d))

## [1.209.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.209.0...v1.209.1) (2025-11-09)

### 💥 Bug Fixes

- snyk vulnerabilties | ART-63316 ([dc0300f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/dc0300f179ae14bcd9118621718ff76528dded67))
- snyk vulnerabilties | ART-63316 ([214511d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/214511d75bf7e6811b61078b8d71afd9ac34e1ce))
- snyk vulnerabilties | ART-63316 ([7eedeb6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7eedeb61c0c138eba295d6a04343bcabb3cf4280))

## [1.209.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.208.0...v1.209.0) (2025-11-04)

### 🚀 Features

- trigger version update | ART-85165 ([5b67e6d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5b67e6d8e12b237b1a21e62a341bffe15bb4456e))

## [1.208.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.207.0...v1.208.0) (2025-10-31)

### 🚀 Features

- **ART-66800:** double spacing for FormattedForbiddenCharacters string ([48aec98](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/48aec98190d734dede5ea2b836bad5bc59a70305))
- **ART-66800:** update comment and test case ([2ddd759](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2ddd75918118599afdc9a76fb724c2c995a8a8e4))
- reverting to previous card | ART-82213 ([4417746](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4417746ef39201cde6e9793e2fa2c23ed25354d5))

## [1.207.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.206.0...v1.207.0) (2025-10-30)

### 🚀 Features

- removed style attribute for span | ART-85143 ([0885478](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/08854782d6cb040485e13a6175e06488563c2127))
- update mvcard subheading to be span | ART-85143 ([42a6151](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/42a615126ef062936dbbce3ac12653d2a1a19848))

## [1.206.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.205.7...v1.206.0) (2025-10-30)

### 🚀 Features

- update mvcard margins and dynamic height feature | ART-82213 ([a83dd0a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a83dd0ada46bc8e840bc4f2b38a485368cbd6b63))

## [1.205.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.205.6...v1.205.7) (2025-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.205.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.205.5...v1.205.6) (2025-10-29)

### 🚀 Features

- add Percentage definition with validation pattern in definitions.yaml | ART-82634 ([184e996](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/184e9963f1a18470cd19af9790f1728c8533005f))

## [1.205.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.205.4...v1.205.5) (2025-10-28)

### 💥 Bug Fixes

- remove outline offset | ART-84954 ([3cd4aa4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3cd4aa4b998b21c0234a91b043ea40b6dd618ef6))
- set leading to 0 to reduce line height | ART-84954 ([0669480](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0669480e0f69f9b191aa58190cb6c4ea6c6c6500))

## [1.205.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.205.3...v1.205.4) (2025-10-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.205.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.205.2...v1.205.3) (2025-10-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.205.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.205.1...v1.205.2) (2025-10-27)

### 💥 Bug Fixes

- change to h-fit to remove the extra whitespace | ART-84954 ([f8802e7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f8802e74c8bb64cc67ada871210e6a4c1a56ebb6))

## [1.205.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.205.0...v1.205.1) (2025-10-27)

### 💥 Bug Fixes

- remove h-0 from link | ART-84954 ([4d5b397](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4d5b39704e538e94d7391b70c4055d95a13cf9f7))

## [1.205.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.204.0...v1.205.0) (2025-10-27)

### 🚀 Features

- add sanitisation/trimming to custom RHF components | ART-74341 ([f3c9cbc](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f3c9cbcaab8f57be3e7a2c6afcf6108eb0d4737a))
- added autofill behaviour | ART-70475 ([3fb3b88](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3fb3b88b30fb02503ff9c8279f917f96807dfccf))
- correct naming error for Feb2026 component | ART-74341 ([e91ec14](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e91ec14dae9f5333995fab5c9c8c5f8e21df4fce))
- restore existing components for side-by-side deployment | ART-74341 ([7a50a8c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7a50a8cdb934d2419ba0de522c0a120ca8086de6))
- update readme for sanitisation/trimming | ART-74341 ([77b24b6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/77b24b6af2f15c022cc784077e33ec647262243f))
- updated formatCurrencyString to allow zero for amountRange | ART-70475 ([971528d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/971528d0a071ce0aa063fa70d43f4cb26034060e))
- updated invalid value message | ART-70475 ([059b627](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/059b627a456168c821294be156b1e5443df9d3c4))

### 💥 Bug Fixes

- bypass flaky test ([5b7cc8c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5b7cc8cc64333f5bbaf8821eb1f9b651e8a559ae))

## [1.204.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.203.0...v1.204.0) (2025-10-26)

### 🚀 Features

- update gel package for accordion bug | ART-79216 ([ee97920](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ee97920aaa906746ebabfd4985c6e07c5d91c554))
- updated form with autocomplete prop | ART-79216 ([0f20a03](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0f20a0307b477cf6a04bd30fd43c88a32bb5ff54))

## [1.203.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.202.0...v1.203.0) (2025-10-24)

### 🚀 Features

- updated onclick event | ART-79216 ([2f42435](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2f4243528c33b038facf307bc8fb7c8a74f013d0))

## [1.202.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.201.2...v1.202.0) (2025-10-24)

### 🚀 Features

- added form tag + removed griditem for children | ART-79216 ([5e6e67e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5e6e67e9e3318c68c05c31905576af40b450b8f6))

## [1.201.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.201.1...v1.201.2) (2025-10-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.201.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.201.0...v1.201.1) (2025-10-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.201.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.200.2...v1.201.0) (2025-10-22)

### 🚀 Features

- update button width | ART-79216 ([302b4cd](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/302b4cd14622687b011a6e93b5ea7ac93f90cea1))

## [1.200.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.200.1...v1.200.2) (2025-10-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.200.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.199.0...v1.200.1) (2025-10-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.199.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.198.0...v1.199.0) (2025-10-20)

### 🚀 Features

- added the package version | ART-82161 ([e324e00](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e324e00d38c6cd513be34a0e25867e5b97ae70f4))

## [1.198.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.197.0...v1.198.0) (2025-10-20)

### 🚀 Features

- Adding new package MVCollapsiblePanel | ART-82161 ([c700b14](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c700b144d7c11e0f476c2f652445ab75471040e3))
- removed collapsible panel comp from library | ART-82161 ([c7e4e8c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c7e4e8cc8330d38718173a2646dfbb2127433f36))
- removed the unnecessary dependency | ART-82161 ([54221eb](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/54221eb3b6fceb89ebc96c25bce47f9afd060026))
- updated according to review comments | ART-82161 ([477701b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/477701b664b4a528812cdfb351130bfa3f797197))
- updated the styling after shoulder check | ART-82161 ([04d681a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/04d681a6336c7163b21c8c57f7b92977dcf3e584))
- updated the tailwind config, keydown event | ART-82161 ([45b3739](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/45b373915ffe81265bf48cc742c3bbc3e5c9f4a4))

## [1.197.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.196.1...v1.197.0) (2025-10-19)

### 🚀 Features

- added textValue to avoid aria errors + added button symbol | ART-79216 ([c3ce97c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c3ce97c145d94a9fce5c86a342c371453f85beab))
- update grid gap | ART-79216 ([57b37ea](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/57b37eabe34354fd5f93b3a05c7131c524276513))

## [1.196.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.196.0...v1.196.1) (2025-10-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.196.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.195.0...v1.196.0) (2025-10-16)

### 🚀 Features

- ART-76879 add common 204 definition ([c7f144d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c7f144df3c2e4579c9d7c2765200ca6205a1eddc))
- ART-76879 add common 204 definition ([8cbead3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8cbead3593db40e6db348e9784824eda3c248f13))
- ART-76879 add common 204 definition ([da977e9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/da977e9f63028c50503fff3cf17d4af1ae0d7213))
- updating apiaccountlist to accept accountstatus query param | ART-82994 ([dc20034](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/dc200343ea8eb62ba76e4ecbedc803bd2e27d926))

## [1.195.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.194.0...v1.195.0) (2025-10-15)

### 🚀 Features

- add useMemo to the intent context data | ART-63313 ([5b0abca](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5b0abcad2833b9261a9ebc7f23b27238967087a7))

## [1.194.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.193.1...v1.194.0) (2025-10-14)

### 🚀 Features

- upgrade multiverse react lib in mv-utils | ART-63313 ([1623b78](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1623b78f9715b438a9ec3e3ecd315fca9671dfdb))

## [1.193.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.193.0...v1.193.1) (2025-10-14)

### 💥 Bug Fixes

- passing on the data into the global redux store | ART-79212 ([2b350fd](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2b350fd18b45b9b3b35743fdb919d87c6843df05))

## [1.193.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.192.2...v1.193.0) (2025-10-13)

### 🚀 Features

- added accountStatusQueryParam |ART-82994 ([012ec82](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/012ec82269ea958daf5f89b74ee308612dad40d1))
- Initial release of mv-apiBsbLookup package with BSB lookup controller | ART-74368 ([fd9f36f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fd9f36f26e6bb2103d0dcc1bf2821bb114710264))
- removed pattern | ART-82994 ([ace0cad](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ace0cad973379035c87a4317045565a1a50b45dc))
- update version to 0.0.0, enhance error handling, and improve test coverage for BSB lookup controller | ART-74368 ([0ea9fb1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0ea9fb12be2c2b573a8196819b58d2333f544a66))

### 💥 Bug Fixes

- remove entitlementInformation from PaymentDetailsRequest | ART-74255 ([84480a6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/84480a67b024321a53f4cb41768bef0c38c12e15))

## [1.192.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.192.1...v1.192.2) (2025-10-10)

### 🚀 Features

- update package.json | aRT-82764 ([c724d71](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c724d71f60d3fd503d33e24012128f7205e2b294))

## [1.192.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.192.0...v1.192.1) (2025-10-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.192.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.191.1...v1.192.0) (2025-10-10)

### 🚀 Features

- testing mv-table | ART-82764 ([6586e2e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6586e2e6bd1534d8c7aca4cae18d0f5679b70ebf))

## [1.191.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.191.0...v1.191.1) (2025-10-10)

### 🚀 Features

- **ART-70353:** remove Balance ([839b764](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/839b76455f0af94858a49c9e8a9ba4cefc031aba))
- **ART-70353:** remove Balance ([616c746](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/616c746768e2983acdc454725c7f6655c8e31fb5))
- **ART-70353:** swagger update: Balance ([71107a3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/71107a380dde0793464e40a843406315361e993b))
- **ART-70353:** update swagger bash script ([70a434d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/70a434d18c4f273653839703b022f82762da6ae3))
- **ART-70353:** update swagger definition ([f75132e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f75132e08f32fc4ecfa7c3645ccc29838e7d0c71))

## [1.191.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.190.0...v1.191.0) (2025-10-09)

### 🚀 Features

- removing from library | ART-79216 ([3f4cf25](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3f4cf251a4da7267b5ee02bccecade7049479955))

## [1.190.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.189.0...v1.190.0) (2025-10-09)

### 🚀 Features

- added progress indicator + removed uneccessary props | ART-79216 ([ce0601a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ce0601a30bfe496d07f56660a983f97114985a35))
- added wrapper to accordion to resolve component overflow issues | ART-79216 ([bd9f9c8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bd9f9c8d4ca91d9c1328beebcd6b85f012c450fb))
- adding expanded left-border | ART-79216 ([340a89f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/340a89f6258f7797bd5c91f8e72eda2f0fb37971))
- adding new filter accordion package | ART-79216 ([3d1e13f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3d1e13fd30246a3611958c3dcabf8456fa12ed85))
- changed button label ([17ba6b0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/17ba6b074369042bdc7f9790600601691c4b85bf))
- cleaned up filter accordion references | ART-79216 ([931f98a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/931f98a3c607396fd3f301e3fb03d9b9547fec34))
- removing comments | ART-79216 ([579f74b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/579f74b37744786469a5a549be25fd121f640cb1))
- renamed component name | ART-79216 ([23192af](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/23192af9d86b283a05516f7df44b6c991151be80))
- simplified accordion | ART-79216 ([9081b6f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9081b6fe19b88950b7033605a1ad7775fdaaba6e))
- updated classes for accordion grid items | ART-79216 ([bfc56e5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bfc56e557b335f4dc057cfd5ea11708beff66c70))
- updated onbuttonclick to address possibly undefined | ART-79216 ([fe9f03c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fe9f03caabe790fcf7352c8539270dcfc00bbea6))
- updated readme | ART-79216 ([7d89ddc](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7d89ddc90f9d24f3a87d960676a42f9f2898c11e))
- updating overflow behaviours | ART-79216 ([9a6c7e4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9a6c7e47a9b91d68da8315a3f3645e6a5f0ff150))

### 💥 Bug Fixes

- fixed spacing issues | ART-79216 ([d3d1941](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d3d1941511409242278921c80fe86038f16dbb2e))

## [1.189.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.188.2...v1.189.0) (2025-10-09)

### 🚀 Features

- update status matching logic | ART-71494 ([ccf677c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ccf677cc6fe1324c667712ef11ba1b0329bd32df))
- update to pass test | ART-71494 ([f592a35](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f592a3517d600bb83c481ac6874548e990124486))

## [1.188.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.188.1...v1.188.2) (2025-10-08)

### 💥 Bug Fixes

- remove redefined ControllerParams | ART-74256 ([9220906](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/922090677f6ca01d6e269581e642d28f30ec72b0))

## [1.188.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.188.0...v1.188.1) (2025-10-08)

### 💥 Bug Fixes

- update beneficiarycreate readme and package.json | ART-74256 ([422e433](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/422e433b97f7b287870c5f003aff4c0be8d6543c))
- update beneficiarycreate readme and package.json | ART-74256 ([06aba42](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/06aba42368c4838a55ce63f635abda6a9609d28a))

## [1.188.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.187.0...v1.188.0) (2025-10-07)

### 🚀 Features

- added type defs and updated readme file | ART-70475 ([85d3221](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/85d32219fee299f8148d66c497c979624cfdaead))
- created complete amountRange component | ART-70475 ([dbe7520](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/dbe75201889389b543ff14dd3ae5a83da441f990))
- refactor code to allow for 0 dollars input | ART-70475 ([322e6c5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/322e6c52ebc1f63847eb8d1a56ca0570c8f7a243))
- remove DOM query for input values and updated error msg | ART-70475 ([42b4648](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/42b4648503e106efd4a69ec29f6b3cf6c6407229))
- remove getClassName() and fix code indentation | ART-70475 ([b6fd023](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b6fd02323934f86d0a69e576cc823f24c31c4f6f))
- removed default prop values | ART-70475 ([ec9ad38](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ec9ad38864048ff4d0587f44570d7f7a18afbc21))
- removed fieldRest | ART-70475 ([57479f9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/57479f9854db7cd550616d9137c3b14bb31c6542))
- removed fix width in InputGroup and set in div instead | ART-70475 ([a2c9a6f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a2c9a6f7e3f3d50fa46ac454ad966ea96e3b5b83))

## [1.187.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.186.5...v1.187.0) (2025-10-07)

### 🚀 Features

- add currencyAmount and reference fields to BeneficiaryDetailsObj | ART-75579 ([1aa7c8f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1aa7c8f1128a14787a06c98d2a48f551bfb67ff1))
- add LPS for BeneficiaryResponseObj and BeneficiaryRequestObj | ART-75579 ([d1979fb](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d1979fb0c58c39a85cdb38af95ac9117905c3614))
- add mv-apibeneficiarycreate package with modern controller architecture ([b1e5f99](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b1e5f990c6f69452677e23002ed2d04b3fd35c43))
- **ART-70353:** add missing swagger dependencies ([c62f961](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c62f961fb89762c6d64e3aa38fe12c1820eb86b3))
- **ART-70353:** update arrangement details swagger definition ([8b5da2e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8b5da2e0c81b8000cb1df8118f98cd0d7bdc1fa8))
- **ART-70353:** update mv-swagger script ([a35e7e2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a35e7e29fb16a08a580e8dbd93d9ebfe6854f869))
- **ART-70353:** update mv-swagger script ([4b17921](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4b179215619b6be6a76ba409def7cc1e4e892c89))
- **ART-70353:** update mv-swagger script ([ebbd707](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ebbd7075f6dd23e4505a3991198f7b669d5ead5c))
- **ART-70353:** update swagger def ([552a15d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/552a15dcb789d2839f06ab3ee569b4a7df599db0))
- **ART-70353:** update swagger def ([f4436ef](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f4436efa0f6265c35b2dc1df462462adabcb1a40))
- **ART-70353:** update swagger definition ([bfbbb8c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bfbbb8c1d8b43b3ee419329f1200de4c2e2c74ce))
- **ART-70353:** update swagger definition ([6160c0f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6160c0f998dbe42c1323a8fdf9d63ca42e7092e1))
- **ART-70353:** update swagger definition ([bfd07b0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bfd07b03fafbeff991c3f03fa9f1790fd510ab0d))
- **ART-70353:** update swagger definition ([afa07b4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/afa07b4c0d18ff596b067a1281584618e573146a))
- **ART-70353:** update swagger definition ([4e985fd](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4e985fd88aec7d0740316e968cdc263f643d94df))
- **ART-70353:** update swagger definition ([25114e3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/25114e3d1658f15baff701b79b5a6128476b5b2e))
- **mv-apibeneficiarycreate:** export detectInjectionVulnerabilityForBeneficiary and related types ([142e821](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/142e82118058f2625685e64e91ecbab0342c6f39))
- rename BeneficiaryDetailsObj and update references for fields | ART-75579 ([5f04557](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5f04557a06549728a23471699aca4038519e7d3d))
- update AmountObj to require currencyCode | ART-75579 ([4a06e34](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4a06e34978e8e7daea2b2d1d20e69fc033fdb078))
- update BeneficiaryStatus to include ON_HOLD option | ART-76897 ([ca0a068](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ca0a0687abbd6d5e67c25a20b39c25ef22d68efd))

### 💥 Bug Fixes

- add reference to validations | ART-74256 ([d545c07](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d545c07944a67e6245f18cee528113ca4b2b6848))
- adjust maxLength for Reference Field and endToEndIdentification | ART-75579 ([e377672](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e3776723d02fb589e250200d3e34467a6f672afd))
- merge Feb 2026 changes and update CreateBeneficiary type | ART-74256 ([e9df3c3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e9df3c33861b38bc607a0f3900134d093c0046fb))
- regenerate package-lock.json with correct dependencies | ART-74256 ([2e3940f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2e3940ffe2bc4fd1c23544b58005ca8305bb5053))
- update Beneficiary types | ART-74256 ([ab48cbf](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ab48cbf91770b79b933b97d3a79c7996093ed47a))

## [1.186.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.186.4...v1.186.5) (2025-10-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.186.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.186.3...v1.186.4) (2025-10-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.186.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.186.2...v1.186.3) (2025-10-07)

### 💥 Bug Fixes

- return loading as false if undefined ([2749351](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2749351431a175fece492691ea132b59f3b771ce))

## [1.186.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.186.1...v1.186.2) (2025-10-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.186.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.186.0...v1.186.1) (2025-10-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.186.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.185.2...v1.186.0) (2025-10-02)

### 🚀 Features

- add viewOptions in handleRaiseIntentParams | ART-76456 ([4b08072](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4b080725d9e6cfacac6b1e7deea1e62c7144f366))
- add windowtabkey | ART-76456 ([4a4cb0e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4a4cb0e522e408bd887c9193665b6fb0f560793f))

## [1.185.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.185.1...v1.185.2) (2025-10-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.185.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.185.0...v1.185.1) (2025-10-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.185.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.9...v1.185.0) (2025-10-01)

### 🚀 Features

- add common definitions for time and whole number | ART-75683 ([8196b40](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8196b4038ee7eed28d51e36e5cfed471f6483f9d))
- add script to retrieve build and dependency info | ART-46535 ([4e2cca9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4e2cca94f5fffa6f93d59e2ff612721b57ace67e))
- add support for multiple formats | ART-46535 ([2ca29e2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2ca29e2dade6eefd5a8dc16cdd9d142e656caf50))
- update mock token for account list api | ART-63785 ([7ec96fd](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7ec96fdc8554ac7df22444bded4151b41b163683))
- update test of account list api | ART-63785 ([89cfb63](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/89cfb638189680c4271a963729c8c65b1d28ab4d))

### 💥 Bug Fixes

- add descriptions | ART-75683 ([2db5020](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2db50208dc57a36af08914a04572618a7f1dd898))

## [1.184.9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.8...v1.184.9) (2025-09-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.184.8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.7...v1.184.8) (2025-09-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.184.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.6...v1.184.7) (2025-09-30)

### 🚀 Features

- add StartDate in mv swagger definition | ART-75854 ([6eb341a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6eb341a7c0a26ddcddf3a9d278108d794ba97cf4))
- update description | ART-75854 ([40f8292](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/40f8292e0ec6e9636270f3c4de77135d46a674f5))

## [1.184.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.5...v1.184.6) (2025-09-26)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.184.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.4...v1.184.5) (2025-09-26)

### 🚀 Features

- user permission update exp api related swagger update | ART-68173 ([9cbe9da](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9cbe9daf7b7f10d3be7e97e3a960b4c8b4a9a4d2))
- user permission update exp api related swagger update | ART-68173 ([9094e2b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9094e2b00832efe983149b1513cf6e214ade8b6d))

## [1.184.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.3...v1.184.4) (2025-09-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.184.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.2...v1.184.3) (2025-09-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.184.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.1...v1.184.2) (2025-09-19)

### 💥 Bug Fixes

- downgrade version | ART-53163 ([87deb20](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/87deb20285d49ec218ba28b4692a38e0080c3092))
- fix failing tests | ART-53163 ([6e8c510](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6e8c510bab6924123e91ebd3655c64a93275abe5))
- fix issues | ART-53163 ([4bd89b6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4bd89b62cbf9c809c6f8264a37ae301e0a9a946e))
- remove console log | ART-53163 ([54165ac](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/54165acb831cff66d1649b4d7551e86d51f49e44))
- update package lock json | ART-53163 ([a2c6144](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a2c6144144d8dfcd0932c08094e13dcc0a4bcda4))
- update types | ART-53163 ([09d237d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/09d237daa923ed605160e3039655f8c3585bdf09))

## [1.184.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.0...v1.184.1) (2025-09-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.184.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.183.0...v1.184.0) (2025-09-16)

### 🚀 Features

- added new constants to subtypes | ART-75298 ([3f069e9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3f069e9a310b0425d7b08ca6452f61b46a3dba8d))

## [1.183.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.182.7...v1.183.0) (2025-09-15)

### 🚀 Features

- include orgCisKey in GetAccountListFromPdp | ART-61915 ([a27ea3d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a27ea3d9ebc23e7fb660825003419ffac35cc75a))

## [1.182.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.182.6...v1.182.7) (2025-09-12)

### 🚀 Features

- add entitlementInformation to PaymentDetailsRequest | ART-74255 ([05b561a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/05b561abd24e6b98d5469554706e48762af10242))

### 💥 Bug Fixes

- updated header class for Currency col | ART-74291 ([cbfa768](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cbfa76847ba15ee37d76d8bcc0d7b48cd44b317b))

## [1.182.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.182.5...v1.182.6) (2025-09-10)

### 💥 Bug Fixes

- updated header alignment for Amount column | ART-74291 ([4a6e8e1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4a6e8e15598e66707cc2765f79f6ad60a88da731))

## [1.182.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.182.4...v1.182.5) (2025-09-09)

### 💥 Bug Fixes

- added header class for columns in beneficiary auth tab tables | ART-75221 ([f5fc84e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f5fc84e3afc982397279488452f23171d28f4570))

## [1.182.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.182.3...v1.182.4) (2025-09-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.182.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.182.2...v1.182.3) (2025-09-09)

### 💥 Bug Fixes

- update valueGetter and value Formatter | ART-74520 ([1e0d85e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1e0d85e293e71c2f0f8b47bef1de1188982709d5))

## [1.182.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.182.1...v1.182.2) (2025-09-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.182.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.182.0...v1.182.1) (2025-09-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.182.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.181.3...v1.182.0) (2025-09-08)

### 🚀 Features

- added iconSize and dismissible to alert component | ART-68971 ([2353b36](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2353b3667dfb57d1d91a0016404997256454e72e))
- added uni test case | ART-68971 ([44ca252](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/44ca2522aacb4f1bff75299e29f93e737e5e6cfe))
- authorisation banner component | ART-68971 ([8d55638](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8d55638bb38ac4a3afdbeef06b30560a2831d4e8))

## [1.181.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.181.2...v1.181.3) (2025-09-07)

### 🚀 Features

- **ui-galaxy:** update in payment request body | ART-74111 ([0bec31f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0bec31fdcec5cfc2ac980d97af10b2b274d4e17d))

## [1.181.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.181.1...v1.181.2) (2025-09-03)

### 🚀 Features

- add max length for ISG_APPROVED_STRING | ART-68197 ([f83bc4b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f83bc4b27c3adb6931c77f09aacbf05a58a51d13))
- add max length for STRING | ART-68197 ([9c119bf](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9c119bf73d3b3fe33cecfc437674c026f763f383))

### 💥 Bug Fixes

- updated mapping logic to include space between bsb and accnumber | ART-71494 ([b67f650](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b67f650174f7b489e6995ef13599b9c01bec0787))

## [1.181.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.181.0...v1.181.1) (2025-09-03)

### 💥 Bug Fixes

- improve currencyCode column definition for better header class handling | ART-73922 ([cedea4e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cedea4e20602d47164f412c0d4d4f21960ecc1d2))

## [1.181.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.180.1...v1.181.0) (2025-09-03)

### 🚀 Features

- add TypeScript definitions for enum exports | ART-73895 ([5506330](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5506330b7d653b7015b8e0b2ced83013c1e2c0e9))

### 💥 Bug Fixes

- build error | ART-73895 ([37f24c6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/37f24c6df61c20d06ba79541f531c987eaafa871))

## [1.180.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.180.0...v1.180.1) (2025-09-03)

### 💥 Bug Fixes

- enhance column definitions for improved header class handling | ART-73922 ([f3edcef](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f3edcef082efc653dcd16f29780eda9253313f05))

## [1.180.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.179.3...v1.180.0) (2025-09-02)

### 🚀 Features

- add channelId query parameter with enum values | ART-71511 ([5413a0a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5413a0a567ba91bb8a7b4fe0743668e8605bf1a2))
- add new badge (WIBDTW1-148) ([693bb94](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/693bb94f02f013d930bb5eff6f0f0d74847df564))
- move mv-constants enum to type file to fix import errors | ART-73895 ([cd8d397](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cd8d397bdb840dfe9bba0fed2456a6d00ca9c403))
- update version in lib package ([dc85874](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/dc85874bdd1ee1a97866afae29fb0f267721df9f))
- updated package name and removed pageSize sorting | ART-71494 ([44edd77](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/44edd775412d2361bd37f88b25de108b547fdaea))

### 💥 Bug Fixes

- updated package-lock | ART-71494 ([0c75e4a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0c75e4a257c7f4cd96871077b348624ae9258ee9))

## [1.179.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.179.2...v1.179.3) (2025-09-02)

### 💥 Bug Fixes

- added missing font-semibold class | ART-73922 ([bee0957](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bee0957e3edb6727e79399b84ec9bbca170c38e9))

## [1.179.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.179.1...v1.179.2) (2025-09-02)

### 💥 Bug Fixes

- enhance headerClass assignment for better styling flexibility | ART-73922 ([25d95b7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/25d95b774b762e68e06a881def55d5d0d0bd57e8))

## [1.179.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.179.0...v1.179.1) (2025-09-02)

### 💥 Bug Fixes

- remove duplicate so swagger.validate passes | ART-71494 ([706c5f0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/706c5f0ddf0fe8e970d817e0c4477211891949d3))

## [1.179.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.12...v1.179.0) (2025-09-01)

### 🚀 Features

- add account status definition | ART-67887 ([8db8e67](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8db8e67c189b51b98b711f05234a42060aa7b9c3))
- add account status definition | ART-67887 ([b4222db](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b4222dbccc1040c1720083ac253def1f684b0f11))
- add approval workflow types and subtypes | ART-73896 ([6ac3f6c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6ac3f6c36b65907d2fabda6e7784743857d41a2a))
- add approvalWorkflow types and subtypes | ART-73896 ([9552b53](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9552b53258d5dd04111035355dd3188249f44b12))
- add FinancialYear definition and year query param | ART-70346 ([e9c9621](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e9c96215cf184395063994cc139666144b51800a))
- add new apiarrangement package | ART-71494 ([91f6cbd](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/91f6cbd5691c7c2082f9d4286bec94ccf7b2827c))
- added AccountStatus |ART-71494 ([17607a8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/17607a892d30469cffd080bc0e9228e1a9db3cce))
- update approvalworkflow type | ART-73896 ([bb3cf91](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bb3cf91f90dc86090cab8e49345ad5bd0c89acd7))
- update status enum in swagger | ART-71494 ([4ce1e63](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4ce1e63c79680d06c16bf2591153a647bcfda0c7))
- update workflowRequestIdPattern pattern | ART-69084 ([c400e6d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c400e6d0f0b8559295434035126d0794dd2d3088))
- update workflowRequestIdPattern pattern | ART-69084 ([e67ebc6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e67ebc68c29b5ca419f89dff9cf2486342d74053))
- updated accountlistObject references | ART-71494 ([bbb4d61](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bbb4d61c696edfe771878e0cad0b358bc86ca97a))
- updated apiarrangements package | ART-71494 ([b764aed](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b764aed77e81d5b7d5a6e4aef77b7ea92b547ec5))
- updated definitions | ART-71494 ([2df9e79](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2df9e79903d655879813a5a782c20e50e7cfb307))
- updated lock file + transformAccountLists function | ART-71494 ([98b00f7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/98b00f75cb062653e2ce1219e4db68c1b8a6eb0c))
- updated mv-swagger to added new accountListObject + general definitions| ART-71494 ([e26284a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e26284adf25af11c85ea3299ff5b307a05a1aa7c))
- updated tsx file to ts | ART-71494 ([7c6059e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7c6059ec9bfc1a43cf78ffb07f717a9202acd3ac))
- updating accountType | ART-71494 ([0d9a88d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0d9a88dd04e2a262e8d02ea051f8e62842ee5a71))

## [1.178.12](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.11...v1.178.12) (2025-08-20)

### 🚀 Features

- added description to channelReqId | ART-71277 ([ffe889a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ffe889a67fa054754e06ba7e8f8298595e2d2497))
- updating description | ART-71277 ([f6140a3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f6140a3d22580ada2b44e18c4a632dd4aee5277d))

### 💥 Bug Fixes

- changed channelRequestIdPattern to 15 minimum | ART-71277 ([745e555](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/745e555b553b9fe2dbdd22a13fe29936a87b1ea6))

## [1.178.11](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.10...v1.178.11) (2025-08-19)

### 🚀 Features

- move group id and group name into mv lib | ART-68560 ([6f6885a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6f6885ae5ad84610690b954dbf1cede4cf051fcc))
- update according to PR review feedback | ART-68560 ([75599b3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/75599b3ed6f8c103732be458b31bab038e6cb9f3))
- update according to PR review feedback | ART-68560 ([ab788cf](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ab788cfe6978047b7c2c1a3789ccad2aaa3670e4))
- update account group name and using DEFAULT_STRING | ART-68560 ([2d939d1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2d939d1c459f3aedec902078f73fcae3797c1be9))
- update example value | feature/ART-68560 ([494ed2d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/494ed2d72a1a6daf24e67cb91bc2fcff966d46f7))
- update example value | feature/ART-68560 ([4b1c16b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4b1c16bc8e9328a3913061be16342965922a2521))

## [1.178.10](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.9...v1.178.10) (2025-08-18)

### 🚀 Features

- add to mv-swagger | ART-69084 ([1394943](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/139494302d5b3ce92d697f6eb1d645926e82cda8))
- update workflowRequestIdPattern pattern | ART-69084 ([e35ea43](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e35ea430181dd711760766823fca66106b2dfcba))

## [1.178.9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.8...v1.178.9) (2025-08-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.178.8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.7...v1.178.8) (2025-08-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.178.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.6...v1.178.7) (2025-08-13)

### 🚀 Features

- add BeneficiaryId definition with UUID reference | ART-70090 ([2af253e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2af253ea232a5abedbcf2629ba9f2e124bd02fa3))

### 💥 Bug Fixes

- wibdtw1-2203 re run build ([4692bcc](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4692bcc8c5893a6553541f05648f5b132996bffe))

## [1.178.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.5...v1.178.6) (2025-08-13)

### 💥 Bug Fixes

- wibdtw1-2203: remove active background colour ([1861d23](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1861d23e3f24fbed9ca7868c3727931fd59363fb))

## [1.178.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.4...v1.178.5) (2025-08-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.178.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.3...v1.178.4) (2025-08-12)

### 🚀 Features

- add common swagger defs ([ae02389](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ae02389283b4885ad37fc770838d72b4769e4d8b))

## [1.178.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.2...v1.178.3) (2025-08-12)

### 💥 Bug Fixes

- change paragraph to div for value rendering in MVDetailSection ([0a80123](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0a80123de3042074d8bb139e9075517e0205dc5c))

## [1.178.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.1...v1.178.2) (2025-08-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.178.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.0...v1.178.1) (2025-08-12)

### 🚀 Features

- add common swagger defs ([05cbb2d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/05cbb2da1ad5437dfd0044884daf499a7319718b))

### 💥 Bug Fixes

- wibdtw1-2203 remove open option and change types ([908b251](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/908b2513f94adbe8cefdef5e5d2cb885f8bf306f))

## [1.178.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.177.2...v1.178.0) (2025-08-11)

### 🚀 Features

- add bottompadding prop | ART-61028 ([9c4b210](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9c4b2102eadd944f41488807fd15fd13838bc1ec))
- update mv-swagger with 401 response | ART-61623 ([b249240](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b2492409bc9bc9a067cee675ecae8b45db76cc7e))

## [1.177.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.177.1...v1.177.2) (2025-08-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.177.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.177.0...v1.177.1) (2025-08-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.177.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.176.0...v1.177.0) (2025-08-11)

### 🚀 Features

- make second autocomplete item optional | ART-68405 ([99357e5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/99357e53185115f632ca08ffe8d6e53f25dc520c))
- make third autocomplete item optional | ART-68405 ([360a456](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/360a4567c32d77a0367ccbd447866b6e50ca4792))
- wibdtw1-2203 active state bg colour ([282916a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/282916a338d939f3d2bd438cb61422c384e7c930))

## [1.176.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.175.0...v1.176.0) (2025-08-08)

### 🚀 Features

- wibdtw1-2203 retrigger build ([0dea939](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0dea939b65534c33b941dc97441bd48d41a8e71b))

## [1.175.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.174.1...v1.175.0) (2025-08-08)

### 🚀 Features

- wibdtw1-2203 add correct imports ([bcf1cf6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bcf1cf6404046cbd2aad8d5983e93fb2bd8add34))
- wibdtw1-2203 add types to library ([9ef9e57](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9ef9e57dd9fe9647d1b0e2548bba5bfe604338cf))

## [1.174.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.174.0...v1.174.1) (2025-08-07)

### 💥 Bug Fixes

- update function description | ART-68532 ([d9a59bc](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d9a59bcfc2441e7f0199afb353cbd7543d5fab5a))

## [1.174.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.8...v1.174.0) (2025-08-07)

### 🚀 Features

- created a constant string for access control expose headers | ART-68532 ([2990838](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2990838f3fc455528fc9ff861ae75f3d6b992fd8))

## [1.173.8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.7...v1.173.8) (2025-08-06)

### 💥 Bug Fixes

- wibdtw1-2203 pass state to consuming repo ([c31b6d8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c31b6d88e11eafd90cb3dbf96cd718aede80fb2a))

## [1.173.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.6...v1.173.7) (2025-08-06)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.173.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.5...v1.173.6) (2025-08-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.173.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.4...v1.173.5) (2025-08-05)

### 🚀 Features

- removed entitlements, updated channelReqId pattern | ART-68527 ([ff783c5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ff783c5a9871e32deb63d6d9bf23c5bba1cd3303))

## [1.173.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.3...v1.173.4) (2025-08-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.173.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.2...v1.173.3) (2025-08-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.173.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.1...v1.173.2) (2025-08-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.173.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.0...v1.173.1) (2025-07-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.173.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.172.2...v1.173.0) (2025-07-30)

### 🚀 Features

- add cvs injection protection to mvtable cvs export | ART-68911 ([ab37d17](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ab37d173a8e1b1eba854b20179da5aa9f193ad88))
- added new header parameter which is used while authorising the request in make checker mfe | ART-61251 ([bb32d38](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bb32d38ad8cb810273d656be9e781098568106d1))

### 💥 Bug Fixes

- pattern fix | ART-61251 ([fab1b77](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fab1b77c3cbc1e586b5ae17194f8c29e3480946d))
- removed length property to resolve validate issue | ART-61251 ([7168cdd](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7168cdd351a801635045c8a48b997a5889c7aab8))
- updated channel request id pattern | ART-61251 ([702e2fd](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/702e2fdcd4ddf8f6abc83ac9381b9ad6f46f29b6))

## [1.172.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.172.1...v1.172.2) (2025-07-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.172.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.172.0...v1.172.1) (2025-07-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.172.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.171.8...v1.172.0) (2025-07-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.171.8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.171.7...v1.171.8) (2025-07-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.171.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.171.6...v1.171.7) (2025-07-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.171.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.171.5...v1.171.6) (2025-07-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.171.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.171.4...v1.171.5) (2025-07-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.171.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.171.3...v1.171.4) (2025-07-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.171.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.171.2...v1.171.3) (2025-07-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.171.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.171.1...v1.171.2) (2025-07-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.171.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.171.0...v1.171.1) (2025-07-22)

### 🚀 Features

- remove unused swagger | ART-66819 ([fd253b6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fd253b656cfd64b5cffce750d31b3a8b5b41e156))
- update mv-swagger for protected orgId | ART-66819 ([0ef240b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0ef240bcb8d70a52f842ed9c494b76090758736b))
- update the Org Cis | ART-66819 ([dba9a2b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/dba9a2b59ed85da33df9843870c9751cffb64eba))

## [1.171.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.170.1...v1.171.0) (2025-07-21)

### 🚀 Features

- created getAppUrlWithoutParams() for entitlement error nav | ART-68385 ([e37532c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e37532cc349eb31f38e4752d8c67ef81d4564392))

## [1.170.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.167.2...v1.170.1) (2025-07-19)

### 🚀 Features

- changed the pattern and. max length of BeneficiaryOrg | ART-66819 ([34de8c3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/34de8c3b70ed20f487504dc70a6715e7c843f644))
- changed the pattern of BeneficiaryOrg | ART-66819 ([0bc8d7c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0bc8d7c3d6c54f4512d70a2ef8881190eb8528e5))
- updated pattern of BeneOrg | ART-66819 ([31dd11d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/31dd11d571b025cd344ff147fef9ae8a91958b1b))

## [1.167.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.166.1...v1.167.0) (2025-07-18)

### 🚀 Features

- wibdtw1-1879 adds missing prop ([b0d3580](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b0d3580a4b50e4c1430716b0b9aef86f14fbe02a))

## [1.166.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.166.0...v1.166.1) (2025-07-18)

### 💥 Bug Fixes

- add 10x key to the context | ART-68038 ([ed85999](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ed85999750c03e700e267f3c749d0c7685b996a3))
- obtain ciskey if context key is not present | ART-68038 ([e9329a7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e9329a7311e620036cbeca5d9252a26ef9b5beaa))
- spread the pageContext into global context | ART-68038 ([497ebb5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/497ebb576b619b0686f655b6a205e339259569b8))

## [1.166.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.165.0...v1.166.0) (2025-07-18)

### 🚀 Features

- wibdtw1-1879 changes to props and stories ([61db31d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/61db31d44fd460316ec621361d16540f5a12bc09))

## [1.165.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.164.0...v1.165.0) (2025-07-17)

### 🚀 Features

- wibdtw1-1879 allows more flexibility for the user ([31b04d9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/31b04d98429f612e1f0d4aac4d3e8d5ee6cbbced))

## [1.164.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.163.1...v1.164.0) (2025-07-17)

### 🚀 Features

- wibdtw1-1879 adds toggle open config ([ec072c7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ec072c7fbec03374f7065b9d4c4419c50f8ce148))

## [1.163.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.163.0...v1.163.1) (2025-07-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.163.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.162.0...v1.163.0) (2025-07-17)

### 🚀 Features

- add dateRangeString() ([0d30598](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0d30598ac833493f4954b2d886769e5bedbae59c))

## [1.162.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.161.1...v1.162.0) (2025-07-17)

### 🚀 Features

- **ART-51863:** update swagger reference ([db0eb1c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/db0eb1ce2282cc74080b2d145f4a342a6a6d47e6))
- fix ref error and improve shared definitions | ART-57958 ([0a18975](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0a1897532b5565d44cf3aff3125a3cc1652b6ea0))
- updated test to pass | ART-67994 ([afb4048](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/afb4048b20b1b7a75eba2efe12cb10a670020532))

### 💥 Bug Fixes

- add missing mesh header params to mv-swagger | ART-57958 ([5f6b7a5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5f6b7a572eca96af035975b5c45fa145e9d86407))
- added getAppURLWithParams to error path | ART-67994 ([8aedfb3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8aedfb385cd09a4285e22bda3e0854f41add94e8))

## [1.161.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.161.0...v1.161.1) (2025-07-16)

### 💥 Bug Fixes

- button group controller default value bug | ART-67809 ([ebaa017](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ebaa0172dc61836666cbe586c25918ae289df00c))

## [1.161.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.160.4...v1.161.0) (2025-07-14)

### 🚀 Features

- updated MVPageLoader | WIBDTW1-2513 ([d91ad71](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d91ad710843e9ac8bfd94bec81130612f5a0e953))

## [1.160.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.160.3...v1.160.4) (2025-07-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.160.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.160.2...v1.160.3) (2025-07-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.160.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.160.1...v1.160.2) (2025-07-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.160.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.160.0...v1.160.1) (2025-07-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.160.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.159.0...v1.160.0) (2025-07-11)

### 🚀 Features

- check openFin env in withIntent | ART-66590 ([2452722](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2452722ad07bea483d9eebf52ea6df9892a4767d))

### 💥 Bug Fixes

- format forbidden characters | ART-54463 ([4198743](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4198743217a582e7798081372104b7c9c062daa4))

## [1.159.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.158.0...v1.159.0) (2025-07-10)

### 🚀 Features

- add missing fields in PaymentDetailsRequest | ART-54463 ([f49e9cb](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f49e9cb5e00de66594fa0868117b1df03e1832c6))
- Add onFilterChanged handler to MVTable | ART-66114 ([9db40b1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9db40b1064ec9b28f3ec1f48ec2e98b0789cd093))
- update support browser in withIntent | ART-66590 ([9589d6c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9589d6ca7756dc6d990ae10a5a881e6958922912))
- update the regex pattern of beneficiaryId | ART-54463 ([0c1fd96](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0c1fd96446040ed1ce5357cb78872dcc926d6597))
- update the swagger of the beneficiaryId | ART-54463 ([a1a8ddc](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a1a8ddcd31484cc47e923f9e9cad3d0f15e76adf))

## [1.158.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.157.0...v1.158.0) (2025-07-09)

### 🚀 Features

- add isStatic and tableHeight params to be more readable | ART-54678 ([03de91f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/03de91f8fbe31b819018de89581e39b08fd1ad8d))

## [1.157.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.156.2...v1.157.0) (2025-07-09)

### 🚀 Features

- save orgID from pageContext to redux store | ART-66590 ([c7f1e37](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c7f1e3752b8d8110e1482dc88aa6c10b1f17291a))

## [1.156.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.156.1...v1.156.2) (2025-07-08)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.156.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.156.0...v1.156.1) (2025-07-08)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.156.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.155.0...v1.156.0) (2025-07-07)

### 🚀 Features

- added react import and use this to replace params | ART-66589 ([5f8468b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5f8468b67d45cf7e29eb0b2a62367b522bd01814))

## [1.155.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.154.0...v1.155.0) (2025-07-07)

### 🚀 Features

- field validations august uplift swagger fix beneorg desc | ART-54463 ([833ef38](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/833ef38e0642e2b5b655d70a47b516f1ab48cfe5))
- implement the loading field from openFin hook | ART-66589 ([c17bc1b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c17bc1b8c2808ce8183abfc1d60a109b5ebae6e5))
- make groupId param more generic | ART-57958 ([bdcf611](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bdcf6119bd765717bb8869825ca1fb58a1f6d37a))
- migrate additional common elements to mv-swagger | ART-57958 ([93ee5b8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/93ee5b839da24fa92cf43ef421534576c25ae505))

## [1.154.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.153.0...v1.154.0) (2025-07-03)

### 🚀 Features

- update text color in MVAlert component for better accessibility ([0b46b1f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0b46b1f209658bd068619c1578de2dd297a96965))

## [1.153.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.152.0...v1.153.0) (2025-07-03)

### 🚀 Features

- add 'system' type to MVAlertType for enhanced alert categorization ([8e06b93](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8e06b9393bf92380b4fef75451718bda9413d3a5))
- add MVAlert component with customizable properties and update README ([0800937](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/08009375c93c1f9bfb57f42a946ae259cdd9be86))
- build MVAlert component ([58e0dd8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/58e0dd89c5549d934d5da6d068c47e03f69f2715))
- enhance MVAlert component with new 'system' type, improved styles, and additional stories ([10c082c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/10c082cfe34b64c78a91429b3878f4e3d0c46b2b))
- field validations august uplift swagger | ART-54463 ([093e2a2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/093e2a2fc28b45120b6a3c969ec8283b41009369))
- field validations august uplift swagger | ART-54463 ([4cf177d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4cf177d9b9371895d218a39ce0928ec128e87ae9))
- field validations august uplift swagger and library changes | ART-54463 ([bd84e4a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bd84e4ad4347b94013ffcc243d046d89c2c1d2e0))
- field validations august uplift swagger and library changes | ART-54463 ([8b47a8e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8b47a8eb20a5e1bf77e21fcaf797422735443bca))
- field validations august uplift swagger and library changes | ART-54463 ([d9c00c5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d9c00c54fdb9620a5863e62194bdbf1c53d08b3f))
- field validations august uplift swagger and PR changes | ART-54463 ([d0a737c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d0a737c0bf122b17539b2e25d9e0de0a6753dbbc))
- updated heading props in libraries ([af26870](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/af26870f3205ae5509e25d9ef7f7e98b5bc5a0f6))
- wibdtw1-1494 new widgets for alert ([21c2021](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/21c202184e08ee8d1b66386bfd12942fb055ebbb))
- WIBDTW1-1494 new widgets for alert ([6d4d573](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6d4d57338316021f9a559f0d69efdc0880f72712))

### 💥 Bug Fixes

- regenerated package-lock file for build failure issue ([165d9ba](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/165d9ba23d4d5b1aa6ffdab0e9e636b0a2a68afc))

## [1.152.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.151.3...v1.152.0) (2025-07-03)

### 🚀 Features

- added top and bottom 24px margins + gave isStatic and height to mvtable params | ART-58868 ([2eb4d92](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2eb4d9298993715f19aab05637858ff698005986))

## [1.151.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.151.2...v1.151.3) (2025-07-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.151.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.151.1...v1.151.2) (2025-07-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.151.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.151.0...v1.151.1) (2025-07-01)

### 🚀 Features

- add amount with negative and fix BSB example | ART-57958 ([6089571](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6089571f5caf29c350ab67eaeffbf4892734f80a))
- add beneficiary details schema | ART-64647 ([712b432](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/712b4321dd99d49db8cf9b1ddc887ebc767366d0))
- refactor amount string definitions | ART-57958 ([650d048](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/650d048b0a78596edcb046034af5a744c9282073))
- update beneficiary swagger spec | ART-64647 ([07d5507](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/07d5507cdc23d89292b1cd40a73bc72210425756))

## [1.151.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.150.1...v1.151.0) (2025-07-01)

### 🚀 Features

- **art-15153:** update clientContext to required ([04b82a7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/04b82a7e25c879e02bce55f19923cc26f10e5190))
- upgrade mep-node and nx/react packages to fix Snyk issues ([18bf179](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/18bf17965f2d9f19cbb9037e7f09a1fac0b40a73))

## [1.150.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.150.0...v1.150.1) (2025-06-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.150.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.149.0...v1.150.0) (2025-06-27)

### 🚀 Features

- added condition in withIntent component | ART-65316 ([ede477f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ede477fde61b082c661bb193c4804b45fa68cb92))
- more update according to review feedback | ART-58898 ([1b1ee19](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1b1ee19a6923b6865dc6110e4bd2d91ce08af51e))
- more update according to review feedback | ART-58898 ([c1301d7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c1301d78d3cdac934690d51d17f940a766eee0c7))
- more update minLength and maxLength | ART-58898 ([9495719](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/94957198aa3b66488825c84e0691598e5f368ffc))
- more update with missing definitions | ART-58898 ([e006980](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e006980fd4726fc42ea2e164dc675c7d98ed980f))
- more update with missing definitions | ART-58898 ([c3b50ff](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c3b50ffc64448d9cf96aea268a97b9beee1d0276))
- more update with missing definitions | ART-58898 ([5ddab0f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5ddab0f9bd1402cbead2dc46fa63479fa21a1f36))
- more update with missing definitions | ART-58898 ([ae4c7f9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ae4c7f94c7a16842c449defa8315e942a74c1d7a))
- more update with missing definitions | ART-58898 ([8321d1a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8321d1ac30af30f371aa32c5e1fdbdbdb22cfc7d))
- update example | ART-58898 ([e9e8443](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e9e84437a69fc16b04fa3d81f76123ae1a7e2a2e))

## [1.149.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.148.0...v1.149.0) (2025-06-26)

### 🚀 Features

- added 24px padding to MVCard | ART-58868 ([b294030](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b294030fd5f0d1ddeaf4fceeff64d5de370f0a29))

## [1.148.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.147.2...v1.148.0) (2025-06-25)

### 🚀 Features

- add AccountDetailFilter into definitions, was in common folder | ART-58898 ([52a4983](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/52a49838a00c0cf1da50be2e4f78ac398776e997))
- add entitlements into definitions | ART-58898 ([97f74e4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/97f74e4b879a0702eec229e45fdc2c4c61e93166))
- add entitlements into definitions | ART-58898 ([883446c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/883446c675df3f57fa5a34383110a619a8b73feb))
- more update | ART-58898 ([f2d5fc0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f2d5fc06493699891a676c2ccc5eacdcac5faef7))
- more update | ART-58898 ([fec1368](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fec136802c46ef39e7c9ee4c3d99e74acccb7ae9))
- remove checking data before updating intentTimestamp | ART-60783 ([22e12f2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/22e12f2ef3702db684c33f23ee991917be4a1d85))
- remove entitlements from definitions | ART-58898 ([0c54cb8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0c54cb813518063dab8bd963fa416d3056e81a46))
- remove name_string, emoji_string and instead of by ISG_approve_sting | ART-58898 ([12b80e0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/12b80e0ca5d7aed23c28640624bda2ea270a9ad3))
- update according to review feedback | ART-58898 ([7a6d179](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7a6d179715f53749a737960b015b91b187144cc8))
- update AccountDetailFilter using ISG approved string | ART-58898 ([e5d7983](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e5d7983054b2d4237873c93540949fee532cb55e))
- update BeneficiaryNickname using name string | ART-58898 ([4bbba07](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4bbba076ac050c2c1bd6d6ccf273467ac74688ae))
- update BsbAccountObj in mv-swagger | ART-58898 ([8786398](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/878639810b431a42a4968a24989af2686c0de26e))
- update bsbaccountobj to bankdetails | ART-58898 ([5ae102e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5ae102ea600fa5de5124cec3c8b29aa122697fcb))
- update PayIDValueTeli with '-' as optional | ART-58898 ([0e8f6a3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0e8f6a321603170e2032e147551960e09c2ee457))

### 💥 Bug Fixes

- resolve data sync issue in redux store and component | ART-60783 ([31eb09a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/31eb09a3602140db35951a4a2ede771ca6c607a1))
- show page loader if shouldWaitForGalaxyContext is enable | ART-60783 ([3d49b6e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3d49b6e7b7266c98d09c883a94707722cb0794d0))

## [1.147.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.147.1...v1.147.2) (2025-06-19)

### 💥 Bug Fixes

- adding ISG approved pattern | ART-58848 ([ec30877](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ec308774b36eaf019db33c3b4ea85b2ccf593a9d))

## [1.147.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.147.0...v1.147.1) (2025-06-18)

### 🚀 Features

- add BeneficiaryOrg in yaml ([fb74320](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fb743204cce62dfc4c36b32a22a760ff8ebe8c06))
- use ISG_APPROVED_STRING ([95fe4ad](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/95fe4adc4b93f05562dcd88810ab8aa7b59cc17d))

### 💥 Bug Fixes

- evaluating perfectexpressSanitizer on-payment details page ui | ART-49958 ([422ddf9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/422ddf97ac445a55c9495d990117569f9c1664d7))

## [1.147.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.146.0...v1.147.0) (2025-06-16)

### 🚀 Features

- evaluating perfectexpressSanitizer on-payment details page ui | ART-49958 ([64859ca](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/64859ca948435f2ea6f2b2910d37426ae17cb019))

## [1.146.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.145.0...v1.146.0) (2025-06-16)

### 🚀 Features

- update index.d.ts ([dfa45fa](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/dfa45fa9a43b55615ff7cd38d6ec88fb70b9f2d4))

## [1.145.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.144.1...v1.145.0) (2025-06-16)

### 🚀 Features

- add BeneficiaryIds in yaml ([3cb7160](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3cb71600d02192fa000f1a0dbc53b650e83f1ea7))
- add BeneficiaryIds in yaml ([4f0ebb9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4f0ebb91a2728426f335ccf0b4c9c0f2056e9fe3))
- add BeneficiaryOrg in definitions.yaml ([e7cf1f6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e7cf1f670dd86b2c6de2093aacb294c31679d101))
- add description of BeneficiaryIds ([6ba0514](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6ba05147778151c7121f9c0e1123f77ec76ae594))
- add requestAction ([f22b25c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f22b25ca9441cbdb56b2a44fb87f60d25c81a14f))
- remove export ([ec63134](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ec63134acfab76b673cf6eb199c2a0b3ed398dc8))
- update index.d.ts ([3cde9fd](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3cde9fd91bd21608413c35ae1a42fac72de083f0))

## [1.144.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.144.0...v1.144.1) (2025-06-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.144.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.143.0...v1.144.0) (2025-06-12)

### 🚀 Features

- fix loading icon position issue ([eea6149](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/eea614941d41ebb220d88898333a7c10ada99281))

## [1.143.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.142.0...v1.143.0) (2025-06-10)

### 🚀 Features

- mv card fix width for longer headings ([3823564](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/382356490182d98fe70e3eeaf7411b53e62abc2c))
- mv card fix width for longer headings with subtitle ([328bad0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/328bad0c8b35c03860db68e6e56cc00563c4ff55))

## [1.142.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.141.0...v1.142.0) (2025-06-10)

### 🚀 Features

- tiny update handleApiService ([9552238](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/955223857cc12b94c964dc3ab14dd2c004d571c8))

## [1.141.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.140.0...v1.141.0) (2025-06-06)

### 🚀 Features

- extend perfectexpresssanitizer to handle template injection | ART-54837 ([c422b02](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c422b02ed5cde5c4ab19021b3cdd2cc458531183))

## [1.140.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.139.1...v1.140.0) (2025-06-05)

### 🚀 Features

- add intentTimestamp in the withIntnet hoc | ART-58610 ([2f824a6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2f824a65e980afdf75769b2d5f9b7e8195f6caa4))

## [1.139.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.139.0...v1.139.1) (2025-06-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.139.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.138.2...v1.139.0) (2025-06-03)

### 🚀 Features

- remove NaN check | ART-47786 ([c34f989](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c34f9894e17d28cdad11ef57648cbad89bc2242e))

## [1.138.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.138.1...v1.138.2) (2025-06-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.138.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.138.0...v1.138.1) (2025-06-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.138.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.137.3...v1.138.0) (2025-05-30)

### 🚀 Features

- WIBDTW1-1748 update aria label ([924db9d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/924db9d1503c66dc65a29ac6d51e1968b65506dd))

## [1.137.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.137.2...v1.137.3) (2025-05-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.137.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.137.1...v1.137.2) (2025-05-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.137.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.137.0...v1.137.1) (2025-05-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.137.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.136.0...v1.137.0) (2025-05-27)

### 🚀 Features

- update readme | ART-43405 ([49ec37e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/49ec37e964740d47489368f4d393d2c3e8a845e5))

## [1.136.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.135.0...v1.136.0) (2025-05-27)

### 🚀 Features

- comment out getValuesByPdpQuery | ART-43405 ([be1aad7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/be1aad7932b39282c305342b4ba0a66593f1e1fa))
- webpack version revert | ART-43405 ([8763c04](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8763c04ec99b0264f87981d93dc48d59512d410e))

## [1.135.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.134.1...v1.135.0) (2025-05-27)

### 🚀 Features

- update mvselectcontroller width full issue | ART-43405 ([8741943](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8741943749ddb11a29c0f09279288f7e21643e2e))

## [1.134.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.134.0...v1.134.1) (2025-05-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.134.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.133.0...v1.134.0) (2025-05-23)

### 🚀 Features

- change default pageSize to 500 | ART-47786 ([1e0ce26](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1e0ce26d9930d02723eb8da1469dfd8264e31d54))
- refactor | ART-47786 ([d8713b6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d8713b60f9b0495dfee6ca96d025b9c9ac7e7c5f))
- refactor and add accountName | ART-47786 ([318bb61](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/318bb61186d8d5d30352452f31a6068f976447cc))
- set default pageSize to 1000 | ART-47786 ([7d6359b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7d6359b137ba58cc1e8e5d232c366c13c992714a))
- split functions to get permitted account list | ART-47786 ([deca3fd](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/deca3fd289164aaa51d0e0239fe49a12a3f655ca))

## [1.133.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.132.0...v1.133.0) (2025-05-22)

### 🚀 Features

- create getValuesByPdpQuery ([2a2c806](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2a2c806794c791958401ae2a99ce35a47efadfa0))

## [1.132.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.131.0...v1.132.0) (2025-05-20)

### 🚀 Features

- update type definitions | ART-50141 ([0a4f0b0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0a4f0b01dc167c35d7502d8593798355959845f4))

## [1.131.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.130.0...v1.131.0) (2025-05-20)

### 🚀 Features

- slice before map | ART-50141 ([88dc499](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/88dc499bcae7efcde31e8d3b6fb93d4db420f94a))
- update transformAccountList to support sort and limit params | ART-50141 ([feb25ba](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/feb25ba0d18c3c35b62d8e07d8b2eb25af39efb4))

## [1.130.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.129.0...v1.130.0) (2025-05-14)

### 🚀 Features

- tiny changes to remove useless code ([3a71b49](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3a71b49a339e52ea594391bece12b4a8ccb714dc))

## [1.129.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.128.0...v1.129.0) (2025-05-14)

### 🚀 Features

- revert ([d698882](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d69888287a95fe1c2514fde9565b413c8155e01f))
- tiny changes for clear button ([6664f48](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6664f489ad9dc7e8d810863f069e9473b9c12f11))

## [1.128.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.127.0...v1.128.0) (2025-05-14)

### 🚀 Features

- update useAutocompleteWrapper ([014726b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/014726b3f2db40f554cb86d76f973a7ce594879b))
- update useAutocompleteWrapper ([87595c8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/87595c884484cc0cbc20bbe85ad5fcdac58ad52c))

## [1.127.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.126.0...v1.127.0) (2025-05-13)

### 🚀 Features

- updated code for onChange function | ART-53954 ([2d5c8e5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2d5c8e524a84de04b400747749df815b8f5b4aa2))

## [1.126.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.125.0...v1.126.0) (2025-05-13)

### 🚀 Features

- WIBDTW1-622 update keydown handling ([6b087c0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6b087c08c6f2621a72bb04937503e1c3d93bbc5f))

## [1.125.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.124.0...v1.125.0) (2025-05-09)

### 🚀 Features

- added new package notificationalert | ART-41399 ([6518b65](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6518b65395584fefbc5c735f3662c40585ec42bf))
- revering the raiseIntent changes in index.d.ts | ART-41399 ([6c2ecd9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6c2ecd9a168eab4886dc3013974caffe395d4f54))

## [1.124.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.123.0...v1.124.0) (2025-05-08)

### 🚀 Features

- add default css class to MVInputController | ART-53975 ([265ff56](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/265ff562be39abcfac59a4246ef155fb348b843c))

## [1.123.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.122.0...v1.123.0) (2025-05-08)

### 🚀 Features

- add the intentId definition | ART-52229 ([b8c64f3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b8c64f362c8c38dd36d4c82203c803c6bdd81689))

## [1.122.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.121.0...v1.122.0) (2025-05-07)

### 🚀 Features

- added focusIn and focusOut events to close dropdown ([7749c22](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7749c22cf98028b71ebe1db79c96bab77d14509f))

## [1.121.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.120.0...v1.121.0) (2025-05-07)

### 🚀 Features

- update table with GridApi remove onGridReady as unused | ART-46688 ([9d0a138](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9d0a13855f065ae510e74970cd02778f226f2df5))
- update table with GridApi | ART-46688 ([f9fddcf](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f9fddcf903cf154bec08e266cbed9388ca3bc8ae))

## [1.120.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.119.0...v1.120.0) (2025-05-07)

### 🚀 Features

- implement sql sanitisation level 5 in perfectExpressSanitizer | ART-50081 ([bf2323a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bf2323a8511533afc7bb9d0654e8745766b260a4))

## [1.119.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.118.0...v1.119.0) (2025-05-06)

### 🚀 Features

- art-47193 update transform pdp query result util ([1834b21](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1834b21394b84d25e5d242ba4e4d9f33d211687d))
- art-47193 update transform pdp query result util ([591aa18](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/591aa18dd460c8a53a12cf61889a8e92fc3e98de))
- art-47193 update transform pdp query result util ([c516ae2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c516ae23b0c5171ac08ebbf801bdd6a8c7e0fa96))
- art-47193 update transform pdp query result util ([1fcc517](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1fcc5177ab5d5ce3b0a52bf7dba396295bc69b5e))

## [1.118.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.117.1...v1.118.0) (2025-05-06)

### 🚀 Features

- art-47193 add transform pdp query result util ([4f688c5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4f688c57446be677980d176a39df0cd94705d63c))
- art-47193 add transform pdp query result util ([16f76eb](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/16f76eb170340a91276ba4f28908fb5d30ba0762))
- art-47193 add transform pdp query result util ([f08d5d4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f08d5d489fc09ce2b213962e354d9d7113f20440))
- art-47193 update transform pdp query result util ([5f2527e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5f2527e4dad4409761ee6b68b0073206d0f89871))
- art-47193 update transform pdp query result util ([ceedf2f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ceedf2f282ef95ab5afa328d176279156de639e8))

## [1.117.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.117.0...v1.117.1) (2025-05-06)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.117.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.116.7...v1.117.0) (2025-05-02)

### 🚀 Features

- updated component for Icon styling ([cd14923](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cd149236fbbab07b83ee009450422c3e9fbdcdc2))

## [1.116.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.116.6...v1.116.7) (2025-04-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.116.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.116.5...v1.116.6) (2025-04-30)

### 💥 Bug Fixes

- moving suppression to above spread operator | ART-53758 ([655df7b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/655df7b97e75995313b31a8c4c4b6012602b3836))
- removed suppressHorizontalScroll | ART-53758 ([b7eab43](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b7eab431dad091513a7e692ffbf8340449487f90))

## [1.116.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.116.4...v1.116.5) (2025-04-30)

### 💥 Bug Fixes

- external library types | ART-53543 ([85b6b59](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/85b6b596595fa46ca391ea5bba4f15e3bd5ace01))

## [1.116.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.116.3...v1.116.4) (2025-04-30)

### 💥 Bug Fixes

- export module + rename function to differ from type | ART-53543 ([ddb0206](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ddb02061424bb51d89de65110dfff001a950c278))

## [1.116.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.116.2...v1.116.3) (2025-04-30)

### 💥 Bug Fixes

- path param + set request body undefined for POST calls to downstream GET services ([bb9d70a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bb9d70afeb161c2b6e531d132fb8f8409fa095b3))

## [1.116.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.116.1...v1.116.2) (2025-04-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.116.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.116.0...v1.116.1) (2025-04-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.116.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.115.0...v1.116.0) (2025-04-24)

### 🚀 Features

- added a story for MVSearch ([4250213](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/42502130ff5f5175da6a94794a43e7ae11bdbf9e))

### 💥 Bug Fixes

- added back submittedDate and receiptNumber in coldefs for backwards compatibility | ART-53469 ([4c6cdb7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4c6cdb7016b14fc9c9410932be592436a4c015ea))

## [1.115.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.114.0...v1.115.0) (2025-04-22)

### 🚀 Features

- art-46689 update test mesh secret util ([0b5fd63](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0b5fd633ef7818aea4b5e422129a678a04629a69))

## [1.114.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.113.0...v1.114.0) (2025-04-22)

### 🚀 Features

- art-46689 update test mesh secret util ([e628159](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e62815900b5380bf2fc28837a8a74a0cfb183aaa))

## [1.113.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.112.2...v1.113.0) (2025-04-22)

### 🚀 Features

- art-46689 update test mesh secret util ([4116bd5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4116bd5eddd6b326f3accb943ad322f7cd5887e4))
- art-46689 update test mesh secret util ([2b8de36](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2b8de3641b7fd314982b1ea4f81171bf5a272d92))

## [1.112.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.112.1...v1.112.2) (2025-04-21)

### 💥 Bug Fixes

- add min-w to columns so they can shrink if needed to stay in parent | ART-53088 ([c4c41f3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c4c41f32924081af91acc6d1e7e4e673c232e1f0))

## [1.112.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.112.0...v1.112.1) (2025-04-17)

### 💥 Bug Fixes

- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([01274a7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/01274a78bf92a29c2cdd4ab19d2c04ed21ff65ed))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([c50efa5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c50efa5f84b71f01b1b11e3ec1a90a8bc715b3e3))

## [1.112.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.111.0...v1.112.0) (2025-04-16)

### 🚀 Features

- art-46689 add read mesh secret util ([8413cbc](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8413cbc22194b8db7ac81d75325b7122f218545d))
- art-46689 add read mesh secret util ([06cc497](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/06cc497c68fbc522c002bb48e42a8af5be4125a3))
- art-46689 add read mesh secret util ([ab78c2e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ab78c2e625fc9bbc0527970b732cf5d5109c5cb7))
- art-46689 export mesh secret util ([9521c5e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9521c5e2f1ccaf501f5aedcd9c965043ffb02420))
- art-46689 export mesh secret util ([f745f06](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f745f06eb0f37b4f82c642ea63793ac6ef1538a3))
- art-46689 update test mesh secret util ([6d551d9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6d551d96866f78c5883790f9a276e7c2f8607511))

## [1.111.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.110.1...v1.111.0) (2025-04-16)

### 🚀 Features

- updated column definitions in mv table | ART-46683 ([c327218](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c327218f23ec8650ad537c28bc761a062ace9d9d))

## [1.110.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.110.0...v1.110.1) (2025-04-15)

### 💥 Bug Fixes

- changed param name | ART-52269 ([4f21cc6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4f21cc6d3f017ff55fd650c1f559d18fa33f0539))
- red line indicator for negative balance on accounts list page is not as expected | ART-52226 ([db6cb27](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/db6cb271c4e8c301606c1d852ef40c328bdc14ef))
- red line indicator for negative balance on accounts list page is not as expected | ART-52226 ([dd5c628](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/dd5c628f1d7c5d34235c820c9997b8d2ad33cee7))

## [1.110.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.109.1...v1.110.0) (2025-04-15)

### 🚀 Features

- added resize event listener to align dropdown ([95bcff6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/95bcff63dad07b146faa967b70103dcd717a6d82))
- finalised changes for tailwind classes ([2706303](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2706303e302bc8144cc5e1a3889211261dfa8eb3))
- mvbuttondropdown component ([f47fde9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f47fde94735006250bfb7ea32dbd62c712009496))
- mvbuttondropdown component ([ef87a23](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ef87a2387a749d64556afa335e509294955fb8b5))
- updated close button with Icon and added padding before & after menu Items ([cdf5ee0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cdf5ee070592fc758bdaaafe923ec69f304c6522))
- updated index.d.ts with export statement ([680b63c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/680b63cf47ee11b3dfb903d3ca66339fc5e7db5b))
- updated inline css with tailwind classes ([0222bbb](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0222bbb33794d99d89e30dace463b84fb446d339))
- updated inline css with tailwind classes ([8c31198](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8c31198d9c86c734df6be431ad98d4044cc5fafb))
- updated package & index.ts files in library ([311a690](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/311a690506177ebcb97bbeda1af8522a990ffe1b))
- updated props to set dropdown maxHeight ([b1b54a3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b1b54a36c936b5485bc33447cab08e120db1c54f))
- updated props to set dropdown menuItems ([4a88ca8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4a88ca831755a99fd92cfb57261f14a8c8c27a37))
- updated props to set dropdown menuItems and updated component as per figma ([1f51dc6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1f51dc6fc8257bf8587c8dc8ae409774f9445344))
- updated props to set dropdown menuItems and updated component as per figma ([7b3ccd4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7b3ccd4e4719db1f9e10170bccc01730296c8f57))
- updated tailwind classes for font color and size ([2af2597](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2af259742c65bc9305cc534933978fcab95afda3))

## [1.109.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.109.0...v1.109.1) (2025-04-15)

### 💥 Bug Fixes

- moved spinner into MVSelector | ART-52269 ([09763bc](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/09763bca7d3a7477f241ab826f5caccc1530e180))

## [1.109.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.108.1...v1.109.0) (2025-04-15)

### 🚀 Features

- update MVRefreshHandle to accept optional parameter | ART-16297 ([cd60572](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cd6057248e4f2775a37bd8c76cd89e3394327034))

## [1.108.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.108.0...v1.108.1) (2025-04-15)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.108.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.107.0...v1.108.0) (2025-04-14)

### 🚀 Features

- ART-41757 update issues found by Abrham ([affe77b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/affe77b0b72fe3a46c0d56a19b0b114ebafcf09a))
- ART-41757 update matchPattern ([e3bd0b7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e3bd0b79a4b6e62d87f45adfe9b0f02ba2491647))

## [1.107.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.106.1...v1.107.0) (2025-04-11)

### 🚀 Features

- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([f6f5685](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f6f5685090a5a821f399c04eac38d452224d13bc))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([594177d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/594177d636efb09433616fb547bd15943b45cd7b))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([3af09bb](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3af09bbff1483f0cf7b78c00962d83e75b1a6c06))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([0e919f9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0e919f9c96bf092f96848d49a6865092771e85f9))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([d669003](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d66900372028af334ff041d6b0faa013c210448c))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([c525d07](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c525d07adf5b1fa897de0c2cb672640808f0d1f6))

## [1.106.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.106.0...v1.106.1) (2025-04-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.106.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.105.0...v1.106.0) (2025-04-10)

### 🚀 Features

- add blur validation and isInvalid logic | ART-41745 ([c9c3c86](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c9c3c86bc61978006f3fbbb558c56a4edb4b891d))
- add readme | ART-41745 ([5ae99ca](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5ae99ca9c46c79a5920c5ca78c9e13dab43e2d3f))
- add validation rules | ART-41745 ([c4f1215](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c4f1215b64d17be16b3d952d4d74d3596e666c9d))
- refactor with trigger | ART-41745 ([620e0ca](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/620e0cab5e102c18e2502e0521db712afa00bc86))
- update type definition | ART-41745 ([29faf01](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/29faf016f5c594ec757094f40ec3beeb1c25165f))
- update type definitions | ART-41745 ([363f356](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/363f3560cce68d898781c3d1b68c440939e888e0))
- updated readme | ART-41745 ([cfb7df7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cfb7df79e0107ddf9236b17472847c5344bd70e5))

## [1.105.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.104.0...v1.105.0) (2025-04-10)

### 🚀 Features

- ART-41757 delete minItemsForFooter ([61f10de](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/61f10de95ad6a692a8068657c0e20a16cff476a6))
- ART-41757 update ([8517f38](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8517f38141856dca3fb27c9ad2c34c2accbc8188))
- ART-41757 update footerText ([6795330](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6795330ee13da64b6aaa2b823dfbeb783d344678))
- ART-41757 use fullMatchRegex ([5d62784](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5d6278499eccef88ea26618106ed563eb6a7f384))

## [1.104.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.103.1...v1.104.0) (2025-04-07)

### 🚀 Features

- added export csv functionality for MVTableV2 | ART - 41541 ([9f2a257](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9f2a25728fdfdb2b0ab0336ae134d590671b2965))
- added forwardRef for MVTable | ART - 41541 ([52da884](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/52da884fd796b3797e5f7ca6fab85ab91722ba76))
- removed console.log | ART - 41541 ([751edaf](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/751edafc8de57ee33f99b5c0920332d468dad139))

## [1.103.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.103.0...v1.103.1) (2025-04-07)

### 💥 Bug Fixes

- add null safe access to req method | ART-50783 ([5a2c71d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5a2c71da1fa70ffce375d8f0857fc2fd23cbba51))
- remove the first questionmark as it is overly defensive and unneeded ([3991a3c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3991a3c140246c70bcca07e1aead89b75bdd7d96))

## [1.103.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.102.2...v1.103.0) (2025-04-07)

### 🚀 Features

- ART-41757 add inputValueFn ([37c4862](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/37c4862a2187f26887dfa0e105041cceda0145cb))
- ART-41757 update test cases ([4382ed5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4382ed548c9cf76309a1bfb926914821648ae857))
- ART-41757-make the name optional ([f17669c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f17669cc0a981f3982611532c4c7d43c55b6b611))

## [1.102.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.102.1...v1.102.2) (2025-04-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.102.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.102.0...v1.102.1) (2025-04-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.102.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.101.0...v1.102.0) (2025-04-03)

### 🚀 Features

- ART-41757 add package-lock ([424ed7f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/424ed7f6b5340d55c58c56507ec5827c787a5ac4))
- ART-41757 add warn for duplicated items ([c5b8409](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c5b8409a150312f21b1717ac70040682a7b2613f))
- ART-41757 remove defaultProps ([be8ed20](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/be8ed2094d48a77ecf123727c74aad6ca36eba20))
- ART-41757 revert MVSearchInputController ([23cbd3a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/23cbd3a0712145f66f94a0e96b82e68972d5f910))
- ART-41757 tiny ([2358656](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/23586563fa541f3896097da89852342bb7c23853))
- ART-41757 update MVAccountAdditionalDetails ([f17e59c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f17e59c6b3da31b70b41bdf00eff67a6cea3e93b))
- ART-41757 update MVAccountAdditionalDetails ([a26f6ab](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a26f6abef52cf0fc0e8889e53100d3a7a11888c7))
- ART-41757-update package-lock ([dda1f11](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/dda1f11ab6a7227a1fe701aa0a6529df15fc86e9))

## [1.101.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.100.0...v1.101.0) (2025-04-02)

### 🚀 Features

- add comments | ART-39684 ([d664292](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d664292b20d86feefc1cf20842a049053aaf36d5))
- create MVButtonGroupController | ART-39684 ([c264596](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c264596934e5958ccf697ceee180854a23eae26e))
- refactor | ART-39684 ([ea877d5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ea877d5d20a6883f8e47321d647266c99b91b36f))

## [1.100.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.99.0...v1.100.0) (2025-04-02)

### 🚀 Features

- ART-41757 add MVAccountAdditionalDetails ([56f461e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/56f461ecb0a3bf07daeca6127472dc927c7bdb80))
- ART-41757 update MVAccountAdditionalDetails ([f05bbde](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f05bbde3de940928fa17f4db09ea655b31d0a29f))

## [1.99.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.98.0...v1.99.0) (2025-04-02)

### 🚀 Features

- ART-41757-clean up ([738451d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/738451d57a56517bbd36d301d9c1ddc7ce7d92c3))

## [1.98.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.97.2...v1.98.0) (2025-04-02)

### 🚀 Features

- ART-41757-filterItems ([9d3f1ad](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9d3f1ad5300b0f1df740355c05f938dbd09773f3))
- ART-41757-fix issue ([d36288f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d36288f6d7adf17b13f488488f4cfd6ccf7d9198))
- ART-41757-fix issue ([e70e8af](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e70e8af67e83588e3ecc94bb69aca14b5dbaf51d))
- ART-41757-fix issue ([7503de7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7503de77b6a7838a8243fb65d7f5da318e44a5e8))
- ART-41757-update autocomplete ([2a1e81d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2a1e81d534a336aca896134f5504f2ab0c88bd98))
- ART-41757-update UT ([9998222](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/999822225f3a8c5c8ecf500ddbc377c49c77c113))

## [1.97.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.97.1...v1.97.2) (2025-04-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.97.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.97.0...v1.97.1) (2025-04-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.97.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.96.3...v1.97.0) (2025-04-01)

### 🚀 Features

- ART-41757-add onBeforeInput ([032119b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/032119b45119bf382d35dfa41b245eb989711ef0))
- ART-41757-tiny ([287fbcc](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/287fbcc201a62c7263fca7b251625ae937492cba))
- ART-41757-update MVPhoneInputController ([045edcd](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/045edcd3e91371b74844c9b941f08002d5857dae))
- ART-41757-update MVPhoneInputController ([32fa969](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/32fa969780c1c39134634f351fc23716bbf25b72))
- ART-41757-update phoneInputController ([d674733](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d6747339cd17755111cf290bdec25ca8a98902ba))
- ART-41757-update removeDialCodeAndDelimiter ([3d0e62a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3d0e62af39690b317e8da6860db8c7921303283c))
- ART-41757-update type definition ([2b0cc4f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2b0cc4f65c3eff4847b0c1f3e12582f638544bed))

## [1.96.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.96.2...v1.96.3) (2025-04-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.96.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.96.1...v1.96.2) (2025-04-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.96.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.96.0...v1.96.1) (2025-03-31)

### 💥 Bug Fixes

- handleSetDownstreamParams to set body as undefined for GET requests | ART-44031 ([5f73098](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5f73098d0c0672a2ca27f3b2208245e805ed8095))

## [1.96.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.95.1...v1.96.0) (2025-03-28)

### 🚀 Features

- ART-41757-fix "overlapping the input box" issue ([52a451c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/52a451c268124803cd6aaac27676dbfe3357ee46))
- ART-41757-update handleFocus ([43a1eee](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/43a1eee5fb55309d2811d247c6eee241098144b2))

## [1.95.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.95.0...v1.95.1) (2025-03-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.95.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.94.0...v1.95.0) (2025-03-28)

### 🚀 Features

- updated statement table data variable | ART-45838 ([8fe5399](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8fe5399adcf8d37d0bec32c4bec51b507b6245eb))

## [1.94.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.93.0...v1.94.0) (2025-03-26)

### 🚀 Features

- ART-41757 update onChange ([fcd771e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fcd771ecd2aee07215496a3b31c53686e748f008))
- ART-41757 update showDropdownList ([1753fe8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1753fe8e2aabfce5ea71e39d9e80d9389157b760))

## [1.93.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.92.0...v1.93.0) (2025-03-26)

### 🚀 Features

- ART-41757 add onClick ([1263aac](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1263aac85f9e50904b2047af511f31c9529bdb36))
- ART-41757 update handleBlur ([fb82ae9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fb82ae9d237c815c433dc1b7cb3beeb05a4916c9))

## [1.92.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.91.0...v1.92.0) (2025-03-25)

### 🚀 Features

- ART-41757 add onChange ([fcbc770](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fcbc770c3bf5645fc559d1f99d97d2bd0faaeb28))
- ART-41757 invalid={!!errorMessage} ([b340385](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b340385933d3a97eb8a0a4d54d55b0a202403b0f))

## [1.91.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.90.0...v1.91.0) (2025-03-25)

### 🚀 Features

- ART-41757 add onChange and pattern for MVInputController ([4649da6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4649da6a76bf39ae0300690d3482b4ec20026787))
- ART-41757 rename ([a9fe932](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a9fe932446831ebe6ed6ff47bd515a7a5092b4df))
- ART-41757 rename ([b2d1aff](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b2d1aff64d636b4e86dbe30463134a22b75eb223))
- ART-41757 tiny change ([2bb8dfa](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2bb8dfa79ee50032d6e475a42d22362671e9d553))
- ART-44081-update convertSydneyLocalTimeToUtc ([f37b49c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f37b49c78d0eb5625580b37879a1bfe4ea09a236))

## [1.90.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.89.0...v1.90.0) (2025-03-24)

### 🚀 Features

- added autoresize on modelUpdate behaviour | ART-32867 ([33ab88a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/33ab88a33069c4ee3571ace64146e1691c6e0d3b))

## [1.89.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.88.0...v1.89.0) (2025-03-24)

### 🚀 Features

- ART-44081-restProps ([06aa1f9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/06aa1f94fa28bec61f7607dadf62083ffd0ebc20))
- ART-44081-update AutocompleteItemDetailsTemplate ([b06e44a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b06e44aa31c08c200a36971b07f70612555db308))

## [1.88.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.87.0...v1.88.0) (2025-03-21)

### 🚀 Features

- changing commoncoldef | ART-32867 ([bb66a47](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bb66a47cc556846a9ca82b90e32afded018a9f70))
- configure resizable parameter in common column defs | ART-32867 ([fba381d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fba381df959c4cbc036f0de02a18729bd5935f7a))
- configured ColDefs to fit requirements per columns | ART-32867 ([3d43d28](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3d43d2897384848d53e8ac073ed1da01ff6c2b00))
- moved changes from MFE to MV coldefs | ART-32867 ([8975be0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8975be063a47fd20b0f13af98117eb4a442c6dab))

## [1.87.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.86.0...v1.87.0) (2025-03-20)

### 🚀 Features

- ART-41757- delete DefaultAdditionalDetails.tsx ([b55036d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b55036df308551e745b93197c29525bf11979f1d))

## [1.86.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.85.0...v1.86.0) (2025-03-20)

### 🚀 Features

- ART-41757- add filterFn ([c94e6bb](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c94e6bbc5b803b07e68c9e0c49fffc4c312d21df))
- ART-41757- add restProps ([216de4f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/216de4f35574bd5552fc71f0dbb5156126cc2cec))

## [1.85.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.84.0...v1.85.0) (2025-03-20)

### 🚀 Features

- remove dropdown placeholder | ART-38630 ([ccc739b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ccc739b42b0c4ddc9a35f479cd556614cfb37edc))

## [1.84.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.83.0...v1.84.0) (2025-03-19)

### 🚀 Features

- added supporting text to bottom of select element so you can style it to match width of select ([031dc90](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/031dc901926540feb3b2113becbeb9ba6e6f5b1b))

## [1.83.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.82.0...v1.83.0) (2025-03-19)

### 🚀 Features

- begin dropdown menu implementation for MVCard | ART-38630 ([cbd5905](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cbd590504e9fd0ac6e5d21caa5c5b9f252545e1f))

## [1.82.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.81.1...v1.82.0) (2025-03-19)

### 🚀 Features

- added validation pattern for payment and transfer description fields ([2bf5fca](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2bf5fca2f2784fb8e05ed615f832688c9e75da43))

## [1.81.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.81.0...v1.81.1) (2025-03-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.81.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.80.5...v1.81.0) (2025-03-18)

### 🚀 Features

- ART-41757 update according to requirements from Alankar ([5344bd0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5344bd0fde56b4d2efb7e29c95f5bd0332f86bbb))

### 💥 Bug Fixes

- use ReactNode | ART-41757 ([a4fca7e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a4fca7e49f9cb25b6f05c4a75e977ea6ea2b9a0c))

## [1.80.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.80.4...v1.80.5) (2025-03-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.80.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.80.3...v1.80.4) (2025-03-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.80.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.80.2...v1.80.3) (2025-03-14)

### 💥 Bug Fixes

- component MVAccountSummary to support grid | ART-44036 ([bdb1e74](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bdb1e746e2072ea69ae2160b4bf767ef0013e49b))
- review changes | ART-44036 ([1821cb5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1821cb5598725de671f938512d6553c55712fd4b))
- update types | ART-44036 ([6d3203e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6d3203e113f63be62dfd80444b37c68bcc75b579))
- update types | ART-44036 ([10be64a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/10be64a435b78495eaf430ffce137ee26e0b6483))
- update types | ART-44036 ([4136532](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4136532554d15706cc966feb137a98285c1be0e0))

## [1.80.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.80.1...v1.80.2) (2025-03-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.80.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.80.0...v1.80.1) (2025-03-13)

### 💥 Bug Fixes

- add constants file to index file export list | ART-43809 ([b61ea77](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b61ea77e6a0bac085184e8b2569f0301364e2373))

## [1.80.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.79.0...v1.80.0) (2025-03-13)

### 🚀 Features

- importing Pdp query actions from entitlement lib ([8044bec](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8044becb353e46cf9183b3637fb3aeebae04a924))
- updating the entitlements lib in util package.json ([c95619d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c95619dcf2d8646bdda25046e9336af8a8287161))

## [1.79.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.78.0...v1.79.0) (2025-03-13)

### 🚀 Features

- ART-44985 tiny update to remove the default value ([05c5401](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/05c54017425a65868223f3dd01edf9d45652bbfa))

## [1.78.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.77.0...v1.78.0) (2025-03-13)

### 🚀 Features

- ART-44985 tiny update ([4d5c114](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4d5c1149a69e28918b81bf953517350cce147f38))

## [1.77.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.76.0...v1.77.0) (2025-03-13)

### 🚀 Features

- ART-44985 add onBlur ([dce663d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/dce663dc588497b4ff93045b97f9a42e9f5238de))
- ART-44985 add MVPhoneInputController ([92c148e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/92c148e3d538591d0f9dcc038ea8fd8aebafdccd))
- ART-44985 clean up ([5861526](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5861526b70a4e4d9ef16dc0034aa7aeb3348ec69))
- ART-44985 tiny ([b073fef](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b073fefa9a236dc9bcab66a6256a75978932c4ee))
- ART-44985 tiny ([d140be5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d140be56785e6c82e41859611aa0d13de8ceb9c8))
- ART-44985 update according to comments ([831ecac](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/831ecac5f95420b6757c2d0c65dff44c87fbc787))
- ART-44985 update index.d.ts ([579c921](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/579c9215c2fa5066c01c00bc7df8f04701b737bd))
- ART-44985 update MVPhoneInputController ([251545b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/251545b61762fc17a09adfeae90b91b703686e0b))

## [1.76.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.75.1...v1.76.0) (2025-03-12)

### 🚀 Features

- create text sanitizer function | ART-43809 ([a121149](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a121149af494e8fa527246ba4939e3fec08e6f5c))
- create text sanitizer function | ART-43809 ([be543c5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/be543c53039030a0df4e2c079de959fb4ac8d35e))
- create text sanitizer function | ART-43809 ([3c6ba67](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3c6ba67c041fc4e738bf6c7596b758e4e6d3ec0d))
- create text sanitizer function | ART-43809 ([0447515](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/04475150150bd46f57ea3f30ec22c1c8085a2233))
- create text sanitizer function | ART-43809 ([dfdca24](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/dfdca2428a563ea02d55344d4d50bfe09967e67a))

## [1.75.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.75.0...v1.75.1) (2025-03-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.75.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.74.3...v1.75.0) (2025-03-11)

### 🚀 Features

- ART-39683 update MVInputController ([f56504c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f56504c56a50d4da950c21554a1bbcc623f2c40e))

## [1.74.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.74.2...v1.74.3) (2025-03-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.74.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.74.1...v1.74.2) (2025-03-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.74.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.74.0...v1.74.1) (2025-03-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.74.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.73.0...v1.74.0) (2025-03-10)

### 🚀 Features

- export tranformPdpResponse in index.d.ts JIRA:ART-36101 ([09dcaa2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/09dcaa222ee28e631b3ea53aebf9cb956ca69c24))
- export tranformPdpResponse in library src/ index.d.ts JIRA:ART-36101 ([370b802](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/370b802527fbd5c08c1a47a385a466e79cda3aeb))

## [1.73.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.72.1...v1.73.0) (2025-03-10)

### 🚀 Features

- ART-41575 AutocompleteItemDetailsTemplate ([25f481d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/25f481d042fd66accdbd35f109fa724158b14d2b))
- ART-41575 clean up autocomplete ([0caddb3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0caddb3cb5d8bd5de8eb46adbd90470f383e506e))
- ART-41575 remove undefined for AdditionalDetails ([a8f856a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a8f856a6e1acfbf7cb211af3e3a3bca7201bef50))
- ART-41575 update autocomplete ([f6f3d45](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f6f3d45f1bf03a34271cdd8e241633a0e4d85666))

## [1.72.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.72.0...v1.72.1) (2025-03-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.72.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.71.3...v1.72.0) (2025-03-10)

### 🚀 Features

- added enum for pdp query action ([d271664](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d27166485032f8ac9b0e2e64f37d53e90d71d4b6))
- added enum in index.d.js ([ab09c29](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ab09c2986bfb94078bec0ecbd62620d9d659c770))
- added transformPdpResponse util function with unit tests: JIRA: ART-36101 ([b4c1698](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b4c1698d03c656246be0e2ce59af030fe4ad7458))

## [1.71.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.71.2...v1.71.3) (2025-03-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.71.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.71.1...v1.71.2) (2025-03-06)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.71.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.71.0...v1.71.1) (2025-03-04)

### 💥 Bug Fixes

- ui/ux fixes | ART-41561 ([89797ce](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/89797ce725aa421bd9bea3e5df54a76d4aec61a4))

## [1.71.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.70.0...v1.71.0) (2025-03-04)

### 🚀 Features

- added padding to account labels | ART-38526 ([1fd67f8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1fd67f8b74fe9541e55c56dd1f93b484eba24cdf))

## [1.70.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.69.4...v1.70.0) (2025-03-04)

### 🚀 Features

- ART-41757 update date range picker ([1ac27b5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1ac27b5575f421311d38bea922d7943f4323ee82))
- ART-41757 update date range picker ([c8d3305](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c8d3305d2fbfb5fafe1f12ee1fbb9f08672f0a09))
- ART-41757 update date range picker type definition ([0c58883](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0c58883435564bef12d5a751b2e3f36f364621f2))
- ART-41757 update UT cases ([94dbe3d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/94dbe3daf1e55cfc2213fe18e703498859826e1b))

## [1.69.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.69.3...v1.69.4) (2025-03-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.69.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.69.2...v1.69.3) (2025-03-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.69.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.69.1...v1.69.2) (2025-03-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.69.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.69.0...v1.69.1) (2025-02-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.69.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.68.0...v1.69.0) (2025-02-28)

### 🚀 Features

- added types in library/src and mv-utils/src JIRA: ART-41647 ([02647dd](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/02647dd0b74088f686756734723489675241fcef))
- common util to check entitlement auth error : JIRA: ART-41647 ([aeeee14](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/aeeee1452c260ce1fd72124eda45c773b3170b2f))
- handle multiple errors :JIRA-41647 ([b822971](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b822971922e9e1d0bc0340023a9cb89fd5ae1ef2))
- removed the length check for excludeActions : JIRA: ART-41647 ([87e8454](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/87e84545d5048e2eafc45302564995d5e9142305))

## [1.68.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.67.0...v1.68.0) (2025-02-26)

### 🚀 Features

- mvselect placeholder style changes | ART-39584 ([1c5cdac](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1c5cdaccc66ed033b603d5fc7b301ff8c35e1a53))
- mvselect placeholder style changes | ART-39584 ([a39e662](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a39e6624618c39d6784f186d1d7cc2c840197489))
- pr comments | ART-39584 ([1850693](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/185069380bb05c999abd9bf3b1ecfbceabab0762))

## [1.67.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.66.3...v1.67.0) (2025-02-26)

### 🚀 Features

- fix for decimal display in amount| ART-39135 ([65280e0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/65280e080224e965ca8af2afdb3505e321dcee8d))
- fix for decimal display in amount| ART-39135 ([173a38f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/173a38fc6dcf3ab83e36da358d01ec160494e5cc))
- update test case for formatcurrency | ART-39135 ([968f2c5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/968f2c5b733662b858c12410f34bd2b6693f88c0))

## [1.66.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.66.2...v1.66.3) (2025-02-26)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.66.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.66.1...v1.66.2) (2025-02-26)

### 💥 Bug Fixes

- added type definitions | ART-42495 ([5af680f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5af680f26a00a4540ef2beafcf60d285d942848b))

## [1.66.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.66.0...v1.66.1) (2025-02-25)

### 💥 Bug Fixes

- added hint text as an optional prop | ART-42495 ([c117a72](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c117a72d20fcdbc8f11c6b6500e4731d9062736d))
- use ref to handle onClick and onKeyDown events | ART-41848 ([617e936](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/617e9365448b98f8b39e221545f254faebdd2a7d))

## [1.66.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.65.0...v1.66.0) (2025-02-25)

### 🚀 Features

- ART-41757 filteredItems ([667cec7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/667cec7b3d1d248490e8eefc7df09c50111e0f38))
- ART-41757 use "!important" to align with Payment-MFE ([2123182](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/21231828851cf2e12e29851a1b27bafcb4fe7427))

## [1.65.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.64.1...v1.65.0) (2025-02-25)

### 🚀 Features

- implement MVAutocompleteController | ART-41757 ([5f01742](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5f01742c2adbd9dca9373febb8a3be81fe9cbb18))
- override the theme-root | ART-41757 ([851124f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/851124f8d251cf9a89eda0cef4935fea169238da))
- update class name | ART-41757 ([d2bf01b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d2bf01ba48fafddb3a2fa9919296db9cca1ce3cb))
- update handleSelectionChange() | ART-41757 ([78236e0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/78236e0c22aa6312e484860a343d3c49d3370de7))
- use autocomplete-wrapper.css | ART-41757 ([600f3d9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/600f3d9abd23859c2ba1b1d701c5aa29ee9cce6f))

## [1.64.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.64.0...v1.64.1) (2025-02-24)

### 💥 Bug Fixes

- added placeholder prop in mvselect | ART-39584 ([85e2504](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/85e250419da5cc83417e5254aa642dfd9a3ac66e))

## [1.64.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.63.0...v1.64.0) (2025-02-24)

### 🚀 Features

- update handleApiService | ART-41956 ([ac44020](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ac440200a624c9b09b6bba37d1883046c0a1575a))

## [1.63.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.62.1...v1.63.0) (2025-02-21)

### 🚀 Features

- remove redundant code | ART-36119 ([e079372](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e079372d449453d0194034d23dfafa5277735ed0))

## [1.62.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.62.0...v1.62.1) (2025-02-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.62.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.61.0...v1.62.0) (2025-02-20)

### 🚀 Features

- remove useEffect | ART-40541 ([736cb76](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/736cb76d879e7a37a9de44a065755c86a8cdaf0c))
- update error message | ART-40541 ([6e42bb3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6e42bb30132578c3afadbdaeac5ba6c4fda26438))

## [1.61.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.60.3...v1.61.0) (2025-02-19)

### 🚀 Features

- clean up | ART-39719 ([d30d02c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d30d02c3722e9542402f2fd9a9aa3b10106740a8))
- remove Grid and GridItem | ART-39719 ([ba1f1a6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ba1f1a6d2df108469c4a7cbe25137836d2355d98))
- remove validation when value changes | ART-39719 ([e9791a1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e9791a11b19a22def769e9139d735394be19486d))
- update DatePickerWrapper | ART-39719 ([8634910](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8634910561b8a82e2a31c08845e51585360289cf))
- use westpacui v0.41 | ART-39719 ([a346407](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a34640799d98e5c4ceb0e7b21aa262d5745ec133))

## [1.60.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.60.2...v1.60.3) (2025-02-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.60.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.60.1...v1.60.2) (2025-02-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.60.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.60.0...v1.60.1) (2025-02-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.60.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.59.0...v1.60.0) (2025-02-13)

### 🚀 Features

- dateRange formatter | ART-27663 ([648c091](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/648c091d40666b8718d0fa40f486cc0fcffdc238))

## [1.59.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.58.3...v1.59.0) (2025-02-12)

### 🚀 Features

- update right arrow icon | ART-39719 ([5738097](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/57380974dadedef38270be549959322a92e02668))

## [1.58.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.58.2...v1.58.3) (2025-02-11)

### 💥 Bug Fixes

- add type def to library file | ART-29898 ([887d1b7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/887d1b763cb018856c2cd72c1c052aed25378434))

## [1.58.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.58.1...v1.58.2) (2025-02-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.58.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.58.0...v1.58.1) (2025-02-10)

### 💥 Bug Fixes

- add parameter to type def | ART-29898 ([f05ce8b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f05ce8b9863a7c4a7ba4692ccdba28ea0f2fe424))

## [1.58.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.57.0...v1.58.0) (2025-02-09)

### 🚀 Features

- changes in MVSearchInputController to pass onChange value | ART-27663 ([659a13a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/659a13abb743509fdc2d1275c160480753f49f80))

## [1.57.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.56.0...v1.57.0) (2025-02-06)

### 🚀 Features

- add red border around Select component when an error occurs | ART-29899 ([fb61735](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fb61735f845b0dc6e93082a30287917a9fa26648))

## [1.56.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.55.5...v1.56.0) (2025-02-05)

### 🚀 Features

- recommit changes using latest version | ART-36119 ([72c1413](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/72c14135fbba3bce83450ab127692490b7e71263))
- update jest config | ART-36119 ([93b1364](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/93b1364369e795c610a6a80caeae1dfa3962cc03))

## [1.55.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.55.4...v1.55.5) (2025-02-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.55.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.55.3...v1.55.4) (2025-02-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.55.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.55.2...v1.55.3) (2025-02-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.55.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.55.1...v1.55.2) (2025-02-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.55.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.55.0...v1.55.1) (2025-02-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.55.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.54.0...v1.55.0) (2025-02-02)

### 🚀 Features

- dummy commit for version bump | ART-38430 ([ade06f5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ade06f53d125ab675340075f87e7213d86a177a4))
- package update to align with account mfe | ART-38430 ([5e4f910](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5e4f9108aeae48ef012b31d081d99260d2f05b39))

## [1.54.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.53.4...v1.54.0) (2025-01-31)

### 🚀 Features

- add onBlur handler to allow handling of focus lost events | ART-29898 ([ea2bd78](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ea2bd78a5298234d7cabd385d4d2b06fc4c973ca))

### 💥 Bug Fixes

- cast onBlur and pass event as param | ART-29898 ([aca4ec2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/aca4ec245fa2ac3fb9bd62842d53860174a60f1b))
- pass the RHF onBlur and execute it before executing our custom behavior | ART-29898 ([6dd6720](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6dd6720718aa7e52179c4d1abf7380dc67c142ae))

## [1.53.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.53.3...v1.53.4) (2025-01-31)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.53.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.53.2...v1.53.3) (2025-01-30)

### 🚀 Features

- sca integration | ART-29541 ([a6ff367](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a6ff367a38ff46d2fbc346341750751f5e96a7db))

## [1.53.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.53.1...v1.53.2) (2025-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.53.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.53.0...v1.53.1) (2025-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.53.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.52.0...v1.53.0) (2025-01-29)

### 🚀 Features

- update The hover banner doesn't appear | ART-38995 ([6d5871b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6d5871ba40f3fecf331bca91d0a0d9bff8508f55))

## [1.52.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.51.1...v1.52.0) (2025-01-28)

### 🚀 Features

- update The hover banner doesn't appear | ART-38995 ([c023fb5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c023fb5002f258dc5fd793fe396f3ab7d90b256e))
- update The hover banner doesn't appear update the lookup issue | ART-38995 ([1cf9550](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1cf95508c862c28190e8f5f62006ac1d222e60da))

## [1.51.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.51.0...v1.51.1) (2025-01-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.51.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.50.0...v1.51.0) (2025-01-27)

### 🚀 Features

- update The hover banner doesn't appear | ART-38995 ([6fb8c3e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6fb8c3e34673bb2d6e604518ead7c53f096ea13a))

## [1.50.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.49.7...v1.50.0) (2025-01-27)

### 🚀 Features

- update The hover banner doesn't appear | ART-38995 ([70d5051](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/70d50516aaabc82bb99615a99758e28ad85bd862))

## [1.49.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.49.6...v1.49.7) (2025-01-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.49.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.49.5...v1.49.6) (2025-01-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.49.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.49.4...v1.49.5) (2025-01-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.49.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.49.3...v1.49.4) (2025-01-23)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.49.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.49.2...v1.49.3) (2025-01-23)

### 💥 Bug Fixes

- add export the mv_entitlements lib | ART-37763 ([b11459b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b11459b4e9fe0f206c16a2aecc4d866cbcf2e6f6))
- add-manage-account-name-action-to-library-export | ART-37763 ([6e24f4a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6e24f4aa0d67ae6165c9aa23fdb7a9fa0a8f30ba))

## [1.49.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.49.1...v1.49.2) (2025-01-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.49.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.49.0...v1.49.1) (2025-01-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.49.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.48.3...v1.49.0) (2025-01-21)

### 🚀 Features

- update format-bsb util function | ART-15927 ([3eaaca0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3eaaca0703830fb94583bee7392e8c264c04006d))

## [1.48.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.48.2...v1.48.3) (2025-01-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.48.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.48.1...v1.48.2) (2025-01-20)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.48.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.48.0...v1.48.1) (2025-01-20)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.48.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.47.2...v1.48.0) (2025-01-20)

### 🚀 Features

- add util function to format bsb from account no | ART-15508 ([c070a66](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c070a663bec35da2bc482556360ef34bb50e2eca))

## [1.47.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.47.1...v1.47.2) (2025-01-20)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.47.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.47.0...v1.47.1) (2025-01-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.47.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.46.2...v1.47.0) (2025-01-16)

### 🚀 Features

- mvSearchInputController updation | ART-28182 ([e03ffd7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e03ffd7e608cf49b852829191c5321aca1b13af1))
- package-lock.json update | ART-28182 ([dda9162](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/dda9162b2c609e48408513bb3c08610163424257))
- searchInputController | ART-28182 ([3cb1781](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3cb1781b2278565c9ca5a0358b854ede11cdf85d))
- searchInputController update | ART-28182 ([1b80b65](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1b80b65e00d8fd6d1a00d2001a1e75b60ae7d2b5))
- searchInputController updation to export | ART-28182 ([8d06fa9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8d06fa9245100c68be1bcf6a56ef00c93aceea3d))

## [1.46.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.46.1...v1.46.2) (2025-01-16)

### 💥 Bug Fixes

- fix entitlement constant types | ART-36119 ([f556dea](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f556dea8bd9c247bbffcaf60ca0280cb252ad3ff))

## [1.46.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.46.0...v1.46.1) (2025-01-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.46.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.45.2...v1.46.0) (2025-01-15)

### 🚀 Features

- update entitlements constants | ART-36119 ([63c36a3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/63c36a3bf93586d0a88339de55d7758ca4af789a))

### 💥 Bug Fixes

- fix entitlements constants spelling error | ART-36119 ([96ddf7c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/96ddf7ca7e721a995759463ea44b7c38b6471dc6))

## [1.45.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.45.1...v1.45.2) (2025-01-15)

### 💥 Bug Fixes

- remove date-rangepicker refernce to fix errors in MFE | ART-28182 ([92328c9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/92328c96b498d1c466ddfa90cd4aaab7248f90f1))

## [1.45.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.45.0...v1.45.1) (2025-01-15)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.45.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.44.1...v1.45.0) (2025-01-15)

### 🚀 Features

- added BSB formatter utility function | ART-28182 ([b7fdb74](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b7fdb745f8871612510803c3bce9ab0476c84252))

## [1.44.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.44.0...v1.44.1) (2025-01-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.44.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.43.0...v1.44.0) (2025-01-13)

### 🚀 Features

- add RightArrow icon | ART-31841 ([b86e89f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b86e89f59fec9bf6693ead9ecf59c1c79792d463))
- update RightArrow icon to use inline src | ART-31841 ([2c47ca6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2c47ca6bfbc1c8777638cc14414a761bfa882626))

## [1.43.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.42.1...v1.43.0) (2025-01-09)

### 🚀 Features

- create MVDateRangePicker | ART-31841 ([1fa8399](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1fa83994e15d5da29d209be6ba3261c9a7151dab))

## [1.42.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.42.0...v1.42.1) (2025-01-08)

### 💥 Bug Fixes

- account summary ui fixes ([f389d5b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f389d5bf86bc3d63d70d522d98e9b6c7965bc135))
- account summary ui fixes JIRA: ART-37989 ([7dba215](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7dba215311397e1279074a8c8e7eb32dc9634531))

## [1.42.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.41.0...v1.42.0) (2024-12-21)

### 🚀 Features

- support-locally-configured-loggedInUserRole | ART-30220 ([b53c4b3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b53c4b396bb743fcf51c5bbebd318614d4f6e450))

## [1.41.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.40.2...v1.41.0) (2024-12-20)

### 🚀 Features

- return-isUserAuthorised function | ART-30219 ([f0adcd4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f0adcd40597e4bd296fb4dd67f8f5d14c319742a))
- return-isUserAuthorised function | ART-30219 ([5661ed0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5661ed0567d439a7fddba259103c85540d7dee3b))
- return-isUserAuthorised function | ART-30219 ([b88a79e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b88a79ea96cb50406ddbbbf7abc3980ad0cf518e))
- return-isUserAuthorised function | ART-30219 ([4da7da5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4da7da5178fefcc00c43c8002de96f0bc8591710))
- return-isUserAuthorised function | ART-30219 ([ab3d973](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ab3d973c51c9d3f61e93eb3f980a5c4cdc386abd))
- return-isUserAuthorised function | ART-30219 ([2580edc](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2580edce45e38cb711ff367aad9371b4c669dfa6))
- return-isUserAuthorised function | ART-30219 ([5651583](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5651583936956ecf5c148dedecf828dd58c43f46))

## [1.40.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.40.1...v1.40.2) (2024-12-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.40.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.40.0...v1.40.1) (2024-12-19)

### 💥 Bug Fixes

- Revert APIError component | ART-31297 ([85f361c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/85f361c5ff8aa0befb13c1106afb73f21c5f10cb))

## [1.40.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.39.5...v1.40.0) (2024-12-18)

### 🚀 Features

- added sample stories for the details & card packages ([9ef7bd3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9ef7bd395cff52395559ab23529426639ff925a4))
- integrated storybook with webpack, added required config files ([b789dc6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b789dc66e72d9661796b48b977fe319ed1186ed4))

### 💥 Bug Fixes

- deleted prettier files and workspace ([0c8fda3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0c8fda3a8648d0b1f1b06d8cd1c6e7ddadf1376b))
- fixed the styling with mvaccount formatter story ([95a3935](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/95a39355f61a65bbc0fd37c0991fdc5d908c6e5a))
- installed additional packages to fix build errors for some packages ([5881713](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/588171307e380234a214cf890fed4d59ebb8a4b9))
- updated redux-actions version to fix version conflict errros ([1348945](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/13489457c9570372bae77eb466bcae950eeb276f))

## [1.39.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.39.4...v1.39.5) (2024-12-18)

### 💥 Bug Fixes

- account detail page the line above the date opened has unexpected space | ART-37396 ([c1348c4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c1348c4b44006fc3d7cf36affad71f9f292ca4c4))

## [1.39.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.39.3...v1.39.4) (2024-12-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.39.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.39.2...v1.39.3) (2024-12-17)

### 💥 Bug Fixes

- add throwAPIError function | ART-31297 ([66b0bdd](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/66b0bdd382b031732d99889e8aeb943cc2fd2eab))
- unit test fixes | ART-31297 ([4044aa9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4044aa981540fe60a4b68c753f3357bf0ae82c36))

## [1.39.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.39.1...v1.39.2) (2024-12-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.39.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.39.0...v1.39.1) (2024-12-16)

### 💥 Bug Fixes

- update export of APIError util | ART-31297 ([b2151f2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b2151f2d283a1072d0696d94e9e65a9add2c2631))

## [1.39.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.38.0...v1.39.0) (2024-12-15)

### 🚀 Features

- added MVAccountSummary prop in lib | ART-14509 ([48d417d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/48d417d71853536fbe89d36d72ed1d07e5a6f9c0))

## [1.38.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.37.0...v1.38.0) (2024-12-13)

### 🚀 Features

- added error prop to Account Summary Prop | ART-14509 ([091da6d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/091da6d842cc4dd3ff8a959f7e98a42224dbab09))

## [1.37.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.36.0...v1.37.0) (2024-12-12)

### 🚀 Features

- minor code refactor | ART-14509 ([193773f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/193773f0b356303c61702bdfb99f94a1c30325de))

## [1.36.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.35.0...v1.36.0) (2024-12-12)

### 🚀 Features

- maccountsummary status prop added | ART-14496 ([3ed3116](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3ed3116be401823b15ac1ca12148d1948b449dda))
- merge conflicts resolved | ART-14496 ([700d2d8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/700d2d8bf9a0af89538380dfb53096d7210e3143))

## [1.35.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.10...v1.35.0) (2024-12-12)

### 🚀 Features

- add error message support to account summary | ART-14509 ([69e2dba](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/69e2dbaefd72811684499a0e2f6392198aeac21c))
- add error message support to account summary | ART-14509 ([4cc2c03](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4cc2c039bb29d4489c51ad0d6b26d54fd666f216))

## [1.34.10](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.9...v1.34.10) (2024-12-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.34.9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.8...v1.34.9) (2024-12-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.34.8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.7...v1.34.8) (2024-12-11)

### 💥 Bug Fixes

- update MVIcon props and add PayTo logo | ART-15769 ([6cffa62](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6cffa6213099e79944e3fa477a8da1b5e247cfb4))
- update MVIcon props and add PayTo logo | ART-15769 ([ed08a6e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ed08a6ec1c96c8233cec0d4d1e66fbb0572fe670))

## [1.34.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.6...v1.34.7) (2024-12-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.34.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.5...v1.34.6) (2024-12-11)

### 💥 Bug Fixes

- label undefined error of account formatter | ART-32246 ([ee7aa85](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ee7aa85557ffcf08061b768303b75b0009248c06))

## [1.34.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.4...v1.34.5) (2024-12-10)

### 💥 Bug Fixes

- correct behaviour of character limit on input and textarea | ART-30903 ([a9562b5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a9562b5160814942924fe102342bde16cf482ebc))

## [1.34.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.3...v1.34.4) (2024-12-08)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.34.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.2...v1.34.3) (2024-12-06)

### 💥 Bug Fixes

- conditionally display the time zone JIRA: ART-31648 ([bcbbdb2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bcbbdb2c4d6235c1c9b314c0d242b98606e29ed0))
- conditionally display the time zone JIRA: ART-31648 ([856b412](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/856b412a68774d973e0b7caa38e23cd7851c182f))

## [1.34.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.1...v1.34.2) (2024-12-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.34.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.0...v1.34.1) (2024-12-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.34.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.33.3...v1.34.0) (2024-12-03)

### 🚀 Features

- adjust divider color ([04ee66b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/04ee66b81cd26151cd7088159e3cf6da030f37eb))
- created account summary component ([adad89f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/adad89f6641e26010ab9221447fcb98facb25bd6))
- updated code to follow best practice ([b22961c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b22961c892a6d68db3e30ba6ac399be11eec3350))

## [1.33.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.33.2...v1.33.3) (2024-12-03)

### 💥 Bug Fixes

- sonar cube major code smell | ART-31297 ([3fb6e20](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3fb6e20c667ff7f7b4362cef48cafcc6bceadb01))

## [1.33.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.33.1...v1.33.2) (2024-11-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.33.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.33.0...v1.33.1) (2024-11-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.33.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.32.1...v1.33.0) (2024-11-28)

### 🚀 Features

- add 2 more format helper functions JIRA: ART-14311 ([7a0019b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7a0019ba0fc7f5143f1729eb3e5307ef2319f6a1))
- format update JIRA: ART-14311 ([4af654a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4af654ad4197a44649bc33ad36f4f1acb44d5814))

## [1.32.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.32.0...v1.32.1) (2024-11-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.32.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.31.1...v1.32.0) (2024-11-26)

### 🚀 Features

- refactor mv-account-formatter ([4593d95](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4593d956ef9c11b50d5633ecbefde9ed1989afee))
- refactor mv-account-formatter ([3911025](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/39110254bf2bf4a5c5784fdd4dd0d2908433799a))

## [1.31.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.31.0...v1.31.1) (2024-11-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.31.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.30.3...v1.31.0) (2024-11-25)

### 🚀 Features

- Updated token with PAC mngmt profile role and added new action to pac mngmt profile role. | ART-30175 ([7fc7acc](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7fc7acc5f416f57fa5cf830208ffcc013ce52b1a))

## [1.30.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.30.2...v1.30.3) (2024-11-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.30.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.30.1...v1.30.2) (2024-11-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.30.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.30.0...v1.30.1) (2024-11-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.30.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.29.0...v1.30.0) (2024-11-22)

### 🚀 Features

- extend mv-accountformatter ([d06d453](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d06d453870568c09394ca5ccea8fedf64a15bfa8))

## [1.29.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.28.0...v1.29.0) (2024-11-20)

### 🚀 Features

- added xlarge | ART-15475 ([4c21d63](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4c21d6388cb7d743546a35600dde7fa83766d420))
- adding optional prop to mvinputcontroller |ART-15475 ([b9d0610](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b9d0610902f88d8ba527b3c4ced4626769a4b003))

## [1.28.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.27.0...v1.28.0) (2024-11-20)

### 🚀 Features

- postArrangementDetails API - add convertSydneyLocalTimeToUtc in .d.ts | ART-14302 ([cd17356](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cd17356957992cea05a1379d6b8df9d1081587e1))
- postArrangementDetails API - add convertSydneyLocalTimeToUtc in .d.ts | ART-14302 ([9e32d6b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9e32d6babeab138c926fad07090ae1854193c952))

## [1.27.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.26.0...v1.27.0) (2024-11-20)

### 🚀 Features

- postArrangementDetails API - add convertSydneyLocalTimeToUtc | ART-14302 ([623fc14](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/623fc14235f4d9edb87677e282103b9bdc9b696c))
- postArrangementDetails API - clean up | ART-14302 ([227d80d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/227d80d9a10bddab0b1efdbec1da3d59e65430fb))
- postArrangementDetails API - rollback | ART-14302 ([a50ec7b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a50ec7bbdf3ef406bc2588c6d3c6fe4323040ca3))
- postArrangementDetails API - rollback package-lock | ART-14302 ([58c55ac](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/58c55ac88b0cd9534c6c6bdf9a76971e7766080a))

## [1.26.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.25.3...v1.26.0) (2024-11-20)

### 🚀 Features

- update utils currency new update | ART-24649 ([b9ef76d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b9ef76d8b53507830fde23102ae7aef522167633))
- update utils currentcy controller | ART-24649 ([99d58b2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/99d58b2dc7a7b6df8efad9a99f46130b747aadec))

## [1.25.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.25.2...v1.25.3) (2024-11-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.25.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.25.1...v1.25.2) (2024-11-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.25.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.25.0...v1.25.1) (2024-11-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.25.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.24.0...v1.25.0) (2024-11-18)

### 🚀 Features

- migrate mv-accountformatter ([9e8f3cb](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9e8f3cb3e93483daebf56cc659667913f16a9a70))
- migrate mv-accountformatter ([aba825a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/aba825a30e2c9c09e251d4eb2dd048cae3c5148b))
- migrate mv-accountformatter ([69b154f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/69b154f04c9dc547fc5affde968298ab29b3924f))

## [1.24.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.23.1...v1.24.0) (2024-11-15)

### 🚀 Features

- allow developers to add a link button to the header of the MVDetailSection component ([3a66ab8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3a66ab875864c55337be4cafd0ed98e5e47ba12b))

## [1.23.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.23.0...v1.23.1) (2024-11-15)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.23.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.22.0...v1.23.0) (2024-11-13)

### 🚀 Features

- MVCard title conditional rendering added | ART-29128 ([99a1257](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/99a1257a8e659d7d495294713c6c5cafe3537bfc))

## [1.22.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.21.2...v1.22.0) (2024-11-13)

### 🚀 Features

- MVCard title conditional rendering added | ART-29128 ([8dae60e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8dae60e04b16f37d4f995d5cad1d7b8bf3ad03a9))

## [1.21.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.21.1...v1.21.2) (2024-11-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.21.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.21.0...v1.21.1) (2024-11-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.21.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.20.1...v1.21.0) (2024-11-11)

### 🚀 Features

- added scrolltotop to index |ART-16950 ([7fc07c7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7fc07c7d0489e384b8a1da7c299b83c8bd36046f))

## [1.20.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.20.0...v1.20.1) (2024-11-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.20.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.19.0...v1.20.0) (2024-11-06)

### 🚀 Features

- autocomplete component update | ART-24649 ([4229dd4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4229dd4459c558e41902df72e4a128cd2c5e3783))

## [1.19.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.18.0...v1.19.0) (2024-11-05)

### 🚀 Features

- update for package.json | ART-24649 ([16a8e58](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/16a8e580a78a24f35e2199696f18da5dac397084))

## [1.18.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.17.0...v1.18.0) (2024-11-05)

### 🚀 Features

- hotfix | ART-24649 ([8364718](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8364718eecd0e1834fdd553aa1f63b49fd2a739c))
- update for index.d.ts | ART-24649 ([1a832ca](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1a832ca960fd64ef4cc099b5108f82f10c2bc971))

## [1.17.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.16.0...v1.17.0) (2024-11-04)

### 🚀 Features

- amount and autocomplete components update| ART-24649 ([468ea8d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/468ea8d1a0a781ca5301f586eba605565964e297))
- autocomplete component package.json update | ART-24649 ([6614b7a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6614b7a48fe4532e9db3945f20794da0f007e6db))
- autocomplete component update | ART-24649 ([de6407f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/de6407f3ee16bf270897861191d619127472094a))
- currency controller update | ART-24649 ([26f04f9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/26f04f91c034c67caca6a9959b9bb7c5677ca230))
- update according to review feedback | ART-24649 ([d1637be](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d1637be774d8d1e034160074dde8800a3fd7148d))
- update package-locak.json | ART-24649 ([f17aeb3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f17aeb3209ec076743692eaa310cc3ca6f84832c))
- update ref to mv-tiles | ART-24649 ([8b6714a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8b6714a965edc022a7702c86e40364d2c51ed5b9))
- update ref with unit test and remove useless code | ART-24649 ([5932336](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5932336d90bab094a26a4fb17ce228622fb21aef))

## [1.16.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.15.0...v1.16.0) (2024-11-04)

### 🚀 Features

- mvcard component updates | ART-29215 ([18f22d2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/18f22d236a49ed6755980cf1c6b15a47222f1915))
- mvcard style updates | ART-29215 ([154ab1c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/154ab1c33c6b40462312a756d7143758aaf6b4d7))

## [1.15.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.14.0...v1.15.0) (2024-11-04)

### 🚀 Features

- update to ts | ART-15347 ([4f5dba5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4f5dba5234cda618bad6b9596bdb1c30cec383fc))

## [1.14.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.13.0...v1.14.0) (2024-11-03)

### 🚀 Features

- Detail section component update and merge with master branch and resolved conflicts| ART-16972 ([f8f8f28](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f8f8f281e9024b6370d48b1a1b2dfd08448d0479))
- Detail section component update the package-lock json file| ART-16972 ([78dbbd8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/78dbbd8a634a26821f8afb7745124cebf34c54bd))

## [1.13.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.8...v1.13.0) (2024-11-01)

### 🚀 Features

- mvcard component migration | ART-29215 ([9d39cda](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9d39cda9a6a10b11ae741d2ed4c1f300d266028f))
- package-lock.json update | ART-29215 ([a82094f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a82094fbdd0f122df628f5562d9c8446fd9e4ad3))
- review comment fixes | ART-29215 ([8f70eb2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8f70eb22a0c099df635df2bd2a84c335a1220360))

## [1.12.8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.7...v1.12.8) (2024-10-31)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.12.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.6...v1.12.7) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.12.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.5...v1.12.6) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.12.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.4...v1.12.5) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.12.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.3...v1.12.4) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.12.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.2...v1.12.3) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.12.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.1...v1.12.2) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.12.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.0...v1.12.1) (2024-10-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.12.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.11.0...v1.12.0) (2024-10-24)

### 🚀 Features

- add ag-grid | ART-15347 ([4d7a0ce](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4d7a0cec74717df4226dbbb8eaa4a9057c1d5168))
- add ag-grid in library | ART-15347 ([c7ddeca](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c7ddecae68130f652111dbf78a97a0fc2890f569))

## [1.11.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.10.0...v1.11.0) (2024-10-23)

### 🚀 Features

- add refresh widget and form controller | ART-24650 ([3c642b6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3c642b6738b45ef17cb7b0ced7b641d9d2cfdcd2))
- detail section update using jsx instead of tsx| ART-16969 ([855b357](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/855b3572b2e1ddca84f1898d7f9df5bc1cbb9bd2))

## [1.10.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.9.0...v1.10.0) (2024-10-22)

### 🚀 Features

- component updateion | ART-28136 ([8c92281](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8c92281f2a764123117bba261294e71c43bf7f25))
- detail section update component name| ART-16969 ([c678c44](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c678c4473c72fccddec3ec333ec3f60724731868))
- mvcard component | ART-28136 ([64a6b0e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/64a6b0eebe6649df67ecb40f1b5430c79c527480))
- mvcard component update and package-lock.json updates | ART-28136 ([10c0789](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/10c0789efe9a5886d6f4313c55b7f9964537d350))
- restructure of missing props | ART-28136 ([e3c1992](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e3c1992f9fda235094cc399b08c2025f0ca50026))
- **ui-galaxy:** add acount formatter | ART-24665 ([6263fc6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6263fc669a00198fdc5ea08ff3537237b26a6218))
- update package-lock.json file | ART-28136 ([6f046e8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6f046e82f5841cfc78051781d2c37a5b3dbdc364))
- update the type declaration file | ART-24650 ([0ebe684](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0ebe68403a73f5c263bd0ee54be90fa3bcc18de2))

## [1.9.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.8.0...v1.9.0) (2024-10-22)

### 🚀 Features

- common detail section componennt update | ART-16969 ([1e09be0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1e09be0b1cb8c32103a37a4a4827fc8253766949))
- detail section update according to PR review 02| ART-16969 ([1762ab5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1762ab5a42b0464dfa3af15ca3fa9eac2b154c3a))

## [1.8.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.7.2...v1.8.0) (2024-10-22)

### 🚀 Features

- update package name in library | ART-24650 ([1bd11b1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1bd11b1fc74f7b9fed08fee4a65aaca3517db2cf))

## [1.7.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.7.1...v1.7.2) (2024-10-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.7.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.7.0...v1.7.1) (2024-10-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/workspace

## [1.7.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.6.0...v1.7.0) (2024-10-22)

### 🚀 Features

- update hello world pacakge | ART-24650 ([5f89051](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5f8905112ccbbab228ee842eb83023bf59df8f10))

## [1.6.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.5.0...v1.6.0) (2024-10-21)

### 🚀 Features

- rename index file | ART-15321 ([d54bc3e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d54bc3e4f242c200a128267788df5ade6f52a7c0))

## [1.5.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.4.0...v1.5.0) (2024-10-21)

### 🚀 Features

- add helloworld comonent | ART-15321 ([2d8a22c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2d8a22c2e64491ba0c09ebe3d55be1ddf00791ef))
- install helloworld comonent | ART-15321 ([9e1e197](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9e1e19785833d17e8b16e5f7f04e8a28d70c1282))
- install helloworld comonent | ART-15321 ([6e4a2b6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6e4a2b6c29d48e60a9850e3d12ddecbfdbcd097d))

## [1.4.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.3.0...v1.4.0) (2024-10-21)

### 🚀 Features

- add Readme | ART-15321 ([0b80100](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0b80100ca7d8208486eeb3f2a138a4a494997fcc))
- gel and tailwind configurations | ART-15321 ([a08d6fa](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a08d6fad4d55fda8c413018fb9e9aad19a407565))
- remove readme | ART-15321 ([df8201c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/df8201c9971d626ad5c8987db0f3270993a553ec))
- remove skip from UrlHelper, eslint configuration | ART-15321 ([f274ca1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f274ca1cee9662b11c0bf09029d79984cf40ac9d))
- update application id | ART-15321 ([cc3932e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cc3932e72f1eef33940e59e0ff3e2936318c1da5))
- update application id | ART-15321 ([fd5aace](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fd5aaceb7aa81e3fec415e913f183bd3de023143))
- update readme | ART-15321 ([c1710e9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c1710e95a55468982fde1ff3ccaacf915e378458))

## 1.3.0 (2024-10-16)

### 🚀 Features

- initial mesh tenant multiverse ui common library | ART-15321 ([b8e295f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b8e295f45a7db6b3b143f3390ab287d2b538c615))
- update container profile name to node | ART-15321 ([2fb5d6f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2fb5d6f7ef16ac3c0c1e526c8f612de8bee66381))
