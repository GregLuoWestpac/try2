import React, { useState, useEffect } from 'react';
import { Input } from '@westpac/ui';
import {
  ExpandMoreIcon,
  ExpandLessIcon,
  CloseIcon,
  ClearIcon,
} from '@westpac/ui/icon';

export type MVSearchProps = {
  total: number;
  index: number;
  downArrow: () => void;
  upArrow: () => void;
  close: () => void;
  search: (phrase: string) => void;
};

function MVSearch({
  total,
  index,
  downArrow,
  upArrow,
  close,
  search,
}: MVSearchProps) {
  const [inputValue, setInputValue] = useState('');

  const handleClear = () => {
    setInputValue('');
  };

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        close();
      } else if (event.key === 'Enter') {
        search(inputValue);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [close, search, inputValue]);

  return (
    <div className="w-[470px] max-h-11 p-2 rounded-md">
      <div className="flex items-center">
        <div className="relative w-full justify-center">
          <Input
            id="#search-box"
            width="full"
            value={inputValue}
            onChange={e => setInputValue(e.target.value)}
            placeholder="Find keywords..."
          />
          {inputValue && (
            <button
              className="absolute transform top-1/2 -translate-y-1/2 right-1.5 focus-visible:outline-focus flex"
              onClick={handleClear}
            >
              <ClearIcon size="small" color="muted" />
            </button>
          )}
        </div>
        <p className="text-base mx-1.5">
          {index !== 0 ? index : ''}
          {index ? '/' : ''}
          {total !== 0 ? total : ''}
        </p>
        <button
          onClick={downArrow}
          className="mr-1.5 focus-visible:outline-focus flex"
        >
          <ExpandMoreIcon color="muted" size="medium" />
        </button>
        <button
          onClick={upArrow}
          className="mr-2 focus-visible:outline-focus flex"
        >
          <ExpandLessIcon color="muted" size="medium" />
        </button>
        <button onClick={close} className="focus-visible:outline-focus flex">
          <CloseIcon color="muted" size="medium" />
        </button>
      </div>
    </div>
  );
}

export default MVSearch;
