import React from 'react';
import MVSearch, { MVSearchProps } from '../MVSearch';
import { StoryFn, Meta } from '@storybook/react';

export default {
  title: 'Components/MVSearch',
  component: MVSearch,
  tags: ['autodocs'],
  argTypes: {
    details: {
      control: 'object',
      description: 'Control F search bar',
    },
  },
} as Meta<typeof MVSearch>;

// template for creating stories
const Template: StoryFn<typeof MVSearch> = args => <MVSearch {...args} />;

// default settings
export const Default = Template.bind({});
Default.args = {
  total: 5,
  index: 1,
  downArrow: () => {
    alert('downArraow function is called');
  },
  upArrow: () => {
    alert('upArraow function is called');
  },
  search: (phrase: string) => alert(`search "${phrase}" is called`),
  close: () => alert('close function is called'),
} as MVSearchProps;
