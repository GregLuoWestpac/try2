import * as React from 'react';

export type MVSearchProps = {
  total: number;
  index: number;
  downArrow: () => void;
  upArrow: () => void;
  close: () => void;
  search: (phrase: string) => void;
};

export const MVSearch: React.FC<MVSearchProps>;
