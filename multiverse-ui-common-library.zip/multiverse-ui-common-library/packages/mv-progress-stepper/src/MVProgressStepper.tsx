import { Button } from '@westpac/ui';
import React, { useRef } from 'react';
import { CircleIcon } from './components/CircleIcon';
import { useIsMobile } from './hooks/useIsMobile';
import { TickCircleIcon } from './components/TickCircleIcon';

type Props = {
  steps: string[];
  activeStep: number;
  setActiveStep: React.Dispatch<React.SetStateAction<number>>;
};

export function MVProgressStepper({ steps, activeStep, setActiveStep }: Props) {
  const isMobile = useIsMobile();
  const maxStepRef = useRef(0);
  maxStepRef.current = Math.max(maxStepRef.current, activeStep);

  return (
    <>
      <div className="flex flex-wrap items-center w-full">
        {steps.map((label, index) => {
          const isCompleted = index < activeStep;
          const isActive = index === activeStep;
          const isInactive = index <= maxStepRef.current && index > activeStep;
          const isNotStarted = index > maxStepRef.current;

          return (
            <div key={index} className="flex items-start relative mt-2">
              <Button
                look="unstyled"
                disabled={isNotStarted}
                className="h-auto"
                onClick={() => {
                  setActiveStep(index);
                }}
              >
                <div className="flex flex-col items-center text-center min-w-[50px] max-w-[120px]">
                  <div
                    className={`rounded-full flex items-center justify-center font-bold z-10 text-primary `}
                  >
                    {isCompleted && <TickCircleIcon />}
                    {!isCompleted && (
                      <CircleIcon
                        count={index + 1}
                        isActive={isActive}
                        isInactive={isInactive}
                        isNotStarted={isNotStarted}
                      />
                    )}
                  </div>

                  {!isMobile && (
                    <div
                      className={`mt-1 text-sm ${
                        isActive ? 'text-primary font-bold' : ''
                      }`}
                    >
                      {label}
                    </div>
                  )}
                </div>
              </Button>

              {index < steps.length - 1 && (
                <div className="flex-grow h-1 bg-gray-300 relative mt-2  min-w-[20px]">
                  <div
                    style={{ borderStyle: isCompleted ? 'solid' : 'dotted' }}
                    className={`absolute top-0 left-0 h-full transition-all duration-300 border-t-2 w-full
                    ${isCompleted ? 'border-primary' : 'border-muted'}
                  `}
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {isMobile && (
        <div className="mt-1 text-sm text-primary  font-bold">
          {steps[activeStep]}
        </div>
      )}
    </>
  );
}
