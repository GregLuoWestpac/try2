import React from 'react';

export const MVProgressStepper: (props: {
  steps: string[];
  activeStep: number;
  setActiveStep: React.Dispatch<React.SetStateAction<number>>;
}) => React.ReactElement;
