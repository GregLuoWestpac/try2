/* eslint-disable react/no-unknown-property */
import React from 'react';

type Props = {
  count: number;
  isActive: boolean;
  isInactive: boolean;
  isNotStarted: boolean;
};

export function CircleIcon({
  count,
  isActive,
  isInactive,
  isNotStarted,
}: Props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      role="img"
      focusable="false"
      className="w-4 h-4 bg-white-500"
    >
      <g clip-path="url(#clip1)">
        {isActive && (
          <path
            style={{ fill: '#DA1710' }}
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M12 24c6.628 0 12-5.373 12-12S18.628 0 12 0 0 5.373 0 12s5.372 12 12 12Z"
            fill="currentColor"
          ></path>
        )}
        {(isInactive || isNotStarted) && (
          <path
            className={isNotStarted ? 'text-muted' : ''}
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M24 12C24 5.373 18.628 0 12 0C5.372 0 0 5.373 0 12C0 18.627 5.372 24 12 24C18.628 24 24 18.627 24 12ZM2 12C2 6.477 6.477 2 12 2C17.523 2 22 6.477 22 12C22 17.523 17.523 22 12 22C6.477 22 2 17.523 2 12Z"
            fill="currentColor"
          ></path>
        )}
        <text
          style={{
            fill: isActive ? 'white' : isInactive ? '#DA1710' : '#595767',
          }}
          x="12"
          y="12"
          text-anchor="middle"
          dominant-baseline="central"
        >
          {count}
        </text>
      </g>
      <defs>
        <clipPath id="clip1">
          <rect width="24" height="24" fill="currentColor"></rect>
        </clipPath>
      </defs>
    </svg>
  );
}
