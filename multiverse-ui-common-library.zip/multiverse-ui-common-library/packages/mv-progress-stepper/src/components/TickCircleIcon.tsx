/* eslint-disable react/no-unknown-property */
import React from 'react';

export function TickCircleIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      role="img"
      focusable="false"
      className="w-4 h-4 bg-white-500"
    >
      <g clip-path="url(#clip2)">
        <path
          d="M9.99519 14.5891L17.2923 7.29199L18.7023 8.71199L9.99519 17.4191L5.28809 12.712L6.69809 11.302L9.99519 14.5891Z"
          fill="currentColor"
        ></path>
        <path
          fill-rule="evenodd"
          clip-rule="evenodd"
          d="M24 12C24 5.373 18.628 0 12 0C5.372 0 0 5.373 0 12C0 18.627 5.372 24 12 24C18.628 24 24 18.627 24 12ZM2 12C2 6.477 6.477 2 12 2C17.523 2 22 6.477 22 12C22 17.523 17.523 22 12 22C6.477 22 2 17.523 2 12Z"
          fill="currentColor"
        ></path>
      </g>
      <defs>
        <clipPath id="clip2">
          <rect width="24" height="24" fill="currentColor"></rect>
        </clipPath>
      </defs>
    </svg>
  );
}
