import { renderHook } from '@testing-library/react';
import { act } from 'react-dom/test-utils';
import { useIsMobile } from './useIsMobile';

describe('useIsMobile', () => {
  const originalInnerWidth = global.innerWidth;

  beforeEach(() => {
    global.innerWidth = originalInnerWidth;
  });

  it('should return "xl" when window width is greater than or equal to GelBreakpoints.xl', () => {
    global.innerWidth = 1901;
    const { result } = renderHook(() => useIsMobile());
    act(() => {
      global.dispatchEvent(new Event('resize'));
    });
    expect(result.current).toBe(false);
  });

  it('should return "xsl" when window width is less than GelBreakpoints.sm', () => {
    global.innerWidth = 400;
    const { result } = renderHook(() => useIsMobile());
    act(() => {
      global.dispatchEvent(new Event('resize'));
    });
    expect(result.current).toBe(true);
  });
});
