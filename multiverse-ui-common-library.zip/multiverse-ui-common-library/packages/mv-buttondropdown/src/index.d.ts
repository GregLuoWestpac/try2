import { HTMLAttributes, ReactNode, Dispatch, SetStateAction } from 'react';
import { ButtonProps } from '@westpac/ui';

type IconProps = {
  size?: 'small' | 'medium' | 'large';
  color?: string;
};
type ContentItem = {
  key: string;
  title: string;
  onClickRowFn: () => void;
  onCloseRowFn: () => void;
  icon: (props: IconProps) => JSX.Element;
  closeBtn: boolean;
};
export type MVButtonDropdownProps = {
  /**
   * Button text
   */
  children?: ReactNode;
  /**
   * Content of button dropdown
   */
  content: ContentItem[];
  /**
   * Heading for button dropdown box
   */
  headingLine?: string;
  /**
   * Supporting Text for Heading of button dropdown box
   */
  supportingText?: string;
  /**
   * Use an icon as the button
   */
  icon?: (props: IconProps) => JSX.Element;
  /**
   * Removes padding from trigger button and sets look to link to be able to look inline, use size prop to match font size
   */
  linkStyling?: boolean;
  /**
   * A function for the onClick event
   */
  onClick?: () => void;
  /**
   * To be used in the consuming repo to access the state
   */
  isOpen: boolean;
  /**
   * To be used in the consuming repo to set the state the state
   */
  setIsOpen: Dispatch<SetStateAction<boolean>>;
  /**
   * Placement of button dropdown. If no placement provided it will default to top unless there is no space then will appear on bottom.
   * @default top
   */
  placement?: 'top' | 'bottom';
  /**
   * Change trigger button color
   */
  buttonColor?: string;
  /**
   * Max Height for dropdown content
   */
  maxHeight?: string;
} & HTMLAttributes<Element> &
  Pick<ButtonProps, 'look' | 'soft' | 'size'>;

export const MVButtonDropdown: React.FC<MVButtonDropdownProps>;
