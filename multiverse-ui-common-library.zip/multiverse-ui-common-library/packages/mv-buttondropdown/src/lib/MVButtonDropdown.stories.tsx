import '!style-loader!css-loader!postcss-loader!tailwindcss/tailwind.css';
import React from 'react';
import { StoryFn, Meta } from '@storybook/react';
import MVButtonDropdown, { MVButtonDropdownProps } from '../MVButtonDropdown';
import { HelpIcon, HouseIcon, SettingsIcon, ExitIcon } from '@westpac/ui/icon';
import { IconProps } from '@westpac/ui/components/icon';

export default {
  title: 'Components/MVButtonDropdown',
  tags: ['autodocs'],
  component: MVButtonDropdown,
} as Meta<typeof MVButtonDropdown>;

const Template: StoryFn<MVButtonDropdownProps> = args => (
  <MVButtonDropdown {...args} />
);

export const Default = Template.bind({});
Default.args = {
  content: [
    {
      key: '1',
      title: 'Settings',
      onClickRowFn: () => alert('Settings clicked'),
      onCloseRowFn: () => alert('Settings closed'),
      icon: (props: IconProps) => <SettingsIcon {...props} />,
      closeBtn: true,
    },
    {
      key: '2',
      title: 'Sign Out',
      onClickRowFn: () => alert('Sign Out clicked'),
      onCloseRowFn: () => alert('Sign Out closed'),
      icon: (props: IconProps) => <ExitIcon {...props} />,
      closeBtn: false,
    },
  ],
  headingLine: 'Genevieve Featherstonehaughhhhhhhhh',
  supportingText: 'Growth Income & Propel Investment',
  children: 'Click me',
};

export const WithHeading = Template.bind({});
WithHeading.args = {
  content: [
    {
      key: '1',
      title: 'Item 1',
      onClickRowFn: () => alert('Item 1 clicked'),
      onCloseRowFn: () => alert('Item 1 closed'),
      icon: (props: IconProps) => <SettingsIcon {...props} />,
      closeBtn: true,
    },
    {
      key: '2',
      title: 'Item 2',
      onClickRowFn: () => alert('Item 2 clicked'),
      onCloseRowFn: () => alert('Item 2 closed'),
      icon: (props: IconProps) => <SettingsIcon {...props} />,
      closeBtn: true,
    },
  ],
  headingLine: 'Genevieve Featherstonehaughhhhhhhhh',
  supportingText: 'Growth Income & Propel Investment',
  children: 'Click me',
};

export const WithIcon = Template.bind({});
WithIcon.args = {
  content: [
    {
      key: '1',
      title: 'Item 1',
      onClickRowFn: () => alert('Item 1 clicked'),
      onCloseRowFn: () => alert('Item 1 closed'),
      icon: (props: IconProps) => <HouseIcon {...props} />,
      closeBtn: true,
    },
    {
      key: '2',
      title: 'Item 2',
      onClickRowFn: () => alert('Item 2 clicked'),
      onCloseRowFn: () => alert('Item 2 closed'),
      icon: (props: IconProps) => <HouseIcon {...props} />,
      closeBtn: true,
    },
  ],
  icon: () => <HelpIcon size="small" color="white" look="outlined" />,
  children: 'Click me',
};

export const WithoutClose = Template.bind({});
WithoutClose.args = {
  content: [
    {
      key: '1',
      title: 'Item 1',
      onClickRowFn: () => alert('Item 1 clicked'),
      onCloseRowFn: () => alert('Item 1 closed'),
      icon: (props: IconProps) => <HouseIcon {...props} />,
      closeBtn: false,
    },
    {
      key: '2',
      title: 'Item 2',
      onClickRowFn: () => alert('Item 2 clicked'),
      onCloseRowFn: () => alert('Item 2 closed'),
      icon: (props: IconProps) => <HouseIcon {...props} />,
      closeBtn: false,
    },
  ],
  children: 'Click me',
};

export const CustomContent = Template.bind({});
CustomContent.args = {
  content: [
    {
      key: '1',
      title: 'Item 1',
      onClickRowFn: () => alert('Item 1 clicked'),
      onCloseRowFn: () => alert('Item 1 closed'),
      icon: (props: IconProps) => <SettingsIcon {...props} />,
      closeBtn: true,
    },
    {
      key: '2',
      title: 'Item 2',
      onClickRowFn: () => alert('Item 2 clicked'),
      onCloseRowFn: () => alert('Item 2 closed'),
      icon: (props: IconProps) => <ExitIcon {...props} />,
      closeBtn: false,
    },
  ],
  children: 'Click me',
};

export const TopPlacement = Template.bind({});
TopPlacement.args = {
  content: [
    {
      key: '1',
      title: 'Item 1',
      onClickRowFn: () => alert('Item 1 clicked'),
      onCloseRowFn: () => alert('Item 1 closed'),
      icon: (props: IconProps) => <SettingsIcon {...props} />,
      closeBtn: true,
    },
    {
      key: '2',
      title: 'Item 2',
      onClickRowFn: () => alert('Item 2 clicked'),
      onCloseRowFn: () => alert('Item 2 closed'),
      icon: (props: IconProps) => <ExitIcon {...props} />,
      closeBtn: false,
    },
  ],
  placement: 'top',
  children: 'Click me',
  maxHeight: '400px',
};

export const WithReactComponent = Template.bind({});
WithReactComponent.args = {
  content: [
    {
      key: '1',
      title: 'Item 1',
      onClickRowFn: () => alert('Item 1 clicked'),
      onCloseRowFn: () => alert('Item 1 closed'),
      icon: (props: IconProps) => <SettingsIcon {...props} />,
      closeBtn: true,
    },
    {
      key: '2',
      title: 'Item 2',
      onClickRowFn: () => alert('Item 2 clicked'),
      onCloseRowFn: () => alert('Item 2 closed'),
      icon: (props: IconProps) => <ExitIcon {...props} />,
      closeBtn: false,
    },
  ],
  children: 'Click me',
  buttonColor: 'Red',
};

const TemplateNew: StoryFn<MVButtonDropdownProps> = args => (
  <>
    <div className="mt-[200px] flex flex-col">
      <div className="flex justify-between">
        <MVButtonDropdown {...args} placement="bottom">
          Left Popover
        </MVButtonDropdown>
        <MVButtonDropdown {...args} placement="bottom">
          Center Popover
        </MVButtonDropdown>
        <MVButtonDropdown {...args} placement="bottom">
          Right Popover
        </MVButtonDropdown>
      </div>
    </div>
    <div className="mt-[200px] flex flex-col">
      <div className="flex justify-between">
        <MVButtonDropdown {...args} placement="top">
          Left Popover
        </MVButtonDropdown>
        <MVButtonDropdown {...args} placement="top">
          Center Popover
        </MVButtonDropdown>
        <MVButtonDropdown {...args} placement="top">
          Right Popover
        </MVButtonDropdown>
      </div>
    </div>
  </>
);

export const AlignRight = TemplateNew.bind({});
AlignRight.args = {
  content: [
    {
      key: '1',
      title: 'Item 1',
      onClickRowFn: () => alert('Item 1 clicked'),
      onCloseRowFn: () => alert('Item 1 closed'),
      icon: (props: IconProps) => <SettingsIcon {...props} />,
      closeBtn: true,
    },
    {
      key: '2',
      title: 'Item 2',
      onClickRowFn: () => alert('Item 2 clicked'),
      onCloseRowFn: () => alert('Item 2 closed'),
      icon: (props: IconProps) => <ExitIcon {...props} />,
      closeBtn: false,
    },
  ],
  children: 'Click me',
  maxHeight: '400px',
};

export const DefaultNew = Template.bind({});
DefaultNew.args = {
  content: [
    {
      key: '1',
      title: 'Item 1',
      onClickRowFn: () => alert('Item 1 clicked'),
      onCloseRowFn: () => alert('Item 1 closed'),
      icon: (props: IconProps) => <HouseIcon {...props} />,
      closeBtn: true,
    },
    {
      key: '2',
      title: 'Item 2',
      onClickRowFn: () => alert('Item 2 clicked'),
      onCloseRowFn: () => alert('Item 2 closed'),
      icon: (props: IconProps) => <ExitIcon {...props} />,
      closeBtn: false,
    },
    {
      key: '3',
      title: 'Item 3',
      onClickRowFn: () => alert('Item 3 clicked'),
      onCloseRowFn: () => alert('Item 3 closed'),
      icon: (props: IconProps) => <SettingsIcon {...props} />,
      closeBtn: true,
    },
  ],
  headingLine: 'Genevieve Featherstonehaughhhhhhhhh',
  supportingText: 'Growth Income & Propel Investment',
  buttonColor: '#007bff',
};
