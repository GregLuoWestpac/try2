import React, {
  useState,
  useRef,
  useEffect,
  useMemo,
  useCallback,
  Dispatch,
  SetStateAction,
} from 'react';
import { CloseIcon } from '@westpac/ui/icon';
type IconProps = {
  size?: string;
  color?: string;
};

type ContentItem = {
  key: string;
  title: string;
  onClickRowFn: () => void;
  onCloseRowFn: () => void;
  icon: (props: IconProps) => JSX.Element;
  closeBtn: boolean;
};
export type MVButtonDropdownProps = {
  children?: React.ReactNode;
  content: ContentItem[];
  headingLine?: string;
  ariaLabel?: string;
  supportingText?: string;
  icon?: (props: IconProps) => JSX.Element;
  linkStyling?: boolean;
  onClick?: () => void;
  isOpen: boolean;
  setIsOpen: Dispatch<SetStateAction<boolean>>;
  placement?: 'top' | 'bottom';
  buttonColor?: string;
  maxHeight?: string;
} & React.HTMLAttributes<Element> & {
    look?: string;
    soft?: boolean;
    size?: string;
  };

const MVButtonDropdown: React.FC<MVButtonDropdownProps> = ({
  children,
  content,
  headingLine,
  ariaLabel,
  supportingText,
  icon: Icon,
  linkStyling = false,
  onClick = () => undefined,
  isOpen,
  setIsOpen,
  placement = 'bottom',
  look = 'hero',
  soft = false,
  size = 'medium',
  buttonColor,
  maxHeight = '200px',
  ...rest
}) => {
  const buttonRef = useRef<HTMLButtonElement>(null);
  const [positionStyle, setPositionStyle] = useState<{
    left: string;
    right: string;
  }>({ left: '0px', right: 'auto' });
  const dropdownRef = useRef<HTMLDivElement | null>(null);
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);

  const updateDropdownPosition = () => {
    const button = buttonRef.current;
    if (button) {
      const buttonRect = button.getBoundingClientRect();
      const viewportWidth = window.innerWidth;

      if (buttonRect.right > viewportWidth / 2) {
        setPositionStyle({ left: 'auto', right: '0px' });
      } else {
        setPositionStyle({ left: '0px', right: 'auto' });
      }
    }
  };

  useEffect(() => {
    // Update position on mount
    updateDropdownPosition();

    // Add resize event listener to handle window  resizing
    window.addEventListener('resize', updateDropdownPosition);
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscKeyPress);

    // Clean up the event listeners on unmount
    return () => {
      window.removeEventListener('resize', updateDropdownPosition);
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscKeyPress);
    };
  }, []);

  const handleClickOutside = (event: MouseEvent) => {
    if (
      dropdownRef.current &&
      !dropdownRef.current.contains(event.target as Node) &&
      !buttonRef.current?.contains(event.target as Node)
    ) {
      setIsOpen(false);
    }
  };

  const handleEscKeyPress = (event: KeyboardEvent) => {
    if (event.key === 'Escape') {
      setIsOpen(false);
    }
  };

  // Focusin and focusout events to handle losing focus
  const handleFocusIn = () => {
    if (
      dropdownRef.current &&
      !dropdownRef.current.contains(document.activeElement)
    ) {
      setIsOpen(true);
    }
  };

  const handleFocusOut = (event: FocusEvent) => {
    // Close dropdown if focus moves outside the dropdown
    if (
      dropdownRef.current &&
      !dropdownRef.current.contains(event.relatedTarget as Node) &&
      !buttonRef.current?.contains(event.relatedTarget as Node)
    ) {
      setIsOpen(false);
    }
  };

  useEffect(() => {
    if (isOpen && dropdownRef.current) {
      dropdownRef.current.focus();
    }

    buttonRef.current?.addEventListener('focusin', handleFocusIn);
    buttonRef.current?.addEventListener('focusout', handleFocusOut);
    dropdownRef.current?.addEventListener('focusin', handleFocusIn);
    dropdownRef.current?.addEventListener('focusout', handleFocusOut);

    return () => {
      buttonRef.current?.removeEventListener('focusin', handleFocusIn);
      buttonRef.current?.removeEventListener('focusout', handleFocusOut);
      dropdownRef.current?.removeEventListener('focusin', handleFocusIn);
      dropdownRef.current?.removeEventListener('focusout', handleFocusOut);
    };
  }, [isOpen]);

  const handleClick = useCallback(() => {
    if (onClick) onClick();
    setIsOpen(prev => !prev);
  }, [onClick]);

  const handleKeyDownEnter = useCallback(() => {
    if (onClick) onClick();
    setIsOpen(prev => !prev);
  }, [onClick]);

  const handleKeyDown = (
    event: React.KeyboardEvent<HTMLDivElement>,
    onClickFn: () => void
  ) => {
    if (event.key === 'Enter' || event.key === 'Space') {
      onClickFn();
    }
  };

  const handleKeyDownOnList = (event: React.KeyboardEvent<HTMLDivElement>) => {
    if (event.key === 'Tab' && event.shiftKey) {
      setIsOpen(false);
    }
    const listItems = document.querySelectorAll('[id^="submenu-item"]');
    const focusedElement = document.activeElement;
    const currentIndex = Array.from(listItems).indexOf(focusedElement);

    if (event.key === 'ArrowDown') {
      event.preventDefault();
      if (currentIndex < content.length - 1) {
        listItems[currentIndex + 1].focus();
      } else {
        listItems[0].focus();
      }
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      if (currentIndex > 0) {
        listItems[currentIndex - 1].focus();
      } else {
        listItems[listItems.length - 1].focus();
      }
    }
  };

  const buttonDropdownContent = useMemo(
    () => (
      <div
        {...rest}
        tabIndex={-1}
        ref={dropdownRef}
        aria-labelledby="button-dropdown-content"
      >
        {(headingLine || supportingText) && (
          <div className="py-2 px-2 pt-1">
            {headingLine && (
              <div className="typography-body-9 self-stretch font-normal tracking-[-0.154px] leading-[22.4px] text-[#181B25]">
                {headingLine}
              </div>
            )}
            {supportingText && (
              <div className="typography-body-11 text-muted text-xs tracking-[-0.144px] self-stretch font-normal leading-normal">
                {supportingText}
              </div>
            )}
          </div>
        )}
        {(headingLine || supportingText) && <hr className="border-border" />}
        <div className="dropdown-items-div">
          {content.map(item => (
            <div
              key={item.key}
              onClick={item.onClickRowFn}
              onKeyDown={event => handleKeyDown(event, item.onClickRowFn)}
              onMouseEnter={() => setHoveredItem(item.key)}
              onMouseLeave={() => setHoveredItem(null)}
              id={`submenu-item-${item.key}`}
              tabIndex={-1}
              className="group flex items-center self-stretch cursor-pointer px-2 h-[36px] hover:bg-[#f6f6f8] transition-colors duration-200 ease-in"
            >
              <div className="cursor-pointer mr-1">
                {item.icon && (
                  <item.icon
                    className="block group-hover:text-[#1f1c4f]"
                    size="small"
                    color="muted"
                    look={hoveredItem === item.key ? 'filled' : 'outline'}
                  />
                )}
              </div>
              <div className="typography-body-11 group-hover:text-[#1f1c4f] content-center text-muted tracking-[-0.154px] leading-[19.6px] font-normal">
                {item.title}
              </div>
              {item.closeBtn && (
                <div
                  onClick={e => {
                    e.stopPropagation();
                    item.onCloseRowFn();
                  }}
                  onKeyDown={event => handleKeyDown(event, item.onCloseRowFn)}
                  aria-label="close item"
                  tabIndex={0}
                  role="button"
                  className="cursor-pointer text-muted absolute right-[10px]"
                >
                  <CloseIcon
                    className="group-hover:text-[#1f1c4f]"
                    size="xsmall"
                    color="muted"
                    look={hoveredItem === item.key ? 'filled' : 'outline'}
                  />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    ),
    [content, headingLine, supportingText, placement, rest, hoveredItem]
  );

  return (
    <div className="relative" tabIndex={-1}>
      <style>
        {`
          @keyframes slideDown {
            0% {
              opacity: 0;
              transform: translateY(-10px);
            }
            100% {
              opacity: 1;
              transform: translateY(0);
            }
          }

          .slide-down-animation {
            animation: slideDown 200ms ease-in;
          }
        `}
      </style>
      <button
        ref={buttonRef}
        style={{ backgroundColor: buttonColor, height: '34px' }}
        className={`border-[#595767] flex items-center justify-center cursor-pointer min-w-[42px] hover:bg-[#626081] active:bg-[#4a486a] focus:outline-dotted focus:outline-white focus:outline-[1px] focus:outline-offset-[-1px] outline-none
          ${
            Icon
              ? 'text-white text-link underline'
              : linkStyling
                ? ''
                : 'bg-hero border border-hero hover:bg-hero-70 active:bg-hero-50'
          }
          ${linkStyling ? 'p-0 text-link underline inline-flex w-auto outline-none' : 'px-1 text-white'}
          ${look ? `look-${look}` : ''} ${soft ? 'soft' : ''} ${size ? `size-${size}` : ''}`}
        onClick={handleClick}
        onKeyDown={e => {
          if (e.key === 'Enter') handleKeyDownEnter();
        }}
        aria-label={ariaLabel}
        aria-controls="button-dropdown-content"
        id="button-dropdown-trigger"
      >
        {Icon ? <Icon size="1.5em" /> : children}
      </button>
      {isOpen && (
        <div
          id="button-dropdown-content"
          ref={dropdownRef}
          tabIndex={-1}
          className={`absolute z-[999] w-[250px] rounded focus:outline-none bg-white shadow-[0_6px_9px_rgba(0,0,0,0.2)] slide-down-animation overflow-y-auto
              py-1 ${headingLine || supportingText ? 'pt-0' : ''} ${
                positionStyle.left == '0px' ? 'left-0' : 'right-0'
              } ${placement == 'top' ? 'bottom-full' : 'top-full'}`}
          style={{ maxHeight }}
          onKeyDown={e => {
            handleKeyDownOnList(e);
          }}
        >
          {buttonDropdownContent}
        </div>
      )}
    </div>
  );
};

export default MVButtonDropdown;
