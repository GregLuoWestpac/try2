# MVButtonDropdown Component

The `MVButtonDropdown` component is a versatile buttondropdown component built with React and styled using Tailwind CSS. It leverages the `@westpac/ui` library for grid layout and headings.

## Installation

To install the `MVButtonDropdown` component, you can use npm:

```sh
npm install @mesh-tenant-multiverse-ui-common/mv-buttondropdown

```


## Usage

To use the `MVButtonDropdown` component, follow these steps:

1. Import the component in your file:

```jsx
import MVButtonDropdown from '@mesh-tenant-multiverse-ui-common/mv-buttondropdown';
```

2. Add the `MVButtonDropdown` component to your JSX code:

```jsx
<MVButtonDropdown content="This is the buttondropdown content" heading="Button Dropdown Heading">
  <button>Click me</button>
</MVButtonDropdown>
```

## Props

The `MVButtonDropdown` component accepts the following props:

- `children` (optional): Button text or any ReactNode to trigger the buttondropdown.

- `content` (required): Content of the buttondropdown.

- `heading` (optional): Heading for the buttondropdown box.

- `headingTag` (optional): Tag to render the heading. Defaults to h1.

- `icon` (optional): Use an icon as the button.

- `linkStyling` (optional): Removes padding from the trigger button and sets the look to link style.

- `onClick` (optional): A function for the onClick event.

- `open` (optional): Whether the button dropdown is open by default.

- `placement` (optional): Placement of the button dropdown. Defaults to top.

- `portal` (optional): Renders the button dropdown using a portal. Can be an HTML element or a boolean value to use document.body.

## Example

Here's an updated example of how to use the `MVButtonDropdown` component:

```jsx
import React from 'react';
import MVButtonDropdown, { MVButtonDropdownProps } from './MVButtonDropdown';

const MVButtonDropdown = () => {
  return (
    <MVButtonDropdown
      content="This is the button dropdown content"
      heading="Button Dropdown Heading"
      icon={(props) => <Icon {...props} name="info" />}
      placement="bottom"
      open={true}
    >
      <button>Click me</button>
    </MVButtonDropdown>
  );
};

export default MVButtonDropdown;
```

That's it! You can now use the updated `MVButtonDropdown` component in your page