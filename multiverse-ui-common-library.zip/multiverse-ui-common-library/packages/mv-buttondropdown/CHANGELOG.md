# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.178.7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.178.6...v1.178.7) (2025-08-13)

### 💥 Bug Fixes

- wibdtw1-2203 re run build ([4692bcc](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4692bcc8c5893a6553541f05648f5b132996bffe))

## [1.178.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.178.5...v1.178.6) (2025-08-13)

### 💥 Bug Fixes

- wibdtw1-2203: remove active background colour ([1861d23](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1861d23e3f24fbed9ca7868c3727931fd59363fb))

## [1.178.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.178.0...v1.178.1) (2025-08-12)

### 💥 Bug Fixes

- wibdtw1-2203 remove open option and change types ([908b251](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/908b2513f94adbe8cefdef5e5d2cb885f8bf306f))

## [1.177.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.176.0...v1.177.0) (2025-08-11)

### 🚀 Features

- wibdtw1-2203 active state bg colour ([282916a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/282916a338d939f3d2bd438cb61422c384e7c930))

## [1.176.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.175.0...v1.176.0) (2025-08-08)

### 🚀 Features

- wibdtw1-2203 retrigger build ([0dea939](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/0dea939b65534c33b941dc97441bd48d41a8e71b))

## [1.173.8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.173.7...v1.173.8) (2025-08-06)

### 💥 Bug Fixes

- wibdtw1-2203 pass state to consuming repo ([c31b6d8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c31b6d88e11eafd90cb3dbf96cd718aede80fb2a))

## [1.170.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.167.2...v1.170.1) (2025-07-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-buttondropdown

## [1.138.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.137.3...v1.138.0) (2025-05-30)

### 🚀 Features

- WIBDTW1-1748 update aria label ([924db9d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/924db9d1503c66dc65a29ac6d51e1968b65506dd))

## [1.126.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.125.0...v1.126.0) (2025-05-13)

### 🚀 Features

- WIBDTW1-622 update keydown handling ([6b087c0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/6b087c08c6f2621a72bb04937503e1c3d93bbc5f))

## [1.122.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.121.0...v1.122.0) (2025-05-07)

### 🚀 Features

- added focusIn and focusOut events to close dropdown ([7749c22](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/7749c22cf98028b71ebe1db79c96bab77d14509f))

## [1.117.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.116.7...v1.117.0) (2025-05-02)

### 🚀 Features

- updated component for Icon styling ([cd14923](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/cd149236fbbab07b83ee009450422c3e9fbdcdc2))

## [1.110.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.109.1...v1.110.0) (2025-04-15)

### 🚀 Features

- added resize event listener to align dropdown ([95bcff6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/95bcff63dad07b146faa967b70103dcd717a6d82))
- finalised changes for tailwind classes ([2706303](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2706303e302bc8144cc5e1a3889211261dfa8eb3))
- mvbuttondropdown component ([f47fde9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f47fde94735006250bfb7ea32dbd62c712009496))
- mvbuttondropdown component ([ef87a23](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ef87a2387a749d64556afa335e509294955fb8b5))
- updated close button with Icon and added padding before & after menu Items ([cdf5ee0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/cdf5ee070592fc758bdaaafe923ec69f304c6522))
- updated index.d.ts with export statement ([680b63c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/680b63cf47ee11b3dfb903d3ca66339fc5e7db5b))
- updated inline css with tailwind classes ([0222bbb](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/0222bbb33794d99d89e30dace463b84fb446d339))
- updated inline css with tailwind classes ([8c31198](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8c31198d9c86c734df6be431ad98d4044cc5fafb))
- updated package & index.ts files in library ([311a690](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/311a690506177ebcb97bbeda1af8522a990ffe1b))
- updated props to set dropdown maxHeight ([b1b54a3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b1b54a36c936b5485bc33447cab08e120db1c54f))
- updated props to set dropdown menuItems ([4a88ca8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4a88ca831755a99fd92cfb57261f14a8c8c27a37))
- updated props to set dropdown menuItems and updated component as per figma ([1f51dc6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1f51dc6fc8257bf8587c8dc8ae409774f9445344))
- updated props to set dropdown menuItems and updated component as per figma ([7b3ccd4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/7b3ccd4e4719db1f9e10170bccc01730296c8f57))
- updated tailwind classes for font color and size ([2af2597](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2af259742c65bc9305cc534933978fcab95afda3))
