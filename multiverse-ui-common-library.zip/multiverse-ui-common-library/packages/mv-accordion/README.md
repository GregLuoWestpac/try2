# MVAccordion

A simple, reusable accordion component for multiverse MFEs that provides a consistent container for any content with built-in apply button and proper overflow handling for popups.

## Features

- 🎯 **Consistent UI**: Standard accordion layout with filter icon and title
- 🏗️ **Flexible Content**: Accepts any React children as filter content
- 🔘 **Built-in Apply Button**: Automatic apply button with customizable text
- 🌟 **Popup Support**: Proper overflow handling for date pickers and dropdowns
- 🎨 **Custom Titles**: Override default filter title with custom content
- ⚡ **Lightweight**: No form dependencies, smaller bundle size
- 🔧 **Simple API**: Minimal props for maximum flexibility

## Usage

### Basic Implementation with State Management

Here's a complete example using accountActivityTabs that demonstrates the three loading scenarios:

```tsx
import { MVAccordion } from '@mesh-tenant-multiverse-ui-common/mv-accordion';
import { GridItem } from '@westpac/ui';
import { useState } from 'react';

function AccountActivityTabs() {
  const [isAccordionExpanded, setIsAccordionExpanded] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleApplyFilters = async () => {
    setIsLoading(true);
    
    try {
      // Scenario 1: While API is calling, maintain loading flag
      // ProgressIndicator will appear, button will be disabled
      const response = await fetchAccountActivity({
        dateRange: selectedDateRange,
        accountType: selectedAccountType,
        // ... other filter values
      });

      // Scenario 2: API finished but no records OR error
      if (!response.data || response.data.length === 0) {
        // Accordion stays open so user can adjust filters
        setIsAccordionExpanded(true);
        showNoResultsMessage();
      } 
      // Scenario 3: API finished with records
      else {
        // Close accordion to show results
        setIsAccordionExpanded(false);
        updateAccountActivityData(response.data);
      }
    } catch (error) {
      // Scenario 2: Error case - keep accordion open
      setIsAccordionExpanded(true);
      showErrorMessage(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAccordionToggle = (expanded: boolean) => {
    setIsAccordionExpanded(expanded);
  };

  return (
    <MVAccordion
      isExpanded={isAccordionExpanded}
      onToggle={handleAccordionToggle}
      onButtonClick={handleApplyFilters}
      loading={isLoading}
      buttonText="Apply Filters"
    >
      <GridItem span={6}>
        <DateRangePicker 
          value={selectedDateRange}
          onChange={setSelectedDateRange}
        />
      </GridItem>
      <GridItem span={6}>
        <AccountTypeDropdown
          value={selectedAccountType}
          onChange={setSelectedAccountType}
        />
      </GridItem>
    </MVAccordion>
  );
}
```

### Three Loading Scenarios Explained

#### Scenario 1: API Call in Progress
```tsx
const handleApplyFilters = async () => {
  setIsLoading(true); // ProgressIndicator appears, button disabled
  // ... API call in progress
};
```
- **ProgressIndicator** appears next to button text
- **Button is disabled** to prevent multiple submissions
- **Accordion state unchanged** during loading

#### Scenario 2: No Results or Error
```tsx
// After API call completes
if (!response.data || response.data.length === 0) {
  setIsAccordionExpanded(true); // Keep accordion open
  showNoResultsMessage();
}
```
- **Accordion stays open** so user can adjust filters
- **Loading state cleared** (`setIsLoading(false)`)
- **User can modify filters and try again**

#### Scenario 3: Successful Results
```tsx
// After API call completes with data
if (response.data && response.data.length > 0) {
  setIsAccordionExpanded(false); // Close accordion
  updateAccountActivityData(response.data);
}
```
- **Accordion closes** to show the results
- **User focus shifts to the data**
- **Accordion can be reopened to modify filters**

### Basic Usage

```tsx
import { MVAccordion } from '@mesh-tenant-multiverse-ui-common/mv-accordion';
import { GridItem } from '@westpac/ui';

function MyFiltersComponent() {
  const handleApply = () => {
    // Handle filter application logic
    console.log('Filters applied!');
  };

  return (
    <MVAccordion
      defaultExpanded={true}
      onButtonClick={handleApply}
    >
      <GridItem span={12}>
        {/* Your filter components go here */}
        <MyDateRangePicker />
      </GridItem>
      <GridItem span={12}>
        <MyDropdown />
      </GridItem>
      {/* Apply button is automatically added */}
    </MVAccordion>
  );
}
```

### With Custom Title and Button Text

```tsx
function CustomAccordion() {
  const customTitle = (
    <div className="flex items-center gap-2">
      <MyCustomIcon />
      <span>Advanced Search</span>
    </div>
  );

  return (
    <MVAccordion
      title={customTitle}
      buttonText="Search Now"
      onButtonClick={handleSearch}
    >
      <GridItem span={12}>
        <MyAdvancedFilters />
      </GridItem>
    </MVAccordion>
  );
}
```

### Controlled State

```tsx
function ControlledAccordion() {
  const [isExpanded, setIsExpanded] = useState(false);

  const handleApply = () => {
    // Your apply logic
  };

  return (
    <MVAccordion
      isExpanded={isExpanded}
      onToggle={setIsExpanded}
      onButtonClick={handleApply}
    >
      <GridItem span={12}>
        {/* Your filter content */}
      </GridItem>
    </MVAccordion>
  );
}
```

## Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `children` | `ReactNode` | - | **Required.** Filter content to display inside the accordion |
| `onButtonClick` | `() => void` | - | **Required.** Callback when apply button is clicked |
| `defaultExpanded` | `boolean` | `false` | Whether accordion starts expanded (uncontrolled mode) |
| `isExpanded` | `boolean` | - | Controlled expansion state - use with `onToggle` |
| `onToggle` | `(expanded: boolean) => void` | - | Callback for expansion state changes |
| `title` | `ReactNode` | Default filter title with icon | Custom title content |
| `buttonText` | `string` | `'Apply'` | Text for the apply button |
| `loading` | `boolean` | `false` | Shows ProgressIndicator and disables button when true |

## Overflow Handling

The component automatically handles overflow for popup components like date pickers and dropdowns:

- **Smart Detection**: Uses MutationObserver to detect when accordion is fully expanded
- **Conditional CSS**: Only applies overflow styles when needed
- **Clean Animations**: Preserves accordion animation without content artifacts
- **Deep Propagation**: Handles nested container overflow issues

## Migration from v0.1.x

If you're upgrading from the previous form-based version:

```tsx
// Before (v0.1.x)
<MVAccordion
  onSubmit={handleSubmit}
  filterFields={[
    {
      id: 'dateRange',
      component: (props) => <DatePicker {...props} />
    }
  ]}
/>

// After (v0.2.x)
<MVAccordion>
  <form onSubmit={handleSubmit}>
    <Grid className="p-0 gap-y-4">
      <GridItem span={12}>
        <DatePicker />
      </GridItem>
      <GridItem span={12}>
        <Button type="submit">Apply</Button>
      </GridItem>
    </Grid>
  </form>
</MVAccordion>
## Best Practices

1. **Grid Layout**: Use Westpac's Grid/GridItem components for consistent spacing
2. **Form Management**: Handle form state in your parent component or using react-hook-form
3. **Accessibility**: Ensure proper labeling and keyboard navigation in your content
4. **Performance**: Only render necessary content to keep accordion responsive

## Dependencies

- `@westpac/ui`: For Accordion and UI components
- `React 18+`: Peer dependency
