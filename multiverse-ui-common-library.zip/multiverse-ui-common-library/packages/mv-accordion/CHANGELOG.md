# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.219.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.0...v1.219.1) (2025-12-19)

### 💥 Bug Fixes

- add back deleted files | ART-88711 ([9b541f6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9b541f66f1babf412fa5f9f318b3533504b1ee0e))

## [1.204.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.203.0...v1.204.0) (2025-10-26)

### 🚀 Features

- update gel package for accordion bug | ART-79216 ([ee97920](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ee97920aaa906746ebabfd4985c6e07c5d91c554))
- updated form with autocomplete prop | ART-79216 ([0f20a03](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/0f20a0307b477cf6a04bd30fd43c88a32bb5ff54))

## [1.203.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.202.0...v1.203.0) (2025-10-24)

### 🚀 Features

- updated onclick event | ART-79216 ([2f42435](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2f4243528c33b038facf307bc8fb7c8a74f013d0))

## [1.202.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.201.2...v1.202.0) (2025-10-24)

### 🚀 Features

- added form tag + removed griditem for children | ART-79216 ([5e6e67e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5e6e67e9e3318c68c05c31905576af40b450b8f6))

## [1.201.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.200.2...v1.201.0) (2025-10-22)

### 🚀 Features

- update button width | ART-79216 ([302b4cd](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/302b4cd14622687b011a6e93b5ea7ac93f90cea1))

## [1.197.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.196.1...v1.197.0) (2025-10-19)

### 🚀 Features

- added textValue to avoid aria errors + added button symbol | ART-79216 ([c3ce97c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c3ce97c145d94a9fce5c86a342c371453f85beab))
- update grid gap | ART-79216 ([57b37ea](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/57b37eabe34354fd5f93b3a05c7131c524276513))

## [1.190.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.189.0...v1.190.0) (2025-10-09)

### 🚀 Features

- added progress indicator + removed uneccessary props | ART-79216 ([ce0601a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ce0601a30bfe496d07f56660a983f97114985a35))
- changed button label ([17ba6b0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/17ba6b074369042bdc7f9790600601691c4b85bf))
- cleaned up filter accordion references | ART-79216 ([931f98a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/931f98a3c607396fd3f301e3fb03d9b9547fec34))
- renamed component name | ART-79216 ([23192af](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/23192af9d86b283a05516f7df44b6c991151be80))
- updated onbuttonclick to address possibly undefined | ART-79216 ([fe9f03c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/fe9f03caabe790fcf7352c8539270dcfc00bbea6))
- updated readme | ART-79216 ([7d89ddc](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/7d89ddc90f9d24f3a87d960676a42f9f2898c11e))

# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2025-10-08

### Breaking Changes

- **Component Rename**: `MVAccordion` renamed to `MVAccordion` for broader use cases
- **Package Rename**: `mv-filter-accordion` renamed to `mv-accordion`
- **Props Rename**: `MVAccordionProps` renamed to `MVAccordionProps`
- **CSS Classes**: All CSS classes updated from `mv-filter-accordion-*` to `mv-accordion-*`

### Added

- **Generic Usage**: Component can now be used for any accordion content, not just filters
- **Improved Documentation**: Updated examples showing various use cases beyond filtering

### Enhanced

- **Broader Applicability**: More semantic naming for general accordion use cases
- **Better Package Structure**: Cleaner package name reflects component flexibility

## [0.3.0] - 2025-10-08

### Added

- **Built-in Apply Button**: Component now includes an apply button within the Grid layout
- **Custom Button Text**: Optional `buttonText` prop to customize apply button text (defaults to "Apply")
- **Apply Callback**: Required `onApply` prop for handling button clicks
- **Button State Support**: Added `disabled` and `loading` props for button state management
- **Auto-close on Apply**: Accordion automatically closes when apply button is clicked

### Enhanced

- **Grid Layout**: Content is now wrapped in a Grid with the apply button as a GridItem
- **Better UX**: Consistent button placement and automatic accordion closing behavior

## [0.2.0] - 2025-10-07

### Breaking Changes

- **Simplified Component API**: Removed all form handling logic and field rendering
- **Children-Based Approach**: Component now accepts `children` prop instead of `filterFields`
- **Removed Dependencies**: No longer depends on `react-hook-form`
- **Simplified Props**: Removed `onSubmit`, `defaultValues`, `filterFields` props

### Added

- **Flexible Children Support**: Can now house any React components as children
- **Custom Title Support**: Optional `title` prop to override default filter title
- **Simplified State Management**: Cleaner accordion state handling

### Enhanced

- **Reusability**: More flexible and reusable across different use cases
- **Performance**: Reduced bundle size by removing form dependencies
- **Maintainability**: Simpler codebase with single responsibility

## [0.1.1] - 2025-10-07

### Enhanced

- **Conditional Overflow Handling**: Wrapper now automatically detects accordion state using MutationObserver
- **Smart CSS Application**: Overflow styles only apply when accordion is fully expanded
- **Clean Animations**: Content properly clips during accordion closing animation
- **Self-Contained Logic**: No external state management required from parent components

### Fixed

- Content persistence during accordion closing animation
- Proper overflow behavior for accordion expand/collapse states

## [0.1.0] - 2025-10-03

### Added

- Initial release of MVAccordion component
- Reusable filter accordion wrapper for MFEs
- Support for factory function pattern and direct JSX components
- Form integration with react-hook-form
- Auto-close accordion after form submission
- PresetsIcon with "Filters" title
- Overflow handling for popup components (date pickers, dropdowns)
- TypeScript support with proper type definitions
- CSS-in-JS styling via wrapper component pattern

### Features

- **MVAccordion**: Main accordion component with form handling
- **MVAccordionWrapper**: Styled wrapper component for overflow fixes
- **Factory Pattern**: Clean TypeScript integration without `any` types
- **Popup Support**: Proper overflow handling for date picker calendars
- **Auto-collapse**: Accordion closes automatically after applying filters
