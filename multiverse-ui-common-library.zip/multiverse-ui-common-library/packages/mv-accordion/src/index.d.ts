import { ReactElement, ReactNode } from 'react';

export interface MVAccordionProps {
  isExpanded?: boolean;
  defaultExpanded?: boolean;
  onToggle?: (isExpanded: boolean) => void;
  onButtonClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
  children: ReactNode;
  title?: ReactNode;
  buttonText?: string;
  disabled?: boolean;
  loading?: boolean;
}

export declare function MVAccordion(props: MVAccordionProps): ReactElement;
export default MVAccordion;
