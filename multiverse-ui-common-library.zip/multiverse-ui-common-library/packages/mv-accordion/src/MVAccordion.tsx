import React, { useState } from 'react';
import {
  Accordion,
  AccordionItem,
  Button,
  Grid,
  GridItem,
  ProgressIndicator,
} from '@westpac/ui';
import { PresetsIcon } from '@westpac/ui/icon';
import { MVAccordionProps } from './index.d';

export function MVAccordion({
  isExpanded,
  defaultExpanded = false,
  onToggle,
  onButtonClick,
  children,
  title = (
    <div className="flex items-center gap-2 typography-body-9">
      <PresetsIcon size="small" />
      Filters
    </div>
  ),
  buttonText = 'Apply',
  loading = false,
}: MVAccordionProps) {
  const [internalExpanded, setInternalExpanded] = useState(defaultExpanded);
  const isControlled = isExpanded !== undefined;
  const expanded = isControlled ? isExpanded : internalExpanded;

  const handleToggle = (newExpanded: boolean) => {
    if (!isControlled) {
      setInternalExpanded(newExpanded);
    }
    onToggle?.(newExpanded);
  };

  const handleButtonClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    onButtonClick?.(event);
  };

  const handleAccordionChange = (expandedKeys: Set<string>) => {
    const isExpanded = expandedKeys.has('accordion-item');
    handleToggle(isExpanded);
  };

  return (
    <Accordion
      rounded
      expandedKeys={expanded ? ['accordion-item'] : []}
      onExpandedChange={handleAccordionChange}
    >
      <AccordionItem
        key="accordion-item"
        title={title}
        textValue="Accordion Section"
      >
        <form autoComplete="off">
          <Grid className="p-0 sm:gap-2.5 xsl:gap-2.5">
            {children}
            <GridItem span={12} className="flex gap-x-1.5">
              <Button
                data-testid="accordion-button"
                size="small"
                look="hero"
                onClick={handleButtonClick}
                disabled={loading}
                iconColor="white"
                className="!min-w-9.5"
              >
                <div>
                  {loading ? <ProgressIndicator color="white" /> : buttonText}
                </div>
              </Button>
            </GridItem>
          </Grid>
        </form>
      </AccordionItem>
    </Accordion>
  );
}

export default MVAccordion;
