import React, { ReactNode, useEffect, useState } from 'react';

type MVAccordionWrapperProps = {
  children: ReactNode;
};
/**
 * Wrapper component for the MVAccordion to manage its expanded state.
 * Temporary solution until a more robust state management is implemented. GEL Ticket Raised.
 */

const MVAccordionWrapper = ({ children }: MVAccordionWrapperProps) => {
  const [isFullyExpanded, setIsFullyExpanded] = useState(false);

  useEffect(() => {
    let expandTimeout: NodeJS.Timeout;

    const observer = new MutationObserver(mutations => {
      mutations.forEach(mutation => {
        if (
          mutation.type === 'attributes' &&
          mutation.attributeName === 'aria-expanded'
        ) {
          const target = mutation.target as HTMLElement;
          const expanded = target.getAttribute('aria-expanded') === 'true';

          if (expanded) {
            if (expandTimeout) clearTimeout(expandTimeout);

            expandTimeout = setTimeout(() => {
              setIsFullyExpanded(true);
            }, 350);
          } else {
            if (expandTimeout) clearTimeout(expandTimeout);
            setIsFullyExpanded(false);
          }
        }
      });
    });

    const findAndObserveAccordion = () => {
      const accordionButton = document.querySelector(
        '.mv-accordion-wrapper [aria-expanded]'
      );
      if (accordionButton) {
        observer.observe(accordionButton, {
          attributes: true,
          attributeFilter: ['aria-expanded'],
        });

        const initialExpanded =
          accordionButton.getAttribute('aria-expanded') === 'true';
        if (initialExpanded) {
          const accordionContent = document.querySelector(
            '.mv-accordion-wrapper [role="region"]'
          ) as HTMLElement;
          if (accordionContent && accordionContent.offsetHeight > 0) {
            setIsFullyExpanded(true);
          } else {
            expandTimeout = setTimeout(() => {
              setIsFullyExpanded(true);
            }, 350);
          }
        }
        return true;
      }
      return false;
    };

    if (!findAndObserveAccordion()) {
      const timeout = setTimeout(findAndObserveAccordion, 100);
      return () => {
        clearTimeout(timeout);
        if (expandTimeout) clearTimeout(expandTimeout);
        observer.disconnect();
      };
    }

    return () => {
      if (expandTimeout) clearTimeout(expandTimeout);
      observer.disconnect();
    };
  }, []);

  return (
    <div className="mv-accordion-wrapper">
      {isFullyExpanded && (
        <style>{`
          .mv-accordion-wrapper [role="region"] {
            overflow: visible !important;
          }

          .mv-accordion-wrapper .westpac-accordion-item-content,
          .mv-accordion-wrapper [class*="accordion"][class*="content"] {
            overflow: visible !important;
          }

          .mv-accordion-wrapper {
            position: relative;
            z-index: 10;
          }

          .mv-accordion-wrapper [data-accordion-item],
          .mv-accordion-wrapper .accordion-item-content,
          .mv-accordion-wrapper [class*="AccordionItem"] {
            overflow: visible !important;
          }

          div:has(.mv-accordion-wrapper),
          section:has(.mv-accordion-wrapper),
          article:has(.mv-accordion-wrapper),
          main:has(.mv-accordion-wrapper) {
            overflow: visible !important;
          }

          .container:has(.mv-accordion-wrapper),
          .content:has(.mv-accordion-wrapper),
          .layout:has(.mv-accordion-wrapper),
          .wrapper:has(.mv-accordion-wrapper),
          .page:has(.mv-accordion-wrapper) {
            overflow: visible !important;
          }

          [class*="grid"]:has(.mv-accordion-wrapper),
          [class*="flex"]:has(.mv-accordion-wrapper),
          [class*="col"]:has(.mv-accordion-wrapper),
          [class*="row"]:has(.mv-accordion-wrapper) {
            overflow: visible !important;
          }

          [class*="overflow-hidden"]:has(.mv-accordion-wrapper),
          [class*="overflow-auto"]:has(.mv-accordion-wrapper) {
            overflow: visible !important;
          }

          .mv-accordion-wrapper .overflow-hidden {
            overflow: visible !important;
          }
          
          .mv-accordion-wrapper .overflow-auto {
            overflow: visible !important;
          }
          
          .mv-accordion-wrapper .overflow-x-hidden {
            overflow-x: visible !important;
          }
          
          .mv-accordion-wrapper .overflow-y-auto {
            overflow-y: visible !important;
          }

          .mv-accordion-wrapper form,
          .mv-accordion-wrapper form *,
          .mv-accordion-wrapper [class*="Grid"],
          .mv-accordion-wrapper [class*="GridItem"] {
            overflow: visible !important;
          }
        `}</style>
      )}
      {children}
    </div>
  );
};

export default MVAccordionWrapper;
