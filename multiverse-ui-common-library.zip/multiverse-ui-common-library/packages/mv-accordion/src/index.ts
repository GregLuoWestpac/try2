export { default as MVAccordion } from './MVAccordion';
export type { MVAccordionProps } from './index.d';
