# MVCopAccountNameCheck Component

The `MVCopAccountNameCheck` component is a React component for displaying Confirmation of Payee (COP) account name verification results. It shows status alerts and detailed messaging based on the verification outcome, helping users understand the result of account name checks before making payments.

## Installation

To install the `MVCopAccountNameCheck` component, you can use npm:

```sh
npm install @mesh-tenant-multiverse-ui-common/mv-cop-accountname-check
```

## Usage

To use the `MVCopAccountNameCheck` component, follow these steps:

1. Import the component in your file:

```tsx
import {
  MVCopAccountNameCheck,
  COPAccountNameCheckRef,
  COPAccountNameCheckProps,
  COPCheckResultData,
} from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
```

2. Add the `MVCopAccountNameCheck` component to your JSX code:

```tsx
<MVCopAccountNameCheck
  copCheckResultData={{
    matchedCOPAccountName: 'John Smith',
    matchedCOPStatusCode: 'V0C1',
  }}
  isError={false}
  errorMessage="Unable to verify account details"
/>
```

## Props

The `MVCopAccountNameCheck` component accepts the following props:

| Prop | Type | Required | Description |
|------|------|----------|-------------|
| `copCheckResultData` | `COPCheckResultData` | Yes | Result data from the COP verification API |
| `isError` | `boolean` | No | Indicates if the API call resulted in an error (default: `false`) |
| `errorMessage` | `string` | No | Error message to display when API call fails |
| `className` | `string` | No | Optional className for additional styling |

## Types

### COPCheckResultData

```typescript
type COPCheckResultData = {
  matchedCOPAccountName: string;
  matchedCOPStatusCode: string;
};
```

### COPAccountNameCheckRef

The component exposes the following methods via ref:

```typescript
type COPAccountNameCheckRef = {
  /** Reset the component state */
  reset: () => void;
};
```

## Features

- **Status Alerts**: Displays contextual alerts based on the COP verification result
- **Collapsible Details**: Shows expandable "What this means" section with detailed messaging
- **Error Handling**: Displays error messages when verification fails
- **Ref-based Control**: Parent components can reset state via ref methods

## Dependencies

This component depends on:
- `@westpac/ui` - For Alert, Collapsible, and Link components
- `@mesh-tenant-multiverse-ui-common/mv-utils` - For COP status response utilities

That's it! You can now use the `MVCopAccountNameCheck` component to display Confirmation of Payee verification results in your payment flows.
