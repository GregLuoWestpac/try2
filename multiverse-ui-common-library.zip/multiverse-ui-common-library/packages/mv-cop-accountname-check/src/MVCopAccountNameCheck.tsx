/* eslint-disable react/require-default-props */
import React, { forwardRef } from 'react';
import { Alert, Collapsible, Link } from '@westpac/ui';
import {
  CoPApiStatusCode,
  CoPNonApiStatusCode,
  mapCoPStatusToMessageProps,
} from '@mesh-tenant-multiverse-ui-common/mv-utils/src/copStatusResponses';
import { COP_COLOR_CODE } from '@mesh-tenant-multiverse-ui-common/mv-apiutils/src/getColorForCoPStatusCode';

/**
 * Result data from the API call
 */
export type COPCheckResultData = {
  matchedCOPAccountName: string;
  matchedCOPStatusCode: CoPApiStatusCode;
  matchedCOPColour?: COP_COLOR_CODE;
};

export type COPAccountNameCheckRef = {
  /** Reset the component state */
  reset: () => void;
};

export type DisplayMode = 'extended' | 'compact';

export type COPAccountNameCheckProps = {
  /** custom UI status, higher priority than status in copCheckResultData */
  customStatus?: CoPNonApiStatusCode;
  /** Result data from the API call */
  copCheckResultData?: COPCheckResultData;
  /** Optional className for styling */
  className?: string;
  /** Display mode for the component */
  displayMode?: DisplayMode;
};

const MVCopAccountNameCheck = forwardRef<
  COPAccountNameCheckRef,
  COPAccountNameCheckProps
>(
  (
    { customStatus, copCheckResultData, className, displayMode = 'extended' },
    ref
  ) => {
    const status = customStatus ?? copCheckResultData?.matchedCOPStatusCode;

    // return if no status found
    if (!status) return null;

    const statusMessage = mapCoPStatusToMessageProps(
      status,
      copCheckResultData?.matchedCOPAccountName ?? ''
    );

    const extendedAlertClass = 'mb-0';
    const compactAlertClass =
      '!m-0 !p-0 !border-0 !text-sm bg-transparent [&_svg]:!ml-0 [&_svg]:!mr-1 [&>*]:!m-0 [&>*]:!p-0';

    return (
      <div
        className={className ?? ''}
        data-testid={`cop-account-name-check-${displayMode === 'compact' ? 'compact' : 'extended'}`}
      >
        {statusMessage && (
          <Alert
            look={statusMessage.look}
            className={
              displayMode === 'compact' ? compactAlertClass : extendedAlertClass
            }
            iconSize="small"
          >
            {statusMessage?.bannerTexts.map((text, index) => (
              <p key={`${customStatus}-${index}`}>{text}</p>
            ))}
          </Alert>
        )}

        {displayMode !== 'compact' &&
          statusMessage?.messageTexts &&
          statusMessage?.messageTexts.length > 0 && (
            <div className="mt-2 mb-2">
              <Collapsible text="What this means:" size="small">
                <ul className="list-disc pl-5">
                  {statusMessage?.messageTexts.map(text => (
                    <li key={text}>{text}</li>
                  ))}
                </ul>

                <Link
                  href="https://www.westpac.com.au/security/how-we-protect-you/westpac-verify/"
                  type="inline"
                  className="mt-2.5"
                >
                  How we verify beneficiary details
                </Link>
              </Collapsible>
            </div>
          )}
      </div>
    );
  }
);

MVCopAccountNameCheck.displayName = 'MVCopAccountNameCheck';

export default MVCopAccountNameCheck;
