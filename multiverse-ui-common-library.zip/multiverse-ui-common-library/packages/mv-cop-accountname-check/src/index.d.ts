export type CoPApiStatusCode =
  // V0
  | 'V0C1'
  | 'V0C2'
  | 'V0C3'
  | 'V0C4'
  | 'V0C5'
  | 'V0C6'
  | 'V0C7'
  | 'V0C8'
  // V1
  | 'V1C1'
  | 'V1C2'
  | 'V1C3'
  | 'V1C4'
  | 'V1C5'
  | 'V1C6'
  | 'V1C7'
  | 'V1C8'
  // V2
  | 'V2C1'
  | 'V2C2'
  | 'V2C3'
  | 'V2C4'
  | 'V2C5'
  | 'V2C6'
  | 'V2C7'
  | 'V2C8'
  // VAC
  | 'VAC1'
  | 'VAC2'
  | 'VAC3'
  | 'VAC4'
  | 'VAC5'
  | 'VAC6'
  | 'VAC7'
  | 'VAC8'
  // VTC
  | 'VTC1'
  | 'VTC2'
  | 'VTC3'
  | 'VTC4'
  | 'VTC5'
  | 'VTC6'
  | 'VTC7'
  | 'VTC8'
  // VEC
  | 'VEC1'
  | 'VEC2'
  | 'VEC3'
  | 'VEC4'
  | 'VEC5'
  | 'VEC6'
  | 'VEC7'
  | 'VEC8';

export type CoPNonApiStatusCode =
  | 'SESSION_OR_DAILY_LIMIT_REACHED'
  | 'USER_DID_NOT_SELECT_CHECK_DETAILS'
  | 'API_ERROR'; // eg. 500, 400 or timtout

export type CoPStatusCode = CoPApiStatusCode | CoPNonApiStatusCode;

// color code passed for SAFI to indicate status of COP (danger, warning or info)
export const enum COP_COLOR_CODE {
  BLUE = 'Blue', //INFO
  AMBER = 'Amber', //WARNING
  RED = 'Red', //DANGER
}

/**
 * Result data from the API call
 */
export type COPCheckResultData = {
  matchedCOPAccountName: string;
  matchedCOPStatusCode: CoPApiStatusCode;
  matchedCOPColour?: COP_COLOR_CODE;
};

export type COPAccountNameCheckRef = {
  /** Reset the component state */
  reset: () => void;
};

export type DisplayMode = 'extended' | 'compact';

export type COPAccountNameCheckProps = {
  /** custom UI status, higher priority than status in copCheckResultData */
  customStatus?: CoPNonApiStatusCode;
  /** Result data from the API call */
  copCheckResultData?: COPCheckResultData;
  /** Optional className for styling */
  className?: string;
  /** Display mode for the component */
  displayMode?: DisplayMode;
};

export const MVCopAccountNameCheck: (
  props: COPAccountNameCheckProps,
  ref: React.Ref<COPAccountNameCheckRef>
) => JSX.Element;
