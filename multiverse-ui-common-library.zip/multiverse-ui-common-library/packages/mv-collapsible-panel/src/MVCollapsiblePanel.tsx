import React, {
  forwardRef,
  useImperativeHandle,
  useState,
  useEffect,
} from 'react';
import './MvCollapsiblePanel.css';

type MVCollapsiblePanelProps = {
  children: React.ReactNode;
  triggerRef: React.RefObject<HTMLElement>;
  shouldCloseOnClick?: boolean;
  defaultOpen?: boolean;
  onClose?: () => void;
  onOpen?: () => void;
};

export type MVCollapsiblePanelHandle = {
  close: () => void;
  open: () => void;
};

const MVCollapsiblePanel = forwardRef<
  MVCollapsiblePanelHandle,
  MVCollapsiblePanelProps
>(
  (
    {
      children,
      triggerRef,
      shouldCloseOnClick = false,
      defaultOpen = false,
      onClose,
      onOpen,
    },
    ref
  ) => {
    const [isOpen, setIsOpen] = useState(defaultOpen);
    const panelState = React.useRef(isOpen);

    useEffect(() => {
      panelState.current = isOpen;
      if (isOpen) {
        onOpen?.();
        triggerRef?.current?.classList.add('panel-open');
      } else {
        onClose?.();
        triggerRef?.current?.classList.remove('panel-open');
      }
    }, [isOpen]);

    const handleClick = () => {
      if (shouldCloseOnClick && panelState.current) {
        setIsOpen(false);
      } else {
        setIsOpen(true);
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.code === 'Enter' || event.code === 'Space') {
        event.preventDefault();
        handleClick();
      }
    };

    useImperativeHandle(ref, () => ({
      close: () => setIsOpen(false),
      open: () => setIsOpen(true),
    }));

    useEffect(() => {
      if (!triggerRef?.current?.classList.contains('mv-collapsible-trigger')) {
        triggerRef?.current?.classList.add('mv-collapsible-trigger');
      }
    }, [triggerRef?.current]);

    useEffect(() => {
      if (triggerRef?.current) {
        triggerRef?.current.addEventListener('click', handleClick, false);
        triggerRef?.current.addEventListener('keydown', handleKeyDown, false);
      }

      return () => {
        if (triggerRef?.current) {
          triggerRef?.current.removeEventListener('click', handleClick, false);
          triggerRef?.current.removeEventListener(
            'keydown',
            handleKeyDown,
            false
          );
        }
      };
    }, []);

    return (
      <div
        className={`mv-collapsible-panel border border-panel-border bg-panel-bg mt-4 p-2.5 br ${isOpen ? 'open' : ''}`}
      >
        {children}
      </div>
    );
  }
);

MVCollapsiblePanel.displayName = 'MVCollapsiblePanel';

export default MVCollapsiblePanel;
