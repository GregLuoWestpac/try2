import * as React from 'react';
import { RefAttributes, ForwardRefExoticComponent } from 'react';

export type MVCollapsiblePanelProps = {
  children: React.ReactNode;
  triggerRef: React.RefObject<HTMLElement>;
  shouldCloseOnClick?: boolean;
  defaultOpen?: boolean;
  onClose?: () => void;
  onOpen?: () => void;
};

export type MVCollapsiblePanelHandle = {
  close: () => void;
  open: () => void;
};

export const MVCollapsiblePanel: ForwardRefExoticComponent<
  MVCollapsiblePanelProps & RefAttributes<MVCollapsiblePanelHandle>
>;
