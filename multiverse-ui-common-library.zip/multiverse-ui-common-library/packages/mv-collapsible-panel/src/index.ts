export { default as MVCollapsiblePanel } from './MVCollapsiblePanel';
