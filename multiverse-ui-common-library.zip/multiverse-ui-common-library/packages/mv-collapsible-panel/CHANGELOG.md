# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.219.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.0...v1.219.1) (2025-12-19)

### 💥 Bug Fixes

- add back deleted files | ART-88711 ([9b541f6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9b541f66f1babf412fa5f9f318b3533504b1ee0e))

## [1.200.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.199.0...v1.200.1) (2025-10-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-collapsible-panel

## [1.199.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.198.0...v1.199.0) (2025-10-20)

### 🚀 Features

- added the package version | ART-82161 ([e324e00](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/e324e00d38c6cd513be34a0e25867e5b97ae70f4))

## [1.198.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.197.0...v1.198.0) (2025-10-20)

### 🚀 Features

- Adding new package MVCollapsiblePanel | ART-82161 ([c700b14](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c700b144d7c11e0f476c2f652445ab75471040e3))
- updated according to review comments | ART-82161 ([477701b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/477701b664b4a528812cdfb351130bfa3f797197))
- updated the styling after shoulder check | ART-82161 ([04d681a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/04d681a6336c7163b21c8c57f7b92977dcf3e584))
- updated the tailwind config, keydown event | ART-82161 ([45b3739](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/45b373915ffe81265bf48cc742c3bbc3e5c9f4a4))
