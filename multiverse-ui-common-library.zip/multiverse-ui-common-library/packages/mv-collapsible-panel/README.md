# MVCollapsiblePanel

MVCollapsiblePanel is a reusable React component for creating collapsible panels in your UI. It allows users to expand or collapse content sections, improving the organization and readability of complex interfaces.

## Installation

```bash
npm install @multiverse-ui/mv-collapsible-panel
```

## Usage

```jsx
import { MVCollapsiblePanel } from '@multiverse-ui/mv-collapsible-panel';

function Example() {
  return (
    <CollapsiblePanel
      triggerRef={elementRef}
      children={`Hi`}
      shouldCloseOnClick={true}
      ref={panelRef}
    ></CollapsiblePanel>
  );
}
```
