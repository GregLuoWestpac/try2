export const CurrencyCode = {
  AustralianDollar: 'AUD',
  UnitedStatesDollar: 'USD',
  Euro: 'EUR',
  NewZealandDollar: 'NZD',
  SingaporeDollar: 'SGD',
  GreatBritishPound: 'GBP',
} as const;

export type CURRENCY_CODE_TYPE =
  (typeof CurrencyCode)[keyof typeof CurrencyCode];
export const SUPPORTED_CURRENCIES = [
  {
    code: CurrencyCode.AustralianDollar,
    symbol: '$',
    amountRegex: '^-?\\d+(\\.\\d{0,2})?$',
    decimalPlaces: 2,
  },
  {
    code: CurrencyCode.UnitedStatesDollar,
    symbol: '$',
    amountRegex: '^-?\\d+(\\.\\d{0,2})?$',
    decimalPlaces: 2,
  },
  {
    code: CurrencyCode.Euro,
    symbol: '€',
    amountRegex: '^-?\\d+(\\.\\d{0,2})?$',
    decimalPlaces: 2,
  },
  {
    code: CurrencyCode.NewZealandDollar,
    symbol: '$',
    amountRegex: '^-?\\d+(\\.\\d{0,2})?$',
    decimalPlaces: 2,
  },
  {
    code: CurrencyCode.SingaporeDollar,
    symbol: 'S$',
    amountRegex: '^-?\\d+(\\.\\d{0,2})?$',
    decimalPlaces: 2,
  },
  {
    code: CurrencyCode.GreatBritishPound,
    symbol: '£',
    amountRegex: '^-?\\d+(\\.\\d{0,2})?$',
    decimalPlaces: 2,
  },
] as const;

type CurrencyAmount = {
  amount: string;
  currencyCode: CURRENCY_CODE_TYPE;
};

export function formatCurrencyString(
  input: string | CurrencyAmount,
  currencyCode: CURRENCY_CODE_TYPE = 'AUD',
  wholeNumbersOnly?: boolean
): string {
  const rawAmount = typeof input === 'object' ? input.amount : input;
  const code = typeof input === 'object' ? input.currencyCode : currencyCode;
  const currency = SUPPORTED_CURRENCIES.find(c => c.code === code);

  if (!currency) {
    return rawAmount;
  }

  const num = Number(rawAmount);

  if (wholeNumbersOnly) {
    if (
      Number.isNaN(num) ||
      rawAmount === '' ||
      num < 0 ||
      rawAmount.includes('.')
    ) {
      return rawAmount;
    }

    return num.toLocaleString('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    });
  }

  if (Number.isNaN(num) || rawAmount === '' || num <= 0) {
    return rawAmount;
  }

  const decimalPart = rawAmount.split('.')[1];

  if (decimalPart && decimalPart.length > currency.decimalPlaces) {
    return rawAmount;
  }

  const formattedNum = num.toLocaleString('en-US', {
    minimumFractionDigits: currency.decimalPlaces,
    maximumFractionDigits: currency.decimalPlaces,
  });

  return formattedNum;
}

export function parseCurrencyString(input: string): string {
  return input.split(',').join('');
}
