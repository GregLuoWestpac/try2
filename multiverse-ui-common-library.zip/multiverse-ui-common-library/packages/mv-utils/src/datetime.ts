import { DateTime, Settings } from 'luxon';
import { AEDT, AEST } from './constants';
import { SYDNEY_ZONE } from '@mesh-tenant-multiverse-ui-common/mv-constants/src';

export { Settings as LuxonSettings };

/**
 * Gets the formatted date and time string for a given ISO date string.
 * If no date string is provided, it uses the current UTC time.
 *
 * @param dateTimeIsoString - The ISO date string to format.
 * @param timeFormat - The format for the time part of the date-time string. Defaults to 'h:mma'.
 * @returns The formatted date-time string in the format 'd LLL yyyy, h:mma (AEDT/AEST)'.
 */
export const getFormattedDateTime = (
  dateTimeIsoString?: string,
  timeFormat: string = 'h:mma'
) => {
  const currentTime = dateTimeIsoString
    ? DateTime.fromISO(dateTimeIsoString).setZone(SYDNEY_ZONE)
    : DateTime.utc().setZone(SYDNEY_ZONE);
  const isDST = currentTime.isInDST;
  const zoneName = isDST ? AEDT : AEST;

  const formattedTime = currentTime.toFormat(timeFormat).toLowerCase();

  const formattedDateTime = `${currentTime.toFormat(
    'd LLL yyyy'
  )}, ${formattedTime} (${zoneName})`;

  return formattedDateTime;
};

/**
 * Gets the formatted date string for a given ISO date string.
 * If no date string is provided, it uses the current UTC time.
 *
 * @param dateTimeIsoString - The ISO date string to format.
 * @param dateFormat - The format for the date part of the date-time string. Defaults to 'd LLL yyyy'.
 * @param displayStyle - The style of the display, either 'date-time' or 'date-time-zone'. Defaults to 'date-time-zone'.
 * @param isDateRequired - If true, returns an empty string if no date string is provided. Defaults to false.
 * @returns The formatted date string in the specified format and style.
 */
export const getFormattedDate = (
  dateTimeIsoString?: string,
  dateFormat: string = 'd LLL yyyy',
  displayStyle: 'date-time' | 'date-time-zone' = 'date-time-zone',
  isDateRequired = false
) => {
  if (isDateRequired && !dateTimeIsoString) return '';
  const currentTime = dateTimeIsoString
    ? DateTime.fromISO(dateTimeIsoString).setZone(SYDNEY_ZONE)
    : DateTime.utc().setZone(SYDNEY_ZONE);
  const isDST = currentTime.isInDST;
  const zoneName = isDST ? AEDT : AEST;

  const formattedDateTime = `${currentTime.toFormat(dateFormat)}${displayStyle === 'date-time-zone' ? ` (${zoneName})` : ''}`;

  return formattedDateTime;
};

/**
 * Gets the end date exclusive for a given ISO date string.
 *
 * @param date - The ISO date string to calculate the end date from.
 * @returns The ISO string of the end date exclusive, in UTC.
 */
export const getEndDateExclusive = (date: string): string | null => {
  let endDate = DateTime.fromISO(date, { zone: SYDNEY_ZONE });
  endDate = endDate.plus({ days: 1 });
  endDate = endDate.startOf('day');
  return endDate.toUTC().toISO();
};

/**
 * Gets the start date inclusive for a given ISO date string.
 *
 * @param date - The ISO date string to calculate the start date from.
 * @returns The ISO string of the start date inclusive, in UTC.
 */
export const getStartDateInclusive = (date: string): string | null => {
  let startDate = DateTime.fromISO(date, { zone: SYDNEY_ZONE });
  startDate = startDate.startOf('day');
  return startDate.toUTC().toISO();
};

/**
 * Converts a Sydney local time string to a UTC ISO string.
 *
 * @param date - The Sydney local time string to convert.
 * @returns The ISO string of the date in UTC.
 */
export type ConvertDateType = 'end';
export function convertSydneyLocalTimeToUtc(
  date: string,
  type?: ConvertDateType
): string | null {
  if (!date) return '';
  const newDate = date.replace(' ', 'T');
  if (type && type === 'end') {
    return DateTime.fromISO(newDate, { zone: SYDNEY_ZONE })
      .endOf('day')
      .toUTC()
      .toISO();
  } else {
    return DateTime.fromISO(newDate, { zone: SYDNEY_ZONE }).toUTC().toISO();
  }
}
/**
 * Formats a date range or sets default values if not provided.
 *
 * @param startDate - The start date of the range.
 * @param endDate - The end date of the range.
 * @returns The formatted date range string in the format `btn:${formattedStartDate},${formattedEndDate}`.
 */
export const formatDateRange = (startDate: string, endDate: string): string => {
  const start = DateTime.fromISO(startDate, { zone: SYDNEY_ZONE }).startOf(
    'day'
  );
  const end = DateTime.fromISO(endDate, { zone: SYDNEY_ZONE }).startOf('day');

  const formattedStartDate = start.toFormat('yyyy-MM-dd');
  const formattedEndDate = end.toFormat('yyyy-MM-dd');

  return `btn:${formattedStartDate},${formattedEndDate}`;
};

/**
 * Formats a date range string.
 *
 * @param startDate - The start date of the range.
 * @param endDate - The end date of the range.
 * @returns The formatted date range string, for example, btn:2024-07-17T00:00:00.000Z,2025-07-17T23:59:59.999Z.
 */
export function dateRangeString(startDate: string, endDate: string): string {
  const start = DateTime.fromISO(startDate, { zone: SYDNEY_ZONE }).startOf(
    'day'
  );
  const end = DateTime.fromISO(endDate, { zone: SYDNEY_ZONE }).endOf('day');

  const formattedStartDate = start.toFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
  const formattedEndDate = end.toFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

  return `btn:${formattedStartDate},${formattedEndDate}`;
}

/**
 * Return current financial year in UI.
 * @returns The financial year as number, for example, 2024, 2025.
 */
export function getCurrentFinancialYear(): number {
  const { month, year } = DateTime.utc().setZone(SYDNEY_ZONE);
  return month < 7 ? year : year + 1;
}
