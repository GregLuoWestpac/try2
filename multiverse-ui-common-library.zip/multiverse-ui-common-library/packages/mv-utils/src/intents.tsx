/* eslint-disable @typescript-eslint/no-explicit-any */
import React, {
  ComponentType,
  FC,
  useCallback,
  useEffect,
  useRef,
  useState,
} from 'react';
import { useSelector } from 'react-redux';
import { getURLParams, isStaffPortal } from './urlUtils';
import MVPageLoader from '../../mv-pageloader/src/MVPageLoader';
import {
  useRaiseIntent,
  useIntentListener,
  usePageContext,
  PageContextRecord,
  useIsCompositeDesktop,
  useIsDesktopVersion,
} from '@mesh-tenant-multiverse-common/react';

export function withIntent<P extends object>(
  useGlobalDispatch: any,
  intentName: string
) {
  return (WrappedComponent: ComponentType<P>): FC<P> => {
    function WithIntent(props: P) {
      const globalDispatch = useGlobalDispatch();
      const intentListener = useIntentListener(intentName);
      const loading = intentListener?.loading ?? true;
      let pageContext: PageContextRecord;

      const isOpenFin = useIsCompositeDesktop();
      const isOpenFinDesktop = useIsDesktopVersion();

      if (isOpenFinDesktop) {
        const pageContextObj = usePageContext();
        console.log('pageContextObj', pageContextObj);
        pageContext = pageContextObj?.context;
      }
      const [storeReady, setStoreReady] = useState(false);
      const intentTimestampRef = useRef<number | null>(null);
      const data = intentListener?.context?.data as Record<string, unknown>;

      // Get the current intentTimestamp from Redux
      const reduxIntentTimestamp = useSelector(
        (state: any) => state?.global?.galaxy?.context?.intentTimestamp
      );

      useEffect(() => {
        if (!loading && (pageContext || !isOpenFinDesktop)) {
          const orgId = pageContext?.contextKey || pageContext?.name;
          const ts = Date.now();
          intentTimestampRef.current = ts;
          globalDispatch({
            type: 'galaxy/context/update',
            data: {
              ...data,
              ...(orgId && {
                orgId,
              }),
              ...(pageContext && {
                pageContext,
              }),
              intentTimestamp: ts,
            },
          });
        }
      }, [data, pageContext, loading, globalDispatch]);
      console.log('intentListener: ', intentListener);

      useEffect(() => {
        if (
          intentTimestampRef.current &&
          reduxIntentTimestamp === intentTimestampRef.current
        ) {
          setStoreReady(true);
        }
      }, [reduxIntentTimestamp]);

      if (!storeReady && isOpenFin) return <MVPageLoader />;

      return <WrappedComponent {...props} />;
    }
    return WithIntent;
  };
}

export type handleRaiseIntentParams = {
  intentName: string;
  intentContextName: string;
  targetPath?: string;
  data?: Record<string, unknown>;
  contextKey?: string;
  intentId?: Record<string, unknown>;
  viewOptions?: Record<string, unknown>;
};

export const useHandleRaiseIntent = (
  useGlobalDispatch: any,
  useNavigate: any
) => {
  const navigate = useNavigate();
  const raiseIntent = useRaiseIntent();
  const globalDispatch = useGlobalDispatch();

  const navigateAndDispatch = useCallback(
    (targetPath: string, data?: Record<string, unknown>) => {
      data &&
        globalDispatch({
          type: 'galaxy/context/update',
          data: {
            ...data,
            isBrowser: true,
          },
        });
      navigate(`${targetPath}${getURLParams()}`);
    },
    []
  );

  const handleRaiseIntent = useCallback(
    async ({
      intentName,
      intentContextName,
      targetPath,
      data,
      contextKey,
      intentId,
      viewOptions,
    }: handleRaiseIntentParams) => {
      const { windowTabKey, ...restViewOptions } = viewOptions || {};
      try {
        await raiseIntent(intentName, {
          type: intentContextName,
          ...((contextKey || intentId) && {
            id: {
              ...(contextKey && {
                contextKey,
              }),
              ...intentId,
            },
          }),
          ...(data && {
            data,
          }),
          viewOptions: {
            isOrgScoped: true,
            ...(isStaffPortal() && windowTabKey && { windowTabKey }),
            ...restViewOptions,
          },
        });
      } catch (e) {
        console.error('OpenFin Intent Error: ', e);
        targetPath && navigateAndDispatch(targetPath, data);
      }
    },
    []
  );

  return handleRaiseIntent;
};
