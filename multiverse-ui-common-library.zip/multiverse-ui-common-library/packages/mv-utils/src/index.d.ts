import { ComponentType, FC, Ref } from 'react';
export { Settings as LuxonSettings } from 'luxon';

export const ChannelTypeCodeCustomer = {
  /**
   * W1C Customer Portal via unknown Openfin mode and any device
   */
  W1C_U_A_CP: 'W1C_U_A_CP',
  /**
   * W1C Customer Portal via Openfin application via non-desktop device
   */
  W1C_O_U_CP: 'W1C_O_U_CP',
  /**
   * W1C Customer Portal via Openfin on browser via desktop
   * */
  W1C_O_B_D_CP: 'W1C_O_B_D_CP',
  /**
   * W1C Customer Portal via Openfin on browser via tablet
   */
  W1C_O_B_T_CP: 'W1C_O_B_T_CP',
  /**
   * W1C Customer Portal via Openfin on browser via mobile
   */
  W1C_O_B_M_CP: 'W1C_O_B_M_CP',
  /**
   * W1C Customer Portal via Openfin application via desktop
   */
  W1C_O_A_D_CP: 'W1C_O_A_D_CP',
} as const;

export const ChannelTypeCodeStaff = {
  /**
   * W1C Staff Portal via Openfin application via desktop
   */
  W1C_O_A_D_SP: 'W1C_O_A_D_SP',
  /**
   * W1C Staff Portal via Openfin on browser via desktop
   */
  W1C_O_B_D_SP: 'W1C_O_B_D_SP',
  /**
   * W1C Staff Portal via unknown Openfin mode and any device
   */
  W1C_U_A_SP: 'W1C_U_A_SP',
} as const;

/**
 * Type definition for the screen
 */

export function scrollToTop(): void;

/**
 * Type definition for the debounce
 */

export function debounce(
  callback: () => void,
  time: number,
  finalCallback: () => void
): () => void;

/**
 * Type definition for the dateTime
 */

export function getFormattedDateTime(
  dateTimeIsoString?: string,
  timeFormat?: string
): string;

export function getFormattedDate(
  dateTimeIsoString?: string,
  dateFormat?: string,
  displayStyle?: 'date-time' | 'date-time-zone',
  isDateRequired?: boolean
): string;

export function getEndDateExclusive(date: string): string | null;

export function getStartDateInclusive(date: string): string | null;

export type ConvertDateType = 'end';
export function convertSydneyLocalTimeToUtc(
  data: string,
  type?: ConvertDateType
): string | null;

export function formatDateRange(startDate: string, endDate: string): string;
export function dateRangeString(startDate: string, endDate: string): string;
export function getCurrentFinancialYear(): number;

/**
 * Type definition for the crypto
 */

export const base64ToArrayBuffer: (base64: string) => ArrayBufferLike;
export const generateKeyFromBase64: (
  base64: string,
  KeyUsage: KeyUsage[]
) => Promise<CryptoKey>;
export const decryptDataChunkFromString: (
  encryptedChunkString: string,
  key: CryptoKey
) => Promise<unknown>;

/**
 * Type definition for the format
 */

export const formatToTwoDecimals: (input: string) => string;
export function prefixWithISOCurrency(
  currency: string,
  value: string | number
): string;
export function currencyFormatter(num?: number, locale?: string): string;
export function formatWithEllipsis(str?: string, maxLength?: number): string;

export function formatCurrency(value: number | ''): string;
export function formatPercentage(rate: number): string;
export function formatBSB(id: string | undefined, index: number): string;
export const formatBSBFromAccNo: (
  accountNo: string | undefined,
  bsbLength?: number
) => string;

export type SupportedCurrency = {
  code: string;
  symbol: string;
  amountRegex: string;
  decimalPlaces: number;
};

export const SUPPORTED_CURRENCIES: readonly SupportedCurrency[];

/**
 * Type definition for the ref
 */

export const mergeRefs: <T>(refs: Ref<T>[]) => (value: T) => void;

/**
 * Type definition for the urlUtils
 */

export const getURLParams: () => string;
export const getAppUrlWithParams: (newUrl: string, appName?: string) => string;
export const getAppUrlWithoutParams: (
  newUrl: string,
  appName?: string
) => string;
export const isStaffPortal: () => boolean;

export type CurrencyAmount = {
  amount: string;
  currencyCode: 'AUD' | 'USD' | 'NZD' | 'EUR' | 'SGD' | 'GBP';
};
export function formatCurrencyString(
  input: string | CurrencyAmount,
  currencyCode?: 'AUD' | 'USD' | 'NZD' | 'EUR' | 'SGD' | 'GBP'
): string;
export const parseCurrencyString: (input: string) => string;

/**
 * Type definition for appCorrelationId
 */
type SetAppCorrelationId = (id: string) => void;
export const useAppCorrelationId: (
  setAppCorrelationId: SetAppCorrelationId
) => string;

/**
 * Type definition for checkEntitlementError
 */
type EntitlementErrorAction = {
  type: string;
  payload: unknown;
};
export const checkEntitlementError: (
  action: EntitlementErrorAction,
  excludeActions?: string[]
) => void;

/**
 * Type definition for intents
 */

export type handleRaiseIntentParams = {
  intentName: string;
  intentContextName: string;
  targetPath?: string;
  data?: Record<string, unknown>;
  contextKey?: string;
  intentId?: Record<string, unknown>;
  viewOptions?: Record<string, unknown>;
};

export function withIntent<P extends object>(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  useGlobalDispatch: any,
  intentName: string,
  supportBrowser?: boolean
): (WrappedComponent: ComponentType<P>) => FC<P>;

export const useHandleRaiseIntent: (
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  useGlobalDispatch: any,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  useNavigate: any
) => ({
  intentName,
  intentContextName,
  targetPath,
  data,
  contextKey,
  intentId,
  viewOptions,
}: handleRaiseIntentParams) => Promise<void>;

/**
 * Type definition for the mv-utils
 */

/**
 * @deprecated This function is deprecated and will be removed in future releases. Use sanitiseWithPattern instead.
 */
export const sanitise: (
  input: string,
  pattern: string,
  maxLength?: number
) => string;

export const sanitiseWithPattern: (
  input: string,
  pattern: string,
  maxLength?: number
) => string;

export const ACCOUNT_HOLDER_PATTERN = '^[a-zA-Z0-9\- !,.:\;?_]+$';
export const ACCOUNT_NAME_PATTERN = '^[a-zA-Z0-9\- !,.:\;?_]+$';

export const PAYMENT_DESCRIPTION_PATTERN = '^[a-zA-Z0-9\- !,.:\;?_]+$';
export const PAYMENT_REFERENCE_PATTERN = '^[a-zA-Z0-9\- !,.:\;?_]+$';
export const TRANSFER_DESCRIPTION_PATTERN = '^[a-zA-Z0-9\- !,.:\;?_]+$';

export const ACCOUNT_NAME_MAX_LENGTH = 70;

export type ChannelTypeCode =
  | (typeof ChannelTypeCodeCustomer)[keyof typeof ChannelTypeCodeCustomer]
  | (typeof ChannelTypeCodeStaff)[keyof typeof ChannelTypeCodeStaff];

export const useGetChannelTypeCode: (openFinHooks: {
  useIsDesktopVersion: () => boolean;
  useIsWebVersion: () => boolean;
  useIsCompositeDesktop: () => boolean;
}) => ChannelTypeCode;

// type definition for the useCheckEntitlementError
export const useCheckEntitlementError: (
  error: any,
  useNavigate: NavigateFunction,
  excludeApiNames: string[],
  apiName: string
) => void;

/**
 * Confirmation of Payee - Map the COP status to GEL UI Alert component 'look' prop
 */
export const enum COP_STATUS_LOOK {
  INFO = 'info',
  WARNING = 'warning',
  DANGER = 'danger',
}

/**
 * Type for the Confirmation of Payee status response for approval workflow
 */
export type CoPStatusMessageProps = {
  bannerTexts: JSX.Element[];
  messageTexts: string[];
  look: COP_STATUS_LOOK;
};

/**
 * All possible CoP API status codes - single source of truth
 */
declare const allCoPApiStatusCodes: readonly [
  'V0C1',
  'V0C2',
  'V0C3',
  'V0C4',
  'V0C5',
  'V0C6',
  'V0C7',
  'V0C8',
  'V1C1',
  'V1C2',
  'V1C3',
  'V1C4',
  'V1C5',
  'V1C6',
  'V1C7',
  'V1C8',
  'V2C1',
  'V2C2',
  'V2C3',
  'V2C4',
  'V2C5',
  'V2C6',
  'V2C7',
  'V2C8',
  'VAC1',
  'VAC2',
  'VAC3',
  'VAC4',
  'VAC5',
  'VAC6',
  'VAC7',
  'VAC8',
  'VTC1',
  'VTC2',
  'VTC3',
  'VTC4',
  'VTC5',
  'VTC6',
  'VTC7',
  'VTC8',
  'VEC1',
  'VEC2',
  'VEC3',
  'VEC4',
  'VEC5',
  'VEC6',
  'VEC7',
  'VEC8',
];

export type CoPApiStatusCode = (typeof allCoPApiStatusCodes)[number];

export type CoPNonApiStatusCode =
  | 'SESSION_OR_DAILY_LIMIT_REACHED'
  | 'USER_DID_NOT_SELECT_CHECK_DETAILS'
  | 'API_ERROR'; // eg. 500, 400 or timtout

export type CoPStatusCode = CoPApiStatusCode | CoPNonApiStatusCode;

/**
 * Get messages for a particular Confirmation of Payee (CoP) status code.
 * - sample pages: Add beneficiary, Update beneficiary, Make a payment, Payment authorisation details, Beneficiary authorisation details pages
 * @param statusCode handles both API status code and Non-Api status
 * @param accountName account name of payee
 */
export const mapCoPStatusToMessageProps: (
  statusCode: CoPStatusCode,
  accountName: string
) => CoPStatusMessageProps | null;
export const CurrencyCode = {
  AustralianDollar: 'AUD',
  UnitedStatesDollar: 'USD',
  Euro: 'EUR',
  NewZealandDollar: 'NZD',
  SingaporeDollar: 'SGD',
  GreatBritishPound: 'GBP',
} as const;

export type CURRENCY_CODE_TYPE =
  (typeof CurrencyCode)[keyof typeof CurrencyCode];
