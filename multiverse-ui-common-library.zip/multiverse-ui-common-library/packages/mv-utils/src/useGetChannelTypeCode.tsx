import { isMobileOnly, isTablet, isDesktop } from 'react-device-detect';
import { ChannelTypeCodeCustomer, ChannelTypeCodeStaff } from './constants';
import { ChannelTypeCode } from './index.d';
import { isStaffPortal as checkIsStaffPortal } from './urlUtils';

/**
 * @description solution design: https://confluence.srv.westpac.com.au/pages/viewpage.action?pageId=1864183677
 * isCompositeDesktop not required as conditions are covered by default cases
 * @param {Object} openFinHooks are from '@mesh-tenant-multiverse-common/react'
 * @returns channel code based on 3 factors:
 *   - openfin mode
 *   - portal type
 *   - device type
 */
export const useGetChannelTypeCode = (openFinHooks: {
  useIsDesktopVersion: () => boolean;
  useIsWebVersion: () => boolean;
}): ChannelTypeCode => {
  const { useIsDesktopVersion, useIsWebVersion } = openFinHooks;
  const isOpenfinDesktop = useIsDesktopVersion();
  const isOpenfinWeb = useIsWebVersion();
  const isStaffPortal = checkIsStaffPortal();

  let newChannelTypeCode: ChannelTypeCode = ChannelTypeCodeCustomer.W1C_U_A_CP;
  // staff portal
  if (isStaffPortal) {
    newChannelTypeCode = ChannelTypeCodeStaff.W1C_U_A_SP;
    if (isDesktop) {
      if (isOpenfinWeb) {
        newChannelTypeCode = ChannelTypeCodeStaff.W1C_O_B_D_SP;
      } else if (isOpenfinDesktop) {
        newChannelTypeCode = ChannelTypeCodeStaff.W1C_O_A_D_SP;
      }
    }
  } else {
    // client portal
    if (isOpenfinWeb) {
      if (isDesktop) {
        newChannelTypeCode = ChannelTypeCodeCustomer.W1C_O_B_D_CP;
      } else if (isTablet) {
        newChannelTypeCode = ChannelTypeCodeCustomer.W1C_O_B_T_CP;
      } else if (isMobileOnly) {
        newChannelTypeCode = ChannelTypeCodeCustomer.W1C_O_B_M_CP;
      }
    } else if (isOpenfinDesktop) {
      newChannelTypeCode = isDesktop
        ? ChannelTypeCodeCustomer.W1C_O_A_D_CP
        : ChannelTypeCodeCustomer.W1C_O_U_CP;
    }
  }

  return newChannelTypeCode;
};
