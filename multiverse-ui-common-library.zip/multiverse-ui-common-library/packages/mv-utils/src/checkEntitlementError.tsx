import { NavigateFunction } from 'react-router-dom';
import { getAppUrlWithoutParams } from './urlUtils';

type EntitlementErrorAction = {
  type: string;
  payload: unknown;
};

export const checkEntitlementError = (
  action: EntitlementErrorAction,
  excludeActions: string[] = []
) => {
  const { type, payload } = action;
  const error = payload?.['error'];
  if (
    !excludeActions?.includes(type) &&
    error?.status === 403 &&
    error?.data?.errors?.some(e => e.code === 8210)
  ) {
    window.location.href = getAppUrlWithoutParams('/error');
    return;
  }
};

export const useCheckEntitlementError = (
  error: any,
  useNavigate: NavigateFunction,
  excludeApiNames:  string[] ,
  apiName : string
) => {
  if (
    !excludeApiNames?.includes(apiName) &&
    error?.status === 403 &&
    error?.data?.errors?.some(e => e.code === 8210)
  ) {
    useNavigate('/error');
    return;
  }
};
