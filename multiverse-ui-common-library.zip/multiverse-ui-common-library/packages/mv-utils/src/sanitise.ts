/**
 * @deprecated This function is deprecated and will be removed in future releases. Use sanitiseWithPattern instead.
 */
export const sanitise = (
  input: string,
  pattern: string,
  maxLength?: number
): string => {
  if (!input) return '';
  if (!pattern) return input;

  const regex = new RegExp(pattern);
  let sanitisedOutput = input
    .split('')
    .filter(char => regex.test(char))
    .join('');
  if (maxLength !== undefined) {
    sanitisedOutput = sanitisedOutput.slice(0, maxLength);
  }
  return sanitisedOutput;
};
