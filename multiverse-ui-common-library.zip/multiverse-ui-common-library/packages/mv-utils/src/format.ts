/**
 * Prefixes the value with the ISO currency code for supported currencies.
 * Formats the value with thousand separators and two decimal places.
 * Supported: AUD, USD, EUR, NZD, SGD, GBP
 * @param currency - ISO currency code
 * @param value - The value to prefix
 * @returns The value prefixed with the ISO currency code and formatted (e.g., "AUD 2,000,000.75"), or just the value if not supported
 */
export function prefixWithISOCurrency(
  currency: string,
  value: string | number
): string {
  const supportedCurrencies = ['AUD', 'USD', 'EUR', 'NZD', 'SGD', 'GBP'];
  const upperCurrency = currency.toUpperCase();

  if (supportedCurrencies.includes(upperCurrency)) {
    const numValue = typeof value === 'string' ? parseFloat(value) : value;
    if (isNaN(numValue)) {
      return `${upperCurrency} ${value}`;
    }
    const formattedValue = new Intl.NumberFormat('en-AU', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(numValue);
    return `${upperCurrency} ${formattedValue}`;
  }
  return String(value);
}
/**
 * Formats the input string to two decimal places.
 *
 * @param {string} input - The input string to be formatted.
 * @returns {string} The formatted string with two decimal places.
 * @throws {Error} If the input is not a valid number.
 */
export const formatToTwoDecimals = (input: string) => {
  const num = Number(input);
  if (Number.isNaN(num)) {
    throw new Error('Input does not match the required format');
  }
  return num.toFixed(2);
};

/**
 * Formats a number as currency according to the specified locale.
 *
 * @param {number} [num] - The number to be formatted.
 * @param {string} [locale='en-AU'] - The locale to use for formatting.
 * @returns {string} The formatted currency string.
 */
export function currencyFormatter(
  num?: number,
  locale: string = 'en-AU'
): string {
  if (num === undefined) {
    return '';
  }

  // Normalize -0 to 0
  if (Object.is(num, -0)) {
    num = 0;
  }

  return new Intl.NumberFormat(locale, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(num);
}

/**
 * Formats a string with an ellipsis if it exceeds the specified maximum length.
 *
 * @param {string} [str] - The string to be formatted.
 * @param {number} [maxLength] - The maximum length of the string before adding an ellipsis.
 * @returns {string} The formatted string with an ellipsis if it exceeds the maximum length.
 */
export const formatWithEllipsis = (
  str?: string,
  maxLength?: number
): string => {
  if (str === undefined || maxLength === undefined) {
    return '';
  }
  return str.length > maxLength ? `${str.substring(0, maxLength)}...` : str;
};

/**
 * Formats a number as currency with a dollar sign and comma separators.
 *
 * @param {number | ''} value - The value to be formatted.
 * @returns {string} The formatted currency string.
 */
export const formatCurrency = (value: number | ''): string => {
  if (value === '') return '';
  return `$${value.toLocaleString('en-AU', { minimumFractionDigits: 2 })}`;
};

/**
 * Formats a number as a percentage with two decimal places and 'p.a.' suffix.
 *
 * @param {number} rate - The rate to be formatted.
 * @returns {string} The formatted percentage string.
 */
export const formatPercentage = (rate: number): string => {
  return `${(rate * 100).toFixed(2)}% p.a.`;
};

/**
 * Formats a given string by inserting a hyphen at the specified index (like '123456' to '123-456').
 *
 * @param {string | undefined} id - The string to be formatted.
 * @param {number} index - The position at which to insert the hyphen.
 * @returns {string} The formatted string with a hyphen inserted at the specified index, or an empty string if the input string is falsy.
 */
export const formatBSB = (id: string | undefined, index: number) => {
  if (!id) return '';
  return `${id.slice(0, index)}-${id.slice(index)}`;
};

/**
 * Formats the BSB and account number from a given account name.
 *
 * @param {string | undefined} accountNo - The account name containing BSB and account number.
 * @param {number} [bsbLength=3] - Optional parameter to specify the length for formatting BSB.
 * @returns {string} The formatted BSB and account number.
 */
export const formatBSBFromAccNo = (
  accountNo: string | undefined,
  bsbLength: number = 3
): string => {
  if (!accountNo) return '';
  const bsb = accountNo.slice(0, 6).trim();
  const accNo = accountNo.slice(6).trim();
  const formattedBsb = formatBSB(bsb, bsbLength);
  return `${formattedBsb} ${accNo}`.trim();
};
