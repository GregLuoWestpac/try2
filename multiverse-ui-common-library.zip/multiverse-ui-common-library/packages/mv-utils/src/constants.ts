export const AEDT = 'AEDT';
export const AEST = 'AEST';

export enum HTTP_STATUS_CODES {
  OK = 200,
  CREATED = 201,
  ACCEPTED = 202,
  NO_CONTENT = 204,
  PARTIAL_CONTENT = 206,
  BAD_REQUEST = 400,
  UNAUTHORIZED = 401,
  FORBIDDEN = 403,
  NOT_FOUND = 404,
  METHOD_NOT_ALLOWED = 405,
  PAYLOAD_TOO_LARGE = 413,
  INTERNAL_SERVER_ERROR = 500,
  SERVICE_UNAVAILABLE = 503,
}

export const ISG_APPROVED_STRING = '^[a-zA-Z0-9\- !,.:\;?_@]*$';
export const ACCOUNT_HOLDER_PATTERN = ISG_APPROVED_STRING;
export const ACCOUNT_NAME_PATTERN = ISG_APPROVED_STRING;
export const PAYMENT_DESCRIPTION_PATTERN = ISG_APPROVED_STRING;
export const PAYMENT_REFERENCE_PATTERN = ISG_APPROVED_STRING;
export const TRANSFER_DESCRIPTION_PATTERN = ISG_APPROVED_STRING;

export const ACCOUNT_NAME_MAX_LENGTH = 70;

/**
 * Channel code reference https://confluence.srv.westpac.com.au/pages/viewpage.action?pageId=1864183677
 */

export const ChannelTypeCodeCustomer = {
  /**
   * W1C Customer Portal via unknown Openfin mode and any device
   */
  W1C_U_A_CP: 'W1C_U_A_CP',
  /**
   * W1C Customer Portal via Openfin application via non-desktop device
   */
  W1C_O_U_CP: 'W1C_O_U_CP',
  /**
   * W1C Customer Portal via Openfin on browser via desktop
   * */
  W1C_O_B_D_CP: 'W1C_O_B_D_CP',
  /**
   * W1C Customer Portal via Openfin on browser via tablet
   */
  W1C_O_B_T_CP: 'W1C_O_B_T_CP',
  /**
   * W1C Customer Portal via Openfin on browser via mobile
   */
  W1C_O_B_M_CP: 'W1C_O_B_M_CP',
  /**
   * W1C Customer Portal via Openfin application via desktop
   */
  W1C_O_A_D_CP: 'W1C_O_A_D_CP',
} as const;

export const ChannelTypeCodeStaff = {
  /**
   * W1C Staff Portal via Openfin application via desktop
   */
  W1C_O_A_D_SP: 'W1C_O_A_D_SP',
  /**
   * W1C Staff Portal via Openfin on browser via desktop
   */
  W1C_O_B_D_SP: 'W1C_O_B_D_SP',
  /**
   * W1C Staff Portal via unknown Openfin mode and any device
   */
  W1C_U_A_SP: 'W1C_U_A_SP',
} as const;
