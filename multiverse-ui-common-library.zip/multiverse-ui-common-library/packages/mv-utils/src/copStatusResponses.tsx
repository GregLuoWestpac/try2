/* eslint-disable react/no-unescaped-entities */
/* eslint-disable react/jsx-key */
import React from 'react';
/**
 * Confirmation of Payee - Map the COP status to GEL UI Alert component 'look' prop
 */
export const enum COP_STATUS_LOOK {
  INFO = 'info',
  WARNING = 'warning',
  DANGER = 'danger',
}

/**
 * Type for the Confirmation of Payee status response for approval workflow
 */
export type CoPStatusMessageProps = {
  bannerTexts: JSX.Element[];
  messageTexts: string[];
  look: COP_STATUS_LOOK;
};

/**
 * All possible CoP codes from API
 * - single source of truth
 * - readonly array allows unittests to verify all statuses are covered
 */
export const allCoPApiStatusCodes = [
  // V0
  'V0C1',
  'V0C2',
  'V0C3',
  'V0C4',
  'V0C5',
  'V0C6',
  'V0C7',
  'V0C8',
  // V1
  'V1C1',
  'V1C2',
  'V1C3',
  'V1C4',
  'V1C5',
  'V1C6',
  'V1C7',
  'V1C8',
  // V2
  'V2C1',
  'V2C2',
  'V2C3',
  'V2C4',
  'V2C5',
  'V2C6',
  'V2C7',
  'V2C8',
  // VAC
  'VAC1',
  'VAC2',
  'VAC3',
  'VAC4',
  'VAC5',
  'VAC6',
  'VAC7',
  'VAC8',
  // VTC
  'VTC1',
  'VTC2',
  'VTC3',
  'VTC4',
  'VTC5',
  'VTC6',
  'VTC7',
  'VTC8',
  // VEC
  'VEC1',
  'VEC2',
  'VEC3',
  'VEC4',
  'VEC5',
  'VEC6',
  'VEC7',
  'VEC8',
] as const;

export type CoPApiStatusCode = (typeof allCoPApiStatusCodes)[number];

export type CoPNonApiStatusCode =
  | 'SESSION_OR_DAILY_LIMIT_REACHED'
  | 'USER_DID_NOT_SELECT_CHECK_DETAILS'
  | 'API_ERROR'; // eg. 500, 400 or timtout

export type CoPStatusCode = CoPApiStatusCode | CoPNonApiStatusCode;

/**
 * Get messages for a particular Confirmation of Payee (CoP) status code.
 * - sample pages: Add beneficiary, Update beneficiary, Make a payment, Payment authorisation details, Beneficiary authorisation details pages
 * @param status handles both API status code and Non-Api status
 * @param accountName account name of payee
 */
export const mapCoPStatusToMessageProps = (
  statusCode: CoPStatusCode,
  accountName: string
): CoPStatusMessageProps | null => {
  const ThisInNameOfBannerText = (
    <span>
      This account is in the name of{' '}
      <span className="font-semibold">{accountName}</span>.
    </span>
  );
  const TheInNameOfBannerText = (
    <span>
      The account is in the name of{' '}
      <span className="font-semibold">{accountName}</span>.
    </span>
  );

  const wrongPayeeAccDisclaimer = `If you pay the wrong account or it's a scam, you may not get your money back.`;

  // To store return value
  let response: CoPStatusMessageProps | null = null;

  switch (statusCode) {
    case 'V0C1': {
      response = {
        bannerTexts: [ThisInNameOfBannerText],
        messageTexts: [
          `This name matches what is held at the beneficiary's bank.`,
          `Make sure you check the BSB and account number. Call them if possible. Account names are not used to process payments.`,
          wrongPayeeAccDisclaimer,
        ],
        look: COP_STATUS_LOOK.INFO,
      };
      break;
    }
    case 'V0C2': {
      response = {
        bannerTexts: [ThisInNameOfBannerText],
        messageTexts: [
          `This name closely matches what is held at the beneficiary's bank.`,
          `Make sure you check the BSB and account number. Call them if possible and confirm the account name. Account names are not used to process payments.`,
          wrongPayeeAccDisclaimer,
        ],
        look: COP_STATUS_LOOK.INFO,
      };
      break;
    }
    case 'V0C3': {
      response = {
        bannerTexts: [
          <span>The account name entered does not match the account.</span>,
          <span>
            However, we see this name is commonly used to pay this account.
          </span>,
        ],
        messageTexts: [
          `The beneficiary might be using a different name. You can ask them for their exact account name and try again to check if it's a match.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'V0C4': {
      response = {
        bannerTexts: [
          TheInNameOfBannerText,
          <span>
            {`The name entered doesn't match, but we've seen this name used
            before to pay this account.`}
          </span>,
        ],
        messageTexts: [
          `The business might be using a different name or they're not who you think they are.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'V0C5': {
      response = {
        bannerTexts: [
          <span>We could not confirm the account name match.</span>,
        ],
        messageTexts: [
          `We can't retrieve the account details from the beneficiary's bank.`,
          `Make sure you check the BSB and account number. Call them if possible and confirm the account name. Account names are not used to process payments.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'V0C6': {
      response = {
        bannerTexts: [
          <span>We could not confirm the account name match.</span>,
          <span>
            However, we see this name is commonly used to pay this account.
          </span>,
        ],
        messageTexts: [
          `We can't retrieve the account details from the beneficiary's bank right now. You can try again later or continue.`,
          `Make sure you check the BSB and account number. Call them if possible and confirm the account name. Account names are not used to process payments.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.INFO,
      };
      break;
    }
    case 'V0C7': {
      response = {
        bannerTexts: [
          <span>This account is closed or does not exist.</span>,
          <span>Contact the beneficiary to confirm the details.</span>,
        ],
        messageTexts: [],
        look: COP_STATUS_LOOK.DANGER,
      };
      break;
    }
    case 'V0C8': {
      response = {
        bannerTexts: [
          <span>We could not confirm the account name match.</span>,
          <span>
            However, we see this name is commonly used to pay this account.
          </span>,
        ],
        messageTexts: [
          `We can't retrieve the account details from the beneficiary's bank right now. You can try again later or continue.`,
          `Make sure you check the BSB and account number. Call them if possible and confirm the account name. Account names are not used to process payments.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.INFO,
      };
      break;
    }
    case 'V1C1': {
      response = {
        bannerTexts: [
          TheInNameOfBannerText,
          <span>
            However, we can't find many payments made to this account.
          </span>,
        ],
        messageTexts: [
          `This name matches what is held at the beneficiary's bank, but we can't find many payments so it may be a new account.`,
          `Make sure you check the BSB and account number. Call them if possible and confirm the account name. Account names are not used to process payments.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'V1C2': {
      response = {
        bannerTexts: [
          TheInNameOfBannerText,
          <span>
            However, we can't find many payments made to this account.
          </span>,
        ],
        messageTexts: [
          `This name closely matches what is held at the beneficiary's bank, but we can't find many payments so it may be a new account.`,
          `Make sure you check the BSB and account number. Call them if possible and confirm the account name. Account names are not used to process payments.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'V1C3': {
      response = {
        bannerTexts: [
          <span>The account name entered does not match the account.</span>,
          <span>We also can't find many payments made to this account.</span>,
        ],
        messageTexts: [
          `The beneficiary may not be who you think they are.`,
          `We can't find many payments to this account, so it may be a new account.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'V1C4': {
      response = {
        bannerTexts: [
          TheInNameOfBannerText,
          <span>
            The name entered doesn't match, and we haven't seen many payments to
            this account.
          </span>,
        ],
        messageTexts: [
          `The business may not be who you think they are.`,
          `We can't find many payments to this account, so it may be a new account.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'V1C5': {
      response = {
        bannerTexts: [
          <span>We could not confirm the account name match.</span>,
          <span>We also can't find many payments made to this account.</span>,
        ],
        messageTexts: [
          `We can't retrieve the account details from the beneficiary's bank.`,
          `We can't find many payments to this account, so it may be a new account.`,
          `Check the BSB and account number. Call them if possible and confirm the account name. We can't find many payments, so it may be a new account.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'V1C6': {
      response = {
        bannerTexts: [
          <span>We could not confirm the account name match.</span>,
          <span>We also can't find many payments made to this account.</span>,
        ],
        messageTexts: [
          `We can't retrieve the account details from the beneficiary's bank. You can try again later.`,
          `We can't find many payments to this account, so it may be a new account.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'V1C7': {
      response = {
        bannerTexts: [
          <span>This account is closed or doesn't exist.</span>,
          <span>Contact the payee to confirm the details.</span>,
        ],
        messageTexts: [],
        look: COP_STATUS_LOOK.DANGER,
      };
      break;
    }
    case 'V1C8': {
      response = {
        bannerTexts: [
          <span>We could not confirm the account name match.</span>,
          <span>We also can't find many payments made to this account.</span>,
        ],
        messageTexts: [
          `We can't retrieve the account details from the beneficiary's bank. You can try again later.`,
          `We can't find many payments to this account, so it may be a new account.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'V2C1': {
      response = {
        bannerTexts: [
          TheInNameOfBannerText,
          <span>
            However, we don't see this name used by other customers to pay this
            account.
          </span>,
        ],
        messageTexts: [
          `This name matches what is held at the beneficiary's bank, but we see other names used to pay this account. The beneficiary might be using a different name.`,
          `Check the BSB and account number. Call them if possible and confirm the account name. Account names are not used to process payments.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'V2C2': {
      response = {
        bannerTexts: [
          TheInNameOfBannerText,
          <span>
            However, we don't see this name used by other customers to pay this
            account.
          </span>,
        ],
        messageTexts: [
          `This name closely matches what is held at the beneficiary's bank, but we see other names used to pay this account. The beneficiary might be using a different name.`,
          `Check the BSB and account number. Call them if possible and confirm the account name. Account names are not used to process payments.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'V2C3': {
      response = {
        bannerTexts: [
          <span>The account name entered does not match the account.</span>,
          <span>
            We also don't see this name used by other customers to pay this
            account.
          </span>,
        ],
        messageTexts: [
          `The beneficiary may not be who you think they are. We see other names used to pay this account.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }

    case 'V2C4': {
      response = {
        bannerTexts: [
          TheInNameOfBannerText,
          <span>
            The name entered doesn't match, and we don't see it used to pay this
            account.
          </span>,
        ],
        messageTexts: [
          `The business may not be who you think they are. We see other names used to pay this account.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }

    case 'V2C5': {
      response = {
        bannerTexts: [
          <span>We could not confirm the account name match.</span>,
          <span>
            We also don't see this name used by other customers to pay this
            account.
          </span>,
        ],
        messageTexts: [
          `We can't retrieve the account details from the beneficiary's bank right now, and the beneficiary may not be who you think they are.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'V2C6': {
      response = {
        bannerTexts: [
          <span>We could not confirm the account name match.</span>,
          <span>
            We also don't see this name used by other customers to pay this
            account.
          </span>,
        ],
        messageTexts: [
          `We can't retrieve the account details from the beneficiary's bank right now. You can try again later.`,
          `We see other names used to pay this account. The beneficiary may not be who you think they are.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'V2C7': {
      response = {
        bannerTexts: [
          <span>This account is closed or does not exist.</span>,
          <span>Contact the beneficiary to confirm the details.</span>,
        ],
        messageTexts: [],
        look: COP_STATUS_LOOK.DANGER,
      };
      break;
    }
    case 'V2C8': {
      response = {
        bannerTexts: [
          <span>We could not confirm the account name match.</span>,
          <span>
            We also don't see this name used by other customers to pay this
            account.
          </span>,
        ],
        messageTexts: [
          `We can't retrieve the account details from the beneficiary's bank right now. You can try again later.`,
          `We see other names used to pay this account. The beneficiary may not be who you think they are.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'VAC1':
    case 'VTC1':
    case 'VEC1': {
      response = {
        bannerTexts: [ThisInNameOfBannerText],
        messageTexts: [
          `This name matches what is held at the beneficiary's bank, but we can't check if there's been any payments made by other customers to this account right now.`,
          `Make sure you check the BSB and account number. Call them if possible and confirm the account name. Account names are not used to process payments.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.INFO,
      };
      break;
    }
    case 'VAC2':
    case 'VTC2':
    case 'VEC2': {
      response = {
        bannerTexts: [ThisInNameOfBannerText],
        messageTexts: [
          `This name closely matches what is held at the beneficiary's bank, but we can't check if there's been any payments made by other customers to this account right now.`,
          `Make sure you check the BSB and account number. Call them if possible and confirm the account name. Account names are not used to process payments.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'VAC3':
    case 'VTC3':
    case 'VEC3': {
      response = {
        bannerTexts: [
          <span>The account name entered does not match the account.</span>,
        ],
        messageTexts: [
          `The beneficiary may not be who you think they are.`,
          `We can't check if there's been any payments made by other customers to this account right now.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'VAC4':
    case 'VTC4':
    case 'VEC4': {
      response = {
        bannerTexts: [
          TheInNameOfBannerText,
          <span>The name entered does not match the account.</span>,
        ],
        messageTexts: [
          `The business may not be who you think they are.`,
          `We can't check if there's been any payments made by other customers to this account right now.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'VAC5':
    case 'VTC5':
    case 'VEC5': {
      response = {
        bannerTexts: [
          <span>We could not confirm the account name match.</span>,
        ],
        messageTexts: [
          `We can't retrieve the account details from the beneficiary's bank. We also can't check if there's been any payments made by other customers to this account right now. You can try again later.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'VAC6':
    case 'VTC6':
    case 'VEC6':
    case 'API_ERROR': {
      response = {
        bannerTexts: [
          <span>We could not confirm the account name match.</span>,
        ],
        messageTexts: [
          `We can't retrieve the account details from the beneficiary's bank right now. We also can't check if there's been any payments made by other customers to this account. You can try again later.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'VAC7':
    case 'VTC7':
    case 'VEC7': {
      response = {
        bannerTexts: [
          <span>This account is closed or does not exist.</span>,
          <span>Contact the beneficiary to confirm the details.</span>,
        ],
        messageTexts: [],
        look: COP_STATUS_LOOK.DANGER,
      };
      break;
    }
    case 'VAC8':
    case 'VTC8':
    case 'VEC8': {
      response = {
        bannerTexts: [
          <span>We could not confirm the account name match.</span>,
        ],
        messageTexts: [
          `We can't retrieve the account details from the beneficiary's bank right now. We also can't check if there's been any payments made by other customers to this account. You can try again later.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'SESSION_OR_DAILY_LIMIT_REACHED': {
      response = {
        bannerTexts: [
          <span>We could not confirm the account name match.</span>,
        ],
        messageTexts: [
          `We can't retrieve the account details from the beneficiary's bank right now. We also can't 
check if there's been any payments made by other customers to this account.`,
          `You can try again later or continue.`,
          `Check the BSB and account number. Call them if possible and confirm the account name.`,
          wrongPayeeAccDisclaimer,
        ],

        look: COP_STATUS_LOOK.WARNING,
      };
      break;
    }
    case 'USER_DID_NOT_SELECT_CHECK_DETAILS': {
      response = {
        bannerTexts: [
          <span>
            Select <span className="font-semibold">Check details</span>
            to verify the account details.
          </span>,
        ],
        messageTexts: [],
        look: COP_STATUS_LOOK.DANGER,
      };
      break;
    }
  }

  return response;
};
