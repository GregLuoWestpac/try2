import { Ref, MutableRefObject } from 'react';

export const mergeRefs = <T>(refs: Ref<T>[]) => {
  return (value: T) => {
    refs.forEach(ref => {
      if (typeof ref === 'function') {
        ref(value);
      } else if (ref !== null) {
        (ref as MutableRefObject<T>).current = value;
      }
    });
  };
};
