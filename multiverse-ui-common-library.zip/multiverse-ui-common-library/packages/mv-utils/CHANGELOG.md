# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.230.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.229.1...v1.230.0) (2026-02-16)

### 🚀 Features

- update mv util intent params | ART-97842 ([0162320](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/016232062d4e763198ca9263820716b3292dc6f9))

## [1.229.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.228.0...v1.229.0) (2026-02-12)

### 🚀 Features

- add prefixWithISOCurrency function to format currency values | ART-85171 ([4c899f9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4c899f964708889b2dc98ed62290830a4ed8c0c9))

## [1.228.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.227.0...v1.228.0) (2026-02-12)

### 🚀 Features

- enhance prefixWithISOCurrency to format values | ART-85171 ([7437beb](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/7437beb0e7585525f4b481fc860f88e4066febf5))
- update prop name and added variable | ART-88591 ([8674205](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8674205971bd3c1589cfc00e3ed20649b23496e6))
- uplift currency string formatting for treasury page | ART-88591 ([51e2822](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/51e2822b1f8c263c587e5007981a3578c53941c9))

## [1.227.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.226.2...v1.227.0) (2026-02-11)

### 🚀 Features

- add prefixWithISOCurrency function with tests for supported currencies | ART-85171 ([eee5e8b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/eee5e8bcef1bb48f3b7ad268545962936855d4aa))

## [1.226.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.225.5...v1.226.0) (2026-02-06)

### 🚀 Features

- add pageContext in data | ART-98468 ([02d8c0e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/02d8c0e44e7ca320858c18536b435228b6d87755))
- add pagecontext name in orgId | ART-98468 ([e6d42fb](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/e6d42fbdc3e7119e0646eb74a19a83810b085bb2))

## [1.225.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.225.1...v1.225.2) (2026-02-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.224.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.223.3...v1.224.0) (2026-01-29)

### 🚀 Features

- update mv currency | ART-88675 ([282490b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/282490b67720306b312f6e6b3d528e4c7ee5db6d))
- update mv currency with balanceAmount input | ART-88675 ([a896ad3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a896ad3b0161648bb063ff8d44e9062079e8d6c3))

## [1.222.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.221.6...v1.222.0) (2026-01-26)

### 🚀 Features

- export supported currency | ART-85294 ([960d6c3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/960d6c357269188b37c8616ad4a5e4e06d7337a1))

## [1.221.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.220.0...v1.221.0) (2026-01-19)

### 🚀 Features

- add currency support function and array object | feature/ART-88675 ([07001c5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/07001c59352ec491426ede064dfabd2fd531c01f))

## [1.219.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.218.0...v1.219.0) (2025-12-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.184.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.184.3...v1.184.4) (2025-09-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.184.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.184.2...v1.184.3) (2025-09-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.182.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.182.3...v1.182.4) (2025-09-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.177.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.177.0...v1.177.1) (2025-08-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.174.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.174.0...v1.174.1) (2025-08-07)

### 💥 Bug Fixes

- update function description | ART-68532 ([d9a59bc](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d9a59bcfc2441e7f0199afb353cbd7543d5fab5a))

## [1.173.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.173.1...v1.173.2) (2025-08-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.172.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.171.8...v1.172.0) (2025-07-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.171.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.171.2...v1.171.3) (2025-07-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.171.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.171.1...v1.171.2) (2025-07-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.171.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.170.1...v1.171.0) (2025-07-21)

### 🚀 Features

- created getAppUrlWithoutParams() for entitlement error nav | ART-68385 ([e37532c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/e37532cc349eb31f38e4752d8c67ef81d4564392))

## [1.166.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.166.0...v1.166.1) (2025-07-18)

### 💥 Bug Fixes

- add 10x key to the context | ART-68038 ([ed85999](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ed85999750c03e700e267f3c749d0c7685b996a3))
- obtain ciskey if context key is not present | ART-68038 ([e9329a7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/e9329a7311e620036cbeca5d9252a26ef9b5beaa))
- spread the pageContext into global context | ART-68038 ([497ebb5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/497ebb576b619b0686f655b6a205e339259569b8))

## [1.163.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.162.0...v1.163.0) (2025-07-17)

### 🚀 Features

- add dateRangeString() ([0d30598](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/0d30598ac833493f4954b2d886769e5bedbae59c))

## [1.162.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.161.1...v1.162.0) (2025-07-17)

### 🚀 Features

- updated test to pass | ART-67994 ([afb4048](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/afb4048b20b1b7a75eba2efe12cb10a670020532))

### 💥 Bug Fixes

- added getAppURLWithParams to error path | ART-67994 ([8aedfb3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8aedfb385cd09a4285e22bda3e0854f41add94e8))

## [1.160.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.160.2...v1.160.3) (2025-07-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.160.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.160.1...v1.160.2) (2025-07-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.160.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.160.0...v1.160.1) (2025-07-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.160.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.159.0...v1.160.0) (2025-07-11)

### 🚀 Features

- check openFin env in withIntent | ART-66590 ([2452722](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2452722ad07bea483d9eebf52ea6df9892a4767d))

## [1.159.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.158.0...v1.159.0) (2025-07-10)

### 🚀 Features

- update support browser in withIntent | ART-66590 ([9589d6c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9589d6ca7756dc6d990ae10a5a881e6958922912))

## [1.157.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.156.2...v1.157.0) (2025-07-09)

### 🚀 Features

- save orgID from pageContext to redux store | ART-66590 ([c7f1e37](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c7f1e3752b8d8110e1482dc88aa6c10b1f17291a))

## [1.156.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.155.0...v1.156.0) (2025-07-07)

### 🚀 Features

- added react import and use this to replace params | ART-66589 ([5f8468b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5f8468b67d45cf7e29eb0b2a62367b522bd01814))

## [1.155.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.154.0...v1.155.0) (2025-07-07)

### 🚀 Features

- implement the loading field from openFin hook | ART-66589 ([c17bc1b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c17bc1b8c2808ce8183abfc1d60a109b5ebae6e5))

## [1.153.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.152.0...v1.153.0) (2025-07-03)

### 🚀 Features

- field validations august uplift swagger and library changes | ART-54463 ([d9c00c5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d9c00c54fdb9620a5863e62194bdbf1c53d08b3f))

## [1.151.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.151.0...v1.151.1) (2025-07-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.150.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.149.0...v1.150.0) (2025-06-27)

### 🚀 Features

- added condition in withIntent component | ART-65316 ([ede477f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ede477fde61b082c661bb193c4804b45fa68cb92))

## [1.148.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.147.2...v1.148.0) (2025-06-25)

### 🚀 Features

- remove checking data before updating intentTimestamp | ART-60783 ([22e12f2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/22e12f2ef3702db684c33f23ee991917be4a1d85))

### 💥 Bug Fixes

- resolve data sync issue in redux store and component | ART-60783 ([31eb09a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/31eb09a3602140db35951a4a2ede771ca6c607a1))
- show page loader if shouldWaitForGalaxyContext is enable | ART-60783 ([3d49b6e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3d49b6e7b7266c98d09c883a94707722cb0794d0))

## [1.147.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.147.1...v1.147.2) (2025-06-19)

### 💥 Bug Fixes

- adding ISG approved pattern | ART-58848 ([ec30877](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ec308774b36eaf019db33c3b4ea85b2ccf593a9d))

## [1.140.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.139.1...v1.140.0) (2025-06-05)

### 🚀 Features

- add intentTimestamp in the withIntnet hoc | ART-58610 ([2f824a6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2f824a65e980afdf75769b2d5f9b7e8195f6caa4))

## [1.123.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.122.0...v1.123.0) (2025-05-08)

### 🚀 Features

- add the intentId definition | ART-52229 ([b8c64f3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b8c64f362c8c38dd36d4c82203c803c6bdd81689))

## [1.107.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.106.1...v1.107.0) (2025-04-11)

### 🚀 Features

- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([594177d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/594177d636efb09433616fb547bd15943b45cd7b))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([3af09bb](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3af09bbff1483f0cf7b78c00962d83e75b1a6c06))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([0e919f9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/0e919f9c96bf092f96848d49a6865092771e85f9))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([d669003](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d66900372028af334ff041d6b0faa013c210448c))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([c525d07](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c525d07adf5b1fa897de0c2cb672640808f0d1f6))

## [1.102.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.102.1...v1.102.2) (2025-04-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.91.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.90.0...v1.91.0) (2025-03-25)

### 🚀 Features

- ART-44081-update convertSydneyLocalTimeToUtc ([f37b49c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f37b49c78d0eb5625580b37879a1bfe4ea09a236))

## [1.82.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.81.1...v1.82.0) (2025-03-19)

### 🚀 Features

- added validation pattern for payment and transfer description fields ([2bf5fca](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2bf5fca2f2784fb8e05ed615f832688c9e75da43))

## [1.80.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.80.0...v1.80.1) (2025-03-13)

### 💥 Bug Fixes

- add constants file to index file export list | ART-43809 ([b61ea77](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b61ea77e6a0bac085184e8b2569f0301364e2373))

## [1.79.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.78.0...v1.79.0) (2025-03-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.76.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.75.1...v1.76.0) (2025-03-12)

### 🚀 Features

- create text sanitizer function | ART-43809 ([a121149](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a121149af494e8fa527246ba4939e3fec08e6f5c))
- create text sanitizer function | ART-43809 ([be543c5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/be543c53039030a0df4e2c079de959fb4ac8d35e))
- create text sanitizer function | ART-43809 ([dfdca24](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/dfdca2428a563ea02d55344d4d50bfe09967e67a))

## [1.74.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.74.2...v1.74.3) (2025-03-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.74.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.74.0...v1.74.1) (2025-03-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.74.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.73.0...v1.74.0) (2025-03-10)

### 🚀 Features

- export tranformPdpResponse in index.d.ts JIRA:ART-36101 ([09dcaa2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/09dcaa222ee28e631b3ea53aebf9cb956ca69c24))

## [1.72.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.72.0...v1.72.1) (2025-03-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.72.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.71.3...v1.72.0) (2025-03-10)

### 🚀 Features

- added enum for pdp query action ([d271664](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d27166485032f8ac9b0e2e64f37d53e90d71d4b6))
- added enum in index.d.js ([ab09c29](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ab09c2986bfb94078bec0ecbd62620d9d659c770))
- added transformPdpResponse util function with unit tests: JIRA: ART-36101 ([b4c1698](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b4c1698d03c656246be0e2ce59af030fe4ad7458))

## [1.71.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.71.2...v1.71.3) (2025-03-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.69.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.68.0...v1.69.0) (2025-02-28)

### 🚀 Features

- added types in library/src and mv-utils/src JIRA: ART-41647 ([02647dd](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/02647dd0b74088f686756734723489675241fcef))
- common util to check entitlement auth error : JIRA: ART-41647 ([aeeee14](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/aeeee1452c260ce1fd72124eda45c773b3170b2f))
- handle multiple errors :JIRA-41647 ([b822971](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b822971922e9e1d0bc0340023a9cb89fd5ae1ef2))
- removed the length check for excludeActions : JIRA: ART-41647 ([87e8454](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/87e84545d5048e2eafc45302564995d5e9142305))

## [1.67.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.66.3...v1.67.0) (2025-02-26)

### 🚀 Features

- fix for decimal display in amount| ART-39135 ([65280e0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/65280e080224e965ca8af2afdb3505e321dcee8d))
- fix for decimal display in amount| ART-39135 ([173a38f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/173a38fc6dcf3ab83e36da358d01ec160494e5cc))
- update test case for formatcurrency | ART-39135 ([968f2c5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/968f2c5b733662b858c12410f34bd2b6693f88c0))

## [1.63.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.62.1...v1.63.0) (2025-02-21)

### 🚀 Features

- remove redundant code | ART-36119 ([e079372](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/e079372d449453d0194034d23dfafa5277735ed0))

## [1.60.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.59.0...v1.60.0) (2025-02-13)

### 🚀 Features

- dateRange formatter | ART-27663 ([648c091](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/648c091d40666b8718d0fa40f486cc0fcffdc238))

## [1.58.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.58.1...v1.58.2) (2025-02-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.56.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.55.5...v1.56.0) (2025-02-05)

### 🚀 Features

- recommit changes using latest version | ART-36119 ([72c1413](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/72c14135fbba3bce83450ab127692490b7e71263))
- update jest config | ART-36119 ([93b1364](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/93b1364369e795c610a6a80caeae1dfa3962cc03))

## [1.53.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.53.0...v1.53.1) (2025-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.51.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.51.0...v1.51.1) (2025-01-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.49.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.48.3...v1.49.0) (2025-01-21)

### 🚀 Features

- update format-bsb util function | ART-15927 ([3eaaca0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3eaaca0703830fb94583bee7392e8c264c04006d))

## [1.48.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.47.2...v1.48.0) (2025-01-20)

### 🚀 Features

- add util function to format bsb from account no | ART-15508 ([c070a66](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c070a663bec35da2bc482556360ef34bb50e2eca))

## [1.45.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.44.1...v1.45.0) (2025-01-15)

### 🚀 Features

- added BSB formatter utility function | ART-28182 ([b7fdb74](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b7fdb745f8871612510803c3bce9ab0476c84252))

## [1.40.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.40.0...v1.40.1) (2024-12-19)

### 💥 Bug Fixes

- Revert APIError component | ART-31297 ([85f361c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/85f361c5ff8aa0befb13c1106afb73f21c5f10cb))

## [1.40.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.39.5...v1.40.0) (2024-12-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.39.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.39.2...v1.39.3) (2024-12-17)

### 💥 Bug Fixes

- add throwAPIError function | ART-31297 ([66b0bdd](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/66b0bdd382b031732d99889e8aeb943cc2fd2eab))
- unit test fixes | ART-31297 ([4044aa9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4044aa981540fe60a4b68c753f3357bf0ae82c36))

## [1.39.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.39.0...v1.39.1) (2024-12-16)

### 💥 Bug Fixes

- update export of APIError util | ART-31297 ([b2151f2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b2151f2d283a1072d0696d94e9e65a9add2c2631))

## [1.34.9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.8...v1.34.9) (2024-12-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.34.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.2...v1.34.3) (2024-12-06)

### 💥 Bug Fixes

- conditionally display the time zone JIRA: ART-31648 ([bcbbdb2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/bcbbdb2c4d6235c1c9b314c0d242b98606e29ed0))
- conditionally display the time zone JIRA: ART-31648 ([856b412](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/856b412a68774d973e0b7caa38e23cd7851c182f))

## [1.33.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.33.2...v1.33.3) (2024-12-03)

### 💥 Bug Fixes

- sonar cube major code smell | ART-31297 ([3fb6e20](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3fb6e20c667ff7f7b4362cef48cafcc6bceadb01))

## [1.33.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.32.1...v1.33.0) (2024-11-28)

### 🚀 Features

- add 2 more format helper functions JIRA: ART-14311 ([7a0019b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/7a0019ba0fc7f5143f1729eb3e5307ef2319f6a1))
- format update JIRA: ART-14311 ([4af654a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4af654ad4197a44649bc33ad36f4f1acb44d5814))

## [1.32.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.32.0...v1.32.1) (2024-11-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.31.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.31.0...v1.31.1) (2024-11-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.28.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.27.0...v1.28.0) (2024-11-20)

### 🚀 Features

- postArrangementDetails API - add convertSydneyLocalTimeToUtc in .d.ts | ART-14302 ([cd17356](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/cd17356957992cea05a1379d6b8df9d1081587e1))
- postArrangementDetails API - add convertSydneyLocalTimeToUtc in .d.ts | ART-14302 ([9e32d6b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9e32d6babeab138c926fad07090ae1854193c952))

## [1.27.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.26.0...v1.27.0) (2024-11-20)

### 🚀 Features

- postArrangementDetails API - add convertSydneyLocalTimeToUtc | ART-14302 ([623fc14](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/623fc14235f4d9edb87677e282103b9bdc9b696c))
- postArrangementDetails API - clean up | ART-14302 ([227d80d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/227d80d9a10bddab0b1efdbec1da3d59e65430fb))
- postArrangementDetails API - rollback | ART-14302 ([a50ec7b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a50ec7bbdf3ef406bc2588c6d3c6fe4323040ca3))

## [1.26.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.25.3...v1.26.0) (2024-11-20)

### 🚀 Features

- update utils currentcy controller | ART-24649 ([99d58b2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/99d58b2dc7a7b6df8efad9a99f46130b747aadec))

## [1.21.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.21.1...v1.21.2) (2024-11-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.21.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.21.0...v1.21.1) (2024-11-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.20.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.20.0...v1.20.1) (2024-11-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.17.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.16.0...v1.17.0) (2024-11-04)

### 🚀 Features

- update ref to mv-tiles | ART-24649 ([8b6714a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8b6714a965edc022a7702c86e40364d2c51ed5b9))
- update ref with unit test and remove useless code | ART-24649 ([5932336](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5932336d90bab094a26a4fb17ce228622fb21aef))

## [1.12.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.12.5...v1.12.6) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-utils

## [1.12.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.11.0...v1.12.0) (2024-10-24)

### 🚀 Features

- add ag-grid | ART-15347 ([4d7a0ce](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4d7a0cec74717df4226dbbb8eaa4a9057c1d5168))

## [1.11.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.10.0...v1.11.0) (2024-10-23)

### 🚀 Features

- add refresh widget and form controller | ART-24650 ([3c642b6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3c642b6738b45ef17cb7b0ced7b641d9d2cfdcd2))
