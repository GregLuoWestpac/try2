import React from 'react';
import '@testing-library/jest-dom';
import { render, screen } from '@testing-library/react';

import {
  mapCoPStatusToMessageProps,
  COP_STATUS_LOOK,
  type CoPStatusCode,
} from '@mesh-tenant-multiverse-ui-common/mv-utils/src/copStatusResponses';

const ACCOUNT_NAME = 'Chris Smith';

// Helper: render banner JSX elements so we can assert on visible text
function renderBanners(bannerTexts: JSX.Element[]) {
  return render(
    <div>
      {bannerTexts.map((b, idx) => (
        <div key={idx} data-testid={`banner-${idx}`}>
          {b}
        </div>
      ))}
    </div>
  );
}

describe('mapCoPStatusToMessageProps', () => {
  it('returns null for unknown status values (safety guard)', () => {
    // Cast to bypass TS union for negative test
    const res = mapCoPStatusToMessageProps(
      'NOT_A_REAL_CODE' as CoPStatusCode,
      ACCOUNT_NAME
    );
    expect(res).toBeNull();
  });

  describe('INFO (blue) statuses', () => {
    const cases: Array<{ status: CoPStatusCode; expectedBannerLines: number }> =
      [
        { status: 'V0C1', expectedBannerLines: 1 },
        { status: 'V0C2', expectedBannerLines: 1 },
        { status: 'V0C6', expectedBannerLines: 2 },
        { status: 'V0C8', expectedBannerLines: 2 },
        { status: 'VAC1', expectedBannerLines: 1 },
        { status: 'VTC1', expectedBannerLines: 1 },
        { status: 'VEC1', expectedBannerLines: 1 },
      ];

    test.each(cases)(
      '$status maps to INFO',
      ({ status, expectedBannerLines }) => {
        const res = mapCoPStatusToMessageProps(status, ACCOUNT_NAME);
        expect(res).not.toBeNull();
        expect(res!.look).toBe(COP_STATUS_LOOK.INFO);
        expect(res!.bannerTexts).toHaveLength(expectedBannerLines);
        expect(res!.messageTexts.length).toBeGreaterThanOrEqual(0);

        // Any "in the name of" banners should include the account name
        // (Some statuses have banners that don't include the name; this check is only for those that do)
        if (
          res!.bannerTexts.some(b =>
            /in the name of/i.test((b.props?.children ?? '').toString())
          )
        ) {
          renderBanners(res!.bannerTexts);
          expect(
            screen.getAllByText(ACCOUNT_NAME, { exact: false }).length
          ).toBeGreaterThan(0);
        }
      }
    );
  });

  describe('WARNING (amber) statuses', () => {
    const cases: Array<{
      status: CoPStatusCode;
      expectedBannerLines?: number;
    }> = [
      // V0
      { status: 'V0C3', expectedBannerLines: 2 },
      { status: 'V0C4', expectedBannerLines: 2 },
      { status: 'V0C5', expectedBannerLines: 1 },

      // V1
      { status: 'V1C1', expectedBannerLines: 2 },
      { status: 'V1C2', expectedBannerLines: 2 },
      { status: 'V1C3', expectedBannerLines: 2 },
      { status: 'V1C4', expectedBannerLines: 2 },
      { status: 'V1C5', expectedBannerLines: 2 }, // opt-out + not enough payments (per your mapping)
      { status: 'V1C6', expectedBannerLines: 2 },
      { status: 'V1C8', expectedBannerLines: 2 },

      // V2
      { status: 'V2C1', expectedBannerLines: 2 },
      { status: 'V2C2', expectedBannerLines: 2 },
      { status: 'V2C3', expectedBannerLines: 2 },
      { status: 'V2C4', expectedBannerLines: 2 },
      { status: 'V2C5', expectedBannerLines: 2 },
      { status: 'V2C6', expectedBannerLines: 2 },
      { status: 'V2C8', expectedBannerLines: 2 },

      // VAC / VTC / VEC
      { status: 'VAC2', expectedBannerLines: 1 },
      { status: 'VTC2', expectedBannerLines: 1 },
      { status: 'VEC2', expectedBannerLines: 1 },

      { status: 'VAC3', expectedBannerLines: 1 },
      { status: 'VTC3', expectedBannerLines: 1 },
      { status: 'VEC3', expectedBannerLines: 1 },

      { status: 'VAC4', expectedBannerLines: 2 },
      { status: 'VTC4', expectedBannerLines: 2 },
      { status: 'VEC4', expectedBannerLines: 2 },

      { status: 'VAC5', expectedBannerLines: 1 },
      { status: 'VTC5', expectedBannerLines: 1 },
      { status: 'VEC5', expectedBannerLines: 1 },

      { status: 'VAC6', expectedBannerLines: 1 },
      { status: 'VTC6', expectedBannerLines: 1 },
      { status: 'VEC6', expectedBannerLines: 1 },

      { status: 'VAC8', expectedBannerLines: 1 },
      { status: 'VTC8', expectedBannerLines: 1 },
      { status: 'VEC8', expectedBannerLines: 1 },

      // Non-API
      { status: 'SESSION_OR_DAILY_LIMIT_REACHED', expectedBannerLines: 1 },
      { status: 'API_ERROR', expectedBannerLines: 1 },
    ];

    test.each(cases)(
      '$status maps to WARNING',
      ({ status, expectedBannerLines }) => {
        const res = mapCoPStatusToMessageProps(status, ACCOUNT_NAME);
        expect(res).not.toBeNull();
        expect(res!.look).toBe(COP_STATUS_LOOK.WARNING);
        if (expectedBannerLines != null) {
          expect(res!.bannerTexts).toHaveLength(expectedBannerLines);
        }

        // In warning states (except the "check details not selected" and closed), disclaimer usually appears in messageTexts.
        // Check only when messageTexts exist.
        if (res!.messageTexts.length > 0) {
          expect(res!.messageTexts.join(' ')).toMatch(
            /may not get your money back/i
          );
        }
      }
    );
  });

  describe('DANGER (red) statuses', () => {
    const cases: Array<{ status: CoPStatusCode; expectedBannerLines: number }> =
      [
        { status: 'V0C7', expectedBannerLines: 2 },
        { status: 'V1C7', expectedBannerLines: 2 },
        { status: 'V2C7', expectedBannerLines: 2 },
        { status: 'VAC7', expectedBannerLines: 2 },
        { status: 'VTC7', expectedBannerLines: 2 },
        { status: 'VEC7', expectedBannerLines: 2 },
        { status: 'USER_DID_NOT_SELECT_CHECK_DETAILS', expectedBannerLines: 1 },
      ];

    test.each(cases)(
      '$status maps to DANGER',
      ({ status, expectedBannerLines }) => {
        const res = mapCoPStatusToMessageProps(status, ACCOUNT_NAME);
        expect(res).not.toBeNull();
        expect(res!.look).toBe(COP_STATUS_LOOK.DANGER);
        expect(res!.bannerTexts).toHaveLength(expectedBannerLines);
      }
    );

    it('closed/does not exist statuses should have empty messageTexts', () => {
      const closedStatuses: CoPStatusCode[] = [
        'V0C7',
        'V1C7',
        'V2C7',
        'VAC7',
        'VTC7',
        'VEC7',
      ];
      closedStatuses.forEach(status => {
        const res = mapCoPStatusToMessageProps(status, ACCOUNT_NAME);
        expect(res).not.toBeNull();
        expect(res!.messageTexts).toEqual([]);
      });
    });
  });

  describe('Banner copy expectations (representative checks)', () => {
    it('V0C1 banner includes "This account is in the name of" and accountName', () => {
      const res = mapCoPStatusToMessageProps('V0C1', ACCOUNT_NAME)!;
      renderBanners(res.bannerTexts);
      expect(
        screen.getByText(/This account is in the name of/i)
      ).toBeInTheDocument();
      expect(screen.getByText(ACCOUNT_NAME)).toBeInTheDocument();
    });

    it('V0C4 banner includes "The account is in the name of" and mismatch line', () => {
      const res = mapCoPStatusToMessageProps('V0C4', ACCOUNT_NAME)!;
      renderBanners(res.bannerTexts);
      expect(
        screen.getByText(/The account is in the name of/i)
      ).toBeInTheDocument();
      expect(screen.getByText(ACCOUNT_NAME)).toBeInTheDocument();
      expect(screen.getByText(/doesn't match/i)).toBeInTheDocument();
    });
  });
});
