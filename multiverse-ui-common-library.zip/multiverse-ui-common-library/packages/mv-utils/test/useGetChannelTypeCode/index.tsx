import React from 'react';
import { render, screen } from '@testing-library/react';
import { useGetChannelTypeCode } from '../../src/useGetChannelTypeCode';
import * as urlUtils from '../../src/urlUtils';
import { mockChannelCodeMappings } from './__mocks__/channelCodeMapping';

const mockDeviceFlags = {
  isDesktop: false,
  isTablet: false,
  isMobileOnly: false,
};
// overriding booleans via getters, pointing to mockDeviceFlags
jest.mock('react-device-detect', () => ({
  get isDesktop() {
    return mockDeviceFlags.isDesktop;
  },
  get isTablet() {
    return mockDeviceFlags.isTablet;
  },
  get isMobileOnly() {
    return mockDeviceFlags.isMobileOnly;
  },
}));

jest.mock('../urlUtils', () => ({
  isStaffPortal: jest.fn(),
}));

function TestComponent(openfinHooks: {
  useIsDesktopVersion: () => boolean;
  useIsWebVersion: () => boolean;
  useIsCompositeDesktop: () => boolean;
}) {
  const channelCode = useGetChannelTypeCode(openfinHooks);

  return <div data-testid="channel-code">{channelCode}</div>;
}

describe('useGetChannelTypeCode', () => {
  let mockIsStaffPortal;

  afterEach(() => {
    jest.restoreAllMocks();
  });

  Object.entries(mockChannelCodeMappings).forEach(
    ([channelTypeCode, config]) => {
      it(config.description, () => {
        mockIsStaffPortal = jest.spyOn(urlUtils, 'isStaffPortal');
        mockIsStaffPortal.mockReturnValue(config.isStaffPortal);
        const mockOpenfinHooks = {
          useIsDesktopVersion: () => config.openfinMode.desktop,
          useIsWebVersion: () => config.openfinMode.web,
          useIsCompositeDesktop: () => config.openfinMode.compositeDesktop,
        };
        // Object assign keeps the original reference
        Object.assign(mockDeviceFlags, config.deviceType);

        render(<TestComponent {...mockOpenfinHooks} />);
        expect(screen.getByTestId('channel-code').textContent).toBe(
          channelTypeCode
        );
      });
    }
  );
});
