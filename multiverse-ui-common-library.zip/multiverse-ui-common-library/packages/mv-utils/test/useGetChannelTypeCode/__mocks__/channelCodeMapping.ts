import { ChannelTypeCode } from '../../../src/index.d';
import {
  ChannelTypeCodeCustomer,
  ChannelTypeCodeStaff,
} from '../../../src/constants';

type Mapping = Record<
  ChannelTypeCode,
  {
    description: string;
    openfinMode: {
      desktop: boolean;
      web: boolean;
      compositeDesktop: boolean;
    };
    isStaffPortal: boolean;
    deviceType: {
      isDesktop: boolean;
      isTablet: boolean;
      isMobileOnly: boolean;
    };
  }
>;

/**
 * reference: https://confluence.srv.westpac.com.au/pages/viewpage.action?pageId=1864183677
 */
export const mockChannelCodeMappings: Mapping = {
  [ChannelTypeCodeCustomer.W1C_O_B_D_CP]: {
    description: 'W1C Customer Portal via Openfin on browser via desktop',
    openfinMode: {
      desktop: false,
      web: true,
      compositeDesktop: true,
    },
    isStaffPortal: false,
    deviceType: {
      isDesktop: true,
      isTablet: false,
      isMobileOnly: false,
    },
  },
  [ChannelTypeCodeCustomer.W1C_O_B_T_CP]: {
    description: 'W1C Customer Portal via Openfin on browser via tablet',
    openfinMode: {
      desktop: false,
      web: true,
      compositeDesktop: true,
    },
    isStaffPortal: false,
    deviceType: {
      isDesktop: false,
      isTablet: true,
      isMobileOnly: false,
    },
  },
  [ChannelTypeCodeCustomer.W1C_O_B_M_CP]: {
    description: 'W1C Customer Portal via Openfin on browser via mobile',
    openfinMode: {
      desktop: false,
      web: true,
      compositeDesktop: true,
    },
    isStaffPortal: false,
    deviceType: {
      isDesktop: false,
      isTablet: false,
      isMobileOnly: true,
    },
  },
  [ChannelTypeCodeCustomer.W1C_O_A_D_CP]: {
    description: 'W1C Customer Portal via Openfin application via desktop',
    openfinMode: {
      desktop: true,
      web: false,
      compositeDesktop: true,
    },
    isStaffPortal: false,
    deviceType: {
      isDesktop: true,
      isTablet: false,
      isMobileOnly: false,
    },
  },
  [ChannelTypeCodeCustomer.W1C_U_A_CP]: {
    description: 'W1C Customer Portal  via unknown Openfin mode and any device',
    openfinMode: {
      desktop: false,
      web: false,
      compositeDesktop: false,
    },
    isStaffPortal: false,
    deviceType: {
      isDesktop: false,
      isTablet: false,
      isMobileOnly: false,
    },
  },
  [ChannelTypeCodeStaff.W1C_O_B_D_SP]: {
    description: 'W1C Staff Portal via Openfin on browser via desktop',
    openfinMode: {
      desktop: false,
      web: true,
      compositeDesktop: true,
    },
    isStaffPortal: true,
    deviceType: {
      isDesktop: true,
      isTablet: false,
      isMobileOnly: false,
    },
  },
  [ChannelTypeCodeStaff.W1C_O_A_D_SP]: {
    description: 'W1C Staff Portal via Openfin application via desktop',
    openfinMode: {
      desktop: true,
      web: false,
      compositeDesktop: true,
    },
    isStaffPortal: true,
    deviceType: {
      isDesktop: true,
      isTablet: false,
      isMobileOnly: false,
    },
  },
  [ChannelTypeCodeStaff.W1C_U_A_SP]: {
    description: 'W1C Staff Portal via unknown Openfin mode and any device ',
    openfinMode: {
      desktop: false,
      web: false,
      compositeDesktop: false,
    },
    isStaffPortal: true,
    deviceType: {
      isDesktop: false,
      isTablet: false,
      isMobileOnly: false,
    },
  },
  [ChannelTypeCodeCustomer.W1C_O_U_CP]: {
    description: '',
    openfinMode: {
      desktop: true,
      web: false,
      compositeDesktop: true,
    },
    isStaffPortal: false,
    deviceType: {
      isDesktop: false,
      isTablet: false,
      isMobileOnly: false,
    },
  },
};
