/* eslint-disable  @typescript-eslint/no-explicit-any */

import { getAppUrlWithParams } from '../src';
import { checkEntitlementError } from '../src/checkEntitlementError';

describe('checkEntitlementError', () => {
  beforeEach(() => {
    delete window.location;
    window.location = { href: 'https://localhost:3000/account' } as any;
  });

  it('should redirect to /error when error status is 403 and error code is 8210', () => {
    const action = {
      type: 'galaxyAccount/getArrangements/ERROR',
      payload: {
        error: {
          status: 403,
          data: {
            errors: [{ code: 8210 }],
          },
        },
      },
    };

    checkEntitlementError(action);

    expect(window.location.href).toBe(getAppUrlWithParams('/error'));
  });

  it('should not redirect when error status is 403 and error code is not 8210', () => {
    const action = {
      type: 'galaxyAccount/getArrangements/ERROR',
      payload: {
        error: {
          status: 403,
          data: {
            errors: [{ code: 9999 }],
          },
        },
      },
    };

    checkEntitlementError(action);

    expect(window.location.href).toBe(getAppUrlWithParams('/account'));
  });

  it('should not redirect when the status is not 403', () => {
    const action = {
      type: 'galaxyAccount/getArrangements/ERROR',
      payload: {
        error: {
          status: 500,
        },
      },
    };

    checkEntitlementError(action);

    expect(window.location.href).toBe(getAppUrlWithParams('account'));
  });

  it('should not redirect when the payments action type is in the excludeActions array', () => {
    window.location = {
      href: 'https://localhost:3000/payment/make-payment',
    } as any;
    const action = {
      type: 'api/expGalaxyPaymentV2/payments/post/ERROR',
      payload: {
        error: {
          status: 403,
          data: {
            errors: [{ code: 8210 }],
          },
        },
      },
    };

    const excludeActions = ['api/expGalaxyPaymentV2/payments/post/ERROR'];
    checkEntitlementError(action, excludeActions);

    expect(window.location.href).toBe(
      getAppUrlWithParams('/payment/make-payment')
    );
  });

  it('should redirect when excludeActions is an empty array', () => {
    const action = {
      type: 'galaxyAccount/getArrangements/ERROR',
      payload: {
        error: {
          status: 403,
          data: {
            errors: [{ code: 8210 }],
          },
        },
      },
    };

    const excludeActions: string[] = [];
    checkEntitlementError(action, excludeActions);

    expect(window.location.href).toBe(getAppUrlWithParams('/error'));
  });

  it('should redirect when there are multiple errors', () => {
    const action = {
      type: 'galaxyAccount/getArrangements/ERROR',
      payload: {
        error: {
          status: 403,
          data: {
            errors: [{ code: 8200 }, { code: 8210 }],
          },
        },
      },
    };

    checkEntitlementError(action);

    expect(window.location.href).toBe(getAppUrlWithParams('/error'));
  });
});
