/* eslint-disable @typescript-eslint/no-explicit-any */
import { renderHook, waitFor } from '@testing-library/react';
import { useHandleRaiseIntent } from '../src/intents';

const mockRaiseIntent = jest.fn();
const mockGetURLParams = jest.fn(() => '?q=1');
const mockIsStaffPortal = jest.fn();

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useRaiseIntent: () => mockRaiseIntent,
}));

jest.mock('../src/urlUtils', () => ({
  getURLParams: () => mockGetURLParams(),
  isStaffPortal: () => mockIsStaffPortal(),
}));

describe('useHandleRaiseIntent', () => {
  const navigateMock = jest.fn();
  const dispatchMock = jest.fn();
  const useNavigateMock = () => navigateMock;
  const useGlobalDispatchMock = () => dispatchMock;

  beforeEach(() => {
    jest.clearAllMocks();
    mockIsStaffPortal.mockReturnValue(false); // Default to non-staff portal
  });

  describe('windowTabKey handling', () => {
    it('includes windowTabKey when in staff portal and windowTabKey is provided', async () => {
      mockIsStaffPortal.mockReturnValue(true);

      const { result } = renderHook(() =>
        useHandleRaiseIntent(useGlobalDispatchMock, useNavigateMock)
      );

      const viewOptions = {
        windowTabKey: '02734520055',
        containerTabTitle: 'Accounts list',
      };

      await result.current({
        intentName: 'mv-show-entity',
        intentContextName: 'mv-entity-view',
        data: { entityId: '123' },
        contextKey: 'ctx-1',
        viewOptions,
      });

      expect(mockRaiseIntent).toHaveBeenCalledWith('mv-show-entity', {
        type: 'mv-entity-view',
        id: { contextKey: 'ctx-1' },
        data: { entityId: '123' },
        viewOptions: {
          isOrgScoped: true,
          windowTabKey: '02734520055',
          containerTabTitle: 'Accounts list',
        },
      });
    });

    it('excludes windowTabKey when NOT in staff portal even if provided', async () => {
      mockIsStaffPortal.mockReturnValue(false);

      const { result } = renderHook(() =>
        useHandleRaiseIntent(useGlobalDispatchMock, useNavigateMock)
      );

      const viewOptions = {
        windowTabKey: '02734520055',
        containerTabTitle: 'Accounts list',
      };

      await result.current({
        intentName: 'mv-show-entity',
        intentContextName: 'mv-entity-view',
        data: { entityId: '123' },
        contextKey: 'ctx-1',
        viewOptions,
      });

      expect(mockRaiseIntent).toHaveBeenCalledWith('mv-show-entity', {
        type: 'mv-entity-view',
        id: { contextKey: 'ctx-1' },
        data: { entityId: '123' },
        viewOptions: {
          isOrgScoped: true,
          containerTabTitle: 'Accounts list',
          // windowTabKey should NOT be included
        },
      });
    });

    it('excludes windowTabKey when in staff portal but windowTabKey is not provided', async () => {
      mockIsStaffPortal.mockReturnValue(true);

      const { result } = renderHook(() =>
        useHandleRaiseIntent(useGlobalDispatchMock, useNavigateMock)
      );

      const viewOptions = {
        containerTabTitle: 'Accounts list',
      };

      await result.current({
        intentName: 'mv-show-entity',
        intentContextName: 'mv-entity-view',
        data: { entityId: '123' },
        contextKey: 'ctx-1',
        viewOptions,
      });

      expect(mockRaiseIntent).toHaveBeenCalledWith('mv-show-entity', {
        type: 'mv-entity-view',
        id: { contextKey: 'ctx-1' },
        data: { entityId: '123' },
        viewOptions: {
          isOrgScoped: true,
          containerTabTitle: 'Accounts list',
          // windowTabKey should NOT be included
        },
      });
    });

    it('excludes windowTabKey when in staff portal but windowTabKey is falsy', async () => {
      mockIsStaffPortal.mockReturnValue(true);

      const { result } = renderHook(() =>
        useHandleRaiseIntent(useGlobalDispatchMock, useNavigateMock)
      );

      const testCases = [
        { windowTabKey: null },
        { windowTabKey: undefined },
        { windowTabKey: '' },
        { windowTabKey: 0 },
        { windowTabKey: false },
      ];

      for (const viewOptions of testCases) {
        jest.clearAllMocks();

        await result.current({
          intentName: 'mv-show-entity',
          intentContextName: 'mv-entity-view',
          data: { entityId: '123' },
          viewOptions,
        });

        expect(mockRaiseIntent).toHaveBeenCalledWith('mv-show-entity', {
          type: 'mv-entity-view',
          data: { entityId: '123' },
          viewOptions: {
            isOrgScoped: true,
            // windowTabKey should NOT be included for falsy values
          },
        });
      }
    });

    it('preserves other viewOptions when windowTabKey is excluded', async () => {
      mockIsStaffPortal.mockReturnValue(false);

      const { result } = renderHook(() =>
        useHandleRaiseIntent(useGlobalDispatchMock, useNavigateMock)
      );

      const viewOptions = {
        windowTabKey: '02734520055',
        containerTabTitle: 'Accounts list',
        windowTabTitle: 'MURPHY#',
        isOrgScoped: false,
        customOption: 'custom-value',
      };

      await result.current({
        intentName: 'mv-show-entity',
        intentContextName: 'mv-entity-view',
        viewOptions,
      });

      expect(mockRaiseIntent).toHaveBeenCalledWith('mv-show-entity', {
        type: 'mv-entity-view',
        viewOptions: {
          isOrgScoped: false, // Should be overridden
          containerTabTitle: 'Accounts list',
          windowTabTitle: 'MURPHY#',
          customOption: 'custom-value',
          // windowTabKey should NOT be included
        },
      });
    });
  });

  it('merges defaults and preserves viewOptions overrides', async () => {
    mockIsStaffPortal.mockReturnValue(true);

    const { result } = renderHook(() =>
      useHandleRaiseIntent(useGlobalDispatchMock, useNavigateMock)
    );

    const viewOptions = {
      containerTabTitle: 'Accounts list',
      isOrgScoped: 'false',
      windowTabKey: '02734520055',
      windowTabTitle: 'MURPHY#',
    } as Record<string, any>;

    await result.current({
      intentName: 'mv-show-entity',
      intentContextName: 'mv-entity-view',
      data: { entityId: '123' },
      contextKey: 'ctx-1',
      intentId: { foo: 'bar' },
      viewOptions,
    });

    expect(mockRaiseIntent).toHaveBeenCalledWith('mv-show-entity', {
      type: 'mv-entity-view',
      id: { contextKey: 'ctx-1', foo: 'bar' },
      data: { entityId: '123' },
      viewOptions: {
        isOrgScoped: 'false',
        windowTabKey: '02734520055',
        containerTabTitle: 'Accounts list',
        windowTabTitle: 'MURPHY#',
      },
    });
  });

  it('applies default viewOptions when none provided', async () => {
    const { result } = renderHook(() =>
      useHandleRaiseIntent(useGlobalDispatchMock, useNavigateMock)
    );

    await result.current({
      intentName: 'mv-open',
      intentContextName: 'mv-context',
    });

    expect(mockRaiseIntent).toHaveBeenCalledWith('mv-open', {
      type: 'mv-context',
      viewOptions: { isOrgScoped: true },
    });
  });

  it('navigates and dispatches when raiseIntent rejects', async () => {
    mockRaiseIntent.mockRejectedValueOnce(new Error('boom'));
    const { result } = renderHook(() =>
      useHandleRaiseIntent(useGlobalDispatchMock, useNavigateMock)
    );

    await result.current({
      intentName: 'mv-open',
      intentContextName: 'mv-context',
      targetPath: '/fallback',
      data: { key: 'value' },
    });

    await waitFor(() => {
      expect(navigateMock).toHaveBeenCalledWith('/fallback?q=1');
      expect(dispatchMock).toHaveBeenCalledWith({
        type: 'galaxy/context/update',
        data: { key: 'value', isBrowser: true },
      });
    });
  });

  describe('edge cases', () => {
    it('handles empty viewOptions object', async () => {
      mockIsStaffPortal.mockReturnValue(true);

      const { result } = renderHook(() =>
        useHandleRaiseIntent(useGlobalDispatchMock, useNavigateMock)
      );

      await result.current({
        intentName: 'mv-open',
        intentContextName: 'mv-context',
        viewOptions: {},
      });

      expect(mockRaiseIntent).toHaveBeenCalledWith('mv-open', {
        type: 'mv-context',
        viewOptions: { isOrgScoped: true },
      });
    });

    it('handles null viewOptions', async () => {
      mockIsStaffPortal.mockReturnValue(true);

      const { result } = renderHook(() =>
        useHandleRaiseIntent(useGlobalDispatchMock, useNavigateMock)
      );

      await result.current({
        intentName: 'mv-open',
        intentContextName: 'mv-context',
        viewOptions: null,
      });

      expect(mockRaiseIntent).toHaveBeenCalledWith('mv-open', {
        type: 'mv-context',
        viewOptions: { isOrgScoped: true },
      });
    });

    it('handles undefined viewOptions', async () => {
      mockIsStaffPortal.mockReturnValue(true);

      const { result } = renderHook(() =>
        useHandleRaiseIntent(useGlobalDispatchMock, useNavigateMock)
      );

      await result.current({
        intentName: 'mv-open',
        intentContextName: 'mv-context',
        viewOptions: undefined,
      });

      expect(mockRaiseIntent).toHaveBeenCalledWith('mv-open', {
        type: 'mv-context',
        viewOptions: { isOrgScoped: true },
      });
    });

    it('handles complex nested viewOptions', async () => {
      mockIsStaffPortal.mockReturnValue(true);

      const { result } = renderHook(() =>
        useHandleRaiseIntent(useGlobalDispatchMock, useNavigateMock)
      );

      const viewOptions = {
        windowTabKey: 'test-key',
        nested: {
          deep: {
            value: 'deep-value',
          },
        },
        array: [1, 2, 3],
      };

      await result.current({
        intentName: 'mv-open',
        intentContextName: 'mv-context',
        viewOptions,
      });

      expect(mockRaiseIntent).toHaveBeenCalledWith('mv-open', {
        type: 'mv-context',
        viewOptions: {
          isOrgScoped: true,
          windowTabKey: 'test-key',
          nested: {
            deep: {
              value: 'deep-value',
            },
          },
          array: [1, 2, 3],
        },
      });
    });

    it('navigates with windowTabKey in fallback when not in staff portal', async () => {
      mockIsStaffPortal.mockReturnValue(false);
      mockRaiseIntent.mockRejectedValueOnce(new Error('Intent failed'));

      const { result } = renderHook(() =>
        useHandleRaiseIntent(useGlobalDispatchMock, useNavigateMock)
      );

      const viewOptions = {
        windowTabKey: '02734520055',
        containerTabTitle: 'Accounts list',
      };

      await result.current({
        intentName: 'mv-show-entity',
        intentContextName: 'mv-entity-view',
        targetPath: '/fallback',
        data: { entityId: '123' },
        viewOptions,
      });

      // Should attempt raiseIntent without windowTabKey first
      expect(mockRaiseIntent).toHaveBeenCalledWith('mv-show-entity', {
        type: 'mv-entity-view',
        data: { entityId: '123' },
        viewOptions: {
          isOrgScoped: true,
          containerTabTitle: 'Accounts list',
          // windowTabKey should NOT be included in intent
        },
      });

      // Then fallback to navigation
      await waitFor(() => {
        expect(navigateMock).toHaveBeenCalledWith('/fallback?q=1');
        expect(dispatchMock).toHaveBeenCalledWith({
          type: 'galaxy/context/update',
          data: { entityId: '123', isBrowser: true },
        });
      });
    });
  });
});
