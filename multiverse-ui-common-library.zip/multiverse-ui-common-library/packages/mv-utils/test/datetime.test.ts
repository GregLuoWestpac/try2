import { Settings } from 'luxon';
import {
  convertSydneyLocalTimeToUtc,
  dateRangeString,
  formatDateRange,
  getCurrentFinancialYear,
  getFormattedDate,
  getFormattedDateTime,
} from '../src/datetime';

describe('Testing date time', () => {
  describe('Testing getFormattedTime', () => {
    beforeEach(() => {
      Settings.resetCaches();
      Settings.now = () => new Date().valueOf();
    });

    it('should show correct formatted date time from other timezone', () => {
      Settings.now = () => new Date('01 October 2023 00:00 UTC').valueOf();

      const result = getFormattedDateTime();
      expect(result).toBe('1 Oct 2023, 11:00am (AEDT)');
    });

    it('should show correct formatted date time with ISO string', () => {
      Settings.defaultZone = 'Asia/Tokyo';
      const result = getFormattedDateTime('2024-02-12T03:24:18.680Z');
      expect(result).toBe('12 Feb 2024, 2:24pm (AEDT)');
    });

    it('should show ADST in daylight saving date time', () => {
      Settings.now = () => new Date('01 December 2023 12:00').valueOf();

      const result = getFormattedDateTime();
      expect(result).toBe('1 Dec 2023, 12:00pm (AEDT)');
    });

    it('should show AEST in standard date time', () => {
      Settings.now = () => new Date('01 July 2023 12:00').valueOf();

      const result = getFormattedDateTime();
      expect(result).toBe('1 Jul 2023, 12:00pm (AEST)');
    });

    it('should show correct formatted date time with custom time format', () => {
      Settings.now = () => new Date('01 July 2023 12:00').valueOf();

      const result = getFormattedDateTime(undefined, 'h:mm:ssa');
      expect(result).toBe('1 Jul 2023, 12:00:00pm (AEST)');
    });
  });

  describe('Testing getFormattedDate', () => {
    it('should show correct formatted time from other timezone', () => {
      Settings.now = () => new Date('01 October 2023 00:00 UTC').valueOf();

      const result = getFormattedDate();
      expect(result).toBe('1 Oct 2023 (AEDT)');
    });

    it('should show correct formatted time with ISO string', () => {
      Settings.defaultZone = 'Asia/Tokyo';
      const result = getFormattedDate('2024-02-12T03:24:18.680Z');
      expect(result).toBe('12 Feb 2024 (AEDT)');
    });

    it('should show correct formatted time with ISO string', () => {
      const result = getFormattedDate('2026-01-02', 'd/LL/yyyy', 'date-time');
      expect(result).toBe('2/01/2026');
    });

    it('should show ADST in daylight saving time', () => {
      Settings.now = () => new Date('01 December 2023 12:00').valueOf();

      const result = getFormattedDate();
      expect(result).toBe('1 Dec 2023 (AEDT)');
    });

    it('should show AEST in standard time', () => {
      Settings.now = () => new Date('01 July 2023 12:00').valueOf();

      const result = getFormattedDate();
      expect(result).toBe('1 Jul 2023 (AEST)');
    });

    it('should not show AEST in standard date time when display style is date-time only', () => {
      Settings.now = () => new Date('01 July 2023 12:00').valueOf();

      const result = getFormattedDate(undefined, undefined, 'date-time');
      expect(result).toBe('1 Jul 2023');
    });

    it('should show correct formatted date with custom date format', () => {
      Settings.now = () => new Date('01 July 2023 12:00').valueOf();

      const result = getFormattedDate(undefined, 'dd LLL yyyy');
      expect(result).toBe('01 Jul 2023 (AEST)');
    });

    it('should return an empty string if isDateRequired is set to true and date is not passed', () => {
      Settings.now = () => new Date('01 July 2023 12:00').valueOf();

      const result = getFormattedDate(
        undefined,
        'dd LLL yyyy',
        'date-time',
        true
      );
      expect(result).toBe('');
    });
  });

  describe('Testing convertSydneyLocalTimeToUtc', () => {
    it('should return correct UTC time in Australian Eastern Daylight Time (AEDT, UTC+11)', () => {
      const date = '2024-11-01 21:56:38';
      const expected = '2024-11-01T10:56:38.000Z';
      const result = convertSydneyLocalTimeToUtc(date);
      expect(result).toBe(expected);
    });

    it('should return correct UTC time in Australian Eastern Standard Time (AEST, UTC+10)', () => {
      const date = '2024-06-01 21:56:38';
      const expected = '2024-06-01T11:56:38.000Z';
      const result = convertSydneyLocalTimeToUtc(date);
      expect(result).toBe(expected);
    });

    it('should return correct UTC time in Australian Eastern Daylight Time (AEDT, UTC+11) for end date', () => {
      const date = '2025-07-11 09:56:38';
      const expected = '2025-07-11T13:59:59.999Z';
      const result = convertSydneyLocalTimeToUtc(date, 'end');
      expect(result).toBe(expected);
    });

    it('should return correct UTC time in Australian Eastern Standard Time (AEST, UTC+10) for end date', () => {
      const date = '2025-11-11 01:56:38';
      const expected = '2025-11-11T12:59:59.999Z';
      const result = convertSydneyLocalTimeToUtc(date, 'end');
      expect(result).toBe(expected);
    });

    it('should return empty string when input date is null', () => {
      const result = convertSydneyLocalTimeToUtc(null);
      expect(result).toBe('');
    });

    it('should return null when input date is invalid date string', () => {
      const date = '2000-66-33 55:99';
      const result = convertSydneyLocalTimeToUtc(date);
      expect(result).toBeNull();
    });
  });

  describe('Testing formatDateRange', () => {
    it('should return correct date range when startDate and endDate are passed', () => {
      const result = formatDateRange('2024-01-01', '2025-01-31');
      expect(result).toBe('btn:2024-01-01,2025-01-31');
    });
  });

  describe('Testing dateRangeString', () => {
    it('should return correct date range when startDate and endDate are passed', () => {
      const result = dateRangeString('2024-07-17', '2025-07-17');
      expect(result).toBe(
        'btn:2024-07-17T00:00:00.000Z,2025-07-17T23:59:59.999Z'
      );
    });
  });

  describe('Testing getCurrentFinancialYear', () => {
    it('should return financial year as 4 digits number', () => {
      const financialYear = getCurrentFinancialYear();
      expect(financialYear.toString()).toMatch(/^\d{4}$/);
    });
  });
});
