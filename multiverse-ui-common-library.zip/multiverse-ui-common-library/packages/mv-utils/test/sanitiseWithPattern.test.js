import { sanitiseWithPattern } from '../src/sanitiseWithPattern';
import {
  ACCOUNT_HOLDER_PATTERN,
  ACCOUNT_NAME_MAX_LENGTH,
} from '../src/constants';

describe('sanitiseWithPattern with ACCOUNT_HOLDER_PATTERN and ACCOUNT_NAME_MAX_LENGTH', () => {
  it('should remove characters not matching the ACCOUNT_HOLDER_PATTERN', () => {
    const input = 'John Doe!@#';
    const pattern = ACCOUNT_HOLDER_PATTERN;
    const output = sanitiseWithPattern(input, pattern);
    expect(output).toBe('John Doe!@');
  });

  it('should limit the output length to ACCOUNT_NAME_MAX_LENGTH', () => {
    const input = 'John Doe!@#'.repeat(10); // Create a long string
    const pattern = ACCOUNT_HOLDER_PATTERN;
    const maxLength = ACCOUNT_NAME_MAX_LENGTH;
    const output = sanitiseWithPattern(input, pattern, maxLength);
    expect(output.length).toBeLessThanOrEqual(maxLength);
  });

  it('should return an empty string if input is empty', () => {
    const input = '';
    const pattern = ACCOUNT_HOLDER_PATTERN;
    const output = sanitiseWithPattern(input, pattern);
    expect(output).toBe('');
  });

  it('should return an empty string if input is null', () => {
    const input = null;
    const pattern = ACCOUNT_HOLDER_PATTERN;
    const output = sanitiseWithPattern(input, pattern);
    expect(output).toBe('');
  });

  it('should return an empty string if input is undefined', () => {
    const input = undefined;
    const pattern = ACCOUNT_HOLDER_PATTERN;
    const output = sanitiseWithPattern(input, pattern);
    expect(output).toBe('');
  });

  it('should return an empty string if pattern is null', () => {
    const input = 'John Doe!@#';
    const pattern = null;
    const output = sanitiseWithPattern(input, pattern);
    // expect(output).toBe('');
    expect(output).toBe(input);
  });

  it('should return an empty string if pattern is undefined', () => {
    const input = 'John Doe!@#';
    const pattern = undefined;
    const output = sanitiseWithPattern(input, pattern);
    // expect(output).toBe('');
    expect(output).toBe(input);
  });

  it('should handle input with mixed characters', () => {
    const input = 'John123 Doe!';
    const pattern = ACCOUNT_HOLDER_PATTERN;
    const output = sanitiseWithPattern(input, pattern);
    expect(output).toBe('John123 Doe!');
  });

  it('should handle special characters correctly', () => {
    const input = 'J@o#h$n% D^o&e!';
    const pattern = ACCOUNT_HOLDER_PATTERN;
    const output = sanitiseWithPattern(input, pattern);
    expect(output).toBe('J@ohn Doe!');
  });

  it('should handle input with only spaces', () => {
    const input = '     ';
    const pattern = ACCOUNT_HOLDER_PATTERN;
    const output = sanitiseWithPattern(input, pattern);
    expect(output).toBe('     ');
  });
});
