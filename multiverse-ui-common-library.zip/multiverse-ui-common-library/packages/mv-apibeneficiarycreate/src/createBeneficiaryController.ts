/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response } from 'express';
import {
  handleApiService,
  normaliseData,
  STATUS_CODES,
  RequestBody,
  accessControlExposeHeaders,
  ControllerParams,
  createControllerWrapper,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { ExpApiResponseData } from './types';
import {
  transformDownstreamResponseToUi,
  detectInjectionVulnerabilityForBeneficiary,
} from './createBeneficiaryController.helper';

/**
 * Core handler function for creating a beneficiary
 */
export const createBeneficiaryHandler = async (
  req: Request,
  res: Response,
  controllerParams: ControllerParams
): Promise<void> => {
  const { normalise, apiClient } = controllerParams;
  const { logger } = res.locals;
  const { createBeneficiaries } = apiClient;
  const protectedOrgCisKeyId = req.get('protected-orgId');
  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);

  // Check for injection vulnerabilities before proceeding
  const vulnerabilities = req.body.beneficiaries
    .map(detectInjectionVulnerabilityForBeneficiary)
    .filter(result => result.vulnerabilityDetected);

  if (vulnerabilities.length > 0) {
    const { message, vulnerableFields } = vulnerabilities[0];
    logger.trace(`${message} Vulnerable fields:`, vulnerableFields);
    res.status(STATUS_CODES.BAD_REQUEST).json(message).end();
    return;
  }

  const requestBodyToDownstream = {
    beneficiaries: req.body.beneficiaries?.map(beneficiary => {
      const rest = Object.fromEntries(
        Object.entries(beneficiary).filter(
          ([key]) => key !== 'currencyAmount' && key !== 'divisionName'
        )
      );
      return {
        ...rest,
        amount: beneficiary.currencyAmount?.amount,
        currency: beneficiary.currencyAmount?.currencyCode,
        org: protectedOrgCisKeyId,
      };
    }),
  };

  const downstreamResponse = await handleApiService({
    req,
    res,
    apiClient: createBeneficiaries,
    requestBody: requestBodyToDownstream as RequestBody,
  });

  const expApiResponseData: ExpApiResponseData =
    transformDownstreamResponseToUi(downstreamResponse.data);

  const normalisedData = normaliseData(
    'beneficiaryCreate',
    expApiResponseData.beneficiaryCreate,
    normalise
  );

  res.status(STATUS_CODES.CREATED).json(normalisedData).end();
};

/**
 * Builds the create beneficiary controller using the generic wrapper
 */
export const buildCreateBeneficiaryController = (
  controllerParams: ControllerParams
) => {
  return createControllerWrapper(createBeneficiaryHandler, controllerParams);
};
