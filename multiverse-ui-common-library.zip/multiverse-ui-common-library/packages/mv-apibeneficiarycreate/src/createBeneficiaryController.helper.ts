import get from 'lodash/get';
import {
  DownstreamServiceResponseData,
  validateWithLibrary,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { PAYID_TYPE } from '@mesh-tenant-multiverse-ui-common/mv-constants';
import {
  CreateBeneficiariesData,
  Beneficiary,
  InjectionVulnerabilityResult,
} from './types';

interface AccountWithPayIDType {
  payIDType: PAYID_TYPE;
}

export type ExpApiResponseData = CreateBeneficiariesData['entities'];

export const transformDownstreamResponseToUi = (
  response: DownstreamServiceResponseData
): ExpApiResponseData => {
  if (!Array.isArray(response.data?.beneficiaries))
    return {
      beneficiaryCreate: response.data?.beneficiaries,
    } as ExpApiResponseData;
  const beneficiaries = response.data?.beneficiaries?.map(beneficiary => {
    const { amount, currency: currencyCode, ...rest } = beneficiary;
    return {
      ...rest,
      currencyAmount: {
        ...(amount && { amount }),
        ...(currencyCode && { currencyCode }),
      },
    };
  });

  return { beneficiaryCreate: beneficiaries } as ExpApiResponseData;
};

export const detectInjectionVulnerabilityForBeneficiary = (
  beneficiary: Beneficiary
): InjectionVulnerabilityResult => {
  const hasPayIDType = (
    account: object | null | undefined
  ): account is AccountWithPayIDType =>
    account !== null && account !== undefined && 'payIDType' in account;

  const propertiesToValidate = {
    accountName: 'account.accountName',
    beneficiaryNickname: 'nickname',
    payIdName: 'account.payIDName',
    reference: 'reference',
    ...(hasPayIDType(beneficiary.account) &&
      beneficiary.account.payIDType === PAYID_TYPE.EMAIL && {
        email: 'account.payIDValue',
      }),
    ...(hasPayIDType(beneficiary.account) &&
      beneficiary.account.payIDType === PAYID_TYPE.ORGANISATION_ID && {
        orgId: 'account.payIDValue',
      }),
  };

  const injectionChecks: { path: string; value: string }[] = [];
  for (const key in propertiesToValidate) {
    const value = get(beneficiary, propertiesToValidate[key]) as string;
    if (value && validateWithLibrary(value)) {
      injectionChecks.push({
        path: propertiesToValidate[key],
        value,
      });
    }
  }

  const supplementaryDataArray =
    beneficiary.entitlementData?.supplementaryData || [];
  const lpsFields = [
    'PAYEENICKNAME',
    'PAYEENICKNAME_OLD',
    'PAYEEPAYIDSHORTNAME',
  ];

  lpsFields.forEach(fieldName => {
    const field = supplementaryDataArray.find(item => item.name === fieldName);
    if (field?.value && validateWithLibrary(field.value)) {
      injectionChecks.push({
        path: `entitlementData.supplementaryData[${fieldName}].value`,
        value: field.value,
      });
    }
  });

  if (injectionChecks.length === 0) {
    return {
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    };
  }

  return {
    vulnerabilityDetected: true,
    message: 'Injection vulnerabilities detected.',
    vulnerableFields: injectionChecks.map(check => check.path),
  };
};
