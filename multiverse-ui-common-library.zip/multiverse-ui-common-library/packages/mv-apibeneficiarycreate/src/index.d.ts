/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response, NextFunction } from 'express';
import { ControllerParams } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

export const buildCreateBeneficiaryController: (
  controllerParams: ControllerParams
) => (req: Request, res: Response, next: NextFunction) => Promise<void>;

export const detectInjectionVulnerabilityForBeneficiary: (
  beneficiary: Beneficiary
) => InjectionVulnerabilityResult;

export type Beneficiary =
  | ({
      type: 'ACCOUNT';
      account: {
        accountName: string;
        bsb: string;
        accountNumber: string;
      };
    } & {
      nickname: string;
    })
  | ({
      type: 'PAYID';
      account: {
        payIDType: string;
        payIDValue: string;
        payIDName?: string;
      };
    } & {
      nickname: string;
    });

export type InjectionVulnerabilityResult = {
  vulnerabilityDetected: boolean;
  message: string;
  vulnerableFields: string[];
};
