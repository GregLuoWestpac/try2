import {
  PAYID_TYPE,
  BENEFICIARY_TYPE,
} from '@mesh-tenant-multiverse-ui-common/mv-constants';

export interface CreateBeneficiariesData {
  entities?: {
    beneficiaryCreate?: ({
      /**
       * Unique id for the beneficiary.
       * @format uuid
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * External id for the beneficiary, used for cross-system references.
       * @format uuid
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      externalId?: string;
      /**
       * Beneficiary Nickname
       * @minLength 1
       * @maxLength 70
       * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
       * @example "John"
       */
      nickname?: string;
      /**
       * Beneficiary account type either Pay id or BSB & Account number
       * @example "BSB_ACCOUNT_NUMBER"
       */
      type?: 'PAYID' | 'BSB_ACCOUNT_NUMBER';
      /**
       * Represents Account detail object
       * @example {"accountId":{"accountNumber":"01235674897","BSB":"035845"},"accountName":"Apple Tree","bankName":"Westpac Banking Corporation"}
       */
      account?:
        | {
            /**
             * Account ID (BSB and Account Number)
             * @example {"BSB":"035845","accountNumber":"10235674897"}
             */
            accountId: {
              /**
               * Bank State Branch Number
               * @pattern ^\d{6}$
               * @example "035845"
               */
              BSB: string;
              /**
               * Account Number
               * @minLength 6
               * @maxLength 28
               * @pattern ^[a-zA-Z\d.]+$
               * @example "01235674897"
               */
              accountNumber: string;
            };
            /**
             * Account Name
             * @minLength 1
             * @maxLength 140
             * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
             * @example "Apple Tree"
             */
            accountName: string;
            /**
             * Name of Bank
             * @minLength 1
             * @maxLength 70
             * @pattern ^[\w ]+$
             * @example "Westpac Banking Corporation"
             */
            bankName: string;
          }
        | (
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Email address.
                 * @example "EMAL"
                 */
                payIDType: 'EMAL';
                /**
                 * PAY ID value representing an Email address
                 * @minLength 5
                 * @maxLength 256
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "john.doe@example.com"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing a Telephone number.
                 * @example "TELI"
                 */
                payIDType: 'TELI';
                /**
                 * PAY ID value representing a Telephone number
                 * @minLength 2
                 * @maxLength 30
                 * @pattern ^\+([1-9]{1}[0-9]{1,2})[-]{0,1}[0-9]+$
                 * @example "+61412345678"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Organisation ID.
                 * @example "ORGN"
                 */
                payIDType: 'ORGN';
                /**
                 * PAY ID value representing an Organisation number
                 * @minLength 2
                 * @maxLength 256
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "ORG-12345"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Australian Business Number (ABN).
                 * @example "AUBN"
                 */
                payIDType: 'AUBN';
                /**
                 * PAY ID value representing an Australian Business Number (ABN)
                 * @minLength 9
                 * @maxLength 11
                 * @pattern ^\d+$
                 * @example "12345678910"
                 */
                payIDValue: string;
              }
          );
      currencyAmount?: {
        /**
         * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
         * @pattern ^\w{3}$
         * @example "AUD"
         */
        currencyCode: string;
        /**
         * A positive number string of up to four decimal places (including zero). Must have at least one digit after the decimal point.
         * @pattern ^\d{1,13}\.\d{1,4}$
         * @example "1000.0000"
         */
        amount?: string;
        /** @example "CR" */
        position?: 'CR' | 'DR';
      };
      /**
       * Unique payment identifier for end-to-end transaction tracking and reconciliation.
       * @maxLength 18
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "INV-123456790"
       */
      reference?: string;
    } & {
      /**
       * CIS Key of the organisation
       * @pattern ^\d{11}$
       * @example "06089457589"
       */
      org?: string;
      /**
       * Beneficiary status; example-> ACTIVE, ARCHIVED, ON_HOLD
       * @example "ACTIVE"
       */
      status?: 'ACTIVE' | 'ARCHIVED' | 'ON_HOLD';
    })[];
  };
  /** @example {"beneficiaryCreate":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    beneficiaryCreate?: string[];
  };
}

export type EntitlementSupplementaryDataItem = {
  name: string;
  value: string;
  datatype: 'STRING' | 'BOOLEAN';
};

export type Entitlement = {
  supplementaryData?: EntitlementSupplementaryDataItem[];
};
export interface BeneficiaryCommon {
  id: string;
  nickname: string;
  currencyAmount: CurrencyAmount;
  reference?: string;
  entitlementData?: Entitlement;
}
export interface CurrencyAmount {
  currencyCode: string;
  amount?: string;
}
export interface BeneficiaryBSB {
  accountId: {
    BSB: string;
    accountNumber: string;
  };
  bankName: string;
  accountName: string;
}

export interface BeneficiaryPayID {
  payIDName: string;
  payIDType: PAYID_TYPE;
  payIDValue: string;
}

export type Beneficiary =
  | ({
      type: BENEFICIARY_TYPE.ACCOUNT;
      account: BeneficiaryBSB;
    } & BeneficiaryCommon)
  | ({
      type: BENEFICIARY_TYPE.PAYID;
      account: BeneficiaryPayID;
    } & BeneficiaryCommon);

export type InjectionVulnerabilityResult = {
  vulnerabilityDetected: boolean;
  message: string;
  vulnerableFields: string[];
};

export type ExpApiResponseData = CreateBeneficiariesData['entities'];
