# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.230.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.230.0...v1.230.1) (2026-02-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apibeneficiarycreate

## [1.224.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.224.5...v1.224.6) (2026-01-30)

### 💥 Bug Fixes

- reverting the currency changes | ART-98062 ([f5d72aa](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f5d72aa81d6f808b1313b665d1d74e07cd158f1a))

## [1.224.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.224.2...v1.224.3) (2026-01-30)

### 💥 Bug Fixes

- fixed the unit test | ART-98062 ([1a973a7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1a973a72675dbce67474d6d60331cad856a58c80))
- updated the default currency from formdata | ART-98062 ([ee2cc8d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ee2cc8db111c4f225a34eeab1c2ecc8740da5163))

## [1.224.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.223.3...v1.224.0) (2026-01-29)

### 💥 Bug Fixes

- excluding divisionName from downstream req body for create bene | ART-98062 ([53350c9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/53350c9033e219391748c235b8214da6162f6386))

## [1.219.9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.8...v1.219.9) (2026-01-14)

### 💥 Bug Fixes

- update test cases according to the payload changes | ART-97745 ([90afbc1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/90afbc1d768107e674fe2ac28d811e5616b5fcc8))

## [1.219.8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.7...v1.219.8) (2026-01-13)

### 💥 Bug Fixes

- remove legalName field from alias lookup response and unit test fix | ART-88711 ([9fb5853](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9fb5853613d7d7c5418350f91cf755ed1b5d9cb7))
- removed a duplicate folder which may created by accident | ART-97745 ([9253f22](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9253f22103b655f32ebaa4d0ad691b35bfbcd1eb))

## [1.219.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.0...v1.219.1) (2025-12-19)

### 💥 Bug Fixes

- add back deleted files | ART-88711 ([9b541f6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9b541f66f1babf412fa5f9f318b3533504b1ee0e))

## [1.218.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.217.1...v1.218.0) (2025-12-18)

### 🚀 Features

- rename currency field to currencyCode JIRA:ART-89540 ([832731a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/832731a1be744f05ad419f2b983d369925b1eab1))

## [1.217.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.216.0...v1.217.0) (2025-12-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apibeneficiarycreate

## [1.215.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.214.0...v1.215.0) (2025-12-09)

### 🚀 Features

- migrate Feb2026 inputs to standard | ART-83263 ([156b6bf](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/156b6bf3fde0a94313420005132ec2463d941902))

## [1.188.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.188.1...v1.188.2) (2025-10-08)

### 💥 Bug Fixes

- remove redefined ControllerParams | ART-74256 ([9220906](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/922090677f6ca01d6e269581e642d28f30ec72b0))

## [1.188.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.188.0...v1.188.1) (2025-10-08)

### 💥 Bug Fixes

- update beneficiarycreate readme and package.json | ART-74256 ([422e433](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/422e433b97f7b287870c5f003aff4c0be8d6543c))
- update beneficiarycreate readme and package.json | ART-74256 ([06aba42](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/06aba42368c4838a55ce63f635abda6a9609d28a))
