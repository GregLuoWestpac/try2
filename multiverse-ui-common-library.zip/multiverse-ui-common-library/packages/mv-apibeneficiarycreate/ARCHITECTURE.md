# Controller Architecture Refactoring

## Overview

The `buildCreateBeneficiaryController` has been refactored to separate concerns and provide a reusable architecture for building Express.js controllers with proper error handling, input validation, and injection detection.

## Architecture Components

### 1. Core Handler Functions

These contain the business logic specific to the beneficiary creation endpoint:

```typescript
export const createBeneficiaryHandler = async (
  req: Request,
  res: Response,
  controllerParams: ControllerParams
): Promise<void> => {
  // Business logic implementation
  // - Extract request parameters and headers
  // - Validate input and detect injection vulnerabilities
  // - Call downstream beneficiary creation APIs
  // - Transform and normalize response data
  // - Send response
};
```

### 2. Generic Controller Wrapper

A reusable wrapper from `mv-apiutils` that handles error catching and Express.js middleware integration:

```typescript
export const createControllerWrapper = (
  handlerFn: ControllerHandler,
  controllerParams: ControllerParams
) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      await handlerFn(req, res, controllerParams);
    } catch (error) {
      const { logger } = res.locals;
      handleControllerError({ error, res, logger });
      next(error);
    }
  };
};
```

### 3. Controller Builder Functions

These combine the handler and wrapper for the beneficiary creation endpoint:

```typescript
export const buildCreateBeneficiaryController = (
  controllerParams: ControllerParams
) => {
  return createControllerWrapper(createBeneficiaryHandler, controllerParams);
};
```

### 4. Helper Functions

Specialized utility functions for data transformation and security:

```typescript
// Response transformation
export const transformDownstreamResponseToUi = (
  response: DownstreamServiceResponseData
): ExpApiResponseData => ({ beneficiaryCreate: response.data.beneficiaries });

// Input validation and injection detection
export const detectInjectionVulnerabilityForBeneficiary = (
  beneficiary: Beneficiary
): InjectionVulnerabilityResult => {
  // Validates beneficiary fields against injection patterns
  // Supports different validation rules for account types and PayID types
};
```

## Security Features

### Injection Detection

The controller implements comprehensive injection detection for beneficiary payloads:

- **Account Name Validation**: Detects malicious patterns in account names
- **Beneficiary Nickname Validation**: Validates nickname fields
- **PayID-specific Validation**: Conditional validation based on PayID type:
  - Email validation when `payIDType` is `EMAIL`
  - Organization ID validation when `payIDType` is `ORGANISATION_ID`
  - PayID Name validation for all PayID types

### Input Validation Flow

```typescript
// Check for injection vulnerabilities before proceeding
const vulnerabilities = req.body.beneficiaries
  .map(detectInjectionVulnerabilityForBeneficiary)
  .filter(result => result.vulnerabilityDetected);

if (vulnerabilities.length > 0) {
  const { message, vulnerableFields } = vulnerabilities[0];
  logger.trace(`${message} Vulnerable fields:`, vulnerableFields);
  res.status(STATUS_CODES.BAD_REQUEST).json(message).end();
  return;
}
```

## Data Flow

1. **Request Handling**: Extract beneficiaries array and entitlements from request body
2. **Security Validation**: Run injection detection on all beneficiary objects
3. **Data Preparation**: Add organization context to beneficiary payloads
4. **Downstream API Call**: Submit beneficiaries to create beneficiaries service
5. **Response Transformation**: Convert downstream response to UI format
6. **Data Normalization**: Apply data normalization for consistent API responses
7. **Response**: Return created beneficiaries with appropriate HTTP status

## Error Handling

The controller provides comprehensive error handling for:

- **Input Validation Errors**: Returns `400 BAD_REQUEST` with specific error messages
- **Injection Detection**: Blocks requests and logs vulnerable fields
- **Downstream API Failures**: Handles and propagates API errors appropriately
- **Data Transformation Errors**: Graceful handling of response processing errors

## Environment Configuration

### Local Development
- Automatic test organization setup when `RUNTIME.isLocal()` returns true
- No mesh secrets required for local development

### Production
- Organization context retrieved from mesh secrets
- Secure handling of sensitive configuration data

## Creating a New Beneficiary Creation Controller

To create a similar controller using this architecture:

### Step 1: Create the Handler Function

```typescript
// src/createNewBeneficiaryHandler.ts
export const createNewBeneficiaryHandler = async (
  req: Request,
  res: Response,
  controllerParams: ControllerParams
): Promise<void> => {
  const { RUNTIME, normalise, apiClient, readMeshSecrets } = controllerParams;
  const { logger } = res.locals;
  
  // Add your specific business logic here
  // Include input validation and security checks
  
  const data = await handleApiService({
    req,
    res,
    apiClient: apiClient.createBeneficiaries,
    requestBody: processedRequestData,
  });
  
  const transformedData = transformDownstreamResponseToUi(data);
  const normalisedData = normaliseData('beneficiaryCreate', transformedData.beneficiaryCreate, normalise);
  
  res.status(STATUS_CODES.CREATED).json(normalisedData).end();
};
```

### Step 2: Create the Controller Builder

```typescript
// src/createNewBeneficiaryController.ts
export const buildNewBeneficiaryController = (controllerParams: ControllerParams) => {
  return createControllerWrapper(createNewBeneficiaryHandler, controllerParams);
};
```

### Step 3: Use in Your Routes

```typescript
// In your Express routes
const controller = buildNewBeneficiaryController(controllerParams);
app.post('/api/beneficiaries', controller);
```

## Benefits

1. **Security First**: Built-in injection detection and input validation
2. **Separation of Concerns**: Business logic separated from middleware and error handling
3. **Reusability**: Generic wrapper can be used for any new API endpoint
4. **Testability**: Handler functions can be tested independently of Express.js middleware
5. **Consistency**: All controllers follow the same error handling and security patterns
6. **Maintainability**: Easy to modify security rules or add features across all controllers
7. **Type Safety**: Comprehensive TypeScript interfaces for all data structures

## Testing

The architecture supports comprehensive testing at multiple levels:

### Unit Tests
- **Handler Tests**: Test core business logic with mocked dependencies
- **Helper Function Tests**: Test transformation and validation functions independently
- **Security Tests**: Verify injection detection works correctly

### Integration Tests
- **End-to-End Flow**: Test complete request/response cycle
- **Error Scenarios**: Verify error handling at all levels
- **Security Integration**: Test injection detection in realistic scenarios

Example test structure:

```typescript
describe('createBeneficiaryHandler', () => {
  it('should successfully create beneficiaries', async () => {
    // Test successful creation flow
  });
  
  it('should reject requests with injection vulnerabilities', async () => {
    // Test security validation
  });
});

describe('detectInjectionVulnerabilityForBeneficiary', () => {
  it('should detect malicious patterns in account names', async () => {
    // Test security helper functions
  });
});

describe('buildCreateBeneficiaryController', () => {
  it('should handle errors correctly through wrapper', async () => {
    // Test error handling integration
  });
});
```

## Dependencies

- `@mesh-tenant-multiverse-ui-common/mv-apiutils`: Core API utilities and wrapper functions
- `@mesh-tenant-multiverse-ui-common/mv-constants`: Shared constants for PayID and beneficiary types
- `lodash`: Utility functions for data manipulation
- `express`: HTTP request/response handling

This architecture provides a robust, secure, and maintainable foundation for beneficiary creation API endpoints with comprehensive error handling and security features.