import {
  PAYID_TYPE,
  BENEFICIARY_TYPE,
} from '@mesh-tenant-multiverse-ui-common/mv-constants';
import {
  DownstreamServiceResponseData,
  validateWithLibrary,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import {
  detectInjectionVulnerabilityForBeneficiary,
  transformDownstreamResponseToUi,
} from '../src/createBeneficiaryController.helper';
import { Beneficiary } from '../src/types';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  validateWithLibrary: jest.fn(),
}));

const mockValidateWithLibrary = validateWithLibrary as jest.MockedFunction<
  typeof validateWithLibrary
>;

describe('createBeneficiariesController.helper', () => {
  describe('transformDownstreamResponseToUi', () => {
    it('should transform downstream response with complete beneficiary data', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          beneficiaries: {
            id: '2ca0fae8-cfd5-428a-818d-dc72806882c4',
            externalId: '3db1fae8-dfd5-528a-918d-ec82906882d5',
            nickname: 'John Doe',
            currency: 'AUD',
            type: 'account',
            account: {
              accountId: {
                BSB: '123456',
                accountNumber: '12345678',
              },
              accountName: 'John Doe Account',
              bankName: 'Test Bank',
            },
            status: 'ACTIVE',
            createdDateTime: '2024-01-01T10:00:00Z',
          },
        },
        status: 200,
        statusText: 'OK',
        headers: {},
        config: {},
      } as DownstreamServiceResponseData;

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result).toEqual({
        beneficiaryCreate: {
          id: '2ca0fae8-cfd5-428a-818d-dc72806882c4',
          externalId: '3db1fae8-dfd5-528a-918d-ec82906882d5',
          nickname: 'John Doe',
          currency: 'AUD',
          type: 'account',
          account: {
            accountId: {
              BSB: '123456',
              accountNumber: '12345678',
            },
            accountName: 'John Doe Account',
            bankName: 'Test Bank',
          },
          status: 'ACTIVE',
          createdDateTime: '2024-01-01T10:00:00Z',
        },
      });
    });

    it('should transform downstream response with PayID beneficiary data', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          beneficiaries: {
            id: '4db2fae8-efd5-628a-a18d-fc92a06882e6',
            nickname: 'Jane Smith',
            currency: 'AUD',
            type: 'payid',
            account: {
              payIDValue: 'jane.smith@example.com',
              payIDType: 'EMAIL',
              payIDName: 'Jane Smith',
            },
            status: 'ACTIVE',
          },
        },
        status: 201,
        statusText: 'Created',
        headers: {},
        config: {},
      } as DownstreamServiceResponseData;

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result).toEqual({
        beneficiaryCreate: {
          id: '4db2fae8-efd5-628a-a18d-fc92a06882e6',
          nickname: 'Jane Smith',
          currency: 'AUD',
          type: 'payid',
          account: {
            payIDValue: 'jane.smith@example.com',
            payIDType: 'EMAIL',
            payIDName: 'Jane Smith',
          },
          status: 'ACTIVE',
        },
      });
    });

    it('should handle minimal beneficiary data', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          beneficiaries: {
            id: '6fd4fae8-gfd5-828a-c38d-hea4c08882g8',
            nickname: 'Minimal Ben',
            currency: 'AUD',
          },
        },
        status: 200,
        statusText: 'OK',
        headers: {},
        config: {},
      } as DownstreamServiceResponseData;

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result).toEqual({
        beneficiaryCreate: {
          id: '6fd4fae8-gfd5-828a-c38d-hea4c08882g8',
          nickname: 'Minimal Ben',
          currency: 'AUD',
        },
      });
    });

    it('should handle null beneficiaries data', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          beneficiaries: null,
        },
        status: 200,
        statusText: 'OK',
        headers: {},
        config: {},
      } as DownstreamServiceResponseData;

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result).toEqual({
        beneficiaryCreate: null,
      });
    });

    it('should handle undefined beneficiaries data', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          beneficiaries: undefined,
        },
        status: 200,
        statusText: 'OK',
        headers: {},
        config: {},
      } as DownstreamServiceResponseData;

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result).toEqual({
        beneficiaryCreate: undefined,
      });
    });
  });

  describe('detectInjectionVulnerabilityForBeneficiary', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('should return no vulnerability for clean beneficiary (account type)', () => {
      mockValidateWithLibrary.mockReturnValue(false);
      const beneficiary: Beneficiary = {
        id: '2ca0fae8-cfd5-428a-818d-dc72806882c4',
        nickname: 'TestNickName',
        currency: 'AUD',
        type: BENEFICIARY_TYPE.ACCOUNT,
        account: {
          accountId: {
            BSB: '232323',
            accountNumber: '2133213123',
          },
          accountName: 'TestAccountName',
          bankName: 'Bank name not available',
        },
      };
      const result = detectInjectionVulnerabilityForBeneficiary(beneficiary);
      expect(result.vulnerabilityDetected).toBe(false);
      expect(result.message).toBe('');
      expect(result.vulnerableFields).toEqual([]);
    });

    it('should detect vulnerability in accountName (account type)', () => {
      mockValidateWithLibrary.mockImplementation(val =>
        (val as string).includes('<script>')
      );
      const beneficiary: Beneficiary = {
        id: '2ca0fae8-cfd5-428a-818d-dc72806882c4',
        nickname: 'TestNickName',
        currency: 'AUD',
        type: BENEFICIARY_TYPE.ACCOUNT,
        account: {
          accountId: {
            BSB: '232323',
            accountNumber: '2133213123',
          },
          accountName: 'bad<script>',
          bankName: 'Bank name not available',
        },
      };
      const result = detectInjectionVulnerabilityForBeneficiary(beneficiary);
      expect(result.vulnerabilityDetected).toBe(true);
      expect(result.message).toBe('Injection vulnerabilities detected.');
      expect(result.vulnerableFields).toContain('account.accountName');
    });

    it('should return no vulnerability for clean beneficiary (payID type)', () => {
      mockValidateWithLibrary.mockReturnValue(false);
      const beneficiary: Beneficiary = {
        id: '2ca0fae8-cfd5-428a-818d-dc72806882c4',
        nickname: 'TestNickName',
        currency: 'AUD',
        type: BENEFICIARY_TYPE.PAYID,
        account: {
          payIDName: 'NormalPayID',
          payIDType: PAYID_TYPE.EMAIL,
          payIDValue: 'normal@email.com',
        },
      };
      const result = detectInjectionVulnerabilityForBeneficiary(beneficiary);
      expect(result.vulnerabilityDetected).toBe(false);
      expect(result.message).toBe('');
      expect(result.vulnerableFields).toEqual([]);
    });

    it('should detect vulnerability in email only when payIDType is EMAIL (payID type)', () => {
      mockValidateWithLibrary.mockImplementation(val =>
        (val as string).includes('<script>')
      );
      const beneficiary: Beneficiary = {
        id: '2ca0fae8-cfd5-428a-818d-dc72806882c4',
        nickname: 'TestNickName',
        currency: 'AUD',
        type: BENEFICIARY_TYPE.PAYID,
        account: {
          payIDName: 'NormalPayID',
          payIDType: PAYID_TYPE.EMAIL,
          payIDValue: 'bad@email.com<script>',
        },
      };
      const result = detectInjectionVulnerabilityForBeneficiary(beneficiary);
      expect(result.vulnerabilityDetected).toBe(true);
      expect(result.vulnerableFields).toContain('account.payIDValue');
    });

    it('should detect vulnerability in orgId only when payIDType is ORGANISATION_ID (payID type)', () => {
      mockValidateWithLibrary.mockImplementation(val =>
        (val as string).includes('<script>')
      );
      const beneficiary: Beneficiary = {
        id: '2ca0fae8-cfd5-428a-818d-dc72806882c4',
        nickname: 'TestNickName',
        currency: 'AUD',
        type: BENEFICIARY_TYPE.PAYID,
        account: {
          payIDName: 'NormalPayID',
          payIDType: PAYID_TYPE.ORGANISATION_ID,
          payIDValue: 'badorg<script>',
        },
      };
      const result = detectInjectionVulnerabilityForBeneficiary(beneficiary);
      expect(result.vulnerabilityDetected).toBe(true);
      expect(result.vulnerableFields).toContain('account.payIDValue');
    });

    it('should detect vulnerability in entitlementData fields', () => {
      mockValidateWithLibrary.mockImplementation(val =>
        (val as string).includes('<script>')
      );
      const beneficiary: Beneficiary = {
        id: '2ca0fae8-cfd5-428a-818d-dc72806882c4',
        nickname: 'TestNickName',
        currencyAmount: { currencyCode: 'AUD', amount: '100.00' },
        type: BENEFICIARY_TYPE.ACCOUNT,
        account: {
          accountId: { BSB: '232323', accountNumber: '2133213123' },
          accountName: 'TestAccountName',
          bankName: 'Bank name',
        },
        entitlementData: {
          supplementaryData: [
            { name: 'PAYEENICKNAME', value: 'Bad<script>', datatype: 'STRING' },
          ],
        },
      };
      const result = detectInjectionVulnerabilityForBeneficiary(beneficiary);
      expect(result.vulnerabilityDetected).toBe(true);
      expect(result.vulnerableFields).toContain(
        'entitlementData.supplementaryData[PAYEENICKNAME].value'
      );
    });

    it('should handle beneficiary without entitlementData', () => {
      mockValidateWithLibrary.mockReturnValue(false);
      const beneficiary: Beneficiary = {
        id: '2ca0fae8-cfd5-428a-818d-dc72806882c4',
        nickname: 'TestNickName',
        currencyAmount: { currencyCode: 'AUD', amount: '100.00' },
        type: BENEFICIARY_TYPE.ACCOUNT,
        account: {
          accountId: { BSB: '232323', accountNumber: '2133213123' },
          accountName: 'TestAccountName',
          bankName: 'Bank name',
        },
      };
      const result = detectInjectionVulnerabilityForBeneficiary(beneficiary);
      expect(result.vulnerabilityDetected).toBe(false);
    });
  });
});
