// Mock external dependencies
jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => {
  const actual = jest.requireActual(
    '@mesh-tenant-multiverse-ui-common/mv-apiutils'
  );
  return {
    ...actual,
    handleApiService: jest.fn(),
    handleControllerError: jest.fn(),
    normaliseData: jest.fn(),
    STATUS_CODES: actual.STATUS_CODES || { CREATED: 201, BAD_REQUEST: 400 },
  };
});
jest.mock('../src/createBeneficiaryController.helper', () => ({
  detectInjectionVulnerabilityForBeneficiary: jest.fn(),
  transformDownstreamResponseToUi: jest.fn(),
}));

import {
  handleApiService,
  normaliseData,
  STATUS_CODES,
  createControllerWrapper,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import {
  detectInjectionVulnerabilityForBeneficiary,
  transformDownstreamResponseToUi,
} from '../src/createBeneficiaryController.helper';

// ================= Shared Mocks & Setup =================
import { NextFunction, Request, Response } from 'express';
import * as createBeneficiaryControllerModule from '../src/createBeneficiaryController';
const { createBeneficiaryHandler, buildCreateBeneficiaryController } =
  createBeneficiaryControllerModule;

let req: Partial<Request>;
let res: Partial<Response>;
let next: NextFunction;
let mockControllerParams: {
  RUNTIME: { isLocal: jest.Mock };
  normalise: jest.Mock;
  apiClient: { createBeneficiaries: jest.Mock };
  readMeshSecrets: jest.Mock;
};
let consoleSpy: jest.SpyInstance;

const mockBenePayload = {
  id: '2ca0fae8-cfd5-428a-818d-dc72806882c4',
  nickname: 'TestNickName',
  type: 'BSB_ACCOUNT_NUMBER',
  account: {
    accountId: {
      BSB: '232323',
      accountNumber: '2133213123',
    },
    accountName: 'TestAccountName',
    bankName: 'Bank name not available',
  },
  currencyAmount: {
    amount: '1000.00',
    currencyCode: 'AUD',
  },
};

const mockEntitlements = {
  authorisation: {
    channelRequestId: '28bfdf82-5566-4d37-9ee7-e9c0a17d4338',
  },
};

const mockBeneResponse = {
  id: '2ca0fae8-cfd5-428a-818d-dc72806882c4',
  nickname: 'TestNickName',
  currency: 'AUD',
  org: '19546900027',
  status: 'ACTIVE',
  type: 'BSB_ACCOUNT_NUMBER',
  account: {
    accountId: {
      accountNumber: '2133213123',
      BSB: '232323',
    },
    accountName: 'TestAccountName',
    bankName: 'Bank name not available',
  },
  amount: '1000.00',
};

beforeEach(() => {
  req = {
    body: {},
    get: ((header: string) => {
      if (header === 'protected-orgId') return '19546900027';
      return undefined;
    }) as Request['get'],
  };

  res = {
    locals: {
      logger: {
        trace: jest.fn(),
        info: jest.fn(),
        error: jest.fn(),
      },
    },
    status: jest.fn().mockReturnThis(),
    json: jest.fn().mockReturnThis(),
    setHeader: jest.fn(),
    end: jest.fn(),
    send: jest.fn().mockReturnThis(),
  };
  next = jest.fn();
  mockControllerParams = {
    RUNTIME: {
      isLocal: jest.fn(() => false),
    },
    normalise: jest.fn(),
    apiClient: {
      createBeneficiaries: jest.fn(),
    },
    readMeshSecrets: jest.fn().mockReturnValue({ org: '19546900027' }),
  };
  jest.clearAllMocks();
  consoleSpy = jest.spyOn(console, 'log').mockImplementation();
});

afterEach(() => {
  consoleSpy.mockRestore();
  jest.clearAllMocks();
});

// ================= Handler Unit Tests =================
describe('createBeneficiaryHandler', () => {
  it('should handle successful response', async () => {
    const downstreamResponse = {
      data: { beneficiaryCreate: [mockBeneResponse] },
    };

    (handleApiService as jest.Mock).mockResolvedValue(downstreamResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      downstreamResponse.data
    );
    (detectInjectionVulnerabilityForBeneficiary as jest.Mock).mockReturnValue({
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    });
    (normaliseData as jest.Mock).mockReturnValue(downstreamResponse.data);

    req.body = {
      beneficiaries: [mockBenePayload],
      entitlements: mockEntitlements,
    };

    await createBeneficiaryHandler(
      req as Request,
      res as Response,
      mockControllerParams
    );

    expect(handleApiService).toHaveBeenCalledWith(
      expect.objectContaining({
        req,
        res,
        apiClient: mockControllerParams.apiClient.createBeneficiaries,
        requestBody: expect.objectContaining({
          beneficiaries: expect.arrayContaining([
            expect.objectContaining({
              id: mockBenePayload.id,
              nickname: mockBenePayload.nickname,
              type: mockBenePayload.type,
              account: mockBenePayload.account,
              amount: '1000.00',
              currency: 'AUD',
              org: '19546900027',
            }),
          ]),
        }),
      })
    );

    expect(normaliseData).toHaveBeenCalledWith(
      'beneficiaryCreate',
      downstreamResponse.data.beneficiaryCreate,
      expect.any(Function)
    );
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.CREATED);
    expect(res.json).toHaveBeenCalledWith(downstreamResponse.data);
    expect(res.end).toHaveBeenCalled();
  });

  it('should pass x-channelRequestId in headers to handleApiService', async () => {
    req = {
      body: { beneficiaries: [{ id: 'some-id' }] },
      headers: { 'x-channelRequestId': 'test-create-id' },
      get: jest.fn((header: string) => {
        if (header === 'protected-orgId') return '19546900027';
        return undefined;
      }),
    } as unknown as Request;
    const mockDownstreamResponse = { data: { beneficiaryCreate: [] } };
    const mockExpApiResponseData = { beneficiaryCreate: [] };
    const mockNormalisedData = {};
    (handleApiService as jest.Mock).mockResolvedValue(mockDownstreamResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      mockExpApiResponseData
    );
    (normaliseData as jest.Mock).mockReturnValue(mockNormalisedData);
    (detectInjectionVulnerabilityForBeneficiary as jest.Mock).mockReturnValue({
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    });
    await createBeneficiaryHandler(
      req as Request,
      res as Response,
      mockControllerParams
    );
    expect(handleApiService).toHaveBeenCalledWith(
      expect.objectContaining({
        req: expect.objectContaining({
          headers: expect.objectContaining({
            'x-channelRequestId': 'test-create-id',
          }),
        }),
        res,
        apiClient: mockControllerParams.apiClient.createBeneficiaries,
        requestBody: expect.objectContaining({
          beneficiaries: expect.arrayContaining([
            expect.objectContaining({
              id: 'some-id',
              org: '19546900027',
            }),
          ]),
        }),
      })
    );
  });

  it('should return BAD_REQUEST if detectInjectionVulnerabilityForBeneficiary detects vulnerability', async () => {
    (detectInjectionVulnerabilityForBeneficiary as jest.Mock).mockReturnValue({
      vulnerabilityDetected: true,
      message: 'Injection detected',
      vulnerableFields: ['accountName'],
    });
    req.body = {
      beneficiaries: [mockBenePayload],
      entitlements: mockEntitlements,
    };
    await createBeneficiaryHandler(
      req as Request,
      res as Response,
      mockControllerParams
    );
    expect(detectInjectionVulnerabilityForBeneficiary).toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith('Injection detected');
    expect(res.end).toHaveBeenCalled();
  });

  it('should handle mixed vulnerabilities where some beneficiaries are safe', async () => {
    (detectInjectionVulnerabilityForBeneficiary as jest.Mock)
      .mockReturnValueOnce({
        vulnerabilityDetected: false,
        message: '',
        vulnerableFields: [],
      })
      .mockReturnValueOnce({
        vulnerabilityDetected: true,
        message: 'SQL injection detected',
        vulnerableFields: ['nickname'],
      });
    req.body = {
      beneficiaries: [
        mockBenePayload,
        { ...mockBenePayload, id: 'another-id' },
      ],
      entitlements: mockEntitlements,
    };
    await createBeneficiaryHandler(
      req as Request,
      res as Response,
      mockControllerParams
    );
    expect(detectInjectionVulnerabilityForBeneficiary).toHaveBeenCalledTimes(2);
    expect(res.locals.logger.trace).toHaveBeenCalledWith(
      'SQL injection detected Vulnerable fields:',
      ['nickname']
    );
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.BAD_REQUEST);
    expect(res.json).toHaveBeenCalledWith('SQL injection detected');
    expect(res.end).toHaveBeenCalled();
  });

  it('should handle when all beneficiaries pass vulnerability checks', async () => {
    (detectInjectionVulnerabilityForBeneficiary as jest.Mock)
      .mockReturnValueOnce({
        vulnerabilityDetected: false,
        message: '',
        vulnerableFields: [],
      })
      .mockReturnValueOnce({
        vulnerabilityDetected: false,
        message: '',
        vulnerableFields: [],
      });
    const mockDownstreamResponse = {
      data: { beneficiaryCreate: [mockBeneResponse] },
    };
    const mockExpApiResponseData = { beneficiaryCreate: [mockBeneResponse] };
    const mockNormalisedData = { beneficiaryCreate: [mockBeneResponse] };
    (handleApiService as jest.Mock).mockResolvedValue(mockDownstreamResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      mockExpApiResponseData
    );
    (normaliseData as jest.Mock).mockReturnValue(mockNormalisedData);
    req.body = {
      beneficiaries: [mockBenePayload, { ...mockBenePayload, id: 'safe-id' }],
      entitlements: mockEntitlements,
    };
    await createBeneficiaryHandler(
      req as Request,
      res as Response,
      mockControllerParams
    );
    expect(detectInjectionVulnerabilityForBeneficiary).toHaveBeenCalledTimes(2);
    expect(handleApiService).toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.CREATED);
    expect(res.json).toHaveBeenCalledWith(mockNormalisedData);
    expect(res.end).toHaveBeenCalled();
  });

  it('should handle empty beneficiaries array', async () => {
    const downstreamResponse = {
      data: { beneficiaryCreate: [] },
    };
    (handleApiService as jest.Mock).mockResolvedValue(downstreamResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      downstreamResponse.data
    );
    (normaliseData as jest.Mock).mockReturnValue(downstreamResponse.data);
    req.body = {
      beneficiaries: [],
      entitlements: mockEntitlements,
    };
    await createBeneficiaryHandler(
      req as Request,
      res as Response,
      mockControllerParams
    );
    expect(detectInjectionVulnerabilityForBeneficiary).toHaveBeenCalledTimes(0);
    expect(handleApiService).toHaveBeenCalledWith({
      req,
      res,
      apiClient: mockControllerParams.apiClient.createBeneficiaries,
      requestBody: {
        beneficiaries: [],
      },
    });
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.CREATED);
    expect(res.json).toHaveBeenCalledWith(downstreamResponse.data);
  });
});

// ================= Builder/Wrapper Tests =================
describe('buildCreateBeneficiaryController', () => {
  it('should return a function with Express signature', () => {
    const controller = buildCreateBeneficiaryController(mockControllerParams);
    expect(typeof controller).toBe('function');
    expect(controller.length).toBe(3); // req, res, next
  });

  it('should call the handler and handle success', async () => {
    res.send = jest.fn().mockReturnThis();
    const mockHandler = jest.fn().mockResolvedValue(undefined);
    // Use the wrapper directly with the mock handler
    const controller = createControllerWrapper(
      mockHandler,
      mockControllerParams
    );
    await controller(req as Request, res as Response, next);
    expect(mockHandler).toHaveBeenCalledWith(req, res, mockControllerParams);
  });
});

// ================= Integration Tests =================
describe('Integration tests for built controller', () => {
  it('should process a successful request end-to-end', async () => {
    res.send = jest.fn().mockReturnThis();
    const downstreamResponse = {
      data: { beneficiaryCreate: [mockBeneResponse] },
    };
    (handleApiService as jest.Mock).mockResolvedValue(downstreamResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      downstreamResponse.data
    );
    (detectInjectionVulnerabilityForBeneficiary as jest.Mock).mockReturnValue({
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    });
    (normaliseData as jest.Mock).mockReturnValue(downstreamResponse.data);

    req.body = {
      beneficiaries: [mockBenePayload],
      entitlements: mockEntitlements,
    };

    const controller = buildCreateBeneficiaryController(mockControllerParams);
    await controller(req as Request, res as Response, next);

    expect(res.status).toHaveBeenCalledWith(201);
    expect(res.json).toHaveBeenCalledWith(downstreamResponse.data);
    expect(res.end).toHaveBeenCalled();
    expect(next).not.toHaveBeenCalledWith(expect.any(Error));
  });

  it('should propagate x-channelRequestId header end-to-end', async () => {
    res.send = jest.fn().mockReturnThis();
    req = {
      body: { beneficiaries: [{ id: 'some-id' }] },
      headers: { 'x-channelRequestId': 'test-create-id' },
      get: jest.fn((header: string) => {
        if (header === 'protected-orgId') return '19546900027';
        return undefined;
      }),
    } as unknown as Request;
    const mockDownstreamResponse = { data: { beneficiaryCreate: [] } };
    const mockExpApiResponseData = { beneficiaryCreate: [] };
    const mockNormalisedData = {};
    (handleApiService as jest.Mock).mockResolvedValue(mockDownstreamResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      mockExpApiResponseData
    );
    (normaliseData as jest.Mock).mockReturnValue(mockNormalisedData);
    (detectInjectionVulnerabilityForBeneficiary as jest.Mock).mockReturnValue({
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    });
    const controller = buildCreateBeneficiaryController(mockControllerParams);
    await controller(req as Request, res as Response, next);
    expect(handleApiService).toHaveBeenCalledWith(
      expect.objectContaining({
        req: expect.objectContaining({
          headers: expect.objectContaining({
            'x-channelRequestId': 'test-create-id',
          }),
        }),
        res,
        apiClient: mockControllerParams.apiClient.createBeneficiaries,
        requestBody: expect.objectContaining({
          beneficiaries: expect.arrayContaining([
            expect.objectContaining({
              id: 'some-id',
              org: '19546900027',
            }),
          ]),
        }),
      })
    );
  });

  it('should handle error response end-to-end', async () => {
    res.send = jest.fn().mockReturnThis();
    const error = new Error('Integration test error');
    (handleApiService as jest.Mock).mockRejectedValue(error);
    (detectInjectionVulnerabilityForBeneficiary as jest.Mock).mockReturnValue({
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    });
    req.body = {
      beneficiaries: [{ ...mockBenePayload, org: '19546900027' }],
    };
    const controller = buildCreateBeneficiaryController(mockControllerParams);

    try {
      await controller(req as Request, res as Response, next);
    } catch (e) {
      // Error should be caught by the wrapper
    }

    // The wrapper should call next with the error
    expect(next).toHaveBeenCalledWith(error);
  });
});
