
# @mesh-tenant-multiverse-ui-common/mv-apibeneficiarycreate

A specialized utility library for Beneficiary Creation API operations, designed for use within the Multiverse UI Common Library ecosystem. This package provides robust beneficiary creation controller logic, transformation, and error handling for Express-based APIs.

## Features

- **Beneficiary Creation Controller**: Ready-to-use Express controller for beneficiary creation endpoints
- **Input Validation & Injection Detection**: Built-in input validation and SQL injection detection for beneficiary payloads
- **Downstream API Integration**: Handles downstream beneficiary creation API calls and response transformation
- **Error Handling**: Comprehensive error handling with logging support
- **Data Normalization**: Structured data normalization for consistent API responses
- **Environment Configuration**: Support for local development and production environments

## Installation

```bash
npm install @mesh-tenant-multiverse-ui-common/mv-apibeneficiarycreate
npm install @mesh-tenant-multiverse-ui-common/mv-apiutils  # Required peer dependency
```

## Usage

### Basic Beneficiary Creation Controller

The package provides a ready-to-use controller for beneficiary creation endpoints:

```typescript
import { buildCreateBeneficiaryController } from '@mesh-tenant-multiverse-ui-common/mv-apibeneficiarycreate';
import { ControllerParams } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

// Define controller parameters
const controllerParams: ControllerParams = {
  RUNTIME: runtimeConfig,
  normalise: normalizeFunction,
  apiClient: {
    createBeneficiaries: downstreamApiClient,
  },
  readMeshSecrets: secretsReader,
};

// Create the beneficiary creation controller
const createBeneficiaryController =
  buildCreateBeneficiaryController(controllerParams);

// Use in Express routes
app.post('/api/beneficiaries', createBeneficiaryController);
```

### Custom Beneficiary Creation Handler

If you need more control, you can use the handler function directly:

```typescript
import { createBeneficiaryHandler } from '@mesh-tenant-multiverse-ui-common/mv-apibeneficiarycreate';
import { createControllerWrapper } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

// Create custom wrapper with additional logic
const customCreateBeneficiaryController = async (req, res, next) => {
  try {
    // Pre-processing logic
    console.log('Processing beneficiary creation request');

    // Use the core handler
    await createBeneficiaryHandler(req, res, controllerParams);

    // Post-processing logic
    console.log('Beneficiary creation completed');
  } catch (error) {
    // Custom error handling
    next(error);
  }
};

app.post('/api/beneficiaries', customCreateBeneficiaryController);
```

### Environment Configuration

The controller automatically handles different environment configurations:

```typescript
// In local development, test org and secrets are automatically set
if (RUNTIME.isLocal()) {
  // Test org is automatically applied for local development
  // No additional configuration needed
}

// In production, org and secrets are read from mesh secrets
const { org } = readMeshSecrets(logger);
```

## API Reference

### Controller Functions

- `buildCreateBeneficiaryController(controllerParams: ControllerParams)`: Creates a complete beneficiary creation controller with error handling
- `createBeneficiaryHandler(req, res, controllerParams)`: Core beneficiary creation handler function

### Types

```typescript
interface ExpApiResponseData {
  id?: string;
  nickname?: string;
  currency?: string;
  org?: string;
  status?: 'ACTIVE' | 'INACTIVE';
  type?: string;
  account?: {
    accountId?: {
      BSB?: string;
      accountNumber?: string;
    };
    accountName?: string;
    bankName?: string;
  };
  // ... other beneficiary properties
}
```

### Request Body

The controller expects the following request body:

```json
{
  "beneficiaries": [
    {
      "nickname": "TestNickName",
      "currency": "AUD",
      "type": "BSB_ACCOUNT_NUMBER",
      "account": {
        "accountId": {
          "BSB": "232323",
          "accountNumber": "2133213123"
        },
        "accountName": "TestAccountName",
        "bankName": "Bank name not available"
      }
    }
  ],
  "entitlements": { ... }
}
```

### Response Format

The controller returns normalized data in the following format:

```json
{
  "beneficiaryCreate": [
    {
      "id": "beneficiary-uuid",
      "nickname": "TestNickName",
      "currency": "AUD",
      "org": "19546900027",
      "status": "ACTIVE",
      "type": "BSB_ACCOUNT_NUMBER",
      "account": {
        "accountId": {
          "BSB": "232323",
          "accountNumber": "2133213123"
        },
        "accountName": "TestAccountName",
        "bankName": "Bank name not available"
      }
    }
  ]
}
```

## Required Headers

The controller expects the following HTTP headers:

- `protected-orgId`: Organization CIS key for authorization

## Error Handling

The controller provides comprehensive error handling for common scenarios:

- **Input Validation Errors**: Returns appropriate error when required fields are missing or invalid
- **Injection Detection**: Detects and blocks SQL injection attempts in beneficiary payloads
- **Downstream API Failures**: Handles and logs downstream API errors
- **Data Transformation Errors**: Gracefully handles data processing errors

## Environment Support

### Local Development

- Automatic test token injection
- Detailed logging for debugging
- Mock data support

### Production

- Secure mesh secrets integration
- Production-grade error handling
- Performance optimizations

## Integration Examples

### With Express.js

```typescript
import express from 'express';
import { buildCreateBeneficiaryController } from '@mesh-tenant-multiverse-ui-common/mv-apibeneficiarycreate';

const app = express();

app.post('/api/beneficiaries', buildCreateBeneficiaryController(controllerParams));
```

### With Next.js API Routes

```typescript
// pages/api/beneficiaries.js
import { createBeneficiaryHandler } from '@mesh-tenant-multiverse-ui-common/mv-apibeneficiarycreate';

export default async function handler(req, res) {
  await createBeneficiaryHandler(req, res, controllerParams);
}
```

### With Custom Middleware

```typescript
import { buildCreateBeneficiaryController } from '@mesh-tenant-multiverse-ui-common/mv-apibeneficiarycreate';

// Add custom middleware
app.use(
  '/api/beneficiaries',
  authenticateUser,
  validateRequest,
  buildCreateBeneficiaryController(controllerParams)
);
```

## Dependencies

This package depends on:

- `@mesh-tenant-multiverse-ui-common/mv-apiutils`: Core API utilities
- `express`: HTTP request/response handling

## To build locally

```bash
nx run @mesh-tenant-multiverse-ui-common/mv-apibeneficiarycreate:build
```

## Testing

```bash
npm test
```

## Contributing

This package is part of the Multiverse UI Common Library. Please follow the established patterns and ensure all changes are properly tested before submitting pull requests.

For questions or support, please refer to the main repository documentation.
