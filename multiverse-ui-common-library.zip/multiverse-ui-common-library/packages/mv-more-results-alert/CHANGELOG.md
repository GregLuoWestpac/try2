# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.178.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.178.3...v1.178.4) (2025-08-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-more-results-alert
