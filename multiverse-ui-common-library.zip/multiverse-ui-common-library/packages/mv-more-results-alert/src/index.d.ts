export const MVMoreResultsAlert: (props: {
  shouldShow: boolean;
  message?: string;
  className?: string;
}) => React.ReactElement;
