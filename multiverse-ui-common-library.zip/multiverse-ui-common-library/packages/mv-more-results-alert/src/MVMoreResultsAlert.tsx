import { MVAlert } from '@mesh-tenant-multiverse-ui-common/mv-alert/src';
import React from 'react';

type Props = {
  shouldShow: boolean;
  message?: string;
  className?: string;
};

const MORE_RESULTS_MESSAGE =
  'There are more results available. You can adjust your search criteria to display different results.';

export function MVMoreResultsAlert({ shouldShow, message, className }: Props) {
  if (!shouldShow) {
    return null;
  }

  return (
    <MVAlert className={className} hasBackground={false}>
      {message || MORE_RESULTS_MESSAGE}
    </MVAlert>
  );
}
