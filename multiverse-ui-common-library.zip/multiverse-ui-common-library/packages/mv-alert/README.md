# MVAlert Component

The `MVAlert` component is a dismissible alert box built with React and styled using Tailwind CSS. It supports multiple alert types (`success`, `danger`, `info`, `warning`) and provides options for icons, links, auto-dismiss timers, and close buttons. It also uses icon components from the `@westpac/ui` library.

## Installation

To install the `MVAlert` component, you can use npm:

```sh
npm install @mesh-tenant-multiverse-ui-common/mv-alert

```

## Usage

To use the `MVAlert` component, follow these steps:

1. Import the component in your file:

```jsx
import MVAlert from '@mesh-tenant-multiverse-ui-common/mv-alert';
```

2. Add the `MVAlert` component to your JSX code:

```jsx
<MVAlert type="success" isDismissible>
  This is a success message!
</MVAlert>
```

## Props

The `MVAlert` component accepts the following props:

- `children` (required): Required content/message of the alert.

- `type` (required): Defines the visual style of the alert. Defaults to `info`.( options : `success | danger | info | warning`)

- `icon` (optional): custom icon. Defaults to a context-based icon if not provided.

- `link` (optional): URL to render as a clickable link next to the message.

- `linkText` (optional): custom text to display for the link. Defaults to the link URL.

- `autoHideDuration` (optional): time (in milliseconds) after which the alert auto-dismisses.

- `isDismissible` (optional): Whether to show a close (X) icon to dismiss the alert.

## Example

Here's an updated example of how to use the `MVAlert` component:

```jsx
import React from 'react';
import MVAlert from '@mesh-tenant-multiverse-ui-common/mv-alert';

const AlertExample = () => {
  return (
    <MVAlert
      type="warning"
      isDismissible
      autoHideDuration={5000}
      link="https://example.com"
      linkText="Learn more"
    >
      Please verify your details before proceeding.
    </MVAlert>
  );
};

export default AlertExample;
```

That's it! You can now use the `MVAlert` component to show alert messages throughout your application in a consistent, accessible, and configurable way.
