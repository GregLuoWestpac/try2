import React from 'react';
import { Meta, StoryObj } from '@storybook/react';
import MVAlert from '../MVAlert';
import { VisibilityOffIcon, InfoIcon } from '@westpac/ui/icon';

const meta: Meta<typeof MVAlert> = {
  title: 'Components/MVAlert',
  component: MVAlert,
  tags: ['autodocs'],
  args: {
    children: 'This is an alert message.',
    type: 'info',
  },
  argTypes: {
    type: {
      control: 'select',
      options: ['success', 'danger', 'info', 'warning', 'system'],
    },
    autoHideDuration: {
      control: 'number',
    },
    isDismissible: {
      control: 'boolean',
    },
    heading: {
      control: 'text',
    },
    link: {
      control: 'text',
    },
    linkText: {
      control: 'text',
    },
  },
};

export default meta;
type Story = StoryObj<typeof MVAlert>;

// Default info alert
export const Info: Story = {
  args: {
    type: 'info',
    children: 'This is an informational alert.',
  },
};

export const InfoAlert: Story = {
  args: {
    heading: 'Info Alert Heading',
    children: 'This is an info alert.',
    type: 'info',
    icon: <InfoIcon size="small" look="outlined" />,
    isDismissible: true,
  },
};

export const SuccessAlert: Story = {
  args: {
    children: 'Operation completed successfully.',
    type: 'success',
    autoHideDuration: 7000,
    isDismissible: true,
  },
};

export const WarningAlert: Story = {
  args: {
    heading: 'Invalid data',
    children: 'Please check your inputs.',
    type: 'warning',
    linkText: 'check this link for valid inputs',
    link: 'https://www.google.com',
    isDismissible: false,
  },
};

export const ErrorAlert: Story = {
  args: {
    children:
      "VPN not connected. To access this app, you'll need to connect to the VPN.",
    type: 'danger',
    icon: <VisibilityOffIcon size="small" look="outlined" />,
    isDismissible: false,
  },
};

export const PersistentAlert: Story = {
  args: {
    children: 'This alert will stay until closed manually.',
    type: 'info',
    icon: <InfoIcon size="small" look="outlined" />,
    isDismissible: true,
  },
};

// Alert with heading
export const WithHeading: Story = {
  args: {
    heading: 'Important Update',
    type: 'warning',
    children: 'This alert contains a heading for emphasis.',
  },
};

// Alert with link
export const WithLink: Story = {
  args: {
    type: 'success',
    children: 'Operation completed. View details',
    link: 'https://example.com',
    linkText: 'here',
  },
};

// Alert with custom icon
export const CustomIcon: Story = {
  args: {
    type: 'danger',
    icon: <InfoIcon size="small" look="outlined" />,
    children: 'This uses a custom Info icon.',
  },
};

// Alert with close button
export const WithCloseButton: Story = {
  args: {
    type: 'system',
    isDismissible: true,
    children: 'This alert can be dismissed.',
  },
};

// Alert with auto hide
export const AutoHide: Story = {
  args: {
    type: 'info',
    autoHideDuration: 3000,
    children: 'This alert will auto-hide after 3 seconds.',
  },
};

// Alert with everything
export const FullFeatured: Story = {
  args: {
    heading: 'System Notice',
    type: 'system',
    icon: <InfoIcon size="small" look="outlined" />,
    link: 'https://example.com',
    linkText: 'Learn more',
    autoHideDuration: 5000,
    isDismissible: true,
    children:
      'This is a full-featured alert with heading, icon, link, and close button.',
  },
};
