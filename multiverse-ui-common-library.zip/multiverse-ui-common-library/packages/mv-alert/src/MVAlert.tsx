import React, { useEffect } from 'react';
import {
  CloseIcon,
  AlertIcon,
  SuccessIcon,
  LimitIcon,
  InfoIcon,
  WarningIcon,
} from '@westpac/ui/icon';

export type MVAlertType = 'success' | 'danger' | 'info' | 'warning' | 'system';

export type MVAlertProps = {
  heading?: string;
  link?: string;
  linkText?: string;
  icon?: React.ReactNode;
  autoHideDuration?: number;
  isDismissible?: boolean;
  closeAlert?: () => void;
  type?: MVAlertType;
  children: React.ReactNode;
  className?: string;
  hasBackground?: boolean;
} & React.HTMLAttributes<HTMLDivElement>;

const typeStyles = {
  success: {
    bg: 'bg-[#F2F9F2]',
    border: 'border-[#80C080]',
    divBg: 'bg-[#008000]',
    text: 'text-success',
    icon: <SuccessIcon size="small" look="outlined" />,
  },
  danger: {
    bg: 'bg-[#FCF2F2]',
    border: 'border-[#E28080]',
    divBg: 'bg-[#C40000]',
    text: 'text-danger',
    icon: <AlertIcon size="small" look="outlined" />,
  },
  warning: {
    bg: 'bg-[#FCF5F2]',
    border: 'border-[#E29D80]',
    divBg: 'bg-[#C53B00]',
    text: 'text-warning',
    icon: <WarningIcon size="small" look="outlined" />,
  },
  info: {
    bg: 'bg-[#F2F8FC]',
    border: 'border-[#80BAE2]',
    divBg: 'bg-[#0074C4]',
    text: 'text-info',
    icon: <InfoIcon size="small" look="outlined" />,
  },
  system: {
    bg: 'bg-[#FFFF00]',
    border: 'border-[#FFFFD4]',
    divBg: 'bg-[#ADAD00]',
    text: 'text-black',
    icon: <LimitIcon size="small" look="outlined" />,
  },
};

export function MVAlert({
  heading,
  children,
  link,
  linkText,
  icon,
  autoHideDuration = 0,
  isDismissible = false,
  closeAlert,
  type = 'info',
  className,
  hasBackground = true,
  ...rest
}: MVAlertProps) {
  useEffect(() => {
    if (autoHideDuration && closeAlert) {
      const timer = setTimeout(closeAlert, autoHideDuration);
      return () => clearTimeout(timer);
    }
  }, [autoHideDuration]);

  const styles = typeStyles[type] || typeStyles.info;
  const finalIcon = icon ?? styles.icon;

  return (
    <>
      <div className={`z-50 flex items-start ${className}`} {...rest}>
        {hasBackground && (
          <div className={`self-stretch w-[6px] ${styles.divBg}`} />
        )}
        <div
          className={`flex items-start gap-1 ${styles.text} h-auto py-[12px] w-full ${hasBackground ? `border border-l-0 border-solid px-[12px] ${styles.border} ${styles.bg}` : 'px-0'}`}
        >
          <div
            className={`flex flex-col justify-center pt-[2px] ${styles.text}`}
          >
            {finalIcon}
          </div>
          <div className="flex flex-col justify-center">
            {heading && (
              <p
                className={`typography-heading-9 text-[16px] m-0 font-bold leading-5 tracking-[-0.07px] ${styles.text}`}
              >
                {heading}
              </p>
            )}
            <p
              className={`typography-body-10 text-[14px] m-0 font-normal text-sm leading-5 tracking-[-0.07px] ${styles.text}`}
            >
              {children}
              {link && (
                <a
                  href={link}
                  className={`ml-1 underline focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-blue-500 ${styles.text}`}
                  tabIndex={0}
                  aria-label={linkText || link}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {linkText || link}
                </a>
              )}
            </p>
          </div>
          {isDismissible && (
            <button
              onClick={closeAlert}
              className={`${styles.text} ml-auto text-[10px] focus:outline-2 focus:outline-offset-2`}
              aria-label="Close alert"
            >
              <CloseIcon size="small" look="outlined" />
            </button>
          )}
        </div>
      </div>
    </>
  );
}
