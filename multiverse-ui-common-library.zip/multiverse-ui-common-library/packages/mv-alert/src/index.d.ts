export type MVAlertType = 'success' | 'danger' | 'info' | 'warning' | 'system';

export type MVAlertProps = {
  /**
   * Optional heading or title text displayed above the main content
   */
  heading?: string;

  /**
   * Optional URL for the link rendered after the children
   */
  link?: string;

  /**
   * Text to display for the clickable link. If not provided, the `link` URL will be shown.
   */
  linkText?: string;

  /**
   * Optional custom icon to display at the start of the alert
   */
  icon?: React.ReactNode;

  /**
   * Duration (in milliseconds) after which the alert hides automatically.
   * If 0 or undefined, the alert stays visible until manually closed.
   */
  autoHideDuration?: number;

  /**
   * Whether or not the alert banner can be dismissed
   */
  isDismissible?: boolean;

  /**
   * Allows for the close function to be determined by the user
   */
  closeAlert?: () => void;

  /**
   * Type of alert to determine color and icon
   */
  type?: MVAlertType;

  /**
   * Alert content (message), supports JSX
   */
  children: React.ReactNode;

  className?: string;

  hasBackground?: boolean;
} & React.HTMLAttributes<HTMLDivElement>;
