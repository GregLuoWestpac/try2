# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.219.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.218.0...v1.219.0) (2025-12-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-alert

## [1.178.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.178.3...v1.178.4) (2025-08-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-alert

## [1.170.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.167.2...v1.170.1) (2025-07-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-alert

## [1.166.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.165.0...v1.166.0) (2025-07-18)

### 🚀 Features

- wibdtw1-1879 changes to props and stories ([61db31d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/61db31d44fd460316ec621361d16540f5a12bc09))

## [1.165.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.164.0...v1.165.0) (2025-07-17)

### 🚀 Features

- wibdtw1-1879 allows more flexibility for the user ([31b04d9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/31b04d98429f612e1f0d4aac4d3e8d5ee6cbbced))

## [1.164.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.163.1...v1.164.0) (2025-07-17)

### 🚀 Features

- wibdtw1-1879 adds toggle open config ([ec072c7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ec072c7fbec03374f7065b9d4c4419c50f8ce148))

## [1.154.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.153.0...v1.154.0) (2025-07-03)

### 🚀 Features

- update text color in MVAlert component for better accessibility ([0b46b1f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/0b46b1f209658bd068619c1578de2dd297a96965))

## [1.153.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.152.0...v1.153.0) (2025-07-03)

### 🚀 Features

- add 'system' type to MVAlertType for enhanced alert categorization ([8e06b93](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8e06b9393bf92380b4fef75451718bda9413d3a5))
- add MVAlert component with customizable properties and update README ([0800937](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/08009375c93c1f9bfb57f42a946ae259cdd9be86))
- build MVAlert component ([58e0dd8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/58e0dd89c5549d934d5da6d068c47e03f69f2715))
- enhance MVAlert component with new 'system' type, improved styles, and additional stories ([10c082c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/10c082cfe34b64c78a91429b3878f4e3d0c46b2b))
- updated heading props in libraries ([af26870](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/af26870f3205ae5509e25d9ef7f7e98b5bc5a0f6))
- WIBDTW1-1494 new widgets for alert ([6d4d573](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/6d4d57338316021f9a559f0d69efdc0880f72712))

## [1.139.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.138.0...v1.139.0) (2025-06-25)

### 🚀 Features

- added new `MVAlert` component with flexible props for icon, message, link, alert type, auto-hide duration, and close functionality ([commit-hash](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commits/your-latest-commit-hash))

---

## [1.138.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.137.3...v1.138.0) (2025-05-30)

### 🚀 Features

- WIBDTW1-1748 update aria label ([924db9d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/924db9d1503c66dc65a29ac6d51e1968b65506dd))
