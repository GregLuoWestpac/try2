/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable react/prop-types */
/* eslint-disable react/display-name */
import React, { useState, forwardRef, useImperativeHandle } from 'react';
import { getFormattedDateTime, debounce } from '../../mv-utils/src';
// @ts-ignore
import { RefreshIcon } from '@westpac/ui/icon';

export type MVRefreshProps = {
  onRefresh: () => void;
  disabled?: boolean;
  lastSuccessfulDateTime?: string;
};

export type MVRefreshHandle = {
  refreshDateTime: () => void;
};

const MVRefresh = forwardRef<MVRefreshHandle, MVRefreshProps>(
  ({ onRefresh, disabled, lastSuccessfulDateTime }, ref) => {
    const [currentTime, setCurrentTime] = useState(getFormattedDateTime);
    const [isButtonDisabled, setIsButtonDisabled] = useState(disabled);

    useImperativeHandle(ref, () => ({
      refreshDateTime: () => {
        setCurrentTime(getFormattedDateTime());
      },
    }));

    // Update displayed time when lastSuccessfulDateTime prop changes
    React.useEffect(() => {
      if (lastSuccessfulDateTime) {
        setCurrentTime(lastSuccessfulDateTime);
      }
    }, [lastSuccessfulDateTime]);

    const handleOnclick = () => {
      if (!isButtonDisabled) {
        setIsButtonDisabled(true);
        // Only update time immediately if lastSuccessfulDateTime prop is not provided
        // When prop is provided, time updates are controlled by parent component
        if (!lastSuccessfulDateTime) {
          setCurrentTime(getFormattedDateTime());
        }
        onRefresh();
      }
    };

    const enableRefreshWidget = () => {
      setIsButtonDisabled(false);
    };

    const debouncedHandleClick = debounce(
      handleOnclick,
      500,
      enableRefreshWidget
    );

    return (
      <button
        className={`flex items-center justify-start border-none bg-transparent cursor-pointer self-start ${disabled ? 'cursor-not-allowed' : ''}`}
        disabled={isButtonDisabled || disabled}
        onClick={debouncedHandleClick}
        type="button"
      >
        <RefreshIcon className="-mb-1 mr-1 mb-0" size="xsmall" />
        <p className="m-0">Last refreshed {currentTime}</p>
      </button>
    );
  }
);

export default MVRefresh;
