# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.211.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.210.3...v1.211.0) (2025-11-25)

### 🚀 Features

- update MVRefresh to handle last successfule date and time display | ART-66871 ([501aa4b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/501aa4becb523e728ef0fd91b0f09cbb3a9ae440))

## [1.170.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.167.2...v1.170.1) (2025-07-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.109.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.108.1...v1.109.0) (2025-04-15)

### 🚀 Features

- update MVRefreshHandle to accept optional parameter | ART-16297 ([cd60572](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/cd6057248e4f2775a37bd8c76cd89e3394327034))

## [1.71.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.71.0...v1.71.1) (2025-03-04)

### 💥 Bug Fixes

- ui/ux fixes | ART-41561 ([89797ce](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/89797ce725aa421bd9bea3e5df54a76d4aec61a4))

## [1.66.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.66.2...v1.66.3) (2025-02-26)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.21.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.21.0...v1.21.1) (2024-11-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.20.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.20.0...v1.20.1) (2024-11-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.17.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.16.0...v1.17.0) (2024-11-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.12.8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.12.7...v1.12.8) (2024-10-31)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.12.7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.12.6...v1.12.7) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.12.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.12.5...v1.12.6) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.12.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.12.1...v1.12.2) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.12.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.12.0...v1.12.1) (2024-10-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.12.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.11.0...v1.12.0) (2024-10-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-refresh

## [1.11.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.10.0...v1.11.0) (2024-10-23)

### 🚀 Features

- add refresh widget and form controller | ART-24650 ([3c642b6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3c642b6738b45ef17cb7b0ced7b641d9d2cfdcd2))
