# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.71.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.71.2...v1.71.3) (2025-03-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-entitlementslib

## [1.56.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.55.5...v1.56.0) (2025-02-05)

### 🚀 Features

- recommit changes using latest version | ART-36119 ([72c1413](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/72c14135fbba3bce83450ab127692490b7e71263))

## [1.49.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.49.2...v1.49.3) (2025-01-23)

### 💥 Bug Fixes

- add export the mv_entitlements lib | ART-37763 ([b11459b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b11459b4e9fe0f206c16a2aecc4d866cbcf2e6f6))
- add-manage-account-name-action-to-library-export | ART-37763 ([6e24f4a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/6e24f4aa0d67ae6165c9aa23fdb7a9fa0a8f30ba))

## [1.46.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.46.1...v1.46.2) (2025-01-16)

### 💥 Bug Fixes

- fix entitlement constant types | ART-36119 ([f556dea](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f556dea8bd9c247bbffcaf60ca0280cb252ad3ff))

## [1.46.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.45.2...v1.46.0) (2025-01-15)

### 🚀 Features

- update entitlements constants | ART-36119 ([63c36a3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/63c36a3bf93586d0a88339de55d7758ca4af789a))

### 💥 Bug Fixes

- fix entitlements constants spelling error | ART-36119 ([96ddf7c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/96ddf7ca7e721a995759463ea44b7c38b6471dc6))

## [1.42.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.41.0...v1.42.0) (2024-12-21)

### 🚀 Features

- support-locally-configured-loggedInUserRole | ART-30220 ([b53c4b3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b53c4b396bb743fcf51c5bbebd318614d4f6e450))

## [1.41.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.40.2...v1.41.0) (2024-12-20)

### 🚀 Features

- return-isUserAuthorised function | ART-30219 ([f0adcd4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f0adcd40597e4bd296fb4dd67f8f5d14c319742a))
- return-isUserAuthorised function | ART-30219 ([5661ed0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5661ed0567d439a7fddba259103c85540d7dee3b))
- return-isUserAuthorised function | ART-30219 ([b88a79e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b88a79ea96cb50406ddbbbf7abc3980ad0cf518e))
- return-isUserAuthorised function | ART-30219 ([4da7da5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4da7da5178fefcc00c43c8002de96f0bc8591710))
- return-isUserAuthorised function | ART-30219 ([5651583](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5651583936956ecf5c148dedecf828dd58c43f46))

## [1.34.9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.8...v1.34.9) (2024-12-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-entitlementslib

## [1.31.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.30.3...v1.31.0) (2024-11-25)

### 🚀 Features

- Updated token with PAC mngmt profile role and added new action to pac mngmt profile role. | ART-30175 ([7fc7acc](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/7fc7acc5f416f57fa5cf830208ffcc013ce52b1a))

## [1.25.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.25.0...v1.25.1) (2024-11-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-entitlementslib

## [1.21.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.21.1...v1.21.2) (2024-11-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-entitlementslib
