import * as React from 'react';

export type GridSpan = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
export type MVDetailSectionProps = {
  heading?: string;
  data: {
    label: string;
    secondaryLabel?: string;
    value: string | JSX.Element | null | undefined;
    itemWithFullWidth?: React.ReactNode;
    style?: string;
    tooltip?: string;
  }[];
  enableDynamicColumnWidth?: boolean;
  withTopBorder?: boolean;
  withBottomBorder?: boolean;
  linkAction?: {
    id?: string;
    name?: string;
    width?: GridSpan;
    text: string;
    action: () => void;
  };
};

export const MVDetailSection: React.FC<MVDetailSectionProps>;
