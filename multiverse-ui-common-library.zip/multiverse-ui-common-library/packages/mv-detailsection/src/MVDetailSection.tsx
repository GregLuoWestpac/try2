import { Button, Grid, GridItem, Heading, Popover } from '@westpac/ui';
import React, { ReactNode } from 'react';
import { HelpIcon } from '@westpac/ui/icon';

export type GridSpan = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
export type MVDetailSectionProps = {
  heading?: string;
  data: {
    label: string;
    secondaryLabel?: string;
    value: string | JSX.Element | null | undefined;
    itemWithFullWidth?: ReactNode;
    style?: string;
    tooltip?: string;
  }[];
  enableDynamicColumnWidth?: boolean;
  withTopBorder?: boolean;
  withBottomBorder?: boolean;
  linkAction?: {
    id?: string;
    name?: string;
    width?: GridSpan;
    text: string;
    action: () => void;
  };
};

function MVDetailSection({
  heading,
  data,
  enableDynamicColumnWidth = false,
  withTopBorder,
  withBottomBorder,
  linkAction,
}: MVDetailSectionProps) {
  const filteredData = data.filter(item => item.value != null);
  if (filteredData.length === 0) return null;

  const renderData = (dynamicWidth: boolean) =>
    filteredData.map(
      ({ label, secondaryLabel, value, itemWithFullWidth, style, tooltip }) => {
        const helpIconId = `${label.replace(/\s+/g, '')}-help-icon-btn`;
        const StyledHelpIcon = () => (
          <HelpIcon
            id={helpIconId}
            size="small"
            color="hero"
            look="outlined"
            aria-label={tooltip}
          />
        );
        return (
          <React.Fragment key={label}>
            <GridItem
              className={`${dynamicWidth ? 'h-fit' : 'pb-2.5'} ${style}`}
              span={dynamicWidth ? undefined : 3}
            >
              <div className="inline-flex items-center">
                <label className="font-semibold text-text !m-0">{label}</label>
                {tooltip && (
                  <Popover
                    soft
                    look="hero"
                    size="small"
                    icon={StyledHelpIcon}
                    content={tooltip}
                  />
                )}
              </div>

              {secondaryLabel && (
                <label className="text-muted font-light !m-0">
                  {secondaryLabel}
                </label>
              )}
            </GridItem>
            <GridItem
              className={`${
                dynamicWidth ? 'h-fit break-words' : 'pb-2.5 break-words'
              } ${tooltip ? 'mt-1' : ''} ${style}`}
              span={dynamicWidth ? undefined : 9}
            >
              <div>{value}</div>
            </GridItem>
            {itemWithFullWidth ? (
              <GridItem span={12}>{itemWithFullWidth}</GridItem>
            ) : null}
          </React.Fragment>
        );
      }
    );

  return (
    <>
      {heading && (
        <GridItem
          className={
            withTopBorder
              ? 'w-full py-2.5 border-t border-border'
              : 'w-full py-2.5'
          }
          span={12}
        >
          <Grid className="auto-rows-min">
            <GridItem
              span={
                (!linkAction ? 12 : 12 - (linkAction?.width ?? 2)) as GridSpan
              }
            >
              <Heading tag="h2" className="text-heading" size={7}>
                {heading}
              </Heading>
            </GridItem>
            {linkAction != null && (
              <GridItem span={linkAction?.width || 2} className="text-right">
                <Button
                  {...(linkAction.id && { id: linkAction.id })}
                  {...(linkAction.name && { name: linkAction.name })}
                  look="link"
                  size="small"
                  onClick={() => linkAction.action()}
                >
                  {linkAction.text}
                </Button>
              </GridItem>
            )}
          </Grid>
        </GridItem>
      )}
      {enableDynamicColumnWidth ? (
        <GridItem span={12}>
          <Grid className="grid grid-cols-[max-content_1fr] auto-rows-[minmax(0,auto)] gap-y-2.5 gap-x-2 pb-2.5 xsl:gap-2.5 sm:gap-2.5">
            {renderData(enableDynamicColumnWidth)}
          </Grid>
        </GridItem>
      ) : (
        renderData(enableDynamicColumnWidth)
      )}

      {withBottomBorder ? (
        <GridItem
          className="p-0 m-0 border-b border-border h-fit"
          span={12}
        ></GridItem>
      ) : (
        ''
      )}
    </>
  );
}
export default MVDetailSection;
