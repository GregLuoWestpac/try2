# MVTable Component

## Installation

```
npm install @mesh-tenant-multiverse-ui-common
```

## Usage

```
import { MVTable } from '@mesh-tenant-multiverse-ui-common/components';

exprot default function MyTable = () => {
  ...
  return (
      <MVTable
        rowData={sortedList}
        defaultColumnDef={defaultColumnDef}
        columnDefs={columnDefs}
        enableCellTextSelection
        onCellClicked={onCellClicked}
        onColumnPinned={onColumnPinned}
        id="payment-list-mvtable"
        noRowMessage={noRowMessage}
      />
    );
}

```

## Dynamic Table Height (Auto-sizing)

MVTable now supports dynamic height calculation that automatically adjusts to fit the viewport while respecting content constraints. This feature prevents unnecessary scrollbars and provides optimal table sizing.

### Basic Implementation

To enable dynamic height in your MFE, follow these steps:

Description at Confluence: https://confluence.srv.westpac.com.au/pages/viewpage.action?pageId=2198747753

#### Step 1: Create a Container Reference

```tsx
import { useRef } from 'react';

export default function YourTableComponent() {
  // Create a ref for the table container
  const tableContainerRef = useRef<HTMLDivElement>(null);

  return (
    <div ref={tableContainerRef}>
      <MVTable
        rowData={yourData}
        columnDefs={yourColumnDefs}
        defaultColumnDef={yourDefaultColumnDef}
        noRowMessage="No data found"
        // Enable dynamic height features
        containerRef={tableContainerRef}
        fallbackHeight={75} // Fallback when dynamic calculation fails (fallbackHeight cannot be larger than minHeight)
        minHeight={75} // Minimum table height (Usually minimum one row is visible)
      />
    </div>
  );
}
```

#### Step 2: Wrap in MVCard (Required)

The dynamic height calculation is designed to work with the MVCard component's padding structure:

```tsx
import { MVCard } from '@mesh-tenant-multiverse-ui-common/components';

export default function YourPageComponent() {
  const tableContainerRef = useRef<HTMLDivElement>(null);

  return (
    <MVCard title="Your Page Title">
      {/* Your other content */}

      <div ref={tableContainerRef}>
        <MVTable
          containerRef={tableContainerRef}
          fallbackHeight={75}
          minHeight={75}
          // ... other props
        />
      </div>
    </MVCard>
  );
}
```

Note: You may already have the MVCard component in a parent layer

### Advanced Configuration

#### Height Props Explained

- **`containerRef`** (RefObject): Reference to the container element for height calculations
- **`fallbackHeight`** (number): Used when viewport space is limited or calculation fails
- **`minHeight`** (number): Absolute minimum height the table can shrink to. 135 for single line header and 153 for double lines header

#### Responsive Behavior

The table will:

- ✅ **Grow** to show all content when viewport has space
- ✅ **Shrink** to fit viewport constraints without causing page scrollbars (unless the minimum height is reached)
- ✅ **Respect minimum height** to maintain usability
- ✅ **Respond immediately** to window resize events
- ✅ **Account for MVCard padding**

### Real-World Example: Galaxy Account MFE

Here's the complete implementation from the Galaxy Account MFE:

```tsx
import { useRef } from 'react';
import { MVTable, MVCard } from '@mesh-tenant-multiverse-ui-common/components';

export default function RenderAccountsListSection({
  allArrangements,
  // ... other props
}) {
  const tableContainerRef = useRef<HTMLDivElement>(null);

  return (
    <MVCard title="Account List">
      {/* Export button and other content */}
      <div>
        <Button onClick={exportCsvHandler}>Export accounts</Button>
      </div>

      {/* Table container with dynamic height */}
      <div ref={tableContainerRef}>
        <MVTable
          rowData={allArrangements}
          defaultColumnDef={defaultColumnDef}
          columnDefs={columnDefs}
          onCellClicked={onCellClicked}
          noRowMessage="There are no accounts found."
          className="mt-2.5"
          // Dynamic height configuration
          containerRef={tableContainerRef}
          fallbackHeight={75}
          minHeight={75}
          // ... other AG Grid props
        />
      </div>
    </MVCard>
  );
}
```

### Testing Dynamic Height

You can add a test banner to verify the dynamic height behavior:

```tsx
const [showTestBanner, setShowTestBanner] = useState(false);

return (
  <MVCard title="Your Table">
    {/* Test banner toggle */}
    <button onClick={() => setShowTestBanner(!showTestBanner)}>
      {showTestBanner ? 'Hide' : 'Show'} Test Banner
    </button>

    {/* Test banner - table should adjust height when this appears/disappears */}
    {showTestBanner && (
      <div style={{ height: '100px', background: 'lightblue' }}>
        Test Banner - Table should resize when this is toggled
      </div>
    )}

    <div ref={tableContainerRef}>
      <MVTable
        containerRef={tableContainerRef}
        // ... other props
      />
    </div>
  </MVCard>
);
```

### Migration from Fixed Height

If you have existing tables with fixed heights, migration is straightforward:

**Before:**

```tsx
<MVTable
  tableHeight={400} // Fixed height
  // ... other props
/>
```

**After:**

```tsx
const tableContainerRef = useRef<HTMLDivElement>(null);

// Wrap in container with ref
<div ref={tableContainerRef}>
  <MVTable
    containerRef={tableContainerRef}
    fallbackHeight={400} // Use previous fixed height as fallback
    minHeight={200} // Set reasonable minimum
    // Remove tableHeight prop
    // ... other props
  />
</div>;
```

### Troubleshooting

**Table not resizing:**

- Ensure `containerRef` are set
- Verify the container is wrapped in an MVCard component
- Check that the ref is attached to a div containing the table

**Scrollbars still appearing:**

- If you have additional content, you may need to adjust `fallbackHeight`

**Table too small:**

- Increase `minHeight` prop to ensure minimum usability
- Check that your `fallbackHeight` is reasonable for your content

## How to set AG Grid license key

### Step1: Generate the crypto key and encrypt your AGGrid License

1. Update licenseGen.js to add your SPA and AGGrid License, eg: secret.spaName & secret.license
2. Copy and Paste the contents of licenseGen.js to Chrome -> DevTools -> Console prompt to run it

Take note of the values of key & lic in console log as you would need to set in your app-config as follows

```
  "mvTable": {
    "key": KEY_VALUE
    "lic": LIC_VALUE
  }
```

### Step2: Add crypto key and encrypted license to the app config

Add the following block to your SPA app-config files. You need to add to all environments:

eg: galaxy-singlepageapplication/env/local/app-config.json

Do the same for all environments - local, dev1, sit1, uat1, svp1 & prod. If staff access is supported do for staff settings too as applicable.

```
"mvTable": {
  "key": "XXXXXXXX",
  "lic": "XXXXXXXX"
}
```

NOTE: lic is an encrypted & stringified JSON object in following format:

```
{
    spaName: 'galaxy', // set this to your SPA componentName
    license: 'agGrid_LICENSE_STRING', // use as-is, don't reformat
}
```

### Step3: Decrypt the license key with crypto key and add it to the AG Grid LicenseManager

Add the following code into your WithMFE HOC for respective MFE to read the license from the Global Store, decrypt it and set in the agGrid License Manager.

```
import { LicenseManager } from 'ag-grid-enterprise';

const mvTableKey = useGlobalSelector(
  (state) => state?.global?.config?.mvTable?.key
);
const mvTableLic = useGlobalSelector(
  (state) => state?.global?.config?.mvTable?.lic
);

useEffect(() => {
  const setLic = async () => {
    const key = await generateKeyFromBase64(
      decodeURIComponent(mvTableKey),
      ['decrypt']
    );
    const lic = await decryptDataChunkFromString(
      decodeURIComponent(mvTableLic),
      key
    );
    LicenseManager.setLicenseKey(lic);
    setIsSetMVTableKey(true);
  };

  if (mvTableKey && mvTableLic) {
    setLic();
  }
}, [mvTableKey, mvTableLic]);
```
