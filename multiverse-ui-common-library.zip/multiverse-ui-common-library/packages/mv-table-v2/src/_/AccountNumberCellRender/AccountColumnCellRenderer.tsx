import React from 'react';
import type { CustomCellRendererProps } from 'ag-grid-react';
import { formatBSBFromAccNo } from '../../../../mv-utils';

const AccountColumnCellRenderer: React.FC<CustomCellRendererProps> = params => {
  const value = formatBSBFromAccNo(params.value);

  const [bsb, accountNumber] = value.split(' ');

  return (
    <div>
      <div>{bsb}</div>
      <div>{accountNumber}</div>
    </div>
  );
};

export default AccountColumnCellRenderer;
