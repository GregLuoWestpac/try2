import React, { SyntheticEvent } from 'react';
import { Button } from '@westpac/ui';
import { MoreHorizIcon } from '@westpac/ui/icon';
import { Column, IContextMenuParams, IRowNode } from 'ag-grid-community';
import { TableData } from '../../MVTable';

type ActionButtonPropsType = {
  api: {
    showContextMenu: (params: IContextMenuParams) => void;
  };
  node: IRowNode<TableData>;
  column: Column<TableData>;
};

const ActionButton = ({ api, node, column }: ActionButtonPropsType) => {
  const { rowIndex } = node;

  const handleEvent = (e: MouseEvent | KeyboardEvent) => {
    e.stopPropagation();
    const event = e as unknown as SyntheticEvent;
    const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
    const x = rect.right - 129;
    const y = rect.bottom;
    api.showContextMenu({
      x,
      y,
      rowNode: node,
      column,
      value: 'showContext',
    });
  };

  const handleRef = (ref: HTMLButtonElement | null) => {
    if (ref) {
      ref.onkeydown = (e: KeyboardEvent) => {
        if (e.key !== 'Enter') return;
        handleEvent(e);
      };

      ref.onclick = (e: MouseEvent) => {
        handleEvent(e);
      };
    }
  };

  return (
    <Button
      ref={handleRef}
      look="faint"
      iconBefore={MoreHorizIcon}
      size="small"
      iconSize="xsmall"
      data-testid={`ActionButton-${rowIndex}`}
    />
  );
};

export default ActionButton;
