import React from 'react';

type Props = {
  footnote: string;
};

export function TableFootnote({ footnote }: Props) {
  return (
    <div className="text-muted text-xs font-extralight mt-2.5">{footnote}</div>
  );
}
