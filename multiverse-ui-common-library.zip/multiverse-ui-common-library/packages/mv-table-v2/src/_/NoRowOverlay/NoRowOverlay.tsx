import { Well } from '@westpac/ui';
import React, { useEffect, useState } from 'react';

const calculateTopOffset = () => {
  const headerHeight = document.querySelector('.ag-header')?.clientHeight || 0;
  return headerHeight + 24;
};

type NoRowOverlayProps = {
  noRowMessage: string;
};

function NoRowOverlay({ noRowMessage }: NoRowOverlayProps) {
  const [topOffset, setTopOffset] = useState(calculateTopOffset());

  useEffect(() => {
    const handleResize = () => {
      setTopOffset(calculateTopOffset());
    };

    const resizeObserver = new ResizeObserver(handleResize);
    const headerElement = document.querySelector('.ag-header');

    if (headerElement) {
      resizeObserver.observe(headerElement);
    }

    return () => resizeObserver.disconnect();
  }, []);

  return (
    <div
      className={`absolute left-0 right-0 w-full text-center flex justify-center`}
      style={{ top: `${topOffset}px` }}
    >
      <Well className="border-none w-[464px] p-3 sm:p-3">{noRowMessage}</Well>
    </div>
  );
}

export default NoRowOverlay;
