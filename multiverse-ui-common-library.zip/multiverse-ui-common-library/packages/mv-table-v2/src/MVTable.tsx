/* eslint-disable @typescript-eslint/no-explicit-any */

import {
  ColDef,
  GetContextMenuItemsParams,
  GridApi,
  GridOptions,
  IsFullWidthRowParams,
  ProcessHeaderForExportParams,
} from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import { AgGridReact, AgGridReactProps } from 'ag-grid-react';
import React, {
  forwardRef,
  RefObject,
  useCallback,
  useImperativeHandle,
  useMemo,
  useRef,
  useState,
} from 'react';
import { NoRowOverlay } from './_/NoRowOverlay';
import { TableFootnote } from './_/TableFootnote';
import { useGridHeight } from './hooks/useGridHeight';
import { onFilterChanged, sanitizeForCSV } from './MVTable.utils';
import MVTableWrapper from './MVTableWrapper';

export type TableData = {
  [key: string]: unknown;
};

export type MVTableExportCSV = {
  exportCsv: (
    fileName: string,
    exportAllColumns: boolean,
    processHeaderCallback?: (params: ProcessHeaderForExportParams) => string
  ) => void;
  api: GridApi<TableData>;
};

export interface CustomColDef extends ColDef {
  excludeFromExport?: boolean;
  columnIndex?: number;
}

export type MVTableV2PropsType = AgGridReactProps & {
  noRowMessage: string;
  rowData: TableData[];
  defaultColumnDef: ColDef;
  footnote?: string;
  ref?: React.RefObject<any>;
  containerRef?: RefObject<HTMLElement>;
  tableHeight?: number;
  minHeight?: number;
};

const MVTable = forwardRef<MVTableExportCSV, MVTableV2PropsType>(
  (
    {
      rowData,
      noRowMessage,
      defaultColumnDef,
      columnDefs,
      footnote,
      containerRef,
      tableHeight = 600,
      minHeight = 135,
      ...agGridProps
    },
    ref?
  ) => {
    const [hasVScroll, setHasVScroll] = useState(false);

    const { gridHeight } = useGridHeight(
      containerRef,
      rowData.length,
      tableHeight,
      minHeight,
      setHasVScroll,
      footnote
    );

    const agGridRef = useRef<AgGridReact>(null);

    const isFullWidthRow = (params: IsFullWidthRowParams): boolean => {
      const { data } = params.rowNode;

      if (!data) return false;
      return !!data?.isLoading;
    };

    const exportCsv = useCallback(
      (
        fileName: string,
        exportAllColumns?: boolean,
        processHeaderCallback?: (params: ProcessHeaderForExportParams) => string
      ) => {
        const allColumns = agGridRef.current?.api?.getColumns();
        if (!allColumns) return;
        const columnsToExport: typeof allColumns = allColumns
          .filter((col: { getColDef: () => ColDef }) => {
            const def: CustomColDef = col.getColDef() as CustomColDef;
            return def?.excludeFromExport !== true;
          })
          .sort((a, b) => {
            const colA = a.getColDef() as CustomColDef;
            const colB = b.getColDef() as CustomColDef;
            return (colA?.columnIndex || 0) - (colB?.columnIndex || 0);
          });
        const columnKeys = columnsToExport.map(
          (col: { getColId: () => string }) => col.getColId()
        );
        agGridRef.current?.api.exportDataAsCsv({
          columnKeys,
          allColumns: !!exportAllColumns,
          fileName,
          processCellCallback: params => {
            const value = params.column.getColDef().valueFormatter
              ? (params.column.getColDef() as any).valueFormatter(params)
              : params.value;
            return typeof value === 'string' ? sanitizeForCSV(value) : value;
          },
          processHeaderCallback,
        });
      },
      []
    );

    if (ref) {
      useImperativeHandle(ref, () => ({
        exportCsv,
        get api() {
          return agGridRef.current?.api as any;
        },
      }));
    }

    const defaultColDef: ColDef = {
      headerClass: 'default-header !text-[0.8125rem]',
      cellClass: 'default-cell !text-[0.8125rem]',
      wrapText: true,
      autoHeight: true,
      autoHeaderHeight: true,
      wrapHeaderText: true,
      suppressHeaderFilterButton: true,
      suppressHeaderContextMenu: true,
      suppressHeaderMenuButton: true,
      ...defaultColumnDef,
    };

    const onBodyScroll = () => {
      if (agGridRef.current) {
        agGridRef.current.api.hidePopupMenu();
      }
    };

    const columnDefsWithHeaderTooltip = columnDefs?.map(
      (col: ColDef<any, any>) => ({
        ...col,
        headerTooltip: col.headerTooltip || col.headerName || col.field,
      })
    );

    const gridOptions: GridOptions = useMemo(
      () => ({
        enableCellTextSelection: true,
        suppressDragLeaveHidesColumns: true,
        domLayout: 'normal',
        rowData,
        columnDefs: columnDefsWithHeaderTooltip,
        tooltipShowMode: 'whenTruncated',
        tooltipShowDelay: 0,
        animateRows: true,
        rowSelection: {
          mode: 'singleRow',
          enableClickSelection: false,
          checkboxes: false,
        },
        isFullWidthRow,
        suppressRowHoverHighlight: true,
        suppressContextMenu: false,
        defaultColDef,
        noRowsOverlayComponent: 'noRowsOverlay',
        onBodyScroll,
        components: {
          noRowsOverlay: () => <NoRowOverlay noRowMessage={noRowMessage} />,
        },
        suppressHorizontalScroll: false,
        onFilterChanged,
        ...agGridProps,

        getContextMenuItems: (params: GetContextMenuItemsParams<TableData>) => {
          if (!agGridProps.getContextMenuItems) return [];
          if (params.value === 'showContext')
            return agGridProps.getContextMenuItems(params);
          return [];
        },
      }),
      [
        rowData,
        columnDefsWithHeaderTooltip,
        defaultColDef,
        noRowMessage,
        onBodyScroll,
        agGridProps,
      ]
    );

    return (
      <MVTableWrapper>
        <div
          className={`ag-theme-alpine ${
            hasVScroll ? 'has-v-scroll' : 'no-v-scroll'
          }`}
          style={{ height: `${gridHeight}px` }}
        >
          <AgGridReact ref={agGridRef} {...gridOptions} />
        </div>

        {footnote && !!rowData?.length && <TableFootnote footnote={footnote} />}
      </MVTableWrapper>
    );
  }
);

MVTable.displayName = 'MVTable';

export default MVTable;
