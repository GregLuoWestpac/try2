import {
  ColDef as ColDefV2,
  ColumnPinnedEvent as ColumnPinnedEventV2,
  Column as ColumnV2,
  FilterChangedEvent,
  GridApi,
  IContextMenuParams,
  IRowNode as IRowNodeV2,
  ProcessHeaderForExportParams,
  SuppressHeaderKeyboardEventParams as SuppressHeaderKeyboardEventParamsV2,
  SuppressKeyboardEventParams as SuppressKeyboardEventParamsV2,
} from 'ag-grid-community';
import { AgGridReactProps as AgGridReactPropsV2 } from 'ag-grid-react';
export {
  CellClickedEvent as CellClickedEventV2,
  CellKeyDownEvent as CellKeyDownEventV2,
  ColDef as ColDefV2,
  Column as ColumnV2,
  GetContextMenuItemsParams as GetContextMenuItemsParamsV2,
  GetMainMenuItemsParams as GetMainMenuItemsParamsV2,
  GridReadyEvent as GridReadyEventV2,
  RowClassParams as RowClassParamsV2,
  RowClassRules as RowClassRulesV2,
  SuppressHeaderKeyboardEventParams as SuppressHeaderKeyboardEventParamsV2,
  SuppressKeyboardEventParams as SuppressKeyboardEventParamsV2,
  ValueFormatterParams as ValueFormatterParamsV2,
  GridApi as GridApiV2,
} from 'ag-grid-community';
export * as AGGridEnterpriseV2 from 'ag-grid-enterprise';
export * as AgGridReactV2 from 'ag-grid-react';
export type { CustomCellRendererProps as CustomCellRendererPropsV2 } from 'ag-grid-react';

export type TableDataV2 = { [key: string]: unknown };

export type ActionButtonV2PropsType = {
  api: {
    showContextMenu: (params: IContextMenuParams) => void;
  };
  node: IRowNodeV2<TableDataV2>;
  column: ColumnV2<TableDataV2>;
};

export const ActionButtonV2: React.FC<ActionButtonV2PropsType>;

export type MVTableExportCSV = {
  exportCsv: (fileName: string, exportAllColumns: boolean) => void;
  api: GridApi<TableDataV2>;
  processHeaderCallback?: (params: ProcessHeaderForExportParams) => string;
};

export type MVTableV2PropsType = AgGridReactPropsV2 & {
  noRowMessage: string;
  rowData: TableDataV2[];
  defaultColumnDef: ColDefV2;
  footnote?: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  ref?: React.RefObject<any>;
  containerRef?: React.RefObject<HTMLElement>;
  tableHeight?: number;
  minHeight?: number;
};

export const MVTableV2: React.FC<MVTableV2PropsType>;

export const useSetAgGridLicV2: () => boolean;

export const getAllFocusableElementsOfV2: (el: HTMLElement) => HTMLElement[];

export const getEventPathV2: (event: KeyboardEvent) => HTMLElement[];

export const onColumnPinnedV2: (event: ColumnPinnedEventV2) => void;

export const suppressKeyboardEventV2: (
  params: SuppressKeyboardEventParamsV2
) => boolean;

export const suppressHeaderKeyboardEventV2: (
  params: SuppressHeaderKeyboardEventParamsV2
) => boolean;

export const onFilterChangedV2: (event: FilterChangedEvent) => void;

type ColumnKeys =
  | 'submittedDate'
  | 'receiptNumber'
  | 'valueDate'
  | 'paymentId'
  | 'fromAccount'
  | 'toAccount'
  | 'amount'
  | 'currency'
  | 'debitDescription'
  | 'paymentMethod'
  | 'status'
  | 'issueDate'
  | 'statementNumber'
  | 'statementId'
  | 'transactionDateTime'
  | 'narrative'
  | 'debitAmount'
  | 'creditAmount'
  | 'balance'
  | 'accountNumber'
  | 'accountName'
  | 'entityName'
  | 'accountType'
  | 'currencyCode'
  | 'availableBalance'
  | 'currentBalance'
  | 'overdraftLimit'
  | 'accListStatus'
  | 'actions'
  | 'beneficiaryNickname'
  | 'accountDetails'
  | 'type'
  | 'interestEarned'
  | 'interestPaid'
  | 'withholdingTax';

declare const COMMON_COLUMN_DEFS: {
  [key in ColumnKeys]: (colDef?: ColDefV2) => ColDefV2;
};

export { COMMON_COLUMN_DEFS };

export interface CustomColDef extends ColDefV2 {
  excludeFromExport?: boolean;
  columnIndex?: number;
}

export const numberComparator: (
  valueA: number | string | null | undefined,
  valueB: number | string | null | undefined
) => number;
