import {
  ColDef,
  Column,
  ColumnGroup,
  ColumnPinnedEvent,
  FilterChangedEvent,
  GridApi,
  LicenseManager,
  SuppressHeaderKeyboardEventParams,
  SuppressKeyboardEventParams,
  ValueFormatterParams,
} from 'ag-grid-enterprise';
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';

import {
  currencyFormatter,
  decryptDataChunkFromString,
  formatBSBFromAccNo,
  generateKeyFromBase64,
  getFormattedDate,
} from '../../mv-utils';
import { ActionButton } from './_/ActionButton';
import { AccountColumnCellRenderer } from './_/AccountNumberCellRender';

type State = {
  global: {
    config: {
      galaxyTable: {
        key: string;
        lic: string;
      };
    };
  };
};

/**
 * Custom hook to set the AG Grid license key.
 *
 * @returns {boolean} - Returns a boolean indicating whether the MVTable key is set.
 */
export const useSetAgGridLic = () => {
  const [isSetMVTableKey, setIsSetMVTableKey] = useState(false);

  const mvTableKey = useSelector(
    (state: State) => state?.global?.config?.galaxyTable?.key
  ) as unknown as string;
  const mvTableLic = useSelector(
    (state: State) => state?.global?.config?.galaxyTable?.lic
  ) as unknown as string;

  useEffect(() => {
    const setLic = async () => {
      const key = await generateKeyFromBase64(decodeURIComponent(mvTableKey), [
        'decrypt',
      ]);
      const lic = await decryptDataChunkFromString(
        decodeURIComponent(mvTableLic),
        key
      );
      LicenseManager.setLicenseKey(lic as string);
      setIsSetMVTableKey(true);
    };

    if (mvTableKey && mvTableLic) {
      setLic();
    }
  }, [mvTableKey, mvTableLic]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (!isSetMVTableKey) {
        console.error("Couldn't initialize MVTable with provided key!!!");
      }
    }, 2000);

    return () => clearTimeout(timer);
  }, [isSetMVTableKey]);

  return isSetMVTableKey;
};

const GRID_CELL_CLASSNAME = 'ag-cell';

/**
 * Gets all focusable elements within a given HTMLElement.
 *
 * @param {HTMLElement} el - The parent element to search within.
 * @returns {HTMLElement[]} - An array of focusable elements.
 */
export const getAllFocusableElementsOf = (el: HTMLElement): HTMLElement[] => {
  const focusableEls = Array.from(
    el.querySelectorAll<HTMLElement>(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    )
  );

  return focusableEls.filter(focusableEl => {
    return focusableEl.tabIndex !== -1;
  });
};

/**
 * Gets the event path for a given KeyboardEvent.
 *
 * @param {KeyboardEvent} event - The keyboard event.
 * @returns {HTMLElement[]} - An array representing the event path.
 */
export const getEventPath = (event: KeyboardEvent): HTMLElement[] => {
  const path: HTMLElement[] = [];
  let currentTarget: HTMLElement | null = event.target as HTMLElement | null;
  while (currentTarget) {
    path.push(currentTarget);
    currentTarget = currentTarget.parentElement;
  }
  return path;
};

/**
 * Handles the column pinned event for AG Grid.
 *
 * @param {ColumnPinnedEvent} event - The column pinned event.
 */
export const onColumnPinned = (event: ColumnPinnedEvent): void => {
  const { api } = event;
  const bodyViewport = document.querySelector('.ag-body-viewport');

  if (bodyViewport) {
    const pinnedColumns = api
      .getAllDisplayedColumns()
      .some((column: Column) => column.getPinned() === 'left');

    if (pinnedColumns) {
      bodyViewport.classList.add('has-pinned-left');
    } else {
      bodyViewport.classList.remove('has-pinned-left');
    }
  }
};

/**
 * Suppress keyboard events within AG Grid cells.
 *
 * @param {SuppressKeyboardEventParams} params - The parameters for suppressing keyboard events.
 * @returns {boolean} - Returns true if the event should be suppressed, false otherwise.
 */
export const suppressKeyboardEvent = ({
  event,
}: SuppressKeyboardEventParams): boolean => {
  const { key, shiftKey } = event;

  const path = getEventPath(event);
  const isTabForward = key === 'Tab' && shiftKey === false;
  const isTabBackward = key === 'Tab' && shiftKey === true;
  let suppressEvent = false;

  // Handle cell children tabbing
  if (isTabForward || isTabBackward) {
    const eGridCell = path.find((el: HTMLElement) => {
      if (el.classList === undefined) return false;
      return el.classList.contains(GRID_CELL_CLASSNAME);
    });
    if (!eGridCell) return suppressEvent;

    const focusableChildrenElements = getAllFocusableElementsOf(eGridCell);
    const lastCellChildEl =
      focusableChildrenElements[focusableChildrenElements.length - 1];
    const firstCellChildEl = focusableChildrenElements[0];
    // Suppress keyboard event if tabbing forward within the cell and the current focused element is not the last child
    if (isTabForward && focusableChildrenElements.length > 0) {
      const isLastChildFocused =
        lastCellChildEl && document.activeElement === lastCellChildEl;
      if (!isLastChildFocused) {
        suppressEvent = true;
      }
    }
    // Suppress keyboard event if tabbing backwards within the cell, and the current focused element is not the first child
    else if (isTabBackward && focusableChildrenElements.length > 0) {
      const cellHasFocusedChildren =
        eGridCell.contains(document.activeElement) &&
        eGridCell !== document.activeElement;
      // Manually set focus to the last child element if cell doesn't have focused children
      if (!cellHasFocusedChildren) {
        lastCellChildEl.focus();
        // Cancel keyboard press, so that it doesn't focus on the last child and then pass through the keyboard press to
        // move to the 2nd last child element
        event.preventDefault();
      }
      const isFirstChildFocused =
        firstCellChildEl && document.activeElement === firstCellChildEl;
      if (!isFirstChildFocused) {
        suppressEvent = true;
      }
    }
  }
  return suppressEvent;
};

/**
 * Moves a column within AG Grid.
 *
 * @param {Column | ColumnGroup} column - The column to move.
 * @param {GridApi} api - The AG Grid API.
 * @param {'left' | 'right'} direction - The direction to move the column.
 */
export const moveColumn = (
  column: Column | ColumnGroup,
  api: GridApi,
  direction: 'left' | 'right'
): void => {
  const allColumns = api.getAllGridColumns();
  const allDisplayColumns = api.getAllDisplayedColumns();

  /* eslint-disable @typescript-eslint/no-explicit-any */
  if (api && allColumns) {
    const index = allDisplayColumns.findIndex(
      (col: Column<any>) => col === column
    );

    if (index !== -1) {
      const newIndex = direction === 'left' ? index - 1 : index + 1;

      const toColumn = allDisplayColumns[newIndex];

      const toIndex = allColumns.findIndex(
        (col: Column<any>) => col === toColumn
      );
      if (toIndex >= 0 && toIndex < allColumns.length) {
        api.moveColumns([column.getUniqueId()], toIndex);
      }
    }
  }
  /* eslint-enable @typescript-eslint/no-explicit-any */
};

/**
 * Suppresses keyboard events within AG Grid headers.
 *
 * @param {SuppressHeaderKeyboardEventParams} params - The parameters for suppressing header keyboard events.
 * @returns {boolean} - Returns true if the event should be suppressed, false otherwise.
 */
export const suppressHeaderKeyboardEvent = ({
  event,
  api,
  column,
}: SuppressHeaderKeyboardEventParams) => {
  let suppressEvent = false;
  const { key, shiftKey } = event;

  if (key === 'ArrowLeft' && shiftKey) {
    moveColumn(column, api, 'left');
    suppressEvent = true;
  }

  if (key === 'ArrowRight' && shiftKey) {
    moveColumn(column, api, 'right');
    suppressEvent = true;
  }

  return suppressEvent;
};

/**
 * Handles the filter changed event for AG Grid.
 *
 * @param {FilterChangedEvent} event - The filter changed event.
 */
export function onFilterChanged(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  event: FilterChangedEvent<any, any>
): void {
  const rows = event.api.getRenderedNodes();
  if (rows.length === 0) return event.api.showNoRowsOverlay();
  event.api.hideOverlay();
}

/**
 * Check if the value starts with * =, +, -, @, tab, or carriage return character,
 * that could be interpreted as a formula in CSV.  If it does, prefix the value
 * with a single quote to prevent it from being interpreted as a formula.
 */
export function sanitizeForCSV(value: string): string {
  if (/^[+-]/.test(value)) return ` ${value}`; // Prefix value with space for negative numbers (-) and phone numbers (+)
  if (/^[=@\x09\x0D]/.test(value)) return `'${value}`; // Prefix value with single quote if it starts with =, @, tab, or carriage return
  return value;
}
/**
 * Type definition for column keys.
 */
type ColumnKeys =
  | 'submittedDate'
  | 'receiptNumber'
  | 'valueDate'
  | 'paymentId'
  | 'fromAccount'
  | 'toAccount'
  | 'amount'
  | 'currency'
  | 'debitDescription'
  | 'paymentMethod'
  | 'status'
  | 'issueDate'
  | 'statementNumber'
  | 'statementId'
  | 'transactionDateTime'
  | 'narrative'
  | 'debitAmount'
  | 'creditAmount'
  | 'balance'
  | 'accountNumber'
  | 'accountName'
  | 'entityName'
  | 'accountType'
  | 'currencyCode'
  | 'availableBalance'
  | 'currentBalance'
  | 'overdraftLimit'
  | 'accListStatus'
  | 'actions'
  | 'beneficiaryNickname'
  | 'accountDetails'
  | 'type'
  | 'interestEarned'
  | 'interestPaid'
  | 'withholdingTax';

const commonDateDef: ColDef = {
  sortable: true,
  resizable: false,
  filter: 'agDateColumnFilter',
  valueGetter: params => {
    if (!params.data || !params.colDef.field) return null;
    const rawValue = params.data[params.colDef.field];

    if (typeof rawValue === 'string') {
      const date = new Date(rawValue);
      return isNaN(date.getTime()) ? null : date;
    }

    return rawValue instanceof Date ? rawValue : null;
  },
  valueFormatter: (params: ValueFormatterParams) => {
    if (!params.value) return '';
    const date =
      params.value instanceof Date ? params.value : new Date(params.value);
    return getFormattedDate(
      date instanceof Date ? date.toISOString() : date,
      'd LLL yyyy',
      'date-time',
      true
    );
  },
  filterParams: {
    filterOptions: ['equals', 'lessThan', 'greaterThan', 'inRange'],
    comparator: (
      filterLocalDateAtMidnight: Date,
      cellValue: Date | string | null | undefined
    ) => {
      if (!cellValue) return 1;

      const cellDate =
        cellValue instanceof Date ? cellValue : new Date(cellValue);
      const cellDateAtMidnight = new Date(
        cellDate.getFullYear(),
        cellDate.getMonth(),
        cellDate.getDate()
      );

      if (cellDateAtMidnight < filterLocalDateAtMidnight) return -1;
      if (cellDateAtMidnight > filterLocalDateAtMidnight) return 1;
      return 0;
    },
  },
};

const commonCurrDef: ColDef = {
  headerClass: 'right-aligned-header default-header !text-[0.8125rem]',
  cellClass: 'right-aligned-amount-cell !text-[0.8125rem]',
  sortable: false,
  valueFormatter: (params: ValueFormatterParams) =>
    params.value ? currencyFormatter(Number(params.value)) : '',
};

/**
 * Compares two values as numbers, handling number, string, null, undefined, empty, and non-numeric strings.
 * Returns:
 *   -1 if valueA < valueB
 *    1 if valueA > valueB
 *    0 if equal or both invalid
 *   Valid numbers are always greater than invalid values.
 */
export function numberComparator(
  valueA: number | string | null | undefined,
  valueB: number | string | null | undefined
): number {
  let numA: number;
  if (typeof valueA === 'number') {
    numA = valueA;
  } else if (valueA !== null && valueA !== undefined && valueA !== '') {
    numA = Number(valueA);
  } else {
    numA = NaN;
  }

  let numB: number;
  if (typeof valueB === 'number') {
    numB = valueB;
  } else if (valueB !== null && valueB !== undefined && valueB !== '') {
    numB = Number(valueB);
  } else {
    numB = NaN;
  }

  const isANumber = Number.isFinite(numA);
  const isBNumber = Number.isFinite(numB);

  if (!isANumber && !isBNumber) return 0; // both invalid
  if (!isANumber) return -1; // B is number, A is not => A first.  Always show invalid at first as invalid value < valid value
  if (!isBNumber) return 1; // A is number, B is not => B first.

  return numA - numB;
}

export function convertToNumber(
  val: null | undefined | string | number
): number {
  if (val === null || val === undefined) {
    return 0;
  }
  if (typeof val === 'number') {
    return Number.isFinite(val) ? val : 0;
  }
  const num = Number(val);
  return Number.isFinite(num) ? num : 0;
}

function convertToNegativeNumber(val: null | undefined | string | number) {
  return -1 * convertToNumber(val);
}

/**
 * Common column definitions for AG Grid.
 */
export const COMMON_COLUMN_DEFS: {
  [key in ColumnKeys]: (colDef?: ColDef) => ColDef;
} = {
  submittedDate: (colDef?: ColDef): ColDef => ({
    ...commonDateDef,
    headerName: 'Submitted date',
    headerClass: 'whitespace-nowrap font-semibold',
    field: 'creationDateTime',
    resizable: false,
    cellStyle: { wordBreak: 'break-all' },
    ...colDef,
  }),
  receiptNumber: (colDef?: ColDef): ColDef => ({
    headerName: 'Receipt number',
    field: 'receiptNumber',
    sortable: false,
    resizable: true,
    ...colDef,
  }),
  valueDate: (colDef?: ColDef): ColDef => ({
    ...commonDateDef,
    headerName: 'Value date',
    field: 'creationDateTime',
    resizable: false,
    cellStyle: { wordBreak: 'break-all' },
    ...colDef,
  }),
  paymentId: (colDef?: ColDef): ColDef => ({
    headerName: 'Payment ID',
    field: 'receiptNumber',
    sortable: false,
    resizable: true,
    ...colDef,
  }),
  fromAccount: (colDef?: ColDef): ColDef => ({
    headerName: 'From account',
    field: 'debitAccountName',
    sortable: false,
    resizable: true,
    ...colDef,
  }),
  toAccount: (colDef?: ColDef): ColDef => ({
    headerName: 'To account',
    field: 'creditAccountName',
    resizable: true,
    sortable: false,
    flex: 1,
    ...colDef,
  }),
  amount: (colDef?: ColDef): ColDef => ({
    ...commonCurrDef,
    headerName: 'Amount',
    headerClass:
      '!pr-[0px] right-aligned-header default-header !text-[0.8125rem]',
    field: 'amount',
    resizable: false,
    flex: 1,
    ...colDef,
  }),
  currency: (colDef?: ColDef): ColDef => {
    const { headerClass, ...restColDef } = colDef || {};
    return {
      headerName: 'CCY',
      headerClass: headerClass
        ? `font-semibold !pr-[0px] right-aligned-header default-header !text-[0.8125rem] ${headerClass}`
        : 'font-semibold !pr-[0px] right-aligned-header default-header !text-[0.8125rem]',
      field: 'currency',
      cellStyle: {
        textAlign: 'center',
      },
      sortable: false,
      resizable: false,
      ...restColDef,
    };
  },
  debitDescription: (colDef?: ColDef): ColDef => ({
    headerName: 'Debit description',
    field: 'debitDescription',
    sortable: false,
    resizable: true,
    flex: 1,
    ...colDef,
  }),
  paymentMethod: (colDef?: ColDef): ColDef => ({
    headerName: 'Payment method',
    field: 'paymentMethod',
    resizable: true,
    sortable: false,
    ...colDef,
  }),
  status: (colDef?: ColDef): ColDef => ({
    headerName: 'Status',
    field: 'status',
    filter: 'agSetColumnFilter',
    cellStyle: {
      textAlign: 'left',
    },
    headerClass: 'left-aligned-header default-header !text-[0.8125rem]',
    sortable: false,
    suppressColumnsToolPanel: true,
    resizable: false,
    ...colDef,
  }),
  issueDate: (colDef?: ColDef): ColDef => ({
    ...commonDateDef,
    headerName: 'Issue date',
    field: 'issueDate',
    sort: 'desc',
    resizable: false,
    ...colDef,
  }),
  statementNumber: (colDef?: ColDef): ColDef => ({
    headerName: 'Statement number',
    field: 'statementNumber',
    sortable: true,
    resizable: false,
    ...colDef,
  }),
  statementId: (colDef?: ColDef): ColDef => ({
    headerName: 'Download',
    field: 'statementId',
    sortable: false,
    resizable: false,
    flex: 1,
    ...colDef,
  }),
  transactionDateTime: (colDef?: ColDef): ColDef => ({
    ...commonDateDef,
    headerName: 'Date',
    field: 'transactionDateTime',
    sortable: false,
    resizable: false,
    ...colDef,
  }),
  narrative: (colDef?: ColDef): ColDef => ({
    headerName: 'Description',
    field: 'narrative',
    sortable: false,
    resizable: false,
    flex: 1,
    ...colDef,
  }),
  debitAmount: (colDef?: ColDef): ColDef => ({
    ...commonCurrDef,
    headerName: 'Debit',
    field: 'debitAmount',
    resizable: false,
    ...colDef,
  }),
  creditAmount: (colDef?: ColDef): ColDef => ({
    ...commonCurrDef,
    headerName: 'Credit',
    field: 'creditAmount',
    resizable: false,
    ...colDef,
  }),
  balance: (colDef?: ColDef): ColDef => ({
    ...commonCurrDef,
    headerName: 'Balance',
    field: 'balance',
    resizable: false,
    ...colDef,
  }),
  accountNumber: (colDef?: ColDef): ColDef => ({
    headerName: 'Account number',
    field: 'accountNumber',
    sortable: true,
    resizable: false,
    sort: 'asc',
    cellRenderer: AccountColumnCellRenderer,
    valueFormatter: (params: ValueFormatterParams) => {
      if (params && params?.value) {
        return formatBSBFromAccNo(params.value);
      }
      return '';
    },
    filterParams: {
      trimInput: true,
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      textMatcher: ({ value, filterText }: any) => {
        const formattedFiltertxt = filterText.replace(/-/gi, '');
        return value && value.indexOf(formattedFiltertxt) >= 0;
      },
    },
    ...colDef,
  }),
  beneficiaryNickname: (colDef?: ColDef): ColDef => ({
    headerName: 'Beneficiary nickname',
    headerClass: 'whitespace-nowrap font-semibold',
    field: 'beneficiaryNickname',
    sortable: true,
    ...colDef,
  }),
  accountDetails: (colDef?: ColDef): ColDef => ({
    headerName: 'Account details',
    headerClass: 'whitespace-nowrap font-semibold',
    field: 'accountDetails',
    // valueGetter:(values) =>{ values.data},
    sortable: true,
    ...colDef,
  }),
  type: (colDef?: ColDef): ColDef => ({
    headerName: 'Type',
    headerClass: 'whitespace-nowrap font-semibold',
    field: 'type',
    sortable: true,
    ...colDef,
  }),
  accountName: (colDef?: ColDef): ColDef => {
    const { headerClass, ...restColDef } = colDef ?? {};
    return {
      headerName: 'Account name',
      headerClass: headerClass
        ? `whitespace-nowrap font-semibold ${headerClass}`
        : 'whitespace-nowrap font-semibold',
      field: 'accountName',
      sortable: true,
      cellStyle: { wordBreak: 'break-all' },
      ...restColDef,
    };
  },
  entityName: (colDef?: ColDef): ColDef => ({
    headerName: 'Account holder',
    field: 'entityName',
    sortable: true,
    flex: 1,
    ...colDef,
  }),
  accountType: (colDef?: ColDef): ColDef => ({
    headerName: 'Account type',
    field: 'accountType',
    sortable: true,
    cellStyle: { wordBreak: 'break-all' },
    flex: 1,
    ...colDef,
  }),
  currencyCode: (colDef?: ColDef): ColDef => {
    const { headerClass, ...restColDef } = colDef ?? {};
    return {
      headerName: 'CCY',
      headerClass: headerClass
        ? `font-semibold ${headerClass}`
        : 'font-semibold',
      field: 'currencyCode',
      sortable: true,
      resizable: false,
      ...restColDef,
    };
  },
  availableBalance: (colDef?: ColDef): ColDef => ({
    ...commonCurrDef,
    headerName: 'Available balance',
    headerClass:
      '!pr-[0px] right-aligned-header default-header !text-[0.8125rem]',
    field: 'availableBalance',
    filter: 'agNumberColumnFilter',
    sortable: true,
    resizable: false,
    comparator: numberComparator,
    ...colDef,
  }),
  currentBalance: (colDef?: ColDef): ColDef => ({
    ...commonCurrDef,
    headerName: 'Current balance',
    headerClass:
      '!pr-[0px] right-aligned-header default-header !text-[0.8125rem]',
    field: 'currentBalance',
    filter: 'agNumberColumnFilter',
    sortable: true,
    resizable: false,
    comparator: numberComparator,
    ...colDef,
  }),
  overdraftLimit: (colDef?: ColDef): ColDef => ({
    ...commonCurrDef,
    headerName: 'Overdraft limit',
    headerClass:
      '!pr-[0px] right-aligned-header default-header !text-[0.8125rem]',
    field: 'overdraftLimit',
    filter: 'agNumberColumnFilter',
    sortable: true,
    resizable: false,
    comparator: numberComparator,
    ...colDef,
  }),
  accListStatus: (colDef?: ColDef): ColDef => ({
    headerName: 'Status',
    field: 'status',
    sortable: true,
    resizable: false,
    wrapHeaderText: false,
    headerClass: 'whitespace-nowrap font-semibold',
    cellClass: 'default-cell',
    filter: 'agSetColumnFilter',
    ...colDef,
  }),

  interestEarned: (colDef?: ColDef): ColDef => {
    const { headerClass, ...restColDef } = colDef ?? {};
    return {
      ...commonCurrDef,
      sortable: true,
      headerName: 'Interest earned',
      field: 'interestEarned',
      minWidth: 146,
      flex: 1,
      filter: 'agNumberColumnFilter',
      filterParams: {
        filterOptions: [
          'equals',
          'lessThan',
          'lessThanOrEqual',
          'greaterThan',
          'greaterThanOrEqual',
        ],
      },
      comparator: numberComparator,
      valueGetter: ({ data: { interestEarned } }) =>
        convertToNumber(interestEarned),
      valueFormatter: ({ value }: { value: number }) =>
        currencyFormatter(value),
      headerClass: headerClass
        ? `!pr-[0px] right-aligned-header !text-[0.8125rem] whitespace-nowrap font-semibold ${headerClass}`
        : '!pr-[0px] right-aligned-header !text-[0.8125rem] whitespace-nowrap font-semibold',
      ...restColDef,
    };
  },
  interestPaid: (colDef?: ColDef): ColDef => {
    const { headerClass, ...restColDef } = colDef ?? {};
    return {
      ...commonCurrDef,
      sortable: true,
      headerName: 'Interest paid',
      field: 'interestPaid',
      minWidth: 130,
      flex: 1,
      filter: 'agNumberColumnFilter',
      filterParams: {
        filterOptions: [
          'equals',
          'lessThan',
          'lessThanOrEqual',
          'greaterThan',
          'greaterThanOrEqual',
        ],
      },
      comparator: numberComparator,
      valueGetter: ({ data: { interestPaid } }) =>
        convertToNegativeNumber(interestPaid),
      valueFormatter: ({ value }: { value: number }) =>
        currencyFormatter(value),
      headerClass: headerClass
        ? `!pr-[0px] right-aligned-header !text-[0.8125rem] whitespace-nowrap font-semibold ${headerClass}`
        : '!pr-[0px] right-aligned-header !text-[0.8125rem] whitespace-nowrap font-semibold',
      ...restColDef,
    };
  },
  withholdingTax: (colDef?: ColDef): ColDef => {
    const { headerClass, ...restColDef } = colDef ?? {};
    return {
      ...commonCurrDef,
      sortable: true,
      headerName: 'Withholding tax',
      field: 'withholdingTax',
      minWidth: 150,
      flex: 1,
      filter: 'agNumberColumnFilter',
      filterParams: {
        filterOptions: [
          'equals',
          'lessThan',
          'lessThanOrEqual',
          'greaterThan',
          'greaterThanOrEqual',
        ],
      },
      comparator: numberComparator,
      valueGetter: ({ data: { withholdingTax } }) =>
        convertToNegativeNumber(withholdingTax),
      valueFormatter: ({ value }: { value: number }) =>
        currencyFormatter(value),
      headerClass: headerClass
        ? `!pr-[0px] right-aligned-header !text-[0.8125rem] whitespace-nowrap font-semibold ${headerClass}`
        : '!pr-[0px] right-aligned-header !text-[0.8125rem] whitespace-nowrap font-semibold',
      ...restColDef,
    };
  },
  actions: (colDef?: ColDef): ColDef => ({
    headerName: 'Actions',
    headerClass: 'whitespace-nowrap font-semibold',
    field: 'actions',
    sortable: false,
    cellRenderer: ActionButton,
    cellClass: 'overflow-visible-cell !text-[0.8125rem]',
    filter: false,
    lockPosition: 'right',
    suppressColumnsToolPanel: true,
    lockPinned: true,
    menuTabs: [],
    resizable: false,
    suppressMovable: true,
    pinned: 'right',
    ...colDef,
  }),
};
