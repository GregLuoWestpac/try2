import { debounce } from 'lodash';
import { RefObject, useEffect, useRef, useState } from 'react';
import {
  CONTENT_PADDING_PX,
  DEBOUNCE_DELAY_MS,
  getElementHeight,
  getGridHeight,
  getPageHeight,
  hasSignificantChange,
  HEADER_HEIGHT,
  ROW_HEIGHT,
} from './useGridHeight.utils';

export function useGridHeight(
  containerRef: RefObject<HTMLElement> | undefined,
  rowCount: number,
  tableHeight: number,
  minHeight: number,
  setHasVScroll: React.Dispatch<React.SetStateAction<boolean>>,
  footnote?: string
) {
  const [gridHeight, setGridHeight] = useState(
    Math.max(minHeight, rowCount * ROW_HEIGHT + HEADER_HEIGHT)
  );

  const resizeObserverRef = useRef<ResizeObserver | null>(null);

  function debouncedCalculateGridHeight() {
    if (!containerRef?.current) return;

    const agGridHeaderHeight: number = getElementHeight(
      '.ag-header',
      containerRef.current
    );

    const agGridRows = containerRef.current?.querySelectorAll('.ag-row');
    let rowHeight = ROW_HEIGHT;

    if (agGridRows?.length && agGridRows?.length > 0) {
      let totalHeight = 0;
      let validRows = 0;

      for (let i = 0; i < Math.min(agGridRows.length, 5); i++) {
        const row = agGridRows[i] as HTMLElement;
        const height = row.offsetHeight;
        if (height > 0) {
          totalHeight += height;
          validRows++;
        }
      }

      if (validRows > 0) {
        rowHeight = Math.round(totalHeight / validRows);
      }
    }

    const agGridTotalHeight = agGridHeaderHeight + rowCount * rowHeight;

    let footnoteHeight = 0;
    if (footnote && containerRef.current) {
      const footnoteElement = containerRef.current.querySelector('.text-muted');
      if (footnoteElement) {
        const footnoteRect = footnoteElement.getBoundingClientRect();
        const footnoteStyles = window.getComputedStyle(footnoteElement);
        const marginTop = parseInt(footnoteStyles.marginTop, 10) || 0;
        const marginBottom = parseInt(footnoteStyles.marginBottom, 10) || 0;
        footnoteHeight = footnoteRect.height + marginTop + marginBottom;
      }
    }

    if (rowCount === 0) return;

    const pageCard = document.querySelector('.mv-card-container');
    const pageCardHeight = pageCard ? pageCard.clientHeight : 0;
    const pageCardMargins = 18;
    const containerHeight = containerRef.current?.clientHeight ?? 0;

    const otherContentHeight = pageCardHeight - containerHeight;
    const footnoteSpace = footnote ? footnoteHeight : 0;

    const pageHeight = getPageHeight();

    const availableHeight =
      pageHeight -
      otherContentHeight -
      pageCardMargins -
      footnoteSpace -
      CONTENT_PADDING_PX;

    const finalHeight = getGridHeight(
      agGridTotalHeight,
      minHeight,
      availableHeight
    );

    if (agGridTotalHeight > finalHeight) {
      setHasVScroll(true);
    }

    setGridHeight(finalHeight);
  }

  const CalculateGridHeight = debounce(
    debouncedCalculateGridHeight,
    DEBOUNCE_DELAY_MS
  );

  const handleWindowResize = () => {
    CalculateGridHeight();
  };

  const debouncedHandleElementResize = (entries: ResizeObserverEntry[]) => {
    const significantChange = hasSignificantChange(entries);
    if (significantChange) {
      CalculateGridHeight();
    }
  };

  const handleElementResize = debounce(
    debouncedHandleElementResize,
    DEBOUNCE_DELAY_MS
  );

  useEffect(() => {
    if (!containerRef?.current || !rowCount) return;

    const elementsToObserve = [containerRef.current].filter(
      Boolean
    ) as Element[];

    const cardContainer = containerRef.current?.closest('.mv-card-container');
    if (cardContainer) {
      elementsToObserve.push(cardContainer);
    }

    if (elementsToObserve.length > 0) {
      resizeObserverRef.current = new ResizeObserver(handleElementResize);
      elementsToObserve.forEach(element => {
        resizeObserverRef.current!.observe(element);
      });
    }

    window.addEventListener('resize', handleWindowResize);

    return () => {
      window.removeEventListener('resize', handleWindowResize);

      if (resizeObserverRef.current) {
        resizeObserverRef.current.disconnect();
        resizeObserverRef.current = null;
      }
    };
  }, [containerRef, rowCount, tableHeight, setHasVScroll, footnote]);

  const enableAutoHeight = !!containerRef;
  if (!enableAutoHeight) {
    return { gridHeight: tableHeight };
  }

  return { gridHeight };
}
