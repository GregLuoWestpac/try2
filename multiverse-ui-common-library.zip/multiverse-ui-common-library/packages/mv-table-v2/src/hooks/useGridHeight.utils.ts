export const ROW_HEIGHT = 42;
export const HEADER_HEIGHT = 48;
export const Max_MinHeight = 600;
export const DEBOUNCE_DELAY_MS = 100;
export const RESIZE_THRESHOLD_PX = 10;
export const CONTENT_PADDING_PX = 20;

export function getElementHeight(
  selector: string,
  gridContainer?: HTMLElement
): number {
  const element = gridContainer?.querySelector<HTMLElement>(selector);
  return element?.getBoundingClientRect().height ?? 0;
}

export function getPageHeight(): number {
  return (
    window.innerHeight ||
    document.documentElement.clientHeight ||
    document.body.clientHeight
  );
}

export function getGridHeight(
  agGridTotalHeight: number,
  minHeight: number,
  availableHeight: number
): number {
  let gridHeight = 0;

  // agGridTotalHeight: 120, availableHeight: 700, then finalHeight = minHeight(135)
  if (agGridTotalHeight < minHeight) {
    gridHeight = minHeight;
  }

  // agGridTotalHeight: 150, availableHeight: 700, then finalHeight = 150
  // agGridTotalHeight: 150, availableHeight: 140, then finalHeight = 150
  // agGridTotalHeight: 400, availableHeight: 500, then finalHeight = 400
  else if (agGridTotalHeight < Max_MinHeight) {
    gridHeight = agGridTotalHeight;
  }

  // agGridTotalHeight: 700, availableHeight: 300, then finalHeight = 600
  else if (availableHeight <= Max_MinHeight) {
    gridHeight = Max_MinHeight;
  }

  // agGridTotalHeight: 700, availableHeight: 800, then finalHeight = 700
  else if (
    availableHeight > Max_MinHeight &&
    agGridTotalHeight <= availableHeight
  ) {
    gridHeight = agGridTotalHeight;
  }

  // agGridTotalHeight: 850, availableHeight: 750, then finalHeight = 750
  else if (
    availableHeight > Max_MinHeight &&
    agGridTotalHeight > availableHeight
  ) {
    gridHeight = availableHeight;
  }

  return gridHeight;
}

export function hasSignificantChange(entries: ResizeObserverEntry[]): boolean {
  const significantChange = entries.some(entry => {
    const { width, height } = entry.contentRect;
    const element = entry.target as HTMLElement;
    const lastWidth = parseFloat(element.dataset.lastWidth || '0');
    const lastHeight = parseFloat(element.dataset.lastHeight || '0');

    const widthDiff = Math.abs(width - lastWidth);
    const heightDiff = Math.abs(height - lastHeight);

    element.dataset.lastWidth = width.toString();
    element.dataset.lastHeight = height.toString();

    return widthDiff > RESIZE_THRESHOLD_PX || heightDiff > RESIZE_THRESHOLD_PX;
  });
  return significantChange;
}
