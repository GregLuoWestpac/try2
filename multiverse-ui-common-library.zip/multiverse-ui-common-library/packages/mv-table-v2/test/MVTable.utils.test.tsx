/* eslint-disable @typescript-eslint/ban-ts-comment */
import { Column, ColumnPinnedEvent, GridApi } from 'ag-grid-enterprise';
import {
  convertToNumber,
  suppressKeyboardEvent,
  onColumnPinned,
  onFilterChanged,
  getAllFocusableElementsOf,
  getEventPath,
  moveColumn,
  suppressHeaderKeyboardEvent,
  numberComparator,
  sanitizeForCSV,
} from '../src/MVTable.utils';

describe('Test MVTable Utils', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  describe('suppressKeyboardEvent', () => {
    const GRID_CELL_CLASSNAME = 'ag-cell';

    beforeEach(() => {
      document.body.innerHTML = `
        <div class='${GRID_CELL_CLASSNAME}'>
          <button id='btn1'>Button 1</button>
          <button id='btn2'>Button 2</button>
        </div>
      `;
    });

    const simulateTabEvent = (shiftKey = false) => {
      const event = new KeyboardEvent('keydown', {
        key: 'Tab',
        shiftKey,
        bubbles: true,
      });

      document.getElementById('btn1')?.dispatchEvent(event);
      return event;
    };

    it('should suppress tabbing forward when not on the last focusable element', () => {
      const event = simulateTabEvent();

      // @ts-ignore
      const suppress = suppressKeyboardEvent({ event });
      expect(suppress).toBe(true);
    });

    it('should not suppress tabbing forward when on the last focusable element', () => {
      document.getElementById('btn2')?.focus();
      const event = simulateTabEvent();

      // @ts-ignore
      const suppress = suppressKeyboardEvent({ event });
      expect(suppress).toBe(false);
    });

    it('should suppress tabbing backward when not on the first focusable element', () => {
      document.getElementById('btn2')?.focus();
      const event = simulateTabEvent(true);

      // @ts-ignore
      const suppress = suppressKeyboardEvent({ event });
      expect(suppress).toBe(true);
    });

    it('should not suppress tabbing backward when on the first focusable element', () => {
      document.getElementById('btn1')?.focus();
      const event = simulateTabEvent(true);

      // @ts-ignore
      const suppress = suppressKeyboardEvent({ event });
      expect(suppress).toBe(false);
    });
  });

  describe('onColumnPinned', () => {
    it('should return undefined if the ag-body-viewport is not existed', () => {
      const columns: Column[] = [];

      // @ts-ignore
      const mockGridApi: GridApi = {
        getAllDisplayedColumns: jest.fn().mockImplementation(() => columns),
      };

      // @ts-ignore
      const event: ColumnPinnedEvent = {
        api: mockGridApi,
      };
      expect(onColumnPinned(event)).toBe(undefined);
    });

    it('should add has-pinned-left class if pinnedColumns is existed', () => {
      // @ts-ignore
      const columns: Column[] = [{ getPinned: () => 'left' }];

      // @ts-ignore
      const mockGridApi: GridApi = {
        getAllDisplayedColumns: jest.fn().mockImplementation(() => columns),
      };
      // @ts-ignore
      const event: ColumnPinnedEvent = {
        api: mockGridApi,
      };
      document.body.innerHTML =
        '<div class="ag-body-viewport">AG body viewport</div>';

      onColumnPinned(event);

      expect(document.body.innerHTML).toContain('has-pinned-left');
    });

    it('should remove has-pinned-left class if pinnedColumns is not existed', () => {
      // @ts-ignore
      const columns: Column[] = [{ getPinned: () => 'right' }];

      // @ts-ignore
      const mockGridApi: ColumnApi = {
        getAllDisplayedColumns: jest.fn().mockImplementation(() => columns),
      };
      // @ts-ignore
      const event: ColumnPinnedEvent = {
        api: mockGridApi,
      };
      document.body.innerHTML =
        '<div class="ag-body-viewport has-pinned-left">AG body viewport</div>';

      onColumnPinned(event);

      expect(document.body.innerHTML).not.toContain('has-pinned-left');
    });
  });

  describe('getAllFocusableElementsOf', () => {
    it('should return an empty array if no focusable elements are founds', () => {
      document.body.innerHTML = '<div id="test"><p>Non-focusable</p></div>';
      const el = document.getElementById('test') as HTMLDivElement;
      expect(getAllFocusableElementsOf(el)).toEqual([]);
    });

    it('should return focusable elements', () => {
      document.body.innerHTML = `
        <div id='test'>
          <button id='button'>Button</button>
          <a href='#' id='link'>Link</a>
          <select id='select'></select>
          <textarea id='textarea'></textarea>
          <div tabindex='0' id='divTab'>Div with tabindex</div>
          <input type='text' id='input'>
        </div>
      `;
      const el = document.getElementById('test') as HTMLDivElement;
      const focusableElements = getAllFocusableElementsOf(el);
      expect(focusableElements.length).toBe(6);
      expect(focusableElements).toEqual(
        expect.arrayContaining([
          expect.objectContaining({ id: 'button' }),
          expect.objectContaining({ id: 'link' }),
          expect.objectContaining({ id: 'input' }),
          expect.objectContaining({ id: 'select' }),
          expect.objectContaining({ id: 'textarea' }),
          expect.objectContaining({ id: 'divTab' }),
        ])
      );
    });

    it('should ignore elements with negative tabindex', () => {
      document.body.innerHTML = `
        <div id='test'>
          <button id='button'>Button</button>
          <div tabindex='-1' id='divTab'>Div with negative tabindex</div>
        </div>
      `;

      const el = document.getElementById('test') as HTMLDivElement;
      const focusableElements = getAllFocusableElementsOf(el);
      expect(focusableElements.length).toBe(1);
      expect(focusableElements[0].id).toBe('button');
    });
  });

  describe('getEventPath', () => {
    it('should return the path from the event target to the root', () => {
      document.body.innerHTML = `
        <div id='parent'><div id='child'></div></div>
      `;
      const child = document.getElementById('child');
      const parent = document.getElementById('parent');
      const event = { target: child };

      // @ts-ignore
      const path = getEventPath(event);
      expect(path[0]).toBe(child);
      expect(path[1]).toBe(parent);
      expect(path[2]).toBe(document.body);
    });

    it('should return only the target if it has no parent', () => {
      const standaloneElement = document.createElement('div');
      const event = { target: standaloneElement };

      // @ts-ignore
      const path = getEventPath(event);
      expect(path).toEqual([standaloneElement]);
    });
  });

  describe('moveColumn', () => {
    let mockGridApi: GridApi;
    let columns: Column[];
    const mockMoveColumn = jest.fn();

    const createMockColumn = (id: string) => ({
      getUniqueId: jest.fn().mockReturnValue(id),
    });

    beforeEach(() => {
      // @ts-ignore
      columns = [createMockColumn('col1'), createMockColumn('col2')];

      // @ts-ignore
      mockGridApi = {
        getAllGridColumns: jest.fn().mockReturnValue(columns),
        getAllDisplayedColumns: jest.fn().mockReturnValue(columns),
        moveColumns: mockMoveColumn,
      };
    });

    it('should move a column to the left', () => {
      const column = columns[1];

      moveColumn(column, mockGridApi, 'left');

      expect(mockMoveColumn).toHaveBeenCalledWith(['col2'], 0);
    });
  });

  describe('suppressHeaderKeyboardEvent', () => {
    let mockGridApi: GridApi;
    const mockColumn = {};
    let columns: Column[];

    const createMockColumn = (id: string) => ({
      getUniqueId: jest.fn().mockReturnValue(id),
    });

    beforeEach(() => {
      // @ts-ignore
      columns = [createMockColumn('col1'), createMockColumn('col2')];

      // @ts-ignore
      mockGridApi = {
        getAllGridColumns: jest.fn().mockReturnValue(columns),
        getAllDisplayedColumns: jest.fn().mockReturnValue(columns),
        moveColumns: jest.fn(),
      };
    });

    const createMockEvent = (key: string, shiftKey = false) => ({
      key,
      shiftKey,
    });

    it('should suppress event for ArrowLeft and shiftKey', () => {
      const event = createMockEvent('ArrowLeft', true);

      const result = suppressHeaderKeyboardEvent({
        // @ts-ignore
        event,
        api: mockGridApi,
        // @ts-ignore
        column: mockColumn,
      });

      expect(result).toBe(true);
    });

    it('should suppress event for ArrowRight and shiftKey', () => {
      const event = createMockEvent('ArrowRight', true);

      const result = suppressHeaderKeyboardEvent({
        // @ts-ignore
        event,
        api: mockGridApi,
        // @ts-ignore
        column: mockColumn,
      });

      expect(result).toBe(true);
    });
  });

  describe('onFilterChanged', () => {
    it('should trigger hide overlay', () => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const event: any = {
        api: {
          getRenderedNodes: jest.fn(() => [{}]),
          showNoRowsOverlay: jest.fn(),
          hideOverlay: jest.fn(),
        },
      };

      onFilterChanged(event);

      expect(event.api.getRenderedNodes).toHaveBeenCalledTimes(1);
      expect(event.api.showNoRowsOverlay).not.toHaveBeenCalled();
      expect(event.api.hideOverlay).toHaveBeenCalledTimes(1);
    });

    it('should trigger no row overlay', () => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const event: any = {
        api: {
          getRenderedNodes: jest.fn(() => []),
          showNoRowsOverlay: jest.fn(),
          hideOverlay: jest.fn(),
        },
      };

      onFilterChanged(event);

      expect(event.api.getRenderedNodes).toHaveBeenCalledTimes(1);
      expect(event.api.showNoRowsOverlay).toHaveBeenCalledTimes(1);
      expect(event.api.hideOverlay).not.toHaveBeenCalled();
    });
  });

  describe('numberComparator', () => {
    it('should return 0 for equal numbers', () => {
      expect(numberComparator(5, 5)).toBe(0);
      expect(numberComparator('5', 5)).toBe(0);
      expect(numberComparator('5', '5')).toBe(0);
      expect(numberComparator(' 5 ', 5)).toBe(0);
      expect(numberComparator(0, 0)).toBe(0);
      expect(numberComparator('0', 0)).toBe(0);
    });

    it('should return 1 if valueA > valueB', () => {
      expect(numberComparator(10, 5)).toBeGreaterThan(0);
      expect(numberComparator('10', 5)).toBeGreaterThan(0);
      expect(numberComparator('10', '5')).toBeGreaterThan(0);
      expect(numberComparator(0.99, 0.9)).toBeGreaterThan(0);
    });

    it('should return -1 if valueA < valueB', () => {
      expect(numberComparator(5, 10)).toBeLessThan(0);
      expect(numberComparator('5', 10)).toBeLessThan(0);
      expect(numberComparator('5', '10')).toBeLessThan(0);
      expect(numberComparator(0.9, 0.99)).toBeLessThan(0);
    });

    it('should handle null, undefined, and empty string as invalid', () => {
      expect(numberComparator(null, 1)).toBe(-1);
      expect(numberComparator(undefined, 1)).toBe(-1);
      expect(numberComparator('', 1)).toBe(-1);
      expect(numberComparator(1, null)).toBe(1);
      expect(numberComparator(1, undefined)).toBe(1);
      expect(numberComparator(1, '')).toBe(1);
      expect(numberComparator(null, null)).toBe(0);
      expect(numberComparator(undefined, undefined)).toBe(0);
      expect(numberComparator('', '')).toBe(0);
    });

    it('should treat non-numeric strings as invalid', () => {
      expect(numberComparator('abc', 1)).toBe(-1);
      expect(numberComparator(1, 'abc')).toBe(1);
      expect(numberComparator('abc', 'def')).toBe(0);
    });

    it('should handle NaN as invalid', () => {
      expect(numberComparator(NaN, 1)).toBe(-1);
      expect(numberComparator(1, NaN)).toBe(1);
      expect(numberComparator(NaN, NaN)).toBe(0);
    });

    it('should be use for sorting an array', () => {
      expect([10, 5, '4', ''].sort(numberComparator)).toEqual(['', '4', 5, 10]);
      expect([NaN, 5, '4', ''].sort(numberComparator)).toEqual([
        NaN,
        '',
        '4',
        5,
      ]);
      expect([10, 3, null, '1'].sort(numberComparator)).toEqual([
        null,
        '1',
        3,
        10,
      ]);
      expect([10, null, 'abc', '1'].sort(numberComparator)).toEqual([
        null,
        'abc',
        '1',
        10,
      ]);
      expect(['abc', 10, 5, '4', ''].sort(numberComparator)).toEqual([
        'abc',
        '',
        '4',
        5,
        10,
      ]);
    });

    describe('convertToNumber', () => {
      it('should return 0 for null or undefined', () => {
        expect(convertToNumber(null)).toBe(0);
        expect(convertToNumber(undefined)).toBe(0);
      });

      it('should return the number itself if it is a finite number', () => {
        expect(convertToNumber(5)).toBe(5);
        expect(convertToNumber(0)).toBe(0);
        expect(convertToNumber(-10)).toBe(-10);
        expect(convertToNumber(3.14)).toBe(3.14);
      });

      it('should return 0 for non-finite numbers', () => {
        expect(convertToNumber(NaN)).toBe(0);
        expect(convertToNumber(Infinity)).toBe(0);
        expect(convertToNumber(-Infinity)).toBe(0);
      });

      it('should convert numeric strings to numbers', () => {
        expect(convertToNumber('5')).toBe(5);
        expect(convertToNumber('0')).toBe(0);
        expect(convertToNumber('-10')).toBe(-10);
        expect(convertToNumber('3.14')).toBe(3.14);
        expect(convertToNumber(' 42 ')).toBe(42);
      });

      it('should return 0 for non-numeric strings', () => {
        expect(convertToNumber('abc')).toBe(0);
        expect(convertToNumber('')).toBe(0);
        expect(convertToNumber(' ')).toBe(0);
        expect(convertToNumber('NaN')).toBe(0);
      });
    });

    describe('sanitizeForCSV', () => {
      it('should prefix value with space if it starts with +', () => {
        expect(sanitizeForCSV('+123456789')).toBe(' +123456789');
        expect(sanitizeForCSV('+61-424222333')).toBe(' +61-424222333');
      });

      it('should prefix value with space if it starts with -', () => {
        expect(sanitizeForCSV('-123')).toBe(' -123');
        expect(sanitizeForCSV('-424222333.00')).toBe(' -424222333.00');
      });

      it('should prefix value with single quote if it starts with =', () => {
        expect(sanitizeForCSV('=SUM(A1:A2)')).toBe("'=SUM(A1:A2)");
      });

      it('should prefix value with single quote if it starts with @', () => {
        expect(sanitizeForCSV('@username')).toBe("'@username");
      });

      it('should prefix value with single quote if it starts with tab character', () => {
        expect(sanitizeForCSV('\tTabbed')).toBe("'\tTabbed");
      });

      it('should prefix value with single quote if it starts with carriage return', () => {
        expect(sanitizeForCSV('\rCarriage')).toBe("'\rCarriage");
      });

      it('should return value unchanged if it does not start with special characters', () => {
        expect(sanitizeForCSV('NormalValue')).toBe('NormalValue');
        expect(sanitizeForCSV('123')).toBe('123');
        expect(sanitizeForCSV('A=1')).toBe('A=1');
      });

      it('should handle empty string', () => {
        expect(sanitizeForCSV('')).toBe('');
      });
    });
  });
});
