# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.231.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.230.1...v1.231.0) (2026-02-18)

### 🚀 Features

- update footer margin | ART-89786 ([c866e44](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c866e44299f003e89e91f17a1a70c6141839284c))

## [1.230.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.229.1...v1.230.0) (2026-02-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.229.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.228.0...v1.229.0) (2026-02-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.228.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.227.0...v1.228.0) (2026-02-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.227.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.226.2...v1.227.0) (2026-02-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.226.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.225.5...v1.226.0) (2026-02-06)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.225.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.225.2...v1.225.3) (2026-02-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.225.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.225.1...v1.225.2) (2026-02-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.225.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.224.9...v1.225.0) (2026-02-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.224.9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.224.8...v1.224.9) (2026-02-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.224.8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.224.7...v1.224.8) (2026-02-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.224.7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.224.6...v1.224.7) (2026-02-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.224.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.224.3...v1.224.4) (2026-01-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.224.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.224.1...v1.224.2) (2026-01-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.224.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.224.0...v1.224.1) (2026-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.224.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.223.3...v1.224.0) (2026-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.223.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.223.2...v1.223.3) (2026-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.223.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.223.1...v1.223.2) (2026-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.223.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.223.0...v1.223.1) (2026-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.222.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.221.6...v1.222.0) (2026-01-26)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.221.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.221.3...v1.221.4) (2026-01-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.221.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.221.2...v1.221.3) (2026-01-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.221.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.221.1...v1.221.2) (2026-01-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.221.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.221.0...v1.221.1) (2026-01-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.221.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.220.0...v1.221.0) (2026-01-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.219.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.218.0...v1.219.0) (2025-12-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.184.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.184.3...v1.184.4) (2025-09-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.184.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.184.2...v1.184.3) (2025-09-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.182.7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.182.6...v1.182.7) (2025-09-12)

### 💥 Bug Fixes

- updated header class for Currency col | ART-74291 ([cbfa768](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/cbfa76847ba15ee37d76d8bcc0d7b48cd44b317b))

## [1.182.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.182.5...v1.182.6) (2025-09-10)

### 💥 Bug Fixes

- updated header alignment for Amount column | ART-74291 ([4a6e8e1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4a6e8e15598e66707cc2765f79f6ad60a88da731))

## [1.182.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.182.4...v1.182.5) (2025-09-09)

### 💥 Bug Fixes

- added header class for columns in beneficiary auth tab tables | ART-75221 ([f5fc84e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f5fc84e3afc982397279488452f23171d28f4570))

## [1.182.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.182.3...v1.182.4) (2025-09-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.182.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.182.2...v1.182.3) (2025-09-09)

### 💥 Bug Fixes

- update valueGetter and value Formatter | ART-74520 ([1e0d85e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1e0d85e293e71c2f0f8b47bef1de1188982709d5))

## [1.181.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.181.2...v1.181.3) (2025-09-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.181.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.181.0...v1.181.1) (2025-09-03)

### 💥 Bug Fixes

- improve currencyCode column definition for better header class handling | ART-73922 ([cedea4e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/cedea4e20602d47164f412c0d4d4f21960ecc1d2))

## [1.180.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.180.0...v1.180.1) (2025-09-03)

### 💥 Bug Fixes

- enhance column definitions for improved header class handling | ART-73922 ([f3edcef](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f3edcef082efc653dcd16f29780eda9253313f05))

## [1.179.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.179.2...v1.179.3) (2025-09-02)

### 💥 Bug Fixes

- added missing font-semibold class | ART-73922 ([bee0957](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/bee0957e3edb6727e79399b84ec9bbca170c38e9))

## [1.179.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.179.1...v1.179.2) (2025-09-02)

### 💥 Bug Fixes

- enhance headerClass assignment for better styling flexibility | ART-73922 ([25d95b7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/25d95b774b762e68e06a881def55d5d0d0bd57e8))

## [1.178.12](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.178.11...v1.178.12) (2025-08-20)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.178.9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.178.8...v1.178.9) (2025-08-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.178.8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.178.7...v1.178.8) (2025-08-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.178.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.178.1...v1.178.2) (2025-08-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.177.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.177.1...v1.177.2) (2025-08-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.177.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.177.0...v1.177.1) (2025-08-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.173.7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.173.6...v1.173.7) (2025-08-06)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.173.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.173.5...v1.173.6) (2025-08-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.173.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.173.4...v1.173.5) (2025-08-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.173.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.173.3...v1.173.4) (2025-08-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.173.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.173.2...v1.173.3) (2025-08-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.173.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.172.2...v1.173.0) (2025-07-30)

### 🚀 Features

- add cvs injection protection to mvtable cvs export | ART-68911 ([ab37d17](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ab37d173a8e1b1eba854b20179da5aa9f193ad88))

## [1.170.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.167.2...v1.170.1) (2025-07-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.163.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.163.0...v1.163.1) (2025-07-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.159.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.158.0...v1.159.0) (2025-07-10)

### 🚀 Features

- Add onFilterChanged handler to MVTable | ART-66114 ([9db40b1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9db40b1064ec9b28f3ec1f48ec2e98b0789cd093))

## [1.158.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.157.0...v1.158.0) (2025-07-09)

### 🚀 Features

- add isStatic and tableHeight params to be more readable | ART-54678 ([03de91f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/03de91f8fbe31b819018de89581e39b08fd1ad8d))

## [1.152.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.151.3...v1.152.0) (2025-07-03)

### 🚀 Features

- added top and bottom 24px margins + gave isStatic and height to mvtable params | ART-58868 ([2eb4d92](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2eb4d9298993715f19aab05637858ff698005986))

## [1.150.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.150.0...v1.150.1) (2025-06-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.117.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.117.0...v1.117.1) (2025-05-06)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.116.7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.116.6...v1.116.7) (2025-04-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.116.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.116.5...v1.116.6) (2025-04-30)

### 💥 Bug Fixes

- moving suppression to above spread operator | ART-53758 ([655df7b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/655df7b97e75995313b31a8c4c4b6012602b3836))
- removed suppressHorizontalScroll | ART-53758 ([b7eab43](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b7eab431dad091513a7e692ffbf8340449487f90))

## [1.116.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.116.0...v1.116.1) (2025-04-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.116.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.115.0...v1.116.0) (2025-04-24)

### 💥 Bug Fixes

- added back submittedDate and receiptNumber in coldefs for backwards compatibility | ART-53469 ([4c6cdb7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4c6cdb7016b14fc9c9410932be592436a4c015ea))

## [1.111.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.110.1...v1.111.0) (2025-04-16)

### 🚀 Features

- updated column definitions in mv table | ART-46683 ([c327218](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c327218f23ec8650ad537c28bc761a062ace9d9d))

## [1.104.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.103.1...v1.104.0) (2025-04-07)

### 🚀 Features

- added export csv functionality for MVTableV2 | ART - 41541 ([9f2a257](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9f2a25728fdfdb2b0ab0336ae134d590671b2965))
- added forwardRef for MVTable | ART - 41541 ([52da884](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/52da884fd796b3797e5f7ca6fab85ab91722ba76))
- removed console.log | ART - 41541 ([751edaf](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/751edafc8de57ee33f99b5c0920332d468dad139))

## [1.95.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.95.0...v1.95.1) (2025-03-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.95.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.94.0...v1.95.0) (2025-03-28)

### 🚀 Features

- updated statement table data variable | ART-45838 ([8fe5399](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8fe5399adcf8d37d0bec32c4bec51b507b6245eb))

## [1.90.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.89.0...v1.90.0) (2025-03-24)

### 🚀 Features

- added autoresize on modelUpdate behaviour | ART-32867 ([33ab88a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/33ab88a33069c4ee3571ace64146e1691c6e0d3b))

## [1.88.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.87.0...v1.88.0) (2025-03-21)

### 🚀 Features

- changing commoncoldef | ART-32867 ([bb66a47](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/bb66a47cc556846a9ca82b90e32afded018a9f70))
- configure resizable parameter in common column defs | ART-32867 ([fba381d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/fba381df959c4cbc036f0de02a18729bd5935f7a))
- configured ColDefs to fit requirements per columns | ART-32867 ([3d43d28](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3d43d2897384848d53e8ac073ed1da01ff6c2b00))
- moved changes from MFE to MV coldefs | ART-32867 ([8975be0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8975be063a47fd20b0f13af98117eb4a442c6dab))

## [1.80.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.80.4...v1.80.5) (2025-03-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.80.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.80.1...v1.80.2) (2025-03-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.75.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.75.0...v1.75.1) (2025-03-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.74.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.74.1...v1.74.2) (2025-03-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.69.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.69.3...v1.69.4) (2025-03-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.66.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.66.2...v1.66.3) (2025-02-26)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.66.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.66.0...v1.66.1) (2025-02-25)

### 💥 Bug Fixes

- use ref to handle onClick and onKeyDown events | ART-41848 ([617e936](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/617e9365448b98f8b39e221545f254faebdd2a7d))

## [1.60.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.60.2...v1.60.3) (2025-02-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.60.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.60.1...v1.60.2) (2025-02-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.60.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.60.0...v1.60.1) (2025-02-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.58.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.58.1...v1.58.2) (2025-02-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.55.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.55.3...v1.55.4) (2025-02-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.49.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.49.4...v1.49.5) (2025-01-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table-v2

## [1.40.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.40.1...v1.40.2) (2024-12-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table

## [1.34.7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.6...v1.34.7) (2024-12-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table

## [1.33.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.33.0...v1.33.1) (2024-11-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table

## [1.30.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.30.1...v1.30.2) (2024-11-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table

## [1.25.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.25.2...v1.25.3) (2024-11-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table

## [1.25.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.25.1...v1.25.2) (2024-11-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-table

## [1.15.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.14.0...v1.15.0) (2024-11-04)

### 🚀 Features

- update to ts | ART-15347 ([4f5dba5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4f5dba5234cda618bad6b9596bdb1c30cec383fc))

## [1.12.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.11.0...v1.12.0) (2024-10-24)

### 🚀 Features

- add ag-grid | ART-15347 ([4d7a0ce](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4d7a0cec74717df4226dbbb8eaa4a9057c1d5168))
