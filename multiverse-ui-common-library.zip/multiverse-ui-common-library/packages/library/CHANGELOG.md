# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.231.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.230.1...v1.231.0) (2026-02-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.230.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.229.1...v1.230.0) (2026-02-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.229.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.229.0...v1.229.1) (2026-02-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.229.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.228.0...v1.229.0) (2026-02-12)

### 🚀 Features

- add prefixWithISOCurrency function to format currency values | ART-85171 ([4c899f9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4c899f964708889b2dc98ed62290830a4ed8c0c9))

## [1.228.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.227.0...v1.228.0) (2026-02-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.227.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.226.2...v1.227.0) (2026-02-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.226.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.226.1...v1.226.2) (2026-02-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.226.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.225.5...v1.226.0) (2026-02-06)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.225.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.225.3...v1.225.4) (2026-02-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.225.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.225.2...v1.225.3) (2026-02-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.225.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.225.1...v1.225.2) (2026-02-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.225.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.225.0...v1.225.1) (2026-02-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.225.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.9...v1.225.0) (2026-02-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.224.9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.8...v1.224.9) (2026-02-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.224.8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.7...v1.224.8) (2026-02-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.224.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.6...v1.224.7) (2026-02-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.224.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.4...v1.224.5) (2026-01-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.224.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.3...v1.224.4) (2026-01-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.224.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.1...v1.224.2) (2026-01-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.224.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.224.0...v1.224.1) (2026-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.224.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.223.3...v1.224.0) (2026-01-29)

### 🚀 Features

- update mv currency with balanceAmount input | ART-88675 ([a896ad3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a896ad3b0161648bb063ff8d44e9062079e8d6c3))

## [1.223.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.223.2...v1.223.3) (2026-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.223.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.223.1...v1.223.2) (2026-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.223.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.223.0...v1.223.1) (2026-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.222.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.221.6...v1.222.0) (2026-01-26)

### 🚀 Features

- export supported currency | ART-85294 ([960d6c3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/960d6c357269188b37c8616ad4a5e4e06d7337a1))

## [1.221.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.221.3...v1.221.4) (2026-01-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.221.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.221.2...v1.221.3) (2026-01-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.221.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.221.1...v1.221.2) (2026-01-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.221.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.221.0...v1.221.1) (2026-01-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.221.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.220.0...v1.221.0) (2026-01-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.219.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.219.5...v1.219.6) (2026-01-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.219.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.219.3...v1.219.4) (2026-01-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.219.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.219.2...v1.219.3) (2026-01-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.219.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.219.1...v1.219.2) (2025-12-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.219.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.219.0...v1.219.1) (2025-12-19)

### 💥 Bug Fixes

- add back deleted files | ART-88711 ([9b541f6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9b541f66f1babf412fa5f9f318b3533504b1ee0e))

## [1.219.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.218.0...v1.219.0) (2025-12-19)

### 🚀 Features

- add mv-crypto package, add enrpytion function | ART-84491 ([70955e7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/70955e7f67f3c27899f0ed6482b9752e12b0dc0e))

### 💥 Bug Fixes

- remove mv-crypto declerations from library package | ART-84491 ([912b42a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/912b42a88956e30eed72f452535b954eb80944d3))

## [1.216.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.215.1...v1.216.0) (2025-12-15)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.215.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.215.0...v1.215.1) (2025-12-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.215.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.214.0...v1.215.0) (2025-12-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.214.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.213.0...v1.214.0) (2025-12-09)

### 🚀 Features

- secondary label for accrued interest labels | ART-87937 ([ef81f49](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ef81f49dd812a3be332dafeba94a6600bca3303f))

## [1.213.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.212.0...v1.213.0) (2025-12-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.211.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.210.3...v1.211.0) (2025-11-25)

### 🚀 Features

- update MVRefresh to handle last successfule date and time display | ART-66871 ([501aa4b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/501aa4becb523e728ef0fd91b0f09cbb3a9ae440))

## [1.210.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.210.2...v1.210.3) (2025-11-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.210.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.210.1...v1.210.2) (2025-11-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.210.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.209.2...v1.210.0) (2025-11-13)

### 🚀 Features

- add onChange prop to MVSelectController for handling selection change | ART-70047 ([a72dbc0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a72dbc054f80092129fbefd149dc04ba34fbcc93))

## [1.209.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.209.1...v1.209.2) (2025-11-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.209.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.209.0...v1.209.1) (2025-11-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.209.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.208.0...v1.209.0) (2025-11-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.208.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.207.0...v1.208.0) (2025-10-31)

### 🚀 Features

- **ART-66800:** double spacing for FormattedForbiddenCharacters string ([48aec98](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/48aec98190d734dede5ea2b836bad5bc59a70305))
- **ART-66800:** update comment and test case ([2ddd759](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2ddd75918118599afdc9a76fb724c2c995a8a8e4))

## [1.207.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.206.0...v1.207.0) (2025-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.206.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.205.7...v1.206.0) (2025-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.205.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.205.6...v1.205.7) (2025-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.205.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.205.5...v1.205.6) (2025-10-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.205.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.205.3...v1.205.4) (2025-10-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.205.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.205.2...v1.205.3) (2025-10-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.205.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.204.0...v1.205.0) (2025-10-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.204.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.203.0...v1.204.0) (2025-10-26)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.203.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.202.0...v1.203.0) (2025-10-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.202.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.201.2...v1.202.0) (2025-10-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.201.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.201.1...v1.201.2) (2025-10-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.201.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.201.0...v1.201.1) (2025-10-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.201.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.200.2...v1.201.0) (2025-10-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.200.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.200.1...v1.200.2) (2025-10-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.198.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.197.0...v1.198.0) (2025-10-20)

### 🚀 Features

- Adding new package MVCollapsiblePanel | ART-82161 ([c700b14](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c700b144d7c11e0f476c2f652445ab75471040e3))
- removed collapsible panel comp from library | ART-82161 ([c7e4e8c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c7e4e8cc8330d38718173a2646dfbb2127433f36))
- removed the unnecessary dependency | ART-82161 ([54221eb](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/54221eb3b6fceb89ebc96c25bce47f9afd060026))
- updated according to review comments | ART-82161 ([477701b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/477701b664b4a528812cdfb351130bfa3f797197))

## [1.197.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.196.1...v1.197.0) (2025-10-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.196.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.196.0...v1.196.1) (2025-10-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.195.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.194.0...v1.195.0) (2025-10-15)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.194.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.193.1...v1.194.0) (2025-10-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.193.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.193.0...v1.193.1) (2025-10-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.192.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.192.1...v1.192.2) (2025-10-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.192.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.192.0...v1.192.1) (2025-10-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.192.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.191.1...v1.192.0) (2025-10-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.191.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.191.0...v1.191.1) (2025-10-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.191.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.190.0...v1.191.0) (2025-10-09)

### 🚀 Features

- removing from library | ART-79216 ([3f4cf25](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3f4cf251a4da7267b5ee02bccecade7049479955))

## [1.190.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.189.0...v1.190.0) (2025-10-09)

### 🚀 Features

- adding new filter accordion package | ART-79216 ([3d1e13f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3d1e13fd30246a3611958c3dcabf8456fa12ed85))
- cleaned up filter accordion references | ART-79216 ([931f98a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/931f98a3c607396fd3f301e3fb03d9b9547fec34))

## [1.188.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.187.0...v1.188.0) (2025-10-07)

### 🚀 Features

- added type defs and updated readme file | ART-70475 ([85d3221](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/85d32219fee299f8148d66c497c979624cfdaead))

## [1.187.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.186.5...v1.187.0) (2025-10-07)

### 🚀 Features

- add mv-apibeneficiarycreate package with modern controller architecture ([b1e5f99](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b1e5f990c6f69452677e23002ed2d04b3fd35c43))

## [1.186.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.186.4...v1.186.5) (2025-10-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.186.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.186.3...v1.186.4) (2025-10-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.186.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.186.2...v1.186.3) (2025-10-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.186.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.186.1...v1.186.2) (2025-10-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.186.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.185.2...v1.186.0) (2025-10-02)

### 🚀 Features

- add viewOptions in handleRaiseIntentParams | ART-76456 ([4b08072](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4b080725d9e6cfacac6b1e7deea1e62c7144f366))
- add windowtabkey | ART-76456 ([4a4cb0e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4a4cb0e522e408bd887c9193665b6fb0f560793f))

## [1.185.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.185.0...v1.185.1) (2025-10-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.184.9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.8...v1.184.9) (2025-09-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.184.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.6...v1.184.7) (2025-09-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.184.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.4...v1.184.5) (2025-09-26)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.184.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.3...v1.184.4) (2025-09-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.184.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.2...v1.184.3) (2025-09-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.184.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.1...v1.184.2) (2025-09-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.184.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.184.0...v1.184.1) (2025-09-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.184.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.183.0...v1.184.0) (2025-09-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.182.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.182.6...v1.182.7) (2025-09-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.182.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.182.5...v1.182.6) (2025-09-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.182.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.182.4...v1.182.5) (2025-09-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.182.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.182.3...v1.182.4) (2025-09-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.182.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.182.2...v1.182.3) (2025-09-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.182.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.182.1...v1.182.2) (2025-09-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.182.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.182.0...v1.182.1) (2025-09-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.181.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.181.2...v1.181.3) (2025-09-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.181.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.181.0...v1.181.1) (2025-09-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.181.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.180.1...v1.181.0) (2025-09-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.180.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.180.0...v1.180.1) (2025-09-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.180.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.179.3...v1.180.0) (2025-09-02)

### 🚀 Features

- update version in lib package ([dc85874](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/dc85874bdd1ee1a97866afae29fb0f267721df9f))

## [1.179.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.179.2...v1.179.3) (2025-09-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.179.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.179.1...v1.179.2) (2025-09-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.179.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.179.0...v1.179.1) (2025-09-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.179.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.12...v1.179.0) (2025-09-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.178.12](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.11...v1.178.12) (2025-08-20)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.178.11](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.10...v1.178.11) (2025-08-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.178.10](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.9...v1.178.10) (2025-08-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.178.9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.8...v1.178.9) (2025-08-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.178.8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.7...v1.178.8) (2025-08-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.178.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.6...v1.178.7) (2025-08-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.178.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.5...v1.178.6) (2025-08-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.178.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.4...v1.178.5) (2025-08-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.178.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.3...v1.178.4) (2025-08-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.178.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.2...v1.178.3) (2025-08-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.178.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.1...v1.178.2) (2025-08-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.178.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.178.0...v1.178.1) (2025-08-12)

### 💥 Bug Fixes

- wibdtw1-2203 remove open option and change types ([908b251](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/908b2513f94adbe8cefdef5e5d2cb885f8bf306f))

## [1.178.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.177.2...v1.178.0) (2025-08-11)

### 🚀 Features

- add bottompadding prop | ART-61028 ([9c4b210](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9c4b2102eadd944f41488807fd15fd13838bc1ec))

## [1.177.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.177.1...v1.177.2) (2025-08-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.177.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.177.0...v1.177.1) (2025-08-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.177.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.176.0...v1.177.0) (2025-08-11)

### 🚀 Features

- make second autocomplete item optional | ART-68405 ([99357e5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/99357e53185115f632ca08ffe8d6e53f25dc520c))
- make third autocomplete item optional | ART-68405 ([360a456](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/360a4567c32d77a0367ccbd447866b6e50ca4792))

## [1.176.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.175.0...v1.176.0) (2025-08-08)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.175.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.174.1...v1.175.0) (2025-08-08)

### 🚀 Features

- wibdtw1-2203 add correct imports ([bcf1cf6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/bcf1cf6404046cbd2aad8d5983e93fb2bd8add34))
- wibdtw1-2203 add types to library ([9ef9e57](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9ef9e57dd9fe9647d1b0e2548bba5bfe604338cf))

## [1.174.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.174.0...v1.174.1) (2025-08-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.173.8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.7...v1.173.8) (2025-08-06)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.173.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.6...v1.173.7) (2025-08-06)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.173.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.5...v1.173.6) (2025-08-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.173.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.4...v1.173.5) (2025-08-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.173.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.3...v1.173.4) (2025-08-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.173.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.2...v1.173.3) (2025-08-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.173.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.1...v1.173.2) (2025-08-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.173.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.173.0...v1.173.1) (2025-07-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.173.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.172.2...v1.173.0) (2025-07-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.172.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.172.1...v1.172.2) (2025-07-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.172.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.172.0...v1.172.1) (2025-07-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.172.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.171.8...v1.172.0) (2025-07-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.171.8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.171.7...v1.171.8) (2025-07-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.171.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.171.4...v1.171.5) (2025-07-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.171.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.171.2...v1.171.3) (2025-07-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.171.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.171.1...v1.171.2) (2025-07-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.171.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.171.0...v1.171.1) (2025-07-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.171.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.170.1...v1.171.0) (2025-07-21)

### 🚀 Features

- created getAppUrlWithoutParams() for entitlement error nav | ART-68385 ([e37532c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e37532cc349eb31f38e4752d8c67ef81d4564392))

## [1.170.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.167.2...v1.170.1) (2025-07-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.167.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.166.1...v1.167.0) (2025-07-18)

### 🚀 Features

- wibdtw1-1879 adds missing prop ([b0d3580](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b0d3580a4b50e4c1430716b0b9aef86f14fbe02a))

## [1.166.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.166.0...v1.166.1) (2025-07-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.166.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.165.0...v1.166.0) (2025-07-18)

### 🚀 Features

- wibdtw1-1879 changes to props and stories ([61db31d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/61db31d44fd460316ec621361d16540f5a12bc09))

## [1.165.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.164.0...v1.165.0) (2025-07-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.164.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.163.1...v1.164.0) (2025-07-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.163.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.163.0...v1.163.1) (2025-07-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.163.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.162.0...v1.163.0) (2025-07-17)

### 🚀 Features

- add dateRangeString() ([0d30598](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0d30598ac833493f4954b2d886769e5bedbae59c))

## [1.162.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.161.1...v1.162.0) (2025-07-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.161.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.161.0...v1.161.1) (2025-07-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.161.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.160.4...v1.161.0) (2025-07-14)

### 🚀 Features

- updated MVPageLoader | WIBDTW1-2513 ([d91ad71](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d91ad710843e9ac8bfd94bec81130612f5a0e953))

## [1.160.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.160.2...v1.160.3) (2025-07-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.160.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.160.1...v1.160.2) (2025-07-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.160.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.160.0...v1.160.1) (2025-07-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.160.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.159.0...v1.160.0) (2025-07-11)

### 💥 Bug Fixes

- format forbidden characters | ART-54463 ([4198743](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4198743217a582e7798081372104b7c9c062daa4))

## [1.159.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.158.0...v1.159.0) (2025-07-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.158.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.157.0...v1.158.0) (2025-07-09)

### 🚀 Features

- add isStatic and tableHeight params to be more readable | ART-54678 ([03de91f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/03de91f8fbe31b819018de89581e39b08fd1ad8d))

## [1.157.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.156.2...v1.157.0) (2025-07-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.156.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.156.1...v1.156.2) (2025-07-08)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.156.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.156.0...v1.156.1) (2025-07-08)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.156.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.155.0...v1.156.0) (2025-07-07)

### 🚀 Features

- added react import and use this to replace params | ART-66589 ([5f8468b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5f8468b67d45cf7e29eb0b2a62367b522bd01814))

## [1.155.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.154.0...v1.155.0) (2025-07-07)

### 🚀 Features

- implement the loading field from openFin hook | ART-66589 ([c17bc1b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c17bc1b8c2808ce8183abfc1d60a109b5ebae6e5))

## [1.154.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.153.0...v1.154.0) (2025-07-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.153.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.152.0...v1.153.0) (2025-07-03)

### 🚀 Features

- add 'system' type to MVAlertType for enhanced alert categorization ([8e06b93](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8e06b9393bf92380b4fef75451718bda9413d3a5))
- add MVAlert component with customizable properties and update README ([0800937](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/08009375c93c1f9bfb57f42a946ae259cdd9be86))
- field validations august uplift swagger and library changes | ART-54463 ([d9c00c5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d9c00c54fdb9620a5863e62194bdbf1c53d08b3f))
- updated heading props in libraries ([af26870](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/af26870f3205ae5509e25d9ef7f7e98b5bc5a0f6))

## [1.152.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.151.3...v1.152.0) (2025-07-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.151.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.151.2...v1.151.3) (2025-07-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.151.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.151.1...v1.151.2) (2025-07-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.151.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.151.0...v1.151.1) (2025-07-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.150.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.150.0...v1.150.1) (2025-06-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.150.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.149.0...v1.150.0) (2025-06-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.149.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.148.0...v1.149.0) (2025-06-26)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.148.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.147.2...v1.148.0) (2025-06-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.147.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.147.1...v1.147.2) (2025-06-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.147.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.147.0...v1.147.1) (2025-06-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.147.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.146.0...v1.147.0) (2025-06-16)

### 🚀 Features

- evaluating perfectexpressSanitizer on-payment details page ui | ART-49958 ([64859ca](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/64859ca948435f2ea6f2b2910d37426ae17cb019))

## [1.144.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.143.0...v1.144.0) (2025-06-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.143.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.142.0...v1.143.0) (2025-06-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.141.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.140.0...v1.141.0) (2025-06-06)

### 🚀 Features

- extend perfectexpresssanitizer to handle template injection | ART-54837 ([c422b02](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c422b02ed5cde5c4ab19021b3cdd2cc458531183))

## [1.140.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.139.1...v1.140.0) (2025-06-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.139.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.139.0...v1.139.1) (2025-06-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.138.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.138.1...v1.138.2) (2025-06-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.138.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.138.0...v1.138.1) (2025-06-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.138.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.137.3...v1.138.0) (2025-05-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.137.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.137.2...v1.137.3) (2025-05-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.137.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.137.0...v1.137.1) (2025-05-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.137.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.136.0...v1.137.0) (2025-05-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.135.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.134.1...v1.135.0) (2025-05-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.130.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.129.0...v1.130.0) (2025-05-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.129.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.128.0...v1.129.0) (2025-05-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.128.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.127.0...v1.128.0) (2025-05-14)

### 🚀 Features

- update useAutocompleteWrapper ([014726b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/014726b3f2db40f554cb86d76f973a7ce594879b))
- update useAutocompleteWrapper ([87595c8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/87595c884484cc0cbc20bbe85ad5fcdac58ad52c))

## [1.127.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.126.0...v1.127.0) (2025-05-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.126.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.125.0...v1.126.0) (2025-05-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.125.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.124.0...v1.125.0) (2025-05-09)

### 🚀 Features

- added new package notificationalert | ART-41399 ([6518b65](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6518b65395584fefbc5c735f3662c40585ec42bf))
- revering the raiseIntent changes in index.d.ts | ART-41399 ([6c2ecd9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6c2ecd9a168eab4886dc3013974caffe395d4f54))

## [1.124.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.123.0...v1.124.0) (2025-05-08)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.123.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.122.0...v1.123.0) (2025-05-08)

### 🚀 Features

- add the intentId definition | ART-52229 ([b8c64f3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b8c64f362c8c38dd36d4c82203c803c6bdd81689))

## [1.122.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.121.0...v1.122.0) (2025-05-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.121.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.120.0...v1.121.0) (2025-05-07)

### 🚀 Features

- update table with GridApi | ART-46688 ([f9fddcf](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f9fddcf903cf154bec08e266cbed9388ca3bc8ae))

## [1.120.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.119.0...v1.120.0) (2025-05-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.117.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.117.0...v1.117.1) (2025-05-06)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.117.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.116.7...v1.117.0) (2025-05-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.116.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.116.6...v1.116.7) (2025-04-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.116.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.116.5...v1.116.6) (2025-04-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.116.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.116.1...v1.116.2) (2025-04-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.116.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.116.0...v1.116.1) (2025-04-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.116.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.115.0...v1.116.0) (2025-04-24)

### 💥 Bug Fixes

- added back submittedDate and receiptNumber in coldefs for backwards compatibility | ART-53469 ([4c6cdb7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4c6cdb7016b14fc9c9410932be592436a4c015ea))

## [1.112.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.112.1...v1.112.2) (2025-04-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.112.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.112.0...v1.112.1) (2025-04-17)

### 💥 Bug Fixes

- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([01274a7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/01274a78bf92a29c2cdd4ab19d2c04ed21ff65ed))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([c50efa5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c50efa5f84b71f01b1b11e3ec1a90a8bc715b3e3))

## [1.111.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.110.1...v1.111.0) (2025-04-16)

### 🚀 Features

- updated column definitions in mv table | ART-46683 ([c327218](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c327218f23ec8650ad537c28bc761a062ace9d9d))

## [1.110.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.110.0...v1.110.1) (2025-04-15)

### 💥 Bug Fixes

- changed param name | ART-52269 ([4f21cc6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4f21cc6d3f017ff55fd650c1f559d18fa33f0539))

## [1.110.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.109.1...v1.110.0) (2025-04-15)

### 🚀 Features

- updated package & index.ts files in library ([311a690](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/311a690506177ebcb97bbeda1af8522a990ffe1b))

## [1.109.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.109.0...v1.109.1) (2025-04-15)

### 💥 Bug Fixes

- moved spinner into MVSelector | ART-52269 ([09763bc](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/09763bca7d3a7477f241ab826f5caccc1530e180))

## [1.109.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.108.1...v1.109.0) (2025-04-15)

### 🚀 Features

- update MVRefreshHandle to accept optional parameter | ART-16297 ([cd60572](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cd6057248e4f2775a37bd8c76cd89e3394327034))

## [1.108.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.107.0...v1.108.0) (2025-04-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.107.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.106.1...v1.107.0) (2025-04-11)

### 🚀 Features

- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([f6f5685](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f6f5685090a5a821f399c04eac38d452224d13bc))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([594177d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/594177d636efb09433616fb547bd15943b45cd7b))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([c525d07](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c525d07adf5b1fa897de0c2cb672640808f0d1f6))

## [1.106.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.106.0...v1.106.1) (2025-04-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.106.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.105.0...v1.106.0) (2025-04-10)

### 🚀 Features

- add blur validation and isInvalid logic | ART-41745 ([c9c3c86](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c9c3c86bc61978006f3fbbb558c56a4edb4b891d))
- update type definition | ART-41745 ([29faf01](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/29faf016f5c594ec757094f40ec3beeb1c25165f))
- update type definitions | ART-41745 ([363f356](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/363f3560cce68d898781c3d1b68c440939e888e0))

## [1.105.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.104.0...v1.105.0) (2025-04-10)

### 🚀 Features

- ART-41757 delete minItemsForFooter ([61f10de](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/61f10de95ad6a692a8068657c0e20a16cff476a6))

## [1.104.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.103.1...v1.104.0) (2025-04-07)

### 🚀 Features

- added export csv functionality for MVTableV2 | ART - 41541 ([9f2a257](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9f2a25728fdfdb2b0ab0336ae134d590671b2965))
- added forwardRef for MVTable | ART - 41541 ([52da884](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/52da884fd796b3797e5f7ca6fab85ab91722ba76))

## [1.103.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.102.2...v1.103.0) (2025-04-07)

### 🚀 Features

- ART-41757 add inputValueFn ([37c4862](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/37c4862a2187f26887dfa0e105041cceda0145cb))

## [1.102.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.102.1...v1.102.2) (2025-04-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.102.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.102.0...v1.102.1) (2025-04-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.102.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.101.0...v1.102.0) (2025-04-03)

### 🚀 Features

- ART-41757 remove defaultProps ([be8ed20](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/be8ed2094d48a77ecf123727c74aad6ca36eba20))
- ART-41757 update MVAccountAdditionalDetails ([f17e59c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f17e59c6b3da31b70b41bdf00eff67a6cea3e93b))
- ART-41757 update MVAccountAdditionalDetails ([a26f6ab](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a26f6abef52cf0fc0e8889e53100d3a7a11888c7))

## [1.101.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.100.0...v1.101.0) (2025-04-02)

### 🚀 Features

- add comments | ART-39684 ([d664292](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d664292b20d86feefc1cf20842a049053aaf36d5))
- refactor | ART-39684 ([ea877d5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ea877d5d20a6883f8e47321d647266c99b91b36f))

## [1.100.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.99.0...v1.100.0) (2025-04-02)

### 🚀 Features

- ART-41757 add MVAccountAdditionalDetails ([56f461e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/56f461ecb0a3bf07daeca6127472dc927c7bdb80))

## [1.99.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.98.0...v1.99.0) (2025-04-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.98.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.97.2...v1.98.0) (2025-04-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.97.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.97.1...v1.97.2) (2025-04-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.97.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.97.0...v1.97.1) (2025-04-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.97.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.96.3...v1.97.0) (2025-04-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.96.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.96.2...v1.96.3) (2025-04-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.96.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.96.1...v1.96.2) (2025-04-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.96.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.95.1...v1.96.0) (2025-03-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.95.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.95.0...v1.95.1) (2025-03-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.95.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.94.0...v1.95.0) (2025-03-28)

### 🚀 Features

- updated statement table data variable | ART-45838 ([8fe5399](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8fe5399adcf8d37d0bec32c4bec51b507b6245eb))

## [1.94.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.93.0...v1.94.0) (2025-03-26)

### 🚀 Features

- ART-41757 update onChange ([fcd771e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fcd771ecd2aee07215496a3b31c53686e748f008))

## [1.93.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.92.0...v1.93.0) (2025-03-26)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.92.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.91.0...v1.92.0) (2025-03-25)

### 🚀 Features

- ART-41757 add onChange ([fcbc770](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/fcbc770c3bf5645fc559d1f99d97d2bd0faaeb28))

## [1.91.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.90.0...v1.91.0) (2025-03-25)

### 🚀 Features

- ART-41757 add onChange and pattern for MVInputController ([4649da6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4649da6a76bf39ae0300690d3482b4ec20026787))
- ART-41757 rename ([a9fe932](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a9fe932446831ebe6ed6ff47bd515a7a5092b4df))

## [1.90.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.89.0...v1.90.0) (2025-03-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.89.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.88.0...v1.89.0) (2025-03-24)

### 🚀 Features

- ART-44081-update AutocompleteItemDetailsTemplate ([b06e44a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b06e44aa31c08c200a36971b07f70612555db308))

## [1.88.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.87.0...v1.88.0) (2025-03-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.87.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.86.0...v1.87.0) (2025-03-20)

### 🚀 Features

- ART-41757- delete DefaultAdditionalDetails.tsx ([b55036d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b55036df308551e745b93197c29525bf11979f1d))

## [1.86.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.85.0...v1.86.0) (2025-03-20)

### 🚀 Features

- ART-41757- add filterFn ([c94e6bb](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c94e6bbc5b803b07e68c9e0c49fffc4c312d21df))

## [1.85.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.84.0...v1.85.0) (2025-03-20)

### 🚀 Features

- remove dropdown placeholder | ART-38630 ([ccc739b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ccc739b42b0c4ddc9a35f479cd556614cfb37edc))

## [1.84.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.83.0...v1.84.0) (2025-03-19)

### 🚀 Features

- added supporting text to bottom of select element so you can style it to match width of select ([031dc90](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/031dc901926540feb3b2113becbeb9ba6e6f5b1b))

## [1.83.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.82.0...v1.83.0) (2025-03-19)

### 🚀 Features

- begin dropdown menu implementation for MVCard | ART-38630 ([cbd5905](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cbd590504e9fd0ac6e5d21caa5c5b9f252545e1f))

## [1.82.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.81.1...v1.82.0) (2025-03-19)

### 🚀 Features

- added validation pattern for payment and transfer description fields ([2bf5fca](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2bf5fca2f2784fb8e05ed615f832688c9e75da43))

## [1.81.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.80.5...v1.81.0) (2025-03-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.80.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.80.4...v1.80.5) (2025-03-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.80.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.80.3...v1.80.4) (2025-03-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.80.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.80.2...v1.80.3) (2025-03-14)

### 💥 Bug Fixes

- update types | ART-44036 ([6d3203e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6d3203e113f63be62dfd80444b37c68bcc75b579))
- update types | ART-44036 ([10be64a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/10be64a435b78495eaf430ffce137ee26e0b6483))

## [1.80.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.80.1...v1.80.2) (2025-03-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.80.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.80.0...v1.80.1) (2025-03-13)

### 💥 Bug Fixes

- add constants file to index file export list | ART-43809 ([b61ea77](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b61ea77e6a0bac085184e8b2569f0301364e2373))

## [1.80.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.79.0...v1.80.0) (2025-03-13)

### 🚀 Features

- importing Pdp query actions from entitlement lib ([8044bec](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8044becb353e46cf9183b3637fb3aeebae04a924))

## [1.79.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.78.0...v1.79.0) (2025-03-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.78.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.77.0...v1.78.0) (2025-03-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.77.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.76.0...v1.77.0) (2025-03-13)

### 🚀 Features

- ART-44985 add onBlur ([dce663d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/dce663dc588497b4ff93045b97f9a42e9f5238de))
- ART-44985 add MVPhoneInputController ([92c148e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/92c148e3d538591d0f9dcc038ea8fd8aebafdccd))
- ART-44985 update index.d.ts ([579c921](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/579c9215c2fa5066c01c00bc7df8f04701b737bd))

## [1.76.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.75.1...v1.76.0) (2025-03-12)

### 🚀 Features

- create text sanitizer function | ART-43809 ([be543c5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/be543c53039030a0df4e2c079de959fb4ac8d35e))
- create text sanitizer function | ART-43809 ([3c6ba67](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3c6ba67c041fc4e738bf6c7596b758e4e6d3ec0d))
- create text sanitizer function | ART-43809 ([0447515](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/04475150150bd46f57ea3f30ec22c1c8085a2233))

## [1.75.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.75.0...v1.75.1) (2025-03-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.75.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.74.3...v1.75.0) (2025-03-11)

### 🚀 Features

- ART-39683 update MVInputController ([f56504c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f56504c56a50d4da950c21554a1bbcc623f2c40e))

## [1.74.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.74.2...v1.74.3) (2025-03-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.74.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.74.1...v1.74.2) (2025-03-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.74.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.74.0...v1.74.1) (2025-03-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.74.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.73.0...v1.74.0) (2025-03-10)

### 🚀 Features

- export tranformPdpResponse in library src/ index.d.ts JIRA:ART-36101 ([370b802](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/370b802527fbd5c08c1a47a385a466e79cda3aeb))

## [1.73.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.72.1...v1.73.0) (2025-03-10)

### 🚀 Features

- ART-41575 AutocompleteItemDetailsTemplate ([25f481d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/25f481d042fd66accdbd35f109fa724158b14d2b))
- ART-41575 remove undefined for AdditionalDetails ([a8f856a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a8f856a6e1acfbf7cb211af3e3a3bca7201bef50))
- ART-41575 update autocomplete ([f6f3d45](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f6f3d45f1bf03a34271cdd8e241633a0e4d85666))

## [1.72.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.72.0...v1.72.1) (2025-03-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.72.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.71.3...v1.72.0) (2025-03-10)

### 🚀 Features

- added enum in index.d.js ([ab09c29](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ab09c2986bfb94078bec0ecbd62620d9d659c770))
- added transformPdpResponse util function with unit tests: JIRA: ART-36101 ([b4c1698](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b4c1698d03c656246be0e2ce59af030fe4ad7458))

## [1.71.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.71.2...v1.71.3) (2025-03-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.71.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.71.1...v1.71.2) (2025-03-06)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.71.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.71.0...v1.71.1) (2025-03-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.71.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.70.0...v1.71.0) (2025-03-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.70.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.69.4...v1.70.0) (2025-03-04)

### 🚀 Features

- ART-41757 update date range picker ([1ac27b5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1ac27b5575f421311d38bea922d7943f4323ee82))
- ART-41757 update date range picker type definition ([0c58883](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0c58883435564bef12d5a751b2e3f36f364621f2))

## [1.69.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.69.3...v1.69.4) (2025-03-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.69.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.69.2...v1.69.3) (2025-03-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.69.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.69.0...v1.69.1) (2025-02-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.69.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.68.0...v1.69.0) (2025-02-28)

### 🚀 Features

- added types in library/src and mv-utils/src JIRA: ART-41647 ([02647dd](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/02647dd0b74088f686756734723489675241fcef))

## [1.68.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.67.0...v1.68.0) (2025-02-26)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.67.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.66.3...v1.67.0) (2025-02-26)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.66.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.66.2...v1.66.3) (2025-02-26)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.66.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.66.1...v1.66.2) (2025-02-26)

### 💥 Bug Fixes

- added type definitions | ART-42495 ([5af680f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5af680f26a00a4540ef2beafcf60d285d942848b))

## [1.66.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.66.0...v1.66.1) (2025-02-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.66.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.65.0...v1.66.0) (2025-02-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.65.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.64.1...v1.65.0) (2025-02-25)

### 🚀 Features

- implement MVAutocompleteController | ART-41757 ([5f01742](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5f01742c2adbd9dca9373febb8a3be81fe9cbb18))
- use autocomplete-wrapper.css | ART-41757 ([600f3d9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/600f3d9abd23859c2ba1b1d701c5aa29ee9cce6f))

## [1.64.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.64.0...v1.64.1) (2025-02-24)

### 💥 Bug Fixes

- added placeholder prop in mvselect | ART-39584 ([85e2504](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/85e250419da5cc83417e5254aa642dfd9a3ac66e))

## [1.63.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.62.1...v1.63.0) (2025-02-21)

### 🚀 Features

- remove redundant code | ART-36119 ([e079372](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e079372d449453d0194034d23dfafa5277735ed0))

## [1.62.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.62.0...v1.62.1) (2025-02-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.62.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.61.0...v1.62.0) (2025-02-20)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.61.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.60.3...v1.61.0) (2025-02-19)

### 🚀 Features

- use westpacui v0.41 | ART-39719 ([a346407](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a34640799d98e5c4ceb0e7b21aa262d5745ec133))

## [1.60.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.60.2...v1.60.3) (2025-02-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.60.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.60.1...v1.60.2) (2025-02-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.60.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.60.0...v1.60.1) (2025-02-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.60.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.59.0...v1.60.0) (2025-02-13)

### 🚀 Features

- dateRange formatter | ART-27663 ([648c091](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/648c091d40666b8718d0fa40f486cc0fcffdc238))

## [1.59.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.58.3...v1.59.0) (2025-02-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.58.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.58.2...v1.58.3) (2025-02-11)

### 💥 Bug Fixes

- add type def to library file | ART-29898 ([887d1b7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/887d1b763cb018856c2cd72c1c052aed25378434))

## [1.58.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.58.1...v1.58.2) (2025-02-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.58.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.58.0...v1.58.1) (2025-02-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.58.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.57.0...v1.58.0) (2025-02-09)

### 🚀 Features

- changes in MVSearchInputController to pass onChange value | ART-27663 ([659a13a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/659a13abb743509fdc2d1275c160480753f49f80))

## [1.57.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.56.0...v1.57.0) (2025-02-06)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.56.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.55.5...v1.56.0) (2025-02-05)

### 🚀 Features

- recommit changes using latest version | ART-36119 ([72c1413](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/72c14135fbba3bce83450ab127692490b7e71263))

## [1.55.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.55.4...v1.55.5) (2025-02-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.55.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.55.3...v1.55.4) (2025-02-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.55.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.55.2...v1.55.3) (2025-02-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.55.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.55.1...v1.55.2) (2025-02-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.55.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.55.0...v1.55.1) (2025-02-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.55.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.54.0...v1.55.0) (2025-02-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.54.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.53.4...v1.54.0) (2025-01-31)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.53.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.53.3...v1.53.4) (2025-01-31)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.53.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.53.2...v1.53.3) (2025-01-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.53.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.53.1...v1.53.2) (2025-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.53.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.53.0...v1.53.1) (2025-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.53.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.52.0...v1.53.0) (2025-01-29)

### 🚀 Features

- update The hover banner doesn't appear | ART-38995 ([6d5871b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6d5871ba40f3fecf331bca91d0a0d9bff8508f55))

## [1.52.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.51.1...v1.52.0) (2025-01-28)

### 🚀 Features

- update The hover banner doesn't appear update the lookup issue | ART-38995 ([1cf9550](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1cf95508c862c28190e8f5f62006ac1d222e60da))

## [1.51.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.51.0...v1.51.1) (2025-01-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.51.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.50.0...v1.51.0) (2025-01-27)

### 🚀 Features

- update The hover banner doesn't appear | ART-38995 ([6fb8c3e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6fb8c3e34673bb2d6e604518ead7c53f096ea13a))

## [1.50.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.49.7...v1.50.0) (2025-01-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.49.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.49.5...v1.49.6) (2025-01-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.49.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.49.4...v1.49.5) (2025-01-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.49.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.49.2...v1.49.3) (2025-01-23)

### 💥 Bug Fixes

- add-manage-account-name-action-to-library-export | ART-37763 ([6e24f4a](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6e24f4aa0d67ae6165c9aa23fdb7a9fa0a8f30ba))

## [1.49.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.49.1...v1.49.2) (2025-01-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.49.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.48.3...v1.49.0) (2025-01-21)

### 🚀 Features

- update format-bsb util function | ART-15927 ([3eaaca0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3eaaca0703830fb94583bee7392e8c264c04006d))

## [1.48.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.48.2...v1.48.3) (2025-01-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.48.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.48.1...v1.48.2) (2025-01-20)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.48.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.47.2...v1.48.0) (2025-01-20)

### 🚀 Features

- add util function to format bsb from account no | ART-15508 ([c070a66](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c070a663bec35da2bc482556360ef34bb50e2eca))

## [1.47.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.47.1...v1.47.2) (2025-01-20)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.47.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.47.0...v1.47.1) (2025-01-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.47.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.46.2...v1.47.0) (2025-01-16)

### 🚀 Features

- mvSearchInputController updation | ART-28182 ([e03ffd7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/e03ffd7e608cf49b852829191c5321aca1b13af1))
- searchInputController | ART-28182 ([3cb1781](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3cb1781b2278565c9ca5a0358b854ede11cdf85d))
- searchInputController updation to export | ART-28182 ([8d06fa9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8d06fa9245100c68be1bcf6a56ef00c93aceea3d))

## [1.46.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.46.1...v1.46.2) (2025-01-16)

### 💥 Bug Fixes

- fix entitlement constant types | ART-36119 ([f556dea](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f556dea8bd9c247bbffcaf60ca0280cb252ad3ff))

## [1.46.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.45.2...v1.46.0) (2025-01-15)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.45.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.45.1...v1.45.2) (2025-01-15)

### 💥 Bug Fixes

- remove date-rangepicker refernce to fix errors in MFE | ART-28182 ([92328c9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/92328c96b498d1c466ddfa90cd4aaab7248f90f1))

## [1.45.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.45.0...v1.45.1) (2025-01-15)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.45.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.44.1...v1.45.0) (2025-01-15)

### 🚀 Features

- added BSB formatter utility function | ART-28182 ([b7fdb74](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b7fdb745f8871612510803c3bce9ab0476c84252))

## [1.44.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.44.0...v1.44.1) (2025-01-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.44.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.43.0...v1.44.0) (2025-01-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.43.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.42.1...v1.43.0) (2025-01-09)

### 🚀 Features

- create MVDateRangePicker | ART-31841 ([1fa8399](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1fa83994e15d5da29d209be6ba3261c9a7151dab))

## [1.42.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.42.0...v1.42.1) (2025-01-08)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.42.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.41.0...v1.42.0) (2024-12-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.41.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.40.2...v1.41.0) (2024-12-20)

### 🚀 Features

- return-isUserAuthorised function | ART-30219 ([5661ed0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5661ed0567d439a7fddba259103c85540d7dee3b))

## [1.40.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.40.1...v1.40.2) (2024-12-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.40.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.40.0...v1.40.1) (2024-12-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.40.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.39.5...v1.40.0) (2024-12-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.39.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.39.4...v1.39.5) (2024-12-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.39.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.39.3...v1.39.4) (2024-12-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.39.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.39.2...v1.39.3) (2024-12-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.39.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.39.1...v1.39.2) (2024-12-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.39.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.39.0...v1.39.1) (2024-12-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.39.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.38.0...v1.39.0) (2024-12-15)

### 🚀 Features

- added MVAccountSummary prop in lib | ART-14509 ([48d417d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/48d417d71853536fbe89d36d72ed1d07e5a6f9c0))

## [1.38.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.37.0...v1.38.0) (2024-12-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.37.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.36.0...v1.37.0) (2024-12-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.36.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.35.0...v1.36.0) (2024-12-12)

### 🚀 Features

- maccountsummary status prop added | ART-14496 ([3ed3116](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3ed3116be401823b15ac1ca12148d1948b449dda))
- merge conflicts resolved | ART-14496 ([700d2d8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/700d2d8bf9a0af89538380dfb53096d7210e3143))

## [1.35.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.10...v1.35.0) (2024-12-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.34.10](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.9...v1.34.10) (2024-12-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.34.9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.8...v1.34.9) (2024-12-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.34.8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.7...v1.34.8) (2024-12-11)

### 💥 Bug Fixes

- update MVIcon props and add PayTo logo | ART-15769 ([ed08a6e](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/ed08a6ec1c96c8233cec0d4d1e66fbb0572fe670))

## [1.34.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.6...v1.34.7) (2024-12-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.34.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.5...v1.34.6) (2024-12-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.34.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.4...v1.34.5) (2024-12-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.34.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.3...v1.34.4) (2024-12-08)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.34.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.2...v1.34.3) (2024-12-06)

### 💥 Bug Fixes

- conditionally display the time zone JIRA: ART-31648 ([856b412](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/856b412a68774d973e0b7caa38e23cd7851c182f))

## [1.34.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.1...v1.34.2) (2024-12-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.34.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.34.0...v1.34.1) (2024-12-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.34.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.33.3...v1.34.0) (2024-12-03)

### 🚀 Features

- created account summary component ([adad89f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/adad89f6641e26010ab9221447fcb98facb25bd6))
- updated code to follow best practice ([b22961c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b22961c892a6d68db3e30ba6ac399be11eec3350))

## [1.33.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.33.2...v1.33.3) (2024-12-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.33.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.33.1...v1.33.2) (2024-11-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.33.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.33.0...v1.33.1) (2024-11-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.33.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.32.1...v1.33.0) (2024-11-28)

### 🚀 Features

- add 2 more format helper functions JIRA: ART-14311 ([7a0019b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7a0019ba0fc7f5143f1729eb3e5307ef2319f6a1))

## [1.32.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.32.0...v1.32.1) (2024-11-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.32.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.31.1...v1.32.0) (2024-11-26)

### 🚀 Features

- refactor mv-account-formatter ([4593d95](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4593d956ef9c11b50d5633ecbefde9ed1989afee))
- refactor mv-account-formatter ([3911025](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/39110254bf2bf4a5c5784fdd4dd0d2908433799a))

## [1.31.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.31.0...v1.31.1) (2024-11-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.31.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.30.3...v1.31.0) (2024-11-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.30.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.30.2...v1.30.3) (2024-11-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.30.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.30.1...v1.30.2) (2024-11-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.30.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.30.0...v1.30.1) (2024-11-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.30.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.29.0...v1.30.0) (2024-11-22)

### 🚀 Features

- extend mv-accountformatter ([d06d453](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/d06d453870568c09394ca5ccea8fedf64a15bfa8))

## [1.29.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.28.0...v1.29.0) (2024-11-20)

### 🚀 Features

- added xlarge | ART-15475 ([4c21d63](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4c21d6388cb7d743546a35600dde7fa83766d420))
- adding optional prop to mvinputcontroller |ART-15475 ([b9d0610](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b9d0610902f88d8ba527b3c4ced4626769a4b003))

## [1.28.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.27.0...v1.28.0) (2024-11-20)

### 🚀 Features

- postArrangementDetails API - add convertSydneyLocalTimeToUtc in .d.ts | ART-14302 ([cd17356](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/cd17356957992cea05a1379d6b8df9d1081587e1))
- postArrangementDetails API - add convertSydneyLocalTimeToUtc in .d.ts | ART-14302 ([9e32d6b](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9e32d6babeab138c926fad07090ae1854193c952))

## [1.27.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.26.0...v1.27.0) (2024-11-20)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.26.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.25.3...v1.26.0) (2024-11-20)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.25.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.25.2...v1.25.3) (2024-11-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.25.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.25.1...v1.25.2) (2024-11-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.25.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.25.0...v1.25.1) (2024-11-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.25.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.24.0...v1.25.0) (2024-11-18)

### 🚀 Features

- migrate mv-accountformatter ([69b154f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/69b154f04c9dc547fc5affde968298ab29b3924f))

## [1.24.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.23.1...v1.24.0) (2024-11-15)

### 🚀 Features

- allow developers to add a link button to the header of the MVDetailSection component ([3a66ab8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3a66ab875864c55337be4cafd0ed98e5e47ba12b))

## [1.23.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.23.0...v1.23.1) (2024-11-15)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.23.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.22.0...v1.23.0) (2024-11-13)

### 🚀 Features

- MVCard title conditional rendering added | ART-29128 ([99a1257](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/99a1257a8e659d7d495294713c6c5cafe3537bfc))

## [1.22.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.21.2...v1.22.0) (2024-11-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.21.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.21.1...v1.21.2) (2024-11-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.21.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.21.0...v1.21.1) (2024-11-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.21.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.20.1...v1.21.0) (2024-11-11)

### 🚀 Features

- added scrolltotop to index |ART-16950 ([7fc07c7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/7fc07c7d0489e384b8a1da7c299b83c8bd36046f))

## [1.20.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.20.0...v1.20.1) (2024-11-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.20.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.19.0...v1.20.0) (2024-11-06)

### 🚀 Features

- autocomplete component update | ART-24649 ([4229dd4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4229dd4459c558e41902df72e4a128cd2c5e3783))

## [1.19.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.18.0...v1.19.0) (2024-11-05)

### 🚀 Features

- update for package.json | ART-24649 ([16a8e58](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/16a8e580a78a24f35e2199696f18da5dac397084))

## [1.18.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.17.0...v1.18.0) (2024-11-05)

### 🚀 Features

- hotfix | ART-24649 ([8364718](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8364718eecd0e1834fdd553aa1f63b49fd2a739c))
- update for index.d.ts | ART-24649 ([1a832ca](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1a832ca960fd64ef4cc099b5108f82f10c2bc971))

## [1.17.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.16.0...v1.17.0) (2024-11-04)

### 🚀 Features

- amount and autocomplete components update| ART-24649 ([468ea8d](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/468ea8d1a0a781ca5301f586eba605565964e297))
- currency controller update | ART-24649 ([26f04f9](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/26f04f91c034c67caca6a9959b9bb7c5677ca230))
- update ref with unit test and remove useless code | ART-24649 ([5932336](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5932336d90bab094a26a4fb17ce228622fb21aef))

## [1.16.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.15.0...v1.16.0) (2024-11-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.15.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.14.0...v1.15.0) (2024-11-04)

### 🚀 Features

- update to ts | ART-15347 ([4f5dba5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/4f5dba5234cda618bad6b9596bdb1c30cec383fc))

## [1.14.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.13.0...v1.14.0) (2024-11-03)

### 🚀 Features

- Detail section component update and merge with master branch and resolved conflicts| ART-16972 ([f8f8f28](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/f8f8f281e9024b6370d48b1a1b2dfd08448d0479))

## [1.13.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.8...v1.13.0) (2024-11-01)

### 🚀 Features

- mvcard component migration | ART-29215 ([9d39cda](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9d39cda9a6a10b11ae741d2ed4c1f300d266028f))
- review comment fixes | ART-29215 ([8f70eb2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8f70eb22a0c099df635df2bd2a84c335a1220360))

## [1.12.8](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.7...v1.12.8) (2024-10-31)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.12.7](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.6...v1.12.7) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.12.6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.5...v1.12.6) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.12.5](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.4...v1.12.5) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.12.4](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.3...v1.12.4) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.12.3](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.2...v1.12.3) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.12.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.1...v1.12.2) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.12.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.12.0...v1.12.1) (2024-10-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.12.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.11.0...v1.12.0) (2024-10-24)

### 🚀 Features

- add ag-grid in library | ART-15347 ([c7ddeca](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/c7ddecae68130f652111dbf78a97a0fc2890f569))

## [1.11.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.10.0...v1.11.0) (2024-10-23)

### 🚀 Features

- add refresh widget and form controller | ART-24650 ([3c642b6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/3c642b6738b45ef17cb7b0ced7b641d9d2cfdcd2))

## [1.10.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.9.0...v1.10.0) (2024-10-22)

### 🚀 Features

- component updateion | ART-28136 ([8c92281](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/8c92281f2a764123117bba261294e71c43bf7f25))
- **ui-galaxy:** add acount formatter | ART-24665 ([6263fc6](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/6263fc669a00198fdc5ea08ff3537237b26a6218))
- update the type declaration file | ART-24650 ([0ebe684](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/0ebe68403a73f5c263bd0ee54be90fa3bcc18de2))

## [1.9.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.8.0...v1.9.0) (2024-10-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.8.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.7.2...v1.8.0) (2024-10-22)

### 🚀 Features

- update package name in library | ART-24650 ([1bd11b1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/1bd11b1fc74f7b9fed08fee4a65aaca3517db2cf))

## [1.7.2](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.7.1...v1.7.2) (2024-10-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.7.1](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.7.0...v1.7.1) (2024-10-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.7.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.6.0...v1.7.0) (2024-10-22)

### 🚀 Features

- update hello world pacakge | ART-24650 ([5f89051](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/5f8905112ccbbab228ee842eb83023bf59df8f10))

## [1.6.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.5.0...v1.6.0) (2024-10-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/components

## [1.5.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.4.0...v1.5.0) (2024-10-21)

### 🚀 Features

- add helloworld comonent | ART-15321 ([2d8a22c](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/2d8a22c2e64491ba0c09ebe3d55be1ddf00791ef))
- install helloworld comonent | ART-15321 ([9e1e197](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/9e1e19785833d17e8b16e5f7f04e8a28d70c1282))

## [1.4.0](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/compare/v1.3.0...v1.4.0) (2024-10-21)

### 🚀 Features

- gel and tailwind configurations | ART-15321 ([a08d6fa](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/a08d6fad4d55fda8c413018fb9e9aad19a407565))

## 1.3.0 (2024-10-16)

### 🚀 Features

- initial mesh tenant multiverse ui common library | ART-15321 ([b8e295f](https://bitbucket.srv.westpac.com.au/scm/wdp/multiverse-ui-common-library/commit/b8e295f45a7db6b3b143f3390ab287d2b538c615))
