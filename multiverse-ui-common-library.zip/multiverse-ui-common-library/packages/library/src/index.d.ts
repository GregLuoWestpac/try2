/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  ColDef,
  Column,
  IRowNode,
  GridApi,
  ProcessHeaderForExportParams,
} from 'ag-grid-community';
import {
  ColDef as ColDefV2,
  ColumnPinnedEvent as ColumnPinnedEventV2,
  Column as ColumnV2,
  FilterChangedEvent,
  IContextMenuParams,
  IRowNode as IRowNodeV2,
  SuppressHeaderKeyboardEventParams as SuppressHeaderKeyboardEventParamsV2,
  SuppressKeyboardEventParams as SuppressKeyboardEventParamsV2,
} from 'ag-grid-community-v2';
import { AgGridReactProps as AgGridReactPropsV2 } from 'ag-grid-react-v2';
import { NavigateFunction } from 'react-router-dom';

import {
  ComponentType,
  FC,
  FocusEventHandler,
  Ref,
  SyntheticEvent,
  HTMLAttributes,
  Dispatch,
  SetStateAction,
} from 'react';
import { ButtonProps } from '@westpac/ui';

import { Look } from '@westpac/ui/components/alert/alert.types';

export * from 'ag-grid-community';
export {
  CellClickedEvent,
  ColDef,
  Column,
  ColumnApi,
  ColumnPinnedEvent,
  SuppressKeyboardEventParams,
} from 'ag-grid-community';
export {
  CellClickedEvent as CellClickedEventV2,
  CellKeyDownEvent as CellKeyDownEventV2,
  ColDef as ColDefV2,
  Column as ColumnV2,
  GetContextMenuItemsParams as GetContextMenuItemsParamsV2,
  GetMainMenuItemsParams as GetMainMenuItemsParamsV2,
  GridReadyEvent as GridReadyEventV2,
  RowClassParams as RowClassParamsV2,
  RowClassRules as RowClassRulesV2,
  SuppressHeaderKeyboardEventParams as SuppressHeaderKeyboardEventParamsV2,
  SuppressKeyboardEventParams as SuppressKeyboardEventParamsV2,
  ValueFormatterParams as ValueFormatterParamsV2,
  GridApi as GridApiV2,
} from 'ag-grid-community-v2';
export * from 'ag-grid-enterprise';
export * as AGGridEnterpriseV2 from 'ag-grid-enterprise-v2';
export * from 'ag-grid-react';
export * as AgGridReactV2 from 'ag-grid-react-v2';
export type { CustomCellRendererProps as CustomCellRendererPropsV2 } from 'ag-grid-react-v2';
export { Settings as LuxonSettings } from 'luxon';

import {
  AutocompleteProps,
  InputGroupProps,
  ButtonGroupProps,
} from '@westpac/ui';
import { DateTime } from 'luxon';
import React, { ReactNode } from 'react';
import {
  Control,
  FieldErrors,
  FieldValues,
  Path,
  RegisterOptions,
  UseFormClearErrors,
  UseFormSetError,
  UseFormTrigger,
} from 'react-hook-form';

/**
 * Constants definition for the MVConstants start
 */

declare const SYDNEY_ZONE = 'Australia/Sydney';

/**
 * Constants definition for the MVConstants end
 */

export type MVInputControllerProps<T extends FieldValues> = {
  fieldName: string;
  control: Control<T>;
  validationRules?: RegisterOptions;
  id?: string;
  maximumLength?: number;
  inputType?: string;
  placeholder?: string;
  onBlur?: FocusEventHandler;
  onChange?: (value: string) => void;
  hideCounterText?: boolean;
  multiLines?: boolean;
  dialCode?: string;
  matchPattern?: RegExp;
} & InputGroupProps;

export const MVInputController: <T extends FieldValues>(
  props: MVInputControllerProps<T>
) => React.ReactElement;

export const MVPhoneInputController: <T extends FieldValues>(
  props: Omit<MVInputControllerProps<T>, 'dialCode'>
) => React.ReactElement;

/**
 * Type definition for the MVRefresh component
 */

export type MVRefreshProps = {
  /**
   * Function to call when the refresh action is triggered
   */
  onRefresh: () => void;

  /**
   * Boolean to disable the refresh button
   */
  disabled?: boolean;

  /**
   * String representing the last successful date and time to display
   */
  lastSuccessfulDateTime?: string;
};

export type MVRefreshHandle = {
  /**
   * Function to refresh the current date and time
   */
  refreshDateTime: () => void;
};

export const MVRefresh: React.ForwardRefExoticComponent<
  React.PropsWithoutRef<MVRefreshProps> & React.RefAttributes<MVRefreshHandle>
>;

export type MVCardProps = {
  children: React.ReactNode;
  title?: string;
  template?: string;
  subtitle?: string;
  bottomDivider?: boolean;
  bottomPadding?: boolean;
};

export const MVCard: React.FC<MVCardProps>;

export type MVAlertType = 'success' | 'danger' | 'info' | 'warning' | 'system';

export type MVAlertProps = {
  /**
   * Optional heading or title text displayed above the main content
   */
  heading?: string;

  /**
   * Optional URL for the link rendered after the children
   */
  link?: string;

  /**
   * Text to display for the clickable link. If not provided, the `link` URL will be shown.
   */
  linkText?: string;

  /**
   * Optional custom icon to display at the start of the alert
   */
  icon?: React.ReactNode;

  /**
   * Duration (in milliseconds) after which the alert hides automatically.
   * If 0 or undefined, the alert stays visible until manually closed.
   */
  autoHideDuration?: number;

  /**
   * Whether to show a close (X) button
   */
  isDismissible?: boolean;

  /**
   * Allows for the close function to be determined by the user
   */
  closeAlert?: () => void;

  /**
   * Type of alert to determine color and icon
   */
  type?: MVAlertType;

  /**
   * Alert content (message), supports JSX
   */
  children: React.ReactNode;

  className?: string;

  hasBackground?: boolean;
} & React.HTMLAttributes<HTMLDivElement>;

export const MVAlert: React.FC<MVAlertProps>;

type IconProps = { size?: 'small' | 'medium' | 'large'; color?: string };
type ContentItem = {
  key: string;
  title: string;
  onClickRowFn: () => void;
  onCloseRowFn: () => void;
  icon: (props: IconProps) => JSX.Element;
  closeBtn: boolean;
};
export type MVButtonDropdownProps = {
  /**
   * Button text
   */
  children?: ReactNode;
  /**
   * Content of button dropdown
   */
  content: ContentItem[];
  /**
   * Heading for button dropdown box
   */
  headingLine?: string;
  /**
   * Supporting Text for Heading of button dropdown box
   */
  supportingText?: string;
  /**
   * Use an icon as the button
   */
  icon?: (props: IconProps) => JSX.Element;
  /**
   * Removes padding from trigger button and sets look to link to be able to look inline, use size prop to match font size
   */
  linkStyling?: boolean;
  /**
   * A function for the onClick event
   */
  onClick?: () => void;
  /**
   * To be used in the consuming repo to access the state
   */
  isOpen: boolean;
  /**
   * To be used in the consuming repo to set the state the state
   */
  setIsOpen: Dispatch<SetStateAction<boolean>>;
  /**
   * Placement of button dropdown. If no placement provided it will default to top unless there is no space then will appear on bottom.
   * @default top
   */
  placement?: 'top' | 'bottom';
  /**
   * Change trigger button color
   */
  buttonColor?: string;
  /**
   * Max Height for dropdown content
   */
  maxHeight?: string;
} & HTMLAttributes<Element> &
  Pick<ButtonProps, 'look' | 'soft' | 'size'>;

export const MVButtonDropdown: React.FC<MVButtonDropdownProps>;

export type GridSpan = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
export type MVDetailSectionProps = {
  heading?: string;
  data: {
    label: string;
    secondaryLabel?: string;
    value: string | JSX.Element | null | undefined;
    itemWithFullWidth?: ReactNode;
    style?: string;
    tooltip?: string;
  }[];
  enableDynamicColumnWidth?: boolean;
  withTopBorder?: boolean;
  withBottomBorder?: boolean;
  linkAction?: {
    id?: string;
    name?: string;
    width?: GridSpan;
    text: string;
    action: () => void;
  };
};

export const MVDetailSection: React.FC<MVDetailSectionProps>;

export type ListOption = {
  name: string;
  id: string;
  entityName?: string;
  accountType?: string;
  payeeType?: string;
  domestic?: { accountName?: string };
};
/*
export interface MVAutoCompleteProps {
  defaultInputValue: ListOption;
  listOptions: ListOption[];
  setSearchItem: (value: ListOption) => void;
  onBlur: () => void;
  isError: boolean;
  autoFocus?: boolean;
  errorMessage: string;
  header: string;
  helpText: string;
  renderOption?: (option: ListOption) => JSX.Element;
  renderValue?: (option: ListOption) => string;
  optionsMaxHeight?: number;
  isIconVisible?: boolean;
  maxVisibleOptions?: number;
  defaultInputOption?: ListOption;
  placeholder?: string;
  renderOptionOnHover?: (option: ListOption) => JSX.Element;
  isAdditionalError?: boolean;
  isBeneficiary?: boolean;
}

export const MVAutoComplete: React.FC<MVAutoCompleteProps>;
*/
export type MVCurrencyControllerProps<T extends FieldValues> = {
  id: string;
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  validationRules?: RegisterOptions;
  trigger: UseFormTrigger<T>;
  disabled?: boolean;
  label?: string;
  removeMargin?: boolean;
};

export const MVCurrencyController: <T extends FieldValues>(
  props: MVCurrencyControllerProps<T>
) => React.ReactElement;

export type MVSelectControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  id?: string;
  label: string;
  validationRules?: RegisterOptions;
  options: Array<{ id: string; label: string; name: string }>;
  disabled?: boolean;
  placeholder?: string;
  size?: 'small' | 'medium' | 'large' | 'xlarge';
  width?: 1 | 2 | 'full' | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 20 | 30;
  hintText?: string;
  supportingText?: React.ReactNode;
  showSpinner?: boolean;
};

export const MVSelectController: <T extends FieldValues>(
  props: MVSelectControllerProps<T>
) => React.ReactElement;

export type AccountDetailsItem = {
  value: string;
  className?: string;
  labelClassName?: string;
} & (
  | {
      variant: 'accessory-icon';
      accessory: React.ReactNode;
      hint: string;
      label: string;
    }
  | { variant: 'text'; label?: string }
);

export type MVAccountFormatterProps = {
  details: string[] | AccountDetailsItem[];
};

export const MVAccountFormatter: React.FC<MVAccountFormatterProps>;

export type MVAccountSummaryItem = {
  title: string;
  content: React.ReactNode | string;
  status?: string;
  statusColor?: 'success' | 'hero' | 'warning' | 'danger';
  maxWidth?: number;
  minWidth?: number;
  truncate?: boolean;
};

export type MVAccountSummaryProps = {
  header?: React.ReactNode;
  items: MVAccountSummaryItem[];
  error?: React.ReactNode;
  gridClassName?: string;
  variant?: 'default' | 'outline';
};

export const MVAccountSummary: React.FC<MVAccountSummaryProps>;

export type MVLoaderProps = {
  iconSize?: 'xsmall' | 'small' | 'medium' | 'large' | 'xlarge';
  color?: 'white' | 'black';
};

export const MVLoader: React.FC<MVLoaderProps>;

export type MVIconsProps = { width?: number; height?: number; name: string };

export const MVIcons: React.FC<MVIconsProps>;

export type MVSearchInputControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  autoFocus?: boolean;
  placeholder: string;
  validationRules?: RegisterOptions;
  listOptions: ListOption[];
  renderOption?: (option: unknown) => JSX.Element;
  renderValue?: (option: unknown) => string;
  noOptionsMessage?: string;
  defaultInputs?: unknown;
  header: string;
  onValueChange?: (newValue: unknown) => void;
};
export const MVSearchInputController: <T extends FieldValues>(
  props: MVSearchInputControllerProps<T>
) => React.ReactElement;
/**
 * ==============================================================
 * ================== MV-ENTITLEMENTSLIB ========================
 * ==============================================================
 */

declare const AUTHORISED_MSG = 'You are authorised.';
declare const NOT_AUTHORISED_MSG = 'You do not have sufficient permission.';
declare const AUTHORISATION_REQUEST_SKIPPED_MSG =
  'Authorisation request skipped.';
declare const INVALID_AUTHORISATION_REQUEST_MSG =
  'Invalid authorisation request.';
declare enum Resources {
  ACCOUNTS = 'account',
  TRANSACTIONS = 'transaction',
  CUSTOMER = 'customer',
  PAC = 'PAC',
}
declare enum Actions {
  VIEW_ACCOUNTS = 'viewAccounts',
  VIEW_TRANSACTIONS = 'viewTransactions',
  VIEW_PAYMENTS = 'viewPayments',
  INITIATE_PAYMENT = 'initiatePayment',
  INITIATE_TRANSFER = 'initiateTransfer',
  INITIATE_PAYMENT_RETURN = 'initiatePaymentReturn',
  VIEW_BENEFICIARIES = 'viewBeneficiaries',
  OVER_RIDE_CREDIT_INTEREST = 'overrideCreditInterest',
  VIEW_DEFAULT_PERMISSIONS = 'viewDefaultPermissions',
  VIEW = 'view',
  OPEN_ACCOUNT = 'openAccount',
  CLOSE_ACCOUNT = 'closeAccount',
  BLOCK_ACCOUNT = 'blockAccount',
  UNBLOCK_ACCOUNT = 'unblockAccount',
  BLOCK_CUSTOMER = 'blockCustomer',
  UNBLOCK_CUSTOMER = 'unblockCustomer',
  AUTHORISE_PAYMENT = 'authorisePayment',
  AUTHORISE_TRANSFER = 'authoriseTransfer',
  CREATE_USER = 'createUser',
  AUTHORISE_USER = 'authoriseUser',
  MANAGE_ACCOUNT_NAME = 'manageAccountName',
  VIEW_ADVANCE_PAYMENT_TRANSACTIONS = 'viewAdvancedPaymentTransactions',
}

type AuthorisationOutcome = { authorised: boolean; message: string };

declare const useAuthoriser: (
  resource: Resources,
  action: Actions
) => AuthorisationOutcome;

declare const isUserAuthorised: (
  resource: Resources,
  action: Actions
) => AuthorisationOutcome;

/**
 * ==============================================================
 * ================== MV-UTILS ==================================
 * ==============================================================
 */

/**
 * Type definition for the screen
 */

export function scrollToTop(): void;

/**
 * Type definition for the debounce
 */

export function debounce(
  callback: () => void,
  time: number,
  finalCallback: () => void
): () => void;

/**
 * Type definition for the dateTime
 */

export function getFormattedDateTime(
  dateTimeIsoString?: string,
  timeFormat?: string
): string;

export function getFormattedDate(
  dateTimeIsoString?: string,
  dateFormat?: string,
  displayStyle?: 'date-time' | 'date-time-zone',
  isDateRequired?: boolean
): string;

export function getEndDateExclusive(date: string): string | null;

export function getStartDateInclusive(date: string): string | null;

export type ConvertDateType = 'end';
export function convertSydneyLocalTimeToUtc(
  data: string,
  type?: ConvertDateType
): string | null;

export function formatDateRange(startDate: string, endDate: string): string;
export function dateRangeString(startDate: string, endDate: string): string;
export function getCurrentFinancialYear(): number;

/**
 * Type definition for the crypto
 */

export const base64ToArrayBuffer: (base64: string) => ArrayBufferLike;
export const generateKeyFromBase64: (
  base64: string,
  KeyUsage: KeyUsage[]
) => Promise<CryptoKey>;
export const decryptDataChunkFromString: (
  encryptedChunkString: string,
  key: CryptoKey
) => Promise<unknown>;

/**
 * Type definition for the format
 */

export const formatToTwoDecimals: (input: string) => string;
export function prefixWithISOCurrency(
  currency: string,
  value: string | number
): string;
export function currencyFormatter(num?: number, locale?: string): string;
export function formatWithEllipsis(str?: string, maxLength?: number): string;
export function formatCurrency(value: number | ''): string;
export function formatPercentage(rate: number): string;
export function formatBSB(id: string | undefined, index: number): string;
export function formatBSBFromAccNo(
  accountNo: string | undefined,
  bsbLength?: number
): string;

export type SupportedCurrency = {
  code: string;
  symbol: string;
  amountRegex: string;
  decimalPlaces: number;
};

export const SUPPORTED_CURRENCIES: readonly SupportedCurrency[];

/**
 * Type definition for the ref
 */

export const mergeRefs: <T>(refs: Ref<T>[]) => (value: T) => void;

/**
 * Type definition for the urlUtils
 */

export const getURLParams: () => string;
export const getAppUrlWithParams: (newUrl: string, appName?: string) => string;
export const getAppUrlWithoutParams: (
  newUrl: string,
  appName?: string
) => string;
export const isStaffPortal: () => boolean;

/**
 * Type definition for the format
 */

export type CurrencyAmount = {
  amount: string;
  currencyCode: 'AUD' | 'USD' | 'NZD' | 'EUR' | 'SGD' | 'GBP';
};
export function formatCurrencyString(
  input: string | CurrencyAmount,
  currencyCode?: 'AUD' | 'USD' | 'NZD' | 'EUR' | 'SGD' | 'GBP'
): string;

export const parseCurrencyString: (input: string) => string;

/**
 * Type definition for appCorrelationId
 */
type SetAppCorrelationId = (id: string) => void;
export const useAppCorrelationId: (
  setAppCorrelationId: SetAppCorrelationId
) => string;

/**
 * Type definition for checkEntitlementError
 */
type EntitlementErrorAction = { type: string; payload: unknown };
export const checkEntitlementError: (
  action: EntitlementErrorAction,
  excludeActions?: string[]
) => void;

/**
 * Type definition for intents
 */

export type handleRaiseIntentParams = {
  intentName: string;
  intentContextName: string;
  targetPath?: string;
  data?: Record<string, unknown>;
  contextKey?: string;
  intentId?: Record<string, unknown>;
  containerTabTitle?: string;
  windowTabTitle?: string;
};

export function withIntent<P extends object>(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  useGlobalDispatch: any,
  intentName: string,
  supportBrowser?: boolean
): (WrappedComponent: ComponentType<P>) => FC<P>;

export const useHandleRaiseIntent: (
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  useGlobalDispatch: any,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  useNavigate: any
) => ({
  intentName,
  intentContextName,
  targetPath,
  data,
  contextKey,
  intentId,
  containerTabTitle,
  windowTabTitle,
}: handleRaiseIntentParams) => Promise<void>;

/**
 * MV Table Type Definitions Start
 */

export type TableData = { [key: string]: unknown };

export type ActionButtonPropsType = {
  api: {
    contextMenuFactory: {
      showMenu: (
        node: IRowNode<TableData>,
        column: Column<TableData>,
        value: string,
        event: SyntheticEvent
      ) => void;
    };
  };
  node: IRowNode<TableData>;
  column: Column<TableData>;
};

export const ActionButton: React.FC<ActionButtonPropsType>;

export type MVTableExportCSV = {
  exportCsv: (fileName: string, exportAllColumns: boolean) => void;
  api: GridApi<TableData>;
  processHeaderCallback?: (params: ProcessHeaderForExportParams) => string;
};
/*
export type MVTablePropsType = AgGridReactProps & {
  noRowMessage: string;
  rowData: TableData[];
  defaultColumnDef: ColDef;
  height?: number;
};

export type MVTableRefType = { api: GridApi | null };

export const MVTable: ForwardRefExoticComponent<
  MVTablePropsType & RefAttributes<MVTableRefType>
>;
*/
export const useSetAgGridLic: () => boolean;

/**
 * MV Table Type Definitions End
 */

/**
 * MV Table V2 Type Definitions Start
 */

export type TableDataV2 = { [key: string]: unknown };

export type ActionButtonV2PropsType = {
  api: { showContextMenu: (params: IContextMenuParams) => void };
  node: IRowNodeV2<TableDataV2>;
  column: ColumnV2<TableDataV2>;
};

export const ActionButtonV2: React.FC<ActionButtonV2PropsType>;

export type MVTableV2PropsType = AgGridReactPropsV2 & {
  noRowMessage: string;
  rowData: TableDataV2[];
  defaultColumnDef: ColDefV2;
  tableHeight?: number;
  isStatic?: boolean;
  footnote?: string;
  ref?: React.RefObject<any>;
  containerRef?: React.RefObject<HTMLElement>;
  minHeight?: number;
};

export const MVTableV2: React.FC<MVTableV2PropsType>;

export const useSetAgGridLicV2: () => boolean;

export const getAllFocusableElementsOfV2: (el: HTMLElement) => HTMLElement[];

export const getEventPathV2: (event: KeyboardEvent) => HTMLElement[];

export const onColumnPinnedV2: (event: ColumnPinnedEventV2) => void;

export const suppressKeyboardEventV2: (
  params: SuppressKeyboardEventParamsV2
) => boolean;

export const suppressHeaderKeyboardEventV2: (
  params: SuppressHeaderKeyboardEventParamsV2
) => boolean;

export const onFilterChangedV2: (event: FilterChangedEvent) => void;

type ColumnKeys =
  | 'submittedDate'
  | 'receiptNumber'
  | 'valueDate'
  | 'paymentId'
  | 'fromAccount'
  | 'toAccount'
  | 'amount'
  | 'currency'
  | 'debitDescription'
  | 'paymentMethod'
  | 'status'
  | 'issueDate'
  | 'statementNumber'
  | 'statementId'
  | 'transactionDateTime'
  | 'narrative'
  | 'debitAmount'
  | 'creditAmount'
  | 'balance'
  | 'accountNumber'
  | 'accountName'
  | 'entityName'
  | 'accountType'
  | 'currencyCode'
  | 'availableBalance'
  | 'currentBalance'
  | 'overdraftLimit'
  | 'accListStatus'
  | 'actions'
  | 'beneficiaryNickname'
  | 'accountDetails'
  | 'type'
  | 'interestEarned'
  | 'interestPaid'
  | 'withholdingTax';

declare const COMMON_COLUMN_DEFS: {
  [key in ColumnKeys]: (colDef?: ColDef) => ColDef;
};

export const numberComparator: (
  valueA: number | string | null | undefined,
  valueB: number | string | null | undefined
) => number;
/**
 * MV Table V2 Type Definitions End
 */

/**
 * MV Date Range Picker
 */
declare const DATE_FORMAT_REGEX_DDMMYYYY: RegExp;
declare const DATE_FORMAT_YYYYMMDD = 'yyyy-MM-dd';

declare enum DATE_RANGE_PICKER_ERROR {
  DATE_RANGE_INVALID = 'Adjust the dates to ensure the "From date" is before the "To date".',
  DATE_REQUIRED = 'Enter a date in the "dd/mm/yyyy" format.',
  DATE_EARLIER_THAN_7_YEARS = 'Select a date range within the last 7 years.',
  DATE_LATER_THAN_TODAY = 'Select a date that is today or earlier.',
  DATE_DURATION_INVALID = 'Select a date range up to 13 months.',
}

export type DateRange = { startDate: string; endDate: string };

type Props<T extends FieldValues> = {
  control: Control<T>;
  fieldName: Path<T>;
  setError: UseFormSetError<T>;
  clearErrors: UseFormClearErrors<T>;
};

type OnlyDurationInDays = {
  durationInDays: number;
  durationInMonths?: never;
  durationInvalidMessage: string;
};
type OnlyDurationInMonths = {
  durationInDays?: never;
  durationInMonths: number;
  durationInvalidMessage: string;
};
type NeitherDurationInDaysAndMonths = {
  durationInDays?: never;
  durationInMonths?: never;
  durationInvalidMessage?: never;
};

type OnlyEarliestYear = {
  earliestYear: number;
  earliestMonth?: never;
  earliestInvalidMessage: string;
};
type OnlyEarliestMonth = {
  earliestYear?: never;
  earliestMonth: number;
  earliestInvalidMessage: string;
};
type NeitherEarliestYearAndMonth = {
  earliestYear?: never;
  earliestMonth?: never;
  earliestInvalidMessage?: never;
};

export type MVDateRangePickerControllerProps<T extends FieldValues> = (
  | OnlyDurationInDays
  | OnlyDurationInMonths
  | NeitherDurationInDaysAndMonths
) &
  (OnlyEarliestYear | OnlyEarliestMonth | NeitherEarliestYearAndMonth) &
  Props<T>;

export const MVDateRangePickerController: <T extends FieldValues>(
  props: MVDateRangePickerControllerProps<T>
) => React.ReactElement;

export function getToday(): DateTime;
export function getTodayAtLastYear(): DateTime;
export function getTodayAtXYearsAgo(earliestYear: number): DateTime;

export function isDateRangeInvalid(start: string, end: string): boolean;
export function isDateDurationInvalid({
  startDate,
  endDate,
  durationInDays,
  durationInMonths,
}: {
  startDate: string;
  endDate: string;
  durationInDays?: number;
  durationInMonths?: number;
}): boolean;
export function isDateAfterToday(data: string): boolean;
export function isDateBeforeXYears(data: string, earliestYear: number): boolean;

/**
 * MV Date Range Picker Definitions End
 */

/**
 * MV Autocomplete Definitions Start
 */
export type AutocompleteId = { id: string };

export type MVAutocompleteControllerProps<
  T1 extends FieldValues,
  T2 extends AutocompleteId,
> = {
  fieldName: Path<T1>;
  control: Control<T1>;
  validationRules?: RegisterOptions;
  allItems: T2[];
  ItemDetails?: ({ item }: { item: T2 }) => ReactNode;
  AdditionalDetails?: ({ item }: { item: T2 }) => ReactNode;
  keyFn?: (item: T2) => string;
  inputValueFn?: (item: T2) => string;
  maxVisibleItems?: number;
  filterFn?: (item: T2, input: string) => boolean;
  onChange?: (value: T2 | null) => void;
} & Omit<AutocompleteProps<T2>, 'children'>;

export const MVAutocompleteController: <
  T1 extends FieldValues,
  T2 extends AutocompleteId,
>(
  props: MVAutocompleteControllerProps<T1, T2>
) => React.ReactElement;

export const AutocompleteItemDetailsTemplate: ({
  line1,
  line2,
  line3,
}: {
  line1: React.ReactNode;
  line2?: React.ReactNode;
  line3?: React.ReactNode;
}) => React.ReactElement;
/**
 * MV Autocomplete Definitions End
 */

export {
  Actions,
  AUTHORISATION_REQUEST_SKIPPED_MSG,
  AuthorisationOutcome,
  AUTHORISED_MSG,
  COMMON_COLUMN_DEFS,
  DATE_FORMAT_REGEX_DDMMYYYY,
  DATE_FORMAT_YYYYMMDD,
  DATE_RANGE_PICKER_ERROR,
  INVALID_AUTHORISATION_REQUEST_MSG,
  isUserAuthorised,
  NOT_AUTHORISED_MSG,
  Resources,
  SYDNEY_ZONE,
  useAuthoriser,
};

/**
 * MVPageLoader type Definitions
 */

export type IconSize = 'xsmall' | 'small' | 'medium' | 'large' | 'xlarge';
export type Placement = 'normal' | 'middle';
export type MVPageLoaderProps = { iconSize?: IconSize; placement?: Placement };
export function MVPageLoader({
  iconSize,
  placement,
}: MVPageLoaderProps): JSX.Element;

/*
 * Type definition for the mv-utils
 */

/**
 * @deprecated This function is deprecated and will be removed in future releases. Use sanitiseWithPattern instead.
 */
export const sanitise: (
  input: string,
  pattern: string,
  maxLength?: number
) => string;

export const sanitiseWithPattern: (
  input: string,
  pattern: string,
  maxLength?: number
) => string;

export const ACCOUNT_HOLDER_PATTERN = '^[a-zA-Z0-9\- !,.:\;?_]+$';
export const ACCOUNT_NAME_PATTERN = '^[a-zA-Z0-9\- !,.:\;?_]+$';

export const PAYMENT_DESCRIPTION_PATTERN = '^[a-zA-Z0-9\- !,.:\;?_]+$';
export const PAYMENT_REFERENCE_PATTERN = '^[a-zA-Z0-9\- !,.:\;?_]+$';
export const TRANSFER_DESCRIPTION_PATTERN = '^[a-zA-Z0-9\- !,.:\;?_]+$';

export const ACCOUNT_NAME_MAX_LENGTH = 70;

export const ChannelTypeCodeCustomer: {
  readonly W1C_U_A_CP: 'W1C_U_A_CP';
  readonly W1C_O_U_CP: 'W1C_O_U_CP';
  readonly W1C_O_B_D_CP: 'W1C_O_B_D_CP';
  readonly W1C_O_B_T_CP: 'W1C_O_B_T_CP';
  readonly W1C_O_B_M_CP: 'W1C_O_B_M_CP';
  readonly W1C_O_A_D_CP: 'W1C_O_A_D_CP';
};

export const ChannelTypeCodeStaff: {
  readonly W1C_O_A_D_SP: 'W1C_O_A_D_SP';
  readonly W1C_O_B_D_SP: 'W1C_O_B_D_SP';
  readonly W1C_U_A_SP: 'W1C_U_A_SP';
};

export type ChannelTypeCode =
  | (typeof ChannelTypeCodeCustomer)[keyof typeof ChannelTypeCodeCustomer]
  | (typeof ChannelTypeCodeStaff)[keyof typeof ChannelTypeCodeStaff];

export const useGetChannelTypeCode: (openFinHooks: {
  useIsDesktopVersion: () => boolean;
  useIsWebVersion: () => boolean;
  useIsCompositeDesktop: () => boolean;
}) => ChannelTypeCode;

/**
 * MVAccountAdditionalDetails Definitions Start
 */
export type MVAccountAdditionalDetailsItem = {
  label: string;
  information: React.ReactNode;
};

export type MVAccountAdditionalDetailsProps = {
  data: MVAccountAdditionalDetailsItem[];
};

export const MVAccountAdditionalDetails: (
  props: MVAccountAdditionalDetailsProps
) => React.ReactElement;
/**
 * MVAccountAdditionalDetails Definitions End
 */

/**
 * MVButtonGroupController Definitions Start
 */
export type MVButtonGroupControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  trigger: UseFormTrigger<T>;
  control: Control<T>;
  validationRules?: RegisterOptions;
  onChange?: () => void;
  onBlur?: () => void;
  tooltip?: string;
} & ButtonGroupProps;

export const MVButtonGroupController: <T extends FieldValues>(
  props: MVButtonGroupControllerProps<T>
) => React.ReactNode;
/**
 * MVButtonGroupController Definitions End
 */

/**
 * Type definition and constant for the mv-injection-checker
 */

export declare const validateWithLibrary: (content: string) => boolean;
export declare const FORBIDDEN_CHARACTERSET: string[];
export declare const sanitiseWithLibrary: (
  input: string,
  maxLength?: number
) => string;
export declare const getFormattedForbiddenCharacters: () => string;
// end mv-injection-checker

// Extend the ColDefV2 with CustomColDef
export interface CustomColDef extends ColDefV2 {
  excludeFromExport?: boolean;
  columnIndex?: number;
}

export type NotificationAlertState = { type: Look; message: string };

export function NotificationAlert(): JSX.Element;

/**
 * MVProgressStepper Definitions Start
 */
export const MVProgressStepper: (props: {
  steps: string[];
  activeStep: number;
  setActiveStep: React.Dispatch<React.SetStateAction<number>>;
}) => React.ReactElement;
/**
 * MVProgressStepper Definitions End
 */

/**
 * MVOpenfin Definitions Start
 */
/**
 * @description custom hook which consolidates logics for closing a page in both openfin web and openfin desktop
 * @reference  https://confluence.srv.westpac.com.au/display/WDVFY24/Technical+Interaction+Between+W1+and+W1C#TechnicalInteractionBetweenW1andW1C-Closingthecurrentcontainertab
 */
export function useUnifyClose(showConfirmModal: boolean): {
  closeTab: () => void | Promise<void>;
};
/**
 * MVOpenfin Definitions End
 */

/*
 * MVExportTableToCsv Definitions Start
 */
export const MVExportTableToCsv: (props: {
  shouldHideExportButton?: boolean;
  mvTableRef: React.RefObject<MVTableExportCSV | null>;
  exportedFileName: string;
  buttonText: string;
  className?: string;
  processHeaderCallback?: (params: ProcessHeaderForExportParams) => string;
}) => React.ReactElement;
/**
 * MVExportTableToCsv Definitions End
 */
// type definition for the useCheckEntitlementError start
export const useCheckEntitlementError: (
  error: any,
  useNavigate: NavigateFunction,
  excludeApiNames: string[],
  apiName: string
) => void;
// end

/**
 * MVMoreResultsAlert Definitions Start
 */
export const MVMoreResultsAlert: (props: {
  shouldShow: boolean;
  message?: string;
  className?: string;
}) => React.ReactElement;
/**
 * MVMoreResultsAlert Definitions End
 */
