import React from 'react';
import { Badge } from '@westpac/ui';

export type MVBadgeType = 'default' | 'pill';
export type MVBadgeColor =
  | 'primary'
  | 'hero'
  | 'neutral'
  | 'warning'
  | 'faint'
  | 'success'
  | 'info'
  | 'danger';

export type MVBadgeProps = {
  type?: MVBadgeType;
  color?: MVBadgeColor;
  value?: number;
} & React.HTMLAttributes<HTMLDivElement>;

export function MVBadge({
  value,
  color = 'primary',
  type = 'pill',
}: MVBadgeProps) {
  return (
    <>
      <Badge
        color={color}
        type={type}
        className="min-w-[20px] h-[20px] max-h-[20px] top-[1px] left-[22px] items-center justify-center absolute pt-[3px] pb-[4px] px-[3px] width-[20px] text-[12px]"
      >
        {value && value > 99 ? '99+' : value}
      </Badge>
    </>
  );
}
