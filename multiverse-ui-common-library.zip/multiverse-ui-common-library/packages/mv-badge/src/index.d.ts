export type MVBadgeType = 'default' | 'pill';
export type MVBadgeColor =
  | 'primary'
  | 'hero'
  | 'neutral'
  | 'warning'
  | 'faint'
  | 'success'
  | 'info'
  | 'danger';

export type MVBadgeProps = {
  /**
   * Type of badge to determine shape
   */
  type?: MVBadgeType;

  /**
   * Type of badge to determine color
   */
  color?: MVBadgeColor;
} & React.HTMLAttributes<HTMLDivElement>;
