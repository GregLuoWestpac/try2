import { Meta, StoryObj } from '@storybook/react';
import { MVBadge } from '../MVBadge';
const meta: Meta<typeof MVBadge> = {
  title: 'Components/MVBadge',
  component: MVBadge,
  tags: ['autodocs'],
  args: {
    type: 'pill',
    color: 'primary',
    value: '19',
  },
  argTypes: {
    type: {
      control: 'select',
      options: ['default', 'pill'],
    },
    color: {
      control: 'select',
      options: [
        'primary',
        'hero',
        'neutral',
        'warning',
        'faint',
        'success',
        'info',
        'danger',
      ],
    },
  },
};

export default meta;
type Story = StoryObj<typeof MVBadge>;

export const Primary: Story = {
  args: {
    type: 'pill',
    color: 'primary',
    value: '16',
  },
};

export const Neutral: Story = {
  args: {
    type: 'pill',
    color: 'neutral',
    value: '16',
  },
};
export const Faint: Story = {
  args: {
    type: 'pill',
    color: 'faint',
    value: '16',
  },
};
export const Warning: Story = {
  args: {
    type: 'pill',
    color: 'warning',
    value: '16',
  },
};
export const Hero: Story = {
  args: {
    type: 'pill',
    color: 'hero',
    value: '16',
  },
};
export const Success: Story = {
  args: {
    type: 'pill',
    color: 'success',
    value: '16',
  },
};
