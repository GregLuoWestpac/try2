# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.219.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.218.0...v1.219.0) (2025-12-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-badge

## [1.180.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.179.3...v1.180.0) (2025-09-02)

### 🚀 Features

- add new badge (WIBDTW1-148) ([693bb94](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/693bb94f02f013d930bb5eff6f0f0d74847df564))
- update version in lib package ([dc85874](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/dc85874bdd1ee1a97866afae29fb0f267721df9f))
