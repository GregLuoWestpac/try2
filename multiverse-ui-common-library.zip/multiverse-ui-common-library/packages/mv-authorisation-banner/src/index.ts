import MVAuthorisationBanner from './MVAuthorisationBanner';
export default MVAuthorisationBanner;
