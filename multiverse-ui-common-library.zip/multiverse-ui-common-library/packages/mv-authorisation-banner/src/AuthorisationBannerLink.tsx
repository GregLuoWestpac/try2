import React from 'react';
import { Button } from '@westpac/ui';

import { useHandleRaiseIntent } from '@mesh-tenant-multiverse-ui-common/mv-utils/src/intents';
import { AuthorisationBannerLinkProps } from './types';

const INTENT_NAMES = {
  VIEW_GALAXY_AUTHORISATIONS_WORKFLOW: 'ViewGalaxyAuthorisationsWorkflow',
} as const;

const INTENTS_CONTEXT_NAME = 'fdc3.nothing' as const;

const PAGE_NAVIGATION = {
  AUTHORISATIONS_WORKFLOW: '/workflowauthorisation',
} as const;

const AuthorisationBannerLink = ({
  sharedData,
  useGlobalDispatch,
  useNavigate,
}: AuthorisationBannerLinkProps) => {
  const handleRaiseIntent = useHandleRaiseIntent(
    useGlobalDispatch,
    useNavigate
  );

  const navigateToAuthorisation = () => {
    handleRaiseIntent({
      intentName: INTENT_NAMES.VIEW_GALAXY_AUTHORISATIONS_WORKFLOW,
      intentContextName: INTENTS_CONTEXT_NAME,
      targetPath: PAGE_NAVIGATION.AUTHORISATIONS_WORKFLOW,
      ...(Object.keys(sharedData).length > 0 && {
        data: { ...sharedData },
      }),
    });
  };
  return (
    <p className="pb-1">
      {`You can track the status from the `}
      <Button
        data-testid="authorisation-banner-link"
        className="text-success p-0 typography-body-11 h-fit outline-offset-0 leading-none"
        look="link"
        soft
        onClick={navigateToAuthorisation}
      >
        Authorisations
      </Button>
      {` page.`}
    </p>
  );
};

export default AuthorisationBannerLink;
