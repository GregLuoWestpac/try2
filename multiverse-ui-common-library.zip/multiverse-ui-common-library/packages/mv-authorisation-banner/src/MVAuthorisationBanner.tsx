import React from 'react';
import { Alert } from '@westpac/ui';

import AuthorisationDangerBanner from './AuthorisationDangerBanner';
import AuthorisationSuccessBanner from './AuthorisationSuccessBanner';

import { MVAuthorisationBannerProps } from './types';

const MVAuthorisationBanner = ({
  bannerType,
  children,
  apiErrorMessage,
  authorisationId,
  sharedData,
  iconSize = 'medium',
  dismissible = true,
  useGlobalDispatch,
  useNavigate,
  ...rest
}: MVAuthorisationBannerProps) => {
  const isSuccess =
    bannerType === 'maker-success' || bannerType === 'checker-success';
  const renderCustomBannerMessage = () => {
    switch (bannerType) {
      case 'maker-success':
        return (
          <AuthorisationSuccessBanner
            authorisationId={authorisationId}
            sharedData={sharedData}
            useGlobalDispatch={useGlobalDispatch}
            useNavigate={useNavigate}
          />
        );

      case 'checker-danger':
        return (
          <AuthorisationDangerBanner
            authorisationId={authorisationId}
            apiErrorMessage={apiErrorMessage}
          />
        );

      default:
        return null;
    }
  };

  return (
    <Alert
      iconSize={iconSize}
      {...rest}
      dismissible={dismissible}
      look={isSuccess ? 'success' : 'danger'}
      className="mb-0"
      id={'authorisationBannerAlertBox'}
    >
      {bannerType !== 'checker-danger' && children}
      {renderCustomBannerMessage()}
    </Alert>
  );
};

export default MVAuthorisationBanner;
