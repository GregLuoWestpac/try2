import React from 'react';
import { MVAuthorisationBannerDangerProps } from './types';

const AuthorisationDangerBanner = ({
  authorisationId,
  apiErrorMessage,
}: Omit<MVAuthorisationBannerDangerProps, 'children' | 'bannerType'>) => (
  <>
    <p>
      <strong>Authorisation ID: {authorisationId}</strong> failed during
      fulfilment.
    </p>
    <p>{apiErrorMessage}</p>
    <p>
      You should inform the initiator of this error. If required, they can
      create the request again.
    </p>
  </>
);

export default AuthorisationDangerBanner;
