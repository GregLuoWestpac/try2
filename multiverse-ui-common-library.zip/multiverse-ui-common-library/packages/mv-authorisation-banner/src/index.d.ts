import { AlertProps } from '@westpac/ui';
import { Dispatch } from 'react';
import { NavigateFunction } from 'react-router-dom';

export type MVAuthorisationBannerBaseProps = AlertProps & {
  bannerType:
    | 'maker-success'
    | 'maker-danger'
    | 'checker-success'
    | 'checker-danger';
};

export type MVAuthorisationBannerSuccessProps =
  MVAuthorisationBannerBaseProps & {
    bannerType: 'maker-success';
    apiErrorMessage?: string;
    authorisationId: string;
    sharedData?: Record<string, string>;
    useNavigate: NavigateFunction;
    useGlobalDispatch: Dispatch<unknown>;
  };

export type MVAuthorisationBannerDangerProps =
  MVAuthorisationBannerBaseProps & {
    bannerType: 'maker-danger' | 'checker-danger' | 'checker-success';
    apiErrorMessage?: string;
    authorisationId?: string;
    sharedData?: Record<string, string>;
    useNavigate?: NavigateFunction;
    useGlobalDispatch?: Dispatch<unknown>;
  };

export type MVAuthorisationBannerProps =
  | MVAuthorisationBannerSuccessProps
  | MVAuthorisationBannerDangerProps;

export type AuthorisationBannerLinkProps = {
  sharedData: Record<string, string>;
  useNavigate: NavigateFunction;
  useGlobalDispatch: Dispatch<unknown>;
};

declare const MVAuthorisationBanner: React.FC<MVAuthorisationBannerProps>;
export default MVAuthorisationBanner;
