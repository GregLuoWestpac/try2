import React from 'react';
import AuthrisationBannerLink from './AuthorisationBannerLink';
import { MVAuthorisationBannerSuccessProps } from './types';

const AuthorisationSuccessBanner = ({
  authorisationId,
  sharedData = {},
  useNavigate,
  useGlobalDispatch,
}: Omit<MVAuthorisationBannerSuccessProps, 'children' | 'bannerType'>) => {
  return (
    <>
      <p>Authorisation ID: {authorisationId} </p>
      <p>
        <AuthrisationBannerLink
          sharedData={sharedData}
          useGlobalDispatch={useGlobalDispatch}
          useNavigate={useNavigate}
        />
      </p>
    </>
  );
};

export default AuthorisationSuccessBanner;
