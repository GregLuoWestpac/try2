import { AlertProps } from '@westpac/ui';
import { Dispatch } from 'react';
import { NavigateFunction } from 'react-router-dom';

export enum BannerType {
  MAKER_SUCCESS = 'maker-success',
  MAKER_DANGER = 'maker-danger',
  CHECKER_SUCCESS = 'checker-success',
  CHECKER_DANGER = 'checker-danger',
}

export type MVAuthorisationBannerBaseProps = AlertProps & {
  bannerType: BannerType;
};

export type MVAuthorisationBannerSuccessProps =
  MVAuthorisationBannerBaseProps & {
    bannerType: BannerType.MAKER_SUCCESS;
    apiErrorMessage?: string;
    authorisationId: string;
    sharedData?: Record<string, string>;
    useNavigate: NavigateFunction;
    useGlobalDispatch: Dispatch<unknown>;
  };

export type MVAuthorisationBannerDangerProps =
  MVAuthorisationBannerBaseProps & {
    bannerType:
      | BannerType.MAKER_DANGER
      | BannerType.CHECKER_DANGER
      | BannerType.CHECKER_SUCCESS;
    apiErrorMessage?: string;
    authorisationId?: string;
    sharedData?: Record<string, string>;
    useNavigate?: NavigateFunction;
    useGlobalDispatch?: Dispatch<unknown>;
  };

export type MVAuthorisationBannerProps =
  | MVAuthorisationBannerSuccessProps
  | MVAuthorisationBannerDangerProps;

export type AuthorisationBannerLinkProps = {
  sharedData: Record<string, string>;
  useNavigate: NavigateFunction;
  useGlobalDispatch: Dispatch<unknown>;
};
