# MVAuthorisationBanner Component

`MVAuthorisationBanner` is a flexible React component for displaying authorisation status, success, and error banners in your application. It supports different banner types (maker/checker flows), visual looks (success/danger), and provides conditional rendering based on the specific workflow requirements.

## Installation

```bash
npm install @mesh-tenant-multiverse-ui-common/mv-authorisation-banner
```

## Usage

Import the component and required types:

```tsx
import MVAuthorisationBanner, {
  BannerType,
} from '@mesh-tenant-multiverse-ui-common/mv-authorisation-banner';
```

## Examples

### Maker Success Flow

Shows a success banner with navigation link to track authorisation status:

```tsx
<MVAuthorisationBanner
  bannerType={BannerType.MAKER_SUCCESS}
  authorisationId="AUTH-123456"
  sharedData={sharedData}
  iconSize="medium"
  dismissible={true}
>
  Your request has been sent for authorisation.
</MVAuthorisationBanner>
```

### Checker Danger Flow

Shows an error banner when authorisation fails during fulfillment:

```tsx
<MVAuthorisationBanner
  bannerType={BannerType.CHECKER_DANGER}
  authorisationId="AR240320251030"
  apiErrorMessage="Payment processing failed due to insufficient funds."
  iconSize="large"
  dismissible={false}
/>
```

### Custom Content

You can provide custom content via children prop:

```tsx
<MVAuthorisationBanner
  bannerType={BannerType.MAKER_SUCCESS}
  look={Look.Success}
  authorisationId="AUTH-789012"
  sharedData={sharedData}
>
  <div>
    <h3>Request Submitted Successfully</h3>
    <p>
      Your authorisation request has been forwarded to the appropriate checker.
    </p>
  </div>
</MVAuthorisationBanner>
```

## Props

| Prop                | Type                                                     | Default        | Required      | Description                                                       |
| ------------------- | -------------------------------------------------------- | -------------- | ------------- | ----------------------------------------------------------------- |
| `bannerType`        | `BannerType`                                             | -              | Yes           | The type of banner workflow (`MAKER_SUCCESS` or `CHECKER_DANGER`) |
| `look`              | `Look`                                                   | `Look.Success` | No            | Visual appearance (`Success` or `Danger`)                         |
| `authorisationId`   | `string`                                                 | -              | Conditional\* | The authorisation ID to display                                   |
| `sharedData`        | `object`                                                 | -              | Conditional\* | Data shared across micro-frontends for intent navigation          |
| `apiErrorMessage`   | `string`                                                 | -              | No            | Error message displayed in danger banners                         |
| `iconSize`          | `'xsmall' \| 'small' \| 'medium' \| 'large' \| 'xlarge'` | `'medium'`     | No            | Size of the alert icon                                            |
| `dismissible`       | `boolean`                                                | `true`         | No            | Whether the banner can be dismissed by the user                   |
| `children`          | `React.ReactNode`                                        | -              | No            | Custom content to display in the banner                           |

\*Required when `look` is `Success` and `bannerType` is `MAKER_SUCCESS`

## Banner Types

### BannerType.MAKER_SUCCESS

- **When to use**: After a maker submits a request that requires checker approval
- **Behavior**: Shows success message with navigation link to track authorisation status
- **Required props**: `authorisationId`, `sharedData`, `useGlobalDispatch`, `useNavigate`

### BannerType.CHECKER_DANGER

- **When to use**: When a checker's authorisation fails during fulfillment
- **Behavior**: Shows error message with failure details and user guidance
- **Required props**: `authorisationId`
- **Optional props**: `apiErrorMessage`

## Features

- **TypeScript Support**: Full TypeScript definitions with discriminated unions for type safety
- **Conditional Rendering**: Smart rendering based on banner type and look combination
- **FDC3 Integration**: Built-in support for micro-frontend navigation via FDC3 intents
- **Flexible Styling**: Configurable icon sizes and dismissible behavior
- **Accessibility**: Proper ARIA labels and semantic markup
- **Error Handling**: Comprehensive error display for failed authorisations
- **Responsive Design**: Works across different screen sizes and devices

## Conditional Logic

The component uses conditional rendering based on the combination of `look` and `bannerType`:

- **Success + MAKER_SUCCESS**: Renders success message with authorisation tracking link
- **Danger + CHECKER_DANGER**: Renders error message with failure details and instructions
- **Other combinations**: Returns null (no rendering)

## Testing

The component includes comprehensive test coverage with React Testing Library:

### Test Scenarios Covered:

- ✅ Maker success flow rendering with navigation link
- ✅ Checker danger flow rendering with error messages
- ✅ Custom content rendering via children prop
- ✅ Conditional rendering logic for different banner types
- ✅ Intent handling and navigation functionality
- ✅ Proper DOM structure and accessibility attributes

### Running Tests

```bash
npm run test
```

## Dependencies

- React 16.8+ (hooks support required)
- @westpac/ui (Alert component)
- @mesh-tenant-multiverse-ui-common/mv-utils (Intent handling)

## Browser Support

Supports all modern browsers that support ES6+ and React 16.8+.

## License

MIT
