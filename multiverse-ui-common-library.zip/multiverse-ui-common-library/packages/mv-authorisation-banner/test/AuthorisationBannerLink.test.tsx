import React from 'react';
import '@testing-library/jest-dom';
import { render, fireEvent, screen } from '@testing-library/react';
import AuthorisationBannerLink from '../src/AuthorisationBannerLink';

const mockUseGlobalDispatch = jest.fn();
const mockUseNavigate = jest.fn();
const mockHandleRaiseIntent = jest.fn();
const mockedSharedData = { foo: 'bar' };

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils/src/intents', () => ({
  useHandleRaiseIntent: () => mockHandleRaiseIntent,
}));

// Mock useHandleRaiseIntent hook
jest.mock('../../mv-utils/src/intents', () => ({
  useHandleRaiseIntent: () => mockHandleRaiseIntent,
}));

describe('AuthorisationBannerLink', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders the link and static text', () => {
    render(
      <AuthorisationBannerLink
        useGlobalDispatch={mockUseGlobalDispatch}
        useNavigate={mockUseNavigate}
        sharedData={mockedSharedData}
      />
    );
    expect(
      screen.getByText(/You can track the status from the/i)
    ).toBeInTheDocument();
    expect(screen.getByTestId('authorisation-banner-link')).toBeInTheDocument();
    expect(screen.getByText('Authorisations')).toBeInTheDocument();
    expect(screen.getByText(/page\./i)).toBeInTheDocument();
  });

  it('calls handleRaiseIntent with correct params when link is clicked', () => {
    render(
      <AuthorisationBannerLink
        useGlobalDispatch={mockUseGlobalDispatch}
        useNavigate={mockUseNavigate}
        sharedData={mockedSharedData}
      />
    );
    fireEvent.click(screen.getByTestId('authorisation-banner-link'));
    expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
      intentName: 'ViewGalaxyAuthorisationsWorkflow',
      intentContextName: 'fdc3.nothing',
      targetPath: '/workflowauthorisation',
      data: { ...mockedSharedData },
    });
  });

  it('calls handleRaiseIntent without data props with sharedData is not passed with empty object', () => {
    render(
      <AuthorisationBannerLink
        useGlobalDispatch={mockUseGlobalDispatch}
        useNavigate={mockUseNavigate}
        sharedData={{}}
      />
    );
    fireEvent.click(screen.getByTestId('authorisation-banner-link'));
    expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
      intentName: 'ViewGalaxyAuthorisationsWorkflow',
      intentContextName: 'fdc3.nothing',
      targetPath: '/workflowauthorisation',
    });
  });
});
