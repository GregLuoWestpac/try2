import React from 'react';
import '@testing-library/jest-dom';
import { render, screen } from '@testing-library/react';
import MVAuthorisationBanner from '../src/MVAuthorisationBanner';
import { BannerType } from '../src/types';

const mockUseGlobalDispatch = jest.fn();
const mockUseNavigate = jest.fn();
const mockedSharedData = { foo: 'bar' };
const mockAuthorisationId = 'AUTH-MOCK-ID';
const mockApiErrorMessage = 'API Error occurred';

describe('MVAuthorisationBanner', () => {
  describe('validate maker action flow', () => {
    const mockMakerSuccessInnerContent =
      'Your request has been sent for authorisation.';
    const makerSuccessDefaultProps = {
      bannerType: BannerType.MAKER_SUCCESS,
      apiErrorMessage: mockApiErrorMessage,
      authorisationId: mockAuthorisationId,
      sharedData: mockedSharedData,
      useGlobalDispatch: mockUseGlobalDispatch,
      useNavigate: mockUseNavigate,
    };

    beforeEach(() => {
      render(
        <MVAuthorisationBanner {...makerSuccessDefaultProps}>
          <span>{mockMakerSuccessInnerContent}</span>
        </MVAuthorisationBanner>
      );
    });

    it('should render with children, authorisation id and a link', () => {
      const link = screen.getByTestId('authorisation-banner-link');

      expect(
        screen.getByText(mockMakerSuccessInnerContent)
      ).toBeInTheDocument();

      expect(screen.getByText(/AUTH-MOCK-ID/i)).toBeInTheDocument();

      expect(link).toBeInTheDocument();
    });
  });

  describe('validate checker "Authroise" fullfilment success flow', () => {
    const mockCheckerSuccessAuthoriseInnerContent = (
      <span>You have authorised Authorisation ID: AR240320251030</span>
    );
    const checkerSuccessAuthroiseProps = {
      bannerType: BannerType.CHECKER_SUCCESS as const,
      authorisationId: mockAuthorisationId,
    };

    beforeEach(() => {
      render(
        <MVAuthorisationBanner {...checkerSuccessAuthroiseProps}>
          {mockCheckerSuccessAuthoriseInnerContent}
        </MVAuthorisationBanner>
      );
    });
    it('should render the "Authorise" message', () => {
      expect(
        screen.getByText(
          /You have authorised Authorisation ID: AR240320251030/i
        )
      ).toBeInTheDocument();
    });

    it('should not render custom success or error message', () => {
      expect(screen.queryByText(/AUTH-MOCK-ID/i)).not.toBeInTheDocument();

      expect(
        screen.queryByTestId('authorisation-banner-link')
      ).not.toBeInTheDocument();
    });
  });

  describe('validate checker "Rejection" success flow', () => {
    const mockCheckerSuccessRejectionInnerContent = (
      <span>You have rejected Authorisation ID: AR240320251030</span>
    );
    const checkerSuccessRejectedDefaultProps = {
      bannerType: BannerType.CHECKER_SUCCESS as const,
      authorisationId: mockAuthorisationId,
    };

    beforeEach(() => {
      render(
        <MVAuthorisationBanner {...checkerSuccessRejectedDefaultProps}>
          {mockCheckerSuccessRejectionInnerContent}
        </MVAuthorisationBanner>
      );
    });

    it('should render the "Authorise" message', () => {
      expect(
        screen.getByText(/You have rejected Authorisation ID: AR240320251030/i)
      ).toBeInTheDocument();
    });

    it('should not render custom success or error message', () => {
      expect(screen.queryByText(/AUTH-MOCK-ID/i)).not.toBeInTheDocument();

      expect(
        screen.queryByTestId('authorisation-banner-link')
      ).not.toBeInTheDocument();
    });
  });

  describe('validate checker "Authorise" fullfilment failure flow', () => {
    const makerSuccessDefaultProps = {
      bannerType: BannerType.CHECKER_DANGER as const,
      look: 'danger' as const,
      apiErrorMessage: mockApiErrorMessage,
      authorisationId: mockAuthorisationId,
    };

    beforeEach(() => {
      render(
        <MVAuthorisationBanner {...makerSuccessDefaultProps}>
          ignore this content
        </MVAuthorisationBanner>
      );
    });

    it('should render the error message', () => {
      expect(screen.getByText(/AUTH-MOCK-ID/i)).toBeInTheDocument();
      expect(screen.getByText(/failed during fulfilment/i)).toBeInTheDocument();
      expect(screen.getByText(/API Error occurred/i)).toBeInTheDocument();
      expect(
        screen.getByText(
          /You should inform the initiator of this error. If required, they can create the request again/i
        )
      ).toBeInTheDocument();
    });

    it('should not render the children content for bannerType "checker-danger"', () => {
      expect(
        screen.queryByText(/ignore this content/i)
      ).not.toBeInTheDocument();
    });
  });

  describe('validate for look other than "success" or "dannger"', () => {
    it('should render the correct inner content look ', () => {
      render(
        <MVAuthorisationBanner
          bannerType={BannerType.CHECKER_SUCCESS}
          look="info"
          authorisationId={mockAuthorisationId}
        >
          <span>Success content</span>
        </MVAuthorisationBanner>
      );

      expect(screen.getByText(/Success content/i)).toBeInTheDocument();
    });
  });

  describe('iconSize and dismissible props', () => {
    it('should render with default iconSize and dismissible values', () => {
      const { container } = render(
        <MVAuthorisationBanner
          bannerType={BannerType.MAKER_SUCCESS}
          look="success"
          authorisationId={mockAuthorisationId}
          sharedData={mockedSharedData}
          useGlobalDispatch={mockUseGlobalDispatch}
          useNavigate={mockUseNavigate}
        >
          <span>Test content</span>
        </MVAuthorisationBanner>
      );

      // Verify component renders (default iconSize: 'medium', dismissible: true)
      expect(
        container.querySelector('#authorisationBannerAlertBox')
      ).toBeInTheDocument();
      expect(screen.getByText(/Test content/i)).toBeInTheDocument();
    });
  });
});
