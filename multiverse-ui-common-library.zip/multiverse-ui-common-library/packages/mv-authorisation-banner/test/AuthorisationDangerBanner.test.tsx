import React from 'react';
import '@testing-library/jest-dom';
import { render, screen } from '@testing-library/react';
import AuthorisationDangerBanner from '../src/AuthorisationDangerBanner';

const mockAuthorisationId = 'AUTH123';
const mockApiErrorMessage = 'Something went wrong!';
describe('AuthorisationDangerBanner', () => {
  beforeEach(() => {
    render(
      <AuthorisationDangerBanner
        authorisationId={mockAuthorisationId}
        apiErrorMessage={mockApiErrorMessage}
      />
    );
  });

  it('renders the authorisation ID and error message', () => {
    expect(screen.getByText(/AUTH123/i)).toBeInTheDocument();
    expect(screen.getByText(mockApiErrorMessage)).toBeInTheDocument();
  });

  it('renders the user instruction', () => {
    expect(
      screen.getByText(/You should inform the initiator of this error/i)
    ).toBeInTheDocument();
    expect(
      screen.getByText(/they can create the request again/i)
    ).toBeInTheDocument();
  });
});
