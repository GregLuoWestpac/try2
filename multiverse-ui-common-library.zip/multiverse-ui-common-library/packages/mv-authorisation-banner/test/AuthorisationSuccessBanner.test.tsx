import React from 'react';
import '@testing-library/jest-dom';
import { render, screen } from '@testing-library/react';
import AuthorisationSuccessBanner from '../src/AuthorisationSuccessBanner';

const mockUseGlobalDispatch = jest.fn();
const mockUseNavigate = jest.fn();
const mockAuthorisationId = 'AR-MOCK-IN';

describe('AuthorisationSuccessBanner', () => {
  describe('with sharedData', () => {
    beforeEach(() => {
      const sharedData = { foo: 'bar' };
      render(
        <AuthorisationSuccessBanner
          authorisationId={mockAuthorisationId}
          sharedData={sharedData}
          useGlobalDispatch={mockUseGlobalDispatch}
          useNavigate={mockUseNavigate}
        />
      );
    });

    it('renders the authorisation ID', () => {
      expect(
        screen.getByText(/Authorisation ID: AR-MOCK-IN/)
      ).toBeInTheDocument();
    });

    it('renders AuthrisationBannerLink', () => {
      const link = screen.getByTestId('authorisation-banner-link');
      expect(link).toBeInTheDocument();
    });
  });

  describe('without sharedData', () => {
    beforeEach(() => {
      render(
        <AuthorisationSuccessBanner
          authorisationId={mockAuthorisationId}
          useGlobalDispatch={mockUseGlobalDispatch}
          useNavigate={mockUseNavigate}
        />
      );
    });

    it('renders the authorisation ID', () => {
      expect(
        screen.getByText(/Authorisation ID: AR-MOCK-IN/)
      ).toBeInTheDocument();
    });
  });
});
