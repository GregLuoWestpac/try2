# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.219.10](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.9...v1.219.10) (2026-01-19)

### 💥 Bug Fixes

- added previous classes used | ART-84954 ([0a1c9cd](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/0a1c9cd845417ef2739df051b355ecb4b25df504))

## [1.219.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.218.0...v1.219.0) (2025-12-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-authorisation-banner

## [1.217.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.217.0...v1.217.1) (2025-12-17)

### 💥 Bug Fixes

- added bottom padding for success banner | ART-84954 ([94dff18](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/94dff18bf1730601fa62f2740ca5e4488541266a))

## [1.205.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.205.4...v1.205.5) (2025-10-28)

### 💥 Bug Fixes

- remove outline offset | ART-84954 ([3cd4aa4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3cd4aa4b998b21c0234a91b043ea40b6dd618ef6))
- set leading to 0 to reduce line height | ART-84954 ([0669480](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/0669480e0f69f9b191aa58190cb6c4ea6c6c6500))

## [1.205.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.205.1...v1.205.2) (2025-10-27)

### 💥 Bug Fixes

- change to h-fit to remove the extra whitespace | ART-84954 ([f8802e7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f8802e74c8bb64cc67ada871210e6a4c1a56ebb6))

## [1.205.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.205.0...v1.205.1) (2025-10-27)

### 💥 Bug Fixes

- remove h-0 from link | ART-84954 ([4d5b397](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4d5b39704e538e94d7391b70c4055d95a13cf9f7))

## [1.190.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.189.0...v1.190.0) (2025-10-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-authorisation-banner

## [1.184.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.184.1...v1.184.2) (2025-09-19)

### 💥 Bug Fixes

- downgrade version | ART-53163 ([87deb20](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/87deb20285d49ec218ba28b4692a38e0080c3092))
- fix failing tests | ART-53163 ([6e8c510](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/6e8c510bab6924123e91ebd3655c64a93275abe5))
- fix issues | ART-53163 ([4bd89b6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4bd89b62cbf9c809c6f8264a37ae301e0a9a946e))
- remove console log | ART-53163 ([54165ac](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/54165acb831cff66d1649b4d7551e86d51f49e44))
- update types | ART-53163 ([09d237d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/09d237daa923ed605160e3039655f8c3585bdf09))

## [1.182.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.181.3...v1.182.0) (2025-09-08)

### 🚀 Features

- added iconSize and dismissible to alert component | ART-68971 ([2353b36](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2353b3667dfb57d1d91a0016404997256454e72e))
- added uni test case | ART-68971 ([44ca252](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/44ca2522aacb4f1bff75299e29f93e737e5e6cfe))
- authorisation banner component | ART-68971 ([8d55638](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8d55638bb38ac4a3afdbeef06b30560a2831d4e8))
