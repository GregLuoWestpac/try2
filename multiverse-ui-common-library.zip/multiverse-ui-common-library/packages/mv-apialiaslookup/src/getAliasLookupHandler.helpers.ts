import { v4 } from 'uuid';
import {
  DownstreamServiceResponse,
  DownstreamServiceResponseData,
  handleApiService,
  PathParams,
  SetDownstreamParamsWithPath,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import {
  AliasLookupEXPRequestBody,
  ExpApiResponseEntities,
} from './types/getAliasLookupHandler.types';

import {
  AliasLookupByBeneIdEXPRequestBody,
  ExpApiResponseByBeneIdEntities,
} from './types/getAliasLookupByBeneIdHandler.types';
import { PAYID_TYPE } from '@mesh-tenant-multiverse-ui-common/mv-constants';

export const transformAliasLookupExpResponse = (
  response: DownstreamServiceResponseData
): ExpApiResponseEntities => ({
  aliasLookup: [
    {
      id: v4(),
      aliasType: response.data.aliasType as PAYID_TYPE,
      name: response.data.name as string,
      resolutionDateTime: response.data.resolutionDateTime as string,
      returnCode: response.data.returnCode,
    },
  ],
});

export const transformAliasLookupByBeneIdExpResponse = (
  response: DownstreamServiceResponseData
): ExpApiResponseByBeneIdEntities => ({
  aliasLookupByBeneId: [
    {
      id: v4(),
      aliasType: response.data.aliasType as PAYID_TYPE,
      name: response.data.name as string,
      resolutionDateTime: response.data.resolutionDateTime as string,
      returnCode: response.data.returnCode,
    },
  ],
});

export const setParamsForPaymentCounter: SetDownstreamParamsWithPath = (
  inputHeaders,
  res,
  body,
  appConfig,
  query,
  path
) => {
  return {
    header: inputHeaders,
    query,
    path,
    body,
  };
};

export const payIDLimitCounter = async (
  apiClient,
  res,
  req,
  userId,
  sessionId?
) => {
  const isGetSessionCounter = apiClient.name === 'getSessionIdCounter';
  const isGetPaymentCounter = apiClient.name === 'getPaymentCounter';
  const pathParams: PathParams = {
    name: 'PAYID',
    customerId: userId,
    ...(!isGetPaymentCounter && { sessionId }),
  };
  const bodyParams =
    isGetSessionCounter || isGetPaymentCounter ? undefined : {};
  const queryParams = undefined;

  const { data: paymentCounterDownstreamResponse }: DownstreamServiceResponse =
    await handleApiService({
      req,
      res,
      apiClient,
      setDownstreamParams: (apiHeaders, response, request, appConfig) => {
        const paymentCounterParams = setParamsForPaymentCounter(
          apiHeaders,
          response,
          bodyParams,
          appConfig,
          queryParams,
          pathParams
        );
        return paymentCounterParams;
      },
    });
  return paymentCounterDownstreamResponse.data;
};

export const validateAliasLookupRequestBody = (
  aliasLookupRequestBody: AliasLookupEXPRequestBody
) => {
  const { id, authBIC8, email, phone, orgn, aubn } = aliasLookupRequestBody;

  const hasId = !!id;
  const hasAuthBIC8 = !!authBIC8;
  const hasPayID = !!(email || phone || orgn || aubn);

  // Must have either id OR (authBIC8 AND at least one PayID)
  if (hasId && !hasPayID) {
    return { isValid: true };
  }

  if (!hasId && hasAuthBIC8 && hasPayID) {
    return { isValid: true };
  }

  return {
    isValid: false,
  };
};

export const validateAliasLookupByBeneIdRequestBody = (
  aliasLookupByBeneIdRequestBody: AliasLookupByBeneIdEXPRequestBody
) => {
  const { id } = aliasLookupByBeneIdRequestBody;

  const hasId = !!id;
  if (hasId) {
    return { isValid: true };
  }

  return {
    isValid: false,
  };
};
