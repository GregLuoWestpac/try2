import {
  getSafiDecisionForAliasLookup,
  getPayIDType,
} from '../getSafiDecisionForAliasLookup';
import * as apiUtils from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  handleApiService: jest.fn(),
}));

describe('getSafiDecisionForAliasLookup', () => {
  let mockReq: any;
  let mockRes: any;
  let mockParams: any;

  beforeEach(() => {
    jest.clearAllMocks();

    mockReq = {
      get: jest.fn((header: string) => {
        const headers: Record<string, string> = {
          'user-agent': 'Mozilla/5.0',
          accept: 'text/html',
          referer: 'https://example.com',
          'accept-encoding': 'gzip',
          'accept-language': 'en-US',
          'accept-charset': 'utf-8',
          'x-devicefingerprint': 'test-fingerprint',
        };
        return headers[header];
      }),
    };

    mockRes = {
      locals: {
        logger: {
          info: jest.fn(),
          error: jest.fn(),
        },
        apiHeaders: {
          'x-userId': 'user-123',
          'x-appCorrelationId': 'corr-456',
        },
        Cookie: {
          get: jest.fn(),
          set: jest.fn(),
        },
        sessionIndex: 'session-789',
        brandSilo: 'STG',
        xBrandId: 'STG',
      },
    };

    mockParams = {
      analyseApiClient: jest.fn(),
      currentSessionCounter: 3,
      currentUserCounter: 10,
      aliasId: 'test@example.com',
      aliasType: 'EMAL',
      payIdSource: 'WEB',
      ID: {
        generate: jest.fn(() => 'generated-id'),
      },
      getIpAddress: jest.fn(() => '192.168.1.1'),
      getDeviceFingerPrint: jest.fn(() => 'device-fp-123'),
      ALLOWED_COOKIES: {
        W1AddnAuthorisation: 'W1AddnAuthorisation',
      },
    };
  });

  describe('getPayIDType', () => {
    it('should return MOBILE for TELI alias type', () => {
      expect(getPayIDType('TELI')).toBe('MOBILE');
    });

    it('should return EMAIL for EMAL alias type', () => {
      expect(getPayIDType('EMAL')).toBe('EMAIL');
    });

    it('should return ABN for AUBN alias type', () => {
      expect(getPayIDType('AUBN')).toBe('ABN');
    });

    it('should return ORGN for ORGN alias type', () => {
      expect(getPayIDType('ORGN')).toBe('ORGN');
    });

    it('should return undefined for unknown types', () => {
      expect(getPayIDType('UNKNOWN')).toBeUndefined();
      expect(getPayIDType('')).toBeUndefined();
    });
  });

  describe('SAFI Decision Flow', () => {
    it('should return true when SAFI returns ALLOW', async () => {
      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: {
          data: {
            analyseResult: 'ALLOW',
            deviceToken: null,
          },
        },
      });

      const result = await getSafiDecisionForAliasLookup(
        mockReq,
        mockRes,
        mockParams
      );

      expect(result).toBe(true);
      expect(mockRes.locals.logger.info).toHaveBeenCalledWith(
        'SAFI decision for PayID alias lookup - START'
      );
      expect(mockRes.locals.logger.info).toHaveBeenCalledWith(
        'SAFI decision for PayID alias lookup - END'
      );
    });

    it('should return false when SAFI returns DENY', async () => {
      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: {
          data: {
            analyseResult: 'DENY',
            deviceToken: null,
          },
        },
      });

      const result = await getSafiDecisionForAliasLookup(
        mockReq,
        mockRes,
        mockParams
      );

      expect(result).toBe(false);
    });

    it('should return false for any non-ALLOW result', async () => {
      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: {
          data: {
            analyseResult: 'CHALLENGE',
            deviceToken: null,
          },
        },
      });

      const result = await getSafiDecisionForAliasLookup(
        mockReq,
        mockRes,
        mockParams
      );

      expect(result).toBe(false);
    });
  });

  describe('Device Token Handling', () => {
    it('should set cookie when deviceToken is returned', async () => {
      const mockDeviceToken = 'new-device-token-123';
      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: {
          data: {
            analyseResult: 'ALLOW',
            deviceToken: mockDeviceToken,
          },
        },
      });

      await getSafiDecisionForAliasLookup(mockReq, mockRes, mockParams);

      expect(mockRes.locals.Cookie.set).toHaveBeenCalledWith(
        'W1AddnAuthorisation',
        mockDeviceToken,
        'STG',
        expect.objectContaining({
          expires: expect.any(Date),
        })
      );

      // Verify cookie expiry is ~1 year
      const setCookieCall = mockRes.locals.Cookie.set.mock.calls[0];
      const expiryDate = setCookieCall[3].expires;
      const now = new Date();
      const daysDiff = Math.floor(
        (expiryDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
      );
      expect(daysDiff).toBeGreaterThanOrEqual(364);
      expect(daysDiff).toBeLessThanOrEqual(365);
    });

    it('should not set cookie when deviceToken is null', async () => {
      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: {
          data: {
            analyseResult: 'ALLOW',
            deviceToken: null,
          },
        },
      });

      await getSafiDecisionForAliasLookup(mockReq, mockRes, mockParams);

      expect(mockRes.locals.Cookie.set).not.toHaveBeenCalled();
    });
  });

  describe('Request Body Construction', () => {
    it('should construct correct SAFI request body', async () => {
      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: {
          data: {
            analyseResult: 'ALLOW',
          },
        },
      });

      await getSafiDecisionForAliasLookup(mockReq, mockRes, mockParams);

      expect(apiUtils.handleApiService).toHaveBeenCalledWith({
        req: mockReq,
        res: mockRes,
        apiClient: mockParams.analyseApiClient,
        setDownstreamParams: expect.any(Function),
        requestBody: expect.objectContaining({
          eventType: 'CLIENT_DEFINED',
          clientDefinedEventType: 'PAYID_LOOKUP',
          tenantId: 'WPACW1',
          userAgentType: 'BROWSER',
          eventMetaData: expect.arrayContaining([
            expect.objectContaining({ name: 'COUNTER', value: '3' }),
            expect.objectContaining({ name: 'COUNTER_24HOUR', value: '10' }),
            expect.objectContaining({ name: 'PAYEEPAYIDTYPE', value: 'EMAIL' }),
            expect.objectContaining({
              name: 'PAYEEPAYIDVALUE',
              value: 'test@example.com',
            }),
            expect.objectContaining({ name: 'SOURCE', value: 'WEB' }),
          ]),
        }),
      });
    });

    it('should include browser information when devicefingerprint header present', async () => {
      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: {
          data: {
            analyseResult: 'ALLOW',
          },
        },
      });

      await getSafiDecisionForAliasLookup(mockReq, mockRes, mockParams);

      const requestBody = (apiUtils.handleApiService as jest.Mock).mock
        .calls[0][0].requestBody;
      expect(requestBody.browserInformation).toEqual({
        userAgent: 'Mozilla/5.0',
        httpAccept: 'text/html',
        httpReferer: 'https://example.com',
        httpAcceptedEncoding: 'gzip',
        httpAcceptedLanguage: 'en-US',
        httpAcceptedCharacters: 'utf-8',
      });
    });

    it('should omit browser information when devicefingerprint header absent', async () => {
      mockReq.get = jest.fn((header: string) => {
        if (header === 'x-devicefingerprint') return undefined;
        return 'some-value';
      });

      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: {
          data: {
            analyseResult: 'ALLOW',
          },
        },
      });

      await getSafiDecisionForAliasLookup(mockReq, mockRes, mockParams);

      const requestBody = (apiUtils.handleApiService as jest.Mock).mock
        .calls[0][0].requestBody;
      expect(requestBody.browserInformation).toEqual({});
    });

    it('should include device information', async () => {
      mockRes.locals.Cookie.get.mockReturnValue('existing-device-token');

      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: {
          data: {
            analyseResult: 'ALLOW',
          },
        },
      });

      await getSafiDecisionForAliasLookup(mockReq, mockRes, mockParams);

      const requestBody = (apiUtils.handleApiService as jest.Mock).mock
        .calls[0][0].requestBody;
      expect(requestBody.device).toEqual({
        IPAddress: '192.168.1.1',
        deviceFingerPrint: 'device-fp-123',
        deviceToken: 'existing-device-token',
      });
    });
  });

  describe('Downstream Params', () => {
    it('should override x-originatingSystemId for SAFI', async () => {
      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: {
          data: {
            analyseResult: 'ALLOW',
          },
        },
      });

      await getSafiDecisionForAliasLookup(mockReq, mockRes, mockParams);

      const setDownstreamParams = (apiUtils.handleApiService as jest.Mock).mock
        .calls[0][0].setDownstreamParams;
      const result = setDownstreamParams({ 'x-original': 'value' }, mockRes, {
        test: 'body',
      });

      expect(result.header['x-originatingSystemId']).toBe('A014A6');
      expect(result.header['x-original']).toBe('value');
      expect(result.query.brandSilo).toBe('STG');
      expect(result.query.pageSize).toBe('0');
    });
  });
});
