import { validateAliasLookupRequestBody } from '../getAliasLookupHandler.helpers';
import { AuthBIC8 } from '../types/getAliasLookupHandler.types';

describe('validateAliasLookupRequestBody', () => {
  describe('Valid requests', () => {
    it('should validate request with only id', () => {
      const result = validateAliasLookupRequestBody({
        id: 'beneficiary-123',
      });
      expect(result.isValid).toBe(true);
    });

    it('should validate request with authBIC8 and email', () => {
      const result = validateAliasLookupRequestBody({
        authBIC8: AuthBIC8.WPACAU3S,
        email: 'test@example.com',
      });
      expect(result.isValid).toBe(true);
    });

    it('should validate request with authBIC8 and phone', () => {
      const result = validateAliasLookupRequestBody({
        authBIC8: AuthBIC8.WPACAU3S,
        phone: '+61412345678',
      });
      expect(result.isValid).toBe(true);
    });

    it('should validate request with authBIC8 and orgn', () => {
      const result = validateAliasLookupRequestBody({
        authBIC8: AuthBIC8.WPACAU3S,
        orgn: 'ORG123',
      });
      expect(result.isValid).toBe(true);
    });

    it('should validate request with authBIC8 and aubn', () => {
      const result = validateAliasLookupRequestBody({
        authBIC8: AuthBIC8.WPACAU3S,
        aubn: '12345678901',
      });
      expect(result.isValid).toBe(true);
    });

    it('should validate request with authBIC8 and multiple PayID fields', () => {
      const result = validateAliasLookupRequestBody({
        authBIC8: AuthBIC8.WPACAU3S,
        email: 'test@example.com',
        phone: '+61412345678',
      });
      expect(result.isValid).toBe(true);
    });
  });

  describe('Invalid requests', () => {
    it('should invalidate empty request', () => {
      const result = validateAliasLookupRequestBody({});
      expect(result.isValid).toBe(false);
    });

    it('should invalidate request with only authBIC8', () => {
      const result = validateAliasLookupRequestBody({
        authBIC8: AuthBIC8.WPACAU3S,
      });
      expect(result.isValid).toBe(false);
    });

    it('should invalidate request with only email (no authBIC8)', () => {
      const result = validateAliasLookupRequestBody({
        email: 'test@example.com',
      });
      expect(result.isValid).toBe(false);
    });

    it('should validate request with id and authBIC8 (both modes allowed)', () => {
      const result = validateAliasLookupRequestBody({
        id: 'beneficiary-123',
        authBIC8: AuthBIC8.WPACAU3S,
      });
      // Note: Based on current logic, id alone is valid, so this passes
      expect(result.isValid).toBe(true);
    });

    it('should invalidate request with id and PayID fields', () => {
      const result = validateAliasLookupRequestBody({
        id: 'beneficiary-123',
        email: 'test@example.com',
      });
      expect(result.isValid).toBe(false);
    });

    it('should invalidate request with all fields', () => {
      const result = validateAliasLookupRequestBody({
        id: 'beneficiary-123',
        authBIC8: AuthBIC8.WPACAU3S,
        email: 'test@example.com',
      });
      expect(result.isValid).toBe(false);
    });
  });
});
