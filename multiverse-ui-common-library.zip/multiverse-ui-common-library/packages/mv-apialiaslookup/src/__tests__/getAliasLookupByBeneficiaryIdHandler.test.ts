import { getAliasLookupByBeneficiaryIdHandler } from '../getAliasLookupByBeneficiaryIdHandler';
import * as apiUtils from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  handleControllerError: jest.fn(),
  handleApiService: jest.fn(),
  APIClientError: class APIClientError extends Error {},
  STATUS_CODES: {
    OK: 200,
  },
  normaliseData: jest.fn((type, data) => ({ normalised: data })),
}));

describe('getAliasLookupByBeneficiaryIdHandler', () => {
  let mockReq: any;
  let mockRes: any;
  let mockNext: jest.Mock;
  let mockControllerParams: any;

  beforeEach(() => {
    jest.clearAllMocks();

    mockReq = {
      body: {
        id: 'beneficiary-123',
      },
    };

    mockRes = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      locals: {
        logger: {
          info: jest.fn(),
          error: jest.fn(),
        },
      },
    };

    mockNext = jest.fn();

    mockControllerParams = {
      normalise: {
        aliasLookup: jest.fn(data => data),
      },
      paymentAliasResolutionV2Services: {
        postResolutionView: jest.fn(),
      },
      beneficiaryManagementV1Services: {
        getBeneficiaryDetail: jest.fn(),
      },
    };
  });

  describe('Successful Flow', () => {
    it('should fetch beneficiary details and perform alias lookup', async () => {
      const mockBeneficiaryData = {
        data: {
          account: {
            payIDValue: 'test@example.com',
            payIDType: 'EMAIL',
          },
        },
      };

      const mockAliasLookupData = {
        data: {
          id: '1',
          name: 'John Doe',
          accountNumber: '123456',
        },
      };

      (apiUtils.handleApiService as jest.Mock)
        .mockResolvedValueOnce({ data: mockBeneficiaryData })
        .mockResolvedValueOnce({ data: mockAliasLookupData });

      await getAliasLookupByBeneficiaryIdHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      // Verify getBeneficiaryDetail was called
      expect(apiUtils.handleApiService).toHaveBeenNthCalledWith(1, {
        req: mockReq,
        res: mockRes,
        apiClient:
          mockControllerParams.beneficiaryManagementV1Services
            .getBeneficiaryDetail,
        pathParams: { id: 'beneficiary-123' },
        reqMethod: 'GET',
      });

      // Verify postResolutionView was called
      expect(apiUtils.handleApiService).toHaveBeenNthCalledWith(2, {
        req: mockReq,
        res: mockRes,
        apiClient:
          mockControllerParams.paymentAliasResolutionV2Services
            .postResolutionView,
        requestBody: {
          aliasId: 'test@example.com',
          aliasType: 'EMAIL',
          authBIC8: 'WPACAU3S',
        },
      });

      expect(mockRes.status).toHaveBeenCalledWith(200);
      expect(mockRes.json).toHaveBeenCalled();
    });

    it('should handle different PayID types', async () => {
      const mockBeneficiaryData = {
        data: {
          account: {
            payIDValue: '+61412345678',
            payIDType: 'MOBILE',
          },
        },
      };

      const mockAliasLookupData = {
        data: { id: '1' },
      };

      (apiUtils.handleApiService as jest.Mock)
        .mockResolvedValueOnce({ data: mockBeneficiaryData })
        .mockResolvedValueOnce({ data: mockAliasLookupData });

      await getAliasLookupByBeneficiaryIdHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      expect(apiUtils.handleApiService).toHaveBeenNthCalledWith(2, {
        req: mockReq,
        res: mockRes,
        apiClient:
          mockControllerParams.paymentAliasResolutionV2Services
            .postResolutionView,
        requestBody: {
          aliasId: '+61412345678',
          aliasType: 'MOBILE',
          authBIC8: 'WPACAU3S',
        },
      });
    });
  });

  describe('Error Handling', () => {
    it('should handle getBeneficiaryDetail errors', async () => {
      const mockError = new Error('Beneficiary not found');
      (apiUtils.handleApiService as jest.Mock).mockRejectedValue(mockError);

      await getAliasLookupByBeneficiaryIdHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      expect(apiUtils.handleControllerError).toHaveBeenCalledWith({
        error: mockError,
        res: mockRes,
        logger: mockRes.locals.logger,
      });
      expect(mockNext).toHaveBeenCalledWith(mockError);
    });

    it('should handle postResolutionView errors', async () => {
      const mockBeneficiaryData = {
        data: {
          account: {
            payIDValue: 'test@example.com',
            payIDType: 'EMAIL',
          },
        },
      };
      const mockError = new Error('Resolution failed');

      (apiUtils.handleApiService as jest.Mock)
        .mockResolvedValueOnce({ data: mockBeneficiaryData })
        .mockRejectedValueOnce(mockError);

      await getAliasLookupByBeneficiaryIdHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      expect(apiUtils.handleControllerError).toHaveBeenCalledWith({
        error: mockError,
        res: mockRes,
        logger: mockRes.locals.logger,
      });
      expect(mockNext).toHaveBeenCalledWith(mockError);
    });
  });

  describe('Transform Logic', () => {
    it('should correctly transform beneficiary response to alias lookup request', async () => {
      const mockBeneficiaryData = {
        data: {
          account: {
            payIDValue: 'business@example.com',
            payIDType: 'EMAIL',
            otherField: 'should-be-ignored',
          },
          otherData: 'not-needed',
        },
      };

      const mockAliasLookupData = {
        data: { id: '1' },
      };

      (apiUtils.handleApiService as jest.Mock)
        .mockResolvedValueOnce({ data: mockBeneficiaryData })
        .mockResolvedValueOnce({ data: mockAliasLookupData });

      await getAliasLookupByBeneficiaryIdHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      const secondCall = (apiUtils.handleApiService as jest.Mock).mock
        .calls[1][0];
      expect(secondCall.requestBody).toEqual({
        aliasId: 'business@example.com',
        aliasType: 'EMAIL',
        authBIC8: 'WPACAU3S',
      });
    });
  });
});
