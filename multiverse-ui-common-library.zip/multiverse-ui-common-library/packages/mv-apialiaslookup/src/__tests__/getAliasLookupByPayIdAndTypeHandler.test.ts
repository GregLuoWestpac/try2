import { getAliasLookupByPayIdAndTypeHandler } from '../getAliasLookupByPayIdAndTypeHandler';
import * as apiUtils from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { LIMIT_EXCEEEDED_ERROR } from '../constants';
import { AuthBIC8 } from '../types/getAliasLookupHandler.types';

// Mock dependencies
jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  handleControllerError: jest.fn(),
  handleApiService: jest.fn(),
  APIClientError: class APIClientError extends Error {},
  STATUS_CODES: {
    OK: 200,
    BAD_REQUEST: 400,
    UNAUTHORIZED: 401,
  },
  normaliseData: jest.fn((type, data) => ({ normalised: data })),
  jwtDecode: jest.fn(),
}));

jest.mock('../getAliasLookupHandler.helpers', () => ({
  ...jest.requireActual('../getAliasLookupHandler.helpers'),
  payIDLimitCounter: jest.fn(),
}));

jest.mock('../getSafiDecisionForAliasLookup', () => ({
  getSafiDecisionForAliasLookup: jest.fn(),
}));

import { payIDLimitCounter } from '../getAliasLookupHandler.helpers';
import { getSafiDecisionForAliasLookup } from '../getSafiDecisionForAliasLookup';

describe('getAliasLookupByPayIdAndTypeHandler', () => {
  let mockReq: any;
  let mockRes: any;
  let mockNext: jest.Mock;
  let mockControllerParams: any;

  beforeEach(() => {
    jest.clearAllMocks();

    mockReq = {
      body: {
        authBIC8: AuthBIC8.WPACAU3S,
        email: 'test@example.com',
      },
      get: jest.fn(() => 'test-value'),
    };

    mockRes = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      locals: {
        logger: {
          info: jest.fn(),
          error: jest.fn(),
        },
        apiHeaders: {
          'x-access-token': 'valid-jwt-token',
        },
        Cookie: {
          get: jest.fn(),
          set: jest.fn(),
        },
        sessionIndex: 'session-123',
      },
    };

    mockNext = jest.fn();

    mockControllerParams = {
      normalise: {
        aliasLookup: jest.fn(data => data),
      },
      paymentAliasResolutionV2Services: {
        postResolutionView: jest.fn(),
      },
      capCustsvcmgtCustsecyverifctnAdaptvauthV2Services: {
        analyse: jest.fn(),
      },
      channelPaymentUtilsV1Services: {
        getSessionIdCounter: { name: 'getSessionIdCounter' },
        incrementSessionIdCounter: { name: 'incrementSessionIdCounter' },
        getPaymentCounter: { name: 'getPaymentCounter' },
      },
      payIdSource: 'TEST_SOURCE',
      RUNTIME: {
        isLocal: jest.fn(() => false),
      },
      ID: {
        generate: jest.fn(() => 'test-id'),
      },
      getIpAddress: jest.fn(() => '127.0.0.1'),
      getDeviceFingerPrint: jest.fn(() => 'fingerprint-123'),
      ALLOWED_COOKIES: {
        W1AddnAuthorisation: 'W1AddnAuthorisation',
      },
    };
  });

  describe('JWT Decoding', () => {
    it('should decode JWT token successfully in non-local environment', async () => {
      const mockDecoded = { userId: 'user-123', sessionIndex: 'session-456' };
      (apiUtils.jwtDecode as jest.Mock).mockReturnValue(mockDecoded);
      (payIDLimitCounter as jest.Mock).mockResolvedValue({
        counters: [{ session: { counter: 5 }, counter: 10 }],
      });
      (getSafiDecisionForAliasLookup as jest.Mock).mockResolvedValue(true);
      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: { data: { id: '1', name: 'Test' } },
      });
      (payIDLimitCounter as jest.Mock)
        .mockResolvedValueOnce({
          counters: [{ session: { counter: 5 }, counter: 10 }],
        })
        .mockResolvedValueOnce({ counters: [{ counter: 6 }] });

      await getAliasLookupByPayIdAndTypeHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      expect(apiUtils.jwtDecode).toHaveBeenCalledWith('valid-jwt-token');
      expect(mockRes.locals.apiHeaders['x-userIdScheme']).toBe(
        'CustomerInternalId'
      );
    });

    it('should return 401 when JWT decode fails', async () => {
      (apiUtils.jwtDecode as jest.Mock).mockImplementation(() => {
        throw new Error('Invalid token');
      });

      await getAliasLookupByPayIdAndTypeHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      expect(mockRes.status).toHaveBeenCalledWith(401);
      expect(mockRes.json).toHaveBeenCalledWith({
        error: 'Access token invalid',
      });
      expect(mockRes.locals.logger.error).toHaveBeenCalledWith(
        expect.objectContaining({
          msg: 'Error decoding token',
        })
      );
    });

    it('should use sample credentials in local environment', async () => {
      mockControllerParams.RUNTIME.isLocal.mockReturnValue(true);
      (payIDLimitCounter as jest.Mock).mockResolvedValue({
        counters: [{ session: { counter: 0 }, counter: 0 }],
      });
      (getSafiDecisionForAliasLookup as jest.Mock).mockResolvedValue(true);
      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: { data: { id: '1' } },
      });
      (payIDLimitCounter as jest.Mock)
        .mockResolvedValueOnce({
          counters: [{ session: { counter: 0 }, counter: 0 }],
        })
        .mockResolvedValueOnce({ counters: [{ counter: 1 }] });

      await getAliasLookupByPayIdAndTypeHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      expect(apiUtils.jwtDecode).not.toHaveBeenCalled();
    });
  });

  describe('Counter Logic', () => {
    beforeEach(() => {
      (apiUtils.jwtDecode as jest.Mock).mockReturnValue({
        userId: 'user-123',
        sessionIndex: 'session-456',
      });
    });

    it('should handle existing counters successfully', async () => {
      (payIDLimitCounter as jest.Mock).mockResolvedValue({
        counters: [{ session: { counter: 5 }, counter: 10 }],
      });
      (getSafiDecisionForAliasLookup as jest.Mock).mockResolvedValue(true);
      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: { data: { id: '1' } },
      });
      (payIDLimitCounter as jest.Mock)
        .mockResolvedValueOnce({
          counters: [{ session: { counter: 5 }, counter: 10 }],
        })
        .mockResolvedValueOnce({ counters: [{ counter: 6 }] });

      await getAliasLookupByPayIdAndTypeHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      expect(getSafiDecisionForAliasLookup).toHaveBeenCalledWith(
        mockReq,
        mockRes,
        expect.objectContaining({
          currentSessionCounter: 6,
          currentUserCounter: 11,
        })
      );
    });

    it('should handle empty counters array and fallback to payment counter', async () => {
      (payIDLimitCounter as jest.Mock)
        .mockResolvedValueOnce({ counters: [] })
        .mockResolvedValueOnce({ counters: [{ counter: 3 }] })
        .mockResolvedValueOnce({ counters: [{ counter: 1 }] });
      (getSafiDecisionForAliasLookup as jest.Mock).mockResolvedValue(true);
      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: { data: { id: '1' } },
      });

      await getAliasLookupByPayIdAndTypeHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      expect(getSafiDecisionForAliasLookup).toHaveBeenCalledWith(
        mockReq,
        mockRes,
        expect.objectContaining({
          currentSessionCounter: 1,
          currentUserCounter: 4,
        })
      );
    });

    it('should handle 404 error with code 1003 (new user)', async () => {
      const mockError = {
        error: {
          status: 404,
          data: {
            result: {
              errors: [{ code: 1003 }],
            },
          },
        },
      };
      (payIDLimitCounter as jest.Mock).mockRejectedValueOnce(mockError);
      (getSafiDecisionForAliasLookup as jest.Mock).mockResolvedValue(true);
      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: { data: { id: '1' } },
      });
      (payIDLimitCounter as jest.Mock).mockResolvedValueOnce({
        counters: [{ counter: 1 }],
      });

      await getAliasLookupByPayIdAndTypeHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      expect(getSafiDecisionForAliasLookup).toHaveBeenCalledWith(
        mockReq,
        mockRes,
        expect.objectContaining({
          currentSessionCounter: 1,
          currentUserCounter: 1,
        })
      );
    });

    it('should return 400 when counters are null/undefined (validation gate)', async () => {
      (payIDLimitCounter as jest.Mock).mockResolvedValue({
        counters: [{ session: {}, counter: undefined }],
      });

      await getAliasLookupByPayIdAndTypeHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      // The explicit null check should catch undefined counters and return 400
      expect(mockRes.status).toHaveBeenCalledWith(400);
      expect(mockRes.json).toHaveBeenCalledWith(LIMIT_EXCEEEDED_ERROR);
      expect(getSafiDecisionForAliasLookup).not.toHaveBeenCalled();
    });

    it('should return 400 when payment counter fallback returns undefined', async () => {
      (payIDLimitCounter as jest.Mock)
        .mockResolvedValueOnce({ counters: [] }) // Empty session counter
        .mockResolvedValueOnce({ counters: [] }); // Empty payment counter too

      await getAliasLookupByPayIdAndTypeHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      // userCounter will be undefined from empty array, validation gate catches it
      expect(mockRes.status).toHaveBeenCalledWith(400);
      expect(mockRes.json).toHaveBeenCalledWith(LIMIT_EXCEEEDED_ERROR);
      expect(getSafiDecisionForAliasLookup).not.toHaveBeenCalled();
    });

    it('should handle counter API errors other than 404/1003', async () => {
      const mockError = {
        error: {
          status: 500,
          data: { message: 'Internal error' },
        },
      };
      (payIDLimitCounter as jest.Mock).mockRejectedValue(mockError);

      await getAliasLookupByPayIdAndTypeHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      expect(apiUtils.handleControllerError).toHaveBeenCalledWith({
        error: mockError,
        res: mockRes,
        logger: mockRes.locals.logger,
      });
      expect(mockNext).toHaveBeenCalledWith(mockError);
    });
  });

  describe('SAFI Decision', () => {
    beforeEach(() => {
      (apiUtils.jwtDecode as jest.Mock).mockReturnValue({
        userId: 'user-123',
        sessionIndex: 'session-456',
      });
      (payIDLimitCounter as jest.Mock).mockResolvedValue({
        counters: [{ session: { counter: 5 }, counter: 10 }],
      });
    });

    it('should proceed with lookup when SAFI allows', async () => {
      (getSafiDecisionForAliasLookup as jest.Mock).mockResolvedValue(true);
      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: { data: { id: '1', name: 'Test' } },
      });
      (payIDLimitCounter as jest.Mock)
        .mockResolvedValueOnce({
          counters: [{ session: { counter: 5 }, counter: 10 }],
        })
        .mockResolvedValueOnce({ counters: [{ counter: 6 }] });

      await getAliasLookupByPayIdAndTypeHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      expect(apiUtils.handleApiService).toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(200);
    });

    it('should return 400 when SAFI denies', async () => {
      (getSafiDecisionForAliasLookup as jest.Mock).mockResolvedValue(false);

      await getAliasLookupByPayIdAndTypeHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      expect(apiUtils.handleApiService).not.toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(400);
      expect(mockRes.json).toHaveBeenCalledWith(LIMIT_EXCEEEDED_ERROR);
    });
  });

  describe('Error Handling', () => {
    beforeEach(() => {
      (apiUtils.jwtDecode as jest.Mock).mockReturnValue({
        userId: 'user-123',
        sessionIndex: 'session-456',
      });
      (payIDLimitCounter as jest.Mock).mockResolvedValue({
        counters: [{ session: { counter: 5 }, counter: 10 }],
      });
      (getSafiDecisionForAliasLookup as jest.Mock).mockResolvedValue(true);
    });

    it('should increment counter on 400 error from downstream', async () => {
      const mockError = {
        error: { status: 400 },
      };
      (apiUtils.handleApiService as jest.Mock).mockRejectedValue(mockError);
      (payIDLimitCounter as jest.Mock)
        .mockResolvedValueOnce({
          counters: [{ session: { counter: 5 }, counter: 10 }],
        })
        .mockResolvedValueOnce({ counters: [{ counter: 6 }] });

      await getAliasLookupByPayIdAndTypeHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      expect(payIDLimitCounter).toHaveBeenCalledWith(
        mockControllerParams.channelPaymentUtilsV1Services
          .incrementSessionIdCounter,
        mockRes,
        mockReq,
        'user-123',
        'session-456'
      );
      expect(apiUtils.handleControllerError).toHaveBeenCalled();
      expect(mockNext).toHaveBeenCalledWith(mockError);
    });

    it('should not increment counter on non-400 errors', async () => {
      const mockError = {
        error: { status: 500 },
      };
      (apiUtils.handleApiService as jest.Mock).mockRejectedValue(mockError);
      (payIDLimitCounter as jest.Mock).mockResolvedValueOnce({
        counters: [{ session: { counter: 5 }, counter: 10 }],
      });

      await getAliasLookupByPayIdAndTypeHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      // Should only be called once for getting counter, not for increment
      expect(payIDLimitCounter).toHaveBeenCalledTimes(1);
    });

    // Note: Counter increment failure is checked in the handler but difficult to test
    // due to the async/await flow. The check exists at line 188 of the handler.
  });

  describe('Successful Flow', () => {
    beforeEach(() => {
      (apiUtils.jwtDecode as jest.Mock).mockReturnValue({
        userId: 'user-123',
        sessionIndex: 'session-456',
      });
      (payIDLimitCounter as jest.Mock).mockResolvedValue({
        counters: [{ session: { counter: 5 }, counter: 10 }],
      });
      (getSafiDecisionForAliasLookup as jest.Mock).mockResolvedValue(true);
    });

    it('should complete full successful flow', async () => {
      const mockDownstreamData = {
        id: '1',
        name: 'John Doe',
        accountNumber: '123456',
      };
      (apiUtils.handleApiService as jest.Mock).mockResolvedValue({
        data: { data: mockDownstreamData },
      });
      (payIDLimitCounter as jest.Mock)
        .mockResolvedValueOnce({
          counters: [{ session: { counter: 5 }, counter: 10 }],
        })
        .mockResolvedValueOnce({ counters: [{ counter: 6 }] });

      await getAliasLookupByPayIdAndTypeHandler(
        mockReq,
        mockRes,
        mockNext,
        mockControllerParams
      );

      expect(mockRes.status).toHaveBeenCalledWith(200);
      expect(mockRes.json).toHaveBeenCalledWith(
        expect.objectContaining({ normalised: expect.any(Array) })
      );
    });
  });
});
