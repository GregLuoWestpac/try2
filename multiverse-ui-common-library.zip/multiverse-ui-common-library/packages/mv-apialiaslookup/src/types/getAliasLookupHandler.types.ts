export interface PostAliasLookupData {
  entities?: {
    aliasLookup?: {
      /**
       * A unique id generated for a lookup result which is the mode of communication between the UI and Exp API
       * @format uuid
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * Alias Type of the beneficiary
       * @maxLength 4
       */
      aliasType?: 'EMAL' | 'TELI' | 'AUBN' | 'ORGN';
      /**
       * Nickname of the beneficiary
       * @minLength 1
       * @maxLength 70
       * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
       * @example "John"
       */
      name?: string;
      /**
       * The date/time when the alias was resolved.
       * @format date-time
       */
      resolutionDateTime?: string;
      /**
       * The response code mapped from the provider service.
       * @minLength 1
       * @maxLength 5
       * @pattern ^[0-9]+$
       * @example 200
       */
      returnCode?: any;
    }[];
  };
  /** @example {"aliasLookup":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    aliasLookup?: string[];
  };
}

export type DecodedToken = {
  userId?: string;
  userIdScheme?: string;
  sessionIndex?: string;
};

export type ExpApiResponseEntities = PostAliasLookupData['entities'];

export enum AuthBIC8 {
  WPACAU3S = 'WPACAU3S',
}

export type AliasLookupAction = 'Add Beneficiary' | 'Update Beneficiary';

export type AliasLookupEXPRequestBody = {
  id?: string;
  authBIC8?: AuthBIC8.WPACAU3S;
  email?: string;
  phone?: string;
  orgn?: string;
  aubn?: string;
  action?: AliasLookupAction;
};

export type AliasTypeKey = 'phone' | 'email' | 'orgn' | 'aubn';
export type AliasTypeValue = 'TELI' | 'EMAL' | 'ORGN' | 'AUBN';

export const aliasTypeMapping: Record<AliasTypeKey, AliasTypeValue> = {
  phone: 'TELI',
  email: 'EMAL',
  orgn: 'ORGN',
  aubn: 'AUBN',
} as const;
