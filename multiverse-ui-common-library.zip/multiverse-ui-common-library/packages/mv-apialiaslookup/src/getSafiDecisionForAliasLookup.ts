import {
  handleApiService,
  DownstreamServiceResponse,
  APIClient,
  SetDownstreamParams,
  ControllerParams,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { Request, Response } from 'express';
import { UserAgentType } from './types/capCustsvcmgtCustsecyverifctnAdaptvauthV2';

export const getPayIDType = (aliasType: string): string => {
  if (aliasType.includes('TELI')) {
    return 'MOBILE';
  } else if (aliasType.includes('EMAL')) {
    return 'EMAIL';
  } else if (aliasType.includes('AUBN')) {
    return 'ABN';
  } else if (aliasType.includes('ORGN')) {
    return 'ORGN';
  }
};

export const getSafiDecisionForAliasLookup = async (
  req: Request,
  res: Response,
  getSafiDecisionForAliasLookupParams: ControllerParams
) => {
  const { logger, apiHeaders, Cookie, sessionIndex } = res.locals;
  logger.info(`SAFI decision for PayID alias lookup - START`);
  const {
    analyseApiClient,
    currentSessionCounter,
    currentUserCounter,
    aliasId,
    aliasType,
    payIdSource,
    ID,
    getIpAddress,
    getDeviceFingerPrint,
    ALLOWED_COOKIES,
  } = getSafiDecisionForAliasLookupParams;

  const IPAddress = getIpAddress(req);
  const deviceTokenFromCookie = Cookie.get(ALLOWED_COOKIES.W1AddnAuthorisation);
  const deviceFingerPrint = getDeviceFingerPrint(req, res);

  // Build browser information headers (like Operations.js does on line 173)
  const deviceFingerPrintHeader = req.get('x-devicefingerprint');
  let browserInformation = {};

  if (deviceFingerPrintHeader) {
    browserInformation = {
      userAgent: req.get('user-agent') || '',
      httpAccept: req.get('accept') || '',
      httpReferer: req.get('referer') || '',
      httpAcceptedEncoding: req.get('accept-encoding') || '',
      httpAcceptedLanguage: req.get('accept-language') || '',
      httpAcceptedCharacters: req.get('accept-charset') || '',
    };
  }

  // Build the SAFI analyse request body (following Operations.js pattern)
  const safiAnalyseRequestBody = {
    eventType: 'CLIENT_DEFINED',
    clientDefinedEventType: 'PAYID_LOOKUP',
    tenantId: 'WPACW1',
    eventMetaData: [
      {
        name: 'TENANT',
        value: 'Treasury',
        datatype: 'STRING',
      },
      {
        name: 'COUNTER',
        value: String(currentSessionCounter),
        datatype: 'INTEGER',
      },
      {
        name: 'COUNTER_24HOUR',
        value: String(currentUserCounter),
        datatype: 'INTEGER',
      },
      {
        name: 'PAYEEPAYIDTYPE',
        value: getPayIDType(aliasType),
        datatype: 'STRING',
      },
      {
        name: 'PAYEEPAYIDVALUE',
        value: aliasId,
        datatype: 'STRING',
      },
      {
        name: 'SOURCE',
        value: payIdSource,
        datatype: 'STRING',
      },
    ],
    userAgentType: UserAgentType.BROWSER,
    clientTransactionId: {
      sessionId: ID.generate(true),
      transactionId: apiHeaders['x-appCorrelationId'] || ID.generate(true),
    },
    browserInformation, // This is where the headers from line 173 go
    device: {
      IPAddress,
      deviceFingerPrint,
      deviceToken: deviceTokenFromCookie,
    },
    verificationReferenceId: sessionIndex,
    customer: {
      customerType: 'Individual',
      customerId: {
        id: apiHeaders['x-userId'],
        idScheme: 'CustomerInternalId',
      },
    },
  };

  // Custom setDownstreamParams function for SAFI analyse
  const setSAFIDownstreamParams: SetDownstreamParams = (
    inputHeaders,
    response,
    safiRequestBody
  ) => ({
    header: {
      ...inputHeaders,
      'x-originatingSystemId': 'A014A6', // Override for SAFI call
    },
    body: safiRequestBody,
    query: {
      brandSilo: response.locals.brandSilo,
      pageSize: '0', // As per Operations.js
    },
  });

  const analyseResponse: DownstreamServiceResponse = await handleApiService({
    req,
    res,
    apiClient: analyseApiClient as APIClient,
    setDownstreamParams: setSAFIDownstreamParams,
    requestBody: safiAnalyseRequestBody,
  });

  const analyseResult = analyseResponse?.data?.data?.analyseResult;
  const deviceToken = analyseResponse?.data?.data?.deviceToken;

  if (deviceToken) {
    const today = new Date();
    const maxExpiryDate = new Date().setDate(today.getDate() + 365);
    Cookie.set(
      ALLOWED_COOKIES.W1AddnAuthorisation,
      deviceToken,
      res.locals.xBrandId,
      {
        expires: new Date(maxExpiryDate),
      }
    );
  }

  const isSAFIAllowed = analyseResult === 'ALLOW';
  logger.info(`SAFI decision for PayID alias lookup - END`);
  return isSAFIAllowed;
};
