import {
  type ControllerParams,
  type RequestBody,
  handleControllerError,
  handleApiService,
  APIClientError,
  STATUS_CODES,
  DownstreamServiceResponse,
  normaliseData,
  jwtDecode,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { NextFunction, Request, Response } from 'express';
import {
  transformAliasLookupExpResponse,
  payIDLimitCounter,
} from './getAliasLookupHandler.helpers';
import { getSafiDecisionForAliasLookup } from './getSafiDecisionForAliasLookup';
import {
  GetPaymentCounterResponse,
  GetSessionCounterResponse,
} from './types/channelPaymentUtilsV1';
import { LIMIT_EXCEEEDED_ERROR, UserIdScheme } from './constants';
import {
  AliasLookupEXPRequestBody,
  AliasTypeKey,
  aliasTypeMapping,
  DecodedToken,
  ExpApiResponseEntities,
} from './types/getAliasLookupHandler.types';
import { AliasResolutionRequest } from './types/paymentAliasResolutionV2';

export const transformPostResolutionViewRequest = (
  aliasLookupRequestBody: AliasLookupEXPRequestBody
): AliasResolutionRequest => {
  const { authBIC8, action, ...rest } = aliasLookupRequestBody;

  const [key, id] = Object.entries(rest)[0] as [AliasTypeKey, string];

  return {
    aliasId: id,
    aliasType: aliasTypeMapping[key],
    authBIC8,
  };
};

export const getAliasLookupByPayIdAndTypeHandler = async (
  req: Request,
  res: Response,
  next: NextFunction,
  controllerParams: ControllerParams
) => {
  const {
    normalise,
    paymentAliasResolutionV2Services,
    capCustsvcmgtCustsecyverifctnAdaptvauthV2Services,
    channelPaymentUtilsV1Services,
    payIdSource,
    RUNTIME,
    ID,
    getIpAddress,
    getDeviceFingerPrint,
    ALLOWED_COOKIES,
  } = controllerParams;
  const isStaffPortal =
    res.locals.apiHeaders['x-userIdScheme'] === UserIdScheme.StaffSalaryNumber;
  const { logger, apiHeaders } = res.locals;
  const { postResolutionView } = paymentAliasResolutionV2Services;
  const { getSessionIdCounter, incrementSessionIdCounter, getPaymentCounter } =
    channelPaymentUtilsV1Services;
  const { analyse } = capCustsvcmgtCustsecyverifctnAdaptvauthV2Services;

  const aliasLookupExpRequestBody: AliasLookupEXPRequestBody = req.body;

  const requestBody = transformPostResolutionViewRequest(
    aliasLookupExpRequestBody
  );

  const xAccessToken = apiHeaders['x-access-token'] as string;
  let decodedToken: DecodedToken = {};

  if (RUNTIME.isLocal()) {
    decodedToken = {
      userId: 'sampleUserId',
      sessionIndex: 'sampleSessionId',
    };
  } else {
    try {
      decodedToken = jwtDecode(xAccessToken);
      res.locals.apiHeaders['x-userIdScheme'] = 'CustomerInternalId';
    } catch (error) {
      const tokenDecodeError = {
        msg: 'Error decoding token',
        payload: { error },
      };
      logger?.error(tokenDecodeError);
      res.status(401).json({ error: 'Access token invalid' });
      return;
    }
  }

  try {
    if (!isStaffPortal) {
      let sessionCounter: number;
      let userCounter: number;
      try {
        const { counters }: GetSessionCounterResponse = await payIDLimitCounter(
          getSessionIdCounter,
          res,
          req,
          decodedToken.userId,
          decodedToken.sessionIndex
        );
        if (counters?.length === 0) {
          const data: GetPaymentCounterResponse = await payIDLimitCounter(
            getPaymentCounter,
            res,
            req,
            decodedToken.userId
          );
          sessionCounter = 0;
          userCounter = data?.counters?.[0]?.counter;
        } else {
          sessionCounter = counters?.[0]?.session?.counter;
          userCounter = counters?.[0]?.counter;
        }
      } catch (error: unknown) {
        const apiError = error as APIClientError;
        const { status, data } = apiError?.error || {};
        if (
          Number(status) === 404 &&
          Number(data?.result?.errors?.[0]?.code) === 1003
        ) {
          sessionCounter = 0;
          userCounter = 0;
        } else {
          handleControllerError({ error: apiError, res, logger });
          next(error);
          return;
        }
      }

      if (sessionCounter == null || userCounter == null) {
        res.status(STATUS_CODES.BAD_REQUEST).json(LIMIT_EXCEEEDED_ERROR);
        return;
      }

      const currentSessionCounter = sessionCounter + 1;
      const currentUserCounter = userCounter + 1;

      const aliasId = String(requestBody.aliasId);
      const aliasType = String(requestBody.aliasType);

      const getSafiDecisionForAliasLookupParams: ControllerParams = {
        analyseApiClient: analyse,
        currentSessionCounter,
        currentUserCounter,
        aliasId,
        aliasType,
        payIdSource,
        ID,
        getIpAddress,
        getDeviceFingerPrint,
        ALLOWED_COOKIES,
      };

      const isSAFIAllowed = await getSafiDecisionForAliasLookup(
        req,
        res,
        getSafiDecisionForAliasLookupParams
      );

      if (isSAFIAllowed) {
        const downstreamResponse: DownstreamServiceResponse =
          await handleApiService({
            req,
            res,
            apiClient: postResolutionView,
            requestBody: requestBody as unknown as RequestBody,
          });

        const incrementPaymentCounterResponse = await payIDLimitCounter(
          incrementSessionIdCounter,
          res,
          req,
          decodedToken.userId,
          decodedToken?.sessionIndex
        );

        if (!incrementPaymentCounterResponse.counters) {
          throw new Error(
            'PayID limit failed to increment after successful lookup'
          );
        }

        const expApiResponseData: ExpApiResponseEntities =
          transformAliasLookupExpResponse(downstreamResponse.data);

        const normalisedData = normaliseData(
          'aliasLookup',
          expApiResponseData.aliasLookup,
          normalise
        );

        res.status(STATUS_CODES.OK).json(normalisedData);
      } else {
        res.status(STATUS_CODES.BAD_REQUEST).json(LIMIT_EXCEEEDED_ERROR);
      }
    } else {
      const downstreamResponse: DownstreamServiceResponse =
        await handleApiService({
          req,
          res,
          apiClient: postResolutionView,
          requestBody: requestBody as unknown as RequestBody,
        });

      const expApiResponseData: ExpApiResponseEntities =
        transformAliasLookupExpResponse(downstreamResponse.data);

      const normalisedData = normaliseData(
        'aliasLookup',
        expApiResponseData.aliasLookup,
        normalise
      );

      res.status(STATUS_CODES.OK).json(normalisedData);
    }
  } catch (error: unknown) {
    const apiError = error as APIClientError;
    if (!isStaffPortal) {
      try {
        if (apiError?.error?.status === 400) {
          await payIDLimitCounter(
            incrementSessionIdCounter,
            res,
            req,
            decodedToken.userId,
            decodedToken.sessionIndex
          );
        }
      } catch (incrementError) {
        handleControllerError({
          error: incrementError as APIClientError,
          res,
          logger,
        });
        next(incrementError);
        return;
      }
    }
    handleControllerError({ error: apiError, res, logger });
    next(error);
  }
};
