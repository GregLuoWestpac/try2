import { Request, Response, NextFunction } from 'express';
import { ControllerParams } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
export { ControllerParams } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

export const getAliasLookupByPayIdAndTypeHandler: (
  req: Request,
  res: Response,
  next: NextFunction,
  controllerParams: ControllerParams
) => Promise<void>;

export const getAliasLookupByBeneficiaryIdHandler: (
  req: Request,
  res: Response,
  next: NextFunction,
  controllerParams: ControllerParams
) => Promise<void>;

export const validateAliasLookupRequestBody: (
  aliasLookupRequestBody: AliasLookupEXPRequestBody
) => {
  isValid: boolean;
};

export const validateAliasLookupByBeneIdRequestBody: (
  aliasLookupByBeneIdRequestBody: AliasLookupByBeneIdEXPRequestBody
) => {
  isValid: boolean;
};

export type AliasLookupAction = 'Add Beneficiary' | 'Update Beneficiary';

export enum AuthBIC8 {
  WPACAU3S = 'WPACAU3S',
}

export type AliasLookupEXPRequestBody = {
  id?: string;
  authBIC8?: AuthBIC8.WPACAU3S;
  email?: string;
  phone?: string;
  orgn?: string;
  aubn?: string;
  action?: AliasLookupAction;
};

export type AliasLookupByBeneIdEXPRequestBody = {
  id: string;
};
