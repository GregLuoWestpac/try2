export const LIMIT_EXCEEEDED_ERROR = {
  result: {
    errors: [
      {
        code: 2000,
        message: 'PayID limit exceeded',
        details:
          'PayID verification cannot be completed. Please try again later.',
      },
    ],
  },
};
export enum UserIdScheme {
  StaffSalaryNumber = 'StaffSalaryNumber',
  CustomerInternalId = 'CustomerInternalId',
  CustomerNumber = 'CustomerNumber',
  CorporateUserId = 'CorporateUserId',
}
