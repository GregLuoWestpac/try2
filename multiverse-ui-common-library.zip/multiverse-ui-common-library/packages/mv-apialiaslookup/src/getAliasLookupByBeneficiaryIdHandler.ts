import type { ControllerParams } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import {
  handleControllerError,
  handleApiService,
  APIClientError,
  STATUS_CODES,
  DownstreamServiceResponse,
  normaliseData,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { NextFunction, Request, Response } from 'express';
import { transformAliasLookupByBeneIdExpResponse } from './getAliasLookupHandler.helpers';
import {
  AuthBIC8,
  ExpApiResponseEntities,
} from './types/getAliasLookupByBeneIdHandler.types';

export const transformPostResolutionViewRequest =
  beneficiaryDetailsResponse => {
    return {
      aliasId: beneficiaryDetailsResponse.account.payIDValue,
      aliasType: beneficiaryDetailsResponse.account.payIDType,
      authBIC8: AuthBIC8.WPACAU3S,
    };
  };

export const getAliasLookupByBeneficiaryIdHandler = async (
  req: Request,
  res: Response,
  next: NextFunction,
  controllerParams: ControllerParams
) => {
  const { logger } = res.locals;
  const {
    normalise,
    paymentAliasResolutionV2Services,
    beneficiaryManagementV1Services,
  } = controllerParams;
  const { postResolutionView } = paymentAliasResolutionV2Services;
  const { getBeneficiaryDetail } = beneficiaryManagementV1Services;
  const { id } = req.body;

  try {
    const getBeneficiaryDetailsResponse: DownstreamServiceResponse =
      await handleApiService({
        req,
        res,
        apiClient: getBeneficiaryDetail,
        pathParams: { id },
        reqMethod: 'GET',
      });

    const beneDetailsExpApiResponseData =
      getBeneficiaryDetailsResponse?.data?.data;
    const requestBody = transformPostResolutionViewRequest(
      beneDetailsExpApiResponseData
    );
    const postResolutionViewResponse: DownstreamServiceResponse =
      await handleApiService({
        req,
        res,
        apiClient: postResolutionView,
        requestBody,
      });

    const expApiResponseData: ExpApiResponseEntities =
      transformAliasLookupByBeneIdExpResponse(postResolutionViewResponse.data);

    const normalisedData = normaliseData(
      'aliasLookupByBeneId',
      expApiResponseData.aliasLookupByBeneId,
      normalise
    );
    res.status(STATUS_CODES.OK).json(normalisedData);
  } catch (error: unknown) {
    handleControllerError({ error: error as APIClientError, res, logger });
    next(error);
  }
};
