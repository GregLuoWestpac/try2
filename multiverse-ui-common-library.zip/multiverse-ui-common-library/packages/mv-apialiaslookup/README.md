# mv-apialiaslookup

PayID Alias Resolution package for Multiverse UI Common Library with integrated SAFI fraud verification and rate limiting.

## Overview

This package provides Express middleware handlers for performing PayID alias lookups with:

- **SAFI (Strategic Anti-Fraud Intelligence)** fraud verification integration
- **Rate limiting** via session and 24-hour user counters
- **JWT authentication** validation and header propagation
- **Dual lookup modes**: Direct PayID lookup or beneficiary-based lookup

## Installation

```bash
npm install @mesh-tenant-multiverse-ui-common/mv-apialiaslookup
```

## Usage

### PayID Lookup Handler

Use this handler when you have PayID details (email, phone, ABN, or organization ID):

```typescript
import { getAliasLookupByPayIdAndTypeHandler } from '@mesh-tenant-multiverse-ui-common/mv-apialiaslookup';
import type { ControllerParams } from '@mesh-tenant-multiverse-ui-common/mv-apialiaslookup';

// Setup your Express route
app.post('/api/alias-lookup', async (req, res, next) => {
  const controllerParams: ControllerParams = {
    normalise: normaliseConfig,
    paymentAliasResolutionV2Services,
    capCustsvcmgtCustsecyverifctnAdaptvauthV2Services,
    channelPaymentUtilsV1Services,
    payIdSource: 'WEB', // or 'MOBILE', 'API'
    RUNTIME,
    ID,
    getIpAddress,
    getDeviceFingerPrint,
    ALLOWED_COOKIES,
  };

  await getAliasLookupByPayIdAndTypeHandler(req, res, next, controllerParams);
});
```

**Request Body:**

```typescript
{
  authBIC8: "WPACAU3S",
  email?: "user@example.com",  // At least one PayID field required
  phone?: "+61412345678",
  orgn?: "ORG123",
  aubn?: "12345678901"
}
```

**Success Response (200):**

```json
{
  "normalised": [
    {
      "id": "uuid-v4",
      "accountName": "John Doe",
      "accountNumber": "123456789",
      "bsb": "032-001"
    }
  ]
}
```

**Error Responses:**

- `400 Bad Request` - Rate limit exceeded, SAFI denied, or validation failed
- `401 Unauthorized` - Invalid JWT token
- `500 Internal Server Error` - Downstream service errors

### Beneficiary Lookup Handler

Use this handler when you have a beneficiary ID:

```typescript
import { getAliasLookupByBeneficiaryIdHandler } from '@mesh-tenant-multiverse-ui-common/mv-apialiaslookup';

app.post('/api/alias-lookup-by-beneficiary', async (req, res, next) => {
  const controllerParams: ControllerParams = {
    normalise: normaliseConfig,
    paymentAliasResolutionV2Services,
    beneficiaryManagementV1Services,
  };

  await getAliasLookupByBeneficiaryIdHandler(req, res, next, controllerParams);
});
```

**Request Body:**

```typescript
{
  id: 'beneficiary-uuid';
}
```

### Request Validation

Validate request bodies before processing:

```typescript
import { validateAliasLookupRequestBody } from '@mesh-tenant-multiverse-ui-common/mv-apialiaslookup';
import type { AliasLookupEXPRequestBody } from '@mesh-tenant-multiverse-ui-common/mv-apialiaslookup';

const requestBody: AliasLookupEXPRequestBody = req.body;
const { isValid } = validateAliasLookupRequestBody(requestBody);

if (!isValid) {
  return res.status(400).json({
    error: 'Invalid request: must have either id OR (authBIC8 + PayID field)',
  });
}
```

**Validation Rules:**

- **Valid**: `{ id: "..." }` alone
- **Valid**: `{ authBIC8: "WPACAU3S", email: "..." }` (or phone/orgn/aubn)
- **Invalid**: Empty object
- **Invalid**: `{ authBIC8 }` without PayID field
- **Invalid**: `{ email }` without authBIC8
- **Invalid**: `{ id, email }` - mixing modes not allowed

## Features

### SAFI Fraud Verification

Every PayID lookup is automatically verified through SAFI:

- **Risk assessment** based on session counters, IP address, device fingerprint
- **Device token management** via secure cookies (1-year expiry)
- **ALLOW/DENY decisions** - denied requests return 400 with rate limit error

### Rate Limiting

**Two-tier counter system:**

1. **Session Counter** - Requests per current session
2. **24-Hour User Counter** - Requests per user in rolling 24-hour window

**Counter behavior:**

- New users (404 with code 1003): Start at 0
- Empty counter arrays: Fallback to user-level counter
- Failed lookups (400 errors): Still increment counter to prevent abuse
- Null counters: Default to 0 (safe fallback)

### JWT Authentication

**Requirements:**

- `x-access-token` header must contain valid JWT
- JWT must include: `userId`, `sessionIndex`

**Header mutations:**

- Sets `x-userIdScheme: CustomerInternalId` for downstream services

**Local development:**

- `RUNTIME.isLocal()` bypasses JWT validation with sample credentials

## Error Codes

| Code | Message              | Reason                                |
| ---- | -------------------- | ------------------------------------- |
| 2000 | PayID limit exceeded | Rate limit hit OR SAFI denied request |
| 401  | Access token invalid | JWT decode failure                    |

## Configuration

### ControllerParams (PayID Handler)

```typescript
{
  normalise: NormaliseConfig,                              // Data normalization config
  paymentAliasResolutionV2Services: {
    postResolutionView: APIClient                          // Alias resolution API
  },
  capCustsvcmgtCustsecyverifctnAdaptvauthV2Services: {
    analyse: APIClient                                     // SAFI verification API
  },
  channelPaymentUtilsV1Services: {
    getSessionIdCounter: APIClient,                        // Get session counter
    incrementSessionIdCounter: APIClient,                  // Increment session counter
    getPaymentCounter: APIClient                           // Get user counter
  },
  payIdSource: 'WEB' | 'MOBILE' | 'API',                  // Source identifier for SAFI
  RUNTIME: { isLocal: () => boolean },                    // Environment detection
  ID: { generate: (secure?: boolean) => string },         // ID generator
  getIpAddress: (req: Request) => string,                 // Extract client IP
  getDeviceFingerPrint: (req, res) => string,             // Get device fingerprint
  ALLOWED_COOKIES: { pmData: string }                     // Cookie names config
}
```

### ControllerParams (Beneficiary Handler)

```typescript
{
  normalise: NormaliseConfig,
  paymentAliasResolutionV2Services: {
    postResolutionView: APIClient
  },
  beneficiaryManagementV1Services: {
    getBeneficiaryDetail: APIClient                        // Beneficiary details API
  }
}
```

## TypeScript Types

All types are exported from the main index:

```typescript
import type {
  ControllerParams,
  AliasLookupEXPRequestBody,
  AliasLookupAction,
  AuthBIC8,
} from '@mesh-tenant-multiverse-ui-common/mv-apialiaslookup';
```

## Development

```bash
# Lint
npm run lint

# Build
npm run build

# Run tests
npm test
```

## Dependencies

- `@mesh-tenant-multiverse-ui-common/mv-apiutils` - API utilities and helpers
- `lodash` (peer) - Utility functions
- `react` (peer) - React framework

## License

UNLICENSED - Westpac Internal Use Only

## Support

For issues or questions, please contact the Multiverse UI Common Library team or refer to the main repository documentation.
