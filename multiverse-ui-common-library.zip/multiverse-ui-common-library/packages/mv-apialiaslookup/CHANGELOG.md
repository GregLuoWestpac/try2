# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.226.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.226.0...v1.226.1) (2026-02-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apialiaslookup

## [1.225.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.225.4...v1.225.5) (2026-02-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apialiaslookup

## [1.223.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.222.0...v1.223.0) (2026-01-28)

### 🚀 Features

- integrate UserIdScheme enum into alias lookup handler for improved user identification | ART-98215 ([9754acc](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9754acc06a1221970da21f44b767f4d893c5c52a))
- refactor alias lookup handler to improve session and user counter logic | ART-98215 ([2ebe78b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2ebe78b3a2c52f517f6593e896ef8e095452a4da))

### 💥 Bug Fixes

- refactor error handling in getAliasLookupByPayIdAndTypeHandler to improve session ID counter logic | ART-98215 ([dce52d6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/dce52d6130bf7a0ac255c26abcef372d5f68c998))

## [1.221.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.221.5...v1.221.6) (2026-01-25)

### 💥 Bug Fixes

- updated the import | ART-98173 ([25c8e7d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/25c8e7ddd62538164463088db989b7dd020d270b))

## [1.221.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.221.4...v1.221.5) (2026-01-25)

### 💥 Bug Fixes

- updated the entity name | ART-98173 ([3497b90](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3497b90ee5e8e7d40c5c3ad64fc4a6fad8df38f6))
- updated the handlers | ART-98173 ([c985a4d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c985a4d33cb9fe06a4bfd8ec11b39e5d2cbf81f1))

## [1.221.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.221.1...v1.221.2) (2026-01-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apialiaslookup

## [1.220.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.10...v1.220.0) (2026-01-19)

### 🚀 Features

- update cookie name from pmData to W1AddnAuthorisation | ART-97784 ([d12b60f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d12b60fbb75e05826a82ff97ac39da43ab55c984))

## [1.219.8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.7...v1.219.8) (2026-01-13)

### 💥 Bug Fixes

- remove legalName field from alias lookup response and unit test fix | ART-88711 ([9fb5853](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9fb5853613d7d7c5418350f91cf755ed1b5d9cb7))

## [1.219.7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.6...v1.219.7) (2026-01-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apialiaslookup

## [1.219.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.4...v1.219.5) (2026-01-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apialiaslookup

## [1.219.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.0...v1.219.1) (2025-12-19)

### 💥 Bug Fixes

- add back deleted files | ART-88711 ([9b541f6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9b541f66f1babf412fa5f9f318b3533504b1ee0e))

## [1.217.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.216.0...v1.217.0) (2025-12-17)

### 🚀 Features

- remove vulnerability fields from alias lookup API response | ART-88711 ([cc5bd72](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/cc5bd7277580f0d3e9d23650dcbdd1be74a4ff4f))
- update aliasType in transformAliasLookupExpResponse to use PAYID_TYPE | ART-88711 ([e847f16](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/e847f16aa637094352fc657466f1b78a98492a41))

## [1.213.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.212.0...v1.213.0) (2025-12-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apialiaslookup

## [1.212.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.211.0...v1.212.0) (2025-12-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apialiaslookup

## [1.210.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.210.0...v1.210.1) (2025-11-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apialiaslookup
