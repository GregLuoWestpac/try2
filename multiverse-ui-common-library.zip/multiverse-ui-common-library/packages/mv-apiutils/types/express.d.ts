// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { Response } from 'express';
import { ApiHeaders } from '../src';

declare module 'express-serve-static-core' {
  interface Response {
    locals: {
      apiHeaders: ApiHeaders;
      apiBaseUrl: string;
      brandSilo?: string;
      BSB?: string;
    };
  }
  interface Response {
    app: AppResponse;
  }
  interface Response {
    req: {
      get: (header: string) => string;
    };
  }
}
