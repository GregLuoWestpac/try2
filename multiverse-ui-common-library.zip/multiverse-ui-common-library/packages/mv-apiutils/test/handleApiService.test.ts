/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { handleApiService } from '../src/handleApiService';

describe('handleApiService', () => {
  let req: any;
  let res: any;
  let apiClient: jest.Mock;
  let setDownstreamParams: jest.Mock;
  let requestBody: any;

  beforeEach(() => {
    req = {
      query: {},
    };
    res = {
      locals: {
        apiHeaders: {},
        apiBaseUrl: 'Base.url',
      },
      app: {
        locals: {
          Config: {
            //@ts-ignore
            get: jest.fn().mockReturnValue({
              requestConfig: { timeout: 1000 },
              responseConfig: { parse: true },
            }),
          },
        },
      },
    };
    //@ts-ignore
    apiClient = jest.fn().mockResolvedValue({ data: {} });
    //@ts-ignore
    setDownstreamParams = jest.fn().mockReturnValue({});
    requestBody = {};
  });

  it('should set apiConfig correctly from appConfig', async () => {
    await handleApiService({
      req,
      res,
      apiClient,
      setDownstreamParams,
      requestBody,
    });

    expect(res.app.locals.Config.get).toHaveBeenCalledWith('app-config', {});
    expect(apiClient).toHaveBeenCalledWith(
      'Base.url',
      {},
      {
        request: { timeout: 1000 },
        response: { parse: true },
      },
      req,
      res
    );
  });

  it('should handle missing appConfig gracefully', async () => {
    res.app.locals.Config.get.mockReturnValue(null);

    await handleApiService({
      req,
      res,
      apiClient,
      setDownstreamParams,
      requestBody,
    });

    expect(apiClient).toHaveBeenCalledWith(
      'Base.url',
      {},
      {
        request: null,
        response: null,
      },
      req,
      res
    );
  });
});
