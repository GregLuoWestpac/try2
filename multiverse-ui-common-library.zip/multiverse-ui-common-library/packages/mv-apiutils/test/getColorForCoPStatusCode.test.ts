import {
  CoPApiStatusCode,
  allCoPApiStatusCodes,
  mapCoPStatusToMessageProps,
} from '@mesh-tenant-multiverse-ui-common/mv-utils/src/copStatusResponses';
import {
  convertColorToLook,
  getColorForCoPStatusCode,
} from '../src/getColorForCoPStatusCode';

describe('getColorForCoPStatusCode', () => {
  const redCases: CoPApiStatusCode[] = [
    'V0C7', // Error - CoP error and Account closed or not found
    'V1C7', // Error - CoP error and Account closed or not found
    'V2C7', // Error - CoP error and Account closed or not found
    'VAC7', // Error - CoP error and Account closed or not found
    'VTC7', // Error - CoP error and Account closed or not found
    'VEC7', // Error - CoP error and Account closed or not found
  ];

  const blueCases: CoPApiStatusCode[] = [
    'V0C1', // Success - CoP match + Verify match
    'V0C2', // Success - CoP close match + Verify match
    'VAC1', // Success - CoP match + Verify error
    'VTC1', // Success - CoP match + Verify timeout (error)
    'VEC1', // Success - CoP match + Verify error
    'V0C6', // Success - CoP error and Verify match
    'V0C8', // Success - CoP error and Verify match
  ];

  const amberCases: CoPApiStatusCode[] = [
    'V1C1', // Warning - CoP match + Verify not enough payments
    'V2C1', // Warning - CoP match + Verify no match
    'V1C2', // Warning - CoP close match + Verify not enough payments
    'V2C2', // Warning - CoP close match + Verify no match
    'V1C6', // Warning - CoP error and Verify not enough payments
    'V1C8', // Warning - CoP error and Verify not enough payments
    'V2C6', // Warning - CoP error and Verify no match
    'V2C8', // Warning - CoP error and Verify no match
    'VAC6', // Warning - CoP error and Verify error
    'VAC8', // Warning - CoP error and Verify error
    'VTC6', // Warning - CoP error and Verify error
    'VTC8', // Warning - CoP error and Verify error
    'VEC6', // Warning - CoP error and Verify error
    'VEC8', // Warning - CoP error and Verify error
    'V0C3', // Warning - CoP no match [IND] and Verify match
    'V0C4', // Warning - CoP no match [NON-IND] and Verify match
    'V1C3', // Warning - CoP no match [IND] and Verify not enough payments
    'V1C4', // Warning - CoP no match [NON-IND] and Verify not enough payments
    'V2C3', // Warning - CoP no match [IND] and Verify no match
    'V2C4', // Warning - CoP no match [NON-IND] and Verify no match
    'VAC3', // Warning - CoP no match [IND] and Verify error
    'VTC3', // Warning - CoP no match [IND] and Verify error
    'VEC3', // Warning - CoP no match [IND] and Verify error
    'VAC4', // Warning - CoP no match [NON-IND] and Verify error
    'VTC4', // Warning - CoP no match [NON-IND] and Verify error
    'VEC4', // Warning - CoP no match [NON-IND] and Verify error
    'V0C5', // Warning - CoP opt-out and Verify match
    'V1C5', // Warning - CoP opt-out and Verify not enough payments
    'V2C5', // Warning - CoP opt-out and Verify no match
    'VAC5', // Warning - CoP opt-out and Verify error
    'VTC5', // Warning - CoP opt-out and Verify error
    'VEC5', // Warning - CoP opt-out and Verify error
    'VAC2', // warning - CoP close match + Verify error
    'VTC2', // warning - CoP close match + Verify timeout (error)
    'VEC2', // warning - CoP close match + Verify error
  ];

  describe('Blue cases (Info)', () => {
    it.each(blueCases)('should return Blue for status %s', status => {
      expect(getColorForCoPStatusCode(status)).toBe('Blue');
    });
  });

  describe('Amber cases (Warning)', () => {
    it.each(amberCases)('should return Amber for status %s', status => {
      expect(getColorForCoPStatusCode(status)).toBe('Amber');
    });
  });

  describe('Red cases (Danger)', () => {
    it.each(redCases)('should return Red for status %s', status => {
      expect(getColorForCoPStatusCode(status)).toBe('Red');
    });
  });

  describe('Unknown status codes', () => {
    it('should return undefined for unknown status code', () => {
      expect(getColorForCoPStatusCode('UNKNOWN')).toBeUndefined();
    });

    it('should return undefined for empty string', () => {
      expect(getColorForCoPStatusCode('')).toBeUndefined();
    });
  });

  describe('Coverage completeness', () => {
    it('should have all CoPApiStatus values covered in test cases', () => {
      const testedStatusCodes = [...redCases, ...blueCases, ...amberCases];

      // Check all statuses are covered
      allCoPApiStatusCodes.forEach(status => {
        expect(testedStatusCodes).toContain(status);
      });

      // Verify count matches
      expect(testedStatusCodes.length).toBe(allCoPApiStatusCodes.length);
    });

    it('should have no duplicate status codes across test cases', () => {
      const allTestedStatuses = [...redCases, ...blueCases, ...amberCases];
      const uniqueStatuses = new Set(allTestedStatuses);
      expect(allTestedStatuses.length).toBe(uniqueStatuses.size);
    });
  });

  describe('should be consistent with mapCoPStatusToMessageProps look for every CoP status', () => {
    allCoPApiStatusCodes.forEach(status => {
      it(`status ${status} derived look should be matched`, () => {
        const color = getColorForCoPStatusCode(status);
        const look = convertColorToLook(color);
        const uiResult = mapCoPStatusToMessageProps(status, '');
        expect(uiResult).toBeDefined();
        expect(look).toEqual(uiResult.look);
      });
    });
  });
});
