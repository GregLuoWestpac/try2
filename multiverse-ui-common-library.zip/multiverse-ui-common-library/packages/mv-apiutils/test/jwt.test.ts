import {
  jwtDecode,
  decodeAndValidateToken,
  InvalidTokenError,
  JwtHeader,
} from '../src/jwt';
import { Logger, RoleBaseJwtModel } from '../src/types';

describe('jwtDecode', () => {
  const validHeader = { typ: 'JWT', alg: 'HS256', kid: 'abc123' };
  const validPayload = { userId: 'user1', userIAMId: 'iam1', role: 'admin' };
  function createJwt(header: object, payload: object) {
    const base64Url = (obj: object) =>
      Buffer.from(JSON.stringify(obj))
        .toString('base64')
        .replace(/=/g, '')
        .replace(/\+/g, '-')
        .replace(/\//g, '_');
    return `${base64Url(header)}.${base64Url(payload)}.signature`;
  }

  it('decodes header when options.header is true', () => {
    const token = createJwt(validHeader, validPayload);
    const decoded = jwtDecode<JwtHeader>(token, { header: true });
    expect(decoded).toEqual(validHeader);
  });

  it('decodes payload by default', () => {
    const token = createJwt(validHeader, validPayload);
    const decoded = jwtDecode<RoleBaseJwtModel>(token);
    expect(decoded).toEqual(validPayload);
  });

  it('throws InvalidTokenError for non-string token', () => {
    // @ts-expect-error: Testing non-string token error handling
    expect(() => jwtDecode(123)).toThrow(InvalidTokenError);
  });

  it('throws InvalidTokenError for malformed token', () => {
    expect(() => jwtDecode('bad.token')).toThrow(InvalidTokenError);
  });

  it('throws InvalidTokenError for invalid JSON', () => {
    const badToken = `${Buffer.from('badjson').toString('base64')}.${Buffer.from('badjson').toString('base64')}.sig`;
    expect(() => jwtDecode(badToken)).toThrow(InvalidTokenError);
  });
});

describe('decodeAndValidateToken', () => {
  const validPayload = { userId: 'user1', userIAMId: 'iam1', role: 'admin' };
  const validHeader = { typ: 'JWT', alg: 'HS256', kid: 'abc123' };
  const token = (() => {
    const base64Url = (obj: object) =>
      Buffer.from(JSON.stringify(obj))
        .toString('base64')
        .replace(/=/g, '')
        .replace(/\+/g, '-')
        .replace(/\//g, '_');
    return `${base64Url(validHeader)}.${base64Url(validPayload)}.signature`;
  })();

  const logger: Logger = Object.assign(console, { error: jest.fn() });

  it('returns mapped fields for valid token', () => {
    const apiHeaders = { 'x-access-token': token };
    const result = decodeAndValidateToken({
      apiHeaders,
      headerKey: 'x-access-token',
      logger,
    });
    expect(result).toEqual({ userId: 'user1', userIAMId: 'iam1' });
  });

  it('throws InvalidTokenError and logs error for invalid token', () => {
    const apiHeaders = { 'x-access-token': 'bad.token' };
    expect(() =>
      decodeAndValidateToken({
        apiHeaders,
        headerKey: 'x-access-token',
        logger,
      })
    ).toThrow(InvalidTokenError);
    expect(logger.error).toHaveBeenCalled();
  });

  it('throws InvalidTokenError if required fields are missing', () => {
    const payload = { userIAMId: 'iam1' };
    const base64Url = (obj: object) =>
      Buffer.from(JSON.stringify(obj))
        .toString('base64')
        .replace(/=/g, '')
        .replace(/\+/g, '-')
        .replace(/\//g, '_');
    const badToken = `${base64Url(validHeader)}.${base64Url(payload)}.signature`;
    const apiHeaders = { 'x-access-token': badToken };
    expect(() =>
      decodeAndValidateToken({
        apiHeaders,
        headerKey: 'x-access-token',
        logger,
      })
    ).toThrow(InvalidTokenError);
  });

  it('applies fieldMappings and postProcess', () => {
    const apiHeaders = { 'x-access-token': token };
    const postProcess = jest.fn(obj => ({ ...obj, extra: true }));
    const result = decodeAndValidateToken({
      apiHeaders,
      headerKey: 'x-access-token',
      logger,
      options: {
        fieldMappings: { userId: 'userId' },
        postProcess,
      },
    });
    expect(postProcess).toHaveBeenCalled();
    expect(result).toEqual({ userId: 'user1' });
  });
});
