import { PdpQueryResult } from '../src';
import {
  transformPdpQueryResult,
  getPermittedPdpQueryResult,
} from '../src/transformPdpQueryResult';

describe('transformPdpQueryResult', () => {
  it('should return an array of string values when decision is PERMIT', () => {
    const pdpQueryResult: PdpQueryResult[] = [
      {
        decision: 'PERMIT',
        attribute: 'RequestAttributes.BeneficiaryId',
        value: '492d9990-8f31-450a-aae2-a47bda425fe3',
      },
      {
        decision: 'PERMIT',
        attribute: 'RequestAttributes.BeneficiaryId',
        value: '3b5805b0-40a1-4ce4-9656-50b7e907518f',
      },
      {
        decision: 'PERMIT',
        attribute: 'RequestAttributes.BeneficiaryId',
        value: 'fd6707d4-feb2-40af-bb09-a3966bedd3d4',
      },
    ];
    const result = transformPdpQueryResult(pdpQueryResult);
    expect(result).toEqual([
      '492d9990-8f31-450a-aae2-a47bda425fe3',
      '3b5805b0-40a1-4ce4-9656-50b7e907518f',
      'fd6707d4-feb2-40af-bb09-a3966bedd3d4',
    ]);
  });

  it('should return an empty array when decision is not PERMIT', () => {
    const pdpQueryResult: PdpQueryResult[] = [
      {
        decision: 'DENY',
        attribute: 'RequestAttributes.BeneficiaryId',
        value: '492d9990-8f31-450a-aae2-a47bda425fe3',
      },
      {
        decision: 'DENY',
        attribute: 'RequestAttributes.BeneficiaryId',
        value: '3b5805b0-40a1-4ce4-9656-50b7e907518f',
      },
    ];
    const result = transformPdpQueryResult(pdpQueryResult);
    expect(result).toEqual([]);
  });

  it('should apply filterFn to include only value equal to active (status)', () => {
    const pdpQueryResult: PdpQueryResult[] = [
      { value: 'ACTIVE', decision: 'PERMIT' },
      { value: 'ARCHIVE', decision: 'PERMIT' },
    ];
    const result = transformPdpQueryResult(
      pdpQueryResult,
      undefined,
      v => v === 'ACTIVE'
    );
    expect(result).toEqual(['ACTIVE']);
  });

  it('should apply both filterfn and mapFn to filter NaN and convert values to numbers', () => {
    const pdpQueryResult: PdpQueryResult[] = [
      { value: '100', decision: 'PERMIT' },
      { value: '200', decision: 'PERMIT' },
      { value: '100abc', decision: 'PERMIT' },
    ];
    const result = transformPdpQueryResult(
      pdpQueryResult,
      v => Number(v),
      v => !isNaN(Number(v))
    );
    expect(result).toEqual([100, 200]);
  });

  it('should apply a custom mapFn returning objects', () => {
    const pdpQueryResult: PdpQueryResult[] = [
      { value: '300', decision: 'PERMIT' },
    ];
    const result = transformPdpQueryResult(pdpQueryResult, v => ({
      original: v,
      parsed: Number(v),
    }));
    expect(result).toEqual([{ original: '300', parsed: 300 }]);
  });
});

describe('getPermittedPdpQueryResult', () => {
  it('should return only accounts with decision PERMIT', () => {
    const input: PdpQueryResult[] = [
      { value: '12345678901234', decision: 'PERMIT' },
      { value: '23456789012345', decision: 'DENY' },
      { value: '34567890123456', decision: 'PERMIT' },
    ];
    const result = getPermittedPdpQueryResult(input);
    expect(result).toEqual([
      { value: '12345678901234', decision: 'PERMIT' },
      { value: '34567890123456', decision: 'PERMIT' },
    ]);
  });

  it('should return an empty array if input is empty', () => {
    const input: PdpQueryResult[] = [];
    const result = getPermittedPdpQueryResult(input);
    expect(result).toEqual([]);
  });
});
