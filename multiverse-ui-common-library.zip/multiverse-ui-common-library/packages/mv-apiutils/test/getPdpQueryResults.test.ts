import { getPdpQueryResults } from '../src/getPdpQueryResults';
import { PDP_ATTRIBUTES, PdpQueryApiResponse } from '../src/types';
import { PDP_QUERY_ACTIONS } from '@mesh-tenant-user-authorisation-policy-decision-engine/entitlements-api-lib';
const {
  pdpQuery,
} = require('@mesh-tenant-user-authorisation-policy-decision-engine/entitlements-api-lib');

jest.mock(
  '@mesh-tenant-user-authorisation-policy-decision-engine/entitlements-api-lib',
  () => ({
    pdpQuery: jest.fn(),
    PDP_QUERY_ACTIONS: {
      VIEW_ACCOUNT: 'VIEW_ACCOUNT',
      VIEW_BENEFICIARY: 'VIEW_BENEFICIARY',
    },
  })
);

describe('getPdpQueryResults', () => {
  const meshSecretsContent = {
    pdpClientToken: 'token123',
    org: 'org456',
  };

  const req: any = {
    query: {},
  };
  const res: any = {};

  const queryDecisionRequest = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('throws error if pdpClientToken or org is missing', async () => {
    await expect(
      getPdpQueryResults({
        meshSecretsContent: { pdpClientToken: undefined, org: undefined },
        req,
        res,
        queryDecisionRequest,
        queryAttribute: PDP_ATTRIBUTES.ACC_ID,
      })
    ).rejects.toThrow('pdpClientToken is not defined in mesh secrets.');
  });

  it('calls pdpQuery with correct params for ACC_ID without groupId', async () => {
    const pdpQueryResults = [{ id: 1 }];
    (pdpQuery as jest.Mock).mockResolvedValue({
      data: { results: pdpQueryResults },
    } as PdpQueryApiResponse);

    const results = await getPdpQueryResults({
      meshSecretsContent,
      req: { query: {} },
      res,
      queryDecisionRequest,
      queryAttribute: PDP_ATTRIBUTES.ACC_ID,
    });

    expect(pdpQuery).toHaveBeenCalledWith(
      expect.objectContaining({
        pdpQueryRequestBody: expect.objectContaining({
          pdpClientToken: meshSecretsContent.pdpClientToken,
          query: [{ attribute: PDP_ATTRIBUTES.ACC_ID }],
          context: {
            action: 'QUERY',
            attributes: {
              [PDP_ATTRIBUTES.ORG_ID]: meshSecretsContent.org,
              [PDP_ATTRIBUTES.REQ_ACTION]: PDP_QUERY_ACTIONS.VIEW_ACCOUNT,
            },
          },
        }),
      })
    );
    expect(results).toEqual(pdpQueryResults);
  });

  it('calls pdpQuery with correct params for ACC_ID with groupId', async () => {
    const pdpQueryResults = [{ id: 2 }];
    (pdpQuery as jest.Mock).mockResolvedValue({
      data: { results: pdpQueryResults },
    } as PdpQueryApiResponse);

    const results = await getPdpQueryResults({
      meshSecretsContent,
      req: { query: { groupId: 'group789' } },
      res,
      queryDecisionRequest,
      queryAttribute: PDP_ATTRIBUTES.ACC_ID,
    });

    expect(pdpQuery).toHaveBeenCalledWith(
      expect.objectContaining({
        pdpQueryRequestBody: expect.objectContaining({
          context: expect.objectContaining({
            attributes: expect.objectContaining({
              [PDP_ATTRIBUTES.SCOPE_ID]: 'group789',
              [PDP_ATTRIBUTES.REQ_ACTION]: PDP_QUERY_ACTIONS.VIEW_ACCOUNT,
            }),
          }),
        }),
      })
    );
    expect(results).toEqual(pdpQueryResults);
  });

  it('calls pdpQuery with correct params for BENE_ID', async () => {
    const pdpQueryResults = [{ id: 3 }];
    (pdpQuery as jest.Mock).mockResolvedValue({
      data: { results: pdpQueryResults },
    } as PdpQueryApiResponse);

    const results = await getPdpQueryResults({
      meshSecretsContent,
      req,
      res,
      queryDecisionRequest,
      queryAttribute: PDP_ATTRIBUTES.BENE_ID,
    });

    expect(pdpQuery).toHaveBeenCalledWith(
      expect.objectContaining({
        pdpQueryRequestBody: expect.objectContaining({
          query: [{ attribute: PDP_ATTRIBUTES.BENE_ID }],
          context: {
            action: 'QUERY',
            attributes: {
              [PDP_ATTRIBUTES.ORG_ID]: meshSecretsContent.org,
              [PDP_ATTRIBUTES.REQ_ACTION]: PDP_QUERY_ACTIONS.VIEW_BENEFICIARY,
            },
          },
        }),
      })
    );
    expect(results).toEqual(pdpQueryResults);
  });

  it('calls pdpQuery with correct params for SCOPE_ID', async () => {
    const pdpQueryResults = [{ id: 4 }];
    (pdpQuery as jest.Mock).mockResolvedValue({
      data: { results: pdpQueryResults },
    } as PdpQueryApiResponse);

    const results = await getPdpQueryResults({
      meshSecretsContent,
      req,
      res,
      queryDecisionRequest,
      queryAttribute: PDP_ATTRIBUTES.SCOPE_ID,
    });

    expect(pdpQuery).toHaveBeenCalledWith(
      expect.objectContaining({
        pdpQueryRequestBody: expect.objectContaining({
          query: [{ attribute: PDP_ATTRIBUTES.SCOPE_ID }],
          context: {
            action: 'QUERY',
            attributes: {
              [PDP_ATTRIBUTES.ORG_ID]: meshSecretsContent.org,
              [PDP_ATTRIBUTES.REQ_ACTION]: PDP_QUERY_ACTIONS.VIEW_ACCOUNT,
            },
          },
        }),
      })
    );
    expect(results).toEqual(pdpQueryResults);
  });

  it('returns undefined if pdpQueryResponse.data.results is undefined', async () => {
    (pdpQuery as jest.Mock).mockResolvedValue({ data: {} });

    const results = await getPdpQueryResults({
      meshSecretsContent,
      req,
      res,
      queryDecisionRequest,
      queryAttribute: PDP_ATTRIBUTES.ACC_ID,
    });

    expect(results).toBeUndefined();
  });

  it('passes setDownstreamParams to pdpQuery if provided', async () => {
    const pdpQueryResults = [{ id: 5 }];
    (pdpQuery as jest.Mock).mockResolvedValue({
      data: { results: pdpQueryResults },
    } as PdpQueryApiResponse);

    const setDownstreamParams = { some: 'param' };

    await getPdpQueryResults({
      meshSecretsContent,
      req,
      res,
      queryDecisionRequest,
      queryAttribute: PDP_ATTRIBUTES.ACC_ID,
      setDownstreamParams,
    });

    expect(pdpQuery).toHaveBeenCalledWith(
      expect.objectContaining({
        setDownstreamParams,
      })
    );
  });
});
