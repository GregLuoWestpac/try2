/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { STATUS_CODES } from '../src/constants';
import { handleControllerError } from '../src/handleError';
import { APIClientError, HandleControllerErrorParams } from '../src/types';

describe('handleControllerError', () => {
  let mockRes: any;
  let mockLogger: any;

  beforeEach(() => {
    mockRes = {
      status: jest.fn().mockReturnThis(),
      send: jest.fn(),
    };
    mockLogger = {
      error: jest.fn(),
    };
  });

  it('should handle error with status and message', () => {
    const error = {
      type: 'type',
      error: {
        status: 400,
        statusText: 'Bad Request',
        data: {
          result: {
            errors: [
              {
                code: 'INVALID_INPUT',
                message: 'Invalid input provided',
                details: 'Details about the error',
              },
            ],
          },
        },
      },
    };
    const params: HandleControllerErrorParams = {
      error,
      res: mockRes,
      logger: mockLogger,
    };

    handleControllerError(params);

    expect(mockLogger.error).toHaveBeenCalledWith(error);
    expect(mockRes.status).toHaveBeenCalledWith(400);
    expect(mockRes.send).toHaveBeenCalledWith({
      result: {
        errors: [
          {
            code: 'INVALID_INPUT',
            message: 'Invalid input provided',
            details: 'Details about the error',
          },
        ],
      },
    });
  });

  it('should handle error without status and message', () => {
    const error = {
      error: {},
    };
    const params: HandleControllerErrorParams = {
      // @ts-ignore
      error,
      res: mockRes,
      logger: mockLogger,
    };

    handleControllerError(params);

    expect(mockLogger.error).toHaveBeenCalledWith(error);
    expect(mockRes.status).toHaveBeenCalledWith(
      STATUS_CODES.INTERNAL_SERVER_ERROR
    );
    expect(mockRes.send).toHaveBeenCalledWith(undefined);
  });

  it('should handle error with partial data', () => {
    const error: APIClientError = {
      type: 'type',
      error: {
        status: 500,
        statusText: 'Bad Request',
        data: {
          result: {
            errors: [
              {
                message: 'Something went wrong',
              },
            ],
          },
        },
      },
    };
    const params: HandleControllerErrorParams = {
      error,
      res: mockRes,
      logger: mockLogger,
    };

    handleControllerError(params);

    expect(mockLogger.error).toHaveBeenCalledWith(error);
    expect(mockRes.status).toHaveBeenCalledWith(500);
    expect(mockRes.send).toHaveBeenCalledWith({
      result: {
        errors: [
          {
            message: 'Something went wrong',
          },
        ],
      },
    });
  });
});
