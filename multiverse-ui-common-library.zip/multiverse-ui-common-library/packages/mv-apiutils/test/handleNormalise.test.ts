import { schema } from 'normalizr';
import {
  createSchemaBuilder,
  createSchemaEntity,
  normaliseData,
} from '../src/handleNormalise';

describe('handleNormalise', () => {
  const mockNormalise = jest.fn();

  it('should create a schema entity', () => {
    const entity = createSchemaEntity('test');
    expect(entity).toBeInstanceOf(schema.Entity);
    expect(entity.key).toBe('test');
  });

  it('should create a schema builder', () => {
    const entity = createSchemaEntity('test');
    const schemaBuilder = createSchemaBuilder('test', entity);
    expect(schemaBuilder).toBeInstanceOf(schema.Object);
  });

  it('should normalise data', () => {
    const data = [{ id: 1, name: 'Test' }];
    normaliseData('test', data, mockNormalise);
    // const result = normaliseData('test', data, mockNormalise);
    expect(mockNormalise).toHaveBeenCalledWith(
      { test: data },
      expect.any(Object)
    );
  });
});
