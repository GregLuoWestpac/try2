import {
  transformAccountList,
  PdpQueryResult,
  sortLimitParams,
} from '../src/transformAccountList';
describe('transformAccountList', () => {
  it('should return an array with BSB and accountNumber', () => {
    const pdpQueryResult: PdpQueryResult[] = [
      { value: '12345678901234', decision: 'PERMIT' },
      { value: '23456789012345', decision: 'PERMIT' },
    ];
    const result = transformAccountList(pdpQueryResult);
    expect(result).toEqual([
      { BSB: '123456', accountNumber: '78901234' },
      { BSB: '234567', accountNumber: '89012345' },
    ]);
  });
  it('should sort accounts in ascending order by accountId when sortBy is "+accountId"', () => {
    const pdpQueryResult: PdpQueryResult[] = [
      { value: '23456789012345', decision: 'PERMIT' },
      { value: '12345678901234', decision: 'PERMIT' },
    ];
    const params: sortLimitParams = { sortBy: '+accountId' };
    const result = transformAccountList(pdpQueryResult, params);
    expect(result).toEqual([
      { BSB: '123456', accountNumber: '78901234' },
      { BSB: '234567', accountNumber: '89012345' },
    ]);
  });
  it('should sort accounts in descending order by accountId when sortBy is "-accountId"', () => {
    const pdpQueryResult: PdpQueryResult[] = [
      { value: '12345678901234', decision: 'PERMIT' },
      { value: '23456789012345', decision: 'PERMIT' },
    ];
    const params: sortLimitParams = { sortBy: '-accountId' };
    const result = transformAccountList(pdpQueryResult, params);
    expect(result).toEqual([
      { BSB: '234567', accountNumber: '89012345' },
      { BSB: '123456', accountNumber: '78901234' },
    ]);
  });
  it('should sort accounts in ascending order by accountName when sortBy is "+accountName"', () => {
    const pdpQueryResult: PdpQueryResult[] = [
      {
        value: '23456789012345',
        decision: 'PERMIT',
        statements: [
          {
            payload: JSON.stringify({ name: 'Zebra' }),
            id: '',
            name: '',
            code: '',
            obligatory: false,
            fulfilled: false,
            attributes: undefined,
          },
        ],
      },
      {
        value: '12345678901234',
        decision: 'PERMIT',
        statements: [
          {
            payload: JSON.stringify({ name: 'Apple' }),
            id: '',
            name: '',
            code: '',
            obligatory: false,
            fulfilled: false,
            attributes: undefined,
          },
        ],
      },
    ];
    const params: sortLimitParams = { sortBy: '+accountName' };
    const result = transformAccountList(pdpQueryResult, params);
    expect(result).toEqual([
      { BSB: '123456', accountNumber: '78901234' },
      { BSB: '234567', accountNumber: '89012345' },
    ]);
  });
  it('should sort accounts in descending order by accountName when sortBy is "-accountName"', () => {
    const pdpQueryResult: PdpQueryResult[] = [
      {
        value: '12345678901234',
        decision: 'PERMIT',
        statements: [
          {
            payload: JSON.stringify({ name: 'Apple' }),
            id: '',
            name: '',
            code: '',
            obligatory: false,
            fulfilled: false,
            attributes: undefined,
          },
        ],
      },
      {
        value: '23456789012345',
        decision: 'PERMIT',
        statements: [
          {
            payload: JSON.stringify({ name: 'Zebra' }),
            id: '',
            name: '',
            code: '',
            obligatory: false,
            fulfilled: false,
            attributes: undefined,
          },
        ],
      },
    ];
    const params: sortLimitParams = { sortBy: '-accountName' };
    const result = transformAccountList(pdpQueryResult, params);
    expect(result).toEqual([
      { BSB: '234567', accountNumber: '89012345' },
      { BSB: '123456', accountNumber: '78901234' },
    ]);
  });
  it('should handle invalid payloads gracefully', () => {
    const pdpQueryResult: PdpQueryResult[] = [
      {
        value: '12345678901234',
        decision: 'PERMIT',
        statements: [
          {
            payload: 'INVALID_JSON',
            id: '',
            name: '',
            code: '',
            obligatory: false,
            fulfilled: false,
            attributes: undefined,
          },
        ],
      },
      {
        value: '23456789012345',
        decision: 'PERMIT',
        statements: [
          {
            payload: JSON.stringify({ name: 'ValidName' }),
            id: '',
            name: '',
            code: '',
            obligatory: false,
            fulfilled: false,
            attributes: undefined,
          },
        ],
      },
    ];
    const params: sortLimitParams = { sortBy: '+accountName' };
    const result = transformAccountList(pdpQueryResult, params);
    expect(result).toEqual([
      { BSB: '123456', accountNumber: '78901234' }, // invalid JSON
      { BSB: '234567', accountNumber: '89012345' }, // ValidName
    ]);
  });
  it('should limit the number of results based on pageSize', () => {
    const pdpQueryResult: PdpQueryResult[] = [
      { value: '12345678901234', decision: 'PERMIT' },
      { value: '23456789012345', decision: 'PERMIT' },
    ];
    const params: sortLimitParams = { pageSize: 2 };
    const result = transformAccountList(pdpQueryResult, params);
    expect(result).toEqual([
      { BSB: '123456', accountNumber: '78901234' },
      { BSB: '234567', accountNumber: '89012345' },
    ]);
  });
  it('should handle pageSize of 0 gracefully', () => {
    const pdpQueryResult: PdpQueryResult[] = [
      { value: '12345678901234', decision: 'PERMIT' },
    ];
    const params: sortLimitParams = { pageSize: 0 };
    const result = transformAccountList(pdpQueryResult, params);
    expect(result).toEqual([]);
  });
  it('should handle missing sortBy and pageSize parameters', () => {
    const pdpQueryResult: PdpQueryResult[] = [
      { value: '12345678901234', decision: 'PERMIT' },
      { value: '23456789012345', decision: 'PERMIT' },
    ];
    const result = transformAccountList(pdpQueryResult);
    expect(result).toEqual([
      { BSB: '123456', accountNumber: '78901234' },
      { BSB: '234567', accountNumber: '89012345' },
    ]);
  });
  it('should handle an empty input array gracefully', () => {
    const pdpQueryResult: PdpQueryResult[] = [];
    const result = transformAccountList(pdpQueryResult);
    expect(result).toEqual([]);
  });
  it('should handle statements with undefined payload gracefully', () => {
    const pdpQueryResult: PdpQueryResult[] = [
      {
        value: '12345678901234',
        decision: 'PERMIT',
        statements: [
          {
            payload: undefined,
            id: '',
            name: '',
            code: '',
            obligatory: false,
            fulfilled: false,
            attributes: undefined,
          },
        ],
      },
      {
        value: '23456789012345',
        decision: 'PERMIT',
        statements: [
          {
            payload: JSON.stringify({ name: 'Zebra' }),
            id: '',
            name: '',
            code: '',
            obligatory: false,
            fulfilled: false,
            attributes: undefined,
          },
        ],
      },
    ];
    const params: sortLimitParams = { sortBy: '+accountName' };
    const result = transformAccountList(pdpQueryResult, params);
    expect(result).toEqual([
      { BSB: '123456', accountNumber: '78901234' }, // undefined payload, sorts as ''
      { BSB: '234567', accountNumber: '89012345' }, // Zebra
    ]);
  });
});
