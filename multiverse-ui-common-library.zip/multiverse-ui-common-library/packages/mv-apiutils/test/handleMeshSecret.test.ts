jest.mock('fs/promises');

import { readMeshSecrets } from '../src/handleMeshSecret';
import * as mockFs from 'fs/promises';

describe('readMeshSecrets', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should return null if secrets directory does not exist', async () => {
    (mockFs.access as jest.Mock).mockRejectedValue(
      new Error('Directory not found')
    );

    const logger = {
      info: jest.fn(),
    };

    const result = await readMeshSecrets({
      logger,
      secretsDir: '/secrets',
    });

    expect(result).toBeNull();
    expect(logger.info).toHaveBeenCalledWith(
      'readMeshSecrets - diagnosticsOutputMessage -',
      'Cannot find the directory: /secrets'
    );
  });
});
