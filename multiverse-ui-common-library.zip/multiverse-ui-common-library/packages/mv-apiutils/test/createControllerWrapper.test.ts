/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response, NextFunction } from 'express';
import {
  createControllerWrapper,
  ControllerParams,
} from '../src/createControllerWrapper';
import { handleControllerError } from '../src/handleError';

// Mock the handleControllerError function
jest.mock('../src/handleError', () => ({
  handleControllerError: jest.fn(),
}));

describe('createControllerWrapper', () => {
  let mockReq: Partial<Request>;
  let mockRes: Partial<Response>;
  let mockNext: NextFunction;
  let mockControllerParams: ControllerParams;
  let mockHandler: jest.MockedFunction<any>;

  beforeEach(() => {
    mockHandler = jest.fn();
    mockNext = jest.fn();

    mockReq = {
      query: { groupId: 'test-group' },
      get: jest.fn().mockReturnValue('test-org-cis-key'),
    };

    mockRes = {
      locals: {
        logger: {
          info: jest.fn(),
          error: jest.fn(),
          warn: jest.fn(),
          debug: jest.fn(),
        },
        apiHeaders: {},
      },
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      end: jest.fn(),
    };

    mockControllerParams = {
      RUNTIME: {
        isLocal: () => false,
      },
      normalise: jest.fn(),
      apiClient: {
        queryDecisionRequest: jest.fn(),
      },
      readMeshSecrets: jest.fn().mockReturnValue({
        pdpClientToken: 'test-token',
      }),
    };

    // Clear all mocks
    jest.clearAllMocks();
  });

  it('should call handler function successfully', async () => {
    // Arrange
    mockHandler.mockResolvedValue(undefined);
    const wrappedController = createControllerWrapper(
      mockHandler,
      mockControllerParams
    );

    // Act
    await wrappedController(mockReq as Request, mockRes as Response, mockNext);

    // Assert
    expect(mockHandler).toHaveBeenCalledWith(
      mockReq,
      mockRes,
      mockControllerParams
    );
    expect(mockNext).not.toHaveBeenCalled();
  });

  it('should handle errors and call next middleware', async () => {
    // Arrange
    const error = new Error('Handler error');
    mockHandler.mockRejectedValue(error);
    const wrappedController = createControllerWrapper(
      mockHandler,
      mockControllerParams
    );

    const mockHandleControllerError =
      handleControllerError as jest.MockedFunction<
        typeof handleControllerError
      >;

    // Act
    await wrappedController(mockReq as Request, mockRes as Response, mockNext);

    // Assert
    expect(mockHandler).toHaveBeenCalledWith(
      mockReq,
      mockRes,
      mockControllerParams
    );
    expect(mockHandleControllerError).toHaveBeenCalledWith({
      error,
      res: mockRes,
      logger: mockRes.locals.logger,
    });
    expect(mockNext).toHaveBeenCalledWith(error);
  });

  it('should pass through different controller params', async () => {
    // Arrange
    const differentParams = {
      ...mockControllerParams,
      RUNTIME: { isLocal: () => true },
    };
    mockHandler.mockResolvedValue(undefined);
    const wrappedController = createControllerWrapper(
      mockHandler,
      differentParams
    );

    // Act
    await wrappedController(mockReq as Request, mockRes as Response, mockNext);

    // Assert
    expect(mockHandler).toHaveBeenCalledWith(mockReq, mockRes, differentParams);
  });

  it('should handle async handler functions', async () => {
    // Arrange
    const asyncHandler = jest.fn().mockImplementation(async () => {
      await new Promise(resolve => setTimeout(resolve, 10));
      return;
    });
    const wrappedController = createControllerWrapper(
      asyncHandler,
      mockControllerParams
    );

    // Act
    await wrappedController(mockReq as Request, mockRes as Response, mockNext);

    // Assert
    expect(asyncHandler).toHaveBeenCalledWith(
      mockReq,
      mockRes,
      mockControllerParams
    );
    expect(mockNext).not.toHaveBeenCalled();
  });

  it('should preserve req, res, and next function types', async () => {
    // Arrange
    const typeCheckHandler = jest
      .fn()
      .mockImplementation(async (req: Request, res: Response) => {
        // This test ensures TypeScript types are preserved
        expect(typeof req).toBe('object');
        expect(typeof res).toBe('object');
        expect(res.status).toBeDefined();
        expect(res.json).toBeDefined();
      });
    const wrappedController = createControllerWrapper(
      typeCheckHandler,
      mockControllerParams
    );

    // Act
    await wrappedController(mockReq as Request, mockRes as Response, mockNext);

    // Assert
    expect(typeCheckHandler).toHaveBeenCalled();
  });
});
