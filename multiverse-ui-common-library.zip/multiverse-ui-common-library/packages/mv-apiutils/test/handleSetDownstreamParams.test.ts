/* eslint-disable @typescript-eslint/ban-ts-comment */
import { Response } from 'express';
import {
  defaultSetDownstreamParams,
  getHeader,
} from '../src/handleSetDownstreamParams';
import { ApiHeaders, AppConfig } from '../src/types';

describe('handleSetDownstreamParams', () => {
  let res: Partial<Response>;
  let appConfig: AppConfig;

  beforeEach(() => {
    res = {
      locals: {
        BSB: '123456',
        brandSilo: 'testBrandSilo',
      },
      // @ts-ignore
      req: {
        // @ts-ignore
        get: jest.fn().mockReturnValue('testSystem'),
      },
    };

    appConfig = {
      originatingBSB: '654321',
      organisationId: 'testOrgId',
    };
  });

  describe('getHeader', () => {
    it('should return headers with x-originatingBSB and x-systemtest', () => {
      const inputHeaders: ApiHeaders = { 'content-type': 'application/json' };
      const result = getHeader(inputHeaders, res as Response, appConfig);

      expect(result).toEqual({
        'content-type': 'application/json',
        'x-originatingBSB': '123456',
        'x-systemtest': 'testSystem',
      });
    });

    it('should return headers with default x-originatingBSB if not in locals', () => {
      res.locals.BSB = undefined;
      const inputHeaders: ApiHeaders = { 'content-type': 'application/json' };
      const result = getHeader(inputHeaders, res as Response, appConfig);

      expect(result).toEqual({
        'content-type': 'application/json',
        'x-originatingBSB': '654321',
        'x-systemtest': 'testSystem',
      });
    });

    it('should not include x-systemtest if not present in request', () => {
      // @ts-ignore
      res.req.get = jest.fn().mockReturnValue('');
      const inputHeaders: ApiHeaders = { 'content-type': 'application/json' };
      const result = getHeader(inputHeaders, res as Response, appConfig);

      expect(result).toEqual({
        'content-type': 'application/json',
        'x-originatingBSB': '123456',
      });
    });
  });

  describe('defaultSetDownstreamParams', () => {
    it('should return correct downstream params', () => {
      const inputHeaders: ApiHeaders = { 'content-type': 'application/json' };
      const requestBody = { key: 'value' };
      const queryParams = { param1: 'value1' };

      const result = defaultSetDownstreamParams(
        inputHeaders,
        res as Response,
        requestBody,
        appConfig,
        queryParams
      );

      expect(result).toEqual({
        header: {
          'content-type': 'application/json',
          'x-originatingBSB': '123456',
          'x-systemtest': 'testSystem',
        },
        body: { key: 'value' },
        query: {
          brandSilo: 'testBrandSilo',
          param1: 'value1',
        },
      });
    });

    it('should use default brandSilo if not in locals', () => {
      res.locals.brandSilo = undefined;
      const inputHeaders: ApiHeaders = { 'content-type': 'application/json' };
      const requestBody = { key: 'value' };
      const queryParams = { param1: 'value1' };

      const result = defaultSetDownstreamParams(
        inputHeaders,
        res as Response,
        requestBody,
        appConfig,
        queryParams
      );

      expect(result).toEqual({
        header: {
          'content-type': 'application/json',
          'x-originatingBSB': '123456',
          'x-systemtest': 'testSystem',
        },
        body: { key: 'value' },
        query: {
          brandSilo: 'testOrgId',
          param1: 'value1',
        },
      });
    });
  });
});
