import {
  convertSydneyLocalTimeToUtc,
  getCurrentFinancialYear,
  getFormattedDateWithoutZoneName,
} from '../src/datetime';

describe('getFormattedDateWithoutZoneName', () => {
  it('should return current UTC time with formate yyyy-MM-dd', () => {
    const result = getFormattedDateWithoutZoneName();
    expect(result).toMatch(/^\d{4}-\d{2}-\d{2}$/);
  });
});

describe('Testing convertSydneyLocalTimeToUtc', () => {
  it('should return correct UTC time in Australian Eastern Daylight Time (AEDT, UTC+11)', () => {
    const date = '2024-11-01 21:56:38';
    const expected = '2024-11-01T10:56:38.000Z';
    const result = convertSydneyLocalTimeToUtc(date);
    expect(result).toBe(expected);
  });

  it('should return correct UTC time in Australian Eastern Standard Time (AEST, UTC+10)', () => {
    const date = '2024-06-01 21:56:38';
    const expected = '2024-06-01T11:56:38.000Z';
    const result = convertSydneyLocalTimeToUtc(date);
    expect(result).toBe(expected);
  });

  it('should return correct UTC time in Australian Eastern Daylight Time (AEDT, UTC+11) for end date', () => {
    const date = '2025-07-11 09:56:38';
    const expected = '2025-07-11T13:59:59.999Z';
    const result = convertSydneyLocalTimeToUtc(date, 'end');
    expect(result).toBe(expected);
  });

  it('should return correct UTC time in Australian Eastern Standard Time (AEST, UTC+10) for end date', () => {
    const date = '2025-11-11 01:56:38';
    const expected = '2025-11-11T12:59:59.999Z';
    const result = convertSydneyLocalTimeToUtc(date, 'end');
    expect(result).toBe(expected);
  });

  it('should return empty string when input date is null', () => {
    const result = convertSydneyLocalTimeToUtc(null);
    expect(result).toBe('');
  });

  it('should return null when input date is invalid date string', () => {
    const date = '2000-66-33 55:99';
    const result = convertSydneyLocalTimeToUtc(date);
    expect(result).toBeNull();
  });
});

describe('Testing getCurrentFinancialYear', () => {
  it('should return financial year as 4 digits number', () => {
    const financialYear = getCurrentFinancialYear();
    expect(financialYear.toString()).toMatch(/^\d{4}$/);
  });
});
