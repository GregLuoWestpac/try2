# @mesh-tenant-multiverse-ui-common/mv-apiutils

A utility library for API-related helpers and functions, designed for use within the Multiverse UI Common Library ecosystem.

## Features

- Simplifies API requests and responses
- Provides common utilities for error handling, data transformation, and more
- Designed for easy integration with other Multiverse UI Common Library packages

## Installation

```bash
npm install @mesh-tenant-multiverse-ui-common/mv-apiutils
```

## To build locally

```bash
nx run @mesh-tenant-multiverse-ui-common/mv-apiutils:build
```
