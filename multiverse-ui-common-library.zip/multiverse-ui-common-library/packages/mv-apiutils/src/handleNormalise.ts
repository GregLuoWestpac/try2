import { schema } from 'normalizr';
import { ApiResponse } from './types';

export const createSchemaEntity = <T>(key: string) => new schema.Entity<T>(key);

export const createSchemaBuilder = <T>(key: string, entity: schema.Entity<T>) =>
  new schema.Object({
    [key]: new schema.Array(entity),
  });

export const normaliseData = <T>(
  key: string,
  data: T[],
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  normalise: any
): ApiResponse<T> => {
  const entity = createSchemaEntity<T>(key);
  const schemaBuilder = createSchemaBuilder<T>(key, entity);
  const normalisedData = normalise({ [key]: data }, schemaBuilder);

  if (Array.isArray(data) && data.length === 0) {
    normalisedData.entities[key] = [];
  }

  return normalisedData;
};

export const normaliseDataWithPaging = <T, U>(
  key: string,
  data: Record<string, T | U>,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  normalise: any
): ApiResponse<T | U> => {
  const SCHEMA_KEY_PAGING = 'paging';

  const entity = createSchemaEntity<T>(key);
  const pagingEntity = createSchemaEntity<U>(SCHEMA_KEY_PAGING);

  const normalisedData = normalise(data, {
    [key]: [entity],
    paging: [pagingEntity],
  });

  if (Array.isArray(data[key]) && data[key].length === 0) {
    normalisedData.entities[key] = [];
  }

  delete normalisedData.result.paging;

  return normalisedData;
};
