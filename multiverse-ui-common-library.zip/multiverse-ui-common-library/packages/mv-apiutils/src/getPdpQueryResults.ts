import {
  GetAccountIdsFromPdpQueryResultParams,
  GetBeneficiaryIdsFromPdpQueryResultParams,
  GetGroupIdsFromPdpQueryResultParams,
  GetDivisionsFromPdpQueryResultParams,
  GetPdpQueryResultsParams,
  PDP_ATTRIBUTES,
  PDP_CONTEXT_ATTRIBUTES,
  PDP_QUERY_ATTRIBUTES,
  PdpQueryApiResponse,
} from './types';
import {
  PDP_QUERY_ACTIONS,
  pdpQuery,
  PdpQueryRequest,
} from '@mesh-tenant-user-authorisation-policy-decision-engine/entitlements-api-lib';
import { getPermittedPdpQueryResult } from './transformPdpQueryResult';
import { maskObjectData } from './maskUserData';

// TODO: Remove this function after the migration to the new PDP query functions is complete.
export async function getPdpQueryResults({
  meshSecretsContent,
  req,
  res,
  queryDecisionRequest,
  queryAttribute,
  setDownstreamParams,
}: GetPdpQueryResultsParams) {
  const { pdpClientToken, org } = meshSecretsContent;
  if (!pdpClientToken) {
    throw new Error('pdpClientToken is not defined in mesh secrets.');
  }

  const queryParams = req.query || {};
  const contextAttributesMap = {
    [PDP_ATTRIBUTES.ACC_ID]: {
      ...(queryParams?.groupId
        ? { [PDP_ATTRIBUTES.SCOPE_ID]: queryParams.groupId as string }
        : { [PDP_ATTRIBUTES.ORG_ID]: org }),
      [PDP_ATTRIBUTES.REQ_ACTION]: PDP_QUERY_ACTIONS.VIEW_ACCOUNT,
    },
    [PDP_ATTRIBUTES.BENE_ID]: {
      [PDP_ATTRIBUTES.ORG_ID]: org,
      [PDP_ATTRIBUTES.REQ_ACTION]: PDP_QUERY_ACTIONS.VIEW_BENEFICIARY,
    },
    [PDP_ATTRIBUTES.SCOPE_ID]: {
      [PDP_ATTRIBUTES.ORG_ID]: org,
      [PDP_ATTRIBUTES.REQ_ACTION]: PDP_QUERY_ACTIONS.VIEW_ACCOUNT,
    },
  };

  const pdpQueryRequestBody: PdpQueryRequest = {
    pdpClientToken,
    query: [
      {
        attribute: queryAttribute,
      },
    ],
    context: {
      action: 'QUERY',
      attributes: contextAttributesMap[queryAttribute],
    },
  };

  const pdpQueryResponse = (await pdpQuery({
    req,
    res,
    apiClient: queryDecisionRequest,
    pdpQueryRequestBody,
    setDownstreamParams,
  })) as PdpQueryApiResponse;

  const pdpQueryResults = pdpQueryResponse?.data?.results;
  return pdpQueryResults;
}

export const getAccountIdsFromPdpQueryResult = async ({
  res,
  req,
  queryDecisionRequest,
  pdpClientToken,
  orgCisKey,
  groupId,
  requestAction,
  userId,
  divisionId,
}: GetAccountIdsFromPdpQueryResultParams) => {
  const pdpQueryRequestBody: PdpQueryRequest = {
    pdpClientToken,
    query: [
      {
        attribute: PDP_QUERY_ATTRIBUTES.ACCOUNT_ID,
      },
    ],
    context: {
      action: 'QUERY',
      attributes: {
        ...(userId && { [PDP_CONTEXT_ATTRIBUTES.CUSTOMER_USER_ID]: userId }),
        ...(groupId && { [PDP_CONTEXT_ATTRIBUTES.SCOPE_ID]: groupId }),
        ...(orgCisKey && { [PDP_CONTEXT_ATTRIBUTES.ORG_ID]: orgCisKey }),
        ...(divisionId && { [PDP_CONTEXT_ATTRIBUTES.DIVISION_ID]: divisionId }),
        [PDP_CONTEXT_ATTRIBUTES.REQ_ACTION]: requestAction,
      },
    },
  };

  const logger = res.locals?.logger;

  const maskedRequestBody = maskObjectData(pdpQueryRequestBody, [
    PDP_CONTEXT_ATTRIBUTES.REQ_ACTION,
    'action',
    'attribute',
  ]);
  logger.info('PDP Query Request:', maskedRequestBody);

  const pdpQueryResponse = (await pdpQuery({
    req,
    res,
    apiClient: queryDecisionRequest,
    pdpQueryRequestBody,
  })) as PdpQueryApiResponse;

  const pdpQueryResults = pdpQueryResponse?.data?.results || [];
  const permittedAccountIds = getPermittedPdpQueryResult(pdpQueryResults);
  return permittedAccountIds;
};

export const getBeneficiaryIdsFromPdpQueryResult = async ({
  res,
  req,
  queryDecisionRequest,
  pdpClientToken,
  orgCisKey,
  requestAction,
  userId,
  divisionId,
}: GetBeneficiaryIdsFromPdpQueryResultParams) => {
  const pdpQueryRequestBody: PdpQueryRequest = {
    pdpClientToken,
    query: [
      {
        attribute: PDP_QUERY_ATTRIBUTES.BENEFICIARY_ID,
      },
    ],
    context: {
      action: 'QUERY',
      attributes: {
        ...(orgCisKey && { [PDP_CONTEXT_ATTRIBUTES.ORG_ID]: orgCisKey }),
        ...(userId && { [PDP_CONTEXT_ATTRIBUTES.CUSTOMER_USER_ID]: userId }),
        ...(divisionId && { [PDP_CONTEXT_ATTRIBUTES.DIVISION_ID]: divisionId }),
        [PDP_CONTEXT_ATTRIBUTES.REQ_ACTION]: requestAction,
      },
    },
  };

  const logger = res.locals?.logger;
  const maskedRequestBody = maskObjectData(pdpQueryRequestBody, [
    PDP_CONTEXT_ATTRIBUTES.REQ_ACTION,
    'action',
    'attribute',
  ]);
  logger.info('PDP Query Request (Beneficiary IDs):', maskedRequestBody);

  const pdpQueryResponse = (await pdpQuery({
    req,
    res,
    apiClient: queryDecisionRequest,
    pdpQueryRequestBody,
  })) as PdpQueryApiResponse;
  const pdpQueryResults = pdpQueryResponse?.data?.results || [];
  const permittedBeneficiaryIds = getPermittedPdpQueryResult(pdpQueryResults);
  return permittedBeneficiaryIds;
};

export const getGroupIdsFromPdpQueryResult = async ({
  res,
  req,
  queryDecisionRequest,
  pdpClientToken,
  orgCisKey,
  requestAction,
}: GetGroupIdsFromPdpQueryResultParams) => {
  const pdpQueryRequestBody: PdpQueryRequest = {
    pdpClientToken,
    query: [
      {
        attribute: PDP_QUERY_ATTRIBUTES.SCOPE_ID,
      },
    ],
    context: {
      action: 'QUERY',
      attributes: {
        ...(orgCisKey && { [PDP_CONTEXT_ATTRIBUTES.ORG_ID]: orgCisKey }),
        [PDP_CONTEXT_ATTRIBUTES.REQ_ACTION]: requestAction,
      },
    },
  };

  const logger = res.locals?.logger;
  const maskedRequestBody = maskObjectData(pdpQueryRequestBody, [
    PDP_CONTEXT_ATTRIBUTES.REQ_ACTION,
    'action',
    'attribute',
  ]);
  logger.info('PDP Query Request (Group IDs):', maskedRequestBody);

  const pdpQueryResponse = (await pdpQuery({
    req,
    res,
    apiClient: queryDecisionRequest,
    pdpQueryRequestBody,
  })) as PdpQueryApiResponse;

  const pdpQueryResults = pdpQueryResponse?.data?.results || [];
  const permittedScopeIds = getPermittedPdpQueryResult(pdpQueryResults);
  return permittedScopeIds;
};

export const getDivisionsFromPdpQueryResult = async ({
  res,
  req,
  queryDecisionRequest,
  pdpClientToken,
  orgCisKey,
  requestAction,
  userId,
}: GetDivisionsFromPdpQueryResultParams) => {
  const pdpQueryRequestBody: PdpQueryRequest = {
    pdpClientToken,
    query: [
      {
        attribute: PDP_QUERY_ATTRIBUTES.DIVISION_ID,
      },
    ],
    context: {
      action: 'QUERY',
      attributes: {
        ...(orgCisKey && { [PDP_CONTEXT_ATTRIBUTES.ORG_ID]: orgCisKey }),
        ...(userId && { [PDP_CONTEXT_ATTRIBUTES.CUSTOMER_USER_ID]: userId }),
        [PDP_CONTEXT_ATTRIBUTES.REQ_ACTION]: requestAction,
      },
    },
  };

  const logger = res.locals?.logger;
  const maskedRequestBody = maskObjectData(pdpQueryRequestBody, [
    PDP_CONTEXT_ATTRIBUTES.REQ_ACTION,
    'action',
    'attribute',
  ]);
  logger.info('PDP Query Request (Divisions):', maskedRequestBody);

  const pdpQueryResponse = (await pdpQuery({
    req,
    res,
    apiClient: queryDecisionRequest,
    pdpQueryRequestBody,
  })) as PdpQueryApiResponse;

  const pdpQueryResults = pdpQueryResponse?.data?.results || [];
  return pdpQueryResults;
};
