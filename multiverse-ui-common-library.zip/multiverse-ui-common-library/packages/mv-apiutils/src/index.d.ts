/**
 * mv-apituils Types
 */

import { Response, Request } from 'express';
import { APIError } from '@mep-node/framework-utilities';
import { NormalizedSchema } from 'normalizr';
import BunyanLogger from 'bunyan';

export type Error = {
  code?: string;
  message?: string;
  details?: string;
};

export type APIClientError = {
  type: string;
  error: {
    status: number;
    statusText: string;
    data: {
      result: {
        errors: Error[];
      };
    };
  };
};

export type Logger = BunyanLogger | Console;

export type HandleControllerErrorParams = {
  error: APIClientError;
  res: Response;
  logger: Logger;
};

export type AppConfig = Record<string, string>;
export type QueryParams = Record<string, string>;
export type ApiHeaders = Record<string, string>;
export type PathParams = Record<string, string>;

export type Params = {
  header: ApiHeaders;
  body: Record<string, unknown>;
  query: Record<string, string>;
};

export type ParamsWithPath = {
  header: ApiHeaders;
  body: Record<string, unknown> | undefined;
  query: Record<string, string>;
  path: Record<string, string> | undefined;
};

export type SetDownstreamParams = (
  apiHeaders: ApiHeaders,
  res: Response,
  requestBody: Record<string, unknown>,
  appConfig: AppConfig,
  queryParams?: QueryParams,
  pathParams?: PathParams
) => Params;

export type SetDownstreamParamsWithPath = (
  apiHeaders: ApiHeaders,
  res: Response,
  requestBody: Record<string, unknown> | undefined,
  appConfig: AppConfig,
  queryParams: QueryParams,
  pathParams: PathParams | undefined
) => ParamsWithPath;

export type RequestBody = Record<string, unknown>;

export type Paging = Record<string, string | number>;

export type DownstreamServiceResponseData = {
  data: Record<string, unknown>;
  paging?: Paging;
};

export type DownstreamServiceResponse = {
  data: DownstreamServiceResponseData;
  status: number;
  statusText: string;
  headers: unknown;
};

export type APIClient = (
  baseUrl: string,
  params: Params,
  apiConfig: AppConfig,
  req: Request,
  res: Response
) => Promise<DownstreamServiceResponse>;

export type HandleApiServiceParams = {
  req: Request;
  res: Response;
  apiClient: APIClient;
  setDownstreamParams?: SetDownstreamParams;
  requestBody?: RequestBody;
  queryParams?: QueryParams;
  pathParams?: PathParams;
  reqMethod?: string;
};

export type HandleApiServiceParamsWithPath = {
  req: Request;
  res: Response;
  queryParams: QueryParams;
  pathParams: PathParams | undefined;
  requestBody: RequestBody | undefined;
  apiClient: APIClient;
  setDownstreamParams?: SetDownstreamParamsWithPath;
};

export type readMeshSecretsParams = {
  logger: Logger;
  secretsDir: string;
};

export type Entity<T> = {
  [name: string]: T[];
};
export type ApiSuccessResponse<E> = NormalizedSchema<Entity<E>, Entity<string>>;
export type ApiResponse<E> = ApiSuccessResponse<E> | APIError;

export interface PdpQueryApiResponse {
  data: {
    requestId: string;
    timeStamp: string;
    deploymentPackageId: string;
    elapsedTime: number;
    results: PdpQueryResult[];
  };
}

export enum PDP_QUERY_ATTRIBUTES {
  ACCOUNT_ID = 'RequestAttributes.AccountId',
  BENEFICIARY_ID = 'RequestAttributes.BeneficiaryId',
  SCOPE_ID = 'RequestAttributes.ScopeId',
  DIVISION_ID = 'RequestAttributes.DivisionId',
}

export enum PDP_CONTEXT_ATTRIBUTES {
  ORG_ID = 'RequestAttributes.OrganisationId',
  REQ_ACTION = 'RequestAttributes.RequestAction',
  SCOPE_ID = 'RequestAttributes.ScopeId',
  CUSTOMER_USER_ID = 'RequestAttributes.CustomerUserId',
  DIVISION_ID = 'RequestAttributes.DivisionId',
}

// TODO: Remove this enum after the migration to the new PDP query functions is complete.
export enum PDP_ATTRIBUTES {
  ACC_ID = 'RequestAttributes.AccountId',
  BENE_ID = 'RequestAttributes.BeneficiaryId',
  SCOPE_ID = 'RequestAttributes.ScopeId',
  ORG_ID = 'RequestAttributes.OrganisationId',
  REQ_ACTION = 'RequestAttributes.RequestAction',
}

export type PdpQueryResult = {
  attribute?: string;
  value: string;
  decision: string;
  statements?: {
    id: string;
    name: string;
    code: string;
    payload: string;
    obligatory: boolean;
    fulfilled: boolean;
    attributes: Record<string, unknown>;
  }[];
};

export type transformedAccount = {
  BSB: string;
  accountNumber: string;
};

export type ArrangementSortAndLimitParams = {
  sortBy?: '+accountId' | '-accountId' | '+accountName' | '-accountName';
  pageSize?: number;
};

export type GetAccountIdsFromPdpQueryResultParams = {
  res: Response;
  req: Request;
  queryDecisionRequest: APIClient;
  pdpClientToken: string;
  orgCisKey?: string;
  groupId?: string;
  requestAction: string;
  userId?: string;
  divisionId?: string;
};

export type GetBeneficiaryIdsFromPdpQueryResultParams = {
  res: Response;
  req: Request;
  queryDecisionRequest: APIClient;
  pdpClientToken: string;
  orgCisKey?: string;
  requestAction: string;
  userId?: string;
  divisionId?: string;
};

export type GetGroupIdsFromPdpQueryResultParams = {
  res: Response;
  req: Request;
  queryDecisionRequest: APIClient;
  pdpClientToken: string;
  orgCisKey?: string;
  requestAction: string;
};

export type GetDivisionsFromPdpQueryResultParams = {
  res: Response;
  req: Request;
  queryDecisionRequest: APIClient;
  pdpClientToken: string;
  orgCisKey?: string;
  requestAction: string;
  userId?: string;
  divisionId?: string;
};

export type GetPdpQueryResultsParams = {
  meshSecretsContent: {
    pdpClientToken?: string;
    org?: string;
  };
  req: Request;
  res: Response;
  queryDecisionRequest: APIClient;
  queryAttribute:
    | PDP_ATTRIBUTES.ACC_ID
    | PDP_ATTRIBUTES.BENE_ID
    | PDP_ATTRIBUTES.SCOPE_ID;
  setDownstreamParams?: SetDownstreamParams;
};

export type JwtDecodeOptions = {
  header?: boolean;
};

export type JwtHeader = {
  typ?: string;
  alg?: string;
  kid?: string;
};

export type RoleBaseJwtModel = {
  role: string | string[];
};

export class InvalidTokenError extends Error {}

export type DecodeAndValidateTokenParams = {
  apiHeaders: Record<string, string>;
  headerKey?: string;
  logger: Logger;
  options?: {
    requiredFields?: string[];
    fieldMappings?: Record<string, string>;
    postProcess?: (decodedToken: Record<string, unknown>) => unknown;
  };
};

export type DecodedTokenResult = {
  userId?: unknown;
  userIAMId?: unknown;
  [key: string]: unknown;
};

/**
 * mv-apituils Constants
 */

export enum STATUS_CODES {
  OK = 200,
  CREATED = 201,
  NO_CONTENT = 204,
  PARTIAL_CONTENT = 206,
  BAD_REQUEST = 400,
  UNAUTHORIZED = 401,
  FORBIDDEN = 403,
  NOT_FOUND = 404,
  METHOD_NOT_ALLOWED = 405,
  PAYLOAD_TOO_LARGE = 413,
  INTERNAL_SERVER_ERROR = 500,
  SERVICE_UNAVAILABLE = 503,
}

/**
 * mv-apituils Functions
 */

export const handleApiService: ({
  req,
  res,
  apiClient,
  setDownstreamParams,
  requestBody,
  queryParams,
  pathParams,
}: HandleApiServiceParams) => Promise<DownstreamServiceResponse>;

export const handleApiServiceV2: ({
  req,
  res,
  queryParams,
  pathParams,
  requestBody,
  apiClient,
  setDownstreamParams,
}: HandleApiServiceParamsWithPath) => Promise<DownstreamServiceResponse>;

export const handleControllerError: ({
  error,
  res,
  logger,
}: HandleControllerErrorParams) => void;

export const normaliseData: <T>(
  key: string,
  data: T[],
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  normalise: any
) => ApiResponse<T>;

export const normaliseDataWithPaging: <T, U>(
  key: string,
  data: Record<string, T | U>,
  normalise: unknown
) => ApiResponse<T | U>;

export const getHeader: (
  inputHeaders: ApiHeaders,
  res: Response,
  appConfig: AppConfig
) => ApiHeaders;

export const readMeshSecrets: ({
  logger,
  secretsDir,
}: readMeshSecretsParams) => {
  [key: string]: unknown;
};

export function jwtDecode<T = JwtHeader>(
  token: string,
  options: JwtDecodeOptions & { header: true }
): T;

export function jwtDecode<T = RoleBaseJwtModel>(
  token: string,
  options?: JwtDecodeOptions
): T;

export function decodeAndValidateToken(
  params: DecodeAndValidateTokenParams
): DecodedTokenResult;

export const defaultSetDownstreamParams: SetDownstreamParams;

/**
 * Type definition for transformAccountList.ts --- Start
 */

export const transformAccountList: (
  pdpQueryResult: PdpQueryResult[],
  params?: ArrangementSortAndLimitParams
) => transformedAccount[];

/**
 * Type definition for transformAccountList.ts --- End
 */

/**
 * Type definition for transformPdpQueryResult.ts --- Start
 */

export const transformPdpQueryResult: <T = string>(
  pdpQueryResult: PdpQueryResult[],
  mapFn?: (value: string) => T,
  filterFn?: (value: string) => boolean
) => T[];

export const getPermittedPdpQueryResult: (
  pdpQueryResult: PdpQueryResult[]
) => PdpQueryResult[];

/**
 * Type definition for transformPdpQueryResult.ts --- Start
 */

/**
 * Type definition for getPdpQueryResults.ts --- Start
 */

export function getPdpQueryResults({
  meshSecretsContent,
  req,
  res,
  queryDecisionRequest,
  queryAttribute,
  setDownstreamParams,
}: GetPdpQueryResultsParams): Promise<PdpQueryResult[]>;

export const getAccountIdsFromPdpQueryResult: ({
  res,
  req,
  queryDecisionRequest,
  pdpClientToken,
  orgCisKey,
  groupId,
  requestAction,
  userId,
  divisionId,
}: GetAccountIdsFromPdpQueryResultParams) => Promise<PdpQueryResult[]>;

export const getBeneficiaryIdsFromPdpQueryResult: ({
  res,
  req,
  queryDecisionRequest,
  pdpClientToken,
  orgCisKey,
  requestAction,
  userId,
  divisionId,
}: GetBeneficiaryIdsFromPdpQueryResultParams) => Promise<PdpQueryResult[]>;

export const getGroupIdsFromPdpQueryResult: ({
  res,
  req,
  queryDecisionRequest,
  pdpClientToken,
  orgCisKey,
  requestAction,
}: GetGroupIdsFromPdpQueryResultParams) => Promise<PdpQueryResult[]>;

export const getDivisionsFromPdpQueryResult: ({
  res,
  req,
  queryDecisionRequest,
  pdpClientToken,
  orgCisKey,
  requestAction,
  userId,
}: GetDivisionsFromPdpQueryResultParams) => Promise<PdpQueryResult[]>;

/**
 * Type definition for getPdpQueryResults.ts --- End
 */
export type ControllerParams = Record<string, any>;
/**
 * Type definition and constant for the mv-injection-checker
 */

export declare const validateWithLibrary: (content: string) => boolean;
export declare const FORBIDDEN_CHARACTERSET: string[];
export declare const sanitiseWithLibrary: (
  input: string,
  maxLength?: number
) => string;
export declare const getFormattedForbiddenCharacters: () => string;
// end mv-injection-checker

export type ConvertDateType = 'end';
export function convertSydneyLocalTimeToUtc(
  data: string,
  type?: ConvertDateType
): string | null;

export function getFormattedDateWithoutZoneName(): string;

export function getCurrentFinancialYear(): number;

export const enum COP_COLOR_CODE {
  BLUE = 'Blue', //INFO
  AMBER = 'Amber', //WARNING
  RED = 'Red', //DANGER
}

/**
 * All possible CoP API status codes - single source of truth
 */
declare const allCoPApiStatusCodes: readonly [
  'V0C1',
  'V0C2',
  'V0C3',
  'V0C4',
  'V0C5',
  'V0C6',
  'V0C7',
  'V0C8',
  'V1C1',
  'V1C2',
  'V1C3',
  'V1C4',
  'V1C5',
  'V1C6',
  'V1C7',
  'V1C8',
  'V2C1',
  'V2C2',
  'V2C3',
  'V2C4',
  'V2C5',
  'V2C6',
  'V2C7',
  'V2C8',
  'VAC1',
  'VAC2',
  'VAC3',
  'VAC4',
  'VAC5',
  'VAC6',
  'VAC7',
  'VAC8',
  'VTC1',
  'VTC2',
  'VTC3',
  'VTC4',
  'VTC5',
  'VTC6',
  'VTC7',
  'VTC8',
  'VEC1',
  'VEC2',
  'VEC3',
  'VEC4',
  'VEC5',
  'VEC6',
  'VEC7',
  'VEC8',
];

export type CoPApiStatusCode = (typeof allCoPApiStatusCodes)[number];

export function getColorForCoPStatusCode(
  statusCode: CoPApiStatusCode
): COP_COLOR_CODE | undefined;

export declare const accessControlExposeHeaders: string;
