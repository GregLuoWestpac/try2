export const maskUserData = (value: string | null | undefined): string => {
  if (!value || typeof value !== 'string' || value.length <= 5) {
    return '';
  }

  const visiblePart = value.slice(-3);
  const maskedPart = '*'.repeat(value.length - 3);
  return maskedPart + visiblePart;
};

export const maskObjectData = (
  obj: Record<string, unknown>,
  excludeKeys: string[] = []
): Record<string, unknown> => {
  if (!obj || typeof obj !== 'object') {
    return obj;
  }

  const masked: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(obj)) {
    if (excludeKeys.includes(key)) {
      masked[key] = value;
    } else if (typeof value === 'string') {
      masked[key] = maskUserData(value);
    } else if (value && typeof value === 'object' && !Array.isArray(value)) {
      masked[key] = maskObjectData(
        value as Record<string, unknown>,
        excludeKeys
      );
    } else if (Array.isArray(value)) {
      masked[key] = value.map(item =>
        typeof item === 'string'
          ? maskUserData(item)
          : typeof item === 'object' && item !== null
            ? maskObjectData(item as Record<string, unknown>, excludeKeys)
            : item
      );
    } else {
      masked[key] = value;
    }
  }

  return masked;
};
