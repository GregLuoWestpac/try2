import { STATUS_CODES } from './constants';
import { HandleControllerErrorParams } from './types';

export const handleControllerError = ({
  error,
  res,
  logger,
}: HandleControllerErrorParams) => {
  const apiClientError = error?.error;
  const statusCode =
    apiClientError?.status || STATUS_CODES.INTERNAL_SERVER_ERROR;
  const responseData = apiClientError?.data;

  logger.error(error);
  res.status(statusCode).send(responseData);
};
