import { Response, Request } from 'express';
import { APIError } from '@mep-node/framework-utilities';
import { NormalizedSchema } from 'normalizr';
import BunyanLogger from 'bunyan';

export type Error = {
  code?: string;
  message?: string;
  details?: string;
};

export type APIClientError = {
  type: string;
  error: {
    status: number;
    statusText: string;
    data: {
      result: {
        errors: Error[];
      };
    };
  };
};

export type Logger = BunyanLogger | Console;

export type HandleControllerErrorParams = {
  error: APIClientError;
  res: Response;
  logger: Logger;
};

export type AppConfig = Record<string, string>;
export type QueryParams = Record<string, string>;
export type ApiHeaders = Record<string, string>;
export type PathParams = Record<string, string>;

export type Params = {
  header: ApiHeaders;
  body: Record<string, unknown>;
  query: Record<string, string>;
};

export type ParamsWithPath = {
  header: ApiHeaders;
  body: Record<string, unknown> | undefined;
  query: Record<string, string>;
  path: Record<string, string> | undefined;
};

export type SetDownstreamParams = (
  apiHeaders: ApiHeaders,
  res: Response,
  requestBody: Record<string, unknown>,
  appConfig: AppConfig,
  queryParams?: QueryParams,
  pathParams?: PathParams
) => Params;

export type SetDownstreamParamsWithPath = (
  apiHeaders: ApiHeaders,
  res: Response,
  requestBody: Record<string, unknown> | undefined,
  appConfig: AppConfig,
  queryParams: QueryParams,
  pathParams: PathParams | undefined
) => ParamsWithPath;

export type RequestBody = Record<string, unknown>;

export type Paging = Record<string, string | number>;

export type DownstreamServiceResponseData = {
  data: Record<string, unknown>;
  paging?: Paging;
};

export type DownstreamServiceResponse = {
  data: DownstreamServiceResponseData;
  status: number;
  statusText: string;
  headers: unknown;
};

export type APIClient = (
  baseUrl: string,
  params: Params,
  apiConfig: AppConfig,
  req: Request,
  res: Response
) => Promise<DownstreamServiceResponse>;

export type HandleApiServiceParams = {
  req: Request;
  res: Response;
  apiClient: APIClient;
  setDownstreamParams?: SetDownstreamParams;
  requestBody?: RequestBody;
  queryParams?: QueryParams;
  pathParams?: PathParams;
  reqMethod?: string;
};

export type HandleApiServiceParamsWithPath = {
  req: Request;
  res: Response;
  queryParams: QueryParams;
  pathParams: PathParams | undefined;
  requestBody: RequestBody | undefined;
  apiClient: APIClient;
  setDownstreamParams?: SetDownstreamParamsWithPath;
};

export type readMeshSecretsParams = {
  logger: Logger;
  secretsDir: string;
};

export type Entity<T> = {
  [name: string]: T[];
};
export type ApiSuccessResponse<E> = NormalizedSchema<Entity<E>, Entity<string>>;
export type ApiResponse<E> = ApiSuccessResponse<E> | APIError;

export interface PdpQueryApiResponse {
  data: {
    requestId: string;
    timeStamp: string;
    deploymentPackageId: string;
    elapsedTime: number;
    results: PdpQueryResult[];
  };
}

export enum PDP_QUERY_ATTRIBUTES {
  ACCOUNT_ID = 'RequestAttributes.AccountId',
  BENEFICIARY_ID = 'RequestAttributes.BeneficiaryId',
  SCOPE_ID = 'RequestAttributes.ScopeId',
  DIVISION_ID = 'RequestAttributes.DivisionId',
}

export enum PDP_CONTEXT_ATTRIBUTES {
  ORG_ID = 'RequestAttributes.OrganisationId',
  REQ_ACTION = 'RequestAttributes.RequestAction',
  SCOPE_ID = 'RequestAttributes.ScopeId',
  CUSTOMER_USER_ID = 'RequestAttributes.CustomerUserId',
  DIVISION_ID = 'RequestAttributes.DivisionId',
}

// TODO: Remove this enum after the migration to the new PDP query functions is complete.
export enum PDP_ATTRIBUTES {
  ACC_ID = 'RequestAttributes.AccountId',
  BENE_ID = 'RequestAttributes.BeneficiaryId',
  SCOPE_ID = 'RequestAttributes.ScopeId',
  ORG_ID = 'RequestAttributes.OrganisationId',
  REQ_ACTION = 'RequestAttributes.RequestAction',
}

export type PdpQueryResult = {
  attribute?: string;
  value: string;
  decision: string;
  statements?: {
    id: string;
    name: string;
    code: string;
    payload: string;
    obligatory: boolean;
    fulfilled: boolean;
    attributes: Record<string, unknown>;
  }[];
};

export type transformedAccount = {
  BSB: string;
  accountNumber: string;
};

export type ArrangementSortAndLimitParams = {
  sortBy?: '+accountId' | '-accountId' | '+accountName' | '-accountName';
  pageSize?: number;
};

type GetInformationFromPdpQueryResultParams = {
  res: Response;
  req: Request;
  queryDecisionRequest: APIClient;
  pdpClientToken: string;
  orgCisKey?: string;
  requestAction: string;
  userId?: string;
  divisionId?: string;
};

export type GetAccountIdsFromPdpQueryResultParams =
  GetInformationFromPdpQueryResultParams & {
    groupId?: string;
  };

export type GetBeneficiaryIdsFromPdpQueryResultParams =
  GetInformationFromPdpQueryResultParams;

export type GetGroupIdsFromPdpQueryResultParams =
  GetInformationFromPdpQueryResultParams;

export type GetDivisionsFromPdpQueryResultParams =
  GetInformationFromPdpQueryResultParams;

export type GetPdpQueryResultsParams = {
  meshSecretsContent: {
    pdpClientToken?: string;
    org?: string;
  };
  req: Request;
  res: Response;
  queryDecisionRequest: APIClient;
  queryAttribute:
    | PDP_ATTRIBUTES.ACC_ID
    | PDP_ATTRIBUTES.BENE_ID
    | PDP_ATTRIBUTES.SCOPE_ID;
  setDownstreamParams?: SetDownstreamParams;
};

export type RoleBaseJwtModel = {
  role: string | string[];
};

export type DecodeAndValidateTokenParams = {
  apiHeaders: Record<string, string>;
  headerKey?: string;
  logger: Logger;
  options?: {
    requiredFields?: string[];
    fieldMappings?: Record<string, string>;
    postProcess?: (decodedToken: Record<string, unknown>) => unknown;
  };
};

export type DecodedTokenResult = {
  userId?: unknown;
  userIAMId?: unknown;
  [key: string]: unknown;
};
