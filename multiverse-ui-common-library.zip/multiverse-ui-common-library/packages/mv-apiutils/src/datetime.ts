import { DateTime, Settings } from 'luxon';
import { SYDNEY_ZONE } from '@mesh-tenant-multiverse-ui-common/mv-constants/src';

export { Settings as LuxonSettings };

export type ConvertDateType = 'end';
export function convertSydneyLocalTimeToUtc(
  date: string,
  type?: ConvertDateType
): string | null {
  if (!date) return '';
  const newDate = date.replace(' ', 'T');
  if (type && type === 'end') {
    return DateTime.fromISO(newDate, { zone: SYDNEY_ZONE })
      .endOf('day')
      .toUTC()
      .toISO();
  } else {
    return DateTime.fromISO(newDate, { zone: SYDNEY_ZONE }).toUTC().toISO();
  }
}

export function getFormattedDateWithoutZoneName(): string {
  return DateTime.utc().setZone(SYDNEY_ZONE).toFormat('yyyy-MM-dd');
}

export function getCurrentFinancialYear(): number {
  const { month, year } = DateTime.utc().setZone(SYDNEY_ZONE);
  return month < 7 ? year : year + 1;
}
