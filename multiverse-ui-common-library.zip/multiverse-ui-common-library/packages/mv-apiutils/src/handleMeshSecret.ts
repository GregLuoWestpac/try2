import { readMeshSecretsParams } from './types';

export const readMeshSecrets = async ({
  logger,
  secretsDir,
}: readMeshSecretsParams): Promise<{ [key: string]: unknown } | null> => {
  const secretsFile = `${secretsDir}/.gitkeep`;
  try {
    let fs: typeof import('fs/promises');
    if (typeof window === 'undefined') {
      fs = await import('fs/promises'); // dynamically import at runtime only in Node
    } else {
      throw new Error('fs module is not available in the browser environment.');
    }
    await fs.access(secretsDir); // Check if directory exists
    const fileContents = await fs.readFile(secretsFile, 'utf8');
    return JSON.parse(fileContents);
  } catch (error) {
    const diagnosticsOutputMessage = `Cannot find the directory: ${secretsDir}`;
    logger?.info(
      'readMeshSecrets - diagnosticsOutputMessage -',
      diagnosticsOutputMessage
    );
    return null;
  }
};
