import {
  PdpQueryResult,
  ArrangementSortAndLimitParams,
  transformedAccount,
} from './types';

const parsePayload = (payload?: string): string => {
  try {
    return payload ? JSON.parse(payload).name : '';
  } catch {
    return '';
  }
};
export const transformAccountList = (
  pdpQueryResult: PdpQueryResult[],
  params: ArrangementSortAndLimitParams = {}
): transformedAccount[] => {
  const { sortBy = '', pageSize = 1000 } = params;
  const isAsc = !sortBy.startsWith('-');
  const field = sortBy.replace(/^[-+]/, '');
  return pdpQueryResult
    .sort((a, b) => {
      let aFieldValue: string = '';
      let bFieldValue: string = '';
      if (field === 'accountId') {
        aFieldValue = a.value;
        bFieldValue = b.value;
      } else if (field === 'accountName') {
        const aPayload = a.statements?.[0]?.payload;
        const bPayload = b.statements?.[0]?.payload;
        aFieldValue = parsePayload(aPayload);
        bFieldValue = parsePayload(bPayload);
      }
      return isAsc
        ? aFieldValue.localeCompare(bFieldValue)
        : bFieldValue.localeCompare(aFieldValue);
    })
    .slice(0, pageSize)
    .map(({ value }) => ({
      BSB: value?.substring(0, 6),
      accountNumber: value?.substring(6),
    }));
};
