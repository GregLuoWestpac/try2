import {
  AppConfig,
  DownstreamServiceResponse,
  HandleApiServiceParamsWithPath,
  QueryParams,
  PathParams,
  RequestBody,
} from './types';
import { setRequiredDownstreamParams } from './handleSetDownstreamParams';

/**
 * This service is used for API services that have a path parameter. This service also has the provision to set the
 * request body as undefined for GET requests.
 * queryParams is a required parameter. 
 * pathParams is a required parameter.
 * requestBody is a required parameter.
 * Please pass these with value 'undefined' if they do not have a value.
 * @returns 
 */
export const handleApiServiceV2 = async ({
  req,
  res,
  queryParams,
  pathParams,
  requestBody,
  apiClient,
  setDownstreamParams = setRequiredDownstreamParams,
}: HandleApiServiceParamsWithPath): Promise<DownstreamServiceResponse> => {

  const { apiHeaders, apiBaseUrl } = res.locals;
  const query = queryParams || {};
  const { Config } = res.app.locals;

  const appConfig = Config.get('app-config', {}) as AppConfig;

  const apiConfig = {
    request: appConfig && appConfig.requestConfig,
    response: appConfig && appConfig.responseConfig,
  };

  const params = setDownstreamParams(
    apiHeaders,
    res,
    requestBody as RequestBody,
    appConfig,
    query as QueryParams,
    pathParams as PathParams
  );

  const response = await apiClient(apiBaseUrl, params, apiConfig, req, res);
  return response;
};
