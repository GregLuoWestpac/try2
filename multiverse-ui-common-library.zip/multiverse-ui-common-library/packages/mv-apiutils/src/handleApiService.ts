import {
  AppConfig,
  DownstreamServiceResponse,
  HandleApiServiceParams,
  QueryParams,
} from './types';
import { defaultSetDownstreamParams } from './handleSetDownstreamParams';

export const handleApiService = async ({
  req,
  res,
  apiClient,
  setDownstreamParams = defaultSetDownstreamParams,
  requestBody,
  queryParams,
  pathParams,
  reqMethod,
}: HandleApiServiceParams): Promise<DownstreamServiceResponse> => {
  const { apiHeaders, apiBaseUrl } = res.locals;
  const requestQuery = queryParams || req.query || {};
  const { Config } = res.app.locals;

  const appConfig = Config.get('app-config', {}) as AppConfig;

  const apiConfig = {
    request: appConfig && appConfig.requestConfig,
    response: appConfig && appConfig.responseConfig,
  };

  const finalReqMethod = reqMethod || res.req?.method || 'GET';

  // Set requestBody to undefined if reqMethod is 'GET'
  const finalRequestBody =
    finalReqMethod.toUpperCase() === 'GET'
      ? undefined
      : requestBody || req.body;

  const params = setDownstreamParams(
    apiHeaders,
    res,
    finalRequestBody,
    appConfig,
    requestQuery as QueryParams,
    pathParams
  );

  const response = await apiClient(apiBaseUrl, params, apiConfig, req, res);
  return response;
};
