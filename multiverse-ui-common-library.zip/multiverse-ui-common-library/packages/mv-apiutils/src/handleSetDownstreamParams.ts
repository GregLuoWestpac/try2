import { Response } from 'express';
import {
  ApiHeaders,
  AppConfig,
  SetDownstreamParams,
  SetDownstreamParamsWithPath,
} from './types';

export const getHeader = (
  inputHeaders: ApiHeaders,
  res: Response,
  appConfig: AppConfig
): ApiHeaders => {
  const xSystemTest = res?.req?.get('x-systemtest') || '';

  return {
    ...inputHeaders,
    'x-originatingBSB': res.locals.BSB || appConfig.originatingBSB,
    ...(xSystemTest && {
      'x-systemtest': xSystemTest,
    }),
  };
};

export const defaultSetDownstreamParams: SetDownstreamParams = (
  apiHeaders,
  res,
  requestBody,
  appConfig,
  queryParams,
  pathParams
) => {
  return {
    header: getHeader(apiHeaders, res, appConfig),
    body: requestBody,
    query: {
      brandSilo: res.locals.brandSilo || appConfig.organisationId,
      ...queryParams,
    },
    ...(pathParams && { path: pathParams }),
  };
};

export const setRequiredDownstreamParams: SetDownstreamParamsWithPath = (
  inputHeaders,
  res,
  requestBody,
  appConfig,
  queryParams,
  pathParams
) => {
  return {
    header: getHeader(inputHeaders, res, appConfig),
    body: requestBody,
    query: {
      brandSilo: res.locals.brandSilo || appConfig.organisationId,
      ...queryParams,
    },
    path: pathParams,
  };
};
