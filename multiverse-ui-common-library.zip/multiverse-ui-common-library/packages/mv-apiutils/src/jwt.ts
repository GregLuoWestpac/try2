import {
  DecodeAndValidateTokenParams,
  DecodedTokenResult,
  RoleBaseJwtModel,
} from './types';

export type JwtDecodeOptions = {
  header?: boolean;
};

export type JwtHeader = {
  typ?: string;
  alg?: string;
  kid?: string;
};

export class InvalidTokenError extends Error {}

InvalidTokenError.prototype.name = 'InvalidTokenError';

function b64DecodeUnicode(str: string) {
  return decodeURIComponent(
    Buffer.from(str, 'base64')
      .toString('binary')
      .replace(/(.)/g, (_m, p) => {
        let code = (p as string).charCodeAt(0).toString(16).toUpperCase();
        if (code.length < 2) {
          code = `0${code}`;
        }
        return `%${code}`;
      })
  );
}

function base64UrlDecode(str: string) {
  let output = str.replace(/-/g, '+').replace(/_/g, '/');
  switch (output.length % 4) {
    case 0:
      break;
    case 2:
      output += '==';
      break;
    case 3:
      output += '=';
      break;
    default:
      throw new Error('base64 string is not of the correct length');
  }

  try {
    return b64DecodeUnicode(output);
  } catch (err) {
    return Buffer.from(output, 'base64').toString('binary');
  }
}

export function jwtDecode<T = JwtHeader>(
  token: string,
  options: JwtDecodeOptions & { header: true }
): T;

export function jwtDecode<T = RoleBaseJwtModel>(
  token: string,
  options?: JwtDecodeOptions
): T;

export function jwtDecode<T = JwtHeader | RoleBaseJwtModel>(
  token: string,
  options?: JwtDecodeOptions
): T {
  if (typeof token !== 'string') {
    throw new InvalidTokenError('Invalid token specified: must be a string');
  }

  const opts = options || {};
  const pos = opts.header === true ? 0 : 1;
  const part = token.split('.')[pos];

  if (typeof part !== 'string') {
    throw new InvalidTokenError(
      `Invalid token specified: missing part #${pos + 1}`
    );
  }

  let decoded: string;
  try {
    decoded = base64UrlDecode(part);
  } catch (e) {
    throw new InvalidTokenError(
      `Invalid token specified: (${(e as Error).message})`
    );
  }

  try {
    return JSON.parse(decoded) as T;
  } catch (e) {
    throw new InvalidTokenError(
      `Invalid token specified: (${(e as Error).message})`
    );
  }
}

/**
 * Decodes a JWT from API headers and validates required fields.
 *
 * @param {DecodeAndValidateTokenParams} params - Parameters for decoding and validation.
 * @param {Record<string, string>} params.apiHeaders - The headers containing the JWT.
 * @param {string} [params.headerKey='x-access-token'] - The header key to extract the token from.
 * @param {object} [params.logger] - Optional logger for error reporting.
 * @param {object} [params.options] - Options for validation and post-processing.
 * @param {string[]} [params.options.requiredFields=['userId']] - Fields required in the decoded token.
 * @param {Record<string, string>} [params.options.fieldMappings] - Mapping of output keys to token keys.
 * @param {(result: Record<string, unknown>) => void} [params.options.postProcess] - Optional post-processing function.
 * @returns {DecodedTokenResult} The decoded and validated token fields.
 * @throws {InvalidTokenError} If decoding fails or required fields are missing.
 */
export const decodeAndValidateToken = (
  params: DecodeAndValidateTokenParams
): DecodedTokenResult => {
  const { apiHeaders, headerKey = 'x-access-token', logger, options } = params;
  let decodedToken: Record<string, unknown> = {};
  try {
    const xAccessToken = apiHeaders[headerKey] as string;
    decodedToken = jwtDecode(xAccessToken);
  } catch (error) {
    const tokenDecodeError = {
      msg: `Error decoding token`,
      payload: { error },
    };
    logger?.error(tokenDecodeError);
    throw new InvalidTokenError(tokenDecodeError.msg);
  }

  const requiredFields = options?.requiredFields || ['userId'];
  const fieldMappings = options?.fieldMappings || {
    userId: 'userId',
    userIAMId: 'userIAMId',
  };

  const result: Record<string, unknown> = {};
  for (const [outputKey, tokenKey] of Object.entries(fieldMappings)) {
    result[outputKey] =
      decodedToken && typeof decodedToken === 'object'
        ? (decodedToken as Record<string, unknown>)[tokenKey]
        : undefined;
  }

  if (typeof options?.postProcess === 'function') {
    options.postProcess(result);
  }

  const missingFields = requiredFields.filter(field => !result[field]);
  if (missingFields.length > 0) {
    throw new InvalidTokenError(
      `Token missing required field(s): ${missingFields.join(', ')}`
    );
  }

  return result;
};
