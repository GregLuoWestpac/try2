/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response, NextFunction } from 'express';
import { handleControllerError } from './handleError';

export type ControllerParams = {
  [key: string]: any;
};

/**
 * Generic type for controller handler functions
 */
export type ControllerHandler = (
  req: Request,
  res: Response,
  controllerParams: ControllerParams
) => Promise<void>;

/**
 * Generic controller wrapper that handles errors and provides Express middleware support.
 * This wrapper can be used to wrap any controller handler function to provide consistent
 * error handling and middleware integration.
 *
 * @param handlerFn - The controller handler function to wrap
 * @param controllerParams - The controller parameters to pass to the handler
 * @returns An Express middleware function that can be used in route handlers
 *
 * @example
 * ```typescript
 * const myController = createControllerWrapper(myHandlerFunction, controllerParams);
 * app.get('/api/endpoint', myController);
 * ```
 */
export const createControllerWrapper = (
  handlerFn: ControllerHandler,
  controllerParams: ControllerParams
) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      await handlerFn(req, res, controllerParams);
    } catch (error) {
      const { logger } = res.locals;
      handleControllerError({ error, res, logger });
      next(error);
    }
  };
};
