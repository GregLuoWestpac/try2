import { PdpQueryResult } from './types';

export const getPermittedPdpQueryResult = (
  pdpQueryResult: PdpQueryResult[]
): PdpQueryResult[] => {
  return pdpQueryResult.filter(({ decision }) => decision === 'PERMIT');
};

export const transformPdpQueryResult = <T = string>(
  pdpQueryResult: PdpQueryResult[],
  mapFn?: (value: string) => T,
  filterFn?: (value: string) => boolean
): T[] => {
  return pdpQueryResult
    .filter(
      ({ decision, value }) =>
        decision === 'PERMIT' && (filterFn ? filterFn(value) : true)
    )
    .map(({ value }) => (mapFn ? mapFn(value) : (value as unknown as T)));
};
