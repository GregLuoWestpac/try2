import {
  COP_STATUS_LOOK,
  CoPApiStatusCode,
} from '@mesh-tenant-multiverse-ui-common/mv-utils/src/copStatusResponses';

// color code passed for SAFI to indicate status of COP (danger, warning or info)
export const enum COP_COLOR_CODE {
  BLUE = 'Blue', //INFO
  AMBER = 'Amber', //WARNING
  RED = 'Red', //DANGER
}

export const convertColorToLook = (
  color?: COP_COLOR_CODE
): COP_STATUS_LOOK | null => {
  let look: COP_STATUS_LOOK | null = null;
  switch (color) {
    case COP_COLOR_CODE.AMBER: {
      look = COP_STATUS_LOOK.WARNING;
      break;
    }
    case COP_COLOR_CODE.BLUE: {
      look = COP_STATUS_LOOK.INFO;

      break;
    }
    case COP_COLOR_CODE.RED: {
      look = COP_STATUS_LOOK.DANGER;
      break;
    }
  }
  return look;
};

// mapping loggic should be consistant with mapCoPStatusToMessageProps
export function getColorForCoPStatusCode(
  statusCode: CoPApiStatusCode
): COP_COLOR_CODE | undefined {
  switch (statusCode) {
    case 'V0C1': // Success - CoP match + Verify match
    case 'V0C2': // Success - CoP close match + Verify match
    case 'VAC1': // Success - CoP match + Verify error
    case 'VTC1': // Success - CoP match + Verify timeout (error)
    case 'VEC1': // Success - CoP match + Verify error
    case 'V0C6': // Success - CoP error and Verify match
    case 'V0C8': {
      // Success - CoP error and Verify match
      return COP_COLOR_CODE.BLUE;
    }
    case 'V1C1': // Warning - CoP match + Verify not enough payments
    case 'V2C1': // Warning - CoP match + Verify no match
    case 'V1C2': // Warning - CoP close match + Verify not enough payments
    case 'V2C2': // Warning - CoP close match + Verify no match
    case 'V1C6': // Warning - CoP error and Verify not enough payments
    case 'V1C8': // Warning - CoP error and Verify not enough payments
    case 'V2C6': // Warning - CoP error and Verify no match
    case 'V2C8': // Warning - CoP error and Verify no match
    case 'VAC6': // Warning - CoP error and Verify error
    case 'VAC8': // Warning - CoP error and Verify error
    case 'VTC6': // Warning - CoP error and Verify error
    case 'VTC8': // Warning - CoP error and Verify error
    case 'VEC6': // Warning - CoP error and Verify error
    case 'VEC8': // Warning - CoP error and Verify error
    case 'V0C3': // Warning - CoP no match [IND] and Verify match
    case 'V0C4': // Warning - CoP no match [NON-IND] and Verify match
    case 'V1C3': // Warning - CoP no match [IND] and Verify not enough payments
    case 'V1C4': // Warning - CoP no match [NON-IND] and Verify not enough payments
    case 'V2C3': // Warning - CoP no match [IND] and Verify no match
    case 'V2C4': // Warning - CoP no match [NON-IND] and Verify no match
    case 'VAC3': // Warning - CoP no match [IND] and Verify error
    case 'VTC3': // Warning - CoP no match [IND] and Verify error
    case 'VEC3': // Warning - CoP no match [IND] and Verify error
    case 'VAC4': // Warning - CoP no match [NON-IND] and Verify error
    case 'VTC4': // Warning - CoP no match [NON-IND] and Verify error
    case 'VEC4': // Warning - CoP no match [NON-IND] and Verify error
    case 'V0C5': // Warning - CoP opt-out and Verify match
    case 'V1C5': // Warning - CoP opt-out and Verify not enough payments
    case 'V2C5': // Warning - CoP opt-out and Verify no match
    case 'VAC5': // Warning - CoP opt-out and Verify error
    case 'VTC5': // Warning - CoP opt-out and Verify error
    case 'VEC5': // Warning - CoP opt-out and Verify error
    case 'VAC2': // Warning - CoP close match + Verify error
    case 'VTC2': // Warning - CoP close match + Verify timeout (error)
    case 'VEC2': {
      // Warning - CoP close match + Verify error
      return COP_COLOR_CODE.AMBER;
    }
    case 'V0C7': // Error - CoP error and Account closed or not found
    case 'V1C7': // Error - CoP error and Account closed or not found
    case 'V2C7': // Error - CoP error and Account closed or not found
    case 'VAC7': // Error - CoP error and Account closed or not found
    case 'VTC7': // Error - CoP error and Account closed or not found
    case 'VEC7': {
      // Error - CoP error and Account closed or not found
      return COP_COLOR_CODE.RED;
    }
    default: {
      return undefined;
    }
  }
}
