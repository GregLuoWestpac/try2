# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.226.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.226.0...v1.226.1) (2026-02-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.225.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.225.4...v1.225.5) (2026-02-05)

### 💥 Bug Fixes

- normaliseData | ART-98641 ([c57049c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c57049cd7faf15e72c8dd71fb1c604923f2effc1))

## [1.221.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.221.1...v1.221.2) (2026-01-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.219.8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.7...v1.219.8) (2026-01-13)

### 💥 Bug Fixes

- removed a duplicate folder which may created by accident | ART-97745 ([9253f22](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9253f22103b655f32ebaa4d0ad691b35bfbcd1eb))

## [1.219.7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.6...v1.219.7) (2026-01-13)

### 💥 Bug Fixes

- add type definition in index.d.ts | ART-97745 ([d37d38b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d37d38b7b9d43f1038b2c8bf0a1e8b87e339cb65))

## [1.219.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.4...v1.219.5) (2026-01-13)

### 💥 Bug Fixes

- flat currencyAmount object | ART-97745 ([f9dbe1f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f9dbe1f503a328375c49b092514dc8c6eee0a1ee))

## [1.219.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.0...v1.219.1) (2025-12-19)

### 💥 Bug Fixes

- add back deleted files | ART-88711 ([9b541f6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9b541f66f1babf412fa5f9f318b3533504b1ee0e))

## [1.219.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.218.0...v1.219.0) (2025-12-19)

### 🚀 Features

- index file update for dependency upgrade | ART-84849 ([f45ecbf](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f45ecbfe1b50c29c8f5ae544165bc131e5ccfc75))
- pdp query function for Divisions | ART-84849 ([6770cd9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/6770cd961078eaaa0c3afce13a6475889860c0ec))
- updated pdp query result to match response object | ART-84849 ([fe6bf9c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/fe6bf9c1bc341940b786cde36f92e53a0997ba49))
- updated pdpquery functions | ART-84849 ([8ccbccd](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8ccbccdf20488d5eb715ce857811a5451a2e6227))

## [1.213.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.212.0...v1.213.0) (2025-12-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.212.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.211.0...v1.212.0) (2025-12-02)

### 🚀 Features

- pdpquery function updates to suppport division | ART-70051 ([4031504](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/40315044f2daa99d14888abed15ab1cdddecfdb1))

## [1.209.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.209.0...v1.209.1) (2025-11-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.209.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.208.0...v1.209.0) (2025-11-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.208.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.207.0...v1.208.0) (2025-10-31)

### 🚀 Features

- **ART-66800:** update comment and test case ([2ddd759](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2ddd75918118599afdc9a76fb724c2c995a8a8e4))

## [1.186.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.186.0...v1.186.1) (2025-10-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.185.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.185.1...v1.185.2) (2025-10-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.185.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.184.9...v1.185.0) (2025-10-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.184.8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.184.7...v1.184.8) (2025-09-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.184.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.184.5...v1.184.6) (2025-09-26)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.182.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.182.1...v1.182.2) (2025-09-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.174.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.173.8...v1.174.0) (2025-08-07)

### 🚀 Features

- created a constant string for access control expose headers | ART-68532 ([2990838](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2990838f3fc455528fc9ff861ae75f3d6b992fd8))

## [1.173.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.173.1...v1.173.2) (2025-08-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.171.7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.171.6...v1.171.7) (2025-07-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.171.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.171.5...v1.171.6) (2025-07-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.171.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.171.3...v1.171.4) (2025-07-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.163.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.163.0...v1.163.1) (2025-07-17)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.160.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.160.3...v1.160.4) (2025-07-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.153.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.152.0...v1.153.0) (2025-07-03)

### 🚀 Features

- field validations august uplift swagger and library changes | ART-54463 ([d9c00c5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d9c00c54fdb9620a5863e62194bdbf1c53d08b3f))

## [1.151.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.150.1...v1.151.0) (2025-07-01)

### 🚀 Features

- upgrade mep-node and nx/react packages to fix Snyk issues ([18bf179](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/18bf17965f2d9f19cbb9037e7f09a1fac0b40a73))

## [1.147.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.147.0...v1.147.1) (2025-06-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.147.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.146.0...v1.147.0) (2025-06-16)

### 🚀 Features

- evaluating perfectexpressSanitizer on-payment details page ui | ART-49958 ([64859ca](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/64859ca948435f2ea6f2b2910d37426ae17cb019))

## [1.146.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.145.0...v1.146.0) (2025-06-16)

### 🚀 Features

- update index.d.ts ([dfa45fa](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/dfa45fa9a43b55615ff7cd38d6ec88fb70b9f2d4))

## [1.145.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.144.1...v1.145.0) (2025-06-16)

### 🚀 Features

- add requestAction ([f22b25c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f22b25ca9441cbdb56b2a44fb87f60d25c81a14f))
- remove export ([ec63134](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ec63134acfab76b673cf6eb199c2a0b3ed398dc8))
- update index.d.ts ([3cde9fd](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3cde9fd91bd21608413c35ae1a42fac72de083f0))

## [1.144.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.144.0...v1.144.1) (2025-06-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.142.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.141.0...v1.142.0) (2025-06-10)

### 🚀 Features

- tiny update handleApiService ([9552238](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/955223857cc12b94c964dc3ab14dd2c004d571c8))

## [1.141.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.140.0...v1.141.0) (2025-06-06)

### 🚀 Features

- extend perfectexpresssanitizer to handle template injection | ART-54837 ([c422b02](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c422b02ed5cde5c4ab19021b3cdd2cc458531183))

## [1.140.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.139.1...v1.140.0) (2025-06-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.139.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.138.2...v1.139.0) (2025-06-03)

### 🚀 Features

- remove NaN check | ART-47786 ([c34f989](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c34f9894e17d28cdad11ef57648cbad89bc2242e))

## [1.137.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.137.1...v1.137.2) (2025-05-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.136.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.135.0...v1.136.0) (2025-05-27)

### 🚀 Features

- comment out getValuesByPdpQuery | ART-43405 ([be1aad7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/be1aad7932b39282c305342b4ba0a66593f1e1fa))

## [1.134.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.134.0...v1.134.1) (2025-05-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.134.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.133.0...v1.134.0) (2025-05-23)

### 🚀 Features

- change default pageSize to 500 | ART-47786 ([1e0ce26](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1e0ce26d9930d02723eb8da1469dfd8264e31d54))
- refactor | ART-47786 ([d8713b6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d8713b60f9b0495dfee6ca96d025b9c9ac7e7c5f))
- refactor and add accountName | ART-47786 ([318bb61](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/318bb61186d8d5d30352452f31a6068f976447cc))
- set default pageSize to 1000 | ART-47786 ([7d6359b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/7d6359b137ba58cc1e8e5d232c366c13c992714a))
- split functions to get permitted account list | ART-47786 ([deca3fd](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/deca3fd289164aaa51d0e0239fe49a12a3f655ca))

## [1.133.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.132.0...v1.133.0) (2025-05-22)

### 🚀 Features

- create getValuesByPdpQuery ([2a2c806](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2a2c806794c791958401ae2a99ce35a47efadfa0))

## [1.132.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.131.0...v1.132.0) (2025-05-20)

### 🚀 Features

- update type definitions | ART-50141 ([0a4f0b0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/0a4f0b01dc167c35d7502d8593798355959845f4))

## [1.131.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.130.0...v1.131.0) (2025-05-20)

### 🚀 Features

- slice before map | ART-50141 ([88dc499](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/88dc499bcae7efcde31e8d3b6fb93d4db420f94a))
- update transformAccountList to support sort and limit params | ART-50141 ([feb25ba](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/feb25ba0d18c3c35b62d8e07d8b2eb25af39efb4))

## [1.120.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.119.0...v1.120.0) (2025-05-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.119.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.118.0...v1.119.0) (2025-05-06)

### 🚀 Features

- art-47193 update transform pdp query result util ([1834b21](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1834b21394b84d25e5d242ba4e4d9f33d211687d))
- art-47193 update transform pdp query result util ([591aa18](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/591aa18dd460c8a53a12cf61889a8e92fc3e98de))
- art-47193 update transform pdp query result util ([c516ae2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c516ae23b0c5171ac08ebbf801bdd6a8c7e0fa96))
- art-47193 update transform pdp query result util ([1fcc517](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1fcc5177ab5d5ce3b0a52bf7dba396295bc69b5e))

## [1.118.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.117.1...v1.118.0) (2025-05-06)

### 🚀 Features

- art-47193 add transform pdp query result util ([4f688c5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4f688c57446be677980d176a39df0cd94705d63c))
- art-47193 add transform pdp query result util ([16f76eb](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/16f76eb170340a91276ba4f28908fb5d30ba0762))
- art-47193 add transform pdp query result util ([f08d5d4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f08d5d489fc09ce2b213962e354d9d7113f20440))
- art-47193 update transform pdp query result util ([5f2527e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5f2527e4dad4409761ee6b68b0073206d0f89871))
- art-47193 update transform pdp query result util ([ceedf2f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ceedf2f282ef95ab5afa328d176279156de639e8))

## [1.116.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.116.4...v1.116.5) (2025-04-30)

### 💥 Bug Fixes

- external library types | ART-53543 ([85b6b59](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/85b6b596595fa46ca391ea5bba4f15e3bd5ace01))

## [1.116.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.116.3...v1.116.4) (2025-04-30)

### 💥 Bug Fixes

- export module + rename function to differ from type | ART-53543 ([ddb0206](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ddb02061424bb51d89de65110dfff001a950c278))

## [1.116.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.116.2...v1.116.3) (2025-04-30)

### 💥 Bug Fixes

- path param + set request body undefined for POST calls to downstream GET services ([bb9d70a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/bb9d70afeb161c2b6e531d132fb8f8409fa095b3))

## [1.115.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.114.0...v1.115.0) (2025-04-22)

### 🚀 Features

- art-46689 update test mesh secret util ([0b5fd63](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/0b5fd633ef7818aea4b5e422129a678a04629a69))

## [1.114.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.113.0...v1.114.0) (2025-04-22)

### 🚀 Features

- art-46689 update test mesh secret util ([e628159](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/e62815900b5380bf2fc28837a8a74a0cfb183aaa))

## [1.113.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.112.2...v1.113.0) (2025-04-22)

### 🚀 Features

- art-46689 update test mesh secret util ([4116bd5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4116bd5eddd6b326f3accb943ad322f7cd5887e4))
- art-46689 update test mesh secret util ([2b8de36](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2b8de3641b7fd314982b1ea4f81171bf5a272d92))

## [1.112.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.112.0...v1.112.1) (2025-04-17)

### 💥 Bug Fixes

- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([01274a7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/01274a78bf92a29c2cdd4ab19d2c04ed21ff65ed))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([c50efa5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c50efa5f84b71f01b1b11e3ec1a90a8bc715b3e3))

## [1.112.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.111.0...v1.112.0) (2025-04-16)

### 🚀 Features

- art-46689 add read mesh secret util ([8413cbc](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8413cbc22194b8db7ac81d75325b7122f218545d))
- art-46689 add read mesh secret util ([06cc497](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/06cc497c68fbc522c002bb48e42a8af5be4125a3))
- art-46689 add read mesh secret util ([ab78c2e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ab78c2e625fc9bbc0527970b732cf5d5109c5cb7))
- art-46689 export mesh secret util ([9521c5e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9521c5e2f1ccaf501f5aedcd9c965043ffb02420))
- art-46689 export mesh secret util ([f745f06](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f745f06eb0f37b4f82c642ea63793ac6ef1538a3))
- art-46689 update test mesh secret util ([6d551d9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/6d551d96866f78c5883790f9a276e7c2f8607511))

## [1.108.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.108.0...v1.108.1) (2025-04-15)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.107.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.106.1...v1.107.0) (2025-04-11)

### 🚀 Features

- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([f6f5685](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f6f5685090a5a821f399c04eac38d452224d13bc))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([594177d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/594177d636efb09433616fb547bd15943b45cd7b))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([3af09bb](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3af09bbff1483f0cf7b78c00962d83e75b1a6c06))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([0e919f9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/0e919f9c96bf092f96848d49a6865092771e85f9))

## [1.103.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.103.0...v1.103.1) (2025-04-07)

### 💥 Bug Fixes

- add null safe access to req method | ART-50783 ([5a2c71d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5a2c71da1fa70ffce375d8f0857fc2fd23cbba51))
- remove the first questionmark as it is overly defensive and unneeded ([3991a3c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3991a3c140246c70bcca07e1aead89b75bdd7d96))

## [1.96.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.96.0...v1.96.1) (2025-03-31)

### 💥 Bug Fixes

- handleSetDownstreamParams to set body as undefined for GET requests | ART-44031 ([5f73098](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5f73098d0c0672a2ca27f3b2208245e805ed8095))

## [1.81.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.81.0...v1.81.1) (2025-03-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.80.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.80.3...v1.80.4) (2025-03-14)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.80.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.79.0...v1.80.0) (2025-03-13)

### 🚀 Features

- importing Pdp query actions from entitlement lib ([8044bec](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8044becb353e46cf9183b3637fb3aeebae04a924))
- updating the entitlements lib in util package.json ([c95619d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c95619dcf2d8646bdda25046e9336af8a8287161))

## [1.74.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.74.0...v1.74.1) (2025-03-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.69.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.69.1...v1.69.2) (2025-03-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.64.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.63.0...v1.64.0) (2025-02-24)

### 🚀 Features

- update handleApiService | ART-41956 ([ac44020](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ac440200a624c9b09b6bba37d1883046c0a1575a))

## [1.49.7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.49.6...v1.49.7) (2025-01-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.49.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.49.3...v1.49.4) (2025-01-23)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.49.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.49.0...v1.49.1) (2025-01-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.48.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.48.0...v1.48.1) (2025-01-20)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils

## [1.46.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.46.0...v1.46.1) (2025-01-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiutils
