/* eslint-disable react/prop-types */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable react/require-default-props */
import {
  InputGroup,
  InputGroupProps,
  ProgressIndicator,
  Select,
} from '@westpac/ui';
import React from 'react';
import {
  Control,
  Controller,
  FieldErrors,
  FieldValues,
  Path,
  RegisterOptions,
} from 'react-hook-form';

export type MVSelectControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  id?: string;
  label: string;
  size?: 'small' | 'medium' | 'large';
  width?: 1 | 2 | 'full' | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 20 | 30;
  validationRules?: RegisterOptions;
  options: Array<{ id: string; label: string; name: string }>;
  disabled?: boolean;
  placeholder?: string;
  hintText?: string;
  supportingText?: React.ReactNode;
  showSpinner?: boolean;
  onChange?: (
    selectedOption: { id: string; label: string; name: string } | undefined
  ) => void;
} & InputGroupProps;

function MVSelectController<T extends FieldValues>({
  label,
  fieldName,
  control,
  size = 'small',
  width = 10,
  errors,
  validationRules = {},
  options,
  disabled = false,
  placeholder,
  hintText,
  supportingText,
  showSpinner = false,
  onChange: onChangeProp,
  ...restProps
}: MVSelectControllerProps<T>) {
  const errorMessage = (errors[fieldName]?.message as string) ?? '';
  const invalid = Boolean(errors[fieldName]?.message);
  const handleOnChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedOption = options.find(
      option => option.label === event.currentTarget.value
    );

    // Call the custom onChange callback if provided
    if (onChangeProp) {
      onChangeProp(selectedOption);
    }

    return selectedOption;
  };

  return (
    <Controller
      name={fieldName}
      control={control as Control<FieldValues>}
      rules={validationRules}
      render={({ field: { onChange, value, ...rest } }) => (
        <InputGroup
          label={label}
          tag="fieldset"
          errorMessage={errorMessage}
          size={size}
          width={width}
          hint={hintText}
          {...restProps}
        >
          <div className="flex flex-col w-full">
            <div className="flex flex-row">
              <Select
                value={value?.label}
                onChange={event => onChange(handleOnChange(event))}
                disabled={disabled}
                {...rest}
                invalid={invalid}
                className={value === '' ? 'text-muted font-light' : 'text-text'}
                size={size}
                width={width}
              >
                {placeholder && (
                  <option key="placeholder" value="" disabled selected hidden>
                    {placeholder}
                  </option>
                )}
                {options.map(option => (
                  <option
                    className="text-text"
                    key={option.id}
                    value={option.label}
                  >
                    {option.label}
                  </option>
                ))}
              </Select>
              {showSpinner && <ProgressIndicator className="ml-2" />}
            </div>
            {supportingText && <div className="mt-2">{supportingText}</div>}
          </div>
        </InputGroup>
      )}
    />
  );
}

export default MVSelectController;
