import { InputGroupProps } from '@westpac/ui';
import React from 'react';
import {
  Control,
  FieldErrors,
  FieldValues,
  Path,
  RegisterOptions,
} from 'react-hook-form';

export type MVSelectControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  id?: string;
  label: string;
  validationRules?: RegisterOptions;
  options: Array<{ id: string; label: string; name: string }>;
  disabled?: boolean;
  placeholder?: string;
  size?: 'small' | 'medium' | 'large' | 'xlarge';
  width?: 1 | 2 | 'full' | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 20 | 30;
  hintText?: string;
  supportingText?: React.ReactNode;
  showSpinner?: boolean;
  onChange?: (
    selectedOption: { id: string; label: string; name: string } | undefined
  ) => void;
} & InputGroupProps;

export const MVSelectController: <T extends FieldValues>(
  props: MVSelectControllerProps<T>
) => React.ReactElement;
