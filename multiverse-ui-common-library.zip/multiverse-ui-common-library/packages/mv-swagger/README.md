# Using `update-swagger-files.sh` in MFEs

This guide explains how to fetch and update common Swagger YAML files in your Micro Frontends (MFEs).

## 1. Add CLI Commands to `package.json`

In your MFE's `package.json`, add the following scripts:

```json
"mv-swagger": "npm run mv-swagger.generate && npm run mv-swagger.clean",
"mv-swagger.generate": "curl -s -L -o ./update-swagger-files.sh 'https://bitbucket.srv.westpac.com.au/projects/WDP/repos/multiverse-ui-common-library/raw/packages/mv-swagger/bash/update-swagger-files.sh?at=refs/heads/master' && chmod +x ./update-swagger-files.sh && bash ./update-swagger-files.sh",
"mv-swagger.clean": "rm -f ./update-swagger-files.sh"
```

## 2. Usage

- **Fetch Swagger from the `master` branch of the multiverse-ui-common-library:**

  Run:

  ```sh
  npm run mv-swagger
  ```

  This will download and execute the script, fetching Swagger definitions from the `master` branch of the multiverse-ui-common-library.

- **Fetch Swagger from another branch of the multiverse-ui-common-library:**

  Run:

  ```sh
  npm run mv-swagger.generate feature/your-branch-name
  npm run mv-swagger.clean
  ```

  Replace `feature/your-branch-name` with the desired branch name from the multiverse-ui-common-library. This will fetch Swagger definitions from that branch.

## 3. Creating or Updating Swagger Definitions

- Use the shared definitions from the `swagger/mv-common` folder first. This folder contains common Swagger definitions endorsed by chapter lead.
- For MFE-specific definitions, add them to your MFE's `swagger/common` directory.
- If a definition can be shared across MFEs, contribute it to `mv-swagger` in the multiverse-ui-common-library.

> **Note:** Always keep your Swagger files up to date with the latest from the common library to ensure consistency across MFEs.

 
