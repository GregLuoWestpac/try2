# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.170.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.167.2...v1.170.1) (2025-07-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-pageloader

## [1.161.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.160.4...v1.161.0) (2025-07-14)

### 🚀 Features

- updated MVPageLoader | WIBDTW1-2513 ([d91ad71](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d91ad710843e9ac8bfd94bec81130612f5a0e953))

## [1.71.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.71.2...v1.71.3) (2025-03-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-pageloader
