export type IconSize = 'xsmall' | 'small' | 'medium' | 'large' | 'xlarge';
export type Placement = 'normal' | 'middle';
export type MVPageLoaderProps = { iconSize?: IconSize; placement?: Placement };
export function MVPageLoader({
  iconSize,
  placement,
}: MVPageLoaderProps): JSX.Element;
