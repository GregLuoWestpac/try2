import React from 'react';
import { ProgressIndicator, VisuallyHidden } from '@westpac/ui';

export type IconSize = 'xsmall' | 'small' | 'medium' | 'large' | 'xlarge';
export type Placement = 'normal' | 'middle';
export type MVPageLoaderProps = { iconSize?: IconSize; placement?: Placement };

export default function MVPageLoader({
  iconSize = 'medium',
  placement = 'normal',
}: MVPageLoaderProps) {
  const containerClass =
    placement === 'middle'
      ? 'flex min-h-screen h-full justify-center items-center'
      : 'flex flex-1 justify-center items-center';
  return (
    <div className={containerClass} data-testid="page-loader">
      <VisuallyHidden>Loading</VisuallyHidden>

      <ProgressIndicator size={iconSize} data-testid="progress-indicator" />
    </div>
  );
}
