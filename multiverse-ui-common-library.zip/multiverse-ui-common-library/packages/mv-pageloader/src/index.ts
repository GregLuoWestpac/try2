export { default as MVPageLoader } from './MVPageLoader';
