import React from 'react';
import { MVTableExportCSV } from '../../mv-table-v2/src/MVTable';
import { ProcessHeaderForExportParams } from 'ag-grid-community';

export const MVExportTableToCsv: (props: {
  shouldHideExportButton?: boolean;
  mvTableRef: React.RefObject<MVTableExportCSV | null>;
  exportedFileName: string;
  buttonText: string;
  className?: string;
  processHeaderCallback?: (params: ProcessHeaderForExportParams) => string;
}) => React.ReactElement;
