import { Button } from '@westpac/ui';
import { DateTime } from 'luxon';
import React from 'react';
import { MVTableExportCSV } from '@mesh-tenant-multiverse-ui-common/mv-table-v2/src/MVTable';
import { SYDNEY_ZONE } from '@mesh-tenant-multiverse-ui-common/mv-constants/src';
import { ProcessHeaderForExportParams } from 'ag-grid-community';
type Props = {
  shouldHideExportButton?: boolean;
  mvTableRef: React.RefObject<MVTableExportCSV | null>;
  exportedFileName: string;
  buttonText: string;
  className?: string;
  processHeaderCallback?: (params: ProcessHeaderForExportParams) => string;
};

export function MVExportTableToCsv({
  shouldHideExportButton = false,
  mvTableRef,
  exportedFileName,
  buttonText,
  className,
  processHeaderCallback,
}: Props) {
  const exportCsvHandler = () => {
    const currentDate = DateTime.utc()
      .setZone(SYDNEY_ZONE)
      .toFormat('yyyyLLdd');
    const csvFileName = `${exportedFileName}-${currentDate}.csv`;
    mvTableRef.current?.exportCsv(csvFileName, true, processHeaderCallback);
  };

  if (shouldHideExportButton) {
    return null;
  }

  return (
    <Button
      data-testid={`${buttonText.toLowerCase().replace(/ /g, '-')}-button`}
      soft
      className={`font-semibold mt-0 ${className}`}
      look="hero"
      size="small"
      onClick={exportCsvHandler}
    >
      {buttonText}
    </Button>
  );
}
