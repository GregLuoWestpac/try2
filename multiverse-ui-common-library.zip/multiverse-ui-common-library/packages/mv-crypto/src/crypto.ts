export async function encryptWithRsaOaep256(plainText, publicKeyPem) {
  function publicPemToBuffer(pem) {
    const b64Lines = pem
      .replace('-----BEGIN PUBLIC KEY-----', '')
      .replace('-----END PUBLIC KEY-----', '')
      .replace(/\n/g, '');
    const binaryString = atob(b64Lines);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
  }

  const keyBuffer = publicPemToBuffer(publicKeyPem);
  const publicKey = await window.crypto.subtle.importKey(
    'spki',
    keyBuffer,
    {
      name: 'RSA-OAEP',
      hash: 'SHA-256',
    },
    true,
    ['encrypt']
  );

  const encoded = new TextEncoder().encode(plainText);

  const encryptedBuffer = await window.crypto.subtle.encrypt(
    {
      name: 'RSA-OAEP',
    },
    publicKey,
    encoded
  );

  function arrayBufferToBase64(buffer) {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary)
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');
  }

  return arrayBufferToBase64(encryptedBuffer);
}

export const getCryptoFunctions = ({
  createPublicKey,
  publicEncrypt,
  createHash,
  createDecipheriv,
  createHmac,
  constants,
}: {
  createPublicKey;
  publicEncrypt;
  createHash;
  createDecipheriv;
  createHmac;
  constants;
}) => {
  const fromB64UrlString = b64Payload => {
    let incoming = b64Payload.replace(/\_/g, '/').replace(/\-/, '+');

    if (b64Payload.length % 4 == 2) incoming += '==';
    else if (b64Payload.length % 4 == 3) incoming += '=';

    return Buffer.from(incoming, 'base64');
  };

  const toB64UrlString = payload => {
    return (
      payload
        .toString('base64')
        //.replace(/[=]*$/, '')
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
    );
  };

  const encryptSdekWithRsaPublicKey = (sdekBuffer, keyPemEncoded) => {
    const publicKey = createPublicKey(keyPemEncoded);
    const buffer = Buffer.from(sdekBuffer);
    const encrypted = publicEncrypt(
      {
        key: publicKey,
        padding: constants.RSA_PKCS1_OAEP_PADDING,
        oaepHash: 'sha512',
      },
      new Uint8Array(buffer)
    );

    return toB64UrlString(encrypted);
  };

  const sha512Hash = toDigest => {
    const hash = createHash('sha512');
    //passing the data to be hashed
    const data = hash.update(new Uint8Array(Buffer.from(toDigest, 'hex')));
    //Creating the hash in the required format
    return toB64UrlString(data.digest());
  };

  const encryptStringWithRSAOAEP256 = async (toEncrypt, keyPemEncoded) => {
    const publicKey = createPublicKey(keyPemEncoded);
    const buffer = Buffer.from(toEncrypt, 'utf-8');
    // Use RSA-OAEP with SHA-256
    const encrypted = publicEncrypt(
      {
        key: publicKey,
        padding: constants.RSA_PKCS1_OAEP_PADDING,
        oaepHash: 'sha256',
      },
      new Uint8Array(buffer)
    );
    // Return as base64url string
    return toB64UrlString(encrypted);
  };

  const decryptWithSdek = async (
    sdekBuffer: Uint8Array,
    sdekEncryptedData: string
  ) => {
    const key = sdekBuffer;
    let enc = fromB64UrlString(sdekEncryptedData);
    const iv = enc.subarray(4, 16);
    const tag = enc.subarray(enc.length - 16);

    enc = enc.subarray(16, enc.length - 16);

    const decipher = createDecipheriv('aes-256-gcm', key, new Uint8Array(iv));
    decipher.setAuthTag(new Uint8Array(tag));
    let plainText: string = decipher
      .update(new Uint8Array(enc))
      .toString('utf-8');
    plainText += decipher.final('utf8');

    return plainText;
  };

  const signDataWithHMacSha512 = (keyHex, header, payload) => {
    const hmac = createHmac(
      'sha512',
      new Uint8Array(Buffer.from(keyHex, 'hex'))
    );

    const toSign =
      toB64UrlString(Buffer.from(header, 'utf-8')) +
      '.' +
      toB64UrlString(Buffer.from(payload, 'utf-8'));

    const data = hmac.update(new Uint8Array(Buffer.from(toSign, 'utf-8')));
    //Creating the hash in the required format
    return toB64UrlString(data.digest());
  };

  const deriveHmacSigningKey = (comp1, comp2) => {
    if (comp1.length !== comp2.length)
      throw Error('both component length must be same');

    const buf1 = Buffer.from(comp1, 'hex');
    const buf2 = Buffer.from(comp2, 'hex');

    for (let i = 0; i < comp1.length; i++) buf1[i] = buf1[i] ^ buf2[i];

    return buf1.toString('hex');
  };
  return {
    encryptSdekWithRsaPublicKey,
    sha512Hash,
    encryptStringWithRSAOAEP256,
    decryptWithSdek,
    signDataWithHMacSha512,
    deriveHmacSigningKey,
    fromB64UrlString,
    toB64UrlString,
  };
};
