export declare function encryptWithRsaOaep256(
  plainText: string,
  publicKeyPem: string
): Promise<string>;

export declare function getCryptoFunctions(functions: {
  createPublicKey: Function;
  publicEncrypt: Function;
  createHash: Function;
  createDecipheriv: Function;
  createHmac: Function;
  constants: unknown;
}): {
  fromB64UrlString: (b64Payload: string) => Buffer;
  toB64UrlString: (payload: Buffer) => string;
  encryptSdekWithRsaPublicKey: (
    sdekBuffer: Uint8Array,
    keyPemEncoded: string
  ) => string;
  sha512Hash: (toDigest: string) => string;
  encryptStringWithRSAOAEP256: (
    toEncrypt: string,
    keyPemEncoded: string
  ) => Promise<string>;
  decryptWithSdek: (
    sdekBuffer: Uint8Array,
    sdekEncryptedData: string
  ) => Promise<string>;
  signDataWithHMacSha512: (
    keyHex: string,
    header: string,
    payload: string
  ) => string;
  deriveHmacSigningKey: (comp1: string, comp2: string) => string;
};
