# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.225.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.224.9...v1.225.0) (2026-02-04)

### 🚀 Features

- add utils for encrypting/decrypting with sdek | ART-84491 ([8070d4e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8070d4e1e034b1cbdca834f7a72cecb3cd8f028c))

### 💥 Bug Fixes

- change types for parameters | ART-84491 ([56cbf23](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/56cbf233289f19a443663220d22134ce5f47cc77))
- pass crypto functions as params | ART-84491 ([f5cf8c0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f5cf8c0d5af528604cce91669e8f54b93a65e3f5))

## [1.219.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.0...v1.219.1) (2025-12-19)

### 💥 Bug Fixes

- add back deleted files | ART-88711 ([9b541f6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9b541f66f1babf412fa5f9f318b3533504b1ee0e))

## [1.219.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.218.0...v1.219.0) (2025-12-19)

### 🚀 Features

- add mv-crypto package, add enrpytion function | ART-84491 ([70955e7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/70955e7f67f3c27899f0ed6482b9752e12b0dc0e))

### 💥 Bug Fixes

- remove hardcoded public key | ART-84491 ([a6c3dec](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a6c3decd0d01b8af22a06a211bb4ba52c440675e))
