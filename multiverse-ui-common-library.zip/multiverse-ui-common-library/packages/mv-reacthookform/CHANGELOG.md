# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.229.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.229.0...v1.229.1) (2026-02-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.228.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.227.0...v1.228.0) (2026-02-12)

### 🚀 Features

- add todo comment for future feature | ART-88591 ([4269222](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/426922200e1aa6590f04857fef0241a790efb1b7))
- move error messages to constants file and small refactor | ART-88591 ([951e304](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/951e3041f661851d8e9928205b6d53e395b1f60c))
- refactor code to take external validation for error scenarios | ART-88591 ([a2e8272](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a2e8272745f5c5086466a7418f90a5d8e74e9fe8))
- remove unused variable | ART-88591 ([68f4288](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/68f42885e751bf055c0a6a3c1516fe041642c61e))
- show currency symbol instead of code | ART-88591 ([d824e15](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d824e15053b1a2d6769a4768d38c77ca7fe2ce82))
- small code refactor for error scenarios and add test file | ART-88591 ([97b2110](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/97b211066f7de9c848633eca59feccfea98ea5cb))
- update prop name and added variable | ART-88591 ([8674205](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8674205971bd3c1589cfc00e3ed20649b23496e6))
- update props and add switch case | ART-88591 ([c36ea2b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c36ea2bcb5140dcfe1184d768527aa7afdd0c0fa))
- update readme file | ART-88591 ([df85b59](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/df85b593652ad5fe7a41961af00c1ceedd340b09))
- update type definitions and constants | ART-88591 ([3c216d2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3c216d22fd22e45ebe95921acdcffda9d2bc2b82))
- uplift amount range component for treasury page | ART-88591 ([333149a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/333149aedf52451d2ca1e267e242f30a00ca44cf))
- uplift currency string formatting for treasury page | ART-88591 ([51e2822](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/51e2822b1f8c263c587e5007981a3578c53941c9))

### 💥 Bug Fixes

- add default for switch statement | ART-88591 ([e7ea3c7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/e7ea3c7051ef8f4f277c40f93576e3fdf6078ea5))
- update test to pass build | ART-88591 ([9576230](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/957623090088f4d3e38b575bb0cba0dd268d2468))

## [1.227.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.226.2...v1.227.0) (2026-02-11)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.225.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.225.3...v1.225.4) (2026-02-05)

### 💥 Bug Fixes

- add missing MVCheckboxController export to index file | ART-98630 ([b592726](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b59272662c8b5a536da300741e4d9bc98efb17c0))

## [1.225.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.225.2...v1.225.3) (2026-02-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.225.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.225.0...v1.225.1) (2026-02-05)

### 💥 Bug Fixes

- enhance trimText function and integrate maximumLength handling in MVInputController | ART-98630 ([2657671](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/26576714fa5d13f75e8d57012da8d668f54d6ff5))

## [1.219.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.5...v1.219.6) (2026-01-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.219.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.3...v1.219.4) (2026-01-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.219.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.2...v1.219.3) (2026-01-13)

### 💥 Bug Fixes

- update validation logic to restrict amount range for greater than 99999999999.99 || ART-96550 ([c2a72f3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c2a72f3aedd9ae3609b26b236dac4dda32ee1704))

## [1.219.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.0...v1.219.1) (2025-12-19)

### 💥 Bug Fixes

- add back deleted files | ART-88711 ([9b541f6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9b541f66f1babf412fa5f9f318b3533504b1ee0e))

## [1.219.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.218.0...v1.219.0) (2025-12-19)

### 🚀 Features

- updated mv input to accept type | ART-84488 ([ac5279e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ac5279e3d5bc255c0372c6b0480ad240645edba9))
- updated type | ART-84488 ([6e8f1a0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/6e8f1a0c8f2e18bbeaa39751c1959fd0ca58e729))

## [1.215.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.215.0...v1.215.1) (2025-12-09)

### 💥 Bug Fixes

- re-add InputGroupProps to MVCurrencyController | ART-83263 ([042fb9e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/042fb9ed4fffc00712747392ea78844c5f9dbfd5))

## [1.215.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.214.0...v1.215.0) (2025-12-09)

### 🚀 Features

- migrate Feb2026 inputs to standard | ART-83263 ([156b6bf](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/156b6bf3fde0a94313420005132ec2463d941902))

### 💥 Bug Fixes

- update imports | ART-83263 ([7bc282e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/7bc282eea67366347fadfb01e0c7bcabac28d570))

## [1.210.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.210.2...v1.210.3) (2025-11-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.210.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.210.1...v1.210.2) (2025-11-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.210.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.209.2...v1.210.0) (2025-11-13)

### 🚀 Features

- add onChange prop to MVSelectController for handling selection change | ART-70047 ([a72dbc0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a72dbc054f80092129fbefd149dc04ba34fbcc93))

## [1.209.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.209.1...v1.209.2) (2025-11-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.205.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.205.5...v1.205.6) (2025-10-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.205.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.205.2...v1.205.3) (2025-10-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.205.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.204.0...v1.205.0) (2025-10-27)

### 🚀 Features

- add sanitisation/trimming to custom RHF components | ART-74341 ([f3c9cbc](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f3c9cbcaab8f57be3e7a2c6afcf6108eb0d4737a))
- added autofill behaviour | ART-70475 ([3fb3b88](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3fb3b88b30fb02503ff9c8279f917f96807dfccf))
- correct naming error for Feb2026 component | ART-74341 ([e91ec14](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/e91ec14dae9f5333995fab5c9c8c5f8e21df4fce))
- restore existing components for side-by-side deployment | ART-74341 ([7a50a8c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/7a50a8cdb934d2419ba0de522c0a120ca8086de6))
- update readme for sanitisation/trimming | ART-74341 ([77b24b6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/77b24b6af2f15c022cc784077e33ec647262243f))
- updated formatCurrencyString to allow zero for amountRange | ART-70475 ([971528d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/971528d0a071ce0aa063fa70d43f4cb26034060e))
- updated invalid value message | ART-70475 ([059b627](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/059b627a456168c821294be156b1e5443df9d3c4))

### 💥 Bug Fixes

- bypass flaky test ([5b7cc8c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5b7cc8cc64333f5bbaf8821eb1f9b651e8a559ae))

## [1.201.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.201.1...v1.201.2) (2025-10-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.192.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.192.0...v1.192.1) (2025-10-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.191.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.191.0...v1.191.1) (2025-10-10)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.188.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.187.0...v1.188.0) (2025-10-07)

### 🚀 Features

- added type defs and updated readme file | ART-70475 ([85d3221](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/85d32219fee299f8148d66c497c979624cfdaead))
- created complete amountRange component | ART-70475 ([dbe7520](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/dbe75201889389b543ff14dd3ae5a83da441f990))
- refactor code to allow for 0 dollars input | ART-70475 ([322e6c5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/322e6c52ebc1f63847eb8d1a56ca0570c8f7a243))
- remove DOM query for input values and updated error msg | ART-70475 ([42b4648](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/42b4648503e106efd4a69ec29f6b3cf6c6407229))
- remove getClassName() and fix code indentation | ART-70475 ([b6fd023](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b6fd02323934f86d0a69e576cc823f24c31c4f6f))
- removed default prop values | ART-70475 ([ec9ad38](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ec9ad38864048ff4d0587f44570d7f7a18afbc21))
- removed fieldRest | ART-70475 ([57479f9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/57479f9854db7cd550616d9137c3b14bb31c6542))
- removed fix width in InputGroup and set in div instead | ART-70475 ([a2c9a6f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a2c9a6f7e3f3d50fa46ac454ad966ea96e3b5b83))

## [1.187.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.186.5...v1.187.0) (2025-10-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.184.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.184.1...v1.184.2) (2025-09-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.184.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.184.0...v1.184.1) (2025-09-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.182.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.182.0...v1.182.1) (2025-09-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.179.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.179.0...v1.179.1) (2025-09-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.178.10](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.178.9...v1.178.10) (2025-08-18)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.177.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.176.0...v1.177.0) (2025-08-11)

### 🚀 Features

- make second autocomplete item optional | ART-68405 ([99357e5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/99357e53185115f632ca08ffe8d6e53f25dc520c))
- make third autocomplete item optional | ART-68405 ([360a456](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/360a4567c32d77a0367ccbd447866b6e50ca4792))

## [1.173.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.173.0...v1.173.1) (2025-07-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.171.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.171.4...v1.171.5) (2025-07-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.171.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.171.0...v1.171.1) (2025-07-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.170.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.167.2...v1.170.1) (2025-07-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.161.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.161.0...v1.161.1) (2025-07-16)

### 💥 Bug Fixes

- button group controller default value bug | ART-67809 ([ebaa017](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ebaa0172dc61836666cbe586c25918ae289df00c))

## [1.156.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.156.1...v1.156.2) (2025-07-08)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.156.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.156.0...v1.156.1) (2025-07-08)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.151.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.151.1...v1.151.2) (2025-07-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.144.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.143.0...v1.144.0) (2025-06-12)

### 🚀 Features

- fix loading icon position issue ([eea6149](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/eea614941d41ebb220d88898333a7c10ada99281))

## [1.139.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.139.0...v1.139.1) (2025-06-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.138.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.138.0...v1.138.1) (2025-06-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.137.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.137.2...v1.137.3) (2025-05-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.137.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.137.0...v1.137.1) (2025-05-27)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.137.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.136.0...v1.137.0) (2025-05-27)

### 🚀 Features

- update readme | ART-43405 ([49ec37e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/49ec37e964740d47489368f4d393d2c3e8a845e5))

## [1.135.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.134.1...v1.135.0) (2025-05-27)

### 🚀 Features

- update mvselectcontroller width full issue | ART-43405 ([8741943](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8741943749ddb11a29c0f09279288f7e21643e2e))

## [1.130.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.129.0...v1.130.0) (2025-05-14)

### 🚀 Features

- tiny changes to remove useless code ([3a71b49](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3a71b49a339e52ea594391bece12b4a8ccb714dc))

## [1.129.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.128.0...v1.129.0) (2025-05-14)

### 🚀 Features

- revert ([d698882](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d69888287a95fe1c2514fde9565b413c8155e01f))
- tiny changes for clear button ([6664f48](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/6664f489ad9dc7e8d810863f069e9473b9c12f11))

## [1.128.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.127.0...v1.128.0) (2025-05-14)

### 🚀 Features

- update useAutocompleteWrapper ([014726b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/014726b3f2db40f554cb86d76f973a7ce594879b))
- update useAutocompleteWrapper ([87595c8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/87595c884484cc0cbc20bbe85ad5fcdac58ad52c))

## [1.127.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.126.0...v1.127.0) (2025-05-13)

### 🚀 Features

- updated code for onChange function | ART-53954 ([2d5c8e5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2d5c8e524a84de04b400747749df815b8f5b4aa2))

## [1.124.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.123.0...v1.124.0) (2025-05-08)

### 🚀 Features

- add default css class to MVInputController | ART-53975 ([265ff56](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/265ff562be39abcfac59a4246ef155fb348b843c))

## [1.110.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.110.0...v1.110.1) (2025-04-15)

### 💥 Bug Fixes

- changed param name | ART-52269 ([4f21cc6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4f21cc6d3f017ff55fd650c1f559d18fa33f0539))

## [1.109.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.109.0...v1.109.1) (2025-04-15)

### 💥 Bug Fixes

- moved spinner into MVSelector | ART-52269 ([09763bc](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/09763bca7d3a7477f241ab826f5caccc1530e180))

## [1.108.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.107.0...v1.108.0) (2025-04-14)

### 🚀 Features

- ART-41757 update issues found by Abrham ([affe77b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/affe77b0b72fe3a46c0d56a19b0b114ebafcf09a))
- ART-41757 update matchPattern ([e3bd0b7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/e3bd0b79a4b6e62d87f45adfe9b0f02ba2491647))

## [1.106.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.105.0...v1.106.0) (2025-04-10)

### 🚀 Features

- add blur validation and isInvalid logic | ART-41745 ([c9c3c86](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c9c3c86bc61978006f3fbbb558c56a4edb4b891d))
- add readme | ART-41745 ([5ae99ca](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5ae99ca9c46c79a5920c5ca78c9e13dab43e2d3f))
- add validation rules | ART-41745 ([c4f1215](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c4f1215b64d17be16b3d952d4d74d3596e666c9d))
- refactor with trigger | ART-41745 ([620e0ca](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/620e0cab5e102c18e2502e0521db712afa00bc86))
- update type definition | ART-41745 ([29faf01](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/29faf016f5c594ec757094f40ec3beeb1c25165f))
- update type definitions | ART-41745 ([363f356](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/363f3560cce68d898781c3d1b68c440939e888e0))
- updated readme | ART-41745 ([cfb7df7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/cfb7df79e0107ddf9236b17472847c5344bd70e5))

## [1.105.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.104.0...v1.105.0) (2025-04-10)

### 🚀 Features

- ART-41757 delete minItemsForFooter ([61f10de](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/61f10de95ad6a692a8068657c0e20a16cff476a6))
- ART-41757 update ([8517f38](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8517f38141856dca3fb27c9ad2c34c2accbc8188))
- ART-41757 update footerText ([6795330](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/6795330ee13da64b6aaa2b823dfbeb783d344678))
- ART-41757 use fullMatchRegex ([5d62784](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5d6278499eccef88ea26618106ed563eb6a7f384))

## [1.103.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.102.2...v1.103.0) (2025-04-07)

### 🚀 Features

- ART-41757 add inputValueFn ([37c4862](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/37c4862a2187f26887dfa0e105041cceda0145cb))
- ART-41757 update test cases ([4382ed5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4382ed548c9cf76309a1bfb926914821648ae857))
- ART-41757-make the name optional ([f17669c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f17669cc0a981f3982611532c4c7d43c55b6b611))

## [1.102.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.101.0...v1.102.0) (2025-04-03)

### 🚀 Features

- ART-41757 add warn for duplicated items ([c5b8409](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c5b8409a150312f21b1717ac70040682a7b2613f))
- ART-41757 remove defaultProps ([be8ed20](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/be8ed2094d48a77ecf123727c74aad6ca36eba20))
- ART-41757 revert MVSearchInputController ([23cbd3a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/23cbd3a0712145f66f94a0e96b82e68972d5f910))

## [1.101.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.100.0...v1.101.0) (2025-04-02)

### 🚀 Features

- add comments | ART-39684 ([d664292](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d664292b20d86feefc1cf20842a049053aaf36d5))
- create MVButtonGroupController | ART-39684 ([c264596](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c264596934e5958ccf697ceee180854a23eae26e))
- refactor | ART-39684 ([ea877d5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ea877d5d20a6883f8e47321d647266c99b91b36f))

## [1.99.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.98.0...v1.99.0) (2025-04-02)

### 🚀 Features

- ART-41757-clean up ([738451d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/738451d57a56517bbd36d301d9c1ddc7ce7d92c3))

## [1.98.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.97.2...v1.98.0) (2025-04-02)

### 🚀 Features

- ART-41757-filterItems ([9d3f1ad](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9d3f1ad5300b0f1df740355c05f938dbd09773f3))
- ART-41757-fix issue ([d36288f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d36288f6d7adf17b13f488488f4cfd6ccf7d9198))
- ART-41757-fix issue ([e70e8af](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/e70e8af67e83588e3ecc94bb69aca14b5dbaf51d))
- ART-41757-fix issue ([7503de7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/7503de77b6a7838a8243fb65d7f5da318e44a5e8))
- ART-41757-update autocomplete ([2a1e81d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2a1e81d534a336aca896134f5504f2ab0c88bd98))
- ART-41757-update UT ([9998222](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/999822225f3a8c5c8ecf500ddbc377c49c77c113))

## [1.97.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.97.1...v1.97.2) (2025-04-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.97.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.97.0...v1.97.1) (2025-04-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.97.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.96.3...v1.97.0) (2025-04-01)

### 🚀 Features

- ART-41757-add onBeforeInput ([032119b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/032119b45119bf382d35dfa41b245eb989711ef0))
- ART-41757-tiny ([287fbcc](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/287fbcc201a62c7263fca7b251625ae937492cba))
- ART-41757-update MVPhoneInputController ([045edcd](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/045edcd3e91371b74844c9b941f08002d5857dae))
- ART-41757-update MVPhoneInputController ([32fa969](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/32fa969780c1c39134634f351fc23716bbf25b72))
- ART-41757-update phoneInputController ([d674733](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d6747339cd17755111cf290bdec25ca8a98902ba))
- ART-41757-update removeDialCodeAndDelimiter ([3d0e62a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3d0e62af39690b317e8da6860db8c7921303283c))
- ART-41757-update type definition ([2b0cc4f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2b0cc4f65c3eff4847b0c1f3e12582f638544bed))

## [1.96.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.96.2...v1.96.3) (2025-04-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.96.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.96.1...v1.96.2) (2025-04-01)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.96.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.95.1...v1.96.0) (2025-03-28)

### 🚀 Features

- ART-41757-fix "overlapping the input box" issue ([52a451c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/52a451c268124803cd6aaac27676dbfe3357ee46))
- ART-41757-update handleFocus ([43a1eee](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/43a1eee5fb55309d2811d247c6eee241098144b2))

## [1.94.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.93.0...v1.94.0) (2025-03-26)

### 🚀 Features

- ART-41757 update onChange ([fcd771e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/fcd771ecd2aee07215496a3b31c53686e748f008))
- ART-41757 update showDropdownList ([1753fe8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1753fe8e2aabfce5ea71e39d9e80d9389157b760))

## [1.93.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.92.0...v1.93.0) (2025-03-26)

### 🚀 Features

- ART-41757 add onClick ([1263aac](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1263aac85f9e50904b2047af511f31c9529bdb36))
- ART-41757 update handleBlur ([fb82ae9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/fb82ae9d237c815c433dc1b7cb3beeb05a4916c9))

## [1.92.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.91.0...v1.92.0) (2025-03-25)

### 🚀 Features

- ART-41757 add onChange ([fcbc770](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/fcbc770c3bf5645fc559d1f99d97d2bd0faaeb28))
- ART-41757 invalid={!!errorMessage} ([b340385](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b340385933d3a97eb8a0a4d54d55b0a202403b0f))

## [1.91.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.90.0...v1.91.0) (2025-03-25)

### 🚀 Features

- ART-41757 add onChange and pattern for MVInputController ([4649da6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4649da6a76bf39ae0300690d3482b4ec20026787))
- ART-41757 rename ([a9fe932](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a9fe932446831ebe6ed6ff47bd515a7a5092b4df))
- ART-41757 rename ([b2d1aff](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b2d1aff64d636b4e86dbe30463134a22b75eb223))
- ART-41757 tiny change ([2bb8dfa](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2bb8dfa79ee50032d6e475a42d22362671e9d553))

## [1.89.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.88.0...v1.89.0) (2025-03-24)

### 🚀 Features

- ART-44081-restProps ([06aa1f9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/06aa1f94fa28bec61f7607dadf62083ffd0ebc20))
- ART-44081-update AutocompleteItemDetailsTemplate ([b06e44a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b06e44aa31c08c200a36971b07f70612555db308))

## [1.88.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.87.0...v1.88.0) (2025-03-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.87.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.86.0...v1.87.0) (2025-03-20)

### 🚀 Features

- ART-41757- delete DefaultAdditionalDetails.tsx ([b55036d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b55036df308551e745b93197c29525bf11979f1d))

## [1.86.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.85.0...v1.86.0) (2025-03-20)

### 🚀 Features

- ART-41757- add filterFn ([c94e6bb](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c94e6bbc5b803b07e68c9e0c49fffc4c312d21df))
- ART-41757- add restProps ([216de4f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/216de4f35574bd5552fc71f0dbb5156126cc2cec))

## [1.84.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.83.0...v1.84.0) (2025-03-19)

### 🚀 Features

- added supporting text to bottom of select element so you can style it to match width of select ([031dc90](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/031dc901926540feb3b2113becbeb9ba6e6f5b1b))

## [1.81.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.80.5...v1.81.0) (2025-03-18)

### 🚀 Features

- ART-41757 update according to requirements from Alankar ([5344bd0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5344bd0fde56b4d2efb7e29c95f5bd0332f86bbb))

### 💥 Bug Fixes

- use ReactNode | ART-41757 ([a4fca7e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a4fca7e49f9cb25b6f05c4a75e977ea6ea2b9a0c))

## [1.79.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.78.0...v1.79.0) (2025-03-13)

### 🚀 Features

- ART-44985 tiny update to remove the default value ([05c5401](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/05c54017425a65868223f3dd01edf9d45652bbfa))

## [1.78.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.77.0...v1.78.0) (2025-03-13)

### 🚀 Features

- ART-44985 tiny update ([4d5c114](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4d5c1149a69e28918b81bf953517350cce147f38))

## [1.77.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.76.0...v1.77.0) (2025-03-13)

### 🚀 Features

- ART-44985 add onBlur ([dce663d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/dce663dc588497b4ff93045b97f9a42e9f5238de))
- ART-44985 add MVPhoneInputController ([92c148e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/92c148e3d538591d0f9dcc038ea8fd8aebafdccd))
- ART-44985 clean up ([5861526](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5861526b70a4e4d9ef16dc0034aa7aeb3348ec69))
- ART-44985 tiny ([b073fef](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b073fefa9a236dc9bcab66a6256a75978932c4ee))
- ART-44985 tiny ([d140be5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d140be56785e6c82e41859611aa0d13de8ceb9c8))
- ART-44985 update according to comments ([831ecac](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/831ecac5f95420b6757c2d0c65dff44c87fbc787))
- ART-44985 update index.d.ts ([579c921](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/579c9215c2fa5066c01c00bc7df8f04701b737bd))
- ART-44985 update MVPhoneInputController ([251545b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/251545b61762fc17a09adfeae90b91b703686e0b))

## [1.75.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.74.3...v1.75.0) (2025-03-11)

### 🚀 Features

- ART-39683 update MVInputController ([f56504c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f56504c56a50d4da950c21554a1bbcc623f2c40e))

## [1.73.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.72.1...v1.73.0) (2025-03-10)

### 🚀 Features

- ART-41575 AutocompleteItemDetailsTemplate ([25f481d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/25f481d042fd66accdbd35f109fa724158b14d2b))
- ART-41575 clean up autocomplete ([0caddb3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/0caddb3cb5d8bd5de8eb46adbd90470f383e506e))
- ART-41575 remove undefined for AdditionalDetails ([a8f856a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a8f856a6e1acfbf7cb211af3e3a3bca7201bef50))
- ART-41575 update autocomplete ([f6f3d45](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f6f3d45f1bf03a34271cdd8e241633a0e4d85666))

## [1.71.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.71.1...v1.71.2) (2025-03-06)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.70.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.69.4...v1.70.0) (2025-03-04)

### 🚀 Features

- ART-41757 update date range picker ([1ac27b5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1ac27b5575f421311d38bea922d7943f4323ee82))
- ART-41757 update date range picker ([c8d3305](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c8d3305d2fbfb5fafe1f12ee1fbb9f08672f0a09))
- ART-41757 update date range picker type definition ([0c58883](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/0c58883435564bef12d5a751b2e3f36f364621f2))
- ART-41757 update UT cases ([94dbe3d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/94dbe3daf1e55cfc2213fe18e703498859826e1b))

## [1.69.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.69.2...v1.69.3) (2025-03-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.69.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.69.0...v1.69.1) (2025-02-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.68.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.67.0...v1.68.0) (2025-02-26)

### 🚀 Features

- mvselect placeholder style changes | ART-39584 ([1c5cdac](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1c5cdaccc66ed033b603d5fc7b301ff8c35e1a53))
- mvselect placeholder style changes | ART-39584 ([a39e662](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a39e6624618c39d6784f186d1d7cc2c840197489))
- pr comments | ART-39584 ([1850693](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/185069380bb05c999abd9bf3b1ecfbceabab0762))

## [1.66.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.66.2...v1.66.3) (2025-02-26)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.66.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.66.1...v1.66.2) (2025-02-26)

### 💥 Bug Fixes

- added type definitions | ART-42495 ([5af680f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5af680f26a00a4540ef2beafcf60d285d942848b))

## [1.66.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.66.0...v1.66.1) (2025-02-25)

### 💥 Bug Fixes

- added hint text as an optional prop | ART-42495 ([c117a72](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c117a72d20fcdbc8f11c6b6500e4731d9062736d))

## [1.66.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.65.0...v1.66.0) (2025-02-25)

### 🚀 Features

- ART-41757 filteredItems ([667cec7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/667cec7b3d1d248490e8eefc7df09c50111e0f38))
- ART-41757 use "!important" to align with Payment-MFE ([2123182](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/21231828851cf2e12e29851a1b27bafcb4fe7427))

## [1.65.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.64.1...v1.65.0) (2025-02-25)

### 🚀 Features

- implement MVAutocompleteController | ART-41757 ([5f01742](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5f01742c2adbd9dca9373febb8a3be81fe9cbb18))
- override the theme-root | ART-41757 ([851124f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/851124f8d251cf9a89eda0cef4935fea169238da))
- update class name | ART-41757 ([d2bf01b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d2bf01ba48fafddb3a2fa9919296db9cca1ce3cb))
- update handleSelectionChange() | ART-41757 ([78236e0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/78236e0c22aa6312e484860a343d3c49d3370de7))
- use autocomplete-wrapper.css | ART-41757 ([600f3d9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/600f3d9abd23859c2ba1b1d701c5aa29ee9cce6f))

## [1.64.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.64.0...v1.64.1) (2025-02-24)

### 💥 Bug Fixes

- added placeholder prop in mvselect | ART-39584 ([85e2504](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/85e250419da5cc83417e5254aa642dfd9a3ac66e))

## [1.62.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.62.0...v1.62.1) (2025-02-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.62.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.61.0...v1.62.0) (2025-02-20)

### 🚀 Features

- remove useEffect | ART-40541 ([736cb76](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/736cb76d879e7a37a9de44a065755c86a8cdaf0c))
- update error message | ART-40541 ([6e42bb3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/6e42bb30132578c3afadbdaeac5ba6c4fda26438))

## [1.61.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.60.3...v1.61.0) (2025-02-19)

### 🚀 Features

- clean up | ART-39719 ([d30d02c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d30d02c3722e9542402f2fd9a9aa3b10106740a8))
- remove Grid and GridItem | ART-39719 ([ba1f1a6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ba1f1a6d2df108469c4a7cbe25137836d2355d98))
- remove validation when value changes | ART-39719 ([e9791a1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/e9791a11b19a22def769e9139d735394be19486d))
- update DatePickerWrapper | ART-39719 ([8634910](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8634910561b8a82e2a31c08845e51585360289cf))
- use westpacui v0.41 | ART-39719 ([a346407](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a34640799d98e5c4ceb0e7b21aa262d5745ec133))

## [1.59.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.58.3...v1.59.0) (2025-02-12)

### 🚀 Features

- update right arrow icon | ART-39719 ([5738097](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/57380974dadedef38270be549959322a92e02668))

## [1.58.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.58.0...v1.58.1) (2025-02-10)

### 💥 Bug Fixes

- add parameter to type def | ART-29898 ([f05ce8b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f05ce8b9863a7c4a7ba4692ccdba28ea0f2fe424))

## [1.58.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.57.0...v1.58.0) (2025-02-09)

### 🚀 Features

- changes in MVSearchInputController to pass onChange value | ART-27663 ([659a13a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/659a13abb743509fdc2d1275c160480753f49f80))

## [1.57.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.56.0...v1.57.0) (2025-02-06)

### 🚀 Features

- add red border around Select component when an error occurs | ART-29899 ([fb61735](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/fb61735f845b0dc6e93082a30287917a9fa26648))

## [1.55.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.55.0...v1.55.1) (2025-02-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.54.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.53.4...v1.54.0) (2025-01-31)

### 🚀 Features

- add onBlur handler to allow handling of focus lost events | ART-29898 ([ea2bd78](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ea2bd78a5298234d7cabd385d4d2b06fc4c973ca))

### 💥 Bug Fixes

- cast onBlur and pass event as param | ART-29898 ([aca4ec2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/aca4ec245fa2ac3fb9bd62842d53860174a60f1b))
- pass the RHF onBlur and execute it before executing our custom behavior | ART-29898 ([6dd6720](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/6dd6720718aa7e52179c4d1abf7380dc67c142ae))

## [1.53.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.53.3...v1.53.4) (2025-01-31)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.53.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.53.2...v1.53.3) (2025-01-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.53.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.53.1...v1.53.2) (2025-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.53.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.53.0...v1.53.1) (2025-01-29)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.51.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.51.0...v1.51.1) (2025-01-28)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.48.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.48.2...v1.48.3) (2025-01-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.47.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.47.1...v1.47.2) (2025-01-20)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.47.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.46.2...v1.47.0) (2025-01-16)

### 🚀 Features

- mvSearchInputController updation | ART-28182 ([e03ffd7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/e03ffd7e608cf49b852829191c5321aca1b13af1))
- searchInputController | ART-28182 ([3cb1781](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3cb1781b2278565c9ca5a0358b854ede11cdf85d))
- searchInputController update | ART-28182 ([1b80b65](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/1b80b65e00d8fd6d1a00d2001a1e75b60ae7d2b5))

## [1.45.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.45.0...v1.45.1) (2025-01-15)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.34.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.4...v1.34.5) (2024-12-10)

### 💥 Bug Fixes

- correct behaviour of character limit on input and textarea | ART-30903 ([a9562b5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a9562b5160814942924fe102342bde16cf482ebc))

## [1.34.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.34.3...v1.34.4) (2024-12-08)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.30.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.30.2...v1.30.3) (2024-11-25)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.29.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.28.0...v1.29.0) (2024-11-20)

### 🚀 Features

- added xlarge | ART-15475 ([4c21d63](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4c21d6388cb7d743546a35600dde7fa83766d420))
- adding optional prop to mvinputcontroller |ART-15475 ([b9d0610](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b9d0610902f88d8ba527b3c4ced4626769a4b003))

## [1.26.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.25.3...v1.26.0) (2024-11-20)

### 🚀 Features

- update utils currency new update | ART-24649 ([b9ef76d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b9ef76d8b53507830fde23102ae7aef522167633))
- update utils currentcy controller | ART-24649 ([99d58b2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/99d58b2dc7a7b6df8efad9a99f46130b747aadec))

## [1.21.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.21.1...v1.21.2) (2024-11-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.21.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.21.0...v1.21.1) (2024-11-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.17.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.16.0...v1.17.0) (2024-11-04)

### 🚀 Features

- amount and autocomplete components update| ART-24649 ([468ea8d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/468ea8d1a0a781ca5301f586eba605565964e297))
- currency controller update | ART-24649 ([26f04f9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/26f04f91c034c67caca6a9959b9bb7c5677ca230))
- update according to review feedback | ART-24649 ([d1637be](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d1637be774d8d1e034160074dde8800a3fd7148d))
- update ref to mv-tiles | ART-24649 ([8b6714a](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8b6714a965edc022a7702c86e40364d2c51ed5b9))

## [1.12.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.12.5...v1.12.6) (2024-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.12.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.11.0...v1.12.0) (2024-10-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-reacthookform

## [1.11.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.10.0...v1.11.0) (2024-10-23)

### 🚀 Features

- add refresh widget and form controller | ART-24650 ([3c642b6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3c642b6738b45ef17cb7b0ced7b641d9d2cfdcd2))
