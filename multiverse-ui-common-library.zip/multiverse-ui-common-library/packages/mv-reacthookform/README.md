# @mesh-tenant-multiverse-ui-common/mv-reacthookform

## Purpose

This package provides reusable form components built with React and `react-hook-form` for the Mesh Tenant Multiverse UI. These components include input controllers and textarea controllers that handle form validation, character limits, and other common form functionalities.

## Usage

### MVInputController

The `MVInputController` component is used to create controlled input fields with validation and character limit functionalities.

#### Props

- `fieldName`: The name of the field.
- `control`: The control object from `react-hook-form`.
- `errors`: The errors object from `react-hook-form`.
- `id`: The id of the input field.
- `label`: The label for the input field.
- `hintText` (optional): Hint text for the input field.
- `validationRules` (optional): Validation rules for the input field.
- `maximumLength` (optional): Maximum character length for the input field.
- `footerAddon` (optional): Additional content to be displayed in the footer.
- `withFooter` (optional): Flag to indicate if the footer should be displayed.
- `inputType` (optional): Type of input, e.g., 'ASCII printable'.

#### Example

```tsx
import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { MVInputController } from '@mesh-tenant-multiverse-ui-common/components';

function MyForm() {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = data => {
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <MVInputController
        fieldName="username"
        control={control}
        errors={errors}
        id="username"
        label="Username"
        hintText="Enter your username"
        validationRules={{ required: 'Username is required' }}
        maximumLength={20}
        inputType="ASCII printable"
      />
      <button type="submit">Submit</button>
    </form>
  );
}
```

### MVTextareaController

The `MVTextareaController` component is used to create controlled textarea fields with validation and character limit functionalities.

### Props

- `fieldName`: The name of the field.
- `control`: The control object from `react-hook-form`.
- `errors`: The errors object from `react-hook-form`.
- `id`: The id of the input field.
- `label`: The label for the input field.
- `hintText` (optional): Hint text for the input field.
- `validationRules` (optional): Validation rules for the input field.
- `maximumLength` (optional): Maximum character length for the input field.
- `footerAddon` (optional): Additional content to be displayed in the footer.
- `withFooter` (optional): Flag to indicate if the footer should be displayed.
- `inputType` (optional): Type of input, e.g., 'ASCII printable'.

#### Example

```tsx
import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { MVTextareaController } from '@mesh-tenant-multiverse-ui-common/components';

function MyForm() {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = data => {
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <MVTextareaController
        fieldName="description"
        control={control}
        errors={errors}
        id="description"
        label="Description"
        hintText="Enter a description"
        validationRules={{ required: 'Description is required' }}
        maximumLength={200}
        inputType="ASCII printable"
      />
      <button type="submit">Submit</button>
    </form>
  );
}
```

### MVCurrencyController

The `MVCurrencyController` component is used to create controlled input fields with validation and formatting of number of money input.

### Props

- `id` : The id of the input field.
- `fieldName` : The name of the field.
- `control` : The control object from.
- `errors` : The errors object from `react-hook-form`.
- `validationRules?` (optional): Validation rules for the input field.
- `trigger` : UseFormTrigger<T>;
- `disabled?` : boolean to disable input or not;

#### Example

```tsx
import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { MVCurrencyController } from '@mesh-tenant-multiverse-ui-common/components';

function MyForm() {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = data => {
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <MVCurrencyController
        id="totalAmount"
        control={control}
        fieldName="totalAmount"
        errors={errors}
        trigger={trigger}
      />
    </form>
  );
}
```

### MVSelectController

The `MVSelectController` component is used to create controlled select fields.

### Props

- `id` : (Optional)The id of the input field.
- `label` : The label of the InputGroup.
- `fieldName` : The name of the field.
- `control` : The control object from `react-hook-form`.
- `errors` : The errors object from `react-hook-form`.
- `validationRules?` (optional): Validation rules for the select field.
- `options` : Options for select;
- `disabled?` : boolean to disable select or not;

#### Example

```tsx
import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { MVSelectController } from '@mesh-tenant-multiverse-ui-common/components';

function MyForm() {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = data => {
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <MVSelectController
        options=[{id:"string", label:"string", name:"string"}, ...]
        control={control}
        label="Payment Method"
        fieldName="payment Method"
        errors={errors}
        hintText="please select one of the payment methods"
      />
    </form>
  );
}
```

### MVSearchInputController

The `MVSearchInputController` component is used to create controlled search input fields with validation and autocomplete functionalities.

### Props

- `fieldName`: The name of the field.
- `control`: The control object from `react-hook-form`.
- `errors`: The errors object from `react-hook-form`.
- `autoFocus?` (optional): Boolean to auto-focus the input field.
- `placeholder`: The placeholder for the input field.
- `validationRules?` (optional): Validation rules for the input field.
- `listOptions`: Array of options for the autocomplete.
- `renderOption?` (optional): Function to render each option.
- `renderValue?` (optional): Function to render the selected value.
- `noOptionsMessage?` (optional): Message to display when no options are available.
- `defaultInputs?` (optional): Default input values.

#### Example

```tsx
import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { MVSearchInputController } from '@mesh-tenant-multiverse-ui-common/components';

function MyForm() {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = data => {
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <MVSearchInputController
        fieldName="search"
        control={control}
        errors={errors}
        placeholder="Search..."
        validationRules={{ required: 'Search is required' }}
        listOptions={[
          { id: '1', label: 'Option 1' },
          { id: '2', label: 'Option 2' },
        ]}
        renderOption={option => <div>{option.label}</div>}
        renderValue={option => option.label}
        noOptionsMessage="No options available"
      />
      <button type="submit">Submit</button>
    </form>
  );
}
```

# MVButtonGroupController

`MVButtonGroupController` is a React component that integrates the `ButtonGroup` component from `@westpac/ui` with `react-hook-form` to manage form state seamlessly.

### Props

- `fieldName`: The name of the field in the form state.
- `trigger`: The trigger object from `react-hook-form` to help trigger onChange when validation mode is 'blur'.
- `control`: The control object from `react-hook-form`.
- `buttons`: Array of button options, where each option is an object with `value` and `label` properties.
- `validationRules?`: Validation rules for the field (e.g., `required`).
- `id?`: The unique identifier for the button group.
- `label?`: The label for the button group.
- `tooltip?`: Optional tooltip text displayed as a help icon next to the label.
- `className?`: Additional CSS classes for styling.
- `size?`: The size of the button group. Can be `'small'`, `'medium'`, or `'large'`. Defaults to `'small'`.
- `aria-label?`: Accessibility label for the button group.
- `onChange?`: Custom handler triggered when the button group value changes.
- `onBlur?`: Custom handler triggered when the button group loses focus.
- `...rest`: Additional props passed to the `ButtonGroup`.

## Example Usage

```tsx
import React from 'react';
import { useForm } from 'react-hook-form';
import { MVButtonGroupController } from '@mesh-tenant-multiverse-ui-common/components';

function MyForm() {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = data => {
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <MVButtonGroupController
        id="ButtonGroupId"
        label="Button Group Label"
        fieldName="options"
        control={control}
        validationRules={{ required: 'This is a required field' }}
        buttons={[
          { value: 'value1', label: 'label_1' },
          { value: 'value2', label: 'label_2' },
        ]}
        tooltip="Select one of the available options"
        onChange={() => console.log('Value changed')}
        onBlur={() => console.log('Field blurred')}
      />
      <button type="submit">Submit</button>
    </form>
  );
}
```

### MVAmountRangeInputController

The `MVAmountRangeInputController` component is used to create controlled amount range input fields with validation and formatting. It provides two connected input fields for "from" and "to" amounts with automatic validation and error handling.

Note: This component is initially built for use as a filter component and uses validateAmountRange() as the default validation function. However, this component has now been uplifted to accept external validation to be used for other purposes (refer to Treasury page example below).

### Props

- `fieldName`: The name of the field in the form state.
- `control`: The control object from `react-hook-form`.
- `setError`: Function to set errors from `react-hook-form`.
- `clearErrors`: Function to clear errors from `react-hook-form`.
- `hideFromAndToLabels?` (optional): Boolean to hide the "From amount" and "To amount" labels. Defaults to `false` (labels shown).
- `wholeNumbersOnly?` (optional): Boolean to disable decimal input and only allow whole numbers. Defaults to `false` (decimals allowed).
- `globalFromAmountError?` (optional): Boolean to highlight the "from amount" field globally across all amount range components.
- `globalToAmountError?` (optional): Boolean to highlight the "to amount" field globally across all amount range components.
- `setGlobalFromAmountError?` (optional): Function to set global error state for "from amount" fields.
- `setGlobalToAmountError?` (optional): Function to set global error state for "to amount" fields.
- `onBlur?` (optional): Custom validation function called on blur. Should return `{ hasErrors: boolean, errorField?: string, errorMessage?: string }`.

### Features

- **Automatic Range Validation**: Validates that "From amount" is less than "To amount"
- **Currency Formatting**: Displays amounts with proper currency formatting (AUD by default)
- **Auto-fill**: If no external validation is provided and "From amount" is valid and "To amount" is empty, "to amount" is auto-filled with the same value
- **Label Control**: Can hide or display "From amount" and "To amount" labels, shown by default
- **Global Error Highlighting**: Can highlight all amount range components simultaneously for overlapping validation scenarios
- **Decimal Control**: Can be configured to allow only whole numbers (useful for treasury pages)
- **Custom Validation**: Supports external validation functions via the `onBlur` prop

### Example Usage

```tsx
import React from 'react';
import { useForm } from 'react-hook-form';
import { MVAmountRangeInputController } from '@mesh-tenant-multiverse-ui-common/components';

function MyForm() {
  const {
    control,
    handleSubmit,
    setError,
    clearErrors,
    formState: { errors },
  } = useForm();

  const onSubmit = data => {
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <MVAmountRangeInputController
        fieldName="amountRange"
        control={control}
        setError={setError}
        clearErrors={clearErrors}
        wholeNumbersOnly={false} // Allow decimals
        hideFromAndToLabels={false} // Show labels
      />
      <button type="submit">Submit</button>
    </form>
  );
}
```

### Treasury Page Example

```tsx
// Example custom validation function
const validateTreasuryRange = () => {
  // Your custom validation logic here
  const hasErrors = false; // Your validation result
  const errorMessage = ''; // Your error message
  const errorField = 'fromAmount'; // 'fromAmount', 'toAmount', or 'fromAndToAmount'

  return { hasErrors, errorField, errorMessage };
};

// For treasury pages that require whole numbers only
<MVAmountRangeInputController
  fieldName="red.amountRange"
  control={control}
  setError={setError}
  clearErrors={clearErrors}
  wholeNumbersOnly={true} // Only whole numbers
  hideFromAndToLabels={true} // Hide labels for compact view
  globalFromAmountError={globalFromError}
  globalToAmountError={globalToError}
  setGlobalFromAmountError={setGlobalFromError}
  setGlobalToAmountError={setGlobalToError}
  onBlur={() => validateTreasuryRange()} // Custom validation
/>;
```

### Error Field Types

When using custom validation via `onBlur`, the `errorField` can be:

- `'fromAmount'`: Error applies only to the "from amount" field
- `'toAmount'`: Error applies only to the "to amount" field
- `'fromAndToAmount'`: Error applies to both fields
- `'globalFromAndToAmount'`: Error applies to all fields (via global highlighting) if there are multiple component on the same page

### Validation Messages

The component includes built-in validation messages for default validation:

- "Enter an amount zero or greater, up to two decimal places." - For invalid amount format
- "Ensure the 'From amount' is less than the 'To amount'." - For invalid range

```

```
