/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { InputGroupProps } from '@westpac/ui';
import {
  Control,
  Controller,
  FieldValues,
  RegisterOptions,
} from 'react-hook-form';
import { InputGroupWrapper } from './input-group-wrapper/InputGroupWrapper';
import React, {
  FocusEventHandler,
  useEffect,
  useRef,
  HTMLInputTypeAttribute,
} from 'react';

// Utility function to trim text based on configuration
const trimText = (
  text: string,
  trimType: 'leading' | 'trailing' | 'both' = 'both',
  maxLength?: number
): string => {
  let trimmed: string;
  switch (trimType) {
    case 'leading':
      trimmed = text.replace(/^\s+/, '');
      break;
    case 'trailing':
      trimmed = text.replace(/\s+$/, '');
      break;
    case 'both':
    default:
      trimmed = text.trim();
      break;
  }
  return trimmed;
};

export type MVInputControllerProps<T extends FieldValues> = {
  fieldName: string;
  control: Control<T>;
  validationRules?: RegisterOptions;
  id?: string;
  maximumLength?: number;
  inputType?: string;
  type?: HTMLInputTypeAttribute;
  placeholder?: string;
  onBlur?: FocusEventHandler;
  onChange?: (value: string) => void;
  hideCounterText?: boolean;
  multiLines?: boolean;
  matchPattern?: RegExp;
  dialCode?: string;
  trimOnPaste?: boolean;
  trimOnBlur?: boolean;
  trimType?: 'leading' | 'trailing' | 'both';
} & InputGroupProps;

export function MVInputController<T extends FieldValues>({
  fieldName,
  control,
  validationRules,
  onBlur,
  onChange,
  size = 'small',
  trimOnPaste = false,
  trimOnBlur = false,
  trimType = 'both',
  id,
  maximumLength,
  ...restProps
}: MVInputControllerProps<T>) {
  const onCustomBlur = onBlur;
  const onCustomChange = onChange;
  const inputId = id || fieldName;

  // Store references to React Hook Form's onChange and onBlur handlers
  const rhfHandlersRef = useRef<{
    onChange: (value: string) => void;
    onBlur: () => void;
  } | null>(null);

  // Use useEffect to attach event listeners for trimming functionality
  useEffect(() => {
    if (!trimOnPaste && !trimOnBlur) return;

    const findAndAttachToInput = () => {
      // Try multiple selectors to find the input
      const selectors = [
        `#${inputId}`,
        `input[name="${fieldName}"]`,
        `textarea[name="${fieldName}"]`,
      ];

      let inputElement: HTMLInputElement | HTMLTextAreaElement | null = null;
      selectors.some(selector => {
        inputElement = document.querySelector(selector);
        return !!inputElement;
      });

      if (!inputElement) return null;

      const attachEventListeners = (
        element: HTMLInputElement | HTMLTextAreaElement
      ) => {
        const cap = (s: string) =>
          typeof maximumLength === 'number' ? s.slice(0, maximumLength) : s;

        const handlePaste = (event: ClipboardEvent) => {
          if (!trimOnPaste || !rhfHandlersRef.current) return;
          event.preventDefault();

          const target = event.target as HTMLInputElement | HTMLTextAreaElement;
          const paste = event.clipboardData?.getData('text') ?? '';
          const trimmedPaste = trimText(paste, trimType /* no max here */);

          const { value, selectionStart = 0, selectionEnd = 0 } = target;
          const combined =
            value.slice(0, selectionStart) +
            trimmedPaste +
            value.slice(selectionEnd);
          const next = cap(combined); // <-- clamp the final string

          rhfHandlersRef.current.onChange(next);

          // put the caret after inserted text, but don't exceed final length
          requestAnimationFrame(() => {
            const pos = Math.min(
              next.length,
              selectionStart + trimmedPaste.length
            );
            target.selectionStart = target.selectionEnd = pos;
          });
        };

        const handleBlur = (event: FocusEvent) => {
          if (!trimOnBlur || !rhfHandlersRef.current) return;

          const target = event.target as HTMLInputElement | HTMLTextAreaElement;
          const currentValue = target.value;
          const trimmedValue = trimText(currentValue, trimType);
          const next = cap(trimmedValue); // <-- clamp the final trimmed string

          if (next !== currentValue) {
            // Update React Hook Form's state directly
            rhfHandlersRef.current.onChange(next);
          }
        };

        if (trimOnPaste) {
          element.addEventListener('paste', handlePaste);
        }

        if (trimOnBlur) {
          element.addEventListener('blur', handleBlur);
        }

        return () => {
          if (trimOnPaste) {
            element.removeEventListener('paste', handlePaste);
          }
          if (trimOnBlur) {
            element.removeEventListener('blur', handleBlur);
          }
        };
      };

      return attachEventListeners(inputElement);
    };

    // Try immediately, then use MutationObserver if needed
    let cleanup = findAndAttachToInput();

    if (!cleanup) {
      const observer = new MutationObserver(() => {
        if (!cleanup) {
          cleanup = findAndAttachToInput();
          if (cleanup) {
            observer.disconnect();
          }
        }
      });

      observer.observe(document.body, { childList: true, subtree: true });

      return () => {
        observer.disconnect();
        cleanup?.();
      };
    }

    return cleanup;
  }, [fieldName, inputId, trimOnPaste, trimOnBlur, trimType, maximumLength]);

  return (
    <Controller
      name={fieldName}
      control={control as Control<FieldValues>}
      rules={validationRules}
      render={({
        field: { onChange, value, onBlur, ...restField },
        fieldState: { error },
      }) => {
        // Store React Hook Form handlers for use in event listeners
        rhfHandlersRef.current = {
          onChange: (newValue: string) => onChange(newValue),
          onBlur: () => onBlur(),
        };

        return (
          <InputGroupWrapper
            {...restProps}
            id={inputId}
            fieldValue={value}
            restField={restField}
            className={`whitespace-pre-wrap ${restProps.className}`}
            onBlur={e => {
              onBlur();
              onCustomBlur?.(e);
            }}
            onChange={e => {
              onChange(e);
              onCustomChange?.(e);
            }}
            errorMessage={error?.message ?? ''}
            size={size}
            maximumLength={maximumLength}
          />
        );
      }}
    />
  );
}
