import { Input, InputGroup, InputGroupProps } from '@westpac/ui';
import React, {
  ClipboardEvent,
  CompositionEvent,
  SyntheticEvent,
  useRef,
  useState,
} from 'react';
import {
  Control,
  Controller,
  FieldErrors,
  FieldValues,
  Path,
  RegisterOptions,
  UseFormTrigger,
} from 'react-hook-form';

import { formatCurrencyString, mergeRefs } from '../../mv-utils/src';

export type MVCurrencyControllerProps<T extends FieldValues> = {
  id: string;
  fieldName: Path<T>;
  control: Control<FieldValues>;
  errors: FieldErrors<T>;
  validationRules?: RegisterOptions;
  trigger: UseFormTrigger<T>;
  disabled?: boolean;
  label?: string;
  removeMargin?: boolean;
} & InputGroupProps;

const invalidValueMessage =
  'Enter an amount greater than 0, up to two decimal places.';

const validateCurrencyNumber = (value: string) => {
  const num = Number(value);
  const isNaN = Number.isNaN(num);
  if (isNaN || !value) return invalidValueMessage;
  const digitsAfterDecimal = value.split('.')[1]?.length;
  if (digitsAfterDecimal > 2 || num <= 0) return invalidValueMessage;
  return true;
};

const rules = {
  required: invalidValueMessage,
  validate: validateCurrencyNumber,
};

const numberFormatRegex = /^\d*(\.\d*)?$/;

const sanitizeValue = (value: string) => {
  // Strip non-digit characters except for decimal point
  const cleanedValue = value.replace(/[^\d.]/g, '');

  // Ensure only one decimal point is allowed
  const parts = cleanedValue.split('.');
  if (parts.length > 2) {
    return `${parts[0]}.${parts.slice(1).join('')}`;
  }
  return cleanedValue;
};

function MVCurrencyController<T extends FieldValues>({
  id,
  fieldName,
  control,
  errors,
  trigger,
  validationRules = rules,
  disabled,
  label = 'Amount',
  removeMargin = false,
  ...restProps
}: MVCurrencyControllerProps<T>) {
  const [isComposing, setIsComposing] = useState(false);
  const [isFocus, setIsFocus] = useState(false);
  const latestValidValue = useRef('');
  const inputRef = useRef<HTMLInputElement>();

  const handleCompositionStart = () => setIsComposing(true);
  const updatedRules = {
    ...rules,
    ...validationRules,
  };

  const handleCompositionEnd = (
    event: CompositionEvent<HTMLInputElement>,
    onChange: (value: string) => void
  ) => {
    const {
      value: currentValue,
      selectionStart,
      selectionEnd,
    } = event.currentTarget;
    setIsComposing(false);

    // First sanitize the value to remove unwanted characters
    const sanitizedValue = sanitizeValue(currentValue);

    if (numberFormatRegex.test(sanitizedValue)) {
      latestValidValue.current = sanitizedValue;
      onChange(sanitizedValue);

      // If sanitization changed the value, update the input and cursor position
      if (sanitizedValue !== currentValue) {
        requestAnimationFrame(() => {
          if (
            inputRef.current &&
            selectionStart !== null &&
            selectionEnd !== null
          ) {
            const lengthDiff = currentValue.length - sanitizedValue.length;
            inputRef.current.selectionStart = Math.max(
              0,
              selectionStart - lengthDiff
            );
            inputRef.current.selectionEnd = Math.max(
              0,
              selectionEnd - lengthDiff
            );
          }
        });
      }
    } else {
      onChange(latestValidValue.current);
      requestAnimationFrame(() => {
        if (
          inputRef.current &&
          selectionStart !== null &&
          selectionEnd !== null
        ) {
          inputRef.current.selectionStart =
            selectionStart -
            (currentValue.length - latestValidValue.current.length);
          inputRef.current.selectionEnd =
            selectionEnd -
            (currentValue.length - latestValidValue.current.length);
        }
      });
    }
  };

  const errorMessage = (errors[fieldName]?.message as string) ?? '';
  const invalid = Boolean(errors[fieldName]?.message);

  const handleOnChange = (
    event: SyntheticEvent<HTMLInputElement>,
    onChange: (value: string) => void
  ) => {
    const {
      value: currentValue,
      selectionStart,
      selectionEnd,
    } = event.currentTarget;

    if (!isComposing) {
      // First sanitize the value to remove unwanted characters
      const sanitizedValue = sanitizeValue(currentValue);

      if (numberFormatRegex.test(sanitizedValue)) {
        latestValidValue.current = sanitizedValue;
        onChange(sanitizedValue);

        // If sanitization changed the value, update the input
        if (sanitizedValue !== currentValue) {
          requestAnimationFrame(() => {
            if (inputRef.current) {
              inputRef.current.value = sanitizedValue;
              // Adjust cursor position based on the difference in length
              const lengthDiff = currentValue.length - sanitizedValue.length;
              const newStart = Math.max(0, (selectionStart || 0) - lengthDiff);
              const newEnd = Math.max(0, (selectionEnd || 0) - lengthDiff);
              inputRef.current.selectionStart = newStart;
              inputRef.current.selectionEnd = newEnd;
            }
          });
        }
      } else {
        // Only fall back to latestValidValue if it's actually valid
        if (
          latestValidValue.current &&
          numberFormatRegex.test(latestValidValue.current)
        ) {
          onChange(latestValidValue.current);
          requestAnimationFrame(() => {
            if (
              inputRef.current &&
              selectionStart !== null &&
              selectionEnd !== null
            ) {
              inputRef.current.selectionStart =
                selectionStart -
                (currentValue.length - latestValidValue.current.length);
              inputRef.current.selectionEnd =
                selectionEnd -
                (currentValue.length - latestValidValue.current.length);
            }
          });
        } else {
          // If no valid fallback, set empty string
          onChange('');
        }
      }
    }
  };

  const handleOnFocus = () => setIsFocus(true);

  const handleOnBlur = () => {
    setIsFocus(false);
    // With mode onBlur, any action that causes losing focus on field, like clicking on Submit button, will trigger the validation on the form. At that time, all fields are valid, therefore, the previous error message will disappear and shift the position of Submit button. The event onClick is targeting on old position of Submit button but now that position has no button, that's why we need to click the submit button twice!
    // So I added setTimeout here to trigger the onBlur validation manually, ensuring the handleSubmit can be triggered before the UI shift.
    setTimeout(() => trigger(fieldName), 150);
  };

  const getClassName = () => {
    const classes = [];

    if (!label) {
      classes.push('[&_legend]:!mb-0');
    }

    if (removeMargin) {
      classes.push('[&_fieldset]:!mb-0');
    }

    return classes.length > 0 ? classes.join(' ') : undefined;
  };

  const handlePaste = (
    event: ClipboardEvent<HTMLInputElement>,
    onChange: (value: string) => void
  ) => {
    event.preventDefault();

    const clipboardData = event.clipboardData?.getData('text') || '';
    const sanitizedClipboard = sanitizeValue(clipboardData);

    const target = event.currentTarget;
    const currentValue = target.value;
    const selectionStart = target.selectionStart || 0;
    const selectionEnd = target.selectionEnd || 0;

    // Calculate new value with sanitized paste data
    const beforeSelection = currentValue.substring(0, selectionStart);
    const afterSelection = currentValue.substring(selectionEnd);
    const newValue = beforeSelection + sanitizedClipboard + afterSelection;

    // Validate the new value
    if (numberFormatRegex.test(newValue)) {
      latestValidValue.current = newValue;
      onChange(newValue);

      // Set cursor position after pasted content
      const newCursorPosition = selectionStart + sanitizedClipboard.length;
      requestAnimationFrame(() => {
        if (target) {
          target.setSelectionRange(newCursorPosition, newCursorPosition);
        }
      });
    } else {
      // If new value would be invalid, just paste the sanitized clipboard at current position
      // but only if it results in a valid number
      if (numberFormatRegex.test(sanitizedClipboard) && sanitizedClipboard) {
        onChange(sanitizedClipboard);
        latestValidValue.current = sanitizedClipboard;

        requestAnimationFrame(() => {
          if (target) {
            target.setSelectionRange(
              sanitizedClipboard.length,
              sanitizedClipboard.length
            );
          }
        });
      }
      // If sanitized clipboard is also invalid, do nothing (paste is prevented)
    }
  };

  return (
    <Controller
      name={fieldName}
      control={control}
      rules={updatedRules}
      render={({ field: { ref, value, onChange, ...rest } }) => (
        <div>
          <div className={getClassName()}>
            <InputGroup
              label={label}
              tag="fieldset"
              errorMessage={errorMessage}
              size="small"
              before="AUD"
              width={10}
              instanceId={id}
              {...restProps}
            >
              <Input
                {...rest}
                disabled={disabled}
                className="focus:outline-2 focus:outline-data-d-tint focus:outline-offset-3"
                invalid={invalid}
                ref={mergeRefs([inputRef, ref])}
                onBlur={handleOnBlur}
                value={isFocus ? value : formatCurrencyString(value)}
                onChange={(event: SyntheticEvent<HTMLInputElement>) =>
                  handleOnChange(event, onChange)
                }
                onFocus={handleOnFocus}
                onCompositionStart={handleCompositionStart}
                onCompositionEnd={(event: CompositionEvent<HTMLInputElement>) =>
                  handleCompositionEnd(event, (value: string) =>
                    onChange(value)
                  )
                }
                onPaste={(event: ClipboardEvent<HTMLInputElement>) =>
                  handlePaste(event, onChange)
                }
              />
            </InputGroup>
          </div>
        </div>
      )}
    />
  );
}

export default MVCurrencyController;
