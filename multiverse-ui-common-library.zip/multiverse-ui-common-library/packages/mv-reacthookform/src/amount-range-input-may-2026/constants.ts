export type AmountRange = {
  fromAmount: string;
  toAmount: string;
};
