import React from 'react';
import { InputGroup } from '@westpac/ui';
import {
  FieldValues,
  Path,
  UseFormClearErrors,
  UseFormSetError,
} from 'react-hook-form';
import FromToAmount from './components/FromToAmount';
import { AmountRange } from './constants';
import { CURRENCY_CODE_TYPE } from '@mesh-tenant-multiverse-ui-common/mv-constants';

export type AmountRangeInputProps<T extends FieldValues> = {
  value: AmountRange;
  onChange: (value: AmountRange) => void;
  fieldName: Path<T>;
  setError: UseFormSetError<T>;
  clearErrors: UseFormClearErrors<T>;
  errorMessage: string;
  currencyCode: CURRENCY_CODE_TYPE;
};

export function AmountRangeInput<T extends FieldValues>(
  props: AmountRangeInputProps<T>
) {
  return (
    <div className="flex flex-col items-start">
      <div className="flex flex-row">
        <InputGroup label="From amount" className="w-[200px] mb-0" />

        <div className="w-[40px]"></div>

        <InputGroup label="To amount" className="w-[200px] mb-0" />
      </div>

      {!!props.errorMessage && (
        <InputGroup errorMessage={props.errorMessage} className="mb-0" />
      )}

      <FromToAmount {...props} />
    </div>
  );
}
