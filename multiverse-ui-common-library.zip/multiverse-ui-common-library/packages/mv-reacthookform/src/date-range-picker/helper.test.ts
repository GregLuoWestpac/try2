import { DateTime } from 'luxon';
import { SYDNEY_ZONE } from '@mesh-tenant-multiverse-ui-common/mv-constants/src';
import {
  getToday,
  getYesterday,
  getTodayAtLastYear,
  getTodayAtXYearsAgo,
  getTodayAtXMonthsAgo,
  isDateRangeInvalid,
  isDateDurationInvalid,
  isDateAfterToday,
  isDateBeforeXYears,
  isDateBeforeXMonths,
  convertStringToDateTime,
  convertStringToDate,
  formatDateString,
  setControllerError,
  disableEnterKeyDown,
} from './helper';

// Mock the mv-utils module
jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  getFormattedDate: jest.fn((dateValue: string) => {
    // Simple mock implementation
    const date = new Date(dateValue);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  }),
}));

describe('Testing date time helper', () => {
  beforeEach(() => {
    jest.useFakeTimers();
    jest.setSystemTime(new Date('2023-06-15T12:00:00.000Z'));
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  describe('getToday', () => {
    it('should return today at midnight Sydney time', () => {
      const today = getToday();
      expect(today.zoneName).toBe(SYDNEY_ZONE);
      expect(today.hour).toBe(0);
      expect(today.minute).toBe(0);
      expect(today.second).toBe(0);
      expect(today.millisecond).toBe(0);
    });
  });

  describe('getYesterday', () => {
    it('should return yesterday at midnight Sydney time', () => {
      const yesterday = getYesterday();
      const today = getToday();
      expect(yesterday.toISODate()).toBe(today.minus({ days: 1 }).toISODate());
    });
  });

  describe('getTodayAtLastYear', () => {
    it('should return the same date one year ago', () => {
      const lastYear = getTodayAtLastYear();
      const today = getToday();
      expect(lastYear.year).toBe(today.year - 1);
      expect(lastYear.month).toBe(today.month);
      expect(lastYear.day).toBe(today.day);
    });
  });

  describe('getTodayAtXYearsAgo', () => {
    it('should return the same date X years ago', () => {
      const yearsAgo = 5;
      const result = getTodayAtXYearsAgo(yearsAgo);
      const today = getToday();
      expect(result.year).toBe(today.year - yearsAgo);
    });

    it('should handle 0 years correctly', () => {
      const result = getTodayAtXYearsAgo(0);
      const today = getToday();
      expect(result.toISODate()).toBe(today.toISODate());
    });
  });

  describe('getTodayAtXMonthsAgo', () => {
    it('should return the same date X months ago', () => {
      const monthsAgo = 3;
      const result = getTodayAtXMonthsAgo(monthsAgo);
      const today = getToday();
      const expected = today.minus({ months: monthsAgo });
      expect(result.toISODate()).toBe(expected.toISODate());
    });

    it('should handle 0 months correctly', () => {
      const result = getTodayAtXMonthsAgo(0);
      const today = getToday();
      expect(result.toISODate()).toBe(today.toISODate());
    });
  });

  describe('isDateRangeInvalid', () => {
    it('should return true when start date is after end date', () => {
      const startDate = DateTime.fromISO('2023-06-15', { zone: SYDNEY_ZONE });
      const endDate = DateTime.fromISO('2023-06-10', { zone: SYDNEY_ZONE });
      expect(isDateRangeInvalid(startDate, endDate)).toBe(true);
    });

    it('should return false when start date is before end date', () => {
      const startDate = DateTime.fromISO('2023-06-10', { zone: SYDNEY_ZONE });
      const endDate = DateTime.fromISO('2023-06-15', { zone: SYDNEY_ZONE });
      expect(isDateRangeInvalid(startDate, endDate)).toBe(false);
    });

    it('should return false when start date equals end date', () => {
      const startDate = DateTime.fromISO('2023-06-15', { zone: SYDNEY_ZONE });
      const endDate = DateTime.fromISO('2023-06-15', { zone: SYDNEY_ZONE });
      expect(isDateRangeInvalid(startDate, endDate)).toBe(false);
    });

    it('should ignore time components when comparing dates', () => {
      const startDate = DateTime.fromISO('2023-06-15T23:59:59', {
        zone: SYDNEY_ZONE,
      });
      const endDate = DateTime.fromISO('2023-06-15T00:00:00', {
        zone: SYDNEY_ZONE,
      });
      expect(isDateRangeInvalid(startDate, endDate)).toBe(false);
    });
  });

  describe('isDateDurationInvalid', () => {
    describe('with durationInDays', () => {
      it('should return true when duration exceeds allowed days', () => {
        const startDate = DateTime.fromISO('2023-06-01', { zone: SYDNEY_ZONE });
        const endDate = DateTime.fromISO('2023-06-11', { zone: SYDNEY_ZONE });
        const result = isDateDurationInvalid({
          startDate,
          endDate,
          durationInDays: 9,
        });
        expect(result).toBe(true);
      });

      it('should return false when duration is within allowed days', () => {
        const startDate = DateTime.fromISO('2023-06-01', { zone: SYDNEY_ZONE });
        const endDate = DateTime.fromISO('2023-06-06', { zone: SYDNEY_ZONE });
        const result = isDateDurationInvalid({
          startDate,
          endDate,
          durationInDays: 10,
        });
        expect(result).toBe(false);
      });

      it('should return false when duration equals allowed days', () => {
        const startDate = DateTime.fromISO('2023-06-01', { zone: SYDNEY_ZONE });
        const endDate = DateTime.fromISO('2023-06-11', { zone: SYDNEY_ZONE });
        const result = isDateDurationInvalid({
          startDate,
          endDate,
          durationInDays: 10,
        });
        expect(result).toBe(false);
      });
    });

    describe('with durationInMonths', () => {
      it('should return true when duration exceeds allowed months', () => {
        const startDate = DateTime.fromISO('2023-01-01', { zone: SYDNEY_ZONE });
        const endDate = DateTime.fromISO('2023-07-01', { zone: SYDNEY_ZONE });
        const result = isDateDurationInvalid({
          startDate,
          endDate,
          durationInMonths: 5,
        });
        expect(result).toBe(true);
      });

      it('should return false when duration is within allowed months', () => {
        const startDate = DateTime.fromISO('2023-01-01', { zone: SYDNEY_ZONE });
        const endDate = DateTime.fromISO('2023-04-01', { zone: SYDNEY_ZONE });
        const result = isDateDurationInvalid({
          startDate,
          endDate,
          durationInMonths: 6,
        });
        expect(result).toBe(false);
      });

      it('should return false when duration equals allowed months', () => {
        const startDate = DateTime.fromISO('2023-01-01', { zone: SYDNEY_ZONE });
        const endDate = DateTime.fromISO('2023-07-01', { zone: SYDNEY_ZONE });
        const result = isDateDurationInvalid({
          startDate,
          endDate,
          durationInMonths: 6,
        });
        expect(result).toBe(false);
      });
    });

    describe('with no duration specified', () => {
      it('should return false when no duration is provided', () => {
        const startDate = DateTime.fromISO('2023-01-01', { zone: SYDNEY_ZONE });
        const endDate = DateTime.fromISO('2023-12-31', { zone: SYDNEY_ZONE });
        const result = isDateDurationInvalid({ startDate, endDate });
        expect(result).toBe(false);
      });
    });
  });

  describe('isDateAfterToday', () => {
    it('should return true when date is after today', () => {
      const futureDate = DateTime.fromISO('2023-06-16', { zone: SYDNEY_ZONE });
      expect(isDateAfterToday(futureDate)).toBe(true);
    });

    it('should return false when date is today', () => {
      const today = DateTime.fromISO('2023-06-15', { zone: SYDNEY_ZONE });
      expect(isDateAfterToday(today)).toBe(false);
    });

    it('should return false when date is in the past', () => {
      const pastDate = DateTime.fromISO('2023-06-14', { zone: SYDNEY_ZONE });
      expect(isDateAfterToday(pastDate)).toBe(false);
    });

    it('should handle time within today correctly', () => {
      const todayLate = DateTime.fromISO('2023-06-15T23:59:00', {
        zone: SYDNEY_ZONE,
      });
      expect(isDateAfterToday(todayLate)).toBe(false);
    });
  });

  describe('isDateBeforeXYears', () => {
    it('should return true when date is before X years ago', () => {
      const oldDate = DateTime.fromISO('2017-01-01', { zone: SYDNEY_ZONE });
      expect(isDateBeforeXYears(oldDate, 5)).toBe(true);
    });

    it('should return false when date is after X years ago', () => {
      const recentDate = DateTime.fromISO('2022-06-15', { zone: SYDNEY_ZONE });
      expect(isDateBeforeXYears(recentDate, 5)).toBe(false);
    });

    it('should handle edge case around the boundary', () => {
      const boundaryDate = getTodayAtXYearsAgo(5);
      expect(isDateBeforeXYears(boundaryDate, 5)).toBe(false);
      expect(isDateBeforeXYears(boundaryDate.minus({ days: 1 }), 5)).toBe(true);
    });
  });

  describe('isDateBeforeXMonths', () => {
    it('should return true when date is before X months ago', () => {
      const oldDate = DateTime.fromISO('2022-11-01', { zone: SYDNEY_ZONE });
      expect(isDateBeforeXMonths(oldDate, 6)).toBe(true);
    });

    it('should return false when date is after X months ago', () => {
      const recentDate = DateTime.fromISO('2023-05-01', { zone: SYDNEY_ZONE });
      expect(isDateBeforeXMonths(recentDate, 6)).toBe(false);
    });

    it('should handle edge case around the boundary', () => {
      const boundaryDate = getTodayAtXMonthsAgo(3);
      expect(isDateBeforeXMonths(boundaryDate, 3)).toBe(false);
      expect(isDateBeforeXMonths(boundaryDate.minus({ days: 1 }), 3)).toBe(
        true
      );
    });
  });

  describe('convertStringToDateTime', () => {
    it('should convert a valid date string to DateTime', () => {
      const dateString = '15/06/2023';
      const result = convertStringToDateTime(dateString);
      expect(result.day).toBe(15);
      expect(result.month).toBe(6);
      expect(result.year).toBe(2023);
      expect(result.zoneName).toBe(SYDNEY_ZONE);
    });

    it('should handle single digit day and month', () => {
      const dateString = '5/1/2023';
      const result = convertStringToDateTime(dateString);
      expect(result.day).toBe(5);
      expect(result.month).toBe(1);
      expect(result.year).toBe(2023);
    });
  });

  describe('convertStringToDate', () => {
    it('should convert a valid date string to Date object', () => {
      const dateString = '15/06/2023';
      const result = convertStringToDate(dateString);
      expect(result.getDate()).toBe(15);
      expect(result.getMonth()).toBe(5); // Month is 0-indexed
      expect(result.getFullYear()).toBe(2023);
    });

    it('should handle single digit day and month', () => {
      const dateString = '5/1/2023';
      const result = convertStringToDate(dateString);
      expect(result.getDate()).toBe(5);
      expect(result.getMonth()).toBe(0); // Month is 0-indexed
      expect(result.getFullYear()).toBe(2023);
    });
  });

  describe('formatDateString', () => {
    it('should format a date string correctly', () => {
      const dateString = '15/06/2023';
      const result = formatDateString(dateString);
      expect(result).toBeDefined();
      expect(typeof result).toBe('string');
    });
  });

  describe('setControllerError', () => {
    it('should call setError when message is provided', () => {
      const setError = jest.fn();
      const clearErrors = jest.fn();
      const fieldName = 'testField';
      const message = 'Error message';

      setControllerError(fieldName, setError, clearErrors, message);

      expect(setError).toHaveBeenCalledWith(fieldName, {
        type: 'invalid',
        message,
      });
      expect(clearErrors).not.toHaveBeenCalled();
    });

    it('should call clearErrors when message is not provided', () => {
      const setError = jest.fn();
      const clearErrors = jest.fn();
      const fieldName = 'testField';

      setControllerError(fieldName, setError, clearErrors);

      expect(clearErrors).toHaveBeenCalledWith(fieldName);
      expect(setError).not.toHaveBeenCalled();
    });

    it('should call clearErrors when message is empty string', () => {
      const setError = jest.fn();
      const clearErrors = jest.fn();
      const fieldName = 'testField';

      setControllerError(fieldName, setError, clearErrors, '');

      expect(clearErrors).toHaveBeenCalledWith(fieldName);
      expect(setError).not.toHaveBeenCalled();
    });
  });

  describe('disableEnterKeyDown', () => {
    it('should prevent default when Enter key is pressed', () => {
      const event = {
        key: 'Enter',
        preventDefault: jest.fn(),
      } as unknown as KeyboardEvent;

      disableEnterKeyDown(event);

      expect(event.preventDefault).toHaveBeenCalled();
    });

    it('should not prevent default when other keys are pressed', () => {
      const event = {
        key: 'Space',
        preventDefault: jest.fn(),
      } as unknown as KeyboardEvent;

      disableEnterKeyDown(event);

      expect(event.preventDefault).not.toHaveBeenCalled();
    });

    it('should not prevent default when Tab key is pressed', () => {
      const event = {
        key: 'Tab',
        preventDefault: jest.fn(),
      } as unknown as KeyboardEvent;

      disableEnterKeyDown(event);

      expect(event.preventDefault).not.toHaveBeenCalled();
    });
  });
});
