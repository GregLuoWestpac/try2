import React from 'react';
import { useEffect, useState } from 'react';
import {
  FieldValues,
  Path,
  UseFormClearErrors,
  UseFormSetError,
} from 'react-hook-form';
import {
  DATE_FORMAT_REGEX_DDMMYYYY,
  DATE_RANGE_PICKER_ERROR,
  DateRange,
} from '../constants';
import {
  convertStringToDateTime,
  disableEnterKeyDown,
  formatDateString,
  isDateAfterToday,
  isDateBeforeXMonths,
  isDateBeforeXYears,
  isDateDurationInvalid,
  isDateRangeInvalid,
  setControllerError,
} from '../helper';
import { DatePickerWrapper } from './date-picker-wrapper/DatePickerWrapper';

type StartEndDateProps<T extends FieldValues> = {
  value: DateRange;
  onChange: (val: DateRange) => void;
  fieldName: Path<T>;
  setError: UseFormSetError<T>;
  clearErrors: UseFormClearErrors<T>;
  errorMessage: string;
  durationInDays?: number;
  durationInMonths?: number;
  durationInvalidMessage?: string;
  earliestYear?: number;
  earliestMonth?: number;
  earliestInvalidMessage?: string;
};

export function StartEndDate<T extends FieldValues>({
  value,
  onChange,
  fieldName,
  setError,
  clearErrors,
  durationInDays,
  durationInMonths,
  durationInvalidMessage,
  earliestYear,
  earliestMonth,
  earliestInvalidMessage,
}: StartEndDateProps<T>) {
  const [startDateHasError, setStartDateHasError] = useState(false);
  const [endDateHasError, setEndDateHasError] = useState(false);
  const [hasClosed, setHasClosed] = useState(false);

  useEffect(() => {
    // use requestAnimationFrame to format date until right before the next screen repaint. This is to make sure "document.querySelector()" can get elements
    let startDatePickerEle: HTMLInputElement,
      endDatePickerEle: HTMLInputElement;
    const id = requestAnimationFrame(() => {
      const { startDatePicker, endDatePicker } = formatDateForUI();
      startDatePickerEle = startDatePicker;
      endDatePickerEle = endDatePicker;
      startDatePickerEle?.addEventListener('keydown', disableEnterKeyDown);
      endDatePickerEle?.addEventListener('keydown', disableEnterKeyDown);
    });
    return () => {
      cancelAnimationFrame(id);
      startDatePickerEle?.removeEventListener('keydown', disableEnterKeyDown);
      endDatePickerEle?.removeEventListener('keydown', disableEnterKeyDown);
    };
  }, []);

  useEffect(() => {
    if (hasClosed) {
      validateDateRange();
      setHasClosed(false);
    }
  }, [hasClosed]);

  function formatDateForUI() {
    const startDatePicker = document.querySelector(
      '#date-picker-wrapper #startDate'
    ) as HTMLInputElement;
    const endDatePicker = document.querySelector(
      '#date-picker-wrapper #endDate'
    ) as HTMLInputElement;

    const startDateValue = startDatePicker?.value;
    const startDateValid =
      !!startDateValue && DATE_FORMAT_REGEX_DDMMYYYY.test(startDateValue);
    if (startDateValid) {
      startDatePicker.value = formatDateString(startDateValue);
    }

    const endDateValue = endDatePicker?.value;
    const endDateValid =
      !!endDateValue && DATE_FORMAT_REGEX_DDMMYYYY.test(endDateValue);
    if (endDateValid) {
      endDatePicker.value = formatDateString(endDateValue);
    }

    return {
      startDateValue,
      endDateValue,
      startDateValid,
      endDateValid,
      startDatePicker,
      endDatePicker,
    };
  }

  function validateDateRange() {
    clearError();

    const { startDateValue, endDateValue, startDateValid, endDateValid } =
      formatDateForUI();

    setStartDateHasError(!startDateValid);
    setEndDateHasError(!endDateValid);

    if (!startDateValid || !endDateValid) {
      putError(DATE_RANGE_PICKER_ERROR.DATE_REQUIRED);
      return;
    }

    const startDate = convertStringToDateTime(startDateValue);
    const endDate = convertStringToDateTime(endDateValue);
    if (isDateAfterToday(startDate) || isDateAfterToday(endDate)) {
      if (isDateAfterToday(startDate)) {
        putErrorForStartDate(DATE_RANGE_PICKER_ERROR.DATE_LATER_THAN_TODAY);
      }
      if (isDateAfterToday(endDate)) {
        putErrorForEndDate(DATE_RANGE_PICKER_ERROR.DATE_LATER_THAN_TODAY);
      }
    } else if (isDateRangeInvalid(startDate, endDate)) {
      putErrorForStartDateEndDate(DATE_RANGE_PICKER_ERROR.DATE_RANGE_INVALID);
    } else if (
      isDateDurationInvalid({
        startDate,
        endDate,
        durationInDays,
        durationInMonths,
      })
    ) {
      putErrorForStartDateEndDate(durationInvalidMessage);
    } else {
      if (earliestYear) {
        if (isDateBeforeXYears(startDate, earliestYear)) {
          putErrorForStartDate(earliestInvalidMessage);
        }
        if (isDateBeforeXYears(endDate, earliestYear)) {
          putErrorForEndDate(earliestInvalidMessage);
        }
      }

      if (earliestMonth) {
        if (isDateBeforeXMonths(startDate, earliestMonth)) {
          putErrorForStartDate(earliestInvalidMessage);
        }
        if (isDateBeforeXMonths(endDate, earliestMonth)) {
          putErrorForEndDate(earliestInvalidMessage);
        }
      }
    }
  }

  function putErrorForStartDate(message?: string) {
    setStartDateHasError(true);
    putError(message);
  }
  function putErrorForEndDate(message?: string) {
    setEndDateHasError(true);
    putError(message);
  }
  function putErrorForStartDateEndDate(message?: string) {
    setStartDateHasError(true);
    setEndDateHasError(true);
    putError(message);
  }
  function putError(message?: string) {
    setControllerError(fieldName, setError, clearErrors, message);
  }
  function clearError() {
    setStartDateHasError(false);
    setEndDateHasError(false);
    putError('');
  }

  return (
    <div className="flex flex-row">
      <DatePickerWrapper
        invalid={startDateHasError}
        id="startDate"
        value={value?.startDate}
        onBlur={validateDateRange}
        onClose={() => setHasClosed(true)}
        onChange={val => {
          onChange({ ...value, startDate: val.detail.value });
        }}
        earliestYear={earliestYear}
        earliestMonth={earliestMonth}
      />

      <img
        src="data:image/svg+xml;charset=utf-8,%0A%20%3Csvg%20width%3D%2216%22%20height%3D%2217%22%20viewBox%3D%220%200%2016%2017%22%20fill%3D%22none%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%0A%3Cpath%20d%3D%22M14.9999%208.48533C15%208.49021%2015%208.4951%2015%208.5C15%208.50516%2015%208.5103%2014.9999%208.51544C15.0039%208.78297%2014.9046%209.05092%2014.7032%209.25214L8.75075%2015.2009C8.35154%2015.5999%207.70523%2015.6008%207.30092%2015.1968C6.89941%2014.7955%206.90136%2014.143%207.29676%2013.7479L11.5473%209.5H2.00685C1.45078%209.5%201%209.05614%201%208.5C1%207.94772%201.44995%207.5%202.00685%207.5H11.5457L7.29906%203.25075C6.90009%202.85154%206.89916%202.20523%207.30321%201.80092C7.70447%201.39941%208.35699%201.40136%208.75214%201.79676L14.7009%207.74925C14.9037%207.95218%2015.0037%208.21895%2014.9999%208.48533Z%22%20fill%3D%22%23545454%22%2F%3E%0A%3C%2Fsvg%3E%0A%0A"
        alt="RightArrow"
        className="mx-2"
      />

      <DatePickerWrapper
        invalid={endDateHasError}
        id="endDate"
        value={value?.endDate}
        onBlur={validateDateRange}
        onClose={() => setHasClosed(true)}
        onChange={val => {
          onChange({ ...value, endDate: val.detail.value });
        }}
        earliestYear={earliestYear}
        earliestMonth={earliestMonth}
      />
    </div>
  );
}
