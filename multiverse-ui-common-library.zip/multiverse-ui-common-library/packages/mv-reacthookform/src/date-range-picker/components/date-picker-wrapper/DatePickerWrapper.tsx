import { DatePicker, DatePickerProps } from '@westpac/ui';
import React from 'react';
import { DATE_FORMAT_YYYYMMDD } from '../../constants';
import {
  getToday,
  getTodayAtXMonthsAgo,
  getTodayAtXYearsAgo,
} from '../../helper';
import './date-picker-wrapper.css';
import { DateTime } from 'luxon';

type Props = {
  earliestYear?: number;
  earliestMonth?: number;
  maxDate?: DateTime;
} & DatePickerProps;

export function DatePickerWrapper({
  earliestYear,
  earliestMonth,
  maxDate,
  ...restProps
}: Props) {
  if (!maxDate) {
    maxDate = getToday();
  }

  let minDate: DateTime= getToday().minus({ years: 100 });;
  if (earliestYear) {
    minDate = getTodayAtXYearsAgo(earliestYear);
  }

  if (earliestMonth) {
    minDate = getTodayAtXMonthsAgo(earliestMonth);
  }

  const dateFormat = 'dd/MM/yyyy';

  return (
    <div id="date-picker-wrapper">
      <DatePicker
        {...restProps}
        min={minDate.toFormat(DATE_FORMAT_YYYYMMDD)}
        max={maxDate.toFormat(DATE_FORMAT_YYYYMMDD)}
        placeholder={dateFormat.toLowerCase()}
        dateFormat={dateFormat}
        size="sm"
      />
    </div>
  );
}
