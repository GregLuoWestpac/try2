export const DATE_FORMAT_REGEX_DDMMYYYY =
  /^([1-9]|0[1-9]|[12][0-9]|3[01])\/([1-9]|0[1-9]|1[012])\/(1|2|3|4)\d{3}$/;
export const DATE_FORMAT_YYYYMMDD = 'yyyy-MM-dd';

export enum DATE_RANGE_PICKER_ERROR {
  DATE_RANGE_INVALID = "Ensure the 'From date' is earlier than the 'To date'.",
  DATE_REQUIRED = "Enter a date in 'dd/mm/yyyy' format.",
  DATE_EARLIER_THAN_7_YEARS = 'Select a date range within the last 7 years.',
  DATE_LATER_THAN_TODAY = 'Select a date up to today.',
  DATE_DURATION_INVALID = 'Select a date range up to 13 months.',
}

export enum DATE_PICKER_ERROR {
  DATE_LATER_THAN_TODAY = 'Enter a past date.',
}

export type DateRange = {
  startDate: string;
  endDate: string;
};
