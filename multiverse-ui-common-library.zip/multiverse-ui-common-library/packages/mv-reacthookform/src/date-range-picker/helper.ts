import { DateTime, Duration } from 'luxon';
import { SYDNEY_ZONE } from '@mesh-tenant-multiverse-ui-common/mv-constants/src';
import {
  FieldValues,
  Path,
  UseFormClearErrors,
  UseFormSetError,
} from 'react-hook-form';
import { getFormattedDate } from '@mesh-tenant-multiverse-ui-common/mv-utils';

export function getToday() {
  return DateTime.now()
    .setZone(SYDNEY_ZONE)
    .set({ hour: 0, minute: 0, second: 0, millisecond: 0 });
}
export function getYesterday() {
  return getToday().minus({ days: 1 });
}

export function getTodayAtLastYear() {
  return getToday().minus({ year: 1 });
}
export function getTodayAtXYearsAgo(earliestYear: number) {
  return getToday().minus({ year: earliestYear });
}
export function getTodayAtXMonthsAgo(earliestMonth: number) {
  return getToday().minus({ month: earliestMonth });
}

export function isDateRangeInvalid(
  startDate: DateTime,
  endDate: DateTime
): boolean {
  return startDate.startOf('day') > endDate.startOf('day');
}

export function isDateDurationInvalid({
  startDate,
  endDate,
  durationInDays = 0,
  durationInMonths = 0,
}: {
  startDate: DateTime;
  endDate: DateTime;
  durationInDays?: number;
  durationInMonths?: number;
}): boolean {
  if (durationInDays) {
    const diffInDays: Duration = endDate.diff(startDate, 'days');
    const duration = diffInDays.toObject();
    return !!duration.days && duration.days > durationInDays;
  }
  if (durationInMonths) {
    const diffInMonths: Duration = endDate.diff(startDate, 'months');
    const duration = diffInMonths.toObject();
    return !!duration.months && duration.months > durationInMonths;
  }
  return false;
}

export function isDateAfterToday(dateTime: DateTime): boolean {
  const today = getToday().set({
    hour: 23,
    minute: 59,
    second: 59,
    millisecond: 999,
  });
  return dateTime > today;
}

export function isDateBeforeXYears(
  dateTime: DateTime,
  earliestYear: number
): boolean {
  return dateTime < getTodayAtXYearsAgo(earliestYear);
}

export function isDateBeforeXMonths(
  dateTime: DateTime,
  earliestMonth: number
): boolean {
  return dateTime < getTodayAtXMonthsAgo(earliestMonth);
}

export function convertStringToDateTime(dateValue: string): DateTime {
  const date = convertStringToDate(dateValue);
  return DateTime.fromJSDate(date, { zone: SYDNEY_ZONE });
}

export function convertStringToDate(dateValue: string): Date {
  const [day, month, year] = dateValue.split('/');
  const date = new Date(+year, +month - 1, +day);
  return date;
}

export function formatDateString(dateValue: string) {
  return getFormattedDate(
    convertStringToDate(dateValue).toISOString(),
    'd/LL/yyyy',
    'date-time'
  );
}

export function setControllerError<T extends FieldValues>(
  fieldName: Path<T>,
  setError: UseFormSetError<T>,
  clearErrors: UseFormClearErrors<T>,
  message?: string
) {
  if (message) {
    setError(fieldName, { type: 'invalid', message });
  } else {
    clearErrors(fieldName);
  }
}

export const disableEnterKeyDown = (event: KeyboardEvent) => {
  if (event.key === 'Enter') {
    event.preventDefault();
  }
};
