import { defineCustomElements } from '@duetds/date-picker/custom-element/index.js';
import { InputGroup } from '@westpac/ui';
import { StartEndDate } from './components/StartEndDate';
import React from 'react';
import { DateRange } from './constants';
import {
  FieldValues,
  Path,
  UseFormClearErrors,
  UseFormSetError,
} from 'react-hook-form';

export type DateRangePickerProps<T extends FieldValues> = {
  value: DateRange;
  onChange: (val: DateRange) => void;
  fieldName: Path<T>;
  setError: UseFormSetError<T>;
  clearErrors: UseFormClearErrors<T>;
  errorMessage: string;
  durationInDays?: number;
  durationInMonths?: number;
  durationInvalidMessage?: string;
  earliestYear?: number;
  earliestMonth?: number;
  earliestInvalidMessage?: string;
};

export function DateRangePicker<T extends FieldValues>(
  props: DateRangePickerProps<T>
) {
  defineCustomElements(window); // This is for fixing the "min and max doesn't work" issue of DatePicker

  return (
    <div className="flex flex-col items-start">
      <div className="flex flex-row">
        <InputGroup label="From date" className="w-[140px] mb-0" />

        <div className="w-[40px]"></div>

        <InputGroup label="To date" className="w-[140px] mb-0" />
      </div>

      {!!props.errorMessage && (
        <InputGroup errorMessage={props.errorMessage} className="mb-0" />
      )}

      <StartEndDate {...props} />
    </div>
  );
}
