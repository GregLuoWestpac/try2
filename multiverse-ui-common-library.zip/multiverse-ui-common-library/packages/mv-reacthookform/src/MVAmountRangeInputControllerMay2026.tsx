import React from 'react';
import {
  Control,
  Controller,
  FieldValues,
  Path,
  UseFormClearErrors,
  UseFormSetError,
  useFormState,
} from 'react-hook-form';
import { AmountRangeInput } from './amount-range-input-may-2026/AmountRangeInput';
import { CURRENCY_CODE_TYPE } from '@mesh-tenant-multiverse-ui-common/mv-constants';

export type MVAmountRangeInputControllerMay2026Props<T extends FieldValues> = {
  control: Control<FieldValues>;
  fieldName: Path<T>;
  currencyCode: CURRENCY_CODE_TYPE;
  setError: UseFormSetError<T>;
  clearErrors: UseFormClearErrors<T>;
};

export default function MVAmountRangeInputControllerMay2026<
  T extends FieldValues,
>({
  control,
  fieldName,
  ...restProps
}: MVAmountRangeInputControllerMay2026Props<T>) {
  const { errors } = useFormState({ control });
  const errorMessage: string = (errors[fieldName]?.message as string) || '';

  return (
    <Controller
      name={fieldName}
      control={control}
      rules={{
        validate: () => errorMessage || true,
      }}
      render={({ field }) => (
        <AmountRangeInput
          {...field}
          {...restProps}
          fieldName={fieldName}
          errorMessage={errorMessage}
        />
      )}
    />
  );
}
