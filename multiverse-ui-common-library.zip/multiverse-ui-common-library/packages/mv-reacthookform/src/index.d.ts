/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  AutocompleteProps,
  InputGroupProps,
  ButtonGroupProps,
  CheckboxGroupProps,
  DatePickerProps,
} from '@westpac/ui';
import { DateTime } from 'luxon';
import React, {
  FocusEventHandler,
  HTMLInputTypeAttribute,
  ReactNode,
} from 'react';
import {
  Control,
  FieldErrors,
  FieldValues,
  Path,
  RegisterOptions,
  UseFormClearErrors,
  UseFormSetError,
  UseFormTrigger,
} from 'react-hook-form';
import { ListOption } from '../../mv-autocomplete';
import { CURRENCY_CODE_TYPE } from '@mesh-tenant-multiverse-ui-common/mv-constants';

export { ListOption } from '../../mv-autocomplete';

export type MVInputControllerProps<T extends FieldValues> = {
  fieldName: string;
  control: Control<T>;
  validationRules?: RegisterOptions;
  id?: string;
  maximumLength?: number;
  inputType?: string;
  type?: HTMLInputTypeAttribute;
  placeholder?: string;
  onBlur?: FocusEventHandler;
  onChange?: (value: string) => void;
  hideCounterText?: boolean;
  multiLines?: boolean;
  matchPattern?: RegExp;
  dialCode?: string;
  trimOnPaste?: boolean;
  trimOnBlur?: boolean;
  trimType?: 'leading' | 'trailing' | 'both';
} & InputGroupProps;

export const MVInputController: <T extends FieldValues>(
  props: MVInputControllerProps<T>
) => React.ReactElement;

export const MVPhoneInputController: <T extends FieldValues>(
  props: Omit<MVInputControllerProps<T>, 'dialCode'>
) => React.ReactElement;

export type MVCurrencyControllerProps<T extends FieldValues> = {
  id: string;
  fieldName: Path<T>;
  control: Control<FieldValues>;
  errors: FieldErrors<T>;
  validationRules?: RegisterOptions;
  trigger: UseFormTrigger<T>;
  disabled?: boolean;
  label?: string;
  removeMargin?: boolean;
} & InputGroupProps;

export const MVCurrencyController: <T extends FieldValues>(
  props: MVCurrencyControllerProps<T>
) => React.ReactElement;

export type MVSelectControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  id?: string;
  label: string;
  validationRules?: RegisterOptions;
  options: Array<{ id: string; label: string; name: string }>;
  disabled?: boolean;
  placeholder?: string;
  size?: 'small' | 'medium' | 'large' | 'xlarge';
  width?: 1 | 2 | 'full' | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 20 | 30;
  hintText?: string;
  supportingText?: React.ReactNode;
  showSpinner?: boolean;
  onChange?: (
    selectedOption: { id: string; label: string; name: string } | undefined
  ) => void;
} & InputGroupProps;

export const MVSelectController: <T extends FieldValues>(
  props: MVSelectControllerProps<T>
) => React.ReactElement;

export type MVSearchInputControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  autoFocus?: boolean;
  placeholder: string;
  validationRules?: RegisterOptions;
  listOptions: ListOption[];
  renderOption?: (option: unknown) => JSX.Element;
  renderValue?: (option: unknown) => string;
  noOptionsMessage?: string;
  defaultInputs?: unknown;
  header: string;
  onValueChange?: (newValue: unknown) => void;
};

export const MVSearchInputController: <T extends FieldValues>(
  props: MVSearchInputControllerProps<T>
) => React.ReactElement;

/**
 * MV Date Picker Definitions Start
 */
export type MVDatePickerControllerProps<T extends FieldValues> = {
  control: Control<T>;
  fieldName: Path<T>;
  setError: UseFormSetError<T>;
  clearErrors: UseFormClearErrors<T>;
  label: string;
  earliestMonth: number;
  maxDate?: DateTime;
} & DatePickerProps;

export const MVDatePickerController: <T extends FieldValues>(
  props: MVDatePickerControllerProps<T>
) => React.ReactElement;
/**
 * MV Date Picker Definitions End
 */

/**
 * MV Date Range Picker
 */
declare const DATE_FORMAT_REGEX_DDMMYYYY: RegExp;
declare const DATE_FORMAT_YYYYMMDD = 'yyyy-MM-dd';

declare enum DATE_RANGE_PICKER_ERROR {
  DATE_RANGE_INVALID = 'Adjust the dates to ensure the "From date" is before the "To date".',
  DATE_REQUIRED = 'Enter a date in the "dd/mm/yyyy" format.',
  DATE_EARLIER_THAN_7_YEARS = 'Select a date range within the last 7 years.',
  DATE_LATER_THAN_TODAY = 'Select a date that is today or earlier.',
  DATE_DURATION_INVALID = 'Select a date range up to 13 months.',
}

export {
  DATE_FORMAT_REGEX_DDMMYYYY,
  DATE_FORMAT_YYYYMMDD,
  DATE_RANGE_PICKER_ERROR,
};

export type DateRange = {
  startDate: string;
  endDate: string;
};

type Props<T extends FieldValues> = {
  control: Control<T>;
  fieldName: Path<T>;
  setError: UseFormSetError<T>;
  clearErrors: UseFormClearErrors<T>;
};

type OnlyDurationInDays = {
  durationInDays: number;
  durationInMonths?: never;
  durationInvalidMessage: string;
};
type OnlyDurationInMonths = {
  durationInDays?: never;
  durationInMonths: number;
  durationInvalidMessage: string;
};
type NeitherDurationInDaysAndMonths = {
  durationInDays?: never;
  durationInMonths?: never;
  durationInvalidMessage?: never;
};

type OnlyEarliestYear = {
  earliestYear: number;
  earliestMonth?: never;
  earliestInvalidMessage: string;
};
type OnlyEarliestMonth = {
  earliestYear?: never;
  earliestMonth: number;
  earliestInvalidMessage: string;
};
type NeitherEarliestYearAndMonth = {
  earliestYear?: never;
  earliestMonth?: never;
  earliestInvalidMessage?: never;
};

export type MVDateRangePickerControllerProps<T extends FieldValues> = (
  | OnlyDurationInDays
  | OnlyDurationInMonths
  | NeitherDurationInDaysAndMonths
) &
  (OnlyEarliestYear | OnlyEarliestMonth | NeitherEarliestYearAndMonth) &
  Props<T>;

export const MVDateRangePickerController: <T extends FieldValues>(
  props: MVDateRangePickerControllerProps<T>
) => React.ReactElement;

export function getToday(): DateTime;
export function getYesterday(): DateTime;
export function getTodayAtLastYear(): DateTime;
export function getTodayAtXYearsAgo(earliestYear: number): DateTime;

export function isDateRangeInvalid(start: string, end: string): boolean;
export function isDateDurationInvalid({
  startDate,
  endDate,
  durationInDays,
  durationInMonths,
}: {
  startDate: string;
  endDate: string;
  durationInDays?: number;
  durationInMonths?: number;
}): boolean;
export function isDateAfterToday(data: string): boolean;
export function isDateBeforeXYears(data: string, earliestYear: number): boolean;
/**
 * MV Date Range Picker Definitions End
 */

/**
 * MV Autocomplete Definitions Start
 */
export type AutocompleteId = { id: string };

export type MVAutocompleteControllerProps<
  T1 extends FieldValues,
  T2 extends AutocompleteId,
> = {
  fieldName: Path<T1>;
  control: Control<T1>;
  validationRules?: RegisterOptions;
  allItems: T2[];
  ItemDetails?: ({ item }: { item: T2 }) => ReactNode;
  AdditionalDetails?: ({ item }: { item: T2 }) => ReactNode;
  keyFn?: (item: T2) => string;
  inputValueFn?: (item: T2) => string;
  maxVisibleItems?: number;
  filterFn?: (item: T2, input: string) => boolean;
  onChange?: (value: T2 | null) => void;
} & {
  ref?: React.Ref<{ clear: () => void }>;
} & Omit<AutocompleteProps<T2>, 'children'>;

export const MVAutocompleteController: <
  T1 extends FieldValues,
  T2 extends AutocompleteId,
>(
  props: MVAutocompleteControllerProps<T1, T2>
) => React.ReactElement;

export type AutocompleteWrapperRef = {
  clear: () => void;
};

export const AutocompleteItemDetailsTemplate: ({
  line1,
  line2,
  line3,
}: {
  line1: React.ReactNode;
  line2?: React.ReactNode;
  line3?: React.ReactNode;
}) => React.ReactElement;
/**
 * MV Autocomplete Definitions End
 */

/**
 * MVButtonGroupController Definitions Start
 */
export type MVButtonGroupControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  trigger: UseFormTrigger<T>;
  control: Control<T>;
  validationRules?: RegisterOptions;
  onChange?: () => void;
  onBlur?: () => void;
  tooltip?: string;
} & ButtonGroupProps;

export const MVButtonGroupController: <T extends FieldValues>(
  props: MVButtonGroupControllerProps<T>
) => React.ReactElement;
/**
 * MVButtonGroupController Definitions End
 */

/**
 * MVAmountRangeInputController Definitions Start
 */

export type AmountRange = {
  fromAmount: string;
  toAmount: string;
};

export type MVAmountRangeInputControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  setError: UseFormSetError<T>;
  clearErrors: UseFormClearErrors<T>;
  globalFromAmountError?: boolean;
  globalToAmountError?: boolean;
  setGlobalFromAmountError?: (hasError: boolean) => void;
  setGlobalToAmountError?: (hasError: boolean) => void;
  hideFromAndToLabels?: boolean;
  wholeNumbersOnly?: boolean;
  onBlur?: () => {
    hasErrors: boolean;
    errorField?: string;
    errorMessage?: string;
  };
  showCurrencySymbol?: boolean;
};

export const MVAmountRangeInputController: <T extends FieldValues>(
  props: MVAmountRangeInputControllerProps<T>
) => React.ReactElement;

export type MVAmountRangeInputControllerMay2026Props<T extends FieldValues> = {
  fieldName: Path<T>;
  control: Control<T>;
  currencyCode: CURRENCY_CODE_TYPE;
  setError: UseFormSetError<T>;
  clearErrors: UseFormClearErrors<T>;
};

export const MVAmountRangeInputControllerMay2026: <T extends FieldValues>(
  props: MVAmountRangeInputControllerMay2026Props<T>
) => React.ReactElement;
/**
 * MVAmountRangeInputController Definitions End
 */

/**
 * MVCheckboxController Definitions Start
 */
export type MVCheckboxControllerProps<T extends FieldValues> = {
  control: Control<T>;
  fieldName: Path<T>;
  label: string;
  className?: string;
} & Omit<CheckboxGroupProps, 'checkboxes'>;

export const MVCheckboxController: <T extends FieldValues>(
  props: MVCheckboxControllerProps<T>
) => React.ReactElement;

/**
 * MVCheckboxController Definitions End
 */
