/* eslint-disable @typescript-eslint/no-unused-vars */
import {
  Control,
  Controller,
  FieldValues,
  Path,
  UseFormClearErrors,
  UseFormSetError,
  useFormState,
} from 'react-hook-form';
import { DateRangePicker } from './date-range-picker/DateRangePicker';
import React from 'react';
import { DATE_RANGE_PICKER_ERROR } from './date-range-picker/constants';

type Props<T extends FieldValues> = {
  control: Control<T>;
  fieldName: Path<T>;
  setError: UseFormSetError<T>;
  clearErrors: UseFormClearErrors<T>;
};

type OnlyDurationInDays = {
  durationInDays: number;
  durationInMonths?: never;
  durationInvalidMessage: string;
};
type OnlyDurationInMonths = {
  durationInDays?: never;
  durationInMonths: number;
  durationInvalidMessage: string;
};
type NeitherDurationInDaysAndMonths = {
  durationInDays?: never;
  durationInMonths?: never;
  durationInvalidMessage?: never;
};

type OnlyEarliestYear = {
  earliestYear: number;
  earliestMonth?: never;
  earliestInvalidMessage: string;
};
type OnlyEarliestMonth = {
  earliestYear?: never;
  earliestMonth: number;
  earliestInvalidMessage: string;
};
type NeitherEarliestYearAndMonth = {
  earliestYear?: never;
  earliestMonth?: never;
  earliestInvalidMessage?: never;
};

export type MVDateRangePickerControllerProps<T extends FieldValues> = (
  | OnlyDurationInDays
  | OnlyDurationInMonths
  | NeitherDurationInDaysAndMonths
) &
  (OnlyEarliestYear | OnlyEarliestMonth | NeitherEarliestYearAndMonth) &
  Props<T>;

export default function MVDateRangePickerController<T extends FieldValues>({
  control,
  fieldName,
  durationInMonths,
  durationInDays,
  durationInvalidMessage,
  earliestYear,
  earliestMonth,
  earliestInvalidMessage,
  ...restProps
}: MVDateRangePickerControllerProps<T>) {
  const { errors } = useFormState({ control });
  const errorMessage: string = (errors[fieldName]?.message as string) || '';

  if (!durationInMonths && !durationInDays) {
    durationInMonths = 13;
    durationInvalidMessage = DATE_RANGE_PICKER_ERROR.DATE_DURATION_INVALID;
  }

  if (!earliestYear && !earliestMonth) {
    earliestYear = 7;
    earliestInvalidMessage = DATE_RANGE_PICKER_ERROR.DATE_EARLIER_THAN_7_YEARS;
  }

  return (
    <Controller
      name={fieldName}
      control={control}
      rules={{
        validate: () => errorMessage || true,
      }}
      render={({ field: { ref, ...fieldRest } }) => (
        <DateRangePicker
          {...fieldRest}
          {...restProps}
          fieldName={fieldName}
          errorMessage={errorMessage}
          durationInMonths={durationInMonths}
          durationInDays={durationInDays}
          durationInvalidMessage={durationInvalidMessage}
          earliestYear={earliestYear}
          earliestMonth={earliestMonth}
          earliestInvalidMessage={earliestInvalidMessage}
        />
      )}
    />
  );
}
