/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { AutocompleteProps } from '@westpac/ui';
import React, {
  memo,
  ReactNode,
  forwardRef,
  useImperativeHandle,
  useRef,
  useMemo,
} from 'react';
import {
  Control,
  Controller,
  FieldValues,
  Path,
  RegisterOptions,
} from 'react-hook-form';
import { AutocompleteId } from './autocomplete/useAutocompleteWrapper';
import {
  AutocompleteWrapper,
  AutocompleteWrapperRef,
} from './autocomplete/AutocompleteWrapper';

export type MVAutocompleteControllerProps<
  T1 extends FieldValues,
  T2 extends AutocompleteId,
> = {
  fieldName: Path<T1>;
  control: Control<T1>;
  validationRules?: RegisterOptions;
  allItems: T2[];
  ItemDetails?: ({ item }: { item: T2 }) => ReactNode;
  AdditionalDetails?: ({ item }: { item: T2 }) => ReactNode;
  keyFn?: (item: T2) => string;
  inputValueFn?: (item: T2) => string;
  maxVisibleItems?: number;
  filterFn?: (item: T2, input: string) => boolean;
  onChange?: (value: T2 | null) => void;
  onBlur?: (e: React.FocusEvent<HTMLInputElement, Element>) => void;
} & {
  ref?: React.Ref<{ clear: () => void }>;
} & Omit<AutocompleteProps<T2>, 'children'>;

function MVAutocompleteControllerInner<
  T1 extends FieldValues,
  T2 extends AutocompleteId,
>(
  {
    fieldName,
    control,
    validationRules,
    onChange: onCustomChange,
    onBlur: onCustomBlur,
    ...restProps
  }: MVAutocompleteControllerProps<T1, T2>,
  ref: React.Ref<{ clear: () => void }>
) {
  const innerRef = useRef<AutocompleteWrapperRef>(null);
  const AutocompleteWrapperWithType = useMemo(
    () => AutocompleteWrapper<T2>(),
    []
  );

  // Expose clear method
  useImperativeHandle(ref, () => ({
    clear: () => {
      innerRef.current?.clear?.();
    },
  }));

  return (
    <Controller
      name={fieldName}
      control={control}
      rules={validationRules as any}
      render={({
        field: { ref: _inputRef, value, onChange, onBlur, ...restField },
        fieldState: { error },
      }) => (
        <AutocompleteWrapperWithType
          ref={innerRef}
          inputRef={_inputRef}
          {...restField}
          {...restProps}
          errorMessage={error?.message}
          fieldName={fieldName}
          fieldValue={value}
          onChange={e => {
            onChange(e);
            onCustomChange?.(e);
          }}
          onBlur={e => {
            onBlur();
            onCustomBlur?.(e);
          }}
        >
          <></>
        </AutocompleteWrapperWithType>
      )}
    />
  );
}

// Wrap with forwardRef
export const MVAutocompleteController = memo(
  forwardRef(MVAutocompleteControllerInner)
) as <T1 extends FieldValues, T2 extends AutocompleteId>(
  props: MVAutocompleteControllerProps<T1, T2>
) => React.ReactElement;
