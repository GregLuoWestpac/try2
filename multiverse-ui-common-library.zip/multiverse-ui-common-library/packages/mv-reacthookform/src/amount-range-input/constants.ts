export type AmountRange = {
  fromAmount: string;
  toAmount: string;
};

export enum ERROR_MESSAGES {
  INVALID_VALUE = 'Enter an amount zero or greater, up to two decimal places.',
  INVALID_RANGE = "Ensure the 'From amount' is less than the 'To amount'.",
}
