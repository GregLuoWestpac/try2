import { Input, InputGroup } from '@westpac/ui';
import React, {
  ClipboardEvent,
  CompositionEvent,
  SyntheticEvent,
  useRef,
  useState,
} from 'react';
import { formatCurrencyString } from '@mesh-tenant-multiverse-ui-common/mv-utils/src';

export type AmountFieldProps = {
  id: string;
  value: string;
  onChange: (value: string) => void;
  onBlur?: () => void;
  onFocus?: () => void;
  disabled?: boolean;
  label?: string;
  removeMargin?: boolean;
  invalid?: boolean;
  wholeNumbersOnly?: boolean;
  showCurrencySymbol?: boolean;
};

function AmountField({
  id,
  value,
  onChange,
  onBlur,
  onFocus,
  disabled,
  label,
  removeMargin,
  invalid,
  wholeNumbersOnly,
  showCurrencySymbol,
}: AmountFieldProps) {
  const [isComposing, setIsComposing] = useState(false);
  const [isFocus, setIsFocus] = useState(false);
  const latestValidValue = useRef('');
  const inputRef = useRef<HTMLInputElement>();
  const currencyCode = 'AUD';

  const numberFormatRegex = wholeNumbersOnly ? /^\d*$/ : /^\d*(\.\d*)?$/;

  const handleCompositionStart = () => setIsComposing(true);

  const handleCompositionEnd = (event: CompositionEvent<HTMLInputElement>) => {
    const {
      value: currentValue,
      selectionStart,
      selectionEnd,
    } = event.currentTarget;
    setIsComposing(false);
    if (numberFormatRegex.test(currentValue)) {
      latestValidValue.current = currentValue;
      onChange(currentValue);
    } else {
      onChange(latestValidValue.current);
      requestAnimationFrame(() => {
        if (
          inputRef.current &&
          selectionStart !== null &&
          selectionEnd !== null
        ) {
          inputRef.current.selectionStart =
            selectionStart -
            (currentValue.length - latestValidValue.current.length);
          inputRef.current.selectionEnd =
            selectionEnd -
            (currentValue.length - latestValidValue.current.length);
        }
      });
    }
  };

  const handleOnChange = (event: SyntheticEvent<HTMLInputElement>) => {
    const {
      value: currentValue,
      selectionStart,
      selectionEnd,
    } = event.currentTarget;

    if (!isComposing) {
      if (numberFormatRegex.test(currentValue)) {
        latestValidValue.current = currentValue;
        onChange(currentValue);
      } else {
        onChange(latestValidValue.current);
        requestAnimationFrame(() => {
          if (
            inputRef.current &&
            selectionStart !== null &&
            selectionEnd !== null
          ) {
            inputRef.current.selectionStart =
              selectionStart -
              (currentValue.length - latestValidValue.current.length);
            inputRef.current.selectionEnd =
              selectionEnd -
              (currentValue.length - latestValidValue.current.length);
          }
        });
        return;
      }
    }
    return currentValue;
  };

  const handleOnPaste = (event: ClipboardEvent<HTMLInputElement>) => {
    const pastedData = event.clipboardData.getData('text');
    if (!numberFormatRegex.test(pastedData)) {
      event.preventDefault();
    }
  };

  const handleOnFocus = () => {
    setIsFocus(true);
    onFocus?.();
  };

  const handleOnBlur = () => {
    setIsFocus(false);
    onBlur?.();
  };

  const classes = `${!label ? '[&_legend]:!mb-0' : ''} ${removeMargin ? '[&_fieldset]:!mb-0' : ''}`;

  return (
    <div id="amount-field-wrapper" className={`${classes} w-[200px]`}>
      <InputGroup
        label={label}
        tag="fieldset"
        size="small"
        // TODO: Remove hardcoded currency symbol once the component fully supports multiple currencies (FCA)
        before={showCurrencySymbol ? '$' : currencyCode}
        instanceId={id}
      >
        <Input
          disabled={disabled}
          className="focus:outline-2 focus:outline-data-d-tint focus:outline-offset-3"
          invalid={invalid}
          ref={inputRef}
          onBlur={handleOnBlur}
          value={
            isFocus
              ? value
              : formatCurrencyString(value, currencyCode, wholeNumbersOnly)
          }
          onChange={handleOnChange}
          onFocus={handleOnFocus}
          onPaste={handleOnPaste}
          onCompositionStart={handleCompositionStart}
          onCompositionEnd={handleCompositionEnd}
        />
      </InputGroup>
    </div>
  );
}

export default AmountField;
