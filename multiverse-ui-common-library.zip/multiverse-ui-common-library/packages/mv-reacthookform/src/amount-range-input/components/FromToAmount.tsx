import AmountField from './AmountField';
import {
  FieldValues,
  Path,
  UseFormClearErrors,
  UseFormSetError,
} from 'react-hook-form';
import { AmountRange, ERROR_MESSAGES } from '../constants';
import React, { useState } from 'react';

export type FromToAmountProps<T extends FieldValues> = {
  value: AmountRange;
  onChange: (value: AmountRange) => void;
  fieldName: Path<T>;
  setError: UseFormSetError<T>;
  clearErrors: UseFormClearErrors<T>;
  errorMessage: string;
  removeMargin?: boolean;
  isTreasuryPage?: boolean;
  ragStatus?: string;
  isStateValuesOverlapping?: boolean;
  globalFromAmountError?: boolean;
  globalToAmountError?: boolean;
  setGlobalFromAmountError?: (hasError: boolean) => void;
  setGlobalToAmountError?: (hasError: boolean) => void;
  wholeNumbersOnly?: boolean;
  onBlur?: () => {
    hasErrors: boolean;
    errorField?: string;
    errorMessage?: string;
  };
  showCurrencySymbol?: boolean;
};

function FromToAmount<T extends FieldValues>({
  value,
  onChange,
  fieldName,
  setError,
  clearErrors,
  removeMargin = true,
  globalFromAmountError,
  globalToAmountError,
  setGlobalFromAmountError,
  setGlobalToAmountError,
  wholeNumbersOnly,
  onBlur,
  showCurrencySymbol,
}: FromToAmountProps<T>) {
  const [fromAmountHasErrors, setFromAmountHasErrors] = useState(false);
  const [toAmountHasErrors, setToAmountHasErrors] = useState(false);

  const shouldHighlightFromAmount =
    globalFromAmountError || fromAmountHasErrors;
  const shouldHighlightToAmount = globalToAmountError || toAmountHasErrors;

  const fromAmountValue = value?.fromAmount || '';
  const toAmountValue = value?.toAmount || '';

  const validateCurrencyNumber = (value: string) => {
    if (!value || value.trim() === '') return true;
    const num = Number(value);
    const digitsAfterDecimal = value.split('.')[1]?.length;
    if (digitsAfterDecimal > 2 || num < 0 || num > 99999999999.99) return false;
    return true;
  };

  function putErrorForRHFController(message: string) {
    if (message) {
      setError(fieldName, { type: 'invalid', message });
    } else {
      clearErrors(fieldName);
    }
  }

  function putErrorForFromAmount(message: string) {
    setFromAmountHasErrors(true);
    putErrorForRHFController(message);
  }
  function putErrorForToAmount(message: string) {
    setToAmountHasErrors(true);
    putErrorForRHFController(message);
  }

  function putErrorForFromAndToAmount(message: string) {
    setFromAmountHasErrors(true);
    setToAmountHasErrors(true);
    putErrorForRHFController(message);
  }

  function clearError() {
    setFromAmountHasErrors(false);
    setToAmountHasErrors(false);
    putErrorForRHFController('');
  }

  function clearAllErrors() {
    clearError();
    setGlobalFromAmountError?.(false);
    setGlobalToAmountError?.(false);
  }

  function validateAmountRange() {
    clearError();

    // if fromAmount is populated correctly and toAmount is empty, autofill toAmount with same value
    if (
      validateCurrencyNumber(fromAmountValue) &&
      fromAmountValue &&
      !toAmountValue
    ) {
      onChange({ ...value, toAmount: fromAmountValue });
      return; // exit early
    }

    // fromAmount is invalid or empty, but toAmount is validated
    if (
      (!validateCurrencyNumber(fromAmountValue) || !fromAmountValue) &&
      validateCurrencyNumber(toAmountValue)
    ) {
      putErrorForFromAmount(ERROR_MESSAGES.INVALID_VALUE);
    }

    // toAmount is invalid or empty, but fromAmount is validated
    if (
      (!validateCurrencyNumber(toAmountValue) || !toAmountValue) &&
      validateCurrencyNumber(fromAmountValue)
    ) {
      putErrorForToAmount(ERROR_MESSAGES.INVALID_VALUE);
    }

    // both amounts are invalid
    if (
      !validateCurrencyNumber(fromAmountValue) &&
      !validateCurrencyNumber(toAmountValue)
    ) {
      putErrorForFromAndToAmount(ERROR_MESSAGES.INVALID_VALUE);
    }

    // invalid range error
    if (
      parseFloat(fromAmountValue) > parseFloat(toAmountValue) &&
      validateCurrencyNumber(fromAmountValue) &&
      validateCurrencyNumber(toAmountValue)
    ) {
      putErrorForFromAndToAmount(ERROR_MESSAGES.INVALID_RANGE);
    }

    if (!fromAmountValue && !toAmountValue) {
      clearError();
    }
  }

  function handleExternalValidationError(result: any) {
    clearError();

    switch (result.errorField) {
      case 'fromAmount':
        putErrorForFromAmount(result.errorMessage);
        break;
      case 'toAmount':
        putErrorForToAmount(result.errorMessage);
        break;
      case 'fromAndToAmount':
        putErrorForFromAndToAmount(result.errorMessage);
        break;
      case 'globalFromAndToAmount':
        setGlobalFromAmountError?.(true);
        setGlobalToAmountError?.(true);
        break;
      default:
        break;
    }
  }

  function triggerOnBlur() {
    if (onBlur) {
      const result = onBlur();
      if (result.hasErrors) {
        handleExternalValidationError(result);
      } else if (!result.hasErrors) {
        clearAllErrors();
      }
    } else {
      validateAmountRange();
    }
  }

  return (
    <div className="flex flex-row">
      <AmountField
        id="fromAmount"
        value={value?.fromAmount}
        onChange={newValue => onChange({ ...value, fromAmount: newValue })}
        onBlur={triggerOnBlur}
        removeMargin={removeMargin}
        invalid={shouldHighlightFromAmount}
        wholeNumbersOnly={wholeNumbersOnly}
        showCurrencySymbol={showCurrencySymbol}
      />

      <img
        src="data:image/svg+xml;charset=utf-8,%0A%20%3Csvg%20width%3D%2216%22%20height%3D%2217%22%20viewBox%3D%220%200%2016%2017%22%20fill%3D%22none%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%0A%3Cpath%20d%3D%22M14.9999%208.48533C15%208.49021%2015%208.4951%2015%208.5C15%208.50516%2015%208.5103%2014.9999%208.51544C15.0039%208.78297%2014.9046%209.05092%2014.7032%209.25214L8.75075%2015.2009C8.35154%2015.5999%207.70523%2015.6008%207.30092%2015.1968C6.89941%2014.7955%206.90136%2014.143%207.29676%2013.7479L11.5473%209.5H2.00685C1.45078%209.5%201%209.05614%201%208.5C1%207.94772%201.44995%207.5%202.00685%207.5H11.5457L7.29906%203.25075C6.90009%202.85154%206.89916%202.20523%207.30321%201.80092C7.70447%201.39941%208.35699%201.40136%208.75214%201.79676L14.7009%207.74925C14.9037%207.95218%2015.0037%208.21895%2014.9999%208.48533Z%22%20fill%3D%22%23545454%22%2F%3E%0A%3C%2Fsvg%3E%0A%0A"
        alt="RightArrow"
        className="mx-2"
      />

      <AmountField
        id="toAmount"
        value={value?.toAmount}
        onChange={newValue => onChange({ ...value, toAmount: newValue })}
        onBlur={triggerOnBlur}
        removeMargin={removeMargin}
        invalid={shouldHighlightToAmount}
        wholeNumbersOnly={wholeNumbersOnly}
        showCurrencySymbol={showCurrencySymbol}
      />
    </div>
  );
}

export default FromToAmount;
