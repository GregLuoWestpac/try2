import React from 'react';
import { InputGroup } from '@westpac/ui';
import {
  FieldValues,
  Path,
  UseFormClearErrors,
  UseFormSetError,
} from 'react-hook-form';
import FromToAmount from './components/FromToAmount';
import { AmountRange } from './constants';

export type AmountRangeInputProps<T extends FieldValues> = {
  value: AmountRange;
  onChange: (value: AmountRange) => void;
  fieldName: Path<T>;
  setError: UseFormSetError<T>;
  clearErrors: UseFormClearErrors<T>;
  errorMessage: string;
  globalFromAmountError?: boolean;
  globalToAmountError?: boolean;
  setGlobalFromAmountError?: (hasError: boolean) => void;
  setGlobalToAmountError?: (hasError: boolean) => void;
  hideFromAndToLabels?: boolean;
  wholeNumbersOnly?: boolean;
  onBlur?: () => {
    hasErrors: boolean;
    errorField?: string;
    errorMessage?: string;
  };
  showCurrencySymbol?: boolean;
};

export function AmountRangeInput<T extends FieldValues>({
  hideFromAndToLabels,
  errorMessage,
  showCurrencySymbol,
  ...restProps
}: AmountRangeInputProps<T>) {
  return (
    <div className="flex flex-col items-start">
      {!hideFromAndToLabels && (
        <div className="flex flex-row">
          <InputGroup label="From amount" className="w-[200px] mb-0" />

          <div className="w-[40px]"></div>

          <InputGroup label="To amount" className="w-[200px] mb-0" />
        </div>
      )}

      {!!errorMessage && (
        <InputGroup errorMessage={errorMessage} className="mb-0" />
      )}

      <FromToAmount
        errorMessage={errorMessage}
        showCurrencySymbol={showCurrencySymbol}
        {...restProps}
      />
    </div>
  );
}
