/* eslint-disable @typescript-eslint/no-unused-vars */
import { CheckboxGroup, CheckboxGroupProps } from '@westpac/ui';
import { Control, Controller, FieldValues, Path } from 'react-hook-form';
import React from 'react';

type MVCheckboxControllerProps<T extends FieldValues> = {
  control: Control<T>;
  fieldName: Path<T>;
  label: string;
  className?: string;
} & Omit<CheckboxGroupProps, 'checkboxes'>;

export function MVCheckboxController<T extends FieldValues>({
  control,
  fieldName,
  label,
  className,
  ...restProps
}: MVCheckboxControllerProps<T>) {
  return (
    <Controller
      name={fieldName}
      control={control}
      render={({ field: { ref, onChange, value, ...restField } }) => (
        <CheckboxGroup
          {...restField}
          {...restProps}
          className={`font-medium typography-body-9 mt-0 ${className}`}
          aria-label={label}
          orientation="horizontal"
          label=""
          size="medium"
          value={value ? ['true'] : ['']}
          onChange={e => {
            onChange(e.filter(item => item)?.[0] === 'true');
          }}
          checkboxes={[
            {
              value: 'true',
              label,
            },
          ]}
        />
      )}
    />
  );
}
