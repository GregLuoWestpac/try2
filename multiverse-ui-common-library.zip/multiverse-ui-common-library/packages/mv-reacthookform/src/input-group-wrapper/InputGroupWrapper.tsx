/* eslint-disable react/jsx-no-bind */
import { Input, InputGroup, InputGroupProps, Textarea } from '@westpac/ui';
import React, { ChangeEvent, FocusEventHandler, HTMLInputTypeAttribute, useEffect } from 'react';
import { FieldValues, Path, RefCallBack } from 'react-hook-form';

export const PHONE_DELIMITER = '-';

export function removeDialCodeAndDelimiter(value: string) {
  if (value?.startsWith('+')) {
    let newValue = value.slice(1);
    const startIdx = newValue.indexOf(PHONE_DELIMITER) + 1;
    if (startIdx > 0) {
      newValue = newValue.slice(startIdx);
    }
    return newValue;
  }
  return value;
}

type InputGroupWrapperProps<T extends FieldValues> = {
  fieldValue: string;
  onChange: (currentValue: string) => void;
  restField: {
    disabled?: boolean;
    name: Path<T>;
    ref: RefCallBack;
  };
  onBlur: FocusEventHandler;
  id?: string;
  maximumLength?: number;
  inputType?: string;
  type?: HTMLInputTypeAttribute; 
  placeholder?: string;
  hideCounterText?: boolean;
  multiLines?: boolean;
  dialCode?: string;
  matchPattern?: RegExp;
} & InputGroupProps;

export function InputGroupWrapper<T extends FieldValues>({
  fieldValue,
  onChange,
  restField,
  id = restField.name,
  maximumLength = 35,
  inputType,
  type,
  placeholder,
  onBlur,
  hideCounterText = false,
  multiLines = false,
  dialCode,
  errorMessage,
  matchPattern,
  ...restProps
}: InputGroupWrapperProps<T>) {
  const charLeft = maximumLength - (fieldValue?.length || 0);
  const counterText = hideCounterText ? null : `${charLeft} remaining`;
  const Child = multiLines ? Textarea : Input;

  useEffect(() => {
    if (dialCode !== undefined) {
      const newValue = removeDialCodeAndDelimiter(fieldValue);
      addDialCodeAndUpdateValue(newValue);
    }
  }, [dialCode]);

  function addDialCodeAndUpdateValue(newValue: string) {
    if (dialCode && newValue) {
      newValue = `${dialCode}${PHONE_DELIMITER}${newValue}`;
    }
    if (newValue !== fieldValue) {
      onChange(newValue);
    }
  }

  function handleOnChange(
    event: ChangeEvent<HTMLInputElement> | ChangeEvent<HTMLTextAreaElement>
  ) {
    let inputValue = event.currentTarget.value;
    if (inputType === 'ASCII printable') {
      inputValue = inputValue.replace(/[^\x20-\x7E]/g, '');
    }

    let cleanedString = inputValue;
    if (matchPattern) {
      let newPattern = matchPattern.source; // the "matchPattern" indicates allowed characters

      if (newPattern.startsWith('^')) {
        newPattern = newPattern.slice(1);
      }
      if (newPattern.startsWith('[')) {
        newPattern = newPattern.slice(1);
      }
      if (newPattern.endsWith('$')) {
        newPattern = newPattern.slice(0, -1);
      }
      if (newPattern.endsWith(']+')) {
        newPattern = newPattern.slice(0, -2);
      }

      const newRegEx = new RegExp(`[^${newPattern}]`, 'g'); // `[^${newPattern}]` means "any character not in this newPattern".
      cleanedString = inputValue.replace(newRegEx, ''); // remove any character not in this newPattern
    }
    inputValue = cleanedString?.slice(0, maximumLength);
    addDialCodeAndUpdateValue(inputValue);
  }

  return (
    <InputGroup
      supportingText={counterText}
      instanceId={id}
      {...restProps}
      errorMessage={errorMessage}
    >
      <Child
        value={
          dialCode === undefined
            ? fieldValue
            : removeDialCodeAndDelimiter(fieldValue)
        }
        onChange={handleOnChange}
        {...restField}
        placeholder={placeholder}
        invalid={!!errorMessage}
        onBlur={onBlur}
        {...(type && { type })} 
      />
    </InputGroup>
  );
}
