import React, { useState } from 'react';
import { FieldValues, Path, useWatch } from 'react-hook-form';
import { MVInputController, MVInputControllerProps } from './MVInputController';
import {
  AUSTRALIA_DIAL_CODE,
  COUNTRY_DIAL_CODES,
} from './dial-code-select/constant';
import { DialCodeSelect } from './dial-code-select/DialCodeSelect';
import {
  PHONE_DELIMITER,
  removeDialCodeAndDelimiter,
} from './input-group-wrapper/InputGroupWrapper';

function getDialCode(phoneNumber: string) {
  const startIdx = phoneNumber.indexOf(PHONE_DELIMITER);
  if (phoneNumber?.startsWith('+') && startIdx > 0) {
    const newValue = phoneNumber.slice(0, startIdx);
    return newValue;
  }
  return '';
}

export function MVPhoneInputController<T extends FieldValues>({
  validationRules,
  ...restProps
}: Omit<MVInputControllerProps<T>, 'dialCode'>) {
  const phoneRegex =
    /^\+?[1-9]\d{0,4}[-\s]{1}\(?\d{1,9}\)?[-\s]?\d{1,9}[-\s]?\d{0,9}$/;
  const rules = {
    validate: (value: string) => {
      const newValue = removeDialCodeAndDelimiter(value);
      if (!newValue) return true;
      return (
        (phoneRegex.test(value) && newValue.length >= 2) ||
        'Enter a valid phone number.'
      );
    },
    ...validationRules,
  };

  const fieldValue = useWatch({
    control: restProps.control,
    name: restProps.fieldName as Path<T>,
  });

  let newDialCode = getDialCode(fieldValue);

  if (!COUNTRY_DIAL_CODES.includes(newDialCode)) {
    newDialCode = AUSTRALIA_DIAL_CODE;
  }
  const [dialCode, setDialCode] = useState(newDialCode);

  return (
    <MVInputController
      before={<DialCodeSelect dialCode={dialCode} setDialCode={setDialCode} />}
      dialCode={dialCode}
      hideCounterText
      validationRules={rules}
      label="Phone number"
      matchPattern={/0-9-\s/}
      {...restProps}
    />
  );
}
