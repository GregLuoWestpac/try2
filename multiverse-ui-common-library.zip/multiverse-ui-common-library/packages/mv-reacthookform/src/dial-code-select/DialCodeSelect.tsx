import { Select } from '@westpac/ui';
import React, { ChangeEvent } from 'react';
import { COUNTRY_DIAL_CODES } from './constant';

export type Props = {
  dialCode: string;
  setDialCode: React.Dispatch<React.SetStateAction<string>>;
};

export function DialCodeSelect({ dialCode, setDialCode }: Props) {
  function handleChange(event: ChangeEvent<HTMLSelectElement>): void {
    setDialCode(event.target.value);
  }

  return (
    <Select
      id="select"
      size="small"
      width={4}
      value={dialCode}
      onChange={handleChange}
    >
      {COUNTRY_DIAL_CODES.map(code => (
        <option key={code} value={code}>
          {code}
        </option>
      ))}
    </Select>
  );
}
