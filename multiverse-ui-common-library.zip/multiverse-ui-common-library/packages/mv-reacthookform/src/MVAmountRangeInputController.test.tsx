import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { useForm } from 'react-hook-form';
import MVAmountRangeInputController from './MVAmountRangeInputController';
import '@testing-library/jest-dom';

type FormData = {
  amountRange: { fromAmount: string; toAmount: string };
};

const TestWrapper = ({
  children,
  onSubmit = jest.fn(),
  defaultValues = {},
}: {
  children: React.ReactElement;
  onSubmit?: (data: FormData) => void;
  defaultValues?: Partial<FormData>;
}) => {
  const { control, handleSubmit, setError, clearErrors } = useForm<FormData>({
    defaultValues: {
      amountRange: { fromAmount: '', toAmount: '' },
      ...defaultValues,
    },
    mode: 'onBlur',
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      {React.cloneElement(children, {
        control,
        setError,
        clearErrors,
      })}
      <button type="submit">Submit</button>
    </form>
  );
};

describe('MVAmountRangeInputController', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render amount range inputs with labels by default', () => {
    render(
      <TestWrapper>
        <MVAmountRangeInputController fieldName="amountRange" />
      </TestWrapper>
    );

    expect(screen.getByText('From amount')).toBeInTheDocument();
    expect(screen.getByText('To amount')).toBeInTheDocument();
    expect(screen.getAllByText('AUD')).toHaveLength(2);
  });

  it('should hide labels when hideFromAndToLabels is true', () => {
    render(
      <TestWrapper>
        <MVAmountRangeInputController
          fieldName="amountRange"
          hideFromAndToLabels={true}
        />
      </TestWrapper>
    );

    expect(screen.queryByText('From amount')).not.toBeInTheDocument();
    expect(screen.queryByText('To amount')).not.toBeInTheDocument();
  });

  it('should allow decimal input by default', async () => {
    render(
      <TestWrapper>
        <MVAmountRangeInputController fieldName="amountRange" />
      </TestWrapper>
    );

    const fromInput = screen.getAllByRole('textbox')[0];

    fireEvent.focus(fromInput);
    fireEvent.change(fromInput, { target: { value: '123.45' } });
    fireEvent.blur(fromInput);

    await waitFor(() => {
      expect(fromInput).toHaveValue('123.45');
    });
  });

  it('should restrict to whole numbers when wholeNumbersOnly is true', async () => {
    render(
      <TestWrapper>
        <MVAmountRangeInputController
          fieldName="amountRange"
          wholeNumbersOnly={true}
        />
      </TestWrapper>
    );

    const fromInput = screen.getAllByRole('textbox')[0];

    // Type a value with decimals
    fireEvent.focus(fromInput);
    fireEvent.change(fromInput, { target: { value: '123.45' } });
    fireEvent.blur(fromInput);

    await waitFor(() => {
      const inputValue = fromInput.value;
      expect(['', '123']).toContain(inputValue);
    });
  });

  it('should auto-fill toAmount when fromAmount is valid and toAmount is empty', async () => {
    render(
      <TestWrapper>
        <MVAmountRangeInputController fieldName="amountRange" />
      </TestWrapper>
    );

    const [fromInput, toInput] = screen.getAllByRole('textbox');

    fireEvent.focus(fromInput);
    fireEvent.change(fromInput, { target: { value: '100' } });
    fireEvent.blur(fromInput);

    await waitFor(() => {
      expect(toInput).toHaveValue('100.00');
    });
  });

  it('should validate range and show error when from > to', async () => {
    render(
      <TestWrapper>
        <MVAmountRangeInputController fieldName="amountRange" />
      </TestWrapper>
    );

    const [fromInput, toInput] = screen.getAllByRole('textbox');

    fireEvent.focus(fromInput);
    fireEvent.change(fromInput, { target: { value: '200' } });
    fireEvent.blur(fromInput);

    fireEvent.focus(toInput);
    fireEvent.change(toInput, { target: { value: '100' } });
    fireEvent.blur(toInput);

    await waitFor(() => {
      expect(
        screen.getByText(
          "Ensure the 'From amount' is less than the 'To amount'."
        )
      ).toBeInTheDocument();
    });
  });

  it('should validate format and show error for invalid input', async () => {
    render(
      <TestWrapper>
        <MVAmountRangeInputController fieldName="amountRange" />
      </TestWrapper>
    );

    const fromInput = screen.getAllByRole('textbox')[0];

    fireEvent.focus(fromInput);
    fireEvent.change(fromInput, { target: { value: '-50' } });
    fireEvent.blur(fromInput);

    fireEvent.focus(fromInput);
    fireEvent.change(fromInput, { target: { value: '50.123' } });
    fireEvent.blur(fromInput);

    await waitFor(() => {
      expect(
        screen.getByText(
          'Enter an amount zero or greater, up to two decimal places.'
        )
      ).toBeInTheDocument();
    });
  });

  it('should format currency on blur', async () => {
    render(
      <TestWrapper>
        <MVAmountRangeInputController fieldName="amountRange" />
      </TestWrapper>
    );

    const fromInput = screen.getAllByRole('textbox')[0];

    fireEvent.focus(fromInput);
    fireEvent.change(fromInput, { target: { value: '1000.5' } });
    fireEvent.blur(fromInput);

    // Wait for formatting to apply
    await waitFor(() => {
      fireEvent.focus(fromInput);
      fireEvent.blur(fromInput);
    });

    expect(fromInput).toHaveValue('1,000.50');
    // When focused again, should show raw value
    fireEvent.focus(fromInput);
    expect(fromInput).toHaveValue('1000.5');
  });

  it('should handle form submission with valid data', async () => {
    const mockSubmit = jest.fn();

    render(
      <TestWrapper onSubmit={mockSubmit}>
        <MVAmountRangeInputController fieldName="amountRange" />
      </TestWrapper>
    );

    const [fromInput, toInput] = screen.getAllByRole('textbox');
    const submitButton = screen.getByText('Submit');

    fireEvent.focus(fromInput);
    fireEvent.change(fromInput, { target: { value: '50' } });
    fireEvent.blur(fromInput);

    fireEvent.focus(toInput);
    fireEvent.change(toInput, { target: { value: '100' } });
    fireEvent.blur(toInput);

    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(mockSubmit).toHaveBeenCalledWith(
        expect.objectContaining({
          amountRange: { fromAmount: '50', toAmount: '100' },
        }),
        expect.anything()
      );
    });
  });

  it('should handle custom validation function', async () => {
    const mockOnBlur = jest.fn().mockReturnValue({
      hasErrors: true,
      errorField: 'fromAmount',
      errorMessage: 'Custom validation error',
    });

    render(
      <TestWrapper>
        <MVAmountRangeInputController
          fieldName="amountRange"
          onBlur={mockOnBlur}
        />
      </TestWrapper>
    );

    const fromInput = screen.getAllByRole('textbox')[0];

    fireEvent.focus(fromInput);
    fireEvent.change(fromInput, { target: { value: '50' } });
    fireEvent.blur(fromInput);

    await waitFor(() => {
      expect(mockOnBlur).toHaveBeenCalled();
      expect(screen.getByText('Custom validation error')).toBeInTheDocument();
    });
  });

  it('should handle global error highlighting', async () => {
    const mockSetGlobalFromError = jest.fn();
    const mockSetGlobalToError = jest.fn();
    const mockOnBlur = jest.fn().mockReturnValue({
      hasErrors: true,
      errorField: 'globalFromAndToAmount',
      errorMessage: 'Global error',
    });

    render(
      <TestWrapper>
        <MVAmountRangeInputController
          fieldName="amountRange"
          setGlobalFromAmountError={mockSetGlobalFromError}
          setGlobalToAmountError={mockSetGlobalToError}
          onBlur={mockOnBlur}
        />
      </TestWrapper>
    );

    const fromInput = screen.getAllByRole('textbox')[0];

    fireEvent.focus(fromInput);
    fireEvent.change(fromInput, { target: { value: '50' } });
    fireEvent.blur(fromInput);

    await waitFor(() => {
      expect(mockSetGlobalFromError).toHaveBeenCalledWith(true);
      expect(mockSetGlobalToError).toHaveBeenCalledWith(true);
    });
  });

  it('should clear errors when validation passes', async () => {
    const mockOnBlur = jest.fn().mockReturnValue({
      hasErrors: false,
      errorField: '',
      errorMessage: '',
    });

    render(
      <TestWrapper>
        <MVAmountRangeInputController
          fieldName="amountRange"
          onBlur={mockOnBlur}
        />
      </TestWrapper>
    );

    const fromInput = screen.getAllByRole('textbox')[0];

    fireEvent.focus(fromInput);
    fireEvent.change(fromInput, { target: { value: '100' } });
    fireEvent.blur(fromInput);

    await waitFor(() => {
      expect(mockOnBlur).toHaveBeenCalled();
      expect(screen.queryByText(/error/i)).not.toBeInTheDocument();
    });
  });

  it('should handle nested field names', () => {
    render(
      <TestWrapper>
        <MVAmountRangeInputController fieldName="red.amountRange" />
      </TestWrapper>
    );

    expect(screen.getByText('From amount')).toBeInTheDocument();
    expect(screen.getByText('To amount')).toBeInTheDocument();
  });
});
