import React from 'react';

type Props = {
  line1: React.ReactNode;
  line2?: React.ReactNode;
  line3?: React.ReactNode;
};

export function AutocompleteItemDetailsTemplate({
  line1,
  line2,
  line3,
}: Props) {
  return (
    <div className="flex flex-col w-full m-0 p-0">
      <span className="text-heading font-semibold truncate">{line1}</span>

      { line2 && (
        <span className="truncate">{line2}</span>
      )}

      { line3 && ( 
        <span className="mt-0.5 text-muted truncate">{line3}</span>
      )}
    </div>
  );
}
