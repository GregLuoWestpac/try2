import { Grid, GridItem } from '@westpac/ui';
import { AutocompleteId } from '../useAutocompleteWrapper';
import React from 'react';

export function DefaultItemDetails<T extends AutocompleteId>({
  item,
}: {
  item: T;
}) {
  return (
    <Grid className="gap-0">
      <GridItem className="text-right" span={6}>
        {item.id}
      </GridItem>
    </Grid>
  );
}
