/* eslint-disable no-lonely-if */
/* eslint-disable no-use-before-define */
import { isEqual } from 'lodash';
import { Key, useEffect, useRef, useState } from 'react';

export type AutocompleteId = { id: string };

const zeroWidthSpace = '\u200B'; // The zero-width space (\u200B) is an invisible character that does not take up any visual space.
const arrowDownEvent = new KeyboardEvent('keydown', {
  key: 'ArrowDown',
  code: 'ArrowDown',
  keyCode: 40,
  which: 40,
  bubbles: true,
});

type Props<T extends AutocompleteId> = {
  fieldValue: T;
  onChange: (item: T | null) => void;
  onBlur: (e: React.FocusEvent<HTMLInputElement, Element>) => void;
  allItems: T[];
  keyFn: (item: T) => string;
  inputValueFn: (item: T) => string;
  noOptionsMessage: string;
  fieldName: string;
  filterFn: ((item: T, input: string) => boolean) | undefined;
  loadingState: boolean | undefined;
};

export function useAutocompleteWrapper<T extends AutocompleteId>({
  fieldValue,
  onChange,
  onBlur,
  allItems,
  keyFn,
  inputValueFn,
  noOptionsMessage,
  fieldName,
  filterFn,
  loadingState,
}: Props<T>) {
  const [inputValue, setInputValue] = useState('');
  const [selectedKey, setSelectedKey] = useState('');
  const [items, setItems] = useState(allItems);
  const [noResultsMessage, setNoResultsMessage] = useState(noOptionsMessage);
  const isOpenRef = useRef(false);

  useEffect(() => {
    if (loadingState === undefined) return;

    if (loadingState) {
      setItems([]);
    } else {
      setItems(allItems);
    }
  }, [loadingState]);

  useEffect(() => {
    if (fieldValue) {
      const newInputValue = inputValueFn(fieldValue);
      if (newInputValue !== inputValue) {
        setInputValue(newInputValue);
      }

      const newKey = keyFn(fieldValue);
      if (newKey !== selectedKey) {
        setSelectedKey(newKey);
      }
    } else {
      resetInputValue();
    }
  }, [fieldValue]);

  useEffect(() => {
    let newNoResultsMessage = noOptionsMessage;

    if (loadingState) {
      newNoResultsMessage = '';
    } else if (items.length) {
      newNoResultsMessage = '';
    } else if (inputValueFn(fieldValue) === inputValue) {
      newNoResultsMessage = '';
    }
    setNoResultsMessage(newNoResultsMessage);
  }, [loadingState, items, inputValue]);

  const sanitizedFieldName = fieldName.replace(/\./g, '');
  const buttonElement: HTMLButtonElement | null = document.querySelector(
    `.autocomplete-wrapper-${sanitizedFieldName} button`
  );
  const inputElement: HTMLInputElement | null = document.querySelector(
    `.autocomplete-wrapper-${sanitizedFieldName} input`
  );
  const autocompleteElement =
    document.querySelector(`.autocomplete-wrapper-${sanitizedFieldName}`) ??
    document.body;

  if (buttonElement) {
    if (inputValue.replace(zeroWidthSpace, '')) {
      buttonElement.style.display = 'block';
    } else {
      buttonElement.style.display = 'none';
    }
  }

  function updateInputValue(newInputValue?: string) {
    if (newInputValue) {
      setInputValue(newInputValue);
    } else if (inputValue) {
      setInputValue('');
    } else {
      setInputValue(zeroWidthSpace); // Input a zero width space to show drop-down options
    }
  }

  function showDropdownList() {
    if (isOpenRef.current) return;
    setItems(prev => (isEqual(prev, allItems) ? prev : allItems));

    const input = inputValue.replace(zeroWidthSpace, '');
    if (!input) {
      updateInputValue();
    } else if (selectedKey) {
      inputElement?.dispatchEvent(arrowDownEvent); // Dispatch an Arrow Down keyboard event to show drop-down options
    } else {
      if (inputValue.includes(zeroWidthSpace)) {
        setInputValue(input);
      } else {
        setInputValue(inputValue + zeroWidthSpace);
      }
    }
  }

  function handleOpenChange(opened: boolean) {
    isOpenRef.current = opened;
  }

  function handleClick() {
    if (loadingState) return;

    showDropdownList();
  }

  const blurRef = useRef(false);

  function handleBlur(e: React.FocusEvent<HTMLInputElement, Element>) {
    if (loadingState) return;
    blurRef.current = true;
    setTimeout(() => {
      blurRef.current = false;
    }, 500);
    if (inputValue === zeroWidthSpace) {
      setInputValue('');
    }
    setNoResultsMessage('');
    if (items.length) {
      setItems([]); // close the dropdown list
    }
    if (inputValue.replace(zeroWidthSpace, '') !== inputValueFn(fieldValue)) {
      onChange(null);
      setSelectedKey('');
    }
    onBlur(e);
  }

  function handleInputChange(input: string) {
    if (inputValue === input) return;
    if (!!fieldValue && !!input && keyFn(fieldValue) === input) {
      setNoResultsMessage('');
      setItems([]);
      return;
    }

    const newInputValue = input.replace(zeroWidthSpace, '');
    updateInputValue(newInputValue);

    if (newInputValue) {
      filterItems(newInputValue);
    } else {
      setItems(prev => (isEqual(prev, allItems) ? prev : allItems));
    }
  }

  function filterItems(input: string) {
    const filteredItems = allItems.filter(item => {
      if (filterFn) {
        return filterFn(item, input);
      }

      return Object.values(item).some(value =>
        JSON.stringify(value).toLowerCase().includes(input.toLowerCase())
      );
    });

    setItems(prev => (isEqual(prev, filteredItems) ? prev : filteredItems));
  }

  function findItemFromAllItems(key: string) {
    return allItems.find(item => keyFn(item) === key);
  }

  function handleSelectionChange(key: Key | null) {
    if (!key) return;

    setTimeout(() => {
      processSelectionChange(key);
    }, 150);
  }

  function processSelectionChange(key: Key) {
    if (blurRef.current) return; // if do handleBlur(), then don't do handleSelectionChange()

    if (inputValue && key.toString() === keyFn(fieldValue)) return;

    const foundItem = findItemFromAllItems(key.toString());
    if (foundItem) {
      onChange(foundItem);

      const newKey = keyFn(foundItem);
      setSelectedKey(newKey);

      const newInputValue = inputValueFn(foundItem);
      updateInputValue(newInputValue);

      setItems([]); // close the dropdown list
    }
  }

  function handleKeyDown(event: React.KeyboardEvent<HTMLInputElement>) {
    if (event.key === 'Enter') {
      showDropdownList();
    }

    if (event.key === 'Escape') {
      inputElement?.blur();
      inputElement?.focus();
    } else if (event.key === 'Tab' && inputValue === zeroWidthSpace) {
      setInputValue('');
    }
  }

  function resetInputValue() {
    setSelectedKey('');
    setInputValue('');
  }

  return {
    autocompleteElement,
    items,
    inputValue,
    handleInputChange,
    selectedKey,
    handleSelectionChange,
    handleBlur,
    handleKeyDown,
    handleOpenChange,
    handleClick,
    resetInputValue,
    noResultsMessage,
  };
}
