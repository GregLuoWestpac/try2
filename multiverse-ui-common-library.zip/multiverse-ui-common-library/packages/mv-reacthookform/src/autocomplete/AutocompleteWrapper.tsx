import {
  Autocomplete,
  AutocompleteItem,
  AutocompleteProps,
  InputGroup,
} from '@westpac/ui';
import React, { forwardRef, ReactNode, useImperativeHandle } from 'react';
import './autocomplete-wrapper.css';
import { DefaultItemDetails } from './components/DefaultItemDetails';
import {
  AutocompleteId,
  useAutocompleteWrapper,
} from './useAutocompleteWrapper';

function defaultInputValueFn<T extends AutocompleteId>(item: T): string {
  if (!item) return '';
  return item.id;
}
function defaultKeyFn<T extends AutocompleteId>(item: T): string {
  if (!item) return '';
  return item.id;
}

type Props<T extends AutocompleteId> = {
  fieldValue: T;
  onChange: (value: T | null) => void;
  onBlur: (e: React.FocusEvent<HTMLInputElement, Element>) => void;
  allItems: T[];
  ItemDetails?: ({ item }: { item: T }) => ReactNode;
  AdditionalDetails?: ({ item }: { item: T }) => ReactNode;
  keyFn?: (item: T) => string;
  inputValueFn?: (item: T) => string;
  maxVisibleItems?: number;
  fieldName: string;
  filterFn?: (item: T, input: string) => boolean;
  inputRef?: React.Ref<HTMLInputElement>;
} & AutocompleteProps<T>;

export type AutocompleteWrapperRef = {
  clear: () => void;
};

export function AutocompleteWrapper<T extends AutocompleteId>() {
  const autocompleteInner = forwardRef<AutocompleteWrapperRef, Props<T>>(
    (
      {
        fieldValue,
        onChange,
        onBlur,
        allItems = [],
        ItemDetails = DefaultItemDetails,
        AdditionalDetails,
        keyFn = defaultKeyFn,
        inputValueFn = defaultInputValueFn,
        maxVisibleItems = 20,
        label,
        hintMessage,
        noOptionsMessage = 'No results found',
        placeholder,
        errorMessage,
        fieldName,
        filterFn,
        loadingState,
        inputRef,
        ...restProps
      },
      ref
    ) => {
      const uniqueAllItems = Array.from(
        new Map(allItems.map(item => [keyFn(item), item])).values()
      );

      const {
        autocompleteElement,
        items,
        inputValue,
        handleInputChange,
        selectedKey,
        handleSelectionChange,
        handleBlur,
        handleKeyDown,
        handleOpenChange,
        handleClick,
        resetInputValue,
        noResultsMessage,
      } = useAutocompleteWrapper<T>({
        fieldValue,
        onChange,
        onBlur,
        allItems: uniqueAllItems,
        keyFn,
        inputValueFn,
        noOptionsMessage: noOptionsMessage?.toString() || '',
        fieldName,
        filterFn,
        loadingState,
      });

      // Expose imperative clear method
      useImperativeHandle(ref, () => ({
        clear: () => {
          resetInputValue();
        },
      }));

      const visibleItems = items.slice(0, maxVisibleItems);

      let itemLength = uniqueAllItems.length;
      if (inputValue) {
        itemLength = items.length;
      }
      const footerText = `Showing ${
        visibleItems.length
      } of ${itemLength} result${itemLength > 1 ? 's' : ''}`;

      const sanitizedFieldName = fieldName.replace(/\./g, '');

      return (
        <div
          id="autocomplete-wrapper"
          className={`autocomplete-wrapper-${sanitizedFieldName}`}
        >
          <InputGroup
            errorMessage={errorMessage}
            size="small"
            label={label?.toString()}
            hint={hintMessage}
            className="w-full mb-0"
          />
          <div onClick={handleClick}>
            <Autocomplete
              {...restProps}
              ref={inputRef}
              invalid={!!errorMessage}
              portalContainer={autocompleteElement}
              noOptionsMessage={
                noResultsMessage ? (
                  <div style={{ marginLeft: '-6px' }}>{noResultsMessage}</div>
                ) : undefined
              }
              items={visibleItems}
              inputValue={inputValue}
              onInputChange={handleInputChange}
              selectedKey={selectedKey}
              onSelectionChange={handleSelectionChange}
              onBlur={handleBlur}
              onKeyDown={handleKeyDown}
              onOpenChange={handleOpenChange}
              placeholder={placeholder}
              footer={
                visibleItems.length > 0 ? (
                  <div style={{ marginLeft: '-6px' }}>{footerText}</div>
                ) : undefined
              }
              size="small"
              aria-label={label?.toString()}
              loadingState={loadingState}
            >
              {item => (
                <AutocompleteItem key={keyFn(item)} textValue={keyFn(item)}>
                  <ItemDetails item={item} />
                </AutocompleteItem>
              )}
            </Autocomplete>
          </div>
          {AdditionalDetails && fieldValue?.id && (
            <div className="mt-1.5">
              <AdditionalDetails item={fieldValue} />
            </div>
          )}
        </div>
      );
    }
  );

  autocompleteInner.displayName = 'mv-autocomplete';
  return autocompleteInner;
}
