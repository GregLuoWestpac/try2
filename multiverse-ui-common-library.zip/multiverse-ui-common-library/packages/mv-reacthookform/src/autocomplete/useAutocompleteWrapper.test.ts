import { renderHook, act } from '@testing-library/react';
import {
  useAutocompleteWrapper,
  AutocompleteId,
} from './useAutocompleteWrapper';
import { createRef } from 'react';

describe('useAutocompleteWrapper', () => {
  const mockFieldValue: AutocompleteId = { id: '1' };
  const mockAllItems: AutocompleteId[] = [
    { id: '1' },
    { id: '2' },
    { id: '3' },
  ];
  const mockKeyFn = (item: AutocompleteId) => item.id;
  const mockInputValueFn = (item: AutocompleteId) => item.id;
  const mockOnChange = jest.fn();
  const mockFilterFn = (item: AutocompleteId, input: string) =>
    item.id?.toLowerCase().includes(input.toLowerCase());
  const mockNoOptionsMessage = 'No options available';
  const mockFieldName = 'testField';
  const innerRef = createRef<HTMLInputElement>();

  const setupHook = () =>
    renderHook(() =>
      useAutocompleteWrapper({
        fieldValue: mockFieldValue,
        onChange: mockOnChange,
        allItems: mockAllItems,
        keyFn: mockKeyFn,
        inputValueFn: mockInputValueFn,
        noOptionsMessage: mockNoOptionsMessage,
        fieldName: mockFieldName,
        filterFn: mockFilterFn,
        innerRef,
      })
    );

  it('should initialize with correct default values', () => {
    const { result } = setupHook();

    expect(result.current.inputValue).toBe('1');
    expect(result.current.selectedKey).toBe('1');
    expect(result.current.items).toEqual(mockAllItems);
  });

  it('should update input value and filter items on input change', () => {
    const { result } = setupHook();

    act(() => {
      result.current.handleInputChange('2');
    });

    expect(result.current.inputValue).toBe('2');
    expect(result.current.items).toEqual([{ id: '2' }]);
  });

  it('should reset items and input value when input is cleared', () => {
    const { result } = setupHook();

    act(() => {
      result.current.handleInputChange('');
    });

    expect(result.current.inputValue).toBe('');
    expect(result.current.items).toEqual(mockAllItems);
  });

  it('should update selectedKey and inputValue on selection change', () => {
    const { result } = setupHook();

    act(() => {
      result.current.handleSelectionChange('2');
    });
    setTimeout(() => {
      expect(result.current.selectedKey).toBe('2');
      expect(result.current.inputValue).toBe('Item 2');
    }, 200);
  });

  it('should update noResultsMessage when no items match the filter', () => {
    const { result } = setupHook();

    act(() => {
      result.current.handleInputChange('Nonexistent');
    });

    expect(result.current.noResultsMessage).toBe(mockNoOptionsMessage);
  });
});
