/* eslint-disable react/react-in-jsx-scope */
/* eslint-disable @typescript-eslint/no-unused-vars */
import { DatePickerProps, InputGroup } from '@westpac/ui';
import { useEffect, useState } from 'react';
import {
  Control,
  Controller,
  FieldValues,
  Path,
  UseFormClearErrors,
  UseFormSetError,
  useFormState,
} from 'react-hook-form';
import {
  DATE_FORMAT_REGEX_DDMMYYYY,
  DATE_PICKER_ERROR,
  DATE_RANGE_PICKER_ERROR,
} from './date-range-picker/constants';
import {
  convertStringToDateTime,
  disableEnterKeyDown,
  formatDateString,
  getToday,
  isDateAfterToday,
  isDateBeforeXMonths,
  setControllerError,
} from './date-range-picker/helper';
import { DatePickerWrapper } from './date-range-picker/components/date-picker-wrapper/DatePickerWrapper';
import { DateTime } from 'luxon';
import React from 'react';

type MVDatePickerControllerProps<T extends FieldValues> = {
  control: Control<T>;
  fieldName: Path<T>;
  setError: UseFormSetError<T>;
  clearErrors: UseFormClearErrors<T>;
  label: string;
  earliestMonth: number;
  maxDate?: DateTime;
} & DatePickerProps;

export function MVDatePickerController<T extends FieldValues>({
  control,
  fieldName,
  setError,
  clearErrors,
  label,
  earliestMonth,
  maxDate,
  ...restProps
}: MVDatePickerControllerProps<T>) {
  const [hasClosed, setHasClosed] = useState(false);
  const { errors } = useFormState({ control });
  const errorMessage: string = (errors[fieldName]?.message as string) || '';
  const earliestInvalidMessage = `Select a date within the last ${earliestMonth} months.`;

  if (!maxDate) {
    maxDate = getToday();
  }

  useEffect(() => {
    // use requestAnimationFrame to format date until right before the next screen repaint. This is to make sure "document.querySelector()" can get elements
    let datePickerEle: HTMLInputElement;
    const id = requestAnimationFrame(() => {
      const { datePickerElement } = formatDateForUI();
      datePickerEle = datePickerElement;
      datePickerEle?.addEventListener('keydown', disableEnterKeyDown);
    });
    return () => {
      cancelAnimationFrame(id);
      datePickerEle?.removeEventListener('keydown', disableEnterKeyDown);
    };
  }, []);

  useEffect(() => {
    if (hasClosed) {
      validateDateRange();
      setHasClosed(false);
    }
  }, [hasClosed]);

  function formatDateForUI() {
    const datePickerElement = document.querySelector(
      '#date-picker-wrapper #datePickerDate'
    ) as HTMLInputElement;

    const dateValue = datePickerElement?.value;
    const isDateValid =
      !!dateValue && DATE_FORMAT_REGEX_DDMMYYYY.test(dateValue);
    if (isDateValid) {
      datePickerElement.value = formatDateString(dateValue);
    }

    return {
      dateValue,
      isDateValid,
      datePickerElement,
    };
  }

  function validateDateRange() {
    putError('');

    const { dateValue, isDateValid } = formatDateForUI();
    if (!isDateValid) {
      putError(DATE_RANGE_PICKER_ERROR.DATE_REQUIRED);
      return;
    }

    const pickedDate = convertStringToDateTime(dateValue);
    if (pickedDate > maxDate!) {
      putError(DATE_PICKER_ERROR.DATE_LATER_THAN_TODAY);
    } else if (isDateBeforeXMonths(pickedDate, earliestMonth)) {
      putError(earliestInvalidMessage);
    }
  }

  function putError(message: string) {
    setControllerError(fieldName, setError, clearErrors, message);
  }

  return (
    <Controller
      name={fieldName}
      control={control}
      rules={{
        validate: () => errorMessage || true,
      }}
      render={({ field: { ref, value, onChange, ...fieldRest } }) => (
        <InputGroup label={label} tag="fieldset" errorMessage={errorMessage}>
          <div className="flex flex-col w-full">
            <div className="flex flex-row">
              <DatePickerWrapper
                invalid={!!errorMessage}
                id="datePickerDate"
                value={value}
                onBlur={validateDateRange}
                onClose={() => setHasClosed(true)}
                onChange={val => {
                  onChange(val.detail.value);
                }}
                earliestMonth={earliestMonth}
                maxDate={maxDate}
                {...restProps}
              />
            </div>
          </div>
        </InputGroup>
      )}
    />
  );
}
