import React from 'react';
import {
  Control,
  Controller,
  FieldValues,
  Path,
  UseFormClearErrors,
  UseFormSetError,
} from 'react-hook-form';
import { AmountRangeInput } from './amount-range-input/AmountRangeInput';

export type MVAmountRangeInputControllerProps<T extends FieldValues> = {
  control: Control<T>;
  fieldName: Path<T>;
  setError: UseFormSetError<T>;
  clearErrors: UseFormClearErrors<T>;
  globalFromAmountError?: boolean;
  globalToAmountError?: boolean;
  setGlobalFromAmountError?: (hasError: boolean) => void;
  setGlobalToAmountError?: (hasError: boolean) => void;
  hideFromAndToLabels?: boolean;
  wholeNumbersOnly?: boolean;
  onBlur?: () => {
    hasErrors: boolean;
    errorField?: string;
    errorMessage?: string;
  };
  showCurrencySymbol?: boolean;
};

export default function MVAmountRangeInputController<T extends FieldValues>({
  control,
  fieldName,
  globalFromAmountError,
  globalToAmountError,
  setGlobalFromAmountError,
  setGlobalToAmountError,
  hideFromAndToLabels,
  wholeNumbersOnly,
  onBlur,
  showCurrencySymbol,
  ...restProps
}: MVAmountRangeInputControllerProps<T>) {
  return (
    <Controller
      name={fieldName}
      control={control}
      render={({ field, fieldState }) => {
        const errorMessage = fieldState.error?.message || '';

        return (
          <AmountRangeInput
            {...field}
            {...restProps}
            fieldName={fieldName}
            errorMessage={errorMessage}
            globalFromAmountError={globalFromAmountError}
            globalToAmountError={globalToAmountError}
            setGlobalFromAmountError={setGlobalFromAmountError}
            setGlobalToAmountError={setGlobalToAmountError}
            hideFromAndToLabels={hideFromAndToLabels}
            wholeNumbersOnly={wholeNumbersOnly}
            onBlur={onBlur}
            showCurrencySymbol={showCurrencySymbol}
          />
        );
      }}
    />
  );
}
