import React from 'react';
import {
  Controller,
  Control,
  UseFormTrigger,
  FieldValues,
  Path,
  RegisterOptions,
} from 'react-hook-form';
import { ButtonGroup, ButtonGroupProps, Popover } from '@westpac/ui';
import { HelpIcon } from '@westpac/ui/icon';

export type MVButtonGroupControllerProps<T extends FieldValues> = {
  fieldName: Path<T>;
  trigger: UseFormTrigger<T>;
  control: Control<T>;
  validationRules?: RegisterOptions;
  onChange?: () => void;
  onBlur?: () => void;
  tooltip?: string;
} & ButtonGroupProps;

export function MVButtonGroupController<T extends FieldValues>({
  fieldName,
  trigger,
  control,
  validationRules,
  size = 'small',
  onChange = () => {},
  onBlur = () => {},
  tooltip,
  label,
  ...restProps
}: MVButtonGroupControllerProps<T>) {
  const helpIconId = `${fieldName.replace(/\s+/g, '')}-help-icon-btn`;
  const StyledHelpIcon = () => (
    <HelpIcon
      id={helpIconId}
      size="small"
      color="hero"
      look="outlined"
      aria-label={tooltip}
    />
  );

  return (
    <Controller
      name={fieldName}
      control={control as Control<FieldValues>}
      rules={validationRules}
      render={({
        field: {
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          ref,
          onChange: fieldOnChange,
          onBlur: fieldOnBlur,
          value,
          ...fieldProps
        },
        fieldState: { error },
      }) => {
        const { message: errorMessage } = error || {};
        return (
          <>
            <div className="inline-flex items-center">
              {label}
              {tooltip && (
                <Popover
                  soft
                  look="hero"
                  size="small"
                  icon={StyledHelpIcon}
                  content={tooltip}
                />
              )}
            </div>
            <ButtonGroup
              {...fieldProps}
              {...restProps}
              size={size}
              {...(value ? { value } : {})}
              onChange={value => {
                fieldOnChange(value); // Update react-hook-form state
                trigger(fieldName); // Trigger validation after change
                onChange(); // Trigger custom onChange handler
              }}
              onBlur={() => {
                fieldOnBlur(); //  Trigger onBlur from react-hook-form
                onBlur(); // Trigger custom onBlur handler
              }}
              errorMessage={errorMessage}
              isInvalid={!!errorMessage}
            />
          </>
        );
      }}
    />
  );
}
