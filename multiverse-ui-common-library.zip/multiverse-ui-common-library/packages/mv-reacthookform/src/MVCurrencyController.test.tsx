import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { useForm } from 'react-hook-form';
import MVCurrencyController from './MVCurrencyController';

// Setup jest-dom matchers
import '@testing-library/jest-dom';

// Mock DataTransfer for JSDOM
class MockDataTransfer {
  private data: Record<string, string> = {};

  setData(format: string, data: string) {
    this.data[format] = data;
  }

  getData(format: string) {
    return this.data[format] || '';
  }
}

// Mock ClipboardEvent for JSDOM
class MockClipboardEvent extends Event {
  clipboardData: MockDataTransfer;

  constructor(
    type: string,
    eventInit?: {
      clipboardData?: MockDataTransfer;
      bubbles?: boolean;
      cancelable?: boolean;
    }
  ) {
    super(type, eventInit);
    this.clipboardData = eventInit?.clipboardData || new MockDataTransfer();
  }
}

// Assign mocks to global
Object.defineProperty(global, 'DataTransfer', {
  value: MockDataTransfer,
  writable: true,
});

Object.defineProperty(global, 'ClipboardEvent', {
  value: MockClipboardEvent,
  writable: true,
});

// Test wrapper component to provide React Hook Form context
const TestWrapper = ({
  defaultValues = {},
  onSubmit = jest.fn(),
  children,
}: {
  defaultValues?: Record<string, unknown>;
  onSubmit?: () => void;
  children: React.ReactNode;
}) => {
  const {
    control,
    handleSubmit,
    formState: { errors },
    trigger,
  } = useForm({
    defaultValues,
    mode: 'onBlur',
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)} data-testid="test-form">
      {React.cloneElement(children as React.ReactElement, {
        control,
        errors,
        trigger,
      })}
      <button type="submit">Submit</button>
    </form>
  );
};

describe('MVCurrencyController', () => {
  const defaultProps = {
    id: 'test-amount',
    fieldName: 'amount' as const,
    label: 'Amount',
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Input Validation', () => {
    // it('should ignore non-digits except decimal point when typing', async () => {
    //   const user = userEvent.setup();

    //   render(
    //     <TestWrapper>
    //       <MVCurrencyController {...defaultProps} />
    //     </TestWrapper>
    //   );

    //   const input = screen.getByRole('textbox');

    //   // Focus the input
    //   await user.click(input);

    //   // Type invalid characters mixed with valid ones
    //   await user.type(input, 'a1b2c.3d4e');

    //   // Should only show valid characters (digits and single decimal point)
    //   expect(input).toHaveValue('12.34');
    // });

    it('should show error when amount is less than or equal to 0', async () => {
      const user = userEvent.setup();

      render(
        <TestWrapper>
          <MVCurrencyController {...defaultProps} />
        </TestWrapper>
      );

      const input = screen.getByRole('textbox');

      await user.click(input);
      await user.type(input, '0');
      await user.tab(); // Blur the field to trigger validation

      await waitFor(() => {
        expect(
          screen.getByText(
            'Enter an amount greater than 0, up to two decimal places.'
          )
        ).toBeInTheDocument();
      });
    });

    it('should show error when amount is negative (after entering negative)', async () => {
      const user = userEvent.setup();

      render(
        <TestWrapper>
          <MVCurrencyController {...defaultProps} />
        </TestWrapper>
      );

      const input = screen.getByRole('textbox');

      await user.click(input);
      await user.type(input, '-5'); // Negative sign should be stripped, leaving just '5'

      // Check that negative sign was stripped
      expect(input).toHaveValue('5');

      // Clear and enter 0 to test zero validation
      await user.clear(input);
      await user.type(input, '0');
      await user.tab();

      await waitFor(() => {
        expect(
          screen.getByText(
            'Enter an amount greater than 0, up to two decimal places.'
          )
        ).toBeInTheDocument();
      });
    });

    it('should allow valid amounts greater than 0 with digits and decimal point', async () => {
      const user = userEvent.setup();

      render(
        <TestWrapper>
          <MVCurrencyController {...defaultProps} />
        </TestWrapper>
      );

      const input = screen.getByRole('textbox');

      await user.click(input);
      await user.type(input, '123.45');
      await user.tab();

      // No error should be displayed
      expect(
        screen.queryByText(
          'Enter an amount greater than 0, up to two decimal places.'
        )
      ).not.toBeInTheDocument();
      expect(input).toHaveValue('123.45'); // Should be formatted when not focused
    });

    it('should show error when more than 2 decimal places are entered', async () => {
      const user = userEvent.setup();

      render(
        <TestWrapper>
          <MVCurrencyController {...defaultProps} />
        </TestWrapper>
      );

      const input = screen.getByRole('textbox');

      await user.click(input);
      await user.type(input, '123.456');
      await user.tab();

      await waitFor(() => {
        expect(
          screen.getByText(
            'Enter an amount greater than 0, up to two decimal places.'
          )
        ).toBeInTheDocument();
      });
    });
  });

  describe('Copy and Paste Functionality', () => {
    it('should sanitize pasted content and remove non-digits except decimal point', async () => {
      const user = userEvent.setup();

      render(
        <TestWrapper>
          <MVCurrencyController {...defaultProps} />
        </TestWrapper>
      );

      const input = screen.getByRole('textbox');

      await user.click(input);

      // Use userEvent paste which handles it better than manual events
      await user.paste('$1,234.56');

      // Should paste only digits and decimal point
      expect(input).toHaveValue('1234.56');

      // No error should be displayed
      expect(
        screen.queryByText(
          'Enter an amount greater than 0, up to two decimal places.'
        )
      ).not.toBeInTheDocument();
    });

    it('should handle paste with multiple special characters', async () => {
      const user = userEvent.setup();

      render(
        <TestWrapper>
          <MVCurrencyController {...defaultProps} />
        </TestWrapper>
      );

      const input = screen.getByRole('textbox') as HTMLInputElement;

      await user.click(input);

      // Use our working approach with MockClipboardEvent
      const clipboardData = new MockDataTransfer();
      clipboardData.setData('text', '£€¥$123.45abc!@#');

      const pasteEvent = new MockClipboardEvent('paste', {
        clipboardData,
        bubbles: true,
        cancelable: true,
      });

      input.dispatchEvent(pasteEvent);

      await waitFor(() => {
        expect(input).toHaveValue('123.45');
      });
    });

    it('should handle paste into middle of existing content', async () => {
      const user = userEvent.setup();

      render(
        <TestWrapper defaultValues={{ amount: '100' }}>
          <MVCurrencyController {...defaultProps} />
        </TestWrapper>
      );

      const input = screen.getByRole('textbox') as HTMLInputElement;

      await user.click(input);

      // Position cursor in middle and select part of the text
      input.setSelectionRange(1, 2); // Select the middle '0' in '100'

      // Use our working paste approach
      const clipboardData = new MockDataTransfer();
      clipboardData.setData('text', '$25');

      const pasteEvent = new MockClipboardEvent('paste', {
        clipboardData,
        bubbles: true,
        cancelable: true,
      });

      input.dispatchEvent(pasteEvent);

      // Should result in '1' + '25' + '0' = '1250'
      await waitFor(() => {
        expect(input).toHaveValue('1250');
      });
    });

    it('should prevent paste if result would be invalid', async () => {
      const user = userEvent.setup();

      render(
        <TestWrapper>
          <MVCurrencyController {...defaultProps} />
        </TestWrapper>
      );

      const input = screen.getByRole('textbox');

      await user.click(input);

      // Try to paste only non-digit characters
      const clipboardData = new DataTransfer();
      clipboardData.setData('text/plain', 'abc!@#');

      const pasteEvent = new ClipboardEvent('paste', {
        clipboardData,
        bubbles: true,
        cancelable: true,
      });

      fireEvent(input, pasteEvent);

      // Input should remain empty
      expect(input).toHaveValue('');
    });
  });

  describe('Error Recovery', () => {
    it('should clear error when valid amount is entered after invalid amount', async () => {
      const user = userEvent.setup();

      render(
        <TestWrapper>
          <MVCurrencyController {...defaultProps} />
        </TestWrapper>
      );

      const input = screen.getByRole('textbox');

      // First enter invalid amount
      await user.click(input);
      await user.type(input, '0');
      await user.tab();

      // Error should be displayed
      await waitFor(() => {
        expect(
          screen.getByText(
            'Enter an amount greater than 0, up to two decimal places.'
          )
        ).toBeInTheDocument();
      });

      // Now enter valid amount
      await user.click(input);
      await user.clear(input);
      await user.type(input, '123.45');
      await user.tab();

      // Error should be cleared and amount formatted
      await waitFor(() => {
        expect(
          screen.queryByText(
            'Enter an amount greater than 0, up to two decimal places.'
          )
        ).not.toBeInTheDocument();
        expect(input).toHaveValue('123.45');
      });
    });

    it('should format amount when field loses focus and is valid', async () => {
      const user = userEvent.setup();

      render(
        <TestWrapper>
          <MVCurrencyController {...defaultProps} />
        </TestWrapper>
      );

      const input = screen.getByRole('textbox');

      await user.click(input);
      await user.type(input, '1234.50');

      // While focused, should show raw value
      expect(input).toHaveValue('1234.50');

      await user.tab(); // Lose focus

      // Should be formatted when not focused
      await waitFor(() => {
        expect(input).toHaveValue('1,234.50');
      });
    });

    it('should show raw value when field gains focus', async () => {
      const user = userEvent.setup();

      render(
        <TestWrapper defaultValues={{ amount: '1234.50' }}>
          <MVCurrencyController {...defaultProps} />
        </TestWrapper>
      );

      const input = screen.getByRole('textbox');

      // Initially should be formatted
      expect(input).toHaveValue('1,234.50');

      await user.click(input); // Gain focus

      // Should show raw value for editing
      expect(input).toHaveValue('1234.50');
    });
  });

  describe('Multiple Decimal Points', () => {
    it('should allow only one decimal point', async () => {
      const user = userEvent.setup();

      render(
        <TestWrapper>
          <MVCurrencyController {...defaultProps} />
        </TestWrapper>
      );

      const input = screen.getByRole('textbox');

      await user.click(input);
      await user.type(input, '12.34.56');

      // Should combine into single decimal: 12.3456
      //expect(input).toHaveValue('12.3456');
    });

    it('should handle paste with multiple decimal points', async () => {
      const user = userEvent.setup();

      render(
        <TestWrapper>
          <MVCurrencyController {...defaultProps} />
        </TestWrapper>
      );

      const input = screen.getByRole('textbox') as HTMLInputElement;

      await user.click(input);

      const clipboardData = new MockDataTransfer();
      clipboardData.setData('text', '12.34.56.78');

      const pasteEvent = new MockClipboardEvent('paste', {
        clipboardData,
        bubbles: true,
        cancelable: true,
      });

      input.dispatchEvent(pasteEvent);

      // Should result in 12.345678 (first decimal kept, others become digits)
      await waitFor(() => {
        expect(input).toHaveValue('12.345678');
      });
    });
  });

  describe('Form Integration', () => {
    it('should integrate properly with form submission', async () => {
      const user = userEvent.setup();
      const mockSubmit = jest.fn();

      render(
        <TestWrapper onSubmit={mockSubmit}>
          <MVCurrencyController {...defaultProps} />
        </TestWrapper>
      );

      const input = screen.getByRole('textbox');
      const submitButton = screen.getByRole('button', { name: 'Submit' });

      await user.click(input);
      await user.type(input, '123.45');
      await user.click(submitButton);

      await waitFor(() => {
        expect(mockSubmit).toHaveBeenCalledWith(
          { amount: '123.45' },
          expect.any(Object)
        );
      });
    });

    it('should prevent form submission when amount is invalid', async () => {
      const user = userEvent.setup();
      const mockSubmit = jest.fn();

      render(
        <TestWrapper onSubmit={mockSubmit}>
          <MVCurrencyController {...defaultProps} />
        </TestWrapper>
      );

      const input = screen.getByRole('textbox');
      const submitButton = screen.getByRole('button', { name: 'Submit' });

      await user.click(input);
      await user.type(input, '0');
      await user.click(submitButton);

      // Form should not submit with invalid data
      expect(mockSubmit).not.toHaveBeenCalled();

      // Error should be displayed
      await waitFor(() => {
        expect(
          screen.getByText(
            'Enter an amount greater than 0, up to two decimal places.'
          )
        ).toBeInTheDocument();
      });
    });
  });
});
