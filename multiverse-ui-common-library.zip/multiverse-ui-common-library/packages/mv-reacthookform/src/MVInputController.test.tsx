import React from 'react';
import { render, screen } from '@testing-library/react';
import { useForm } from 'react-hook-form';
import { MVInputController } from './MVInputController';
import '@testing-library/jest-dom';

// Mock DataTransfer for JSDOM
class MockDataTransfer {
  private data: Record<string, string> = {};

  setData(format: string, data: string) {
    this.data[format] = data;
  }

  getData(format: string) {
    return this.data[format] || '';
  }
}

// Mock ClipboardEvent for paste testing
class MockClipboardEvent extends Event {
  clipboardData: MockDataTransfer;

  constructor(type: string, init: { clipboardData: MockDataTransfer }) {
    super(type);
    this.clipboardData = init.clipboardData;
  }
}

// Assign mocks to global
Object.defineProperty(global, 'DataTransfer', {
  value: MockDataTransfer,
  writable: true,
});

Object.defineProperty(global, 'ClipboardEvent', {
  value: MockClipboardEvent,
  writable: true,
});

const TestWrapper = ({ children }: { children: React.ReactElement }) => {
  const { control } = useForm({
    defaultValues: { testField: '' },
  });

  return <form>{React.cloneElement(children, { control })}</form>;
};

describe('MVInputController', () => {
  it('should render', () => {
    render(
      <TestWrapper>
        <MVInputController fieldName="testField" label="Test" />
      </TestWrapper>
    );

    expect(screen.getByRole('textbox')).toBeInTheDocument();
  });

  it('should trim content on blur when trimOnBlur is enabled', async () => {
    render(
      <TestWrapper>
        <MVInputController
          fieldName="testField"
          label="Test"
          trimOnBlur={true}
        />
      </TestWrapper>
    );

    const input = screen.getByRole('textbox') as HTMLInputElement;

    // Simulate typing with whitespace
    input.focus();
    input.value = '  test content  ';

    // Trigger blur to activate trimming
    input.blur();

    // Wait for any async updates
    await new Promise(resolve => setTimeout(resolve, 100));

    expect(input.value).toBe('test content');
  });

  it('should preserve value when trimming is disabled', async () => {
    render(
      <TestWrapper>
        <MVInputController fieldName="testField" label="Test" />
      </TestWrapper>
    );

    const input = screen.getByRole('textbox') as HTMLInputElement;

    input.focus();
    input.value = '  test content  ';
    input.blur();

    await new Promise(resolve => setTimeout(resolve, 100));

    // Should preserve whitespace when trimming is disabled
    expect(input.value).toBe('  test content  ');
  });

  it('should handle different trim types on blur', async () => {
    const TestWrapperWithTrimType = () => {
      const { control } = useForm();
      return (
        <MVInputController
          fieldName="testField"
          label="Test"
          control={control}
          trimOnBlur={true}
          trimType="leading"
        />
      );
    };

    render(<TestWrapperWithTrimType />);

    const input = screen.getByRole('textbox') as HTMLInputElement;

    input.focus();
    input.value = '  content  ';
    input.blur();

    await new Promise(resolve => setTimeout(resolve, 100));

    // Should only trim leading whitespace
    expect(input.value).toBe('content  ');
  });

  it('should handle trailing trim type on blur', async () => {
    const TestWrapperWithTrimType = () => {
      const { control } = useForm();
      return (
        <MVInputController
          fieldName="testField"
          label="Test"
          control={control}
          trimOnBlur={true}
          trimType="trailing"
        />
      );
    };

    render(<TestWrapperWithTrimType />);

    const input = screen.getByRole('textbox') as HTMLInputElement;

    input.focus();
    input.value = '  content  ';
    input.blur();

    await new Promise(resolve => setTimeout(resolve, 100));

    // Should only trim trailing whitespace
    expect(input.value).toBe('  content');
  });

  it('should not re-trigger trim if value is already trimmed', async () => {
    render(
      <TestWrapper>
        <MVInputController
          fieldName="testField"
          label="Test"
          trimOnBlur={true}
        />
      </TestWrapper>
    );

    const input = screen.getByRole('textbox') as HTMLInputElement;

    input.focus();
    input.value = 'already trimmed';
    input.blur();

    await new Promise(resolve => setTimeout(resolve, 100));

    expect(input.value).toBe('already trimmed');
  });

  // Test that the critical bug fix works - value doesn't clear after trimming
  it('should maintain value after trimming and not clear on subsequent blur', async () => {
    render(
      <TestWrapper>
        <MVInputController
          fieldName="testField"
          label="Test"
          trimOnBlur={true}
        />
      </TestWrapper>
    );

    const input = screen.getByRole('textbox') as HTMLInputElement;

    // First blur with whitespace - should trim
    input.focus();
    input.value = '  important data  ';
    input.blur();

    await new Promise(resolve => setTimeout(resolve, 100));
    expect(input.value).toBe('important data');

    // Second focus/blur - should NOT clear the value (this was the original bug)
    input.focus();
    input.blur();

    await new Promise(resolve => setTimeout(resolve, 100));
    expect(input.value).toBe('important data'); // This should NOT be empty
  });

  it('should render with trimOnPaste enabled without errors', () => {
    render(
      <TestWrapper>
        <MVInputController
          fieldName="testField"
          label="Test"
          trimOnPaste={true}
        />
      </TestWrapper>
    );

    expect(screen.getByRole('textbox')).toBeInTheDocument();
  });
});
