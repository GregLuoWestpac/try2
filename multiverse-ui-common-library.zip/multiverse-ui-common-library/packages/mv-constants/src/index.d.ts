export declare const SYDNEY_ZONE = 'Australia/Sydney';

// Mapping as per ERDM, any change in values needs to be in sync with ERDM
export declare enum APPROVAL_WORKFLOW_TYPE {
  PAYMENTS = 'w1cpayments',
  BENEFICIARY = 'w1cbeneficiary',
  ACCOUNT_WORKFLOW = 'w1caccountworkflow',
  TREASURY = 'w1climitcontrol',
  ENTITLEMENTS = 'w1centitlements',
  ACCOUNT_PAC = 'w1caccountpac',
}

// Mapping as per ERDM, any change in values needs to be in sync with ERDM
export declare enum APPROVAL_WORKFLOW_SUB_TYPE {
  PAYMENTS = 'payments',
  TRANSFERS = 'transfers',
  PAYMENT_RETURNS = 'initiatereturns',
  ADD_BENEFICIARY = 'addbeneficiary',
  AMEND_BENEFICIARY = 'amendbeneficiary',
  ARCHIVE_BENEFICIARY = 'archivebeneficiary',
  UPDATE_TAX_DETAILS_AND_MAILING_ADDRESS = 'updatetaxmaildetails',
  UPDATE_FSS_STATUS = 'updatefssstatus',
  UPDATE_TREASURY_LIMITS = 'updatetreasurylimits',
  UPDATE_RAG_RULES = 'updateragrules',
  UPDATE_ACCOUNT_NAME = 'updateaccname',
  UPDATE_PRODUCT_SWITCH = 'updateproductswitching',
  ADD_ACCOUNT_INDICATORS = 'addaccindicators',
  CREATE_CREDIT_INTEREST_OVERRIDES = 'addcrintoverrides',
  ADJUST_CREDIT_INTEREST_OVERRIDES = 'updatecrintoverrides',
  CREATE_ACCOUNT_ORDER = 'addaccorder',
  UPDATE_ACCOUNT_BLOCK_STATUS = 'addaccblockstatus',
  UPDATE_ACCOUNT_CLOSURE = 'updateaccclosure',
  ADD_ORG_CHANNEL_PAYMENT_LIMIT = 'addpaymentorgchnlimit',
  UPDATE_ORG_CHANNEL_PAYMENT_LIMIT = 'updatepaymentorgchnlimit',
  ADD_USER_PAYMENT_LIMIT = 'addpaymentuserlimit',
  UPDATE_USER_PAYMENT_LIMIT = 'updatepaymentuserlimit',
  ADD_ORG = 'addorg',
  ADD_ACCOUNT_GROUP = 'addaccgroup',
  MANAGE_ACCOUNT_GROUP = 'updateaccgroup',
  ADD_USER = 'adduser',
  MANAGE_USER_PERMISSION = 'updateuserpermission',
  MANAGE_AUTH_MODEL = 'updateauthmodel',
  MANAGE_DIVISION = 'updatedivision',
  NPP_AUTO_REPLAY = 'nppautoreplay',
}

export enum PAYID_TYPE {
  PHONE = 'TELI',
  EMAIL = 'EMAL',
  ABN_ACN = 'AUBN',
  ORGANISATION_ID = 'ORGN',
}

export enum BENEFICIARY_TYPE {
  ACCOUNT = 'BSB_ACCOUNT_NUMBER',
  PAYID = 'PAYID',
}

export enum HTTP_STATUS_CODES {
  OK = 200,
  CREATED = 201,
  ACCEPTED = 202,
  NO_CONTENT = 204,
  PARTIAL_CONTENT = 206,
  BAD_REQUEST = 400,
  UNAUTHORIZED = 401,
  FORBIDDEN = 403,
  NOT_FOUND = 404,
  METHOD_NOT_ALLOWED = 405,
  PAYLOAD_TOO_LARGE = 413,
  INTERNAL_SERVER_ERROR = 500,
  SERVICE_UNAVAILABLE = 503,
}

export type CURRENCY_CODE_TYPE = 'AUD' | 'USD' | 'NZD' | 'EUR' | 'SGD' | 'GBP';
