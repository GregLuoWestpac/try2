# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.229.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.229.0...v1.229.1) (2026-02-16)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-constants

## [1.219.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.218.0...v1.219.0) (2025-12-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-constants

## [1.216.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.215.1...v1.216.0) (2025-12-15)

### 🚀 Features

- add product switch sub type constant | ART-78294 ([be32ada](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/be32ada2eb58ff54fba81aaab31c15796ea3c937))

## [1.205.7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.205.6...v1.205.7) (2025-10-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-constants

## [1.186.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.186.1...v1.186.2) (2025-10-03)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-constants

## [1.184.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.183.0...v1.184.0) (2025-09-16)

### 🚀 Features

- added new constants to subtypes | ART-75298 ([3f069e9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/3f069e9a310b0425d7b08ca6452f61b46a3dba8d))

## [1.181.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.180.1...v1.181.0) (2025-09-03)

### 🚀 Features

- add TypeScript definitions for enum exports | ART-73895 ([5506330](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5506330b7d653b7015b8e0b2ced83013c1e2c0e9))

## [1.180.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.179.3...v1.180.0) (2025-09-02)

### 🚀 Features

- move mv-constants enum to type file to fix import errors | ART-73895 ([cd8d397](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/cd8d397bdb840dfe9bba0fed2456a6d00ca9c403))

## [1.179.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.178.12...v1.179.0) (2025-09-01)

### 🚀 Features

- add approval workflow types and subtypes | ART-73896 ([6ac3f6c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/6ac3f6c36b65907d2fabda6e7784743857d41a2a))
- update approvalworkflow type | ART-73896 ([bb3cf91](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/bb3cf91f90dc86090cab8e49345ad5bd0c89acd7))
