# Controller Architecture - BSB Lookup

## Overview

The `buildGetBsbLookupController` follows a modular architecture pattern designed to separate concerns and provide a reusable structure for building Express.js controllers with proper error handling, data transformation, and downstream service integration.

## Architecture Components

### 1. Core Handler Functions

Contains the business logic specific to the BSB lookup endpoint:

```typescript
export const getBsbLookupHandler = async (
  req: Request,
  res: Response,
  controllerParams: ControllerParams
): Promise<void> => {
  // Business logic implementation
  // - Set CORS headers for cross-origin requests
  // - Call downstream branch reference data service
  // - Transform response data to UI format
  // - Normalize data using mv-apiutils
  // - Send structured response
};
```

### 2. Generic Controller Wrapper

A reusable wrapper from `mv-apiutils` that handles error catching and Express.js middleware integration:

```typescript
export const createControllerWrapper = (
  handlerFn: ControllerHandler,
  controllerParams: ControllerParams
) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      await handlerFn(req, res, controllerParams);
    } catch (error) {
      const { logger } = res.locals;
      handleControllerError({ error, res, logger });
      next(error);
    }
  };
};
```

### 3. Controller Builder Functions

Combines the handler and wrapper for the BSB lookup endpoint:

```typescript
export const buildGetBsbLookupController = (
  controllerParams: ControllerParams
) => {
  return createControllerWrapper(getBsbLookupHandler, controllerParams);
};
```

### 4. Helper Functions

Specialized utility functions for data transformation:

```typescript
// Response transformation from downstream service to UI format
export const transformDownstreamResponseToUi = (
  response: DownstreamServiceResponseData
): ExpApiResponseData => {
  // Maps downstream branch data to UI-compatible format
  // Generates unique IDs for each BSB entry
  // Handles empty or malformed responses gracefully
  return { bsbLookup: mappedBsbLookupData };
};
```

## Data Flow Architecture

### Request Processing Pipeline

```mermaid
graph TD
    A[HTTP Request] --> B[Controller Wrapper]
    B --> C[getBsbLookupHandler]
    C --> D[Set CORS Headers]
    D --> E[handleApiService]
    E --> F[Downstream BSB Service]
    F --> G[transformDownstreamResponseToUi]
    G --> H[normaliseData]
    H --> I[HTTP Response]
```

### Component Interactions

1. **Request Entry**: HTTP request enters through Express middleware
2. **Controller Wrapper**: Generic error handling and middleware setup
3. **Handler Execution**: Core BSB lookup business logic
4. **Header Management**: CORS headers for cross-origin support
5. **Downstream Integration**: Call to branch reference data service
6. **Data Transformation**: Convert downstream format to UI format
7. **Data Normalization**: Standardize response structure
8. **Response Delivery**: Send formatted response to client

## Core Features

### Cross-Origin Resource Sharing (CORS)

The controller automatically sets appropriate CORS headers:

```typescript
res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);
```

This enables web applications from different origins to access the BSB lookup API.

### Downstream Service Integration

Utilizes the `handleApiService` utility for robust downstream API calls:

```typescript
const downstreamResponse: DownstreamServiceResponse = await handleApiService({
  req,
  res,
  apiClient: getBranchReferenceData,
});
```

Benefits:
- Automatic error handling
- Request/response logging
- Timeout management
- Retry logic (if configured)

### Data Transformation Layer

Implements a dedicated transformation layer to convert downstream service responses:

```typescript
const expApiResponseData: ExpApiResponseData =
  transformDownstreamResponseToUi(downstreamResponse.data);
```

Key transformation features:
- **UUID Generation**: Assigns unique IDs to each BSB entry
- **Data Mapping**: Maps downstream fields to UI-expected format
- **Null Safety**: Handles missing or undefined data gracefully
- **Default Values**: Provides fallback data for empty responses

### Response Normalization

Uses the `normaliseData` utility from `mv-apiutils` for consistent response structure:

```typescript
const normalisedData = normaliseData(
  'bsbLookup',
  expApiResponseData.bsbLookup,
  normalise
);
```

This ensures all API responses follow the same structural pattern across the application.

## Security Considerations

### Input Validation

While BSB lookup typically uses query parameters, the controller processes requests through the standardized `handleApiService` which includes:
- Parameter sanitization
- Request validation
- Logging for audit trails

### Error Information Disclosure

The controller uses structured error handling that prevents sensitive information leakage:
- Downstream service errors are logged but not exposed directly
- Generic error responses protect internal system details
- Request correlation IDs enable debugging without exposing sensitive data

## Performance Optimizations

### Response Caching

The controller supports HTTP caching headers through the `handleApiService` utility, allowing for:
- Browser-level caching of BSB data
- CDN caching for frequently requested BSBs
- Reduced load on downstream services

### Efficient Data Processing

- **Minimal Data Processing**: Only essential transformations are performed
- **Memory Efficiency**: Streaming approach where possible
- **Early Returns**: Error conditions short-circuit processing

## Extension Points

### Custom Transformation Logic

The transformation function can be extended for specific business requirements:

```typescript
// Custom transformation with additional business logic
export const customTransformDownstreamResponseToUi = (
  response: DownstreamServiceResponseData,
  customOptions?: TransformOptions
): ExpApiResponseData => {
  const baseTransformation = transformDownstreamResponseToUi(response);
  
  // Add custom business logic
  return enhanceWithBusinessRules(baseTransformation, customOptions);
};
```

### Additional Middleware

The controller can be wrapped with additional middleware for specific requirements:

```typescript
const enhancedBsbLookupController = [
  rateLimitingMiddleware,
  authenticationMiddleware,
  buildGetBsbLookupController(controllerParams),
  auditLoggingMiddleware
];
```

## Testing Strategy

### Unit Testing

Each component can be tested independently:
- Handler function testing with mocked dependencies
- Transformation function testing with various input scenarios
- Error handling testing with simulated failures

### Integration Testing

Full request-response cycle testing:
- End-to-end API testing
- Downstream service integration testing
- Error scenario testing

### Test Data Management

Structured test data for comprehensive coverage:
- Valid BSB responses
- Empty response scenarios
- Malformed data handling
- Network error conditions

## Monitoring and Observability

### Logging

Structured logging at key points:
- Request initiation
- Downstream service calls
- Data transformation steps
- Error conditions
- Response completion

### Metrics

Key metrics for monitoring:
- Request throughput
- Response times
- Error rates
- Downstream service health

### Health Checks

Controller health can be monitored through:
- Downstream service availability
- Response time thresholds
- Error rate monitoring