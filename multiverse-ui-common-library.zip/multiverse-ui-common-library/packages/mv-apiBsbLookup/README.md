# @mesh-tenant-multiverse-ui-common/mv-apiBsbLookup

A specialized utility library for BSB (Bank State Branch) Lookup API operations, designed for use within the Multiverse UI Common Library ecosystem. This package provides robust BSB lookup controller logic, data transformation, and error handling for Express-based APIs.

## Features

- **BSB Lookup Controller**: Ready-to-use Express controller for BSB lookup endpoints
- **Branch Reference Data Integration**: Handles downstream BSB lookup API calls and response transformation
- **Data Normalization**: Structured data normalization for consistent API responses
- **Error Handling**: Comprehensive error handling with logging support
- **Environment Configuration**: Support for local development and production environments
- **Cross-Origin Support**: Built-in CORS header management

## Installation

```bash
npm install @mesh-tenant-multiverse-ui-common/mv-apiBsbLookup
npm install @mesh-tenant-multiverse-ui-common/mv-apiutils  # Required peer dependency
```

## Usage

### Basic BSB Lookup Controller

The package provides a ready-to-use controller for BSB lookup endpoints:

```typescript
import { buildGetBsbLookupController } from '@mesh-tenant-multiverse-ui-common/mv-apiBsbLookup';
import { ControllerParams } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

// Define controller parameters
const controllerParams: ControllerParams = {
  RUNTIME: runtimeConfig,
  normalise: normalizeFunction,
  apiClient: {
    getBranchReferenceData: downstreamApiClient,
  },
  readMeshSecrets: secretsReader,
};

// Create the BSB lookup controller
const bsbLookupController = buildGetBsbLookupController(controllerParams);

// Use in Express routes
app.get('/api/bsb-lookup', bsbLookupController);
```

### Custom BSB Lookup Handler

For more control over the BSB lookup process, you can use the handler directly:

```typescript
import { 
  getBsbLookupHandler,
  transformDownstreamResponseToUi 
} from '@mesh-tenant-multiverse-ui-common/mv-apiBsbLookup';

// Custom middleware with the handler
const customBsbLookupMiddleware = async (req, res, next) => {
  try {
    // Custom pre-processing logic here
    
    // Use the core handler
    await getBsbLookupHandler(req, res, controllerParams);
    
    // Custom post-processing logic here
  } catch (error) {
    next(error);
  }
};
```

### Response Transformation

Transform downstream service responses to UI-compatible format:

```typescript
import { transformDownstreamResponseToUi } from '@mesh-tenant-multiverse-ui-common/mv-apiBsbLookup';

// Transform raw downstream response
const downstreamData = await getBranchReferenceData(queryParams);
const transformedData = transformDownstreamResponseToUi(downstreamData);

// transformedData structure:
// {
//   bsbLookup: [
//     {
//       id: "uuid-generated-id",
//       bankName: "Bank Name",
//       // ... other branch properties
//     }
//   ]
// }
```

## API Reference

### Controllers

#### `buildGetBsbLookupController(controllerParams: ControllerParams)`

Creates a complete Express middleware for BSB lookup operations.

**Parameters:**
- `controllerParams` - Configuration object containing:
  - `RUNTIME` - Runtime environment configuration
  - `normalise` - Data normalization function
  - `apiClient.getBranchReferenceData` - Downstream API client
  - `readMeshSecrets` - Secrets management function

**Returns:** Express middleware function

#### `getBsbLookupHandler(req: Request, res: Response, controllerParams: ControllerParams)`

Core handler function for BSB lookup operations.

**Parameters:**
- `req` - Express request object
- `res` - Express response object  
- `controllerParams` - Controller configuration

**Returns:** Promise<void>

### Utilities

#### `transformDownstreamResponseToUi(response: DownstreamServiceResponseData)`

Transforms downstream service response to UI-compatible format.

**Parameters:**
- `response` - Raw downstream service response

**Returns:** Transformed data with BSB lookup structure

## Data Flow

1. **Request Processing**: Controller receives BSB lookup request
2. **Downstream API Call**: Calls branch reference data service
3. **Data Transformation**: Converts downstream response to UI format
4. **Data Normalization**: Normalizes response using mv-apiutils
5. **Response**: Returns formatted BSB lookup data

## Response Format

The controller returns normalized BSB lookup data in the following structure:

```typescript
{
  result: {
    bsbLookup: [
      {
        id: string,           // UUID generated for each entry
        bankName: string,     // Bank/Institution name
        // Additional branch properties as returned by downstream service
      }
    ]
  },
  pagination: {
    // Pagination metadata if applicable
  }
}
```

## Error Handling

The package includes comprehensive error handling:

- **Network Errors**: Handles downstream service failures
- **Data Transformation Errors**: Graceful handling of malformed responses
- **Validation Errors**: Input parameter validation
- **Logging**: Structured error logging for debugging

## Environment Support

### Local Development

Supports local development with mock configurations and test data.

### Production

Optimized for production environments with proper error handling and logging.

## Dependencies

- `@mesh-tenant-multiverse-ui-common/mv-apiutils` - Core API utilities and types
- `uuid` - UUID generation for response data
- `express` - Web framework types (peer dependency)

## Testing

The package includes comprehensive test coverage:

```bash
# Run tests
npm test

# Run tests with coverage
npm run test:coverage
```

## Contributing

Please refer to the main multiverse-ui-common-library contributing guidelines.

## License

UNLICENSED - Internal Westpac use only.

## Changelog

See [CHANGELOG.md](./CHANGELOG.md) for version history and changes.

## Architecture

See [ARCHITECTURE.md](./ARCHITECTURE.md) for detailed architectural documentation.