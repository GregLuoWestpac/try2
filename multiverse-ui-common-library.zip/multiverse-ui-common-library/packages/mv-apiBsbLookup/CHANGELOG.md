# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.219.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.0...v1.219.1) (2025-12-19)

### 💥 Bug Fixes

- add back deleted files | ART-88711 ([9b541f6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9b541f66f1babf412fa5f9f318b3533504b1ee0e))

## [1.213.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.212.0...v1.213.0) (2025-12-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiBsbLookup

## [1.212.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.211.0...v1.212.0) (2025-12-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiBsbLookup

## [1.209.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.209.0...v1.209.1) (2025-11-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiBsbLookup

## [1.209.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.208.0...v1.209.0) (2025-11-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiBsbLookup

## [1.208.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.207.0...v1.208.0) (2025-10-31)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiBsbLookup

## [1.193.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.192.2...v1.193.0) (2025-10-13)

### 🚀 Features

- Initial release of mv-apiBsbLookup package with BSB lookup controller | ART-74368 ([fd9f36f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/fd9f36f26e6bb2103d0dcc1bf2821bb114710264))
- update version to 0.0.0, enhance error handling, and improve test coverage for BSB lookup controller | ART-74368 ([0ea9fb1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/0ea9fb12be2c2b573a8196819b58d2333f544a66))

## [1.0.0] (2025-10-13)

### 🎉 Initial Release

- Initial release of mv-apiBsbLookup package
- BSB lookup controller with downstream service integration
- Data transformation utilities for branch reference data
- TypeScript support with comprehensive type definitions
- Express middleware integration with error handling
- CORS support for cross-origin requests

### ✨ Features

- **BSB Lookup Controller**: Ready-to-use Express controller for BSB lookup endpoints
- **Branch Reference Data Integration**: Seamless integration with downstream BSB services
- **Data Transformation**: Robust transformation layer converting downstream responses to UI format
- **UUID Generation**: Automatic unique ID assignment for BSB entries
- **Error Handling**: Comprehensive error handling with structured logging
- **CORS Support**: Built-in cross-origin resource sharing headers
- **Response Normalization**: Consistent API response structure using mv-apiutils

### 🏗️ Architecture

- Modular controller architecture with separated concerns
- Reusable controller wrapper pattern from mv-apiutils
- Dedicated helper functions for data transformation
- Type-safe implementations with full TypeScript support

### 🔧 Technical Implementation

- `getBsbLookupHandler`: Core business logic for BSB lookup operations
- `buildGetBsbLookupController`: Factory function for Express middleware creation
- `transformDownstreamResponseToUi`: Data transformation utilities
- Comprehensive test coverage with unit and integration tests

### 📦 Dependencies

- `@mesh-tenant-multiverse-ui-common/mv-apiutils`: ^1.186.1
- `uuid`: For unique identifier generation
- `express`: Peer dependency for HTTP request/response handling

### 🧪 Testing

- Unit tests for controller logic
- Integration tests for end-to-end functionality
- Test coverage for error scenarios and edge cases
- Mock implementations for downstream services
