import { Request, Response, NextFunction } from 'express';
import { ControllerParams } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

export const buildGetBsbLookupController: (
  controllerParams: ControllerParams
) => (req: Request, res: Response, next: NextFunction) => Promise<void>;
