/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { Request, Response } from 'express';
import {
  DownstreamServiceResponse,
  handleApiService,
  normaliseData,
  STATUS_CODES,
  ControllerParams,
  accessControlExposeHeaders,
  createControllerWrapper,
  APIClientError,
  handleControllerError,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import {
  BsbLookupItem,
  ExpApiResponseData,
  transformDownstreamResponseToUi,
} from './getBsbLookupController.helper';

/**
 * getBsbLookupController
 * @param {object} req - Implicit HTTP request object based on http.IncomingMessage
 * @param {object} res - Implicit HTTP response object based on http.ServerResponse
 */
export const getBsbLookupHandler = async (
  req: Request,
  res: Response,
  controllerParams: ControllerParams
) => {
  const { logger } = res.locals;
  const { normalise, apiClient } = controllerParams;

  const { getBranchReferenceData } = apiClient;
  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);
  try {
    const downstreamResponse: DownstreamServiceResponse =
      await handleApiService({
        req,
        res,
        apiClient: getBranchReferenceData,
      });

    const branches = downstreamResponse?.data?.data
      ?.branches as BsbLookupItem[];
    if (!branches || branches.length === 0) {
      res.status(404).end();
    }
    const expApiResponseData: ExpApiResponseData =
      transformDownstreamResponseToUi(downstreamResponse.data);

    const normalisedData = normaliseData(
      'bsbLookup',
      expApiResponseData.bsbLookup,
      normalise
    );

    res.status(STATUS_CODES.OK).json(normalisedData).end();
  } catch (error: unknown) {
    handleControllerError({ error: error as APIClientError, res, logger });
  }
};
export const buildGetBsbLookupController = (
  controllerParams: ControllerParams
) => {
  return createControllerWrapper(getBsbLookupHandler, controllerParams);
};
