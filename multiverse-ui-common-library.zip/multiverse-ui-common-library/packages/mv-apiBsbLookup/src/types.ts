export interface GetBsbLookupData {
  entities?: {
    bsbLookup?: {
      /**
       * A unique id generated for a lookup result which is the mode of communication between the UI and Exp API
       * @format uuid
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * Represents the branch Id for which the reference data is to be retrieved
       * @minLength 1
       * @maxLength 30
       * @pattern ^[\w ]+$
       * @example "501226"
       */
      branchId?: string;
      /**
       * Bank State Branch Number
       * @pattern ^\d{6}$
       * @example "035845"
       */
      BSB?: string;
      /**
       * Name of the Branch
       * @minLength 1
       * @maxLength 70
       * @pattern ^[\w ]+$
       * @example "Central"
       */
      branchName?: string;
      /**
       * Name of the Bank
       * @minLength 1
       * @maxLength 70
       * @pattern ^[\w ]+$
       * @example "Central Bank"
       */
      bankName?: string;
      /**
       * Branch Identification code
       * @minLength 1
       * @maxLength 70
       * @pattern ^[\w ]+$
       * @example "03"
       */
      bankCode?: string;
      /**
       * A set of available predefined values representing the label names used by Westpac for its products and services
       * @example "WBC"
       */
      brand?: 'WBC' | 'SGB' | 'BOM' | 'BSA';
      /**
       * Status of the Branch
       * @example "OPERATIONAL"
       */
      branchStatus?: 'OPERATIONAL' | 'CLOSED';
      /**
       * Branch Available indicate if the BSB is valid for origination
       * @example true
       */
      branchAvailable?: boolean;
      /** Address of the Branch */
      address?: {
        /**
         * First line of the address
         * @minLength 1
         * @maxLength 100
         * @pattern ^[\w ]+$
         * @example "123 Main St"
         */
        addressLine1?: string;
        /**
         * Second line of the address
         * @minLength 0
         * @maxLength 100
         * @pattern ^[\w ]+$
         * @example "Suite 456"
         */
        addressLine2?: string;
        /**
         * City of the address
         * @minLength 1
         * @maxLength 50
         * @pattern ^[\w ]+$
         * @example "Sydney"
         */
        city?: string;
        /**
         * State of the address
         * @minLength 1
         * @maxLength 50
         * @pattern ^[\w ]+$
         * @example "NSW"
         */
        state?: string;
        /**
         * Postal code of the address
         * @minLength 4
         * @maxLength 10
         * @pattern ^[\d]+$
         * @example "2000"
         */
        postCode?: string;
      };
    }[];
  };
  /** @example {"bsbLookup":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    bsbLookup?: string[];
  };
}

export type ExpApiResponseData = GetBsbLookupData['entities'];
