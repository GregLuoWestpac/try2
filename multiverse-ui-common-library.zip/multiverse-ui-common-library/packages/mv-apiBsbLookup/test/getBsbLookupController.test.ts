/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response } from 'express';
import {
  handleApiService,
  handleControllerError,
  normaliseData,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import {
  buildGetBsbLookupController,
  getBsbLookupHandler,
} from '../src/getBsbLookupController';
import { transformDownstreamResponseToUi } from '../src/getBsbLookupController.helper';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  normaliseData: jest.fn(),
  STATUS_CODES: { OK: 200 },
  handleControllerError: jest.fn(),
  handleApiService: jest.fn(),
  accessControlExposeHeaders: 'X-Custom-Header',
  createControllerWrapper: jest.fn((handlerFn, params) => {
    // Return a mock Express middleware function
    return jest.fn(async (req, res) => {
      try {
        // Call the original handler function for testing
        await handlerFn(req, res, params);
      } catch (error) {
        // Handle error appropriately
        console.error(error);
      }
    });
  }),
}));

jest.mock('../src/getBsbLookupController.helper', () => ({
  transformDownstreamResponseToUi: jest.fn(),
}));

describe('getBsbLookupController', () => {
  let mockReq: Partial<Request>;
  let mockRes: Partial<Response>;
  let controllerParams: any;

  beforeEach(() => {
    mockReq = {
      query: { bsb: '123456' },
    };

    mockRes = {
      locals: {
        logger: {
          error: jest.fn(),
          info: jest.fn(),
          debug: jest.fn(),
        },
      },
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      setHeader: jest.fn(),
      end: jest.fn(),
    };

    controllerParams = {
      RUNTIME: {
        isLocal: jest.fn().mockReturnValue(false),
      },
      normalise: {},
      apiClient: {
        getBranchReferenceData: jest.fn(),
      },
      readMeshSecrets: jest.fn().mockReturnValue({
        pdpClientToken: 'test-token',
      }),
    };

    jest.clearAllMocks();
  });

  describe('getBsbLookupHandler', () => {
    describe('buildGetBsbLookupController', () => {
      it('should build controller using createControllerWrapper', () => {
        const controller = buildGetBsbLookupController(controllerParams);
        expect(controller).toBeDefined();
        expect(typeof controller).toBe('function');
      });
    });

    it('should return normalized data when downstream API succeeds', async () => {
      const mockDownstreamResponse = {
        data: {
          branches: [
            {
              branchId: '123',
              BSB: '123456',
              branchName: 'Test Branch',
              bankName: 'Test Bank',
            },
          ],
        },
      };

      const mockTransformedData = {
        bsbLookup: [
          {
            branchId: '123',
            BSB: '123456',
            branchName: 'Test Branch',
            bankName: 'Test Bank',
          },
        ],
      };
      const mockNormalizedData = {
        entities: {
          bsbLookup: [
            {
              branchId: '123',
              BSB: '123456',
              branchName: 'Test Branch',
              bankName: 'Test Bank',
            },
          ],
        },
      };

      (handleApiService as jest.Mock).mockResolvedValue(mockDownstreamResponse);
      (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
        mockTransformedData
      );
      (normaliseData as jest.Mock).mockReturnValue(mockNormalizedData);

      await getBsbLookupHandler(
        mockReq as Request,
        mockRes as Response,
        controllerParams
      );

      expect(handleApiService).toHaveBeenCalledWith({
        req: mockReq,
        res: mockRes,
        apiClient: controllerParams.apiClient.getBranchReferenceData,
      });
      expect(transformDownstreamResponseToUi).toHaveBeenCalledWith(
        mockDownstreamResponse.data
      );
      expect(normaliseData).toHaveBeenCalledWith(
        'bsbLookup',
        mockTransformedData.bsbLookup,
        controllerParams.normalise
      );
      expect(mockRes.status).toHaveBeenCalledWith(200);
      expect(mockRes.json).toHaveBeenCalledWith(mockNormalizedData);
      expect(mockRes.end).toHaveBeenCalled();
    });

    it('should return 404 when no branches are found', async () => {
      const mockDownstreamResponseEmpty = {
        data: {
          data: {
            branches: [], // Empty branches array
          },
        },
      };

      (handleApiService as jest.Mock).mockResolvedValue(
        mockDownstreamResponseEmpty
      );

      await getBsbLookupHandler(
        mockReq as Request,
        mockRes as Response,
        controllerParams
      );

      expect(handleApiService).toHaveBeenCalledWith({
        req: mockReq,
        res: mockRes,
        apiClient: controllerParams.apiClient.getBranchReferenceData,
      });
      expect(mockRes.status).toHaveBeenCalledWith(404);
      expect(mockRes.end).toHaveBeenCalled();
    });

    it('should return 404 when branches data is undefined', async () => {
      const mockDownstreamResponseUndefined = {
        data: {
          data: {
            // branches property is missing
          },
        },
      };

      (handleApiService as jest.Mock).mockResolvedValue(
        mockDownstreamResponseUndefined
      );

      await getBsbLookupHandler(
        mockReq as Request,
        mockRes as Response,
        controllerParams
      );

      expect(handleApiService).toHaveBeenCalledWith({
        req: mockReq,
        res: mockRes,
        apiClient: controllerParams.apiClient.getBranchReferenceData,
      });
      expect(mockRes.status).toHaveBeenCalledWith(404);
      expect(mockRes.end).toHaveBeenCalled();
    });

    it('should handle error response', async () => {
      const error = new Error('Test error');
      (handleApiService as jest.Mock).mockRejectedValue(error);

      await getBsbLookupHandler(
        mockReq as Request,
        mockRes as Response,
        controllerParams
      );

      expect(handleControllerError).toHaveBeenCalledWith({
        error,
        res: mockRes,
        logger: mockRes.locals.logger,
      });
    });
  });
});
