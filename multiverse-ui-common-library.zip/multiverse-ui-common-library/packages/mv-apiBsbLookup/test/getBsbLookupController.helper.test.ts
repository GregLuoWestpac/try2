/* eslint-disable @typescript-eslint/no-explicit-any */
import { DownstreamServiceResponseData } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import {
  transformDownstreamResponseToUi,
  ExpApiResponseData,
} from '../src/getBsbLookupController.helper';

// Mock uuid to always return the same value
jest.mock('uuid', () => ({
  v4: jest.fn(() => 'mock-uuid'),
}));

describe('transformDownstreamResponseToUi', () => {
  it('should transform downstream response to UI format', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '123',
            BSB: '123456',
            branchName: 'Test Branch',
            bankName: 'Test Bank',
            bankCode: '03',
            brand: 'WBC',
            branchStatus: 'OPERATIONAL',
            branchAvailable: true,
            address: {
              addressLine1: '123 Main St',
              city: 'Sydney',
              state: 'NSW',
              postCode: '2000',
            },
          },
        ],
      },
    };

    const expectedTransformedData: ExpApiResponseData = {
      bsbLookup: [
        {
          id: 'mock-uuid',
          branchId: '123',
          BSB: '123456',
          branchName: 'Test Branch',
          bankName: 'Test Bank',
          bankCode: '03',
          brand: 'WBC',
          branchStatus: 'OPERATIONAL',
          branchAvailable: true,
          address: {
            addressLine1: '123 Main St',
            city: 'Sydney',
            state: 'NSW',
            postCode: '2000',
          },
        },
      ],
    };

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual(expectedTransformedData);
  });

  it('should handle empty branches array', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {
      data: {
        branches: [],
      },
    };

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should handle missing branches property', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {
      data: {},
    };

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should handle null branches', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {
      data: {
        branches: null,
      },
    };

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should handle missing data property', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {} as any;

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should map branch with missing bankName to default value', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '456',
            BSB: '654321',
            branchName: 'Another Branch',
            // bankName is missing
            bankCode: '04',
            brand: 'ANZ',
            branchStatus: 'CLOSED',
            branchAvailable: false,
          },
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          branchId: '456',
          BSB: '654321',
          branchName: 'Another Branch',
          bankName: undefined,
          bankCode: '04',
          brand: 'ANZ',
          branchStatus: 'CLOSED',
          branchAvailable: false,
        },
      ],
    });
  });

  it('should map multiple branches correctly', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '789',
            BSB: '789012',
            branchName: 'First Branch',
            bankName: 'First Bank',
            bankCode: '05',
            brand: 'NAB',
          },
          {
            branchId: '890',
            BSB: '890123',
            branchName: 'Second Branch',
            // bankName is missing for this one
            bankCode: '06',
            brand: 'CBA',
          },
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          branchId: '789',
          BSB: '789012',
          branchName: 'First Branch',
          bankName: 'First Bank',
          bankCode: '05',
          brand: 'NAB',
        },
        {
          id: 'mock-uuid',
          branchId: '890',
          BSB: '890123',
          branchName: 'Second Branch',
          bankName: undefined,
          bankCode: '06',
          brand: 'CBA',
        },
      ],
    });
  });

  it('should handle when response.data.branches is not an array', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {
      data: {
        branches: 'not-an-array' as any, // Non-array value
      },
    };

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should handle branch with existing bankName and preserve it', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '999',
            BSB: '999999',
            branchName: 'Existing Bank Branch',
            bankName: 'Existing Bank Name', // This should be preserved
            bankCode: '07',
            brand: 'TEST',
          },
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          branchId: '999',
          BSB: '999999',
          branchName: 'Existing Bank Branch',
          bankName: 'Existing Bank Name',
          bankCode: '07',
          brand: 'TEST',
        },
      ],
    });
  });

  it('should handle response with valid branches array (covering Array.isArray true branch)', () => {
    // This test specifically targets the Array.isArray(response?.data?.branches) true branch
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '123',
            BSB: '123456',
            branchName: 'Valid Branch',
            bankName: 'Valid Bank',
          },
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result.bsbLookup).toHaveLength(1);
    expect(result.bsbLookup[0]).toEqual({
      id: 'mock-uuid',
      branchId: '123',
      BSB: '123456',
      branchName: 'Valid Branch',
      bankName: 'Valid Bank',
    });
  });

  it('should test branch?.bankName truthiness in mapping', () => {
    // This test specifically ensures both truthy and falsy branch?.bankName paths are hit
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '1',
            bankName: '', // Falsy bankName
          },
          {
            branchId: '2',
            bankName: null, // Falsy bankName
          },
          {
            branchId: '3',
            bankName: undefined, // Falsy bankName
          },
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result.bsbLookup).toHaveLength(3);
    expect(result.bsbLookup[0].bankName).toBe(''); // Empty string preserved
    expect(result.bsbLookup[1].bankName).toBe(null); // null preserved
    expect(result.bsbLookup[2].bankName).toBe(undefined); // undefined preserved
  });

  it('should handle response where data exists but branches is undefined', () => {
    // This should specifically test the response?.data part of the conditional
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        // branches property doesn't exist at all
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should handle response where data is undefined but response exists', () => {
    // This should test the response?.data?.branches chain
    const mockResponse: DownstreamServiceResponseData = {
      // data property doesn't exist
    } as any;

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should cover false branch when response is completely undefined', () => {
    // This targets the Array.isArray(response?.data?.branches) false branch
    const result = transformDownstreamResponseToUi(undefined as any);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should cover false branch when branches is a primitive value', () => {
    // This specifically targets Array.isArray() returning false
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: 'string-instead-of-array' as any,
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should cover branch where bankName is explicitly false', () => {
    // This targets the branch?.bankName || fallback branch more explicitly
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '1',
            bankName: false as any, // Explicitly falsy value
          },
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          branchId: '1',
          bankName: false,
        },
      ],
    });
  });

  it('should cover branch where bankName is 0', () => {
    // This targets another falsy value for branch?.bankName ||
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '1',
            bankName: 0 as any, // Falsy number
          },
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          branchId: '1',
          bankName: 0,
        },
      ],
    });
  });

  it('should ensure truthy bankName preserves original value', () => {
    // This ensures the truthy branch of branch?.bankName || is covered
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '1',
            bankName: 'Valid Bank Name', // Truthy value
          },
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          branchId: '1',
          bankName: 'Valid Bank Name',
        },
      ],
    });
  });

  it('should handle branch object that is null', () => {
    // This tests the branch? optional chaining
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [null as any], // null branch
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should handle branch object that is undefined', () => {
    // This tests the branch? optional chaining
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [undefined as any], // undefined branch
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should handle array with mixed valid and invalid branches', () => {
    // This targets the Array.isArray true branch with edge cases
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '1',
            bankName: 'Valid Bank',
          },
          null, // invalid branch
          {
            branchId: '2',
            // no bankName property
          },
        ] as any,
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result.bsbLookup).toHaveLength(3);
    expect(result.bsbLookup[0]).toEqual({
      id: 'mock-uuid',
      branchId: '1',
      bankName: 'Valid Bank',
    });
    expect(result.bsbLookup[1]).toEqual({
      id: 'mock-uuid',
      bankName: undefined,
    });
    expect(result.bsbLookup[2]).toEqual({
      id: 'mock-uuid',
      branchId: '2',
      bankName: undefined,
    });
  });

  it('should handle response.data.branches as empty array specifically', () => {
    // This specifically tests when Array.isArray returns true for an empty array
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [], // Empty array - Array.isArray should return true
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should handle array with truthy and falsy bankName values to test branch coverage', () => {
    // This specifically tests both branches of the branch?.bankName || expression
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          { branchId: '1', bankName: 'Truthy Bank' }, // truthy branch
          { branchId: '2' }, // falsy branch (no bankName)
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result.bsbLookup).toHaveLength(2);
    expect(result.bsbLookup[0]).toEqual({
      id: 'mock-uuid',
      branchId: '1',
      bankName: 'Truthy Bank', // preserved truthy value
    });
    expect(result.bsbLookup[1]).toEqual({
      id: 'mock-uuid',
      branchId: '2',
      bankName: undefined, // fallback for falsy value
    });
  });
});
