# @mesh-tenant-multiverse-ui-common/mv-aicommonsetup

AI Common Setup - Install AI agents and tooling from the ai-common repository via npx.

## Quick Start

Run the installer directly with npx (no installation required):

```bash
npx @mesh-tenant-multiverse-ui-common/mv-aicommonsetup
```

This will install all enabled AI agents configured for your project type.

## Prerequisites

### BITBUCKET_PAT Token

The installer requires a `BITBUCKET_PAT` environment variable to download files from the private ai-common repository.

#### Setting up your token

**1. Create a Personal Access Token:**
- Visit https://bitbucket.srv.westpac.com.au
- Click your profile → Manage account → Personal access tokens
- Create a token with "Read" permissions for repositories

**2. Set the environment variable:**

**Windows PowerShell:**
```powershell
# Add to your PowerShell profile ($PROFILE)
$env:BITBUCKET_PAT="your-token-here"

# Or set it system-wide in System Properties > Environment Variables
```

**Windows Git Bash:**
```bash
# Add to ~/.bashrc
export BITBUCKET_PAT="your-token-here"

# Reload
source ~/.bashrc
```

**macOS/Linux:**
```bash
# Add to ~/.zshrc or ~/.bashrc or ~/.bash_profile
export BITBUCKET_PAT="your-token-here"

# Reload your shell
source ~/.zshrc  # or your profile file
```

## Usage

### Install all enabled agents

Install all agents that are enabled and match your project type (defaults to `generic` target):

```bash
npx @mesh-tenant-multiverse-ui-common/mv-aicommonsetup
```

### Install a specific agent

Install only the specified agent:

```bash
npx @mesh-tenant-multiverse-ui-common/mv-aicommonsetup code-review
```

### Target filtering

Use the `--target` flag to filter agents, files, and actions by project type:

```bash
# Install agents configured for MFE projects
npx @mesh-tenant-multiverse-ui-common/mv-aicommonsetup --target=mfe

# Install code-review agent with SPA-specific configuration
npx @mesh-tenant-multiverse-ui-common/mv-aicommonsetup code-review --target=spa
```

**Common targets:**
- `generic` - Default, works for all project types
- `mfe` - Micro-frontend projects
- `spa` - Single-page applications
- `widget` - Widget projects
- `api` - API/backend projects

### List available agents

See all available agents with their status and target platforms:

```bash
npx @mesh-tenant-multiverse-ui-common/mv-aicommonsetup --list
```

### Help

Display detailed help information:

```bash
npx @mesh-tenant-multiverse-ui-common/mv-aicommonsetup --help
```

## Available Agents

The package includes configuration for the following agents:

- **code-review** - Automated PR review with AI
  - Downloads PR review tooling to `tools/pr-review/`
  - Installs agent definitions to `.github/agents/`
  - Installs prompts to `.github/prompts/`
  - Installs skills to `.github/skills/`
  - Optionally sets up pre-push hooks (for spa/mfe/widget targets)

More agents can be added by updating the ai-common-config.json in the ai-common repository.

## What Gets Installed

When you run the installer, it will:

1. **Download files** from the ai-common repository
   - Agent definitions (`.github/agents/`)
   - Prompts (`.github/prompts/`)
   - Skills (`.github/skills/`)
   - Tool directories (e.g., `tools/pr-review/`)

2. **Execute actions** defined in the agent configuration
   - Run `npm install` for tools that require dependencies
   - Create configuration files (e.g., `pr_review_bot.yaml.local`)
   - Update `.gitignore` with necessary exclusions
   - Set up git hooks (if applicable to your project type)
   - Make scripts executable (Unix/Linux/macOS)

3. **Validate tokens** (if configured)
   - Verify required environment variables are set
   - Check token validity using validation scripts

## Troubleshooting

### "BITBUCKET_PAT not set"

The `BITBUCKET_PAT` environment variable is required. See [Prerequisites](#prerequisites) above for setup instructions.

### "Config not found"

This should not happen with the npm package. If you see this error, the package may be corrupted. Try:
```bash
npm cache clean --force
npx @mesh-tenant-multiverse-ui-common/mv-aicommonsetup
```

### File download failures

If specific files fail to download:
- Verify your BITBUCKET_PAT token is valid and hasn't expired
- Check your network connection
- Ensure you have access to the ai-common repository

### Permission errors (Unix/Linux/macOS)

If you see "Permission denied" errors, the installer may have failed to make scripts executable. Run:
```bash
chmod +x tools/pr-review/cli.js
chmod +x .husky/pre-push
# etc.
```

## Package vs. Source Repository

This npm package is a **distribution package** that makes the ai-common setup tooling easily accessible via npx.

- **Source of truth**: The ai-common repository contains the original source code and agent configurations
- **This package**: Bundles the install-agent tooling for convenient distribution
- **Updates**: When agents are updated in ai-common, this package is republished with the new configuration

## Development

### Local testing

To test the package locally before publishing:

```bash
# In the multiverse-ui-common-library/packages/mv-aicommonsetup directory
npm link

# In another project directory
npx @mesh-tenant-multiverse-ui-common/mv-aicommonsetup --help
```

### Publishing

This package is published to the internal Artifactory registry as part of the multiverse-ui-common-library release process:

```bash
# From the repository root
npm run release
```

## Related

- **ai-common repository**: Source repository containing agents, workflows, and tools
- **multiverse-ui-common-library**: Parent monorepo containing shared UI components and utilities

## Support

For issues or questions:
- Check the ai-common repository documentation
- Contact the AI/Copilot team
- Create an issue in the ai-common or multiverse-ui-common-library repository

## License

UNLICENSED - Internal use only within Westpac organization.
