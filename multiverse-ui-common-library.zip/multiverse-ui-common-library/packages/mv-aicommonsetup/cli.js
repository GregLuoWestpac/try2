#!/usr/bin/env node
/**
 * CLI Wrapper for mv-aicommonsetup
 *
 * This script allows running the AI Common setup tooling via npx:
 *   npx @mesh-tenant-multiverse-ui-common/mv-aicommonsetup
 *
 * It delegates to the install-agent.js script from ai-common repository.
 */

/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path');
const fs = require('fs');

// Resolve the install-agent.js from the package
const installAgentPath = path.join(__dirname, 'src', 'install-agent.js');

// Verify the install-agent.js exists
if (!fs.existsSync(installAgentPath)) {
  console.error('\n❌ Error: install-agent.js not found in package');
  console.error(`Expected location: ${installAgentPath}\n`);
  process.exit(1);
}

// Load and execute install-agent.js
try {
  const installAgent = require(installAgentPath);
  // Explicitly call main() since this module is loaded via require()
  // and won't trigger the "require.main === module" check
  if (installAgent.main) {
    installAgent.main();
  } else {
    throw new Error('main() function not exported from install-agent.js');
  }
} catch (error) {
  console.error('\n❌ Fatal error:', error.message);
  if (error.stack) {
    console.error('\nStack trace:');
    console.error(error.stack);
  }
  console.error('');
  process.exit(1);
}
