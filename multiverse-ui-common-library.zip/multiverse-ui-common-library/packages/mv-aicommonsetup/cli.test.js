/* eslint-disable @typescript-eslint/no-var-requires */
/**
 * Comprehensive test suite for cli.js
 *
 * Purpose: Ensure that cli.js properly loads and executes install-agent.js
 * Critical requirement: cli.js must call the main() function exported from install-agent.js
 *
 * Context: When a module is loaded via require(), it doesn't trigger the
 * "require.main === module" check, so cli.js must explicitly invoke main().
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

describe('cli.js', () => {
  const cliPath = path.join(__dirname, 'cli.js');
  const installAgentPath = path.join(__dirname, 'src', 'install-agent.js');

  beforeAll(() => {
    // Ensure the files exist before running tests
    expect(fs.existsSync(cliPath)).toBe(true);
    expect(fs.existsSync(installAgentPath)).toBe(true);
  });

  describe('Critical Requirement: main() function invocation', () => {
    test('cli.js must explicitly call main() from install-agent.js', () => {
      const cliContent = fs.readFileSync(cliPath, 'utf8');

      // Verify that cli.js requires install-agent.js
      expect(cliContent).toMatch(/require\(installAgentPath\)/);

      // CRITICAL: Verify that main() is explicitly called
      // This prevents regression of the original bug where main() was never executed
      expect(cliContent).toMatch(/\.main\(\)/);
    });

    test('cli.js must check if main() function exists before calling', () => {
      const cliContent = fs.readFileSync(cliPath, 'utf8');

      // Verify defensive programming: check if main exists before calling
      expect(cliContent).toMatch(/if\s*\(\s*\w+\.main\s*\)/);
    });

    test('cli.js must handle missing main() function gracefully', () => {
      const cliContent = fs.readFileSync(cliPath, 'utf8');

      // Verify error handling for missing main() function
      expect(cliContent).toMatch(/throw new Error.*main.*not exported/i);
    });
  });

  describe('Module loading and execution', () => {
    test('cli.js must store the required module in a variable', () => {
      const cliContent = fs.readFileSync(cliPath, 'utf8');

      // Verify that the required module is stored (not just require() without assignment)
      // This pattern: const installAgent = require(...)
      expect(cliContent).toMatch(
        /const\s+\w+\s*=\s*require\(installAgentPath\)/
      );
    });

    test('install-agent.js must export main() function', () => {
      // This test ensures install-agent.js has the expected structure
      const installAgent = require(installAgentPath);

      expect(installAgent).toHaveProperty('main');
      expect(typeof installAgent.main).toBe('function');
    });

    test('cli.js must not rely on require.main === module pattern', () => {
      const cliContent = fs.readFileSync(cliPath, 'utf8');

      // Verify that cli.js does NOT use the pattern that caused the bug
      // (just requiring without calling main)
      const lines = cliContent.split('\n');
      const requireLine = lines.find(line =>
        line.includes('require(installAgentPath)')
      );

      if (requireLine) {
        // If there's a require() call, ensure it's not standalone (must be assigned)
        expect(requireLine).toMatch(/=\s*require\(/);
      }
    });
  });

  describe('Error handling', () => {
    test('cli.js must handle missing install-agent.js file', () => {
      const cliContent = fs.readFileSync(cliPath, 'utf8');

      // Verify file existence check
      expect(cliContent).toMatch(/existsSync.*installAgentPath/);
      expect(cliContent).toMatch(/install-agent\.js not found/);
      expect(cliContent).toMatch(/process\.exit\(1\)/);
    });

    test('cli.js must have try-catch for module loading errors', () => {
      const cliContent = fs.readFileSync(cliPath, 'utf8');

      // Verify try-catch block exists
      expect(cliContent).toMatch(/try\s*{/);
      expect(cliContent).toMatch(/}\s*catch\s*\(/);
    });

    test('cli.js must log errors with proper formatting', () => {
      const cliContent = fs.readFileSync(cliPath, 'utf8');

      // Verify error output includes newlines and error emoji
      expect(cliContent).toMatch(/console\.error.*❌.*Fatal error/);
      expect(cliContent).toMatch(/error\.message/);
      expect(cliContent).toMatch(/error\.stack/);
    });
  });

  describe('Integration: Actual execution', () => {
    test('cli.js --help produces output', () => {
      // This is the most important integration test
      // It verifies that main() is actually called and produces output
      try {
        const output = execSync('node cli.js --help', {
          cwd: __dirname,
          encoding: 'utf8',
          timeout: 10000,
        });

        // Verify that output is produced (not empty)
        expect(output).toBeTruthy();
        expect(output.length).toBeGreaterThan(0);

        // Verify expected help content
        expect(output).toMatch(/Usage:/i);
        expect(output).toMatch(/Options:/i);
      } catch (error) {
        // If it fails, provide detailed error information
        throw new Error(
          `cli.js --help failed to produce output. This indicates main() is not being called. Error: ${error.message}`
        );
      }
    });

    test('cli.js --list produces output', () => {
      try {
        const output = execSync('node cli.js --list', {
          cwd: __dirname,
          encoding: 'utf8',
          timeout: 10000,
        });

        // Verify that output is produced
        expect(output).toBeTruthy();
        expect(output.length).toBeGreaterThan(0);

        // Verify expected list content
        expect(output).toMatch(/Agents:/i);
      } catch (error) {
        throw new Error(
          `cli.js --list failed to produce output. Error: ${error.message}`
        );
      }
    });

    test('cli.js with invalid arguments shows error', () => {
      // Test that error handling works
      try {
        execSync('node cli.js --invalid-flag', {
          cwd: __dirname,
          encoding: 'utf8',
          timeout: 10000,
        });
        // If it succeeds, that's also valid (might just show help)
      } catch (error) {
        // Errors are expected for invalid arguments
        // Just verify the process ran and exited (not hung)
        expect(error).toBeDefined();
      }
    });
  });

  describe('Code quality and maintainability', () => {
    test('cli.js has shebang for Node.js', () => {
      const cliContent = fs.readFileSync(cliPath, 'utf8');
      const firstLine = cliContent.split('\n')[0];

      expect(firstLine).toBe('#!/usr/bin/env node');
    });

    test('cli.js has documentation comments', () => {
      const cliContent = fs.readFileSync(cliPath, 'utf8');

      // Verify there's documentation about the purpose
      expect(cliContent).toMatch(/CLI Wrapper/);
      expect(cliContent).toMatch(/npx/);
    });

    test('cli.js explains why main() is called explicitly', () => {
      const cliContent = fs.readFileSync(cliPath, 'utf8');

      // Verify there's a comment explaining the main() call
      // This is important for future maintainers
      expect(cliContent).toMatch(/Explicitly call main/i);
      expect(cliContent).toMatch(/require\.main/);
    });

    test('cli.js uses const for immutable variables', () => {
      const cliContent = fs.readFileSync(cliPath, 'utf8');

      // Verify modern JavaScript practices
      expect(cliContent).toMatch(/const path/);
      expect(cliContent).toMatch(/const fs/);
    });

    test('cli.js file size is reasonable', () => {
      const stats = fs.statSync(cliPath);

      // cli.js should be a simple wrapper, not too large
      expect(stats.size).toBeLessThan(5000); // ~5KB max
    });
  });

  describe('Regression prevention', () => {
    test('REGRESSION CHECK: Ensure bug pattern is not present', () => {
      const cliContent = fs.readFileSync(cliPath, 'utf8');

      // The original bug was just: require(installAgentPath);
      // Without storing it or calling main()

      // Check that there's no standalone require() without assignment
      const lines = cliContent.split('\n').filter(
        line =>
          line.includes('require(installAgentPath)') && !line.includes('=') // Not an assignment
      );

      expect(lines.length).toBe(0);
    });

    test('REGRESSION CHECK: main() is definitely invoked in execution path', () => {
      const cliContent = fs.readFileSync(cliPath, 'utf8');

      // Use AST-like analysis: find the require() and verify .main() follows
      const requireMatch = cliContent.match(
        /const\s+(\w+)\s*=\s*require\(installAgentPath\)/
      );
      expect(requireMatch).toBeTruthy();

      const varName = requireMatch[1];
      const mainCallPattern = new RegExp(`${varName}\\.main\\(\\)`);
      expect(cliContent).toMatch(mainCallPattern);
    });

    test('REGRESSION CHECK: Integration test verifies actual output', () => {
      // This meta-test ensures the integration tests are meaningful
      const testContent = fs.readFileSync(__filename, 'utf8');

      expect(testContent).toMatch(/cli\.js --help produces output/);
      expect(testContent).toMatch(/expect\(output\)\.toBeTruthy/);
    });
  });

  describe('Future-proofing', () => {
    test('cli.js pattern works even if install-agent.js internal structure changes', () => {
      // As long as install-agent.js exports main(), cli.js should work
      const installAgent = require(installAgentPath);

      // Verify the contract: install-agent.js must export main()
      expect(typeof installAgent.main).toBe('function');

      // This test will fail if src/install-agent.js stops exporting main(),
      // alerting developers to update cli.js accordingly
    });

    test('cli.js does not depend on install-agent.js internal implementation', () => {
      const cliContent = fs.readFileSync(cliPath, 'utf8');

      // cli.js should only know about:
      // 1. The path to install-agent.js
      // 2. The exported main() function
      // It should NOT reference internal functions or variables

      // Verify it doesn't reference internal functions like loadConfig, validateToken, etc.
      expect(cliContent).not.toMatch(/loadConfig/);
      expect(cliContent).not.toMatch(/validateToken/);
      expect(cliContent).not.toMatch(/downloadAgent/);
      expect(cliContent).not.toMatch(/executeAction/);

      // Should only call main(), not other exported functions
      const installAgentReferences =
        cliContent.match(/installAgent\.\w+/g) || [];
      // All references should be to .main only (may appear multiple times)
      const uniqueReferences = [...new Set(installAgentReferences)];
      expect(uniqueReferences).toEqual(['installAgent.main']);
    });
  });
});
