import React from 'react';
import { useSelector } from 'react-redux';
import { Look } from '@westpac/ui/components/alert/alert.types';
import { MVAlert } from '@mesh-tenant-multiverse-ui-common/mv-alert/src';

export type GlobalContextState = {
  global: {
    galaxy: {
      context: {
        notificationAlert: NotificationAlertState;
      };
    };
  };
};
export type NotificationAlertState = {
  type: Look;
  message: string;
};

function NotificationAlert() {
  const { type, message }: NotificationAlertState = useSelector(
    (state: GlobalContextState) =>
      state?.global?.galaxy?.context?.notificationAlert
  ) || { type: 'info', message: '' };
  return (
    message && (
      <MVAlert hasBackground={false} id={`${type}Message`}>
        {message}
      </MVAlert>
    )
  );
}

export default NotificationAlert;
