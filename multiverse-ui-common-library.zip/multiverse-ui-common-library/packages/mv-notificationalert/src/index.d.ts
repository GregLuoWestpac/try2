import { Look } from '@westpac/ui/components/alert/alert.types';

export type NotificationAlertState = {
  type: Look;
  message: string;
};

export function NotificationAlert(): JSX.Element;
