# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.219.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.218.0...v1.219.0) (2025-12-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-injection-checker

## [1.213.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.212.0...v1.213.0) (2025-12-04)

### 🚀 Features

- added detectInjectionVulnerability generic function in mv-inject-checker inorder to check input vulnerability at xapi layer ([4fced00](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/4fced00a1549f2c9186114972415ecaf4d9a7c53))

## [1.209.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.209.0...v1.209.1) (2025-11-09)

### 💥 Bug Fixes

- snyk vulnerabilties | ART-63316 ([dc0300f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/dc0300f179ae14bcd9118621718ff76528dded67))

## [1.209.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.208.0...v1.209.0) (2025-11-04)

### 🚀 Features

- trigger version update | ART-85165 ([5b67e6d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/5b67e6d8e12b237b1a21e62a341bffe15bb4456e))

## [1.208.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.207.0...v1.208.0) (2025-10-31)

### 🚀 Features

- **ART-66800:** double spacing for FormattedForbiddenCharacters string ([48aec98](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/48aec98190d734dede5ea2b836bad5bc59a70305))
- **ART-66800:** update comment and test case ([2ddd759](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2ddd75918118599afdc9a76fb724c2c995a8a8e4))

## [1.182.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.182.1...v1.182.2) (2025-09-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-injection-checker

## [1.153.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.152.0...v1.153.0) (2025-07-03)

### 🚀 Features

- field validations august uplift swagger | ART-54463 ([093e2a2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/093e2a2fc28b45120b6a3c969ec8283b41009369))
- field validations august uplift swagger and library changes | ART-54463 ([d9c00c5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d9c00c54fdb9620a5863e62194bdbf1c53d08b3f))

## [1.147.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.147.0...v1.147.1) (2025-06-18)

### 💥 Bug Fixes

- evaluating perfectexpressSanitizer on-payment details page ui | ART-49958 ([422ddf9](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/422ddf97ac445a55c9495d990117569f9c1664d7))

## [1.147.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.146.0...v1.147.0) (2025-06-16)

### 🚀 Features

- evaluating perfectexpressSanitizer on-payment details page ui | ART-49958 ([64859ca](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/64859ca948435f2ea6f2b2910d37426ae17cb019))

## [1.141.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.140.0...v1.141.0) (2025-06-06)

### 🚀 Features

- extend perfectexpresssanitizer to handle template injection | ART-54837 ([c422b02](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/c422b02ed5cde5c4ab19021b3cdd2cc458531183))

## [1.107.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.106.1...v1.107.0) (2025-04-11)

### 🚀 Features

- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([f6f5685](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f6f5685090a5a821f399c04eac38d452224d13bc))
- integrate PerfectExpressSanitizer into mv common lib | ART-50081 ([594177d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/594177d636efb09433616fb547bd15943b45cd7b))
