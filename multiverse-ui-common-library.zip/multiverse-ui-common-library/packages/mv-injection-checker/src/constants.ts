export const SQL_SANITISATION_LEVEL: 1 | 2 | 3 | 4 | 5 = 1;
export const WHITELIST_CHARACTERSET = ["'", '&', '/'];
export const FORBIDDEN_CHARACTERSET = [
  ';',
  '--',
  '{',
  '}',
  '<',
  '>',
  '%',
  '#',
  '"',
  '=',
];
