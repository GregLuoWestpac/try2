import { InjectionVulnerabilityResult } from './types';

export declare const FORBIDDEN_CHARACTERSET: string[];

/**
 * - returns a string of forbidden characters from FORBIDDEN_CHARACTERSET constant, seperated in double spaces.
 * - to preservce double spacing, one can add whitespace-pre-wrap tailwind class to wrapper component.
 */
export declare const getFormattedForbiddenCharacters: () => string;
export declare const validateWithLibrary: (content: string) => boolean;
export declare const sanitiseWithLibrary: (
  input: string,
  maxLength?: number
) => string;
export declare const detectInjectionVulnerability: <
  T extends Record<string, unknown>,
>(
  data: T,
  propertiesToValidate: Record<string, string>
) => InjectionVulnerabilityResult;
