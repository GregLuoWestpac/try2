import { sanitize } from 'perfect-express-sanitizer';
import { WHITELIST_CHARACTERSET, SQL_SANITISATION_LEVEL } from './constants';

/**
 * Checks if the input string is potentially vulnerable to injection attacks.
 * Returns true if injection risk is detected (unsafe), false otherwise (safe).
 *
 * @param content - The input string to validate.
 * @returns boolean - true if input is unsafe, false if safe.
 */
const containForbiddenCharacter = true;
export const validateWithLibrary = (content: string): boolean => {
  if (!content) {
    return !containForbiddenCharacter;
  }

  if (detectForbiddenCharacters(content)) {
    return containForbiddenCharacter;
  }

  content = hideWhitelistedCharacters(content);

  const hasXss: boolean = sanitize.detectXss(content);
  const hasSqlInjection: boolean = sanitize.detectSqlInj(
    content,
    SQL_SANITISATION_LEVEL
  );
  return hasXss || hasSqlInjection;
};

function hideWhitelistedCharacters(content: string) {
  const escaped = WHITELIST_CHARACTERSET.map(c => '\\' + c).join('');
  const regex = new RegExp(`[${escaped}]`, 'g');
  content = content.replace(regex, '');
  return content;
}

function detectForbiddenCharacters(content: string): boolean {
  //LIBRARY_PROTECTED_STRING pattern: '^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$'
  const forbiddenPattern = /(;|--|\{|\}|<|>|%|#|"|=)/;
  return forbiddenPattern.test(content);
}
