/**
 * Removes all characters from the input string that match any character in the FORBIDDEN_CHARACTERSET array.
 * Optionally limits the output string to a specified maximum length.
 * @param input - The input string to be sanitised.
 * @param maxLength - (Optional) The maximum length of the output string.
 * @returns The sanitised string with specified characters removed and optionally truncated.
 */

import { FORBIDDEN_CHARACTERSET } from './constants';

export const sanitiseWithLibrary = (
  input: string,
  maxLength?: number
): string => {
  if (!input) {
    return '';
  }
  if (
    !Array.isArray(FORBIDDEN_CHARACTERSET) ||
    FORBIDDEN_CHARACTERSET.length === 0
  ) {
    return input;
  }

  // remove all double hyphens to avoid false positives for single hyphens
  const forbiddenChars = FORBIDDEN_CHARACTERSET.filter(c => c !== '--');
  let sanitisedOutput = input.replace(/--/g, '');

  // Create a Set for faster lookup
  const patternSet = new Set(forbiddenChars);

  sanitisedOutput = sanitisedOutput
    .split('')
    .filter(char => !patternSet.has(char))
    .join('');

  if (maxLength !== undefined) {
    sanitisedOutput = sanitisedOutput.slice(0, maxLength);
  }
  return sanitisedOutput;
};
