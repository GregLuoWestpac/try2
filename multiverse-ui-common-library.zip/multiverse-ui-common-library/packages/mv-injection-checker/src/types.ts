export type InjectionVulnerabilityResult = {
  vulnerabilityDetected: boolean;
  message: string;
  vulnerableFields: string[];
};
