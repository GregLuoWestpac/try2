import { FORBIDDEN_CHARACTERSET } from './constants';

export const getFormattedForbiddenCharacters = (): string => {
  return FORBIDDEN_CHARACTERSET.join(' ');
};
