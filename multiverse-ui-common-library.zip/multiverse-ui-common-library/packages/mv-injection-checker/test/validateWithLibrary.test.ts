import {
  validateWithLibrary,
  FORBIDDEN_CHARACTERSET,
  WHITELIST_CHARACTERSET,
} from '../src';

describe('validateWithLibrary', () => {
  it('should detect vulnerability for each forbidden character (except whitelisted)', () => {
    FORBIDDEN_CHARACTERSET.forEach(char => {
      if (!WHITELIST_CHARACTERSET.includes(char)) {
        expect(validateWithLibrary(char)).toBe(true);
      }
    });
  });

  it('should not detect vulnerability for single hyphen', () => {
    expect(validateWithLibrary('-')).toBe(false);
    expect(validateWithLibrary('safe-hyphen')).toBe(false);
  });

  it('should detect vulnerability for double hyphen', () => {
    expect(validateWithLibrary('--')).toBe(true);
    expect(validateWithLibrary('foo--bar')).toBe(true);
  });

  it('should detect vulnerability for tripple hyphen', () => {
    expect(validateWithLibrary('---')).toBe(true);
    expect(validateWithLibrary('foo---bar')).toBe(true);
  });

  it('should detect vulnerability for xss injection patterns', () => {
    expect(validateWithLibrary('<script>alert(1)</script>')).toBe(true);
    expect(validateWithLibrary('<input onfocus=alert(1) autofocus>')).toBe(
      true
    );
    expect(validateWithLibrary('<img src=x onerror=alert(1)>')).toBe(true);
    expect(validateWithLibrary("<body onload=alert('XSS')>")).toBe(true);
  });

  it('should detect vulnerability for sql injection patterns', () => {
    expect(validateWithLibrary("SELECT * FROM users WHERE id = '1'")).toBe(
      true
    );
    expect(validateWithLibrary('OR 1=1')).toBe(true);
    expect(validateWithLibrary("'; DROP TABLE users; --")).toBe(true);
    expect(validateWithLibrary("admin' --")).toBe(true);
    expect(validateWithLibrary("admin' #")).toBe(true);
  });

  it('should detect vulnerability for template injection patterns', () => {
    expect(validateWithLibrary('{{7*7}}')).toBe(true);
    expect(validateWithLibrary('{% print(7*7) %}')).toBe(true);
    expect(validateWithLibrary('<%= user.name %>')).toBe(true);
    expect(validateWithLibrary('${7*7}')).toBe(true);
  });

  it('should not detect vulnerability for whitelisted characters', () => {
    WHITELIST_CHARACTERSET.forEach(char => {
      expect(validateWithLibrary(char)).toBe(false);
    });
  });

  it('should not detect vulnerability for safe input', () => {
    expect(validateWithLibrary('hello world')).toBe(false);
    expect(validateWithLibrary('abc123')).toBe(false);
    expect(validateWithLibrary('safe_input')).toBe(false);
  });

  it('should not detect vulnerability for empty string', () => {
    expect(validateWithLibrary('')).toBe(false);
    expect(validateWithLibrary(null)).toBe(false);
    expect(validateWithLibrary(undefined)).toBe(false);
  });

  it('should handle mixed safe and unsafe input', () => {
    expect(validateWithLibrary('hello -- world')).toBe(true);
    expect(validateWithLibrary('safe <script>')).toBe(true);
    expect(validateWithLibrary('normal text')).toBe(false);
  });
});
