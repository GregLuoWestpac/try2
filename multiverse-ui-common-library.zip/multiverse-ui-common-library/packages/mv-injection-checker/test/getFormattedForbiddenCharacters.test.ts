import { getFormattedForbiddenCharacters } from '../src';

describe('getFormattedForbiddenCharacters', () => {
  it('should return forbidden characters joined by space', () => {
    // space separated forbidden characters, FORBIDDEN_CHARACTERSET.join(' ')
    const expected = '; -- { } < > % # " =';
    expect(getFormattedForbiddenCharacters()).toBe(expected);
  });
});
