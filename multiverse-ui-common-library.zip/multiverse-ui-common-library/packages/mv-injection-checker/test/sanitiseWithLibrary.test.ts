import { sanitiseWithLibrary, FORBIDDEN_CHARACTERSET } from '../src';

describe('sanitiseWithLibrary', () => {
  it('should return empty string if input is empty', () => {
    expect(sanitiseWithLibrary('')).toBe('');
  });
  it('should return input with single hyphen', () => {
    expect(sanitiseWithLibrary('abc-')).toBe('abc-');
  });

  it('should return remove double hyphen from input', () => {
    expect(sanitiseWithLibrary('abc--')).toBe('abc');
  });
  it('should return remove double hyphen from input and return single hyphen', () => {
    expect(sanitiseWithLibrary('abc---')).toBe('abc-');
  });

  it('should return remove double hyphen from input and return no hyphen', () => {
    expect(sanitiseWithLibrary('abc----')).toBe('abc');
  });
  it('should return remove double hyphen from input and return single hyphen', () => {
    expect(sanitiseWithLibrary('abc-----')).toBe('abc-');
  });
  it('should return input unchanged if FORBIDDEN_CHARACTERSET is empty', () => {
    // Temporarily override FORBIDDEN_CHARACTERSET
    const original = [...FORBIDDEN_CHARACTERSET];
    (FORBIDDEN_CHARACTERSET as string[]).length = 0;
    expect(sanitiseWithLibrary('test123')).toBe('test123');
    // Restore original
    FORBIDDEN_CHARACTERSET.push(...original);
  });

  it('should remove forbidden characters from input', () => {
    // Example: if FORBIDDEN_CHARACTERSET = ['$', '%']
    (FORBIDDEN_CHARACTERSET as string[]).length = 0;
    FORBIDDEN_CHARACTERSET.push('$', '%');
    expect(sanitiseWithLibrary('abc$def%ghi')).toBe('abcdefghi');
  });

  it('should truncate output to maxLength if specified', () => {
    (FORBIDDEN_CHARACTERSET as string[]).length = 0;
    FORBIDDEN_CHARACTERSET.push('@');
    expect(sanitiseWithLibrary('hello@world', 6)).toBe('hellow');
  });

  it('should handle input with only forbidden characters', () => {
    (FORBIDDEN_CHARACTERSET as string[]).length = 0;
    FORBIDDEN_CHARACTERSET.push('x', 'y', 'z');
    expect(sanitiseWithLibrary('xyzxyz')).toBe('');
  });

  it('should handle undefined maxLength', () => {
    (FORBIDDEN_CHARACTERSET as string[]).length = 0;
    FORBIDDEN_CHARACTERSET.push('!');
    expect(sanitiseWithLibrary('hello!')).toBe('hello');
    expect(sanitiseWithLibrary('hello!', undefined)).toBe('hello');
  });
});
