# Build Number and Dependency Tracker

This script is designed to fetch build numbers and dependencies for components in a specified environment. It retrieves data from APIs, processes it, and writes the results to CSV files for further analysis.

## Table of Contents

- [Features](#features)
- [Installation](#installation)
  - [Prerequisites](#prerequisites)
  - [Steps](#steps)

## Features

- Fetches build numbers for components across different environments.
- Recursively retrieves dependencies for components.
- Outputs data to CSV files:
  - `build_numbers.csv`: Contains build numbers for components.
  - `dependencies_dict.csv`: Contains dependencies for components.

## Installation

### Prerequisites

- Python 3.7 or higher
- Required Python packages (see `requirements.txt`)

### Required Dependencies

The following Python packages are required:

```
click==8.1.3
wdp-common==1.0.0
mesh-services==1.0.0
wdp-logging==1.0.0
```

### Steps

1. **Clone the repository:**

   ```bash
   git clone ssh://git@bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library.git
   ```

2. **Change into the project directory:**

   ```bash
   cd multiverse-ui-common-library/tools/build
   ```

3. **Create and activate a virtual environment:**

   ```bash
   python -m venv venv
   source venv/bin/activate # On Windows, use `venv\Scripts\activate`
   ```

   or

   ```bash
   pyenv local 3.12.4
   poetry shell
   ```

4. **Install the dependencies:**

   ```bash
   pip install -r requirements.txt
   ```

   or

   ```bash
   poetry install
   ```

5. **Run the application:**

   ```bash
   python generate_build_data.py
   ```
