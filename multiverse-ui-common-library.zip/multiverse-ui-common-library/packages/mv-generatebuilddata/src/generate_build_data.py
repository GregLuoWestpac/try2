#!/bin/env python

from wdp_common import wdp_component, wdp_exception
from mesh_services import dream_api
from wdp_logging import logger

import csv
import json
import click

def write_to_csv(data, headers, file_name):
    """
    Writes data to a CSV file with the specified headers.

    :param data: List of dictionaries containing the data to write.
    :param headers: List of strings representing the column headers.
    :param file_name: Name of the CSV file to write to.
    """
    with open(file_name, mode='w', newline='') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(headers)

        for row in data:
            writer.writerow([row.get(header) for header in headers])

    logger.info(f"Data has been written to {file_name}")

def write_build_numbers_to_csv(build_numbers, file_name='build_numbers.csv'):
    """
    Writes the build numbers data to a CSV file.

    :param build_numbers: Dictionary containing build numbers data.
    :param file_name: Name of the CSV file to write to.
    """
    data = []
    for component_id, environments in build_numbers.items():
        for environment in environments:
            data.append({
                "Component Name": component_id,
                "Environment": environment['env'],
                "Build Number": environment['build_number']
            })

    write_to_csv(data, headers=["Component Name", "Environment", "Build Number"], file_name=file_name)

def write_dependencies_to_csv(dependencies, file_name='dependencies_dict.csv'):
    data = [
        {"Component Name": component_name, "Component ID": dependency["componentId"]}
        for component_name, dependency_list in dependencies.items()
        for dependency in dependency_list
    ]
    write_to_csv(data, headers=["Component Name", "Component ID"], file_name=file_name)


def write_to_json(data, file_name):
    """
    Writes the given data to a JSON file.

    :param data: The data to write, typically a dictionary or list.
    :param file_name: The name of the JSON file to write to.
    
    This function serializes the provided data into JSON format and writes it to the specified file.
    The output is formatted with an indentation of 2 spaces for better readability.
    If the file already exists, it will be overwritten.

    Example:
        data = {"key": "value"}
        write_to_json(data, "output.json")
        # This will create a file named 'output.json' with the content:
        # {
        #     "key": "value"
        # }
    """
    with open(file_name, "w") as json_file:
        json.dump(data, json_file, indent=2)
    logger.info(f"Data has been written to {file_name}")

def get_ids_and_build_numbers(env, component):
    try:
        deployments_data = dream_api.get_deployments(env, component)
    except Exception as e:
        logger.error(f"Failed to fetch deployments for {component.id}: {e}")
        return []

    result = []
    for environment in deployments_data.get("environments", []):
        env = environment.get("id")
        build_number = environment.get("artifactDetails", {}).get("buildNumber")
        if env and build_number:
            result.append({"env": env, "build_number": build_number})
    return result

def fetch_dependencies_recursively(env, component, visited, dependencies_dict, deployments_dict):
    if component.id in visited:
        return
    visited.add(component.id)

    dependencies = dream_api.get_dependencies(env, component)
    component_name = component._component_name
    if not component_name in dependencies_dict:
        dependencies_dict[component_name] = []
    dependencies_dict[component_name].append({
        "componentId": component.id,
        "componentName": component_name,
    })
    deployments_dict[component_name] = get_ids_and_build_numbers(env, component)

    for dependency in dependencies.get('componentDependencies', [])[0].get('dependsOn', {}).get('components', []):
        dependency_id = dependency.get("componentId")
        if dependency_id not in visited:
            logger.info(f"Fetching for {dependency.get('componentName')}: {dependency_id}")
            dependency_component = wdp_component.WDPComponent.initialise_from_name_and_type(
                dependency.get("componentName"), dependency.get("componentType")
            )
            fetch_dependencies_recursively(env, dependency_component, visited, dependencies_dict, deployments_dict)

@click.command(context_settings=dict(help_option_names=['-h', '--help']))
@click.option('--env', help='Environment being referred to',required=False, default="prod1")
@click.option('--components', help='Comma-separated list of component repository URIs', required=False, default="")
@click.option('--format', help='Format: csv or json', required=False, default="csv")
@wdp_exception.unknown_exception_handler
def run(env, components, format):
    """
        prod1
        svp1
        uat1
        sit1
        dev1
    """
    
    dependencies_dict = {}
    deployments_dict = {}

    if components:
        components_list = components.split(",")
    else:
        # Default components if none are provided via the flag
        components_list = [
            "ssh://git@bitbucket.srv.westpac.com.au/wdp/galaxy-payment-microfrontend.git",
            # "ssh://git@bitbucket.srv.westpac.com.au/wdp/galaxy-account-microfrontend.git",
            # "ssh://git@bitbucket.srv.westpac.com.au/wdp/galaxy-dashboard-microfrontend.git",
            # "ssh://git@bitbucket.srv.westpac.com.au/wdp/galaxy-singlepageapplication.git",
            # "ssh://git@bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library.git",
            # "ssh://git@bitbucket.srv.westpac.com.au/wdp/galaxy-beneficiary-microfrontend.git"
        ]

    visited_components = set()
    for repository_uri in components_list:
        component = wdp_component.WDPComponent.initialise_from_repo_uri(repository_uri)
        fetch_dependencies_recursively(env, component, visited_components, dependencies_dict, deployments_dict)

    logger.info(f"Deployments list {deployments_dict}")
    logger.info(f"Dependencies list {dependencies_dict}")
    
        # Write output based on the specified format
    if format.lower() == "csv":
        write_dependencies_to_csv(dependencies_dict)
        write_build_numbers_to_csv(deployments_dict)
    elif format.lower() == "json":
        write_to_json(dependencies_dict, "dependencies.json")
        write_to_json(deployments_dict, "build_numbers.json")
    else:
        logger.error(f"Unsupported output format: {format}")

if __name__ == '__main__':
    run()
