import { Grid, GridItem, Heading } from '@westpac/ui';
import React, { ReactNode } from 'react';

export type MVCardProps = {
  children: ReactNode;
  title?: string;
  subtitle?: string;
  bottomDivider?: boolean;
  bottomPadding?: boolean;
  template?: 'wide' | 'narrow';
};

function MVCard({
  children,
  template = 'wide',
  title,
  subtitle = '',
  bottomDivider = true,
  bottomPadding = true,
}: MVCardProps) {
  const margin = 3;
  return (
    <Grid
      className={`mv-card-container justify-start ${template === 'narrow' ? 'max-w-[720px]' : 'max-w-[1260px]'} bg-white border border-border p-4 m-${margin} xsl:gap-0 sm:gap-0 !gap-0 min-w-[528px]`}
    >
      {title && (
        <GridItem span={12}>
          <Grid
            data-testid="title-grid"
            className={`gap-0 flex flex-row items-center justify-between ${
              bottomPadding ? 'pb-2.5' : ''
            } ${bottomDivider ? 'border-b border-border' : ''}`}
          >
            <GridItem
              span={12}
              className="w-full flex flex-col flex-wrap items-flex-start overflow-hidden gap-2.5"
            >
              <Heading
                className="text-heading my-0 mt-0 mb-0.5"
                size={6}
                tag="h1"
              >
                {title}
              </Heading>
              {subtitle && (
                <span className="my-0 typography-body-11 text-muted">
                  {subtitle}
                </span>
              )}
            </GridItem>
          </Grid>
        </GridItem>
      )}
      <GridItem span={12}>{children}</GridItem>
    </Grid>
  );
}

export default MVCard;
