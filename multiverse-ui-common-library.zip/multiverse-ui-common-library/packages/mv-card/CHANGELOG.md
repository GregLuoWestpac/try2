# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.226.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.226.1...v1.226.2) (2026-02-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-card

## [1.224.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.224.4...v1.224.5) (2026-01-30)

### 💥 Bug Fixes

- correct margin change | ART-98065 ([074fe71](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/074fe712ac281a4fe9c4d2156105cb969eccb809))
- update heading margins to prevent text overlap on windows | ART-98065 ([2ae75e4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2ae75e413885c298a6f898c11e048c701a9e9037))

## [1.221.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.221.0...v1.221.1) (2026-01-21)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-card

## [1.219.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.218.0...v1.219.0) (2025-12-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-card

## [1.178.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.177.2...v1.178.0) (2025-08-11)

### 🚀 Features

- add bottompadding prop | ART-61028 ([9c4b210](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9c4b2102eadd944f41488807fd15fd13838bc1ec))

## [1.170.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.167.2...v1.170.1) (2025-07-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-card

## [1.158.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.157.0...v1.158.0) (2025-07-09)

### 🚀 Features

- add isStatic and tableHeight params to be more readable | ART-54678 ([03de91f](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/03de91f8fbe31b819018de89581e39b08fd1ad8d))

## [1.152.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.151.3...v1.152.0) (2025-07-03)

### 🚀 Features

- added top and bottom 24px margins + gave isStatic and height to mvtable params | ART-58868 ([2eb4d92](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/2eb4d9298993715f19aab05637858ff698005986))

## [1.149.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.148.0...v1.149.0) (2025-06-26)

### 🚀 Features

- added 24px padding to MVCard | ART-58868 ([b294030](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b294030fd5f0d1ddeaf4fceeff64d5de370f0a29))

## [1.143.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.142.0...v1.143.0) (2025-06-10)

### 🚀 Features

- mv card fix width for longer headings ([3823564](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/382356490182d98fe70e3eeaf7411b53e62abc2c))
- mv card fix width for longer headings with subtitle ([328bad0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/328bad0c8b35c03860db68e6e56cc00563c4ff55))

## [1.102.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.101.0...v1.102.0) (2025-04-03)

### 🚀 Features

- ART-41757 remove defaultProps ([be8ed20](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/be8ed2094d48a77ecf123727c74aad6ca36eba20))

## [1.85.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.84.0...v1.85.0) (2025-03-20)

### 🚀 Features

- remove dropdown placeholder | ART-38630 ([ccc739b](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ccc739b42b0c4ddc9a35f479cd556614cfb37edc))

## [1.83.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.82.0...v1.83.0) (2025-03-19)

### 🚀 Features

- begin dropdown menu implementation for MVCard | ART-38630 ([cbd5905](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/cbd590504e9fd0ac6e5d21caa5c5b9f252545e1f))

## [1.69.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.69.3...v1.69.4) (2025-03-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-card

## [1.66.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.66.2...v1.66.3) (2025-02-26)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-card

## [1.55.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.54.0...v1.55.0) (2025-02-02)

### 🚀 Features

- dummy commit for version bump | ART-38430 ([ade06f5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ade06f53d125ab675340075f87e7213d86a177a4))

## [1.40.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.39.5...v1.40.0) (2024-12-18)

### 🚀 Features

- added sample stories for the details & card packages ([9ef7bd3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9ef7bd395cff52395559ab23529426639ff925a4))

### 💥 Bug Fixes

- fixed the styling with mvaccount formatter story ([95a3935](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/95a39355f61a65bbc0fd37c0991fdc5d908c6e5a))

## [1.22.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.21.2...v1.22.0) (2024-11-13)

### 🚀 Features

- MVCard title conditional rendering added | ART-29128 ([8dae60e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8dae60e04b16f37d4f995d5cad1d7b8bf3ad03a9))

## [1.16.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.15.0...v1.16.0) (2024-11-04)

### 🚀 Features

- mvcard component updates | ART-29215 ([18f22d2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/18f22d236a49ed6755980cf1c6b15a47222f1915))
- mvcard style updates | ART-29215 ([154ab1c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/154ab1c33c6b40462312a756d7143758aaf6b4d7))

## [1.13.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.12.8...v1.13.0) (2024-11-01)

### 🚀 Features

- mvcard component migration | ART-29215 ([9d39cda](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9d39cda9a6a10b11ae741d2ed4c1f300d266028f))
- review comment fixes | ART-29215 ([8f70eb2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8f70eb22a0c099df635df2bd2a84c335a1220360))

## [1.10.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.9.0...v1.10.0) (2024-10-22)

### 🚀 Features

- component updateion | ART-28136 ([8c92281](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/8c92281f2a764123117bba261294e71c43bf7f25))
- mvcard component | ART-28136 ([64a6b0e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/64a6b0eebe6649df67ecb40f1b5430c79c527480))
- mvcard component update and package-lock.json updates | ART-28136 ([10c0789](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/10c0789efe9a5886d6f4313c55b7f9964537d350))
- restructure of missing props | ART-28136 ([e3c1992](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/e3c1992f9fda235094cc399b08c2025f0ca50026))
