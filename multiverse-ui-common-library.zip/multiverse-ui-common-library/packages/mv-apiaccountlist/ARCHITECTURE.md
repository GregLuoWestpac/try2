# Controller Architecture Refactoring

## Overview

The `buildGetAccountListController` has been refactored to separate concerns and provide a reusable architecture for building Express.js controllers with proper error handling.

## Architecture Components

### 1. Core Handler Functions

These contain the business logic specific to each API endpoint:

```typescript
export const getAccountListHandler = async (
  req: Request,
  res: Response,
  controllerParams: ControllerParams
): Promise<void> => {
  // Business logic implementation
  // - Extract request parameters
  // - Call services/APIs
  // - Format response
  // - Send response
};
```

### 2. Generic Controller Wrapper

A reusable wrapper that handles error catching and Express.js middleware integration:

```typescript
export const createControllerWrapper = (
  handlerFn: ControllerHandler,
  controllerParams: ControllerParams
) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      await handlerFn(req, res, controllerParams);
    } catch (error) {
      const { logger } = res.locals;
      handleControllerError({ error, res, logger });
      next(error);
    }
  };
};
```

### 3. Controller Builder Functions

These combine the handler and wrapper for specific endpoints:

```typescript
export const buildGetAccountListController = (
  controllerParams: ControllerParams
) => {
  return createControllerWrapper(getAccountListHandler, controllerParams);
};
```

## Creating a New API Controller

To create a new API controller using this architecture:

### Step 1: Create the Handler Function

```typescript
// src/getNewApiHandler.ts
export const getNewApiHandler = async (
  req: Request,
  res: Response,
  controllerParams: ControllerParams
): Promise<void> => {
  const { RUNTIME, normalise, apiClient, readMeshSecrets } = controllerParams;
  const { apiHeaders, logger } = res.locals;
  const { OK } = STATUS_CODES;

  // Your business logic here
  const data = await fetchSomeData(req, res, apiClient);
  const normalisedData = normaliseData('dataType', data, normalise);

  res.status(OK).json(normalisedData).end();
};
```

### Step 2: Create the Controller Builder

```typescript
// src/getNewApiController.ts
export const buildNewApiController = (controllerParams: ControllerParams) => {
  return createControllerWrapper(getNewApiHandler, controllerParams);
};
```

### Step 3: Use in Your Routes

```typescript
// In your Express routes
const controller = buildNewApiController(controllerParams);
app.get('/api/new-endpoint', controller);
```

## Benefits

1. **Separation of Concerns**: Business logic is separated from error handling and middleware concerns
2. **Reusability**: The `createControllerWrapper` can be used for any new API endpoint
3. **Testability**: Handler functions can be tested independently of Express.js middleware
4. **Consistency**: All controllers follow the same error handling pattern
5. **Maintainability**: Easy to modify error handling or add features across all controllers

## Testing

The architecture supports comprehensive testing at multiple levels:

- **Unit Tests**: Test individual handler functions with mocked dependencies
- **Integration Tests**: Test the complete controller flow
- **Error Handling Tests**: Verify error scenarios are handled correctly

Example test structure:

```typescript
describe('newApiHandler', () => {
  it('should successfully process request', async () => {
    // Test the core business logic
  });
});

describe('createControllerWrapper', () => {
  it('should handle errors correctly', async () => {
    // Test error handling wrapper
  });
});
```
