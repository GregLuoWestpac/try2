/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response } from 'express';
import { v4 } from 'uuid';
import { getAccountListFromPdp } from '../src/transformAccountLists';
import { GetAccountListFromPdpParams, PdpQueryResult } from '../src/types';
import { getAccountIdsFromPdpQueryResult } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  getAccountIdsFromPdpQueryResult: jest.fn(),
}));

jest.mock('uuid', () => ({
  v4: jest.fn(() => 'mock-uuid-id'),
}));

const mockV4 = v4 as jest.MockedFunction<typeof v4>;

describe('transformAccountLists', () => {
  let mockReq: Partial<Request>;
  let mockRes: Partial<Response>;
  let mockQueryDecisionRequest: any;
  let mockPdpClientToken: string;
  let mockParams: GetAccountListFromPdpParams;

  beforeEach(() => {
    mockReq = {};
    mockRes = {};
    mockQueryDecisionRequest = jest.fn();
    mockPdpClientToken = 'test-token';
    mockParams = {
      groupId: 'test-group',
      requestAction: 'VIEW_ACCOUNT',
      orgCisKey: 'test-org-key',
    };

    jest.clearAllMocks();
    mockV4.mockReturnValue('mock-uuid-id');
  });

  describe('getAccountListFromPdp', () => {
    it('should successfully transform PDP query results to account list', async () => {
      // Arrange
      const mockPdpQueryResults: PdpQueryResult[] = [
        {
          value: 'account1',
          decision: 'PERMIT',
          statements: [
            {
              id: 'stmt1',
              name: 'Account 1 Statement',
              code: 'ACC1',
              payload: JSON.stringify({
                name: 'Apple Tree Account',
                bsb: '035845',
                accountNumber: '123456789',
                type: 'Corporate Investment Account',
                status: 'active',
                currency: 'AUD',
              }),
              obligatory: true,
              fulfilled: true,
              attributes: {},
            },
          ],
        },
      ];

      (getAccountIdsFromPdpQueryResult as jest.Mock).mockResolvedValue(
        mockPdpQueryResults
      );

      // Act
      const result = await getAccountListFromPdp(
        mockReq as Request,
        mockRes as Response,
        mockQueryDecisionRequest,
        mockPdpClientToken,
        mockParams
      );

      // Assert
      expect(getAccountIdsFromPdpQueryResult).toHaveBeenCalledWith({
        res: mockRes,
        req: mockReq,
        queryDecisionRequest: mockQueryDecisionRequest,
        pdpClientToken: mockPdpClientToken,
        groupId: 'test-group',
        requestAction: 'VIEW_ACCOUNT',
        orgCisKey: 'test-org-key',
      });

      expect(result).toEqual([
        {
          id: 'mock-uuid-id',
          accountId: '035845 123456789',
          accountName: 'Apple Tree Account',
          accountType: 'Corporate Investment Account',
          status: 'ACTIVE',
          currencyCode: 'AUD',
        },
      ]);
    });

    it('should sort accounts by account name alphabetically', async () => {
      // Arrange
      const mockPdpQueryResults: PdpQueryResult[] = [
        {
          value: 'account1',
          decision: 'PERMIT',
          statements: [
            {
              id: 'stmt1',
              name: 'Account 1 Statement',
              code: 'ACC1',
              payload: JSON.stringify({
                name: 'Zebra Account',
                bsb: '035845',
                accountNumber: '123456789',
              }),
              obligatory: true,
              fulfilled: true,
              attributes: {},
            },
          ],
        },
        {
          value: 'account2',
          decision: 'PERMIT',
          statements: [
            {
              id: 'stmt2',
              name: 'Account 2 Statement',
              code: 'ACC2',
              payload: JSON.stringify({
                name: 'Apple Account',
                bsb: '035845',
                accountNumber: '987654321',
              }),
              obligatory: true,
              fulfilled: true,
              attributes: {},
            },
          ],
        },
      ];

      (getAccountIdsFromPdpQueryResult as jest.Mock).mockResolvedValue(
        mockPdpQueryResults
      );

      // Act
      const result = await getAccountListFromPdp(
        mockReq as Request,
        mockRes as Response,
        mockQueryDecisionRequest,
        mockPdpClientToken,
        mockParams
      );

      // Assert
      expect(result[0].accountName).toBe('Apple Account');
      expect(result[1].accountName).toBe('Zebra Account');
    });

    it('should handle missing payload gracefully', async () => {
      // Arrange
      const mockPdpQueryResults: PdpQueryResult[] = [
        {
          value: 'account1',
          decision: 'PERMIT',
          statements: [
            {
              id: 'stmt1',
              name: 'Account 1 Statement',
              code: 'ACC1',
              payload: '', // Empty payload
              obligatory: true,
              fulfilled: true,
              attributes: {},
            },
          ],
        },
      ];

      (getAccountIdsFromPdpQueryResult as jest.Mock).mockResolvedValue(
        mockPdpQueryResults
      );

      // Act
      const result = await getAccountListFromPdp(
        mockReq as Request,
        mockRes as Response,
        mockQueryDecisionRequest,
        mockPdpClientToken,
        mockParams
      );

      // Assert
      expect(result).toEqual([
        {
          id: 'mock-uuid-id',
          accountId: 'undefined undefined',
          accountName: '',
          accountType: '',
          status: 'INACTIVE',
          currencyCode: '',
        },
      ]);
    });

    it('should use default parameters when not provided', async () => {
      // Arrange
      const mockPdpQueryResults: PdpQueryResult[] = [];
      (getAccountIdsFromPdpQueryResult as jest.Mock).mockResolvedValue(
        mockPdpQueryResults
      );

      // Act
      const result = await getAccountListFromPdp(
        mockReq as Request,
        mockRes as Response,
        mockQueryDecisionRequest,
        mockPdpClientToken
      );

      // Assert
      expect(getAccountIdsFromPdpQueryResult).toHaveBeenCalledWith({
        res: mockRes,
        req: mockReq,
        queryDecisionRequest: mockQueryDecisionRequest,
        pdpClientToken: mockPdpClientToken,
        groupId: undefined,
        requestAction: undefined,
        orgCisKey: undefined,
      });
      expect(result).toEqual([]);
    });

    it('should correctly map active/inactive status', async () => {
      // Arrange
      const mockPdpQueryResults: PdpQueryResult[] = [
        {
          value: 'account1',
          decision: 'PERMIT',
          statements: [
            {
              id: 'stmt1',
              name: 'Account 1 Statement',
              code: 'ACC1',
              payload: JSON.stringify({
                name: 'Active Account',
                status: 'active',
              }),
              obligatory: true,
              fulfilled: true,
              attributes: {},
            },
          ],
        },
        {
          value: 'account2',
          decision: 'PERMIT',
          statements: [
            {
              id: 'stmt2',
              name: 'Account 2 Statement',
              code: 'ACC2',
              payload: JSON.stringify({
                name: 'Inactive Account',
                status: 'suspended',
              }),
              obligatory: true,
              fulfilled: true,
              attributes: {},
            },
          ],
        },
      ];

      (getAccountIdsFromPdpQueryResult as jest.Mock).mockResolvedValue(
        mockPdpQueryResults
      );

      // Act
      const result = await getAccountListFromPdp(
        mockReq as Request,
        mockRes as Response,
        mockQueryDecisionRequest,
        mockPdpClientToken,
        mockParams
      );

      // Assert
      expect(result[0].status).toBe('ACTIVE');
      expect(result[1].status).toBe('INACTIVE');
    });

    it('should filter accounts by status when accountStatus is ACTIVE', async () => {
      // Arrange
      const mockPdpQueryResults = [
        {
          value: 'account1',
          decision: 'PERMIT',
          statements: [
            {
              id: 'stmt1',
              name: 'Active Account',
              code: 'ACC1',
              payload: JSON.stringify({
                name: 'Active Account',
                bsb: '035845',
                accountNumber: '123456789',
                type: 'Corporate Investment Account',
                status: 'active',
                currency: 'AUD',
              }),
              obligatory: true,
              fulfilled: true,
              attributes: {
                status: 'active',
              },
            },
          ],
        },
        {
          value: 'account2',
          decision: 'PERMIT',
          statements: [
            {
              id: 'stmt2',
              name: 'Inactive Account',
              code: 'ACC2',
              payload: JSON.stringify({
                name: 'Inactive Account',
                bsb: '035845',
                accountNumber: '987654321',
                type: 'Corporate Investment Account',
                status: 'inactive',
                currency: 'AUD',
              }),
              obligatory: true,
              fulfilled: true,
              attributes: {
                status: 'inactive',
              },
            },
          ],
        },
      ];

      (getAccountIdsFromPdpQueryResult as jest.Mock).mockResolvedValue(
        mockPdpQueryResults
      );

      const paramsWithActiveFilter = {
        ...mockParams,
        accountStatus: 'ACTIVE' as const,
      };

      // Act
      const result = await getAccountListFromPdp(
        mockReq as Request,
        mockRes as Response,
        mockQueryDecisionRequest,
        mockPdpClientToken,
        paramsWithActiveFilter
      );

      // Assert
      expect(result).toHaveLength(1);
      expect(result[0].status).toBe('ACTIVE');
    });

    it('should return all accounts when accountStatus is ACTIVE_AND_INACTIVE', async () => {
      // Arrange
      const mockPdpQueryResults = [
        {
          value: 'account1',
          decision: 'PERMIT',
          statements: [
            {
              id: 'stmt1',
              name: 'Active Account',
              code: 'ACC1',
              payload: JSON.stringify({
                name: 'Active Account',
                bsb: '035845',
                accountNumber: '123456789',
                type: 'Corporate Investment Account',
                status: 'active',
                currency: 'AUD',
              }),
              obligatory: true,
              fulfilled: true,
              attributes: {
                status: 'active',
              },
            },
          ],
        },
        {
          value: 'account2',
          decision: 'PERMIT',
          statements: [
            {
              id: 'stmt2',
              name: 'Inactive Account',
              code: 'ACC2',
              payload: JSON.stringify({
                name: 'Inactive Account',
                bsb: '035845',
                accountNumber: '987654321',
                type: 'Corporate Investment Account',
                status: 'inactive',
                currency: 'AUD',
              }),
              obligatory: true,
              fulfilled: true,
              attributes: {
                status: 'inactive',
              },
            },
          ],
        },
      ];

      (getAccountIdsFromPdpQueryResult as jest.Mock).mockResolvedValue(
        mockPdpQueryResults
      );

      const paramsWithAllFilter = {
        ...mockParams,
        accountStatus: 'ACTIVE_AND_INACTIVE' as const,
      };

      // Act
      const result = await getAccountListFromPdp(
        mockReq as Request,
        mockRes as Response,
        mockQueryDecisionRequest,
        mockPdpClientToken,
        paramsWithAllFilter
      );

      // Assert
      expect(result).toHaveLength(2);
      expect(result[0].status).toBe('ACTIVE');
      expect(result[1].status).toBe('INACTIVE');
    });

    it('should return all accounts when accountStatus is not specified', async () => {
      // Arrange
      const mockPdpQueryResults = [
        {
          value: 'account1',
          decision: 'PERMIT',
          statements: [
            {
              id: 'stmt1',
              name: 'Active Account',
              code: 'ACC1',
              payload: JSON.stringify({
                name: 'Active Account',
                bsb: '035845',
                accountNumber: '123456789',
                type: 'Corporate Investment Account',
                status: 'active',
                currency: 'AUD',
              }),
              obligatory: true,
              fulfilled: true,
              attributes: {
                status: 'active',
              },
            },
          ],
        },
        {
          value: 'account2',
          decision: 'PERMIT',
          statements: [
            {
              id: 'stmt2',
              name: 'Inactive Account',
              code: 'ACC2',
              payload: JSON.stringify({
                name: 'Inactive Account',
                bsb: '035845',
                accountNumber: '987654321',
                type: 'Corporate Investment Account',
                status: 'inactive',
                currency: 'AUD',
              }),
              obligatory: true,
              fulfilled: true,
              attributes: {
                status: 'inactive',
              },
            },
          ],
        },
      ];

      (getAccountIdsFromPdpQueryResult as jest.Mock).mockResolvedValue(
        mockPdpQueryResults
      );

      // Act - no accountStatus specified (should default to all accounts)
      const result = await getAccountListFromPdp(
        mockReq as Request,
        mockRes as Response,
        mockQueryDecisionRequest,
        mockPdpClientToken,
        mockParams
      );

      // Assert
      expect(result).toHaveLength(2);
      expect(result[0].status).toBe('ACTIVE');
      expect(result[1].status).toBe('INACTIVE');
    });

    it('should generate unique IDs for each account', async () => {
      // Arrange
      mockV4.mockReturnValueOnce('id1').mockReturnValueOnce('id2');

      const mockPdpQueryResults: PdpQueryResult[] = [
        {
          value: 'account1',
          decision: 'PERMIT',
          statements: [
            {
              id: 'stmt1',
              name: 'Account 1 Statement',
              code: 'ACC1',
              payload: JSON.stringify({ name: 'Account 1' }),
              obligatory: true,
              fulfilled: true,
              attributes: {},
            },
          ],
        },
        {
          value: 'account2',
          decision: 'PERMIT',
          statements: [
            {
              id: 'stmt2',
              name: 'Account 2 Statement',
              code: 'ACC2',
              payload: JSON.stringify({ name: 'Account 2' }),
              obligatory: true,
              fulfilled: true,
              attributes: {},
            },
          ],
        },
      ];

      (getAccountIdsFromPdpQueryResult as jest.Mock).mockResolvedValue(
        mockPdpQueryResults
      );

      // Act
      const result = await getAccountListFromPdp(
        mockReq as Request,
        mockRes as Response,
        mockQueryDecisionRequest,
        mockPdpClientToken,
        mockParams
      );

      // Assert
      expect(result[0].id).toBe('id1');
      expect(result[1].id).toBe('id2');
      expect(mockV4).toHaveBeenCalledTimes(2);
    });
  });
});
