/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response, NextFunction } from 'express';
import {
  STATUS_CODES,
  handleControllerError,
  normaliseData,
  ControllerParams,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { PDP_QUERY_ACTIONS } from '@mesh-tenant-user-authorisation-policy-decision-engine/entitlements-api-lib';
import {
  buildGetAccountListController,
  getAccountListHandler,
} from '../src/getAccountListController';
import { getAccountListFromPdp } from '../src/transformAccountLists';

// Mock external dependencies
jest.mock('../src/transformAccountLists');
jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => {
  const handleControllerError = jest.fn();
  return {
    handleControllerError,
    normaliseData: jest.fn(),
    STATUS_CODES: {
      OK: 200,
    },
    createControllerWrapper: jest.fn((handlerFn, params) => {
      // Return a mock Express middleware function
      return jest.fn(async (req, res, next) => {
        try {
          // Call the original handler function for testing
          await handlerFn(req, res, params);
        } catch (error) {
          // Mock the real createControllerWrapper error handling
          const { logger } = res.locals;
          handleControllerError({ error, res, logger });
          next(error);
        }
      });
    }),
  };
});

const mockGetAccountListFromPdp = getAccountListFromPdp as jest.MockedFunction<
  typeof getAccountListFromPdp
>;
const mockNormaliseData = normaliseData as jest.MockedFunction<
  typeof normaliseData
>;

describe('getAccountListController', () => {
  let mockReq: Partial<Request>;
  let mockRes: Partial<Response>;
  let mockNext: NextFunction;
  let mockControllerParams: ControllerParams;
  let consoleSpy: jest.SpyInstance;

  beforeEach(() => {
    // Mock console.log to avoid noise in tests
    consoleSpy = jest.spyOn(console, 'log').mockImplementation();

    mockReq = {
      query: { groupId: 'test-group' },
      get: jest.fn().mockReturnValue('test-org-cis-key'),
    };

    mockRes = {
      locals: {
        apiHeaders: {},
        logger: {
          error: jest.fn(),
        },
      },
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      end: jest.fn(),
    };

    mockNext = jest.fn();

    mockControllerParams = {
      RUNTIME: {
        isLocal: jest.fn().mockReturnValue(false),
      },
      normalise: jest.fn(),
      apiClient: {
        queryDecisionRequest: jest.fn(),
      },
      readMeshSecrets: jest.fn().mockReturnValue({
        pdpClientToken: 'mock-token',
      }),
      pdpQueryAction: PDP_QUERY_ACTIONS.VIEW_ACCOUNT,
    };

    // Reset all mocks
    jest.clearAllMocks();
  });

  afterEach(() => {
    consoleSpy.mockRestore();
  });

  describe('getAccountListHandler', () => {
    it('should successfully process account list request', async () => {
      // Arrange
      const mockExpApiResponseData = [
        {
          id: 'test-id',
          accountId: '035845 123456789',
          accountName: 'Test Account',
          accountType: 'Corporate Investment Account',
          status: 'ACTIVE' as const,
          currencyCode: 'AUD',
        },
      ];

      const mockNormalisedData = {
        entities: {
          accountList: mockExpApiResponseData,
        },
        result: {
          accountList: ['test-id'],
        },
      };

      mockGetAccountListFromPdp.mockResolvedValue(mockExpApiResponseData);
      mockNormaliseData.mockReturnValue(mockNormalisedData);

      // Act
      await getAccountListHandler(
        mockReq as Request,
        mockRes as Response,
        mockControllerParams
      );

      expect(mockControllerParams.readMeshSecrets).toHaveBeenCalledWith(
        ['pdpClientToken'],
        mockRes.locals.logger
      );
      expect(mockGetAccountListFromPdp).toHaveBeenCalledWith(
        mockReq,
        mockRes,
        mockControllerParams.apiClient.queryDecisionRequest,
        'mock-token',
        {
          groupId: 'test-group',
          requestAction: PDP_QUERY_ACTIONS.VIEW_ACCOUNT,
          orgCisKey: 'test-org-cis-key',
        }
      );
      expect(mockNormaliseData).toHaveBeenCalledWith(
        'accountList',
        mockExpApiResponseData,
        mockControllerParams.normalise
      );
      expect(mockRes.status).toHaveBeenCalledWith(STATUS_CODES.OK);
      expect(mockRes.json).toHaveBeenCalledWith(mockNormalisedData);
      expect(mockRes.end).toHaveBeenCalled();
    });

    it('should set access token when in local environment', async () => {
      // Arrange
      mockControllerParams.RUNTIME.isLocal.mockReturnValue(true);
      const mockExpApiResponseData = [];
      const mockNormalisedData = {
        entities: { accountList: [] },
        result: { accountList: [] },
      };

      mockGetAccountListFromPdp.mockResolvedValue(mockExpApiResponseData);
      mockNormaliseData.mockReturnValue(mockNormalisedData);

      // Act
      await getAccountListHandler(
        mockReq as Request,
        mockRes as Response,
        mockControllerParams
      );

      // Assert
      expect(mockRes.locals.apiHeaders['x-access-token']).toBe(
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjM0NTY3ODkwIiwiaWFtSUQiOiIxMjM0NTY3ODkwIiwiZW1wbG95ZWVJRCI6IjEyMzQ1Njc4OTAifQ.gocKT5owkYeZ9jJS8k9AV3BwtcwZVqBB0rO_xcoiyyE'
      );
    });

    it('should handle missing query parameters gracefully', async () => {
      // Arrange
      mockReq.query = {};
      const mockExpApiResponseData = [];
      const mockNormalisedData = {
        entities: { accountList: [] },
        result: { accountList: [] },
      };

      mockGetAccountListFromPdp.mockResolvedValue(mockExpApiResponseData);
      mockNormaliseData.mockReturnValue(mockNormalisedData);

      // Act
      await getAccountListHandler(
        mockReq as Request,
        mockRes as Response,
        mockControllerParams
      );

      // Assert
      expect(mockGetAccountListFromPdp).toHaveBeenCalledWith(
        mockReq,
        mockRes,
        mockControllerParams.apiClient.queryDecisionRequest,
        'mock-token',
        {
          groupId: undefined,
          requestAction: PDP_QUERY_ACTIONS.VIEW_ACCOUNT,
          orgCisKey: 'test-org-cis-key',
        }
      );
    });

    it('should handle missing protected-orgId header', async () => {
      // Arrange
      (mockReq.get as jest.Mock).mockReturnValue(undefined);
      const mockExpApiResponseData = [];
      const mockNormalisedData = {
        entities: { accountList: [] },
        result: { accountList: [] },
      };

      mockGetAccountListFromPdp.mockResolvedValue(mockExpApiResponseData);
      mockNormaliseData.mockReturnValue(mockNormalisedData);

      // Act
      await getAccountListHandler(
        mockReq as Request,
        mockRes as Response,
        mockControllerParams
      );

      // Assert
      expect(mockGetAccountListFromPdp).toHaveBeenCalledWith(
        mockReq,
        mockRes,
        mockControllerParams.apiClient.queryDecisionRequest,
        'mock-token',
        {
          groupId: 'test-group',
          requestAction: PDP_QUERY_ACTIONS.VIEW_ACCOUNT,
          orgCisKey: undefined,
        }
      );
    });

    it('should pass accountStatus query parameter when provided', async () => {
      // Arrange
      mockReq.query = {
        ...mockReq.query,
        accountStatus: 'ACTIVE',
      };
      const mockExpApiResponseData = [];
      const mockNormalisedData = {
        entities: { accountList: [] },
        result: { accountList: [] },
      };

      mockGetAccountListFromPdp.mockResolvedValue(mockExpApiResponseData);
      mockNormaliseData.mockReturnValue(mockNormalisedData);

      // Act
      await getAccountListHandler(
        mockReq as Request,
        mockRes as Response,
        mockControllerParams
      );

      // Assert
      expect(mockGetAccountListFromPdp).toHaveBeenCalledWith(
        mockReq,
        mockRes,
        mockControllerParams.apiClient.queryDecisionRequest,
        'mock-token',
        {
          groupId: 'test-group',
          requestAction: PDP_QUERY_ACTIONS.VIEW_ACCOUNT,
          orgCisKey: 'test-org-cis-key',
          accountStatus: 'ACTIVE',
        }
      );
    });

    it('should handle ACTIVE_AND_INACTIVE accountStatus parameter', async () => {
      // Arrange
      mockReq.query = {
        ...mockReq.query,
        accountStatus: 'ACTIVE_AND_INACTIVE',
      };
      const mockExpApiResponseData = [];
      const mockNormalisedData = {
        entities: { accountList: [] },
        result: { accountList: [] },
      };

      mockGetAccountListFromPdp.mockResolvedValue(mockExpApiResponseData);
      mockNormaliseData.mockReturnValue(mockNormalisedData);

      // Act
      await getAccountListHandler(
        mockReq as Request,
        mockRes as Response,
        mockControllerParams
      );

      // Assert
      expect(mockGetAccountListFromPdp).toHaveBeenCalledWith(
        mockReq,
        mockRes,
        mockControllerParams.apiClient.queryDecisionRequest,
        'mock-token',
        {
          groupId: 'test-group',
          requestAction: PDP_QUERY_ACTIONS.VIEW_ACCOUNT,
          orgCisKey: 'test-org-cis-key',
          accountStatus: 'ACTIVE_AND_INACTIVE',
        }
      );
    });

    it('should not pass accountStatus when not provided in query', async () => {
      // Arrange
      mockReq.query = {
        groupId: 'test-group',
        // accountStatus intentionally omitted
      };
      const mockExpApiResponseData = [];
      const mockNormalisedData = {
        entities: { accountList: [] },
        result: { accountList: [] },
      };

      mockGetAccountListFromPdp.mockResolvedValue(mockExpApiResponseData);
      mockNormaliseData.mockReturnValue(mockNormalisedData);

      // Act
      await getAccountListHandler(
        mockReq as Request,
        mockRes as Response,
        mockControllerParams
      );

      // Assert
      expect(mockGetAccountListFromPdp).toHaveBeenCalledWith(
        mockReq,
        mockRes,
        mockControllerParams.apiClient.queryDecisionRequest,
        'mock-token',
        {
          groupId: 'test-group',
          requestAction: PDP_QUERY_ACTIONS.VIEW_ACCOUNT,
          orgCisKey: 'test-org-cis-key',
          accountStatus: undefined,
        }
      );
    });

    it('should throw error when readMeshSecrets fails', async () => {
      // Arrange
      const error = new Error('Failed to read secrets');
      mockControllerParams.readMeshSecrets.mockImplementation(() => {
        throw error;
      });

      // Act & Assert
      await expect(
        getAccountListHandler(
          mockReq as Request,
          mockRes as Response,
          mockControllerParams
        )
      ).rejects.toThrow('Failed to read secrets');
    });

    it('should throw error when getAccountListFromPdp fails', async () => {
      // Arrange
      const error = new Error('PDP request failed');
      mockGetAccountListFromPdp.mockRejectedValue(error);

      // Act & Assert
      await expect(
        getAccountListHandler(
          mockReq as Request,
          mockRes as Response,
          mockControllerParams
        )
      ).rejects.toThrow('PDP request failed');
    });
  });

  describe('buildGetAccountListController', () => {
    it('should return a wrapped controller function', async () => {
      // Arrange
      const mockExpApiResponseData = [];
      const mockNormalisedData = {
        entities: { accountList: [] },
        result: { accountList: [] },
      };

      mockGetAccountListFromPdp.mockResolvedValue(mockExpApiResponseData);
      mockNormaliseData.mockReturnValue(mockNormalisedData);

      // Act
      const controller = buildGetAccountListController(mockControllerParams);
      await controller(mockReq as Request, mockRes as Response, mockNext);

      // Assert
      expect(typeof controller).toBe('function');
      expect(controller.length).toBe(3); // req, res, next parameters
      expect(mockGetAccountListFromPdp).toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(STATUS_CODES.OK);
      expect(mockNext).not.toHaveBeenCalled();
    });

    it('should handle errors in built controller', async () => {
      // Arrange
      const error = new Error('Controller error');
      mockGetAccountListFromPdp.mockRejectedValue(error);

      const mockHandleControllerError =
        handleControllerError as jest.MockedFunction<
          typeof handleControllerError
        >;

      // Act
      const controller = buildGetAccountListController(mockControllerParams);
      await controller(mockReq as Request, mockRes as Response, mockNext);

      // Assert
      expect(mockHandleControllerError).toHaveBeenCalledWith({
        error,
        res: mockRes,
        logger: mockRes.locals.logger,
      });
      expect(mockNext).toHaveBeenCalledWith(error);
    });
  });

  describe('Integration tests', () => {
    it('should handle complete flow with real-like data', async () => {
      // Arrange
      const mockExpApiResponseData = [
        {
          id: 'acc-1',
          accountId: '035845 123456789',
          accountName: 'Business Account',
          accountType: 'Corporate Investment Account',
          status: 'ACTIVE' as const,
          currencyCode: 'AUD',
        },
        {
          id: 'acc-2',
          accountId: '035845 987654321',
          accountName: 'Savings Account',
          accountType: 'Personal Savings Account',
          status: 'INACTIVE' as const,
          currencyCode: 'AUD',
        },
      ];

      const mockNormalisedData = {
        entities: {
          accountList: mockExpApiResponseData,
        },
        result: {
          accountList: ['acc-1', 'acc-2'],
        },
      };

      mockGetAccountListFromPdp.mockResolvedValue(mockExpApiResponseData);
      mockNormaliseData.mockReturnValue(mockNormalisedData);

      // Act
      const controller = buildGetAccountListController(mockControllerParams);
      await controller(mockReq as Request, mockRes as Response, mockNext);

      // Assert
      expect(mockRes.status).toHaveBeenCalledWith(200);
      expect(mockRes.json).toHaveBeenCalledWith(mockNormalisedData);
      expect(mockRes.end).toHaveBeenCalled();
      expect(mockNext).not.toHaveBeenCalled();
    });

    it('should work with empty request query', async () => {
      // Arrange
      mockReq = {
        query: null,
        get: jest.fn().mockReturnValue('test-org-cis-key'),
      };

      const mockExpApiResponseData = [];
      const mockNormalisedData = {
        entities: { accountList: [] },
        result: { accountList: [] },
      };

      mockGetAccountListFromPdp.mockResolvedValue(mockExpApiResponseData);
      mockNormaliseData.mockReturnValue(mockNormalisedData);

      // Act
      const controller = buildGetAccountListController(mockControllerParams);
      await controller(mockReq as Request, mockRes as Response, mockNext);

      // Assert
      expect(mockGetAccountListFromPdp).toHaveBeenCalledWith(
        mockReq,
        mockRes,
        mockControllerParams.apiClient.queryDecisionRequest,
        'mock-token',
        {
          groupId: undefined,
          requestAction: PDP_QUERY_ACTIONS.VIEW_ACCOUNT,
          orgCisKey: 'test-org-cis-key',
        }
      );
      expect(mockRes.status).toHaveBeenCalledWith(200);
    });
  });
});
