# @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

A utility library for AccountList helpers and functions, designed for use within the Multiverse UI Common Library ecosystem.

## Features

- Simplifies AccountList API requests and responses
- Designed for easy/modular integration with other Multiverse UI Common Library packages

## Installation

```bash
npm install @mesh-tenant-multiverse-ui-common/mv-apiaccountlist
```

## To build locally

```bash
nx run @mesh-tenant-multiverse-ui-common/mv-apiaccountlist:build
```
