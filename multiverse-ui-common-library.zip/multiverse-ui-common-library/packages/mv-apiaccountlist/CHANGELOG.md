# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.226.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.226.0...v1.226.1) (2026-02-07)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

## [1.225.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.225.4...v1.225.5) (2026-02-05)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

## [1.221.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.221.1...v1.221.2) (2026-01-22)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

## [1.219.8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.7...v1.219.8) (2026-01-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

## [1.219.7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.6...v1.219.7) (2026-01-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

## [1.219.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.4...v1.219.5) (2026-01-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

## [1.219.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.0...v1.219.1) (2025-12-19)

### 💥 Bug Fixes

- add back deleted files | ART-88711 ([9b541f6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9b541f66f1babf412fa5f9f318b3533504b1ee0e))

## [1.219.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.218.0...v1.219.0) (2025-12-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

## [1.217.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.216.0...v1.217.0) (2025-12-17)

### 🚀 Features

- uplife accountlist pdp function to support divisions | ART-84849 ([d154bb3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/d154bb338576a9ec60b994520464d294c7d96273))

## [1.213.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.212.0...v1.213.0) (2025-12-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

## [1.212.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.211.0...v1.212.0) (2025-12-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

## [1.209.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.209.0...v1.209.1) (2025-11-09)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

## [1.209.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.208.0...v1.209.0) (2025-11-04)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

## [1.208.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.207.0...v1.208.0) (2025-10-31)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

## [1.196.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.195.0...v1.196.0) (2025-10-16)

### 🚀 Features

- updating apiaccountlist to accept accountstatus query param | ART-82994 ([dc20034](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/dc200343ea8eb62ba76e4ecbedc803bd2e27d926))

## [1.190.0] (2025-10-14)

### 🚀 Features

- **accountStatus**: Add new accountStatus parameter to filter accounts by status
  - Supports 'ACTIVE' to return only active accounts
  - Supports 'ACTIVE_AND_INACTIVE' to return all accounts (default behavior)
  - Available in both getAccountListFromPdp function and API controller
  - Parameter name matches Swagger specification for consistency

## [1.189.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.188.2...v1.189.0) (2025-10-09)

### 🚀 Features

- update status matching logic | ART-71494 ([ccf677c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/ccf677cc6fe1324c667712ef11ba1b0329bd32df))
- update to pass test | ART-71494 ([f592a35](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f592a3517d600bb83c481ac6874548e990124486))

## [1.186.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.186.0...v1.186.1) (2025-10-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

## [1.185.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.185.1...v1.185.2) (2025-10-02)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

## [1.185.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.184.9...v1.185.0) (2025-10-01)

### 🚀 Features

- update mock token for account list api | ART-63785 ([7ec96fd](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/7ec96fdc8554ac7df22444bded4151b41b163683))
- update test of account list api | ART-63785 ([89cfb63](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/89cfb638189680c4271a963729c8c65b1d28ab4d))

## [1.184.8](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.184.7...v1.184.8) (2025-09-30)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

## [1.184.6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.184.5...v1.184.6) (2025-09-26)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-apiaccountlist

## [1.183.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.182.7...v1.183.0) (2025-09-15)

### 🚀 Features

- include orgCisKey in GetAccountListFromPdp | ART-61915 ([a27ea3d](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a27ea3d9ebc23e7fb660825003419ffac35cc75a))

## [1.181.2](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.181.1...v1.181.2) (2025-09-03)

### 💥 Bug Fixes

- updated mapping logic to include space between bsb and accnumber | ART-71494 ([b67f650](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b67f650174f7b489e6995ef13599b9c01bec0787))

## [1.180.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.179.3...v1.180.0) (2025-09-02)

### 🚀 Features

- updated package name and removed pageSize sorting | ART-71494 ([44edd77](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/44edd775412d2361bd37f88b25de108b547fdaea))

## [1.179.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.178.12...v1.179.0) (2025-09-01)

### 🚀 Features

- add new apiarrangement package | ART-71494 ([91f6cbd](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/91f6cbd5691c7c2082f9d4286bec94ccf7b2827c))
- updated apiarrangements package | ART-71494 ([b764aed](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/b764aed77e81d5b7d5a6e4aef77b7ea92b547ec5))
- updated lock file + transformAccountLists function | ART-71494 ([98b00f7](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/98b00f75cb062653e2ce1219e4db68c1b8a6eb0c))
- updated tsx file to ts | ART-71494 ([7c6059e](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/7c6059ec9bfc1a43cf78ffb07f717a9202acd3ac))
