import BunyanLogger from 'bunyan';

export type PdpQueryResult = {
  attribute?: string;
  value: string;
  decision: string;
  statements?: {
    id: string;
    name: string;
    code: string;
    payload: string;
    obligatory: boolean;
    fulfilled: boolean;
    attributes: Record<string, unknown>;
  }[];
};

export interface GetAccountListData {
  entities?: {
    accountList?: {
      /**
       * A unique id generated for an arrangement which is the mode of communication between the UI and Exp API
       * @format uuid
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * Full account number with format <BSB  Account Number> -> "035845 123456789"
       * @maxLength 35
       * @pattern ^[0-9]{6} [a-zA-Z\d.]{6,28}$
       * @example "035845 103784254"
       */
      accountId?: string;
      /**
       * Account Name
       * @minLength 1
       * @maxLength 140
       * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
       * @example "Apple Tree"
       */
      accountName?: string;
      /**
       * Arrangement type; it is product name in master product system
       * @maxLength 1000
       * @pattern ^[\w ]+$
       * @example "Corporate Investment Account"
       */
      accountType?: string;
      /**
       * Status; example-> Active, Inactive
       * @example "Active"
       */
      status?: 'ACTIVE' | 'INACTIVE';
      /**
       * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
       * @pattern ^\w{3}$
       * @example "AUD"
       */
      currencyCode?: string;
    }[];
  };
  /** @example {"accountList":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    accountList?: string[];
  };
}
export interface AccountListResult {
  accountList: string[];
}

export type Logger = BunyanLogger | Console;

export interface GetAccountListFromPdpParams {
  groupId?: string;
  divisionId?: string;
  userId?: string;
  requestAction?: string;
  orgCisKey?: string;
}

export type ExpApiResponseData = GetAccountListData['entities']['accountList'];
