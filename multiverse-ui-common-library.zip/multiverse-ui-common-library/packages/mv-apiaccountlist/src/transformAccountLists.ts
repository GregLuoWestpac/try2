import {
  APIClient,
  getAccountIdsFromPdpQueryResult,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { Request, Response } from 'express';
import {
  ExpApiResponseData,
  GetAccountListFromPdpParams,
  PdpQueryResult,
} from './types';
import { v4 } from 'uuid';

const parsePayload = (payload?: string): Record<string, unknown> => {
  try {
    return payload ? JSON.parse(payload) : {};
  } catch {
    return {};
  }
};

const buildAccountListResponseFromPdpResults = (
  pdpQueryResult: PdpQueryResult[]
): ExpApiResponseData => {
  const sorted = pdpQueryResult.sort((a, b) => {
    const aPayload = a.statements?.[0]?.payload;
    const bPayload = b.statements?.[0]?.payload;
    const aAccountName = (parsePayload(aPayload).name as string) ?? '';
    const bAccountName = (parsePayload(bPayload).name as string) ?? '';

    return aAccountName.localeCompare(bAccountName);
  });

  return sorted.map(item => {
    const payloadObj = parsePayload(item.statements?.[0]?.payload);
    return {
      id: v4(),
      accountId:
        (payloadObj.bsb as string) + ' ' + (payloadObj.accountNumber as string),
      accountName: (payloadObj.name as string) ?? '',
      accountType: (payloadObj.type as string) ?? '',
      status:
        ((payloadObj.status as string) ?? '').toLowerCase() === 'active'
          ? 'ACTIVE'
          : 'INACTIVE',
      currencyCode: (payloadObj.currency as string) ?? '',
    };
  });
};

export const getAccountListFromPdp = async (
  req: Request,
  res: Response,
  queryDecisionRequest: APIClient,
  pdpClientToken: string,
  params: GetAccountListFromPdpParams = {}
): Promise<ExpApiResponseData> => {
  const {
    groupId,
    requestAction,
    orgCisKey,
    accountStatus,
    divisionId,
    userId,
  } = params;

  const permittedAccountIds = await getAccountIdsFromPdpQueryResult({
    res,
    req,
    queryDecisionRequest,
    pdpClientToken,
    userId,
    groupId,
    divisionId,
    requestAction,
    orgCisKey,
  });

  const expApiResponseData =
    buildAccountListResponseFromPdpResults(permittedAccountIds);

  if (accountStatus === 'ACTIVE') {
    return expApiResponseData.filter(account => account.status === 'ACTIVE');
  }

  return expApiResponseData;
};
