import { GetAccountListFromPdpParams, AccountListEntity } from './types';
import { Request, Response } from 'express';
import { APIClient } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

export type ExpApiResponseData = AccountListEntity[];

export const getAccountListFromPdp: (
  req: Request,
  res: Response,
  queryDecisionRequest: APIClient,
  pdpClientToken: string,
  params: GetAccountListFromPdpParams
) => Promise<ExpApiResponseData>;
