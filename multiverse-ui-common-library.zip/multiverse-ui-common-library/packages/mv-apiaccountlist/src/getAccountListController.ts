/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response } from 'express';
import {
  ApiResponse,
  normaliseData,
  STATUS_CODES,
  createControllerWrapper,
  ControllerParams,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { getAccountListFromPdp } from './transformAccountLists';
import { ExpApiResponseData } from './types';

/**
 * Core handler function for getting account list
 */
export const getAccountListHandler = async (
  req: Request,
  res: Response,
  controllerParams: ControllerParams
): Promise<void> => {
  const { RUNTIME, normalise, apiClient, readMeshSecrets, pdpQueryAction } =
    controllerParams;
  const { apiHeaders, logger } = res.locals;
  const { OK } = STATUS_CODES;
  const queryParams = req.query || {};
  const protectedOrgCisKeyId = req.get('protected-orgId');
  const { queryDecisionRequest } = apiClient;
  const requestAction =
    pdpQueryAction || (queryParams.pdpQueryAction as string);

  if (RUNTIME.isLocal()) {
    apiHeaders['x-access-token'] =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjM0NTY3ODkwIiwiaWFtSUQiOiIxMjM0NTY3ODkwIiwiZW1wbG95ZWVJRCI6IjEyMzQ1Njc4OTAifQ.gocKT5owkYeZ9jJS8k9AV3BwtcwZVqBB0rO_xcoiyyE';
  }

  const { pdpClientToken } = readMeshSecrets(['pdpClientToken'], logger);
  const userId = apiHeaders['x-userId'];

  const expApiResponseData = await getAccountListFromPdp(
    req,
    res,
    queryDecisionRequest,
    pdpClientToken,
    {
      groupId: queryParams?.groupId as string,
      requestAction: requestAction,
      orgCisKey: protectedOrgCisKeyId,
      divisionId: queryParams.divisionId as string,
      userId,
      accountStatus: queryParams?.accountStatus as
        | 'ACTIVE'
        | 'ACTIVE_AND_INACTIVE',
    }
  );

  const normalisedData = normaliseData(
    'accountList',
    expApiResponseData,
    normalise
  ) as ApiResponse<{ accountList: ExpApiResponseData }>;

  res.status(OK).json(normalisedData).end();
};

/**
 * Builds the account list controller using the generic wrapper
 */
export const buildGetAccountListController = (
  controllerParams: ControllerParams
) => {
  return createControllerWrapper(getAccountListHandler, controllerParams);
};
