# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.178.5](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.178.4...v1.178.5) (2025-08-13)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-account-additional-details

## [1.178.4](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.178.3...v1.178.4) (2025-08-12)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-account-additional-details

## [1.102.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.101.0...v1.102.0) (2025-04-03)

### 🚀 Features

- ART-41757 tiny ([2358656](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/23586563fa541f3896097da89852342bb7c23853))
- ART-41757 update MVAccountAdditionalDetails ([f17e59c](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/f17e59c6b3da31b70b41bdf00eff67a6cea3e93b))
- ART-41757 update MVAccountAdditionalDetails ([a26f6ab](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/a26f6abef52cf0fc0e8889e53100d3a7a11888c7))

# Change Log
