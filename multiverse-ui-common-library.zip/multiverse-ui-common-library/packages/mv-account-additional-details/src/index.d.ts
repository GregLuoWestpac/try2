import React from 'react';

export type MVAccountAdditionalDetailsItem = {
  label: string;
  information: React.ReactNode;
};

export type MVAccountAdditionalDetailsProps = {
  data: MVAccountAdditionalDetailsItem[];
};

export const MVAccountAdditionalDetails: (
  props: MVAccountAdditionalDetailsProps
) => React.ReactElement;
