import React from 'react';

type MVAccountAdditionalDetailsItem = {
  label: string;
  information: React.ReactNode;
};

export type MVAccountAdditionalDetailsProps = {
  data: MVAccountAdditionalDetailsItem[];
};

export function MVAccountAdditionalDetails({
  data,
}: MVAccountAdditionalDetailsProps) {
  return (
    <Alert>
      <table>
        <tbody>
          {data.map(item => (
            <tr key={item.label}>
              <td className="font-bold whitespace-nowrap align-top pr-1 w-1">
                {item.label}
              </td>
              <td>{item.information}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </Alert>
  );
}

function Alert({ children }: { children: React.ReactNode }) {
  return (
    <div className="typography-body-10 relative mb-4 xsl:flex text-info border-y border-info-50 bg-info-5 mt-2 p-2">
      <span className="float-left flex-none mr-1 xsl:mr-2">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          role="img"
          focusable="false"
          className="inline-block transition-colors disabled:pointer-events-none disabled:opacity-50 xsl:size-4 size-3"
          aria-label="Info"
        >
          <path d="M13 18V10H11V18H13Z" fill="currentColor"></path>
          <path d="M13 6V8H11V6H13Z" fill="currentColor"></path>
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M12 24C18.6278 24 24 18.627 24 12C24 5.373 18.6278 0 12 0C5.37225 0 0 5.373 0 12C0 18.627 5.37225 24 12 24ZM2 12C2 6.47714 6.47714 2 12 2C17.5229 2 22 6.47714 22 12C22 17.5229 17.5229 22 12 22C6.47714 22 2 17.5229 2 12Z"
            fill="currentColor"
          ></path>
        </svg>
      </span>

      <div className="relative flex-1 overflow-hidden xsl:top-[0.125rem] [&_a]:underline">
        {children}
      </div>
    </div>
  );
}
