/**
 * @description custom hook which consolidates logics for closing a page in both openfin web and openfin desktop
 * @reference  https://confluence.srv.westpac.com.au/display/WDVFY24/Technical+Interaction+Between+W1+and+W1C#TechnicalInteractionBetweenW1andW1C-Closingthecurrentcontainertab
 */
export function useUnifyClose(showConfirmModal: boolean): {
  closeTab: () => void | Promise<void>;
};
