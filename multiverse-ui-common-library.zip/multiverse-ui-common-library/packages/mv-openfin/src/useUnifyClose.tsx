import {
  useClose,
  useConfirmClose,
  useCancelModal,
  useIsDesktopVersion,
} from '@mesh-tenant-multiverse-common/react';

/**
 * @description custom hook which consolidates logics for closing a page in both openfin web and openfin desktop
 * @reference  https://confluence.srv.westpac.com.au/display/WDVFY24/Technical+Interaction+Between+W1+and+W1C#TechnicalInteractionBetweenW1andW1C-Closingthecurrentcontainertab
 */
export const useUnifyClose = (
  showConfirmModal: boolean
): { closeTab: () => void | Promise<void> } => {
  const isOpenfinDesktop = useIsDesktopVersion();

  // this hook should only be used when it is openfin desktop, it intercepts close tab
  useConfirmClose(showConfirmModal && isOpenfinDesktop);

  const { showModal } = useCancelModal();
  const { closeTab } = useClose();

  // react modal should only be shown when it is not openfin desktop version
  const shouldShowReactModal = showConfirmModal && !isOpenfinDesktop;

  return { closeTab: shouldShowReactModal ? showModal : closeTab };
};
