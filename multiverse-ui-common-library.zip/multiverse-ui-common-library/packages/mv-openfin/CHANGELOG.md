# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.219.1](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.219.0...v1.219.1) (2025-12-19)

### 💥 Bug Fixes

- add back deleted files | ART-88711 ([9b541f6](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/commit/9b541f66f1babf412fa5f9f318b3533504b1ee0e))

## [1.219.0](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.218.0...v1.219.0) (2025-12-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-openfin

## [1.184.3](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.184.2...v1.184.3) (2025-09-24)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-openfin

## [1.178.11](https://bitbucket.srv.westpac.com.au/wdp/multiverse-ui-common-library/compare/v1.178.10...v1.178.11) (2025-08-19)

**Note:** Version bump only for package @mesh-tenant-multiverse-ui-common/mv-openfin
