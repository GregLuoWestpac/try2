import { Badge, Grid, GridItem, Well } from '@westpac/ui';
import React from 'react';

export type MVAccountSummaryItem = {
  title: string;
  content: React.ReactNode | string;
  status?: string;
  statusColor?: 'success' | 'hero' | 'warning' | 'danger';
  maxWidth?: number;
  minWidth?: number;
  truncate?: boolean;
};

export type MVAccountSummaryProps = {
  header?: React.ReactNode;
  items: MVAccountSummaryItem[];
  error?: React.ReactNode;
  gridClassName?: string;
  variant?: 'default' | 'outline';
};

export default function MVAccountSummary(props: MVAccountSummaryProps) {
  const { header, items, error, gridClassName, variant = 'default' } = props;

  const getWellStyle = (variant: 'default' | 'outline') => {
    switch (variant) {
      case 'default':
        return 'bg-light border-light';
      case 'outline':
        return 'bg-transparent border-border';
      default:
        return 'bg-light border-light';
    }
  };

  return (
    <Well className={`!p-2.5 w-full mt-2.5 mb-2.5 ${getWellStyle(variant)}`}>
      {header}
      {error}
      <Grid
        tag="ol"
        className={`${header ? 'mt-2' : ''} flex flex-wrap !gap-1.5  ${gridClassName}`}
      >
        {items.map((item, i) => {
          const classes = [];
          const styles: React.CSSProperties = {};
          if (i !== items.length - 1) {
            classes.push('pr-1.5 border-border border-r-[1px] min-w-0');
          }

          if (!isNaN(item.minWidth)) {
            styles.minWidth = `${item.minWidth}rem`;
          }
          if (!isNaN(item.maxWidth)) {
            styles.maxWidth = `${item.maxWidth}rem`;
          }

          return (
            <GridItem
              key={item.title}
              tag="li"
              className={classes.join(' ')}
              style={styles}
            >
              <p className="typography-body-10 text-muted font-bold">
                {item.title}
              </p>
              <p
                className={`typography-body-9 text-hero font-normal mt-0.5 ${item.truncate ? 'truncate text-ellipsis' : 'break-words'}`}
              >
                {item.content}
              </p>
              {item.status && (
                <Badge
                  color={item.statusColor ?? 'success'}
                  soft
                  className="mt-1"
                >
                  {item.status}
                </Badge>
              )}
            </GridItem>
          );
        })}
      </Grid>
    </Well>
  );
}
