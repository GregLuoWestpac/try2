# Archetype for microfrontend

## Install

`npm install`


## Register consumption

Ensure your MFE is registered to be able to be rendered by your parent SPA, by adding the SPA name to consumption.yaml

```sh
consumption:
  singlePageApplications:
    - name: [SPA_name]
```

## Configure

 Refer to **4. Configure MFE (optional - Validate only step)** in the [confluence page](https://confluence.srv.westpac.com.au/display/MESH/3.1.1+MFE+Getting+Started)


## Run locally

1. Serve MFE locally: `npm start // Start both UI, EXP API`
  You should now see (MFE) running locally on your defined port eg. `http://localhost:6001/remoteEntry.js` Port number as defined in project.json

2. The MFE (javascript files) must be consumed by a SPA (see below) in order to render HTML in a browser.

3. EXP API will run in `localhost:3001`. Port number as defined in `app-config.json`. 
  To verify the EXP API, you can obtain the `basePath` from `swagger.yaml` and run it on port 3003, appending "/healthcheck" at the end of the URL.
  For instance :  `http://localhost:3001/exp/[componentName]/reference/v2/healthcheck`


## Unit test

- For both API and UI: 
  `npm run test`

- For UI project only: 
  `npx nx run [componentName]:test`

- For API project only: 
  `npx nx run exp-[componentName]-v2:test`

- For individual UI test: 
  `	npx jest [fileName_without_extension]`

- For individual API test: 
  `	npx nx run exp-[componentName]-v2:test -- fileName_with_extension`
