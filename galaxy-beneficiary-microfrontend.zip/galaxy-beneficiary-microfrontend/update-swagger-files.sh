#!/bin/bash
# Update swagger yaml files from Bitbucket multiverse-ui-common-library, preserving folder structure

set -e

# Parse --swagger-branch argument or fallback to positional or master
BRANCH="master"
for arg in "$@"; do
  case $arg in
    --swagger-branch=*)
      BRANCH="${arg#*=}"
      ;;
    *)
      if [[ "$arg" != "--" ]]; then
        BRANCH="$arg"
      fi
      ;;
  esac
  break
done

BITBUCKET_BASE_URL="https://bitbucket.srv.westpac.com.au/projects/WDP/repos/multiverse-ui-common-library/raw/packages/mv-swagger/swagger"
BITBUCKET_API_URL="https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/files/packages/mv-swagger/swagger"

TARGET_DIR=./swagger/mv-common

echo "Discovering swagger yaml files from branch $BRANCH..."

# Get list of all yaml files in the swagger directory from Bitbucket API
FILES=$(curl -s -L "$BITBUCKET_API_URL?at=refs/heads/$BRANCH&limit=1000" | grep -oE '"[^"]+\.ya?ml"' | tr -d '"' | sort)

if [ -z "$FILES" ]; then
  echo "No yaml files found in the swagger directory on branch $BRANCH" >&2
  echo "This could mean the branch doesn't exist, has no yaml files, or there was an API error." >&2
  exit 1
fi

file_count=$(echo "$FILES" | wc -l | tr -d ' ')
echo "Found $file_count yaml file(s) to download"

echo "Updating swagger yaml files from branch $BRANCH..."
while IFS= read -r file; do
  # Skip empty lines
  [ -z "$file" ] && continue
  
  dest_dir="$TARGET_DIR/$(dirname "$file")"
  mkdir -p "$dest_dir"
  filename=$(basename "$file")
  echo "Downloading $file..."
  curl -s -L -o "$dest_dir/$filename" "$BITBUCKET_BASE_URL/$file?at=refs/heads/$BRANCH"
  if [ $? -ne 0 ]; then
    echo "Failed to update $file" >&2
    exit 1
  fi
  echo "$file updated."
done <<< "$FILES"

echo "Swagger yaml files updated successfully."
