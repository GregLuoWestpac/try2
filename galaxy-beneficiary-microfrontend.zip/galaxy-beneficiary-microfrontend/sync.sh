#!/bin/sh
# Sync feature branch with master and push

git checkout master
git pull origin master
git checkout feature/Aug-2025-ERM
git pull origin feature/Aug-2025-ERM
git merge master
git push origin feature/Aug-2025-ERM
