# PR Review Bot Configuration

## Quick Start

### Running the PR Review Bot

**Windows:**
```cmd
review.bat [options] [--base <branch>] [directory]
```

**Linux/macOS:**
```bash
chmod +x review.sh
./review.sh [options] [--base <branch>] [directory]
```

**Direct Node.js:**
```bash
node tools/pr-review/cli.js [options]
```

### Command Line Options

| Option | Description |
|--------|-------------|
| `--simple` | Use fast/small model (gpt-4.1) for quick reviews |
| `--complex` | Use large/capable model (claude-opus-4.5) for thorough reviews |
| `-v, --verbose` | Enable verbose logging with detailed execution info and timestamps |
| `--no-cache` | Disable caching of AI review results (forces fresh AI review) |
| `--clear-cache` | Clear all cached responses before running |
| `--no-bitbucket` | Skip Bitbucket PR comment integration |
| `-b, --base <branch>` | Set the base branch for diff comparison |
| `-h, --help` | Show help message with all options and configured models |

### Model Tiers

| Tier | Model | Description |
|------|-------|-------------|
| `simple` | gpt-4.1 | Fast, cost-effective model for quick reviews |
| `default` | claude-sonnet-4.5 | Balanced model for standard reviews |
| `complex` | claude-opus-4.6 | Most capable model for thorough reviews |

**Note:** Even without `--verbose`, the script displays high-level progress updates including:
- Pipeline initialization status
- AI model being used
- Files changed count
- Each stage execution progress with timing
- Completion status with icons (✅/❌/⏭️)

### Examples

```bash
# Run with default settings (shows progress output)
review.bat

# Show help with configured model information
review.bat --help

# Run with verbose logging (detailed timestamps and debug info)
review.bat --verbose

# Quick review with fast model
review.bat --simple

# Thorough review with most capable model
review.bat --complex

# Run without caching (force fresh AI review)
review.bat --no-cache

# Clear all cached responses, then run fresh review
review.bat --clear-cache

# Review changes against a specific base branch
review.bat --base develop

# Review a specific directory
review.bat --complex --base main ./src

# Skip Bitbucket PR integration
review.bat --no-bitbucket

# Combine multiple options
review.bat --verbose --no-cache --complex
```

### Example Output (Normal Mode)

```
🤖 Starting Agentic PR Review Pipeline...

📋 Using AI Model: claude-sonnet-4.5
💾 Cache: 3 cached reviews available
📊 Pipeline stages: 5 enabled

🔍 Analyzing changes (base: main)

📁 Files changed: 8

[1/5 - Code Standards Review] Running stage...
[1/5 - Code Standards Review] ✅ Complete (Cached) (0.1s)

[2/5 - Architecture Review] Running stage...
[2/5 - Architecture Review] ✅ Complete (15.7s)

[3/5 - UI/UX Standards Review] Running stage...
[3/5 - UI/UX Standards Review] ⏭️  Skipped

[4/5 - Security Review] Running stage...
[4/5 - Security Review] ✅ Complete (Cached) (0.1s)

[5/5 - Testing Coverage Review] Running stage...
[5/5 - Testing Coverage Review] ✅ Complete (6.2s)

✨ Pipeline execution complete
```

**Note:** Stages marked "(Cached)" retrieved results from previous reviews with identical code changes, significantly speeding up the review process.

## Configuration Hierarchy

The PR Review Bot uses a layered configuration system with the following priority (highest to lowest):

1. **Environment Variables** - `PR_REVIEW_[CONFIG_KEY_NAME]`
2. **Local Config** - `pr_review_bot.yaml.local` (project root directory)
3. **User Home Config** - `~/.pr_review_bot.yaml.local` (user's home directory)
4. **Base Config** - `tools/pr-review/config.yaml`

### Environment Variables

Environment variables follow the naming pattern `PR_REVIEW_[CONFIG_KEY_NAME]`. Examples:

```bash
# Bitbucket token
export PR_REVIEW_BITBUCKET_TOKEN=your_token_here
```

### Local Configuration

Create `pr_review_bot.yaml.local` in the project root for local overrides:

```yaml
# Authentication token
bitbucket_token: your_token_here
```

**Note:** This file is automatically added to `.gitignore` and should NOT be committed.

### User Home Configuration

Create `~/.pr_review_bot.yaml.local` in your home directory for user-wide configuration:

```yaml
# Your personal Bitbucket token (applies to all projects)
bitbucket_token: your_token_here
```

This allows you to set a default Bitbucket token for all projects, which can be overridden per-project using `pr_review_bot.yaml.local` in the project root.

### Base Configuration

The base configuration is in `tools/pr-review/config.yaml` and contains:
- Pipeline settings
- Stage definitions
- AI model configurations
- Bitbucket integration settings
- Output formatting options

## Configuration Keys

### Bitbucket Integration
- `bitbucket_token` - Authentication token for Bitbucket API
- `bitbucket.enabled` - Enable/disable Bitbucket integration (default: true)
- `bitbucket.autoPrompt` - Prompt before posting to PR (default: true)
- `bitbucket.baseUrl` - Bitbucket server URL
- `bitbucket.project` - Project key
- `bitbucket.repo` - Repository name

### Pipeline Settings
See `config.yaml` for complete pipeline, stage, AI, and output configuration options.

## Bitbucket PR Integration

When Bitbucket integration is enabled, the script will:

1. **Find your PR** - Automatically detect the open PR for your current branch
2. **Prompt to post** - Ask if you want to post the review (if `autoPrompt: true`)
3. **Post/Update review** - Add a new comment or update existing bot comment
4. **Provide link** - Show the PR URL for easy access

### Setting up Bitbucket Token

To enable PR commenting, create a Personal Access Token:

1. Visit: https://bitbucket.srv.westpac.com.au/plugins/servlet/access-tokens/users/[EmployeeID]/manage
2. Create token with permissions:
   - **Repository: Read**
   - **Pull Request: Write**
3. Add token to `pr_review_bot.yaml.local`:
   ```yaml
   bitbucket_token: your-token-here
   ```

Or use environment variable:
```bash
# Windows
set PR_REVIEW_BITBUCKET_TOKEN=your-token-here

# Linux/Mac
export PR_REVIEW_BITBUCKET_TOKEN=your-token-here
```

### Disabling Bitbucket Integration

To run reviews without Bitbucket posting:
```yaml
# In pr_review_bot.yaml.local
bitbucket:
  enabled: false
```

Or use the `--no-bitbucket` flag:
```bash
review.bat --no-bitbucket
```

Or set an environment variable:
```bash
set PR_REVIEW_BITBUCKET_ENABLED=false
review.bat
```

## Troubleshooting

### Windows: "Node.js is not installed"
Install Node.js from https://nodejs.org/ and ensure it's added to your PATH.

### Linux/macOS: "Permission denied"
Make the script executable: `chmod +x review.sh`

### "node_modules not found"
Run `npm install` in the project root directory.

### Cache Issues
If reviews seem stale, use `--no-cache` flag for a fresh review, or use `--clear-cache` to clear all cached responses and run fresh. You can also manually delete the `tools/pr-review/.cache/` directory.

## Development

### Testing Configuration Changes
```bash
# Test with verbose output to see config loading
review.bat --verbose --no-cache

# Test environment variable override
set PR_REVIEW_AI_SECURITY_SCANS=false
review.bat --verbose
```

### Direct CLI Usage
For development or debugging, you can run the CLI directly:
```bash
cd tools/pr-review
node cli.js --verbose --no-cache
```

### Environment Variables

| Variable | Description |
|----------|-------------|
| `PR_REVIEW_ENABLED=false` | Skip all review |
| `PR_BASE_BRANCH=develop` | Override base branch (default: auto-detect) |
| `BITBUCKET_TOKEN` | Personal Access Token for Bitbucket API |
| `DEBUG=1` | Show stack traces on error |
| `PR_REVIEW_*` | Override any config value (e.g., `PR_REVIEW_AI_PR_APPROVALS=true`) |
