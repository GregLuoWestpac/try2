/**
 * PurposeStage - Generates an executive summary describing the purpose of the change.
 * Runs as the first pipeline stage and saves its output to .temp/purpose.txt.
 */

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const PipelineStage = require('./PipelineStage');

class PurposeStage extends PipelineStage {
  constructor(config, basePath, options = {}) {
    super(config, basePath, options);
    this.outputFile = path.join(basePath, '.temp', 'purpose.txt');
  }

  /**
   * Execute the purpose stage — produces plain text, not JSON.
   */
  async execute(diffContent, fileList = []) {
    const result = await super.execute(diffContent, fileList);

    // Extract plain-text purpose from the AI response
    const purposeText = this.extractPurposeText(result);

    // Persist to disk so downstream stages/tools can read it back
    this.savePurposeText(purposeText);

    // Attach the purpose text to the result for in-memory consumers
    result.purposeText = purposeText;

    return result;
  }

  /**
   * Override invokeCopilot to use a plain-text short prompt instead of the
   * JSON-focused one in the base class. The base class shortPrompt demands
   * "Output ONLY valid JSON" which conflicts with this stage's plain-text prompt.
   */
  async invokeCopilot(prompt) {
    const { command, flag } = this.modelConfig;

    const tempDir = path.join(this.basePath, '.temp');
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }
    const tempFile = path.join(tempDir, `prompt_${this.id}.md`);
    const tempFilePosix = tempFile.replace(/\\/g, '/');

    try {
      this.log(`Writing prompt to temp file: ${tempFile}`);
      fs.writeFileSync(tempFile, prompt, 'utf8');

      // Plain-text short prompt — no JSON requirement
      const shortPrompt = `Read "${tempFilePosix}" which contains instructions and a code diff. Follow the instructions in the file and output ONLY a short plain-text paragraph. Do NOT output JSON. Do NOT show your thinking. Do NOT describe what you are doing. Just output the paragraph.`;

      const escapedPrompt = shortPrompt.replace(/"/g, '\\"');
      const modelArg = flag || '';
      const cmdString = `${command} ${modelArg} -s --no-ask-user --allow-tool view --deny-tool write --deny-tool edit --deny-tool create -p "${escapedPrompt}"`;

      this.log(`Executing: ${command} ${modelArg} -s --no-ask-user ... -p "<prompt>"`);

      return new Promise((resolve, reject) => {
        const proc = spawn(cmdString, [], {
          shell: true,
          windowsHide: true,
          stdio: ['pipe', 'pipe', 'pipe'],
          cwd: path.dirname(this.basePath),
        });

        let stdout = '';
        let stderr = '';

        proc.stdout.on('data', (data) => { stdout += data.toString(); });
        proc.stderr.on('data', (data) => { stderr += data.toString(); });

        proc.on('close', (code) => {
          try { if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile); } catch (e) { /* ignore */ }

          this.log(`Command completed with code ${code}, stdout: ${stdout.length} chars`);

          // For plain text we skip the aggressive thinking filter —
          // just trim leading/trailing whitespace.
          const output = (stdout || stderr || '').trim();

          if (code === 0 || output.length > 0) {
            resolve(output);
          } else {
            this.log(`stderr: ${stderr.substring(0, 500)}`);
            resolve(this.simulateReview(prompt));
          }
        });

        proc.on('error', (err) => {
          this.log(`Spawn error: ${err.message}`);
          try { if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile); } catch (e) { /* ignore */ }
          resolve(this.simulateReview(prompt));
        });

        const timeoutId = setTimeout(() => {
          this.log(`Command timed out after ${this.timeout}ms`);
          proc.kill();
          try { if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile); } catch (e) { /* ignore */ }
          resolve(this.simulateReview(prompt));
        }, this.timeout);

        proc.on('close', () => { clearTimeout(timeoutId); });
        proc.stdin.end();
      });
    } catch (e) {
      this.log(`Error: ${e.message}`);
      try { if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile); } catch (err) { /* ignore */ }
      return this.simulateReview(prompt);
    }
  }

  /**
   * Extract clean plain-text purpose from the stage result.
   * The prompt asks for plain text, but the base class tries JSON parsing.
   * We prefer rawOutput or the original output string.
   */
  extractPurposeText(result) {
    if (!result.success || result.skipped) {
      return '';
    }

    // If JSON parsing produced a rawOutput (plain text fallback), use that
    if (result.parsed?.rawOutput) {
      return result.parsed.rawOutput.trim();
    }

    // If parsed summary exists and there are no issues, the AI may have
    // wrapped its answer in the JSON schema — pull the summary
    if (result.parsed?.summary && result.parsed.summary !== 'Review complete' &&
        result.parsed.summary !== 'No output' &&
        result.parsed.summary !== 'Could not parse structured response') {
      return result.parsed.summary.trim();
    }

    // Last resort: use raw output, stripping any accidental JSON wrapper
    const raw = (result.output || '').trim();
    return raw;
  }

  /**
   * Save purpose text to .temp/purpose.txt
   */
  savePurposeText(text) {
    try {
      const dir = path.dirname(this.outputFile);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(this.outputFile, text, 'utf8');
      this.log(`Purpose text saved to ${this.outputFile}`);
    } catch (err) {
      this.log(`Failed to save purpose text: ${err.message}`);
    }
  }

  /**
   * Read previously saved purpose text (static helper for other stages)
   */
  static readPurposeText(basePath) {
    try {
      const filePath = path.join(basePath, '.temp', 'purpose.txt');
      if (fs.existsSync(filePath)) {
        return fs.readFileSync(filePath, 'utf8').trim();
      }
    } catch (err) {
      // Ignore read errors
    }
    return '';
  }
}

module.exports = PurposeStage;
