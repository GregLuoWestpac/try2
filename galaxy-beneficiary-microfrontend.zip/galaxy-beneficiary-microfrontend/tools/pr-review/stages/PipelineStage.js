/**
 * PipelineStage - Single Responsibility: Execute a single review stage
 * Open/Closed: Can be extended for different stage types without modification
 */

const fs = require('fs');
const path = require('path');
const { execSync, spawn } = require('child_process');

class PipelineStage {
  constructor(config, basePath, options = {}) {
    this.id = config.id;
    this.name = config.name;
    this.enabled = config.enabled;
    this.promptFile = config.promptFile;
    this.timeout = config.timeout || 60000;
    this.filePatterns = config.filePatterns || ['*'];
    this.basePath = basePath;
    this.modelConfig = options.modelConfig || { command: 'copilot', flag: '' };
    this.verbose = options.verbose || false;
    this.cacheManager = options.cacheManager || null;
  }

  /**
   * Log message if verbose mode is enabled
   */
  log(message) {
    if (this.verbose) {
      const timestamp = new Date().toISOString().split('T')[1].slice(0, 12);
      console.log(`[${timestamp}]   ${message}`);
    }
  }

  /**
   * Load the prompt template for this stage
   */
  loadPromptTemplate() {
    const promptPath = path.join(this.basePath, 'prompts', this.promptFile);
    
    if (!fs.existsSync(promptPath)) {
      throw new Error(`Prompt file not found: ${promptPath}`);
    }

    return fs.readFileSync(promptPath, 'utf8');
  }

  /**
   * Build the full prompt with diff content injected
   */
  buildPrompt(diffContent) {
    const template = this.loadPromptTemplate();
    
    // Truncate diff if too large to fit in context window
    // Claude Opus has 200k context, Sonnet has 200k - be conservative
    // Prompt template ~5k chars, leave room for response ~4k tokens
    // ~150k characters (~37k tokens) is safe for diff content
    const maxDiffLength = 150000;
    let truncatedDiff = diffContent;
    
    if (diffContent.length > maxDiffLength) {
      truncatedDiff = diffContent.substring(0, maxDiffLength) + 
        '\n\n[... diff truncated due to size - showing first 150,000 characters ...]';
    }

    return template.replace('{{DIFF_CONTENT}}', truncatedDiff);
  }

  /**
   * Execute the stage using Copilot CLI
   */
  async execute(diffContent, fileList = []) {
    const result = {
      stageId: this.id,
      stageName: this.name,
      success: false,
      output: '',
      parsed: null, // Parsed JSON response
      error: null,
      duration: 0,
      skipped: false,
      cached: false,
    };

    const startTime = Date.now();

    // Check if stage is enabled
    if (!this.enabled) {
      this.log('Stage is disabled, skipping');
      result.skipped = true;
      result.output = 'Stage disabled in configuration';
      result.parsed = { passed: true, issues: [], observations: [], summary: 'Stage disabled' };
      result.success = true;
      return result;
    }

    // Check if there's relevant diff content
    if (!diffContent || diffContent.trim().length === 0) {
      this.log('No matching files in diff, skipping');
      result.skipped = true;
      result.output = 'No matching files in diff';
      result.parsed = { passed: true, issues: [], observations: [], summary: 'No matching files' };
      result.success = true;
      return result;
    }

    try {
      this.log(`Loading prompt template: ${this.promptFile}`);
      const prompt = this.buildPrompt(diffContent);
      this.log(`Prompt built, size: ${prompt.length} characters`);
      
      // Check cache first - include file list for proper invalidation
      if (this.cacheManager) {
        const cachedResponse = this.cacheManager.get(this.id, prompt, diffContent, fileList);
        if (cachedResponse) {
          this.log('Using cached response');
          result.success = true;
          result.output = cachedResponse;
          result.parsed = this.parseJsonResponse(cachedResponse);
          result.cached = true;
          result.duration = Date.now() - startTime;
          return result;
        }
      }
      
      this.log('Invoking Copilot CLI...');
      const output = await this.invokeCopilot(prompt);
      this.log(`Copilot response received, size: ${output.length} characters`);
      
      // Parse JSON response
      result.parsed = this.parseJsonResponse(output);
      
      // Cache the response (raw output for re-parsing) - include file list
      if (this.cacheManager && output && output.length > 0) {
        this.cacheManager.set(this.id, prompt, diffContent, output, fileList);
      }
      
      result.success = true;
      result.output = output;
    } catch (error) {
      this.log(`Error: ${error.message}`);
      result.success = false;
      result.error = error.message;
      result.output = `Stage failed: ${error.message}`;
      result.parsed = { passed: false, issues: [], observations: [], summary: `Error: ${error.message}` };
    }

    result.duration = Date.now() - startTime;
    return result;
  }

  /**
   * Parse JSON response from Copilot output
   */
  parseJsonResponse(output) {
    if (!output) {
      return { passed: true, issues: [], observations: [], summary: 'No output' };
    }

    try {
      // Try to extract JSON from the output
      const jsonMatch = output.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        // Validate structure
        return {
          passed: parsed.passed !== false,
          issues: Array.isArray(parsed.issues) ? parsed.issues : [],
          observations: Array.isArray(parsed.observations) ? parsed.observations : [],
          summary: parsed.summary || 'Review complete',
        };
      }
    } catch (e) {
      this.log(`JSON parse error: ${e.message}`);
    }

    // Fallback: treat as plain text
    return {
      passed: !output.toLowerCase().includes('[severity: high]'),
      issues: [],
      observations: [{ type: 'neutral', description: output.substring(0, 500) }],
      summary: 'Could not parse structured response',
      rawOutput: output,
    };
  }

  /**
   * Invoke GitHub Copilot CLI for inference
   */
  async invokeCopilot(prompt) {
    const { command, flag } = this.modelConfig;
    
    // Write prompt to temp file in .temp/ directory - copilot will read it via its file tools
    const tempDir = path.join(this.basePath, '.temp');
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }
    const tempFile = path.join(tempDir, `prompt_${this.id}.md`);
    const tempFilePosix = tempFile.replace(/\\/g, '/');
    
    try {
      this.log(`Writing prompt to temp file: ${tempFile}`);
      fs.writeFileSync(tempFile, prompt, 'utf8');
      
      // Build the command - emphasize clean JSON output in prompt
      const shortPrompt = `You are a code reviewer. Read "${tempFilePosix}" which contains review instructions and code diff. Output ONLY valid JSON in the exact format specified in the file. Do NOT output any text before or after the JSON. Do NOT show your thinking. Do NOT describe what you are doing. Just output the JSON review results.`;
      
      // Escape the short prompt for shell
      const escapedPrompt = shortPrompt.replace(/"/g, '\\"');
      
      const modelArg = flag || '';
      // Use -s for script mode, deny write tools
      const cmdString = `${command} ${modelArg} -s --no-ask-user --allow-tool view --deny-tool write --deny-tool edit --deny-tool create -p "${escapedPrompt}"`;
      
      this.log(`Executing: ${command} ${modelArg} -s --no-ask-user ... -p "<prompt>"`);
      
      return new Promise((resolve, reject) => {
        const proc = spawn(cmdString, [], {
          shell: true,
          windowsHide: true,
          stdio: ['pipe', 'pipe', 'pipe'],
          cwd: path.dirname(this.basePath),
        });
        
        let stdout = '';
        let stderr = '';
        
        proc.stdout.on('data', (data) => {
          stdout += data.toString();
        });
        
        proc.stderr.on('data', (data) => {
          stderr += data.toString();
        });
        
        proc.on('close', (code) => {
          // Clean up temp file
          try {
            if (fs.existsSync(tempFile)) {
              fs.unlinkSync(tempFile);
            }
          } catch (e) {
            // Ignore cleanup errors
          }
          
          this.log(`Command completed with code ${code}, stdout: ${stdout.length} chars`);
          
          // Filter out thinking/internal text from output
          const cleanOutput = this.filterThinkingOutput(stdout || stderr);
          
          if (code === 0 || cleanOutput.length > 0) {
            resolve(cleanOutput);
          } else {
            this.log(`stderr: ${stderr.substring(0, 500)}`);
            resolve(this.simulateReview(prompt));
          }
        });
        
        proc.on('error', (err) => {
          this.log(`Spawn error: ${err.message}`);
          // Clean up temp file
          try {
            if (fs.existsSync(tempFile)) {
              fs.unlinkSync(tempFile);
            }
          } catch (e) {
            // Ignore cleanup errors
          }
          resolve(this.simulateReview(prompt));
        });
        
        // Set timeout
        const timeoutId = setTimeout(() => {
          this.log(`Command timed out after ${this.timeout}ms`);
          proc.kill();
          // Clean up temp file
          try {
            if (fs.existsSync(tempFile)) {
              fs.unlinkSync(tempFile);
            }
          } catch (e) {
            // Ignore cleanup errors
          }
          resolve(this.simulateReview(prompt));
        }, this.timeout);
        
        proc.on('close', () => {
          clearTimeout(timeoutId);
        });
        
        // Close stdin immediately
        proc.stdin.end();
      });
    } catch (e) {
      this.log(`Error: ${e.message}`);
      // Clean up temp file
      try {
        if (fs.existsSync(tempFile)) {
          fs.unlinkSync(tempFile);
        }
      } catch (err) {
        // Ignore cleanup errors
      }
      return this.simulateReview(prompt);
    }
  }

  /**
   * Simulate review when Copilot CLI is not available
   * This provides a fallback for testing/development
   */
  simulateReview(prompt) {
    return `[Copilot CLI not available - simulated review for ${this.name}]\n\n` +
      `Analysis would be performed on the provided diff.\n` +
      `Install GitHub Copilot CLI: gh extension install github/gh-copilot\n\n` +
      `✓ Review stage completed (simulation mode)`;
  }

  /**
   * Filter out thinking/internal text from Copilot output
   * Removes lines that show internal reasoning rather than review results
   */
  filterThinkingOutput(output) {
    if (!output) return '';
    
    const lines = output.split('\n');
    const filteredLines = [];
    
    // Patterns that indicate thinking/internal text
    const thinkingPatterns = [
      /^I need to /i,
      /^I'll /i,
      /^I will /i,
      /^I'm going to /i,
      /^I should /i,
      /^Let me /i,
      /^Now I /i,
      /^First,? I /i,
      /^Now,? let/i,
      /^I can see /i,
      /^Looking at /i,
      /^I notice /i,
      /^Based on (my|the) /i,
      /^I'm ready to help/i,
      /^What would you like/i,
      /^Please let me know/i,
      /^I cannot access/i,
      /^Since I cannot/i,
      /^However, I'm unable/i,
      /^Let me (check|view|read|get|try|continue)/i,
      /^I'm unable to/i,
      /^The project requires/i,
      /^\*\*Manual Setup Required/i,
    ];
    
    let skipBlock = false;
    
    for (const line of lines) {
      const trimmedLine = line.trim();
      
      // Skip empty lines at the start
      if (filteredLines.length === 0 && trimmedLine === '') {
        continue;
      }
      
      // Check if line matches thinking patterns
      const isThinking = thinkingPatterns.some(pattern => pattern.test(trimmedLine));
      
      if (isThinking) {
        skipBlock = true;
        continue;
      }
      
      // Reset skip block on empty lines (new paragraph)
      if (trimmedLine === '') {
        skipBlock = false;
      }
      
      if (!skipBlock) {
        filteredLines.push(line);
      }
    }
    
    // If everything was filtered out, return original (better than nothing)
    const result = filteredLines.join('\n').trim();
    if (result.length < 50 && output.length > 200) {
      this.log('Warning: Most output was filtered as thinking text');
      // Return original but trim obvious thinking prefix
      return output.replace(/^(I need to|Let me|I'll|First,).*?\n\n/s, '').trim();
    }
    
    return result;
  }
}

module.exports = PipelineStage;
