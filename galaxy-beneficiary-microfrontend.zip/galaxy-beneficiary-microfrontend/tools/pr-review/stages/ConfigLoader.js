/**
 * ConfigLoader - Single Responsibility: Load and parse configuration
 * Config chain: ENV vars (PR_REVIEW_*) > ./pr_review_bot.yaml.local > ~/.pr_review_bot.yaml.local > tools/pr-review/config.yaml
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const yaml = require('js-yaml');

class ConfigLoader {
  constructor(basePath) {
    this.basePath = basePath;
    this.rootPath = path.resolve(basePath, '../..');
  }

  /**
   * Load YAML config file
   */
  loadYamlConfig(configPath) {
    try {
      if (!fs.existsSync(configPath)) {
        return null;
      }
      const content = fs.readFileSync(configPath, 'utf8');
      return yaml.load(content);
    } catch (error) {
      console.error(`Warning: Could not parse ${configPath}: ${error.message}`);
      return null;
    }
  }

  /**
   * Load configuration with proper precedence
   * Priority: ENV vars > ./pr_review_bot.yaml.local > ~/.pr_review_bot.yaml.local > tools/pr-review/config.yaml
   */
  loadPipelineConfig() {
    // Load base config from tools/pr-review/config.yaml
    const baseConfigPath = path.join(this.basePath, 'config.yaml');
    let config = this.loadYamlConfig(baseConfigPath);
    
    if (!config) {
      throw new Error(`Failed to load base config from ${baseConfigPath}`);
    }

    // Load user home directory config from ~/.pr_review_bot.yaml.local or %USERPROFILE%\.pr_review_bot.yaml.local
    const homeDir = os.homedir();
    const homeConfigPath = path.join(homeDir, '.pr_review_bot.yaml.local');
    const homeConfig = this.loadYamlConfig(homeConfigPath);
    
    // Merge home config over base config
    if (homeConfig) {
      config = this.deepMerge(config, homeConfig);
    }

    // Load local overrides from pr_review_bot.yaml.local (working directory)
    const localConfigPath = path.join(this.rootPath, 'pr_review_bot.yaml.local');
    const localConfig = this.loadYamlConfig(localConfigPath);
    
    // Merge local config over base+home config (local overrides home)
    if (localConfig) {
      config = this.deepMerge(config, localConfig);
    }

    return config;
  }

  /**
   * Deep merge two objects
   */
  deepMerge(target, source) {
    const output = { ...target };
    
    if (this.isObject(target) && this.isObject(source)) {
      Object.keys(source).forEach(key => {
        if (this.isObject(source[key])) {
          if (!(key in target)) {
            output[key] = source[key];
          } else {
            output[key] = this.deepMerge(target[key], source[key]);
          }
        } else {
          output[key] = source[key];
        }
      });
    }
    
    return output;
  }

  isObject(item) {
    return item && typeof item === 'object' && !Array.isArray(item);
  }

  /**
   * Get environment variable overrides
   * Supports PR_REVIEW_[CONFIG_KEY_NAME] format
   */
  getEnvOverrides() {
    const envPrefix = 'PR_REVIEW_';
    const overrides = {};
    
    Object.keys(process.env).forEach(key => {
      if (key.startsWith(envPrefix)) {
        const configKey = key.substring(envPrefix.length).toLowerCase();
        let value = process.env[key];
        
        // Parse boolean values
        if (value.toLowerCase() === 'true') value = true;
        else if (value.toLowerCase() === 'false') value = false;
        
        overrides[configKey] = value;
      }
    });
    
    return overrides;
  }

  /**
   * Get merged configuration with environment variable and flag overrides
   * Priority: ENV vars > ./pr_review_bot.yaml.local > ~/.pr_review_bot.yaml.local > tools/pr-review/config.yaml
   */
  getConfig() {
    const pipelineConfig = this.loadPipelineConfig();
    const envOverrides = this.getEnvOverrides();
    
    // Apply environment variable overrides
    const config = this.deepMerge(pipelineConfig, envOverrides);
    
    // Extract AI flags (for backward compatibility)
    const aiFlags = {
      ai_pr_approvals: config.ai_pr_approvals ?? true,
      ai_pr_comments: config.ai_pr_comments ?? true,
      ai_security_scans: config.ai_security_scans ?? true,
      ai_mock_data_generator: config.ai_mock_data_generator ?? true,
    };

    // Apply feature flag logic
    if (!aiFlags.ai_pr_approvals && !aiFlags.ai_pr_comments) {
      // Disable all stages if PR reviews are disabled
      config.stages.forEach(stage => {
        stage.enabled = false;
      });
    }

    // Security stage respects ai_security_scans flag
    const securityStage = config.stages.find(s => s.id === '4_security');
    if (securityStage && !aiFlags.ai_security_scans) {
      securityStage.enabled = false;
    }

    // Add bitbucket token from config if available
    if (config.bitbucket_token && config.bitbucket) {
      config.bitbucket.token = config.bitbucket_token;
    }

    return {
      aiFlags,
      pipeline: config,
    };
  }
}

module.exports = ConfigLoader;
