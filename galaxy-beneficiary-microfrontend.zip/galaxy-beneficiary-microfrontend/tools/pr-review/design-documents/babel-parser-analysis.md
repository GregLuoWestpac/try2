# Babel Parser Analysis for PR-Review Transformations

## Executive Summary

This document analyzes the benefits, trade-offs, and practicality of using **Babel Parser** for parsing changed files in the PR-Review transformation pipeline. Currently, the transformations use regex-based heuristics for code analysis. Babel Parser would provide accurate AST (Abstract Syntax Tree) analysis for JavaScript/TypeScript files.

## Current State: Regex-Based Heuristics

### Current Implementation (`functionBoundaryExpansion.js`)
```javascript
// Current approach: regex matching
const funcMatch = line.match(/^\s*(export\s+)?(async\s+)?(function\s+(\w+)|const\s+(\w+)\s*=.*function|...)/);

// Brace counting for function boundaries
for (const char of line) {
  if (char === '{') braceCount++;
  if (char === '}') braceCount--;
}
```

### Current Limitations
1. **False positives**: Regex matches function-like patterns in strings/comments
2. **Incomplete patterns**: Doesn't handle all ES6+ syntax (class methods, decorators, getters/setters)
3. **Brace counting failures**: Fails on braces in strings, template literals, regex, comments
4. **Arrow functions**: Complex arrow function patterns are hard to match with regex
5. **No semantic understanding**: Can't determine variable types, scopes, or relationships

---

## Babel Parser Overview

### What is Babel Parser?
- The parser behind Babel.js, parses JavaScript/TypeScript into an AST
- Supports ES2023+, JSX, TypeScript, Flow, and proposals
- Used by ESLint, Prettier, and thousands of build tools
- **Package**: `@babel/parser` (~3MB)

### AST Output Example
```javascript
// Input: "const add = (a, b) => a + b;"
// Output AST (simplified):
{
  type: "VariableDeclaration",
  declarations: [{
    id: { type: "Identifier", name: "add" },
    init: {
      type: "ArrowFunctionExpression",
      params: [{ name: "a" }, { name: "b" }],
      body: { type: "BinaryExpression", operator: "+" }
    }
  }]
}
```

---

## Benefits of Babel Parser

### 1. **Accurate Function Detection**
| Scenario | Regex | Babel Parser |
|----------|-------|--------------|
| Named functions | ✅ | ✅ |
| Arrow functions | ⚠️ Partial | ✅ |
| Class methods | ⚠️ Partial | ✅ |
| Object method shorthand | ❌ | ✅ |
| Getters/Setters | ❌ | ✅ |
| Async generators | ❌ | ✅ |
| Functions in strings/comments | ❌ False positive | ✅ Excluded |
| Destructured params | ⚠️ | ✅ |

### 2. **Precise Boundary Detection**
```javascript
// Regex brace counting FAILS on:
const str = "function foo() { }";  // ← Not a real function
const regex = /\{.*\}/;             // ← Braces in regex
const template = `${obj.method()}`;  // ← Braces in template
/* multi-line comment with { braces } */

// Babel Parser correctly ignores all of these
```

### 3. **Semantic Understanding**
- **Scope analysis**: Know where variables are declared and used
- **Type inference**: Track TypeScript types across files
- **Import resolution**: Understand what's imported from where
- **Call graph**: Know which functions call which

### 4. **Transformation Enablement**
| Transformation | Regex Feasible? | With Babel Parser |
|---------------|-----------------|-------------------|
| Function boundary expansion | ⚠️ Basic only | ✅ Complete |
| Type definition injection | ❌ Nearly impossible | ✅ Easy |
| React hook dependency context | ❌ Error-prone | ✅ Accurate |
| Sibling function peek | ⚠️ Fragile | ✅ Reliable |
| Doc comment preservation | ⚠️ | ✅ With `attachComment: true` |

### 5. **Industry Standard**
- Battle-tested on millions of codebases
- Regular updates for new JS/TS features
- Extensive plugin ecosystem
- Well-documented AST format (ESTree + extensions)

---

## Cons and Trade-offs

### 1. **Performance Overhead**
| Metric | Regex | Babel Parser |
|--------|-------|--------------|
| Parse 1KB file | <1ms | ~5-10ms |
| Parse 100KB file | ~2ms | ~50-100ms |
| Memory for AST | N/A | ~10x source size |

**Mitigation**: 
- Parse only changed files, not entire codebase
- Cache parsed ASTs within a single PR review run
- Use `babel-parser`'s `startLine` option to parse only relevant portions

### 2. **Dependency Size**
```
@babel/parser: ~3MB (single package)
vs
@babel/parser + @babel/traverse + @babel/types: ~15MB
```
**Recommendation**: Use just `@babel/parser` + manual traversal for simple needs

### 3. **TypeScript Limitations**
- Babel parses TypeScript syntax but doesn't type-check
- For full type resolution, need TypeScript compiler API (`typescript` package)
- **Practical impact**: Can identify type annotations syntactically, but not resolve cross-file types

### 4. **Error Handling**
- Babel throws on syntax errors (vs regex silently fails/proceeds)
- Need robust try/catch with fallback to heuristics
- Partial files (mid-edit) may not parse

### 5. **Learning Curve**
- AST traversal patterns differ from text manipulation
- Developers need to understand node types

---

## Practicality Assessment

### Integration Effort: **MEDIUM** (2-3 days)

#### Step 1: Add Dependency
```bash
npm install @babel/parser
```

#### Step 2: Create AST Helper Module
```javascript
// astParser.js
const parser = require('@babel/parser');

function parseJS(code, options = {}) {
  try {
    return parser.parse(code, {
      sourceType: 'module',
      plugins: ['jsx', 'typescript', 'decorators-legacy'],
      attachComment: true,
      ...options
    });
  } catch (e) {
    return null; // Fallback to heuristics
  }
}

function findFunctionAtLine(ast, lineNum) {
  const functions = [];
  
  function visit(node) {
    if (isFunctionNode(node) && 
        node.loc.start.line <= lineNum && 
        node.loc.end.line >= lineNum) {
      functions.push(node);
    }
    for (const key in node) {
      const child = node[key];
      if (Array.isArray(child)) child.forEach(visit);
      else if (child && child.type) visit(child);
    }
  }
  
  visit(ast.program);
  return functions[functions.length - 1]; // Innermost function
}

function isFunctionNode(node) {
  return ['FunctionDeclaration', 'FunctionExpression', 
          'ArrowFunctionExpression', 'ObjectMethod', 
          'ClassMethod'].includes(node.type);
}
```

#### Step 3: Refactor Transformation
```javascript
// functionBoundaryExpansion.js (updated)
const { parseJS, findFunctionAtLine } = require('./astParser');

static findEnclosingFunction(text, lineNum) {
  const ast = parseJS(text);
  
  if (!ast) {
    // Fallback to existing heuristic
    return this.findEnclosingFunctionHeuristic(text, lineNum);
  }
  
  const funcNode = findFunctionAtLine(ast, lineNum);
  if (!funcNode) return null;
  
  const lines = text.split('\n');
  return {
    name: funcNode.id?.name || 'anonymous',
    lineCount: funcNode.loc.end.line - funcNode.loc.start.line + 1,
    content: lines.slice(funcNode.loc.start.line - 1, funcNode.loc.end.line).join('\n'),
    startLine: funcNode.loc.start.line,
    endLine: funcNode.loc.end.line,
  };
}
```

### Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Parse failures on valid code | Low | Medium | Always fallback to heuristics |
| Performance regression | Medium | Low | Lazy parsing, caching |
| Bundle size increase | Low | Low | Already using Node.js, not browser |
| Maintenance burden | Low | Low | Babel is actively maintained |

---

## Recommendation

### **Use Babel Parser** ✅

**Rationale**:
1. **Accuracy gain is significant** - Regex approach has known failure modes that Babel solves
2. **Enables advanced transformations** - Type injection, hook analysis, test cross-reference all require AST
3. **Reasonable overhead** - ~50ms per file is acceptable for PR review (not hot path)
4. **Safe with fallback** - Keep heuristics as backup for parse failures
5. **Industry standard** - Well-maintained, documented, and understood

### Implementation Priority

| Phase | Scope | Effort |
|-------|-------|--------|
| 1 | Add Babel parser with fallback for `function_boundary_expansion` | 1 day |
| 2 | Create shared AST utilities module | 0.5 day |
| 3 | Migrate remaining transformations | 1-2 days |
| 4 | Add TypeScript-specific handling | Optional |

### Alternative: TypeScript Compiler API

For full type resolution across files, consider `typescript` package instead/alongside:
```javascript
const ts = require('typescript');
const program = ts.createProgram([...files], options);
const typeChecker = program.getTypeChecker();
```
**Trade-off**: Heavier (~50MB), but provides complete type information.

---

## Conclusion

Babel Parser provides substantial benefits for the PR-review transformation pipeline:
- **Eliminates false positives** from regex matching functions in strings/comments
- **Enables accurate boundary detection** without fragile brace counting
- **Unlocks advanced transformations** that require semantic understanding
- **Minimal risk** when implemented with heuristic fallback

The ~3MB dependency and ~50ms/file overhead are acceptable trade-offs for the accuracy and capability gains. Implementation can be incremental, starting with function boundary expansion and extending to other transformations.
