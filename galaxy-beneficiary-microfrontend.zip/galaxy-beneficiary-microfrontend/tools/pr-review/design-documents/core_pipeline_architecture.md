# Core Pipeline Architecture Design Document

## Overview

The PR Review Bot is built on a **modular, extensible pipeline architecture** that orchestrates multi-stage AI-powered code reviews. The core pipeline separates concerns into distinct, single-responsibility components: diff provisioning, configuration management, stage execution, caching, and report formatting. This architecture enables deterministic, reproducible reviews while remaining open for extension through configuration and new stage implementations.

---

## Key Concepts

### PipelineRunner
- **Definition:** Central orchestrator that coordinates the entire review lifecycle.
- **Responsibilities:**
  - Initialize configuration, cache, and formatting subsystems
  - Coordinate diff retrieval and transformation
  - Execute stages sequentially with error isolation
  - Aggregate results and produce final report
- **Interface:**
  - `initialize(): void` — Load config, initialize dependencies
  - `run(): Promise<Report>` — Execute full pipeline
- **Design Principles:** Dependency Inversion (depends on abstractions), Open/Closed (extensible via configuration)

### PipelineStage
- **Definition:** Encapsulates a single, isolated review concern (e.g., code standards, security, architecture).
- **Interface:**
  - `execute(diffContent: string): Promise<StageResult>`
  - Each stage receives transformed diff context and produces a structured JSON result.
- **Responsibilities:**
  - Load stage-specific prompt template
  - Build complete prompt by injecting diff content
  - Invoke AI inference (GitHub Copilot CLI)
  - Parse and validate JSON response
  - Handle caching and error recovery
- **Configuration:**
  - Defined in `config.yaml` under `pipeline.stages[]`
  - Each stage configurable with: `id`, `name`, `enabled`, `promptFile`, `timeout`, `filePatterns`

### DiffProvider
- **Definition:** Git abstraction layer for retrieving change information.
- **Responsibilities:**
  - Auto-detect base branch (main, master, develop)
  - Calculate merge-base between branches
  - Retrieve changed file lists
  - Generate unified diff content (full or filtered by patterns)
- **Interface:**
  - `getFullDiff(): string` — Complete unified diff
  - `getDiffForPatterns(patterns: string[]): string` — Filtered diff by file patterns
  - `getChangedFiles(): string[]` — List of changed file paths
  - `getMergeBase(): string` — Merge-base SHA

### CacheManager
- **Definition:** Persistent cache layer for AI review responses.
- **Responsibilities:**
  - Generate deterministic cache keys (SHA256 hash of prompt + diff)
  - Store and retrieve cached responses with TTL expiration
  - Prune expired entries
  - Track cache statistics (hit rate, entry count)
- **Storage:** JSON file at `.cache/review_cache.json`
- **Cache Key:** `SHA256(prompt + diff).substring(0, 16) + stageId`
- **TTL:** Configurable (default: 24 hours)

### ConfigLoader
- **Definition:** Unified configuration loader supporting multiple sources.
- **Sources (in priority order):**
  1. Command-line flags (e.g., `--simple`, `--complex`, `--base`)
  2. `.ai_flags` file (AI flag overrides like `enable_feature_x`)
  3. `config.yaml` (base pipeline configuration)
- **Responsibilities:**
  - Load and merge configuration from multiple sources
  - Provide model configuration based on selected tier
  - Expose unified config object to pipeline
- **Interface:**
  - `getConfig(): Config` — Merged configuration object

### ReportFormatter
- **Definition:** Output abstraction for producing human-readable reports.
- **Responsibilities:**
  - Format complete pipeline report with header, stage results, summary
  - Generate executive summary with issue counts and severity breakdowns
  - Format individual stage results with structured issues/observations
  - Apply consistent formatting (dividers, line width, icons)
- **Output Options:**
  - `showTimings`: Include stage execution durations
  - `showSummary`: Include overall summary statistics
  - `format`: text (current), extensible to JSON/HTML/Markdown

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                         PipelineRunner                          │
│  (Orchestrates entire review lifecycle)                        │
└────────────────────┬────────────────────────────────────────────┘
                     │
         ┌───────────┼───────────┐
         │           │           │
         ▼           ▼           ▼
  ┌───────────┐ ┌────────────┐ ┌──────────────┐
  │  Config   │ │    Diff    │ │    Cache     │
  │  Loader   │ │  Provider  │ │   Manager    │
  └───────────┘ └────────────┘ └──────────────┘
         │           │
         │           ▼
         │    [InputTransformationPipeline]
         │           │
         │           ▼ (transformed diff)
         │    ┌──────────────────┐
         └───>│  PipelineStage   │──┐
              │  (execute N times)│  │
              └──────────────────┘  │
                     │              │
                     ▼              │
              [AI Inference via     │
               Copilot CLI]         │
                     │              │
                     ▼              │
              [Parse JSON Response] │
                     │              │
              ┌──────┴──────┐       │
              ▼             ▼       │
         (cache result) (return)    │
                                    │
              ┌─────────────────────┘
              │ (aggregate results)
              ▼
      ┌──────────────────┐
      │ Report Formatter │
      └──────────────────┘
              │
              ▼
        [Final Report]
```

---

## Core Data Model

### Config (Unified Configuration)
**Required sections**
- `pipeline: PipelineConfig` — Pipeline-level settings
- `stages: StageConfig[]` — Stage definitions
- `ai: AIConfig` — AI model configuration
- `bitbucket?: BitbucketConfig` — Optional Bitbucket integration

**PipelineConfig fields**
- `name: string` — Pipeline name
- `version: string` — Pipeline version
- `failOnError: boolean` — Stop pipeline on stage failure (default: false)
- `continueOnStageFailure: boolean` — Continue to next stage on failure (default: true)
- `cache: CacheConfig` — Cache settings

**StageConfig fields**
- `id: string` — Unique stage identifier
- `name: string` — Human-readable stage name
- `enabled: boolean` — Enable/disable stage
- `promptFile: string` — Prompt template filename (relative to `prompts/`)
- `timeout: number` — AI inference timeout in milliseconds
- `filePatterns: string[]` — Glob patterns for file filtering

**AIConfig fields**
- `command: string` — AI command (e.g., `copilot`)
- `maxTokens: number` — Token limit for prompts
- `models: { [tier]: ModelConfig }` — Model configurations per tier
- `selectedModel: string` — Default model tier (simple/default/complex)

**ModelConfig fields**
- `name: string` — Model identifier (e.g., `claude-sonnet-4.5`)
- `description: string` — Human-readable description
- `flag: string` — CLI flag to select model (e.g., `--model gpt-4.1`)

---

### StageResult (Stage Execution Output)
**Required fields**
- `stageId: string` — Stage identifier
- `stageName: string` — Human-readable stage name
- `success: boolean` — Execution success status
- `output: string` — Raw AI response text
- `parsed: ParsedReview` — Structured JSON response
- `duration: number` — Execution time in milliseconds
- `skipped: boolean` — Whether stage was skipped (disabled or no matching files)
- `cached: boolean` — Whether result came from cache
- `error?: string` — Error message if execution failed

**ParsedReview structure**
```json
{
  "passed": boolean,
  "issues": Issue[],
  "observations": Observation[],
  "summary": string,
  "rawOutput"?: string
}
```

**Issue structure**
```json
{
  "severity": "high" | "medium" | "low",
  "category": string,
  "file": string,
  "line": number,
  "description": string,
  "suggestion": string
}
```

**Observation structure**
```json
{
  "type": "positive" | "neutral" | "negative",
  "description": string
}
```

---

### Report (Final Pipeline Output)
**Structure**
- `metadata: Metadata` — Pipeline execution metadata
- `results: StageResult[]` — All stage results
- `summary: Summary` — Aggregated statistics

**Metadata fields**
- `branch: string` — Current branch name
- `baseBranch: string` — Base branch for diff comparison
- `filesChanged: number` — Count of changed files
- `files: string[]` — List of changed file paths
- `model: string` — AI model used
- `modelTier: string` — Model tier (simple/default/complex)
- `timestamp: string` — ISO 8601 execution timestamp
- `duration: number` — Total pipeline execution time
- `cacheStats: CacheStats` — Cache hit/miss statistics

**Summary fields**
- `totalIssues: number` — Total issues across all stages
- `issuesBySeverity: { high: number, medium: number, low: number }`
- `passedStages: number` — Count of stages that passed
- `failedStages: number` — Count of stages that failed
- `skippedStages: number` — Count of stages that were skipped
- `overallPassed: boolean` — Whether all non-skipped stages passed

---

## Pipeline Execution Flow (Deterministic)

### 1. Initialization Phase
**Steps:**
1. Load and merge configuration (CLI args → .ai_flags → config.yaml)
2. Select AI model based on tier (simple/default/complex)
3. Initialize CacheManager (load cache, prune expired entries)
4. Initialize ReportFormatter with output options
5. Instantiate PipelineStage objects for each enabled stage
6. Display initialization summary (model, cache stats, stage count)

**Constraints:**
- Must fail fast if configuration is invalid or required files missing
- Must log all initialization steps if verbose mode enabled

---

### 2. Diff Retrieval Phase
**Steps:**
1. Detect or use configured base branch
2. Calculate merge-base SHA
3. Retrieve list of changed files
4. Generate full unified diff content (via `git diff <mergeBase> HEAD`)
5. Display diff summary (file count, base branch)

**Determinism requirements:**
- Diff content must be deterministic for a given repo state and merge-base
- File ordering must be stable (lexicographic)

---

### 3. Input Transformation Phase
**Steps:**
1. Build DiffContext from raw diff and repo state
2. Run InputTransformationPipeline (see: `input_transformation_pipeline.md.txt`)
3. Output: Enriched diff context with expanded boundaries, type definitions, imports, etc.

**Integration:**
- Transformation runs **once** for full diff (shared by all stages)
- Transformation runs **per-stage** for filtered diffs (respecting `filePatterns`)

**Constraints:**
- Must preserve original `+` / `-` lines exactly
- Must remain bounded by transformation limits (max bytes, max time)

---

### 4. Stage Execution Phase
**For each enabled stage:**
1. **Pre-flight checks:**
   - Check if stage is enabled
   - Filter diff by stage's `filePatterns`
   - Skip if no matching files
2. **Cache lookup:**
   - Generate cache key from prompt template + transformed diff
   - Return cached result if valid (within TTL)
3. **AI Inference:**
   - Load prompt template from `prompts/<promptFile>`
   - Inject transformed diff into template via `{{DIFF_CONTENT}}` placeholder
   - Truncate diff if exceeds token limits (~12,000 chars for safety)
   - Invoke GitHub Copilot CLI in script mode with tool restrictions
   - Set timeout to stage's configured timeout value
4. **Response Processing:**
   - Filter out AI "thinking" text (heuristic patterns)
   - Extract JSON response from output
   - Validate and parse JSON into `ParsedReview` structure
   - Cache response if successful
5. **Error Handling:**
   - On timeout: log warning, simulate fallback response
   - On CLI failure: log error, simulate fallback response
   - On parse failure: treat output as plain text observation
   - If `continueOnStageFailure=true`, log error and continue to next stage

**Determinism requirements:**
- Given same prompt and diff, must produce same cache key
- Given same cache key within TTL, must return identical cached response

---

### 5. Report Generation Phase
**Steps:**
1. Aggregate all stage results
2. Calculate summary statistics (total issues, severity breakdown, pass/fail counts)
3. Format header with metadata and executive summary
4. Format each stage result with issues/observations
5. Format issues summary (grouped by severity across all stages)
6. Format overall summary with timing and statistics
7. Output final report to console

**Output format:**
```
==========================================================
              PR REVIEW PIPELINE REPORT
==========================================================

Branch:      feature/new-component
Base:        main
Files:       5 changed
Model:       claude-sonnet-4.5 (default)
Timestamp:   2026-02-11T22:15:30Z

Changed Files:
  • src/components/NewComponent.tsx
  • src/utils/helper.ts
  • tests/NewComponent.test.tsx

Executive Summary:
  ✅ 4 stages passed
  ❌ 1 stage failed
  ⚠️  5 issues found (2 high, 2 medium, 1 low)

----------------------------------------------------------
[STAGE] Code Standards Review                    [✅ PASS]
----------------------------------------------------------
Execution Time: 3.2s | Cached: No

Issues Found: 2
  [HIGH] Missing error handling in async function
    File: src/utils/helper.ts:45
    Suggestion: Add try-catch block around await statement

  [MEDIUM] Inconsistent naming convention
    File: src/components/NewComponent.tsx:12
    Suggestion: Rename 'myVar' to 'myVariable'

Observations:
  ✓ Good use of TypeScript type annotations
  ✓ Consistent code formatting

Summary: Code follows most standards with minor issues

----------------------------------------------------------
[SUMMARY]
----------------------------------------------------------
Total Execution Time: 15.8s
Cache Hit Rate: 40% (2/5 stages)

Issues by Severity:
  HIGH:    2 issues
  MEDIUM:  2 issues
  LOW:     1 issue

Stages:
  ✅ Passed:  4
  ❌ Failed:  1
  ⏭️  Skipped: 0

Overall: ❌ REVIEW FAILED (1 stage failed)
==========================================================
```

---

## Extension Points

### Adding a New Stage
1. Create prompt template in `prompts/<stage_name>.md`
2. Define stage configuration in `config.yaml` under `pipeline.stages[]`
3. Stage automatically integrates via `PipelineRunner` (no code changes required)

**Prompt template requirements:**
- Must include `{{DIFF_CONTENT}}` placeholder
- Must specify expected JSON output format
- Should include examples of expected issues/observations

---

### Adding a New AI Model
1. Add model configuration under `config.yaml` → `ai.models.<tier>`
2. Specify model name, description, and CLI flag
3. Model available via CLI options (e.g., `--simple`, `--complex`)

**Model requirements:**
- Must be accessible via GitHub Copilot CLI (`copilot --model <name>`)
- Must support structured JSON output
- Should respect token limits defined in `ai.maxTokens`

---

### Custom Input Transformations
See `input_transformation_pipeline.md.txt` for detailed transformation architecture.

**Integration point:**
- Transformations run between Diff Retrieval and Stage Execution
- Configure transformations in `config.yaml` → `inputTransformations[]`
- Each transformation receives and returns `DiffContext`

---

### Custom Report Formats
Extend `ReportFormatter` to support additional output formats:
- JSON: Structured JSON for CI/CD integration
- HTML: Rich web report with syntax highlighting
- Markdown: GitHub-flavored markdown for PR comments

**Implementation:**
- Add format option to `config.yaml` → `output.format`
- Implement format-specific `format*` methods in `ReportFormatter`
- Maintain same `Report` data model for all formats

---

## Design Principles Applied

### Single Responsibility Principle
- **DiffProvider:** Only git operations
- **CacheManager:** Only cache storage/retrieval
- **PipelineStage:** Only stage execution
- **ReportFormatter:** Only output formatting
- **ConfigLoader:** Only configuration loading

### Open/Closed Principle
- Pipeline open for extension via configuration (new stages, new models)
- Pipeline closed for modification (core orchestration logic stable)
- Stages extensible via prompt templates without code changes

### Dependency Inversion Principle
- `PipelineRunner` depends on stage interface, not concrete implementations
- Stages depend on abstract AI inference (Copilot CLI), not specific models
- Easy to mock dependencies for testing

### Liskov Substitution Principle
- All stages implement same `execute(diffContent): Promise<StageResult>` interface
- Stages interchangeable from pipeline perspective
- Enables stage ordering flexibility

### Interface Segregation Principle
- Components expose minimal interfaces (e.g., `DiffProvider` exposes only diff retrieval methods)
- No "god objects" with excessive responsibilities

---

## Determinism and Reproducibility

### Cache Key Generation
```js
function generateCacheKey(stageId, prompt, diff) {
  const content = `${prompt}\n---DIFF---\n${diff}`;
  const hash = SHA256(content).substring(0, 16);
  return `${hash}_${stageId}`;
}
```

**Guarantees:**
- Same prompt + diff = same cache key
- Cache key independent of execution time or environment
- Cache key includes stage ID for isolation

### Execution Determinism
**Sources of non-determinism (mitigated):**
- **Git state:** Fixed by using explicit merge-base SHA
- **AI responses:** Mitigated via caching (same input = cached response)
- **File system order:** Stable lexicographic sorting of file lists
- **Timestamps:** Excluded from cache keys, included only in metadata

**Sources of non-determinism (intentional):**
- **AI model behavior:** May vary slightly between identical prompts (temperature > 0)
- **Cache expiration:** Responses expire after TTL, forcing fresh inference

---

## Performance Characteristics

### Execution Time Breakdown (typical)
- Initialization: ~100-200ms
- Diff Retrieval: ~50-500ms (depends on repo size)
- Input Transformation: ~200-2000ms (depends on transformation count and complexity)
- Stage Execution: ~2-10s per stage (depends on AI model and diff size)
  - Cache hit: <10ms
  - AI inference: 2-10s per stage
- Report Generation: ~10-50ms

**Total (5 stages, no cache):** ~15-60 seconds  
**Total (5 stages, 100% cache hit):** ~500ms

### Caching Impact
- **Cache hit rate:** Typically 40-80% for iterative reviews on same PR
- **Cache TTL:** 24 hours (configurable)
- **Cache storage:** JSON file, ~10-100KB per stage result
- **Cache pruning:** Automatic on initialization (removes expired entries)

### Scalability Limits
- **Max diff size:** ~12,000 characters per stage (token limit)
- **Max stages:** No hard limit, but total execution time scales linearly
- **Max file count:** No hard limit, but diff truncation applies
- **Concurrent execution:** Not supported (stages run sequentially)

---

## Error Handling Strategy

### Error Isolation by Stage
- Stage failures do not stop pipeline if `continueOnStageFailure=true`
- Each stage result includes `success` flag and optional `error` field
- Failed stages produce fallback `ParsedReview` with error summary

### Fallback Mechanisms
1. **Cache unavailable:** Continue without caching (log warning)
2. **Copilot CLI unavailable:** Simulate review with notice message
3. **AI timeout:** Return timeout error, mark stage as failed, continue
4. **JSON parse failure:** Treat output as plain text, extract basic info
5. **Git failure (merge-base):** Fallback to `HEAD~1` as base

### Logging Levels
- **Normal mode:** High-level progress updates (stage start/end, summary)
- **Verbose mode (`--verbose`):** Detailed execution logs with timestamps
  - Config loading steps
  - Cache operations (hit/miss, pruning)
  - Prompt sizes and diff sizes
  - AI invocation details
  - Response parsing details

---

## Testing Strategy

### Unit Tests
- **DiffProvider:** Test git operations, merge-base detection, file filtering
- **CacheManager:** Test cache key generation, TTL expiration, hit/miss logic
- **ConfigLoader:** Test config merging, source precedence, validation
- **ReportFormatter:** Test output formatting, issue aggregation, summary generation
- **PipelineStage:** Test prompt building, JSON parsing, cache integration

### Integration Tests
- **InputTransformationPipeline:** Test transformation chaining (see `PipelineRunner.integration.test.js`)
- **PipelineRunner:** Test end-to-end execution with mocked AI responses
- **Stage Execution:** Test real Copilot CLI integration (if available)

### Test Fixtures
- Mock git repositories with known diffs
- Mock AI responses (valid JSON, invalid JSON, timeouts)
- Mock cache files with various TTL states

---

## Benefits

### For Developers
- **Fast feedback:** Caching reduces review time by 80-95% for iterations
- **Consistent reviews:** Deterministic caching ensures same feedback for same changes
- **Configurable depth:** Choose model tier based on review importance (simple/default/complex)
- **Minimal disruption:** CLI-based, no external services or integrations required

### For Teams
- **Standardized standards:** Codified review criteria in prompt templates
- **Reproducible reviews:** Same diff always produces same review (within cache TTL)
- **Extensible stages:** Add new review concerns without changing core pipeline
- **Audit trail:** Cached reviews provide historical record of review decisions

### For Maintainers
- **Modular architecture:** Each component testable in isolation
- **Clear extension points:** Add stages, models, transformations, formats via configuration
- **Graceful degradation:** Pipeline continues on stage failures, provides partial results
- **Observable execution:** Verbose mode provides detailed execution trace

---

## Security and Privacy Considerations

### Data Handling
- **Local execution:** All processing happens locally (no external APIs except GitHub Copilot)
- **Sensitive data:** Diff content sent to AI model (respect your organization's AI usage policies)
- **Cache storage:** Cached responses stored locally in `.cache/` (gitignored)
- **Secrets:** No credentials or secrets required for core pipeline operation

### Tool Restrictions
Stages execute AI with strict tool denials:
```bash
copilot --no-ask-user \
  --allow-tool view \    # Read-only file access
  --deny-tool write \    # No file modifications
  --deny-tool edit \     # No file edits
  --deny-tool create     # No file creation
```

**Guarantees:**
- AI cannot modify repository files
- AI cannot create new files
- AI has read-only access to view diff and context

---

## Future Enhancements

### Planned Features
1. **Parallel stage execution:** Run independent stages concurrently (requires thread-safe caching)
2. **Incremental reviews:** Review only new changes since last review (cache invalidation strategy)
3. **Custom transformations:** User-defined transformations in external scripts/plugins
4. **Rich output formats:** HTML reports with syntax highlighting, interactive issue filtering
5. **CI/CD integration:** Exit codes, JSON output, and PR comment automation

### Experimental Features
1. **Multi-model consensus:** Run same stage with multiple models, aggregate results
2. **Adaptive timeout:** Adjust stage timeout based on diff complexity
3. **Smart caching:** Cache invalidation based on semantic diff changes (not just text changes)
4. **Learning from feedback:** Track user feedback on AI suggestions, tune prompts

---

## Next Steps (Design → Implementation)

**Phase 1: Core stability (complete)**
- ✅ Implement PipelineRunner orchestration
- ✅ Implement PipelineStage execution
- ✅ Implement DiffProvider git operations
- ✅ Implement CacheManager with TTL
- ✅ Implement ConfigLoader with multi-source merging
- ✅ Implement ReportFormatter with text output

**Phase 2: Input enrichment (in progress)**
- ✅ Integrate InputTransformationPipeline (see `input_transformation_pipeline.md.txt`)
- 🔄 Implement initial transformations (#1, #2, #3)
- 🔄 Test transformation impact on review quality

**Phase 3: Integration and polish**
- ⏳ Bitbucket PR comment integration
- ⏳ CI/CD integration (exit codes, JSON output)
- ⏳ Performance optimization (parallel stages)
- ⏳ Enhanced error recovery and diagnostics
