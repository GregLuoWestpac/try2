# InputTransformationPipeline Design Document

## Overview

To enhance PR review context, we introduce a pluggable, configurable `InputTransformationPipeline` architecture. This system allows chaining multiple `InputTransformation` stages, each responsible for a deterministic transformation of diff input, such as expanding function boundaries or injecting type definitions. The pipeline is technology/language-aware and is configured via `config.yaml`.

---

## Key Concepts

### InputTransformation
- **Definition:** Encapsulates a single transformation (e.g., function expansion, import injection).
- **Interface:**
  - `transform(input: DiffContext): DiffContext`
  - Each transformation receives and returns a `DiffContext` object, which contains the diff, file metadata, and language info.
- **Examples:**
  - `FunctionBoundaryExpansionTransformation`
  - `ImportStatementInjectionTransformation`
  - `TypeDefinitionInjectionTransformation`

### InputTransformationPipeline
- **Definition:** Chains together multiple `InputTransformation` instances in a configurable order.
- **Interface:**
  - `run(input: DiffContext): DiffContext`
  - Internally, calls each transformation's `transform` method in sequence.
- **Configuration:**
  - Defined in `config.yaml` under a new `inputTransformations` section.
  - Each transformation can be enabled/disabled and configured with parameters (e.g., language, file patterns).

---

## Architecture Diagram

```
Raw Diff Input
     |
     v
[InputTransformationPipeline]
     |
     v
Transformed Diff Context
     |
     v
[Analysis Pipeline Stages]
```

---

## Example config.yaml Section

```yaml
inputTransformations:
  - id: function_boundary_expansion
    enabled: true
    languages: [js, ts, py]
  - id: import_statement_injection
    enabled: true
    languages: [js, ts]
  - id: type_definition_injection
    enabled: true
    languages: [ts]
```

---

## Integration Points (Existing PR Review Pipeline)

### Where it plugs in
- The `InputTransformationPipeline` runs **after** `DiffProvider.getFullDiff()` / `DiffProvider.getDiffForPatterns()` and **before** each `PipelineStage.execute()`.
- Each analysis stage receives a **transformed** `diffContent` (still in unified diff form with `+/-/ ` prefixes preserved) plus optional “related context blocks” appended.

### Invocation model
- The pipeline should run:
  1) once for the full diff (for general stages), and
  2) once for each stage-specific filtered diff (so transformations can respect filePatterns and stage constraints).

### Determinism requirement
All transformations MUST be:
- deterministic given repo state at `HEAD` and the merge-base (no network calls),
- bounded by explicit size/time limits,
- reproducible (same inputs => same outputs).

---

## Core Data Model

### DiffContext (conceptual)
A normalized structure used internally by transformations.

**Required fields**
- `rawDiffText: string` — unified diff text (as produced by `git diff`).
- `mergeBase: string` — SHA/ref used as base.
- `head: string` — typically `HEAD`.
- `files: DiffFile[]` — parsed representation of the unified diff.

**Per-file fields**
- `path: string`
- `languageId: string | null` (derived from extension or heuristics)
- `hunks: DiffHunk[]`
- `beforeText?: string` (from `git show ${mergeBase}:${path}`)
- `afterText?: string` (from working tree or `git show HEAD:${path}`)

**Notes**
- Transformations may enrich `DiffContext` (e.g., attach parsed AST, symbol maps), but must not mutate core identifiers (`path`, `mergeBase`, etc.)

### Output format requirement
The pipeline output must remain compatible with existing prompt templates expecting `{{DIFF_CONTENT}}`.

The output should be one of:
1) **Expanded unified diff** (preferred): same diff headers/hunks, with additional context lines included using the unified diff context prefix (` `).
2) **Unified diff + appended context sections**: keep original diff intact, then append deterministic context blocks (clearly delimited) when true diff expansion isn’t feasible.

---

## Extensibility & Language Support

- Each transformation declares supported `languages` and/or `filePatterns`.
- For JS/TS, AST-based extraction should use a deterministic parser (e.g., Babel/TypeScript compiler API).
- For non-AST languages, use deterministic structural heuristics (brace matching, indentation blocks) with conservative fallbacks.
- If language detection fails, transformation must either skip or fall back to generic behavior.

---

## Transformation Catalog (Requirements for the 12 Identified Transformations)

This section formalizes each transformation as an `InputTransformation` with clear **triggers**, **inputs**, **outputs**, **configuration**, and **constraints**.

### Common requirements (apply to all transformations)
- Must preserve original `+` and `-` lines exactly as produced by `git diff`.
- Any added contextual lines must be emitted as **context** lines (prefix ` `) when embedding into hunks.
- Must avoid duplicating identical context blocks multiple times per file/hunk (dedupe by stable key).
- Must enforce limits (max bytes added per file, max total bytes added per stage, max lookup count).

---

### 1) `function_boundary_expansion`
**Goal:** Ensure each change hunk includes the entire enclosing function/method body.

**Trigger (deterministic):**
- For each file hunk, if changed lines fall within a function/method scope (AST or heuristic), expand the hunk to include full function boundaries.

**Inputs:**
- parsed hunks with line ranges
- `beforeText` and/or `afterText`

**Output:**
- Expanded hunks containing full function body; unchanged lines added as ` ` context lines.

**Config:**
- `strategy: ast|heuristic` (default: `ast` when supported)
- `maxFunctionLines` (cap; skip if larger)
- `preferAfterVersion: true|false`

**Constraints / fallbacks:**
- If function is too large or cannot be identified, fall back to fixed-line context expansion.

**Expected impact:** HIGH

---

### 2) `import_statement_injection`
**Goal:** Always include import/require/export context for changed files.

**Trigger:**
- File has at least one hunk and language is JS/TS (or configured list).

**Inputs:**
- `afterText` (preferred)

**Output:**
- Inject a context block containing the import section (top-of-file imports) either:
  - by expanding the first hunk upward to include it, or
  - by appending a `--- Related Context: Imports ---` block.

**Config:**
- `includeExportBlock: true|false`
- `maxLines: number`

**Constraints:**
- Must not include the entire file header if it contains huge license banners unless configured.

**Expected impact:** MEDIUM

---

### 3) `class_or_component_header_inclusion`
**Goal:** Include class/component declaration header when changes occur inside it.

**Trigger:**
- Changed lines are within a `class` body, or within a React component (function component or class component).

**Inputs:**
- AST symbol map OR regex anchors

**Output:**
- Context lines for:
  - `class X extends Y implements Z` header, and (optional) constructor signature
  - for React FC: `function X(props: Props)` / `const X = (props: Props) =>` signature

**Config:**
- `includeConstructorSignature: true|false`
- `includeHeritageClauses: true|false`

**Expected impact:** HIGH

---

### 4) `type_interface_definition_injection`
**Goal:** When diff references TS types/interfaces, include their definitions.

**Trigger:**
- TS/TSX files and changed lines contain identifiers likely to be types (`Props`, `FooOptions`, generics usage, `: Type`, `implements Type`).

**Inputs:**
- `afterText`
- repo search for symbol definitions (deterministic local search)

**Output:**
- Append deterministic blocks:
  - `--- Related Context: Type Definition (Foo) ---` with definition excerpt

**Config:**
- `maxDefinitions: number`
- `searchScope: file|project`
- `preferLocalDefinitions: true|false`

**Constraints:**
- Must avoid ambiguous symbol collisions: include the nearest definition (same file) else first match by stable ordering.

**Expected impact:** HIGH

---

### 5) `sibling_function_peek`
**Goal:** Provide immediate neighboring functions for pattern context.

**Trigger:**
- A changed function is identified (from transformation #1 or independently).

**Inputs:**
- AST function list ordered by source position

**Output:**
- Append small excerpts of previous/next function signatures and first N lines.

**Config:**
- `siblingsBefore: number` (default 1)
- `siblingsAfter: number` (default 1)
- `excerptLines: number` (default 10)

**Expected impact:** MEDIUM

---

### 6) `react_hook_dependency_context`
**Goal:** When hooks change, include definitions of dependency variables.

**Trigger:**
- Changed lines include `useEffect(` / `useMemo(` / `useCallback(` or hook dependency arrays are modified.

**Inputs:**
- AST for hook call + dependency array
- symbol resolution within file

**Output:**
- Append blocks for each dependency symbol with its declaration excerpt.

**Config:**
- `hooks: [useEffect,useMemo,useCallback]`
- `maxDeps: number`
- `declarationContextLines: number`

**Expected impact:** HIGH

---

### 7) `test_cross_reference`
**Goal:** For a changed source file, include relevant test blocks.

**Trigger:**
- Non-test file changed AND corresponding test file(s) exist by naming convention.

**Inputs:**
- file path mapping rules
- grep/AST to locate `describe/it/test` blocks referencing changed function/class

**Output:**
- Append `--- Related Context: Tests ---` containing matched blocks.

**Config:**
- `testFilePatterns` (e.g., `*.test.ts`, `*.spec.ts`)
- `maxTestBlocks: number`

**Expected impact:** MEDIUM

---

### 8) `doc_comment_preservation`
**Goal:** Ensure JSDoc/TSDoc for modified symbols is included.

**Trigger:**
- Modified function/class signature or body detected.

**Inputs:**
- `afterText`

**Output:**
- Expand hunk upward to include nearest preceding docblock or append as related context.

**Config:**
- `maxDocLines: number`

**Expected impact:** LOW–MEDIUM

---

### 9) `react_props_contract_inclusion`
**Goal:** Include Props contract: `propTypes`, `defaultProps`, or TS `Props` interface.

**Trigger:**
- React component changed.

**Inputs:**
- AST/grep within file

**Output:**
- Append or inline excerpts for props contract definitions.

**Config:**
- `includeDefaultProps: true|false`
- `includePropTypes: true|false`

**Expected impact:** MEDIUM

---

### 10) `constant_definition_context`
**Goal:** When changes reference constants/config, include their definitions.

**Trigger:**
- Changed lines include likely constants (e.g., `^[A-Z_]{3,}$` tokens) or config keys.

**Inputs:**
- local file scan first; optional project scan

**Output:**
- Append `--- Related Context: Constant (X) ---` excerpts.

**Config:**
- `maxConstants: number`
- `searchScope: file|project`

**Expected impact:** LOW–MEDIUM

---

### 11) `call_site_expansion`
**Goal:** When function signature changes, include representative call sites.

**Trigger:**
- Function signature change detected (diff modifies params/return type) OR renamed symbol.

**Inputs:**
- symbol name
- project grep for call expressions

**Output:**
- Append `--- Related Context: Call Sites ---` with N call site excerpts.

**Config:**
- `maxCallSites: number`
- `excerptLines: number`
- `preferSamePackage: true|false`

**Constraints:**
- Must be stable ordering (e.g., lexicographic by file path, then by line).

**Expected impact:** MEDIUM

---

### 12) `state_management_context`
**Goal:** For Redux/Zustand-like changes, include state shape and related selectors/actions.

**Trigger:**
- Diff includes `createSlice`, `useSelector`, `dispatch(`, `reducer`, `selector`, `zustand` store patterns, etc.

**Inputs:**
- AST/grep to find store definition and state interfaces

**Output:**
- Append `--- Related Context: State Shape ---` and `--- Related Context: Selectors/Actions ---` excerpts.

**Config:**
- `frameworks: [redux,zustand]`
- `maxBlocks: number`

**Expected impact:** HIGH

---

## Recommended Ordering (Deterministic)

Because some transformations depend on symbol identification from others, a default ordering is:
1) `function_boundary_expansion`
2) `doc_comment_preservation`
3) `import_statement_injection`
4) `class_or_component_header_inclusion`
5) `react_props_contract_inclusion`
6) `react_hook_dependency_context`
7) `type_interface_definition_injection`
8) `constant_definition_context`
9) `sibling_function_peek`
10) `state_management_context`
11) `call_site_expansion`
12) `test_cross_reference`

(Projects can override this order in `config.yaml`.)

---

## Example Interfaces (Pseudocode)

```js
class InputTransformation {
  static id = '...';

  // return true if this transformation should run for this DiffContext
  matches(diffContext) { return true; }

  // must be deterministic
  transform(diffContext) { return diffContext; }
}

class InputTransformationPipeline {
  constructor(transformations, limits) {
    this.transformations = transformations;
    this.limits = limits;
  }

  run(diffContext) {
    let ctx = diffContext;
    for (const t of this.transformations) {
      if (!t.matches(ctx)) continue;
      ctx = t.transform(ctx);
    }
    return ctx;
  }
}
```

---

## Benefits
- Modular, testable transformation logic
- Technology/language-aware context expansion without changing analysis stage prompts
- Deterministic and bounded enrichment of diffs for higher-signal PR reviews

---

## Next Steps (Design → Implementation)
- Extend `config.yaml` schema to include `inputTransformations` + per-transformation config
- Implement diff parsing + `DiffContext` builder
- Implement the pipeline runner and integrate it into the existing pipeline before `PipelineStage.execute()`
- Implement transformations incrementally (start with #1, #2, #3)
