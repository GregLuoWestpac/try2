/**
 * Integration tests for PipelineRunner with InputTransformationPipeline
 */

const DiffProvider = require('../stages/DiffProvider');
const PipelineStage = require('../stages/PipelineStage');

jest.mock('../stages/DiffProvider');
jest.mock('../stages/PipelineStage');

jest.mock('../transformations/functionBoundaryExpansion', () => ({
  transform: jest.fn((ctx) => {
    ctx.appendedContextBlocks.push({
      name: 'Test Marker',
      file: 'src/test.js',
      content: 'MARKER_CONTENT',
    });
    return ctx;
  }),
}));

const PipelineRunner = require('../stages/PipelineRunner');

describe('PipelineRunner Integration', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('T020: passes transformed diff into PipelineStage.execute', async () => {
    // Mock DiffProvider
    const mockDiff = `diff --git a/src/test.js b/src/test.js
@@ -1,2 +1,3 @@
 const x = 1;
+const y = 2;
 const z = 3;`;

    DiffProvider.mockImplementation(() => ({
      baseBranch: 'main',
      getCurrentBranch: jest.fn(() => 'feature-branch'),
      getFullDiff: jest.fn(() => mockDiff),
      getDiffForPatterns: jest.fn(() => mockDiff),
      getChangedFiles: jest.fn(() => ['src/test.js']),
      getMergeBase: jest.fn(() => 'abc123'),
    }));

    // Mock PipelineStage
    const mockExecute = jest.fn(async (diffContent) => ({
      stageId: 'test-stage',
      stageName: 'Test Stage',
      success: true,
      output: 'Test output',
      duration: 100,
      skipped: false,
      cached: false,
    }));

    PipelineStage.mockImplementation(() => ({
      id: 'test-stage',
      name: 'Test Stage',
      enabled: true,
      filePatterns: ['*.js'],
      execute: mockExecute,
    }));

    // Create a mock config with inputTransformations
    const runner = new PipelineRunner(__dirname, { verbose: false, cache: false });
    
    // Mock the config loader to return a config with transformations
    runner.config = {
      aiFlags: {
        ai_pr_approvals: true,
        ai_pr_comments: true,
      },
      pipeline: {
        name: 'Test Pipeline',
        stages: [
          {
            id: 'test-stage',
            name: 'Test Stage',
            enabled: true,
            promptFile: 'test.md',
            filePatterns: ['*.js'],
          },
        ],
        pipeline: {
          failOnError: false,
          continueOnStageFailure: true,
        },
        ai: {
          command: 'copilot',
          models: {
            default: {
              name: 'test-model',
              flag: '',
            },
          },
        },
        output: {},
      },
      inputTransformations: [
        {
          id: 'function_boundary_expansion',
          enabled: true,
          config: {},
        },
      ],
    };

    runner.stages = [
      {
        id: 'test-stage',
        name: 'Test Stage',
        enabled: true,
        filePatterns: ['*.js'],
        execute: mockExecute,
      },
    ];

    // Execute pipeline
    await runner.execute();

    // Verify that execute was called with transformed diff content
    expect(mockExecute).toHaveBeenCalled();
    const calledWith = mockExecute.mock.calls[0][0];
    expect(calledWith).toContain('const x = 1');
    expect(calledWith).toContain('MARKER_CONTENT');
  });

  test('T021: no-op when config has no inputTransformations', async () => {
    const mockDiff = 'diff --git a/src/test.js b/src/test.js\ntest content';

    DiffProvider.mockImplementation(() => ({
      baseBranch: 'main',
      getCurrentBranch: jest.fn(() => 'feature-branch'),
      getFullDiff: jest.fn(() => mockDiff),
      getDiffForPatterns: jest.fn(() => mockDiff),
      getChangedFiles: jest.fn(() => ['src/test.js']),
      getMergeBase: jest.fn(() => 'abc123'),
    }));

    const mockExecute = jest.fn(async (diffContent) => ({
      stageId: 'test-stage',
      stageName: 'Test Stage',
      success: true,
      output: 'Test output',
      duration: 100,
      skipped: false,
      cached: false,
    }));

    const runner = new PipelineRunner(__dirname, { verbose: false, cache: false });
    
    runner.config = {
      aiFlags: {
        ai_pr_approvals: true,
        ai_pr_comments: true,
      },
      pipeline: {
        name: 'Test Pipeline',
        stages: [
          {
            id: 'test-stage',
            name: 'Test Stage',
            enabled: true,
            filePatterns: ['*.js'],
          },
        ],
        pipeline: {
          failOnError: false,
          continueOnStageFailure: true,
        },
        ai: {
          command: 'copilot',
          models: {
            default: {
              name: 'test-model',
              flag: '',
            },
          },
        },
        output: {},
        // No inputTransformations
      },
    };

    runner.stages = [
      {
        id: 'test-stage',
        name: 'Test Stage',
        enabled: true,
        filePatterns: ['*.js'],
        execute: mockExecute,
      },
    ];

    await runner.execute();

    expect(mockExecute).toHaveBeenCalled();
    const calledWith = mockExecute.mock.calls[0][0];
    // Should receive original diff unchanged
    expect(calledWith).toBe(mockDiff);
  });
});
