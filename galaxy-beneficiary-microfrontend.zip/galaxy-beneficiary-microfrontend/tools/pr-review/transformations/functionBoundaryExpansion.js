/**
 * functionBoundaryExpansion - Adds full enclosing function context
 */

const GitTextProvider = require('./GitTextProvider');

class FunctionBoundaryExpansion {
  /**
   * Transform context by adding function boundary information
   */
  static transform(ctx, config = {}) {
    const maxFunctionLines = config.maxFunctionLines || 200;
    const fallbackContextLines = config.fallbackContextLines || 20;

    for (const file of ctx.files) {
      // Only process JS/TS files
      if (!this.isJavaScriptFile(file.languageId)) {
        continue;
      }

      // Prefer already-populated afterText from DiffContextBuilder
      const afterText = file.afterText || new GitTextProvider(ctx.mergeBase, ctx.head).getAfterText(file.path);
      if (!afterText) {
        continue;
      }

      file.afterText = afterText;

      for (const hunk of file.hunks) {
        // Find changed lines in this hunk
        const changedLines = this.extractChangedLines(hunk);
        
        for (const lineNum of changedLines) {
          // Try to find enclosing function
          const funcInfo = this.findEnclosingFunction(afterText, lineNum);
          
          if (funcInfo && funcInfo.lineCount <= maxFunctionLines) {
            // Add full function context
            ctx.appendedContextBlocks.push({
              name: `Function Boundary (${funcInfo.name})`,
              file: file.path,
              content: funcInfo.content,
            });
          } else {
            // Fallback to window context
            const windowContext = this.extractWindowContext(
              afterText,
              lineNum,
              fallbackContextLines
            );
            ctx.appendedContextBlocks.push({
              name: 'Fallback Context',
              file: file.path,
              content: windowContext,
            });
          }
        }
      }
    }

    return ctx;
  }

  /**
   * Check if file is JavaScript/TypeScript
   */
  static isJavaScriptFile(languageId) {
    return ['javascript', 'javascriptreact', 'typescript', 'typescriptreact'].includes(
      languageId
    );
  }

  /**
   * Extract changed line numbers from a hunk
   */
  static extractChangedLines(hunk) {
    const changedLines = [];
    let currentLine = hunk.newStart;

    for (const line of hunk.lines) {
      if (line.startsWith('+') && !line.startsWith('+++')) {
        changedLines.push(currentLine);
        currentLine++;
      } else if (!line.startsWith('-')) {
        currentLine++;
      }
    }

    return changedLines;
  }

  /**
   * Find enclosing function for a given line number
   */
  static findEnclosingFunction(text, lineNum) {
    const lines = text.split('\n');
    
    if (lineNum > lines.length) {
      return null;
    }

    // Search backward for function declaration
    let funcStartLine = -1;
    let funcName = 'anonymous';
    
    for (let i = lineNum - 1; i >= 0; i--) {
      const line = lines[i];
      
      // Match function declarations
      const funcMatch = line.match(/^\s*(export\s+)?(async\s+)?(function\s+(\w+)|const\s+(\w+)\s*=.*function|(\w+)\s*:\s*function|\(.*\)\s*=>|(\w+)\s*\(.*\)\s*\{)/);
      
      if (funcMatch) {
        funcStartLine = i;
        funcName = funcMatch[4] || funcMatch[5] || funcMatch[6] || funcMatch[7] || 'anonymous';
        break;
      }
    }

    if (funcStartLine === -1) {
      return null;
    }

    // Find matching closing brace
    let braceCount = 0;
    let funcEndLine = -1;
    
    for (let i = funcStartLine; i < lines.length; i++) {
      const line = lines[i];
      
      for (const char of line) {
        if (char === '{') braceCount++;
        if (char === '}') braceCount--;
        
        if (braceCount === 0 && i > funcStartLine) {
          funcEndLine = i;
          break;
        }
      }
      
      if (funcEndLine !== -1) break;
    }

    if (funcEndLine === -1) {
      return null;
    }

    const lineCount = funcEndLine - funcStartLine + 1;
    const content = lines.slice(funcStartLine, funcEndLine + 1).join('\n');

    return {
      name: funcName,
      lineCount,
      content,
      startLine: funcStartLine + 1,
      endLine: funcEndLine + 1,
    };
  }

  /**
   * Extract a window of context around a line
   */
  static extractWindowContext(text, lineNum, windowSize) {
    const lines = text.split('\n');
    const startLine = Math.max(0, lineNum - windowSize - 1);
    const endLine = Math.min(lines.length, lineNum + windowSize);
    
    return lines.slice(startLine, endLine).join('\n');
  }
}

module.exports = FunctionBoundaryExpansion;
