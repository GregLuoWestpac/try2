/**
 * Unit tests for GitTextProvider
 */

const GitTextProvider = require('./GitTextProvider');
const { execSync } = require('child_process');

jest.mock('child_process');

describe('GitTextProvider', () => {
  let provider;

  beforeEach(() => {
    jest.clearAllMocks();
    provider = new GitTextProvider('abc123', 'HEAD');
  });

  describe('getBeforeText', () => {
    test('T004: returns before text via execSync', () => {
      const mockContent = 'const x = 1;\nconst y = 2;';
      execSync.mockReturnValue(Buffer.from(mockContent, 'utf-8'));

      const result = provider.getBeforeText('src/x.ts');

      expect(execSync).toHaveBeenCalledWith('git show abc123:src/x.ts', {
        encoding: 'utf-8',
        stdio: ['ignore', 'pipe', 'ignore'],
      });
      expect(result).toBe(mockContent);
    });
  });

  describe('getAfterText', () => {
    test('T004: returns after text via execSync', () => {
      const mockContent = 'const x = 1;\nconst y = 2;\nconst z = 3;';
      execSync.mockReturnValue(Buffer.from(mockContent, 'utf-8'));

      const result = provider.getAfterText('src/x.ts');

      expect(execSync).toHaveBeenCalledWith('git show HEAD:src/x.ts', {
        encoding: 'utf-8',
        stdio: ['ignore', 'pipe', 'ignore'],
      });
      expect(result).toBe(mockContent);
    });
  });

  describe('handles missing files', () => {
    test('T005: returns null when git show fails (before text)', () => {
      execSync.mockImplementation(() => {
        throw new Error('fatal: Path does not exist');
      });

      const result = provider.getBeforeText('src/new-file.ts');

      expect(result).toBeNull();
      expect(execSync).toHaveBeenCalledWith('git show abc123:src/new-file.ts', {
        encoding: 'utf-8',
        stdio: ['ignore', 'pipe', 'ignore'],
      });
    });

    test('T005: returns null when git show fails (after text)', () => {
      execSync.mockImplementation(() => {
        throw new Error('fatal: Path does not exist');
      });

      const result = provider.getAfterText('src/deleted-file.ts');

      expect(result).toBeNull();
      expect(execSync).toHaveBeenCalledWith('git show HEAD:src/deleted-file.ts', {
        encoding: 'utf-8',
        stdio: ['ignore', 'pipe', 'ignore'],
      });
    });
  });
});
