/**
 * JavaLanguageProvider
 * 
 * Language provider for Java files using java-parser (Chevrotain-based).
 * Produces a Concrete Syntax Tree (CST) with full traversal support.
 * 
 * Install: npm install java-parser
 */

const BaseLanguageProvider = require('./BaseLanguageProvider');

let javaParser = null;
let BaseJavaCstVisitorWithDefaults = null;

/**
 * Lazily load java-parser to avoid startup overhead
 */
function getJavaParser() {
  if (!javaParser) {
    try {
      const jp = require('java-parser');
      javaParser = jp.parse;
      BaseJavaCstVisitorWithDefaults = jp.BaseJavaCstVisitorWithDefaults;
    } catch (e) {
      // java-parser not installed
      return null;
    }
  }
  return javaParser;
}

/**
 * CST Visitor to collect method/class information
 */
class MethodCollector {
  constructor(BaseVisitor) {
    // Dynamically create visitor class
    const self = this;
    
    class Visitor extends BaseVisitor {
      constructor() {
        super();
        this.methods = [];
        this.classes = [];
        this.imports = [];
        this.currentClass = null;
        this.validateVisitor();
      }

      importDeclaration(ctx) {
        if (ctx.packageOrTypeName) {
          const name = this._extractName(ctx.packageOrTypeName[0]);
          self.imports.push({
            source: name,
            isStatic: !!ctx.Static,
            line: this._getLine(ctx)
          });
        }
      }

      classDeclaration(ctx) {
        const prevClass = this.currentClass;
        if (ctx.normalClassDeclaration) {
          const decl = ctx.normalClassDeclaration[0];
          if (decl.children.typeIdentifier) {
            this.currentClass = this._extractIdentifier(decl.children.typeIdentifier[0]);
            this.classes.push({
              name: this.currentClass,
              type: 'class',
              startLine: this._getLine(decl),
              endLine: this._getEndLine(decl)
            });
          }
        }
        // Visit children
        this.visitChildren(ctx);
        this.currentClass = prevClass;
      }

      methodDeclaration(ctx) {
        const header = ctx.methodHeader?.[0];
        if (header?.children?.methodDeclarator) {
          const declarator = header.children.methodDeclarator[0];
          const name = this._extractIdentifier(declarator.children.Identifier?.[0]);
          
          this.methods.push({
            name: name || 'anonymous',
            type: 'method',
            className: this.currentClass,
            startLine: this._getLine(ctx),
            endLine: this._getEndLine(ctx),
            params: this._extractParams(declarator),
            modifiers: this._extractModifiers(ctx.methodModifier)
          });
        }
        this.visitChildren(ctx);
      }

      constructorDeclaration(ctx) {
        const declarator = ctx.constructorDeclarator?.[0];
        if (declarator?.children?.simpleTypeName) {
          const name = this._extractIdentifier(declarator.children.simpleTypeName[0]);
          
          this.methods.push({
            name: name || 'constructor',
            type: 'constructor',
            className: this.currentClass,
            startLine: this._getLine(ctx),
            endLine: this._getEndLine(ctx),
            params: this._extractParams(declarator)
          });
        }
        this.visitChildren(ctx);
      }

      _extractName(node) {
        if (!node?.children?.Identifier) return 'unknown';
        return node.children.Identifier.map(id => id.image).join('.');
      }

      _extractIdentifier(node) {
        if (!node) return null;
        if (node.image) return node.image;
        if (node.children?.Identifier) {
          return node.children.Identifier[0].image;
        }
        return null;
      }

      _extractParams(declarator) {
        const params = [];
        const formalParams = declarator?.children?.formalParameterList?.[0];
        if (formalParams?.children?.formalParameter) {
          for (const param of formalParams.children.formalParameter) {
            const varDecl = param.children?.variableDeclaratorId?.[0];
            if (varDecl?.children?.Identifier) {
              params.push(varDecl.children.Identifier[0].image);
            }
          }
        }
        return params;
      }

      _extractModifiers(modifiers) {
        if (!modifiers) return [];
        return modifiers.map(m => {
          const keys = Object.keys(m.children);
          return keys[0]?.toLowerCase() || 'unknown';
        });
      }

      _getLine(ctx) {
        // Recursively find first token with location
        const findLine = (node) => {
          if (!node) return 1;
          if (node.startLine) return node.startLine;
          if (node.children) {
            for (const key of Object.keys(node.children)) {
              const child = node.children[key];
              if (Array.isArray(child)) {
                for (const c of child) {
                  const line = findLine(c);
                  if (line > 0) return line;
                }
              }
            }
          }
          return 1;
        };
        return findLine(ctx);
      }

      _getEndLine(ctx) {
        // Recursively find last token with location
        const findEndLine = (node) => {
          if (!node) return 1;
          if (node.endLine) return node.endLine;
          if (node.children) {
            const keys = Object.keys(node.children).reverse();
            for (const key of keys) {
              const child = node.children[key];
              if (Array.isArray(child)) {
                for (let i = child.length - 1; i >= 0; i--) {
                  const line = findEndLine(child[i]);
                  if (line > 0) return line;
                }
              }
            }
          }
          return 1;
        };
        return findEndLine(ctx);
      }

      visitChildren(ctx) {
        if (!ctx) return;
        for (const key of Object.keys(ctx)) {
          const child = ctx[key];
          if (Array.isArray(child)) {
            for (const c of child) {
              if (c && typeof c === 'object' && c.children) {
                this.visit(c);
              }
            }
          }
        }
      }
    }

    this.VisitorClass = Visitor;
  }

  collect(cst) {
    const visitor = new this.VisitorClass();
    visitor.visit(cst);
    return {
      methods: visitor.methods,
      classes: visitor.classes,
      imports: visitor.imports
    };
  }
}

class JavaLanguageProvider extends BaseLanguageProvider {
  constructor(options = {}) {
    super(options);
    this._collector = null;
  }

  get languageId() {
    return 'java';
  }

  get extensions() {
    return ['.java'];
  }

  /**
   * Parse Java source code
   */
  parse(source, options = {}) {
    const parser = getJavaParser();
    
    if (parser) {
      try {
        const cst = parser(source);
        
        // Collect metadata using visitor
        if (!this._collector && BaseJavaCstVisitorWithDefaults) {
          this._collector = new MethodCollector(BaseJavaCstVisitorWithDefaults);
        }
        
        const metadata = this._collector ? this._collector.collect(cst) : { methods: [], classes: [], imports: [] };
        
        return {
          type: 'JavaCST',
          cst,
          ...metadata,
          source,
          lines: source.split('\n'),
          parseMode: 'java-parser'
        };
      } catch (e) {
        if (this.verbose) {
          console.warn('[JavaLanguageProvider] Parse error, using heuristics:', e.message);
        }
      }
    }

    // Fallback to heuristics
    return this._parseWithHeuristics(source);
  }

  /**
   * Find enclosing method for a line
   */
  findEnclosingFunction(ast, lineNum) {
    if (ast.parseMode === 'java-parser') {
      // Use collected methods
      const candidates = ast.methods.filter(m => 
        m.startLine <= lineNum && m.endLine >= lineNum
      );
      
      if (candidates.length === 0) return null;
      
      // Return innermost (smallest range)
      candidates.sort((a, b) => (a.endLine - a.startLine) - (b.endLine - b.startLine));
      const method = candidates[0];
      
      return {
        name: method.name,
        type: method.type,
        startLine: method.startLine,
        endLine: method.endLine,
        startColumn: 0,
        endColumn: 0,
        params: method.params || [],
        className: method.className,
        modifiers: method.modifiers || [],
        async: false,
        generator: false
      };
    }

    // Heuristic fallback
    return this._findEnclosingMethodHeuristic(ast, lineNum);
  }

  /**
   * Find all methods in the file
   */
  findAllFunctions(ast) {
    if (ast.parseMode === 'java-parser') {
      return ast.methods.map(m => ({
        name: m.name,
        type: m.type,
        startLine: m.startLine,
        endLine: m.endLine,
        startColumn: 0,
        endColumn: 0,
        params: m.params || [],
        className: m.className,
        modifiers: m.modifiers || [],
        async: false,
        generator: false
      }));
    }

    // Heuristic fallback
    return this._findAllMethodsHeuristic(ast);
  }

  /**
   * Find a symbol by name
   */
  findSymbol(ast, name) {
    // Check methods
    const method = ast.methods?.find(m => m.name === name);
    if (method) {
      return {
        name: method.name,
        type: method.type,
        line: method.startLine,
        column: 0
      };
    }

    // Check classes
    const cls = ast.classes?.find(c => c.name === name);
    if (cls) {
      return {
        name: cls.name,
        type: 'class',
        line: cls.startLine,
        column: 0
      };
    }

    return null;
  }

  /**
   * Get imports
   */
  getImports(ast) {
    if (ast.parseMode === 'java-parser') {
      return ast.imports.map(i => ({
        source: i.source,
        specifiers: [],
        isStatic: i.isStatic,
        line: i.line
      }));
    }

    // Heuristic fallback
    return this._getImportsHeuristic(ast);
  }

  /**
   * Get exports (Java uses public modifier, not exports)
   */
  getExports(ast) {
    // Return public classes/methods
    const exports = [];
    
    for (const cls of ast.classes || []) {
      exports.push({
        name: cls.name,
        type: 'class',
        line: cls.startLine
      });
    }
    
    for (const method of ast.methods || []) {
      if (method.modifiers?.includes('public')) {
        exports.push({
          name: method.name,
          type: method.type,
          line: method.startLine
        });
      }
    }
    
    return exports;
  }

  // --- Heuristic fallbacks ---

  _parseWithHeuristics(source) {
    const lines = source.split('\n');
    const methods = this._findAllMethodsHeuristic({ lines, source });
    const classes = this._findClassesHeuristic(lines);
    const imports = this._getImportsHeuristic({ lines });

    return {
      type: 'JavaHeuristic',
      source,
      lines,
      methods,
      classes,
      imports,
      parseMode: 'heuristic'
    };
  }

  _findAllMethodsHeuristic(ast) {
    const lines = ast.lines;
    const methods = [];
    
    // Pattern for Java method declarations
    const methodPattern = /^\s*(?:(public|private|protected|static|final|abstract|synchronized|native)\s+)*(?:[\w<>\[\],\s]+)\s+(\w+)\s*\([^)]*\)\s*(?:throws\s+[\w,\s]+)?\s*\{?\s*$/;
    
    const braceStack = [];
    let currentMethod = null;
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmed = line.trim();
      
      // Skip comments
      if (trimmed.startsWith('//') || trimmed.startsWith('/*') || trimmed.startsWith('*')) {
        continue;
      }
      
      // Check for method start
      const match = line.match(methodPattern);
      if (match && !trimmed.startsWith('if') && !trimmed.startsWith('for') && !trimmed.startsWith('while')) {
        const name = match[2];
        // Skip constructors detected as methods (name matches class)
        currentMethod = {
          name,
          type: 'method',
          startLine: i + 1,
          endLine: i + 1,
          params: this._extractParamsFromSignature(line)
        };
        methods.push(currentMethod);
      }
      
      // Track braces
      for (const char of line) {
        if (char === '{') {
          braceStack.push({ line: i + 1, method: currentMethod });
        } else if (char === '}') {
          const popped = braceStack.pop();
          if (popped?.method && braceStack.length === 1) {
            // Method ended
            popped.method.endLine = i + 1;
            currentMethod = null;
          }
        }
      }
    }
    
    return methods;
  }

  _findEnclosingMethodHeuristic(ast, lineNum) {
    const methods = ast.methods || this._findAllMethodsHeuristic(ast);
    
    const candidates = methods.filter(m => 
      m.startLine <= lineNum && m.endLine >= lineNum
    );
    
    if (candidates.length === 0) return null;
    
    candidates.sort((a, b) => (a.endLine - a.startLine) - (b.endLine - b.startLine));
    const method = candidates[0];
    
    return {
      name: method.name,
      type: method.type || 'method',
      startLine: method.startLine,
      endLine: method.endLine,
      startColumn: 0,
      endColumn: 0,
      params: method.params || [],
      async: false,
      generator: false
    };
  }

  _findClassesHeuristic(lines) {
    const classes = [];
    const classPattern = /^\s*(?:public|private|protected)?\s*(?:abstract|final)?\s*class\s+(\w+)/;
    
    for (let i = 0; i < lines.length; i++) {
      const match = lines[i].match(classPattern);
      if (match) {
        classes.push({
          name: match[1],
          type: 'class',
          startLine: i + 1,
          endLine: lines.length // Simplified - doesn't track class end
        });
      }
    }
    
    return classes;
  }

  _getImportsHeuristic(ast) {
    const imports = [];
    const lines = ast.lines;
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      
      // import statements
      const match = line.match(/^import\s+(static\s+)?([^;]+);/);
      if (match) {
        imports.push({
          source: match[2].trim(),
          specifiers: [],
          isStatic: !!match[1],
          line: i + 1
        });
      }
      
      // Stop after package/imports section
      if (line.match(/^(public|private|protected|class|interface|enum|@)/)) {
        break;
      }
    }
    
    return imports;
  }

  _extractParamsFromSignature(line) {
    const match = line.match(/\(([^)]*)\)/);
    if (!match) return [];
    
    const paramStr = match[1].trim();
    if (!paramStr) return [];
    
    // Split by comma, extract param names
    return paramStr.split(',').map(p => {
      const parts = p.trim().split(/\s+/);
      return parts[parts.length - 1].replace(/[<>\[\]]/g, '');
    }).filter(Boolean);
  }
}

module.exports = JavaLanguageProvider;
