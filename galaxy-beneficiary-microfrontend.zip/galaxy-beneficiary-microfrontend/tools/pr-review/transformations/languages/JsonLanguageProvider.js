/**
 * JsonLanguageProvider
 * 
 * Language provider for JSON files.
 * Provides structure analysis for JSON documents.
 */

const BaseLanguageProvider = require('./BaseLanguageProvider');

class JsonLanguageProvider extends BaseLanguageProvider {
  get languageId() {
    return 'json';
  }

  get extensions() {
    return ['.json', '.jsonc', '.json5'];
  }

  /**
   * Parse JSON source
   */
  parse(source, options = {}) {
    try {
      // Handle JSONC (JSON with comments) by stripping comments
      let cleanSource = source;
      if (options.allowComments !== false) {
        cleanSource = this._stripComments(source);
      }

      const parsed = JSON.parse(cleanSource);
      
      return {
        type: 'JsonDocument',
        source,
        cleanSource,
        data: parsed,
        lines: source.split('\n'),
        keys: this._extractKeys(parsed),
        structure: this._analyzeStructure(parsed)
      };
    } catch (e) {
      if (this.verbose) {
        console.error(`[JsonLanguageProvider] Parse error: ${e.message}`);
      }
      return {
        type: 'JsonDocument',
        source,
        lines: source.split('\n'),
        error: e.message,
        data: null
      };
    }
  }

  /**
   * Get all top-level keys
   */
  getTopLevelKeys(ast) {
    if (!ast.data || typeof ast.data !== 'object' || Array.isArray(ast.data)) {
      return [];
    }
    return Object.keys(ast.data);
  }

  /**
   * Find a key in the JSON structure
   */
  findKey(ast, keyPath) {
    if (!ast.data) return null;

    const parts = keyPath.split('.');
    let current = ast.data;
    
    for (const part of parts) {
      if (current === null || current === undefined) return null;
      if (typeof current !== 'object') return null;
      current = current[part];
    }

    return current;
  }

  /**
   * Get the line number where a key is defined
   * (Heuristic - searches for the key in the source)
   */
  findKeyLine(ast, keyName) {
    const lines = ast.lines;
    const pattern = new RegExp(`"${keyName}"\\s*:`);
    
    for (let i = 0; i < lines.length; i++) {
      if (pattern.test(lines[i])) {
        return i + 1;
      }
    }
    
    return -1;
  }

  /**
   * Get structure info for a path
   */
  getStructureAt(ast, path = '') {
    const parts = path ? path.split('.') : [];
    let current = ast.structure;
    
    for (const part of parts) {
      if (!current || !current.children) return null;
      current = current.children[part];
    }
    
    return current;
  }

  // --- Private helpers ---

  _stripComments(source) {
    // Remove single-line comments
    let result = source.replace(/\/\/[^\n]*/g, '');
    // Remove multi-line comments
    result = result.replace(/\/\*[\s\S]*?\*\//g, '');
    return result;
  }

  _extractKeys(obj, prefix = '', result = []) {
    if (obj === null || typeof obj !== 'object') {
      return result;
    }

    if (Array.isArray(obj)) {
      obj.forEach((item, i) => {
        this._extractKeys(item, `${prefix}[${i}]`, result);
      });
    } else {
      for (const key of Object.keys(obj)) {
        const fullKey = prefix ? `${prefix}.${key}` : key;
        result.push(fullKey);
        this._extractKeys(obj[key], fullKey, result);
      }
    }

    return result;
  }

  _analyzeStructure(obj, depth = 0) {
    if (obj === null) {
      return { type: 'null', depth };
    }
    
    if (Array.isArray(obj)) {
      return {
        type: 'array',
        depth,
        length: obj.length,
        itemType: obj.length > 0 ? this._analyzeStructure(obj[0], depth + 1) : null
      };
    }
    
    if (typeof obj === 'object') {
      const children = {};
      for (const key of Object.keys(obj)) {
        children[key] = this._analyzeStructure(obj[key], depth + 1);
      }
      return {
        type: 'object',
        depth,
        keys: Object.keys(obj),
        children
      };
    }
    
    return { type: typeof obj, depth };
  }
}

module.exports = JsonLanguageProvider;
