/**
 * GenericLanguageProvider
 * 
 * Fallback language provider for unsupported file types.
 * Uses basic heuristics that work across many languages.
 */

const BaseLanguageProvider = require('./BaseLanguageProvider');

class GenericLanguageProvider extends BaseLanguageProvider {
  constructor(options = {}) {
    super(options);
    this._languageId = options.languageId || 'generic';
    this._extensions = options.extensions || [];
  }

  get languageId() {
    return this._languageId;
  }

  get extensions() {
    return this._extensions;
  }

  /**
   * Always returns true - this is the fallback provider
   */
  supports(filePath) {
    return true;
  }

  /**
   * Parse source into a generic structure
   */
  parse(source, options = {}) {
    const lines = source.split('\n');
    
    return {
      type: 'GenericDocument',
      source,
      lines,
      lineCount: lines.length,
      blocks: this._findIndentBlocks(lines),
      braceBlocks: this._findBraceBlocks(lines)
    };
  }

  /**
   * Find enclosing block for a line (using indentation)
   */
  findEnclosingFunction(ast, lineNum) {
    // Try brace-based blocks first (C-style languages)
    const braceBlock = this._findEnclosingBraceBlock(ast, lineNum);
    if (braceBlock) {
      return braceBlock;
    }

    // Fall back to indentation-based blocks
    const indentBlock = this._findEnclosingIndentBlock(ast, lineNum);
    return indentBlock;
  }

  /**
   * Find all function-like blocks
   */
  findAllFunctions(ast) {
    // Return brace blocks that look like functions
    return ast.braceBlocks.filter(b => b.type === 'function');
  }

  /**
   * Generic import detection
   */
  getImports(ast) {
    const imports = [];
    const lines = ast.lines;

    // Common import patterns across languages
    const patterns = [
      // JavaScript/TypeScript
      /^\s*import\s+.*from\s+['"]([^'"]+)['"]/,
      // Python
      /^\s*(?:from\s+(\S+)\s+)?import\s+/,
      // Go
      /^\s*import\s+(?:\(\s*)?["']?([^"'\s\)]+)/,
      // Rust
      /^\s*use\s+(\S+)/,
      // Java/Kotlin
      /^\s*import\s+(\S+)/,
      // Ruby
      /^\s*require\s+['"]([^'"]+)['"]/,
      // PHP
      /^\s*(?:use|require|include)\s+['"]?([^'";\s]+)/,
    ];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      for (const pattern of patterns) {
        const match = line.match(pattern);
        if (match) {
          imports.push({
            source: match[1] || 'unknown',
            specifiers: [],
            line: i + 1
          });
          break;
        }
      }
    }

    return imports;
  }

  // --- Private helpers ---

  _findIndentBlocks(lines) {
    const blocks = [];
    const stack = [];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (line.trim() === '') continue;

      const indent = line.match(/^(\s*)/)[1].length;

      // Pop blocks that have ended
      while (stack.length > 0 && stack[stack.length - 1].indent >= indent) {
        const block = stack.pop();
        block.endLine = i;
        blocks.push(block);
      }

      // Check if this looks like a block start
      if (this._looksLikeBlockStart(line)) {
        stack.push({
          startLine: i + 1,
          endLine: lines.length,
          indent,
          header: line.trim()
        });
      }
    }

    // Close remaining blocks
    while (stack.length > 0) {
      const block = stack.pop();
      block.endLine = lines.length;
      blocks.push(block);
    }

    return blocks;
  }

  _findBraceBlocks(lines) {
    const blocks = [];
    const stack = [];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      // Count braces (simplified - doesn't handle strings/comments)
      for (let j = 0; j < line.length; j++) {
        if (line[j] === '{') {
          // Check if previous line looks like function/class
          const prevLines = lines.slice(Math.max(0, i - 2), i + 1).join(' ');
          const type = this._classifyBraceBlock(prevLines);
          
          stack.push({
            startLine: i + 1,
            endLine: -1,
            type,
            name: this._extractBlockName(prevLines, type)
          });
        } else if (line[j] === '}' && stack.length > 0) {
          const block = stack.pop();
          block.endLine = i + 1;
          blocks.push(block);
        }
      }
    }

    return blocks;
  }

  _findEnclosingBraceBlock(ast, lineNum) {
    const candidates = ast.braceBlocks.filter(b => 
      b.startLine <= lineNum && b.endLine >= lineNum && b.type === 'function'
    );
    
    if (candidates.length === 0) return null;
    
    // Return innermost
    const block = candidates[candidates.length - 1];
    return {
      name: block.name || 'anonymous',
      type: 'function',
      startLine: block.startLine,
      endLine: block.endLine,
      startColumn: 0,
      endColumn: 0,
      params: [],
      async: false,
      generator: false
    };
  }

  _findEnclosingIndentBlock(ast, lineNum) {
    const candidates = ast.blocks.filter(b => 
      b.startLine <= lineNum && b.endLine >= lineNum
    );
    
    if (candidates.length === 0) return null;
    
    // Return innermost (smallest)
    candidates.sort((a, b) => (a.endLine - a.startLine) - (b.endLine - b.startLine));
    const block = candidates[0];
    
    return {
      name: this._extractNameFromHeader(block.header),
      type: 'block',
      startLine: block.startLine,
      endLine: block.endLine,
      startColumn: block.indent,
      endColumn: 0,
      params: [],
      async: false,
      generator: false
    };
  }

  _looksLikeBlockStart(line) {
    const trimmed = line.trim();
    // Common block starters across languages
    return /^(def|fn|func|function|class|interface|struct|enum|module|namespace|if|for|while|switch|case|try|catch)\b/.test(trimmed) ||
           /:\s*$/.test(trimmed) ||  // Python-style
           /\{\s*$/.test(trimmed);   // C-style
  }

  _classifyBraceBlock(context) {
    if (/\bfunction\b/.test(context)) return 'function';
    if (/\b(class|struct)\b/.test(context)) return 'class';
    if (/\binterface\b/.test(context)) return 'interface';
    if (/\bif\b/.test(context)) return 'if';
    if (/\b(for|while)\b/.test(context)) return 'loop';
    if (/\btry\b/.test(context)) return 'try';
    return 'block';
  }

  _extractBlockName(context, type) {
    if (type === 'function') {
      const match = context.match(/(?:function|def|fn|func)\s+(\w+)/);
      return match ? match[1] : 'anonymous';
    }
    if (type === 'class' || type === 'interface') {
      const match = context.match(/(?:class|struct|interface)\s+(\w+)/);
      return match ? match[1] : 'Anonymous';
    }
    return null;
  }

  _extractNameFromHeader(header) {
    // Try to extract a name from various patterns
    const patterns = [
      /(?:def|fn|func|function)\s+(\w+)/,
      /(?:class|struct|interface)\s+(\w+)/,
      /(\w+)\s*[=:]\s*(?:function|fn|\()/,
      /(\w+)\s*\(/
    ];

    for (const pattern of patterns) {
      const match = header.match(pattern);
      if (match) return match[1];
    }

    return 'block';
  }
}

module.exports = GenericLanguageProvider;
