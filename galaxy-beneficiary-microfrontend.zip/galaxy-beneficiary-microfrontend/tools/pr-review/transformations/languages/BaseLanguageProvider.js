/**
 * BaseLanguageProvider
 * 
 * Abstract base class for language-specific parsing and analysis.
 * Concrete implementations handle specific languages (JS, TS, JSON, YAML, etc.)
 */

class BaseLanguageProvider {
  constructor(options = {}) {
    this.options = options;
    this.verbose = options.verbose || false;
  }

  /**
   * Get the language identifier
   * @returns {string} Language ID (e.g., 'javascript', 'typescript', 'json')
   */
  get languageId() {
    throw new Error('languageId must be implemented by subclass');
  }

  /**
   * Get supported file extensions
   * @returns {string[]} Array of extensions (e.g., ['.js', '.mjs', '.cjs'])
   */
  get extensions() {
    throw new Error('extensions must be implemented by subclass');
  }

  /**
   * Check if this provider supports the given file
   * @param {string} filePath - File path or name
   * @returns {boolean}
   */
  supports(filePath) {
    const ext = this._getExtension(filePath);
    return this.extensions.includes(ext);
  }

  /**
   * Parse source code into an AST or structured representation
   * @param {string} source - Source code
   * @param {object} options - Parse options
   * @returns {object|null} Parsed representation, or null on failure
   */
  parse(source, options = {}) {
    throw new Error('parse must be implemented by subclass');
  }

  /**
   * Find the function/method containing a given line
   * @param {object} ast - Parsed AST
   * @param {number} lineNum - 1-based line number
   * @returns {FunctionInfo|null}
   */
  findEnclosingFunction(ast, lineNum) {
    return null; // Override in language-specific providers
  }

  /**
   * Find all functions in the source
   * @param {object} ast - Parsed AST
   * @returns {FunctionInfo[]}
   */
  findAllFunctions(ast) {
    return []; // Override in language-specific providers
  }

  /**
   * Find a symbol definition (type, interface, class, variable)
   * @param {object} ast - Parsed AST
   * @param {string} symbolName - Name to find
   * @returns {SymbolInfo|null}
   */
  findSymbol(ast, symbolName) {
    return null; // Override in language-specific providers
  }

  /**
   * Get all imports/requires
   * @param {object} ast - Parsed AST
   * @returns {ImportInfo[]}
   */
  getImports(ast) {
    return []; // Override in language-specific providers
  }

  /**
   * Get all exports
   * @param {object} ast - Parsed AST
   * @returns {ExportInfo[]}
   */
  getExports(ast) {
    return []; // Override in language-specific providers
  }

  /**
   * Extract comments (doc comments, inline comments)
   * @param {object} ast - Parsed AST
   * @returns {CommentInfo[]}
   */
  getComments(ast) {
    return []; // Override in language-specific providers
  }

  /**
   * Get the source text for a node
   * @param {string} source - Original source
   * @param {object} node - AST node with location info
   * @returns {string}
   */
  getNodeText(source, node) {
    if (!node || !node.loc) return '';
    const lines = source.split('\n');
    const startLine = node.loc.start.line - 1;
    const endLine = node.loc.end.line - 1;
    
    if (startLine === endLine) {
      return lines[startLine].substring(node.loc.start.column, node.loc.end.column);
    }
    
    const result = [];
    result.push(lines[startLine].substring(node.loc.start.column));
    for (let i = startLine + 1; i < endLine; i++) {
      result.push(lines[i]);
    }
    result.push(lines[endLine].substring(0, node.loc.end.column));
    return result.join('\n');
  }

  /**
   * Get lines from source
   * @param {string} source - Source code
   * @param {number} startLine - 1-based start line
   * @param {number} endLine - 1-based end line (inclusive)
   * @returns {string}
   */
  getLines(source, startLine, endLine) {
    const lines = source.split('\n');
    return lines.slice(startLine - 1, endLine).join('\n');
  }

  /**
   * Helper to get file extension
   * @private
   */
  _getExtension(filePath) {
    const match = filePath.match(/(\.[^.]+)$/);
    return match ? match[1].toLowerCase() : '';
  }
}

/**
 * @typedef {object} FunctionInfo
 * @property {string} name - Function name (or 'anonymous')
 * @property {string} type - 'function' | 'method' | 'arrow' | 'getter' | 'setter'
 * @property {number} startLine - 1-based start line
 * @property {number} endLine - 1-based end line
 * @property {number} startColumn - 0-based start column
 * @property {number} endColumn - 0-based end column
 * @property {string[]} params - Parameter names
 * @property {boolean} async - Is async function
 * @property {boolean} generator - Is generator function
 * @property {object} [node] - Original AST node
 */

/**
 * @typedef {object} SymbolInfo
 * @property {string} name - Symbol name
 * @property {string} type - 'class' | 'interface' | 'type' | 'variable' | 'function' | 'enum'
 * @property {number} startLine - 1-based start line
 * @property {number} endLine - 1-based end line
 * @property {object} [node] - Original AST node
 */

/**
 * @typedef {object} ImportInfo
 * @property {string} source - Module source (e.g., 'react', './utils')
 * @property {string[]} specifiers - Imported names
 * @property {string} [defaultImport] - Default import name
 * @property {boolean} isNamespace - Is namespace import (import * as)
 * @property {number} line - 1-based line number
 */

/**
 * @typedef {object} ExportInfo
 * @property {string} name - Exported name
 * @property {string} type - 'named' | 'default' | 'all'
 * @property {number} line - 1-based line number
 */

/**
 * @typedef {object} CommentInfo
 * @property {string} type - 'line' | 'block' | 'doc'
 * @property {string} text - Comment text
 * @property {number} startLine - 1-based start line
 * @property {number} endLine - 1-based end line
 */

module.exports = BaseLanguageProvider;
