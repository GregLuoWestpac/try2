/**
 * YamlLanguageProvider
 * 
 * Language provider for YAML files.
 * Provides structure analysis for YAML documents.
 */

const BaseLanguageProvider = require('./BaseLanguageProvider');

// Lazy-load yaml parser
let yamlParser = null;
function getYamlParser() {
  if (!yamlParser) {
    try {
      yamlParser = require('yaml');
    } catch (e) {
      try {
        yamlParser = require('js-yaml');
      } catch (e2) {
        return null;
      }
    }
  }
  return yamlParser;
}

class YamlLanguageProvider extends BaseLanguageProvider {
  get languageId() {
    return 'yaml';
  }

  get extensions() {
    return ['.yaml', '.yml'];
  }

  /**
   * Parse YAML source
   */
  parse(source, options = {}) {
    const parser = getYamlParser();

    // Try using yaml parser if available
    if (parser) {
      try {
        let data;
        if (parser.parse) {
          // 'yaml' package
          data = parser.parse(source);
        } else if (parser.load) {
          // 'js-yaml' package
          data = parser.load(source);
        }

        return {
          type: 'YamlDocument',
          source,
          data,
          lines: source.split('\n'),
          keys: this._extractKeys(data),
          structure: this._analyzeStructure(data)
        };
      } catch (e) {
        if (this.verbose) {
          console.error(`[YamlLanguageProvider] Parse error: ${e.message}`);
        }
      }
    }

    // Fallback: heuristic parsing
    return this._parseHeuristic(source);
  }

  /**
   * Heuristic YAML parsing (key-value extraction)
   */
  _parseHeuristic(source) {
    const lines = source.split('\n');
    const keys = [];
    const structure = { type: 'object', keys: [], children: {} };

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      // Match YAML keys (not comments, proper indentation)
      const match = line.match(/^(\s*)([a-zA-Z_][\w-]*)\s*:/);
      if (match && !line.trimStart().startsWith('#')) {
        const indent = match[1].length;
        const key = match[2];
        keys.push({
          name: key,
          indent,
          line: i + 1
        });
      }
    }

    return {
      type: 'YamlDocument',
      source,
      data: null,
      lines,
      keys,
      structure,
      heuristic: true
    };
  }

  /**
   * Get all top-level keys
   */
  getTopLevelKeys(ast) {
    if (ast.heuristic) {
      return ast.keys.filter(k => k.indent === 0).map(k => k.name);
    }
    if (!ast.data || typeof ast.data !== 'object' || Array.isArray(ast.data)) {
      return [];
    }
    return Object.keys(ast.data);
  }

  /**
   * Find a key in the YAML structure
   */
  findKey(ast, keyPath) {
    if (!ast.data) return null;

    const parts = keyPath.split('.');
    let current = ast.data;
    
    for (const part of parts) {
      if (current === null || current === undefined) return null;
      if (typeof current !== 'object') return null;
      current = current[part];
    }

    return current;
  }

  /**
   * Get the line number where a key is defined
   */
  findKeyLine(ast, keyName) {
    if (ast.heuristic) {
      const found = ast.keys.find(k => k.name === keyName);
      return found ? found.line : -1;
    }

    const lines = ast.lines;
    const pattern = new RegExp(`^\\s*${keyName}\\s*:`);
    
    for (let i = 0; i < lines.length; i++) {
      if (pattern.test(lines[i])) {
        return i + 1;
      }
    }
    
    return -1;
  }

  /**
   * Get indentation-based sections
   */
  getSections(ast) {
    const sections = [];
    const lines = ast.lines;
    let currentSection = null;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      // Top-level key (no indentation)
      const match = line.match(/^([a-zA-Z_][\w-]*)\s*:/);
      if (match) {
        if (currentSection) {
          currentSection.endLine = i;
          sections.push(currentSection);
        }
        currentSection = {
          name: match[1],
          startLine: i + 1,
          endLine: lines.length
        };
      }
    }

    if (currentSection) {
      sections.push(currentSection);
    }

    return sections;
  }

  // --- Private helpers ---

  _extractKeys(obj, prefix = '', result = []) {
    if (obj === null || typeof obj !== 'object') {
      return result;
    }

    if (Array.isArray(obj)) {
      obj.forEach((item, i) => {
        this._extractKeys(item, `${prefix}[${i}]`, result);
      });
    } else {
      for (const key of Object.keys(obj)) {
        const fullKey = prefix ? `${prefix}.${key}` : key;
        result.push(fullKey);
        this._extractKeys(obj[key], fullKey, result);
      }
    }

    return result;
  }

  _analyzeStructure(obj, depth = 0) {
    if (obj === null) {
      return { type: 'null', depth };
    }
    
    if (Array.isArray(obj)) {
      return {
        type: 'array',
        depth,
        length: obj.length,
        itemType: obj.length > 0 ? this._analyzeStructure(obj[0], depth + 1) : null
      };
    }
    
    if (typeof obj === 'object') {
      const children = {};
      for (const key of Object.keys(obj)) {
        children[key] = this._analyzeStructure(obj[key], depth + 1);
      }
      return {
        type: 'object',
        depth,
        keys: Object.keys(obj),
        children
      };
    }
    
    return { type: typeof obj, depth };
  }
}

module.exports = YamlLanguageProvider;
