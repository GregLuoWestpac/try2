/**
 * TypeScriptLanguageProvider
 * 
 * Language provider for TypeScript files.
 * Extends JavaScript provider with TypeScript-specific plugins and type extraction.
 */

const JavaScriptLanguageProvider = require('./JavaScriptLanguageProvider');

// Lazy-load babel parser
let babelParser = null;
function getBabelParser() {
  if (!babelParser) {
    try {
      babelParser = require('@babel/parser');
    } catch (e) {
      return null;
    }
  }
  return babelParser;
}

class TypeScriptLanguageProvider extends JavaScriptLanguageProvider {
  get languageId() {
    return 'typescript';
  }

  get extensions() {
    return ['.ts', '.tsx', '.mts', '.cts'];
  }

  /**
   * Parse TypeScript source into AST
   */
  parse(source, options = {}) {
    const parser = getBabelParser();

    if (!parser) {
      return this._parseHeuristic(source);
    }

    try {
      const isJsx = options.filePath?.endsWith('.tsx') || options.jsx;
      
      return parser.parse(source, {
        sourceType: options.sourceType || 'module',
        plugins: [
          'typescript',
          isJsx ? 'jsx' : null,
          'classProperties',
          'classPrivateProperties',
          'classPrivateMethods',
          ['decorators', { decoratorsBeforeExport: true }],
          'exportDefaultFrom',
          'exportNamespaceFrom',
          'dynamicImport',
          'nullishCoalescingOperator',
          'optionalChaining',
          'objectRestSpread',
          ...(options.plugins || [])
        ].filter(Boolean),
        attachComment: true,
        ranges: true,
        ...options
      });
    } catch (e) {
      if (this.verbose) {
        console.error(`[TypeScriptLanguageProvider] Parse error: ${e.message}`);
      }
      return this._parseHeuristic(source);
    }
  }

  /**
   * Find symbol including TypeScript types and interfaces
   */
  findSymbol(ast, symbolName) {
    if (ast.type === 'HeuristicParse') {
      return this._findSymbolHeuristic(ast, symbolName);
    }

    let found = null;
    this._visitNode(ast.program, (node) => {
      if (found) return;

      // TypeScript interfaces
      if (node.type === 'TSInterfaceDeclaration' && node.id?.name === symbolName) {
        found = {
          name: symbolName,
          type: 'interface',
          startLine: node.loc.start.line,
          endLine: node.loc.end.line,
          node
        };
      }

      // TypeScript type aliases
      if (node.type === 'TSTypeAliasDeclaration' && node.id?.name === symbolName) {
        found = {
          name: symbolName,
          type: 'type',
          startLine: node.loc.start.line,
          endLine: node.loc.end.line,
          node
        };
      }

      // TypeScript enums
      if (node.type === 'TSEnumDeclaration' && node.id?.name === symbolName) {
        found = {
          name: symbolName,
          type: 'enum',
          startLine: node.loc.start.line,
          endLine: node.loc.end.line,
          node
        };
      }
    });

    // Fallback to base class for regular symbols
    return found || super.findSymbol(ast, symbolName);
  }

  /**
   * Get all type definitions (interfaces, type aliases, enums)
   */
  getTypeDefinitions(ast) {
    if (ast.type === 'HeuristicParse') {
      return this._getTypeDefinitionsHeuristic(ast);
    }

    const types = [];
    this._visitNode(ast.program, (node) => {
      if (node.type === 'TSInterfaceDeclaration') {
        types.push({
          name: node.id.name,
          kind: 'interface',
          startLine: node.loc.start.line,
          endLine: node.loc.end.line,
          extends: (node.extends || []).map(e => e.expression?.name || 'unknown'),
          node
        });
      }

      if (node.type === 'TSTypeAliasDeclaration') {
        types.push({
          name: node.id.name,
          kind: 'type',
          startLine: node.loc.start.line,
          endLine: node.loc.end.line,
          node
        });
      }

      if (node.type === 'TSEnumDeclaration') {
        types.push({
          name: node.id.name,
          kind: 'enum',
          startLine: node.loc.start.line,
          endLine: node.loc.end.line,
          members: (node.members || []).map(m => m.id?.name),
          node
        });
      }
    });

    return types;
  }

  // --- Heuristic fallbacks ---

  _findSymbolHeuristic(ast, symbolName) {
    const lines = ast.lines;
    const patterns = [
      { pattern: new RegExp(`^\\s*(?:export\\s+)?interface\\s+${symbolName}\\b`), type: 'interface' },
      { pattern: new RegExp(`^\\s*(?:export\\s+)?type\\s+${symbolName}\\s*=`), type: 'type' },
      { pattern: new RegExp(`^\\s*(?:export\\s+)?enum\\s+${symbolName}\\b`), type: 'enum' },
      { pattern: new RegExp(`^\\s*(?:export\\s+)?class\\s+${symbolName}\\b`), type: 'class' },
    ];

    for (let i = 0; i < lines.length; i++) {
      for (const { pattern, type } of patterns) {
        if (pattern.test(lines[i])) {
          return {
            name: symbolName,
            type,
            startLine: i + 1,
            endLine: i + 1 // Can't determine end without parsing
          };
        }
      }
    }

    return null;
  }

  _getTypeDefinitionsHeuristic(ast) {
    const lines = ast.lines;
    const types = [];
    
    const interfacePattern = /^\s*(?:export\s+)?interface\s+(\w+)/;
    const typePattern = /^\s*(?:export\s+)?type\s+(\w+)\s*=/;
    const enumPattern = /^\s*(?:export\s+)?enum\s+(\w+)/;

    for (let i = 0; i < lines.length; i++) {
      let match = lines[i].match(interfacePattern);
      if (match) {
        types.push({ name: match[1], kind: 'interface', startLine: i + 1, endLine: i + 1 });
        continue;
      }

      match = lines[i].match(typePattern);
      if (match) {
        types.push({ name: match[1], kind: 'type', startLine: i + 1, endLine: i + 1 });
        continue;
      }

      match = lines[i].match(enumPattern);
      if (match) {
        types.push({ name: match[1], kind: 'enum', startLine: i + 1, endLine: i + 1 });
      }
    }

    return types;
  }
}

module.exports = TypeScriptLanguageProvider;
