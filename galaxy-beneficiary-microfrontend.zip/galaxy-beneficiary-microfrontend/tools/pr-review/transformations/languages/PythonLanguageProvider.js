/**
 * PythonLanguageProvider
 * 
 * Language provider for Python files.
 * Uses indentation-based heuristics for structure analysis.
 */

const BaseLanguageProvider = require('./BaseLanguageProvider');

class PythonLanguageProvider extends BaseLanguageProvider {
  get languageId() {
    return 'python';
  }

  get extensions() {
    return ['.py', '.pyw', '.pyi'];
  }

  /**
   * Parse Python source (heuristic-based)
   */
  parse(source, options = {}) {
    const lines = source.split('\n');
    
    return {
      type: 'PythonDocument',
      source,
      lines,
      functions: this._findFunctions(lines),
      classes: this._findClasses(lines),
      imports: this._findImports(lines)
    };
  }

  /**
   * Find enclosing function for a line
   */
  findEnclosingFunction(ast, lineNum) {
    const candidates = ast.functions.filter(f => 
      f.startLine <= lineNum && f.endLine >= lineNum
    );
    
    // Return innermost function
    return candidates.length > 0 ? candidates[candidates.length - 1] : null;
  }

  /**
   * Find all functions in AST
   */
  findAllFunctions(ast) {
    return ast.functions || [];
  }

  /**
   * Get all imports
   */
  getImports(ast) {
    return ast.imports || [];
  }

  /**
   * Find a symbol (class, function, variable)
   */
  findSymbol(ast, symbolName) {
    // Check functions
    const func = ast.functions.find(f => f.name === symbolName);
    if (func) {
      return {
        name: symbolName,
        type: 'function',
        startLine: func.startLine,
        endLine: func.endLine
      };
    }

    // Check classes
    const cls = ast.classes.find(c => c.name === symbolName);
    if (cls) {
      return {
        name: symbolName,
        type: 'class',
        startLine: cls.startLine,
        endLine: cls.endLine
      };
    }

    return null;
  }

  /**
   * Get all classes
   */
  getClasses(ast) {
    return ast.classes || [];
  }

  // --- Private helpers ---

  _findFunctions(lines) {
    const functions = [];
    const funcPattern = /^(\s*)(async\s+)?def\s+(\w+)\s*\(/;

    for (let i = 0; i < lines.length; i++) {
      const match = lines[i].match(funcPattern);
      if (match) {
        const indent = match[1].length;
        const name = match[3];
        const isAsync = !!match[2];
        
        // Find end of function by indentation
        const endLine = this._findBlockEnd(lines, i, indent);
        
        functions.push({
          name,
          type: isAsync ? 'async function' : 'function',
          startLine: i + 1,
          endLine,
          indent,
          startColumn: indent,
          endColumn: 0,
          async: isAsync,
          generator: false,
          params: this._extractParams(lines[i])
        });
      }
    }

    return functions;
  }

  _findClasses(lines) {
    const classes = [];
    const classPattern = /^(\s*)class\s+(\w+)(?:\s*\([^)]*\))?\s*:/;

    for (let i = 0; i < lines.length; i++) {
      const match = lines[i].match(classPattern);
      if (match) {
        const indent = match[1].length;
        const name = match[2];
        
        // Find end of class by indentation
        const endLine = this._findBlockEnd(lines, i, indent);
        
        // Extract parent classes
        const parents = [];
        const parentsMatch = lines[i].match(/class\s+\w+\s*\(([^)]*)\)/);
        if (parentsMatch) {
          parents.push(...parentsMatch[1].split(',').map(p => p.trim()).filter(Boolean));
        }

        classes.push({
          name,
          type: 'class',
          startLine: i + 1,
          endLine,
          indent,
          parents
        });
      }
    }

    return classes;
  }

  _findImports(lines) {
    const imports = [];
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      
      // import X
      // import X as Y
      // import X, Y, Z
      const importMatch = line.match(/^import\s+(.+)$/);
      if (importMatch) {
        const modules = importMatch[1].split(',').map(m => m.trim().split(/\s+as\s+/)[0]);
        imports.push({
          source: modules.join(', '),
          specifiers: modules,
          line: i + 1,
          type: 'import'
        });
        continue;
      }

      // from X import Y
      // from X import Y, Z
      // from X import *
      const fromMatch = line.match(/^from\s+([\w.]+)\s+import\s+(.+)$/);
      if (fromMatch) {
        const source = fromMatch[1];
        const imported = fromMatch[2].split(',').map(s => s.trim().split(/\s+as\s+/)[0]);
        imports.push({
          source,
          specifiers: imported,
          line: i + 1,
          type: 'from'
        });
      }
    }

    return imports;
  }

  _findBlockEnd(lines, startLine, startIndent) {
    for (let i = startLine + 1; i < lines.length; i++) {
      const line = lines[i];
      
      // Skip empty lines and comments
      if (line.trim() === '' || line.trim().startsWith('#')) {
        continue;
      }

      // Calculate current indent
      const currentIndent = line.match(/^(\s*)/)[1].length;
      
      // If we're back to the same or lower indent level, block ended
      if (currentIndent <= startIndent) {
        return i; // Return 1-based
      }
    }

    return lines.length;
  }

  _extractParams(defLine) {
    const match = defLine.match(/def\s+\w+\s*\(([^)]*)\)/);
    if (!match) return [];
    
    return match[1]
      .split(',')
      .map(p => p.trim().split(':')[0].split('=')[0].trim())
      .filter(p => p && p !== 'self' && p !== 'cls');
  }
}

module.exports = PythonLanguageProvider;
