/**
 * Language Providers
 * 
 * Registry and factory for language-specific parsing providers.
 * Abstracts away parsing details for different file types.
 * 
 * Usage:
 *   const { getProviderForFile, parseFile } = require('./languages');
 *   
 *   // Get provider for a specific file
 *   const provider = getProviderForFile('app.tsx');
 *   const ast = provider.parse(source);
 *   const func = provider.findEnclosingFunction(ast, 42);
 *   
 *   // Or use the convenience function
 *   const ast = parseFile('config.yaml', yamlContent);
 */

const BaseLanguageProvider = require('./BaseLanguageProvider');
const JavaScriptLanguageProvider = require('./JavaScriptLanguageProvider');
const TypeScriptLanguageProvider = require('./TypeScriptLanguageProvider');
const JsonLanguageProvider = require('./JsonLanguageProvider');
const YamlLanguageProvider = require('./YamlLanguageProvider');
const PythonLanguageProvider = require('./PythonLanguageProvider');
const JavaLanguageProvider = require('./JavaLanguageProvider');
const GenericLanguageProvider = require('./GenericLanguageProvider');

/**
 * Registry of language providers
 */
const providers = [
  new TypeScriptLanguageProvider(),  // Before JS (more specific)
  new JavaScriptLanguageProvider(),
  new JsonLanguageProvider(),
  new YamlLanguageProvider(),
  new PythonLanguageProvider(),
  new JavaLanguageProvider(),
];

/**
 * Extension to language ID mapping (for fallback)
 */
const extensionMap = {
  '.js': 'javascript',
  '.jsx': 'javascript',
  '.mjs': 'javascript',
  '.cjs': 'javascript',
  '.ts': 'typescript',
  '.tsx': 'typescript',
  '.mts': 'typescript',
  '.cts': 'typescript',
  '.json': 'json',
  '.jsonc': 'json',
  '.json5': 'json',
  '.yaml': 'yaml',
  '.yml': 'yaml',
  '.py': 'python',
  '.pyw': 'python',
  '.pyi': 'python',
  '.md': 'markdown',
  '.mdx': 'markdown',
  '.html': 'html',
  '.htm': 'html',
  '.css': 'css',
  '.scss': 'scss',
  '.sass': 'sass',
  '.less': 'less',
  '.java': 'java',
  '.kt': 'kotlin',
  '.kts': 'kotlin',
  '.go': 'go',
  '.rs': 'rust',
  '.rb': 'ruby',
  '.php': 'php',
  '.c': 'c',
  '.h': 'c',
  '.cpp': 'cpp',
  '.cc': 'cpp',
  '.cxx': 'cpp',
  '.hpp': 'cpp',
  '.cs': 'csharp',
  '.swift': 'swift',
  '.sh': 'shell',
  '.bash': 'shell',
  '.zsh': 'shell',
  '.bat': 'batch',
  '.cmd': 'batch',
  '.ps1': 'powershell',
  '.sql': 'sql',
  '.xml': 'xml',
  '.svg': 'xml',
  '.toml': 'toml',
  '.ini': 'ini',
  '.cfg': 'ini',
  '.env': 'dotenv',
  '.dockerfile': 'dockerfile',
  '.graphql': 'graphql',
  '.gql': 'graphql',
  '.proto': 'protobuf',
};

/**
 * Get the language provider for a file
 * @param {string} filePath - File path or name
 * @param {object} options - Provider options
 * @returns {BaseLanguageProvider|null} Provider instance or null if unsupported
 */
function getProviderForFile(filePath, options = {}) {
  for (const provider of providers) {
    if (provider.supports(filePath)) {
      // Return configured instance
      if (options.verbose !== undefined) {
        provider.verbose = options.verbose;
      }
      return provider;
    }
  }
  
  // Return generic fallback if requested
  if (options.allowFallback !== false) {
    if (options.verbose !== undefined) {
      genericProvider.verbose = options.verbose;
    }
    return genericProvider;
  }
  
  return null;
}

/**
 * Get the language ID for a file extension
 * @param {string} filePath - File path or extension
 * @returns {string|null} Language ID or null
 */
function getLanguageId(filePath) {
  const ext = getExtension(filePath);
  return extensionMap[ext] || null;
}

/**
 * Get file extension from path
 * @param {string} filePath - File path
 * @returns {string} Extension including dot (e.g., '.js')
 */
function getExtension(filePath) {
  const match = filePath.match(/(\.[^./\\]+)$/);
  return match ? match[1].toLowerCase() : '';
}

/**
 * Check if a file type is supported by a provider
 * @param {string} filePath - File path
 * @returns {boolean}
 */
function isSupported(filePath) {
  return getProviderForFile(filePath) !== null;
}

/**
 * Parse a file with the appropriate provider
 * @param {string} filePath - File path (for language detection)
 * @param {string} source - Source content
 * @param {object} options - Parse options
 * @returns {object|null} Parsed AST or null if unsupported
 */
function parseFile(filePath, source, options = {}) {
  const provider = getProviderForFile(filePath, options);
  if (!provider) {
    return null;
  }
  return provider.parse(source, { filePath, ...options });
}

/**
 * Find enclosing function in a file
 * @param {string} filePath - File path
 * @param {string} source - Source content
 * @param {number} lineNum - 1-based line number
 * @param {object} options - Options
 * @returns {FunctionInfo|null}
 */
function findEnclosingFunction(filePath, source, lineNum, options = {}) {
  const provider = getProviderForFile(filePath, options);
  if (!provider) {
    return null;
  }
  
  const ast = provider.parse(source, { filePath, ...options });
  if (!ast) {
    return null;
  }
  
  return provider.findEnclosingFunction(ast, lineNum);
}

/**
 * Find all functions in a file
 * @param {string} filePath - File path
 * @param {string} source - Source content
 * @param {object} options - Options
 * @returns {FunctionInfo[]}
 */
function findAllFunctions(filePath, source, options = {}) {
  const provider = getProviderForFile(filePath, options);
  if (!provider) {
    return [];
  }
  
  const ast = provider.parse(source, { filePath, ...options });
  if (!ast) {
    return [];
  }
  
  return provider.findAllFunctions(ast);
}

/**
 * Get imports from a file
 * @param {string} filePath - File path
 * @param {string} source - Source content
 * @param {object} options - Options
 * @returns {ImportInfo[]}
 */
function getImports(filePath, source, options = {}) {
  const provider = getProviderForFile(filePath, options);
  if (!provider) {
    return [];
  }
  
  const ast = provider.parse(source, { filePath, ...options });
  if (!ast) {
    return [];
  }
  
  return provider.getImports(ast);
}

/**
 * Register a custom language provider
 * @param {BaseLanguageProvider} provider - Provider instance
 * @param {boolean} prepend - Add to start of list (higher priority)
 */
function registerProvider(provider, prepend = false) {
  if (!(provider instanceof BaseLanguageProvider)) {
    throw new Error('Provider must extend BaseLanguageProvider');
  }
  if (prepend) {
    providers.unshift(provider);
  } else {
    providers.push(provider);
  }
}

/**
 * Get all registered providers
 * @returns {BaseLanguageProvider[]}
 */
function getProviders() {
  return [...providers];
}

/**
 * Get all supported extensions
 * @returns {string[]}
 */
function getSupportedExtensions() {
  const exts = new Set();
  for (const provider of providers) {
    for (const ext of provider.extensions) {
      exts.add(ext);
    }
  }
  return Array.from(exts);
}

// Default fallback provider
const genericProvider = new GenericLanguageProvider();

module.exports = {
  // Classes
  BaseLanguageProvider,
  JavaScriptLanguageProvider,
  TypeScriptLanguageProvider,
  JsonLanguageProvider,
  YamlLanguageProvider,
  PythonLanguageProvider,
  JavaLanguageProvider,
  GenericLanguageProvider,
  
  // Factory functions
  getProviderForFile,
  getLanguageId,
  getExtension,
  isSupported,
  parseFile,
  
  // Convenience functions
  findEnclosingFunction,
  findAllFunctions,
  getImports,
  
  // Registry management
  registerProvider,
  getProviders,
  getSupportedExtensions,
  
  // Direct access to extension map
  extensionMap,
};
