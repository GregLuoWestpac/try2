/**
 * JavaScriptLanguageProvider
 * 
 * Language provider for JavaScript files using Babel Parser.
 * Provides AST parsing and code analysis for JS/JSX files.
 */

const BaseLanguageProvider = require('./BaseLanguageProvider');

// Lazy-load babel parser to avoid startup cost
let babelParser = null;
function getBabelParser() {
  if (!babelParser) {
    try {
      babelParser = require('@babel/parser');
    } catch (e) {
      return null;
    }
  }
  return babelParser;
}

class JavaScriptLanguageProvider extends BaseLanguageProvider {
  get languageId() {
    return 'javascript';
  }

  get extensions() {
    return ['.js', '.jsx', '.mjs', '.cjs'];
  }

  /**
   * Parse JavaScript source into AST
   */
  parse(source, options = {}) {
    const parser = getBabelParser();
    
    if (!parser) {
      // Fallback: return minimal structure for heuristic analysis
      return this._parseHeuristic(source);
    }

    try {
      return parser.parse(source, {
        sourceType: options.sourceType || 'module',
        plugins: [
          'jsx',
          'classProperties',
          'classPrivateProperties',
          'classPrivateMethods',
          ['decorators', { decoratorsBeforeExport: true }],
          'exportDefaultFrom',
          'exportNamespaceFrom',
          'dynamicImport',
          'nullishCoalescingOperator',
          'optionalChaining',
          'objectRestSpread',
          ...(options.plugins || [])
        ],
        attachComment: true,
        ranges: true,
        ...options
      });
    } catch (e) {
      if (this.verbose) {
        console.error(`[JavaScriptLanguageProvider] Parse error: ${e.message}`);
      }
      // Return heuristic fallback on parse error
      return this._parseHeuristic(source);
    }
  }

  /**
   * Heuristic fallback when Babel is unavailable
   */
  _parseHeuristic(source) {
    return {
      type: 'HeuristicParse',
      source,
      lines: source.split('\n'),
      program: { body: [] }
    };
  }

  /**
   * Find enclosing function for a line
   */
  findEnclosingFunction(ast, lineNum) {
    if (ast.type === 'HeuristicParse') {
      return this._findEnclosingFunctionHeuristic(ast, lineNum);
    }

    const functions = [];
    this._visitNode(ast.program, (node) => {
      if (this._isFunctionNode(node)) {
        if (node.loc.start.line <= lineNum && node.loc.end.line >= lineNum) {
          functions.push(this._nodeToFunctionInfo(node));
        }
      }
    });

    // Return innermost (last) function containing the line
    return functions.length > 0 ? functions[functions.length - 1] : null;
  }

  /**
   * Find all functions in AST
   */
  findAllFunctions(ast) {
    if (ast.type === 'HeuristicParse') {
      return this._findAllFunctionsHeuristic(ast);
    }

    const functions = [];
    this._visitNode(ast.program, (node) => {
      if (this._isFunctionNode(node)) {
        functions.push(this._nodeToFunctionInfo(node));
      }
    });
    return functions;
  }

  /**
   * Find symbol by name
   */
  findSymbol(ast, symbolName) {
    if (ast.type === 'HeuristicParse') {
      return null;
    }

    let found = null;
    this._visitNode(ast.program, (node) => {
      if (found) return;

      // Variable declarations
      if (node.type === 'VariableDeclarator' && node.id?.name === symbolName) {
        found = {
          name: symbolName,
          type: 'variable',
          startLine: node.loc.start.line,
          endLine: node.loc.end.line,
          node
        };
      }

      // Function declarations
      if (node.type === 'FunctionDeclaration' && node.id?.name === symbolName) {
        found = {
          name: symbolName,
          type: 'function',
          startLine: node.loc.start.line,
          endLine: node.loc.end.line,
          node
        };
      }

      // Class declarations
      if (node.type === 'ClassDeclaration' && node.id?.name === symbolName) {
        found = {
          name: symbolName,
          type: 'class',
          startLine: node.loc.start.line,
          endLine: node.loc.end.line,
          node
        };
      }
    });

    return found;
  }

  /**
   * Get all imports
   */
  getImports(ast) {
    if (ast.type === 'HeuristicParse') {
      return this._getImportsHeuristic(ast);
    }

    const imports = [];
    for (const node of ast.program.body) {
      if (node.type === 'ImportDeclaration') {
        const specifiers = [];
        let defaultImport = null;
        let isNamespace = false;

        for (const spec of node.specifiers || []) {
          if (spec.type === 'ImportDefaultSpecifier') {
            defaultImport = spec.local.name;
          } else if (spec.type === 'ImportNamespaceSpecifier') {
            isNamespace = true;
            specifiers.push(spec.local.name);
          } else if (spec.type === 'ImportSpecifier') {
            specifiers.push(spec.imported.name);
          }
        }

        imports.push({
          source: node.source.value,
          specifiers,
          defaultImport,
          isNamespace,
          line: node.loc.start.line
        });
      }
    }
    return imports;
  }

  /**
   * Get all exports
   */
  getExports(ast) {
    if (ast.type === 'HeuristicParse') {
      return [];
    }

    const exports = [];
    for (const node of ast.program.body) {
      if (node.type === 'ExportDefaultDeclaration') {
        exports.push({
          name: 'default',
          type: 'default',
          line: node.loc.start.line
        });
      } else if (node.type === 'ExportNamedDeclaration') {
        if (node.declaration) {
          // export const/function/class
          const names = this._getDeclarationNames(node.declaration);
          for (const name of names) {
            exports.push({ name, type: 'named', line: node.loc.start.line });
          }
        }
        for (const spec of node.specifiers || []) {
          exports.push({
            name: spec.exported.name,
            type: 'named',
            line: node.loc.start.line
          });
        }
      } else if (node.type === 'ExportAllDeclaration') {
        exports.push({
          name: '*',
          type: 'all',
          source: node.source.value,
          line: node.loc.start.line
        });
      }
    }
    return exports;
  }

  /**
   * Get comments from AST
   */
  getComments(ast) {
    if (ast.type === 'HeuristicParse' || !ast.comments) {
      return [];
    }

    return ast.comments.map(c => ({
      type: c.type === 'CommentLine' ? 'line' : (c.value.startsWith('*') ? 'doc' : 'block'),
      text: c.value,
      startLine: c.loc.start.line,
      endLine: c.loc.end.line
    }));
  }

  // --- Private helpers ---

  _isFunctionNode(node) {
    return [
      'FunctionDeclaration',
      'FunctionExpression',
      'ArrowFunctionExpression',
      'ObjectMethod',
      'ClassMethod',
      'ClassPrivateMethod'
    ].includes(node.type);
  }

  _nodeToFunctionInfo(node) {
    let name = 'anonymous';
    let type = 'function';

    if (node.id?.name) {
      name = node.id.name;
    } else if (node.key?.name) {
      name = node.key.name;
    }

    if (node.type === 'ArrowFunctionExpression') {
      type = 'arrow';
    } else if (node.type === 'ClassMethod' || node.type === 'ObjectMethod') {
      type = node.kind || 'method';
    }

    return {
      name,
      type,
      startLine: node.loc.start.line,
      endLine: node.loc.end.line,
      startColumn: node.loc.start.column,
      endColumn: node.loc.end.column,
      params: (node.params || []).map(p => p.name || 'param'),
      async: !!node.async,
      generator: !!node.generator,
      node
    };
  }

  _visitNode(node, callback) {
    if (!node || typeof node !== 'object') return;
    
    callback(node);
    
    for (const key of Object.keys(node)) {
      const child = node[key];
      if (Array.isArray(child)) {
        for (const item of child) {
          this._visitNode(item, callback);
        }
      } else if (child && typeof child === 'object' && child.type) {
        this._visitNode(child, callback);
      }
    }
  }

  _getDeclarationNames(declaration) {
    if (!declaration) return [];
    
    if (declaration.id?.name) {
      return [declaration.id.name];
    }
    
    if (declaration.declarations) {
      return declaration.declarations
        .map(d => d.id?.name)
        .filter(Boolean);
    }
    
    return [];
  }

  // --- Heuristic fallbacks ---

  _findEnclosingFunctionHeuristic(ast, lineNum) {
    const lines = ast.lines;
    let funcStartLine = -1;
    let funcName = 'anonymous';

    // Search backward for function declaration
    for (let i = lineNum - 1; i >= 0; i--) {
      const line = lines[i];
      const match = line.match(/^\s*(export\s+)?(async\s+)?(function\s+(\w+)|const\s+(\w+)\s*=.*(?:function|=>)|(\w+)\s*\(.*\)\s*\{)/);
      
      if (match) {
        funcStartLine = i;
        funcName = match[4] || match[5] || match[6] || 'anonymous';
        break;
      }
    }

    if (funcStartLine === -1) return null;

    // Find matching closing brace
    let braceCount = 0;
    let funcEndLine = -1;

    for (let i = funcStartLine; i < lines.length; i++) {
      for (const char of lines[i]) {
        if (char === '{') braceCount++;
        if (char === '}') braceCount--;
        if (braceCount === 0 && i > funcStartLine) {
          funcEndLine = i;
          break;
        }
      }
      if (funcEndLine !== -1) break;
    }

    if (funcEndLine === -1) return null;

    return {
      name: funcName,
      type: 'function',
      startLine: funcStartLine + 1,
      endLine: funcEndLine + 1,
      startColumn: 0,
      endColumn: lines[funcEndLine].length,
      params: [],
      async: false,
      generator: false
    };
  }

  _findAllFunctionsHeuristic(ast) {
    const lines = ast.lines;
    const functions = [];
    const funcPattern = /^\s*(export\s+)?(async\s+)?(function\s+(\w+)|const\s+(\w+)\s*=.*(?:function|=>)|(\w+)\s*\(.*\)\s*\{)/;

    for (let i = 0; i < lines.length; i++) {
      const match = lines[i].match(funcPattern);
      if (match) {
        const name = match[4] || match[5] || match[6] || 'anonymous';
        functions.push({
          name,
          type: 'function',
          startLine: i + 1,
          endLine: i + 1, // Can't determine end without parsing
          startColumn: 0,
          endColumn: 0,
          params: [],
          async: !!match[2],
          generator: false
        });
      }
    }

    return functions;
  }

  _getImportsHeuristic(ast) {
    const lines = ast.lines;
    const imports = [];
    const importPattern = /^\s*import\s+.*\s+from\s+['"]([^'"]+)['"]/;
    const requirePattern = /^\s*(?:const|let|var)\s+.*\s*=\s*require\(['"]([^'"]+)['"]\)/;

    for (let i = 0; i < lines.length; i++) {
      const importMatch = lines[i].match(importPattern);
      if (importMatch) {
        imports.push({
          source: importMatch[1],
          specifiers: [],
          line: i + 1
        });
        continue;
      }

      const requireMatch = lines[i].match(requirePattern);
      if (requireMatch) {
        imports.push({
          source: requireMatch[1],
          specifiers: [],
          line: i + 1
        });
      }
    }

    return imports;
  }
}

module.exports = JavaScriptLanguageProvider;
