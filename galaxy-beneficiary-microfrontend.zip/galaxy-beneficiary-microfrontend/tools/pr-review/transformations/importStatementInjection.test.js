/**
 * Unit tests for importStatementInjection transformation
 */

const importStatementInjection = require('./importStatementInjection');
const DiffContextBuilder = require('./DiffContextBuilder');
const GitTextProvider = require('./GitTextProvider');

jest.mock('./GitTextProvider');

describe('importStatementInjection', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('T013: extracts top-of-file import block', () => {
    const afterText = `import React from 'react';
import { useState, useEffect } from 'react';
import axios from 'axios';

const MyComponent = () => {
  return <div>Hello</div>;
};`;

    const rawDiffText = `diff --git a/src/MyComponent.tsx b/src/MyComponent.tsx
@@ -5,5 +5,6 @@
 const MyComponent = () => {
+  const [count, setCount] = useState(0);
   return <div>Hello</div>;`;

    GitTextProvider.mockImplementation(() => ({
      getAfterText: jest.fn(() => afterText),
      getBeforeText: jest.fn(() => ''),
    }));

    const ctx = DiffContextBuilder.buildDiffContext({
      rawDiffText,
      mergeBase: 'abc123',
      head: 'HEAD',
    });

    const config = { maxLines: 80, includeExportBlock: false };
    const result = importStatementInjection.transform(ctx, config);

    expect(result.appendedContextBlocks.length).toBeGreaterThan(0);
    const block = result.appendedContextBlocks.find((b) => b.name.includes('Imports'));
    expect(block).toBeDefined();
    expect(block.content).toContain("import React from 'react'");
    expect(block.content).toContain("import axios from 'axios'");
  });

  test('T014: honors maxLines and truncates deterministically', () => {
    const imports = [];
    for (let i = 0; i < 100; i++) {
      imports.push(`import module${i} from 'module${i}';`);
    }
    const afterText = imports.join('\n') + '\n\nconst x = 1;';

    const rawDiffText = `diff --git a/src/test.js b/src/test.js
@@ -102,3 +102,4 @@
 const x = 1;
+const y = 2;`;

    GitTextProvider.mockImplementation(() => ({
      getAfterText: jest.fn(() => afterText),
      getBeforeText: jest.fn(() => ''),
    }));

    const ctx = DiffContextBuilder.buildDiffContext({
      rawDiffText,
      mergeBase: 'abc123',
      head: 'HEAD',
    });

    const config = { maxLines: 10, includeExportBlock: false };
    const result = importStatementInjection.transform(ctx, config);

    const block = result.appendedContextBlocks.find((b) => b.name.includes('Imports'));
    expect(block).toBeDefined();
    
    const contentLines = block.content.split('\n').filter((l) => l.trim());
    expect(contentLines.length).toBeLessThanOrEqual(11); // 10 lines + truncation marker
    expect(block.content).toContain('truncated');
  });

  test('T015: skips non-JS/TS languages', () => {
    const afterText = `import os
import sys

def main():
    print("Hello")`;

    const rawDiffText = `diff --git a/src/test.py b/src/test.py
@@ -4,3 +4,4 @@
 def main():
+    print("World")
     print("Hello")`;

    GitTextProvider.mockImplementation(() => ({
      getAfterText: jest.fn(() => afterText),
      getBeforeText: jest.fn(() => ''),
    }));

    const ctx = DiffContextBuilder.buildDiffContext({
      rawDiffText,
      mergeBase: 'abc123',
      head: 'HEAD',
    });

    const config = { maxLines: 80, includeExportBlock: false };
    const result = importStatementInjection.transform(ctx, config);

    const importBlock = result.appendedContextBlocks.find((b) => b.name.includes('Imports'));
    expect(importBlock).toBeUndefined();
  });

  test('T035: uses file.afterText from context (no extra git read)', () => {
    GitTextProvider.mockImplementation(() => {
      throw new Error('GitTextProvider should not be constructed');
    });

    const ctx = {
      rawDiffText: 'diff --git a/src/a.ts b/src/a.ts',
      mergeBase: 'abc123',
      head: 'HEAD',
      appendedContextBlocks: [],
      files: [
        {
          path: 'src/a.ts',
          languageId: 'typescript',
          beforeText: null,
          afterText: "import React from 'react';\n\nconst x = 1;\n",
          hunks: [{ newStart: 3, lines: ['+const y = 2;'] }],
        },
      ],
    };

    const result = importStatementInjection.transform(ctx, {
      maxLines: 80,
      includeExportBlock: false,
    });

    expect(GitTextProvider).not.toHaveBeenCalled();
    const block = result.appendedContextBlocks.find((b) => b.name.includes('Imports'));
    expect(block).toBeDefined();
    expect(block.content).toContain('import React');
  });
});
