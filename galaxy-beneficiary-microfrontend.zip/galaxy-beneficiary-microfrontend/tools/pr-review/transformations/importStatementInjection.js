/**
 * importStatementInjection - Adds import/export context from top of file
 */

const GitTextProvider = require('./GitTextProvider');

class ImportStatementInjection {
  /**
   * Transform context by adding import statements
   */
  static transform(ctx, config = {}) {
    const maxLines = config.maxLines || 80;
    const includeExportBlock = config.includeExportBlock || false;

    for (const file of ctx.files) {
      // Only process JS/TS files
      if (!this.isJavaScriptFile(file.languageId)) {
        continue;
      }

      const afterText = file.afterText || new GitTextProvider(ctx.mergeBase, ctx.head).getAfterText(file.path);
      if (!afterText) {
        continue;
      }

      file.afterText = afterText;

      // Extract imports
      const imports = this.extractImports(afterText, maxLines);
      
      if (imports) {
        ctx.appendedContextBlocks.push({
          name: 'Imports',
          file: file.path,
          content: imports,
        });
      }

      // Extract exports if requested
      if (includeExportBlock) {
        const exports = this.extractExports(afterText, maxLines);
        if (exports) {
          ctx.appendedContextBlocks.push({
            name: 'Exports',
            file: file.path,
            content: exports,
          });
        }
      }
    }

    return ctx;
  }

  /**
   * Check if file is JavaScript/TypeScript
   */
  static isJavaScriptFile(languageId) {
    return ['javascript', 'javascriptreact', 'typescript', 'typescriptreact'].includes(
      languageId
    );
  }

  /**
   * Extract import statements from top of file
   */
  static extractImports(text, maxLines) {
    const lines = text.split('\n');
    const importLines = [];
    let inImportBlock = false;

    for (const line of lines) {
      const trimmed = line.trim();
      
      // Start of import
      if (trimmed.startsWith('import ')) {
        inImportBlock = true;
        importLines.push(line);
      }
      // Continuation of multi-line import
      else if (inImportBlock && !trimmed.startsWith('//') && trimmed) {
        importLines.push(line);
        // Check if this line ends the import statement
        if (trimmed.endsWith(';') || trimmed.endsWith("';") || trimmed.endsWith('";')) {
          inImportBlock = false;
        }
      }
      // Empty line or comment - continue if we're in import section
      else if (trimmed === '' || trimmed.startsWith('//') || trimmed.startsWith('/*')) {
        if (importLines.length > 0) {
          importLines.push(line);
        }
      }
      // Non-import statement found after imports
      else if (importLines.length > 0) {
        break;
      }

      // Stop if we've exceeded maxLines
      if (importLines.length >= maxLines) {
        importLines.push('... truncated ...');
        break;
      }
    }

    return importLines.length > 0 ? importLines.join('\n') : null;
  }

  /**
   * Extract export statements (simplified - just looks for export keyword)
   */
  static extractExports(text, maxLines) {
    const lines = text.split('\n');
    const exportLines = [];

    for (const line of lines) {
      if (line.trim().startsWith('export ')) {
        exportLines.push(line);
        
        if (exportLines.length >= maxLines) {
          exportLines.push('... truncated ...');
          break;
        }
      }
    }

    return exportLines.length > 0 ? exportLines.join('\n') : null;
  }
}

module.exports = ImportStatementInjection;
