/**
 * GitTextProvider - Fetches file content from git history
 */

const { execSync } = require('child_process');

class GitTextProvider {
  constructor(mergeBase, head) {
    this.mergeBase = mergeBase;
    this.head = head;
  }

  /**
   * Get file content at merge base (before changes)
   */
  getBeforeText(path) {
    return this.getTextAt(this.mergeBase, path);
  }

  /**
   * Get file content at HEAD (after changes)
   */
  getAfterText(path) {
    return this.getTextAt(this.head, path);
  }

  /**
   * Get file content at a specific git ref
   */
  getTextAt(ref, path) {
    try {
      const content = execSync(`git show ${ref}:${path}`, {
        encoding: 'utf-8',
        stdio: ['ignore', 'pipe', 'ignore'],
      });
      return Buffer.isBuffer(content) ? content.toString('utf-8') : content;
    } catch (error) {
      // File doesn't exist at this ref (new/deleted file)
      return null;
    }
  }
}

module.exports = GitTextProvider;
