/**
 * Unit tests for classOrComponentHeaderInclusion transformation
 */

const classOrComponentHeaderInclusion = require('./classOrComponentHeaderInclusion');
const DiffContextBuilder = require('./DiffContextBuilder');
const GitTextProvider = require('./GitTextProvider');

jest.mock('./GitTextProvider');

describe('classOrComponentHeaderInclusion', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('T016: finds nearest class header above changed line', () => {
    const afterText = `import React from 'react';

class Foo extends Bar {
  constructor(props) {
    super(props);
    this.state = { count: 0 };
  }

  render() {
    return <div>Hello</div>;
  }
}`;

    const rawDiffText = `diff --git a/src/Foo.tsx b/src/Foo.tsx
@@ -9,6 +9,7 @@
   render() {
+    const x = 1;
     return <div>Hello</div>;`;

    GitTextProvider.mockImplementation(() => ({
      getAfterText: jest.fn(() => afterText),
      getBeforeText: jest.fn(() => ''),
    }));

    const ctx = DiffContextBuilder.buildDiffContext({
      rawDiffText,
      mergeBase: 'abc123',
      head: 'HEAD',
    });

    const config = { maxHeaderLines: 3 };
    const result = classOrComponentHeaderInclusion.transform(ctx, config);

    const block = result.appendedContextBlocks.find((b) => b.name.includes('Class Header'));
    expect(block).toBeDefined();
    expect(block.content).toContain('class Foo extends Bar');
  });

  test('T017: finds function component signature above changed line', () => {
    const afterText = `import React from 'react';

function LandingPage(props) {
  const [count, setCount] = useState(0);
  
  return (
    <div>
      <h1>Landing Page</h1>
    </div>
  );
}`;

    const rawDiffText = `diff --git a/src/LandingPage.tsx b/src/LandingPage.tsx
@@ -5,6 +5,7 @@
   
   return (
     <div>
+      <p>New paragraph</p>
       <h1>Landing Page</h1>`;

    GitTextProvider.mockImplementation(() => ({
      getAfterText: jest.fn(() => afterText),
      getBeforeText: jest.fn(() => ''),
    }));

    const ctx = DiffContextBuilder.buildDiffContext({
      rawDiffText,
      mergeBase: 'abc123',
      head: 'HEAD',
    });

    const config = { maxHeaderLines: 3 };
    const result = classOrComponentHeaderInclusion.transform(ctx, config);

    const block = result.appendedContextBlocks.find((b) =>
      b.name.includes('Component Header')
    );
    expect(block).toBeDefined();
    expect(block.content).toContain('function LandingPage(props)');
  });

  test('T018: finds const component assignment signature', () => {
    const afterText = `import React from 'react';

const LandingPage = (props: Props) => {
  return <div>Hello</div>;
};`;

    const rawDiffText = `diff --git a/src/LandingPage.tsx b/src/LandingPage.tsx
@@ -3,5 +3,6 @@
 const LandingPage = (props: Props) => {
+  const x = 1;
   return <div>Hello</div>;`;

    GitTextProvider.mockImplementation(() => ({
      getAfterText: jest.fn(() => afterText),
      getBeforeText: jest.fn(() => ''),
    }));

    const ctx = DiffContextBuilder.buildDiffContext({
      rawDiffText,
      mergeBase: 'abc123',
      head: 'HEAD',
    });

    const config = { maxHeaderLines: 3 };
    const result = classOrComponentHeaderInclusion.transform(ctx, config);

    const block = result.appendedContextBlocks.find((b) =>
      b.name.includes('Component Header')
    );
    expect(block).toBeDefined();
    expect(block.content).toContain('const LandingPage = (props: Props) =>');
  });

  test('T019: skips if no header found within scan window', () => {
    // File with no class or component header nearby
    const afterText = `const x = 1;
const y = 2;
const z = 3;
// ... many more lines
const a = 4;`;

    const rawDiffText = `diff --git a/src/utils.js b/src/utils.js
@@ -3,4 +3,5 @@
 const z = 3;
+const z2 = 33;
 const a = 4;`;

    GitTextProvider.mockImplementation(() => ({
      getAfterText: jest.fn(() => afterText),
      getBeforeText: jest.fn(() => ''),
    }));

    const ctx = DiffContextBuilder.buildDiffContext({
      rawDiffText,
      mergeBase: 'abc123',
      head: 'HEAD',
    });

    const config = { maxHeaderLines: 3 };
    const result = classOrComponentHeaderInclusion.transform(ctx, config);

    const block = result.appendedContextBlocks.find(
      (b) => b.name.includes('Class Header') || b.name.includes('Component Header')
    );
    expect(block).toBeUndefined();
  });

  test('T038: uses file.afterText from context (no extra git read)', () => {
    GitTextProvider.mockImplementation(() => {
      throw new Error('GitTextProvider should not be constructed');
    });

    const ctx = {
      rawDiffText: 'diff --git a/src/a.tsx b/src/a.tsx',
      mergeBase: 'abc123',
      head: 'HEAD',
      appendedContextBlocks: [],
      files: [
        {
          path: 'src/a.tsx',
          languageId: 'typescriptreact',
          beforeText: null,
          afterText: `import React from 'react';

class Foo {
  render() {
    return <div/>;
  }
}
`,
          hunks: [{ newStart: 5, lines: ['+    const x = 1;'] }],
        },
      ],
    };

    const result = classOrComponentHeaderInclusion.transform(ctx, {
      maxHeaderLines: 3,
      scanWindowLines: 200,
    });

    expect(GitTextProvider).not.toHaveBeenCalled();
    const block = result.appendedContextBlocks.find((b) => b.name.includes('Class Header'));
    expect(block).toBeDefined();
    expect(block.content).toContain('class Foo');
  });
});
