/**
 * classOrComponentHeaderInclusion - Adds class/component header context
 */

const GitTextProvider = require('./GitTextProvider');

class ClassOrComponentHeaderInclusion {
  /**
   * Transform context by adding class/component headers
   */
  static transform(ctx, config = {}) {
    const maxHeaderLines = config.maxHeaderLines || 3;
    const scanWindowLines = config.scanWindowLines || 200;

    for (const file of ctx.files) {
      // Only process JS/TS files
      if (!this.isJavaScriptFile(file.languageId)) {
        continue;
      }

      const afterText = file.afterText || new GitTextProvider(ctx.mergeBase, ctx.head).getAfterText(file.path);
      if (!afterText) {
        continue;
      }

      file.afterText = afterText;

      for (const hunk of file.hunks) {
        // Find changed lines in this hunk
        const changedLines = this.extractChangedLines(hunk);
        
        for (const lineNum of changedLines) {
          // Try to find class/component header
          const header = this.findHeader(afterText, lineNum, scanWindowLines, maxHeaderLines);
          
          if (header) {
            const blockName = header.type === 'class' ? 'Class Header' : 'Component Header';
            ctx.appendedContextBlocks.push({
              name: `${blockName} (${header.name})`,
              file: file.path,
              content: header.content,
            });
            break; // Only add one header per hunk
          }
        }
      }
    }

    return ctx;
  }

  /**
   * Check if file is JavaScript/TypeScript
   */
  static isJavaScriptFile(languageId) {
    return ['javascript', 'javascriptreact', 'typescript', 'typescriptreact'].includes(
      languageId
    );
  }

  /**
   * Extract changed line numbers from a hunk
   */
  static extractChangedLines(hunk) {
    const changedLines = [];
    let currentLine = hunk.newStart;

    for (const line of hunk.lines) {
      if (line.startsWith('+') && !line.startsWith('+++')) {
        changedLines.push(currentLine);
        currentLine++;
      } else if (!line.startsWith('-')) {
        currentLine++;
      }
    }

    return changedLines;
  }

  /**
   * Find class or component header above a given line
   */
  static findHeader(text, lineNum, scanWindowLines, maxHeaderLines) {
    const lines = text.split('\n');
    
    if (lineNum > lines.length) {
      return null;
    }

    const startScan = Math.max(0, lineNum - scanWindowLines - 1);
    
    // Search backward for class or component declaration
    for (let i = lineNum - 1; i >= startScan; i--) {
      const line = lines[i];
      
      // Match class declaration
      const classMatch = line.match(/^\s*class\s+(\w+)(\s+extends\s+\w+)?/);
      if (classMatch) {
        const name = classMatch[1];
        const headerContent = this.extractHeaderLines(lines, i, maxHeaderLines);
        return {
          type: 'class',
          name,
          content: headerContent,
        };
      }

      // Match function component (capitalized name)
      const funcMatch = line.match(/^\s*(export\s+)?(default\s+)?function\s+([A-Z]\w+)\s*\(/);
      if (funcMatch) {
        const name = funcMatch[3];
        const headerContent = this.extractHeaderLines(lines, i, maxHeaderLines);
        return {
          type: 'component',
          name,
          content: headerContent,
        };
      }

      // Match const/let component (arrow function with capitalized name)
      const constMatch = line.match(/^\s*(export\s+)?(const|let)\s+([A-Z]\w+)\s*=\s*(\(.*\)|.*)\s*=>/);
      if (constMatch) {
        const name = constMatch[3];
        const headerContent = this.extractHeaderLines(lines, i, maxHeaderLines);
        return {
          type: 'component',
          name,
          content: headerContent,
        };
      }
    }

    return null;
  }

  /**
   * Extract header lines (may span multiple lines)
   */
  static extractHeaderLines(lines, startLine, maxLines) {
    const headerLines = [];
    
    for (let i = startLine; i < Math.min(lines.length, startLine + maxLines); i++) {
      headerLines.push(lines[i]);
      
      // Stop if we hit the opening brace
      if (lines[i].includes('{')) {
        break;
      }
    }

    return headerLines.join('\n');
  }
}

module.exports = ClassOrComponentHeaderInclusion;
