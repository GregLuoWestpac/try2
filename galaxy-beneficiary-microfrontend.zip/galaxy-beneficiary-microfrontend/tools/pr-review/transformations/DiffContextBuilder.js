/**
 * DiffContextBuilder - Parses unified diff text into structured DiffContext
 */

const GitTextProvider = require('./GitTextProvider');

class DiffContextBuilder {
  /**
   * Build a DiffContext from raw unified diff text
   * @param {Object} options
   * @param {string} options.rawDiffText - Unified diff text
   * @param {string} options.mergeBase - Merge base SHA
   * @param {string} options.head - Head ref (typically 'HEAD')
   * @returns {Object} DiffContext
   */
  static buildDiffContext({ rawDiffText, mergeBase, head }) {
    const files = [];

    // Parse diff to extract files
    const fileBlocks = this.splitIntoFileBlocks(rawDiffText);

    for (const block of fileBlocks) {
      const file = this.parseFileBlock(block);
      if (file) {
        files.push(file);
      }
    }

    if (files.length > 0 && mergeBase && head) {
      const textProvider = new GitTextProvider(mergeBase, head);
      for (const file of files) {
        try {
          file.beforeText = textProvider.getBeforeText(file.path);
        } catch {
          file.beforeText = null;
        }

        try {
          file.afterText = textProvider.getAfterText(file.path);
        } catch {
          file.afterText = null;
        }
      }
    }

    return {
      rawDiffText,
      mergeBase,
      head,
      files,
      appendedContextBlocks: [],
    };
  }
  
  /**
   * Split diff text into per-file blocks
   */
  static splitIntoFileBlocks(diffText) {
    const blocks = [];
    const lines = diffText.split('\n');
    let currentBlock = [];
    
    for (const line of lines) {
      if (line.startsWith('diff --git ') && currentBlock.length > 0) {
        blocks.push(currentBlock.join('\n'));
        currentBlock = [line];
      } else {
        currentBlock.push(line);
      }
    }
    
    if (currentBlock.length > 0) {
      blocks.push(currentBlock.join('\n'));
    }
    
    return blocks;
  }
  
  /**
   * Parse a single file block from diff
   */
  static parseFileBlock(block) {
    const lines = block.split('\n');
    
    // Extract file path from diff --git line
    const diffLine = lines[0];
    const match = diffLine.match(/^diff --git a\/(.+?) b\/(.+?)$/);
    if (!match) {
      return null;
    }
    
    const path = match[2]; // Use the "b/" path (after version)
    
    // Parse hunks
    const hunks = this.parseHunks(block);
    
    return {
      path,
      languageId: this.detectLanguage(path),
      hunks,
      beforeText: null,
      afterText: null,
    };
  }
  
  /**
   * Parse hunks from file block
   */
  static parseHunks(block) {
    const hunks = [];
    const lines = block.split('\n');
    let currentHunk = null;
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      
      if (line.startsWith('@@')) {
        // Parse hunk header
        const match = line.match(/^@@ -(\d+),?(\d*) \+(\d+),?(\d*) @@/);
        if (match) {
          if (currentHunk) {
            hunks.push(currentHunk);
          }
          
          currentHunk = {
            oldStart: parseInt(match[1], 10),
            oldCount: match[2] ? parseInt(match[2], 10) : 1,
            newStart: parseInt(match[3], 10),
            newCount: match[4] ? parseInt(match[4], 10) : 1,
            lines: [],
            header: line,
          };
        }
      } else if (currentHunk) {
        // Add line to current hunk
        currentHunk.lines.push(line);
      }
    }
    
    if (currentHunk) {
      hunks.push(currentHunk);
    }
    
    return hunks;
  }
  
  /**
   * Detect language from file extension
   */
  static detectLanguage(path) {
    const ext = path.split('.').pop();
    const langMap = {
      ts: 'typescript',
      tsx: 'typescriptreact',
      js: 'javascript',
      jsx: 'javascriptreact',
    };
    return langMap[ext] || null;
  }
}

module.exports = DiffContextBuilder;
