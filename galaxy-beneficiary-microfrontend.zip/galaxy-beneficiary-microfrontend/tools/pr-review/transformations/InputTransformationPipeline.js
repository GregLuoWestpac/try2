/**
 * InputTransformationPipeline - Orchestrates input transformations
 */

class InputTransformationPipeline {
  constructor(transformations = [], options = {}) {
    this.transformations = transformations;
    this.maxTotalAppendedBytes = options.maxTotalAppendedBytes || 50000; // 50KB default
    this.maxAppendedBytesPerFile = options.maxAppendedBytesPerFile ?? Infinity;
  }

  /**
   * Run the pipeline on a DiffContext
   * @param {Object} ctx - DiffContext
   * @returns {Object} Transformed DiffContext
   */
  run(ctx) {
    let currentCtx = { ...ctx };

    for (const transformation of this.transformations) {
      // Skip disabled transformations
      if (transformation.enabled === false) {
        continue;
      }

      try {
        // Run transformation
        currentCtx = transformation.transform(currentCtx);
      } catch (error) {
        // Degrade gracefully - log error but continue
        console.error(`Transformation ${transformation.id} failed:`, error.message);
      }
    }

    currentCtx.appendedContextBlocks = this.enforceByteLimit(
      this.dedupeBlocks(currentCtx.appendedContextBlocks)
    );

    return currentCtx;
  }

  dedupeBlocks(blocks) {
    const seen = new Set();
    const deduped = [];

    for (const block of blocks || []) {
      if (!block) continue;
      const key = `${block.name}\n${block.file}\n${block.content}`;
      if (seen.has(key)) continue;
      seen.add(key);
      deduped.push(block);
    }

    return deduped;
  }

  /**
   * Enforce max total appended bytes limit (and per-file appended byte limit)
   */
  enforceByteLimit(blocks) {
    const limited = [];
    let totalBytes = 0;
    const perFileBytes = new Map();

    for (const block of blocks || []) {
      const blockText = this.formatBlock(block);
      const blockBytes = Buffer.byteLength(blockText, 'utf-8');

      const fileKey = block.file || '';
      const fileBytesSoFar = perFileBytes.get(fileKey) || 0;
      if (fileBytesSoFar + blockBytes > this.maxAppendedBytesPerFile) {
        continue;
      }

      if (totalBytes + blockBytes <= this.maxTotalAppendedBytes) {
        limited.push(block);
        totalBytes += blockBytes;
        perFileBytes.set(fileKey, fileBytesSoFar + blockBytes);
      } else {
        // Stop adding blocks once limit is reached
        break;
      }
    }

    return limited;
  }

  /**
   * Format a single block for byte calculation
   */
  formatBlock(block) {
    return `\n\n--- Related Context: ${block.name} ---\nFile: ${block.file}\n${block.content}\n--- End Related Context ---\n`;
  }

  /**
   * Format all appended blocks as a string
   */
  formatAppendedBlocks(blocks) {
    return blocks.map((block) => this.formatBlock(block)).join('');
  }

  /**
   * Get the final transformed diff text
   */
  getFinalDiffText(ctx) {
    const appendedText = this.formatAppendedBlocks(ctx.appendedContextBlocks);
    return ctx.rawDiffText + appendedText;
  }
}

module.exports = InputTransformationPipeline;
