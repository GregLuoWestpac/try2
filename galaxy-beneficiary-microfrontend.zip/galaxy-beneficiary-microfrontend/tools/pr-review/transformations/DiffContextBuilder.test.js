/**
 * Unit tests for DiffContextBuilder
 */

const DiffContextBuilder = require('./DiffContextBuilder');
const GitTextProvider = require('./GitTextProvider');

jest.mock('./GitTextProvider');

describe('DiffContextBuilder', () => {
  describe('buildDiffContext', () => {
    test('T001: parses multi-file unified diff', () => {
      const rawDiffText = `diff --git a/src/a.ts b/src/a.ts
index 1234567..abcdefg 100644
--- a/src/a.ts
+++ b/src/a.ts
@@ -1,3 +1,4 @@
 const x = 1;
+const y = 2;
 
 function foo() {
diff --git a/src/b.ts b/src/b.ts
index 9876543..fedcba9 100644
--- a/src/b.ts
+++ b/src/b.ts
@@ -10,5 +10,6 @@
 export class Bar {
   constructor() {
+    this.name = 'bar';
   }
 }`;

      const ctx = DiffContextBuilder.buildDiffContext({
        rawDiffText,
        mergeBase: 'abc123',
        head: 'HEAD',
      });

      expect(ctx.files).toHaveLength(2);
      expect(ctx.files[0].path).toBe('src/a.ts');
      expect(ctx.files[1].path).toBe('src/b.ts');
      expect(ctx.files[0].hunks.length).toBeGreaterThan(0);
      expect(ctx.files[1].hunks.length).toBeGreaterThan(0);
    });

    test('T002: handles diff with no hunks', () => {
      const rawDiffText = '';

      const ctx = DiffContextBuilder.buildDiffContext({
        rawDiffText,
        mergeBase: 'abc123',
        head: 'HEAD',
      });

      expect(ctx.files).toEqual([]);
      expect(ctx.rawDiffText).toBe('');
      expect(ctx.mergeBase).toBe('abc123');
      expect(ctx.head).toBe('HEAD');
    });

    test('T003: language detection from extension', () => {
      const testCases = [
        { path: 'src/file.ts', expected: 'typescript' },
        { path: 'src/file.tsx', expected: 'typescriptreact' },
        { path: 'src/file.js', expected: 'javascript' },
        { path: 'src/file.jsx', expected: 'javascriptreact' },
        { path: 'src/file.py', expected: null },
        { path: 'src/file.unknown', expected: null },
      ];

      testCases.forEach(({ path, expected }) => {
        const lang = DiffContextBuilder.detectLanguage(path);
        expect(lang).toBe(expected);
      });
    });

    test('T024: populates beforeText/afterText for each file via GitTextProvider', () => {
      const rawDiffText = `diff --git a/src/a.ts b/src/a.ts
index 1234567..abcdefg 100644
--- a/src/a.ts
+++ b/src/a.ts
@@ -1,1 +1,2 @@
 const x = 1;
+const y = 2;`;

      const getBeforeText = jest.fn(() => 'BEFORE_TEXT');
      const getAfterText = jest.fn(() => 'AFTER_TEXT');

      GitTextProvider.mockImplementation(() => ({
        getBeforeText,
        getAfterText,
      }));

      const ctx = DiffContextBuilder.buildDiffContext({
        rawDiffText,
        mergeBase: 'abc123',
        head: 'HEAD',
      });

      expect(GitTextProvider).toHaveBeenCalledWith('abc123', 'HEAD');
      expect(getBeforeText).toHaveBeenCalledWith('src/a.ts');
      expect(getAfterText).toHaveBeenCalledWith('src/a.ts');
      expect(ctx.files[0].beforeText).toBe('BEFORE_TEXT');
      expect(ctx.files[0].afterText).toBe('AFTER_TEXT');
    });

    test('T026: handles null beforeText/afterText gracefully', () => {
      const rawDiffText = `diff --git a/src/a.ts b/src/a.ts
@@ -1,1 +1,2 @@
 const x = 1;
+const y = 2;`;

      GitTextProvider.mockImplementation(() => ({
        getBeforeText: jest.fn(() => null),
        getAfterText: jest.fn(() => null),
      }));

      const ctx = DiffContextBuilder.buildDiffContext({
        rawDiffText,
        mergeBase: 'abc123',
        head: 'HEAD',
      });

      expect(ctx.files[0].beforeText).toBeNull();
      expect(ctx.files[0].afterText).toBeNull();
    });
  });
});
