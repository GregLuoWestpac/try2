# Review Output Schema

All review stages must output valid JSON in this exact format:

```json
{
  "passed": true,
  "issues": [
    {
      "severity": "HIGH|MEDIUM|LOW",
      "category": "string describing issue type",
      "file": "filename.ext",
      "line": 123,
      "issue": "Brief description of the problem",
      "suggestion": "How to fix or improve"
    }
  ],
  "observations": [
    {
      "type": "positive|neutral|suggestion",
      "description": "General observation about the code"
    }
  ],
  "summary": "One sentence summary of review findings"
}
```

## Field Descriptions

- **passed**: `true` if no HIGH severity issues, `false` otherwise
- **issues**: Array of specific problems found (empty array if none)
  - **severity**: HIGH (must fix), MEDIUM (should fix), LOW (consider fixing)
  - **category**: Type of issue (naming, structure, security, etc.)
  - **file**: Filename from the diff
  - **line**: Line number if identifiable, or `null`
  - **issue**: Clear description of the problem
  - **suggestion**: Actionable fix recommendation
- **observations**: General notes that aren't issues (empty array if none)
  - **type**: positive (good practice), neutral (informational), suggestion (optional improvement)
  - **description**: The observation
- **summary**: Brief one-line summary of the review

## Important

- Output ONLY the JSON object, no markdown code blocks
- Do not include any text before or after the JSON
- Ensure valid JSON syntax (proper quotes, commas, brackets)
