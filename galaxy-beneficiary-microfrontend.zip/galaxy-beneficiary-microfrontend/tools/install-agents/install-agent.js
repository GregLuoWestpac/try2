#!/usr/bin/env node
/**
 * All-in-one Agent Installer
 * Downloads files, executes actions, validates tokens.
 * Configuration-driven: update ai-common-config.json to add agents, files, or actions.
 */

// ============================================
// SECTION 1: Dependencies & Configuration
// ============================================
const https = require("https");
const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

const BITBUCKET_BASE_URL = "bitbucket.srv.westpac.com.au";
const AI_COMMON_PROJECT = "A014A6";
const AI_COMMON_REPO = "ai-common";
const PROJECT_ROOT = process.cwd();
const CONFIG_PATH = path.join(__dirname, "ai-common-config.json");

// ============================================
// SECTION 2: Utility Functions
// ============================================

function loadConfig() {
  if (!fs.existsSync(CONFIG_PATH)) {
    // eslint-disable-next-line no-console
    console.error("\n❌ Config not found. Run: node sync-ai-common.js\n");
    process.exit(1);
  }
  return JSON.parse(fs.readFileSync(CONFIG_PATH, "utf8"));
}

function validateToken() {
  if (!process.env.BITBUCKET_PAT) {
    // eslint-disable-next-line no-console
    console.error("\n❌ BITBUCKET_PAT not set\n");
    process.exit(1);
  }
  return process.env.BITBUCKET_PAT;
}

function ensureDirectoryExists(directoryPath) {
  if (!fs.existsSync(directoryPath))
    fs.mkdirSync(directoryPath, { recursive: true });
}

function isGitRepo() {
  try {
    execSync("git rev-parse --git-dir", { stdio: "pipe" });
    return true;
  } catch (_error) {
    return false;
  }
}

function isFileTrackedInGit(filePath) {
  if (!isGitRepo()) return false;
  try {
    execSync(`git ls-files --error-unmatch "${filePath}"`, { stdio: "pipe" });
    return true;
  } catch (_error) {
    return false;
  }
}

function restoreFileIfUnchangedFromHead(filePath) {
  if (!isGitRepo() || !isFileTrackedInGit(filePath)) return;
  try {
    execSync(`git diff --quiet HEAD -- "${filePath}"`, { stdio: "pipe" });
  } catch (_diffError) {
    try {
      const headContent = execSync(`git show HEAD:"${filePath}"`, {
        encoding: "utf8",
        stdio: "pipe",
      });
      const currentContent = fs.readFileSync(filePath, "utf8");
      if (headContent === currentContent) {
        execSync(`git checkout HEAD -- "${filePath}"`, { stdio: "pipe" });
      }
    } catch (_compareError) {
      // Couldn't compare, leave as is
    }
  }
}

function getTemplateVariables() {
  const variables = {
    PROJECT_ROOT,
    USER: process.env.USER || "user",
    OS: process.platform,
  };
  try {
    const remoteUrl = execSync("git config --get remote.origin.url", {
      encoding: "utf8",
      stdio: ["pipe", "pipe", "pipe"],
    }).trim();
    const repoNameMatch = remoteUrl.match(/\/([^/]+?)(\.git)?$/);
    if (repoNameMatch) {
      const [, repoName] = repoNameMatch;
      variables.GIT_REPO_NAME = repoName;
    }
  } catch (_error) {
    // No git remote available
  }
  return variables;
}

function substituteVariables(templateString, variables) {
  let result = templateString;
  Object.entries(variables).forEach(([variableName, variableValue]) => {
    result = result.replace(
      new RegExp(`\\$\\{${variableName}\\}`, "g"),
      variableValue,
    );
  });
  return result;
}

/**
 * Checks whether an item's target array matches the active target filter.
 * - If the item's target includes "generic" or "all" (backward compat), it always matches (wildcard).
 * - If no activeTarget is provided (no --target flag), defaults to "generic",
 *   matching items with "generic" or "all" targets.
 * - Otherwise, the item matches if its target includes the activeTarget value (case-insensitive).
 */
function isTargetMatch(itemTargets, activeTarget) {
  const effectiveTarget = activeTarget || "generic";
  const normalizedTargets = (itemTargets || ["generic"]).map((target) =>
    target.toLowerCase(),
  );
  // Support both "generic" (new) and "all" (backward compatibility) as wildcards
  if (
    normalizedTargets.includes("generic") ||
    normalizedTargets.includes("all")
  )
    return true;
  return normalizedTargets.includes(effectiveTarget.toLowerCase());
}

// ============================================
// SECTION 3: Download Functions
// ============================================

function downloadFileFromBitbucket(sourcePath, bitbucketToken, branchName) {
  return new Promise((resolve, reject) => {
    const requestPath = `/rest/api/1.0/projects/${AI_COMMON_PROJECT}/repos/${AI_COMMON_REPO}/raw/${sourcePath}?at=refs/heads/${branchName}`;
    https
      .request(
        {
          hostname: BITBUCKET_BASE_URL,
          path: requestPath,
          headers: { Authorization: `Bearer ${bitbucketToken}` },
          rejectUnauthorized: false,
        },
        (response) => {
          if (response.statusCode === 301 || response.statusCode === 302) {
            https
              .get(
                response.headers.location,
                {
                  headers: { Authorization: `Bearer ${bitbucketToken}` },
                  rejectUnauthorized: false,
                },
                (redirectResponse) => {
                  if (redirectResponse.statusCode !== 200) {
                    reject(new Error(`HTTP ${redirectResponse.statusCode}`));
                    return;
                  }
                  let responseData = "";
                  redirectResponse.on("data", (chunk) => {
                    responseData += chunk;
                  });
                  redirectResponse.on("end", () => {
                    resolve(responseData);
                  });
                },
              )
              .on("error", reject);
            return;
          }
          if (response.statusCode !== 200) {
            reject(new Error(`HTTP ${response.statusCode}`));
            return;
          }
          let responseData = "";
          response.on("data", (chunk) => {
            responseData += chunk;
          });
          response.on("end", () => {
            resolve(responseData);
          });
        },
      )
      .on("error", reject)
      .end();
  });
}

function listDirectoryFiles(directoryPath, bitbucketToken, branchName) {
  return new Promise((resolve, reject) => {
    const requestPath = `/rest/api/1.0/projects/${AI_COMMON_PROJECT}/repos/${AI_COMMON_REPO}/files/${directoryPath}?at=refs/heads/${branchName}&limit=1000`;
    https
      .request(
        {
          hostname: BITBUCKET_BASE_URL,
          path: requestPath,
          headers: { Authorization: `Bearer ${bitbucketToken}` },
          rejectUnauthorized: false,
        },
        (response) => {
          if (response.statusCode !== 200) {
            reject(new Error(`HTTP ${response.statusCode}`));
            return;
          }
          let responseData = "";
          response.on("data", (chunk) => {
            responseData += chunk;
          });
          response.on("end", () => {
            resolve(JSON.parse(responseData).values || []);
          });
        },
      )
      .on("error", reject)
      .end();
  });
}

async function downloadSingleFile(fileMapping, bitbucketToken, branchName) {
  try {
    process.stdout.write(
      `  ${fileMapping.description || fileMapping.source}... `,
    );
    const fileContent = await downloadFileFromBitbucket(
      fileMapping.source,
      bitbucketToken,
      branchName,
    );
    const destinationPath = path.join(PROJECT_ROOT, fileMapping.destination);
    const wasTracked = isFileTrackedInGit(destinationPath);

    ensureDirectoryExists(path.dirname(destinationPath));
    fs.writeFileSync(destinationPath, fileContent);

    if (
      !wasTracked &&
      (fileMapping.destination.endsWith(".js") ||
        fileMapping.destination.endsWith(".sh"))
    ) {
      try {
        fs.chmodSync(destinationPath, 0o755);
      } catch (_chmodError) {
        /* chmod may fail on Windows */
      }
    }

    if (wasTracked) {
      restoreFileIfUnchangedFromHead(destinationPath);
    }

    // eslint-disable-next-line no-console
    console.log("✓");
    return { success: true };
  } catch (downloadError) {
    // eslint-disable-next-line no-console
    console.log(`✗ (${downloadError.message})`);
    return { success: false, error: downloadError.message };
  }
}

async function downloadDirectoryFiles(fileMapping, bitbucketToken, branchName) {
  // eslint-disable-next-line no-console
  console.log(`\n  Dir: ${fileMapping.description || fileMapping.source}`);
  const results = [];
  try {
    const fileList = await listDirectoryFiles(
      fileMapping.source,
      bitbucketToken,
      branchName,
    );
    // Sequential downloads required to maintain order and avoid overwhelming the server
    // eslint-disable-next-line no-restricted-syntax
    for (const fileName of fileList) {
      const fullSourcePath = `${fileMapping.source}/${fileName}`;
      const relativePath = fileName.replace(`${fileMapping.source}/`, "");
      // eslint-disable-next-line no-await-in-loop
      results.push(
        await downloadSingleFile(
          {
            source: fullSourcePath,
            destination: path.join(fileMapping.destination, relativePath),
            description: fileName,
          },
          bitbucketToken,
          branchName,
        ),
      );
    }
  } catch (_listError) {
    results.push({ success: false });
  }
  return results;
}

async function downloadAgentFiles(
  agent,
  bitbucketToken,
  branchName,
  targetFilter,
) {
  // eslint-disable-next-line no-console
  console.log(`\n📦 ${agent.name}`);
  const results = [];
  // Sequential processing required for ordered output and server load management
  // eslint-disable-next-line no-restricted-syntax
  for (const fileMapping of agent.files) {
    if (!isTargetMatch(fileMapping.target, targetFilter)) {
      // eslint-disable-next-line no-console
      console.log(
        `  ⊘ Skipped (target): ${fileMapping.description || fileMapping.source}`,
      );
    } else if (fileMapping.type === "directory") {
      // eslint-disable-next-line no-await-in-loop
      results.push(
        ...(await downloadDirectoryFiles(
          fileMapping,
          bitbucketToken,
          branchName,
        )),
      );
    } else {
      // eslint-disable-next-line no-await-in-loop
      results.push(
        await downloadSingleFile(fileMapping, bitbucketToken, branchName),
      );
    }
  }
  return results;
}

// ============================================
// SECTION 4: Action Executors
// ============================================

function executeNpmInstall(action) {
  const packagePath = path.join(PROJECT_ROOT, action.path);
  if (!fs.existsSync(path.join(packagePath, "package.json"))) {
    throw new Error("No package.json");
  }
  execSync("npm install", { cwd: packagePath, stdio: "inherit" });
  // eslint-disable-next-line no-console
  console.log("    ✓");
  return { success: true };
}

function executeCreateConfig(action, templateVariables) {
  const destinationPath = path.join(PROJECT_ROOT, action.destination);

  let content = "";
  if (action.content) {
    content = action.content;
  } else if (action.template) {
    const templatePath = path.join(PROJECT_ROOT, action.template);
    if (fs.existsSync(templatePath))
      content = fs.readFileSync(templatePath, "utf8");
  }
  content = substituteVariables(content, {
    ...templateVariables,
    ...action.variables,
  });

  const isAutoGenerated = content.includes("AUTO-GENERATED");

  if (isAutoGenerated && fs.existsSync(destinationPath)) {
    fs.unlinkSync(destinationPath);
  }

  if (!isAutoGenerated && fs.existsSync(destinationPath)) {
    // eslint-disable-next-line no-console
    console.log("    Exists (user file)");
    return { success: true, skipped: true };
  }

  ensureDirectoryExists(path.dirname(destinationPath));
  fs.writeFileSync(destinationPath, content);
  // eslint-disable-next-line no-console
  console.log("    ✓");
  return { success: true };
}

function executeEnsureGitignore(action) {
  const gitignorePath = path.join(PROJECT_ROOT, ".gitignore");

  let lines = [];
  if (fs.existsSync(gitignorePath)) {
    lines = fs.readFileSync(gitignorePath, "utf8").split("\n");
  }

  let insertIndex = -1;
  const commentLine = action.entries.find((entry) => entry.startsWith("#"));
  if (commentLine) {
    insertIndex = lines.findIndex((line) => line.trim() === commentLine.trim());
  }

  const missingEntries = action.entries.filter((entry) => {
    if (entry === "" || entry.startsWith("#")) return false;
    return !lines.some((line) => line.trim() === entry.trim());
  });

  if (missingEntries.length > 0) {
    if (insertIndex === -1) {
      if (lines[lines.length - 1] !== "") lines.push("");
      lines.push(...action.entries);
    } else {
      lines.splice(insertIndex + 1, 0, ...missingEntries);
    }

    fs.writeFileSync(gitignorePath, lines.join("\n"));
    restoreFileIfUnchangedFromHead(gitignorePath);
  }

  // eslint-disable-next-line no-console
  console.log("    ✓");
  return { success: true };
}

function executeCopyFile(action) {
  const sourcePath = path.join(PROJECT_ROOT, action.source);
  const destinationPath = path.join(PROJECT_ROOT, action.destination);

  if (!fs.existsSync(sourcePath)) {
    throw new Error("Source not found");
  }

  if (fs.existsSync(destinationPath)) {
    // eslint-disable-next-line no-console
    console.log("    Exists");
    return { success: true, skipped: true };
  }

  ensureDirectoryExists(path.dirname(destinationPath));
  fs.copyFileSync(sourcePath, destinationPath);
  // eslint-disable-next-line no-console
  console.log("    ✓");
  return { success: true };
}

function executeMakeExecutable(action) {
  const filePath = path.join(PROJECT_ROOT, action.path);

  if (!fs.existsSync(filePath)) {
    throw new Error("File not found");
  }

  try {
    fs.chmodSync(filePath, 0o755);
  } catch (chmodError) {
    if (process.platform !== "win32") throw chmodError;
  }

  // eslint-disable-next-line no-console
  console.log("    ✓");
  return { success: true };
}

function executeRunScript(action) {
  const scriptPath = path.join(PROJECT_ROOT, action.script);

  if (!fs.existsSync(scriptPath)) {
    throw new Error("Script not found");
  }

  execSync(`node "${scriptPath}" ${(action.args || []).join(" ")}`, {
    cwd: PROJECT_ROOT,
    stdio: "inherit",
  });

  // eslint-disable-next-line no-console
  console.log("    ✓");
  return { success: true };
}

function executeAction(action, templateVariables) {
  // eslint-disable-next-line no-console
  console.log(`\n  ▸ ${action.description || action.type}`);
  try {
    switch (action.type) {
      case "npm-install":
        return executeNpmInstall(action);
      case "create-config":
        return executeCreateConfig(action, templateVariables);
      case "ensure-gitignore":
        return executeEnsureGitignore(action);
      case "copy-file":
        return executeCopyFile(action);
      case "make-executable":
        return executeMakeExecutable(action);
      case "run-script":
        return executeRunScript(action);
      default:
        throw new Error(`Unknown action type: ${action.type}`);
    }
  } catch (actionError) {
    // eslint-disable-next-line no-console
    console.log(`    ✗ ${actionError.message}`);
    return { success: false };
  }
}

// ============================================
// SECTION 5: Main Orchestration
// ============================================

function executeAllActions(agent, templateVariables, targetFilter) {
  // eslint-disable-next-line no-console
  console.log(`\n⚙️  ${agent.name}`);
  if (!agent.actions || !agent.actions.length) {
    // eslint-disable-next-line no-console
    console.log("  (none)");
    return { ok: 0, fail: 0 };
  }
  const results = [];
  let shouldStop = false;
  agent.actions.forEach((action) => {
    if (shouldStop) return;
    if (!isTargetMatch(action.target, targetFilter)) {
      // eslint-disable-next-line no-console
      console.log(
        `\n  ⊘ Skipped (target): ${action.description || action.type}`,
      );
      return;
    }
    const result = executeAction(action, templateVariables);
    results.push(result);
    if (!result.success && !result.skipped) {
      shouldStop = true;
    }
  });
  return {
    ok: results.filter((result) => result.success).length,
    fail: results.filter((result) => !result.success).length,
  };
}

function validateRequiredTokens(agent) {
  if (!agent.requiredTokens || !agent.requiredTokens.length) return true;
  // eslint-disable-next-line no-console
  console.log("\n🔑 Tokens");
  const validatorScriptPath = path.join(
    PROJECT_ROOT,
    ".github/skills/check-pat/scripts/validate-token.js",
  );
  if (!fs.existsSync(validatorScriptPath)) {
    // eslint-disable-next-line no-console
    console.log("  (validator missing)");
    return true;
  }
  let allTokensValid = true;
  agent.requiredTokens.forEach((tokenName) => {
    try {
      execSync(`node "${validatorScriptPath}" ${tokenName}`, {
        cwd: PROJECT_ROOT,
        stdio: "inherit",
      });
      // eslint-disable-next-line no-console
      console.log(`  ✓ ${tokenName}`);
    } catch (_validationError) {
      // eslint-disable-next-line no-console
      console.log(`  ✗ ${tokenName}`);
      allTokensValid = false;
    }
  });
  return allTokensValid;
}

function listAgents(config) {
  // eslint-disable-next-line no-console
  console.log("\n📋 Agents:\n");
  Object.entries(config.agents).forEach(([agentKey, agent]) => {
    const targetLabel = (agent.target || ["generic"]).join(", ");
    // eslint-disable-next-line no-console
    console.log(
      `${agent.enabled ? "✓" : "✗"} ${agentKey} - ${agent.description} [target: ${targetLabel}]`,
    );
  });
  // eslint-disable-next-line no-console
  console.log("");
}

async function installAgent(agentName, config, targetFilter) {
  const agent = config.agents[agentName];
  if (!agent) {
    // eslint-disable-next-line no-console
    console.error(`\n❌ Not found: ${agentName}\n`);
    process.exit(1);
  }
  if (!agent.enabled) {
    // eslint-disable-next-line no-console
    console.error(`\n❌ Disabled: ${agentName}\n`);
    process.exit(1);
  }

  // eslint-disable-next-line no-console
  console.log(`\n🚀 ${agent.name}\n`);

  const bitbucketToken = validateToken();
  const branchName = config.repository?.branch || "master";
  const templateVariables = getTemplateVariables();

  const downloadResults = await downloadAgentFiles(
    agent,
    bitbucketToken,
    branchName,
    targetFilter,
  );
  const successfulDownloadCount = downloadResults.filter(
    (result) => result.success,
  ).length;
  // eslint-disable-next-line no-console
  console.log(`\n  ✅ ${successfulDownloadCount} files`);
  if (downloadResults.some((result) => !result.success)) return false;

  const { ok: successfulActionCount, fail: failedActionCount } =
    executeAllActions(agent, templateVariables, targetFilter);
  // eslint-disable-next-line no-console
  console.log(`\n  ✅ ${successfulActionCount} actions`);
  if (failedActionCount > 0) return false;

  const allTokensValid = validateRequiredTokens(agent);

  // eslint-disable-next-line no-console
  console.log("\n✅ Done!\n");
  // eslint-disable-next-line no-console
  if (!allTokensValid) console.log("⚠️  Some tokens missing\n");

  return true;
}

async function installAllMatchingAgents(config, targetFilter) {
  const enabledAgents = Object.entries(config.agents).filter(
    ([, agent]) => agent.enabled && isTargetMatch(agent.target, targetFilter),
  );
  if (!enabledAgents.length) {
    // eslint-disable-next-line no-console
    console.log("\n⚠️  No matching enabled agents\n");
    return;
  }

  // eslint-disable-next-line no-console
  console.log(`\n🚀 ${enabledAgents.length} agents\n`);
  let successCount = 0;
  let failureCount = 0;
  // Sequential agent installation required for ordered output
  // eslint-disable-next-line no-restricted-syntax
  for (const [agentKey] of enabledAgents) {
    // eslint-disable-next-line no-console
    console.log("─".repeat(50));
    // eslint-disable-next-line no-await-in-loop
    const installResult = await installAgent(agentKey, config, targetFilter);
    if (installResult) {
      successCount += 1;
    } else {
      failureCount += 1;
    }
  }
  // eslint-disable-next-line no-console
  console.log(`\n📊 ${successCount} ok, ${failureCount} failed\n`);
  if (failureCount) process.exit(1);
}

/**
 * Parses the --target=<value> flag from CLI arguments.
 * Returns the target value or 'generic' if not specified (default).
 */
function parseTargetFlag(cliArgs) {
  const targetArg = cliArgs.find((arg) => arg.startsWith("--target="));
  if (!targetArg) return "generic";
  return targetArg.split("=")[1] || "generic";
}

async function main() {
  const cliArgs = process.argv.slice(2);

  if (cliArgs[0] === "--help") {
    /* eslint-disable no-console */
    console.log("\nUsage: node install-agent.js [options] [agent-name]\n");
    console.log("Description:");
    console.log(
      "  Downloads and installs AI agents from the ai-common repository.",
    );
    console.log("  Configuration is read from ai-common-config.json.\n");
    console.log("Arguments:");
    console.log(
      "  <agent-name>               Name of a specific agent to install\n",
    );
    console.log("Options:");
    console.log("  --help                     Show this help message and exit");
    console.log(
      "  --list                     List all available agents with their status and targets",
    );
    console.log(
      "  --target=<value>           Filter agents/files/actions by target platform",
    );
    console.log(
      '                             Defaults to "generic" if not specified',
    );
    console.log(
      "                             Common values: generic, mfe, spa, widget, api\n",
    );
    console.log("Examples:");
    console.log(
      "  node install-agent.js                        Install all enabled agents (target=generic)",
    );
    console.log(
      '  node install-agent.js code-review            Install the "code-review" agent (target=generic)',
    );
    console.log("  node install-agent.js code-review --target=mfe");
    console.log(
      '                                               Install agent, filtering by target "mfe"',
    );
    console.log(
      '  node install-agent.js --target=generic       Install all enabled agents with target "generic"',
    );
    console.log(
      '  node install-agent.js --target=mfe           Install all enabled agents matching target "mfe"',
    );
    console.log(
      "  node install-agent.js --list                 List available agents\n",
    );
    console.log("Environment:");
    console.log(
      "  BITBUCKET_PAT              Required. Personal access token for Bitbucket.\n",
    );
    /* eslint-enable no-console */
    process.exit(0);
  }

  const config = loadConfig();
  const targetFilter = parseTargetFlag(cliArgs);
  const positionalArgs = cliArgs.filter((arg) => !arg.startsWith("--target="));

  if (positionalArgs[0] === "--list") {
    listAgents(config);
  } else if (positionalArgs.length === 0 || positionalArgs[0] === undefined) {
    await installAllMatchingAgents(config, targetFilter);
  } else {
    const installSuccess = await installAgent(
      positionalArgs[0],
      config,
      targetFilter,
    );
    process.exit(installSuccess ? 0 : 1);
  }
}

if (require.main === module) {
  main().catch((error) => {
    // eslint-disable-next-line no-console
    console.error(`\n❌ ${error.message}\n`);
    process.exit(1);
  });
}

// Backward-compatible aliases for old function names (used by tests during migration)
const ensureDir = ensureDirectoryExists;
const getVars = getTemplateVariables;
const sub = substituteVariables;
const dl = downloadFileFromBitbucket;
const ls = listDirectoryFiles;
const dlSingle = downloadSingleFile;
const dlDir = downloadDirectoryFiles;
const dlAgent = downloadAgentFiles;
const exec = executeAction;
const execAll = executeAllActions;
const valTok = validateRequiredTokens;
const list = listAgents;
const install = installAgent;
const installAll = installAllMatchingAgents;

module.exports = {
  // New descriptive names
  loadConfig,
  validateToken,
  ensureDirectoryExists,
  isGitRepo,
  isFileTrackedInGit,
  restoreFileIfUnchangedFromHead,
  getTemplateVariables,
  substituteVariables,
  isTargetMatch,
  downloadFileFromBitbucket,
  listDirectoryFiles,
  downloadSingleFile,
  downloadDirectoryFiles,
  downloadAgentFiles,
  executeAction,
  executeNpmInstall,
  executeCreateConfig,
  executeEnsureGitignore,
  executeCopyFile,
  executeMakeExecutable,
  executeRunScript,
  executeAllActions,
  validateRequiredTokens,
  listAgents,
  installAgent,
  installAllMatchingAgents,
  parseTargetFlag,
  main,
  // Backward-compatible aliases
  ensureDir,
  getVars,
  sub,
  dl,
  ls,
  dlSingle,
  dlDir,
  dlAgent,
  exec,
  execAll,
  valTok,
  list,
  install,
  installAll,
  // Constants
  BITBUCKET_BASE_URL,
  AI_COMMON_PROJECT,
  AI_COMMON_REPO,
  PROJECT_ROOT,
  CONFIG_PATH,
};
