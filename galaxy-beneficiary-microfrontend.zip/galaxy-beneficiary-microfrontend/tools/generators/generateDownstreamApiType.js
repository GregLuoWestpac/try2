const fs = require('fs');
const path = require('path');
const { generateApi } = require('swagger-typescript-api');
const { convertDashedToCamelCase } = require('./utils.js');

const [, , downstreamServiceArgv, downstreamSwaggerUrlArgv] = process.argv;

const getArgvValue = argv => {
  return argv.split('=')[1];
};

const downstreamService = getArgvValue(downstreamServiceArgv);
const downstreamSwaggerUrl = getArgvValue(downstreamSwaggerUrlArgv);

async function generateDownstreamApiType(downstreamSwaggerUrl) {
  const outputPath = path.join(__dirname, '../../types');

  await generateApi({
    url: downstreamSwaggerUrl,
    output: outputPath,
    extractResponseBody: true,
    generateClient: false,
    modular: true,
  });
}

async function generateTypeTemplate(downstreamService) {
  await generateDownstreamApiType(downstreamSwaggerUrl);
  // await delay()

  const dataContractsPath = path.join(
    __dirname,
    '../../types/data-contracts.ts'
  );
  const dataContractsContent = fs.readFileSync(dataContractsPath, 'utf8');
  const modifiedDataContractsContent = dataContractsContent
    .split('\n')
    .slice(10)
    .join('\n');

  const downstreamApiTypeTemplate = modifiedDataContractsContent;

  const downstreamApiTypeDirPath = path.join(
    __dirname,
    '../../api/interfaces/models/downstream'
  );
  const downstreamApiTypeFilePath = path.join(
    downstreamApiTypeDirPath,
    `${convertDashedToCamelCase(downstreamService)}.ts`
  );

  // Ensure the directory exists
  if (!fs.existsSync(downstreamApiTypeDirPath)) {
    fs.mkdirSync(downstreamApiTypeDirPath, { recursive: true });
  }

  fs.writeFileSync(downstreamApiTypeFilePath, downstreamApiTypeTemplate);

  // Delete the /types folder
  const typesDirPath = path.join(__dirname, '../../types');
  if (fs.existsSync(typesDirPath)) {
    fs.rmSync(typesDirPath, { recursive: true, force: true });
  }

  process.exit();
}

generateTypeTemplate(downstreamService);
