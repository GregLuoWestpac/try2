const fs = require('fs');

const readline = require('readline').createInterface({
  input: process.stdin,
  output: process.stdout,
});

function readInput(prompt) {
  return new Promise((resolve) => {
    readline.question(prompt, (input) => {
      resolve(input);
    });
  });
}

function capitalizeFirstLetter(string) {
  const lowerStr = string.toLowerCase();
  return lowerStr.charAt(0).toUpperCase() + lowerStr.slice(1);
}

function capitalizeFirstLetterForCamelCase(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

function convertDashedToCamelCase(string) {
  if (!string) return '';

  return string
    .split('-')
    .map((word, index) => {
      if (index === 0) return word.toLowerCase();
      return capitalizeFirstLetter(word);
    })
    .join('');
}

function convertDashedToPath(string) {
  const lowerStr = string.toLowerCase();
  return lowerStr.split('-').join('/');
}

function getDownstreamApiType(string) {
  const lowerStr = string.toLowerCase();
  return capitalizeFirstLetter(lowerStr.split('-')[0]);
}

// Function to find the matching closing brace for a given opening brace
function findClosingBraceIndex(str, startIndex) {
  let openBraces = 0;
  for (let i = startIndex; i < str.length; i++) {
    if (str[i] === '{') openBraces++;
    if (str[i] === '}') openBraces--;
    if (openBraces === 0) return i;
  }
  return -1;
}

// Helper function to extract a type definition
function extractType(typeName, additionalContent, inputFilePath) {
  try {
    // Read the input file
    const data = fs.readFileSync(inputFilePath, 'utf8');

    // Use a regular expression to find the start of the specified type
    const typeRegex = new RegExp(`export\\s+interface\\s+${typeName}\\s+{`);
    const match = data.match(typeRegex);

    if (match) {
      const startIndex = match.index;
      const endIndex = findClosingBraceIndex(
        data,
        startIndex + match[0].length - 1,
      );

      if (endIndex !== -1) {
        const typeDefinition =
          data.substring(startIndex, endIndex + 1) + '\n' + additionalContent;

        // Delete the input file
        fs.unlinkSync(inputFilePath);
        return typeDefinition;
      } else {
        console.log('Matching closing brace not found.');
        return null;
      }
    } else {
      console.log(`${typeName} type not found in the file.`);
      return null;
    }
  } catch (err) {
    console.error('Error:', err);
    return null;
  }
}

module.exports = {
  capitalizeFirstLetter,
  capitalizeFirstLetterForCamelCase,
  convertDashedToCamelCase,
  convertDashedToPath,
  getDownstreamApiType,
  readInput,
  extractType,
};