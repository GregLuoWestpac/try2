const fs = require('fs');
const path = require('path');
const {
  convertDashedToPath,
} = require('./utils.js');

const getArgvValue = (argv) => {
  return argv.split('=')[1];
};

const [, , downstreamServiceArgv, downstreamApiPathArgv, downstreamApiHttpMethodArgv] = process.argv;
const downstreamService = getArgvValue(downstreamServiceArgv);
const downstreamApiPath = getArgvValue(downstreamApiPathArgv);
const downstreamApiHttpMethod = getArgvValue(downstreamApiHttpMethodArgv);

function generateDownstreamMockTemplate(
  downStreamService,
  downstreamApiPath,
  downstreamApiHttpMethod,
) {
  const downstreamApiMockPath = `${convertDashedToPath(downStreamService)}${downstreamApiPath}`;
  const downstreamApiMockTemplate = `{
    "body": {
        "data": {
        },
        "result": {
            "payments": []
        }
    }
}`;

  const downstreamApiMockDirPath = path.join(
    __dirname,
    `../../api/mock-api/static-mock/${downstreamApiMockPath}`,
  );
  const downstreamApiMockFilePath = path.join(
    downstreamApiMockDirPath,
    `${downstreamApiHttpMethod}.default.json`,
  );

  // Ensure the directory exists
  if (!fs.existsSync(downstreamApiMockDirPath)) {
    fs.mkdirSync(downstreamApiMockDirPath, { recursive: true });
  }

  fs.writeFileSync(downstreamApiMockFilePath, downstreamApiMockTemplate);
}
generateDownstreamMockTemplate(
  downstreamService,
  downstreamApiPath,
  downstreamApiHttpMethod,
)