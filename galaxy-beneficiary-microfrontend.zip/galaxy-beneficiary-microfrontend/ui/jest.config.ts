import type { Config } from 'jest';

const config: Config = {
  displayName: 'ui',
  preset: '../jest.preset.js',
  setupFilesAfterEnv: ['<rootDir>/test-support/setupTests.js'],
  maxWorkers: process.env.CI ? 1 : '50%',
  workerIdleMemoryLimit: '512MB',
  collectCoverageFrom: [
    'src/**/*.{js,jsx,ts,tsx}',
    '!**/index.{js,jsx,ts,tsx}',
    '!**/serviceWorker.js',
    '!**/tools/**',
    '!**/test-support/**',
    '!**/__snapshots__/**',
    '!**/__fixtures__/**',
    '!**/node_modules/**',
    '!**/generated/**',
    '!src/types/**',
    '!**/d.ts',
  ],
  coverageThreshold: {
    global: {
      lines: 75,
      branches: 75,
      functions: 75,
      statements: 75,
    },
  },
  transform: {
    '^(?!.*\\.(js|jsx|ts|tsx|css|json)$)': '@nx/react/plugins/jest',
    '^.+\\.[tj]sx?$': ['babel-jest', { presets: ['@nrwl/react/babel'] }],
  },
  // Updated transformIgnorePatterns to allow transformation of @mesh-tenant-multiverse-ui-common packages and their sub-packages (fixes ESM import errors)
  transformIgnorePatterns: [
    'node_modules/(?!(@westpac/ui|@mesh-tenant-multiverse-common|@mesh-tenant-multiverse-ui-common))',
  ],
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx'],
  coverageDirectory: '../coverage/ui',
  coverageReporters: ['json', 'lcov', 'text', 'html'],
  reporters: [
    'default',
    [
      'jest-junit',
      {
        suiteName: 'jest tests',
        outputDirectory: 'coverage/ui',
        classNameTemplate: '{classname}-{title}',
        titleTemplate: '{classname}-{title}',
        ancestorSeparator: ' › ',
        usePathForSuiteName: 'true',
      },
    ],
  ],
  coveragePathIgnorePatterns: [
    '../src/store/',
    '../src/types',
    '../src/hoc',
    '../src/widgets/',
  ],
};

export default config;
