import crypto from 'crypto';
import '@testing-library/jest-dom';
import { TextDecoder, TextEncoder } from 'util';

global.TextEncoder = TextEncoder;
global.TextDecoder = TextDecoder;

// Setup global object for webpack UMD modules (fixes mv-reacthookform webpack chunk loading error)
// Webpack's UMD wrapper checks for self.webpackChunkmvReacthookform
// Define on multiple possible globals to ensure coverage
global.self = global.self || global;
if (typeof window !== 'undefined') {
  window.self = window.self || window;
  window.self.webpackChunkmvReacthookform =
    window.self.webpackChunkmvReacthookform || [];
}
global.self.webpackChunkmvReacthookform =
  global.self.webpackChunkmvReacthookform || [];
global.webpackChunkmvReacthookform = global.webpackChunkmvReacthookform || [];

Object.defineProperty(global, 'crypto', {
  value: {
    getRandomValues: arr => crypto.randomBytes(arr.length),
  },
});

Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation(query => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(), // deprecated
    removeListener: jest.fn(), // deprecated
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn(),
  })),
});

/* Mock global store */
const { initialiseStore } = require('@mep-ui/framework');

initialiseStore({
  // reducer: {},
  // middlewares: [sagaMiddleware],
  initialState: { global: {} },
});
