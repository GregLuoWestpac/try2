const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const process = require('process');
const { merge } = require('lodash');

// eslint-disable-next-line consistent-return
const readDependencies = () => {
  const { dependencies } = yaml.load(
    fs.readFileSync('../dependencies.yaml', 'utf8')
  );
  return dependencies;
};

const constructMicrofrontendConfig = dependencies => {
  const { microFrontends, widgets } = dependencies;
  const modifiedMicrofrontendsConfig =
    (microFrontends &&
      microFrontends.map((microfrontend, idx) => {
        const { name } = microfrontend;
        const port = 6001 + idx;
        const source = `http://localhost:${port}/remoteEntry.js`;
        return {
          name,
          source,
        };
      })) ||
    [];

  const modifiedWidgetsConfig =
    (widgets &&
      widgets.map((widget, idx) => {
        const { name } = widget;
        const port = 7001 + idx;
        const source = `http://localhost:${port}/remoteEntry.js`;
        return {
          name,
          source,
        };
      })) ||
    [];
  return {
    microfrontends: modifiedMicrofrontendsConfig,
    widgets: modifiedWidgetsConfig,
  };
};

const writeToManifest = microFrontendConfig => {
  const manifestFilePath = path.join(__dirname, '../public/manifest.json');
  try {
    const manifest = JSON.parse(fs.readFileSync(manifestFilePath, 'utf-8'));
    fs.writeFileSync(
      manifestFilePath,
      JSON.stringify(merge(manifest, microFrontendConfig), null, 2),
      'utf-8'
    );
  } catch (e) {
    console.log(e);
    process.exit(1);
  }
};

try {
  const dependencies = readDependencies();
  const microFrontendConfig = constructMicrofrontendConfig(dependencies);
  writeToManifest(microFrontendConfig);
} catch (error) {
  console.error(error);
  process.exit(1);
}
