const fse = require('fs-extra');
const path = require('path');
const ora = require('ora');

// #region Library dependency module path derivations

// Assumption is that this path is always .../packages/example
const currentWorkingDirectory = process.cwd();

// Based on the above assumption, this would be the project's root
const projectRoot = currentWorkingDirectory;

// Library environment folder to bootstrap into the App
const rootEnvDir = path.join(projectRoot, 'env');

// App's root environment folder where the library environment config needs to be bootstrapped
const publicEnvDir = path.join(currentWorkingDirectory, 'public', 'env');

// #endregion

const cp = async (source, destination) => {
  try {
    await fse.copy(source, destination, { overwrite: true });
  } catch (error) {
    console.error(
      `\n\n\u001b[31mError occurred while copying ${source} -> ${destination}\n\n${error}\u001b[0m\n\n`
    );
  }
};

const cpConfig = async (target, source) => {
  try {
    const promisedRemove = fse.remove(target);
    ora.promise(
      promisedRemove,
      `\u001b[33;1mPerforming house-keeping\u001b[0m`
    );
    await promisedRemove;

    const promisedDir = fse.mkdirp(target);
    ora.promise(
      promisedDir,
      `\u001b[33;1mCreating a pristine environment\u001b[0m`
    );
    await promisedDir;

    const promisedEnvironments = fse.readdir(source);
    ora.promise(
      promisedEnvironments,
      `\u001b[33;1mParsing environments for available configurations\u001b[0m\n`
    );
    const subDirs = await promisedEnvironments;

    await Promise.all(
      subDirs
        .filter(dir => dir === 'local' || dir === 'default')
        .map(async dir => {
          try {
            const sourceEnvironment = path.join(source, dir);
            const promisedFiles = fse.readdir(sourceEnvironment);
            ora.promise(
              promisedFiles,
              `\u001b[33;1mReading available configurations for ${dir.toUpperCase()} environment\u001b[0m`
            );
            const files = await promisedFiles;

            await Promise.all(
              files.map(async file => {
                const filePath = path.join(sourceEnvironment, file);
                const promisedStat = fse.stat(filePath);
                ora.promise(
                  promisedStat,
                  `\u001b[33;1mDetecting if the configuration belongs to the SPA or a micro-app\u001b[0m`
                );
                const stat = await promisedStat;

                const isDirectory = stat.isDirectory();

                if (isDirectory) {
                  const targetDir = path.join(target, file);
                  await fse.ensureDir(targetDir);

                  const microAppFiles = await fse.readdir(filePath);
                  await Promise.all(
                    microAppFiles.map(async microAppFile => {
                      const microAppFilePath = path.join(
                        filePath,
                        microAppFile
                      );
                      const relativeTarget = path.relative(
                        projectRoot,
                        targetDir
                      );
                      const promisedCopy = cp(
                        microAppFilePath,
                        path.join(targetDir, microAppFile)
                      );
                      ora.promise(
                        promisedCopy,
                        `\u001b[33;1mCopying micro-app configurations to ${relativeTarget}\u001b[0m`
                      );
                      await promisedCopy;
                    })
                  );
                } else {
                  const relativeTarget = path.relative(projectRoot, target);
                  const promisedCopy = cp(filePath, path.join(target, file));
                  ora.promise(
                    promisedCopy,
                    `\u001b[33;1mCopying the SPA configurations to ${relativeTarget}\u001b[0m`
                  );
                  await promisedCopy;
                }
              })
            );
          } catch (error) {
            const message = `\u001b[31mError occurred while setting up the target environment\n${error.message}\u001b[0m`;
            throw new Error(message);
          }
        })
    );
    console.log(``);
  } catch (error) {
    const message = `\u001b[31mError occurred while bootstrapping Micro-app configurations\n${error.message}\u001b[0m`;
    throw new Error(message);
  }
};

(async () => {
  const promise = cpConfig(publicEnvDir, rootEnvDir);
  ora.promise(
    promise,
    `\u001b[33;1mLocal environment setup complete!\u001b[0m`
  );
  await promise;

  console.log(``);
})();