const CopyWebpackPlugin = require('copy-webpack-plugin');

const ENV_DEVELOP_BUILD_REGEX = /^REACT_APP_|NX_/i;
const ENV_PROD_BUILD_REGEX = /^REACT_APP_/i;

const isDevelopment = () => {
  return process.env.NODE_ENV === 'development';
};

function createCopyPlugin(assets) {
  return new CopyWebpackPlugin({
    patterns: assets.map(asset => {
      const assetIgnore = Array.isArray(asset.ignore) ? asset.ignore : [];
      return {
        context: asset.input,
        // Now we remove starting slash to make Webpack place it from the output root.
        to: asset.output,
        from: asset.glob,
        globOptions: {
          dot: true,
          gitignore: true,
          ignore: ['.gitkeep', '**/.DS_Store', '**/Thumbs.db', ...assetIgnore],
        },
      };
    }),
  });
}

function getClientEnvironment(environment) {
  const raw = Object.keys(process.env)
    .filter(key =>
      environment === 'development'
        ? ENV_DEVELOP_BUILD_REGEX.test(key)
        : ENV_PROD_BUILD_REGEX.test(key)
    )
    .reduce(
      (env, key) => {
        // eslint-disable-next-line no-param-reassign
        env[key] = process.env[key];
        return env;
      },
      {
        // Useful for determining whether we’re running in production mode.
        // Most importantly, it switches React into the correct mode.
        NODE_ENV: process.env.NODE_ENV || 'development',
        // Useful for resolving the correct path to static assets in `public`.
        // For example, <img src={process.env.PUBLIC_URL + '/img/logo.png'} />.
        // This should only be used as an escape hatch. Normally you would put
        // images into the `src` and `import` them in code to get their paths.
      }
    );
  // Stringify all values so we can feed into Webpack DefinePlugin
  const stringified = {
    'process.env': Object.keys(raw).reduce((env, key) => {
      // eslint-disable-next-line no-param-reassign
      env[key] = JSON.stringify(raw[key]);
      return env;
    }, {}),
  };

  return { raw, stringified };
}

module.exports = {
  createCopyPlugin,
  getClientEnvironment,
  isDevelopment,
};