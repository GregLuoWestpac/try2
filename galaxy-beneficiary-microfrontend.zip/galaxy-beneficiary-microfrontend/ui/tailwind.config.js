import { withGEL } from '@westpac/ui/tailwind';

const { join } = require('path');

/** @type {import('tailwindcss').Config} */
const config = withGEL({
  content: [
    join(__dirname, './src/**/*.{js,ts,jsx,tsx,mdx}'),
    join(__dirname, './node_modules/@westpac/ui/src/**/*.{js,ts,jsx,tsx,mdx}'),
    // Also pick up any CSS/JS/MDX from the mv-common packages in different
    // node_modules locations so Tailwind can see utility classes when the
    // package is installed at the UI level, at the monorepo root, or when
    // packages are linked in the workspace.
    join(
      __dirname,
      './node_modules/@mesh-tenant-multiverse-ui-common/**/*.{js,ts,jsx,tsx,mdx,css}'
    ),
    join(
      __dirname,
      '../node_modules/@mesh-tenant-multiverse-ui-common/**/*.{js,ts,jsx,tsx,mdx,css}'
    ),
  ],
  options: {
    brandFonts: {
      src: '/fonts',
      /** takes a single brand string e.g. 'wbc' or an array of brands.
    If no brands are specified will import all brands by default */
      brands: ['wbc'],
    },
  },
  plugins: [
    function ({ addUtilities }) {
      addUtilities({
        '.include-archived-beneficiaries .leading-loose': {
          display: 'none !important',
        },
        '.include-archived-beneficiaries .flex': {
          display: 'flex !important',
        },
        '.include-archived-beneficiaries .mb-1': {
          'margin-bottom': 0,
        },
        '.include-archived-beneficiaries .label-h1-include-archived-beneficiaries':
          {
            display: 'none',
          },
      });
    },
  ],
});

export default config;
