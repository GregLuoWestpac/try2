const webpack = require('webpack');

const { withReact } = require('@nx/react');
const { withNx, composePlugins } = require('@nx/webpack');
// const withModuleFederation = require('@nx/react/module-federation');

const HtmlWebpackPlugin = require('html-webpack-plugin');
const NodePolyfillPlugin = require('node-polyfill-webpack-plugin');
const InterpolateHtmlPlugin = require('react-dev-utils/InterpolateHtmlPlugin');

const { ModuleFederationPlugin } = webpack.container;

const { getClientEnvironment } = require('./tools/buildUtils');
const moduleFederationConfig = require('./modulefederation.config');

// console.log(`moduleFederationConfig`, moduleFederationConfig);

module.exports = composePlugins(
  withNx(),
  withReact(),
  // withModuleFederation(moduleFederationConfig),
  async config => {
    const configuration = process.env.NODE_ENV || 'production';
    const env = getClientEnvironment(configuration);

    const terserPlugin = config.optimization.minimizer.find(
      plugin =>
        plugin.constructor.name === 'TerserPlugin' ||
        plugin instanceof TerserPlugin
    );

    terserPlugin.options.minimizer.options.format.comments = /MFE/i;

    config.module.rules =
      config?.module?.rules?.map(rule => {
        if (/file-loader/.test(rule.loader)) {
          return {
            ...rule,
            type: 'javascript/auto', // This is fixing issue https://webpack.js.org/guides/asset-modules/
          };
        }

        return rule;
      }) || [];

    /* To process mp4 files */
    config.module.rules.push({
      test: /\.mp4$/,
      use: ['file-loader'],
    });

    const plugins = [
      // Makes some environment variables available to the JS code, for example:
      // if (process.env.NODE_ENV === 'production') { ... }. See `./env.js`.
      // Sets certain variables prefixed with REACT_APP_ or NX_
      new webpack.DefinePlugin(env.stringified),
      ...config.plugins.filter(
        plugin => !(plugin instanceof webpack.DefinePlugin)
      ),
      new webpack.BannerPlugin({
        banner: `MFE ${process.env.REACT_APP_NAME} Build number is: ${process.env.BUILD_NUMBER}`,
      }),
      new NodePolyfillPlugin({
        excludeAliases: ['console'],
      }),
      new ModuleFederationPlugin(moduleFederationConfig),
    ];

    if (configuration !== 'development') {
      plugins.push(
        new HtmlWebpackPlugin({
          inject: true,
          template: './public/index.html',
          minify: {
            removeComments: true,
            collapseWhitespace: true,
            removeRedundantAttributes: true,
            useShortDoctype: true,
            removeEmptyAttributes: true,
            removeStyleLinkTypeAttributes: true,
            keepClosingSlash: true,
            minifyJS: true,
            minifyCSS: true,
            minifyURLs: true,
          },
        }),
        new InterpolateHtmlPlugin(HtmlWebpackPlugin, env.raw)
      );
    }

    return {
      ...config,
      devServer: {
        ...config.devServer,
        devMiddleware: {
          writeToDisk: true,
          publicPath: '/',
          stats: false,
        },
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': '*',
          'Access-Control-Allow-Methods': 'GET, OPTIONS',
        },
        client: {
          overlay: {
            errors: true,
            warnings: false,
          },
          logging: 'info',
          progress: true,
        },
      },
      optimization: {
        minimizer: config.optimization.minimizer,
        removeEmptyChunks: true,
        mergeDuplicateChunks: true,
        splitChunks: {
          chunks: 'async',
        },
      },
      output: {
        ...config.output,
        publicPath: 'auto',
        uniqueName: `galaxy_beneficiary`,
        scriptType: 'text/javascript',
      },
      resolve: {
        mainFields: ['browser', 'module', 'main'],
        extensions: ['.js', '.jsx', '.ts', '.tsx', '.json'],
      },
      node: { global: true },
      plugins,
    };
  }
);