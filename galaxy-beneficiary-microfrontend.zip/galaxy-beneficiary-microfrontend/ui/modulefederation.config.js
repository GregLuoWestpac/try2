const path = require('path');
const manifest = require('./public/manifest.json');
const constructRemotes = require('./tools/constructRemotes');
const { dependencies } = require('./package.json');

module.exports = {
  name: 'galaxy_beneficiary',
  filename: 'remoteEntry.js', // remoteEntry.js
  remotes: constructRemotes(manifest),
  exposes: {
    './pages': path.join(__dirname, './src/index.js'),
  },
  shared: {
    '@mep-ui/framework': {
      import: false,
      singleton: true,
    },
    'styled-components': {
      import: false,
      singleton: true,
    },
    react: {
      import: false,
      singleton: true,
    },
    'react-dom': {
      import: false,
      singleton: true,
    },
    'react-router-dom': {
      import: false,
      singleton: true,
    },
    '@mep-ui/framework-router-addon': {
      import: false,
      singleton: true,
      requiredVersion: dependencies['@mep-ui/framework-router-addon'],
    },
    '@mesh-tenant-multiverse-ui-common/mv-utils': {
      import: false,
      singleton: true,
      requiredVersion:
        dependencies['@mesh-tenant-multiverse-ui-common/mv-utils'],
    },
    '@mesh-tenant-multiverse-ui-common/mv-pageloader': {
      import: false,
      singleton: true,
      requiredVersion:
        dependencies['@mesh-tenant-multiverse-ui-common/mv-pageloader'],
    },
    '@mesh-tenant-multiverse-ui-common/mv-card': {
      import: false,
      singleton: true,
      requiredVersion:
        dependencies['@mesh-tenant-multiverse-ui-common/mv-card'],
    },
    '@westpac/ui': {
      import: false,
      singleton: true,
      requiredVersion: dependencies['@westpac/ui'],
    },
    '@mesh-tenant-multiverse-common/react': {
      import: false,
      singleton: true,
      requiredVersion: dependencies['@mesh-tenant-multiverse-common/react'],
    },
  },
};
