import React from 'react';
import {
  AsyncDefault,
  AsyncHome,
  AsyncError,
  AsyncAddBeneficiaries,
  AsyncBeneficiaryDetails,
  AsyncUpdateBeneficiary,
  AsyncBeneficiaryTask,
  AsyncBeneficiaryActivities,
} from './layouts';
/**
 * The routes exported are stitched together
 * in the RouteRegistry of the master SPA
 * along-with the other micro apps
 *
 * NOTE:
 * - The top level route if exposing nested routes MUST not have the `exact` property defined
 * - The top level route if exposing nested routes MUST not have the `element` property defined
 * - Instead the top level `routes` array used to define the nested routes MUST define the top-level route first
 *   along-with the `element` property and optionally the `exact` property if so desired
 *
 * [Reference route config](https://reactrouter.com/web/example/route-config)
 * [Reference exact prop](https://reactrouter.com/web/api/Route/exact-bool)
 */
export const pages = [
  {
    id: 'pages.galaxy.beneficiary.home',
    path: '/beneficiary/*',
    isPublic: true, // change to true for local testing / test without any role based access
    name: 'Galaxy-Beneficiary',
    title: 'Beneficiaries',
    element: <AsyncDefault />,
    /*
    // sample query params definition for route validation
    queryParams: {
      test: {
        required: true,
        pattern: /^\w{1,4}/,
        maxLength: 4
      },
    },
    */
    children: [
      {
        id: 'pages.galaxy.beneficiary.homepage',
        index: true,
        isPublic: true, // change to true for local testing / test without any role based access
        name: 'Beneficiaries',
        title: 'Beneficiaries',
        element: <AsyncHome />,
        /*
        // sample query params definition for route validation
        queryParams: {
          test: {
            required: true,
            pattern: /^\w{1,4}/,
            maxLength: 4
          },
        },
        */
      },
      {
        id: 'pages.galaxy.beneficiary.updatebeneficiary',
        path: 'update-beneficiary',
        title: 'Update beneficiary',
        isPublic: true,
        name: 'Update beneficiary | Westpac One',
        element: <AsyncUpdateBeneficiary />,
        exact: true,
      },
      {
        id: 'pages.galaxy.beneficiary.beneficiarydetails',
        path: 'view-beneficiary',
        title: 'Beneficiary details',
        isPublic: true,
        name: 'Beneficiary details',
        element: <AsyncBeneficiaryDetails />,
        exact: true,
      },
      {
        id: 'pages.galaxy.beneficiary.beneficiarytask',
        path: 'beneficiary-task-details',
        title: 'Beneficiary details',
        isPublic: true,
        name: 'Beneficiary details | Westpac One',
        element: <AsyncBeneficiaryTask />,
        exact: true,
      },
      {
        id: 'pages.galaxy.beneficiary.createbeneficiary',
        path: 'create-beneficiary',
        isPublic: true,
        name: 'Add a beneficiary | Westpac One',
        title: 'Add a beneficiary',
        element: <AsyncAddBeneficiaries />,
        exact: true,
      },
      {
        id: 'pages.galaxy.beneficiary.beneficiaryactivitydetails',
        path: 'beneficiary-activity-details',
        isPublic: true,
        name: 'Beneficiary activity details | Westpac One',
        title: 'Beneficiary activity details',
        element: <AsyncBeneficiaryActivities />,
        exact: true,
      },
      {
        id: 'pages.galaxy.beneficiary.error',
        name: 'Galaxy-Beneficiary - Error',
        path: '*',
        isPublic: true,
        element: <AsyncError />,
      },
    ],
  },
];

export default pages;
