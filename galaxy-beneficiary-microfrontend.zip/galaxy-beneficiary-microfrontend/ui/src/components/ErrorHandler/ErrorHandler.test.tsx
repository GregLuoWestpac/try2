import '@testing-library/jest-dom';
import { fireEvent, render, screen } from '@testing-library/react';
import React from 'react';
import ErrorHandler from './ErrorHandler';

jest.mock('@westpac/ui', () => ({
  Alert: ({ children, ...props }: any) => (
    <div data-testid="alert" {...props}>
      {children}
    </div>
  ),
  Button: ({ children, onClick, ...props }: any) => (
    <button data-testid="try-again-link" onClick={onClick} {...props}>
      {children}
    </button>
  ),
  Grid: ({ children }: any) => <div>{children}</div>,
  GridItem: ({ children }: any) => <div>{children}</div>,
}));

describe('ErrorHandler', () => {
  const mockOnRefresh = jest.fn();
  it('renders the error message', () => {
    const { getByText } = render(
      <ErrorHandler
        onRefresh={mockOnRefresh}
        errorMessage="Something went wrong."
      />
    );
    const errorMessage = getByText((content, element) => {
      return content.includes('Something went wrong.');
    });
    expect(errorMessage).toBeInTheDocument();
  });

  it('renders the try again link', () => {
    render(
      <ErrorHandler
        onRefresh={mockOnRefresh}
        errorMessage="Something went wrong."
      />
    );
    const linkElement = screen.getByText('try again');
    expect(linkElement).toBeInTheDocument();
    fireEvent.click(linkElement);
    expect(mockOnRefresh).toHaveBeenCalled();
  });

  it('should not render the retry button when shouldRetry is false', () => {
    render(
      <ErrorHandler errorMessage="Something went wrong." shouldRetry={false} />
    );
    expect(screen.queryByTestId('try-again-link')).not.toBeInTheDocument();
  });

  it('should not render the retry button when onRefresh is not provided', () => {
    render(
      <ErrorHandler errorMessage="Something went wrong." shouldRetry={true} />
    );
    expect(screen.queryByTestId('try-again-link')).not.toBeInTheDocument();
  });
});
