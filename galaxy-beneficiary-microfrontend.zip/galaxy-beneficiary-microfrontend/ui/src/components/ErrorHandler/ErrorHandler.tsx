/* eslint-disable jsx-a11y/anchor-is-valid */
import { Alert, Button, Grid, GridItem } from '@westpac/ui';
import React from 'react';

export type ErrorHandlerPropType = {
  onRefresh?: () => void;
  errorMessage: string;
  mode?: 'box' | 'text';
  iconSize?: 'small' | 'xlarge' | 'medium' | 'large' | 'xsmall';
  width?: 'half' | 'full';
  shouldRetry?: boolean;
  className?: string;
};

export default function ErrorHandler({
  onRefresh,
  errorMessage,
  mode = 'box',
  iconSize = 'small',
  width = 'half',
  shouldRetry = true,
  className = '',
}: ErrorHandlerPropType) {
  const alertGridClassName = width === 'half' ? 'mb-0 w-1/2' : 'mb-0 w-full';
  return (
    <Grid className="flex justify-center">
      <GridItem className={alertGridClassName}>
        <Alert
          look="danger"
          id="errorMessage"
          className={className}
          iconSize={iconSize}
          mode={mode}
        >
          {shouldRetry && onRefresh ? (
            <>
              {`${errorMessage} Please `}
              <Button
                data-testid="try-again-link"
                className="text-danger p-0 typography-body-11 h-0"
                look="link"
                soft
                onClick={onRefresh}
              >
                try again
              </Button>
              .
            </>
          ) : (
            <>{errorMessage}</>
          )}
        </Alert>
      </GridItem>
    </Grid>
  );
}
