import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import BeneficiaryTaskRejectModal from './BeneficiaryTaskRejectModal';

jest.mock('@westpac/ui', () => ({
  Modal: ({ title, state, children }: any) => {
    if (!state?.isOpen) return null;
    return (
      <div role="dialog">
        <div>{title}</div>
        {children}
      </div>
    );
  },
  ModalBody: ({ children }: any) => <div>{children}</div>,
  InputGroup: ({
    label,
    hint,
    supportingText,
    errorMessage,
    children,
  }: any) => (
    <div>
      <div>{label}</div>
      {children}
      {hint ? <div>{hint}</div> : null}
      {supportingText ? <div>{supportingText}</div> : null}
      {errorMessage ? <div>{errorMessage}</div> : null}
    </div>
  ),
  Textarea: (props: any) => <textarea {...props} />,
  Button: ({ children, onClick, ...props }: any) => (
    <button onClick={onClick} {...props}>
      {children}
    </button>
  ),
}));

describe('BeneficiaryTaskRejectModal', () => {
  const mockRejectRequest = jest.fn();

  beforeEach(() => {
    mockRejectRequest.mockClear();
  });

  const TestWrapper = () => {
    const [isOpen, setIsOpen] = React.useState(true);
    const state = React.useMemo(
      () => ({
        isOpen,
        setOpen: (open: boolean) => setIsOpen(open),
        open: () => setIsOpen(true),
        close: () => setIsOpen(false),
        toggle: () => setIsOpen(prev => !prev),
      }),
      [isOpen]
    ) as any;

    return (
      <div>
        <button type="button" onClick={() => state.setOpen(true)}>
          Open modal
        </button>
        <BeneficiaryTaskRejectModal
          state={state}
          rejectRequest={mockRejectRequest}
        />
      </div>
    );
  };

  it('renders title and comments field', () => {
    render(<TestWrapper />);

    expect(screen.getByText('Reject request?')).toBeInTheDocument();
    expect(screen.getByText('Comments')).toBeInTheDocument();
    expect(
      screen.getByText(/You can provide a reason for your decision\./i)
    ).toBeInTheDocument();
    expect(screen.getByText('300 remaining')).toBeInTheDocument();

    const textarea = screen.getByLabelText('Comments');
    expect(textarea).toHaveAttribute('maxLength', '300');
  });

  it('updates remaining counter as the user types', async () => {
    const user = userEvent.setup();

    render(<TestWrapper />);

    await user.type(screen.getByLabelText('Comments'), 'Hello');

    expect(screen.getByText('295 remaining')).toBeInTheDocument();
  });

  it('closes when Cancel is clicked', async () => {
    const user = userEvent.setup();

    render(<TestWrapper />);

    await user.click(screen.getByRole('button', { name: 'Cancel' }));

    expect(screen.queryByText('Reject request?')).not.toBeInTheDocument();
  });

  it('calls mockRejectRequest with the comment and closes when Reject is clicked', async () => {
    const user = userEvent.setup();

    render(<TestWrapper />);

    await user.type(screen.getByLabelText('Comments'), 'Not compliant');
    expect(screen.getByRole('button', { name: 'Reject' })).toBeEnabled();
    await user.click(screen.getByRole('button', { name: 'Reject' }));

    expect(mockRejectRequest).toHaveBeenCalledWith('Not compliant');
    expect(screen.queryByText('Reject request?')).not.toBeInTheDocument();
  });

  it('clears the textarea when modal is closed and reopened', async () => {
    const user = userEvent.setup();
    render(<TestWrapper />);

    const textarea = screen.getByLabelText('Comments');
    await user.type(textarea, 'Some reason');
    expect(screen.getByDisplayValue('Some reason')).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(screen.queryByText('Reject request?')).not.toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Open modal' }));
    expect(screen.getByText('Reject request?')).toBeInTheDocument();
    expect(screen.getByLabelText('Comments')).toHaveValue('');
    expect(screen.getByText('300 remaining')).toBeInTheDocument();
  });

  it('shows validation error for invalid characters', async () => {
    const user = userEvent.setup();
    render(<TestWrapper />);

    const textarea = screen.getByLabelText('Comments');
    await user.type(textarea, 'Invalid character #');
    await user.tab(); // Trigger onBlur

    expect(
      screen.getByText(
        /Use only letters, numbers, spaces, or the following special characters/i
      )
    ).toBeInTheDocument();
  });

  it('does not show validation error for valid characters', async () => {
    const user = userEvent.setup();
    render(<TestWrapper />);

    const textarea = screen.getByLabelText('Comments');
    await user.type(textarea, 'Valid comment with -!,.:;?_@');
    await user.tab(); // Trigger onBlur

    expect(
      screen.queryByText(
        /Use only letters, numbers, spaces, or the following special characters/i
      )
    ).not.toBeInTheDocument();
  });

  it('does not call rejectRequest when validation fails', async () => {
    const user = userEvent.setup();
    render(<TestWrapper />);

    const textarea = screen.getByLabelText('Comments');
    await user.type(textarea, 'Invalid #$%');
    await user.tab(); // Trigger onBlur

    await user.click(screen.getByRole('button', { name: 'Reject' }));

    expect(mockRejectRequest).not.toHaveBeenCalled();
    expect(screen.getByText('Reject request?')).toBeInTheDocument();
  });

  it('allows rejection with empty comment', async () => {
    const user = userEvent.setup();
    render(<TestWrapper />);

    await user.click(screen.getByRole('button', { name: 'Reject' }));

    expect(mockRejectRequest).toHaveBeenCalledWith('');
    expect(screen.queryByText('Reject request?')).not.toBeInTheDocument();
  });

  it('clears validation error when modal is closed', async () => {
    const user = userEvent.setup();
    render(<TestWrapper />);

    const textarea = screen.getByLabelText('Comments');
    await user.type(textarea, 'Invalid #');
    await user.tab();

    expect(
      screen.getByText(
        /Use only letters, numbers, spaces, or the following special characters/i
      )
    ).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Cancel' }));
    await user.click(screen.getByRole('button', { name: 'Open modal' }));

    expect(
      screen.queryByText(
        /Use only letters, numbers, spaces, or the following special characters/i
      )
    ).not.toBeInTheDocument();
  });

  it('re-validates when user corrects invalid input', async () => {
    const user = userEvent.setup();
    render(<TestWrapper />);

    const textarea = screen.getByLabelText('Comments');
    await user.type(textarea, 'Invalid #');
    await user.tab();

    expect(
      screen.getByText(
        /Use only letters, numbers, spaces, or the following special characters/i
      )
    ).toBeInTheDocument();

    await user.clear(textarea);
    await user.type(textarea, 'Valid comment');
    await user.tab();

    expect(
      screen.queryByText(
        /Use only letters, numbers, spaces, or the following special characters/i
      )
    ).not.toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Reject' }));
    expect(mockRejectRequest).toHaveBeenCalledWith('Valid comment');
  });
});
