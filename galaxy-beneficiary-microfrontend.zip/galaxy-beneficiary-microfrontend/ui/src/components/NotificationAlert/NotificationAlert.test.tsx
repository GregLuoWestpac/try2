import React from 'react';
import { render } from '@testing-library/react';
import { useGlobalSelector } from '@mep-ui/framework';
import { Alert } from '@westpac/ui';
import NotificationAlert, {
  getErrorMessage,
  getNotificationMessage,
} from './NotificationAlert';
import { createErrorMessageForAuthorisation } from './NotificationAlert';
import { NotificationMessage } from './NotificationAlert.type';

jest.mock('@mep-ui/framework', () => ({
  useGlobalSelector: jest.fn(),
}));

jest.mock('@westpac/ui', () => ({
  Alert: jest.fn(({ children }) => <div>{children}</div>),
}));

describe('NotificationAlert', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('renders nothing when there is no message', () => {
    (useGlobalSelector as jest.Mock).mockReturnValue({
      type: 'info',
      message: '',
    });

    const { container } = render(<NotificationAlert />);
    expect(container.firstChild).toBeNull();
  });

  it('renders an Alert with the correct props when there is a message', () => {
    const mockMessage = 'Test message';
    const mockType = 'success';
    (useGlobalSelector as jest.Mock).mockReturnValue({
      type: mockType,
      message: mockMessage,
    });

    const { getByText } = render(<NotificationAlert />);
    expect(getByText(mockMessage)).toBeInTheDocument();
    expect(Alert).toHaveBeenCalledWith(
      expect.objectContaining({
        look: mockType,
        id: `${mockType}Message`,
        className: 'mb-0 mt-2.5',
        iconSize: 'small',
        mode: 'box',
      }),
      {}
    );
  });

  it('renders a default Alert when useGlobalSelector returns null', () => {
    (useGlobalSelector as jest.Mock).mockReturnValue(null);

    const { container } = render(<NotificationAlert />);
    expect(container.firstChild).toBeNull();
  });

  it('renders a default Alert when useGlobalSelector returns undefined', () => {
    (useGlobalSelector as jest.Mock).mockReturnValue(undefined);

    const { container } = render(<NotificationAlert />);
    expect(container.firstChild).toBeNull();
  });
});

describe('getErrorMessage', () => {
  it('returns the correct message for 403 status with code 8210', () => {
    const errors = {
      status: 403,
      data: {
        errors: [{ code: 8210, message: 'Permission denied' }],
      },
    };
    const errorFor = 'add or update beneficiaries';
    const result = getErrorMessage(errors, errorFor);
    expect(result).toBe(
      'You do not have permission to add or update beneficiaries. Contact your administrator for more information.'
    );
  });

  it('returns a generic message for 403 status without code 8210', () => {
    const errors = {
      status: 403,
      data: {
        errors: [{ code: 1234, message: 'Error occurred' }],
      },
    };
    const errorFor = 'add or update beneficiaries';
    const result = getErrorMessage(errors, errorFor);
    expect(result).toBe('Something went wrong. Please try again later.');
  });

  it('returns a server error message for 500 status', () => {
    const errors = {
      status: 500,
      data: {
        errors: [{ code: 9999, message: 'Internal Server Error' }],
      },
    };
    const errorFor = 'add';
    const result = getErrorMessage(errors, errorFor);
    expect(result).toBe('Something went wrong. Please try again later.');
  });

  it('returns a server error message for 503 status', () => {
    const errors = {
      status: 503,
      data: {
        errors: [{ code: 9999, message: 'Service Unavailable' }],
      },
    };
    const errorFor = 'add';
    const result = getErrorMessage(errors, errorFor);
    expect(result).toBe('Something went wrong. Please try again later.');
  });

  it('returns a default error message for 400 status', () => {
    const errors = {
      status: 400,
      data: {
        errors: [{ code: 9999, message: 'Bad Request' }],
      },
    };
    const errorFor = 'add';
    const result = getErrorMessage(errors, errorFor);
    expect(result).toBe('Something went wrong. Please try again.');
  });

  it('returns a default error message when errors are undefined', () => {
    const result = getErrorMessage(undefined as any, 'add');
    expect(result).toBe('Something went wrong. Please try again.');
  });

  it('returns a default error message when errors have no status', () => {
    const errors = {
      data: {
        errors: [{ code: 9999, message: 'No status error' }],
      },
    } as any;
    const result = getErrorMessage(errors, 'add');
    expect(result).toBe('Something went wrong. Please try again.');
  });

  it('returns a default error message when errors data is null', () => {
    const errors = {
      status: 400,
      data: null,
    } as any;
    const result = getErrorMessage(errors, 'add');
    expect(result).toBe('Something went wrong. Please try again.');
  });
});

describe('createErrorMessageForAuthorisation', () => {
  const errorMessageListForAuthoriseBenReq = {
    ACTION_RESTRICTED:
      'You do not have permisson to authorise or reject the beneficiary',
    ACTION_RESTRICTED_UPDATE:
      'You do not have permisson to authorise or reject the update to the beneficiary',
    UNREACHABLE: 'Something went wrong. Please try again.',
  };

  const mockErrorResponse = (
    status: number,
    code: number,
    details?: string
  ) => ({
    status,
    data: {
      errors: [
        {
          code,
          details:
            details || JSON.stringify({ result: { errors: [{ code: 1007 }] } }),
        },
      ],
    },
  });

  // Tests for authorise_add action
  it('should return the correct message for authorise_add with already authorised/rejected error', () => {
    const errorResponse = mockErrorResponse(
      400,
      8135,
      JSON.stringify({ data: { errors: [{ code: 1007 }] } })
    );
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_add',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Unable to authorise the beneficiary John Doe. This beneficiary already authorised or rejected.'
    );
  });

  it('should return the correct message for authorise_add with 400/8135 error (fallback)', () => {
    const errorResponse = mockErrorResponse(400, 8135, '{}');
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_add',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Unable to authorise the beneficiary John Doe. Please try again later.'
    );
  });

  it('should return the correct message for authorise_add with 400/8140 error', () => {
    const errorResponse = mockErrorResponse(400, 8140);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_add',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Beneficiary $John Doe could not be added. Please contact the initiator to add the beneficiary again.'
    );
  });

  it('should return the correct message for authorise_add with 500/8135 error', () => {
    const errorResponse = mockErrorResponse(500, 8135);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_add',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Unable to authorise the beneficiary John Doe. Please try again later.'
    );
  });

  it('should return the correct message for authorise_add with 500/8140 error', () => {
    const errorResponse = mockErrorResponse(500, 8140);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_add',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Beneficiary $John Doe could not be added. Please contact the initiator to add the beneficiary again.'
    );
  });

  it('should return the correct message for authorise_add with 403/8210 error', () => {
    const errorResponse = mockErrorResponse(403, 8210);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_add',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'You do not have permisson to authorise or reject the beneficiary John Doe. Please contact your administrator for more information.'
    );
  });

  it('should return the default message for authorise_add with other errors', () => {
    const errorResponse = mockErrorResponse(422, 9999);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_add',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Unable to authorise the beneficiary John Doe. Please try again later.'
    );
  });

  // Tests for authorise_update action
  it('should return the correct message for authorise_update with already authorised/rejected error', () => {
    const errorResponse = mockErrorResponse(
      400,
      8135,
      JSON.stringify({ data: { errors: [{ code: 1007 }] } })
    );
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_update',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Enable to authorise the beneficiary John Doe. The update is already authorised or rejected.'
    );
  });

  it('should return the correct message for authorise_update with 400/8135 error (fallback)', () => {
    const errorResponse = mockErrorResponse(400, 8135, '{}');
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_update',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Unable to authorise the update to the beneficiary John Doe. Please try again later.'
    );
  });

  it('should return the correct message for authorise_update with 400/8140 error', () => {
    const errorResponse = mockErrorResponse(400, 8140);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_update',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Beneficiary $John Doe could not be updated. Please contact the initiator to add the beneficiary again.'
    );
  });

  it('should return the correct message for authorise_update with 500/8135 error', () => {
    const errorResponse = mockErrorResponse(500, 8135);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_update',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Unable to authorise the update to the beneficiary John Doe. Please try again later.'
    );
  });

  it('should return the correct message for authorise_update with 500/8140 error', () => {
    const errorResponse = mockErrorResponse(500, 8140);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_update',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Beneficiary $John Doe could not be updated. Please contact the initiator to add the beneficiary again.'
    );
  });

  it('should return the correct message for authorise_update with 403/8210 error', () => {
    const errorResponse = mockErrorResponse(403, 8210);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_update',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'You do not have permisson to authorise or reject the update to the beneficiary John Doe. Please contact your administrator for more information.'
    );
  });

  it('should return the default message for authorise_update with other errors', () => {
    const errorResponse = mockErrorResponse(422, 9999);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_update',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Unable to authorise the update to the beneficiary John Doe. Please try again later.'
    );
  });

  // Tests for authorise_archive action
  it('should return the correct message for authorise_archive with already authorised/rejected error', () => {
    const errorResponse = mockErrorResponse(
      400,
      8135,
      JSON.stringify({ data: { errors: [{ code: 1007 }] } })
    );
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_archive',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Unable to athorise archiving of the beneficiary John Doe. This archiving already authorised or rejected.'
    );
  });

  it('should return the correct message for authorise_archive with 400/8135 error (fallback)', () => {
    const errorResponse = mockErrorResponse(400, 8135, '{}');
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_archive',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Unable to authorise the archiving of the beneficiary John Doe. Please try again later.'
    );
  });

  it('should return the correct message for authorise_archive with 400/8140 error', () => {
    const errorResponse = mockErrorResponse(400, 8140);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_archive',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Beneficiary John Doe could not be archived. Contact the initiator to archive the beneficiary again.'
    );
  });

  it('should return the correct message for authorise_archive with 500/8135 error', () => {
    const errorResponse = mockErrorResponse(500, 8135);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_archive',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Unable to authorise the archiving of the beneficiary John Doe. Please try again later.'
    );
  });

  it('should return the correct message for authorise_archive with 500/8140 error', () => {
    const errorResponse = mockErrorResponse(500, 8140);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_archive',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Beneficiary John Doe could not be archived. Contact the initiator to archive the beneficiary again.'
    );
  });

  it('should return the correct message for authorise_archive with 403/8210 error', () => {
    const errorResponse = mockErrorResponse(403, 8210);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_archive',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'You do not have permisson to authorise or reject the beneficiary John Doe. Please contact your administrator for more information.'
    );
  });

  it('should return the default message for authorise_archive with other errors', () => {
    const errorResponse = mockErrorResponse(422, 9999);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_archive',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Unable to authorise the archiving of the beneficiary John Doe. Please try again later.'
    );
  });

  // Edge cases
  it('should handle malformed JSON in error details gracefully', () => {
    const errorResponse = {
      status: 400,
      data: {
        errors: [
          {
            code: 8135,
            details: 'invalid json{',
          },
        ],
      },
    };
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_add',
        'John Doe',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Unable to authorise the beneficiary John Doe. Please try again later.'
    );
  });

  it('should return the unreachable error message for unknown action', () => {
    const errorResponse = mockErrorResponse(500, 9999);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'unknown_action',
        'John Doe',
        errorResponse,
        'unknown'
      )
    );
    expect(container.textContent).toContain(
      errorMessageListForAuthoriseBenReq.UNREACHABLE
    );
  });

  it('should return the correct message for authorise_add with missing beneficiary name', () => {
    const errorResponse = mockErrorResponse(400, 8135);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'authorise_add',
        '',
        errorResponse,
        'authorise'
      )
    );
    expect(container.textContent).toContain(
      'Unable to authorise the beneficiary . Please try again later.'
    );
  });
  it('should return the unreachable error message for unsupported action type', () => {
    const errorResponse = mockErrorResponse(500, 9999);
    const { container } = render(
      createErrorMessageForAuthorisation(
        'unsupported_action',
        'John Doe',
        errorResponse,
        'unsupported'
      )
    );
    expect(container.textContent).toContain(
      errorMessageListForAuthoriseBenReq.UNREACHABLE
    );
  });
});

describe('getNotificationMessage', () => {
  it('returns the message when it is a string', () => {
    const message = 'Test notification message';
    const result = getNotificationMessage(message);
    expect(result).toBe(message);
  });

  it('returns error message when message object has no nickname', () => {
    const message: NotificationMessage = {
      nickname: '',
      action: 'add',
    };
    const result = getNotificationMessage(message);
    expect(result).toBe('Something went wrong. Please try again.');
  });

  it('returns error message when message object has no action', () => {
    const result = getNotificationMessage({
      nickname: 'John Doe',
    } as NotificationMessage);
    expect(result).toBe('Something went wrong. Please try again.');
  });

  // Archive action tests
  it('returns the authorisation JSX for archive action with isMakerCheckerApplicable true', () => {
    const message: NotificationMessage = {
      nickname: 'John Doe',
      action: 'archive',
      isMakerCheckerApplicable: true,
    };
    const result = getNotificationMessage(message);
    const { container } = render(<>{result}</>);
    expect(container.innerHTML).toContain(
      'Archive request for the beneficiary <strong>John Doe</strong> has been sent for authorisation.'
    );
  });

  it('returns the archive JSX for archive action with isMakerCheckerApplicable false', () => {
    const message: NotificationMessage = {
      nickname: 'John Doe',
      action: 'archive',
      isMakerCheckerApplicable: false,
    };
    const result = getNotificationMessage(message);
    const { container } = render(<>{result}</>);
    expect(container.innerHTML).toContain(
      'The beneficiary <strong>John Doe</strong> has been archived.'
    );
  });

  // Add action tests
  it('returns the beneficiary added JSX for add action with isMakerCheckerApplicable true', () => {
    const message: NotificationMessage = {
      nickname: 'Jane Doe',
      action: 'add',
      isMakerCheckerApplicable: true,
    };
    const result = getNotificationMessage(message);
    const { container } = render(<>{result}</>);
    expect(container.innerHTML).toContain(
      'The beneficiary <strong>Jane Doe</strong> has been sent for authorisation.'
    );
  });

  it('returns the beneficiary added JSX for add action with isMakerCheckerApplicable false', () => {
    const message: NotificationMessage = {
      nickname: 'Jane Doe',
      action: 'add',
      isMakerCheckerApplicable: false,
    };
    const result = getNotificationMessage(message);
    const { container } = render(<>{result}</>);
    expect(container.innerHTML).toContain(
      'The beneficiary <strong>Jane Doe</strong> has been added.'
    );
  });

  // Update action tests
  it('returns the beneficiary updated JSX for update action with isMakerCheckerApplicable true', () => {
    const message: NotificationMessage = {
      nickname: 'Alice',
      action: 'update',
      isMakerCheckerApplicable: true,
    };
    const result = getNotificationMessage(message);
    const { container } = render(<>{result}</>);
    expect(container.innerHTML).toContain(
      'Updates to the beneficiary <strong>Alice</strong> have been sent for authorisation.'
    );
  });

  it('returns the beneficiary updated JSX for update action with isMakerCheckerApplicable false', () => {
    const message: NotificationMessage = {
      nickname: 'Alice',
      action: 'update',
      isMakerCheckerApplicable: false,
    };
    const result = getNotificationMessage(message);
    const { container } = render(<>{result}</>);
    expect(container.innerHTML).toContain(
      'The beneficiary <strong>Alice</strong> has been updated.'
    );
  });

  // Authorise actions tests
  it('returns success message for authorise_add without error response', () => {
    const message: NotificationMessage = {
      nickname: 'John Doe',
      action: 'authorise_add',
    };
    const result = getNotificationMessage(message);
    const { container } = render(<>{result}</>);
    expect(container.innerHTML).toContain(
      'You have authorised the beneficiary <strong>John Doe</strong>. This beneficiary is now <strong>fully authorised</strong> and available to use for any new payments.'
    );
  });

  it('returns error message for authorise_add with error response', () => {
    const errorResponse = {
      status: 400,
      data: {
        errors: [{ code: 8135, details: '{}' }],
      },
    };
    const message: NotificationMessage = {
      nickname: 'John Doe',
      action: 'authorise_add',
      errorResponse,
      userAction: 'authorise',
    };
    const result = getNotificationMessage(message);
    const { container } = render(<>{result}</>);
    expect(container.innerHTML).toContain(
      'Unable to authorise the beneficiary <strong>John Doe</strong>. Please try again later.'
    );
  });

  it('returns success message for authorise_update without error response', () => {
    const message: NotificationMessage = {
      nickname: 'Jane Doe',
      action: 'authorise_update',
    };
    const result = getNotificationMessage(message);
    const { container } = render(<>{result}</>);
    expect(container.innerHTML).toContain(
      'You have authorised the update to beneficiary <strong>Jane Doe</strong>. The update is now <strong>fully authorised</strong>.'
    );
  });

  it('returns error message for authorise_update with error response', () => {
    const errorResponse = {
      status: 403,
      data: {
        errors: [{ code: 8210, details: '{}' }],
      },
    };
    const message: NotificationMessage = {
      nickname: 'Jane Doe',
      action: 'authorise_update',
      errorResponse,
      userAction: 'authorise',
    };
    const result = getNotificationMessage(message);
    const { container } = render(<>{result}</>);
    expect(container.innerHTML).toContain(
      'You do not have permisson to authorise or reject the update to the beneficiary <strong>Jane Doe</strong>. Please contact your administrator for more information.'
    );
  });

  it('returns success message for authorise_archive without error response', () => {
    const message: NotificationMessage = {
      nickname: 'Bob Smith',
      action: 'authorise_archive',
    };
    const result = getNotificationMessage(message);
    const { container } = render(<>{result}</>);
    expect(container.innerHTML).toContain(
      'You have authorised the archive request for the beneficiary <strong>Bob Smith</strong>. This beneficiary is now <strong>archived</strong>.'
    );
  });

  it('returns error message for authorise_archive with error response', () => {
    const errorResponse = {
      status: 400,
      data: {
        errors: [{ code: 8140, details: '{}' }],
      },
    };
    const message: NotificationMessage = {
      nickname: 'Bob Smith',
      action: 'authorise_archive',
      errorResponse,
      userAction: 'authorise',
    };
    const result = getNotificationMessage(message);
    const { container } = render(<>{result}</>);
    expect(container.innerHTML).toContain(
      'Beneficiary <strong>Bob Smith</strong> could not be archived. Contact the initiator to archive the beneficiary again.'
    );
  });

  // Reject actions tests
  it('returns reject message for reject_add action', () => {
    const message: NotificationMessage = {
      nickname: 'Test User',
      action: 'reject_add',
    };
    const result = getNotificationMessage(message);
    const { container } = render(<>{result}</>);
    expect(container.innerHTML).toContain(
      'You have rejected the beneficiary <strong>Test User</strong>.'
    );
  });

  it('returns reject message for reject_update action', () => {
    const message: NotificationMessage = {
      nickname: 'Test User',
      action: 'reject_update',
    };
    const result = getNotificationMessage(message);
    const { container } = render(<>{result}</>);
    expect(container.innerHTML).toContain(
      'You have rejected the update to the beneficiary <strong>Test User</strong>.'
    );
  });

  it('returns reject message for reject_archive action', () => {
    const message: NotificationMessage = {
      nickname: 'Test User',
      action: 'reject_archive',
    };
    const result = getNotificationMessage(message);
    const { container } = render(<>{result}</>);
    expect(container.innerHTML).toContain(
      'You have rejected the archive request for the beneficiary <strong>Test User</strong>.'
    );
  });
});
describe(' should match the snapshot', () => {
  it('renders the NotificationAlert component correctly', () => {
    const { container } = render(<NotificationAlert />);
    expect(container).toMatchSnapshot();
  });
});

describe('NotificationAlert - Additional Edge Cases', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('renders Alert when useGlobalSelector returns valid notification state', () => {
    const mockMessage = {
      nickname: 'Test User',
      action: 'add' as const,
      isMakerCheckerApplicable: false,
    };
    const mockType = 'success';
    (useGlobalSelector as jest.Mock).mockReturnValue({
      type: mockType,
      message: mockMessage,
    });

    const { container } = render(<NotificationAlert />);
    expect(container.textContent).toContain(
      'The beneficiary Test User has been added.'
    );
    expect(Alert).toHaveBeenCalledWith(
      expect.objectContaining({
        look: mockType,
        id: `${mockType}Message`,
        className: 'mb-0 mt-2.5',
        iconSize: 'small',
        mode: 'box',
      }),
      {}
    );
  });

  it('renders nothing when message is empty string', () => {
    (useGlobalSelector as jest.Mock).mockReturnValue({
      type: 'info',
      message: '',
    });

    const { container } = render(<NotificationAlert />);
    expect(container.firstChild).toBeNull();
  });

  it('renders Alert even when message object returns empty string from getNotificationMessage', () => {
    (useGlobalSelector as jest.Mock).mockReturnValue({
      type: 'info',
      message: {
        nickname: '',
        action: 'add',
      },
    });

    const { container } = render(<NotificationAlert />);
    // The component will still render an Alert because the message object is truthy,
    // even though getNotificationMessage returns an empty string
    expect(container.firstChild).not.toBeNull();
    expect(Alert).toHaveBeenCalled();
  });
});
