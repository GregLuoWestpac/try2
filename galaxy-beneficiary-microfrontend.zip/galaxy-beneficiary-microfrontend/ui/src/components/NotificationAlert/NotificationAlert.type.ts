/* eslint-disable default-case */
import { AlertProps } from '@westpac/ui';
import { BeneficiaryAuthReqError } from '../../store/types';
import { UserActionType } from '../../common/constants';

export type NotificationObject = {
  nickname: string;
  action:
    | 'add'
    | 'archive'
    | 'update'
    | 'authorise_add'
    | 'authorise_update'
    | 'authorise_archive'
    | 'reject_add'
    | 'reject_update'
    | 'reject_archive';
  isMakerCheckerApplicable?: boolean;
  errorResponse?: BeneficiaryAuthReqError;
  userAction?: UserActionType;
};

export type NotificationMessage = string | NotificationObject;

export type NotificationAlertState = {
  type: AlertProps['look'];
  message: NotificationMessage;
};

export type GlobalContextState = {
  global: {
    galaxy: {
      context: {
        notificationAlert: NotificationAlertState;
      };
    };
  };
};
