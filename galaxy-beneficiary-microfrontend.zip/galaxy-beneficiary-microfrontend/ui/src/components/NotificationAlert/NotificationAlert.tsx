/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable no-use-before-define */
/* eslint-disable react/function-component-definition */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable no-else-return */
/* eslint-disable default-case */
import React, { ReactNode } from 'react';
import { Alert } from '@westpac/ui';
import { useGlobalSelector } from '@mep-ui/framework';
import { BeneficiaryError } from '../../store/types';
import { errorMessageListForAuthoriseBenReq } from '../../common/constants';
import {
  NotificationAlertState,
  NotificationMessage,
  NotificationObject,
} from './NotificationAlert.type';

/**
 * get simple error message for non-authorisation operations
 */
export const getErrorMessage = (errors: BeneficiaryError, errorFor: string) => {
  let errorMsg = '';
  switch (errors?.status) {
    case 403: {
      if (errors?.data?.errors?.[0]?.code === 8210) {
        errorMsg = `You do not have permission to ${errorFor}. Contact your administrator for more information.`;
      } else {
        errorMsg = 'Something went wrong. Please try again later.';
      }
      break;
    }
    default:
      if (errors?.status && errors.status >= 500 && errors.status < 600) {
        errorMsg = 'Something went wrong. Please try again later.';
      } else {
        errorMsg = 'Something went wrong. Please try again.';
      }
  }
  return errorMsg;
};

export const createErrorMessageForAuthorisation = (
  action: NotificationObject['action'],
  nickname: NotificationObject['nickname'],
  errorResponse: NotificationObject['errorResponse'],
  userAction: NotificationObject['userAction']
): JSX.Element => {
  const statusCode = errorResponse?.status;
  const errorCode = errorResponse?.data?.errors[0]?.code;
  let details;
  try {
    details = errorResponse?.data?.errors[0]?.details
      ? JSON.parse(errorResponse.data.errors[0].details)
      : {};
  } catch (e) {
    details = {};
  }
  switch (action) {
    case 'authorise_add':
      if (
        statusCode === 400 &&
        errorCode === 8135 &&
        details?.data?.errors[0].code === 1007
      ) {
        return (
          <>
            Unable to {userAction} the beneficiary <strong>{nickname}</strong>.
            This beneficiary already authorised or rejected.
          </>
        );
      }
      if (statusCode === 400 && errorCode === 8135) {
        return (
          <>
            Unable to {userAction} the beneficiary <strong>{nickname}</strong>.
            Please try again later.
          </>
        );
      } else if (statusCode === 400 && errorCode === 8140) {
        return (
          <>
            Beneficiary $<strong>{nickname}</strong> could not be added. Please
            contact the initiator to add the beneficiary again.
          </>
        );
      } else if (statusCode === 500 && errorCode === 8135) {
        return (
          <>
            Unable to {userAction} the beneficiary <strong>{nickname}</strong>.
            Please try again later.
          </>
        );
      } else if (statusCode === 500 && errorCode === 8140) {
        return (
          <>
            Beneficiary $<strong>{nickname}</strong> could not be added. Please
            contact the initiator to add the beneficiary again.
          </>
        );
      } else if (statusCode === 403 && errorCode === 8210) {
        return (
          <>
            {errorMessageListForAuthoriseBenReq.ACTION_RESTRICTED}{' '}
            <strong>{nickname}</strong>. Please contact your administrator for
            more information.
          </>
        );
      } else {
        return (
          <>
            Unable to {userAction} the beneficiary <strong>{nickname}</strong>.
            Please try again later.
          </>
        );
      }
      break;
    case 'authorise_update':
      if (
        statusCode === 400 &&
        errorCode === 8135 &&
        details?.data?.errors[0].code === 1007
      ) {
        return (
          <>
            Enable to {userAction} the beneficiary <strong>{nickname}</strong>.
            The update is already authorised or rejected.
          </>
        );
      }
      if (statusCode === 400 && errorCode === 8135) {
        return (
          <>
            Unable to {userAction} the update to the beneficiary{' '}
            <strong>{nickname}</strong>. Please try again later.
          </>
        );
      } else if (statusCode === 400 && errorCode === 8140) {
        return (
          <>
            Beneficiary $<strong>{nickname}</strong> could not be updated.
            Please contact the initiator to add the beneficiary again.
          </>
        );
      } else if (statusCode === 500 && errorCode === 8135) {
        return (
          <>
            Unable to {userAction} the update to the beneficiary{' '}
            <strong>{nickname}</strong>. Please try again later.
          </>
        );
      } else if (statusCode === 500 && errorCode === 8140) {
        return (
          <>
            Beneficiary $<strong>{nickname}</strong> could not be updated.
            Please contact the initiator to add the beneficiary again.
          </>
        );
      } else if (statusCode === 403 && errorCode === 8210) {
        return (
          <>
            {errorMessageListForAuthoriseBenReq.ACTION_RESTRICTED_UPDATE}{' '}
            <strong>{nickname}</strong>. Please contact your administrator for
            more information.
          </>
        );
      } else {
        return (
          <>
            Unable to {userAction} the update to the beneficiary{' '}
            <strong>{nickname}</strong>. Please try again later.
          </>
        );
      }
      break;
    case 'authorise_archive':
      if (
        statusCode === 400 &&
        errorCode === 8135 &&
        details?.data?.errors[0].code === 1007
      ) {
        return (
          <>
            Unable to athorise archiving of the beneficiary{' '}
            <strong>{nickname}</strong>. This archiving already authorised or
            rejected.
          </>
        );
      }
      if (statusCode === 400 && errorCode === 8135) {
        return (
          <>
            Unable to {userAction} the archiving of the beneficiary{' '}
            <strong>{nickname}</strong>. Please try again later.
          </>
        );
      } else if (statusCode === 400 && errorCode === 8140) {
        return (
          <>
            Beneficiary <strong>{nickname}</strong> could not be archived.
            Contact the initiator to archive the beneficiary again.
          </>
        );
      } else if (statusCode === 500 && errorCode === 8135) {
        return (
          <>
            Unable to {userAction} the archiving of the beneficiary{' '}
            <strong>{nickname}</strong>. Please try again later.
          </>
        );
      } else if (statusCode === 500 && errorCode === 8140) {
        return (
          <>
            Beneficiary <strong>{nickname}</strong> could not be archived.
            Contact the initiator to archive the beneficiary again.
          </>
        );
      } else if (statusCode === 403 && errorCode === 8210) {
        return (
          <>
            {errorMessageListForAuthoriseBenReq.ACTION_RESTRICTED}{' '}
            <strong>{nickname}</strong>. Please contact your administrator for
            more information.
          </>
        );
      } else {
        return (
          <>
            Unable to {userAction} the archiving of the beneficiary{' '}
            <strong>{nickname}</strong>. Please try again later.
          </>
        );
      }
      break;

    case 'reject_archive':
      return (
        <>
          Unable to {userAction} the archiving of the beneficiary{' '}
          <strong>{nickname}</strong>. Please try again later.
        </>
      );
    case 'reject_add':
      return (
        <>
          Unable to {userAction} the beneficiary <strong>{nickname}</strong>.
          Please try again later.
        </>
      );
    case 'reject_update':
      return (
        <>
          Unable to {userAction} the update to the beneficiary{' '}
          <strong>{nickname}</strong>. Please try again later.
        </>
      );
    default:
      return <>{errorMessageListForAuthoriseBenReq.UNREACHABLE}</>;
  }
};
export const getNotificationMessage = (
  message: NotificationMessage
): ReactNode => {
  if (typeof message === 'string') {
    return message;
  }
  const {
    nickname,
    action,
    isMakerCheckerApplicable,
    errorResponse,
    userAction,
  } = message;

  if (
    !nickname ||
    !action ||
    (errorResponse &&
      (errorResponse?.status === undefined || errorResponse?.status === null))
  ) {
    return errorMessageListForAuthoriseBenReq.UNREACHABLE;
  }

  switch (action) {
    case 'archive': {
      if (isMakerCheckerApplicable)
        return (
          <>
            Archive request for the beneficiary <strong>{nickname}</strong> has
            been sent for authorisation.
          </>
        );
      else
        return (
          <>
            The beneficiary <strong>{nickname}</strong> has been archived.
          </>
        );
    }
    case 'add': {
      if (isMakerCheckerApplicable)
        return (
          <>
            The beneficiary <strong>{nickname}</strong> has been sent for
            authorisation.
          </>
        );
      else
        return (
          <>
            The beneficiary <strong>{nickname}</strong> has been added.
          </>
        );
    }
    case 'update': {
      if (isMakerCheckerApplicable)
        return (
          <>
            Updates to the beneficiary <strong>{nickname}</strong> have been
            sent for authorisation.
          </>
        );
      else
        return (
          <>
            The beneficiary <strong>{nickname}</strong> has been updated.
          </>
        );
    }
    case 'authorise_add': {
      if (errorResponse) {
        return createErrorMessageForAuthorisation(
          action,
          nickname,
          errorResponse,
          userAction
        );
      } else
        return (
          <>
            You have authorised the beneficiary <strong>{nickname}</strong>.
            This beneficiary is now <strong>fully authorised</strong> and
            available to use for any new payments.
          </>
        );
    }
    case 'authorise_update': {
      if (errorResponse) {
        return createErrorMessageForAuthorisation(
          action,
          nickname,
          errorResponse,
          userAction
        );
      } else
        return (
          <>
            You have authorised the update to beneficiary{' '}
            <strong>{nickname}</strong>. The update is now{' '}
            <strong>fully authorised</strong>.
          </>
        );
    }
    case 'authorise_archive': {
      if (errorResponse) {
        return createErrorMessageForAuthorisation(
          action,
          nickname,
          errorResponse,
          userAction
        );
      } else
        return (
          <>
            You have authorised the archive request for the beneficiary{' '}
            <strong>{nickname}</strong>. This beneficiary is now{' '}
            <strong>archived</strong>.
          </>
        );
    }
    case 'reject_add': {
      if (errorResponse) {
        return createErrorMessageForAuthorisation(
          action,
          nickname,
          errorResponse,
          userAction
        );
      }
      return (
        <>
          You have rejected the beneficiary <strong>{nickname}</strong>.
        </>
      );
    }
    case 'reject_update': {
      if (errorResponse) {
        return createErrorMessageForAuthorisation(
          action,
          nickname,
          errorResponse,
          userAction
        );
      }
      return (
        <>
          You have rejected the update to the beneficiary{' '}
          <strong>{nickname}</strong>.
        </>
      );
    }
    case 'reject_archive': {
      if (errorResponse) {
        return createErrorMessageForAuthorisation(
          action,
          nickname,
          errorResponse,
          userAction
        );
      }
      return (
        <>
          You have rejected the archive request for the beneficiary{' '}
          <strong>{nickname}</strong>.
        </>
      );
    }
  }
};

const NotificationAlert = () => {
  const { type, message }: NotificationAlertState = useGlobalSelector(
    (state: GlobalContextState) =>
      state?.global?.galaxy?.context?.notificationAlert
  ) || { type: 'info', message: '' };
  return (
    message && (
      <Alert
        look={type}
        id={`${type}Message`}
        className="mb-0 mt-2.5"
        iconSize="small"
        mode="box"
      >
        {getNotificationMessage(message)}
      </Alert>
    )
  );
};

export default NotificationAlert;
