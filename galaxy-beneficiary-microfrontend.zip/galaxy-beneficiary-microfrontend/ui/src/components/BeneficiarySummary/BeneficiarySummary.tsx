/* eslint-disable react/react-in-jsx-scope */
import { MVDetailSection } from '@mesh-tenant-multiverse-ui-common/mv-detailsection';
import { formatBSB } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { MVCopAccountNameCheck, type CoPApiStatusCode } from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check'
import { Badge } from '@westpac/ui';
import { getFriendlyBeneficiaryStatus } from '../../common/Beneficiary.util';
import { getFriendlyPayIDType } from '../../common/PayID.util';
import {
  Beneficiary,
  BeneficiaryBSB,
  BeneficiaryPayID,
  BeneficiaryTaskDetail,
} from '../../store/types';
import { DetailSection } from './BeneficiarySummary.types';

type BeneficiarySummaryProps = {
  beneficiaryDetails: Beneficiary | BeneficiaryTaskDetail;
};

type BSBDetailsProps = {
  BSBNumber: string;
  bankName: string;
};

function DisplayBSBDetails({ bankName, BSBNumber }: BSBDetailsProps) {
  return (
    <>
      <p className="overflow-hidden overflow-ellipsis break-words">
        {BSBNumber}
      </p>
      <p className="overflow-hidden overflow-ellipsis break-words">
        {bankName}
      </p>
    </>
  );
}

export function BeneficiarySummary({
  beneficiaryDetails,
}: BeneficiarySummaryProps) {
  const mapSectionData = (
    beneficiary: Beneficiary | BeneficiaryTaskDetail
  ): DetailSection[] => {
    const beneficiaryBSBAccount = (beneficiary?.account ||
      {}) as BeneficiaryBSB;
    const { bankName, accountName } = beneficiaryBSBAccount;
    const { payIDName, payIDType, payIDValue } = (beneficiary?.account ||
      {}) as BeneficiaryPayID;
    const { BSB, accountNumber } = beneficiaryBSBAccount?.accountId || {};

    const beneficiaryStatus = getFriendlyBeneficiaryStatus(beneficiary.status);
    const bsbDetails = (
      <DisplayBSBDetails
        BSBNumber={formatBSB(BSB, 3) || ''}
        bankName={bankName?.toUpperCase() || ''}
      />
    );

    // not all fields will be rendered, null or undefined fields will be ignored by MVDetailSection
    const data: DetailSection[] = [
      {
        label: 'Beneficiary nickname',
        value: beneficiary.nickname,
      },
      {
        label: 'Account name',
        value: accountName,
      },
      {
        label: 'BSB',
        value: BSB ? bsbDetails : null,
      },
      {
        label: 'Account number',
        value: accountNumber ? (
          <>
            {accountNumber}
            {beneficiary.matchedCOPStatusCode ? (
              <div className='mt-1'>
                <MVCopAccountNameCheck
                  displayMode="compact"
                  copCheckResultData={{
                    matchedCOPAccountName: beneficiary.matchedCOPAccountName || '',
                    matchedCOPStatusCode: beneficiary.matchedCOPStatusCode as CoPApiStatusCode,
                  }}
                />
              </div>
            ) : null}
          </>
        ) : null,
      },
      {
        label: 'PayID name',
        value: payIDName,
      },
      {
        label: 'PayID',
        value: payIDValue,
      },
      {
        label: 'PayID type',
        value: payIDType ? getFriendlyPayIDType(payIDType) : null,
      },
      {
        label: 'Status',
        value: (
          <Badge color={beneficiaryStatus.badgeColor} soft>
            {beneficiaryStatus.text}
          </Badge>
        ),
      },
    ];

    return data;
  };

  return (
    <MVDetailSection
      heading="Beneficiary summary"
      data={mapSectionData(beneficiaryDetails)}
    />
  );
}
