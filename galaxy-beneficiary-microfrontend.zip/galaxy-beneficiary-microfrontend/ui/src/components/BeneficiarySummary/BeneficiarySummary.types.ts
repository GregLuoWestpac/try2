import React from 'react';
import { Beneficiary } from 'ui/src/store/types';

export type Props = {
  beneficiaryDetails: Beneficiary;
};

export enum BENEFICIARY_STATUS {
  ACTIVE = 'ACTIVE',
  ARCHIVED = 'ARCHIVED',
}

export type DetailSection = {
  label: string;
  value: string | React.JSX.Element | null | undefined;
  itemWithFullWidth?: React.ReactNode;
};
