import React from 'react';
import { render, screen } from '@testing-library/react';
import { BeneficiarySummary } from './BeneficiarySummary';
import {
  BENEFICIARY_STATUS,
  BENEFICIARY_TYPE,
  Beneficiary,
  PAYID_TYPE,
} from '../../store/types';
import { CURRENCY } from '../../common/constants';

// Mock @westpac/ui to avoid React child rendering issues
jest.mock('@westpac/ui', () => ({
  Badge: ({ children, ...props }: any) => (
    <span data-testid="badge" {...props}>
      {children}
    </span>
  ),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  getTodayAtLastYear: () => ({ toFormat: () => '2024-01-18' }),
  getToday: () => ({ toFormat: () => '2025-01-18' }),
}));

jest.mock('../../store/store', () => ({
  __esModule: true,
  default: {
    dispatch: jest.fn(),
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check', () => ({
  MVCopAccountNameCheck: ({ copCheckResultData, displayMode }: any) => (
    <div data-testid="cop-account-name-check" data-display-mode={displayMode}>
      {copCheckResultData?.matchedCOPAccountName}
    </div>
  ),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  formatBSB: jest.fn((bsb: string) => {
    if (!bsb) return ''; // Handle null, undefined, empty string
    if (bsb === '014111') return '014-111';
    return `${bsb.slice(0, 3)}-${bsb.slice(3)}`;
  }),
  convertSydneyLocalTimeToUtc: jest.fn((date: string) => date),
}));

const bsbMockBeneficiary: Beneficiary = {
  id: 'd0868661-b955-4e76-9f15-d97626f7df6b',
  externalId: 'd0868661-b955-4e76-9f15-d97626f7df6b',
  nickname: 'Bayer, Miller and MacGyver',
  currencyAmount: {
    currencyCode: CURRENCY.AUD,
    amount: '10.00',
  },
  reference: 'ref',
  org: 'office',
  type: BENEFICIARY_TYPE.ACCOUNT,
  status: BENEFICIARY_STATUS.ACTIVE,
  matchedCOPStatusCode: '',
  matchedCOPAccountName: '',
  account: {
    accountId: {
      BSB: '014111',
      accountNumber: '084765',
    },
    accountName: 'Westpac Joint',
    bankName: 'Westpac Banking Corporation',
  },
};

const payIDMockBeneficiary: Beneficiary = {
  id: 'd0868661-b955-4e76-9f15-d97626f7df6b',
  externalId: 'd0868661-b955-4e76-9f15-d97626f7df6b',
  nickname: 'Bayer, Miller and MacGyver',
  currencyAmount: {
    currencyCode: CURRENCY.AUD,
    amount: '10.00',
  },
  reference: 'ref',
  org: 'office',
  type: BENEFICIARY_TYPE.PAYID,
  status: BENEFICIARY_STATUS.ARCHIVED,
  matchedCOPStatusCode: '',
  matchedCOPAccountName: '',
  account: {
    payIDName: 'Tay Tay',
    payIDType: PAYID_TYPE.EMAIL,
    payIDValue: 'taylor.swift@era.com',
  },
};

describe('BeneficiarySummary', () => {
  it('beneficiary PayID details are displayed', () => {
    render(<BeneficiarySummary beneficiaryDetails={payIDMockBeneficiary} />);
    expect(screen.getByText('Beneficiary nickname')).toBeInTheDocument();
    expect(screen.getByText('Bayer, Miller and MacGyver')).toBeInTheDocument();
    expect(screen.getByText('PayID name')).toBeInTheDocument();
    expect(screen.getByText('Tay Tay')).toBeInTheDocument();
    expect(screen.getByText('PayID')).toBeInTheDocument();
    expect(screen.getByText('taylor.swift@era.com')).toBeInTheDocument();
    expect(screen.getByText('PayID type')).toBeInTheDocument();
    expect(screen.getByText('Email')).toBeInTheDocument();
  });

  it('beneficiary BSB details are displayed', () => {
    render(<BeneficiarySummary beneficiaryDetails={bsbMockBeneficiary} />);
    expect(screen.getByText('Beneficiary nickname')).toBeInTheDocument();
    expect(screen.getByText('Bayer, Miller and MacGyver')).toBeInTheDocument();
    expect(screen.getByText('Account name')).toBeInTheDocument();
    expect(screen.getByText('Westpac Joint')).toBeInTheDocument();
    expect(screen.getByText('BSB')).toBeInTheDocument();
    expect(screen.getByText('014-111')).toBeInTheDocument();
    expect(screen.getByText('WESTPAC BANKING CORPORATION')).toBeInTheDocument();
    expect(screen.getByText('Account number')).toBeInTheDocument();
    expect(screen.getByText('084765')).toBeInTheDocument();
  });

  it('check if the ACTIVE status label is displayed', () => {
    render(
      <BeneficiarySummary
        beneficiaryDetails={{
          ...bsbMockBeneficiary,
          status: BENEFICIARY_STATUS.ACTIVE,
        }}
      />
    );
    expect(screen.getByText(/Active/i)).toBeInTheDocument();
  });

  it('check if the ARCHIVED status label is displayed', () => {
    render(
      <BeneficiarySummary
        beneficiaryDetails={{
          ...payIDMockBeneficiary,
          status: BENEFICIARY_STATUS.ARCHIVED,
        }}
      />
    );
    expect(screen.getByText(/Archived/i)).toBeInTheDocument();
  });

  it('handles beneficiary with missing accountId gracefully', () => {
    const beneficiaryWithoutAccountId: any = {
      id: 'd0868661-b955-4e76-9f15-d97626f7df6b',
      externalId: 'd0868661-b955-4e76-9f15-d97626f7df6b',
      nickname: 'Test Beneficiary',
      currency: 'AUD',
      org: 'office',
      type: BENEFICIARY_TYPE.ACCOUNT,
      status: BENEFICIARY_STATUS.ACTIVE,
      account: {
        // accountId is missing
        accountName: 'Test Account',
        bankName: 'Test Bank',
      },
    };

    render(
      <BeneficiarySummary beneficiaryDetails={beneficiaryWithoutAccountId} />
    );
    expect(screen.getByText('Beneficiary nickname')).toBeInTheDocument();
    expect(screen.getByText('Test Beneficiary')).toBeInTheDocument();
    expect(screen.getByText('Account name')).toBeInTheDocument();
    expect(screen.getByText('Test Account')).toBeInTheDocument();
    // BSB and Account number should not be displayed when accountId is missing
    expect(screen.queryByText('BSB')).not.toBeInTheDocument();
    expect(screen.queryByText('Account number')).not.toBeInTheDocument();
  });

  it('handles beneficiary with null accountId gracefully', () => {
    const beneficiaryWithNullAccountId: any = {
      id: 'd0868661-b955-4e76-9f15-d97626f7df6b',
      externalId: 'd0868661-b955-4e76-9f15-d97626f7df6b',
      nickname: 'Test Beneficiary Null',
      currency: 'AUD',
      org: 'office',
      type: BENEFICIARY_TYPE.ACCOUNT,
      status: BENEFICIARY_STATUS.ACTIVE,
      account: {
        accountId: null, // explicitly null
        accountName: 'Test Account',
        bankName: 'Test Bank',
      },
    };

    render(
      <BeneficiarySummary beneficiaryDetails={beneficiaryWithNullAccountId} />
    );
    expect(screen.getByText('Beneficiary nickname')).toBeInTheDocument();
    expect(screen.getByText('Test Beneficiary Null')).toBeInTheDocument();
    expect(screen.getByText('Account name')).toBeInTheDocument();
    expect(screen.getByText('Test Account')).toBeInTheDocument();
    // BSB and Account number should not be displayed when accountId is null
    expect(screen.queryByText('BSB')).not.toBeInTheDocument();
    expect(screen.queryByText('Account number')).not.toBeInTheDocument();
  });

  it('handles beneficiary with missing account property gracefully', () => {
    const beneficiaryWithoutAccount: any = {
      id: 'd0868661-b955-4e76-9f15-d97626f7df6b',
      externalId: 'd0868661-b955-4e76-9f15-d97626f7df6b',
      nickname: 'Test Beneficiary No Account',
      currency: 'AUD',
      org: 'office',
      type: BENEFICIARY_TYPE.ACCOUNT,
      status: BENEFICIARY_STATUS.ACTIVE,
      // account property is completely missing
    };

    render(
      <BeneficiarySummary beneficiaryDetails={beneficiaryWithoutAccount} />
    );
    expect(screen.getByText('Beneficiary nickname')).toBeInTheDocument();
    expect(screen.getByText('Test Beneficiary No Account')).toBeInTheDocument();
    // No account-related fields should be displayed
    expect(screen.queryByText('Account name')).not.toBeInTheDocument();
    expect(screen.queryByText('BSB')).not.toBeInTheDocument();
    expect(screen.queryByText('Account number')).not.toBeInTheDocument();
    expect(screen.queryByText('PayID name')).not.toBeInTheDocument();
    expect(screen.queryByText('PayID')).not.toBeInTheDocument();
    expect(screen.queryByText('PayID type')).not.toBeInTheDocument();
  });

  it('handles beneficiary with undefined accountId gracefully', () => {
    const beneficiaryWithUndefinedAccountId: any = {
      id: 'd0868661-b955-4e76-9f15-d97626f7df6b',
      externalId: 'd0868661-b955-4e76-9f15-d97626f7df6b',
      nickname: 'Test Beneficiary Undefined',
      currency: 'AUD',
      org: 'office',
      type: BENEFICIARY_TYPE.ACCOUNT,
      status: BENEFICIARY_STATUS.ACTIVE,
      account: {
        accountId: undefined, // explicitly undefined
        accountName: 'Test Account',
        bankName: 'Test Bank',
      },
    };

    render(
      <BeneficiarySummary
        beneficiaryDetails={beneficiaryWithUndefinedAccountId}
      />
    );
    expect(screen.getByText('Beneficiary nickname')).toBeInTheDocument();
    expect(screen.getByText('Test Beneficiary Undefined')).toBeInTheDocument();
    expect(screen.getByText('Account name')).toBeInTheDocument();
    expect(screen.getByText('Test Account')).toBeInTheDocument();
    // BSB and Account number should not be displayed when accountId is undefined
    expect(screen.queryByText('BSB')).not.toBeInTheDocument();
    expect(screen.queryByText('Account number')).not.toBeInTheDocument();
  });

  it('handles beneficiary with empty BSB gracefully', () => {
    const beneficiaryWithEmptyBSB: Beneficiary = {
      id: 'd0868661-b955-4e76-9f15-d97626f7df6b',
      externalId: 'd0868661-b955-4e76-9f15-d97626f7df6b',
      nickname: 'Test Beneficiary Empty BSB',
      currencyAmount: {
        currencyCode: CURRENCY.AUD,
        amount: '10.00',
      },
      org: 'office',
      type: BENEFICIARY_TYPE.ACCOUNT,
      status: BENEFICIARY_STATUS.ACTIVE,
      matchedCOPStatusCode: '',
      matchedCOPAccountName: '',
      account: {
        accountId: {
          BSB: '', // empty BSB
          accountNumber: '084765',
        },
        accountName: 'Test Account',
        bankName: 'Test Bank',
      },
    };

    render(<BeneficiarySummary beneficiaryDetails={beneficiaryWithEmptyBSB} />);
    expect(screen.getByText('Beneficiary nickname')).toBeInTheDocument();
    expect(screen.getByText('Test Beneficiary Empty BSB')).toBeInTheDocument();
    expect(screen.getByText('Account number')).toBeInTheDocument();
    expect(screen.getByText('084765')).toBeInTheDocument();
    // BSB should not be displayed when empty
    expect(screen.queryByText('BSB')).not.toBeInTheDocument();
  });

  it('renders MVCopAccountNameCheck when matchedCOPStatusCode is present', () => {
    render(
      <BeneficiarySummary
        beneficiaryDetails={{
          ...bsbMockBeneficiary,
          matchedCOPStatusCode: 'V0C1',
          matchedCOPAccountName: 'Westpac Joint',
        }}
      />
    );
    const copComponent = screen.getByTestId('cop-account-name-check');
    expect(copComponent).toBeInTheDocument();
    expect(copComponent).toHaveAttribute('data-display-mode', 'compact');
    expect(copComponent).toHaveTextContent('Westpac Joint');
  });

  it('does not render MVCopAccountNameCheck when matchedCOPStatusCode is empty', () => {
    render(
      <BeneficiarySummary
        beneficiaryDetails={{
          ...bsbMockBeneficiary,
          matchedCOPStatusCode: '',
          matchedCOPAccountName: '',
        }}
      />
    );
    expect(screen.queryByTestId('cop-account-name-check')).not.toBeInTheDocument();
  });

  it('handles beneficiary with empty bank name gracefully', () => {
    const beneficiaryWithEmptyBankName: Beneficiary = {
      id: 'd0868661-b955-4e76-9f15-d97626f7df6b',
      externalId: 'd0868661-b955-4e76-9f15-d97626f7df6b',
      nickname: 'Test Beneficiary Empty Bank',
      currencyAmount: {
        currencyCode: CURRENCY.AUD,
        amount: '10.00',
      },
      org: 'office',
      type: BENEFICIARY_TYPE.ACCOUNT,
      status: BENEFICIARY_STATUS.ACTIVE,
      matchedCOPStatusCode: '',
      matchedCOPAccountName: '',
      account: {
        accountId: {
          BSB: '014111',
          accountNumber: '084765',
        },
        accountName: 'Test Account',
        bankName: '', // empty bank name
      },
    };

    render(
      <BeneficiarySummary beneficiaryDetails={beneficiaryWithEmptyBankName} />
    );
    expect(screen.getByText('Beneficiary nickname')).toBeInTheDocument();
    expect(screen.getByText('Test Beneficiary Empty Bank')).toBeInTheDocument();
    expect(screen.getByText('BSB')).toBeInTheDocument();
    expect(screen.getByText('014-111')).toBeInTheDocument();
    expect(screen.getByText('Account number')).toBeInTheDocument();
    expect(screen.getByText('084765')).toBeInTheDocument();
    // Bank name should be empty but BSB section should still display
    expect(
      screen.queryByText('WESTPAC BANKING CORPORATION')
    ).not.toBeInTheDocument();
  });
});
