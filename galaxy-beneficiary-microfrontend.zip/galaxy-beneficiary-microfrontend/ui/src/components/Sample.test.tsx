import React from 'react';
import { render } from '@testing-library/react';

import Sample from './Sample';

describe('Default', () => {
  it('should render with Grid component', () => {
    const { baseElement } = render(<Sample message="test" />);
    expect(baseElement).toMatchSnapshot();
  });
});