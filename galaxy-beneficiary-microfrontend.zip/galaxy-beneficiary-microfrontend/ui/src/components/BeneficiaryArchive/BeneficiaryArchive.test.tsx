import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { OverlayTriggerState } from 'react-stately';
import BeneficiaryArchive from './BeneficiaryArchive';

// Mock @westpac/ui to avoid React child rendering issues
jest.mock('@westpac/ui', () => ({
  Button: ({ children, onClick, ...props }: any) => (
    <button onClick={onClick} {...props}>
      {children}
    </button>
  ),
  Modal: ({ children, title, state, ...props }: any) => (
    <div data-testid="modal" {...props}>
      <div>{title}</div>
      {children}
    </div>
  ),
  ModalBody: ({ children }: any) => <div>{children}</div>,
  ModalFooter: ({ children }: any) => <div>{children}</div>,
}));

describe('BeneficiaryArchive', () => {
  const mockState: OverlayTriggerState = {
    isOpen: true,
    close: jest.fn(),
    open: jest.fn(),
    toggle: jest.fn(),
    setOpen: jest.fn(),
  };
  const mockOnArchiveClick = jest.fn();
  const beneficiaryNickName = 'John Doe';

  it('should render the modal with the correct title and body', () => {
    render(
      <BeneficiaryArchive
        state={mockState}
        beneficiaryNickName={beneficiaryNickName}
        onArchiveClick={mockOnArchiveClick}
      />
    );

    expect(screen.getByText('Archive beneficiary?')).toBeInTheDocument();
    expect(
      screen.getByText(
        'If you archive this beneficiary, it cannot be used for any new payments.'
      )
    ).toBeInTheDocument();
    expect(screen.getByText(beneficiaryNickName)).toBeInTheDocument();
  });

  it('should call onArchiveClick when the Archive button is clicked', () => {
    render(
      <BeneficiaryArchive
        state={mockState}
        beneficiaryNickName={beneficiaryNickName}
        onArchiveClick={mockOnArchiveClick}
      />
    );

    const archiveButton = screen.getByText('Archive');
    fireEvent.click(archiveButton);

    expect(mockOnArchiveClick).toHaveBeenCalled();
  });

  it('should call state.setOpen with false when the Cancel button is clicked', () => {
    render(
      <BeneficiaryArchive
        state={mockState}
        beneficiaryNickName={beneficiaryNickName}
        onArchiveClick={mockOnArchiveClick}
      />
    );

    const cancelButton = screen.getByText('Cancel');
    fireEvent.click(cancelButton);

    expect(mockState.setOpen).toHaveBeenCalledWith(false);
  });

  it('should match the snapshot', () => {
    const { container } = render(
      <BeneficiaryArchive
        state={mockState}
        beneficiaryNickName={beneficiaryNickName}
        onArchiveClick={mockOnArchiveClick}
      />
    );

    expect(container).toMatchSnapshot();
  });
});
