import React from 'react';
import { Button, Modal, ModalBody, ModalFooter } from '@westpac/ui';
import { OverlayTriggerState } from 'react-stately';

type Props = {
  state: OverlayTriggerState;
  beneficiaryNickName: string;
  onArchiveClick: () => void;
};
function BeneficiaryArchive({
  state,
  beneficiaryNickName,
  onArchiveClick,
}: Props) {
  return (
    <Modal size="md" title="Archive beneficiary?" state={state} isDismissable>
      <ModalBody>
        <p>
          If you archive this beneficiary, it cannot be used for any new
          payments.
        </p>
        <p>
          Payments already created and submitted will not be impacted by this.
        </p>
        <h2 className="font-medium my-2.5">{beneficiaryNickName}</h2>
        <Button
          look="primary"
          type="submit"
          className="mr-2"
          size="small"
          onClick={onArchiveClick}
        >
          Archive
        </Button>
        <Button
          soft
          look="hero"
          onClick={() => state.setOpen(false)}
          size="small"
        >
          Cancel
        </Button>
      </ModalBody>
    </Modal>
  );
}

export default BeneficiaryArchive;
