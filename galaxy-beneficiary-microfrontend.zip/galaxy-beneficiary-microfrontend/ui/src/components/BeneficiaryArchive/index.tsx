export { default as BeneficiaryArchive } from './BeneficiaryArchive';
