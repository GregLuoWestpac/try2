/* eslint-disable react/react-in-jsx-scope */
import React from 'react';
import { useAuthoriser } from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import '@testing-library/jest-dom';
import { fireEvent, render, screen } from '@testing-library/react';
import {
  Beneficiary,
  BENEFICIARY_STATUS,
  BENEFICIARY_TYPE,
  CURRENCY,
  PAYID_TYPE,
} from '../../store/types';
import BeneficiaryList, { BeneficiaryListProps } from './BeneficiaryList';

const mockHandleIntent = jest.fn();

jest.mock('@mesh-tenant-user-authorisation-policy-decision-engine/components');

// Mock @westpac/ui to avoid React hooks issues in tests
jest.mock('@westpac/ui', () => ({
  Button: ({ children, onClick, ...props }: any) => (
    <button onClick={onClick} {...props}>
      {children}
    </button>
  ),
}));

jest.mock('@westpac/ui/icon', () => ({
  AddIcon: () => <span data-testid="add-icon">+</span>,
}));

const mockIsStaffPortal = jest.fn<boolean | undefined, []>();
const mockUsePlatformState = jest.fn(() => [{}, jest.fn()]);

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => {
  const actual = jest.requireActual<
    typeof import('@mesh-tenant-multiverse-ui-common/mv-utils')
  >('@mesh-tenant-multiverse-ui-common/mv-utils');
  return {
    ...actual,
    useHandleRaiseIntent: () => mockHandleIntent,
    isStaffPortal: () => mockIsStaffPortal(),
    getFormattedDate: jest.fn(() => '20230918'),
  };
});

jest.mock('@mesh-tenant-multiverse-common/react', () => {
  const actual = jest.requireActual<
    typeof import('@mesh-tenant-multiverse-common/react')
  >('@mesh-tenant-multiverse-common/react');
  return {
    ...actual,
    usePlatformState: jest.fn(() => mockUsePlatformState()),
  };
});

// Mock DateTime
jest.mock('luxon', () => ({
  DateTime: {
    now: jest.fn(() => ({
      toISO: jest.fn(() => '2023-09-18T10:00:00.000Z'),
    })),
    fromISO: jest.fn((isoString: string) => ({
      setZone: jest.fn(() => ({
        toISO: jest.fn(() => isoString || '2023-09-18T00:00:00.000+11:00'),
        toUTC: jest.fn(() => ({
          toISO: jest.fn(() => isoString || '2023-09-18T00:00:00.000Z'),
        })),
      })),
      toISO: jest.fn(() => isoString || '2023-09-18T00:00:00.000Z'),
      toUTC: jest.fn(() => ({
        toISO: jest.fn(() => isoString || '2023-09-18T00:00:00.000Z'),
      })),
    })),
  },
}));

// Mock MVTable and related components
const mockExportCsv = jest.fn();
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let mockTableHandlers: any = {};

jest.mock('@mesh-tenant-multiverse-ui-common/mv-table-v2', () => {
  const actual = jest.requireActual<
    typeof import('@mesh-tenant-multiverse-ui-common/mv-table-v2')
  >('@mesh-tenant-multiverse-ui-common/mv-table-v2');
  return {
    ...actual,
    MVTableV2: jest.fn().mockImplementation(
      /* eslint-disable @typescript-eslint/no-explicit-any, @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access, @typescript-eslint/no-unsafe-call */
      ({
        rowData,
        onCellClicked,
        onCellKeyDown,
        getContextMenuItems,
        ...props
      }: any) => {
        // Store the handlers for testing
        mockTableHandlers = {
          onCellClicked,
          onCellKeyDown,
          getContextMenuItems,
        };

        return (
          <div data-testid="mv-table" {...props}>
            {rowData && rowData.length > 0 ? (
              <div>
                {rowData.map((row: any, index: number) => {
                  const menuItems =
                    getContextMenuItems?.({ node: { data: row } }) || [];
                  return (
                    /* eslint-disable-next-line react/no-array-index-key */
                    <div key={index} data-testid={`table-row-${index}`}>
                      <div data-testid={`nickname-${index}`}>
                        {row.beneficiaryNickname || row.nickname}
                      </div>
                      <div data-testid={`type-${index}`}>
                        {row.type === 'BSB_ACCOUNT_NUMBER'
                          ? 'BSB & account number'
                          : 'PayID'}
                      </div>
                      <button
                        type="button"
                        data-testid={`ActionButton-${index}`}
                      >
                        Actions
                      </button>
                      {menuItems.map((item: any, menuIndex: number) => (
                        <button
                          // eslint-disable-next-line react/no-array-index-key
                          key={menuIndex}
                          type="button"
                          onClick={item.action}
                        >
                          {item.name}
                        </button>
                      ))}
                    </div>
                  );
                })}
              </div>
            ) : (
              <div>There are no beneficiaries found.</div>
            )}
          </div>
        );
      }
    ),
    MVTableExportCSV: function MVTableExportCSV() {
      return {
        exportCsv: mockExportCsv,
      };
    },
  };
});

jest.mock('../../store/store', () => ({
  __esModule: true,
  default: {
    dispatch: jest.fn(),
  },
}));
const mockNavigate = jest.fn();
jest.mock('@mep-ui/framework-router-addon', () => {
  const actual = jest.requireActual<
    typeof import('@mep-ui/framework-router-addon')
  >('@mep-ui/framework-router-addon');
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});

const mockGlobalDispatch = jest.fn();
const mockGlobalSelector = jest.fn();

jest.mock('@mep-ui/framework', () => {
  const actual =
    jest.requireActual<typeof import('@mep-ui/framework')>('@mep-ui/framework');
  return {
    ...actual,
    ssoActions: {
      sso: {
        signout: {
          request: jest.fn(),
        },
      },
    },
    useGlobalDispatch: () => mockGlobalDispatch,
    useGlobalSelector: () => mockGlobalSelector,
  };
});

jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  MVDateRangePickerController: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div>{children}</div>;
  },
  getToday: jest.fn(() => ({
    minus: jest.fn(() => ({
      toFormat: jest.fn(() => '09/03/2025'),
    })),
    toFormat: jest.fn(() => '09/03/2025'),
  })),
  getTodayAtLastYear: jest.fn(() => ({
    toFormat: jest.fn(() => '09/03/2024'),
  })),
}));

const bsbMockBeneficiary: Beneficiary = {
  id: 'd0868661-b955-4e76-9f15-d97626f7df6b',
  externalId: 'd0868661-b955-4e76-9f15-d97626f7df6b',
  nickname: 'Bayer, Miller and MacGyver',
  currency: CURRENCY.AUD,
  currencyAmount: {
    amount: '0',
    currencyCode: CURRENCY.AUD,
  },
  org: 'office',
  type: BENEFICIARY_TYPE.ACCOUNT,
  status: BENEFICIARY_STATUS.ACTIVE,
  account: {
    accountId: {
      BSB: '014111',
      accountNumber: '084765',
    },
    bankName: 'Westpac',
    accountName: 'Westpac Joint',
  },
};

const payIDMockBeneficiary: Beneficiary = {
  id: 'd0868661-b955-4e76-9f15-d97626f7df6b',
  externalId: 'd0868661-b955-4e76-9f15-d97626f7df6b',
  nickname: 'Bayer, Miller and MacGyver',
  currency: CURRENCY.AUD,
  currencyAmount: {
    amount: '0',
    currencyCode: CURRENCY.AUD,
  },
  org: 'office',
  type: BENEFICIARY_TYPE.PAYID,
  status: BENEFICIARY_STATUS.ARCHIVED,
  account: {
    payIDName: 'Tay Tay',
    payIDType: PAYID_TYPE.EMAIL,
    payIDValue: 'taylor.swift@era.com',
  },
};

const mockBeneficiaries: Beneficiary[] = [
  bsbMockBeneficiary,
  payIDMockBeneficiary,
];

const defaultProps: BeneficiaryListProps = {
  beneficiaries: mockBeneficiaries,
  clearBeneficiaryArchive: jest.fn(),
  isUserAuthorizedToCreateBeneficiaries: true,
  isBeneficiaryListFetching: false,
  isBeneficiaryListError: false,
  onClickAddBeneficiary: jest.fn(),
  onRefresh: jest.fn(),
};

beforeAll(() => {
  global.ResizeObserver = function ResizeObserver() {
    return {
      observe: () => undefined,
      unobserve: () => undefined,
      disconnect: () => undefined,
    };
  } as unknown as typeof ResizeObserver;
});

describe('BeneficiaryList Component', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockIsStaffPortal.mockReturnValue(false); // Default to false for existing tests
    mockUsePlatformState.mockReturnValue([{}, jest.fn()]); // Default empty customer details
    (useAuthoriser as jest.Mock).mockReturnValue({
      authorised: true,
    });
  });
  it('should render with account details', () => {
    mockIsStaffPortal.mockReturnValue(true); // Hide buttons for snapshot
    const { container } = render(<BeneficiaryList {...defaultProps} />);
    expect(container).toMatchSnapshot();
  });

  it('should render with payID details', () => {
    mockIsStaffPortal.mockReturnValue(true); // Hide buttons for snapshot
    const { container } = render(
      <BeneficiaryList
        {...defaultProps}
        beneficiaries={[payIDMockBeneficiary]}
      />
    );
    expect(container).toMatchSnapshot();
  });

  it('renders specific row data', () => {
    render(
      <BeneficiaryList {...defaultProps} beneficiaries={[bsbMockBeneficiary]} />
    );
    expect(screen.getByTestId('nickname-0')).toHaveTextContent(
      'Bayer, Miller and MacGyver'
    );
    expect(screen.getByTestId('type-0')).toHaveTextContent(
      'BSB & account number'
    );
  });

  describe('Testing Action Buttons', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });
    it('should show context menu from the action buttons', () => {
      render(
        <BeneficiaryList
          {...defaultProps}
          beneficiaries={[bsbMockBeneficiary]}
        />
      );

      const actionButton = screen.getByTestId('ActionButton-0');
      expect(actionButton).toBeInTheDocument();

      fireEvent.click(actionButton);

      const ViewBeneficiary = screen.getByText('View beneficiary details');
      expect(ViewBeneficiary).toBeInTheDocument();

      const UpdateBeneficiary = screen.getByText('Update beneficiary');
      expect(UpdateBeneficiary).toBeInTheDocument();
    });

    it('navigates to beneficiary details screen', () => {
      render(
        <BeneficiaryList
          {...defaultProps}
          beneficiaries={[bsbMockBeneficiary]}
        />
      );

      const actionButton = screen.getByTestId('ActionButton-0');
      expect(actionButton).toBeInTheDocument();

      fireEvent.click(actionButton);
      const ViewBeneficiary = screen.getByText('View beneficiary details');
      fireEvent.click(ViewBeneficiary);
      expect(mockHandleIntent).toHaveBeenCalled();
    });

    it('should render with account details', () => {
      mockIsStaffPortal.mockReturnValue(true); // Hide buttons for snapshot
      const { container } = render(<BeneficiaryList {...defaultProps} />);
      expect(container).toMatchSnapshot();
    });

    it('should render with payID details', () => {
      mockIsStaffPortal.mockReturnValue(true); // Hide buttons for snapshot
      const { container } = render(
        <BeneficiaryList
          {...defaultProps}
          beneficiaries={[payIDMockBeneficiary]}
        />
      );
      expect(container).toMatchSnapshot();
    });

    it('should call onUpdateBeneficiary when "Update beneficiary" is clicked in the context menu', () => {
      render(
        <BeneficiaryList
          {...defaultProps}
          beneficiaries={[bsbMockBeneficiary]}
        />
      );
      const actionButton = screen.getByTestId('ActionButton-0');
      fireEvent.click(actionButton);
      const updateButton = screen.getByText('Update beneficiary');
      fireEvent.click(updateButton);
      expect(mockHandleIntent).toHaveBeenCalled();
    });
    it('should display "There are no beneficiaries found." when no beneficiaries are provided', () => {
      render(<BeneficiaryList {...defaultProps} beneficiaries={[]} />);
      expect(
        screen.queryByText('Bayer, Miller and MacGyver')
      ).not.toBeInTheDocument();
    });

    it('should call onSelectBeneficiary when a cell is clicked', () => {
      const mockOnSelectBeneficiary = jest.fn();

      const mockProps = {
        ...defaultProps,
        onSelectBeneficiary: mockOnSelectBeneficiary,
      };

      render(<BeneficiaryList {...mockProps} />);

      const cellParams = {
        data: bsbMockBeneficiary,
      };

      const handleCellClick = (clickParams: { data: Beneficiary }) => {
        const selectedBeneficiary = clickParams.data;
        mockOnSelectBeneficiary(selectedBeneficiary);
      };

      handleCellClick(cellParams);

      expect(mockOnSelectBeneficiary).toHaveBeenCalledWith(bsbMockBeneficiary);
    });

    it('should not call onSelectBeneficiary if e.event is undefined', () => {
      const mockOnSelectBeneficiary = jest.fn();

      const eventParam = {
        event: undefined,
        node: { data: bsbMockBeneficiary },
      };

      const onCellKeyDown = (keyDownEvent: {
        event: unknown;
        node: { data: Beneficiary };
      }) => {
        if (!keyDownEvent.event) {
          return;
        }

        const keyboardEvent = keyDownEvent.event as KeyboardEvent;
        const key = keyboardEvent?.key;
        if (key === 'Enter') {
          const rowNode = keyDownEvent.node;
          const selectedBeneficiary = rowNode?.data;
          mockOnSelectBeneficiary(selectedBeneficiary);
        }
      };
      onCellKeyDown(eventParam);

      expect(mockOnSelectBeneficiary).not.toHaveBeenCalled();
    });

    it('should call onSelectBeneficiary when Enter key is pressed on a cell', () => {
      const mockOnSelectBeneficiary = jest.fn();

      const mockProps = {
        ...defaultProps,
        onSelectBeneficiary: mockOnSelectBeneficiary,
      };

      render(<BeneficiaryList {...mockProps} />);

      const eventParam = {
        event: new KeyboardEvent('keydown', { key: 'Enter' }),
        node: { data: bsbMockBeneficiary },
      };

      const onCellKeyDown = (keyDownEvent: {
        event: unknown;
        node: { data: Beneficiary };
      }) => {
        if (!keyDownEvent.event) {
          return;
        }

        const keyboardEvent = keyDownEvent.event as KeyboardEvent;
        const key = keyboardEvent?.key;
        if (key === 'Enter') {
          const rowNode = keyDownEvent.node;
          const selectedBeneficiary = rowNode?.data;
          mockOnSelectBeneficiary(selectedBeneficiary);
        }
      };

      onCellKeyDown(eventParam);

      expect(mockOnSelectBeneficiary).toHaveBeenCalledWith(bsbMockBeneficiary);
    });

    it('should not call onSelectBeneficiary if key is not Enter', () => {
      const mockOnSelectBeneficiary = jest.fn();

      const eventParam = {
        event: new KeyboardEvent('keydown', { key: 'Escape' }),
        node: { data: bsbMockBeneficiary },
      };

      const onCellKeyDown = (keyDownEvent: {
        event: unknown;
        node: { data: Beneficiary };
      }) => {
        if (!keyDownEvent.event) {
          return;
        }

        const keyboardEvent = keyDownEvent.event as KeyboardEvent;
        const key = keyboardEvent?.key;
        if (key === 'Enter') {
          const rowNode = keyDownEvent.node;
          const selectedBeneficiary = rowNode?.data;
          mockOnSelectBeneficiary(selectedBeneficiary);
        }
      };

      onCellKeyDown(eventParam);

      expect(mockOnSelectBeneficiary).not.toHaveBeenCalled();
    });
  });

  it('should not call onSelectBeneficiary if key is not Enter', () => {
    const mockOnSelectBeneficiary = jest.fn();
    const eventParam = {
      event: new KeyboardEvent('keydown', { key: 'Escape' }),
      node: { data: bsbMockBeneficiary },
    };

    const onCellKeyDown = (keyDownEvent: {
      event: unknown;
      node: { data: Beneficiary };
    }) => {
      if (!keyDownEvent.event) return;
      const keyboardEvent = keyDownEvent.event as KeyboardEvent;
      const key = keyboardEvent?.key;
      if (key === 'Enter') {
        const rowNode = keyDownEvent.node;
        const selectedBeneficiary = rowNode?.data;
        mockOnSelectBeneficiary(selectedBeneficiary);
      }
    };

    onCellKeyDown(eventParam);
    expect(mockOnSelectBeneficiary).not.toHaveBeenCalled();
  });

  it('should return correct context menu items for active beneficiaries', () => {
    const menuParams = {
      node: { data: bsbMockBeneficiary },
    };

    const getContextMenuItems = (contextParams: {
      node: { data: Beneficiary };
    }) => {
      const actionItemsArray: Array<{
        name: string;
        action: () => void;
      }> = [];
      const status = contextParams.node?.data?.status;
      actionItemsArray.push({
        name: 'View beneficiary details',
        // eslint-disable-next-line @typescript-eslint/no-empty-function
        action: () => {},
      });
      if (status !== BENEFICIARY_STATUS.ARCHIVED) {
        // eslint-disable-next-line @typescript-eslint/no-empty-function
        actionItemsArray.push({ name: 'Update beneficiary', action: () => {} });
      }
      return actionItemsArray;
    };

    const menuItems = getContextMenuItems(menuParams);
    expect(menuItems).toHaveLength(2);
    expect(menuItems[0].name).toBe('View beneficiary details');
    expect(menuItems[1].name).toBe('Update beneficiary');
  });

  it('should return correct context menu items for archived beneficiaries', () => {
    const menuParams = {
      node: { data: payIDMockBeneficiary },
    };

    const getContextMenuItems = (contextParams: {
      node: { data: Beneficiary };
    }) => {
      const actionItemsArray: Array<{
        name: string;
        action: () => void;
      }> = [];
      const status = contextParams.node?.data?.status;
      actionItemsArray.push({
        name: 'View beneficiary details',
        // eslint-disable-next-line @typescript-eslint/no-empty-function
        action: () => {},
      });
      if (status !== BENEFICIARY_STATUS.ARCHIVED) {
        // eslint-disable-next-line @typescript-eslint/no-empty-function
        actionItemsArray.push({ name: 'Update beneficiary', action: () => {} });
      }
      return actionItemsArray;
    };

    const menuItems = getContextMenuItems(menuParams);
    expect(menuItems).toHaveLength(1);
    expect(menuItems[0].name).toBe('View beneficiary details');
  });

  it('should map beneficiaries to formattedListOptions correctly', () => {
    const formattedListOptions = mockBeneficiaries.map(option => ({
      ...option,
      beneficiaryNickname: option.nickname,
    }));

    expect(formattedListOptions[0].beneficiaryNickname).toBe(
      bsbMockBeneficiary.nickname
    );
    expect(formattedListOptions[1].beneficiaryNickname).toBe(
      payIDMockBeneficiary.nickname
    );
  });
});
it('should call clearBeneficiaryArchive when onSelectBeneficiary is invoked', () => {
  const mockClearBeneficiaryArchive = jest.fn();
  const mockHandleRaiseIntent = jest.fn().mockResolvedValue(undefined);

  jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => {
    const actual = jest.requireActual<
      typeof import('@mesh-tenant-multiverse-ui-common/mv-utils')
    >('@mesh-tenant-multiverse-ui-common/mv-utils');
    return {
      ...actual,
      useHandleRaiseIntent: () => mockHandleRaiseIntent,
    };
  });

  const mockProps = {
    ...defaultProps,
    clearBeneficiaryArchive: mockClearBeneficiaryArchive,
  };

  render(<BeneficiaryList {...mockProps} />);

  const onSelectBeneficiary = () => {
    mockClearBeneficiaryArchive();
  };

  onSelectBeneficiary();

  expect(mockClearBeneficiaryArchive).toHaveBeenCalled();
});

describe('check entitlements', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('contains entitlements', () => {
    (useAuthoriser as jest.Mock)
      .mockReturnValue({
        authorised: true,
      })
      .mockReturnValue({
        authorised: true,
      });
    render(
      <BeneficiaryList {...defaultProps} beneficiaries={[bsbMockBeneficiary]} />
    );

    const actionButton = screen.getByTestId('ActionButton-0');
    expect(actionButton).toBeInTheDocument();

    fireEvent.click(actionButton);

    const ViewBeneficiary = screen.getByText('View beneficiary details');
    const UpdateBeneficiary = screen.queryByText('Update beneficiary');
    expect(ViewBeneficiary).toBeInTheDocument();
    expect(UpdateBeneficiary).toBeInTheDocument();
  });

  it('does not contain entitlements', () => {
    (useAuthoriser as jest.Mock)
      .mockReturnValue({
        authorised: false,
      })
      .mockReturnValue({
        authorised: false,
      })
      .mockReturnValue({
        authorised: false,
      });

    render(
      <BeneficiaryList {...defaultProps} beneficiaries={[bsbMockBeneficiary]} />
    );

    const actionButton = screen.getByTestId('ActionButton-0');
    expect(actionButton).toBeInTheDocument();

    fireEvent.click(actionButton);

    const ViewBeneficiary = screen.queryByText('View beneficiary details');
    const UpdateBeneficiary = screen.queryByText('Update beneficiary');
    expect(ViewBeneficiary).not.toBeInTheDocument();
    expect(UpdateBeneficiary).not.toBeInTheDocument();
  });

  // isStaffPortal tests
  it('should render "Add beneficiary" button when not staff portal and user is authorized', () => {
    mockIsStaffPortal.mockReturnValue(false);
    const propsWithCreateAuth = {
      ...defaultProps,
      isUserAuthorizedToCreateBeneficiaries: true,
    };

    render(<BeneficiaryList {...propsWithCreateAuth} />);

    const addButton = screen.getByRole('button', { name: /add beneficiary/i });
    expect(addButton).toBeInTheDocument();
  });

  it('should not render "Add beneficiary" button when not staff portal but user is not authorized', () => {
    mockIsStaffPortal.mockReturnValue(false);
    const propsWithoutCreateAuth = {
      ...defaultProps,
      isUserAuthorizedToCreateBeneficiaries: false,
    };

    render(<BeneficiaryList {...propsWithoutCreateAuth} />);

    const addButton = screen.queryByRole('button', {
      name: /add beneficiary/i,
    });
    expect(addButton).not.toBeInTheDocument();
  });

  it('should render "Export beneficiaries" button when not staff portal', () => {
    mockIsStaffPortal.mockReturnValue(false);
    const propsWithData = {
      ...defaultProps,
      isBeneficiaryListFetching: false,
      isBeneficiaryListError: false,
    };

    render(<BeneficiaryList {...propsWithData} />);

    const exportButton = screen.getByRole('button', {
      name: /export beneficiaries/i,
    });
    expect(exportButton).toBeInTheDocument();
  });

  it('should call onClickAddBeneficiary when "Add beneficiary" button is clicked', () => {
    mockIsStaffPortal.mockReturnValue(false);
    const mockOnClickAddBeneficiary = jest.fn();
    const propsWithClickHandler = {
      ...defaultProps,
      isUserAuthorizedToCreateBeneficiaries: true,
      onClickAddBeneficiary: mockOnClickAddBeneficiary,
    };

    render(<BeneficiaryList {...propsWithClickHandler} />);

    const addButton = screen.getByRole('button', { name: /add beneficiary/i });
    fireEvent.click(addButton);

    expect(mockOnClickAddBeneficiary).toHaveBeenCalledTimes(1);
  });

  it('should not render "Add beneficiary" button when staff portal even with authorization', () => {
    mockIsStaffPortal.mockReturnValue(true);
    const propsWithCreateAuth = {
      ...defaultProps,
      isUserAuthorizedToCreateBeneficiaries: true,
    };

    render(<BeneficiaryList {...propsWithCreateAuth} />);

    const addButton = screen.queryByRole('button', {
      name: /add beneficiary/i,
    });
    expect(addButton).not.toBeInTheDocument();
  });

  it('should not render "Export beneficiaries" button when staff portal', () => {
    mockIsStaffPortal.mockReturnValue(true);
    const propsWithData = {
      ...defaultProps,
      isBeneficiaryListFetching: false,
      isBeneficiaryListError: false,
    };

    render(<BeneficiaryList {...propsWithData} />);

    const exportButton = screen.queryByRole('button', {
      name: /export beneficiaries/i,
    });
    expect(exportButton).not.toBeInTheDocument();
  });

  it('should still render table when staff portal', () => {
    mockIsStaffPortal.mockReturnValue(true);
    const propsWithData = {
      ...defaultProps,
      isBeneficiaryListFetching: false,
      isBeneficiaryListError: false,
      beneficiaries: [bsbMockBeneficiary], // Use BSB beneficiary to test this type
    };

    render(<BeneficiaryList {...propsWithData} />);

    const beneficiaryNames = screen.getAllByText('Bayer, Miller and MacGyver');
    expect(beneficiaryNames.length).toBeGreaterThan(0);
    expect(screen.getByText('BSB & account number')).toBeInTheDocument();
  });

  it('should show buttons when isStaffPortal returns undefined', () => {
    mockIsStaffPortal.mockReturnValue(undefined);
    const propsWithCreateAuth = {
      ...defaultProps,
      isUserAuthorizedToCreateBeneficiaries: true,
    };

    render(<BeneficiaryList {...propsWithCreateAuth} />);

    const addButton = screen.getByRole('button', { name: /add beneficiary/i });
    expect(addButton).toBeInTheDocument();
  });

  it('should handle when isStaffPortal throws an error', () => {
    mockIsStaffPortal.mockImplementation(() => {
      throw new Error('Test error');
    });
    const propsWithCreateAuth = {
      ...defaultProps,
      isUserAuthorizedToCreateBeneficiaries: true,
    };

    expect(() => {
      render(<BeneficiaryList {...propsWithCreateAuth} />);
    }).toThrow('Test error');
  });
});

describe('Component event handlers', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockIsStaffPortal.mockReturnValue(false);
    (useAuthoriser as jest.Mock).mockReturnValue({
      authorised: true,
    });
  });

  it('should call onSelectBeneficiary when onCellClicked is triggered', async () => {
    const mockClearBeneficiaryArchive = jest.fn();

    const props = {
      ...defaultProps,
      clearBeneficiaryArchive: mockClearBeneficiaryArchive,
    };

    render(<BeneficiaryList {...props} />);

    // Get the actual onCellClicked handler from the component
    const { onCellClicked } = mockTableHandlers;
    expect(onCellClicked).toBeDefined();

    // Simulate a cell click event
    const mockParams = {
      data: bsbMockBeneficiary,
    };

    await onCellClicked(mockParams);

    // Verify that clearBeneficiaryArchive and handleRaiseIntent were called
    expect(mockClearBeneficiaryArchive).toHaveBeenCalled();
    expect(mockHandleIntent).toHaveBeenCalledWith({
      intentName: 'ViewGalaxyBeneficiaryDetails',
      intentContextName: 'fdc3.nothing',
      data: { selectedBeneficiary: bsbMockBeneficiary },
      contextKey: bsbMockBeneficiary.id,
      targetPath: '/beneficiary/view-beneficiary',
    });
  });

  it('should call onSelectBeneficiary when Enter key is pressed in onCellKeyDown', async () => {
    const mockClearBeneficiaryArchive = jest.fn();

    const props = {
      ...defaultProps,
      clearBeneficiaryArchive: mockClearBeneficiaryArchive,
    };

    render(<BeneficiaryList {...props} />);

    // Get the actual onCellKeyDown handler from the component
    const { onCellKeyDown } = mockTableHandlers;
    expect(onCellKeyDown).toBeDefined();

    // Simulate Enter key press event
    const mockEvent = {
      event: { key: 'Enter' },
      node: { data: bsbMockBeneficiary },
    };

    await onCellKeyDown(mockEvent);

    // Verify that clearBeneficiaryArchive and handleRaiseIntent were called
    expect(mockClearBeneficiaryArchive).toHaveBeenCalled();
    expect(mockHandleIntent).toHaveBeenCalledWith({
      intentName: 'ViewGalaxyBeneficiaryDetails',
      intentContextName: 'fdc3.nothing',
      data: { selectedBeneficiary: bsbMockBeneficiary },
      contextKey: bsbMockBeneficiary.id,
      targetPath: '/beneficiary/view-beneficiary',
    });
  });

  it('should not call onSelectBeneficiary when non-Enter key is pressed in onCellKeyDown', async () => {
    const mockClearBeneficiaryArchive = jest.fn();

    const props = {
      ...defaultProps,
      clearBeneficiaryArchive: mockClearBeneficiaryArchive,
    };

    render(<BeneficiaryList {...props} />);

    // Get the actual onCellKeyDown handler from the component
    const { onCellKeyDown } = mockTableHandlers;
    expect(onCellKeyDown).toBeDefined();

    // Simulate non-Enter key press event
    const mockEvent = {
      event: { key: 'Escape' },
      node: { data: bsbMockBeneficiary },
    };

    await onCellKeyDown(mockEvent);

    // Verify that functions were NOT called
    expect(mockClearBeneficiaryArchive).not.toHaveBeenCalled();
    expect(mockHandleIntent).not.toHaveBeenCalled();
  });

  it('should not call onSelectBeneficiary when event is null in onCellKeyDown', async () => {
    const mockClearBeneficiaryArchive = jest.fn();

    const props = {
      ...defaultProps,
      clearBeneficiaryArchive: mockClearBeneficiaryArchive,
    };

    render(<BeneficiaryList {...props} />);

    // Get the actual onCellKeyDown handler from the component
    const { onCellKeyDown } = mockTableHandlers;
    expect(onCellKeyDown).toBeDefined();

    // Simulate event with null event
    const mockEvent = {
      event: null,
      node: { data: bsbMockBeneficiary },
    };

    await onCellKeyDown(mockEvent);

    // Verify that functions were NOT called
    expect(mockClearBeneficiaryArchive).not.toHaveBeenCalled();
    expect(mockHandleIntent).not.toHaveBeenCalled();
  });

  it('should NOT include viewOptions when isStaffPortal returns false', async () => {
    const mockClearBeneficiaryArchive = jest.fn();
    mockIsStaffPortal.mockReturnValue(false);

    const props = {
      ...defaultProps,
      clearBeneficiaryArchive: mockClearBeneficiaryArchive,
    };

    render(<BeneficiaryList {...props} />);

    const { onCellClicked } = mockTableHandlers;
    expect(onCellClicked).toBeDefined();

    const mockParams = {
      data: bsbMockBeneficiary,
    };

    await onCellClicked(mockParams);

    expect(mockClearBeneficiaryArchive).toHaveBeenCalled();
    expect(mockHandleIntent).toHaveBeenCalledWith({
      intentName: 'ViewGalaxyBeneficiaryDetails',
      intentContextName: 'fdc3.nothing',
      data: { selectedBeneficiary: bsbMockBeneficiary },
      contextKey: bsbMockBeneficiary.id,
      targetPath: '/beneficiary/view-beneficiary',
    });

    // Verify viewOptions is NOT included
    const callArgs = mockHandleIntent.mock.calls[0][0];
    expect(callArgs).not.toHaveProperty('viewOptions');
  });

  it('should include viewOptions when isStaffPortal returns true', async () => {
    const mockClearBeneficiaryArchive = jest.fn();
    mockIsStaffPortal.mockReturnValue(true);
    mockUsePlatformState.mockReturnValue([{}, jest.fn()]);

    const props = {
      ...defaultProps,
      clearBeneficiaryArchive: mockClearBeneficiaryArchive,
    };

    render(<BeneficiaryList {...props} />);

    const { onCellClicked } = mockTableHandlers;
    expect(onCellClicked).toBeDefined();

    const mockParams = {
      data: bsbMockBeneficiary,
    };

    await onCellClicked(mockParams);

    expect(mockClearBeneficiaryArchive).toHaveBeenCalled();
    expect(mockHandleIntent).toHaveBeenCalledWith({
      intentName: 'ViewGalaxyBeneficiaryDetails',
      intentContextName: 'fdc3.nothing',
      data: { selectedBeneficiary: bsbMockBeneficiary },
      contextKey: bsbMockBeneficiary.id,
      targetPath: '/beneficiary/view-beneficiary',
      viewOptions: {
        windowTabKey: 'office',
        windowTabTitle: '',
        containerTabTitle: 'Beneficiary details | Westpac One',
      },
    });
  });

  it('should include customer fullName in viewOptions windowTabTitle when available', async () => {
    const mockClearBeneficiaryArchive = jest.fn();
    mockIsStaffPortal.mockReturnValue(true);

    const mockCustomerDetails = {
      office: [
        {
          fullName: 'John Doe',
          organisationId: 'office',
        },
      ],
    };
    mockUsePlatformState.mockReturnValue([mockCustomerDetails, jest.fn()]);

    const props = {
      ...defaultProps,
      clearBeneficiaryArchive: mockClearBeneficiaryArchive,
    };

    render(<BeneficiaryList {...props} />);

    const { onCellClicked } = mockTableHandlers;
    expect(onCellClicked).toBeDefined();

    const mockParams = {
      data: bsbMockBeneficiary,
    };

    await onCellClicked(mockParams);

    expect(mockClearBeneficiaryArchive).toHaveBeenCalled();
    expect(mockHandleIntent).toHaveBeenCalledWith({
      intentName: 'ViewGalaxyBeneficiaryDetails',
      intentContextName: 'fdc3.nothing',
      data: { selectedBeneficiary: bsbMockBeneficiary },
      contextKey: bsbMockBeneficiary.id,
      targetPath: '/beneficiary/view-beneficiary',
      viewOptions: {
        windowTabKey: 'office',
        windowTabTitle: 'John Doe',
        containerTabTitle: 'Beneficiary details | Westpac One',
      },
    });
  });
});
