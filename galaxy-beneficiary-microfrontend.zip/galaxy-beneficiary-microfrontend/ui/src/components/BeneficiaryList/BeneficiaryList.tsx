/* eslint-disable import/no-relative-packages */
/* eslint-disable no-nested-ternary */
/* eslint-disable react/no-unstable-nested-components */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable react/function-component-definition */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unused-expressions */
import { useGlobalDispatch } from '@mep-ui/framework';
import { useNavigate } from '@mep-ui/framework-router-addon';
import { usePlatformState } from '@mesh-tenant-multiverse-common/react';
import { MVPageLoader as PageLoader } from '@mesh-tenant-multiverse-ui-common/mv-pageloader';
import {
  CellClickedEventV2 as CellClickedEvent,
  CellKeyDownEventV2 as CellKeyDownEvent,
  ColDefV2 as ColDef,
  GetContextMenuItemsParamsV2 as GetContextMenuItemsParams,
  MVTableV2 as MVTable,
  MVTableExportCSV,
  onColumnPinnedV2 as onColumnPinned,
  onFilterChangedV2 as onFilterChanged,
  suppressHeaderKeyboardEventV2 as suppressHeaderKeyboardEvent,
  suppressKeyboardEventV2 as suppressKeyboardEvent,
  TableDataV2 as TableData,
} from '@mesh-tenant-multiverse-ui-common/mv-table-v2';
import {
  getFormattedDate,
  isStaffPortal,
  useHandleRaiseIntent,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import {
  Actions,
  Resources,
  useAuthoriser,
} from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import { Button } from '@westpac/ui';
import { AddIcon } from '@westpac/ui/icon';
import { DateTime } from 'luxon';
import React, { useCallback, useMemo, useRef } from 'react';
import {
  CONTAINERTAB_TITLES,
  INTENT_NAMES,
  INTENTS_CONTEXT_NAME,
  noRowMessage,
  PAGE_NAVIGATION,
} from '../../common';
import { updateBeneficiaryKey } from '../../common/Beneficiary.util';
import { CustomerDetails } from '../../common/types';
import { Beneficiary, BENEFICIARY_STATUS } from '../../store/types';
import { ErrorHandler } from '../ErrorHandler';
import { buildColumnDefs } from './BeneficiaryList.utils';

export type BeneficiaryListProps = {
  beneficiaries: Beneficiary[];
  clearBeneficiaryArchive: () => void;
  isUserAuthorizedToCreateBeneficiaries: boolean;
  isBeneficiaryListFetching: boolean;
  isBeneficiaryListError: boolean;
  onClickAddBeneficiary: () => void;
  onRefresh: () => void;
};

const BeneficiaryList: React.FC<BeneficiaryListProps> = ({
  beneficiaries,
  clearBeneficiaryArchive,
  isUserAuthorizedToCreateBeneficiaries,
  isBeneficiaryListFetching,
  isBeneficiaryListError,
  onClickAddBeneficiary,
  onRefresh,
}) => {
  const { authorised: isUserAuthorizedToViewBeneficiaries } = useAuthoriser(
    Resources.BENEFICIARY,
    Actions.VIEW_BENEFICIARY
  );

  const { authorised: isUserAuthorizedToUpdateBeneficiaries } = useAuthoriser(
    Resources.BENEFICIARY,
    Actions.MODIFY_BENEFICIARY
  );

  const handleRaiseIntent = useHandleRaiseIntent(
    useGlobalDispatch,
    useNavigate
  );
  const tableContainerRef = useRef<HTMLDivElement>(null);
  const columnDefs = useMemo(() => buildColumnDefs(), []);
  const mvTableRef = useRef<MVTableExportCSV>(null);

  const [selectedCustomerDetails] = usePlatformState<
    Record<string, CustomerDetails[]>
  >('w1c/customerDetails', {});

  const defaultColumnDef: ColDef = {
    menuTabs: ['generalMenuTab', 'filterMenuTab', 'columnsMenuTab'],
    filter: 'agTextColumnFilter',
    filterParams: {
      buttons: ['reset'],
      filterOptions: ['contains'],
    },
    minWidth: 119.5,
    suppressKeyboardEvent,
    suppressHeaderKeyboardEvent,
    suppressHeaderContextMenu: true,
    suppressHeaderFilterButton: false,
    suppressHeaderMenuButton: false,
    headerClass:
      'default-header !text-[0.8125rem] whitespace-nowrap [word-spacing:normal]',
  };
  const list: Beneficiary[] = beneficiaries;

  const onSelectBeneficiary = async (beneficiary: Beneficiary) => {
    clearBeneficiaryArchive();

    const customerFullName =
      selectedCustomerDetails[beneficiary.org]?.[0]?.fullName || '';

    await handleRaiseIntent({
      intentName: INTENT_NAMES.VIEW_BENEFICIARY_DETAILS,
      intentContextName: INTENTS_CONTEXT_NAME.BENEFICIARY,
      data: { selectedBeneficiary: beneficiary },
      contextKey: beneficiary.id,
      targetPath: PAGE_NAVIGATION.BENEFICIARY_DETAILS,
      ...(isStaffPortal() && {
        viewOptions: {
          windowTabKey: beneficiary.org,
          windowTabTitle: customerFullName,
          containerTabTitle: CONTAINERTAB_TITLES.BENEFICIARY_DETAILS,
        },
      }),
    });
  };

  const onUpdateBeneficiary = async (beneficiary: Beneficiary) => {
    await handleRaiseIntent({
      intentName: INTENT_NAMES.UPDATE_BENEFICIARY,
      intentContextName: INTENTS_CONTEXT_NAME.BENEFICIARY,
      data: { beneficiaryToBeUpdated: beneficiary },
      contextKey: updateBeneficiaryKey(beneficiary.id),
      targetPath: PAGE_NAVIGATION.UPDATE_BENEFICIARY,
    });
  };

  const formattedListOptions = list.map(option => ({
    ...option,
    currency: option?.currencyAmount?.currencyCode,
    beneficiaryNickname: option.nickname,
  }));

  const getContextMenuItems = (
    params: GetContextMenuItemsParams<TableData>
  ) => {
    const actionItemsArray: any[] = [];
    const status = params.node?.data?.status;
    if (isUserAuthorizedToViewBeneficiaries) {
      actionItemsArray.push({
        name: 'View beneficiary details',
        cssClasses: ['action-button'],
        action: () => {
          onSelectBeneficiary(params.node.data);
        },
      });
    }
    status === BENEFICIARY_STATUS.ACTIVE &&
      isUserAuthorizedToUpdateBeneficiaries &&
      actionItemsArray.push({
        name: 'Update beneficiary',
        cssClasses: ['action-button'],
        action: () => {
          onUpdateBeneficiary(params.node.data);
        },
      });
    return actionItemsArray;
  };
  const onCellClicked = (params: CellClickedEvent<TableData>) => {
    const selectedBeneficiary = params.data as Beneficiary;
    onSelectBeneficiary(selectedBeneficiary);
  };

  const onCellKeyDown = useCallback(async (e: CellKeyDownEvent) => {
    if (!e.event) {
      return;
    }
    const keyboardEvent = e.event as unknown as KeyboardEvent;
    const key = keyboardEvent?.key;
    if (key === 'Enter') {
      const rowNode = e.node;
      const selectedBeneficiary = rowNode?.data as Beneficiary;
      onSelectBeneficiary(selectedBeneficiary);
    }
  }, []);

  const exportCsvHandler = () => {
    const currentDate = getFormattedDate(
      DateTime.now().toISO(),
      'yyyyLLdd',
      'date-time'
    );
    const fileName = `Beneficiaries-${currentDate}.csv`;
    mvTableRef.current?.exportCsv(fileName, true);
  };

  return (
    <div className="mt-2.5">
      {!isStaffPortal() && isUserAuthorizedToCreateBeneficiaries && (
        <Button
          className="font-semibold"
          soft
          look="hero"
          size="small"
          iconSize="small"
          iconBefore={() => <AddIcon size="small" />}
          onClick={onClickAddBeneficiary}
        >
          Add beneficiary
        </Button>
      )}
      {isBeneficiaryListFetching ? (
        <PageLoader iconSize="medium" />
      ) : isBeneficiaryListError ? (
        <ErrorHandler
          onRefresh={onRefresh}
          errorMessage="Something went wrong."
          className="mt-2.5 mb-0"
        />
      ) : (
        <>
          {!isStaffPortal() && (
            <Button
              data-testid="export-transactions-button"
              soft
              className="font-semibold ml-1.5 align-top"
              look="hero"
              size="small"
              type="submit"
              onClick={exportCsvHandler}
            >
              Export beneficiaries
            </Button>
          )}
          <div ref={tableContainerRef}>
            <MVTable
              rowData={formattedListOptions}
              defaultColumnDef={defaultColumnDef}
              onCellClicked={onCellClicked}
              onCellKeyDown={onCellKeyDown}
              columnDefs={columnDefs}
              enableCellTextSelection
              onColumnPinned={onColumnPinned}
              getContextMenuItems={getContextMenuItems}
              noRowMessage={noRowMessage}
              className="mt-2.5"
              columnMenu="legacy"
              ref={mvTableRef}
              onFilterChanged={onFilterChanged}
              containerRef={tableContainerRef}
            />
          </div>
        </>
      )}
    </div>
  );
};

export default BeneficiaryList;
