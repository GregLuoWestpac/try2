import { formatBSB } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import '@testing-library/jest-dom';
import { render, screen } from '@testing-library/react';
import { getFriendlyBeneficiaryStatus } from '../../common/Beneficiary.util';
import { BENEFICIARY_STATUS, BENEFICIARY_TYPE } from '../../store/types';
import {
  buildColumnDefs,
  formatBeneficiaryStatus,
  StatusBadge,
} from './BeneficiaryList.utils';

// Mock @westpac/ui to avoid React child rendering issues
jest.mock('@westpac/ui', () => ({
  Badge: ({ children, ...props }: any) => (
    <span data-testid="badge" {...props}>
      {children}
    </span>
  ),
}));

// Mock dependencies
jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-utils'),
  formatBSB: jest.fn(),
}));

jest.mock('../../common/Beneficiary.util', () => ({
  getFriendlyBeneficiaryStatus: jest.fn(),
}));

describe('buildColumnDefs', () => {
  it('should return an array of column definitions', () => {
    const columnDefs = buildColumnDefs();
    expect(columnDefs).toHaveLength(7); // Ensure all columns are included
  });

  it('should render accountDetails column correctly when BSB is present', () => {
    (formatBSB as jest.Mock).mockReturnValue('123-456');
    const columnDefs = buildColumnDefs();
    const accountDetailsColumn = columnDefs.find(
      col => col.field === 'accountDetails'
    );

    const { container } = render(
      accountDetailsColumn?.valueGetter({
        data: {
          account: {
            accountId: {
              BSB: '123456',
              accountNumber: '987654',
            },
          },
        },
      })
    );

    expect(container.textContent).toBe('123-456 987654');
    expect(formatBSB).toHaveBeenCalledWith('123456', 3);
  });

  it('should render accountDetails column correctly when payIDValue is present', () => {
    const columnDefs = buildColumnDefs();
    const accountDetailsColumn = columnDefs.find(
      col => col.field === 'accountDetails'
    );

    const { container } = render(
      accountDetailsColumn?.valueGetter({
        data: {
          account: {
            payIDValue: 'test@example.com',
          },
        },
      })
    );

    expect(container.textContent).toBe(`${' '}test@example.com`);
  });

  it('should render accountDetails column correctly when BSB is missing but payIDValue is present', () => {
    const columnDefs = buildColumnDefs();
    const accountDetailsColumn = columnDefs.find(
      col => col.field === 'accountDetails'
    );

    const { container } = render(
      accountDetailsColumn?.valueGetter({
        data: {
          account: {
            accountId: {
              accountNumber: '987654',
              // BSB is missing
            },
            payIDValue: 'test@example.com',
          },
        },
      })
    );

    expect(container.textContent).toBe(`${' '}test@example.com`);
  });

  it('should render accountDetails column correctly when accountNumber is missing but payIDValue is present', () => {
    const columnDefs = buildColumnDefs();
    const accountDetailsColumn = columnDefs.find(
      col => col.field === 'accountDetails'
    );

    const { container } = render(
      accountDetailsColumn?.valueGetter({
        data: {
          account: {
            accountId: {
              BSB: '123456',
              // accountNumber is missing
            },
            payIDValue: 'test@example.com',
          },
        },
      })
    );

    expect(container.textContent).toBe(`${' '}test@example.com`);
  });

  it('should render accountDetails column correctly when both BSB and accountNumber are missing', () => {
    const columnDefs = buildColumnDefs();
    const accountDetailsColumn = columnDefs.find(
      col => col.field === 'accountDetails'
    );

    const { container } = render(
      accountDetailsColumn?.valueGetter({
        data: {
          account: {
            accountId: {
              // Both BSB and accountNumber are missing
            },
            payIDValue: 'test@example.com',
          },
        },
      })
    );

    expect(container.textContent).toBe(`${' '}test@example.com`);
  });

  it('should render accountName column correctly when BSB is present', () => {
    const columnDefs = buildColumnDefs();
    const accountNameColumn = columnDefs.find(
      col => col.field === 'accountName'
    );

    const { container } = render(
      accountNameColumn?.valueGetter({
        data: {
          account: {
            bsb: '123456',
            accountName: 'John Doe',
          },
        },
      })
    );

    expect(container.textContent).toBe('John Doe');
  });

  it('should render accountName column correctly when payIDName is present', () => {
    const columnDefs = buildColumnDefs();
    const accountNameColumn = columnDefs.find(
      col => col.field === 'accountName'
    );

    const { container } = render(
      accountNameColumn?.valueGetter({
        data: {
          account: {
            payIDName: 'Test PayID',
          },
        },
      })
    );

    expect(container.textContent).toBe('Test PayID');
  });

  it('should render accountName column correctly when accountName is missing but payIDName is present', () => {
    const columnDefs = buildColumnDefs();
    const accountNameColumn = columnDefs.find(
      col => col.field === 'accountName'
    );

    const { container } = render(
      accountNameColumn?.valueGetter({
        data: {
          account: {
            // accountName is missing
            payIDName: 'Fallback PayID Name',
          },
        },
      })
    );

    expect(container.textContent).toBe('Fallback PayID Name');
  });

  it('should render accountName column correctly when accountName is empty but payIDName is present', () => {
    const columnDefs = buildColumnDefs();
    const accountNameColumn = columnDefs.find(
      col => col.field === 'accountName'
    );

    const result = (accountNameColumn?.valueGetter as any)({
      data: {
        account: {
          accountName: '', // empty accountName
          payIDName: 'Fallback PayID Name',
        },
      },
    });

    const { container } = render(result);
    expect(container.textContent).toBe('Fallback PayID Name');
  });

  it('should render accountName column correctly when accountName is null', () => {
    const columnDefs = buildColumnDefs();
    const accountNameColumn = columnDefs.find(
      col => col.field === 'accountName'
    );

    const result = (accountNameColumn?.valueGetter as any)({
      data: {
        account: {
          accountName: null, // null accountName
          payIDName: 'Fallback PayID Name',
        },
      },
    });

    const { container } = render(result);
    expect(container.textContent).toBe('Fallback PayID Name');
  });

  it('should render accountName column correctly when accountName is false', () => {
    const columnDefs = buildColumnDefs();
    const accountNameColumn = columnDefs.find(
      col => col.field === 'accountName'
    );

    const result = (accountNameColumn?.valueGetter as any)({
      data: {
        account: {
          accountName: false, // false accountName
          payIDName: 'Fallback PayID Name',
        },
      },
    });

    const { container } = render(result);
    expect(container.textContent).toBe('Fallback PayID Name');
  });

  it('should render accountName column correctly when accountName is 0', () => {
    const columnDefs = buildColumnDefs();
    const accountNameColumn = columnDefs.find(
      col => col.field === 'accountName'
    );

    const result = (accountNameColumn?.valueGetter as any)({
      data: {
        account: {
          accountName: 0, // 0 accountName (falsy)
          payIDName: 'Fallback PayID Name',
        },
      },
    });

    const { container } = render(result);
    expect(container.textContent).toBe('Fallback PayID Name');
  });

  it('should render accountDetails column correctly when BSB is empty string but accountNumber exists', () => {
    (formatBSB as jest.Mock).mockReturnValue('');
    const columnDefs = buildColumnDefs();
    const accountDetailsColumn = columnDefs.find(
      col => col.field === 'accountDetails'
    );

    const result = (accountDetailsColumn?.valueGetter as any)({
      data: {
        account: {
          accountId: {
            BSB: '', // empty BSB
            accountNumber: '987654',
          },
          payIDValue: 'test@example.com',
        },
      },
    });

    const { container } = render(result);
    expect(container.textContent).toBe(`${' '}test@example.com`);
  });

  it('should render accountDetails column correctly when BSB is null', () => {
    const columnDefs = buildColumnDefs();
    const accountDetailsColumn = columnDefs.find(
      col => col.field === 'accountDetails'
    );

    const result = (accountDetailsColumn?.valueGetter as any)({
      data: {
        account: {
          accountId: {
            BSB: null, // null BSB
            accountNumber: '987654',
          },
          payIDValue: 'test@example.com',
        },
      },
    });

    const { container } = render(result);
    expect(container.textContent).toBe(`${' '}test@example.com`);
  });

  it('should set the correct properties for the Currency column', () => {
    const columnDefs = buildColumnDefs();
    const currencyCol = columnDefs.find(col => col.field === 'currency');
    expect(currencyCol?.minWidth).toBe(56);
    expect(currencyCol?.width).toBe(60);
    expect(currencyCol?.filterParams).toEqual({ filterOptions: ['contains'] });
    expect(currencyCol?.headerClass).toBe(
      'font-semibold !pr-[0px] right-aligned-header default-header !text-[0.8125rem] whitespace-nowrap'
    );
    expect(currencyCol?.columnIndex).toBe(3);
  });

  it('should render accountDetails column correctly when accountNumber is empty string', () => {
    (formatBSB as jest.Mock).mockReturnValue('123-456');
    const columnDefs = buildColumnDefs();
    const accountDetailsColumn = columnDefs.find(
      col => col.field === 'accountDetails'
    );

    const result = (accountDetailsColumn?.valueGetter as any)({
      data: {
        account: {
          accountId: {
            BSB: '123456',
            accountNumber: '', // empty accountNumber
          },
          payIDValue: 'test@example.com',
        },
      },
    });

    const { container } = render(result);
    expect(container.textContent).toBe(`${' '}test@example.com`);
  });

  it('should render accountDetails column correctly when accountNumber is null', () => {
    const columnDefs = buildColumnDefs();
    const accountDetailsColumn = columnDefs.find(
      col => col.field === 'accountDetails'
    );

    const result = (accountDetailsColumn?.valueGetter as any)({
      data: {
        account: {
          accountId: {
            BSB: '123456',
            accountNumber: null, // null accountNumber
          },
          payIDValue: 'test@example.com',
        },
      },
    });

    const { container } = render(result);
    expect(container.textContent).toBe(`${' '}test@example.com`);
  });

  it('should render accountDetails column correctly when BSB is false', () => {
    const columnDefs = buildColumnDefs();
    const accountDetailsColumn = columnDefs.find(
      col => col.field === 'accountDetails'
    );

    const result = (accountDetailsColumn?.valueGetter as any)({
      data: {
        account: {
          accountId: {
            BSB: false, // false BSB
            accountNumber: '987654',
          },
          payIDValue: 'test@example.com',
        },
      },
    });

    const { container } = render(result);
    expect(container.textContent).toBe(`${' '}test@example.com`);
  });

  it('should render accountDetails column correctly when accountNumber is false', () => {
    const columnDefs = buildColumnDefs();
    const accountDetailsColumn = columnDefs.find(
      col => col.field === 'accountDetails'
    );

    const result = (accountDetailsColumn?.valueGetter as any)({
      data: {
        account: {
          accountId: {
            BSB: '123456',
            accountNumber: false, // false accountNumber
          },
          payIDValue: 'test@example.com',
        },
      },
    });

    const { container } = render(result);
    expect(container.textContent).toBe(`${' '}test@example.com`);
  });
});

describe('type column', () => {
  it('should render type column correctly for ACCOUNT type', () => {
    const columnDefs = buildColumnDefs();
    const typeColumn = columnDefs.find(col => col.field === 'type');

    const result = (typeColumn?.valueGetter as any)({
      data: {
        type: BENEFICIARY_TYPE.ACCOUNT,
      },
    });

    const { container } = render(result);
    expect(container.textContent).toBe('BSB & account number');
  });

  it('should render type column correctly for PAYID type', () => {
    const columnDefs = buildColumnDefs();
    const typeColumn = columnDefs.find(col => col.field === 'type');

    const result = (typeColumn?.valueGetter as any)({
      data: {
        type: BENEFICIARY_TYPE.PAYID,
      },
    });

    const { container } = render(result);
    expect(container.textContent).toBe('PayID');
  });
});

describe('StatusBadge', () => {
  it('should render StatusBadge correctly', () => {
    (getFriendlyBeneficiaryStatus as jest.Mock).mockReturnValue({
      text: 'Active',
      badgeColor: 'success',
    });

    const mockParams = {
      data: { status: BENEFICIARY_STATUS.ACTIVE },
      value: 'test',
      valueFormatted: 'test',
      node: {} as any,
      eGridCell: {} as any,
      eParentOfValue: {} as any,
      column: {} as any,
      api: {} as any,
      context: {},
      registerRowDragger: jest.fn(),
      setTooltip: jest.fn(),
    };

    render(<StatusBadge {...mockParams} />);
    expect(screen.getByText('Active')).toBeInTheDocument();
    expect(getFriendlyBeneficiaryStatus).toHaveBeenCalledWith(
      BENEFICIARY_STATUS.ACTIVE
    );
  });

  it('should render StatusBadge correctly for ARCHIVED status', () => {
    (getFriendlyBeneficiaryStatus as jest.Mock).mockReturnValue({
      text: 'Archived',
      badgeColor: 'neutral',
    });

    const mockParams = {
      data: { status: BENEFICIARY_STATUS.ARCHIVED },
      value: 'test',
      valueFormatted: 'test',
      node: {} as any,
      eGridCell: {} as any,
      eParentOfValue: {} as any,
      column: {} as any,
      api: {} as any,
      context: {},
      registerRowDragger: jest.fn(),
      setTooltip: jest.fn(),
    };

    render(<StatusBadge {...mockParams} />);
    expect(screen.getByText('Archived')).toBeInTheDocument();
    expect(getFriendlyBeneficiaryStatus).toHaveBeenCalledWith(
      BENEFICIARY_STATUS.ARCHIVED
    );
  });
});

describe('formatBeneficiaryStatus', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should return the correct label for ACTIVE status', () => {
    // Mock the implementation of getFriendlyBeneficiaryStatus
    (getFriendlyBeneficiaryStatus as jest.Mock).mockImplementation(status => {
      if (status === BENEFICIARY_STATUS.ACTIVE) {
        return { text: 'Active', badgeColor: 'green' };
      }
      if (status === BENEFICIARY_STATUS.ARCHIVED) {
        return { text: 'Archived', badgeColor: 'gray' };
      }
      return { text: 'Unknown', badgeColor: 'red' };
    });

    const result = formatBeneficiaryStatus({
      value: BENEFICIARY_STATUS.ACTIVE,
    });
    expect(result).toBe('Active');
    expect(getFriendlyBeneficiaryStatus).toHaveBeenCalledWith(
      BENEFICIARY_STATUS.ACTIVE
    );
  });
  it('should return the correct label for ARCHIVED status', () => {
    (getFriendlyBeneficiaryStatus as jest.Mock).mockImplementation(status => {
      if (status === BENEFICIARY_STATUS.ACTIVE) {
        return { text: 'Active', badgeColor: 'green' };
      }
      if (status === BENEFICIARY_STATUS.ARCHIVED) {
        return { text: 'Archived', badgeColor: 'gray' };
      }
      return { text: 'Unknown', badgeColor: 'red' };
    });

    const result = formatBeneficiaryStatus({
      value: BENEFICIARY_STATUS.ARCHIVED,
    });
    expect(result).toBe('Archived');
    expect(getFriendlyBeneficiaryStatus).toHaveBeenCalledWith(
      BENEFICIARY_STATUS.ARCHIVED
    );
  });
});
