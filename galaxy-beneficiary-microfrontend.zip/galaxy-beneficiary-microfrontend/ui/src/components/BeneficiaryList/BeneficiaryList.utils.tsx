/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable react/destructuring-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import {
  COMMON_COLUMN_DEFS,
  ColDefV2 as ColDef,
  CustomCellRendererPropsV2 as CustomCellRendererProps,
  CustomColDef,
} from '@mesh-tenant-multiverse-ui-common/mv-table-v2';
import { formatBSB } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { Badge } from '@westpac/ui';
import { getFriendlyBeneficiaryStatus } from '../../common/Beneficiary.util';
import { BENEFICIARY_STATUS, BENEFICIARY_TYPE } from '../../store/types';

export function StatusBadge(params: CustomCellRendererProps) {
  const { status } = params.data;
  const statusFriendlyValue = getFriendlyBeneficiaryStatus(status);
  return (
    <Badge color={statusFriendlyValue.badgeColor} soft>
      {statusFriendlyValue.text}
    </Badge>
  );
}

export const formatBeneficiaryStatus = (params: { value: string }) => {
  return getFriendlyBeneficiaryStatus(params.value as BENEFICIARY_STATUS).text;
};

const CUSTOM_COMMON_DEFS: { [key: string]: (params?: any) => CustomColDef } =
  Object.fromEntries(
    Object.entries(COMMON_COLUMN_DEFS).map(([key, fn]) => [
      key,
      (params?: any) => ({ ...(fn(params) as ColDef) }),
    ])
  ) as { [key: string]: (params?: any) => CustomColDef };

const {
  beneficiaryNickname,
  accountDetails,
  accountName,
  currency,
  type,
  status,
  actions,
} = CUSTOM_COMMON_DEFS;

export const buildColumnDefs = (): CustomColDef[] => {
  return [
    beneficiaryNickname({
      minWidth: 250,
      width: 300,
      sort: 'asc',
      flex: 1,
    }),
    accountDetails({
      minWidth: 82,
      width: 250,
      flex: 1,
      valueGetter: (params: any) => {
        const account = params?.data?.account || {};
        const accountId = account?.accountId || {};
        const { BSB, accountNumber } = accountId;
        const { payIDValue } = account;

        return BSB && accountNumber
          ? `${formatBSB(BSB, 3)} ${accountNumber}`
          : `${' '}${payIDValue}`;
      },
    }),
    accountName({
      minWidth: 82,
      width: 250,
      flex: 1,
      valueGetter: (params: any) => {
        const account = params?.data?.account || {};
        const { accountName, payIDName } = account;
        return accountName ? accountName : payIDName;
      },
    }),
    currency({
      minWidth: 56,
      width: 60,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'],
      },
      headerClass: 'whitespace-nowrap',
      resizable: false,
    }),
    type({
      minWidth: 60,
      maxWidth: 163,
      flex: 1,
      valueGetter: (params: any) =>
        params?.data?.type === BENEFICIARY_TYPE.ACCOUNT
          ? 'BSB & account number'
          : 'PayID',
      filter: 'agSetColumnFilter',
      filterParams: {
        suppressSelectAll: true,
        suppressMiniFilter: true,
      },
    }),
    status({
      minWidth: 82,
      width: 100,
      cellRenderer: StatusBadge,
      sortable: true,
      filter: 'agSetColumnFilter',
      filterParams: {
        values: [BENEFICIARY_STATUS.ACTIVE, BENEFICIARY_STATUS.ARCHIVED],
        suppressSelectAll: true,
        suppressMiniFilter: true,
        valueFormatter: formatBeneficiaryStatus,
      },
      suppressColumnsToolPanel: false,
    }),
    actions({
      minWidth: 80,
      maxWidth: 80,
      suppressMovable: false,
      lockPosition: false,
      lockPinned: false,
      menuTabs: ['generalMenuTab'],
      pinned: false,
      excludeFromExport: true,
    }),
  ].map((col, index) => {
    return { ...col, columnIndex: index } as CustomColDef;
  });
};
