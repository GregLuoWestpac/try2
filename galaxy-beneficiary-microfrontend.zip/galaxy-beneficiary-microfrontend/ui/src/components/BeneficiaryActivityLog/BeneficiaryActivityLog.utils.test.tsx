/* eslint-disable react/react-in-jsx-scope */
/* eslint-disable @typescript-eslint/no-explicit-any */
import React from 'react';
import { render, screen } from '@testing-library/react';
import {
  getUserFriendlyBeneficiaryActionText,
  columnDefs,
  beneSubtitle,
} from './BeneficiaryActivityLog.utils';
import { BENEFICIARY_TYPE } from '../../store/types';
describe('BeneficiaryActivityLog.utils', () => {
  describe('beneSubtitle', () => {
    it('formats ACCOUNT beneficiary subtitle with dashed BSB and account number', () => {
      const beneficiary: any = {
        nickname: 'Test Bene',
        type: BENEFICIARY_TYPE.ACCOUNT,
        account: { accountId: { BSB: '062948', accountNumber: '222227777' } },
      };
      const subtitle = beneSubtitle(beneficiary);
      expect(subtitle).toBe('Test Bene - 062-948 222227777');
    });

    it('formats PAYID beneficiary subtitle with payIDValue', () => {
      const beneficiary: any = {
        nickname: 'PayID Bene',
        type: BENEFICIARY_TYPE.PAYID,
        account: { payIDValue: 'payid@example.com' },
      };
      const subtitle = beneSubtitle(beneficiary);
      expect(subtitle).toBe('PayID Bene - payid@example.com');
    });

    it('returns empty string when beneficiary is null/undefined', () => {
      expect(beneSubtitle(null)).toBe('');
      expect(beneSubtitle(undefined)).toBe('');
    });
  });
  describe('getUserFriendlyBeneficiaryActionText', () => {
    it('returns correct text for beneficiaryCreate', () => {
      expect(getUserFriendlyBeneficiaryActionText('beneficiaryCreate')).toBe(
        'Add beneficiary'
      );
    });

    it('returns correct text for beneficiaryUpdate', () => {
      expect(getUserFriendlyBeneficiaryActionText('beneficiaryUpdate')).toBe(
        'Update beneficiary'
      );
    });

    it('returns correct text for beneficiaryArchive', () => {
      expect(getUserFriendlyBeneficiaryActionText('beneficiaryArchive')).toBe(
        'Archive beneficiary'
      );
    });

    it('returns the action as-is for unknown action', () => {
      expect(getUserFriendlyBeneficiaryActionText('unknownAction')).toBe(
        'unknownAction'
      );
    });
  });

  describe('BeneficiaryActivityDetailCellTable cellRenderer', () => {
    // Get the BeneficiaryActivityDetailCellTable component from columnDefs
    const detailsColumn = columnDefs.find(col => col.field === 'details');
    const BeneficiaryActivityDetailCellTable =
      detailsColumn?.cellRenderer as React.ComponentType<any>;

    it('renders table with activity details', () => {
      const mockData = {
        details: {
          accountDetail: '062-948 222227777',
          accountName: 'Test Account',
          beneficiaryNickname: 'Test Beneficiary',
          currency: 'AUD',
          amount: '$100.00',
          reference: 'Test Reference',
        },
      };

      const { container } = render(
        <BeneficiaryActivityDetailCellTable data={mockData} />
      );

      expect(container.querySelector('table')).toBeInTheDocument();
      expect(screen.getByText('Account detail')).toBeInTheDocument();
      expect(screen.getByText('062-948 222227777')).toBeInTheDocument();
      expect(screen.getByText('Account name')).toBeInTheDocument();
      expect(screen.getByText('Test Account')).toBeInTheDocument();
      expect(screen.getByText('Beneficiary nickname')).toBeInTheDocument();
      expect(screen.getByText('Test Beneficiary')).toBeInTheDocument();
      expect(screen.getByText('Currency')).toBeInTheDocument();
      expect(screen.getByText('AUD')).toBeInTheDocument();
      expect(screen.getByText('Amount')).toBeInTheDocument();
      expect(screen.getByText('$100.00')).toBeInTheDocument();
      expect(screen.getByText('Reference')).toBeInTheDocument();
      expect(screen.getByText('Test Reference')).toBeInTheDocument();
    });

    it('renders unknown keys as-is', () => {
      const mockData = {
        details: {
          unknownField: 'Unknown Value',
        },
      };

      render(<BeneficiaryActivityDetailCellTable data={mockData} />);

      expect(screen.getByText('unknownField')).toBeInTheDocument();
      expect(screen.getByText('Unknown Value')).toBeInTheDocument();
    });

    it('returns null when details is empty', () => {
      const mockData = {
        details: {},
      };

      const { container } = render(
        <BeneficiaryActivityDetailCellTable data={mockData} />
      );

      expect(container.firstChild).toBeNull();
    });

    it('returns null when details is null', () => {
      const mockData = {
        details: null,
      };

      const { container } = render(
        <BeneficiaryActivityDetailCellTable data={mockData} />
      );

      expect(container.firstChild).toBeNull();
    });

    it('returns null when details is not an object', () => {
      const mockData = {
        details: 'string value',
      };

      const { container } = render(
        <BeneficiaryActivityDetailCellTable data={mockData} />
      );

      expect(container.firstChild).toBeNull();
    });
  });

  describe('columnDefs', () => {
    it('contains expected columns', () => {
      expect(columnDefs).toHaveLength(5);
      expect(columnDefs.map(col => col.field)).toEqual([
        'date',
        'user',
        'activity',
        'activityStatus',
        'details',
      ]);
    });

    it('date column is sortable by default with ascending sort', () => {
      const dateColumn = columnDefs.find(col => col.field === 'date');
      expect(dateColumn?.sort).toBe('asc');
    });

    it('details column has cellRenderer', () => {
      const detailsColumn = columnDefs.find(col => col.field === 'details');
      expect(detailsColumn?.cellRenderer).toBeDefined();
    });
  });
});
