/* eslint-disable react/react-in-jsx-scope */
import React from 'react';
import { render } from '@testing-library/react';
import BeneficiaryActivityLog from './BeneficiaryActivityLog';

// Mock ResizeObserver
global.ResizeObserver = jest.fn().mockImplementation(() => ({
  observe: jest.fn(),
  unobserve: jest.fn(),
  disconnect: jest.fn(),
}));

describe('BeneficiaryActivityLog', () => {
  it('renders without crashing', () => {
    const mockProps = {
      beneficiaryActivityDetails: [],
    };

    render(<BeneficiaryActivityLog {...mockProps} />);
  });

  it('renders activity details with activityDetail', () => {
    const mockProps = {
      beneficiaryActivityDetails: [
        {
          date: '2024-01-01',
          user: 'John Doe',
          activity: 'Payment Made',
          activityStatus: 'Completed',
          activityDetail: {
            accountDetail: '123456789',
            accountName: 'Test Account',
            beneficiaryNickname: 'Test Beneficiary',
            currency: 'USD',
            amount: '100.00',
            reference: 'REF123',
          },
        },
      ],
    };

    const { container } = render(<BeneficiaryActivityLog {...mockProps} />);
    expect(container).toBeTruthy();
  });

  it('renders activity details without activityDetail', () => {
    const mockProps = {
      beneficiaryActivityDetails: [
        {
          date: '2024-01-01',
          user: 'Jane Doe',
          activity: 'Status Changed',
          activityStatus: 'Pending',
        },
      ],
    };

    const { container } = render(<BeneficiaryActivityLog {...mockProps} />);
    expect(container).toBeTruthy();
  });

  it('renders activity details with activityDetail but missing optional fields', () => {
    const mockProps = {
      beneficiaryActivityDetails: [
        {
          date: '2024-01-02',
          user: 'Test User',
          activity: 'Transfer',
          activityStatus: 'Success',
          activityDetail: {
            accountDetail: '987654321',
            accountName: 'Another Account',
            beneficiaryNickname: 'Another Beneficiary',
            currency: 'EUR',
          },
        },
      ],
    };

    const { container } = render(<BeneficiaryActivityLog {...mockProps} />);
    expect(container).toBeTruthy();
  });
});
