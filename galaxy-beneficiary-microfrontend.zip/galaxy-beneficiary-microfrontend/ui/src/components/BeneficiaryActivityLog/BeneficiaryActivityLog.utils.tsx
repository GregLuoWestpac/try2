import React from 'react';
import {
  CustomColDef,
  CustomCellRendererPropsV2 as CustomCellRendererProps,
} from '@mesh-tenant-multiverse-ui-common/mv-table-v2';
import { Beneficiary, BENEFICIARY_TYPE } from '../../store/types';

export const beneSubtitle = (beneficiary: Beneficiary) => {
  if (!beneficiary) return '';
  if (beneficiary.type === BENEFICIARY_TYPE.ACCOUNT) {
    let bsb = beneficiary.account.accountId.BSB;
    return `${beneficiary.nickname} - ${bsb.slice(0, 3)}-${bsb.slice(3)} ${
      beneficiary.account.accountId.accountNumber
    }`;
  }
  if (beneficiary.type === BENEFICIARY_TYPE.PAYID) {
    return `${beneficiary.nickname} - ${beneficiary.account?.payIDValue}`;
  }
  return '';
};

const getUserFriendlyActivityDetailKeyName = (key: string) => {
  switch (key) {
    case 'accountDetail':
      return 'Account detail';
    case 'accountName':
      return 'Account name';
    case 'beneficiaryNickname':
      return 'Beneficiary nickname';
    case 'currency':
      return 'Currency';
    case 'amount':
      return 'Amount';
    case 'reference':
      return 'Reference';
    default:
      return key;
  }
};

export const getUserFriendlyBeneficiaryActionText = (action: string) => {
  switch (action) {
    case 'beneficiaryCreate':
      return 'Add beneficiary';
    case 'beneficiaryUpdate':
      return 'Update beneficiary';
    case 'beneficiaryArchive':
      return 'Archive beneficiary';
    default:
      return action;
  }
};

// eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access
function BeneficiaryActivityDetailCellTable({
  data: { details: beneficiaryActivityLogDetails },
}: CustomCellRendererProps) {
  // Guard against empty or invalid details
  // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
  if (
    !beneficiaryActivityLogDetails ||
    typeof beneficiaryActivityLogDetails !== 'object' ||
    Object.keys(beneficiaryActivityLogDetails).length === 0
  ) {
    return null;
  }

  return (
    <table>
      <tbody>
        {/* eslint-disable-next-line @typescript-eslint/no-unsafe-argument */}
        {Object.entries(beneficiaryActivityLogDetails).map(([key, value]) => (
          <tr key={key}>
            <td className="pr-2.5 align-top whitespace-nowrap">
              {getUserFriendlyActivityDetailKeyName(key)}
            </td>
            <td className="align-top break-normal">{value as string}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export const columnDefs: CustomColDef[] = [
  {
    field: 'date',
    headerName: 'Date',
    minWidth: 120,
    maxWidth: 120,
    sort: 'asc',
    sortable: false,
    suppressHeaderMenuButton: true,
    flex: 1,
  },
  {
    field: 'user',
    minWidth: 50,
    maxWidth: 150,
    sortable: false,
    suppressHeaderMenuButton: true,
  },
  {
    field: 'activity',
    minWidth: 90,
    maxWidth: 150,
    flex: 1,
    sortable: false,
    suppressHeaderMenuButton: true,
    cellClass: 'font-semibold',
    cellRenderer: (props: CustomCellRendererProps) => {
      const activityType = props.value;
      return <span>{getUserFriendlyBeneficiaryActionText(activityType)}</span>;
    },
  },
  {
    field: 'activityStatus',
    headerName: 'Activity status',
    wrapHeaderText: false,
    minWidth: 110,
    maxWidth: 150,
    sortable: false,
    suppressHeaderMenuButton: true,
    flex: 1,
  },
  {
    field: 'details',
    sortable: false,
    suppressHeaderMenuButton: true,
    cellRenderer: BeneficiaryActivityDetailCellTable,
    minWidth: 250,
    flex: 2, // Give details column more space since it contains nested table
  },
];
