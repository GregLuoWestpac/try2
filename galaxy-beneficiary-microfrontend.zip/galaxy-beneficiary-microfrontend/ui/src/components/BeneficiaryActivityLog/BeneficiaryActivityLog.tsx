/* eslint-disable no-nested-ternary */
/* eslint-disable react/no-unstable-nested-components */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable react/function-component-definition */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unused-expressions */
import {
  ColDefV2 as ColDef,
  MVTableV2 as MVTable,
  onColumnPinnedV2 as onColumnPinned,
  suppressHeaderKeyboardEventV2 as suppressHeaderKeyboardEvent,
  suppressKeyboardEventV2 as suppressKeyboardEvent,
} from '@mesh-tenant-multiverse-ui-common/mv-table-v2';
import React, { useRef } from 'react';
import { noRowMessage } from '../../common';
import { BeneficiaryActivityLogEntryType } from '../../common/Beneficiary.util';
import { columnDefs } from './BeneficiaryActivityLog.utils';

export type BeneficiaryActivityLogProps = {
  beneficiaryActivityDetails: BeneficiaryActivityLogEntryType[];
};

const BeneficiaryActivityLog: React.FC<BeneficiaryActivityLogProps> = ({
  beneficiaryActivityDetails,
}) => {
  const tableContainerRef = useRef<HTMLDivElement>(null);

  const defaultColumnDef: ColDef = {
    menuTabs: ['generalMenuTab', 'filterMenuTab', 'columnsMenuTab'],
    filter: 'agTextColumnFilter',
    filterParams: {
      buttons: ['reset'],
      filterOptions: ['contains'],
    },
    suppressKeyboardEvent,
    suppressHeaderKeyboardEvent,
    suppressHeaderContextMenu: true,
    suppressHeaderFilterButton: false,
    suppressHeaderMenuButton: false,
    headerClass: '!text-[0.8125rem] whitespace-nowrap [word-spacing:normal]',
  };

  const formattedListOptions = beneficiaryActivityDetails.map(option => ({
    date: option.date,
    user: option.user,
    activity: option.activity,
    activityStatus: option.activityStatus,
    details: option.activityDetail
      ? {
          accountDetail: option.activityDetail.accountDetail,
          accountName: option.activityDetail.accountName,
          beneficiaryNickname: option.activityDetail.beneficiaryNickname,
          currency: option.activityDetail.currency,
          amount: option.activityDetail.amount ?? '',
          reference: option.activityDetail.reference ?? '',
        }
      : {},
  }));

  return (
    <div
      ref={tableContainerRef}
      className="w-full overflow-x-auto"
      style={{ minWidth: '100%' }}
    >
      <MVTable
        rowData={formattedListOptions}
        defaultColumnDef={defaultColumnDef}
        columnDefs={columnDefs}
        enableCellTextSelection
        onColumnPinned={onColumnPinned}
        noRowMessage={noRowMessage}
        className="mt-2.5"
        columnMenu="legacy"
        autoSizeStrategy={{
          type: 'fitCellContents',
          skipHeader: true,
          colIds: ['user', 'activity', 'activityStatus'],
        }}
        containerRef={tableContainerRef}
      />
    </div>
  );
};

export default BeneficiaryActivityLog;
