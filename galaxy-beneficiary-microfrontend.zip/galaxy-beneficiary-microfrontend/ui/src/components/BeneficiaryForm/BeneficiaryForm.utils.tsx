/* eslint-disable consistent-return */
import { v4 } from 'uuid';
import { RegisterOptions } from 'react-hook-form';
import {
  getFormattedForbiddenCharacters,
  validateWithLibrary,
} from '@mesh-tenant-multiverse-ui-common/mv-injection-checker';
import { formatToTwoDecimals } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import {
  COP_COLOR_CODE,
  CoPApiStatusCode,
} from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
import {
  buildBeneficiaryCreateEntitlement,
  buildBeneficiaryUpdateEntitlement,
} from 'ui/src/common/Beneficiary.util';
import { FormValues } from './BeneficiaryForm.types';
import {
  AUTHBIC8,
  CURRENCY,
  ERROR_MESSAGES,
  REGEX_PATTERN,
  forbiddenCharacterErrorMessage,
} from '../../common/constants';
import {
  Beneficiary,
  BENEFICIARY_TYPE,
  GetBSBLookupParamsPayload,
  PayIDTypeValue,
  PAYID_TYPE,
  PostAliaLookupParamsPayload,
  UpdateBeneficiary,
} from '../../store/types';
import { PayID } from '../../store/types/AliasLookup';
import { Currency } from '../../store/types/Beneficiary';

/**
 * Checks if an amount value is valid (not undefined, empty, whitespace-only, or non-numeric)
 * @param amount - The amount string to validate
 * @returns true if the amount is valid, false otherwise
 */
export const isValidAmount = (amount: string | undefined | null): boolean => {
  if (amount === undefined || amount === null) {
    return false;
  }
  const trimmed = String(amount).trim();
  if (trimmed === '') {
    return false;
  }
  // Check if it's a valid number
  const numValue = Number(trimmed);
  return !Number.isNaN(numValue) && Number.isFinite(numValue);
};

/**
 * Sanitizes currencyAmount object by removing the amount property if it's invalid
 * (undefined, empty string, whitespace-only, or not a valid number)
 * @param currencyAmount - The currency amount object to sanitize
 * @returns A sanitized currency amount object with amount omitted if invalid
 */
export const sanitizeCurrencyAmount = (
  currencyAmount: Currency | undefined
): Partial<Currency> | undefined => {
  if (!currencyAmount) {
    return undefined;
  }
  const { amount, currencyCode } = currencyAmount;
  if (isValidAmount(amount)) {
    return {
      currencyCode,
      amount,
    };
  }
  // Return only currencyCode if amount is invalid
  return {
    currencyCode,
  };
};

// BeneficiaryForm-specific utility functions moved from Beneficiary.util.ts

export const getPayIDValueFromEditForm = (fields: PayIDTypeValue) => {
  const { email, organisationId, phone, abnAcn, payIdType } = fields;
  const payIdMap = {
    EMAL: email,
    ORGN: organisationId,
    AUBN: abnAcn,
    TELI: phone,
  };
  const value = payIdMap[payIdType as keyof typeof payIdMap];
  return value?.trim() || '';
};

export const getDefaultFormValues = (
  beneficiary: Beneficiary | undefined
): FormValues => {
  const defaultValues = {
    beneficiaryType: undefined,
    payIdType: undefined,
    payIdName: undefined,
    bsb: '',
    bankName: '',
    accountNumber: '',
    accountName: '',
    beneficiaryNickname: '',
    currency: CURRENCY.AUD,
    phone: '',
    email: '',
    abnAcn: '',
    organisationId: '',
    account: undefined,
    amount: '',
    toReference: '',
  };
  const type = beneficiary?.type;
  if (type === BENEFICIARY_TYPE.ACCOUNT && beneficiary) {
    const { accountId, bankName, accountName } = beneficiary.account || {};
    const { BSB, accountNumber } = accountId || {};
    const bsb = BSB;
    return {
      ...defaultValues,
      beneficiaryType: type,
      bsb,
      bankName,
      accountNumber,
      accountName,
      beneficiaryNickname: beneficiary.nickname,
      currency:
        beneficiary.currency ??
        beneficiary?.currencyAmount?.currencyCode ??
        CURRENCY.AUD,
      amount: beneficiary?.currencyAmount?.amount ?? '',
      toReference: beneficiary.reference || '',
    };
  }
  if (type === BENEFICIARY_TYPE.PAYID && beneficiary) {
    const { payIDName, payIDType, payIDValue } = beneficiary.account || {};

    // Map payIDValue to the correct form field based on payIDType
    const payIdFieldMapping: Record<string, Partial<FormValues>> = {
      [PAYID_TYPE.PHONE]: { phone: payIDValue },
      [PAYID_TYPE.EMAIL]: { email: payIDValue },
      [PAYID_TYPE.ABN_ACN]: { abnAcn: payIDValue },
      [PAYID_TYPE.ORGANISATION_ID]: { organisationId: payIDValue },
    };

    return {
      ...defaultValues,
      beneficiaryType: type,
      payIdName: payIDName,
      payIdType: payIDType,
      ...payIdFieldMapping[payIDType],
      beneficiaryNickname: beneficiary.nickname,
      currency:
        beneficiary.currency ??
        beneficiary?.currencyAmount?.currencyCode ??
        CURRENCY.AUD,
      amount: beneficiary?.currencyAmount?.amount ?? '',
      toReference: beneficiary.reference || '',
    };
  }
  return defaultValues;
};

export const mapBeneficiaries = (
  formData: FormValues,
  matchedCOPStatusCode?: CoPApiStatusCode,
  matchedCOPAccountName?: string,
  matchedCOPColour?: COP_COLOR_CODE
) => {
  // Ensure beneficiaryType is defined
  if (!formData?.beneficiaryType) {
    throw new Error('Beneficiary type is required');
  }

  const { amount, currency } = formData || {};

  const beneficiary: any = {
    id: v4(),
    nickname: formData?.beneficiaryNickname,
    ...(formData.divisions && {
      divisionId: formData?.divisions?.id,
      divisionName: formData?.divisions?.name,
    }),
    type: formData.beneficiaryType,
    reference: formData?.toReference || '',
    ...(matchedCOPStatusCode && { matchedCOPStatusCode }),
    ...(matchedCOPAccountName && { matchedCOPAccountName }),
    account:
      formData.beneficiaryType === BENEFICIARY_TYPE.PAYID
        ? {
            payIDName: formData?.payIdName,
            payIDType: formData?.payIdType,
            payIDValue:
              formData?.payIdType === PAYID_TYPE.PHONE
                ? formData.phone.replace(/\s/g, '')
                : formData?.payIdType === PAYID_TYPE.EMAIL
                ? formData.email
                : formData?.payIdType === PAYID_TYPE.ABN_ACN
                ? formData.abnAcn
                : formData.organisationId,
          }
        : {
            accountId: {
              BSB: formData?.bsb,
              accountNumber: formData?.accountNumber ?? '',
            },
            accountName: formData?.accountName ?? '',
            bankName: formData?.bankName ?? '',
          },
    currencyAmount: {
      currencyCode: currency || CURRENCY.AUD,
      ...(amount &&
        isValidAmount(amount) && { amount: formatToTwoDecimals(amount) }),
    },
    entitlementData: buildBeneficiaryCreateEntitlement(
      formData,
      matchedCOPColour
    ),
  };

  return {
    beneficiaries: [beneficiary],
  };
};

export const mapUpdateBeneficiaryParams = (
  formData: FormValues,
  beneficiaryToBeUpdated: Beneficiary,
  matchedCOPStatusCode?: CoPApiStatusCode,
  matchedCOPAccountName?: string,
  matchedCOPColour?: COP_COLOR_CODE
) => {
  const { id, externalId, currency } = beneficiaryToBeUpdated;
  const {
    accountName,
    accountNumber,
    bankName,
    bsb,
    email,
    organisationId,
    phone,
    abnAcn,
    payIdType,
  } = formData;
  const updateAmount = formData?.amount;
  const payload: UpdateBeneficiary = {
    id,
    externalId,
    nickname: formData.beneficiaryNickname,
    type: formData.beneficiaryType,
    currencyAmount: {
      currencyCode: currency || CURRENCY.AUD,
      ...(updateAmount &&
        isValidAmount(updateAmount) && {
          amount: formatToTwoDecimals(updateAmount),
        }),
    } as Currency,
    reference: formData?.toReference || '',
    ...(matchedCOPStatusCode && { matchedCOPStatusCode }),
    ...(matchedCOPAccountName && { matchedCOPAccountName }),
    account:
      formData.beneficiaryType === BENEFICIARY_TYPE.PAYID && payIdType
        ? {
            payIDType: payIdType,
            payIDValue:
              getPayIDValueFromEditForm({
                payIdType,
                email,
                organisationId,
                phone,
                abnAcn,
              }) || '',
            payIDName: formData.payIdName as string,
          }
        : {
            accountId: {
              BSB: bsb,
              accountNumber,
            },
            bankName,
            accountName,
          },
    entitlementData: buildBeneficiaryUpdateEntitlement(
      formData,
      beneficiaryToBeUpdated,
      matchedCOPColour
    ),
  };

  return {
    beneficiary: payload,
  };
};

// Utility function for fetching BSB lookup
export const fetchBsbLookup =
  (callBack: (params: GetBSBLookupParamsPayload) => void) =>
  (event: React.FocusEvent<HTMLInputElement>) => {
    const BSB = event.target.value;
    const params = {
      BSB,
      meta: {
        replaceEntities: ['bsbLookup'],
      },
    };
    callBack(params);
  };

// Utility function for handling Alias Lookup
export const handleAliasLookup =
  (callBack: (params: PostAliaLookupParamsPayload) => void) =>
  (payIDDetails: PayID, action: string) => {
    const { aliasType, aliasId } = payIDDetails;
    const createPostTransactionParams: PostAliaLookupParamsPayload = {
      params: {
        [aliasType]: aliasId,
        authBIC8: AUTHBIC8,
        action,
      },
      meta: {
        replaceEntities: ['aliasLookup'],
      },
    };
    callBack(createPostTransactionParams);
  };

export type validationResultType = boolean | string | Promise<boolean | string>;
export type validationFunction = (value: string) => validationResultType;

export const nameLikedFieldsValidationRules: RegisterOptions = {
  validate: (value: string) =>
    !validateWithLibrary(value) ||
    `${forbiddenCharacterErrorMessage} ${getFormattedForbiddenCharacters()}`,
};

export function validatePhone(value: string): validationResultType {
  if (!value) {
    return ERROR_MESSAGES.PHONE;
  }
  const [, number] = value.split('-');
  if (number.length < 2) {
    return ERROR_MESSAGES.PHONE;
  }
  return true;
}
export function validateEmail(value: string): validationResultType {
  if (!value || value.length < 5) {
    return ERROR_MESSAGES.EMAIL_REQUIRED;
  }
  const sanitisationResult = (
    nameLikedFieldsValidationRules.validate as validationFunction
  )(value);
  if (typeof sanitisationResult === 'string') {
    return sanitisationResult;
  }
  return (
    REGEX_PATTERN.EMAIL_FORMAT.test(value) ||
    ERROR_MESSAGES.EMAIL_INVALID_FORMAT
  );
}

export function validateAbnAcn(value: string): validationResultType {
  if (!value || value.length < 9 || value.length > 11) {
    return ERROR_MESSAGES.ABN;
  }
  return true;
}

export function validateOrganisationId(value: string): validationResultType {
  if (!value || value.length < 2) {
    return ERROR_MESSAGES.ORGANISATION_REQUIRED;
  }
  return (nameLikedFieldsValidationRules.validate as validationFunction)(value);
}

export function validateField(fieldName: string, value: string) {
  switch (fieldName) {
    case 'phone':
      return validatePhone(value);
    case 'email':
      return validateEmail(value);
    case 'abnAcn':
      return validateAbnAcn(value);
    case 'organisationId':
      return validateOrganisationId(value);
    default:
      break;
  }
}

export function payIdBSBLookupErrorMessage(errorMessage: string | boolean) {
  if (
    typeof errorMessage === 'string' &&
    [
      ERROR_MESSAGES.PAYID_SERVICE_UNAVAILABLE,
      ERROR_MESSAGES.PAYID_CHECK_LIMIT_EXCEEDED,
      ERROR_MESSAGES.INVALID_PAYID,
      ERROR_MESSAGES.PHONE,
      ERROR_MESSAGES.EMAIL_REQUIRED,
      ERROR_MESSAGES.EMAIL_INVALID_FORMAT,
      ERROR_MESSAGES.ABN_ACN,
      ERROR_MESSAGES.ORGANISATION_ID,
      ERROR_MESSAGES.BSB_NOT_RECOGNISED,
      ERROR_MESSAGES.BSB_SERVICE_UNAVAILABLE,
    ].includes(errorMessage)
  ) {
    return errorMessage;
  }
  return true;
}
