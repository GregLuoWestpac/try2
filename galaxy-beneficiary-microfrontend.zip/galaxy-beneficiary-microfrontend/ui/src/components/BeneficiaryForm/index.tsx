export { default as BeneficiaryForm } from './BeneficiaryForm';
