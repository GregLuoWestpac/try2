import {
  BENEFICIARY_TYPE,
  BeneficiaryBSB,
  BeneficiaryPayID,
  PAYID_TYPE,
} from '../../store/types';


export type FormValues = {
  id?: string;
  beneficiaryType?: BENEFICIARY_TYPE;
  payIdType?: PAYID_TYPE;
  payIdName?: string;
  bsb: string;
  bankName: string;
  accountNumber: string;
  accountName: string;
  beneficiaryNickname: string;
  currency?: string;
  phone: string;
  email: string;
  abnAcn: string;
  organisationId: string;
  account?: BeneficiaryBSB | BeneficiaryPayID;
  amount?: string;
  toReference?: string;
  divisions?: {
    id: string;
    name: string;
    label: string;
  }
};
