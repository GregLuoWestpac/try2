import {
  getFormattedForbiddenCharacters,
  validateWithLibrary,
} from '@mesh-tenant-multiverse-ui-common/mv-injection-checker';
import { RegisterOptions } from 'react-hook-form';
import { forbiddenCharacterErrorMessage } from '../../common/constants';

export const DESCRIPTION_VALIDATION_RULES: RegisterOptions = {
  validate: (value: string) =>
    !validateWithLibrary(value) ||
    `${forbiddenCharacterErrorMessage} ${getFormattedForbiddenCharacters()}`,
};

export const defaultDivisionData = [
  {
    id: '',
    name: 'Select a division',
    label: 'Select a division',
  },
];

/**
 * CoP response codes indicating the account is closed
 * V0C7, V1C7, V2C7, VAC7, VTC7, VEC7 - Account closed status codes
 */
export const CLOSED_ACCOUNT_CODES = [
  'V0C7',
  'V1C7',
  'V2C7',
  'VAC7',
  'VTC7',
  'VEC7',
] as const;
