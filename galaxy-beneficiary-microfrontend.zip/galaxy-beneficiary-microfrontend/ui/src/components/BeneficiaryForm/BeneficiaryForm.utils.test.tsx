import { v4 as uuidv4 } from 'uuid';
import {
  Beneficiary,
  BENEFICIARY_STATUS,
  BENEFICIARY_TYPE,
  PAYID_TYPE,
} from '../../store/types';
import { AliasType, PayID } from '../../store/types/AliasLookup';
import { CURRENCY, AUTHBIC8 } from '../../common/constants';
import {
  getPayIDValueFromEditForm,
  isValidAmount,
  mapBeneficiaries,
  mapUpdateBeneficiaryParams,
  fetchBsbLookup,
  handleAliasLookup,
  sanitizeCurrencyAmount,
  validatePhone,
  validateEmail,
  validateAbnAcn,
  validateOrganisationId,
  validateField,
  payIdBSBLookupErrorMessage,
  nameLikedFieldsValidationRules,
} from './BeneficiaryForm.utils';

// Mock uuid to return a predictable ID
jest.mock('uuid', () => ({
  v4: jest.fn(),
}));

jest.mock('./BeneficiaryForm.utils', () => ({
  ...jest.requireActual('./BeneficiaryForm.utils'),
  getPayIDValueFromEditForm: jest.fn(),
}));

// Mock injection checker library
jest.mock('@mesh-tenant-multiverse-ui-common/mv-injection-checker', () => ({
  validateWithLibrary: jest.fn(),
  getFormattedForbiddenCharacters: jest.fn().mockReturnValue('< > " \' &'),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  DATE_FORMAT_YYYYMMDD: 'YYYY-MM-DD',
  getToday: () => ({ toFormat: () => '2026-01-29' }),
  getTodayAtLastYear: () => ({ toFormat: () => '2025-01-29' }),
}));

// Mock constants for forbidden character error message
jest.mock('../../common/constants', () => ({
  ...jest.requireActual('../../common/constants'),
  forbiddenCharacterErrorMessage: 'Forbidden characters found:',
}));

describe('mapBeneficiaries', () => {
  beforeEach(() => {
    (uuidv4 as jest.Mock).mockReturnValue('mocked-uuid');
  });

  it('should map a PayID beneficiary with phone type', () => {
    const result = mapBeneficiaries({
      beneficiaryNickname: 'John Doe',
      phone: '0412 345 678',
      beneficiaryType: BENEFICIARY_TYPE.PAYID,
      payIdType: PAYID_TYPE.PHONE,
      payIdName: 'John Doe',
      bsb: '',
      bankName: '',
      accountNumber: '',
      accountName: '',
      email: '',
      abnAcn: '',
      organisationId: '',
    });

    expect(result).toEqual({
      beneficiaries: [
        expect.objectContaining({
          nickname: 'John Doe',
          reference: '',
          id: 'mocked-uuid',
          type: BENEFICIARY_TYPE.PAYID,
          account: {
            payIDName: 'John Doe',
            payIDType: PAYID_TYPE.PHONE,
            payIDValue: '0412345678',
          },
          entitlementData: expect.any(Object),
          currencyAmount: {
            currencyCode: 'AUD',
          },
        }),
      ],
    });
  });

  it('should map a PayID beneficiary with email type', () => {
    const result = mapBeneficiaries({
      beneficiaryNickname: 'Alice',
      email: 'alice@example.com',
      beneficiaryType: BENEFICIARY_TYPE.PAYID,
      payIdType: PAYID_TYPE.EMAIL,
      bsb: '',
      bankName: '',
      accountNumber: '',
      accountName: '',
      phone: '',
      abnAcn: '',
      organisationId: '',
    });

    expect(result.beneficiaries[0].account.payIDValue).toBe(
      'alice@example.com'
    );
  });

  it('should map a PayID beneficiary with ABN_ACN type', () => {
    const result = mapBeneficiaries({
      beneficiaryNickname: 'Corp Pty Ltd',
      abnAcn: '12345678901',
      beneficiaryType: BENEFICIARY_TYPE.PAYID,
      payIdType: PAYID_TYPE.ABN_ACN,
      bsb: '',
      bankName: '',
      accountNumber: '',
      accountName: '',
      phone: '',
      email: '',
      organisationId: '',
    });

    expect(result.beneficiaries[0].account.payIDValue).toBe('12345678901');
  });

  it('should map a PayID beneficiary with organisationId type', () => {
    const result = mapBeneficiaries({
      beneficiaryNickname: 'Charity Org',
      organisationId: 'ORG-4567',
      beneficiaryType: BENEFICIARY_TYPE.PAYID,
      bsb: '',
      bankName: '',
      accountNumber: '',
      accountName: '',
      phone: '',
      email: '',
      abnAcn: '',
    });

    expect(result.beneficiaries[0].account.payIDValue).toBe('ORG-4567');
  });

  it('should map a non-PayID beneficiary (BSB + Account)', () => {
    const result = mapBeneficiaries({
      beneficiaryNickname: 'Jane Smith',
      bsb: '123456',
      accountNumber: '987654321',
      accountName: 'Jane Smith',
      bankName: 'Central Bank',
      beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
      phone: '',
      email: '',
      abnAcn: '',
      organisationId: '',
    });

    expect(result).toEqual({
      beneficiaries: [
        expect.objectContaining({
          nickname: 'Jane Smith',
          reference: '',
          id: 'mocked-uuid',
          type: BENEFICIARY_TYPE.ACCOUNT,
          account: {
            accountId: {
              BSB: '123456',
              accountNumber: '987654321',
            },
            accountName: 'Jane Smith',
            bankName: 'Central Bank',
          },
          entitlementData: expect.any(Object),
        }),
      ],
    });
  });

  it('should handle undefined accountNumber, accountName, and bankName in non-PayID beneficiary', () => {
    const result = mapBeneficiaries({
      beneficiaryNickname: 'No Details',
      bsb: '123456',
      beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
      bankName: '',
      accountNumber: '',
      accountName: '',
      phone: '',
      email: '',
      abnAcn: '',
      organisationId: '',
      // accountNumber, accountName, and bankName are undefined
    });

    expect(result.beneficiaries[0].account).toEqual({
      accountId: {
        BSB: '123456',
        accountNumber: '',
      },
      accountName: '',
      bankName: '',
    });
  });
});

describe('mapUpdateBeneficiaryParams', () => {
  const baseBeneficiary: Beneficiary = {
    id: '123',
    externalId: 'ext-123',
    currency: 'AUD',
    type: BENEFICIARY_TYPE.PAYID,
    nickname: 'john',
    org: '12134',
    status: BENEFICIARY_STATUS.ACTIVE,
    account: {
      payIDType: PAYID_TYPE.EMAIL,
      payIDValue: 'test@example.com',
      payIDName: 'John Doe',
    },
  };

  it('should map payload for PAYID type', () => {
    (getPayIDValueFromEditForm as jest.Mock).mockReturnValue(
      'test@example.com'
    );

    const formData = {
      beneficiaryNickname: 'John PayID',
      beneficiaryType: BENEFICIARY_TYPE.PAYID,
      payIdType: PAYID_TYPE.EMAIL,
      email: 'test@example.com',
      organisationId: '',
      phone: '',
      abnAcn: '',
      accountName: '',
      accountNumber: '',
      bankName: '',
      bsb: '',
      payIdName: 'John PayID',
    };

    const result = mapUpdateBeneficiaryParams(formData, baseBeneficiary);

    expect(result).toEqual({
      beneficiary: expect.objectContaining({
        id: '123',
        externalId: 'ext-123',
        currencyAmount: {
          currencyCode: 'AUD',
        },
        reference: '',
        nickname: 'John PayID',
        type: BENEFICIARY_TYPE.PAYID,
        account: {
          payIDType: PAYID_TYPE.EMAIL,
          payIDValue: 'test@example.com',
          payIDName: 'John PayID',
        },
        entitlementData: expect.any(Object),
      }),
    });
  });

  it('should map payload for BSB type', () => {
    const formData = {
      beneficiaryNickname: 'Jane Bank',
      beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
      payIdType: undefined,
      payIdName: '',
      email: '',
      organisationId: '',
      phone: '',
      abnAcn: '',
      accountName: 'Jane Doe',
      accountNumber: '12345678',
      bankName: 'Test Bank',
      bsb: '062000',
    };

    const result = mapUpdateBeneficiaryParams(formData, baseBeneficiary);

    expect(result).toEqual({
      beneficiary: expect.objectContaining({
        id: '123',
        externalId: 'ext-123',
        currencyAmount: {
          currencyCode: 'AUD',
        },
        reference: '',
        nickname: 'Jane Bank',
        type: BENEFICIARY_TYPE.ACCOUNT,
        account: {
          accountId: {
            BSB: '062000',
            accountNumber: '12345678',
          },
          bankName: 'Test Bank',
          accountName: 'Jane Doe',
        },
        entitlementData: expect.any(Object),
      }),
    });
  });

  it('should default payIDValue to empty string if getPayIDValueFromEditForm returns null', () => {
    (getPayIDValueFromEditForm as jest.Mock).mockReturnValue(null);

    const formData = {
      beneficiaryNickname: 'Missing PayID',
      beneficiaryType: BENEFICIARY_TYPE.PAYID,
      payIdType: PAYID_TYPE.EMAIL,
      payIdName: 'No Value',
      email: '',
      organisationId: '',
      phone: '',
      abnAcn: '',
      accountName: '',
      accountNumber: '',
      bankName: '',
      bsb: '',
    };

    const result = mapUpdateBeneficiaryParams(formData, baseBeneficiary);

    if ('payIDValue' in result.beneficiary?.account) {
      expect(result.beneficiary?.account.payIDValue).toBe('');
    }
  });
});

describe('fetchBsbLookup', () => {
  it('should call callback with correct params', () => {
    const mockCallback = jest.fn();
    const event = {
      target: { value: '123456' },
    } as React.FocusEvent<HTMLInputElement>;

    fetchBsbLookup(mockCallback)(event);

    expect(mockCallback).toHaveBeenCalledWith({
      BSB: '123456',
      meta: { replaceEntities: ['bsbLookup'] },
    });
  });
});

describe('handleAliasLookup', () => {
  it('should call callback with correct params for alias lookup', () => {
    const mockCallback = jest.fn();
    const payIDDetails: PayID = {
      aliasType: AliasType.EMAIL,
      aliasId: 'test@example.com',
    };

    handleAliasLookup(mockCallback)(payIDDetails);

    expect(mockCallback).toHaveBeenCalledWith({
      params: {
        email: 'test@example.com',
        authBIC8: AUTHBIC8,
      },
      meta: { replaceEntities: ['aliasLookup'] },
    });
  });
});

describe('validation functions', () => {
  describe('validatePhone', () => {
    it('should return error when value is empty', () => {
      const result = validatePhone('');
      expect(result).toBe('Enter a valid phone number.');
    });

    it('should return error when phone number part is too short', () => {
      const result = validatePhone('04-1');
      expect(result).toBe('Enter a valid phone number.');
    });

    it('should return True for valid phone format', () => {
      const result = validatePhone('04-12345678');
      expect(result).toBeTruthy();
    });
  });

  describe('validateEmail', () => {
    it('should return error when value is empty', () => {
      const result = validateEmail('');
      expect(result).toBe('Enter a valid email address.');
    });

    it('should return error when value is too short', () => {
      const result = validateEmail('abc');
      expect(result).toBe('Enter a valid email address.');
    });

    it('should return error for invalid email format', () => {
      const result = validateEmail('invalid-email');
      expect(result).toBe('Enter a valid email address.');
    });

    it('should return True for valid email', () => {
      const result = validateEmail('test@example.com');
      expect(result).toBeTruthy();
    });
  });

  describe('validateAbnAcn', () => {
    it('should return error when value is empty', () => {
      const result = validateAbnAcn('');
      expect(result).toBe(
        'Enter a valid ABN or ACN number between 9 and 11 digits.'
      );
    });

    it('should return error when value is too short', () => {
      const result = validateAbnAcn('12345');
      expect(result).toBe(
        'Enter a valid ABN or ACN number between 9 and 11 digits.'
      );
    });

    it('should return True for valid ABN / ACN', () => {
      const result = validateAbnAcn('123456789');
      expect(result).toBeTruthy();
    });
  });

  describe('validateOrganisationId', () => {
    it('should return error when value is empty', () => {
      const result = validateOrganisationId('');
      expect(result).toBe(
        'Enter a valid organisation ID between 2 and 256 characters.'
      );
    });

    it('should return error when value is too short', () => {
      const result = validateOrganisationId('A');
      expect(result).toBe(
        'Enter a valid organisation ID between 2 and 256 characters.'
      );
    });

    it('should return True for valid organisation ID', () => {
      const result = validateOrganisationId('ORG123');
      expect(result).toBeTruthy();
    });
  });

  describe('validateField', () => {
    it('should call validatePhone for phone field', () => {
      const result = validateField('phone', '');
      expect(result).toBe('Enter a valid phone number.');
    });

    it('should call validateEmail for email field', () => {
      const result = validateField('email', '');
      expect(result).toBe('Enter a valid email address.');
    });

    it('should call validateAbnAcn for abnAcn field', () => {
      const result = validateField('abnAcn', '');
      expect(result).toBe(
        'Enter a valid ABN or ACN number between 9 and 11 digits.'
      );
    });

    it('should call validateOrganisationId for organisationId field', () => {
      const result = validateField('organisationId', '');
      expect(result).toBe(
        'Enter a valid organisation ID between 2 and 256 characters.'
      );
    });

    it('should return undefined for unknown field', () => {
      const result = validateField('unknownField', 'value');
      expect(result).toBeUndefined();
    });
  });

  describe('payIdBSBLookupErrorMessage', () => {
    it('should return error message when it matches known errors', () => {
      const result = payIdBSBLookupErrorMessage(
        'PayID service is currently not available. Please try again.'
      );
      expect(result).toBe(
        'PayID service is currently not available. Please try again.'
      );
    });

    it('should return true when error message is not in known list', () => {
      const result = payIdBSBLookupErrorMessage('Unknown error message');
      expect(result).toBeTruthy();
    });

    it('should return true when error message is undefined', () => {
      const result = payIdBSBLookupErrorMessage(undefined);
      expect(result).toBeTruthy();
    });

    it('should return true when error message is empty string', () => {
      const result = payIdBSBLookupErrorMessage('');
      expect(result).toBeTruthy();
    });
  });

  describe('nameLikedFieldsValidationRules', () => {
    it('should return true when validateWithLibrary returns false (no forbidden characters)', () => {
      const {
        validateWithLibrary,
      } = require('@mesh-tenant-multiverse-ui-common/mv-injection-checker');
      validateWithLibrary.mockReturnValue(false);

      const validator = nameLikedFieldsValidationRules.validate as (
        value: string
      ) => boolean | string;
      const result = validator('valid text');

      expect(result).toBe(true);
      expect(validateWithLibrary).toHaveBeenCalledWith('valid text');
    });

    it('should return error message when validateWithLibrary returns true (forbidden characters found)', () => {
      const {
        validateWithLibrary,
        getFormattedForbiddenCharacters,
      } = require('@mesh-tenant-multiverse-ui-common/mv-injection-checker');
      validateWithLibrary.mockReturnValue(true);
      getFormattedForbiddenCharacters.mockReturnValue('< > " \' &');

      const validator = nameLikedFieldsValidationRules.validate as (
        value: string
      ) => boolean | string;
      const result = validator('invalid <script> text');

      expect(result).toBe('Forbidden characters found: < > " \' &');
      expect(validateWithLibrary).toHaveBeenCalledWith('invalid <script> text');
    });
  });
});

describe('isValidAmount', () => {
  describe('should return false for invalid amounts', () => {
    it('returns false for undefined', () => {
      expect(isValidAmount(undefined)).toBe(false);
    });

    it('returns false for null', () => {
      expect(isValidAmount(null)).toBe(false);
    });

    it('returns false for empty string', () => {
      expect(isValidAmount('')).toBe(false);
    });

    it('returns false for whitespace-only string', () => {
      expect(isValidAmount('   ')).toBe(false);
    });

    it('returns false for tab characters', () => {
      expect(isValidAmount('\t\t')).toBe(false);
    });

    it('returns false for newline characters', () => {
      expect(isValidAmount('\n')).toBe(false);
    });

    it('returns false for non-numeric string', () => {
      expect(isValidAmount('abc')).toBe(false);
    });

    it('returns false for mixed alphanumeric string', () => {
      expect(isValidAmount('123abc')).toBe(false);
    });

    it('returns false for NaN representation', () => {
      expect(isValidAmount('NaN')).toBe(false);
    });

    it('returns false for Infinity', () => {
      expect(isValidAmount('Infinity')).toBe(false);
    });

    it('returns false for -Infinity', () => {
      expect(isValidAmount('-Infinity')).toBe(false);
    });

    it('returns false for special characters', () => {
      expect(isValidAmount('$100')).toBe(false);
    });

    it('returns false for comma-formatted numbers', () => {
      expect(isValidAmount('1,000.00')).toBe(false);
    });
  });

  describe('should return true for valid amounts', () => {
    it('returns true for integer string', () => {
      expect(isValidAmount('100')).toBe(true);
    });

    it('returns true for decimal string', () => {
      expect(isValidAmount('100.50')).toBe(true);
    });

    it('returns true for zero', () => {
      expect(isValidAmount('0')).toBe(true);
    });

    it('returns true for zero with decimal', () => {
      expect(isValidAmount('0.00')).toBe(true);
    });

    it('returns true for negative number', () => {
      expect(isValidAmount('-50.25')).toBe(true);
    });

    it('returns true for number with leading whitespace (trimmed)', () => {
      expect(isValidAmount('  100.50')).toBe(true);
    });

    it('returns true for number with trailing whitespace (trimmed)', () => {
      expect(isValidAmount('100.50  ')).toBe(true);
    });

    it('returns true for scientific notation', () => {
      expect(isValidAmount('1e5')).toBe(true);
    });

    it('returns true for small decimal', () => {
      expect(isValidAmount('0.01')).toBe(true);
    });

    it('returns true for large number', () => {
      expect(isValidAmount('9999999999999.99')).toBe(true);
    });
  });
});

describe('sanitizeCurrencyAmount', () => {
  describe('should return undefined', () => {
    it('returns undefined when currencyAmount is undefined', () => {
      expect(sanitizeCurrencyAmount(undefined)).toBeUndefined();
    });
  });

  describe('should return currencyAmount with amount when valid', () => {
    it('includes amount when it is a valid number string', () => {
      const result = sanitizeCurrencyAmount({
        currencyCode: CURRENCY.AUD,
        amount: '100.50',
      });
      expect(result).toEqual({
        currencyCode: CURRENCY.AUD,
        amount: '100.50',
      });
    });

    it('includes amount when it is zero', () => {
      const result = sanitizeCurrencyAmount({
        currencyCode: CURRENCY.AUD,
        amount: '0',
      });
      expect(result).toEqual({
        currencyCode: CURRENCY.AUD,
        amount: '0',
      });
    });

    it('includes amount when it is a negative number', () => {
      const result = sanitizeCurrencyAmount({
        currencyCode: CURRENCY.AUD,
        amount: '-25.00',
      });
      expect(result).toEqual({
        currencyCode: CURRENCY.AUD,
        amount: '-25.00',
      });
    });
  });

  describe('should return currencyAmount without amount when invalid', () => {
    it('excludes amount when it is empty string', () => {
      const result = sanitizeCurrencyAmount({
        currencyCode: CURRENCY.AUD,
        amount: '',
      });
      expect(result).toEqual({
        currencyCode: CURRENCY.AUD,
      });
      expect(result).not.toHaveProperty('amount');
    });

    it('excludes amount when it is whitespace-only', () => {
      const result = sanitizeCurrencyAmount({
        currencyCode: CURRENCY.AUD,
        amount: '   ',
      });
      expect(result).toEqual({
        currencyCode: CURRENCY.AUD,
      });
      expect(result).not.toHaveProperty('amount');
    });

    it('excludes amount when it is non-numeric', () => {
      const result = sanitizeCurrencyAmount({
        currencyCode: CURRENCY.AUD,
        amount: 'abc',
      });
      expect(result).toEqual({
        currencyCode: CURRENCY.AUD,
      });
      expect(result).not.toHaveProperty('amount');
    });

    it('excludes amount when it is NaN string', () => {
      const result = sanitizeCurrencyAmount({
        currencyCode: CURRENCY.AUD,
        amount: 'NaN',
      });
      expect(result).toEqual({
        currencyCode: CURRENCY.AUD,
      });
    });
  });
});

describe('mapBeneficiaries - currencyAmount sanitization', () => {
  beforeEach(() => {
    (uuidv4 as jest.Mock).mockReturnValue('mocked-uuid');
  });

  it('should exclude amount from currencyAmount when amount is empty string', () => {
    const result = mapBeneficiaries({
      beneficiaryNickname: 'Test',
      beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
      bsb: '123456',
      accountNumber: '12345678',
      accountName: 'Test Account',
      bankName: 'Test Bank',
      amount: '',
      phone: '',
      email: '',
      abnAcn: '',
      organisationId: '',
    });

    expect(result.beneficiaries[0].currencyAmount).toEqual({
      currencyCode: 'AUD',
    });
    expect(result.beneficiaries[0].currencyAmount).not.toHaveProperty('amount');
  });

  it('should exclude amount from currencyAmount when amount is undefined', () => {
    const result = mapBeneficiaries({
      beneficiaryNickname: 'Test',
      beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
      bsb: '123456',
      accountNumber: '12345678',
      accountName: 'Test Account',
      bankName: 'Test Bank',
      phone: '',
      email: '',
      abnAcn: '',
      organisationId: '',
    });

    expect(result.beneficiaries[0].currencyAmount).toEqual({
      currencyCode: 'AUD',
    });
    expect(result.beneficiaries[0].currencyAmount).not.toHaveProperty('amount');
  });

  it('should exclude amount from currencyAmount when amount is whitespace', () => {
    const result = mapBeneficiaries({
      beneficiaryNickname: 'Test',
      beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
      bsb: '123456',
      accountNumber: '12345678',
      accountName: 'Test Account',
      bankName: 'Test Bank',
      amount: '   ',
      phone: '',
      email: '',
      abnAcn: '',
      organisationId: '',
    });

    expect(result.beneficiaries[0].currencyAmount).toEqual({
      currencyCode: 'AUD',
    });
  });

  it('should exclude amount from currencyAmount when amount is non-numeric', () => {
    const result = mapBeneficiaries({
      beneficiaryNickname: 'Test',
      beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
      bsb: '123456',
      accountNumber: '12345678',
      accountName: 'Test Account',
      bankName: 'Test Bank',
      amount: 'abc',
      phone: '',
      email: '',
      abnAcn: '',
      organisationId: '',
    });

    expect(result.beneficiaries[0].currencyAmount).toEqual({
      currencyCode: 'AUD',
    });
  });

  it('should include amount in currencyAmount when amount is valid', () => {
    const result = mapBeneficiaries({
      beneficiaryNickname: 'Test',
      beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
      bsb: '123456',
      accountNumber: '12345678',
      accountName: 'Test Account',
      bankName: 'Test Bank',
      amount: '100.50',
      phone: '',
      email: '',
      abnAcn: '',
      organisationId: '',
    });

    expect(result.beneficiaries[0].currencyAmount).toEqual({
      currencyCode: 'AUD',
      amount: '100.50',
    });
  });

  it('should include amount in currencyAmount when amount is zero', () => {
    const result = mapBeneficiaries({
      beneficiaryNickname: 'Test',
      beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
      bsb: '123456',
      accountNumber: '12345678',
      accountName: 'Test Account',
      bankName: 'Test Bank',
      amount: '0',
      phone: '',
      email: '',
      abnAcn: '',
      organisationId: '',
    });

    expect(result.beneficiaries[0].currencyAmount).toEqual({
      currencyCode: 'AUD',
      amount: '0.00',
    });
  });
});

describe('mapUpdateBeneficiaryParams - currencyAmount sanitization', () => {
  const baseBeneficiary: Beneficiary = {
    id: '123',
    externalId: 'ext-123',
    currency: 'AUD',
    type: BENEFICIARY_TYPE.ACCOUNT,
    nickname: 'Test',
    org: 'test-org',
    status: BENEFICIARY_STATUS.ACTIVE,
    account: {
      accountId: {
        BSB: '123456',
        accountNumber: '12345678',
      },
      bankName: 'Test Bank',
      accountName: 'Test Account',
    },
  } as Beneficiary;

  it('should exclude amount from currencyAmount when amount is empty string', () => {
    const result = mapUpdateBeneficiaryParams(
      {
        beneficiaryNickname: 'Test',
        beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
        bsb: '123456',
        accountNumber: '12345678',
        accountName: 'Test Account',
        bankName: 'Test Bank',
        amount: '',
        phone: '',
        email: '',
        abnAcn: '',
        organisationId: '',
      },
      baseBeneficiary
    );

    expect(result.beneficiary.currencyAmount).toEqual({
      currencyCode: 'AUD',
    });
    expect(result.beneficiary.currencyAmount).not.toHaveProperty('amount');
  });

  it('should exclude amount from currencyAmount when amount is whitespace', () => {
    const result = mapUpdateBeneficiaryParams(
      {
        beneficiaryNickname: 'Test',
        beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
        bsb: '123456',
        accountNumber: '12345678',
        accountName: 'Test Account',
        bankName: 'Test Bank',
        amount: '   ',
        phone: '',
        email: '',
        abnAcn: '',
        organisationId: '',
      },
      baseBeneficiary
    );

    expect(result.beneficiary.currencyAmount).toEqual({
      currencyCode: 'AUD',
    });
  });

  it('should exclude amount from currencyAmount when amount is non-numeric', () => {
    const result = mapUpdateBeneficiaryParams(
      {
        beneficiaryNickname: 'Test',
        beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
        bsb: '123456',
        accountNumber: '12345678',
        accountName: 'Test Account',
        bankName: 'Test Bank',
        amount: 'invalid',
        phone: '',
        email: '',
        abnAcn: '',
        organisationId: '',
      },
      baseBeneficiary
    );

    expect(result.beneficiary.currencyAmount).toEqual({
      currencyCode: 'AUD',
    });
  });

  it('should include amount in currencyAmount when amount is valid', () => {
    const result = mapUpdateBeneficiaryParams(
      {
        beneficiaryNickname: 'Test',
        beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
        bsb: '123456',
        accountNumber: '12345678',
        accountName: 'Test Account',
        bankName: 'Test Bank',
        amount: '250.00',
        phone: '',
        email: '',
        abnAcn: '',
        organisationId: '',
      },
      baseBeneficiary
    );

    expect(result.beneficiary.currencyAmount).toEqual({
      currencyCode: 'AUD',
      amount: '250.00',
    });
  });
});

describe('mapBeneficiaries - COP fields', () => {
  beforeEach(() => {
    (uuidv4 as jest.Mock).mockReturnValue('mocked-uuid');
  });

  const baseFormData = {
    beneficiaryNickname: 'COP Test',
    beneficiaryType: BENEFICIARY_TYPE.ACCOUNT as const,
    bsb: '123456',
    accountNumber: '12345678',
    accountName: 'COP Account',
    bankName: 'Test Bank',
    phone: '',
    email: '',
    abnAcn: '',
    organisationId: '',
  };

  it('should include matchedCOPStatusCode when provided', () => {
    const result = mapBeneficiaries(baseFormData, 'V0C1');

    expect(result.beneficiaries[0]).toHaveProperty(
      'matchedCOPStatusCode',
      'V0C1'
    );
  });

  it('should include matchedCOPAccountName when provided', () => {
    const result = mapBeneficiaries(
      baseFormData,
      'V0C1',
      'Matched Account Name'
    );

    expect(result.beneficiaries[0]).toHaveProperty(
      'matchedCOPAccountName',
      'Matched Account Name'
    );
  });

  it('should not include matchedCOPStatusCode when undefined', () => {
    const result = mapBeneficiaries(baseFormData);

    expect(result.beneficiaries[0]).not.toHaveProperty('matchedCOPStatusCode');
  });

  it('should not include matchedCOPAccountName when undefined', () => {
    const result = mapBeneficiaries(baseFormData, undefined, undefined);

    expect(result.beneficiaries[0]).not.toHaveProperty('matchedCOPAccountName');
  });

  it('should not include matchedCOPStatusCode when empty string (falsy)', () => {
    const result = mapBeneficiaries(baseFormData, '' as any);

    expect(result.beneficiaries[0]).not.toHaveProperty('matchedCOPStatusCode');
  });

  it('should not include matchedCOPAccountName when empty string (falsy)', () => {
    const result = mapBeneficiaries(baseFormData, 'V0C1', '');

    expect(result.beneficiaries[0]).not.toHaveProperty('matchedCOPAccountName');
  });

  it('should pass matchedCOPColour to entitlementData via buildBeneficiaryCreateEntitlement', () => {
    const result = mapBeneficiaries(
      baseFormData,
      'V0C1',
      'Account Name',
      'Amber' as any
    );

    // entitlementData should contain PAYEE_NAME_CHECK_COLOUR supplementary data
    const colourEntry =
      result.beneficiaries[0].entitlementData?.supplementaryData?.find(
        (item: any) => item.name === 'PAYEE_NAME_CHECK_COLOUR'
      );
    expect(colourEntry).toEqual({
      name: 'PAYEE_NAME_CHECK_COLOUR',
      value: 'Amber',
      datatype: 'STRING',
    });
  });

  it('should not include PAYEE_NAME_CHECK_COLOUR in entitlementData when matchedCOPColour is undefined', () => {
    const result = mapBeneficiaries(baseFormData, 'V0C1', 'Account Name');

    const colourEntry =
      result.beneficiaries[0].entitlementData?.supplementaryData?.find(
        (item: any) => item.name === 'PAYEE_NAME_CHECK_COLOUR'
      );
    expect(colourEntry).toBeUndefined();
  });

  it('should include all three COP fields together', () => {
    const result = mapBeneficiaries(
      baseFormData,
      'V1C2',
      'Full Match Name',
      'Blue' as any
    );

    const bene = result.beneficiaries[0];
    expect(bene.matchedCOPStatusCode).toBe('V1C2');
    expect(bene.matchedCOPAccountName).toBe('Full Match Name');

    const colourEntry = bene.entitlementData?.supplementaryData?.find(
      (item: any) => item.name === 'PAYEE_NAME_CHECK_COLOUR'
    );
    expect(colourEntry).toBeDefined();
    expect(colourEntry.value).toBe('Blue');
  });
});

describe('mapUpdateBeneficiaryParams - COP fields', () => {
  const baseBeneficiary: Beneficiary = {
    id: '456',
    externalId: 'ext-456',
    currency: 'AUD',
    type: BENEFICIARY_TYPE.ACCOUNT,
    nickname: 'Existing Bene',
    org: 'test-org',
    status: BENEFICIARY_STATUS.ACTIVE,
    account: {
      accountId: {
        BSB: '654321',
        accountNumber: '87654321',
      },
      bankName: 'Old Bank',
      accountName: 'Old Account',
    },
  } as Beneficiary;

  const baseFormData = {
    beneficiaryNickname: 'Updated Bene',
    beneficiaryType: BENEFICIARY_TYPE.ACCOUNT as const,
    bsb: '654321',
    accountNumber: '87654321',
    accountName: 'Updated Account',
    bankName: 'Old Bank',
    phone: '',
    email: '',
    abnAcn: '',
    organisationId: '',
  };

  it('should include matchedCOPStatusCode on the beneficiary payload when provided', () => {
    const result = mapUpdateBeneficiaryParams(
      baseFormData,
      baseBeneficiary,
      'VAC3'
    );

    expect(result.beneficiary).toHaveProperty('matchedCOPStatusCode', 'VAC3');
  });

  it('should include matchedCOPAccountName on the beneficiary payload when provided', () => {
    const result = mapUpdateBeneficiaryParams(
      baseFormData,
      baseBeneficiary,
      'VAC3',
      'Updated Match Name'
    );

    expect(result.beneficiary).toHaveProperty(
      'matchedCOPAccountName',
      'Updated Match Name'
    );
  });

  it('should not include matchedCOPStatusCode when undefined', () => {
    const result = mapUpdateBeneficiaryParams(baseFormData, baseBeneficiary);

    expect(result.beneficiary).not.toHaveProperty('matchedCOPStatusCode');
  });

  it('should not include matchedCOPAccountName when undefined', () => {
    const result = mapUpdateBeneficiaryParams(
      baseFormData,
      baseBeneficiary,
      undefined,
      undefined
    );

    expect(result.beneficiary).not.toHaveProperty('matchedCOPAccountName');
  });

  it('should not include matchedCOPStatusCode when empty string (falsy)', () => {
    const result = mapUpdateBeneficiaryParams(
      baseFormData,
      baseBeneficiary,
      '' as any
    );

    expect(result.beneficiary).not.toHaveProperty('matchedCOPStatusCode');
  });

  it('should not include matchedCOPAccountName when empty string (falsy)', () => {
    const result = mapUpdateBeneficiaryParams(
      baseFormData,
      baseBeneficiary,
      'VAC3',
      ''
    );

    expect(result.beneficiary).not.toHaveProperty('matchedCOPAccountName');
  });

  it('should pass matchedCOPColour to entitlementData via buildBeneficiaryUpdateEntitlement', () => {
    const result = mapUpdateBeneficiaryParams(
      baseFormData,
      baseBeneficiary,
      'VAC3',
      'Match Name',
      'Red' as any
    );

    const colourEntry =
      result.beneficiary.entitlementData?.supplementaryData?.find(
        (item: any) => item.name === 'PAYEE_NAME_CHECK_COLOUR'
      );
    expect(colourEntry).toEqual({
      name: 'PAYEE_NAME_CHECK_COLOUR',
      value: 'Red',
      datatype: 'STRING',
    });
  });

  it('should not include PAYEE_NAME_CHECK_COLOUR in entitlementData when matchedCOPColour is undefined', () => {
    const result = mapUpdateBeneficiaryParams(
      baseFormData,
      baseBeneficiary,
      'VAC3',
      'Match Name'
    );

    const colourEntry =
      result.beneficiary.entitlementData?.supplementaryData?.find(
        (item: any) => item.name === 'PAYEE_NAME_CHECK_COLOUR'
      );
    expect(colourEntry).toBeUndefined();
  });

  it('should include all COP fields together in update scenario', () => {
    const result = mapUpdateBeneficiaryParams(
      baseFormData,
      baseBeneficiary,
      'VTC5',
      'Full Update Name',
      'Amber' as any
    );

    const bene = result.beneficiary;
    expect(bene.matchedCOPStatusCode).toBe('VTC5');
    expect(bene.matchedCOPAccountName).toBe('Full Update Name');

    const colourEntry = bene.entitlementData?.supplementaryData?.find(
      (item: any) => item.name === 'PAYEE_NAME_CHECK_COLOUR'
    );
    expect(colourEntry).toBeDefined();
    expect(colourEntry!.value).toBe('Amber');
  });
});
