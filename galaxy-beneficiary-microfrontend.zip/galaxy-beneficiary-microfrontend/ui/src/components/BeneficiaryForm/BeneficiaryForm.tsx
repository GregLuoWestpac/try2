/* eslint-disable consistent-return */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable import/no-cycle */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable prefer-destructuring */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable jsx-a11y/no-redundant-roles */
/* eslint-disable react/require-default-props */
import { MVAccountFormatter } from '@mesh-tenant-multiverse-ui-common/mv-accountformatter';
import {
  MVButtonGroupController,
  MVCurrencyController,
  MVInputController,
  MVPhoneInputController,
} from '@mesh-tenant-multiverse-ui-common/mv-reacthookform';
import { MVSelectController } from '@mesh-tenant-multiverse-ui-common/mv-selectcontroller';
import { useUnifyClose } from '@mesh-tenant-multiverse-ui-common/mv-openfin';
import { MVPageLoader } from '@mesh-tenant-multiverse-ui-common/mv-pageloader';
import {
  Alert,
  Button,
  Grid,
  GridItem,
  Heading,
  ProgressIndicator,
  Well,
} from '@westpac/ui';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useForm, useFormState } from 'react-hook-form';
import { isStaffPortal } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { type COPCheckResultData } from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
import { CopResultsSection } from '../CopResultsSection';
import {
  ERROR_MESSAGES,
  INPUT_MAX_LENGTH,
  REGEX_PATTERN,
  CURRENCY,
} from '../../common';
import { FormValues } from './BeneficiaryForm.types';
import {
  getFriendlyPayIDType,
  getMappedFormFieldNameWithPayIDType,
} from '../../common/PayID.util';
import {
  DESCRIPTION_VALIDATION_RULES,
  defaultDivisionData,
} from './BeneficiaryForm.constants';
import {
  useAccountNameCheck,
  AccountNameCheckFieldPaths,
} from '../../hooks/useAccountNameCheck';

import {
  Beneficiary,
  BENEFICIARY_TYPE,
  BeneficiaryBSB,
  BeneficiaryOptionsPayload,
  BeneficiaryPayID,
  GetBSBLookupParamsPayload,
  PAYID_TYPE,
  PostAliaLookupParamsPayload,
  PostBeneficiaryParamsPayload,
  PutBeneficiaryParams,
  PutBeneficiaryParamsPayload,
} from '../../store/types';
import { AliasType, PayID, PayIDs } from '../../store/types/AliasLookup';
import { Branch } from '../../store/types/BsbLookup';
import {
  fetchBsbLookup,
  getDefaultFormValues,
  handleAliasLookup,
  mapBeneficiaries,
  mapUpdateBeneficiaryParams,
  nameLikedFieldsValidationRules,
  payIdBSBLookupErrorMessage,
  validateAbnAcn,
  validateEmail,
  validateField,
  validateOrganisationId,
  validatePhone,
} from './BeneficiaryForm.utils';
import { useHandleRedirectToBeneficiaryList } from '../../common/BeneficiaryList.util';
import { Division } from '../../store/types/DivisonList';

type BeneficiaryFormProps = {
  beneficiaryToBeUpdated?: Beneficiary;
  isBsbLookupFetching?: boolean;
  isBsbLookupError?: boolean;
  branches?: Branch[];
  apiStatus?: number;
  onUpdateBeneficiary?: (
    payload: PutBeneficiaryParamsPayload,
    options: BeneficiaryOptionsPayload
  ) => void;
  isBeneficiaryUpdateFetching?: boolean;
  isBeneficiaryUpdateError?: boolean;
  getBsbLookup: (payload: GetBSBLookupParamsPayload) => void;
  postAliasLookup: (payload: PostAliaLookupParamsPayload) => void;
  payIDDetails?: PayIDs[];
  isAliasLookupFetching?: boolean;
  isAliasLookupError?: boolean;
  doesAliasIdContainInvalidData?: boolean;
  isPayIdNotValid?: boolean;
  isPayIdLimitExceeded?: boolean;
  isPayIdServiceNotAvailable: boolean;
  addBeneficiary?: (
    payload: PostBeneficiaryParamsPayload,
    options: BeneficiaryOptionsPayload
  ) => void;
  isBeneficiaryCreateFetching?: boolean;
  isBeneficiaryCreateError?: boolean;
  isBeneficiaryDetailsError: boolean;
  onRefreshBeneficiaryDetails?: () => void;
  clearAliasLookup: () => void;
  clearBsbLookup: () => void;
  isBeneficiaryStatusUpdateFetching?: boolean;
  isDivisionListFetching?: boolean;
  isDivisionListError?: boolean;
  allDivisionList?: Division[];
  postAccountNameCheck?: (params: {
    accountName: string;
    accountNumber: string;
    bsb: string;
  }) => void;
  lookupState?: React.MutableRefObject<{
    triggeredByReview: boolean;
    fieldName: string | null;
  }>;
  copCheckResultData?: COPCheckResultData;
  isCopLoading?: boolean;
  isCopError?: boolean;
  onInvalidateCopCheck?: () => void;
  shouldShowCopResults?: boolean;
  // AC3: CoP limit exceeded flag
  isCopLimitExceeded?: boolean;
};

function BeneficiaryForm({
  beneficiaryToBeUpdated,
  isBeneficiaryDetailsError,
  getBsbLookup,
  isBsbLookupFetching,
  isBsbLookupError,
  branches,
  apiStatus,
  onUpdateBeneficiary,
  isBeneficiaryUpdateFetching,
  isBeneficiaryUpdateError,
  postAliasLookup,
  payIDDetails,
  isAliasLookupFetching,
  isAliasLookupError,
  doesAliasIdContainInvalidData,
  isPayIdNotValid,
  isPayIdLimitExceeded,
  isPayIdServiceNotAvailable,
  addBeneficiary,
  isBeneficiaryCreateFetching = false,
  isBeneficiaryCreateError = false,
  onRefreshBeneficiaryDetails,
  clearAliasLookup,
  clearBsbLookup,
  isBeneficiaryStatusUpdateFetching = false,
  isDivisionListFetching,
  isDivisionListError,
  allDivisionList,
  postAccountNameCheck,
  lookupState,
  onInvalidateCopCheck,
  copCheckResultData,
  isCopLoading,
  isCopError,
  shouldShowCopResults: shouldShowCopResultsProp,
  isCopLimitExceeded,
}: BeneficiaryFormProps) {
  const form = useForm<FormValues>({
    mode: 'onBlur',
    defaultValues: getDefaultFormValues(beneficiaryToBeUpdated),
    reValidateMode: 'onBlur',
  });

  const {
    trigger,
    control,
    watch,
    getValues,
    setValue,
    handleSubmit,
    clearErrors,
    setError,
    reset,
    formState: { errors },
  } = form;
  const { isDirty } = useFormState({ control });
  const [showPayIDInfo, setShowPayIDInfo] = useState(!!beneficiaryToBeUpdated);
  const [isBeneficiaryAdded, setIsBeneficiaryAdded] = useState(false);

  const [isBeneficiaryUpdated, setIsBeneficiaryUpdated] = useState(false);
  const [selectedPayID, setSelectedPayID] = useState('');
  const [isSubmitClicked, setIsSubmitClicked] = React.useState(false);

  // Field paths configuration for the account name check hook
  const accountNameCheckFieldPaths: AccountNameCheckFieldPaths<FormValues> = {
    bsb: 'bsb',
    accountNumber: 'accountNumber',
    accountName: 'accountName',
    beneficiaryType: 'beneficiaryType',
  };

  // Use the centralized account name check hook for both add and update flows
  const {
    copValidationStatus,
    isCheckDetailsClicked,
    isAccountClosed,
    handleCheckDetails,
    resetValidationState,
    notifyCheckRequired,
  } = useAccountNameCheck<FormValues>({
    form,
    fieldPaths: accountNameCheckFieldPaths,
    bsbBeneficiaryTypeValue: BENEFICIARY_TYPE.ACCOUNT,
    postAccountNameCheck,
    copCheckResultData,
    isCopLoading,
    onAccountValidationChange: undefined,
    onInvalidateCopCheck,
    lookupState,
  });

  // Derive display flags from hook status and container prop (same as payment MFE)
  const shouldShowCopResults =
    copValidationStatus === 'pending' ||
    copValidationStatus === 'validated' ||
    copValidationStatus === 'closed' ||
    shouldShowCopResultsProp;
  const showCheckDetailsAlert = copValidationStatus === 'checkRequired';

  const watchBeneficiaryType =
    watch('beneficiaryType') ||
    getValues('beneficiaryType') ||
    beneficiaryToBeUpdated?.type;

  // Determine if we should show the payment details section
  // Always show when updating a beneficiary, or when there's a beneficiary type selected
  const shouldShowPaymentDetails =
    !!beneficiaryToBeUpdated || !!watchBeneficiaryType;
  const watchBeneficiaryNickname = watch('beneficiaryNickname');
  const watchPayIdType = watch('payIdType');
  const watchBankName = watch('bankName');
  const watchDivisions = watch('divisions')?.label;

  const { closeTab } = useUnifyClose(isDirty);
  const previousBSB = useRef<string>(
    (beneficiaryToBeUpdated?.account as BeneficiaryBSB)?.accountId?.BSB || ''
  );
  const prevPayIdValue = useRef<string>(
    (beneficiaryToBeUpdated?.account as BeneficiaryPayID)?.payIDValue || ''
  );

  // max length of 18 regardless of beneficiary type as per requirements
  const referenceFieldMaxLength = 18;

  const shouldShowDivisionSelect =
    !isStaffPortal() &&
    !isDivisionListError &&
    allDivisionList &&
    allDivisionList.length > 0;
  // Determine if we should show other form fields based on division selection
  const shouldShowOtherFields = shouldShowDivisionSelect
    ? watchDivisions &&
      watchDivisions &&
      watchDivisions !== defaultDivisionData[0].label
    : !isDivisionListFetching && !isDivisionListError;

  const handleRedirectToBeneficiaryList = useHandleRedirectToBeneficiaryList();
  useEffect(() => {
    if (
      isBeneficiaryAdded &&
      !isBeneficiaryCreateFetching &&
      !isBeneficiaryCreateError
    ) {
      // since action has been completed, isMakerCheckerApplicable not applicable
      handleRedirectToBeneficiaryList('success', {
        nickname: watchBeneficiaryNickname,
        action: 'add',
      });
    }
  }, [isBeneficiaryAdded, isBeneficiaryCreateFetching]);

  const handlePayIdTypeChange = useCallback(() => {
    (
      [
        'phone',
        'email',
        'abnAcn',
        'organisationId',
        'beneficiaryNickname',
      ] as (keyof FormValues)[]
    ).forEach(field => setValue(field, ''));
    clearErrors([
      'phone',
      'email',
      'abnAcn',
      'organisationId',
      'beneficiaryNickname',
    ]);
    clearAliasLookup?.();
    prevPayIdValue.current = '';
    setShowPayIDInfo(false);
    setIsSubmitClicked(false);
  }, [clearErrors, setValue]);

  const handleBeneficiaryTypeChange = useCallback(() => {
    const fieldsToReset: (keyof FormValues)[] = [
      'phone',
      'email',
      'abnAcn',
      'organisationId',
      'bsb',
      'accountNumber',
      'accountName',
      'beneficiaryNickname',
      'bankName',
      'payIdType',
      'payIdName',
    ];
    fieldsToReset.forEach(field => setValue(field, ''));
    clearErrors(fieldsToReset);
    // Clear the previous BSB reference value
    previousBSB.current = '';
    setShowPayIDInfo(false);
    setIsSubmitClicked(false);
    // Reset check details validation state using the hook
    resetValidationState();
  }, [clearErrors, setValue, resetValidationState]);

  const onSubmit = (data: FormValues) => {
    setIsBeneficiaryAdded(false);
    setIsBeneficiaryUpdated(false);

    let hasFormErrors = false;

    const isDivisionValid = validateDivisionList();
    if (!isDivisionValid) {
      hasFormErrors = true;
    }

    // Check if BSB/Account beneficiary without Check details validation (both add and update flows)
    if (
      postAccountNameCheck &&
      data.beneficiaryType === BENEFICIARY_TYPE.ACCOUNT &&
      !isCheckDetailsClicked
    ) {
      setIsSubmitClicked(true);
      notifyCheckRequired();
      hasFormErrors = true;
    }

    // prevent submit if fetching alias or bsb or division List
    if (
      isAliasLookupFetching ||
      isBsbLookupFetching ||
      isDivisionListFetching
    ) {
      return;
    }
    // Only prevent submission if BSB has changed AND we don't have successful lookup data
    if (
      data.beneficiaryType === BENEFICIARY_TYPE.ACCOUNT &&
      data.bsb !== previousBSB.current &&
      (!branches || branches.length === 0)
    ) {
      return;
    }
    if (!isAliasLookupFetching && isAliasLookupError) {
      // check for custom validation
      validateAliasLookupStatus();
      hasFormErrors = true;
    }
    if (isBsbLookupError) {
      validateBsbStatus();
      hasFormErrors = true;
    }
    if (hasFormErrors) {
      return;
    }

    // Ensure beneficiaryType is selected before proceeding
    if (!data.beneficiaryType) {
      setError('beneficiaryType', {
        message: ERROR_MESSAGES.BENEFICIARY_TYPE_REQUIRED,
        type: 'manual',
      });
      return;
    }

    if (data && beneficiaryToBeUpdated) {
      const updateBeneParams: PutBeneficiaryParams = mapUpdateBeneficiaryParams(
        data,
        beneficiaryToBeUpdated,
        copCheckResultData?.matchedCOPStatusCode,
        copCheckResultData?.matchedCOPAccountName,
        copCheckResultData?.matchedCOPColour
      );
      if (onUpdateBeneficiary) {
        onUpdateBeneficiary(
          {
            params: updateBeneParams,
            meta: {
              replaceEntities: ['beneficiaryUpdate'],
            },
          },
          {
            headers: {},
          }
        );
      }
      setIsBeneficiaryUpdated(true);
    } else {
      // At this point we know beneficiaryType is defined due to validation above
      const addBeneParams = mapBeneficiaries(
        data,
        copCheckResultData?.matchedCOPStatusCode,
        copCheckResultData?.matchedCOPAccountName,
        copCheckResultData?.matchedCOPColour
      );
      if (addBeneficiary) {
        addBeneficiary(
          { params: addBeneParams },
          {
            headers: {},
          }
        );
      }
      setIsBeneficiaryAdded(true);
    }
    reset(data);
  };

  const onInvalid = (formErrors: typeof errors) => {
    if (!isAliasLookupFetching && isAliasLookupError) {
      validateAliasLookupStatus();
    }
    if (isBsbLookupError) {
      validateBsbStatus();
    }
    // Scroll to the first error field
    if (formErrors && Object.keys(formErrors).length > 0) {
      const firstErrorField = Object.keys(formErrors)[0];
      const errorElement = document.getElementById(firstErrorField);
      if (errorElement && typeof errorElement.scrollIntoView === 'function') {
        errorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
        if (typeof errorElement.focus === 'function') {
          errorElement.focus();
        }
      }
    }
  };

  const validateDivisionList = () => {
    // Only validate if division select should be shown
    if (!shouldShowDivisionSelect) {
      return true;
    }
    // Check if division is not selected
    const isDivisionEmpty =
      !watchDivisions ||
      !watchDivisions ||
      watchDivisions === defaultDivisionData[0].label;
    if (isDivisionEmpty) {
      //  Set error when division is not selected
      setError('divisions', {
        type: 'manual',
        message: 'Select a division.',
      });

      return false;
    }
    return true;
  };
  const validateBsbStatus = () => {
    if (isBsbLookupError) {
      if (apiStatus === 404) {
        setError('bsb', {
          message: ERROR_MESSAGES.BSB_NOT_RECOGNISED,
          type: 'manual',
        });
      } else {
        setError('bsb', {
          message: ERROR_MESSAGES.BSB_SERVICE_UNAVAILABLE,
          type: 'manual',
        });
      }
    } else if (!isBsbLookupFetching && getValues('bsb') && !watchBankName) {
      // Handle case where lookup succeeds but bank name is empty
      setError('bsb', {
        message: ERROR_MESSAGES.BSB_NOT_RECOGNISED,
        type: 'manual',
      });
    } else if (watchBankName) {
      // Clear manual error if bank name is now available and valid
      clearErrors('bsb');
    }
  };

  const resetSubmitClickedState = () => {
    setIsSubmitClicked(false);
  };

  useEffect(() => {
    if (apiStatus) {
      validateBsbStatus();
    }
  }, [apiStatus, isBsbLookupError]);

  useEffect(() => {
    // Validate BSB when bank name changes or lookup completes
    validateBsbStatus();
  }, [watchBankName, isBsbLookupFetching]);

  useEffect(() => {
    if (beneficiaryToBeUpdated) {
      if (getValues('beneficiaryType') === BENEFICIARY_TYPE.PAYID) {
        setShowPayIDInfo(true);
      }
      if (getValues('beneficiaryType') === BENEFICIARY_TYPE.ACCOUNT) {
        setValue(
          'bankName',
          branches?.[0]?.bankName ??
            (beneficiaryToBeUpdated?.account as BeneficiaryBSB)?.bankName
        );
      }
    } else {
      setValue('bankName', branches?.[0]?.bankName ?? '');
    }
  }, [setValue, branches, beneficiaryToBeUpdated]);

  useEffect(
    () =>
      // clear all lookup results in Redux when exit the page
      () => {
        clearBsbLookup?.();
        clearAliasLookup?.();
      },
    []
  );

  const shouldShowBankName =
    !errors.bsb &&
    !isBsbLookupError &&
    !isBsbLookupFetching &&
    getValues('bsb') &&
    watchBankName;

  const formatPayID = (payIDType: AliasType, payIDValue: string): string => {
    switch (payIDType) {
      case AliasType.PHONE: {
        // Remove all leading zeros
        const [_dialCode, number] = payIDValue.split('-');
        const strippedNumber = number?.replace(/^0/, '');
        setValue('phone', `${_dialCode}-${strippedNumber}`);
        return getValues('phone');
      }

      case AliasType.EMAIL: {
        const formattedPayID = payIDValue.trim().toLowerCase();
        setValue('email', formattedPayID);
        return getValues('email');
      }

      case AliasType.ORGN: {
        const formattedPayID = payIDValue.trim().toLowerCase();
        setValue('organisationId', formattedPayID);
        return getValues('organisationId');
      }
      default: {
        return payIDValue;
      }
    }
  };
  const prepopulateBeneficiaryNickname = (name: string) => {
    if (name && !getValues('beneficiaryNickname')) {
      setValue(
        'beneficiaryNickname',
        name.substring(0, INPUT_MAX_LENGTH.BENEFICIARY_NICKNAME)
      );
      clearErrors(['beneficiaryNickname']);
    }
  };
  const triggerAliasLookup = useCallback(
    (fieldName: keyof FormValues, payIDType: AliasType, payIDValue: string) => {
      const formattedPayID = formatPayID(payIDType, payIDValue);
      if (prevPayIdValue.current !== formattedPayID) {
        const validationResult = validateField(fieldName, formattedPayID);
        if (typeof validationResult !== 'string' && postAliasLookup) {
          prevPayIdValue.current = formattedPayID;
          setSelectedPayID(formattedPayID);
          const payIDObj: PayID = {
            aliasType: payIDType,
            aliasId: formattedPayID,
          };
          handleAliasLookup(postAliasLookup)(
            payIDObj,
            isBeneficiaryUpdated ? 'Update Beneficiary' : 'Add Beneficiary'
          );
          clearErrors([fieldName]);
          setShowPayIDInfo(true);
        } else {
          setShowPayIDInfo(false);
        }
      }
    },
    [trigger, postAliasLookup, clearErrors, formatPayID]
  );

  const validateAliasLookupStatus = () => {
    const inputFieldName = getMappedFormFieldNameWithPayIDType(watchPayIdType);
    if (isPayIdNotValid) {
      setShowPayIDInfo(false);
      setError(inputFieldName as keyof FormValues, {
        message: ERROR_MESSAGES.INVALID_PAYID,
        type: 'manual',
      });
    } else if (isPayIdLimitExceeded) {
      setShowPayIDInfo(false);
      setError(inputFieldName as keyof FormValues, {
        message: ERROR_MESSAGES.PAYID_CHECK_LIMIT_EXCEEDED,
        type: 'manual',
      });
    } else if (doesAliasIdContainInvalidData) {
      setShowPayIDInfo(false);
      const invalidDataErrorMessageMap = {
        phone: ERROR_MESSAGES.PHONE,
        email: ERROR_MESSAGES.EMAIL_REQUIRED,
        abnAcn: ERROR_MESSAGES.ABN_ACN,
        organisationId: ERROR_MESSAGES.ORGANISATION_ID,
      };
      setError(inputFieldName as keyof FormValues, {
        message:
          invalidDataErrorMessageMap[
            inputFieldName as keyof typeof invalidDataErrorMessageMap
          ],
        type: 'manual',
      });
    } else if (isPayIdServiceNotAvailable) {
      setShowPayIDInfo(false);
      setError(inputFieldName as keyof FormValues, {
        message: ERROR_MESSAGES.PAYID_SERVICE_UNAVAILABLE,
        type: 'manual',
      });
    }
  };

  const onPayIDChange = (value: string) => {
    if (!value) {
      prevPayIdValue.current = '';
    }
    setIsSubmitClicked(false);
  };

  useEffect(() => {
    const inputFieldName = getMappedFormFieldNameWithPayIDType(watchPayIdType);
    if (!isAliasLookupFetching && isAliasLookupError) {
      validateAliasLookupStatus();
    } else {
      clearErrors(inputFieldName as keyof FormValues);
    }
  }, [
    isPayIdNotValid,
    doesAliasIdContainInvalidData,
    isAliasLookupFetching,
    watchPayIdType,
    isAliasLookupError,
  ]);

  useEffect(() => {
    const inputFieldName = getMappedFormFieldNameWithPayIDType(watchPayIdType);
    clearErrors(inputFieldName as keyof FormValues);
  }, [watchPayIdType, clearErrors]);

  useEffect(() => {
    prepopulateBeneficiaryNickname(payIDDetails?.[0]?.name ?? '');
    if (payIDDetails?.[0]?.name) {
      setValue('payIdName', payIDDetails?.[0]?.name);
    }
  }, [payIDDetails]);

  const isBeneficiaryUpdateInProgress =
    isBeneficiaryUpdateFetching || isBeneficiaryStatusUpdateFetching;

  return (
    <>
      {(isBeneficiaryCreateFetching || isBeneficiaryUpdateInProgress) && (
        <div className="fixed inset-0 flex justify-center items-center bg-border bg-opacity-75 z-50">
          <ProgressIndicator data-testid="progress-indicator" size="medium" />
        </div>
      )}

      {!isBeneficiaryDetailsError &&
      !isDivisionListError &&
      !isDivisionListFetching ? (
        <form
          onSubmit={e => {
            e.preventDefault();
            handleSubmit(onSubmit, onInvalid)();
          }}
          autoComplete="off"
          role="form"
        >
          {shouldShowDivisionSelect && (
            <Well className="!p-2.5 w-full mt-2.5 mb-2.5 bg-light border-light [&_fieldset]:mb-0">
              <MVSelectController
                control={control}
                fieldName="divisions"
                id="divisions"
                width="full"
                label="Division"
                errors={errors}
                options={[
                  ...defaultDivisionData,
                  ...(allDivisionList?.map(division => ({
                    id: division.divisionId,
                    label: division.divisionName,
                    name: division.divisionName,
                  })) || []),
                ]}
                validationRules={{
                  required: 'Select a division.',
                }}
              />
            </Well>
          )}
          {shouldShowOtherFields && (
            <>
              <Heading className="mb-2.5" size={7} tag="h2">
                Beneficiary details
              </Heading>
              <MVButtonGroupController
                id="beneficiaryType"
                label="Beneficiary type"
                fieldName="beneficiaryType"
                control={control}
                trigger={trigger}
                onChange={handleBeneficiaryTypeChange}
                validationRules={{
                  required: ERROR_MESSAGES.BENEFICIARY_TYPE_REQUIRED,
                }}
                buttons={[
                  {
                    value: BENEFICIARY_TYPE.ACCOUNT,
                    label: 'BSB & account number',
                  },
                  { value: BENEFICIARY_TYPE.PAYID, label: 'PayID' },
                ]}
                aria-label="Beneficiary type"
                className="mb-0.5"
              />

              {watchBeneficiaryType &&
                watchBeneficiaryType === BENEFICIARY_TYPE.ACCOUNT && (
                  <>
                    <Grid className="gap-0">
                      <GridItem span={4}>
                        <MVInputController
                          id="bsb"
                          fieldName="bsb"
                          label="BSB"
                          control={control}
                          data-testid="bsb-input"
                          hideCounterText
                          maximumLength={INPUT_MAX_LENGTH.BSB}
                          className="mb-2.5"
                          onBlur={async (
                            event: React.FocusEvent<HTMLInputElement>
                          ) => {
                            // Add a short delay before running the BSB lookup to avoid confusing UX behaviour
                            await new Promise(resolve =>
                              setTimeout(resolve, 150)
                            );
                            const val = event.target.value;
                            if (val !== previousBSB.current) {
                              // if the BSB value has changed
                              previousBSB.current = val;
                              val.length === 6 &&
                                REGEX_PATTERN.DIGIT.test(val) &&
                                fetchBsbLookup(getBsbLookup)(event);
                            }
                            await trigger('bsb');
                          }}
                          matchPattern={REGEX_PATTERN.DIGIT}
                          validationRules={{
                            required: ERROR_MESSAGES.BSB,
                            minLength: {
                              value: 6,
                              message: ERROR_MESSAGES.BSB,
                            },
                            validate: () =>
                              payIdBSBLookupErrorMessage(errors.bsb?.message),
                          }}
                          onChange={resetSubmitClickedState}
                        />
                      </GridItem>
                      {shouldShowBankName && (
                        <GridItem span={12} className="mb-5">
                          <Alert look="info" iconSize="small" className="mb-0">
                            <span className="font-semibold">Bank name: </span>
                            {watchBankName}
                          </Alert>
                        </GridItem>
                      )}
                    </Grid>
                    <Grid>
                      <GridItem span={8}>
                        <MVInputController
                          className="mb-2.5"
                          id="accountNumber"
                          fieldName="accountNumber"
                          label="Account number"
                          control={control}
                          data-testid="account-number-input"
                          hideCounterText
                          maximumLength={INPUT_MAX_LENGTH.ACCOUNT_NUMBER}
                          validationRules={{
                            required: ERROR_MESSAGES.ACCOUNT_NUMBER_REQUIRED,
                            pattern: {
                              value: REGEX_PATTERN.ACCOUNT_NUMBER,
                              message: ERROR_MESSAGES.ACCOUNT_NUMBER_INVALID,
                            },
                          }}
                        />
                        <div className="flex items-end gap-2.5 mb-2.5">
                          <div className="flex-1">
                            <MVInputController
                              id="accountName"
                              className="mb-0 whitespace-pre-wrap"
                              fieldName="accountName"
                              label="Account name"
                              control={control}
                              data-testid="account-name-input"
                              hideCounterText
                              maximumLength={INPUT_MAX_LENGTH.ACCOUNT_NAME}
                              validationRules={{
                                required: ERROR_MESSAGES.ACCOUNT_NAME_REQUIRED,
                                ...nameLikedFieldsValidationRules,
                                validate: {
                                  ...nameLikedFieldsValidationRules.validate,
                                  checkDetailsRequired: () => {
                                    if (
                                      lookupState?.current.triggeredByReview &&
                                      !isCheckDetailsClicked &&
                                      !isAccountClosed
                                    ) {
                                      notifyCheckRequired();
                                      return false;
                                    }
                                    return true;
                                  },
                                },
                              }}
                              trimOnBlur
                              trimOnPaste
                              onBlur={() => {
                                prepopulateBeneficiaryNickname(
                                  getValues('accountName') ?? ''
                                );
                              }}
                            />
                          </div>
                          {postAccountNameCheck && (
                            <div className="flex items-center w-[110px]">
                              {isCopLoading ? (
                                <div className="flex items-center gap-2">
                                  <ProgressIndicator size="small" />
                                  <span>Verifying</span>
                                </div>
                              ) : (
                                <Button
                                  soft
                                  look="hero"
                                  size="small"
                                  type="button"
                                  data-testid="check-details-button"
                                  onClick={async () => {
                                    await handleCheckDetails();
                                  }}
                                >
                                  Check details
                                </Button>
                              )}
                            </div>
                          )}
                        </div>
                      </GridItem>
                    </Grid>
                    <CopResultsSection
                      isCopLimitExceeded={isCopLimitExceeded}
                      shouldShowCopResults={shouldShowCopResults}
                      isCopLoading={isCopLoading}
                      isCopError={isCopError}
                      copCheckResultData={copCheckResultData}
                      showCheckDetailsAlert={showCheckDetailsAlert}
                    />
                  </>
                )}

              {watchBeneficiaryType === BENEFICIARY_TYPE.PAYID && (
                <>
                  <MVButtonGroupController
                    id="payIdType"
                    label="PayID type"
                    fieldName="payIdType"
                    control={control}
                    trigger={trigger}
                    validationRules={{
                      required: ERROR_MESSAGES.PAYID_TYPE_REQUIRED,
                    }}
                    className="mb-0.5"
                    buttons={[
                      {
                        value: PAYID_TYPE.PHONE,
                        label: getFriendlyPayIDType(PAYID_TYPE.PHONE),
                      },
                      {
                        value: PAYID_TYPE.EMAIL,
                        label: getFriendlyPayIDType(PAYID_TYPE.EMAIL),
                      },
                      {
                        value: PAYID_TYPE.ABN_ACN,
                        label: getFriendlyPayIDType(PAYID_TYPE.ABN_ACN),
                      },
                      {
                        value: PAYID_TYPE.ORGANISATION_ID,
                        label: getFriendlyPayIDType(PAYID_TYPE.ORGANISATION_ID),
                      },
                    ]}
                    onChange={handlePayIdTypeChange}
                    aria-label="PayID type"
                  />
                  {watchPayIdType === PAYID_TYPE.PHONE && (
                    <Grid>
                      <GridItem span={6}>
                        <MVPhoneInputController
                          id="phone"
                          label={getFriendlyPayIDType(PAYID_TYPE.PHONE)}
                          fieldName="phone"
                          control={control}
                          data-testid="phone-input"
                          maximumLength={INPUT_MAX_LENGTH.PHONE}
                          className="mb-2.5"
                          onBlur={() => {
                            const isValid = validatePhone(getValues('phone'));
                            if (isValid === true) {
                              triggerAliasLookup(
                                'phone',
                                AliasType.PHONE,
                                getValues('phone')
                              );
                            }
                          }}
                          onChange={onPayIDChange}
                          matchPattern={REGEX_PATTERN.DIGIT}
                          validationRules={{
                            validate: (value: string) => {
                              if (validatePhone(value) !== true) {
                                return validatePhone(value);
                              }
                              return payIdBSBLookupErrorMessage(
                                errors.phone?.message
                              );
                            },
                          }}
                        />
                      </GridItem>
                    </Grid>
                  )}
                  {watchPayIdType === PAYID_TYPE.EMAIL && (
                    <Grid>
                      <GridItem span={6}>
                        <MVInputController
                          id="email"
                          fieldName="email"
                          label={getFriendlyPayIDType(PAYID_TYPE.EMAIL)}
                          control={control}
                          data-testid="email-input"
                          hideCounterText
                          maximumLength={INPUT_MAX_LENGTH.EMAIL_OR_ORG_ID}
                          className="mb-2.5 whitespace-pre-wrap"
                          onBlur={(event: React.FocusEvent<HTMLInputElement>) =>
                            triggerAliasLookup(
                              'email',
                              AliasType.EMAIL,
                              event.target.value
                            )
                          }
                          onChange={onPayIDChange}
                          validationRules={{
                            validate: (value: string) => {
                              if (validateEmail(value) !== true) {
                                return validateEmail(value);
                              }
                              return payIdBSBLookupErrorMessage(
                                errors.email?.message
                              );
                            },
                          }}
                          trimOnBlur
                          trimOnPaste
                        />
                      </GridItem>
                    </Grid>
                  )}
                  {watchPayIdType === PAYID_TYPE.ABN_ACN && (
                    <Grid>
                      <GridItem span={6}>
                        <MVInputController
                          id="abnAcn"
                          fieldName="abnAcn"
                          label={getFriendlyPayIDType(PAYID_TYPE.ABN_ACN)}
                          control={control}
                          data-testid="abn-acn-input"
                          hideCounterText
                          maximumLength={INPUT_MAX_LENGTH.ABN_ACN}
                          className="mb-2.5"
                          onBlur={(event: React.FocusEvent<HTMLInputElement>) =>
                            triggerAliasLookup(
                              'abnAcn',
                              AliasType.AUBN,
                              event.target.value
                            )
                          }
                          onChange={onPayIDChange}
                          matchPattern={REGEX_PATTERN.DIGIT}
                          validationRules={{
                            validate: (value: string) => {
                              if (validateAbnAcn(value) !== true) {
                                return validateAbnAcn(value);
                              }
                              return payIdBSBLookupErrorMessage(
                                errors.abnAcn?.message
                              );
                            },
                          }}
                        />
                      </GridItem>
                    </Grid>
                  )}
                  {watchPayIdType === PAYID_TYPE.ORGANISATION_ID && (
                    <Grid>
                      <GridItem span={6}>
                        <MVInputController
                          id="organisationId"
                          fieldName="organisationId"
                          label={getFriendlyPayIDType(
                            PAYID_TYPE.ORGANISATION_ID
                          )}
                          control={control}
                          data-testid="organisation-id-input"
                          hideCounterText
                          className="mb-2.5 whitespace-pre-wrap"
                          onBlur={(event: React.FocusEvent<HTMLInputElement>) =>
                            triggerAliasLookup(
                              'organisationId',
                              AliasType.ORGN,
                              event.target.value
                            )
                          }
                          onChange={onPayIDChange}
                          maximumLength={INPUT_MAX_LENGTH.EMAIL_OR_ORG_ID}
                          validationRules={{
                            validate: (value: string) => {
                              if (validateOrganisationId(value) !== true) {
                                return validateOrganisationId(value);
                              }
                              return payIdBSBLookupErrorMessage(
                                errors.organisationId?.message
                              );
                            },
                          }}
                          trimOnBlur
                          trimOnPaste
                        />
                      </GridItem>
                    </Grid>
                  )}
                  {showPayIDInfo && (
                    <Grid>
                      <GridItem span={12}>
                        {isAliasLookupFetching && !isAliasLookupError ? (
                          <div className="flex flex-row items-center pl-0 mb-2.5">
                            <ProgressIndicator size="small" />
                            <div className="pl-1">Verifying PayID</div>
                          </div>
                        ) : (
                          <Alert
                            className="mb-2.5 text-info"
                            look="info"
                            iconSize="small"
                          >
                            <MVAccountFormatter
                              details={[
                                {
                                  label: 'PayID name:',
                                  value:
                                    payIDDetails?.[0]?.name ??
                                    (
                                      beneficiaryToBeUpdated?.account as BeneficiaryPayID
                                    )?.payIDName,
                                  className:
                                    'm-0 whitespace-normal typography-body-11',
                                  labelClassName: 'text-info',
                                  variant: 'text',
                                },
                                {
                                  label: 'PayID:',
                                  value:
                                    selectedPayID !== ''
                                      ? selectedPayID
                                      : (
                                          beneficiaryToBeUpdated?.account as BeneficiaryPayID
                                        )?.payIDValue,
                                  className:
                                    'm-0 overflow-hidden break-words typography-body-11',
                                  labelClassName: 'text-info',
                                  variant: 'text',
                                },
                                {
                                  label: 'PayID type:',
                                  value:
                                    watchPayIdType !== PAYID_TYPE.ABN_ACN
                                      ? getFriendlyPayIDType(
                                          watchPayIdType || PAYID_TYPE.PHONE
                                        )
                                      : 'ABN',
                                  className:
                                    'm-0 overflow-hidden break-words typography-body-11',
                                  labelClassName: 'text-info',
                                  variant: 'text',
                                },
                              ]}
                            />
                          </Alert>
                        )}
                      </GridItem>
                    </Grid>
                  )}
                </>
              )}

              {shouldShowPaymentDetails && (
                <>
                  <Grid>
                    <GridItem span={6}>
                      <MVInputController
                        className="mb-2.5 whitespace-pre-wrap"
                        id="beneficiaryNickname"
                        fieldName="beneficiaryNickname"
                        label="Beneficiary nickname"
                        control={control}
                        hideCounterText
                        maximumLength={INPUT_MAX_LENGTH.BENEFICIARY_NICKNAME}
                        validationRules={{
                          required:
                            ERROR_MESSAGES.BENEFICIARY_NICKNAME_REQUIRED,
                          ...nameLikedFieldsValidationRules,
                        }}
                        trimOnBlur
                        trimOnPaste
                      />
                    </GridItem>
                  </Grid>
                  <Grid>
                    <GridItem
                      span={12}
                      className="pt-2.5 border-t-solid border-t border-t-border"
                    >
                      <Heading className="mb-2.5" size={7} tag="h2">
                        Payment details
                      </Heading>

                      <MVSelectController
                        className="mb-2.5"
                        control={control}
                        fieldName="currency"
                        label="Currency"
                        errors={errors}
                        options={[
                          {
                            id: CURRENCY.AUD,
                            label: CURRENCY.AUD,
                            name: CURRENCY.AUD,
                          },
                        ]}
                        width={3}
                      />

                      <div className="mb-2.5">
                        <MVCurrencyController
                          id="amount-payment-details"
                          control={control}
                          width={10}
                          fieldName="amount"
                          errors={errors}
                          trigger={trigger}
                          label="Amount - Optional"
                          validationRules={{
                            required: false,
                            validate: (value: string) => {
                              // Allow empty values (optional field)
                              if (!value || value.trim() === '') {
                                return true;
                              }
                              // If value is provided, validate it using the same logic as the original
                              const num = Number(value);
                              const isNaN = Number.isNaN(num);
                              if (isNaN)
                                return 'Enter an amount greater than 0, up to two decimal places.';
                              const digitsAfterDecimal =
                                value.split('.')[1]?.length;
                              if (digitsAfterDecimal > 2 || num <= 0)
                                return 'Enter an amount greater than 0, up to two decimal places.';
                              return true;
                            },
                          }}
                        />
                      </div>

                      <Grid>
                        <GridItem span={6}>
                          <MVInputController
                            hint="For you and the beneficiary."
                            className="mb-2.5"
                            id="toAccount-payment-reference-description"
                            label="Reference - Optional"
                            fieldName="toReference"
                            control={control}
                            validationRules={DESCRIPTION_VALIDATION_RULES}
                            maximumLength={referenceFieldMaxLength}
                            trimOnBlur
                            trimOnPaste
                          />
                        </GridItem>
                      </Grid>
                    </GridItem>
                  </Grid>
                </>
              )}
            </>
          )}

          {beneficiaryToBeUpdated && (
            <GridItem span={12}>
              <Alert className="mb-2.5" look="info" iconSize="small">
                {ERROR_MESSAGES.BENEFICIARY_CHANGE_DISCLAIMER}
              </Alert>
            </GridItem>
          )}
          {isAliasLookupFetching && isSubmitClicked && (
            <Alert
              className="mb-2.5"
              mode="text"
              look="danger"
              iconSize="xsmall"
            >
              PayID verification is in progress. You can continue when
              verification is complete.
            </Alert>
          )}
          {isBsbLookupFetching && isSubmitClicked && (
            <Alert
              className="mb-2.5"
              mode="text"
              look="danger"
              iconSize="xsmall"
            >
              BSB verification is in progress. You can continue when
              verification is complete.
            </Alert>
          )}
          <div className="border-t-solid border-t border-t-border pt-2.5">
            <Button
              look="primary"
              size="small"
              data-testid="add-or-update-beneficiary-button"
              type="submit"
              onClick={e => {
                setIsSubmitClicked(true);
                if (
                  isBsbLookupFetching ||
                  isAliasLookupFetching ||
                  isAccountClosed
                ) {
                  // Prevent form submission/validation
                  e.preventDefault();
                }
              }}
            >
              {beneficiaryToBeUpdated ? 'Update' : 'Add'} beneficiary
            </Button>
            <Button
              className="ml-1.5"
              type="button"
              size="small"
              soft
              onClick={() => closeTab()}
            >
              Cancel
            </Button>
          </div>
        </form>
      ) : (
        <>
          {isDivisionListFetching && (
            <div className="mb-3" data-testid="division-list-loader">
              <MVPageLoader iconSize="medium" />
            </div>
          )}
          <div className="border-t-solid border-t border-t-border pt-2.5">
            <Button
              className="ml-0"
              type="button"
              size="small"
              soft
              onClick={() => closeTab()}
            >
              Cancel
            </Button>
          </div>
        </>
      )}
    </>
  );
}

export default BeneficiaryForm;
