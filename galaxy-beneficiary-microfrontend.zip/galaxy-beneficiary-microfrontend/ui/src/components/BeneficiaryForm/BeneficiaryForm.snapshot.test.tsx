/* eslint-disable react/react-in-jsx-scope */
import {
  useCancelModal,
  useClose,
  useIsDesktopVersion,
  usePlatformState,
} from '@mesh-tenant-multiverse-common/react';
import '@testing-library/jest-dom';
import { render, screen } from '@testing-library/react';
import BeneficiaryForm from './BeneficiaryForm';

// Mock react-router-dom to avoid useRef issues with MemoryRouter
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn(),
  useLocation: () => ({ pathname: '/', search: '', hash: '', state: null }),
  useParams: () => ({}),
}));

// Mock react-hook-form to avoid useRef null issues in Jest
jest.mock('react-hook-form', () => ({
  ...jest.requireActual('react-hook-form'),
  useForm: () => ({
    control: {
      register: jest.fn(),
      unregister: jest.fn(),
      getFieldState: jest.fn(() => ({ invalid: false, error: undefined })),
      _names: {
        mount: new Set(),
        unMount: new Set(),
        array: new Set(),
        watch: new Set(),
      },
      _subjects: {
        watch: { subscribe: jest.fn(() => ({ unsubscribe: jest.fn() })) },
      },
      _getWatch: jest.fn(),
      _formValues: {},
      _defaultValues: {},
    },
    handleSubmit: jest.fn((fn: any) => (e: any) => {
      e?.preventDefault();
      return fn({});
    }),
    formState: {
      errors: {},
      isDirty: false,
      isValid: true,
      isSubmitting: false,
    },
    reset: jest.fn(),
    watch: jest.fn(() => ''),
    setValue: jest.fn(),
    getValues: jest.fn(() => ({})),
    trigger: jest.fn(),
    setError: jest.fn(),
    clearErrors: jest.fn(),
    register: jest.fn(() => ({
      onChange: jest.fn(),
      onBlur: jest.fn(),
      ref: jest.fn(),
      name: '',
    })),
  }),
  useFormState: () => ({ errors: {} }),
  useController: ({ name }: any) => ({
    field: {
      name,
      value: '',
      onChange: jest.fn(),
      onBlur: jest.fn(),
      ref: jest.fn(),
    },
    fieldState: {
      invalid: false,
      isTouched: false,
      isDirty: false,
      error: undefined,
    },
  }),
  Controller: ({ render: renderProp, name }: any) => {
    const field = {
      value: '',
      onChange: jest.fn(),
      onBlur: jest.fn(),
      name,
      ref: jest.fn(),
    };
    return renderProp({ field, fieldState: { error: undefined } });
  },
}));

// Mock @westpac/ui to avoid React child rendering issues
jest.mock('@westpac/ui', () => ({
  Alert: ({ children, ...props }: any) => (
    <div data-testid="alert" {...props}>
      {children}
    </div>
  ),
  Button: ({ children, onClick, ...props }: any) => (
    <button onClick={onClick} {...props}>
      {children}
    </button>
  ),
  Grid: ({ children, ...props }: any) => <div {...props}>{children}</div>,
  GridItem: ({ children, ...props }: any) => <div {...props}>{children}</div>,
  Heading: ({ children, ...props }: any) => <h2 {...props}>{children}</h2>,
  ProgressIndicator: ({ ...props }: any) => (
    <div data-testid="progress-indicator" {...props} />
  ),
  Well: ({ children, ...props }: any) => <div {...props}>{children}</div>,
}));

// Mock mv-selectcontroller to avoid React Aria hooks causing useRef issues
jest.mock('@mesh-tenant-multiverse-ui-common/mv-selectcontroller', () => {
  const MVSelectController = ({ fieldName, label, options, ...props }: any) => (
    <select
      name={fieldName}
      aria-label={label}
      data-testid={`select-${fieldName}`}
    >
      {options?.map((opt: any) => (
        <option key={opt.value} value={opt.value}>
          {opt.label}
        </option>
      ))}
    </select>
  );
  return { MVSelectController };
});

// Mock mv-accountformatter
jest.mock('@mesh-tenant-multiverse-ui-common/mv-accountformatter', () => ({
  MVAccountFormatter: ({ children }: any) => <span>{children}</span>,
}));

// Mock mv-pageloader
jest.mock('@mesh-tenant-multiverse-ui-common/mv-pageloader', () => ({
  MVPageLoader: () => <div data-testid="mock-page-loader">Loading...</div>,
}));

// Mock mv-openfin
jest.mock('@mesh-tenant-multiverse-ui-common/mv-openfin', () => ({
  useUnifyClose: () => ({ closeTab: jest.fn() }),
}));

// Mock mv-cop-accountname-check
jest.mock('@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check', () => {
  const React = require('react');
  const MockComponent = React.forwardRef((props: any, ref: any) => {
    React.useImperativeHandle(ref, () => ({
      triggerCheck: jest.fn(),
      reset: jest.fn(),
    }));
    return <div data-testid="cop-results" />;
  });
  return {
    MVCopAccountNameCheck: MockComponent,
  };
});

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useClose: jest.fn(),
  useCancelModal: jest.fn(),
  useConfirmClose: jest.fn(),
  useIsDesktopVersion: jest.fn(),
  usePlatformState: jest.fn(),
}));

jest.mock('@mep-ui/framework-router-addon', () => {
  const mockNavigate = jest.fn();
  return {
    ...jest.requireActual('@mep-ui/framework-router-addon'),
    useNavigate: () => mockNavigate,
  };
});

jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  MVButtonGroupController: ({ id, label }: any) => (
    <div>
      <span>{label}</span>
      <div data-testid={id}>Mocked MVButtonGroupController</div>
    </div>
  ),
  MVInputController: ({ fieldname }: any) => <input name={fieldname} />,
  MVCurrencyController: ({ fieldname }: any) => <input name={fieldname} />,
  MVSelectController: ({ fieldname }: any) => <select name={fieldname} />,
  MVPhoneInputController: ({ fieldname }: any) => <input name={fieldname} />,
  getTodayAtLastYear: () => ({ toFormat: () => '2024-01-18' }),
  getToday: () => ({ toFormat: () => '2025-01-18' }),
}));
jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-utils'),
  useHandleRaiseIntent: jest.fn(),
}));

(usePlatformState as jest.Mock).mockReturnValue([{ id: 'ORG123' }, jest.fn()]);

const defaultProps = {
  isBeneficiaryDetailsError: false,
  isPayIdServiceNotAvailable: false,
  getBsbLookup: jest.fn(),
  postAliasLookup: jest.fn(),
  clearAliasLookup: jest.fn(),
  clearBsbLookup: jest.fn(),
};

describe('BeneficiaryForm Snapshot only', () => {
  const closeTabMock = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    (useClose as jest.Mock).mockImplementation(() => ({
      closeTab: closeTabMock,
    }));
    (useCancelModal as jest.Mock).mockImplementation(() => ({
      closeTab: closeTabMock,
    }));
    (useIsDesktopVersion as jest.Mock).mockReturnValue(false);
    (usePlatformState as jest.Mock).mockReturnValue([{ id: '' }]);
  });

  it('renders the component', () => {
    const { container } = render(
      <BeneficiaryForm
        {...defaultProps}
        isBsbLookupFetching={false}
        isBsbLookupError={false}
        branches={[]}
        isPayIdNotValid={false}
      />
    );
    expect(screen.getByText('Beneficiary type')).toBeInTheDocument();
    expect(container).toMatchSnapshot();
  });
});
