import { MVInputController } from '@mesh-tenant-multiverse-ui-common/mv-reacthookform';
import { CheckboxGroup, GridItem } from '@westpac/ui';
import { Controller } from 'react-hook-form';
import { MVAccordion } from '@mesh-tenant-multiverse-ui-common/mv-accordion';
import {
  BENEFICIARY_VALIDATION_RULES,
  BeneficiaryListSearchFormProps,
  beneficiaryStatusOptions,
} from './BeneficiaryListSearchForm.types';
import { useState } from 'react';
import { SearchBeneficiaryInputPlaceholder } from '../../common/constants';

const BeneficiaryListSearchForm = ({
  handleApplyClick,
  control,
}: BeneficiaryListSearchFormProps) => {
  const [isAccordionExpanded, setIsAccordionExpanded] = useState(true);

  const handleAccordionToggle = (expanded: boolean) => {
    setIsAccordionExpanded(expanded);
  };

  return (
    <>
      <MVAccordion
        isExpanded={isAccordionExpanded}
        defaultExpanded={true}
        onButtonClick={handleApplyClick}
        onToggle={handleAccordionToggle}
        loading={false}
      >
        <GridItem
          span={12}
          className="col-span-12 sm:col-span-8 md:col-span-8 lg:col-span-7"
        >
          <MVInputController
            id="beneficiarySearchCriteria"
            label="Search by"
            size="small"
            hideCounterText
            fieldName="beneficiarySearchCriteria"
            placeholder={SearchBeneficiaryInputPlaceholder}
            control={control}
            maximumLength={256}
            validationRules={{
              validate: BENEFICIARY_VALIDATION_RULES.validate,
            }}
            className="mb-0 whitespace-pre-wrap"
          />
        </GridItem>
        <GridItem className="-mb-2" span={12}>
          <div className="flex items-center">
            <Controller
              name="archivedBeneficiaryStatus"
              control={control}
              defaultValue={[]}
              render={({ field }) => (
                <CheckboxGroup
                  checkboxes={beneficiaryStatusOptions}
                  {...field}
                  orientation="horizontal"
                  className="include-archived-beneficiaries"
                  aria-label="Include archived beneficiaries"
                />
              )}
            />
          </div>
        </GridItem>
      </MVAccordion>
    </>
  );
};

export default BeneficiaryListSearchForm;
