import { Control } from 'react-hook-form';
import { BeneficiaryListSearchFormData, BeneficiaryListSearchFormProps } from './BeneficiaryListSearchForm.types';

describe('BeneficiaryListSearchForm.types', () => {
  describe('BeneficiaryListSearchFormProps interface', () => {
    it('should accept valid props structure', () => {
      const validProps: BeneficiaryListSearchFormProps = {
       handleApplyClick: jest.fn(),
      control: {} as Control<BeneficiaryListSearchFormData>,
      };

      expect(validProps).toBeDefined();
    });

 
  });

}); 


