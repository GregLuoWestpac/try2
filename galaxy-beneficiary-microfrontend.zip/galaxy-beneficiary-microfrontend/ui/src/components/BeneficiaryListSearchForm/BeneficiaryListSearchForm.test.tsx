import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import BeneficiaryListSearchForm from './BeneficiaryListSearchForm';
import { BeneficiaryListSearchFormProps } from './BeneficiaryListSearchForm.types';

// Mock @westpac/ui to avoid React child rendering issues
jest.mock('@westpac/ui', () => ({
  CheckboxGroup: ({ children, ...props }: any) => (
    <div data-testid="checkbox-group" {...props}>
      {children}
    </div>
  ),
  GridItem: ({ children, ...props }: any) => <div {...props}>{children}</div>,
}));

// Mock react-hook-form
jest.mock('react-hook-form', () => ({
  ...jest.requireActual('react-hook-form'),
  useForm: () => ({
    control: {},
    handleSubmit: (fn: any) => (e: any) => {
      e?.preventDefault();
      fn({ beneficiarySearchCriteria: '', beneficiaryStatus: [] });
    },
    formState: { errors: {} },
    reset: jest.fn(),
    watch: jest.fn(() => ({
      unsubscribe: jest.fn(),
    })),
  }),
  Controller: ({ render: renderProp }: any) => {
    const field = {
      value: [],
      onChange: jest.fn(),
      onBlur: jest.fn(),
      name: 'beneficiaryStatus',
      ref: jest.fn(),
    };
    return renderProp({ field });
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-accordion', () => ({
  MVAccordion: ({
    isExpanded,
    title,
    onButtonClick,
    buttonText,
    onToggle,
    children,
    loading,
  }: any) => (
    <div>
      <div data-testid="accordion-title">{title}</div>

      <button
        data-testid="accordion-toggle-button"
        onClick={() => onToggle(!isExpanded)}
      ></button>
      {isExpanded && <div data-testid="accordion-children">{children}</div>}
      <button data-testid="accordion-apply-button" onClick={onButtonClick}>
        {buttonText || 'Apply'}
      </button>
    </div>
  ),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  MVInputController: ({
    fieldName,
    placeholder,
    label,
    control,
    ...props
  }: any) => (
    <div data-testid={`input-${fieldName}`}>
      <label>{label}</label>
      <input
        placeholder={placeholder}
        data-testid={`${fieldName}-input`}
        {...props}
      />
    </div>
  ),
}));

// Mock data
const mockBeneficiaries = [
  {
    id: '1',
    nickname: 'Test Beneficiary 1',
    status: 'ACTIVE',
  },
  {
    id: '2',
    nickname: 'Test Beneficiary 2',
    status: 'ARCHIVED',
  },
];

const defaultProps: BeneficiaryListSearchFormProps = {
  handleApplyClick: jest.fn(),
  control: {} as any,
};

describe('BeneficiaryListSearchForm', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render the search form with input and checkbox', () => {
    render(<BeneficiaryListSearchForm {...defaultProps} />);

    // Check if search input is rendered
    expect(
      screen.getByTestId('input-beneficiarySearchCriteria')
    ).toBeInTheDocument();

    // Check if apply button is rendered
    expect(screen.getByTestId('accordion-apply-button')).toBeInTheDocument();
  });

  it('should call handleFilterSearch when form is submitted', async () => {
    render(<BeneficiaryListSearchForm {...defaultProps} />);

    const applyButton = screen.getByTestId('accordion-apply-button');

    // Click the apply button to submit form
    fireEvent.click(applyButton);

    await waitFor(() => {
      expect(defaultProps.handleApplyClick).toHaveBeenCalled();
    });
  });

  it('should call onFormChange when provided', () => {
    const onFormChange = jest.fn();

    render(<BeneficiaryListSearchForm {...defaultProps} />);

    // onFormChange should be set up via watch effect
    expect(onFormChange).toBeDefined();
  });

  it('should handle accordion toggle', () => {
    render(<BeneficiaryListSearchForm {...defaultProps} />);

    const toggleButton = screen.getByTestId('accordion-toggle-button');

    fireEvent.click(toggleButton);

    // Accordion toggle should work
    expect(toggleButton).toBeInTheDocument();
  });

  // Snapshot Test: Ensures component structure doesn't change unexpectedly
  it('should match snapshot', () => {
    const { container } = render(
      <BeneficiaryListSearchForm {...defaultProps} />
    );
    expect(container.firstChild).toMatchSnapshot();
  });
});
