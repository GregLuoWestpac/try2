import {
  getFormattedForbiddenCharacters,
  validateWithLibrary,
} from '@mesh-tenant-multiverse-ui-common/mv-injection-checker';

import { Control, RegisterOptions } from 'react-hook-form';

// eslint-disable-next-line no-shadow
export enum BeneficiaryStatus {
  ACTIVE = 'ACTIVE',
  ON_HOLD = 'ON-HOLD',
  ARCHIVED = 'ARCHIVED',
}
// eslint-disable-next-line no-shadow
export enum ArchivedBeneficiaryStatus {
  ARCHIVED = 'ARCHIVED',
}

export type BeneficiaryListSearchFormData = {
  beneficiarySearchCriteria: string;
  archivedBeneficiaryStatus: ArchivedBeneficiaryStatus[];
};

export type BeneficiaryListSearchFormProps = {
  handleApplyClick: (e?: React.MouseEvent) => void;
  control: Control<BeneficiaryListSearchFormData>;
};

export const beneficiaryStatusOptions = [
  {
    label: 'Include archived beneficiaries',
    value: ArchivedBeneficiaryStatus.ARCHIVED,
  },
];

export const BENEFICIARY_VALIDATION_RULES: RegisterOptions = {
  validate: (value: string) =>
    !validateWithLibrary(value) ||
    `You cannot use the following special characters  ${getFormattedForbiddenCharacters()}`,
};
