import React from 'react';
import { Alert } from '@westpac/ui';

export default function StaySafeFromScamsBanner() {
  return (
    <Alert look="warning" className="my-2.5" iconSize="small">
      <span className="font-semibold">Stay safe from scams.</span> Scammers pretend to be people you trust.
      Always confirm details by calling the beneficiary using an existing number
      you trust. We may not be able to recover your money if it is a scam.
    </Alert>
  );
}
