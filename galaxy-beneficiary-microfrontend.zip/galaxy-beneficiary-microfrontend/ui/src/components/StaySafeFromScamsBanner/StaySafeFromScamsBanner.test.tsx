import React from 'react';
import { render, screen } from '@testing-library/react';
import StaySafeFromScamsBanner from './StaySafeFromScamsBanner';

// Mock @westpac/ui to avoid React child rendering issues
jest.mock('@westpac/ui', () => ({
  Alert: ({ children, ...props }: any) => (
    <div data-testid="alert" {...props}>
      {children}
    </div>
  ),
}));

describe('StaySafeFromScamsBanner', () => {
  it('renders the warning alert with correct text', () => {
    render(<StaySafeFromScamsBanner />);
    const alertElement = screen.getByText('Stay safe from scams.', {
      selector: 'span',
    });
    expect(alertElement).toBeInTheDocument();
    expect(
      screen.getByText(/Scammers pretend to be people you trust/)
    ).toBeInTheDocument();
  });
});
