import { render, screen } from '@testing-library/react';
import { DivisionDisplay } from './DivisionDisplay';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-accountsummary', () => ({
  MVAccountSummary: ({ items }: any) => (
    <div data-testid="mv-account-summary">
      {items.map((item: any, idx: number) => (
        <div key={idx}>
          <span>{item.title}</span>: <span>{item.content}</span>
        </div>
      ))}
    </div>
  ),
}));

jest.mock('@westpac/ui', () => ({
  GridItem: ({ children, className, span }: any) => (
    <div data-testid="grid-item" className={className} data-span={span}>
      {children}
    </div>
  ),
}));

describe('DivisionDisplay', () => {
  it.skip('renders nothing when no props are provided', () => {
    render(<DivisionDisplay />);
    expect(screen.getByTestId('mv-account-summary').textContent).toBe('');
  });

  it('renders division when division prop is provided', () => {
    render(<DivisionDisplay division="Retail" />);
    expect(screen.getByText('Division')).toBeInTheDocument();
    expect(screen.getByText('Retail')).toBeInTheDocument();
  });

  it('renders only division when division prop is provided', () => {
    render(<DivisionDisplay division="Corporate" />);
    expect(screen.getByText('Division')).toBeInTheDocument();
    expect(screen.getByText('Corporate')).toBeInTheDocument();
  });

  it.skip('applies gridClassName to GridItem', () => {
    render(<DivisionDisplay gridClassName="custom-class" />);
    const gridItem = screen.getByTestId('grid-item');
    expect(gridItem).toHaveClass('w-full');
    expect(gridItem).toHaveClass('custom-class');
    expect(gridItem).toHaveAttribute('data-span', '12');
  });
});
