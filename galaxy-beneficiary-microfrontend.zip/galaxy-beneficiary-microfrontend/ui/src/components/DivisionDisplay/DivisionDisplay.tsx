/* eslint-disable react/require-default-props */
import { MVAccountSummary } from '@mesh-tenant-multiverse-ui-common/mv-accountsummary';
import { GridItem } from '@westpac/ui';
import React from 'react';

type DivisionDisplayItem = {
  title: string;
  content: React.ReactNode | string;
};

type Props = {
  division?: string;
  gridClassName?: string;
};

export function DivisionDisplay({ division = '', gridClassName }: Props) {
  const items: DivisionDisplayItem[] = [
    ...(division ? [{ title: 'Division', content: division }] : []),
  ];

  if (items.length === 0) {
    return null;
  }
  return (
    <GridItem className={`w-full ${gridClassName}`} span={12}>
      <MVAccountSummary items={items} gridClassName="mt-0" />
    </GridItem>
  );
}
