import React from 'react';
import PropTypes from 'prop-types';

export default function Sample({ message }: { message: string }): JSX.Element {
  return <h1>Hello World {message}</h1>;
}

Sample.propTypes = {
  message: PropTypes.string.isRequired,
};