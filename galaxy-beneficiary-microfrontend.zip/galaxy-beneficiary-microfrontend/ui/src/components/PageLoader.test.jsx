import React from 'react';
import { render, screen } from '@testing-library/react';
import PageLoader from './PageLoader';

// Mock the ProgressIndicator component from @westpac/ui
jest.mock('@westpac/ui', () => ({
  ProgressIndicator: jest.fn(({ size }) => (
    <div data-testid="progress-indicator" data-size={size}>
      Loading...
    </div>
  )),
}));

describe('PageLoader', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Rendering', () => {
    it('renders successfully with default props', () => {
      render(<PageLoader />);
      expect(screen.getByTestId('page-loader')).toBeInTheDocument();
      expect(screen.getByTestId('progress-indicator')).toBeInTheDocument();
    });

    it('renders ProgressIndicator with default medium size', () => {
      render(<PageLoader />);
      const progressIndicator = screen.getByTestId('progress-indicator');
      expect(progressIndicator).toHaveAttribute('data-size', 'medium');
    });

    it('applies correct container class for normal placement by default', () => {
      render(<PageLoader />);
      const container = screen.getByTestId('page-loader');
      expect(container).toHaveClass(
        'flex',
        'flex-1',
        'justify-center',
        'items-center'
      );
      expect(container).not.toHaveClass('min-h-screen', 'h-full');
    });
  });

  describe('Icon Size Props', () => {
    const iconSizes = ['xsmall', 'small', 'medium', 'large', 'xlarge'];

    iconSizes.forEach(size => {
      it(`renders with ${size} icon size`, () => {
        render(<PageLoader iconSize={size} />);
        const progressIndicator = screen.getByTestId('progress-indicator');
        expect(progressIndicator).toHaveAttribute('data-size', size);
      });
    });
  });

  describe('Placement Props', () => {
    it('applies normal placement classes by default', () => {
      render(<PageLoader />);
      const container = screen.getByTestId('page-loader');
      expect(container).toHaveClass(
        'flex',
        'flex-1',
        'justify-center',
        'items-center'
      );
    });

    it('applies normal placement classes when explicitly set', () => {
      render(<PageLoader placement="normal" />);
      const container = screen.getByTestId('page-loader');
      expect(container).toHaveClass(
        'flex',
        'flex-1',
        'justify-center',
        'items-center'
      );
      expect(container).not.toHaveClass('min-h-screen', 'h-full');
    });

    it('applies middle placement classes when set to middle', () => {
      render(<PageLoader placement="middle" />);
      const container = screen.getByTestId('page-loader');
      expect(container).toHaveClass(
        'flex',
        'min-h-screen',
        'h-full',
        'justify-center',
        'items-center'
      );
      expect(container).not.toHaveClass('flex-1');
    });
  });

  describe('Combined Props', () => {
    it('handles both iconSize and placement props together', () => {
      render(<PageLoader iconSize="large" placement="middle" />);

      const container = screen.getByTestId('page-loader');
      expect(container).toHaveClass(
        'flex',
        'min-h-screen',
        'h-full',
        'justify-center',
        'items-center'
      );

      const progressIndicator = screen.getByTestId('progress-indicator');
      expect(progressIndicator).toHaveAttribute('data-size', 'large');
    });

    it('handles different combinations of props', () => {
      render(<PageLoader iconSize="xsmall" placement="normal" />);

      const container = screen.getByTestId('page-loader');
      expect(container).toHaveClass(
        'flex',
        'flex-1',
        'justify-center',
        'items-center'
      );

      const progressIndicator = screen.getByTestId('progress-indicator');
      expect(progressIndicator).toHaveAttribute('data-size', 'xsmall');
    });
  });

  describe('ProgressIndicator Integration', () => {
    it('passes the correct size prop to ProgressIndicator', () => {
      const { ProgressIndicator } = require('@westpac/ui');

      render(<PageLoader iconSize="xlarge" />);

      expect(ProgressIndicator).toHaveBeenCalledWith(
        expect.objectContaining({
          size: 'xlarge',
        }),
        expect.any(Object)
      );
    });

    it('calls ProgressIndicator with medium size by default', () => {
      const { ProgressIndicator } = require('@westpac/ui');

      render(<PageLoader />);

      expect(ProgressIndicator).toHaveBeenCalledWith(
        expect.objectContaining({
          size: 'medium',
        }),
        expect.any(Object)
      );
    });
  });

  describe('Accessibility', () => {
    it('has the correct data-testid for automated testing', () => {
      render(<PageLoader />);
      expect(screen.getByTestId('page-loader')).toBeInTheDocument();
    });

    it('maintains semantic structure with proper div container', () => {
      render(<PageLoader />);
      const container = screen.getByTestId('page-loader');
      expect(container.tagName).toBe('DIV');
    });
  });

  describe('CSS Classes', () => {
    it('always includes base flex classes', () => {
      render(<PageLoader placement="normal" />);
      const container = screen.getByTestId('page-loader');
      expect(container).toHaveClass('flex', 'justify-center', 'items-center');
    });

    it('conditionally applies placement-specific classes', () => {
      const { rerender } = render(<PageLoader placement="normal" />);
      let container = screen.getByTestId('page-loader');
      expect(container).toHaveClass('flex-1');
      expect(container).not.toHaveClass('min-h-screen');

      rerender(<PageLoader placement="middle" />);
      container = screen.getByTestId('page-loader');
      expect(container).toHaveClass('min-h-screen', 'h-full');
      expect(container).not.toHaveClass('flex-1');
    });
  });

  describe('Edge Cases', () => {
    it('handles undefined props gracefully', () => {
      render(<PageLoader iconSize={undefined} placement={undefined} />);

      expect(screen.getByTestId('page-loader')).toBeInTheDocument();
      expect(screen.getByTestId('progress-indicator')).toBeInTheDocument();
    });

    it('handles empty props object', () => {
      render(<PageLoader {...{}} />);

      expect(screen.getByTestId('page-loader')).toBeInTheDocument();
      expect(screen.getByTestId('progress-indicator')).toBeInTheDocument();
    });
  });
});
