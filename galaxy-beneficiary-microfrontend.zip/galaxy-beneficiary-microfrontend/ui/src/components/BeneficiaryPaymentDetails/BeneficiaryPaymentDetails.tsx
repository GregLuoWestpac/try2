/* eslint-disable react/react-in-jsx-scope */
import {
  MVDetailSection,
  MVDetailSectionProps,
} from '@mesh-tenant-multiverse-ui-common/mv-detailsection';
import { Beneficiary, BeneficiaryTaskDetail } from '../../store/types';

type BeneficiaryPaymentDetailsProps = {
  beneficiaryDetails: Beneficiary | BeneficiaryTaskDetail;
};

export function BeneficiaryPaymentDetails({
  beneficiaryDetails,
}: BeneficiaryPaymentDetailsProps) {
  const mapSectionData = (
    beneficiary: Beneficiary | BeneficiaryTaskDetail
  ): MVDetailSectionProps['data'] => {
    // null or undefined fields will be ignored by MVDetailSection

    const data: MVDetailSectionProps['data'] = [
      {
        label: 'Currency',
        value: beneficiary?.currencyAmount?.currencyCode ?? '',
      },
      {
        label: 'Amount',
        value: beneficiary.currencyAmount.amount || '',
      },
      {
        label: 'Reference',
        value: beneficiary.reference || '',
      },
    ];

    return data;
  };

  return (
    <MVDetailSection
      heading="Payment details"
      withTopBorder
      data={mapSectionData(beneficiaryDetails)}
    />
  );
}
