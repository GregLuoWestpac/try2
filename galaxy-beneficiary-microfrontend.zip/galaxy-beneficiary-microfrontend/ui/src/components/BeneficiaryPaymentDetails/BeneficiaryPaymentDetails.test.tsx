/* eslint-disable react/react-in-jsx-scope */
import { render, screen } from '@testing-library/react';
import { BeneficiaryPaymentDetails } from './BeneficiaryPaymentDetails';
import {
  BENEFICIARY_STATUS,
  BENEFICIARY_TYPE,
  Beneficiary,
  PAYID_TYPE,
} from '../../store/types';
import { CURRENCY } from '../../common/constants';

jest.mock('../../store/store', () => ({
  __esModule: true,
  default: {
    dispatch: jest.fn(),
  },
}));

const payIDMockBeneficiary: Beneficiary = {
  id: 'd0868661-b955-4e76-9f15-d97626f7df6b',
  externalId: 'd0868661-b955-4e76-9f15-d97626f7df6b',
  nickname: 'Bayer, Miller and MacGyver',
  currencyAmount: {
    currencyCode: CURRENCY.AUD,
    amount: '10.00',
  },
  reference: 'reference-1',
  org: 'office',
  type: BENEFICIARY_TYPE.PAYID,
  status: BENEFICIARY_STATUS.ARCHIVED,
  account: {
    payIDName: 'Tay Tay',
    payIDType: PAYID_TYPE.EMAIL,
    payIDValue: 'taylor.swift@era.com',
  },
};

describe('BeneficiaryPaymentDetails', () => {
  it('beneficiary payment details are displayed with correct values', () => {
    render(
      <BeneficiaryPaymentDetails beneficiaryDetails={payIDMockBeneficiary} />
    );
    expect(screen.getByText('Currency')).toBeInTheDocument();
    expect(screen.getByText('AUD')).toBeInTheDocument();
    expect(screen.getByText('Amount')).toBeInTheDocument();
    expect(screen.getByText('10.00')).toBeInTheDocument();
    expect(screen.getByText('Reference')).toBeInTheDocument();
    expect(screen.getByText('reference-1')).toBeInTheDocument();
  });

  it('show beneficiary payment details even when value is empty', () => {
    const dataWithEmptyPaymentDetails: Beneficiary = {
      ...payIDMockBeneficiary,
      currencyAmount: {
        currencyCode: '' as CURRENCY,
        amount: '',
      },
    };

    render(
      <BeneficiaryPaymentDetails
        beneficiaryDetails={dataWithEmptyPaymentDetails}
      />
    );
    expect(screen.getByText('Currency')).toBeInTheDocument();
    expect(screen.getByText('Amount')).toBeInTheDocument();
    expect(screen.getByText('Reference')).toBeInTheDocument();
  });
});
