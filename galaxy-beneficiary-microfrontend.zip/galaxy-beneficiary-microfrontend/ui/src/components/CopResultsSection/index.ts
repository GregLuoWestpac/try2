export { CopResultsSection, type CopResultsSectionProps } from './CopResultsSection';
