import React from 'react';
import { MVDetailSection } from '@mesh-tenant-multiverse-ui-common/mv-detailsection';
import {
  getFormattedDateTime,
  isStaffPortal,
  useHandleRaiseIntent,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { useGlobalDispatch, useGlobalSelector } from '@mep-ui/framework';
import { useNavigate } from '@mep-ui/framework-router-addon';
import { GridItem, Heading, ProgressIndicator } from '@westpac/ui';
import { usePlatformState } from '@mesh-tenant-multiverse-common/react';
import ErrorHandler from '../ErrorHandler/ErrorHandler';
import {
  CONTAINERTAB_TITLES,
  INTENT_NAMES,
  INTENTS_CONTEXT_NAME,
  PAGE_NAVIGATION,
} from '../../common/constants';
import {
  BeneficiaryActivitySummary,
  DetailSection,
} from './BeneficiaryActivity.types';

import { Beneficiary, GlobalState } from '../../store/types';
import { CustomerDetails } from '../../common/types';

const renderActivityDetails = (
  time: string | null | undefined,
  name: string | null | undefined
) => {
  if (!time && !name) return null;
  return (
    <>
      <div>{time ? getFormattedDateTime(time, 'h:mma') : ''}</div>
      <div>{name || ''}</div>
    </>
  );
};

const mapSectionData = (
  activitySummary: BeneficiaryActivitySummary
): DetailSection[] => {
  const data: DetailSection[] = [
    {
      label: 'Created',
      value: renderActivityDetails(
        activitySummary.createdAt,
        activitySummary.createdBy
      ),
    },
    {
      label: 'Archived',
      value: renderActivityDetails(
        activitySummary.archivedAt,
        activitySummary.archivedBy
      ),
    },
    {
      label: 'Updated',
      value: renderActivityDetails(
        activitySummary.updatedAt,
        activitySummary.updatedBy
      ),
    },
    {
      label: 'Authorised',
      value: renderActivityDetails(
        activitySummary.authorisedAt,
        activitySummary.authorisedBy
      ),
    },
  ];
  return data;
};

type BeneficiaryActivityProps = {
  activitySummary: BeneficiaryActivitySummary | null;
  isLoading: boolean;
  isError: boolean;
  onRetry: () => void;
};

export default function BeneficiaryActivity({
  activitySummary,
  isLoading = false,
  isError = false,
  onRetry = () => {},
}: BeneficiaryActivityProps) {
  const selectedBeneficiary: Beneficiary = useGlobalSelector(
    (state: GlobalState) => state?.global?.galaxy?.context?.selectedBeneficiary
  );

  const [selectedCustomerDetails] = usePlatformState<
    Record<string, CustomerDetails[]>
  >('w1c/customerDetails', {});

  const handleRaiseIntent = useHandleRaiseIntent(
    useGlobalDispatch,
    useNavigate
  );

  const onSelectedBeneficiaryActivityDetails = async () => {
    await handleRaiseIntent({
      intentName: INTENT_NAMES.VIEW_BENEFICIARY_ACTIVITY_DETAILS,
      data: { selectedBeneficiary },
      contextKey: selectedBeneficiary?.id,
      intentContextName: INTENTS_CONTEXT_NAME.BENEFICIARY,
      targetPath: PAGE_NAVIGATION.BENEFICIARY_ACTIVITY_DETAILS,
      ...(isStaffPortal() && {
        viewOptions: {
          windowTabKey: selectedBeneficiary.org,
          windowTabTitle:
            selectedCustomerDetails?.[selectedBeneficiary.org]?.[0]?.fullName ||
            '',
          containerTabTitle: CONTAINERTAB_TITLES.BENEFICIARY_ACTIVITY_DETAILS,
        },
      }),
    });
  };

  const sectionHeading = (
    <GridItem span={12} className="w-full py-2.5 border-t border-border">
      <Heading tag="h2" className="text-heading" size={7}>
        Beneficiary activity
      </Heading>
    </GridItem>
  );

  return (
    <>
      <MVDetailSection
        data={activitySummary ? mapSectionData(activitySummary) : []}
        heading="Beneficiary activity"
        withTopBorder
        linkAction={{
          text: 'View activity details',
          width: 4,
          action: async () => {
            await onSelectedBeneficiaryActivityDetails();
          },
        }}
      />

      {isLoading && (
        <>
          {sectionHeading}
          <GridItem span={12}>
            <ProgressIndicator size="medium" />
          </GridItem>
        </>
      )}

      {isError && (
        <>
          {sectionHeading}
          <GridItem span={12}>
            <ErrorHandler
              onRefresh={onRetry}
              errorMessage="Something went wrong."
              width="full"
            />
          </GridItem>
        </>
      )}
    </>
  );
}
