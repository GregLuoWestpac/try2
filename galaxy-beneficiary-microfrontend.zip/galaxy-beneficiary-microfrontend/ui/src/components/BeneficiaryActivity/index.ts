export { default as BeneficiaryActivity } from "./BeneficiaryActivity"
