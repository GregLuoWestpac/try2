import React from 'react';

export type DetailSection = {
  label: string;
  value: string | React.JSX.Element | null | undefined;
  itemWithFullWidth?: React.ReactNode;
};

export type BeneficiaryActivitySummary = {
  id: string;
  createdBy: string;
  createdAt: string;
  updatedBy?: string;
  updatedAt?: string;
  archivedBy?: string;
  archivedAt?: string;
  authorisedBy?: string;
  authorisedAt?: string;
};
