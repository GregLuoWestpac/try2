import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import BeneficiaryActivity from './BeneficiaryActivity';
import { BeneficiaryActivitySummary } from './BeneficiaryActivity.types';

// Mocks
const mockHandleRaiseIntentInner = jest.fn();
const mockUseNavigate = jest.fn();
const mockUseGlobalDispatch = jest.fn();

jest.mock('@mesh-tenant-multiverse-ui-common/mv-detailsection', () => ({
  MVDetailSection: ({
    data,
    withTopBorder,
    linkAction,
    heading,
  }: {
    data: Array<{ label: string; value: unknown }>;
    withTopBorder: boolean;
    linkAction: { text: string; action: () => void; width: number };
    heading: string;
  }) => {
    const filtered = Array.isArray(data)
      ? data.filter(d => d.value != null)
      : [];
    return (
      <div
        data-testid="mv-detail-section"
        data-has-top-border={withTopBorder}
        data-data-length={filtered.length}
        data-link-text={linkAction?.text}
        data-heading={heading}
      >
        {filtered.length > 0 && (
          <ul>
            {filtered.map((d, index) => (
              <li key={`${d.label}-${index}`}>
                <span>{d.label}</span>: <span>{d.value}</span>
              </li>
            ))}
          </ul>
        )}
        {linkAction && (
          <button data-testid="link-action" onClick={linkAction.action}>
            {linkAction.text}
          </button>
        )}
      </div>
    );
  },
}));

const mockIsStaffPortal = jest.fn().mockReturnValue(false);

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-utils'),
  useHandleRaiseIntent: () => mockHandleRaiseIntentInner,
  isStaffPortal: () => mockIsStaffPortal(),
  getFormattedDateTime: jest.fn((date: string, format: string) => {
    if (!date) return '';
    // Mock implementation for testing
    const dateObj = new Date(date);
    if (format === 'h:mma') {
      return `${dateObj.getHours()}:${dateObj.getMinutes()}${
        dateObj.getHours() >= 12 ? 'pm' : 'am'
      }`;
    }
    return dateObj.toISOString();
  }),
}));

// Provide a mock selectedBeneficiary via useGlobalSelector
const mockUseGlobalSelector = jest.fn().mockReturnValue({ id: 'bene-123' });
jest.mock('@mep-ui/framework', () => ({
  __esModule: true,
  useGlobalDispatch: () => mockUseGlobalDispatch,
  useGlobalSelector: (
    fn: (state: {
      global: {
        galaxy: { context: { selectedBeneficiary: { id: string } } };
      };
    }) => unknown
  ) =>
    fn({
      global: {
        galaxy: { context: { selectedBeneficiary: mockUseGlobalSelector() } },
      },
    }),
}));

jest.mock('@mep-ui/framework-router-addon', () => ({
  __esModule: true,
  useNavigate: () => mockUseNavigate,
}));

const mockUsePlatformState = jest.fn().mockReturnValue([{}, jest.fn()]);
jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  usePlatformState: (key: string, defaultValue: unknown) =>
    mockUsePlatformState(key, defaultValue),
}));

// Simplify Button from @westpac/ui to avoid style / side-effects while preserving className & onClick
jest.mock('@westpac/ui', () => ({
  Button: ({
    children,
    className,
    onClick,
    'data-testid': dataTestId,
  }: {
    children: React.ReactNode;
    className?: string;
    onClick?: () => void;
    'data-testid'?: string;
  }) => (
    <button
      type="button"
      data-testid={dataTestId || 'beneficiary-activity-btn'}
      className={className}
      onClick={onClick}
    >
      {children}
    </button>
  ),
  ProgressIndicator: () => <div data-testid="progress-indicator">Loading</div>,
  Heading: ({ children }: { children: React.ReactNode }) => (
    <div>{children}</div>
  ),
  GridItem: ({ children }: { children: React.ReactNode }) => (
    <div>{children}</div>
  ),
}));

jest.mock('../ErrorHandler/ErrorHandler', () => ({
  __esModule: true,
  default: ({ onRefresh }: { onRefresh: () => void }) => (
    <div data-testid="error-handler">
      <span>Error loading beneficiary activity</span>
      <button data-testid="retry-button" onClick={onRefresh}>
        try again
      </button>
    </div>
  ),
}));

describe('BeneficiaryActivity', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockIsStaffPortal.mockReturnValue(false);
    mockUsePlatformState.mockReturnValue([{}, jest.fn()]);
  });

  describe('Component Rendering', () => {
    it('renders MVDetailSection with expected props', () => {
      render(
        <BeneficiaryActivity
          activitySummary={null}
          isLoading={false}
          isError={false}
          onRetry={jest.fn()}
        />
      );
      const detailSection = screen.getByTestId('mv-detail-section');
      expect(detailSection).toBeInTheDocument();
      expect(detailSection).toHaveAttribute(
        'data-heading',
        'Beneficiary activity'
      );
      expect(detailSection).toHaveAttribute('data-has-top-border', 'true');
      expect(detailSection).toHaveAttribute('data-data-length');
    });

    it('passes linkAction to MVDetailSection with expected text', () => {
      render(
        <BeneficiaryActivity
          activitySummary={null}
          isLoading={false}
          isError={false}
          onRetry={jest.fn()}
        />
      );
      const detailSection = screen.getByTestId('mv-detail-section');
      expect(detailSection).toHaveAttribute(
        'data-link-text',
        'View activity details'
      );
      expect(
        screen.getByRole('button', { name: /view activity details/i })
      ).toBeInTheDocument();
    });

    it('renders with default prop values', () => {
      render(
        <BeneficiaryActivity
          activitySummary={null}
          isLoading={false}
          isError={false}
          onRetry={jest.fn()}
        />
      );
      const detailSection = screen.getByTestId('mv-detail-section');
      expect(detailSection).toBeInTheDocument();
    });
  });

  describe('Activity Summary Display', () => {
    it('renders all activity labels when activitySummary has complete values', () => {
      const activitySummary: BeneficiaryActivitySummary = {
        id: 'act-123',
        createdAt: '2025-09-25T15:27:49.732Z',
        createdBy: 'John Doe',
        updatedAt: '2025-09-26T10:00:00.000Z',
        updatedBy: 'Jane Doe',
        authorisedAt: '2025-09-27T12:00:00.000Z',
        authorisedBy: 'Will Smith',
        archivedAt: '2025-09-28T14:30:00.000Z',
        archivedBy: 'Admin User',
      };

      render(
        <BeneficiaryActivity
          activitySummary={activitySummary}
          isLoading={false}
          isError={false}
          onRetry={() => {}}
        />
      );

      expect(screen.getByText('Created')).toBeInTheDocument();
      expect(screen.getByText('Updated')).toBeInTheDocument();
      expect(screen.getByText('Authorised')).toBeInTheDocument();
      expect(screen.getByText('Archived')).toBeInTheDocument();
    });

    it('does not render Authorised when authorised fields are null', () => {
      const activitySummary: BeneficiaryActivitySummary = {
        id: 'act-123',
        createdAt: '2025-09-25T15:27:49.732Z',
        createdBy: 'John Doe',
        updatedAt: '2025-09-26T10:00:00.000Z',
        updatedBy: 'Jane Doe',
        authorisedAt: undefined,
        authorisedBy: undefined,
        archivedAt: undefined,
        archivedBy: undefined,
      };

      render(
        <BeneficiaryActivity
          activitySummary={activitySummary}
          isLoading={false}
          isError={false}
          onRetry={() => {}}
        />
      );

      expect(screen.getByText('Created')).toBeInTheDocument();
      expect(screen.getByText('Updated')).toBeInTheDocument();
      expect(screen.queryByText('Authorised')).not.toBeInTheDocument();
      expect(screen.queryByText('Archived')).not.toBeInTheDocument();
    });

    it('renders Created only when other fields are missing', () => {
      const activitySummary: BeneficiaryActivitySummary = {
        id: 'act-123',
        createdAt: '2025-09-25T15:27:49.732Z',
        createdBy: 'John Doe',
      };

      render(
        <BeneficiaryActivity
          activitySummary={activitySummary}
          isLoading={false}
          isError={false}
          onRetry={() => {}}
        />
      );

      expect(screen.getByText('Created')).toBeInTheDocument();
      expect(screen.queryByText('Updated')).not.toBeInTheDocument();
      expect(screen.queryByText('Authorised')).not.toBeInTheDocument();
      expect(screen.queryByText('Archived')).not.toBeInTheDocument();
    });

    it('handles partial data - only time present', () => {
      const activitySummary: BeneficiaryActivitySummary = {
        id: 'act-123',
        createdAt: '2025-09-25T15:27:49.732Z',
        createdBy: '',
      };

      render(
        <BeneficiaryActivity
          activitySummary={activitySummary}
          isLoading={false}
          isError={false}
          onRetry={() => {}}
        />
      );

      expect(screen.getByText('Created')).toBeInTheDocument();
    });

    it('handles partial data - only name present', () => {
      const activitySummary: BeneficiaryActivitySummary = {
        id: 'act-123',
        createdAt: '',
        createdBy: 'John Doe',
      };

      render(
        <BeneficiaryActivity
          activitySummary={activitySummary}
          isLoading={false}
          isError={false}
          onRetry={() => {}}
        />
      );

      expect(screen.getByText('Created')).toBeInTheDocument();
    });
  });

  describe('Intent Handling', () => {
    it('invokes handleRaiseIntent with expected parameters on click', async () => {
      render(
        <BeneficiaryActivity
          activitySummary={null}
          isLoading={false}
          isError={false}
          onRetry={jest.fn()}
        />
      );
      const linkBtn = screen.getByTestId('link-action');
      fireEvent.click(linkBtn);

      await waitFor(() => {
        expect(mockHandleRaiseIntentInner).toHaveBeenCalledTimes(1);
      });

      const callArg = mockHandleRaiseIntentInner.mock.calls[0][0];
      expect(callArg).toMatchObject({
        intentName: 'ViewGalaxyBeneficiaryActivityDetails',
        intentContextName: 'fdc3.nothing',
        targetPath: '/beneficiary/beneficiary-activity-details',
      });
      expect(callArg.contextKey).toBe('bene-123');
      expect(callArg.viewOptions).toBeUndefined();
    });

    it('passes selectedBeneficiary data to intent', async () => {
      const activitySummary: BeneficiaryActivitySummary = {
        id: 'act-123',
        createdAt: '2025-09-25T15:27:49.732Z',
        createdBy: 'John Doe',
      };

      render(
        <BeneficiaryActivity
          activitySummary={activitySummary}
          isLoading={false}
          isError={false}
          onRetry={jest.fn()}
        />
      );
      const linkBtn = screen.getByTestId('link-action');
      fireEvent.click(linkBtn);

      await waitFor(() => {
        expect(mockHandleRaiseIntentInner).toHaveBeenCalledTimes(1);
      });

      const callArg = mockHandleRaiseIntentInner.mock.calls[0][0];
      expect(callArg.data).toEqual({ selectedBeneficiary: { id: 'bene-123' } });
    });

    it('is resilient to multiple rapid clicks', async () => {
      mockHandleRaiseIntentInner.mockResolvedValue(undefined);
      render(
        <BeneficiaryActivity
          activitySummary={null}
          isLoading={false}
          isError={false}
          onRetry={jest.fn()}
        />
      );
      const linkBtn = screen.getByTestId('link-action');

      fireEvent.click(linkBtn);
      fireEvent.click(linkBtn);
      fireEvent.click(linkBtn);

      await waitFor(() => {
        expect(mockHandleRaiseIntentInner).toHaveBeenCalledTimes(3);
      });
    });

    it('includes viewOptions when in staff portal mode', async () => {
      mockIsStaffPortal.mockReturnValue(true);
      mockUseGlobalSelector.mockReturnValue({ id: 'bene-123', org: 'org-456' });
      mockUsePlatformState.mockReturnValue([
        {
          'org-456': [{ fullName: 'John Smith' }],
        },
        jest.fn(),
      ]);

      render(
        <BeneficiaryActivity
          activitySummary={null}
          isLoading={false}
          isError={false}
          onRetry={jest.fn()}
        />
      );
      const linkBtn = screen.getByTestId('link-action');
      fireEvent.click(linkBtn);

      await waitFor(() => {
        expect(mockHandleRaiseIntentInner).toHaveBeenCalledTimes(1);
      });

      const callArg = mockHandleRaiseIntentInner.mock.calls[0][0];
      expect(callArg.viewOptions).toEqual({
        windowTabKey: 'org-456',
        windowTabTitle: 'John Smith',
        containerTabTitle: 'Beneficiary activity details | Westpac One',
      });
    });

    it('does not include viewOptions when not in staff portal mode', async () => {
      mockIsStaffPortal.mockReturnValue(false);
      render(
        <BeneficiaryActivity
          activitySummary={null}
          isLoading={false}
          isError={false}
          onRetry={jest.fn()}
        />
      );
      const linkBtn = screen.getByTestId('link-action');
      fireEvent.click(linkBtn);

      await waitFor(() => {
        expect(mockHandleRaiseIntentInner).toHaveBeenCalledTimes(1);
      });

      const callArg = mockHandleRaiseIntentInner.mock.calls[0][0];
      expect(callArg.viewOptions).toBeUndefined();
    });

    it('handles missing customer details gracefully in staff portal', async () => {
      mockIsStaffPortal.mockReturnValue(true);
      mockUseGlobalSelector.mockReturnValue({ id: 'bene-123', org: 'org-456' });
      mockUsePlatformState.mockReturnValue([{}, jest.fn()]);

      render(
        <BeneficiaryActivity
          activitySummary={null}
          isLoading={false}
          isError={false}
          onRetry={jest.fn()}
        />
      );
      const linkBtn = screen.getByTestId('link-action');
      fireEvent.click(linkBtn);

      await waitFor(() => {
        expect(mockHandleRaiseIntentInner).toHaveBeenCalledTimes(1);
      });

      const callArg = mockHandleRaiseIntentInner.mock.calls[0][0];
      expect(callArg.viewOptions).toEqual({
        windowTabKey: 'org-456',
        windowTabTitle: '',
        containerTabTitle: 'Beneficiary activity details | Westpac One',
      });
    });
  });

  describe('Loading State', () => {
    it('shows loading indicator when isLoading is true', () => {
      render(
        <BeneficiaryActivity
          activitySummary={null}
          isLoading
          isError={false}
          onRetry={() => {}}
        />
      );

      expect(screen.getByTestId('progress-indicator')).toBeInTheDocument();
      const detailSection = screen.getByTestId('mv-detail-section');
      expect(detailSection).toHaveAttribute(
        'data-heading',
        'Beneficiary activity'
      );
    });

    it('displays section heading when loading', () => {
      render(
        <BeneficiaryActivity
          activitySummary={null}
          isLoading
          isError={false}
          onRetry={() => {}}
        />
      );

      expect(screen.getByText('Beneficiary activity')).toBeInTheDocument();
    });

    it('shows loading state alongside MVDetailSection', () => {
      render(
        <BeneficiaryActivity
          activitySummary={null}
          isLoading
          isError={false}
          onRetry={() => {}}
        />
      );

      expect(screen.getByTestId('mv-detail-section')).toBeInTheDocument();
      expect(screen.getByTestId('progress-indicator')).toBeInTheDocument();
    });
  });

  describe('Error State', () => {
    it('shows error handler when isError is true', () => {
      const onRetry = jest.fn();
      render(
        <BeneficiaryActivity
          activitySummary={null}
          isLoading={false}
          isError
          onRetry={onRetry}
        />
      );

      expect(screen.getByTestId('error-handler')).toBeInTheDocument();
      expect(
        screen.getByText(/Error loading beneficiary activity/i)
      ).toBeInTheDocument();
    });

    it('calls onRetry when retry button is clicked', () => {
      const onRetry = jest.fn();
      render(
        <BeneficiaryActivity
          activitySummary={null}
          isLoading={false}
          isError
          onRetry={onRetry}
        />
      );

      const retryButton = screen.getByTestId('retry-button');
      fireEvent.click(retryButton);

      expect(onRetry).toHaveBeenCalledTimes(1);
    });

    it('displays section heading when error occurs', () => {
      render(
        <BeneficiaryActivity
          activitySummary={null}
          isLoading={false}
          isError
          onRetry={() => {}}
        />
      );

      expect(screen.getByText('Beneficiary activity')).toBeInTheDocument();
    });

    it('shows error state alongside MVDetailSection', () => {
      render(
        <BeneficiaryActivity
          activitySummary={null}
          isLoading={false}
          isError
          onRetry={() => {}}
        />
      );

      expect(screen.getByTestId('mv-detail-section')).toBeInTheDocument();
      expect(screen.getByTestId('error-handler')).toBeInTheDocument();
    });
  });

  describe('Combined States', () => {
    it('prioritizes loading state over error state', () => {
      render(
        <BeneficiaryActivity
          activitySummary={null}
          isLoading
          isError
          onRetry={() => {}}
        />
      );

      expect(screen.getByTestId('progress-indicator')).toBeInTheDocument();
      expect(screen.getByTestId('error-handler')).toBeInTheDocument();
    });

    it('displays both MVDetailSection and loading indicator', () => {
      const activitySummary: BeneficiaryActivitySummary = {
        id: 'act-123',
        createdAt: '2025-09-25T15:27:49.732Z',
        createdBy: 'John Doe',
      };

      render(
        <BeneficiaryActivity
          activitySummary={activitySummary}
          isLoading
          isError={false}
          onRetry={() => {}}
        />
      );

      expect(screen.getByTestId('mv-detail-section')).toBeInTheDocument();
      expect(screen.getByTestId('progress-indicator')).toBeInTheDocument();
    });

    it('displays both MVDetailSection and error handler', () => {
      const activitySummary: BeneficiaryActivitySummary = {
        id: 'act-123',
        createdAt: '2025-09-25T15:27:49.732Z',
        createdBy: 'John Doe',
      };

      render(
        <BeneficiaryActivity
          activitySummary={activitySummary}
          isLoading={false}
          isError
          onRetry={() => {}}
        />
      );

      expect(screen.getByTestId('mv-detail-section')).toBeInTheDocument();
      expect(screen.getByTestId('error-handler')).toBeInTheDocument();
    });
  });
});
