import React from 'react';
import { render, screen } from '@testing-library/react';
import { BeneficiaryAuthorisationActivity } from './BeneficiaryAuthorisationActivity';
import { BENEFICIARY_TYPE } from '../../store/types/Beneficiary';
import { AUTHORISATION_STATUS } from '../../store/types';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  getTodayAtLastYear: () => ({ toFormat: () => '2024-01-18' }),
  getToday: () => ({ toFormat: () => '2025-01-18' }),
}));

jest.mock('../../store/store', () => ({
  __esModule: true,
  default: {
    dispatch: jest.fn(),
  },
}));
const authorisationActivityDetails = {
  type: BENEFICIARY_TYPE.ACCOUNT,
  subType: 'addbeneficiary',
  account: {
    accountId: { BSB: '', accountNumber: '' },
    accountName: 'WestpacJoint',
    bankName: 'WestpacJoint',
  },
  id: '123456',
  externalId: 'string',
  currency: 'AUD',
  org: 'WBC',
  nickname: 'ABCcompany',
  status: AUTHORISATION_STATUS.PENDING_AUTHORISATION,
  sentForAuthWorkflowAuditDetails: {
    actionedBy: 'Kelly Math',
    actionedDateTime: '2025-05-18T10:49:57.566Z',
  },
  rejectedWorkflowAuditDetails: { actionedBy: '', actionedDateTime: '' },
};
describe('BeneficiaryAuthorisationActivity', () => {
  it('beneficiary and authorisation activity details are displayed', () => {
    render(
      <BeneficiaryAuthorisationActivity
        authorisationActivityDetails={authorisationActivityDetails}
      />
    );
    expect(screen.getByText('Authorisation request')).toBeInTheDocument();
    expect(screen.getByText('Add beneficiary')).toBeInTheDocument();
  });

  it('displays rejection details when status is REJECTED', () => {
    const rejectedActivityDetails = {
      ...authorisationActivityDetails,
      status: AUTHORISATION_STATUS.REJECTED,
      rejectedWorkflowAuditDetails: {
        actionedBy: 'John Doe',
        actionedDateTime: '2025-05-19T15:30:00.000Z',
      },
      rejectComments: 'Invalid beneficiary details provided',
    };

    render(
      <BeneficiaryAuthorisationActivity
        authorisationActivityDetails={rejectedActivityDetails}
      />
    );

    expect(screen.getByText('Rejected')).toBeInTheDocument();
    expect(screen.getByText('John Doe')).toBeInTheDocument();
    expect(screen.getByText('Comments')).toBeInTheDocument();
    expect(
      screen.getByText('Invalid beneficiary details provided')
    ).toBeInTheDocument();
  });

  it('handles missing sentForAuthWorkflowAuditDetails gracefully', () => {
    const activityDetailsWithoutSentForAuth = {
      ...authorisationActivityDetails,
      sentForAuthWorkflowAuditDetails: {
        actionedBy: '',
        actionedDateTime: '',
      },
    };

    render(
      <BeneficiaryAuthorisationActivity
        authorisationActivityDetails={activityDetailsWithoutSentForAuth}
      />
    );

    expect(screen.getByText('Authorisation request')).toBeInTheDocument();
    expect(screen.getByText('Sent for authorisation')).toBeInTheDocument();
  });

  it('handles undefined sentForAuthWorkflowAuditDetails', () => {
    const activityDetailsWithUndefinedAuth = {
      ...authorisationActivityDetails,
      sentForAuthWorkflowAuditDetails: undefined as any,
    };

    render(
      <BeneficiaryAuthorisationActivity
        authorisationActivityDetails={activityDetailsWithUndefinedAuth}
      />
    );

    expect(screen.getByText('Authorisation request')).toBeInTheDocument();
    expect(screen.getByText('Sent for authorisation')).toBeInTheDocument();
  });

  it('handles missing rejectedWorkflowAuditDetails when status is REJECTED', () => {
    const rejectedActivityDetailsWithoutRejectedAudit = {
      ...authorisationActivityDetails,
      status: AUTHORISATION_STATUS.REJECTED,
      rejectedWorkflowAuditDetails: {
        actionedBy: '',
        actionedDateTime: '',
      },
      rejectComments: 'Rejection reason',
    };

    render(
      <BeneficiaryAuthorisationActivity
        authorisationActivityDetails={
          rejectedActivityDetailsWithoutRejectedAudit
        }
      />
    );

    expect(screen.getByText('Rejected')).toBeInTheDocument();
    expect(screen.getByText('Comments')).toBeInTheDocument();
    expect(screen.getByText('Rejection reason')).toBeInTheDocument();
  });

  it('handles undefined rejectedWorkflowAuditDetails when status is REJECTED', () => {
    const rejectedActivityDetailsWithUndefinedRejectedAudit = {
      ...authorisationActivityDetails,
      status: AUTHORISATION_STATUS.REJECTED,
      rejectedWorkflowAuditDetails: undefined as any,
      rejectComments: 'Missing audit details',
    };

    render(
      <BeneficiaryAuthorisationActivity
        authorisationActivityDetails={
          rejectedActivityDetailsWithUndefinedRejectedAudit
        }
      />
    );

    expect(screen.getByText('Rejected')).toBeInTheDocument();
    expect(screen.getByText('Comments')).toBeInTheDocument();
    expect(screen.getByText('Missing audit details')).toBeInTheDocument();
  });

  it('handles empty comments when status is REJECTED', () => {
    const rejectedActivityDetailsWithEmptyComments = {
      ...authorisationActivityDetails,
      status: AUTHORISATION_STATUS.REJECTED,
      rejectedWorkflowAuditDetails: {
        actionedBy: 'Jane Doe',
        actionedDateTime: '2025-05-19T15:30:00.000Z',
      },
      rejectComments: '',
    };

    render(
      <BeneficiaryAuthorisationActivity
        authorisationActivityDetails={rejectedActivityDetailsWithEmptyComments}
      />
    );

    expect(screen.getByText('Rejected')).toBeInTheDocument();
    expect(screen.getByText('Comments')).toBeInTheDocument();
  });

  it('handles undefined comments when status is REJECTED', () => {
    const rejectedActivityDetailsWithUndefinedComments = {
      ...authorisationActivityDetails,
      status: AUTHORISATION_STATUS.REJECTED,
      rejectedWorkflowAuditDetails: {
        actionedBy: 'Jane Doe',
        actionedDateTime: '2025-05-19T15:30:00.000Z',
      },
      rejectComments: undefined as any,
    };

    render(
      <BeneficiaryAuthorisationActivity
        authorisationActivityDetails={
          rejectedActivityDetailsWithUndefinedComments
        }
      />
    );

    expect(screen.getByText('Rejected')).toBeInTheDocument();
    expect(screen.getByText('Comments')).toBeInTheDocument();
  });

  it('handles missing subType gracefully', () => {
    const activityDetailsWithoutSubType = {
      ...authorisationActivityDetails,
      subType: undefined as any,
    };

    render(
      <BeneficiaryAuthorisationActivity
        authorisationActivityDetails={activityDetailsWithoutSubType}
      />
    );

    expect(screen.getByText('Authorisation activity')).toBeInTheDocument();
    expect(screen.getByText('Sent for authorisation')).toBeInTheDocument();
  });

  it('handles empty subType gracefully', () => {
    const activityDetailsWithEmptySubType = {
      ...authorisationActivityDetails,
      subType: '',
    };

    render(
      <BeneficiaryAuthorisationActivity
        authorisationActivityDetails={activityDetailsWithEmptySubType}
      />
    );

    expect(screen.getByText('Authorisation activity')).toBeInTheDocument();
    expect(screen.getByText('Sent for authorisation')).toBeInTheDocument();
  });

  it('handles different authorisation statuses correctly', () => {
    const approvedActivityDetails = {
      ...authorisationActivityDetails,
      status: AUTHORISATION_STATUS.PENDING_AUTHORISATION,
    };

    render(
      <BeneficiaryAuthorisationActivity
        authorisationActivityDetails={approvedActivityDetails}
      />
    );

    expect(screen.getByText('Authorisation request')).toBeInTheDocument();
    expect(screen.queryByText('Rejected')).not.toBeInTheDocument();
  });

  it('renders audit details with formatted date and time', () => {
    const activityDetailsWithDateTime = {
      ...authorisationActivityDetails,
      sentForAuthWorkflowAuditDetails: {
        actionedBy: 'Jane Smith',
        actionedDateTime: '2025-05-20T09:15:30.000Z',
      },
    };

    render(
      <BeneficiaryAuthorisationActivity
        authorisationActivityDetails={activityDetailsWithDateTime}
      />
    );

    expect(screen.getByText('Jane Smith')).toBeInTheDocument();
  });

  it('handles null actionedDateTime in audit details', () => {
    const activityDetailsWithNullDateTime = {
      ...authorisationActivityDetails,
      sentForAuthWorkflowAuditDetails: {
        actionedBy: 'Test User',
        actionedDateTime: null as any,
      },
    };

    render(
      <BeneficiaryAuthorisationActivity
        authorisationActivityDetails={activityDetailsWithNullDateTime}
      />
    );

    expect(screen.getByText('Test User')).toBeInTheDocument();
  });

  it('handles undefined actionedBy in audit details', () => {
    const activityDetailsWithUndefinedActionedBy = {
      ...authorisationActivityDetails,
      sentForAuthWorkflowAuditDetails: {
        actionedBy: undefined as any,
        actionedDateTime: '2025-05-20T09:15:30.000Z',
      },
    };

    render(
      <BeneficiaryAuthorisationActivity
        authorisationActivityDetails={activityDetailsWithUndefinedActionedBy}
      />
    );

    expect(screen.getByText('Authorisation request')).toBeInTheDocument();
  });
});
