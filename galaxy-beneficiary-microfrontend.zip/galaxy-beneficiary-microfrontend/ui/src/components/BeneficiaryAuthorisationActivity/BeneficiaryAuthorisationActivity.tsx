/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
import React from 'react';
import { getFormattedDateTime } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { MVDetailSection } from '@mesh-tenant-multiverse-ui-common/mv-detailsection';
import { mapAuthorisationRequestToWorkflowSubtype } from '../../common/Beneficiary.util';
import {
  AUTHORISATION_STATUS,
  BeneficiaryTaskDetail,
  WorkflowAuditDetails,
} from '../../store/types';
import { DetailSection, Props } from './BeneficiaryAuthorisationActivity.types';

const renderAuditDetails = (details: WorkflowAuditDetails) => (
  <>
    <div>
      {details?.actionedDateTime
        ? getFormattedDateTime(details.actionedDateTime, 'h:mma')
        : ''}
    </div>
    <div>{details?.actionedBy || ''}</div>
  </>
);
const mapSectionData = (
  beneficiary: BeneficiaryTaskDetail
): DetailSection[] => {
  const data: DetailSection[] = [
    {
      label: 'Authorisation request',
      value: mapAuthorisationRequestToWorkflowSubtype(
        beneficiary?.subType ?? ''
      ),
    },
    {
      label: 'Sent for authorisation',
      value: renderAuditDetails(beneficiary?.sentForAuthWorkflowAuditDetails),
    },
  ];
  if (beneficiary?.status === AUTHORISATION_STATUS.REJECTED) {
    data.push(
      {
        label: 'Rejected',
        value: renderAuditDetails(beneficiary?.rejectedWorkflowAuditDetails),
      },
      {
        label: 'Comments',
        value: <>{beneficiary?.rejectComments || ''}</>,
      }
    );
  }

  return data;
};

export function BeneficiaryAuthorisationActivity({
  authorisationActivityDetails,
}: Props) {
  return (
    <MVDetailSection
      heading="Authorisation activity"
      data={mapSectionData(authorisationActivityDetails)}
      withTopBorder
    />
  );
}
