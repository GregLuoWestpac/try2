export { BeneficiaryAuthorisationActivity } from './BeneficiaryAuthorisationActivity';
