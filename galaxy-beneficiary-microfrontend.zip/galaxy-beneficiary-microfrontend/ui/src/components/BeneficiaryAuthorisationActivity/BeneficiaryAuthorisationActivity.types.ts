import React from 'react';
import { BeneficiaryTaskDetail } from '../../store/types';

export type Props = {
  authorisationActivityDetails: BeneficiaryTaskDetail;
};

export type DetailSection = {
  label: string;
  value: string | React.JSX.Element | null | undefined;
  itemWithFullWidth?: React.ReactNode;
};
