import { registerRoutes } from '@mep-ui/framework';
import './index.css';
import { pages } from './routes';

import React from 'react';
globalThis.React = React;

export const init = () => {
  registerRoutes(pages);
};

/**
 * Initializing registration while importing itself.
 * This would be useful when project teams inject microfrontend dynamically.
 * In case of traditional micro apps, they've to import reducers, routes, sagas, etc manually as of today
 */
init();
