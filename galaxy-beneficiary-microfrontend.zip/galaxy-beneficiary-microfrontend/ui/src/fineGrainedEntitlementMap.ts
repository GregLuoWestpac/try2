import {
  Actions,
  Resources,
} from '@mesh-tenant-user-authorisation-policy-decision-engine/components';

export const entitlementToPathMap = {
  '/beneficiary': {
    resource: Resources.BENEFICIARY,
    action: Actions.VIEW_BENEFICIARY,
  },
  '/beneficiary/view-beneficiary': {
    resource: Resources.BENEFICIARY,
    action: Actions.VIEW_BENEFICIARY,
  },
  '/beneficiary/update-beneficiary': {
    resource: Resources.BENEFICIARY,
    action: Actions.MODIFY_BENEFICIARY,
  },
  '/beneficiary/create-beneficiary': {
    resource: Resources.BENEFICIARY,
    action: Actions.CREATE_BENEFICIARY,
  },
  '/beneficiary/beneficiary-task-details': {
    resource: Resources.BENEFICIARY,
    action: Actions.VIEW_BENEFICIARY,
  },
  '/beneficiary/beneficiary-activity-details': {
    resource: Resources.BENEFICIARY,
    action: Actions.VIEW_BENEFICIARY,
  },
};
