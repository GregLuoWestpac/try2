// Extend Window type to include encode_deviceprint
declare global {
  interface Window {
    encode_deviceprint?: () => string;
  }
}

export {};
