/* eslint-disable @typescript-eslint/no-explicit-any */

/* This file polyfill the type declaraion for the follow module as mep-ui has not yet provided */
declare module '@mep-ui/framework' {
  const compose: AnyFunc; // no type declaration in @mep-ui/framework
  const connect: AnyFunc; // no type declaration in @mep-ui/framework
  const watchAppConfig: AnyFunc; // no type declaration in @mep-ui/framework
  const appConfigReducer: AnyFunc; // no type declaration in @mep-ui/framework
  const apiClientMiddleware: AnyFunc; // no type declaration in @mep-ui/framework
  const createStore: AnyFunc; // no type declaration in @mep-ui/framework
  const combineReducers: AnyFunc; // no type declaration in @mep-ui/framework
  const watchAppConfig: AnyFunc; // no type declaration in @mep-ui/framework
  const useMFEConfig: AnyFunc; // no type declaration in @mep-ui/framework
  const useManifest: AnyFunc; // no type declaration in @mep-ui/framework
  const Provider: Provider; // no type declaration in @mep-ui/framework
  const ssoActions: AnyFunc; // no type declaration in @mep-ui/framework
  const useGlobalDispatch: AnyFunc; // no type declaration in @mep-ui/framework
  const createSelector: AnyFunc; // no type declaration in @mep-ui/framework
  const useGlobalSelector: AnyFunc; // no type declaration in @mep-ui/framework
  const isLocalUrl: () => boolean; // no type declaration in @mep-ui/framework
}
