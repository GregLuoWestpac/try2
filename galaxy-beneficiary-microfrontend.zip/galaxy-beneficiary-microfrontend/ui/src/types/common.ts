/* eslint-disable @typescript-eslint/no-explicit-any */

// Helper to polyfill missing type
export type AnyComp<P = any> = React.FC<P>;
