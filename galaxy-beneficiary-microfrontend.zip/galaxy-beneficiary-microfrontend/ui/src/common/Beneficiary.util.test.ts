/* eslint-disable @typescript-eslint/no-var-requires */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable no-template-curly-in-string */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-require-imports */
/* eslint-disable global-require */
import {
  getFriendlyBeneficiaryStatus,
  formatAuthorisationStatus,
  getContextKey,
  updateBeneficiaryKey,
  viewBeneficiaryKey,
  transformApprovalWorkflowToBeneficiaryTaskDetail,
  extractBeneficiaryDetails,
  mapApprovalWorkflowList,
  mapSubTypeLabel,
  mapStatusToWorkflowStatus,
  mapAuthorisationRequestToWorkflowSubtype,
  getWorkflowAuditDetails,
  buildBeneficiaryCreateEntitlement,
  buildBeneficiaryUpdateEntitlement,
} from './Beneficiary.util';
import {
  getDefaultFormValues,
  getPayIDValueFromEditForm,
} from '../components/BeneficiaryForm/BeneficiaryForm.utils';
import {
  APPROVAL_WORKFLOW_AUDIT_EVENT_NAME,
  AUTHORISATION_STATUS,
  Beneficiary,
  BENEFICIARY_STATUS,
  BENEFICIARY_TYPE,
} from '../store/types';
import {
  ApprovalWorkflow,
  ApprovalWorkflowDetail,
} from '../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types/helper.types';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  getTodayAtLastYear: () => ({ toFormat: () => '2024-01-18' }),
  getToday: () => ({ toFormat: () => '2025-01-18' }),
}));

describe('getFriendlyBeneficiaryStatus', () => {
  it('should return "Active" and "success" for BENEFICIARY_STATUS.ACTIVE', () => {
    const result = getFriendlyBeneficiaryStatus(BENEFICIARY_STATUS.ACTIVE);
    expect(result).toEqual({
      text: 'Active',
      badgeColor: 'success',
    });
  });

  it('should return "Archived" and "primary" for BENEFICIARY_STATUS.ARCHIVED', () => {
    const result = getFriendlyBeneficiaryStatus(BENEFICIARY_STATUS.ARCHIVED);
    expect(result).toEqual({
      text: 'Archived',
      badgeColor: 'primary',
    });
  });

  it('should return "Unknown" and "neutral" for an unknown status', () => {
    const result = getFriendlyBeneficiaryStatus(
      'UNKNOWN' as BENEFICIARY_STATUS
    );
    expect(result).toEqual({
      text: 'Unknown',
      badgeColor: 'neutral',
    });
  });
});

const defaultBSBBeneficiary = {
  id: 'd0868661-b955-4e76-9f15-d97626f7d78b',
  externalId: 'd0868661-b955-4e76-9f15-d97626f7d78b',
  nickname: 'Bayer, Miller and MacGyver',
  currency: 'AUD',
  org: 'office',
  status: 'ACTIVE',
  type: 'BSB_ACCOUNT_NUMBER',
  account: {
    accountId: {
      BSB: '062948',
      accountNumber: '22222123',
    },
    bankName: 'Westpac Banking Corporation',
    accountName: 'Westpac Joint',
  },
} as Beneficiary;

const defaultPAYIDBeneficiary = {
  id: 'd0868661-b955-4e76-9f15-d97626f7df6b',
  externalId: 'd0868661-b955-4e76-9f15-d97626f7df6b',
  nickname: 'ABC MacGyver',
  currency: 'AUD',
  org: 'office',
  status: 'ACTIVE',
  type: 'PAYID',
  account: {
    payIDType: 'TELI',
    payIDValue: '+61-407123456',
    payIDName: 'ABC Corp',
  },
};

describe('getDefaultFormValues', () => {
  const defaultValues = {
    beneficiaryType: undefined,
    payIdType: undefined,
    payIdName: undefined,
    bsb: '',
    bankName: '',
    accountNumber: '',
    accountName: '',
    beneficiaryNickname: '',
    currency: 'AUD',
    phone: '',
    email: '',
    abnAcn: '',
    organisationId: '',
    account: undefined,
    amount: '',
    toReference: '',
  };

  it('should return default values when type is undefined', () => {
    const result = getDefaultFormValues(undefined);
    expect(result).toEqual(defaultValues);
  });

  it('should return account-related values when type is BENEFICIARY_TYPE.ACCOUNT', () => {
    const result = getDefaultFormValues(defaultBSBBeneficiary);
    expect(result).toEqual({
      ...defaultValues,
      beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
      bsb: '062948',
      bankName: 'Westpac Banking Corporation',
      accountNumber: '22222123',
      accountName: 'Westpac Joint',
      beneficiaryNickname: 'Bayer, Miller and MacGyver',
      currency: 'AUD',
    });
  });

  it('should handle account with missing accountId (lines 95-96)', () => {
    const beneficiaryWithoutAccountId = {
      nickname: 'Bayer, Miller and MacGyver',
      type: BENEFICIARY_TYPE.ACCOUNT,
      currency: 'AUD',
      account: {
        accountName: 'Test Account',
        bankName: 'Test Bank',
        // Missing accountId
      },
    } as unknown as Beneficiary;

    const result = getDefaultFormValues(beneficiaryWithoutAccountId);
    expect(result).toEqual({
      ...defaultValues,
      beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
      bsb: undefined,
      accountNumber: undefined,
      accountName: 'Test Account',
      bankName: 'Test Bank',
      beneficiaryNickname: 'Bayer, Miller and MacGyver',
      currency: 'AUD',
    });
  });

  it('should handle account with missing account object (line 95)', () => {
    const beneficiaryWithoutAccount = {
      nickname: 'Bayer, Miller and MacGyver',
      type: BENEFICIARY_TYPE.ACCOUNT,
      currency: 'AUD',
      account: null, // Missing account
    } as unknown as Beneficiary;

    const result = getDefaultFormValues(beneficiaryWithoutAccount);
    expect(result).toEqual({
      ...defaultValues,
      beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
      bsb: undefined,
      accountNumber: undefined,
      accountName: undefined,
      bankName: undefined,
      beneficiaryNickname: 'Bayer, Miller and MacGyver',
      currency: 'AUD',
    });
  });

  it('should handle account with missing account object (line 95)', () => {
    const beneficiaryWithoutAccount = {
      ...defaultBSBBeneficiary,
      account: undefined,
    } as unknown as Beneficiary;

    const result = getDefaultFormValues(beneficiaryWithoutAccount);
    expect(result).toEqual({
      ...defaultValues,
      beneficiaryType: BENEFICIARY_TYPE.ACCOUNT,
      bsb: undefined,
      accountNumber: undefined,
      accountName: undefined,
      bankName: undefined,
      beneficiaryNickname: 'Bayer, Miller and MacGyver',
      currency: 'AUD',
    });
  });

  it('should return PayID-related values when type is BENEFICIARY_TYPE.PAYID', () => {
    const result = getDefaultFormValues(defaultPAYIDBeneficiary as Beneficiary);
    expect(result).toEqual({
      ...defaultValues,
      beneficiaryType: BENEFICIARY_TYPE.PAYID,
      payIdType: defaultPAYIDBeneficiary.account.payIDType,
      phone: '+61-407123456',
      beneficiaryNickname: 'ABC MacGyver',
      payIdName: 'ABC Corp',
      currency: 'AUD',
    });
  });

  it('should return default values when type does not match any case (line 117)', () => {
    const beneficiaryWithUnknownType = {
      ...defaultBSBBeneficiary,
      type: 'UNKNOWN_TYPE',
    } as unknown as Beneficiary;

    const result = getDefaultFormValues(beneficiaryWithUnknownType);
    expect(result).toEqual(defaultValues);
  });
});

describe('getPayIDValueFromEditForm', () => {
  it('should return email if payIdType is EMAL and email is provided', () => {
    const result = getPayIDValueFromEditForm({
      email: 'test@example.com',
      organisationId: '',
      phone: '',
      abnAcn: '',
      payIdType: 'EMAL',
    });
    expect(result).toBe('test@example.com');
  });

  it('should return organisationId if payIdType is ORGN and org ID is provided', () => {
    const result = getPayIDValueFromEditForm({
      email: '',
      organisationId: 'ORG123',
      phone: '',
      abnAcn: '',
      payIdType: 'ORGN',
    });
    expect(result).toBe('ORG123');
  });

  it('should return phone if payIdType is TELI and phone is provided', () => {
    const result = getPayIDValueFromEditForm({
      email: '',
      organisationId: '',
      phone: '+61412345678',
      abnAcn: '',
      payIdType: 'TELI',
    });
    expect(result).toBe('+61412345678');
  });

  it('should return abnAcn if payIdType is AUBN and abnAcn is provided', () => {
    const result = getPayIDValueFromEditForm({
      email: '',
      organisationId: '',
      phone: '',
      abnAcn: '12345678901',
      payIdType: 'AUBN',
    });
    expect(result).toBe('12345678901');
  });

  it('should return empty string if matching value is present but payIdType does not match', () => {
    const result = getPayIDValueFromEditForm({
      email: 'test@example.com',
      organisationId: '',
      phone: '',
      abnAcn: '',
      payIdType: 'TELI',
    });
    expect(result).toBe('');
  });

  it('should return email if payIdType is EMAL even when other values are provided', () => {
    const email = 'test@example.com';
    const result = getPayIDValueFromEditForm({
      email,
      organisationId: 'ORG123',
      phone: '',
      abnAcn: '',
      payIdType: 'EMAL',
    });
    expect(result).toBe(email);
  });
});

describe('formatAuthorisationStatus', () => {
  it('returns friendly status text', () => {
    const result = formatAuthorisationStatus({
      value: AUTHORISATION_STATUS.REJECTED,
    });
    expect(result).toBe('Rejected by authoriser');
  });
});

describe('getContextKey', () => {
  it('generate a new function', () => {
    const id = '1234';
    const fn = getContextKey('update');
    expect(fn(id)).toStrictEqual('update-1234');
  });

  it('test context keys', () => {
    const id = '1234';
    expect(updateBeneficiaryKey(id)).toStrictEqual(`update-beneficiary-${id}`);
    expect(viewBeneficiaryKey(id)).toStrictEqual(`view-beneficiary-${id}`);
  });
});

describe('test extractBeneficiaryDetails', () => {
  it('should extract details for Add Beneficiary', () => {
    const workflow = {
      subType: 'addbeneficiary',
      payloadObject: {
        beneficiaries: [
          {
            nickname: '',
            type: '',
            currency: '',
            divisionName: '',
            account: {
              accountId: {
                BSB: '',
                accountNumber: '',
              },
              accountName: '',
              bankName: '',
              payIDValue: '',
              payIDType: '',
              payIDName: '',
            },
          },
        ],
      },
    } as unknown as ApprovalWorkflow;
    expect(extractBeneficiaryDetails(workflow)).toEqual({
      beneficiaryNickname: '',
      type: '',
      currency: '',
      divisionName: '',
      authorisationRequest: 'addbeneficiary',
      account: {
        accountId: {
          BSB: '',
          accountNumber: '',
        },
        accountName: '',
        bankName: '',
        payIDValue: '',
        payIDType: '',
        payIDName: '',
      },
    });
  });

  it('should handle empty beneficiaries array (line 158)', () => {
    const workflow = {
      subType: 'addbeneficiary',
      payloadObject: {
        beneficiaries: [], // Empty array
      },
    } as unknown as ApprovalWorkflow;
    expect(extractBeneficiaryDetails(workflow)).toEqual({
      beneficiaryNickname: '',
      type: '',
      currency: '',
      divisionName: '',
      authorisationRequest: 'addbeneficiary',
      account: {
        accountId: {
          BSB: '',
          accountNumber: '',
        },
        accountName: '',
        bankName: '',
        payIDValue: '',
        payIDType: '',
        payIDName: '',
      },
    });
  });

  it('should handle non-array beneficiaries (line 158)', () => {
    const workflow = {
      subType: 'addbeneficiary',
      payloadObject: {
        beneficiaries: 'not-an-array', // Not an array
      },
    } as unknown as ApprovalWorkflow;
    expect(extractBeneficiaryDetails(workflow)).toEqual({
      beneficiaryNickname: '',
      type: '',
      currency: '',
      divisionName: '',
      authorisationRequest: 'addbeneficiary',
      account: {
        accountId: {
          BSB: '',
          accountNumber: '',
        },
        accountName: '',
        bankName: '',
        payIDValue: '',
        payIDType: '',
        payIDName: '',
      },
    });
  });

  it('should handle missing payloadObject (line 158)', () => {
    const workflow = {
      subType: 'addbeneficiary',
      payloadObject: null,
    } as unknown as ApprovalWorkflow;
    expect(extractBeneficiaryDetails(workflow)).toEqual({
      beneficiaryNickname: '',
      type: '',
      currency: '',
      divisionName: '',
      authorisationRequest: 'addbeneficiary',
      account: {
        accountId: {
          BSB: '',
          accountNumber: '',
        },
        accountName: '',
        bankName: '',
        payIDValue: '',
        payIDType: '',
        payIDName: '',
      },
    });
  });

  it('should handle missing beneficiaries property (line 158)', () => {
    const workflow = {
      subType: 'addbeneficiary',
      payloadObject: {
        otherProperty: 'value',
      },
    } as unknown as ApprovalWorkflow;
    expect(extractBeneficiaryDetails(workflow)).toEqual({
      beneficiaryNickname: '',
      type: '',
      currency: '',
      divisionName: '',
      authorisationRequest: 'addbeneficiary',
      account: {
        accountId: {
          BSB: '',
          accountNumber: '',
        },
        accountName: '',
        bankName: '',
        payIDValue: '',
        payIDType: '',
        payIDName: '',
      },
    });
  });

  it('should handle missing beneficiary property for amend/archive (line 169)', () => {
    const workflow = {
      subType: 'amendbeneficiary',
      payloadObject: {
        otherProperty: 'value',
      },
    } as unknown as ApprovalWorkflow;
    expect(extractBeneficiaryDetails(workflow)).toEqual({
      beneficiaryNickname: '',
      type: '',
      currency: '',
      divisionName: '',
      authorisationRequest: 'amendbeneficiary',
      account: {
        accountId: {
          BSB: '',
          accountNumber: '',
        },
        accountName: '',
        bankName: '',
        payIDValue: '',
        payIDType: '',
        payIDName: '',
      },
    });
  });

  it('should handle null beneficiary property for amend/archive (line 169)', () => {
    const workflow = {
      subType: 'amendbeneficiary',
      payloadObject: {
        beneficiary: null,
      },
    } as unknown as ApprovalWorkflow;
    expect(extractBeneficiaryDetails(workflow)).toEqual({
      beneficiaryNickname: '',
      type: '',
      currency: '',
      divisionName: '',
      authorisationRequest: 'amendbeneficiary',
      account: {
        accountId: {
          BSB: '',
          accountNumber: '',
        },
        accountName: '',
        bankName: '',
        payIDValue: '',
        payIDType: '',
        payIDName: '',
      },
    });
  });

  it('should extract details for Amend Beneficiary', () => {
    const workflow = {
      subType: 'amendbeneficiary',
      payloadObject: {
        beneficiary: {
          nickname: '',
          type: '',
          currency: '',
          divisionName: '',
          account: {
            accountId: {
              BSB: '',
              accountNumber: '',
            },
            accountName: '',
            bankName: '',
            payIDValue: '',
            payIDType: '',
            payIDName: '',
          },
        },
      },
    } as unknown as ApprovalWorkflow;
    expect(extractBeneficiaryDetails(workflow)).toEqual({
      beneficiaryNickname: '',
      type: '',
      currency: '',
      divisionName: '',
      authorisationRequest: 'amendbeneficiary',
      account: {
        accountId: {
          BSB: '',
          accountNumber: '',
        },
        accountName: '',
        bankName: '',
        payIDValue: '',
        payIDType: '',
        payIDName: '',
      },
    });
  });

  it('should extract details for Amend Beneficiary', () => {
    const workflow = {
      subType: 'amendbeneficiary',
      payloadObject: {
        beneficiary: {
          nickname: '',
          currency: '',
          divisionName: '',
          type: '',
          account: {
            accountId: {
              BSB: '',
              accountNumber: '',
            },
            accountName: '',
            bankName: '',
            payIDValue: '',
            payIDType: '',
            payIDName: '',
          },
        },
      },
    } as unknown as ApprovalWorkflow;
    expect(extractBeneficiaryDetails(workflow)).toEqual({
      beneficiaryNickname: '',
      type: '',
      currency: '',
      divisionName: '',
      authorisationRequest: 'amendbeneficiary',
      account: {
        accountId: {
          BSB: '',
          accountNumber: '',
        },
        accountName: '',
        bankName: '',
        payIDValue: '',
        payIDType: '',
        payIDName: '',
      },
    });
  });

  it('should extract details for Archive Beneficiary', () => {
    const workflow = {
      subType: 'archivebeneficiary',
      payloadObject: {
        beneficiary: {
          nickname: '',
          type: '',
          currency: '',
          divisionName: '',
          account: {
            accountId: {
              BSB: '',
              accountNumber: '',
            },
            accountName: '',
            bankName: '',
            payIDValue: '',
            payIDType: '',
            payIDName: '',
          },
        },
      },
    } as unknown as ApprovalWorkflow;
    expect(extractBeneficiaryDetails(workflow)).toEqual({
      beneficiaryNickname: '',
      type: '',
      currency: '',
      divisionName: '',
      authorisationRequest: 'archivebeneficiary',
      account: {
        accountId: {
          BSB: '',
          accountNumber: '',
        },
        accountName: '',
        bankName: '',
        payIDValue: '',
        payIDType: '',
        payIDName: '',
      },
    });
  });

  it('should return null beneficiary for unknown subType (default case)', () => {
    const workflow = {
      subType: 'unknowntype',
      payloadObject: {
        someData: 'test',
      },
    } as unknown as ApprovalWorkflow;
    expect(extractBeneficiaryDetails(workflow)).toEqual({
      beneficiaryNickname: '',
      type: '',
      currency: '',
      divisionName: '',
      authorisationRequest: 'unknowntype',
      account: {
        accountId: {
          BSB: '',
          accountNumber: '',
        },
        accountName: '',
        bankName: '',
        payIDValue: '',
        payIDType: '',
        payIDName: '',
      },
    });
  });
});

describe('mapApprovalWorkflowList', () => {
  it('should map approvalWorkflowList with add, amend, and archive beneficiaries', () => {
    const approvalWorkflowList = [
      {
        id: 'id-add',
        approvalWorkflowId: 'wf-add',
        workflowStatus: 'ApprovalPending',
        brand: 'WBC',
        subType: 'addbeneficiary',
        payloadObject: {
          beneficiaries: [
            {
              nickname: 'AddNick',
              currency: 'AUD',
              divisionName: '',
              type: 'BSB',
              account: {
                accountId: {
                  BSB: '',
                  accountNumber: '',
                },
                bankName: 'ANZ Bank',
                accountName: 'ANZ Joint',
              },
            },
          ],
        },
      },
      {
        id: 'id-amend',
        approvalWorkflowId: 'wf-amend',
        workflowStatus: 'ApprovalPending',
        brand: 'WBC',
        subType: 'amendbeneficiary',
        payloadObject: {
          beneficiary: {
            nickname: '',
            currency: '',
            divisionName: '',
            type: '',
            account: {
              accountId: {
                BSB: '',
                accountNumber: '',
              },
              bankName: '',
              accountName: '',
            },
          },
        },
      },
      {
        id: 'id-archive',
        approvalWorkflowId: 'wf-archive',
        workflowStatus: 'ApprovalPending',
        brand: 'WBC',
        subType: 'archivebeneficiary',
        payloadObject: {
          beneficiary: {
            nickname: '',
            currency: '',
            divisionName: '',
            type: '',
            account: {
              accountId: {
                BSB: '',
                accountNumber: '',
              },
              bankName: '',
              accountName: '',
            },
          },
        },
      },
    ];

    const result = mapApprovalWorkflowList(
      approvalWorkflowList as unknown as ApprovalWorkflow[]
    );

    expect(result).toEqual([
      {
        id: 'wf-add',
        status: 'ApprovalPending',
        type: 'BSB',
        currency: 'AUD',
        divisionName: '',
        account: {
          accountId: {
            BSB: '',
            accountNumber: '',
          },
          accountName: 'ANZ Joint',
          bankName: 'ANZ Bank',
          payIDName: '',
          payIDType: '',
          payIDValue: '',
        },
        authorisationRequest: 'addbeneficiary',
        authorisationType: 'addbeneficiary',
        beneficiaryNickname: 'AddNick',
        creationDateTime: '',
        payloadString: '',
      },
      {
        id: 'wf-amend',
        status: 'ApprovalPending',
        type: '',
        currency: '',
        divisionName: '',
        account: {
          accountId: {
            BSB: '',
            accountNumber: '',
          },
          accountName: '',
          bankName: '',
          payIDName: '',
          payIDType: '',
          payIDValue: '',
        },
        authorisationRequest: 'amendbeneficiary',
        authorisationType: 'amendbeneficiary',
        beneficiaryNickname: '',
        creationDateTime: '',
        payloadString: '',
      },
      {
        id: 'wf-archive',
        status: 'ApprovalPending',
        type: '',
        currency: '',
        divisionName: '',
        account: {
          accountId: {
            BSB: '',
            accountNumber: '',
          },
          accountName: '',
          bankName: '',
          payIDName: '',
          payIDType: '',
          payIDValue: '',
        },
        authorisationRequest: 'archivebeneficiary',
        authorisationType: 'archivebeneficiary',
        beneficiaryNickname: '',
        creationDateTime: '',
        payloadString: '',
      },
    ]);
  });

  it('should return empty array when approvalWorkflowList is not an array', () => {
    expect(
      mapApprovalWorkflowList(null as unknown as ApprovalWorkflow[])
    ).toEqual([]);
    expect(
      mapApprovalWorkflowList(undefined as unknown as ApprovalWorkflow[])
    ).toEqual([]);
    expect(
      mapApprovalWorkflowList('not an array' as unknown as ApprovalWorkflow[])
    ).toEqual([]);
    expect(
      mapApprovalWorkflowList({} as unknown as ApprovalWorkflow[])
    ).toEqual([]);
  });
});

describe('test transformApprovalWorkflowToBeneficiaryTaskDetail', () => {
  it('should transform addbeneficiary workflow correctly', () => {
    const workflow = {
      subType: 'addbeneficiary',
      approvalWorkflowId: 'wf-1',
      id: 'ext-1',
      workflowStatus: 'PENDING',
      brand: 'office',
      payloadObject: {
        beneficiaries: [
          {
            type: 'BSB_ACCOUNT_NUMBER',
            currency: 'AUD',
            divisionName: '',
            nickname: 'Nick Add',
            account: {
              bankName: 'Account bank name',
              accountName: 'Account Add',
              accountId: {
                BSB: '123456',
                accountNumber: '111222',
              },
            },
          },
        ],
      },
    } as unknown as ApprovalWorkflowDetail;
    const result = transformApprovalWorkflowToBeneficiaryTaskDetail(workflow);
    expect(result).toEqual({
      subType: 'addbeneficiary',
      account: {
        accountId: {
          BSB: '123456',
          accountNumber: '111222',
        },
        accountName: 'Account Add',
        bankName: 'Account bank name',
      },
      id: 'wf-1',
      nickname: 'Nick Add',
      status: 'PENDING',
      beneficiaryId: '',
      currencyAmount: {
        currencyCode: '',
        amount: '',
      },
      reference: '',
      rejectedWorkflowAuditDetails: {
        actionedBy: '',
        actionedDateTime: '',
      },
      sentForAuthWorkflowAuditDetails: {
        actionedBy: '',
        actionedDateTime: '',
      },
      divisionName: '',
      matchedCOPStatusCode: undefined,
      matchedCOPAccountName: undefined,
    });
  });

  it('should transform amendbeneficiary workflow with beneficiaries array', () => {
    const workflow = {
      subType: 'amendbeneficiary',
      approvalWorkflowId: 'wf-2',
      id: 'ext-2',
      workflowStatus: 'PENDING',
      brand: 'office',
      payloadObject: {
        beneficiary: {
          type: 'PAYID',
          currency: 'AUD',
          divisionName: '',
          nickname: 'Nick Amend',
          account: {
            payIDName: 'payid name',
            payIDType: 'TELI',
            payIDValue: '0488888888',
          },
        },
      },
    } as unknown as ApprovalWorkflowDetail;
    const result = transformApprovalWorkflowToBeneficiaryTaskDetail(workflow);
    expect(result).toEqual({
      subType: 'amendbeneficiary',
      account: {
        payIDName: 'payid name',
        payIDType: 'TELI',
        payIDValue: '0488888888',
      },
      id: 'wf-2',
      nickname: 'Nick Amend',
      status: 'PENDING',
      beneficiaryId: '',
      currencyAmount: {
        currencyCode: '',
        amount: '',
      },
      reference: '',
      rejectedWorkflowAuditDetails: {
        actionedBy: '',
        actionedDateTime: '',
      },
      sentForAuthWorkflowAuditDetails: {
        actionedBy: '',
        actionedDateTime: '',
      },
      divisionName: '',
      matchedCOPStatusCode: undefined,
      matchedCOPAccountName: undefined,
    });
  });

  it('should transform archivebeneficiary workflow correctly', () => {
    const workflow = {
      subType: 'archivebeneficiary',
      approvalWorkflowId: 'wf-4',
      id: 'ext-4',
      workflowStatus: 'ARCHIVED',
      brand: 'office',
      payloadObject: {
        beneficiary: {
          type: 'BSB_ACCOUNT_NUMBER',
          currency: 'AUD',
          divisionName: '',
          nickname: 'Nick Archive',
          account: {
            accountName: 'Account Archive',
            accountId: {
              BSB: '222333',
              accountNumber: '777888',
            },
            bankName: 'Account Bank Name',
          },
        },
      },
    } as unknown as ApprovalWorkflowDetail;
    const result = transformApprovalWorkflowToBeneficiaryTaskDetail(workflow);
    expect(result).toEqual({
      subType: 'archivebeneficiary',
      account: {
        accountId: {
          BSB: '222333',
          accountNumber: '777888',
        },
        accountName: 'Account Archive',
        bankName: 'Account Bank Name',
      },
      id: 'wf-4',
      nickname: 'Nick Archive',
      status: 'ARCHIVED',
      beneficiaryId: '',
      currencyAmount: {
        currencyCode: '',
        amount: '',
      },
      reference: '',
      rejectedWorkflowAuditDetails: {
        actionedBy: '',
        actionedDateTime: '',
      },
      sentForAuthWorkflowAuditDetails: {
        actionedBy: '',
        actionedDateTime: '',
      },
      divisionName: '',
      matchedCOPStatusCode: undefined,
      matchedCOPAccountName: undefined,
    });
  });

  it('should transform addbeneficiary workflow with beneficiaries object (not array)', () => {
    const workflow = {
      subType: 'addbeneficiary',
      approvalWorkflowId: 'wf-single',
      workflowStatus: 'PENDING',
      approvalWorkflowsAudit: [],
      payloadObject: {
        beneficiaries: {
          type: 'BSB_ACCOUNT_NUMBER',
          currency: 'AUD',
          divisionName: '',
          nickname: 'Single Beneficiary',
          account: {
            bankName: 'Single Bank',
            accountName: 'Single Account',
            accountId: {
              BSB: '111111',
              accountNumber: '999999',
            },
          },
        },
      },
    } as unknown as ApprovalWorkflowDetail;
    const result = transformApprovalWorkflowToBeneficiaryTaskDetail(workflow);
    expect(result).toEqual({
      subType: 'addbeneficiary',
      account: {
        accountId: {
          BSB: '111111',
          accountNumber: '999999',
        },
        accountName: 'Single Account',
        bankName: 'Single Bank',
      },
      currencyAmount: {
        currencyCode: '',
        amount: '',
      },
      reference: '',
      id: 'wf-single',
      nickname: 'Single Beneficiary',
      status: 'PENDING',
      beneficiaryId: '',
      rejectedWorkflowAuditDetails: {
        actionedBy: '',
        actionedDateTime: '',
      },
      sentForAuthWorkflowAuditDetails: {
        actionedBy: '',
        actionedDateTime: '',
      },
      divisionName: '',
      matchedCOPStatusCode: undefined,
      matchedCOPAccountName: undefined,
    });
  });

  it('should handle unknown subType in transformApprovalWorkflowToBeneficiaryTaskDetail (default case)', () => {
    const workflow = {
      subType: 'unknownsubtype',
      approvalWorkflowId: 'wf-unknown',
      workflowStatus: 'PENDING',
      approvalWorkflowsAudit: [],
    } as unknown as ApprovalWorkflowDetail;
    const result = transformApprovalWorkflowToBeneficiaryTaskDetail(workflow);
    expect(result).toEqual({
      subType: 'unknownsubtype',
      account: {
        payIDValue: '',
        payIDName: '',
        payIDType: '',
      },
      id: 'wf-unknown',
      nickname: '',
      status: 'PENDING',
      beneficiaryId: '',
      currencyAmount: {
        currencyCode: '',
        amount: '',
      },
      reference: '',
      rejectedWorkflowAuditDetails: {
        actionedBy: '',
        actionedDateTime: '',
      },
      sentForAuthWorkflowAuditDetails: {
        actionedBy: '',
        actionedDateTime: '',
      },
      divisionName: '',
      matchedCOPStatusCode: undefined,
      matchedCOPAccountName: undefined,
    });
  });
});

describe('mapSubTypeLabel', () => {
  it('should return "Add beneficiary" for addbeneficiary subType', () => {
    expect(mapSubTypeLabel('addbeneficiary')).toBe('Add beneficiary');
  });

  it('should return "Update beneficiary" for amendbeneficiary subType', () => {
    expect(mapSubTypeLabel('amendbeneficiary')).toBe('Update beneficiary');
  });

  it('should return "Archive beneficiary" for archivebeneficiary subType', () => {
    expect(mapSubTypeLabel('archivebeneficiary')).toBe('Archive beneficiary');
  });

  it('should return the original subType for unknown subType', () => {
    expect(mapSubTypeLabel('unknowntype')).toBe('unknowntype');
  });

  it('should return empty string for undefined subType', () => {
    expect(mapSubTypeLabel(undefined)).toBe('');
  });

  it('should return empty string for empty string subType', () => {
    expect(mapSubTypeLabel('')).toBe('');
  });
});

describe('mapStatusToWorkflowStatus', () => {
  it('should map ApprovalPending to friendly status', () => {
    expect(mapStatusToWorkflowStatus('ApprovalPending')).toBe(
      'Pending authorisation'
    );
  });

  it('should map Rejected to friendly status', () => {
    expect(mapStatusToWorkflowStatus('Rejected')).toBe(
      'Rejected by authoriser'
    );
  });
});

describe('mapAuthorisationRequestToWorkflowSubtype', () => {
  it('should map addbeneficiary to friendly label', () => {
    expect(mapAuthorisationRequestToWorkflowSubtype('addbeneficiary')).toBe(
      'Add beneficiary'
    );
  });

  it('should map amendbeneficiary to friendly label', () => {
    expect(mapAuthorisationRequestToWorkflowSubtype('amendbeneficiary')).toBe(
      'Update beneficiary'
    );
  });

  it('should map archivebeneficiary to friendly label', () => {
    expect(mapAuthorisationRequestToWorkflowSubtype('archivebeneficiary')).toBe(
      'Archive beneficiary'
    );
  });
});

describe('getWorkflowAuditDetails', () => {
  it('should return audit details when event is ServiceRequestAuthorisationRequestRejected', () => {
    const workflow = {
      approvalWorkflowsAudit: [
        {
          action: {
            type: 'Creation',
            dateTime: '2024-01-01T10:00:00Z',
          },
          actionedBy: {
            firstName: 'John',
            lastName: 'Doe',
          },
        },
        {
          action: {
            type: 'Event',
            dateTime: '2024-01-02T11:00:00Z',
          },
          actionedBy: {
            firstName: 'Jane',
            lastName: 'Smith',
          },
          eventName: 'ServiceRequestAuthorisationRequestRejected',
        },
      ],
    } as unknown as ApprovalWorkflowDetail;

    const result = getWorkflowAuditDetails(
      workflow,
      'ServiceRequestAuthorisationRequestRejected' as any
    );
    expect(result).toEqual({
      actionedBy: 'Jane Smith',
      actionedDateTime: '2024-01-02T11:00:00Z',
    });
  });

  it('should return empty audit details when no matching audit is found', () => {
    const workflow = {
      approvalWorkflowsAudit: [
        {
          action: {
            type: 'PENDING_AUTHORISATION',
            dateTime: '2024-01-01T10:00:00Z',
          },
          actionedBy: {
            firstName: 'John',
            lastName: 'Doe',
          },
        },
      ],
    } as unknown as ApprovalWorkflowDetail;

    const result = getWorkflowAuditDetails(
      workflow,
      'REJECTED' as APPROVAL_WORKFLOW_AUDIT_EVENT_NAME
    );
    expect(result).toEqual({
      actionedBy: '',
      actionedDateTime: '',
    });
  });

  it('should handle missing first or last name', () => {
    const workflow = {
      approvalWorkflowsAudit: [
        {
          action: {
            type: 'Event',
            dateTime: '2024-01-01T10:00:00Z',
          },
          actionedBy: {
            firstName: 'John',
            lastName: '',
          },
          eventName: 'ServiceRequestAuthorisationRequested',
        },
      ],
    } as unknown as ApprovalWorkflowDetail;

    const result = getWorkflowAuditDetails(
      workflow,
      'ServiceRequestAuthorisationRequested' as any
    );
    expect(result).toEqual({
      actionedBy: 'John',
      actionedDateTime: '2024-01-01T10:00:00Z',
    });
  });

  it('should handle missing actionedBy', () => {
    const workflow = {
      approvalWorkflowsAudit: [
        {
          action: {
            type: 'Event',
            dateTime: '2024-01-01T10:00:00Z',
          },

          eventName: 'ServiceRequestAuthorisationRequested',
        },
      ],
    } as unknown as ApprovalWorkflowDetail;

    const result = getWorkflowAuditDetails(
      workflow,
      'ServiceRequestAuthorisationRequested' as any
    );
    expect(result).toEqual({
      actionedBy: '',
      actionedDateTime: '2024-01-01T10:00:00Z',
    });
  });
});

describe('test mapApprovalWorkflowList', () => {
  it('should map approval workflow list', () => {
    const approvalWorkflowList = [
      {
        approvalWorkflowId: 'test-id-1',
        workflowStatus: 'PENDING',
        requestedDateTime: '2024-01-01T00:00:00.000Z',
        subType: 'addbeneficiary',
        payloadObject: {
          beneficiaries: [
            {
              nickname: 'test-nickname',
              type: 'BSB',
              currency: 'AUD',
              divisionName: '',
              account: {
                accountId: {
                  BSB: '123-456',
                  accountNumber: '12345678',
                },
                accountName: 'test-account',
                bankName: 'test-bank',
              },
            },
          ],
        },
        payloadString: 'test-payload-string',
      },
    ] as unknown as ApprovalWorkflow[];

    const result = mapApprovalWorkflowList(approvalWorkflowList);

    expect(result).toEqual([
      {
        id: 'test-id-1',
        status: 'PENDING',
        creationDateTime: '2024-01-01T00:00:00.000Z',
        authorisationType: 'addbeneficiary',
        beneficiaryNickname: 'test-nickname',
        type: 'BSB',
        currency: 'AUD',
        divisionName: '',
        authorisationRequest: 'addbeneficiary',
        account: {
          accountId: {
            BSB: '123-456',
            accountNumber: '12345678',
          },
          accountName: 'test-account',
          bankName: 'test-bank',
          payIDValue: '',
          payIDType: '',
          payIDName: '',
        },
        payloadString: 'test-payload-string',
      },
    ]);
  });

  it('should return empty array for non-array input (line 205)', () => {
    const result = mapApprovalWorkflowList(
      'not-an-array' as unknown as ApprovalWorkflow[]
    );
    expect(result).toEqual([]);
  });

  it('should return empty array for null input (line 205)', () => {
    const result = mapApprovalWorkflowList(
      null as unknown as ApprovalWorkflow[]
    );
    expect(result).toEqual([]);
  });

  it('should return empty array for undefined input (line 205)', () => {
    const result = mapApprovalWorkflowList(
      undefined as unknown as ApprovalWorkflow[]
    );
    expect(result).toEqual([]);
  });

  it('should handle empty array', () => {
    const result = mapApprovalWorkflowList([]);
    expect(result).toEqual([]);
  });

  it('should handle workflow with missing payloadObject (line 219)', () => {
    const approvalWorkflowList = [
      {
        approvalWorkflowId: 'test-id',
        workflowStatus: 'PENDING',
        requestedDateTime: '2024-01-01T00:00:00.000Z',
        subType: 'addbeneficiary',
        payloadObject: null, // Missing payloadObject
        payloadString: 'test-payload-string',
      },
    ] as unknown as ApprovalWorkflow[];

    const result = mapApprovalWorkflowList(approvalWorkflowList);

    expect(result[0]).toEqual({
      id: 'test-id',
      status: 'PENDING',
      creationDateTime: '2024-01-01T00:00:00.000Z',
      authorisationType: 'addbeneficiary',
      beneficiaryNickname: '',
      type: '',
      authorisationRequest: '',
      account: {
        accountId: {
          BSB: '',
          accountNumber: '',
        },
        accountName: '',
        bankName: '',
        payIDValue: '',
        payIDName: '',
        payIDType: '',
      },
      payloadString: 'test-payload-string',
    });
  });

  it('should handle missing properties with nullish coalescing (lines 232-240)', () => {
    const approvalWorkflowList = [
      {
        // Missing all properties to test nullish coalescing
      } as unknown as ApprovalWorkflow,
    ];

    const result = mapApprovalWorkflowList(approvalWorkflowList);

    expect(result[0]).toEqual({
      id: '',
      status: '',
      creationDateTime: '',
      authorisationType: '',
      beneficiaryNickname: '',
      type: '',
      authorisationRequest: '',
      account: {
        accountId: {
          BSB: '',
          accountNumber: '',
        },
        accountName: '',
        bankName: '',
        payIDValue: '',
        payIDName: '',
        payIDType: '',
      },
      payloadString: '',
    });
  });
});

describe('test transformApprovalWorkflowToBeneficiaryTaskDetail additional cases', () => {
  it('should handle missing payloadObject (line 219)', () => {
    const approvalWorkflow = {
      approvalWorkflowId: 'test-id',
      workflowStatus: 'PENDING',
      requestedDateTime: '2024-01-01T00:00:00.000Z',
      subType: 'addbeneficiary',
      payloadObject: null, // Missing payloadObject
      payloadString: 'test-payload-string',
    } as unknown as ApprovalWorkflowDetail;

    const result =
      transformApprovalWorkflowToBeneficiaryTaskDetail(approvalWorkflow);

    expect(result).toEqual({
      subType: 'addbeneficiary',
      account: {
        payIDValue: '',
        payIDName: '',
        payIDType: '',
      },
      beneficiaryId: '',
      currencyAmount: {
        amount: '',
        currencyCode: '',
      },
      divisionName: '',
      id: 'test-id',
      nickname: '',
      status: 'PENDING',
      sentForAuthWorkflowAuditDetails: { actionedBy: '', actionedDateTime: '' },
      reference: '',
      rejectedWorkflowAuditDetails: { actionedBy: '', actionedDateTime: '' },
      matchedCOPStatusCode: undefined,
      matchedCOPAccountName: undefined,
    });
  });

  it('should handle missing properties with nullish coalescing (lines 232-240)', () => {
    const approvalWorkflow = {
      // Missing all properties to test nullish coalescing
      approvalWorkflowsAudit: [],
    } as unknown as ApprovalWorkflowDetail;

    const result =
      transformApprovalWorkflowToBeneficiaryTaskDetail(approvalWorkflow);

    expect(result).toEqual({
      subType: '',
      account: {
        payIDValue: '',
        payIDName: '',
        payIDType: '',
      },
      beneficiaryId: '',
      currencyAmount: {
        amount: '',
        currencyCode: '',
      },
      divisionName: '',
      id: '',
      nickname: '',
      status: '',
      sentForAuthWorkflowAuditDetails: { actionedBy: '', actionedDateTime: '' },
      reference: '',
      rejectedWorkflowAuditDetails: { actionedBy: '', actionedDateTime: '' },
      matchedCOPStatusCode: undefined,
      matchedCOPAccountName: undefined,
    });
  });

  it('should handle partial properties (lines 232-240)', () => {
    const approvalWorkflow = {
      approvalWorkflowId: 'test-id',
      workflowStatus: null,
      requestedDateTime: undefined,
      subType: 'amendbeneficiary',
      payloadObject: {
        beneficiary: {
          nickname: 'test-nickname',
          type: 'PayID',
          currency: 'AUD',
          account: {
            payIDValue: 'test@example.com',
            payIDType: 'EMAIL',
            payIDName: 'Test User',
          },
          divisionName: '',
        },
      },
      payloadString: null,
      approvalWorkflowsAudit: [],
    } as unknown as ApprovalWorkflowDetail;

    const result =
      transformApprovalWorkflowToBeneficiaryTaskDetail(approvalWorkflow);

    expect(result).toEqual({
      subType: 'amendbeneficiary',
      account: {
        payIDValue: 'test@example.com',
        payIDName: 'Test User',
        payIDType: 'EMAIL',
      },
      beneficiaryId: '',
      currencyAmount: {
        amount: '',
        currencyCode: '',
      },
      id: 'test-id',
      nickname: 'test-nickname',
      divisionName: '',
      status: '',
      sentForAuthWorkflowAuditDetails: { actionedBy: '', actionedDateTime: '' },
      reference: '',
      rejectedWorkflowAuditDetails: { actionedBy: '', actionedDateTime: '' },
      matchedCOPStatusCode: undefined,
      matchedCOPAccountName: undefined,
    });
  });
});

describe('test additional uncovered lines', () => {
  it('should handle non-array beneficiaries in addbeneficiary (line 276)', () => {
    const workflow = {
      approvalWorkflowId: 'test-id',
      workflowStatus: 'PENDING',
      subType: 'addbeneficiary',
      payloadObject: {
        beneficiaries: {
          // Non-array beneficiaries - should use as single beneficiary
          nickname: 'test-nickname',
          type: BENEFICIARY_TYPE.ACCOUNT, // Use proper enum constant
          currency: 'AUD',
          account: {
            accountId: {
              BSB: '123-456',
              accountNumber: '12345678',
            },
            accountName: 'test-account',
            bankName: 'test-bank',
          },
        },
      },
      approvalWorkflowsAudit: [],
    } as unknown as ApprovalWorkflowDetail;

    const result = transformApprovalWorkflowToBeneficiaryTaskDetail(workflow);

    expect(result.nickname).toBe('test-nickname');
    expect(result.account).toEqual({
      accountId: {
        BSB: '123-456',
        accountNumber: '12345678',
      },
      accountName: 'test-account',
      bankName: 'test-bank',
    });
  });

  it('should handle PayID beneficiary type (line 312-316)', () => {
    const workflow = {
      approvalWorkflowId: 'test-id',
      workflowStatus: 'PENDING',
      subType: 'addbeneficiary',
      payloadObject: {
        beneficiaries: [
          {
            nickname: 'test-payid',
            type: 'PAYID', // Non-ACCOUNT type to trigger PayID branch
            currency: 'AUD',
            divisionName: '',
            account: {
              payIDValue: 'test@example.com',
              payIDName: 'Test User',
              payIDType: 'EMAIL',
            },
          },
        ],
      },
      approvalWorkflowsAudit: [],
    } as unknown as ApprovalWorkflowDetail;

    const result = transformApprovalWorkflowToBeneficiaryTaskDetail(workflow);

    expect(result.nickname).toBe('test-payid');
    expect(result.account).toEqual({
      payIDValue: 'test@example.com',
      payIDName: 'Test User',
      payIDType: 'EMAIL',
    });
  });

  it('should handle missing account data in PayID beneficiary (line 326-328)', () => {
    const workflow = {
      approvalWorkflowId: 'test-id',
      workflowStatus: 'PENDING',
      subType: 'addbeneficiary',
      payloadObject: {
        beneficiaries: [
          {
            nickname: 'test-payid',
            type: 'PAYID', // Non-ACCOUNT type
            currency: 'AUD',
            divisionName: '',
            account: null, // Missing account data
          },
        ],
      },
      approvalWorkflowsAudit: [],
    } as unknown as ApprovalWorkflowDetail;

    const result = transformApprovalWorkflowToBeneficiaryTaskDetail(workflow);

    expect(result.account).toEqual({
      payIDValue: '',
      payIDName: '',
      payIDType: '',
    });
  });

  it('should handle missing account data in BSB beneficiary (line 312-316)', () => {
    const workflow = {
      approvalWorkflowId: 'test-id',
      workflowStatus: 'PENDING',
      subType: 'addbeneficiary',
      payloadObject: {
        beneficiaries: [
          {
            nickname: 'test-bsb',
            type: BENEFICIARY_TYPE.ACCOUNT, // Use proper enum constant
            currency: 'AUD',
            divisionName: '',
            account: null, // Missing account data
          },
        ],
      },
      approvalWorkflowsAudit: [],
    } as unknown as ApprovalWorkflowDetail;

    const result = transformApprovalWorkflowToBeneficiaryTaskDetail(workflow);

    expect(result).toEqual({
      subType: 'addbeneficiary',
      account: {
        accountId: {
          BSB: '',
          accountNumber: '',
        },
        accountName: '',
        bankName: '',
      },
      beneficiaryId: '',
      currencyAmount: {
        amount: '',
        currencyCode: '',
      },
      divisionName: '',
      id: 'test-id',
      nickname: 'test-bsb',
      status: 'PENDING',
      sentForAuthWorkflowAuditDetails: { actionedBy: '', actionedDateTime: '' },
      reference: '',
      rejectedWorkflowAuditDetails: { actionedBy: '', actionedDateTime: '' },
      matchedCOPStatusCode: undefined,
      matchedCOPAccountName: undefined,
    });
  });

  it('should handle missing all workflow properties (line 330)', () => {
    const workflow = {
      // Missing all properties
      approvalWorkflowsAudit: [],
    } as unknown as ApprovalWorkflowDetail;

    const result = transformApprovalWorkflowToBeneficiaryTaskDetail(workflow);

    expect(result).toEqual({
      subType: '',
      account: {
        payIDValue: '',
        payIDName: '',
        payIDType: '',
      },
      beneficiaryId: '',
      currencyAmount: {
        amount: '',
        currencyCode: '',
      },
      divisionName: '',
      id: '',
      nickname: '',
      status: '',
      sentForAuthWorkflowAuditDetails: { actionedBy: '', actionedDateTime: '' },
      reference: '',
      rejectedWorkflowAuditDetails: { actionedBy: '', actionedDateTime: '' },
      matchedCOPStatusCode: undefined,
      matchedCOPAccountName: undefined,
    });
  });

  it('should handle workflow with audit details (line 288)', () => {
    const workflow = {
      approvalWorkflowId: 'test-id',
      workflowStatus: 'PENDING',
      subType: 'addbeneficiary',
      payloadObject: {
        beneficiaries: [
          {
            nickname: 'test-nickname',
            type: BENEFICIARY_TYPE.ACCOUNT, // Use proper enum constant
            currency: 'AUD',
            divisionName: '',
            account: {
              accountId: {
                BSB: '123-456',
                accountNumber: '12345678',
              },
              accountName: 'test-account',
              bankName: 'test-bank',
            },
          },
        ],
      },
      approvalWorkflowsAudit: [
        {
          action: {
            type: 'Event',
            dateTime: '2024-01-01T10:00:00Z',
          },
          actionedBy: {
            firstName: 'John',
            lastName: 'Doe',
          },
          eventName: 'ServiceRequestAuthorisationRequested',
        },
        {
          action: {
            type: 'Event',
            dateTime: '2024-01-01T11:00:00Z',
          },
          actionedBy: {
            firstName: 'Jane',
            lastName: 'Smith',
          },
          eventName: 'ServiceRequestAuthorisationRequestRejected',
        },
      ],
    } as unknown as ApprovalWorkflowDetail;

    const result = transformApprovalWorkflowToBeneficiaryTaskDetail(workflow);

    expect(result).toEqual({
      subType: 'addbeneficiary',
      account: {
        accountId: {
          BSB: '123-456',
          accountNumber: '12345678',
        },
        accountName: 'test-account',
        bankName: 'test-bank',
      },
      beneficiaryId: '',
      currencyAmount: {
        amount: '',
        currencyCode: '',
      },
      divisionName: '',
      id: 'test-id',
      nickname: 'test-nickname',
      status: 'PENDING',
      sentForAuthWorkflowAuditDetails: {
        actionedBy: 'John Doe',
        actionedDateTime: '2024-01-01T10:00:00Z',
      },
      reference: '',
      rejectedWorkflowAuditDetails: {
        actionedBy: 'Jane Smith',
        actionedDateTime: '2024-01-01T11:00:00Z',
      },
      matchedCOPStatusCode: undefined,
      matchedCOPAccountName: undefined,
    });
  });
});

describe('test mapSubTypeLabel', () => {
  it('should map addbeneficiary to "Add beneficiary"', () => {
    expect(mapSubTypeLabel('addbeneficiary')).toBe('Add beneficiary');
  });

  it('should map amendbeneficiary to "Update beneficiary"', () => {
    expect(mapSubTypeLabel('amendbeneficiary')).toBe('Update beneficiary');
  });

  it('should map archivebeneficiary to "Archive beneficiary"', () => {
    expect(mapSubTypeLabel('archivebeneficiary')).toBe('Archive beneficiary');
  });

  it('should return the subType for unknown values', () => {
    expect(mapSubTypeLabel('unknown')).toBe('unknown');
  });

  it('should return empty string for undefined', () => {
    expect(mapSubTypeLabel(undefined)).toBe('');
  });
});

describe('interpolateTemplate', () => {
  // Import the function
  const { interpolateTemplate } = require('./Beneficiary.util');

  it('should return empty string when template is empty', () => {
    expect(interpolateTemplate('')).toBe('');
  });

  it('should return empty string when template is null', () => {
    expect(interpolateTemplate(null as any)).toBe('');
  });

  it('should return empty string when template is undefined', () => {
    expect(interpolateTemplate(undefined as any)).toBe('');
  });

  it('should return template unchanged when values is undefined', () => {
    const template = 'The beneficiary ${beneficiaryNickname} has been updated.';
    expect(interpolateTemplate(template, undefined)).toBe(template);
  });

  it('should return template unchanged when values is null', () => {
    const template = 'The beneficiary ${beneficiaryNickname} has been updated.';
    expect(interpolateTemplate(template, null as any)).toBe(template);
  });

  it('should return template unchanged when values is an empty object', () => {
    const template = 'The beneficiary ${beneficiaryNickname} has been updated.';
    expect(interpolateTemplate(template, {})).toBe(template);
  });

  it('should replace single placeholder with value', () => {
    const template = 'The beneficiary ${beneficiaryNickname} has been updated.';
    const values = { beneficiaryNickname: 'Test Beneficiary' };
    expect(interpolateTemplate(template, values)).toBe(
      'The beneficiary Test Beneficiary has been updated.'
    );
  });

  it('should replace multiple placeholders with values', () => {
    const template =
      'User ${userName} updated ${beneficiaryNickname} at ${time}.';
    const values = {
      userName: 'John Doe',
      beneficiaryNickname: 'Test Beneficiary',
      time: '10:00 AM',
    };
    expect(interpolateTemplate(template, values)).toBe(
      'User John Doe updated Test Beneficiary at 10:00 AM.'
    );
  });

  it('should replace the same placeholder multiple times', () => {
    const template =
      '${beneficiaryNickname} was updated. ${beneficiaryNickname} is now active.';
    const values = { beneficiaryNickname: 'Test Beneficiary' };
    expect(interpolateTemplate(template, values)).toBe(
      'Test Beneficiary was updated. Test Beneficiary is now active.'
    );
  });

  it('should handle template with no placeholders', () => {
    const template = 'The beneficiary has been updated.';
    const values = { beneficiaryNickname: 'Test Beneficiary' };
    expect(interpolateTemplate(template, values)).toBe(
      'The beneficiary has been updated.'
    );
  });

  it('should handle values that are not used in template', () => {
    const template = 'The beneficiary ${beneficiaryNickname} has been updated.';
    const values = {
      beneficiaryNickname: 'Test Beneficiary',
      extraValue: 'Not Used',
    };
    expect(interpolateTemplate(template, values)).toBe(
      'The beneficiary Test Beneficiary has been updated.'
    );
  });

  it('should keep placeholder intact when no matching value is provided', () => {
    const template = 'The beneficiary ${beneficiaryNickname} has been updated.';
    const values = { otherKey: 'Test Value' };
    expect(interpolateTemplate(template, values)).toBe(
      'The beneficiary ${beneficiaryNickname} has been updated.'
    );
  });

  it('should handle empty string values', () => {
    const template = 'The beneficiary ${beneficiaryNickname} has been updated.';
    const values = { beneficiaryNickname: '' };
    expect(interpolateTemplate(template, values)).toBe(
      'The beneficiary  has been updated.'
    );
  });

  it('should handle special characters in placeholder values', () => {
    const template = 'The beneficiary ${beneficiaryNickname} has been updated.';
    const values = { beneficiaryNickname: "O'Brien & Co." };
    expect(interpolateTemplate(template, values)).toBe(
      "The beneficiary O'Brien & Co. has been updated."
    );
  });

  it('should handle values with regex special characters', () => {
    const template = 'The beneficiary ${beneficiaryNickname} has been updated.';
    const values = { beneficiaryNickname: 'Test (Beneficiary) [123]' };
    expect(interpolateTemplate(template, values)).toBe(
      'The beneficiary Test (Beneficiary) [123] has been updated.'
    );
  });

  it('should work with success message constants', () => {
    const template = 'The beneficiary ${beneficiaryNickname} has been updated.';
    const values = { beneficiaryNickname: 'My Account' };
    expect(interpolateTemplate(template, values)).toBe(
      'The beneficiary My Account has been updated.'
    );
  });

  it('should work with archive success message', () => {
    const template =
      'The beneficiary ${beneficiaryNickname} has been archived.';
    const values = { beneficiaryNickname: 'Old Account' };
    expect(interpolateTemplate(template, values)).toBe(
      'The beneficiary Old Account has been archived.'
    );
  });

  it('should work with sent for authorisation message', () => {
    const template =
      'Updates to the beneficiary ${beneficiaryNickname} have been sent for authorisation.';
    const values = { beneficiaryNickname: 'Business Account' };
    expect(interpolateTemplate(template, values)).toBe(
      'Updates to the beneficiary Business Account have been sent for authorisation.'
    );
  });
});

describe('buildBeneficiaryCreateEntitlement - matchedCOPColour', () => {
  const baseAccountFormData = {
    beneficiaryNickname: 'Test Bene',
    beneficiaryType: BENEFICIARY_TYPE.ACCOUNT as const,
    bsb: '123456',
    accountNumber: '12345678',
    accountName: 'Test Account',
    bankName: 'Test Bank',
    phone: '',
    email: '',
    abnAcn: '',
    organisationId: '',
  };

  it('should include PAYEE_NAME_CHECK_COLOUR in supplementaryData when matchedCOPColour is provided for ACCOUNT type', () => {
    const result = buildBeneficiaryCreateEntitlement(
      baseAccountFormData,
      'Amber' as any
    );

    const colourEntry = result.supplementaryData.find(
      item => item.name === 'PAYEE_NAME_CHECK_COLOUR'
    );
    expect(colourEntry).toEqual({
      name: 'PAYEE_NAME_CHECK_COLOUR',
      value: 'Amber',
      datatype: 'STRING',
    });
  });

  it('should not include PAYEE_NAME_CHECK_COLOUR when matchedCOPColour is undefined for ACCOUNT type', () => {
    const result = buildBeneficiaryCreateEntitlement(baseAccountFormData);

    const colourEntry = result.supplementaryData.find(
      item => item.name === 'PAYEE_NAME_CHECK_COLOUR'
    );
    expect(colourEntry).toBeUndefined();
  });

  it('should include PAYEE_NAME_CHECK_COLOUR with Red value', () => {
    const result = buildBeneficiaryCreateEntitlement(
      baseAccountFormData,
      'Red' as any
    );

    const colourEntry = result.supplementaryData.find(
      item => item.name === 'PAYEE_NAME_CHECK_COLOUR'
    );
    expect(colourEntry).toBeDefined();
    expect(colourEntry!.value).toBe('Red');
  });

  it('should include PAYEE_NAME_CHECK_COLOUR with Blue value', () => {
    const result = buildBeneficiaryCreateEntitlement(
      baseAccountFormData,
      'Blue' as any
    );

    const colourEntry = result.supplementaryData.find(
      item => item.name === 'PAYEE_NAME_CHECK_COLOUR'
    );
    expect(colourEntry).toBeDefined();
    expect(colourEntry!.value).toBe('Blue');
  });

  it('should not include PAYEE_NAME_CHECK_COLOUR for PayID beneficiary type even if matchedCOPColour is provided', () => {
    const payIdFormData = {
      ...baseAccountFormData,
      beneficiaryType: BENEFICIARY_TYPE.PAYID as const,
      payIdType: 'EMAIL' as any,
      email: 'test@example.com',
      payIdName: 'Test PayID',
    };

    const result = buildBeneficiaryCreateEntitlement(
      payIdFormData,
      'Amber' as any
    );

    const colourEntry = result.supplementaryData.find(
      item => item.name === 'PAYEE_NAME_CHECK_COLOUR'
    );
    expect(colourEntry).toBeUndefined();
  });
});

describe('buildBeneficiaryUpdateEntitlement - matchedCOPColour', () => {
  const baseAccountFormData = {
    beneficiaryNickname: 'Updated Bene',
    beneficiaryType: BENEFICIARY_TYPE.ACCOUNT as const,
    bsb: '654321',
    accountNumber: '87654321',
    accountName: 'Updated Account',
    bankName: 'Updated Bank',
    phone: '',
    email: '',
    abnAcn: '',
    organisationId: '',
  };

  const oldBeneficiary: Beneficiary = {
    id: 'old-id',
    externalId: 'old-ext-id',
    nickname: 'Old Bene',
    currency: 'AUD',
    type: BENEFICIARY_TYPE.ACCOUNT,
    org: 'test-org',
    status: BENEFICIARY_STATUS.ACTIVE,
    account: {
      accountId: {
        BSB: '654321',
        accountNumber: '87654321',
      },
      bankName: 'Old Bank',
      accountName: 'Old Account',
    },
  } as Beneficiary;

  it('should include PAYEE_NAME_CHECK_COLOUR in supplementaryData when matchedCOPColour is provided for ACCOUNT type', () => {
    const result = buildBeneficiaryUpdateEntitlement(
      baseAccountFormData,
      oldBeneficiary,
      'Red' as any
    );

    const colourEntry = result.supplementaryData.find(
      item => item.name === 'PAYEE_NAME_CHECK_COLOUR'
    );
    expect(colourEntry).toEqual({
      name: 'PAYEE_NAME_CHECK_COLOUR',
      value: 'Red',
      datatype: 'STRING',
    });
  });

  it('should not include PAYEE_NAME_CHECK_COLOUR when matchedCOPColour is undefined for ACCOUNT type', () => {
    const result = buildBeneficiaryUpdateEntitlement(
      baseAccountFormData,
      oldBeneficiary
    );

    const colourEntry = result.supplementaryData.find(
      item => item.name === 'PAYEE_NAME_CHECK_COLOUR'
    );
    expect(colourEntry).toBeUndefined();
  });

  it('should include PAYEE_NAME_CHECK_COLOUR with Amber value', () => {
    const result = buildBeneficiaryUpdateEntitlement(
      baseAccountFormData,
      oldBeneficiary,
      'Amber' as any
    );

    const colourEntry = result.supplementaryData.find(
      item => item.name === 'PAYEE_NAME_CHECK_COLOUR'
    );
    expect(colourEntry).toBeDefined();
    expect(colourEntry!.value).toBe('Amber');
  });

  it('should not include PAYEE_NAME_CHECK_COLOUR for PayID beneficiary type even if matchedCOPColour is provided', () => {
    const payIdFormData = {
      ...baseAccountFormData,
      beneficiaryType: BENEFICIARY_TYPE.PAYID as const,
      payIdType: 'EMAIL' as any,
      email: 'test@example.com',
      payIdName: 'Update PayID',
    };

    const oldPayIdBeneficiary: Beneficiary = {
      ...oldBeneficiary,
      type: BENEFICIARY_TYPE.PAYID,
      account: {
        payIDType: 'EMAIL' as any,
        payIDValue: 'old@example.com',
        payIDName: 'Old PayID',
      },
    } as Beneficiary;

    const result = buildBeneficiaryUpdateEntitlement(
      payIdFormData,
      oldPayIdBeneficiary,
      'Red' as any
    );

    const colourEntry = result.supplementaryData.find(
      item => item.name === 'PAYEE_NAME_CHECK_COLOUR'
    );
    expect(colourEntry).toBeUndefined();
  });
});
