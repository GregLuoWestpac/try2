export const genericErrorMessage = 'Something went wrong.';

export const PAGE_NAVIGATION = {
  BENEFICIARY_DETAILS: '/beneficiary/view-beneficiary',
  BENEFICIARY_TASK_DETAILS: '/beneficiary/beneficiary-task-details',
  BENEFICIARY_ACTIVITY_DETAILS: '/beneficiary/beneficiary-activity-details',
  UPDATE_BENEFICIARY: '/beneficiary/update-beneficiary',
  BENEFICIARY_LISTS: '/beneficiary',
  CREATE_BENEFICIARY: '/beneficiary/create-beneficiary',
} as const;

export const INTENT_NAMES = {
  VIEW_BENEFICIARY_DETAILS: 'ViewGalaxyBeneficiaryDetails',
  VIEW_BENEFICIARY_TASK_DETAILS: 'ViewGalaxyBeneficiaryTaskDetails',
  VIEW_BENEFICIARY_ACTIVITY_DETAILS: 'ViewGalaxyBeneficiaryActivityDetails',
  UPDATE_BENEFICIARY: 'UpdateGalaxyBeneficiary',
  BENEFICIARY_LISTS: 'ViewGalaxyBeneficiaries',
  CREATE_BENEFICIARY: 'CreateGalaxyBeneficiary',
} as const;

export const CONTAINERTAB_TITLES = {
  BENEFICIARY_DETAILS: 'Beneficiary details | Westpac One',
  BENEFICIARY_ACTIVITY_DETAILS: 'Beneficiary activity details | Westpac One',
} as const;

export const INTENTS_CONTEXT_NAME = {
  BENEFICIARY: 'fdc3.nothing',
};
// eslint-disable-next-line no-shadow
export enum BENE_STATUS {
  ACTIVE = 'Active',
  ARCHIVED = 'Archived',
}

// eslint-disable-next-line no-shadow
export enum SafiDataType {
  STRING = 'STRING',
  BOOLEAN = 'BOOLEAN',
}

// eslint-disable-next-line no-shadow
export enum PAYID_TYPE {
  PHONE = 'phone',
  EMAIL = 'email',
  ABN_ACN = 'abnAcn',
  ORGANISATION_ID = 'organisationId',
}

// eslint-disable-next-line no-shadow
export enum MFA_CODE {
  MFA_CANCELLED = 'MFA_CANCELLED',
  MFA_LOCKED = 'MFA_LOCKED',
  MFA_ERROR = 'MFA_ERROR',
  INVALID_OTP = 'INVALID_OTP',
}

export const REGEX_PATTERN = {
  DIGIT: /^[\d]+$/,
  ACCOUNT_NUMBER: /^[a-zA-Z0-9.]+$/,
  EMAIL_FORMAT: /^[A-Za-z0-9\-!,:;?_.]+@[A-Za-z0-9\-!,:;?_.]+$/,
  REJECT_COMMENT: /^[a-zA-Z0-9\s\-!,.:\\;?_@]*$/,
};

export const forbiddenCharacterErrorMessage =
  'You cannot use the following special characters';

export const ERROR_MESSAGES = {
  BSB: 'Enter a valid 6-digit BSB.',
  ACCOUNT_NUMBER_REQUIRED: 'Enter an account number.',
  ACCOUNT_NUMBER_INVALID: 'Use only letters, numbers or full stops.',
  ACCOUNT_NAME_REQUIRED: 'Enter an account name up to 140 characters.',
  BENEFICIARY_NICKNAME_REQUIRED:
    'Enter the beneficiary nickname up to 70 characters.',
  BENEFICIARY_TYPE_REQUIRED: 'Select a beneficiary type.',
  BSB_NOT_RECOGNISED: 'BSB is not recognised.',
  BSB_SERVICE_UNAVAILABLE:
    'BSB service is currently not available. Please try again.',
  PAYID_TYPE_REQUIRED: 'Select a PayID type.',
  PHONE: 'Enter a valid phone number.',
  EMAIL_REQUIRED: 'Enter a valid email address.',
  EMAIL_INVALID_FORMAT: 'Enter a valid email address.',
  ABN: 'Enter a valid ABN or ACN number between 9 and 11 digits.',
  ABN_ACN: 'Enter a valid ABN / ACN.',
  ORGANISATION_ID: 'Enter a valid Organisation ID.',
  ORGANISATION_REQUIRED:
    'Enter a valid organisation ID between 2 and 256 characters.',
  PAYID_SERVICE_UNAVAILABLE:
    'PayID service is currently not available. Please try again.',
  INVALID_PAYID:
    'This PayID is not valid. Contact the beneficiary to confirm their payment details.',
  PAYID_CHECK_LIMIT_EXCEEDED:
    'PayID verification cannot be completed. Please try again later.',
  BENEFICIARY_CHANGE_DISCLAIMER:
    'Any changes to beneficiaries will only affect new payments. Payments already created and submitted will not be updated with these changes.',
};

// eslint-disable-next-line no-shadow
export enum BranchStatus {
  OPERATIONAL = 'OPERATIONAL',
  CLOSED = 'CLOSED',
}
// eslint-disable-next-line no-shadow
export enum BranchBrand {
  WBC = 'WBC',
  SGB = 'SGB',
  BOM = 'BOM',
  BSA = 'BSA',
}

export const AUTHBIC8 = 'WPACAU3S';
export const BENEFICIARY_ARCHIVE_ERROR_ACTION =
  'api/expGalaxyBeneficiaryV2/beneficiaryArchive/post/ERROR';
export const BENEFICIARY_CREATE_ERROR_ACTION =
  'api/expGalaxyBeneficiaryV2/beneficiaryCreate/post/ERROR';
export const BENEFICIARY_UPDATE_ERROR_ACTION =
  'api/expGalaxyBeneficiaryV2/beneficiaryUpdate/put/ERROR';
// eslint-disable-next-line no-shadow
export enum CURRENCY {
  AUD = 'AUD',
}

export const INPUT_MAX_LENGTH = {
  BSB: 6,
  ABN_ACN: 11,
  ACCOUNT_NUMBER: 28,
  PHONE: 30,
  BENEFICIARY_NICKNAME: 70,
  ACCOUNT_NAME: 140,
  EMAIL_OR_ORG_ID: 256,
};

export const AuthorisationAction = {
  ForYouToAuthorise: 'For you to authorise',
  TrackAuthorisation: 'Track authorisations',
} as const;

export const AuthorisationStatus = {
  All: 'All',
  PendingAuthorisation: 'Pending authorisation',
  RejectedByAuthoriser: 'Rejected by authoriser',
};

export const AuthorisationTab = {
  ForYouToAuthorise: 'ForYouToAuthorise',
  TrackAuthorisation: 'TrackAuthorisation',
} as const;

export const AuthorisationStatusTab = {
  All: 'All',
  PendingAuthorisation: 'PendingAuthorisation',
  RejectedByAuthoriser: 'RejectedByAuthoriser',
} as const;

export const BeneficiaryTab = {
  BeneficiariesList: 'beneficiaries_List',
  Authorisation: 'authorisation',
};

export const noRowMessage = 'There are no beneficiaries found.';

export const errorMessageListForAuthoriseBenReq = {
  AUTHORISE: 'Unable to authorise beneficiary',
  REJECT: 'Unable to reject beneficiary',
  AUTHORISE_UPDATE: 'Unable to authorise the update to the beneficiary',
  REJECT_UPDATE: 'Unable to reject the update to the beneficiary',
  CONCURRENT_UPDATE: 'Unable to authorise beneficiary',
  CONCURRENT_REJECT: 'Unable to reject beneficiary',
  CONCURRENT_AUTHORISE_UPDATE:
    'Unable to authorise the update to the beneficiary',
  CONCURRENT_REJECT_UPDATE: 'Unable to reject the update to the beneficiary',
  UNREACHABLE: 'Something went wrong. Please try again.',
  ACTION_RESTRICTED:
    'You do not have permisson to authorise or reject the beneficiary',
  ACTION_RESTRICTED_UPDATE:
    'You do not have permisson to authorise or reject the update to the beneficiary',
};
export type UserActionType = 'authorise' | 'reject';

// eslint-disable-next-line no-shadow
export enum ERROR_CODES {
  STEP_UP_REQUIRED = 8200,
  NOT_ENTITLED = 8210,
}

/**
 * Flag indicating whether the organization ID should be retrieved from OpenFin.
 * @default false
 */
export const SearchBeneficiaryInputPlaceholder =
  'Search by beneficiary nickname, account details or account name';
export const W1_ORGANIZATION_SSO = 'w1/organisationSso';

// Beneficiary add messages
export const BENEFICIARY_ADD_EXIST_ERROR_MESSAGE =
  'This beneficiary is already authorised or rejected.';
export const BENEFICIARY_ADD_SERVER_TIMEOUT_ERROR_MESSAGE =
  'Something went wrong.';
export const BENEFICIARY_ADD_CLIENT_TIMEOUT_ERROR_MESSAGE =
  'Something went wrong. Please try again.';
export const BENEFICIARY_ADD_GENERIC_ERROR_MESSAGE =
  'Something went wrong. Please try again later.';
export const BENEFICIARY_ADD_ENTITLEMENT_ERROR_MESSAGE =
  'You do not have permission to authorise or reject beneficiaries. Contact your administrator for more information.';

// Beneficiary status update messages
export const BENEFICIARY_STATUS_UPDATE_TIMEOUT_ERROR_MESSAGE =
  'Something went wrong. Please try again.';
export const BENEFICIARY_STATUS_UPDATE_GENERIC_ERROR_MESSAGE =
  'Something went wrong. Please try again later.';
export const BENEFICIARY_STATUS_UPDATE_UNKNOWN_ERROR_MESSAGE =
  'Something went wrong.';

// Beneficiary update messages
export const BENEFICIARY_UPDATE_SUCCESS_MESSAGE = `The beneficiary \${beneficiaryNickname} has been updated.`;
export const BENEFICIARY_UPDATE_SENT_FOR_AUTHORISATION_MESSAGE = `Updates to the beneficiary \${beneficiaryNickname} have been sent for authorisation.`;
export const BENEFICIARY_UPDATE_TIMEOUT_ERROR_MESSAGE = 'Something went wrong.';
export const BENEFICIARY_UPDATE_GENERIC_ERROR_MESSAGE =
  'Something went wrong. Please try again later.';
export const BENEFICIARY_UPDATE_ENTITLEMENT_ERROR_MESSAGE =
  'You do not have permission to add or update beneficiaries. Contact your administrator for more information.';

// Beneficiary archive messages
export const BENEFICIARY_ARCHIVE_SUCCESS_MESSAGE = `The beneficiary \${beneficiaryNickname} has been archived.`;
export const BENEFICIARY_ARCHIVE_SENT_FOR_AUTHORISATION_MESSAGE = `Archive request for the beneficiary \${beneficiaryNickname} has been sent for authorisation.`;
export const BENEFICIARY_ARCHIVE_TIMEOUT_ERROR_MESSAGE =
  'Something went wrong.';
export const BENEFICIARY_ARCHIVE_GENERIC_ERROR_MESSAGE =
  'Something went wrong. Please try again later.';
export const BENEFICIARY_ARCHIVE_ENTITLEMENT_ERROR_MESSAGE =
  'You do not have permission to archive beneficiaries. Contact your administrator for more information.';

export const INVALID_ERROR_MESSAGE = String.raw`Use only letters, numbers, spaces, or the following special characters  -  !  ,  .  :  \  ;  ?  _  @`;
