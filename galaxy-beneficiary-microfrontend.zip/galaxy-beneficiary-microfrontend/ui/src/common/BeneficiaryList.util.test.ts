import { useClose } from '@mesh-tenant-multiverse-common/react';
import {
  useHandleRedirectToBeneficiaryList,
  useRedirectToBeneficiaryList,
} from './BeneficiaryList.util';
import {
  INTENT_NAMES,
  INTENTS_CONTEXT_NAME,
  PAGE_NAVIGATION,
} from './constants';

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useClose: jest.fn(),
}));

const mockHandleRaiseIntent = jest.fn();

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-utils'),
  useHandleRaiseIntent: () => mockHandleRaiseIntent,
}));

const mockNavigate = jest.fn();

jest.mock('@mep-ui/framework-router-addon', () => {
  const actual = jest.requireActual('@mep-ui/framework-router-addon');
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});

describe('useHandleRedirectToBeneficiaryList', () => {
  it('should call handleRaiseIntent and closeTab with correct parameters', async () => {
    const mockCloseTab = jest.fn();
    (useClose as jest.Mock).mockReturnValue({ closeTab: mockCloseTab });

    const handleRedirect = useHandleRedirectToBeneficiaryList();
    const messageType = 'success';
    const message = 'Beneficiary updated successfully';

    await handleRedirect(messageType, message);

    expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
      intentName: INTENT_NAMES.BENEFICIARY_LISTS,
      data: {
        notificationAlert: {
          type: messageType,
          message,
        },
      },
      intentContextName: INTENTS_CONTEXT_NAME.BENEFICIARY,
      targetPath: PAGE_NAVIGATION.BENEFICIARY_LISTS,
    });
    expect(mockCloseTab).toHaveBeenCalled();
  });
});

describe('useRedirectToBeneficiaryList', () => {
  it('should call useRedirectToBeneficiaryList and redirect user to bene list', async () => {
    const mockCloseTab = jest.fn();
    (useClose as jest.Mock).mockReturnValue({ closeTab: mockCloseTab });

    const handleRedirect = useRedirectToBeneficiaryList();

    await handleRedirect();

    expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
      intentName: INTENT_NAMES.BENEFICIARY_LISTS,
      intentContextName: INTENTS_CONTEXT_NAME.BENEFICIARY,
      targetPath: PAGE_NAVIGATION.BENEFICIARY_LISTS,
    });
    expect(mockCloseTab).toHaveBeenCalled();
  });
});
