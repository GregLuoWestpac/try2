import { PAYID_TYPE } from '../store/types';
import { ErrorResponse } from '../store/types/Common';
import { ERROR_MESSAGES } from './constants';

export const getFriendlyPayIDType = (payIDTypeValue: PAYID_TYPE): string => {
  switch (payIDTypeValue) {
    case PAYID_TYPE.ABN_ACN:
      return 'ABN / ACN';
    case PAYID_TYPE.EMAIL:
      return 'Email';
    case PAYID_TYPE.ORGANISATION_ID:
      return 'Organisation ID';
    case PAYID_TYPE.PHONE:
      return 'Phone number';
    default:
      return 'Unknown';
  }
};

export const getMappedFormFieldNameWithPayIDType = (
  payIDTypeValue: PAYID_TYPE | undefined
): string => {
  switch (payIDTypeValue) {
    case PAYID_TYPE.PHONE:
      return 'phone';
    case PAYID_TYPE.EMAIL:
      return 'email';
    case PAYID_TYPE.ABN_ACN:
      return 'abnAcn';
    case PAYID_TYPE.ORGANISATION_ID:
      return 'organisationId';
    default:
      return 'Unknown';
  }
};
export const validatePayID = (value: string): boolean => {
  const parts = value.split('-');
  if (parts.length < 2 || parts[1].length < 2) {
    return false;
  }
  return true;
};

export const mapPayIdTypeToSafiFormat = (payIdType?: string): string => {
  switch (payIdType) {
    case PAYID_TYPE.PHONE:
      return 'MOBILE';
    case PAYID_TYPE.EMAIL:
      return 'EMAIL';
    case PAYID_TYPE.ABN_ACN:
      return 'ABN';
    case PAYID_TYPE.ORGANISATION_ID:
      return 'FREEFORM';
    // LANDLINE TYPE currently not part of payIDType enum, but if added in future, can map it here after adding the enum value
    default:
      return 'FREEFORM';
  }
};
