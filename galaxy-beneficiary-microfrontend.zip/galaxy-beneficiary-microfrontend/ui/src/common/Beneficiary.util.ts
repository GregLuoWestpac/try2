/* eslint-disable no-use-before-define */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/restrict-template-expressions */
/* eslint-disable no-unsafe-optional-chaining */
/* eslint-disable import/no-unresolved */
import { Badge } from '@westpac/ui';
import {
  DATE_FORMAT_YYYYMMDD,
  getToday,
  getTodayAtLastYear,
} from '@mesh-tenant-multiverse-ui-common/mv-reacthookform';
import { getApproverComments } from '@mesh-tenant-multiverse-ui-common/mv-makerchecker';
import { COP_COLOR_CODE } from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
import {
  APPROVAL_WORKFLOW_AUDIT_EVENT_NAME,
  AUTHORISATION_STATUS,
  AuthorisationSearchFormType,
  AuthorisationStatusOption,
  AuthorisationStatusValues,
  AuthorisationTabOption,
  AuthorisationTabValues,
  Beneficiary,
  BENEFICIARY_STATUS,
  BENEFICIARY_TYPE,
  BeneficiaryBSB,
  BeneficiaryPayID,
  BeneficiaryTaskDetail,
  Entitlement,
  EntitlementSupplementaryDataItem,
  WORKFLOW_STATUS_MAP,
  WORKFLOW_SUBTYPE_MAP,
} from '../store/types';
import { ApprovalWorkflowListing } from '../store/types/ApprovalWorkflowListing';
import {
  ApprovalWorkflow,
  ApprovalWorkflowDetail,
} from '../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types/helper.types';
import {
  getMappedFormFieldNameWithPayIDType,
  mapPayIdTypeToSafiFormat,
} from './PayID.util';
import {
  AuthorisationAction,
  AuthorisationStatus,
  CURRENCY,
  SafiDataType,
} from './constants';
import { FormValues } from '../components/BeneficiaryForm/BeneficiaryForm.types';
import { getPayIDValueFromEditForm } from '../components/BeneficiaryForm/BeneficiaryForm.utils';

type BadgeProps = React.ComponentProps<typeof Badge>;

// Helper functions - defined early to avoid use-before-define
export function mapStatusToWorkflowStatus(value: string): string {
  return WORKFLOW_STATUS_MAP[value as keyof typeof WORKFLOW_STATUS_MAP];
}

export const getFriendlyBeneficiaryStatus = (
  beneficiaryStatusValue: BENEFICIARY_STATUS | AUTHORISATION_STATUS
): {
  text: string;
  badgeColor: BadgeProps['color'];
} => {
  const statusMap: Record<
    BENEFICIARY_STATUS | AUTHORISATION_STATUS,
    { text: string; badgeColor: BadgeProps['color'] }
  > = {
    [BENEFICIARY_STATUS.ACTIVE]: { text: 'Active', badgeColor: 'success' },
    [BENEFICIARY_STATUS.ARCHIVED]: { text: 'Archived', badgeColor: 'primary' },
    [BENEFICIARY_STATUS.ON_HOLD]: { text: 'On hold', badgeColor: 'hero' },
    [BENEFICIARY_STATUS.PENDING_AUTHORISATION]: {
      text: 'Pending authorisation',
      badgeColor: 'info',
    },
    [AUTHORISATION_STATUS.PENDING_AUTHORISATION]: {
      text: mapStatusToWorkflowStatus(
        AUTHORISATION_STATUS.PENDING_AUTHORISATION
      ),
      badgeColor: 'info',
    },
    [AUTHORISATION_STATUS.REJECTED]: {
      text: mapStatusToWorkflowStatus(AUTHORISATION_STATUS.REJECTED),
      badgeColor: 'danger',
    },
  };

  return (
    statusMap[beneficiaryStatusValue] || {
      text: 'Unknown',
      badgeColor: 'neutral',
    }
  );
};

export type ActionItem = {
  name: string;
  cssClasses: string[];
  action: unknown;
};
export const formatAuthorisationStatus = (params: { value: string }) =>
  getFriendlyBeneficiaryStatus(params.value as AUTHORISATION_STATUS).text;

export const getContextKey = (action: string) => (id: string) =>
  `${action}-${id}`;
export const updateBeneficiaryKey = getContextKey('update-beneficiary');
export const viewBeneficiaryKey = getContextKey('view-beneficiary');

/**
 * extract beneficiary details with all possible fields
 */
export const extractBeneficiaryDetails = (workflow: ApprovalWorkflow) => {
  const { subType, payloadObject } = workflow;
  let beneficiary: Beneficiary | null = null;

  switch (subType) {
    case 'addbeneficiary':
      if (
        payloadObject &&
        'beneficiaries' in payloadObject &&
        Array.isArray(payloadObject?.beneficiaries) &&
        payloadObject?.beneficiaries.length > 0
      ) {
        beneficiary = payloadObject?.beneficiaries[0] as Beneficiary;
      }
      break;
    case 'amendbeneficiary':
    case 'archivebeneficiary':
      if (
        payloadObject &&
        'beneficiary' in payloadObject &&
        payloadObject?.beneficiary
      ) {
        beneficiary = payloadObject?.beneficiary as Beneficiary;
      }
      break;
    default:
      beneficiary = null;
  }

  return {
    beneficiaryNickname: beneficiary?.nickname ?? '',
    type: (beneficiary?.type ?? '') as BENEFICIARY_TYPE,
    authorisationRequest: subType ?? '',
    account: {
      // available for bsb account bene
      accountId: {
        BSB: (beneficiary?.account as BeneficiaryBSB)?.accountId?.BSB ?? '',
        accountNumber:
          (beneficiary?.account as BeneficiaryBSB)?.accountId?.accountNumber ??
          '',
      },
      accountName: (beneficiary?.account as BeneficiaryBSB)?.accountName ?? '',
      bankName: (beneficiary?.account as BeneficiaryBSB)?.bankName ?? '',
      // available for payid bene
      payIDValue: (beneficiary?.account as BeneficiaryPayID)?.payIDValue ?? '',
      payIDName: (beneficiary?.account as BeneficiaryPayID)?.payIDName ?? '',
      payIDType: (beneficiary?.account as BeneficiaryPayID)?.payIDType ?? '',
    },
    currency: beneficiary?.currency ?? '',
    divisionName: beneficiary?.divisionName ?? '',
  };
};

export const mapApprovalWorkflowList = (
  approvalWorkflowList: ApprovalWorkflow[]
): ApprovalWorkflowListing[] => {
  if (!Array.isArray(approvalWorkflowList)) return [];

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return approvalWorkflowList.map(workflow => {
    const {
      approvalWorkflowId,
      requestedDateTime,
      subType,
      payloadObject,
      payloadString,
    } = workflow;

    const workflowStatus = workflow?.workflowStatus as AUTHORISATION_STATUS;

    const beneficiaryDetails = payloadObject
      ? extractBeneficiaryDetails(workflow)
      : {
          beneficiaryNickname: '',
          type: '',
          authorisationRequest: '',
          account: {
            accountId: {
              BSB: '',
              accountNumber: '',
            },
            accountName: '',
            bankName: '',
            payIDValue: '',
            payIDName: '',
            payIDType: '',
          },
        };

    return {
      id: approvalWorkflowId ?? '',
      status: workflowStatus ?? '',
      creationDateTime: requestedDateTime ?? '',
      authorisationType: subType ?? '',
      ...beneficiaryDetails,
      payloadString: payloadString ?? '',
    };
  }) as ApprovalWorkflow[];
};

export const getWorkflowAuditDetails = (
  workflow: ApprovalWorkflowDetail,
  eventName: APPROVAL_WORKFLOW_AUDIT_EVENT_NAME
) => {
  const audit = workflow?.approvalWorkflowsAudit?.find(
    a => a.eventName === eventName
  );
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const firstName = String((audit as any)?.actionedBy?.firstName || '');
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const lastName = String((audit as any)?.actionedBy?.lastName || '');

  return {
    ...(audit
      ? {
          actionedBy:
            firstName && lastName
              ? `${firstName} ${lastName}`
              : firstName || lastName || '',
          actionedDateTime: audit.action?.dateTime ?? '',
        }
      : { actionedBy: '', actionedDateTime: '' }),
  };
};

export const transformApprovalWorkflowToBeneficiaryTaskDetail = (
  workflow: ApprovalWorkflowDetail
): BeneficiaryTaskDetail => {
  let beneficiary: Beneficiary | null = null;
  const { subType, payloadObject } = workflow;

  switch (subType) {
    case 'addbeneficiary':
      if (
        payloadObject &&
        'beneficiaries' in payloadObject &&
        payloadObject?.beneficiaries
      ) {
        beneficiary = Array.isArray(payloadObject?.beneficiaries)
          ? (payloadObject?.beneficiaries[0] as Beneficiary)
          : (payloadObject?.beneficiaries as Beneficiary);
      }
      break;
    case 'amendbeneficiary':
    case 'archivebeneficiary':
      if (
        payloadObject &&
        'beneficiary' in payloadObject &&
        payloadObject?.beneficiary
      ) {
        beneficiary = payloadObject?.beneficiary as Beneficiary;
      }
      break;
    default:
      beneficiary = null;
  }

  const sentForAuthWorkflowAuditDetails = getWorkflowAuditDetails(
    workflow,
    APPROVAL_WORKFLOW_AUDIT_EVENT_NAME.SEND_FOR_AUTHORISATION
  );
  const rejectedWorkflowAuditDetails = getWorkflowAuditDetails(
    workflow,
    APPROVAL_WORKFLOW_AUDIT_EVENT_NAME.REJECTED
  );
  const rejectComments = getApproverComments(
    workflow,
    AUTHORISATION_STATUS.REJECTED
  );
  const accountData: BeneficiaryBSB | BeneficiaryPayID =
    beneficiary?.type === BENEFICIARY_TYPE.ACCOUNT
      ? {
          accountId: {
            BSB: beneficiary?.account?.accountId?.BSB ?? '',
            accountNumber: beneficiary?.account?.accountId?.accountNumber ?? '',
          },
          accountName: beneficiary?.account?.accountName ?? '',
          bankName: beneficiary?.account?.bankName ?? '',
        }
      : {
          payIDValue: beneficiary?.account?.payIDValue ?? '',
          payIDName: beneficiary?.account?.payIDName ?? '',
          payIDType: (beneficiary?.account?.payIDType ??
            '') as BeneficiaryPayID['payIDType'], // force type cast with fallback,
        };

  return {
    subType: workflow?.subType ?? '',
    account: accountData,
    id: workflow?.approvalWorkflowId ?? '',
    nickname: beneficiary?.nickname ?? '',
    status: (workflow?.workflowStatus ?? '') as AUTHORISATION_STATUS,
    sentForAuthWorkflowAuditDetails,
    rejectedWorkflowAuditDetails,
    rejectComments,
    beneficiaryId: beneficiary?.id ?? '',
    reference: beneficiary?.reference ?? '',
    currencyAmount: {
      currencyCode: beneficiary?.currencyAmount?.currencyCode ?? '',
      amount: beneficiary?.currencyAmount?.amount ?? '',
    },
    divisionName: beneficiary?.divisionName ?? '',
    matchedCOPStatusCode: beneficiary?.matchedCOPStatusCode,
    matchedCOPAccountName: beneficiary?.matchedCOPAccountName,
  };
};

export const mapSubTypeLabel = (subType?: string) => {
  if (subType === 'addbeneficiary') return 'Add beneficiary';
  if (subType === 'amendbeneficiary') return 'Update beneficiary';
  if (subType === 'archivebeneficiary') return 'Archive beneficiary';
  return subType ?? '';
};

export function mapAuthorisationRequestToWorkflowSubtype(
  value: string
): string {
  return WORKFLOW_SUBTYPE_MAP[value as keyof typeof WORKFLOW_SUBTYPE_MAP];
}

export const authorisationTabOptions: AuthorisationTabOption[] = Object.entries(
  AuthorisationAction
).map(([value, label]) => ({
  value: value as AuthorisationTabValues,
  label: label as string,
}));

export const authorisationStatusOptions: AuthorisationStatusOption[] =
  Object.entries(AuthorisationStatus).map(([value, label]) => ({
    value: value as AuthorisationStatusValues,
    label,
  }));

export const defaultAuthorisationSearchFormData: AuthorisationSearchFormType = {
  authorisationTab: AuthorisationAction.ForYouToAuthorise,
  authorisationStatusTab: AuthorisationStatus.PendingAuthorisation,
  dateRange: {
    startDate: getTodayAtLastYear().toFormat(DATE_FORMAT_YYYYMMDD) ?? '',
    endDate: getToday().toFormat(DATE_FORMAT_YYYYMMDD) ?? '',
  },
};

export type BeneficiaryActivityLogActivityDetail = {
  accountDetail?: string;
  accountName?: string;
  beneficiaryNickname?: string;
  currency?: string;
  amount?: string;
  reference?: string;
};

export type BeneficiaryActivityLogEntryType = {
  date: string;
  user: string;
  activity: string;
  activityStatus: string;
  activityDetail?: BeneficiaryActivityLogActivityDetail;
};

// Utility function to replace placeholders in message templates with actual values
export const interpolateTemplate = (
  template: string,
  values?: Record<string, string>
): string => {
  if (!template) {
    return '';
  }

  if (!values) {
    return template;
  }

  // Replace named placeholders like ${beneficiaryNickname} with actual values
  return Object.entries(values).reduce(
    (result, [key, value]) =>
      result.replace(new RegExp(`\\$\\{${key}\\}`, 'g'), value),
    template
  );
};

const stringDatatype = SafiDataType.STRING;

export const buildBeneficiaryCreateEntitlement = (
  formData: FormValues,
  matchedCOPColour?: COP_COLOR_CODE
): Entitlement => {
  const {
    currency,
    payIdType,
    accountName,
    bsb,
    accountNumber,
    beneficiaryNickname,
    email,
    organisationId,
    phone,
    abnAcn,
    payIdName,
  } = formData;

  const isPayID =
    formData.beneficiaryType === BENEFICIARY_TYPE.PAYID && payIdType;

  const supplementaryData: EntitlementSupplementaryDataItem[] = [
    { name: 'W1_2FADEVICETYPE', value: 'SOFT TOKEN', datatype: stringDatatype },
    { name: 'TENANT', value: 'TREASURY', datatype: stringDatatype },
    {
      name: 'W1C_CURRENCY',
      value: currency || CURRENCY.AUD,
      datatype: stringDatatype,
    },
    {
      name: 'PAYEENICKNAME',
      value: beneficiaryNickname,
      datatype: stringDatatype,
    },
  ];

  if (isPayID) {
    supplementaryData.push(
      ...(payIdType
        ? [
            {
              name: 'PAYEEPAYIDTYPE',
              value: mapPayIdTypeToSafiFormat(payIdType),
              datatype: stringDatatype,
            },
          ]
        : []),
      {
        name: 'PAYEEPAYIDVALUE',
        value:
          getPayIDValueFromEditForm({
            payIdType,
            email,
            organisationId,
            phone,
            abnAcn,
          }) || '',
        datatype: stringDatatype,
      },
      ...(payIdName
        ? [
            {
              name: 'PAYEEPAYIDSHORTNAME',
              value: payIdName,
              datatype: stringDatatype,
            },
          ]
        : [])
    );
  } else {
    const toBSB = bsb;
    const toAccountNumber = accountNumber;
    const payeeDestAccount = `${toBSB} ${toAccountNumber}`;

    supplementaryData.push(
      {
        name: 'PAYEEDESTINATIONACCOUNT',
        value: payeeDestAccount,
        datatype: stringDatatype,
      },
      ...(accountName
        ? [
            {
              name: 'PAYEEACCTNAME',
              value: accountName || '',
              datatype: stringDatatype,
            },
          ]
        : []),
      ...(bsb
        ? [
            {
              name: 'PAYEEPAYIDACCOUNTTYPE',
              value: bsb,
              datatype: stringDatatype,
            },
          ]
        : []),
      ...(matchedCOPColour
        ? [
            {
              name: 'PAYEE_NAME_CHECK_COLOUR',
              value: matchedCOPColour,
              datatype: stringDatatype,
            },
          ]
        : [])
    );
  }

  return { supplementaryData };
};

export const buildBeneficiaryUpdateEntitlement = (
  formData: FormValues,
  oldBeneficiaryDetails: Beneficiary,
  matchedCOPColour?: COP_COLOR_CODE
): Entitlement => {
  const {
    beneficiaryNickname,
    currency,
    payIdType,
    accountName,
    bsb,
    accountNumber,
    payIdName,
  } = formData;

  const isPayID =
    formData.beneficiaryType === BENEFICIARY_TYPE.PAYID && payIdType;

  const supplementaryData: EntitlementSupplementaryDataItem[] = [
    { name: 'W1_2FADEVICETYPE', value: 'SOFT TOKEN', datatype: stringDatatype },
    { name: 'TENANT', value: 'TREASURY', datatype: stringDatatype },
    {
      name: 'W1C_CURRENCY',
      value: currency || CURRENCY.AUD,
      datatype: stringDatatype,
    },
    {
      name: 'PAYEENICKNAME_OLD',
      value: oldBeneficiaryDetails.nickname,
      datatype: stringDatatype,
    },
    {
      name: 'PAYEENICKNAME',
      value: beneficiaryNickname,
      datatype: stringDatatype,
    },
  ];

  if (isPayID) {
    const oldAccount = oldBeneficiaryDetails.account as BeneficiaryPayID;

    supplementaryData.push(
      ...(payIdName
        ? [
            {
              name: 'PAYEEPAYIDSHORTNAME',
              value: payIdName,
              datatype: stringDatatype,
            },
          ]
        : []),
      ...(oldAccount?.payIDType
        ? [
            {
              name: 'PAYEEPAYIDTYPE_OLD',
              value: mapPayIdTypeToSafiFormat(oldAccount.payIDType),
              datatype: stringDatatype,
            },
          ]
        : []),
      ...(oldAccount?.payIDValue
        ? [
            {
              name: 'PAYEEPAYIDVALUE_OLD',
              value: oldAccount.payIDValue,
              datatype: stringDatatype,
            },
          ]
        : [])
    );
  } else {
    const oldAccount = oldBeneficiaryDetails.account as BeneficiaryBSB;
    const toBSB = bsb;
    const toAccountNumber = accountNumber;
    const payeeDestAccount = `${toBSB} ${toAccountNumber}`;

    supplementaryData.push(
      {
        name: 'PAYEEDESTINATIONACCOUNT',
        value: payeeDestAccount,
        datatype: stringDatatype,
      },
      ...(oldAccount?.accountName
        ? [
            {
              name: 'PAYEEACCTNAME_OLD',
              value: oldAccount?.accountName || '',
              datatype: stringDatatype,
            },
          ]
        : []),
      ...(accountName
        ? [
            {
              name: 'PAYEEACCTNAME',
              value: accountName || '',
              datatype: stringDatatype,
            },
          ]
        : []),

      ...(bsb
        ? [
            {
              name: 'PAYEEPAYIDACCOUNTTYPE',
              value: bsb,
              datatype: stringDatatype,
            },
          ]
        : []),
      ...(matchedCOPColour
        ? [
            {
              name: 'PAYEE_NAME_CHECK_COLOUR',
              value: matchedCOPColour,
              datatype: stringDatatype,
            },
          ]
        : [])
    );
  }

  return { supplementaryData };
};
