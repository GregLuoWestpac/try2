import {
  getFriendlyPayIDType,
  validatePayID,
  getMappedFormFieldNameWithPayIDType,
} from './PayID.util';
import { PAYID_TYPE } from '../store/types';
import { ErrorResponse } from '../store/types/Common';

describe('getFriendlyPayIDType', () => {
  it('should return "ABN" for PayIDType.ABN_ACN', () => {
    expect(getFriendlyPayIDType(PAYID_TYPE.ABN_ACN)).toBe('ABN / ACN');
  });

  it('should return "Email" for PayIDType.EMAIL', () => {
    expect(getFriendlyPayIDType(PAYID_TYPE.EMAIL)).toBe('Email');
  });

  it('should return "Organisation ID" for PayIDType.ORGANISATION_ID', () => {
    expect(getFriendlyPayIDType(PAYID_TYPE.ORGANISATION_ID)).toBe(
      'Organisation ID'
    );
  });

  it('should return "Phone number" for PayIDType.PHONE', () => {
    expect(getFriendlyPayIDType(PAYID_TYPE.PHONE)).toBe('Phone number');
  });

  it('should return "Unknown" for an unknown PayIDType', () => {
    expect(getFriendlyPayIDType('UNKNOWN' as PAYID_TYPE)).toBe('Unknown');
  });
});

describe('getMappedFormFieldNameWithPayIDType', () => {
  it('should return "phone" for PAYID_TYPE.PHONE', () => {
    const result = getMappedFormFieldNameWithPayIDType(PAYID_TYPE.PHONE);
    expect(result).toBe('phone');
  });

  it('should return "email" for PAYID_TYPE.EMAIL', () => {
    const result = getMappedFormFieldNameWithPayIDType(PAYID_TYPE.EMAIL);
    expect(result).toBe('email');
  });

  it('should return "abnAcn" for PAYID_TYPE.ABN_ACN', () => {
    const result = getMappedFormFieldNameWithPayIDType(PAYID_TYPE.ABN_ACN);
    expect(result).toBe('abnAcn');
  });

  it('should return "organisationId" for PAYID_TYPE.ORGANISATION_ID', () => {
    const result = getMappedFormFieldNameWithPayIDType(
      PAYID_TYPE.ORGANISATION_ID
    );
    expect(result).toBe('organisationId');
  });

  it('should return "Unknown" for an unknown PAYID_TYPE', () => {
    const result = getMappedFormFieldNameWithPayIDType(
      'UNKNOWN_TYPE' as PAYID_TYPE
    );
    expect(result).toBe('Unknown');
  });
});

describe('validatePayID', () => {
  it('should return true for valid PayID', () => {
    expect(validatePayID('123-456')).toBe(true);
    expect(validatePayID('1-23')).toBe(true);
  });

  it('should return false for invalid PayID with missing parts', () => {
    expect(validatePayID('123')).toBe(false);
    expect(validatePayID('')).toBe(false);
  });

  it('should return false for invalid PayID with insufficient length in the second part', () => {
    expect(validatePayID('123-')).toBe(false);
    expect(validatePayID('123-1')).toBe(false);
  });
});
