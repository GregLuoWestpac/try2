import { useGlobalDispatch } from '@mep-ui/framework';
import { useNavigate } from '@mep-ui/framework-router-addon';
import { useClose } from '@mesh-tenant-multiverse-common/react';
import { useHandleRaiseIntent } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { NotificationMessage } from '../components/NotificationAlert/NotificationAlert';
import {
  INTENT_NAMES,
  INTENTS_CONTEXT_NAME,
  PAGE_NAVIGATION,
} from './constants';

export const useHandleRedirectToBeneficiaryList = () => {
  const handleRaiseIntent = useHandleRaiseIntent(
    useGlobalDispatch,
    useNavigate
  );

  const { closeTab } = useClose();
  return async (messageType: string, message: NotificationMessage) => {
    await handleRaiseIntent({
      intentName: INTENT_NAMES.BENEFICIARY_LISTS,
      data: {
        notificationAlert: {
          type: messageType,
          message,
        },
      },
      intentContextName: INTENTS_CONTEXT_NAME.BENEFICIARY,
      targetPath: PAGE_NAVIGATION.BENEFICIARY_LISTS,
    });
    await closeTab();
  };
};

export const useRedirectToBeneficiaryList = () => {
  const handleRaiseIntent = useHandleRaiseIntent(
    useGlobalDispatch,
    useNavigate
  );

  const { closeTab } = useClose();

  return async () => {
    await handleRaiseIntent({
      intentName: INTENT_NAMES.BENEFICIARY_LISTS,
      intentContextName: INTENTS_CONTEXT_NAME.BENEFICIARY,
      targetPath: PAGE_NAVIGATION.BENEFICIARY_LISTS,
    });
    await closeTab();
  };
};
