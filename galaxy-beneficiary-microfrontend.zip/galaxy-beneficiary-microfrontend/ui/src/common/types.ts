export type CustomerDetails = {
  fullName?: string;
};
