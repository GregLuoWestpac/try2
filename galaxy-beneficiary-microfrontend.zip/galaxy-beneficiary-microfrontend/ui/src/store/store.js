import createSagaMiddleware from 'redux-saga';

import {
  apiClientMiddleware,
  appConfigReducer,
  combineReducers,
  createStore,
} from '@mep-ui/framework';

import { checkEntitlementError } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { rootMFESaga } from './sagas';
// TODO: Once redux-artifacts are generated, uncomment to refer entityReducer
import {
  BENEFICIARY_ARCHIVE_ERROR_ACTION,
  BENEFICIARY_CREATE_ERROR_ACTION,
  BENEFICIARY_UPDATE_ERROR_ACTION,
} from '../common';
import { reducer as galaxyGalaxyEntityReducer } from './generated';

const sagaMiddleware = createSagaMiddleware();

// @ts-ignore:next-line
const checkEntErrorMiddleware = () => next => action => {
  checkEntitlementError(action, [
    BENEFICIARY_ARCHIVE_ERROR_ACTION,
    BENEFICIARY_CREATE_ERROR_ACTION,
    BENEFICIARY_UPDATE_ERROR_ACTION,
  ]); // Redirect to /error - excluding the Error Actions
  return next(action);
};

const middlewares = [
  sagaMiddleware,
  apiClientMiddleware,
  checkEntErrorMiddleware,
];

const store = createStore({
  name: 'galaxy-beneficiary',
  reducer: {
    config: appConfigReducer,
    // capabilities: combineReducers({}),
    // TODO: Once redux-artifacts are generated, uncomment to refer entityReducer
    entities: combineReducers({ ...galaxyGalaxyEntityReducer }),
  },
  middlewares, // any custom middlewares to be added
  initialState: {},
});

sagaMiddleware.run(rootMFESaga);

export default store;
