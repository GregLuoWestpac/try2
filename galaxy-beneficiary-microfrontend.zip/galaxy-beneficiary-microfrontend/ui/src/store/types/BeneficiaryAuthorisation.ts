/* eslint-disable no-shadow */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { DateRange } from '@mesh-tenant-multiverse-ui-common/mv-reacthookform';
import { CoPApiStatusCode } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { BeneficiaryBSB, BeneficiaryPayID, PAYID_TYPE } from './Beneficiary';
import {
  AuthorisationAction,
  AuthorisationStatus,
} from '../../common/constants';

export type BeneficiaryAuthorisation = {
  id: string;
  status: string;
  creationDateTime: string;
  beneficiaryNickname: string;
  accountName: string;
  accountDetails: string;
  type: string;
  authorisationRequest: string;
  account:
    | {
        bsb?: string;
        accountName?: string;
        accountNumber?: string;
      }
    | {
        payIDName?: string;
        payIDType?: PAYID_TYPE;
        payIDValue?: string;
      };
};

// eslint-disable-next-line no-shadow
export enum AUTHORISATION_STATUS {
  PENDING_AUTHORISATION = 'ApprovalPending',
  REJECTED = 'Rejected',
}

export enum APPROVAL_WORKFLOW_AUDIT_EVENT_NAME {
  SEND_FOR_AUTHORISATION = 'ServiceRequestAuthorisationRequested',
  REJECTED = 'ServiceRequestAuthorisationRequestRejected',
}

export const WORKFLOW_TYPE = {
  W1C_BENEFICIARY: 'w1cbeneficiary',
};

export const WORKFLOW_SUBTYPE = {
  ADD_BENEFICIARY: 'addbeneficiary',
  UPDATE_BENEFICIARY: 'amendbeneficiary',
  ARCHIVE_BENEFICIARY: 'archivebeneficiary',
};

/**
 * Mapping of workflow status and subtype to the constants used in the UI.
 * Note: This may not cover all workflow statuses and subtypes, only supported ones.
 */
export const WORKFLOW_STATUS_MAP = {
  ApprovalPending: 'Pending authorisation',
  Rejected: 'Rejected by authoriser',
} as const;

export const WORKFLOW_SUBTYPE_MAP = {
  addbeneficiary: 'Add beneficiary',
  amendbeneficiary: 'Update beneficiary',
  archivebeneficiary: 'Archive beneficiary',
} as const;

export const REQUEST_GROUP = 'Customer';

export const APPLICATION_CHANNEL = 'W1C-Customer';

export const AuthorisationTab = {
  ForYouToAuthorise: 'ForYouToAuthorise',
  TrackAuthorisation: 'TrackAuthorisation',
} as const;

export const AuthorisationStatusTab = {
  All: 'All',
  PendingAuthorisation: 'PendingAuthorisation',
  RejectedByAuthoriser: 'RejectedByAuthoriser',
} as const;

export type WorkflowAuditDetails = {
  actionedBy: string;
  actionedDateTime: string;
};

/**
 * this type is for BeneficiaryTaskDetail UI display only
 * reference: https://1sxdhw.axshare.com/#id=a2z1yh&p=4_2_beneficiary_details&g=1
 * */
export type BeneficiaryTaskDetail = {
  subType: string;
  account: BeneficiaryPayID | BeneficiaryBSB;
  id: string;
  nickname: string;
  status: AUTHORISATION_STATUS;
  sentForAuthWorkflowAuditDetails: WorkflowAuditDetails;
  rejectedWorkflowAuditDetails: WorkflowAuditDetails;
  rejectComments?: string;
  beneficiaryId: string;
  reference: string;
  currencyAmount: {
    currencyCode: string;
    amount: string;
  };
  divisionName?: string;
  matchedCOPStatusCode?: CoPApiStatusCode;
  matchedCOPAccountName?: string;
};

export type AuthorisationTabValues = keyof typeof AuthorisationAction;

export type AuthorisationTabOption = {
  value: AuthorisationTabValues;
  label: string;
};

export type AuthorisationStatusValues = keyof typeof AuthorisationStatus;

export type AuthorisationStatusOption = {
  value: AuthorisationStatusValues;
  label: string;
};
export type AuthorisationSearchFormType = {
  authorisationTab?: AuthorisationTabValues | string;
  authorisationStatusTab?: AuthorisationStatusValues | string;
  dateRange?: DateRange;
};
