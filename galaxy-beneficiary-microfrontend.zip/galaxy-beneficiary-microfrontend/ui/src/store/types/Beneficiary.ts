/* eslint-disable no-shadow */
import { CoPApiStatusCode } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { EntityCollection } from './Common';

export enum PAYID_TYPE {
  PHONE = 'TELI',
  EMAIL = 'EMAL',
  ABN_ACN = 'AUBN',
  ORGANISATION_ID = 'ORGN',
}

export enum BENEFICIARY_STATUS {
  ACTIVE = 'ACTIVE',
  ARCHIVED = 'ARCHIVED',
  PENDING_AUTHORISATION = 'PENDING_AUTHORISATION',
  ON_HOLD = 'ON-HOLD',
}

export enum BENEFICIARY_COSMIC_STATUS {
  ACTIVE = 'ACTIVE',
  ARCHIVED = 'ARCHIVED',
  ON_HOLD = 'ON-HOLD',
}

export enum BENEFICIARY_TYPE {
  ACCOUNT = 'BSB_ACCOUNT_NUMBER',
  PAYID = 'PAYID',
}

export enum CURRENCY {
  AUD = 'AUD',
}

export interface Currency {
  amount: string;
  currencyCode: CURRENCY;
}

export type EntitlementSupplementaryDataItem = {
  name: string;
  value: string;
  datatype: 'STRING' | 'BOOLEAN';
};

export type Entitlement = {
  supplementaryData: EntitlementSupplementaryDataItem[];
};

export interface BeneficiaryCommon {
  id: string;
  externalId: string;
  nickname: string;
  currency?: CURRENCY;
  currencyAmount: Currency;
  reference?: string;
  org: string;
  status: BENEFICIARY_STATUS;
  divisionName?: string;
  matchedCOPStatusCode?: CoPApiStatusCode;
  matchedCOPAccountName?: string;
  entitlementData?: Entitlement;
}
export interface BeneficiaryBSB {
  accountId: {
    BSB: string;
    accountNumber: string;
  };
  bankName: string;
  accountName: string;
}

export interface BeneficiaryPayID {
  payIDName: string;
  payIDType: PAYID_TYPE;
  payIDValue: string;
}

export type Beneficiary =
  | ({
      type: BENEFICIARY_TYPE.ACCOUNT;
      account: BeneficiaryBSB;
    } & BeneficiaryCommon)
  | ({
      type: BENEFICIARY_TYPE.PAYID;
      account: BeneficiaryPayID;
    } & BeneficiaryCommon);

export type BeneficiaryListEntities = EntityCollection<Beneficiary>;

export type BeneficiaryError = {
  status?: number;
  data?: {
    errors: {
      code: number;
      message: string;
      details?: string;
    }[];
  };
};

export type PayIDTypeValue = {
  payIdType: string;
  email: string;
  organisationId: string;
  phone: string;
  abnAcn: string;
};

export type beneficiaryNicknamefromForm = {
  nickname: string;
  fromForm: 'add' | 'update' | 'archive';
};

export type BeneficiaryAuthReqError = {
  status?: number;
  data?: {
    errors: {
      code: number;
      message?: string;
      details?: string;
    }[];
  };
};
