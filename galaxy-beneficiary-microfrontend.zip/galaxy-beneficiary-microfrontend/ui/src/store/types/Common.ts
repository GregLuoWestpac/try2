/* eslint-disable no-use-before-define */
type Error = {
  status: number;
  data: {
    errors: ErrorResponse[];
  };
};

export type EntityCollection<T> = {
  byId: Record<string, T>;
  allIds: string[];
  isFetching?: boolean;
  isError?: boolean;
  error?: Error;
};

export type MetaData = {
  replaceEntities: string[];
};

export type ErrorResponse = {
  code: number;
  /** Error Message */
  message: string;
  /** Detailed information about the error */
  details?: string;
};
