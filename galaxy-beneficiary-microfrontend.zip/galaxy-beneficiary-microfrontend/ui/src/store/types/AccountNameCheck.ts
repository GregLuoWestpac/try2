export type PostAccountNameCheckParamsPayload = {
  params: {
    payee: {
      accountName: string;
      accountId: {
        accountNumber: string;
        BSB: string;
      };
    };
  };
  meta?: {
    replaceEntities?: string[];
  };
};
