export type Division = {
  id: string;
  divisionName: string;
  divisionId: string;
};
