import { AUTHORISATION_STATUS } from './BeneficiaryAuthorisation';

/**
 * formatted approval workflow listing stored in redux, for ui display such as MVTable
 */
export type ApprovalWorkflowListing = {
  id: string;
  status: AUTHORISATION_STATUS;
  creationDateTime: string;
  authorisationType: string;
  beneficiaryNickname: string;
  type: string;
  authorisationRequest: string;
  account: {
    accountId: {
      BSB: string;
      accountNumber: string;
    };
    bankName: string;
    accountName: string;
  };
};
