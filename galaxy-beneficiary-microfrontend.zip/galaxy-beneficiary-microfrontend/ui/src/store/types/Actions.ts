import { CoPApiStatusCode } from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
import { AliasType } from './AliasLookup';
import { Beneficiary, BENEFICIARY_COSMIC_STATUS } from './Beneficiary';
import { MetaData } from './Common';
import { BeneficiaryStatus } from '../../components/BeneficiaryListSearchForm/BeneficiaryListSearchForm.types';
export type PostBeneficiaryDetailsParams = {
  id: string;
};

export type PostBeneficiaryDetailsParamsPayload = {
  params: PostBeneficiaryDetailsParams;
  meta?: MetaData;
};

export type PostBeneficiaryListParamsPayload = {
  meta?: MetaData;
  params?: {
    orgId?: string;
    statuses?: BeneficiaryStatus[];
    searchCriteria?: string;
  };
};
export type GetDivisionListParamsPayload = {
  meta?: MetaData;
};

export type PostBeneficiaryStatusUpdateParams = {
  beneficiary: {
    id: string;
    status: BENEFICIARY_COSMIC_STATUS;
  };
};

export type PostBeneficiaryStatusUpdateParamsPayload = {
  params: PostBeneficiaryStatusUpdateParams;
  meta?: MetaData;
};

export type RequestOptionsPayload = {
  headers: Record<string, string>;
};

export type ArchiveBeneficiaryDetailsParams = {
  beneficiary: Omit<Beneficiary, 'status'>;
};

export type ArchiveBeneficiaryParamsPayload = {
  params: ArchiveBeneficiaryDetailsParams;
  meta?: MetaData;
};

export type GetBSBLookupParamsPayload = {
  BSB: string;
  meta?: MetaData;
};

export type UpdateBeneficiary = Omit<Beneficiary, 'org' | 'status'> & {
  matchedCOPStatusCode?: CoPApiStatusCode;
  matchedCOPAccountName?: string;
};

export type PutBeneficiaryParams = {
  beneficiary: UpdateBeneficiary;
};

export type PutBeneficiaryParamsPayload = {
  params: PutBeneficiaryParams;
  meta?: MetaData;
};
export type PostAliasLookupParams = {
  authBIC8?: string;
  action?: string;
} & {
  [key in AliasType]?: string;
};

export type PostAliaLookupParamsPayload = {
  params: PostAliasLookupParams;
  meta?: MetaData;
};

export type PostBeneficiaryParams = Omit<
  Beneficiary,
  'org' | 'status' | 'externalId'
>;

export type PostBeneficiaryParamsPayload = {
  params: {
    beneficiaries: Array<PostBeneficiaryParams>;
  };
};

export type BeneficiaryOptionsPayload = {
  headers: Record<string, string>;
};
