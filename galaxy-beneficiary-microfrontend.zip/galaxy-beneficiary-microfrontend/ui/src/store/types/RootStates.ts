import { Beneficiary, BeneficiaryListEntities } from './Beneficiary';
import { BsbLookupEntities } from './BsbLookup';
import { EntityCollection } from './Common';
import { AliasLookupEntities } from './AliasLookup';
import type { NotificationAlertState } from '../../components/NotificationAlert/NotificationAlert.type';

export type PostBeneficiaryListState = {
  statusCode?: number;
};

export type GalaxyApiState = {
  api: {
    expGalaxyPaymentV2: {
      beneficiaryList: {
        post: PostBeneficiaryListState;
      };
    };
  };
};

export type RootState = {
  entities: {
    expGalaxyBeneficiaryV2: {
      beneficiaries: EntityCollection<Beneficiary>;
      beneficiaryList: BeneficiaryListEntities;
      bsbLookup: BsbLookupEntities;
      aliasLookup: AliasLookupEntities;
      beneficiaryArchive: EntityCollection<Beneficiary>;
      beneficiaryCreate: EntityCollection<Beneficiary>;
      beneficiaryUpdate: EntityCollection<Beneficiary>;
      beneficiaryStatusUpdate: EntityCollection<Beneficiary>;
    };
  };
  galaxy: GalaxyApiState;
};

export const SearchBy = {
  CreatedBy: 'CreatedBy',
  ApproverAndCreatedOnDateRange: 'ApproverAndCreatedOnDateRange',
} as const;

export type SearchByType = (typeof SearchBy)[keyof typeof SearchBy];

export type SelectedCustomerType = {
  cisKey?: string;
  tenXPartyKey?: string;
  organisationName?: string;
};

export type OrganisationType = {
  orgId: string;
  name: string;
  aliasName: string;
};

export type GlobalState = {
  global?: {
    galaxy?: {
      context?: {
        selectedBeneficiary?: Beneficiary;
        beneficiaryToBeUpdated?: Beneficiary;
        notificationAlert?: NotificationAlertState;
        cisKey?: string;
        approvalWorkflowId?: string;
        selectedBeneficiariesTab?: string;
        searchBy?: SearchByType;
        selectedCustomer?: SelectedCustomerType;
        selectedOrganisation?: OrganisationType;
        orgId?: string;
      };
    };
    instance?: {
      appCorrelationId?: string;
    };
  };
};
