export type ApprovalWorkflowConsent = {
  approvalWorkflowConsent: {
    approvalWorkflowId: string;
    status: string;
    comment?: {
      reason?: string;
      description?: string;
      documentId?: string;
    };
  };
  entitlementsPayload: string;
};
