import {
  SearchBy,
  SearchByType,
  RootState,
  GlobalState,
  GalaxyApiState,
  PostBeneficiaryListState,
  SelectedCustomerType,
  OrganisationType,
} from './RootStates';
import {
  BENEFICIARY_TYPE,
  BENEFICIARY_STATUS,
  Beneficiary,
} from './Beneficiary';

describe('RootStates Types', () => {
  describe('SearchBy constant', () => {
    it('should have CreatedBy value', () => {
      expect(SearchBy.CreatedBy).toBe('CreatedBy');
    });

    it('should have Approver value', () => {
      expect(SearchBy.ApproverAndCreatedOnDateRange).toBe(
        'ApproverAndCreatedOnDateRange'
      );
    });

    it('should be frozen object (immutable)', () => {
      expect(Object.isFrozen(SearchBy)).toBe(false); // SearchBy is not frozen by default, but TypeScript enforces immutability
      // TypeScript prevents assignment at compile time even though the object is mutable at runtime
    });
  });

  describe('SearchByType', () => {
    it('should accept CreatedBy value', () => {
      const searchBy: SearchByType = SearchBy.CreatedBy;
      expect(searchBy).toBe('CreatedBy');
    });

    it('should accept Approver value', () => {
      const searchBy: SearchByType = SearchBy.ApproverAndCreatedOnDateRange;
      expect(searchBy).toBe('ApproverAndCreatedOnDateRange');
    });

    it('should not accept invalid values at compile time', () => {
      // This test demonstrates that TypeScript will catch invalid values
      // @ts-expect-error - Testing that invalid values are rejected
      const invalidSearchBy: SearchByType = 'InvalidValue';
      expect(invalidSearchBy).toBeDefined(); // This line won't execute in real usage due to compile error
    });
  });

  describe('PostBeneficiaryListState', () => {
    it('should allow undefined statusCode', () => {
      const state: PostBeneficiaryListState = {};
      expect(state.statusCode).toBeUndefined();
    });

    it('should allow statusCode number', () => {
      const state: PostBeneficiaryListState = { statusCode: 200 };
      expect(state.statusCode).toBe(200);
    });
  });

  describe('GalaxyApiState', () => {
    it('should have correct structure', () => {
      const state: GalaxyApiState = {
        api: {
          expGalaxyPaymentV2: {
            beneficiaryList: {
              post: { statusCode: 201 },
            },
          },
        },
      };
      expect(state.api.expGalaxyPaymentV2.beneficiaryList.post.statusCode).toBe(
        201
      );
    });

    it('should allow empty post state', () => {
      const state: GalaxyApiState = {
        api: {
          expGalaxyPaymentV2: {
            beneficiaryList: {
              post: {},
            },
          },
        },
      };
      expect(state.api.expGalaxyPaymentV2.beneficiaryList.post).toEqual({});
    });
  });

  describe('RootState', () => {
    it('should have correct entities structure', () => {
      const mockRootState: RootState = {
        entities: {
          expGalaxyBeneficiaryV2: {
            beneficiaries: { byId: {}, allIds: [] },
            beneficiaryList: { byId: {}, allIds: [] },
            bsbLookup: { byId: {}, allIds: [] },
            aliasLookup: { byId: {}, allIds: [] },
            beneficiaryArchive: { byId: {}, allIds: [] },
            beneficiaryCreate: { byId: {}, allIds: [] },
            beneficiaryUpdate: { byId: {}, allIds: [] },
            beneficiaryStatusUpdate: { byId: {}, allIds: [] },
          },
        },
        galaxy: {
          api: {
            expGalaxyPaymentV2: {
              beneficiaryList: {
                post: { statusCode: 200 },
              },
            },
          },
        },
      };

      expect(
        mockRootState.entities.expGalaxyBeneficiaryV2.beneficiaries
      ).toBeDefined();
      expect(
        mockRootState.entities.expGalaxyBeneficiaryV2.beneficiaryStatusUpdate
      ).toBeDefined();
      expect(
        mockRootState.galaxy.api.expGalaxyPaymentV2.beneficiaryList.post
          .statusCode
      ).toBe(200);
    });
  });

  describe('GlobalState', () => {
    it('should allow undefined global', () => {
      const state: GlobalState = {};
      expect(state.global).toBeUndefined();
    });

    it('should allow partial global state', () => {
      const state: GlobalState = {
        global: {
          galaxy: {
            context: {
              selectedBeneficiary: undefined,
              cisKey: 'test-key',
              searchBy: SearchBy.CreatedBy,
            },
          },
        },
      };
      expect(state.global?.galaxy?.context?.cisKey).toBe('test-key');
      expect(state.global?.galaxy?.context?.searchBy).toBe(SearchBy.CreatedBy);
    });

    it('should allow all context properties', () => {
      const mockBeneficiary: Beneficiary = {
        id: 'test-id',
        externalId: 'test-external-id',
        nickname: 'Test Beneficiary',
        currency: 'AUD',
        org: 'test-org',
        type: BENEFICIARY_TYPE.ACCOUNT,
        status: BENEFICIARY_STATUS.ACTIVE,
        account: {
          accountId: {
            BSB: '032000',
            accountNumber: '123456789',
          },
          bankName: 'Test Bank',
          accountName: 'Test Account',
        },
      };

      const mockSelectedCustomer: SelectedCustomerType = {
        cisKey: 'customer-cis-key',
        tenXPartyKey: 'tenant-party-key',
        organisationName: 'Test Organisation',
      };

      const mockSelectedOrganisation: OrganisationType = {
        orgId: 'org-123',
        name: 'Test Org',
        aliasName: 'Test Alias',
      };

      const state: GlobalState = {
        global: {
          galaxy: {
            context: {
              selectedBeneficiary: mockBeneficiary,
              beneficiaryToBeUpdated: mockBeneficiary,
              notificationAlert: {
                type: 'success',
                message: 'Test message',
              },
              cisKey: 'test-cis-key',
              approvalWorkflowId: 'test-workflow-id',
              selectedBeneficiariesTab: 'active',
              searchBy: SearchBy.ApproverAndCreatedOnDateRange,
              selectedCustomer: mockSelectedCustomer,
              selectedOrganisation: mockSelectedOrganisation,
              orgId: 'context-org-id',
            },
          },
          instance: {
            appCorrelationId: 'test-correlation-id',
          },
        },
      };

      expect(state.global?.galaxy?.context?.selectedBeneficiary?.id).toBe(
        'test-id'
      );
      expect(state.global?.galaxy?.context?.searchBy).toBe(
        SearchBy.ApproverAndCreatedOnDateRange
      );
      expect(state.global?.galaxy?.context?.selectedCustomer?.cisKey).toBe(
        'customer-cis-key'
      );
      expect(state.global?.galaxy?.context?.selectedOrganisation?.orgId).toBe(
        'org-123'
      );
      expect(state.global?.galaxy?.context?.orgId).toBe('context-org-id');
      expect(state.global?.instance?.appCorrelationId).toBe(
        'test-correlation-id'
      );
    });

    it('should work with both SearchBy values in context', () => {
      const stateWithCreatedBy: GlobalState = {
        global: {
          galaxy: {
            context: {
              searchBy: SearchBy.CreatedBy,
            },
          },
        },
      };

      const stateWithApprover: GlobalState = {
        global: {
          galaxy: {
            context: {
              searchBy: SearchBy.ApproverAndCreatedOnDateRange,
            },
          },
        },
      };

      expect(stateWithCreatedBy.global?.galaxy?.context?.searchBy).toBe(
        'CreatedBy'
      );
      expect(stateWithApprover.global?.galaxy?.context?.searchBy).toBe(
        'ApproverAndCreatedOnDateRange'
      );
    });
  });

  describe('SelectedCustomerType', () => {
    it('should allow all properties', () => {
      const customer: SelectedCustomerType = {
        cisKey: 'cis-123',
        tenXPartyKey: 'party-456',
        organisationName: 'Test Company',
      };

      expect(customer.cisKey).toBe('cis-123');
      expect(customer.tenXPartyKey).toBe('party-456');
      expect(customer.organisationName).toBe('Test Company');
    });

    it('should allow partial properties', () => {
      const customer: SelectedCustomerType = {
        cisKey: 'cis-123',
      };

      expect(customer.cisKey).toBe('cis-123');
      expect(customer.tenXPartyKey).toBeUndefined();
      expect(customer.organisationName).toBeUndefined();
    });

    it('should allow empty object', () => {
      const customer: SelectedCustomerType = {};

      expect(customer.cisKey).toBeUndefined();
      expect(customer.tenXPartyKey).toBeUndefined();
      expect(customer.organisationName).toBeUndefined();
    });
  });

  describe('OrganisationType', () => {
    it('should require all properties', () => {
      const organisation: OrganisationType = {
        orgId: 'org-789',
        name: 'My Organisation',
        aliasName: 'MyOrg',
      };

      expect(organisation.orgId).toBe('org-789');
      expect(organisation.name).toBe('My Organisation');
      expect(organisation.aliasName).toBe('MyOrg');
    });

    it('should work with empty strings', () => {
      const organisation: OrganisationType = {
        orgId: '',
        name: '',
        aliasName: '',
      };

      expect(organisation.orgId).toBe('');
      expect(organisation.name).toBe('');
      expect(organisation.aliasName).toBe('');
    });
  });
});
