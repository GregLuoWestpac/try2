import { RootState } from '../types';

export const getBeneficiaryStatusUpdateErrors = (state: RootState) =>
  state?.entities?.expGalaxyBeneficiaryV2?.beneficiaryStatusUpdate?.error;
