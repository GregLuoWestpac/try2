import { RootState } from '../types';

export const getAddBeneficiaryErrors = (state: RootState) => {
  return state?.entities?.expGalaxyBeneficiaryV2?.beneficiaryCreate?.error;
};
