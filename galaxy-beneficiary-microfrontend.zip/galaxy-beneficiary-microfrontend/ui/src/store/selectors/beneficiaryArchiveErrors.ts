import { RootState } from '../types';

export const getBeneficiaryArchiveErrors = (state: RootState) => {
  return state?.entities?.expGalaxyBeneficiaryV2?.beneficiaryArchive?.error;
};
