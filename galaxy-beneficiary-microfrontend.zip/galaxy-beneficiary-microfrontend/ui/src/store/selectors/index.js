import { createSelector } from '@mep-ui/framework';
import get from 'lodash/get';

export const getMFEs = state => get(state, `microfrontends`, {});

export const getMFESlice = createSelector([getMFEs], mfes =>
  get(mfes, 'beneficiary', {})
);

export { getAddBeneficiaryErrors } from './beneficiaryAddErrors.ts';
export { getBeneficiaryArchiveErrors } from './beneficiaryArchiveErrors.ts';
export { getBeneficiaryUpdateErrors } from './beneficiaryUpdateErrors.ts';
export { getBeneficiaryStatusUpdateErrors } from './beneficiaryStatusUpdateErrors.ts';
export {
  isCopLimitExceededSelector,
  isCopServiceNotAvailableSelector,
} from './accountNameCheck.ts';
