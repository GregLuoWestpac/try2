/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { createSelector } from '@mep-ui/framework';
import { isAliasLookupError } from '../generated';
import { RootState } from '../types';

export const getPostLookupStatusCode = (state: RootState) =>
  state?.entities?.expGalaxyBeneficiaryV2?.aliasLookup?.error?.status;
export const getPostLookupErrorCode = (state: RootState) =>
  state?.entities?.expGalaxyBeneficiaryV2?.aliasLookup?.error?.data?.errors?.[0]
    ?.code;

export const doesAliasIdContainInvalidDataSelector = createSelector(
  [getPostLookupStatusCode, getPostLookupErrorCode],
  (statusCode: number, errorCode: number) =>
    statusCode === 400 && errorCode === 2
);

export const isPayIdNotValidSelector = createSelector(
  [getPostLookupStatusCode, getPostLookupErrorCode],
  (statusCode: number, errorCode: number) =>
    statusCode === 400 &&
    (errorCode === 2001 || errorCode === 2002 || errorCode === 2003)
);

export const isPayIdLimitExceededSelector = createSelector(
  [getPostLookupStatusCode, getPostLookupErrorCode],
  (statusCode: number, errorCode: number) =>
    statusCode === 400 && errorCode === 2000
);

export const isPayIdServiceNotAvailableSelector = createSelector(
  [getPostLookupStatusCode, getPostLookupErrorCode, isAliasLookupError],
  (statusCode: number, errorCode: number, isLookupError: boolean) =>
    (statusCode === 400 &&
      errorCode !== 2 &&
      errorCode !== 2000 &&
      errorCode !== 2001 &&
      errorCode !== 2002 &&
      errorCode !== 2003) ||
    (statusCode >= 401 && statusCode <= 499) ||
    (statusCode >= 500 && statusCode <= 599) ||
    (statusCode == null && isLookupError)
);
