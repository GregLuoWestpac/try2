import { RootState } from '../types';

export const getBeneficiaryUpdateErrors = (state: RootState) => {
  return state?.entities?.expGalaxyBeneficiaryV2?.beneficiaryUpdate?.error;
};
