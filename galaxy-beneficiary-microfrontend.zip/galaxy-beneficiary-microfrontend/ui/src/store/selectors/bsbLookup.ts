/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { createSelector } from '@mep-ui/framework';
import { RootState } from '../types';

export const getBsbLookupStatusCode = (state: RootState) => state?.entities?.expGalaxyBeneficiaryV2?.bsbLookup?.error?.status;

export const isBsbLookupUnavailableError = createSelector(
  [getBsbLookupStatusCode],
  (statusCode: number) => statusCode === 500,
);
export const isBsbLookupNotFoundError = createSelector(
  [getBsbLookupStatusCode],
  (statusCode: number) => statusCode === 400,
);
