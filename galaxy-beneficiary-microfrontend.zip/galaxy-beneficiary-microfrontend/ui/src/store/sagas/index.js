import { all } from 'redux-saga/effects';
import { watchAppConfig } from '@mep-ui/framework';

// TODO: Once redux artifacts are generated, uncomment to watch entity actions
import { rootExportSaga as galaxyGalaxySagas } from '../generated';

export function* rootMFESaga() {
  yield all([watchAppConfig(), galaxyGalaxySagas()]);
}
