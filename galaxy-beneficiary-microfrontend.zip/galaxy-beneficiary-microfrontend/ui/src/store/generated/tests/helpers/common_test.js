const {
  updateTemplate,
  buildApiEndpoint,
  formatData,
  getDisplayName,
  getParentsByEntityId,
  getRootParentsByEntityId,
} = require('../../src/helpers/common');

test('formatData', () => {
  const data = formatData({
    entities: {
      users: [{ id: 123 }, { id: 124 }],
    },
  });
  expect(data).toEqual({
    entities: {
      users: {
        allIds: [123, 124],
        byId: { 123: { id: 123 }, 124: { id: 124 } },
      },
    },
  });
});
