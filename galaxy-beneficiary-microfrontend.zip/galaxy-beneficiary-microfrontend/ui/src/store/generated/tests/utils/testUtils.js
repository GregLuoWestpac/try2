import { runSaga } from 'redux-saga';

export async function recordSaga(saga, initialAction, testState) {
  const dispatched = [];

  await runSaga(
    {
      dispatch: action => dispatched.push(action),
      getState: () => testState,
    },
    saga,
    initialAction
  ).done;

  return dispatched;
}
