import { postAliasLookupData } from '../../src/sagas/aliasLookup.saga';
import { recordSaga } from '../utils/testUtils';

jest.mock('../../src/helpers/common', () => ({
  buildApiEndpoint: () => 'http://test.com',
  formatData: d => d,
  handleError: e => e,
  updateTemplate: u => u,
  getDisplayName: n => n,
  getParentsByEntityId: p => p,
  api_get: () =>
    -new Promise((resolve, reject) => {
      resolve({
        data: 'ok',
        status: 'ok',
      });
    }),
  api_post: () =>
    -new Promise((resolve, reject) => {
      resolve({
        status: 204,
      });
    }),
  api_put: () =>
    -new Promise((resolve, reject) => {
      resolve({
        status: 204,
      });
    }),
  api_patch: () =>
    -new Promise((resolve, reject) => {
      resolve({
        status: 204,
      });
    }),
  api_delete: () =>
    -new Promise((resolve, reject) => {
      resolve({
        status: 204,
      });
    }),
}));

describe('postaliasLookup saga', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  const state = {
    config: {
      api: {
        baseUrl: {
          'exp-galaxy-beneficiary-v2': 'https://gw.test.com',
        },
        basePath: {
          'exp-galaxy-beneficiary-v2': '/exp/test/core/v1/',
        },
      },
    },
  };

  it('should dispatch error action if url is incorrect', async () => {
    const initialAction = { payload: { params: 'submissionId=SUB123' } };
    const dispatched = await recordSaga(postAliasLookupData, initialAction);
    const expected = { type: 'api/aliasLookup/post/ERROR' };
    expect(dispatched[0]).toMatchObject(expected);
  });

  it('should dispatch recieve action alone for a valid api call with NONE refresh', async () => {
    const initialAction = {
      payload: {},
      meta: { refreshMethod: 'NONE' },
    };
    const dispatched = await recordSaga(
      postAliasLookupData,
      initialAction,
      state
    );
    const expected = { type: 'api/aliasLookup/post/RECEIVE' };
    expect(dispatched[0]).toMatchObject(expected);
  });

  it('should dispatch recieve action and get call for a valid api call by default', async () => {
    const initialAction = {
      payload: {},
    };
    const dispatched = await recordSaga(
      postAliasLookupData,
      initialAction,
      state
    );
    const expected = { type: 'api/aliasLookup/post/RECEIVE' };
    expect(dispatched[0]).toMatchObject(expected);
    // mock the actions to assert this in a better way to find the get actions
    if (dispatched.length > 1) {
      const refreshAction = { type: 'api/aliasLookup/get/REQUEST' };
      expect(dispatched[1]).toMatchObject(refreshAction);
    }
  });
});
