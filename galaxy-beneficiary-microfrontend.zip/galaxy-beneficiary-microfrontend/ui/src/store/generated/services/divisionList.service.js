import { apiClient } from '@mep-ui/framework';
import { handleError, updateTemplate } from './utils';

/**
 * getDivisionList - The endpoint will query PDP to retrieve the divisions based on OrgCISKey and logged in user&#39;s CISKey
 *
 * @param {string} url - Request url including apiBaseUrl and apiBasePath
 *
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *  `path` -   request path parameters
 *
 *  `query` -  request query parameters
 *
 * @param {Object} options - Optional configuration for the request
 *
 *  `xBrandIdOverride` - optional brand ID to override the default brand ID
 *
 * @return {Promise} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
export function getDivisionList(url, params, options) {
  let urlWithBasePath = url;
  const resourcePath = 'divisionList';
  const { path = {}, query } = params || {};
  const { headers: customHeaders = {}, withCredentials = false } =
    options || {};

  const apiConfig = {
    params: query,
    options,
    withCredentials,
    headers: customHeaders,
  };

  const resourcePathUrl = updateTemplate(
    `${urlWithBasePath}${resourcePath}`,
    path
  );

  return apiClient.get(resourcePathUrl, apiConfig).catch(handleError);
}
