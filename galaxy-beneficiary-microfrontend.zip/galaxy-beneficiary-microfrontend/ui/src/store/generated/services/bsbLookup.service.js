import { apiClient } from '@mep-ui/framework';
import { handleError, updateTemplate } from './utils';

/**
 * getBsbLookup - This endpoint allows to lookup a BSB
 *
 * @param {string} url - Request url including apiBaseUrl and apiBasePath
 *
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *  `path` -   request path parameters
 *
 *  `query` -  request query parameters
 *
 * @param {Object} options - Optional configuration for the request
 *
 *  `xBrandIdOverride` - optional brand ID to override the default brand ID
 *
 * @return {Promise} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
export function getBsbLookup(url, params, options) {
  let urlWithBasePath = url;
  const resourcePath = 'bsbLookup';
  const { path = {}, query } = params || {};
  const { headers: customHeaders = {}, withCredentials = false } =
    options || {};

  const apiConfig = {
    params: query,
    options,
    withCredentials,
    headers: customHeaders,
  };

  const resourcePathUrl = updateTemplate(
    `${urlWithBasePath}${resourcePath}`,
    path
  );

  return apiClient.get(resourcePathUrl, apiConfig).catch(handleError);
}
