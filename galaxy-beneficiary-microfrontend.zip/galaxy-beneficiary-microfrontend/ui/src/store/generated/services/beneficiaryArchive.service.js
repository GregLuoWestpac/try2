import { apiClient } from '@mep-ui/framework';
import { handleError, updateTemplate } from './utils';

/**
 * archiveBeneficiaries - Archiving beneficiaries using the id
 *
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *  `path` -   request path parameters
 *
 *  `query` -  request query parameters
 *
 *  `body` -   request body
 *
 * @param {Object} options - Optional configuration for the request
 *
 *  `xBrandIdOverride` - optional brand ID to override the default brand ID
 *
 * @return {Promise} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
export function archiveBeneficiaries(url, params, options) {
  let urlWithBasePath = url;
  const resourcePath = 'beneficiaryArchive';
  const { path = {}, body, query } = params || {};
  const { headers: customHeaders = {}, withCredentials = false } =
    options || {};

  const apiConfig = {
    params: query,
    options,
    withCredentials,
    headers: customHeaders,
  };

  const resourcePathUrl = updateTemplate(
    `${urlWithBasePath}${resourcePath}`,
    path
  );

  return apiClient.post(resourcePathUrl, body, apiConfig).catch(handleError);
}
