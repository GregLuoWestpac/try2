export const handleError = error => {
  if (error.response) {
    // The request was made and the server responded with a status code
    // that falls out of the range of 2xx
    const {
      data: { errors: rootErrors, result: { errors: nestedErrors } = {} } = {},
    } = error.response;
    // Preferred structure for errors is within result, the flattened strcuture is deprecatred.
    const errors = nestedErrors || rootErrors || [];
    throw { ...error.response, data: { errors } };
  } else if (error.request) {
    // The request was made but no response was received
    // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
    // http.ClientRequest in node.js
    throw { request: error.request, message: error.message };
  } else {
    // Something happened in setting up the request that triggered an Error
    throw { error };
  }
};

// Utility provisioned for path parameter replacement in the URL
export const updateTemplate = (templateString, parameters) => {
  const params = parameters || {};

  return templateString.replace(
    /{\s*([^}]*)\s*}/g,
    (match, $1) => params[$1.trim()]
  );
};
