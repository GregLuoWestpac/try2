import { logger, configureLogger, ConsoleTransport } from '@mep-ui/framework';

configureLogger({
  appId: 'redux-artifact-nativejs-bridge',
  transport: ConsoleTransport,
});

const scriptLoadError = (promise = false) => {
  logger.error('NativeJSBridge :: Error loading nativeJs script');
  if (promise) {
    const error = new Error('NativeJsBridge :: Error loading nativeJs script');
    return Promise.reject(error);
  }
  return false;
};

/**
 * Identifies if the nativejs-bridge library is loaded.
 *
 */
const isNativeJsBridgeLoaded = () =>
  typeof window.NativeJSInterface !== 'undefined' && window.NativeJSInterface;

/**
 * Check if this web page is running in a native container
 * @returns boolean
 */
export const isNativeContainer = () => {
  if (!isNativeJsBridgeLoaded()) {
    return scriptLoadError();
  }
  return window.NativeJSInterface.isNativeContainer();
};

/**
 * Provides the app version
 * throws error if NativeJsBridge is not loaded
 */
export const getAppVersion = () => {
  if (!isNativeJsBridgeLoaded()) {
    return scriptLoadError();
  }
  return window.NativeJSInterface.getAppVersion();
};

/**
 * Fetch data for the feature of type defined
 * Creates a promise object which checks the feature status and based on the result the app will trigger the data fetch
 * A failure means we can't retrieve feature data for the app of the type specified
 * @param {String} featureType - Eg.RSA
 * @param {Object} inputData - Optional
 * @returns {Promise} promise
 */
export const fetchDataForFeature = (featureType, inputData) => {
  if (!isNativeJsBridgeLoaded()) {
    return scriptLoadError(true);
  }
  return window.NativeJSInterface.fetchDataForFeature(featureType, inputData);
};

const processStatusCode = (statusCode, feature) => {
  if (statusCode !== E_NOERR) {
    logger.error(
      `NativeJSBridge :: feature: ${feature} not supported and failed with statusCode: ${statusCode}`
    );
  }
  return statusCode === E_NOERR;
};

/**
 * * Transfers a raw data payload from the website to the app
 * If the function is supported, the pdf document will be displayed in the native app
 * @param {*} data base64 encoded pdf data
 * @param {*} filename name of the file to be saved
 * @param {*} mimeType currently only requires to support application/pdf although this may expand in the future
 * @returns boolean E_NOTSUPPORTED (1000) if the function is not available
 */
export const displayDataAsDocument = (data, filename, mimeType) => {
  if (!isNativeJsBridgeLoaded()) {
    return scriptLoadError(true);
  }
  const statusCode = window.NativeJSInterface.displayDataAsDocument(
    data,
    filename,
    mimeType
  );

  return processStatusCode(statusCode, 'displayDataAsDocument');
};
