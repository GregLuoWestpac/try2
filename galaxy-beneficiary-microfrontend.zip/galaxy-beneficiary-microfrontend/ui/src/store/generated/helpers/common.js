import { apiClient, getXBrandIdOverridden } from '@mep-ui/framework';

const handleError = error => {
  if (error.response) {
    // The request was made and the server responded with a status code
    // that falls out of the range of 2xx
    const {
      data: { errors: rootErrors, result: { errors: nestedErrors } = {} } = {},
    } = error.response;
    // Preferred structure for errors is within result, the flattened strcuture is deprecatred.
    const errors = nestedErrors || rootErrors || [];
    throw { ...error.response, data: { errors } };
  } else if (error.request) {
    // The request was made but no response was received
    // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
    // http.ClientRequest in node.js
    throw { request: error.request, message: error.message };
  } else {
    // Something happened in setting up the request that triggered an Error
    throw { error };
  }
};

export const api_get = (url, apiConfig) =>
  apiClient.get(url, apiConfig).catch(handleError);

export const api_post = (
  url,
  data,
  query,
  withCredentials,
  responseTypeObj,
  options,
  headers
) =>
  apiClient
    .post(url, data, {
      params: query,
      withCredentials,
      ...responseTypeObj,
      options,
      headers,
    })
    .catch(handleError);

export const api_put = (
  url,
  data,
  query,
  withCredentials,
  responseTypeObj,
  options,
  headers
) =>
  apiClient
    .put(url, data, { params: query, withCredentials, options, headers })
    .catch(handleError);

export const api_patch = (
  url,
  data,
  query,
  withCredentials,
  responseTypeObj,
  options,
  headers
) =>
  apiClient
    .patch(url, data, { params: query, withCredentials, options, headers })
    .catch(handleError);

export const api_delete = (url, query, withCredentials, options, headers) =>
  apiClient
    .delete(url, { params: query, withCredentials, options, headers })
    .catch(handleError);

export const isBrandIdOverridden = getXBrandIdOverridden;

// Utility provisioned for path parameter replacement in the URL
export const updateTemplate = (templateString, parameters) => {
  const params = parameters || {};

  return templateString.replace(
    /{\s*([^}]*)\s*}/g,
    (match, $1) => params[$1.trim()]
  );
};

export const buildApiEndpoint = (
  baseUrl,
  basePath,
  resourcePath,
  pathParams = null
) => {
  const url = `${baseUrl}${basePath}${resourcePath}`;
  return pathParams ? updateTemplate(url, pathParams) : url;
};

// Utility used to format the data in the desired shape
// to be populated in the redux store
export const formatData = data => {
  if (data && data.entities) {
    const entities = Object.entries(data.entities).reduce(
      (acc, [name, entity]) => {
        if (Array.isArray(entity)) {
          const allIds = [];
          const byId = {};

          entity.forEach(entry => {
            allIds.push(entry.id);
            byId[entry.id] = entry;
          });

          const entitySlice = {
            [name]: {
              byId,
              allIds,
            },
          };

          return { ...acc, ...entitySlice };
        }

        return acc;
      },
      {}
    );

    return {
      ...data,
      entities,
    };
  }

  return data;
};

export const getDisplayName = WrappedComponent =>
  WrappedComponent.displayName || WrappedComponent.name || 'Component';

// For each field in the parent object, check if the ids include any impacted child id
const IsParentRecordImpacted = (parentObj, fields, impactedChildIds) =>
  fields.some(
    field =>
      parentObj[field] &&
      impactedChildIds.some(impactedId => parentObj[field].includes(impactedId))
  );

// We don't support recursive inner loop as MVP
export const getParentsByEntityId = (entities, entityIdObjs, entityMap) => {
  const parentId = [];
  const impactedEntities = [];

  entityIdObjs.forEach(eId => {
    const currentEntityName = eId.entityName;

    if (entityMap[currentEntityName]) {
      const currentEntityMap = entityMap[currentEntityName];
      const parentEntitieNames = Object.keys(currentEntityMap);

      parentEntitieNames.forEach(n => {
        const parentFieldsToCurrentEntity = currentEntityMap[n];
        const e = entities[n];

        e.allIds.forEach(pId => {
          if (
            IsParentRecordImpacted(
              e.byId[pId],
              parentFieldsToCurrentEntity,
              eId.id
            )
          ) {
            parentId.push(pId);
          }
        });
        impactedEntities.push({ entityName: n, id: parentId });
      });
    } else {
      impactedEntities.push(entityIdObjs);
    }
  });

  return impactedEntities;
};

const shouldFindKeepFindParent = (entityIdObjs, entityMap) =>
  entityIdObjs.map(e => e.entityName).some(n => entityMap[n] !== undefined);

export const getRootParentsByEntityId = (entities, entityIdObjs, entityMap) => {
  let impactedEntities = entityIdObjs;

  while (shouldFindKeepFindParent(impactedEntities, entityMap)) {
    impactedEntities = getParentsByEntityId(entities, entityIdObjs, entityMap);
  }

  return impactedEntities;
};

export const convertBlobToJSON = blobInput => {
  const fileReader = new FileReader();

  const blobToJSONError = reject => {
    fileReader.abort();
    reject('An error occurred while converting blob to json');
  };

  return new Promise((resolve, reject) => {
    fileReader.onerror = () => {
      blobToJSONError(reject);
    };

    fileReader.onload = () => {
      const fileReaderResult = fileReader.result || '{}';
      try {
        resolve(JSON.parse(fileReaderResult));
      } catch (e) {
        blobToJSONError(reject);
      }
    };

    fileReader.readAsText(blobInput);
  });
};

export const arrayBufferToBase64 = buffer => {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const byteLength = bytes.byteLength;
  for (var i = 0; i < byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
};
