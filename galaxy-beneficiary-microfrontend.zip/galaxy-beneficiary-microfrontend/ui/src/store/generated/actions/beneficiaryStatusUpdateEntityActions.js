import { createActions } from 'redux-actions';

export const beneficiaryStatusUpdateEntityActions = createActions({
  api: {
    expGalaxyBeneficiaryV2: {
      beneficiaryStatusUpdate: {
        clear: {
          REQUEST: () => ({}),
          error: {
            REQUEST: () => ({}),
          },
        },
      },
    },
  },
  galaxyBeneficiary: {
    beneficiaryStatusUpdate: {
      clear: {
        REQUEST: () => ({}),
        error: {
          REQUEST: () => ({}),
        },
      },
    },
  },
});
