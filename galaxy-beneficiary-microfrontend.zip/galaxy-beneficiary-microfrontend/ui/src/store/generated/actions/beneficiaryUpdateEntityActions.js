import { createActions } from 'redux-actions';

export const beneficiaryUpdateEntityActions = createActions({
  api: {
    expGalaxyBeneficiaryV2: {
      beneficiaryUpdate: {
        clear: {
          REQUEST: () => ({}),
          error: {
            REQUEST: () => ({}),
          },
        },
      },
    },
  },
  galaxyBeneficiary: {
    beneficiaryUpdate: {
      clear: {
        REQUEST: () => ({}),
        error: {
          REQUEST: () => ({}),
        },
      },
    },
  },
});
