import { createActions } from 'redux-actions';

export const bsbLookupEntityActions = createActions({
  api: {
    expGalaxyBeneficiaryV2: {
      bsbLookup: {
        clear: {
          REQUEST: () => ({}),
          error: {
            REQUEST: () => ({}),
          },
        },
      },
    },
  },
  galaxyBeneficiary: {
    bsbLookup: {
      clear: {
        REQUEST: () => ({}),
        error: {
          REQUEST: () => ({}),
        },
      },
    },
  },
});
