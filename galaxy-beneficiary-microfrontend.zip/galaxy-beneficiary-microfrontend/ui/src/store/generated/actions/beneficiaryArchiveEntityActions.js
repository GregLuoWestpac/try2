import { createActions } from 'redux-actions';

export const beneficiaryArchiveEntityActions = createActions({
  api: {
    expGalaxyBeneficiaryV2: {
      beneficiaryArchive: {
        clear: {
          REQUEST: () => ({}),
          error: {
            REQUEST: () => ({}),
          },
        },
      },
    },
  },
  galaxyBeneficiary: {
    beneficiaryArchive: {
      clear: {
        REQUEST: () => ({}),
        error: {
          REQUEST: () => ({}),
        },
      },
    },
  },
});
