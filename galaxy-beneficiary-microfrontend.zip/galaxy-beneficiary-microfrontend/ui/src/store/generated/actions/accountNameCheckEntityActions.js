import { createActions } from 'redux-actions';

export const accountNameCheckEntityActions = createActions({
  api: {
    expGalaxyBeneficiaryV2: {
      accountNameCheck: {
        clear: {
          REQUEST: () => ({}),
          error: {
            REQUEST: () => ({}),
          },
        },
      },
    },
  },
  galaxyBeneficiary: {
    accountNameCheck: {
      clear: {
        REQUEST: () => ({}),
        error: {
          REQUEST: () => ({}),
        },
      },
    },
  },
});
