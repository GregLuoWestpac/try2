import { get } from 'lodash';
import { createActions } from 'redux-actions';

export const beneficiaryStatusUpdateActions = createActions({
  api: {
    expGalaxyBeneficiaryV2: {
      beneficiaryStatusUpdate: {
        post: {
          REQUEST: [
            // payload creator
            (postBeneficiaryStatusUpdateParams, options) => {
              const { pathParams, params, query } =
                postBeneficiaryStatusUpdateParams;
              return { options, pathParams, params, query };
            },

            // meta creator
            (postBeneficiaryStatusUpdateParams, options) => {
              const { meta } = postBeneficiaryStatusUpdateParams;
              return meta;
            },
          ],
          RECEIVE: [
            // payload creator
            data => ({ ...data }),

            // meta creator
            (data, statusCode, resource, metadata = {}) => {
              // Ensure data has values we need:
              const result = get(data, 'result', null);
              const entities = get(data, 'entities', null);

              // We deliberately keep these as arrays so we can consistently
              // use Array.includes for existence checks:

              // Primary is whatever we request/have a result key for
              const primary = result ? Object.keys(result) : [];

              // Secondaries are all other entity types we have been sent data for (payload.entities) but
              // do not have an explicit result key for
              const secondary = entities
                ? Object.keys(entities).filter(item => !primary.includes(item))
                : [];

              // TODO: What is this metadata and what is the use case for having it?
              // Is there something better than customData that it can be called?
              return {
                resource,
                statusCode,
                // Following meta will be come meta: {meta}, because we are returning under meta creator
                meta: metadata,
                entities: {
                  primary,
                  secondary,
                },
              };
            },
          ],
          ERROR: [
            error => ({ error }),
            (err, metadata) => ({
              meta: metadata,
              entity: 'beneficiaryStatusUpdate',
            }),
          ],
        },
      },
    },
  },

  galaxyBeneficiary: {
    updateBeneficiaryStatus: {
      REQUEST: [
        // payload creator
        (updateBeneficiaryStatusParams, options) => {
          const { pathParams, params, query } = updateBeneficiaryStatusParams;
          return { options, pathParams, params, query };
        },

        // meta creator
        (updateBeneficiaryStatusParams, options) => {
          const { meta } = updateBeneficiaryStatusParams;
          return meta;
        },
      ],
      RECEIVE: [
        // payload creator
        data => ({ ...data }),

        // meta creator
        (data, statusCode, resource, metadata = {}) => {
          // Ensure data has values we need:
          const result = get(data, 'result', null);
          const entities = get(data, 'entities', null);

          // We deliberately keep these as arrays so we can consistently
          // use Array.includes for existence checks:

          // Primary is whatever we request/have a result key for
          const primary = result ? Object.keys(result) : [];

          // Secondaries are all other entity types we have been sent data for (payload.entities) but
          // do not have an explicit result key for
          const secondary = entities
            ? Object.keys(entities).filter(item => !primary.includes(item))
            : [];

          // TODO: What is this metadata and what is the use case for having it?
          // Is there something better than customData that it can be called?
          return {
            resource,
            statusCode,
            // Following meta will be come meta: {meta}, because we are returning under meta creator
            meta: metadata,
            entities: {
              primary,
              secondary,
            },
          };
        },
      ],
      ERROR: [
        error => ({ error }),
        (err, metadata) => ({
          meta: metadata,
          entity: 'beneficiaryStatusUpdate',
        }),
      ],
    },
  },
});
