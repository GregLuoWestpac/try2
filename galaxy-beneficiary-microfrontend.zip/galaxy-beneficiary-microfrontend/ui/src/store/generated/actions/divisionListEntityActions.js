import { createActions } from 'redux-actions';

export const divisionListEntityActions = createActions({
  api: {
    expGalaxyBeneficiaryV2: {
      divisionList: {
        clear: {
          REQUEST: () => ({}),
          error: {
            REQUEST: () => ({}),
          },
        },
      },
    },
  },
  galaxyBeneficiary: {
    divisionList: {
      clear: {
        REQUEST: () => ({}),
        error: {
          REQUEST: () => ({}),
        },
      },
    },
  },
});
