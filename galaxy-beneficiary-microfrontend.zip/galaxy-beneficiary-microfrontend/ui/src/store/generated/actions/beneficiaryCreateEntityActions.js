import { createActions } from 'redux-actions';

export const beneficiaryCreateEntityActions = createActions({
  api: {
    expGalaxyBeneficiaryV2: {
      beneficiaryCreate: {
        clear: {
          REQUEST: () => ({}),
          error: {
            REQUEST: () => ({}),
          },
        },
      },
    },
  },
  galaxyBeneficiary: {
    beneficiaryCreate: {
      clear: {
        REQUEST: () => ({}),
        error: {
          REQUEST: () => ({}),
        },
      },
    },
  },
});
