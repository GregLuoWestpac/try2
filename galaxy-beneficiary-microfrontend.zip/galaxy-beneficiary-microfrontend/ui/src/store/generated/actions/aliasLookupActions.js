import { get } from 'lodash';
import { createActions } from 'redux-actions';

export const aliasLookupActions = createActions({
  api: {
    expGalaxyBeneficiaryV2: {
      aliasLookup: {
        post: {
          REQUEST: [
            // payload creator
            (postAliasLookupParams, options) => {
              const { pathParams, params, query } = postAliasLookupParams;
              return { options, pathParams, params, query };
            },

            // meta creator
            (postAliasLookupParams, options) => {
              const { meta } = postAliasLookupParams;
              return meta;
            },
          ],
          RECEIVE: [
            // payload creator
            data => ({ ...data }),

            // meta creator
            (data, statusCode, resource, metadata = {}) => {
              // Ensure data has values we need:
              const result = get(data, 'result', null);
              const entities = get(data, 'entities', null);

              // We deliberately keep these as arrays so we can consistently
              // use Array.includes for existence checks:

              // Primary is whatever we request/have a result key for
              const primary = result ? Object.keys(result) : [];

              // Secondaries are all other entity types we have been sent data for (payload.entities) but
              // do not have an explicit result key for
              const secondary = entities
                ? Object.keys(entities).filter(item => !primary.includes(item))
                : [];

              // TODO: What is this metadata and what is the use case for having it?
              // Is there something better than customData that it can be called?
              return {
                resource,
                statusCode,
                // Following meta will be come meta: {meta}, because we are returning under meta creator
                meta: metadata,
                entities: {
                  primary,
                  secondary,
                },
              };
            },
          ],
          ERROR: [
            error => ({ error }),
            (err, metadata) => ({
              meta: metadata,
              entity: 'aliasLookup',
            }),
          ],
        },
      },
    },
  },

  galaxyBeneficiary: {
    postAliasLookup: {
      REQUEST: [
        // payload creator
        (postAliasLookupParams, options) => {
          const { pathParams, params, query } = postAliasLookupParams;
          return { options, pathParams, params, query };
        },

        // meta creator
        (postAliasLookupParams, options) => {
          const { meta } = postAliasLookupParams;
          return meta;
        },
      ],
      RECEIVE: [
        // payload creator
        data => ({ ...data }),

        // meta creator
        (data, statusCode, resource, metadata = {}) => {
          // Ensure data has values we need:
          const result = get(data, 'result', null);
          const entities = get(data, 'entities', null);

          // We deliberately keep these as arrays so we can consistently
          // use Array.includes for existence checks:

          // Primary is whatever we request/have a result key for
          const primary = result ? Object.keys(result) : [];

          // Secondaries are all other entity types we have been sent data for (payload.entities) but
          // do not have an explicit result key for
          const secondary = entities
            ? Object.keys(entities).filter(item => !primary.includes(item))
            : [];

          // TODO: What is this metadata and what is the use case for having it?
          // Is there something better than customData that it can be called?
          return {
            resource,
            statusCode,
            // Following meta will be come meta: {meta}, because we are returning under meta creator
            meta: metadata,
            entities: {
              primary,
              secondary,
            },
          };
        },
      ],
      ERROR: [
        error => ({ error }),
        (err, metadata) => ({
          meta: metadata,
          entity: 'aliasLookup',
        }),
      ],
    },
  },
});
