import { createActions } from 'redux-actions';

export const aliasLookupEntityActions = createActions({
  api: {
    expGalaxyBeneficiaryV2: {
      aliasLookup: {
        clear: {
          REQUEST: () => ({}),
          error: {
            REQUEST: () => ({}),
          },
        },
      },
    },
  },
  galaxyBeneficiary: {
    aliasLookup: {
      clear: {
        REQUEST: () => ({}),
        error: {
          REQUEST: () => ({}),
        },
      },
    },
  },
});
