import { createActions } from 'redux-actions';

export const pagingEntityActions = createActions({
  api: {
    expGalaxyBeneficiaryV2: {
      paging: {
        clear: {
          REQUEST: () => ({}),
          error: {
            REQUEST: () => ({}),
          },
        },
      },
    },
  },
  galaxyBeneficiary: {
    paging: {
      clear: {
        REQUEST: () => ({}),
        error: {
          REQUEST: () => ({}),
        },
      },
    },
  },
});
