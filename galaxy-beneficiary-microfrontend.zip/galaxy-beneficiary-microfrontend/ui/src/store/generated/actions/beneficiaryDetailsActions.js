import { get } from 'lodash';
import { createActions } from 'redux-actions';

export const beneficiaryDetailsActions = createActions({
  api: {
    expGalaxyBeneficiaryV2: {
      beneficiaryDetails: {
        post: {
          REQUEST: [
            // payload creator
            (postBeneficiaryDetailsParams, options) => {
              const { pathParams, params, query } =
                postBeneficiaryDetailsParams;
              return { options, pathParams, params, query };
            },

            // meta creator
            (postBeneficiaryDetailsParams, options) => {
              const { meta } = postBeneficiaryDetailsParams;
              return meta;
            },
          ],
          RECEIVE: [
            // payload creator
            data => ({ ...data }),

            // meta creator
            (data, statusCode, resource, metadata = {}) => {
              // Ensure data has values we need:
              const result = get(data, 'result', null);
              const entities = get(data, 'entities', null);

              // We deliberately keep these as arrays so we can consistently
              // use Array.includes for existence checks:

              // Primary is whatever we request/have a result key for
              const primary = result ? Object.keys(result) : [];

              // Secondaries are all other entity types we have been sent data for (payload.entities) but
              // do not have an explicit result key for
              const secondary = entities
                ? Object.keys(entities).filter(item => !primary.includes(item))
                : [];

              // TODO: What is this metadata and what is the use case for having it?
              // Is there something better than customData that it can be called?
              return {
                resource,
                statusCode,
                // Following meta will be come meta: {meta}, because we are returning under meta creator
                meta: metadata,
                entities: {
                  primary,
                  secondary,
                },
              };
            },
          ],
          ERROR: [
            error => ({ error }),
            (err, metadata) => ({
              meta: metadata,
              entity: 'beneficiaryDetails',
            }),
          ],
        },
      },
    },
  },

  galaxyBeneficiary: {
    retrieveBeneficiary: {
      REQUEST: [
        // payload creator
        (retrieveBeneficiaryParams, options) => {
          const { pathParams, params, query } = retrieveBeneficiaryParams;
          return { options, pathParams, params, query };
        },

        // meta creator
        (retrieveBeneficiaryParams, options) => {
          const { meta } = retrieveBeneficiaryParams;
          return meta;
        },
      ],
      RECEIVE: [
        // payload creator
        data => ({ ...data }),

        // meta creator
        (data, statusCode, resource, metadata = {}) => {
          // Ensure data has values we need:
          const result = get(data, 'result', null);
          const entities = get(data, 'entities', null);

          // We deliberately keep these as arrays so we can consistently
          // use Array.includes for existence checks:

          // Primary is whatever we request/have a result key for
          const primary = result ? Object.keys(result) : [];

          // Secondaries are all other entity types we have been sent data for (payload.entities) but
          // do not have an explicit result key for
          const secondary = entities
            ? Object.keys(entities).filter(item => !primary.includes(item))
            : [];

          // TODO: What is this metadata and what is the use case for having it?
          // Is there something better than customData that it can be called?
          return {
            resource,
            statusCode,
            // Following meta will be come meta: {meta}, because we are returning under meta creator
            meta: metadata,
            entities: {
              primary,
              secondary,
            },
          };
        },
      ],
      ERROR: [
        error => ({ error }),
        (err, metadata) => ({
          meta: metadata,
          entity: 'beneficiaryDetails',
        }),
      ],
    },
  },
});
