import { createActions } from 'redux-actions';

export const beneficiaryListEntityActions = createActions({
  api: {
    expGalaxyBeneficiaryV2: {
      beneficiaryList: {
        clear: {
          REQUEST: () => ({}),
          error: {
            REQUEST: () => ({}),
          },
        },
      },
    },
  },
  galaxyBeneficiary: {
    beneficiaryList: {
      clear: {
        REQUEST: () => ({}),
        error: {
          REQUEST: () => ({}),
        },
      },
    },
  },
});
