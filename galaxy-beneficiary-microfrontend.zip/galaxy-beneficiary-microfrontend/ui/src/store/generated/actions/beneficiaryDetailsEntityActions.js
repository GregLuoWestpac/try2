import { createActions } from 'redux-actions';

export const beneficiaryDetailsEntityActions = createActions({
  api: {
    expGalaxyBeneficiaryV2: {
      beneficiaryDetails: {
        clear: {
          REQUEST: () => ({}),
          error: {
            REQUEST: () => ({}),
          },
        },
      },
    },
  },
  galaxyBeneficiary: {
    beneficiaryDetails: {
      clear: {
        REQUEST: () => ({}),
        error: {
          REQUEST: () => ({}),
        },
      },
    },
  },
});
