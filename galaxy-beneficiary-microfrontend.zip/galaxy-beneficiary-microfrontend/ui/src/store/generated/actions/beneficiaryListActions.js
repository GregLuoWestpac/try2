import { get } from 'lodash';
import { createActions } from 'redux-actions';

export const beneficiaryListActions = createActions({
  api: {
    expGalaxyBeneficiaryV2: {
      beneficiaryList: {
        post: {
          REQUEST: [
            // payload creator
            (postBeneficiaryListParams, options) => {
              const { pathParams, params, query } = postBeneficiaryListParams;
              return { options, pathParams, params, query };
            },

            // meta creator
            (postBeneficiaryListParams, options) => {
              const { meta } = postBeneficiaryListParams;
              return meta;
            },
          ],
          RECEIVE: [
            // payload creator
            data => ({ ...data }),

            // meta creator
            (data, statusCode, resource, metadata = {}) => {
              // Ensure data has values we need:
              const result = get(data, 'result', null);
              const entities = get(data, 'entities', null);

              // We deliberately keep these as arrays so we can consistently
              // use Array.includes for existence checks:

              // Primary is whatever we request/have a result key for
              const primary = result ? Object.keys(result) : [];

              // Secondaries are all other entity types we have been sent data for (payload.entities) but
              // do not have an explicit result key for
              const secondary = entities
                ? Object.keys(entities).filter(item => !primary.includes(item))
                : [];

              // TODO: What is this metadata and what is the use case for having it?
              // Is there something better than customData that it can be called?
              return {
                resource,
                statusCode,
                // Following meta will be come meta: {meta}, because we are returning under meta creator
                meta: metadata,
                entities: {
                  primary,
                  secondary,
                },
              };
            },
          ],
          ERROR: [
            error => ({ error }),
            (err, metadata) => ({
              meta: metadata,
              entity: 'beneficiaryList',
            }),
          ],
        },
      },
    },
  },

  galaxyBeneficiary: {
    retrieveBeneficiaries: {
      REQUEST: [
        // payload creator
        (retrieveBeneficiariesParams, options) => {
          const { pathParams, params, query } = retrieveBeneficiariesParams;
          return { options, pathParams, params, query };
        },

        // meta creator
        (retrieveBeneficiariesParams, options) => {
          const { meta } = retrieveBeneficiariesParams;
          return meta;
        },
      ],
      RECEIVE: [
        // payload creator
        data => ({ ...data }),

        // meta creator
        (data, statusCode, resource, metadata = {}) => {
          // Ensure data has values we need:
          const result = get(data, 'result', null);
          const entities = get(data, 'entities', null);

          // We deliberately keep these as arrays so we can consistently
          // use Array.includes for existence checks:

          // Primary is whatever we request/have a result key for
          const primary = result ? Object.keys(result) : [];

          // Secondaries are all other entity types we have been sent data for (payload.entities) but
          // do not have an explicit result key for
          const secondary = entities
            ? Object.keys(entities).filter(item => !primary.includes(item))
            : [];

          // TODO: What is this metadata and what is the use case for having it?
          // Is there something better than customData that it can be called?
          return {
            resource,
            statusCode,
            // Following meta will be come meta: {meta}, because we are returning under meta creator
            meta: metadata,
            entities: {
              primary,
              secondary,
            },
          };
        },
      ],
      ERROR: [
        error => ({ error }),
        (err, metadata) => ({
          meta: metadata,
          entity: 'beneficiaryList',
        }),
      ],
    },
  },
});
