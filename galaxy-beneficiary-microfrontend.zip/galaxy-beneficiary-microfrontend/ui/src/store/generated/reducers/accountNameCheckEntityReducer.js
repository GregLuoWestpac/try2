/* eslint-disable no-constant-condition, no-self-compare, no-console */

import { handleActions } from 'redux-actions';
import { cloneDeep, includes, isArray, merge, uniq } from 'lodash';

import {
  defaultEntityStateShape,
  reducerRequestFn,
  reducerErrorFn,
  reducerClearFn,
  reducerClearErrorFn,
} from './common';

import { commonActions } from '../actions/commonActions';
import { accountNameCheckEntityActions } from '../actions/accountNameCheckEntityActions';
import { accountNameCheckActions } from '../actions/accountNameCheckActions';

const reducerReceiveFn = (state = {}, action) => {
  const {
    payload: { entities },
    meta,
    meta: { meta: metaData },
  } = action;

  if (metaData && metaData.fileDownloadSuccess) {
    return {
      ...state,
      isFetching: false,
      isError: false,
    };
  }

  const replaceEntities = metaData ? metaData.replaceEntities : null;
  const isReplaceEntity =
    isArray(replaceEntities) && includes(replaceEntities, 'accountNameCheck');

  console.debug(
    'Reducer :: accountNameCheck :: action=',
    action,
    'state=',
    state,
    'meta=',
    meta,
    'isReplaceEntity=',
    isReplaceEntity
  );

  if (
    // Act on this entity being a primary entity of the action
    includes(meta.entities.primary, 'accountNameCheck') ||
    // Act on this entity being a secondary entity of the action
    includes(meta.entities.secondary, 'accountNameCheck')
  ) {
    console.debug(
      'Reducer :: accountNameCheck :: has matched primary or secondary entity'
    );

    // TODO: Figure out how to handle state updates
    // for read-only applications
    // Since the payload is always spread along-with
    // existing state, stale data is not removed from
    // the store

    // merge() mutates so we create a deepClone first
    const currentById = cloneDeep(state.byId);

    const result = isReplaceEntity
      ? {
          byId: entities.accountNameCheck.byId,
          allIds: entities.accountNameCheck.allIds,
          isFetching: false,
          isError: false,
        }
      : {
          byId: merge(currentById, entities.accountNameCheck.byId),
          allIds: uniq([...state.allIds, ...entities.accountNameCheck.allIds]),
          isFetching: false,
          isError: false,
        };

    console.debug('Reducer :: accountNameCheck :: returning:', result);

    return result;
  }

  // TODO: Should there be handlers for other 2xx status codes?
  // Possible use cases could be to do with file uploads

  // This block ensures that a 204 response (no payload) still sets the
  // api status flags back to normal since 20X still means success and
  // a completion of the request
  if (meta.resource === 'accountNameCheck' && meta.statusCode === 204) {
    console.debug(
      'Reducer :: accountNameCheck :: 204 response, setting api flags to false'
    );

    const nextState = isReplaceEntity ? defaultEntityStateShape : state;
    return {
      ...nextState,
      isFetching: false,
      isError: false,
    };
  }

  return state;
};

export const accountNameCheckReducer = handleActions(
  {
    [commonActions.api.entities.clear.request]: reducerClearFn,
    [accountNameCheckEntityActions.api.expGalaxyBeneficiaryV2.accountNameCheck
      .clear.request]: reducerClearFn,
    [accountNameCheckEntityActions.api.expGalaxyBeneficiaryV2.accountNameCheck
      .clear.error.request]: reducerClearErrorFn,

    [commonActions.entities.clear.request]: reducerClearFn,
    [accountNameCheckEntityActions.galaxyBeneficiary.accountNameCheck.clear
      .request]: reducerClearFn,
    [accountNameCheckEntityActions.galaxyBeneficiary.accountNameCheck.clear
      .error.request]: reducerClearErrorFn,
    [accountNameCheckActions.api.expGalaxyBeneficiaryV2.accountNameCheck.post
      .request]:
      'accountNameCheck' === 'accountNameCheck'
        ? reducerRequestFn
        : state => state,
    [accountNameCheckActions.api.expGalaxyBeneficiaryV2.accountNameCheck.post
      .receive]: reducerReceiveFn,
    [accountNameCheckActions.api.expGalaxyBeneficiaryV2.accountNameCheck.post
      .error]:
      'accountNameCheck' === 'accountNameCheck'
        ? reducerErrorFn
        : state => state,

    [accountNameCheckActions.galaxyBeneficiary.postAccountNameCheck.request]:
      'accountNameCheck' === 'accountNameCheck'
        ? reducerRequestFn
        : state => state,
    [accountNameCheckActions.galaxyBeneficiary.postAccountNameCheck.receive]:
      reducerReceiveFn,
    [accountNameCheckActions.galaxyBeneficiary.postAccountNameCheck.error]:
      'accountNameCheck' === 'accountNameCheck'
        ? reducerErrorFn
        : state => state,
  },
  defaultEntityStateShape
);
