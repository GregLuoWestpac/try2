/* eslint-disable no-constant-condition, no-self-compare, no-console */

import { handleActions } from 'redux-actions';
import { cloneDeep, includes, isArray, merge, uniq } from 'lodash';

import {
  defaultEntityStateShape,
  reducerRequestFn,
  reducerErrorFn,
  reducerClearFn,
  reducerClearErrorFn,
} from './common';

import { commonActions } from '../actions/commonActions';
import { beneficiaryUpdateEntityActions } from '../actions/beneficiaryUpdateEntityActions';
import { beneficiaryUpdateActions } from '../actions/beneficiaryUpdateActions';

const reducerReceiveFn = (state = {}, action) => {
  const {
    payload: { entities },
    meta,
    meta: { meta: metaData },
  } = action;

  if (metaData && metaData.fileDownloadSuccess) {
    return {
      ...state,
      isFetching: false,
      isError: false,
    };
  }

  const replaceEntities = metaData ? metaData.replaceEntities : null;
  const isReplaceEntity =
    isArray(replaceEntities) && includes(replaceEntities, 'beneficiaryUpdate');

  console.debug(
    'Reducer :: beneficiaryUpdate :: action=',
    action,
    'state=',
    state,
    'meta=',
    meta,
    'isReplaceEntity=',
    isReplaceEntity
  );

  if (
    // Act on this entity being a primary entity of the action
    includes(meta.entities.primary, 'beneficiaryUpdate') ||
    // Act on this entity being a secondary entity of the action
    includes(meta.entities.secondary, 'beneficiaryUpdate')
  ) {
    console.debug(
      'Reducer :: beneficiaryUpdate :: has matched primary or secondary entity'
    );

    // TODO: Figure out how to handle state updates
    // for read-only applications
    // Since the payload is always spread along-with
    // existing state, stale data is not removed from
    // the store

    // merge() mutates so we create a deepClone first
    const currentById = cloneDeep(state.byId);

    const result = isReplaceEntity
      ? {
          byId: entities.beneficiaryUpdate.byId,
          allIds: entities.beneficiaryUpdate.allIds,
          isFetching: false,
          isError: false,
        }
      : {
          byId: merge(currentById, entities.beneficiaryUpdate.byId),
          allIds: uniq([...state.allIds, ...entities.beneficiaryUpdate.allIds]),
          isFetching: false,
          isError: false,
        };

    console.debug('Reducer :: beneficiaryUpdate :: returning:', result);

    return result;
  }

  // TODO: Should there be handlers for other 2xx status codes?
  // Possible use cases could be to do with file uploads

  // This block ensures that a 204 response (no payload) still sets the
  // api status flags back to normal since 20X still means success and
  // a completion of the request
  if (meta.resource === 'beneficiaryUpdate' && meta.statusCode === 204) {
    console.debug(
      'Reducer :: beneficiaryUpdate :: 204 response, setting api flags to false'
    );

    const nextState = isReplaceEntity ? defaultEntityStateShape : state;
    return {
      ...nextState,
      isFetching: false,
      isError: false,
    };
  }

  return state;
};

export const beneficiaryUpdateReducer = handleActions(
  {
    [commonActions.api.entities.clear.request]: reducerClearFn,
    [beneficiaryUpdateEntityActions.api.expGalaxyBeneficiaryV2.beneficiaryUpdate
      .clear.request]: reducerClearFn,
    [beneficiaryUpdateEntityActions.api.expGalaxyBeneficiaryV2.beneficiaryUpdate
      .clear.error.request]: reducerClearErrorFn,

    [commonActions.entities.clear.request]: reducerClearFn,
    [beneficiaryUpdateEntityActions.galaxyBeneficiary.beneficiaryUpdate.clear
      .request]: reducerClearFn,
    [beneficiaryUpdateEntityActions.galaxyBeneficiary.beneficiaryUpdate.clear
      .error.request]: reducerClearErrorFn,
    [beneficiaryUpdateActions.api.expGalaxyBeneficiaryV2.beneficiaryUpdate.put
      .request]:
      'beneficiaryUpdate' === 'beneficiaryUpdate'
        ? reducerRequestFn
        : state => state,
    [beneficiaryUpdateActions.api.expGalaxyBeneficiaryV2.beneficiaryUpdate.put
      .receive]: reducerReceiveFn,
    [beneficiaryUpdateActions.api.expGalaxyBeneficiaryV2.beneficiaryUpdate.put
      .error]:
      'beneficiaryUpdate' === 'beneficiaryUpdate'
        ? reducerErrorFn
        : state => state,

    [beneficiaryUpdateActions.galaxyBeneficiary.updateBeneficiary.request]:
      'beneficiaryUpdate' === 'beneficiaryUpdate'
        ? reducerRequestFn
        : state => state,
    [beneficiaryUpdateActions.galaxyBeneficiary.updateBeneficiary.receive]:
      reducerReceiveFn,
    [beneficiaryUpdateActions.galaxyBeneficiary.updateBeneficiary.error]:
      'beneficiaryUpdate' === 'beneficiaryUpdate'
        ? reducerErrorFn
        : state => state,
  },
  defaultEntityStateShape
);
