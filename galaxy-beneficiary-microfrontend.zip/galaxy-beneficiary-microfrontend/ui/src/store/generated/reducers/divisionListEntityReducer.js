/* eslint-disable no-constant-condition, no-self-compare, no-console */

import { handleActions } from 'redux-actions';
import { cloneDeep, includes, isArray, merge, uniq } from 'lodash';

import {
  defaultEntityStateShape,
  reducerRequestFn,
  reducerErrorFn,
  reducerClearFn,
  reducerClearErrorFn,
} from './common';

import { commonActions } from '../actions/commonActions';
import { divisionListEntityActions } from '../actions/divisionListEntityActions';
import { divisionListActions } from '../actions/divisionListActions';

const reducerReceiveFn = (state = {}, action) => {
  const {
    payload: { entities },
    meta,
    meta: { meta: metaData },
  } = action;

  if (metaData && metaData.fileDownloadSuccess) {
    return {
      ...state,
      isFetching: false,
      isError: false,
    };
  }

  const replaceEntities = metaData ? metaData.replaceEntities : null;
  const isReplaceEntity =
    isArray(replaceEntities) && includes(replaceEntities, 'divisionList');

  console.debug(
    'Reducer :: divisionList :: action=',
    action,
    'state=',
    state,
    'meta=',
    meta,
    'isReplaceEntity=',
    isReplaceEntity
  );

  if (
    // Act on this entity being a primary entity of the action
    includes(meta.entities.primary, 'divisionList') ||
    // Act on this entity being a secondary entity of the action
    includes(meta.entities.secondary, 'divisionList')
  ) {
    console.debug(
      'Reducer :: divisionList :: has matched primary or secondary entity'
    );

    // TODO: Figure out how to handle state updates
    // for read-only applications
    // Since the payload is always spread along-with
    // existing state, stale data is not removed from
    // the store

    // merge() mutates so we create a deepClone first
    const currentById = cloneDeep(state.byId);

    const result = isReplaceEntity
      ? {
          byId: entities.divisionList.byId,
          allIds: entities.divisionList.allIds,
          isFetching: false,
          isError: false,
        }
      : {
          byId: merge(currentById, entities.divisionList.byId),
          allIds: uniq([...state.allIds, ...entities.divisionList.allIds]),
          isFetching: false,
          isError: false,
        };

    console.debug('Reducer :: divisionList :: returning:', result);

    return result;
  }

  // TODO: Should there be handlers for other 2xx status codes?
  // Possible use cases could be to do with file uploads

  // This block ensures that a 204 response (no payload) still sets the
  // api status flags back to normal since 20X still means success and
  // a completion of the request
  if (meta.resource === 'divisionList' && meta.statusCode === 204) {
    console.debug(
      'Reducer :: divisionList :: 204 response, setting api flags to false'
    );

    const nextState = isReplaceEntity ? defaultEntityStateShape : state;
    return {
      ...nextState,
      isFetching: false,
      isError: false,
    };
  }

  return state;
};

export const divisionListReducer = handleActions(
  {
    [commonActions.api.entities.clear.request]: reducerClearFn,
    [divisionListEntityActions.api.expGalaxyBeneficiaryV2.divisionList.clear
      .request]: reducerClearFn,
    [divisionListEntityActions.api.expGalaxyBeneficiaryV2.divisionList.clear
      .error.request]: reducerClearErrorFn,

    [commonActions.entities.clear.request]: reducerClearFn,
    [divisionListEntityActions.galaxyBeneficiary.divisionList.clear.request]:
      reducerClearFn,
    [divisionListEntityActions.galaxyBeneficiary.divisionList.clear.error
      .request]: reducerClearErrorFn,
    [divisionListActions.api.expGalaxyBeneficiaryV2.divisionList.get.request]:
      'divisionList' === 'divisionList' ? reducerRequestFn : state => state,
    [divisionListActions.api.expGalaxyBeneficiaryV2.divisionList.get.receive]:
      reducerReceiveFn,
    [divisionListActions.api.expGalaxyBeneficiaryV2.divisionList.get.error]:
      'divisionList' === 'divisionList' ? reducerErrorFn : state => state,

    [divisionListActions.galaxyBeneficiary.getDivisionList.request]:
      'divisionList' === 'divisionList' ? reducerRequestFn : state => state,
    [divisionListActions.galaxyBeneficiary.getDivisionList.receive]:
      reducerReceiveFn,
    [divisionListActions.galaxyBeneficiary.getDivisionList.error]:
      'divisionList' === 'divisionList' ? reducerErrorFn : state => state,
  },
  defaultEntityStateShape
);
