import { combineReducers } from '@mep-ui/framework';

import { beneficiaryCreateReducer } from './beneficiaryCreateEntityReducer';
import { beneficiaryListReducer } from './beneficiaryListEntityReducer';
import { pagingReducer } from './pagingEntityReducer';
import { beneficiaryUpdateReducer } from './beneficiaryUpdateEntityReducer';
import { beneficiaryDetailsReducer } from './beneficiaryDetailsEntityReducer';
import { beneficiaryArchiveReducer } from './beneficiaryArchiveEntityReducer';
import { beneficiaryStatusUpdateReducer } from './beneficiaryStatusUpdateEntityReducer';
import { aliasLookupReducer } from './aliasLookupEntityReducer';
import { bsbLookupReducer } from './bsbLookupEntityReducer';
import { divisionListReducer } from './divisionListEntityReducer';
import { accountNameCheckReducer } from './accountNameCheckEntityReducer';

export const reducer = {
  expGalaxyBeneficiaryV2: combineReducers({
    beneficiaryCreate: beneficiaryCreateReducer,
    beneficiaryList: beneficiaryListReducer,
    paging: pagingReducer,
    beneficiaryUpdate: beneficiaryUpdateReducer,
    beneficiaryDetails: beneficiaryDetailsReducer,
    beneficiaryArchive: beneficiaryArchiveReducer,
    beneficiaryStatusUpdate: beneficiaryStatusUpdateReducer,
    aliasLookup: aliasLookupReducer,
    bsbLookup: bsbLookupReducer,
    divisionList: divisionListReducer,
    accountNameCheck: accountNameCheckReducer,
  }),
};

export default reducer;
