/* eslint-disable no-constant-condition, no-self-compare, no-console */

import { handleActions } from 'redux-actions';
import { cloneDeep, includes, isArray, merge, uniq } from 'lodash';

import {
  defaultEntityStateShape,
  reducerRequestFn,
  reducerErrorFn,
  reducerClearFn,
  reducerClearErrorFn,
} from './common';

import { commonActions } from '../actions/commonActions';
import { bsbLookupEntityActions } from '../actions/bsbLookupEntityActions';
import { bsbLookupActions } from '../actions/bsbLookupActions';

const reducerReceiveFn = (state = {}, action) => {
  const {
    payload: { entities },
    meta,
    meta: { meta: metaData },
  } = action;

  if (metaData && metaData.fileDownloadSuccess) {
    return {
      ...state,
      isFetching: false,
      isError: false,
    };
  }

  const replaceEntities = metaData ? metaData.replaceEntities : null;
  const isReplaceEntity =
    isArray(replaceEntities) && includes(replaceEntities, 'bsbLookup');

  console.debug(
    'Reducer :: bsbLookup :: action=',
    action,
    'state=',
    state,
    'meta=',
    meta,
    'isReplaceEntity=',
    isReplaceEntity
  );

  if (
    // Act on this entity being a primary entity of the action
    includes(meta.entities.primary, 'bsbLookup') ||
    // Act on this entity being a secondary entity of the action
    includes(meta.entities.secondary, 'bsbLookup')
  ) {
    console.debug(
      'Reducer :: bsbLookup :: has matched primary or secondary entity'
    );

    // TODO: Figure out how to handle state updates
    // for read-only applications
    // Since the payload is always spread along-with
    // existing state, stale data is not removed from
    // the store

    // merge() mutates so we create a deepClone first
    const currentById = cloneDeep(state.byId);

    const result = isReplaceEntity
      ? {
          byId: entities.bsbLookup.byId,
          allIds: entities.bsbLookup.allIds,
          isFetching: false,
          isError: false,
        }
      : {
          byId: merge(currentById, entities.bsbLookup.byId),
          allIds: uniq([...state.allIds, ...entities.bsbLookup.allIds]),
          isFetching: false,
          isError: false,
        };

    console.debug('Reducer :: bsbLookup :: returning:', result);

    return result;
  }

  // TODO: Should there be handlers for other 2xx status codes?
  // Possible use cases could be to do with file uploads

  // This block ensures that a 204 response (no payload) still sets the
  // api status flags back to normal since 20X still means success and
  // a completion of the request
  if (meta.resource === 'bsbLookup' && meta.statusCode === 204) {
    console.debug(
      'Reducer :: bsbLookup :: 204 response, setting api flags to false'
    );

    const nextState = isReplaceEntity ? defaultEntityStateShape : state;
    return {
      ...nextState,
      isFetching: false,
      isError: false,
    };
  }

  return state;
};

export const bsbLookupReducer = handleActions(
  {
    [commonActions.api.entities.clear.request]: reducerClearFn,
    [bsbLookupEntityActions.api.expGalaxyBeneficiaryV2.bsbLookup.clear.request]:
      reducerClearFn,
    [bsbLookupEntityActions.api.expGalaxyBeneficiaryV2.bsbLookup.clear.error
      .request]: reducerClearErrorFn,

    [commonActions.entities.clear.request]: reducerClearFn,
    [bsbLookupEntityActions.galaxyBeneficiary.bsbLookup.clear.request]:
      reducerClearFn,
    [bsbLookupEntityActions.galaxyBeneficiary.bsbLookup.clear.error.request]:
      reducerClearErrorFn,
    [bsbLookupActions.api.expGalaxyBeneficiaryV2.bsbLookup.get.request]:
      'bsbLookup' === 'bsbLookup' ? reducerRequestFn : state => state,
    [bsbLookupActions.api.expGalaxyBeneficiaryV2.bsbLookup.get.receive]:
      reducerReceiveFn,
    [bsbLookupActions.api.expGalaxyBeneficiaryV2.bsbLookup.get.error]:
      'bsbLookup' === 'bsbLookup' ? reducerErrorFn : state => state,

    [bsbLookupActions.galaxyBeneficiary.getBsbLookup.request]:
      'bsbLookup' === 'bsbLookup' ? reducerRequestFn : state => state,
    [bsbLookupActions.galaxyBeneficiary.getBsbLookup.receive]: reducerReceiveFn,
    [bsbLookupActions.galaxyBeneficiary.getBsbLookup.error]:
      'bsbLookup' === 'bsbLookup' ? reducerErrorFn : state => state,
  },
  defaultEntityStateShape
);
