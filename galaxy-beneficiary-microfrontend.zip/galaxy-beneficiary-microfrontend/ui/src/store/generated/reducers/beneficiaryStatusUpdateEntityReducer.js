/* eslint-disable no-constant-condition, no-self-compare, no-console */

import { handleActions } from 'redux-actions';
import { cloneDeep, includes, isArray, merge, uniq } from 'lodash';

import {
  defaultEntityStateShape,
  reducerRequestFn,
  reducerErrorFn,
  reducerClearFn,
  reducerClearErrorFn,
} from './common';

import { commonActions } from '../actions/commonActions';
import { beneficiaryStatusUpdateEntityActions } from '../actions/beneficiaryStatusUpdateEntityActions';
import { beneficiaryStatusUpdateActions } from '../actions/beneficiaryStatusUpdateActions';

const reducerReceiveFn = (state = {}, action) => {
  const {
    payload: { entities },
    meta,
    meta: { meta: metaData },
  } = action;

  if (metaData && metaData.fileDownloadSuccess) {
    return {
      ...state,
      isFetching: false,
      isError: false,
    };
  }

  const replaceEntities = metaData ? metaData.replaceEntities : null;
  const isReplaceEntity =
    isArray(replaceEntities) &&
    includes(replaceEntities, 'beneficiaryStatusUpdate');

  console.debug(
    'Reducer :: beneficiaryStatusUpdate :: action=',
    action,
    'state=',
    state,
    'meta=',
    meta,
    'isReplaceEntity=',
    isReplaceEntity
  );

  if (
    // Act on this entity being a primary entity of the action
    includes(meta.entities.primary, 'beneficiaryStatusUpdate') ||
    // Act on this entity being a secondary entity of the action
    includes(meta.entities.secondary, 'beneficiaryStatusUpdate')
  ) {
    console.debug(
      'Reducer :: beneficiaryStatusUpdate :: has matched primary or secondary entity'
    );

    // TODO: Figure out how to handle state updates
    // for read-only applications
    // Since the payload is always spread along-with
    // existing state, stale data is not removed from
    // the store

    // merge() mutates so we create a deepClone first
    const currentById = cloneDeep(state.byId);

    const result = isReplaceEntity
      ? {
          byId: entities.beneficiaryStatusUpdate.byId,
          allIds: entities.beneficiaryStatusUpdate.allIds,
          isFetching: false,
          isError: false,
        }
      : {
          byId: merge(currentById, entities.beneficiaryStatusUpdate.byId),
          allIds: uniq([
            ...state.allIds,
            ...entities.beneficiaryStatusUpdate.allIds,
          ]),
          isFetching: false,
          isError: false,
        };

    console.debug('Reducer :: beneficiaryStatusUpdate :: returning:', result);

    return result;
  }

  // TODO: Should there be handlers for other 2xx status codes?
  // Possible use cases could be to do with file uploads

  // This block ensures that a 204 response (no payload) still sets the
  // api status flags back to normal since 20X still means success and
  // a completion of the request
  if (meta.resource === 'beneficiaryStatusUpdate' && meta.statusCode === 204) {
    console.debug(
      'Reducer :: beneficiaryStatusUpdate :: 204 response, setting api flags to false'
    );

    const nextState = isReplaceEntity ? defaultEntityStateShape : state;
    return {
      ...nextState,
      isFetching: false,
      isError: false,
    };
  }

  return state;
};

export const beneficiaryStatusUpdateReducer = handleActions(
  {
    [commonActions.api.entities.clear.request]: reducerClearFn,
    [beneficiaryStatusUpdateEntityActions.api.expGalaxyBeneficiaryV2
      .beneficiaryStatusUpdate.clear.request]: reducerClearFn,
    [beneficiaryStatusUpdateEntityActions.api.expGalaxyBeneficiaryV2
      .beneficiaryStatusUpdate.clear.error.request]: reducerClearErrorFn,

    [commonActions.entities.clear.request]: reducerClearFn,
    [beneficiaryStatusUpdateEntityActions.galaxyBeneficiary
      .beneficiaryStatusUpdate.clear.request]: reducerClearFn,
    [beneficiaryStatusUpdateEntityActions.galaxyBeneficiary
      .beneficiaryStatusUpdate.clear.error.request]: reducerClearErrorFn,
    [beneficiaryStatusUpdateActions.api.expGalaxyBeneficiaryV2
      .beneficiaryStatusUpdate.post.request]:
      'beneficiaryStatusUpdate' === 'beneficiaryStatusUpdate'
        ? reducerRequestFn
        : state => state,
    [beneficiaryStatusUpdateActions.api.expGalaxyBeneficiaryV2
      .beneficiaryStatusUpdate.post.receive]: reducerReceiveFn,
    [beneficiaryStatusUpdateActions.api.expGalaxyBeneficiaryV2
      .beneficiaryStatusUpdate.post.error]:
      'beneficiaryStatusUpdate' === 'beneficiaryStatusUpdate'
        ? reducerErrorFn
        : state => state,

    [beneficiaryStatusUpdateActions.galaxyBeneficiary.updateBeneficiaryStatus
      .request]:
      'beneficiaryStatusUpdate' === 'beneficiaryStatusUpdate'
        ? reducerRequestFn
        : state => state,
    [beneficiaryStatusUpdateActions.galaxyBeneficiary.updateBeneficiaryStatus
      .receive]: reducerReceiveFn,
    [beneficiaryStatusUpdateActions.galaxyBeneficiary.updateBeneficiaryStatus
      .error]:
      'beneficiaryStatusUpdate' === 'beneficiaryStatusUpdate'
        ? reducerErrorFn
        : state => state,
  },
  defaultEntityStateShape
);
