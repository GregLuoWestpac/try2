/* eslint-disable no-constant-condition, no-self-compare, no-console */

import { handleActions } from 'redux-actions';
import { cloneDeep, includes, isArray, merge, uniq } from 'lodash';

import {
  defaultEntityStateShape,
  reducerRequestFn,
  reducerErrorFn,
  reducerClearFn,
  reducerClearErrorFn,
} from './common';

import { commonActions } from '../actions/commonActions';
import { beneficiaryArchiveEntityActions } from '../actions/beneficiaryArchiveEntityActions';
import { beneficiaryArchiveActions } from '../actions/beneficiaryArchiveActions';

const reducerReceiveFn = (state = {}, action) => {
  const {
    payload: { entities },
    meta,
    meta: { meta: metaData },
  } = action;

  if (metaData && metaData.fileDownloadSuccess) {
    return {
      ...state,
      isFetching: false,
      isError: false,
    };
  }

  const replaceEntities = metaData ? metaData.replaceEntities : null;
  const isReplaceEntity =
    isArray(replaceEntities) && includes(replaceEntities, 'beneficiaryArchive');

  console.debug(
    'Reducer :: beneficiaryArchive :: action=',
    action,
    'state=',
    state,
    'meta=',
    meta,
    'isReplaceEntity=',
    isReplaceEntity
  );

  if (
    // Act on this entity being a primary entity of the action
    includes(meta.entities.primary, 'beneficiaryArchive') ||
    // Act on this entity being a secondary entity of the action
    includes(meta.entities.secondary, 'beneficiaryArchive')
  ) {
    console.debug(
      'Reducer :: beneficiaryArchive :: has matched primary or secondary entity'
    );

    // TODO: Figure out how to handle state updates
    // for read-only applications
    // Since the payload is always spread along-with
    // existing state, stale data is not removed from
    // the store

    // merge() mutates so we create a deepClone first
    const currentById = cloneDeep(state.byId);

    const result = isReplaceEntity
      ? {
          byId: entities.beneficiaryArchive.byId,
          allIds: entities.beneficiaryArchive.allIds,
          isFetching: false,
          isError: false,
        }
      : {
          byId: merge(currentById, entities.beneficiaryArchive.byId),
          allIds: uniq([
            ...state.allIds,
            ...entities.beneficiaryArchive.allIds,
          ]),
          isFetching: false,
          isError: false,
        };

    console.debug('Reducer :: beneficiaryArchive :: returning:', result);

    return result;
  }

  // TODO: Should there be handlers for other 2xx status codes?
  // Possible use cases could be to do with file uploads

  // This block ensures that a 204 response (no payload) still sets the
  // api status flags back to normal since 20X still means success and
  // a completion of the request
  if (meta.resource === 'beneficiaryArchive' && meta.statusCode === 204) {
    console.debug(
      'Reducer :: beneficiaryArchive :: 204 response, setting api flags to false'
    );

    const nextState = isReplaceEntity ? defaultEntityStateShape : state;
    return {
      ...nextState,
      isFetching: false,
      isError: false,
    };
  }

  return state;
};

export const beneficiaryArchiveReducer = handleActions(
  {
    [commonActions.api.entities.clear.request]: reducerClearFn,
    [beneficiaryArchiveEntityActions.api.expGalaxyBeneficiaryV2
      .beneficiaryArchive.clear.request]: reducerClearFn,
    [beneficiaryArchiveEntityActions.api.expGalaxyBeneficiaryV2
      .beneficiaryArchive.clear.error.request]: reducerClearErrorFn,

    [commonActions.entities.clear.request]: reducerClearFn,
    [beneficiaryArchiveEntityActions.galaxyBeneficiary.beneficiaryArchive.clear
      .request]: reducerClearFn,
    [beneficiaryArchiveEntityActions.galaxyBeneficiary.beneficiaryArchive.clear
      .error.request]: reducerClearErrorFn,
    [beneficiaryArchiveActions.api.expGalaxyBeneficiaryV2.beneficiaryArchive
      .post.request]:
      'beneficiaryArchive' === 'beneficiaryArchive'
        ? reducerRequestFn
        : state => state,
    [beneficiaryArchiveActions.api.expGalaxyBeneficiaryV2.beneficiaryArchive
      .post.receive]: reducerReceiveFn,
    [beneficiaryArchiveActions.api.expGalaxyBeneficiaryV2.beneficiaryArchive
      .post.error]:
      'beneficiaryArchive' === 'beneficiaryArchive'
        ? reducerErrorFn
        : state => state,

    [beneficiaryArchiveActions.galaxyBeneficiary.archiveBeneficiaries.request]:
      'beneficiaryArchive' === 'beneficiaryArchive'
        ? reducerRequestFn
        : state => state,
    [beneficiaryArchiveActions.galaxyBeneficiary.archiveBeneficiaries.receive]:
      reducerReceiveFn,
    [beneficiaryArchiveActions.galaxyBeneficiary.archiveBeneficiaries.error]:
      'beneficiaryArchive' === 'beneficiaryArchive'
        ? reducerErrorFn
        : state => state,
  },
  defaultEntityStateShape
);
