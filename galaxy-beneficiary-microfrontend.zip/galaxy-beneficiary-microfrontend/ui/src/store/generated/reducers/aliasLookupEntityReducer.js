/* eslint-disable no-constant-condition, no-self-compare, no-console */

import { handleActions } from 'redux-actions';
import { cloneDeep, includes, isArray, merge, uniq } from 'lodash';

import {
  defaultEntityStateShape,
  reducerRequestFn,
  reducerErrorFn,
  reducerClearFn,
  reducerClearErrorFn,
} from './common';

import { commonActions } from '../actions/commonActions';
import { aliasLookupEntityActions } from '../actions/aliasLookupEntityActions';
import { aliasLookupActions } from '../actions/aliasLookupActions';

const reducerReceiveFn = (state = {}, action) => {
  const {
    payload: { entities },
    meta,
    meta: { meta: metaData },
  } = action;

  if (metaData && metaData.fileDownloadSuccess) {
    return {
      ...state,
      isFetching: false,
      isError: false,
    };
  }

  const replaceEntities = metaData ? metaData.replaceEntities : null;
  const isReplaceEntity =
    isArray(replaceEntities) && includes(replaceEntities, 'aliasLookup');

  console.debug(
    'Reducer :: aliasLookup :: action=',
    action,
    'state=',
    state,
    'meta=',
    meta,
    'isReplaceEntity=',
    isReplaceEntity
  );

  if (
    // Act on this entity being a primary entity of the action
    includes(meta.entities.primary, 'aliasLookup') ||
    // Act on this entity being a secondary entity of the action
    includes(meta.entities.secondary, 'aliasLookup')
  ) {
    console.debug(
      'Reducer :: aliasLookup :: has matched primary or secondary entity'
    );

    // TODO: Figure out how to handle state updates
    // for read-only applications
    // Since the payload is always spread along-with
    // existing state, stale data is not removed from
    // the store

    // merge() mutates so we create a deepClone first
    const currentById = cloneDeep(state.byId);

    const result = isReplaceEntity
      ? {
          byId: entities.aliasLookup.byId,
          allIds: entities.aliasLookup.allIds,
          isFetching: false,
          isError: false,
        }
      : {
          byId: merge(currentById, entities.aliasLookup.byId),
          allIds: uniq([...state.allIds, ...entities.aliasLookup.allIds]),
          isFetching: false,
          isError: false,
        };

    console.debug('Reducer :: aliasLookup :: returning:', result);

    return result;
  }

  // TODO: Should there be handlers for other 2xx status codes?
  // Possible use cases could be to do with file uploads

  // This block ensures that a 204 response (no payload) still sets the
  // api status flags back to normal since 20X still means success and
  // a completion of the request
  if (meta.resource === 'aliasLookup' && meta.statusCode === 204) {
    console.debug(
      'Reducer :: aliasLookup :: 204 response, setting api flags to false'
    );

    const nextState = isReplaceEntity ? defaultEntityStateShape : state;
    return {
      ...nextState,
      isFetching: false,
      isError: false,
    };
  }

  return state;
};

export const aliasLookupReducer = handleActions(
  {
    [commonActions.api.entities.clear.request]: reducerClearFn,
    [aliasLookupEntityActions.api.expGalaxyBeneficiaryV2.aliasLookup.clear
      .request]: reducerClearFn,
    [aliasLookupEntityActions.api.expGalaxyBeneficiaryV2.aliasLookup.clear.error
      .request]: reducerClearErrorFn,

    [commonActions.entities.clear.request]: reducerClearFn,
    [aliasLookupEntityActions.galaxyBeneficiary.aliasLookup.clear.request]:
      reducerClearFn,
    [aliasLookupEntityActions.galaxyBeneficiary.aliasLookup.clear.error
      .request]: reducerClearErrorFn,
    [aliasLookupActions.api.expGalaxyBeneficiaryV2.aliasLookup.post.request]:
      'aliasLookup' === 'aliasLookup' ? reducerRequestFn : state => state,
    [aliasLookupActions.api.expGalaxyBeneficiaryV2.aliasLookup.post.receive]:
      reducerReceiveFn,
    [aliasLookupActions.api.expGalaxyBeneficiaryV2.aliasLookup.post.error]:
      'aliasLookup' === 'aliasLookup' ? reducerErrorFn : state => state,

    [aliasLookupActions.galaxyBeneficiary.postAliasLookup.request]:
      'aliasLookup' === 'aliasLookup' ? reducerRequestFn : state => state,
    [aliasLookupActions.galaxyBeneficiary.postAliasLookup.receive]:
      reducerReceiveFn,
    [aliasLookupActions.galaxyBeneficiary.postAliasLookup.error]:
      'aliasLookup' === 'aliasLookup' ? reducerErrorFn : state => state,
  },
  defaultEntityStateShape
);
