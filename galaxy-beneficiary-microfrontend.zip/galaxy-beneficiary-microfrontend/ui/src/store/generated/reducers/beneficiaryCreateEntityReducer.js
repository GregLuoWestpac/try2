/* eslint-disable no-constant-condition, no-self-compare, no-console */

import { handleActions } from 'redux-actions';
import { cloneDeep, includes, isArray, merge, uniq } from 'lodash';

import {
  defaultEntityStateShape,
  reducerRequestFn,
  reducerErrorFn,
  reducerClearFn,
  reducerClearErrorFn,
} from './common';

import { commonActions } from '../actions/commonActions';
import { beneficiaryCreateEntityActions } from '../actions/beneficiaryCreateEntityActions';
import { beneficiaryCreateActions } from '../actions/beneficiaryCreateActions';

const reducerReceiveFn = (state = {}, action) => {
  const {
    payload: { entities },
    meta,
    meta: { meta: metaData },
  } = action;

  if (metaData && metaData.fileDownloadSuccess) {
    return {
      ...state,
      isFetching: false,
      isError: false,
    };
  }

  const replaceEntities = metaData ? metaData.replaceEntities : null;
  const isReplaceEntity =
    isArray(replaceEntities) && includes(replaceEntities, 'beneficiaryCreate');

  console.debug(
    'Reducer :: beneficiaryCreate :: action=',
    action,
    'state=',
    state,
    'meta=',
    meta,
    'isReplaceEntity=',
    isReplaceEntity
  );

  if (
    // Act on this entity being a primary entity of the action
    includes(meta.entities.primary, 'beneficiaryCreate') ||
    // Act on this entity being a secondary entity of the action
    includes(meta.entities.secondary, 'beneficiaryCreate')
  ) {
    console.debug(
      'Reducer :: beneficiaryCreate :: has matched primary or secondary entity'
    );

    // TODO: Figure out how to handle state updates
    // for read-only applications
    // Since the payload is always spread along-with
    // existing state, stale data is not removed from
    // the store

    // merge() mutates so we create a deepClone first
    const currentById = cloneDeep(state.byId);

    const result = isReplaceEntity
      ? {
          byId: entities.beneficiaryCreate.byId,
          allIds: entities.beneficiaryCreate.allIds,
          isFetching: false,
          isError: false,
        }
      : {
          byId: merge(currentById, entities.beneficiaryCreate.byId),
          allIds: uniq([...state.allIds, ...entities.beneficiaryCreate.allIds]),
          isFetching: false,
          isError: false,
        };

    console.debug('Reducer :: beneficiaryCreate :: returning:', result);

    return result;
  }

  // TODO: Should there be handlers for other 2xx status codes?
  // Possible use cases could be to do with file uploads

  // This block ensures that a 204 response (no payload) still sets the
  // api status flags back to normal since 20X still means success and
  // a completion of the request
  if (meta.resource === 'beneficiaryCreate' && meta.statusCode === 204) {
    console.debug(
      'Reducer :: beneficiaryCreate :: 204 response, setting api flags to false'
    );

    const nextState = isReplaceEntity ? defaultEntityStateShape : state;
    return {
      ...nextState,
      isFetching: false,
      isError: false,
    };
  }

  return state;
};

export const beneficiaryCreateReducer = handleActions(
  {
    [commonActions.api.entities.clear.request]: reducerClearFn,
    [beneficiaryCreateEntityActions.api.expGalaxyBeneficiaryV2.beneficiaryCreate
      .clear.request]: reducerClearFn,
    [beneficiaryCreateEntityActions.api.expGalaxyBeneficiaryV2.beneficiaryCreate
      .clear.error.request]: reducerClearErrorFn,

    [commonActions.entities.clear.request]: reducerClearFn,
    [beneficiaryCreateEntityActions.galaxyBeneficiary.beneficiaryCreate.clear
      .request]: reducerClearFn,
    [beneficiaryCreateEntityActions.galaxyBeneficiary.beneficiaryCreate.clear
      .error.request]: reducerClearErrorFn,
    [beneficiaryCreateActions.api.expGalaxyBeneficiaryV2.beneficiaryCreate.post
      .request]:
      'beneficiaryCreate' === 'beneficiaryCreate'
        ? reducerRequestFn
        : state => state,
    [beneficiaryCreateActions.api.expGalaxyBeneficiaryV2.beneficiaryCreate.post
      .receive]: reducerReceiveFn,
    [beneficiaryCreateActions.api.expGalaxyBeneficiaryV2.beneficiaryCreate.post
      .error]:
      'beneficiaryCreate' === 'beneficiaryCreate'
        ? reducerErrorFn
        : state => state,

    [beneficiaryCreateActions.galaxyBeneficiary.createBeneficiaries.request]:
      'beneficiaryCreate' === 'beneficiaryCreate'
        ? reducerRequestFn
        : state => state,
    [beneficiaryCreateActions.galaxyBeneficiary.createBeneficiaries.receive]:
      reducerReceiveFn,
    [beneficiaryCreateActions.galaxyBeneficiary.createBeneficiaries.error]:
      'beneficiaryCreate' === 'beneficiaryCreate'
        ? reducerErrorFn
        : state => state,
  },
  defaultEntityStateShape
);
