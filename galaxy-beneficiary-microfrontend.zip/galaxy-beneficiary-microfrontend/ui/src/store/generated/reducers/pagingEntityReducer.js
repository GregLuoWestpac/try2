/* eslint-disable no-constant-condition, no-self-compare, no-console */

import { handleActions } from 'redux-actions';
import { cloneDeep, includes, isArray, merge, uniq } from 'lodash';

import {
  defaultEntityStateShape,
  reducerRequestFn,
  reducerErrorFn,
  reducerClearFn,
  reducerClearErrorFn,
} from './common';

import { commonActions } from '../actions/commonActions';
import { pagingEntityActions } from '../actions/pagingEntityActions';
import { beneficiaryListActions } from '../actions/beneficiaryListActions';

const reducerReceiveFn = (state = {}, action) => {
  const {
    payload: { entities },
    meta,
    meta: { meta: metaData },
  } = action;

  if (metaData && metaData.fileDownloadSuccess) {
    return {
      ...state,
      isFetching: false,
      isError: false,
    };
  }

  const replaceEntities = metaData ? metaData.replaceEntities : null;
  const isReplaceEntity =
    isArray(replaceEntities) && includes(replaceEntities, 'paging');

  console.debug(
    'Reducer :: paging :: action=',
    action,
    'state=',
    state,
    'meta=',
    meta,
    'isReplaceEntity=',
    isReplaceEntity
  );

  if (
    // Act on this entity being a primary entity of the action
    includes(meta.entities.primary, 'paging') ||
    // Act on this entity being a secondary entity of the action
    includes(meta.entities.secondary, 'paging')
  ) {
    console.debug(
      'Reducer :: paging :: has matched primary or secondary entity'
    );

    // TODO: Figure out how to handle state updates
    // for read-only applications
    // Since the payload is always spread along-with
    // existing state, stale data is not removed from
    // the store

    // merge() mutates so we create a deepClone first
    const currentById = cloneDeep(state.byId);

    const result = isReplaceEntity
      ? {
          byId: entities.paging.byId,
          allIds: entities.paging.allIds,
          isFetching: false,
          isError: false,
        }
      : {
          byId: merge(currentById, entities.paging.byId),
          allIds: uniq([...state.allIds, ...entities.paging.allIds]),
          isFetching: false,
          isError: false,
        };

    console.debug('Reducer :: paging :: returning:', result);

    return result;
  }

  // TODO: Should there be handlers for other 2xx status codes?
  // Possible use cases could be to do with file uploads

  // This block ensures that a 204 response (no payload) still sets the
  // api status flags back to normal since 20X still means success and
  // a completion of the request
  if (meta.resource === 'paging' && meta.statusCode === 204) {
    console.debug(
      'Reducer :: paging :: 204 response, setting api flags to false'
    );

    const nextState = isReplaceEntity ? defaultEntityStateShape : state;
    return {
      ...nextState,
      isFetching: false,
      isError: false,
    };
  }

  return state;
};

export const pagingReducer = handleActions(
  {
    [commonActions.api.entities.clear.request]: reducerClearFn,
    [pagingEntityActions.api.expGalaxyBeneficiaryV2.paging.clear.request]:
      reducerClearFn,
    [pagingEntityActions.api.expGalaxyBeneficiaryV2.paging.clear.error.request]:
      reducerClearErrorFn,

    [commonActions.entities.clear.request]: reducerClearFn,
    [pagingEntityActions.galaxyBeneficiary.paging.clear.request]:
      reducerClearFn,
    [pagingEntityActions.galaxyBeneficiary.paging.clear.error.request]:
      reducerClearErrorFn,
    [beneficiaryListActions.api.expGalaxyBeneficiaryV2.beneficiaryList.post
      .request]:
      'paging' === 'beneficiaryList' ? reducerRequestFn : state => state,
    [beneficiaryListActions.api.expGalaxyBeneficiaryV2.beneficiaryList.post
      .receive]: reducerReceiveFn,
    [beneficiaryListActions.api.expGalaxyBeneficiaryV2.beneficiaryList.post
      .error]: 'paging' === 'beneficiaryList' ? reducerErrorFn : state => state,

    [beneficiaryListActions.galaxyBeneficiary.retrieveBeneficiaries.request]:
      'paging' === 'beneficiaryList' ? reducerRequestFn : state => state,
    [beneficiaryListActions.galaxyBeneficiary.retrieveBeneficiaries.receive]:
      reducerReceiveFn,
    [beneficiaryListActions.galaxyBeneficiary.retrieveBeneficiaries.error]:
      'paging' === 'beneficiaryList' ? reducerErrorFn : state => state,
  },
  defaultEntityStateShape
);
