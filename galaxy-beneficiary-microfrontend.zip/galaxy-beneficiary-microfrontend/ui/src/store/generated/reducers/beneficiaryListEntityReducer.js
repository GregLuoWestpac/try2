/* eslint-disable no-constant-condition, no-self-compare, no-console */

import { handleActions } from 'redux-actions';
import { cloneDeep, includes, isArray, merge, uniq } from 'lodash';

import {
  defaultEntityStateShape,
  reducerRequestFn,
  reducerErrorFn,
  reducerClearFn,
  reducerClearErrorFn,
} from './common';

import { commonActions } from '../actions/commonActions';
import { beneficiaryListEntityActions } from '../actions/beneficiaryListEntityActions';
import { beneficiaryListActions } from '../actions/beneficiaryListActions';

const reducerReceiveFn = (state = {}, action) => {
  const {
    payload: { entities },
    meta,
    meta: { meta: metaData },
  } = action;

  if (metaData && metaData.fileDownloadSuccess) {
    return {
      ...state,
      isFetching: false,
      isError: false,
    };
  }

  const replaceEntities = metaData ? metaData.replaceEntities : null;
  const isReplaceEntity =
    isArray(replaceEntities) && includes(replaceEntities, 'beneficiaryList');

  console.debug(
    'Reducer :: beneficiaryList :: action=',
    action,
    'state=',
    state,
    'meta=',
    meta,
    'isReplaceEntity=',
    isReplaceEntity
  );

  if (
    // Act on this entity being a primary entity of the action
    includes(meta.entities.primary, 'beneficiaryList') ||
    // Act on this entity being a secondary entity of the action
    includes(meta.entities.secondary, 'beneficiaryList')
  ) {
    console.debug(
      'Reducer :: beneficiaryList :: has matched primary or secondary entity'
    );

    // TODO: Figure out how to handle state updates
    // for read-only applications
    // Since the payload is always spread along-with
    // existing state, stale data is not removed from
    // the store

    // merge() mutates so we create a deepClone first
    const currentById = cloneDeep(state.byId);

    const result = isReplaceEntity
      ? {
          byId: entities.beneficiaryList.byId,
          allIds: entities.beneficiaryList.allIds,
          isFetching: false,
          isError: false,
        }
      : {
          byId: merge(currentById, entities.beneficiaryList.byId),
          allIds: uniq([...state.allIds, ...entities.beneficiaryList.allIds]),
          isFetching: false,
          isError: false,
        };

    console.debug('Reducer :: beneficiaryList :: returning:', result);

    return result;
  }

  // TODO: Should there be handlers for other 2xx status codes?
  // Possible use cases could be to do with file uploads

  // This block ensures that a 204 response (no payload) still sets the
  // api status flags back to normal since 20X still means success and
  // a completion of the request
  if (meta.resource === 'beneficiaryList' && meta.statusCode === 204) {
    console.debug(
      'Reducer :: beneficiaryList :: 204 response, setting api flags to false'
    );

    const nextState = isReplaceEntity ? defaultEntityStateShape : state;
    return {
      ...nextState,
      isFetching: false,
      isError: false,
    };
  }

  return state;
};

export const beneficiaryListReducer = handleActions(
  {
    [commonActions.api.entities.clear.request]: reducerClearFn,
    [beneficiaryListEntityActions.api.expGalaxyBeneficiaryV2.beneficiaryList
      .clear.request]: reducerClearFn,
    [beneficiaryListEntityActions.api.expGalaxyBeneficiaryV2.beneficiaryList
      .clear.error.request]: reducerClearErrorFn,

    [commonActions.entities.clear.request]: reducerClearFn,
    [beneficiaryListEntityActions.galaxyBeneficiary.beneficiaryList.clear
      .request]: reducerClearFn,
    [beneficiaryListEntityActions.galaxyBeneficiary.beneficiaryList.clear.error
      .request]: reducerClearErrorFn,
    [beneficiaryListActions.api.expGalaxyBeneficiaryV2.beneficiaryList.post
      .request]:
      'beneficiaryList' === 'beneficiaryList'
        ? reducerRequestFn
        : state => state,
    [beneficiaryListActions.api.expGalaxyBeneficiaryV2.beneficiaryList.post
      .receive]: reducerReceiveFn,
    [beneficiaryListActions.api.expGalaxyBeneficiaryV2.beneficiaryList.post
      .error]:
      'beneficiaryList' === 'beneficiaryList' ? reducerErrorFn : state => state,

    [beneficiaryListActions.galaxyBeneficiary.retrieveBeneficiaries.request]:
      'beneficiaryList' === 'beneficiaryList'
        ? reducerRequestFn
        : state => state,
    [beneficiaryListActions.galaxyBeneficiary.retrieveBeneficiaries.receive]:
      reducerReceiveFn,
    [beneficiaryListActions.galaxyBeneficiary.retrieveBeneficiaries.error]:
      'beneficiaryList' === 'beneficiaryList' ? reducerErrorFn : state => state,
  },
  defaultEntityStateShape
);
