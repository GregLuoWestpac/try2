/* eslint-disable no-constant-condition, no-self-compare, no-console */

import { handleActions } from 'redux-actions';
import { cloneDeep, includes, isArray, merge, uniq } from 'lodash';

import {
  defaultEntityStateShape,
  reducerRequestFn,
  reducerErrorFn,
  reducerClearFn,
  reducerClearErrorFn,
} from './common';

import { commonActions } from '../actions/commonActions';
import { beneficiaryDetailsEntityActions } from '../actions/beneficiaryDetailsEntityActions';
import { beneficiaryDetailsActions } from '../actions/beneficiaryDetailsActions';

const reducerReceiveFn = (state = {}, action) => {
  const {
    payload: { entities },
    meta,
    meta: { meta: metaData },
  } = action;

  if (metaData && metaData.fileDownloadSuccess) {
    return {
      ...state,
      isFetching: false,
      isError: false,
    };
  }

  const replaceEntities = metaData ? metaData.replaceEntities : null;
  const isReplaceEntity =
    isArray(replaceEntities) && includes(replaceEntities, 'beneficiaryDetails');

  console.debug(
    'Reducer :: beneficiaryDetails :: action=',
    action,
    'state=',
    state,
    'meta=',
    meta,
    'isReplaceEntity=',
    isReplaceEntity
  );

  if (
    // Act on this entity being a primary entity of the action
    includes(meta.entities.primary, 'beneficiaryDetails') ||
    // Act on this entity being a secondary entity of the action
    includes(meta.entities.secondary, 'beneficiaryDetails')
  ) {
    console.debug(
      'Reducer :: beneficiaryDetails :: has matched primary or secondary entity'
    );

    // TODO: Figure out how to handle state updates
    // for read-only applications
    // Since the payload is always spread along-with
    // existing state, stale data is not removed from
    // the store

    // merge() mutates so we create a deepClone first
    const currentById = cloneDeep(state.byId);

    const result = isReplaceEntity
      ? {
          byId: entities.beneficiaryDetails.byId,
          allIds: entities.beneficiaryDetails.allIds,
          isFetching: false,
          isError: false,
        }
      : {
          byId: merge(currentById, entities.beneficiaryDetails.byId),
          allIds: uniq([
            ...state.allIds,
            ...entities.beneficiaryDetails.allIds,
          ]),
          isFetching: false,
          isError: false,
        };

    console.debug('Reducer :: beneficiaryDetails :: returning:', result);

    return result;
  }

  // TODO: Should there be handlers for other 2xx status codes?
  // Possible use cases could be to do with file uploads

  // This block ensures that a 204 response (no payload) still sets the
  // api status flags back to normal since 20X still means success and
  // a completion of the request
  if (meta.resource === 'beneficiaryDetails' && meta.statusCode === 204) {
    console.debug(
      'Reducer :: beneficiaryDetails :: 204 response, setting api flags to false'
    );

    const nextState = isReplaceEntity ? defaultEntityStateShape : state;
    return {
      ...nextState,
      isFetching: false,
      isError: false,
    };
  }

  return state;
};

export const beneficiaryDetailsReducer = handleActions(
  {
    [commonActions.api.entities.clear.request]: reducerClearFn,
    [beneficiaryDetailsEntityActions.api.expGalaxyBeneficiaryV2
      .beneficiaryDetails.clear.request]: reducerClearFn,
    [beneficiaryDetailsEntityActions.api.expGalaxyBeneficiaryV2
      .beneficiaryDetails.clear.error.request]: reducerClearErrorFn,

    [commonActions.entities.clear.request]: reducerClearFn,
    [beneficiaryDetailsEntityActions.galaxyBeneficiary.beneficiaryDetails.clear
      .request]: reducerClearFn,
    [beneficiaryDetailsEntityActions.galaxyBeneficiary.beneficiaryDetails.clear
      .error.request]: reducerClearErrorFn,
    [beneficiaryDetailsActions.api.expGalaxyBeneficiaryV2.beneficiaryDetails
      .post.request]:
      'beneficiaryDetails' === 'beneficiaryDetails'
        ? reducerRequestFn
        : state => state,
    [beneficiaryDetailsActions.api.expGalaxyBeneficiaryV2.beneficiaryDetails
      .post.receive]: reducerReceiveFn,
    [beneficiaryDetailsActions.api.expGalaxyBeneficiaryV2.beneficiaryDetails
      .post.error]:
      'beneficiaryDetails' === 'beneficiaryDetails'
        ? reducerErrorFn
        : state => state,

    [beneficiaryDetailsActions.galaxyBeneficiary.retrieveBeneficiary.request]:
      'beneficiaryDetails' === 'beneficiaryDetails'
        ? reducerRequestFn
        : state => state,
    [beneficiaryDetailsActions.galaxyBeneficiary.retrieveBeneficiary.receive]:
      reducerReceiveFn,
    [beneficiaryDetailsActions.galaxyBeneficiary.retrieveBeneficiary.error]:
      'beneficiaryDetails' === 'beneficiaryDetails'
        ? reducerErrorFn
        : state => state,
  },
  defaultEntityStateShape
);
