export const defaultEntityStateShape = {
  byId: {},
  allIds: [],
};

export const reducerRequestFn = state => ({
  ...state,
  isFetching: true,
  isError: false,
});

export const reducerErrorFn = (state, { payload: { error } }) => ({
  ...state,
  isFetching: false,
  isError: true,
  error,
});

export const reducerClearFn = () => ({ ...defaultEntityStateShape });

export const reducerClearErrorFn = state => ({
  ...state,
  isError: false,
  error: null,
});
