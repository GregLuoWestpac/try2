import { get } from 'lodash';
import { createSelector } from '@mep-ui/framework';

// get all beneficiaryArchive (byId, allIds)
export const getBeneficiaryArchiveSlice = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.beneficiaryArchive', null);

// gets either id and returns it as array, or ids props (if both are given, ids overrides singular id)
const propIds = (state, { id, ids }) => ids || (id ? [id] : null);

// get all beneficiaryArchive data from store
export const getBeneficiaryArchiveIds = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.beneficiaryArchive.allIds', []);

export const getBeneficiaryArchiveById = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.beneficiaryArchive.byId', {});

// get all beneficiaryArchive as nested array shape
export const getAllBeneficiaryArchive = createSelector(
  [getBeneficiaryArchiveIds, getBeneficiaryArchiveById],
  (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
);

// get beneficiaryArchive by id/ids
export const getBeneficiaryArchiveFromPropIds = () =>
  createSelector([propIds, getBeneficiaryArchiveById], (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
  );

export const isBeneficiaryArchiveFetching = createSelector(
  [getBeneficiaryArchiveSlice],
  slice => (slice ? slice.isFetching : null)
);

export const isBeneficiaryArchiveError = createSelector(
  [getBeneficiaryArchiveSlice],
  slice => (slice ? slice.isError : null)
);
