import { get } from 'lodash';
import { createSelector } from '@mep-ui/framework';

// get all beneficiaryDetails (byId, allIds)
export const getBeneficiaryDetailsSlice = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.beneficiaryDetails', null);

// gets either id and returns it as array, or ids props (if both are given, ids overrides singular id)
const propIds = (state, { id, ids }) => ids || (id ? [id] : null);

// get all beneficiaryDetails data from store
export const getBeneficiaryDetailsIds = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.beneficiaryDetails.allIds', []);

export const getBeneficiaryDetailsById = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.beneficiaryDetails.byId', {});

// get all beneficiaryDetails as nested array shape
export const getAllBeneficiaryDetails = createSelector(
  [getBeneficiaryDetailsIds, getBeneficiaryDetailsById],
  (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
);

// get beneficiaryDetails by id/ids
export const getBeneficiaryDetailsFromPropIds = () =>
  createSelector([propIds, getBeneficiaryDetailsById], (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
  );

export const isBeneficiaryDetailsFetching = createSelector(
  [getBeneficiaryDetailsSlice],
  slice => (slice ? slice.isFetching : null)
);

export const isBeneficiaryDetailsError = createSelector(
  [getBeneficiaryDetailsSlice],
  slice => (slice ? slice.isError : null)
);
