import { get } from 'lodash';
import { createSelector } from '@mep-ui/framework';

// get all aliasLookup (byId, allIds)
export const getAliasLookupSlice = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.aliasLookup', null);

// gets either id and returns it as array, or ids props (if both are given, ids overrides singular id)
const propIds = (state, { id, ids }) => ids || (id ? [id] : null);

// get all aliasLookup data from store
export const getAliasLookupIds = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.aliasLookup.allIds', []);

export const getAliasLookupById = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.aliasLookup.byId', {});

// get all aliasLookup as nested array shape
export const getAllAliasLookup = createSelector(
  [getAliasLookupIds, getAliasLookupById],
  (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
);

// get aliasLookup by id/ids
export const getAliasLookupFromPropIds = () =>
  createSelector([propIds, getAliasLookupById], (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
  );

export const isAliasLookupFetching = createSelector(
  [getAliasLookupSlice],
  slice => (slice ? slice.isFetching : null)
);

export const isAliasLookupError = createSelector([getAliasLookupSlice], slice =>
  slice ? slice.isError : null
);
