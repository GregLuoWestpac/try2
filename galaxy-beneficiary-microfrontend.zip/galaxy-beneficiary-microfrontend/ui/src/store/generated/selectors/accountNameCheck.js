import { get } from 'lodash';
import { createSelector } from '@mep-ui/framework';

// get all accountNameCheck (byId, allIds)
export const getAccountNameCheckSlice = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.accountNameCheck', null);

// gets either id and returns it as array, or ids props (if both are given, ids overrides singular id)
const propIds = (state, { id, ids }) => ids || (id ? [id] : null);

// get all accountNameCheck data from store
export const getAccountNameCheckIds = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.accountNameCheck.allIds', []);

export const getAccountNameCheckById = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.accountNameCheck.byId', {});

// get all accountNameCheck as nested array shape
export const getAllAccountNameCheck = createSelector(
  [getAccountNameCheckIds, getAccountNameCheckById],
  (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
);

// get accountNameCheck by id/ids
export const getAccountNameCheckFromPropIds = () =>
  createSelector([propIds, getAccountNameCheckById], (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
  );

export const isAccountNameCheckFetching = createSelector(
  [getAccountNameCheckSlice],
  slice => (slice ? slice.isFetching : null)
);

export const isAccountNameCheckError = createSelector(
  [getAccountNameCheckSlice],
  slice => (slice ? slice.isError : null)
);
