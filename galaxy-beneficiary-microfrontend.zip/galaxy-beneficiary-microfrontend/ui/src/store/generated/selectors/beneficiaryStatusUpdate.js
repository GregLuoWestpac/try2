import { get } from 'lodash';
import { createSelector } from '@mep-ui/framework';

// get all beneficiaryStatusUpdate (byId, allIds)
export const getBeneficiaryStatusUpdateSlice = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.beneficiaryStatusUpdate', null);

// gets either id and returns it as array, or ids props (if both are given, ids overrides singular id)
const propIds = (state, { id, ids }) => ids || (id ? [id] : null);

// get all beneficiaryStatusUpdate data from store
export const getBeneficiaryStatusUpdateIds = state =>
  get(
    state,
    'entities.expGalaxyBeneficiaryV2.beneficiaryStatusUpdate.allIds',
    []
  );

export const getBeneficiaryStatusUpdateById = state =>
  get(
    state,
    'entities.expGalaxyBeneficiaryV2.beneficiaryStatusUpdate.byId',
    {}
  );

// get all beneficiaryStatusUpdate as nested array shape
export const getAllBeneficiaryStatusUpdate = createSelector(
  [getBeneficiaryStatusUpdateIds, getBeneficiaryStatusUpdateById],
  (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
);

// get beneficiaryStatusUpdate by id/ids
export const getBeneficiaryStatusUpdateFromPropIds = () =>
  createSelector(
    [propIds, getBeneficiaryStatusUpdateById],
    (ids, entitiesById) =>
      ids && entitiesById ? ids.map(id => entitiesById[id]) : []
  );

export const isBeneficiaryStatusUpdateFetching = createSelector(
  [getBeneficiaryStatusUpdateSlice],
  slice => (slice ? slice.isFetching : null)
);

export const isBeneficiaryStatusUpdateError = createSelector(
  [getBeneficiaryStatusUpdateSlice],
  slice => (slice ? slice.isError : null)
);
