import { get } from 'lodash';
import { createSelector } from '@mep-ui/framework';

// get all divisionList (byId, allIds)
export const getDivisionListSlice = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.divisionList', null);

// gets either id and returns it as array, or ids props (if both are given, ids overrides singular id)
const propIds = (state, { id, ids }) => ids || (id ? [id] : null);

// get all divisionList data from store
export const getDivisionListIds = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.divisionList.allIds', []);

export const getDivisionListById = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.divisionList.byId', {});

// get all divisionList as nested array shape
export const getAllDivisionList = createSelector(
  [getDivisionListIds, getDivisionListById],
  (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
);

// get divisionList by id/ids
export const getDivisionListFromPropIds = () =>
  createSelector([propIds, getDivisionListById], (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
  );

export const isDivisionListFetching = createSelector(
  [getDivisionListSlice],
  slice => (slice ? slice.isFetching : null)
);

export const isDivisionListError = createSelector(
  [getDivisionListSlice],
  slice => (slice ? slice.isError : null)
);
