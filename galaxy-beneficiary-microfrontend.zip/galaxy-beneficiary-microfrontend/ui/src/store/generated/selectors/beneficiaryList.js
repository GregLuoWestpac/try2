import { get } from 'lodash';
import { createSelector } from '@mep-ui/framework';

// get all beneficiaryList (byId, allIds)
export const getBeneficiaryListSlice = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.beneficiaryList', null);

// gets either id and returns it as array, or ids props (if both are given, ids overrides singular id)
const propIds = (state, { id, ids }) => ids || (id ? [id] : null);

// get all beneficiaryList data from store
export const getBeneficiaryListIds = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.beneficiaryList.allIds', []);

export const getBeneficiaryListById = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.beneficiaryList.byId', {});

// get all beneficiaryList as nested array shape
export const getAllBeneficiaryList = createSelector(
  [getBeneficiaryListIds, getBeneficiaryListById],
  (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
);

// get beneficiaryList by id/ids
export const getBeneficiaryListFromPropIds = () =>
  createSelector([propIds, getBeneficiaryListById], (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
  );

export const isBeneficiaryListFetching = createSelector(
  [getBeneficiaryListSlice],
  slice => (slice ? slice.isFetching : null)
);

export const isBeneficiaryListError = createSelector(
  [getBeneficiaryListSlice],
  slice => (slice ? slice.isError : null)
);
