import { get } from 'lodash';
import { createSelector } from '@mep-ui/framework';

// get all bsbLookup (byId, allIds)
export const getBsbLookupSlice = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.bsbLookup', null);

// gets either id and returns it as array, or ids props (if both are given, ids overrides singular id)
const propIds = (state, { id, ids }) => ids || (id ? [id] : null);

// get all bsbLookup data from store
export const getBsbLookupIds = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.bsbLookup.allIds', []);

export const getBsbLookupById = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.bsbLookup.byId', {});

// get all bsbLookup as nested array shape
export const getAllBsbLookup = createSelector(
  [getBsbLookupIds, getBsbLookupById],
  (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
);

// get bsbLookup by id/ids
export const getBsbLookupFromPropIds = () =>
  createSelector([propIds, getBsbLookupById], (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
  );

export const isBsbLookupFetching = createSelector([getBsbLookupSlice], slice =>
  slice ? slice.isFetching : null
);

export const isBsbLookupError = createSelector([getBsbLookupSlice], slice =>
  slice ? slice.isError : null
);
