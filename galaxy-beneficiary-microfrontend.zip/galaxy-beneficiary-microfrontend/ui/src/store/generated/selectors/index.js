import { get, join, trim } from 'lodash';

// TODO: Need to check for getBrandSelector if to useGlobalSelector
import {
  logger,
  getBrand,
  getConfig,
  getSsoToken,
  createSelector,
  isProspectRoute,
  getIdpSegmentFromUrl,
} from '@mep-ui/framework';

export {
  getAllBeneficiaryCreate,
  getBeneficiaryCreateIds,
  getBeneficiaryCreateById,
  isBeneficiaryCreateError,
  getBeneficiaryCreateSlice,
  isBeneficiaryCreateFetching,
  getBeneficiaryCreateFromPropIds,
} from './beneficiaryCreate';

export {
  getAllBeneficiaryList,
  getBeneficiaryListIds,
  getBeneficiaryListById,
  isBeneficiaryListError,
  getBeneficiaryListSlice,
  isBeneficiaryListFetching,
  getBeneficiaryListFromPropIds,
} from './beneficiaryList';

export {
  getAllPaging,
  getPagingIds,
  getPagingById,
  isPagingError,
  getPagingSlice,
  isPagingFetching,
  getPagingFromPropIds,
} from './paging';

export {
  getAllBeneficiaryUpdate,
  getBeneficiaryUpdateIds,
  getBeneficiaryUpdateById,
  isBeneficiaryUpdateError,
  getBeneficiaryUpdateSlice,
  isBeneficiaryUpdateFetching,
  getBeneficiaryUpdateFromPropIds,
} from './beneficiaryUpdate';

export {
  getAllBeneficiaryDetails,
  getBeneficiaryDetailsIds,
  getBeneficiaryDetailsById,
  isBeneficiaryDetailsError,
  getBeneficiaryDetailsSlice,
  isBeneficiaryDetailsFetching,
  getBeneficiaryDetailsFromPropIds,
} from './beneficiaryDetails';

export {
  getAllBeneficiaryArchive,
  getBeneficiaryArchiveIds,
  getBeneficiaryArchiveById,
  isBeneficiaryArchiveError,
  getBeneficiaryArchiveSlice,
  isBeneficiaryArchiveFetching,
  getBeneficiaryArchiveFromPropIds,
} from './beneficiaryArchive';

export {
  getAllBeneficiaryStatusUpdate,
  getBeneficiaryStatusUpdateIds,
  getBeneficiaryStatusUpdateById,
  isBeneficiaryStatusUpdateError,
  getBeneficiaryStatusUpdateSlice,
  isBeneficiaryStatusUpdateFetching,
  getBeneficiaryStatusUpdateFromPropIds,
} from './beneficiaryStatusUpdate';

export {
  getAllAliasLookup,
  getAliasLookupIds,
  getAliasLookupById,
  isAliasLookupError,
  getAliasLookupSlice,
  isAliasLookupFetching,
  getAliasLookupFromPropIds,
} from './aliasLookup';

export {
  getAllBsbLookup,
  getBsbLookupIds,
  getBsbLookupById,
  isBsbLookupError,
  getBsbLookupSlice,
  isBsbLookupFetching,
  getBsbLookupFromPropIds,
} from './bsbLookup';

export {
  getAllDivisionList,
  getDivisionListIds,
  getDivisionListById,
  isDivisionListError,
  getDivisionListSlice,
  isDivisionListFetching,
  getDivisionListFromPropIds,
} from './divisionList';

export {
  getAllAccountNameCheck,
  getAccountNameCheckIds,
  getAccountNameCheckById,
  isAccountNameCheckError,
  getAccountNameCheckSlice,
  isAccountNameCheckFetching,
  getAccountNameCheckFromPropIds,
} from './accountNameCheck';

export const getApiBaseUrl = createSelector([getConfig], config =>
  get(config, 'apiBaseUrl', null)
);

export const getApiBasePath = createSelector([getConfig], config =>
  get(config, 'exp-galaxy-beneficiary-basePath', null)
);

const getApiConfig = createSelector([getConfig], config =>
  get(config, 'api', null)
);

const getApiBasePathConfig = createSelector([getApiConfig], apiConfig =>
  get(apiConfig, 'basePath', null)
);

const getApiBaseUrlConfig = createSelector(
  [getApiConfig, getBrand],
  (apiConfig, brand) =>
    get(apiConfig, `baseUrl.${brand}`, null) || get(apiConfig, 'baseUrl', null)
);

const getApiGateway = createSelector([getApiConfig], apiConfig =>
  get(apiConfig, 'gateway', null)
);

const getApiJunction = createSelector([getApiConfig], apiConfig =>
  get(apiConfig, 'junction', null)
);

const getBFFBasePath = createSelector([getApiConfig], apiConfig =>
  get(apiConfig, 'bffBasePath', null)
);

const getPublicApiGateway = createSelector([getApiConfig], apiConfig => {
  return get(apiConfig, 'publicGateway', null);
});

const getLegacyConfigSupport = createSelector([getApiConfig], apiConfig => {
  return get(apiConfig, 'useLegacyConfig', false);
});

const getRole = createSelector([getSsoToken], token =>
  get(token, 'role', null)
);

const substituteUserCommunity = (value, role) => {
  const isThirdParty = role === 'thirdparty';
  const userCommunity = isProspectRoute()
    ? isThirdParty
      ? 'thirdparty'
      : 'prospect'
    : 'customer';

  return value?.replace('{userCommunity}', userCommunity);
};

const substituteBrand = gateway => {
  const siteNameList = window.location.hostname.split('.');

  /**
   * Assuming brand name will always be the third last element in the hostname
   * e.g. mesh.westpac.com.au, sit1.banking.stgeorge.com.au
   */
  const brandName =
    siteNameList.length > 2 ? siteNameList[siteNameList.length - 3] : 'westpac';

  return gateway?.replace('{brand}', brandName);
};

const getApiBasePathWithoutUsingJunction = basePathConfig => {
  const idpSegment = getIdpSegmentFromUrl();
  const basePathToken = trim('/exp/galaxy/beneficiary/v2', '/').replace(
    /\//g,
    '-'
  );

  const idpSegmentedBasePath = get(
    basePathConfig,
    `${basePathToken}.${idpSegment}`
  );
  const defaultBasePath = get(basePathConfig, basePathToken);

  const basePath = idpSegmentedBasePath || defaultBasePath;
  return basePath;
};

const getApiBasePathUsingJunction = (apiJunction, bffBasePath, role) => {
  // No '{userCommunity}' substitution required in path for local and staff junction
  if (apiJunction !== 'customer') return bffBasePath;

  // Substitute '{userCommunity}' in path for customer junction only e.g. "/exp/{userCommunity}/showcase/capabilities/v2"
  return substituteUserCommunity(bffBasePath, role);
};

const getApiBaseUrlWithoutUsingJunction = baseUrlConfig => {
  const idpSegment = getIdpSegmentFromUrl();
  const baseUrlToken = trim('/exp/galaxy/beneficiary/v2', '/').replace(
    /\//g,
    '-'
  );

  const idpSegmentedBaseUrl = get(
    baseUrlConfig,
    `${baseUrlToken}.${idpSegment}`
  );
  const defaultBaseUrl = get(baseUrlConfig, baseUrlToken);

  const baseUrl = idpSegmentedBaseUrl || defaultBaseUrl;
  logger.trace('## redux-artifacts/selector', `baseUrl => ${baseUrl}`);

  return baseUrl;
};

const getApiBaseUrlUsingJunction = (apiJunction, apiGateway, role) => {
  let apiGatewayConnection = apiGateway;

  // No '{userCommunity}' or '{brand}' substitution required for local and staff junction
  if (apiJunction === 'local' || apiJunction === 'staff') {
    logger.trace(
      '## redux-artifacts/selector',
      `apiGateway => ${apiGatewayConnection}`
    );
    return apiGatewayConnection;
  }

  /**
   * Substitute '{userCommunity}' and '{brand}' in gateway for customer junction
   * e.g. "gw-{userCommunity}.dev1.api.{brand}.com.au"
   */
  apiGatewayConnection = substituteUserCommunity(apiGatewayConnection, role);
  apiGatewayConnection = substituteBrand(apiGatewayConnection);

  logger.trace(
    '## redux-artifacts/selector',
    `apiGateway => ${apiGatewayConnection}`
  );

  return apiGatewayConnection;
};

export const getCustomisedApiBasePath = createSelector(
  [
    getApiBasePathConfig,
    getApiJunction,
    getBFFBasePath,
    getRole,
    getLegacyConfigSupport,
  ],
  (basePathConfig, apiJunction, bffBasePath, role, useLegacyConfig) => {
    const basePath =
      apiJunction && bffBasePath && !useLegacyConfig
        ? getApiBasePathUsingJunction(apiJunction, bffBasePath, role)
        : getApiBasePathWithoutUsingJunction(basePathConfig);

    logger.trace('## redux-artifacts/selector', `basePath => ${basePath}`);
    return basePath;
  }
);

export const getCustomisedApiBaseUrl = createSelector(
  [
    getApiBaseUrlConfig,
    getApiJunction,
    getApiGateway,
    getRole,
    getLegacyConfigSupport,
  ],
  (baseUrlConfig, apiJunction, apiGateway, role, useLegacyConfig) => {
    const gateway =
      apiJunction && apiGateway && !useLegacyConfig
        ? getApiBaseUrlUsingJunction(apiJunction, apiGateway, role)
        : getApiBaseUrlWithoutUsingJunction(baseUrlConfig);

    return gateway;
  }
);

export const getCustomisedPublicApiGateway = createSelector(
  [getPublicApiGateway],
  publicApiGateway => {
    // Return empty value when gateway is invalid
    if (!publicApiGateway) return '';

    /**
     * Substitute '{brand}' in gateway for public junction
     * e.g. "//gw-public.sit1.api.{brand}.com.au/pub/showcase/demo/v1/"
     */
    const publicGatewayConnection = substituteBrand(publicApiGateway);

    logger.trace(
      '## redux-artifacts/selector',
      `publicGatewayConnection => ${publicGatewayConnection}`
    );

    return publicGatewayConnection;
  }
);

export const getBeneficiaryCreateUrl = createSelector(
  [getCustomisedApiBaseUrl, getCustomisedApiBasePath],
  (apiBaseUrl, apiBasePath) =>
    join([apiBaseUrl, apiBasePath, 'beneficiaryCreate'], '')
);
export const getBeneficiaryListUrl = createSelector(
  [getCustomisedApiBaseUrl, getCustomisedApiBasePath],
  (apiBaseUrl, apiBasePath) =>
    join([apiBaseUrl, apiBasePath, 'beneficiaryList'], '')
);
export const getBeneficiaryDetailsUrl = createSelector(
  [getCustomisedApiBaseUrl, getCustomisedApiBasePath],
  (apiBaseUrl, apiBasePath) =>
    join([apiBaseUrl, apiBasePath, 'beneficiaryDetails'], '')
);
export const getBeneficiaryArchiveUrl = createSelector(
  [getCustomisedApiBaseUrl, getCustomisedApiBasePath],
  (apiBaseUrl, apiBasePath) =>
    join([apiBaseUrl, apiBasePath, 'beneficiaryArchive'], '')
);
export const getBeneficiaryStatusUpdateUrl = createSelector(
  [getCustomisedApiBaseUrl, getCustomisedApiBasePath],
  (apiBaseUrl, apiBasePath) =>
    join([apiBaseUrl, apiBasePath, 'beneficiaryStatusUpdate'], '')
);
export const getAliasLookupUrl = createSelector(
  [getCustomisedApiBaseUrl, getCustomisedApiBasePath],
  (apiBaseUrl, apiBasePath) =>
    join([apiBaseUrl, apiBasePath, 'aliasLookup'], '')
);
export const getAccountNameCheckUrl = createSelector(
  [getCustomisedApiBaseUrl, getCustomisedApiBasePath],
  (apiBaseUrl, apiBasePath) =>
    join([apiBaseUrl, apiBasePath, 'accountNameCheck'], '')
);
