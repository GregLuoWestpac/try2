import { get } from 'lodash';
import { createSelector } from '@mep-ui/framework';

// get all beneficiaryCreate (byId, allIds)
export const getBeneficiaryCreateSlice = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.beneficiaryCreate', null);

// gets either id and returns it as array, or ids props (if both are given, ids overrides singular id)
const propIds = (state, { id, ids }) => ids || (id ? [id] : null);

// get all beneficiaryCreate data from store
export const getBeneficiaryCreateIds = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.beneficiaryCreate.allIds', []);

export const getBeneficiaryCreateById = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.beneficiaryCreate.byId', {});

// get all beneficiaryCreate as nested array shape
export const getAllBeneficiaryCreate = createSelector(
  [getBeneficiaryCreateIds, getBeneficiaryCreateById],
  (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
);

// get beneficiaryCreate by id/ids
export const getBeneficiaryCreateFromPropIds = () =>
  createSelector([propIds, getBeneficiaryCreateById], (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
  );

export const isBeneficiaryCreateFetching = createSelector(
  [getBeneficiaryCreateSlice],
  slice => (slice ? slice.isFetching : null)
);

export const isBeneficiaryCreateError = createSelector(
  [getBeneficiaryCreateSlice],
  slice => (slice ? slice.isError : null)
);
