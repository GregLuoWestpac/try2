import { get } from 'lodash';
import { createSelector } from '@mep-ui/framework';

// get all beneficiaryUpdate (byId, allIds)
export const getBeneficiaryUpdateSlice = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.beneficiaryUpdate', null);

// gets either id and returns it as array, or ids props (if both are given, ids overrides singular id)
const propIds = (state, { id, ids }) => ids || (id ? [id] : null);

// get all beneficiaryUpdate data from store
export const getBeneficiaryUpdateIds = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.beneficiaryUpdate.allIds', []);

export const getBeneficiaryUpdateById = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.beneficiaryUpdate.byId', {});

// get all beneficiaryUpdate as nested array shape
export const getAllBeneficiaryUpdate = createSelector(
  [getBeneficiaryUpdateIds, getBeneficiaryUpdateById],
  (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
);

// get beneficiaryUpdate by id/ids
export const getBeneficiaryUpdateFromPropIds = () =>
  createSelector([propIds, getBeneficiaryUpdateById], (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
  );

export const isBeneficiaryUpdateFetching = createSelector(
  [getBeneficiaryUpdateSlice],
  slice => (slice ? slice.isFetching : null)
);

export const isBeneficiaryUpdateError = createSelector(
  [getBeneficiaryUpdateSlice],
  slice => (slice ? slice.isError : null)
);
