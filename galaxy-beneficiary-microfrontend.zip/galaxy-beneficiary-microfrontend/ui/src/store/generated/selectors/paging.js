import { get } from 'lodash';
import { createSelector } from '@mep-ui/framework';

// get all paging (byId, allIds)
export const getPagingSlice = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.paging', null);

// gets either id and returns it as array, or ids props (if both are given, ids overrides singular id)
const propIds = (state, { id, ids }) => ids || (id ? [id] : null);

// get all paging data from store
export const getPagingIds = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.paging.allIds', []);

export const getPagingById = state =>
  get(state, 'entities.expGalaxyBeneficiaryV2.paging.byId', {});

// get all paging as nested array shape
export const getAllPaging = createSelector(
  [getPagingIds, getPagingById],
  (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
);

// get paging by id/ids
export const getPagingFromPropIds = () =>
  createSelector([propIds, getPagingById], (ids, entitiesById) =>
    ids && entitiesById ? ids.map(id => entitiesById[id]) : []
  );

export const isPagingFetching = createSelector([getPagingSlice], slice =>
  slice ? slice.isFetching : null
);

export const isPagingError = createSelector([getPagingSlice], slice =>
  slice ? slice.isError : null
);
