import { createDispatchHook, createSelectorHook } from '@mep-ui/framework';
import { beneficiaryArchiveActions } from '../actions';
import {
  isBeneficiaryArchiveFetching,
  isBeneficiaryArchiveError,
} from '../selectors';

export const useArchiveBeneficiaries = (store, selector) => {
  const useDispatch = createDispatchHook(store.contextRef);
  const useSelector = createSelectorHook(store.contextRef);

  const dispatch = useDispatch();

  const isFetching = useSelector(isBeneficiaryArchiveFetching);
  const isError = useSelector(isBeneficiaryArchiveError);

  const data = useSelector(state => {
    return selector && selector(state);
  });

  const archiveBeneficiaries = (params, options) =>
    dispatch(
      beneficiaryArchiveActions.galaxyBeneficiary.archiveBeneficiaries.request(
        params,
        options
      )
    );

  return {
    isFetching,
    isError,
    archiveBeneficiaries,
    ...(selector && data),
  };
};
