import { createDispatchHook, createSelectorHook } from '@mep-ui/framework';
import { beneficiaryListActions } from '../actions';
import {
  isBeneficiaryListFetching,
  isBeneficiaryListError,
} from '../selectors';

export const useRetrieveBeneficiaries = (store, selector) => {
  const useDispatch = createDispatchHook(store.contextRef);
  const useSelector = createSelectorHook(store.contextRef);

  const dispatch = useDispatch();

  const isFetching = useSelector(isBeneficiaryListFetching);
  const isError = useSelector(isBeneficiaryListError);

  const data = useSelector(state => {
    return selector && selector(state);
  });

  const retrieveBeneficiaries = (params, options) =>
    dispatch(
      beneficiaryListActions.galaxyBeneficiary.retrieveBeneficiaries.request(
        params,
        options
      )
    );

  return {
    isFetching,
    isError,
    retrieveBeneficiaries,
    ...(selector && data),
  };
};
