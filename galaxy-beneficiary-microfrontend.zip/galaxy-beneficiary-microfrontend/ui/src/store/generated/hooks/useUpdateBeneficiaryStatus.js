import { createDispatchHook, createSelectorHook } from '@mep-ui/framework';
import { beneficiaryStatusUpdateActions } from '../actions';
import {
  isBeneficiaryStatusUpdateFetching,
  isBeneficiaryStatusUpdateError,
} from '../selectors';

export const useUpdateBeneficiaryStatus = (store, selector) => {
  const useDispatch = createDispatchHook(store.contextRef);
  const useSelector = createSelectorHook(store.contextRef);

  const dispatch = useDispatch();

  const isFetching = useSelector(isBeneficiaryStatusUpdateFetching);
  const isError = useSelector(isBeneficiaryStatusUpdateError);

  const data = useSelector(state => {
    return selector && selector(state);
  });

  const updateBeneficiaryStatus = (params, options) =>
    dispatch(
      beneficiaryStatusUpdateActions.galaxyBeneficiary.updateBeneficiaryStatus.request(
        params,
        options
      )
    );

  return {
    isFetching,
    isError,
    updateBeneficiaryStatus,
    ...(selector && data),
  };
};
