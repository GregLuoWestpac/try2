import { createDispatchHook, createSelectorHook } from '@mep-ui/framework';
import { accountNameCheckActions } from '../actions';
import {
  isAccountNameCheckFetching,
  isAccountNameCheckError,
} from '../selectors';

export const usePostAccountNameCheck = (store, selector) => {
  const useDispatch = createDispatchHook(store.contextRef);
  const useSelector = createSelectorHook(store.contextRef);

  const dispatch = useDispatch();

  const isFetching = useSelector(isAccountNameCheckFetching);
  const isError = useSelector(isAccountNameCheckError);

  const data = useSelector(state => {
    return selector && selector(state);
  });

  const postAccountNameCheck = (params, options) =>
    dispatch(
      accountNameCheckActions.galaxyBeneficiary.postAccountNameCheck.request(
        params,
        options
      )
    );

  return {
    isFetching,
    isError,
    postAccountNameCheck,
    ...(selector && data),
  };
};
