import { createDispatchHook, createSelectorHook } from '@mep-ui/framework';
import { bsbLookupActions } from '../actions';
import { isBsbLookupFetching, isBsbLookupError } from '../selectors';

export const useGetBsbLookup = (store, selector) => {
  const useDispatch = createDispatchHook(store.contextRef);
  const useSelector = createSelectorHook(store.contextRef);

  const dispatch = useDispatch();

  const isFetching = useSelector(isBsbLookupFetching);
  const isError = useSelector(isBsbLookupError);

  const data = useSelector(state => {
    return selector && selector(state);
  });

  const getBsbLookup = (params, options) =>
    dispatch(
      bsbLookupActions.galaxyBeneficiary.getBsbLookup.request(params, options)
    );

  return {
    isFetching,
    isError,
    getBsbLookup,
    ...(selector && data),
  };
};
