import { createDispatchHook, createSelectorHook } from '@mep-ui/framework';
import { beneficiaryDetailsActions } from '../actions';
import {
  isBeneficiaryDetailsFetching,
  isBeneficiaryDetailsError,
} from '../selectors';

export const useRetrieveBeneficiary = (store, selector) => {
  const useDispatch = createDispatchHook(store.contextRef);
  const useSelector = createSelectorHook(store.contextRef);

  const dispatch = useDispatch();

  const isFetching = useSelector(isBeneficiaryDetailsFetching);
  const isError = useSelector(isBeneficiaryDetailsError);

  const data = useSelector(state => {
    return selector && selector(state);
  });

  const retrieveBeneficiary = (params, options) =>
    dispatch(
      beneficiaryDetailsActions.galaxyBeneficiary.retrieveBeneficiary.request(
        params,
        options
      )
    );

  return {
    isFetching,
    isError,
    retrieveBeneficiary,
    ...(selector && data),
  };
};
