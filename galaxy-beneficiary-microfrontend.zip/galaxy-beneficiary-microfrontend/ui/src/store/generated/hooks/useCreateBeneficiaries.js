import { createDispatchHook, createSelectorHook } from '@mep-ui/framework';
import { beneficiaryCreateActions } from '../actions';
import {
  isBeneficiaryCreateFetching,
  isBeneficiaryCreateError,
} from '../selectors';

export const useCreateBeneficiaries = (store, selector) => {
  const useDispatch = createDispatchHook(store.contextRef);
  const useSelector = createSelectorHook(store.contextRef);

  const dispatch = useDispatch();

  const isFetching = useSelector(isBeneficiaryCreateFetching);
  const isError = useSelector(isBeneficiaryCreateError);

  const data = useSelector(state => {
    return selector && selector(state);
  });

  const createBeneficiaries = (params, options) =>
    dispatch(
      beneficiaryCreateActions.galaxyBeneficiary.createBeneficiaries.request(
        params,
        options
      )
    );

  return {
    isFetching,
    isError,
    createBeneficiaries,
    ...(selector && data),
  };
};
