import { createDispatchHook, createSelectorHook } from '@mep-ui/framework';
import { beneficiaryUpdateActions } from '../actions';
import {
  isBeneficiaryUpdateFetching,
  isBeneficiaryUpdateError,
} from '../selectors';

export const useUpdateBeneficiary = (store, selector) => {
  const useDispatch = createDispatchHook(store.contextRef);
  const useSelector = createSelectorHook(store.contextRef);

  const dispatch = useDispatch();

  const isFetching = useSelector(isBeneficiaryUpdateFetching);
  const isError = useSelector(isBeneficiaryUpdateError);

  const data = useSelector(state => {
    return selector && selector(state);
  });

  const updateBeneficiary = (params, options) =>
    dispatch(
      beneficiaryUpdateActions.galaxyBeneficiary.updateBeneficiary.request(
        params,
        options
      )
    );

  return {
    isFetching,
    isError,
    updateBeneficiary,
    ...(selector && data),
  };
};
