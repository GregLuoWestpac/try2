import { createDispatchHook, createSelectorHook } from '@mep-ui/framework';
import { aliasLookupActions } from '../actions';
import { isAliasLookupFetching, isAliasLookupError } from '../selectors';

export const usePostAliasLookup = (store, selector) => {
  const useDispatch = createDispatchHook(store.contextRef);
  const useSelector = createSelectorHook(store.contextRef);

  const dispatch = useDispatch();

  const isFetching = useSelector(isAliasLookupFetching);
  const isError = useSelector(isAliasLookupError);

  const data = useSelector(state => {
    return selector && selector(state);
  });

  const postAliasLookup = (params, options) =>
    dispatch(
      aliasLookupActions.galaxyBeneficiary.postAliasLookup.request(
        params,
        options
      )
    );

  return {
    isFetching,
    isError,
    postAliasLookup,
    ...(selector && data),
  };
};
