import { createDispatchHook, createSelectorHook } from '@mep-ui/framework';
import { divisionListActions } from '../actions';
import { isDivisionListFetching, isDivisionListError } from '../selectors';

export const useGetDivisionList = (store, selector) => {
  const useDispatch = createDispatchHook(store.contextRef);
  const useSelector = createSelectorHook(store.contextRef);

  const dispatch = useDispatch();

  const isFetching = useSelector(isDivisionListFetching);
  const isError = useSelector(isDivisionListError);

  const data = useSelector(state => {
    return selector && selector(state);
  });

  const getDivisionList = (params, options) =>
    dispatch(
      divisionListActions.galaxyBeneficiary.getDivisionList.request(
        params,
        options
      )
    );

  return {
    isFetching,
    isError,
    getDivisionList,
    ...(selector && data),
  };
};
