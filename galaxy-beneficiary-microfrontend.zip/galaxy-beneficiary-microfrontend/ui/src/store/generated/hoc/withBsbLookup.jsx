import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

import { isEqual, isFunction } from 'lodash';

import { connect } from '@mep-ui/framework';

import { bsbLookupActions } from '../actions/bsbLookupActions';

// TODO: Should we move isFetching and isError
// from entity based selectors to resource based selectors
import { isBsbLookupError, isBsbLookupFetching } from '../selectors/bsbLookup';

import { getDisplayName } from '../helpers/common';

export const withBsbLookup =
  (context, paramsCreator, optsCreator) => WrappedComponent => {
    class WithBsbLookup extends PureComponent {
      static propTypes = {
        requestBsbLookup: PropTypes.func.isRequired,
        isFetching: PropTypes.bool,
        isError: PropTypes.bool,
      };

      static defaultProps = {
        isFetching: false,
        isError: false,
      };

      state = { params: {}, options: {} };

      componentDidMount() {
        this.loadBsbLookupData(this.props);
      }

      componentWillReceiveProps(nextProps) {
        const { meta: newMeta, ...newParams } = this.getParams(
          paramsCreator,
          nextProps
        );
        const { meta: oldMeta, ...oldParams } = this.getParams(
          paramsCreator,
          this.props
        );

        const { ...newOptions } = this.getOptions(optsCreator, nextProps);
        const { ...oldOptions } = this.getOptions(optsCreator, this.props);

        // Adding a condition to check params as well as options in case the params
        // don't change but the xBrandIdOverride does
        const shouldLoadData =
          !isEqual(newParams, oldParams) || !isEqual(newOptions, oldOptions);

        if (shouldLoadData) {
          this.loadBsbLookupData(nextProps);
        }
      }

      getParams = (paramFn, props) =>
        isFunction(paramFn)
          ? paramFn.call(null, this.state, props)
          : paramFn || {};

      getOptions = (optionFn, props) =>
        isFunction(optionFn)
          ? optionFn.call(null, this.state, props)
          : optionFn || {};

      loadBsbLookupData = props => {
        const { requestBsbLookup } = props;

        const params = this.getParams(paramsCreator, props);
        const options = this.getOptions(optsCreator, props);

        this.setState({ params, options });

        if (requestBsbLookup) {
          requestBsbLookup(params, options);
        }
      };

      onRetry = () => {
        this.loadBsbLookupData(this.props);
      };

      render() {
        // The individual wrapped components should deal with UI of what to show if there is no pages
        return <WrappedComponent onRetry={this.onRetry} {...this.props} />;
      }
    }

    // Set displayName for debugging
    WithBsbLookup.displayName = `WithBsbLookup(${getDisplayName(
      WrappedComponent
    )})`;

    // MFE actions needs to be registered on a MFE specific store.
    // If application pass the store context, same would be passed to connect options
    const connectOptions = context ? { context } : {};

    /**
     * isFetching should depend on all entities isFetching flag
     */
    return connect(
      state => ({
        isFetching: isBsbLookupFetching(state),
        isError: isBsbLookupError(state),
      }),
      {
        requestBsbLookup:
          bsbLookupActions.galaxyBeneficiary.getBsbLookup.request,
      },
      null,
      { ...connectOptions }
    )(WithBsbLookup);
  };
