import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

import { isEqual, isFunction } from 'lodash';

import { connect } from '@mep-ui/framework';

import { beneficiaryCreateActions } from '../actions/beneficiaryCreateActions';

// TODO: Should we move isFetching and isError
// from entity based selectors to resource based selectors
import {
  isBeneficiaryCreateError,
  isBeneficiaryCreateFetching,
} from '../selectors/beneficiaryCreate';

import { getDisplayName } from '../helpers/common';
