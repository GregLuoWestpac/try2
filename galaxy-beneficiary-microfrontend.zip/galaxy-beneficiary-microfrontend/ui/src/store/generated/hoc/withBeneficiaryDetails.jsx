import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

import { isEqual, isFunction } from 'lodash';

import { connect } from '@mep-ui/framework';

import { beneficiaryDetailsActions } from '../actions/beneficiaryDetailsActions';

// TODO: Should we move isFetching and isError
// from entity based selectors to resource based selectors
import {
  isBeneficiaryDetailsError,
  isBeneficiaryDetailsFetching,
} from '../selectors/beneficiaryDetails';

import { getDisplayName } from '../helpers/common';
