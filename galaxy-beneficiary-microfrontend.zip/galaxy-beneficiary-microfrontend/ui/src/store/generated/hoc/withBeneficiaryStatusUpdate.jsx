import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

import { isEqual, isFunction } from 'lodash';

import { connect } from '@mep-ui/framework';

import { beneficiaryStatusUpdateActions } from '../actions/beneficiaryStatusUpdateActions';

// TODO: Should we move isFetching and isError
// from entity based selectors to resource based selectors
import {
  isBeneficiaryStatusUpdateError,
  isBeneficiaryStatusUpdateFetching,
} from '../selectors/beneficiaryStatusUpdate';

import { getDisplayName } from '../helpers/common';
