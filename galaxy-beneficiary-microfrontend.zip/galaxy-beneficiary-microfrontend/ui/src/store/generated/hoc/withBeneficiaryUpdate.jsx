import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

import { isEqual, isFunction } from 'lodash';

import { connect } from '@mep-ui/framework';

import { beneficiaryUpdateActions } from '../actions/beneficiaryUpdateActions';

// TODO: Should we move isFetching and isError
// from entity based selectors to resource based selectors
import {
  isBeneficiaryUpdateError,
  isBeneficiaryUpdateFetching,
} from '../selectors/beneficiaryUpdate';

import { getDisplayName } from '../helpers/common';
