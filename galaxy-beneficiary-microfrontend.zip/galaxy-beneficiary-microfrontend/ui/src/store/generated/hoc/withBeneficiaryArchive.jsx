import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

import { isEqual, isFunction } from 'lodash';

import { connect } from '@mep-ui/framework';

import { beneficiaryArchiveActions } from '../actions/beneficiaryArchiveActions';

// TODO: Should we move isFetching and isError
// from entity based selectors to resource based selectors
import {
  isBeneficiaryArchiveError,
  isBeneficiaryArchiveFetching,
} from '../selectors/beneficiaryArchive';

import { getDisplayName } from '../helpers/common';
