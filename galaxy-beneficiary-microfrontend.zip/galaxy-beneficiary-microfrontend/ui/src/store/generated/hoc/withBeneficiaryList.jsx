import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

import { isEqual, isFunction } from 'lodash';

import { connect } from '@mep-ui/framework';

import { beneficiaryListActions } from '../actions/beneficiaryListActions';

// TODO: Should we move isFetching and isError
// from entity based selectors to resource based selectors
import {
  isBeneficiaryListError,
  isBeneficiaryListFetching,
} from '../selectors/beneficiaryList';

import { getDisplayName } from '../helpers/common';
