import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

import { isEqual, isFunction } from 'lodash';

import { connect } from '@mep-ui/framework';

import { accountNameCheckActions } from '../actions/accountNameCheckActions';

// TODO: Should we move isFetching and isError
// from entity based selectors to resource based selectors
import {
  isAccountNameCheckError,
  isAccountNameCheckFetching,
} from '../selectors/accountNameCheck';

import { getDisplayName } from '../helpers/common';
