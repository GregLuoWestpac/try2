import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

import { isEqual, isFunction } from 'lodash';

import { connect } from '@mep-ui/framework';

import { aliasLookupActions } from '../actions/aliasLookupActions';

// TODO: Should we move isFetching and isError
// from entity based selectors to resource based selectors
import {
  isAliasLookupError,
  isAliasLookupFetching,
} from '../selectors/aliasLookup';

import { getDisplayName } from '../helpers/common';
