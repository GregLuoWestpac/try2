import { get } from 'lodash';

// { all, fork } are applicable to only mutations
import { all, put, call, fork, select } from 'redux-saga/effects';

import { divisionListActions } from '../actions/divisionListActions';

import { getDivisionList } from '../services';
import {
  formatData,
  isBrandIdOverridden,
  getRootParentsByEntityId,
} from '../helpers/common';

import {
  getApiBaseUrl,
  getApiBasePath,
  getCustomisedApiBaseUrl,
  getCustomisedApiBasePath,
} from '../selectors';

export function* getDivisionListData(action) {
  const {
    payload: { options: payloadOptions = {}, pathParams, params },
    meta,
  } = action;
  // Ability for applications to pass custom headers
  const { headers: customHeaders = {} } = payloadOptions || {};

  const withSafiParam = '' || null;
  const withCredentials = !!withSafiParam;

  const isApiInNamespace = /^api\//.test(action.type);
  let dispatchApiError;

  if (isApiInNamespace) {
    dispatchApiError =
      divisionListActions.api.expGalaxyBeneficiaryV2.divisionList.get.error;
  } else {
    dispatchApiError =
      divisionListActions.galaxyBeneficiary.getDivisionList.error;
  }

  try {
    const resource = 'divisionList';
    const resourcePath = 'divisionList';

    const apiBaseUrl = yield select(getApiBaseUrl);
    const apiBasePath = yield select(getApiBasePath);

    const customisedBaseUrl = yield select(getCustomisedApiBaseUrl);
    const customisedBasePath = yield select(getCustomisedApiBasePath);

    const baseUrl = customisedBaseUrl || apiBaseUrl;
    const basePath = customisedBasePath || apiBasePath;

    const url = baseUrl && basePath ? `${baseUrl}${basePath}` : '';

    if (url) {
      const safiHeaderParams = {};
      let devicePermissions;

      let dispatchApiResponse;
      if (isApiInNamespace) {
        dispatchApiResponse =
          divisionListActions.api.expGalaxyBeneficiaryV2.divisionList.get
            .receive;
      } else {
        dispatchApiResponse =
          divisionListActions.galaxyBeneficiary.getDivisionList.receive;
      }

      const options = {
        ...payloadOptions,
        ...safiHeaderParams,
        applicationId: 'A017EC',
        headers: customHeaders,
        withCredentials,
      };

      const {
        data: response,
        headers,
        status,
      } = yield call(
        getDivisionList,
        url,
        { path: pathParams, query: params },
        options
      );
      const formattedResponse = formatData(response);

      /**
       * Enhance the original response metadata with a flag to indicate
       * whether the `x-BrandId` was overridden for the request
       */
      const metadata = {
        ...meta,
        xBrandIdOverrideApplied: isBrandIdOverridden(),
      };

      yield put(
        dispatchApiResponse(formattedResponse, status, resource, metadata)
      );
    } else {
      yield put(
        dispatchApiError(
          { message: `Malformed url :: ${baseUrl}${basePath}${resourcePath}` },
          meta
        )
      );
    }
  } catch (exception) {
    yield put(dispatchApiError({ ...exception }, meta));
    if (withCredentials) {
      yield put({ type: 'SAFI/UPDATE', payload: { ...exception } });
    }
  }
}
