import { get } from 'lodash';

// { all, fork } are applicable to only mutations
import { all, put, call, fork, select } from 'redux-saga/effects';

import { bsbLookupActions } from '../actions/bsbLookupActions';

import { getBsbLookup } from '../services';
import {
  formatData,
  isBrandIdOverridden,
  getRootParentsByEntityId,
} from '../helpers/common';

import {
  getApiBaseUrl,
  getApiBasePath,
  getCustomisedApiBaseUrl,
  getCustomisedApiBasePath,
} from '../selectors';

export function* getBsbLookupData(action) {
  const {
    payload: { options: payloadOptions = {}, pathParams, params },
    meta,
  } = action;
  // Ability for applications to pass custom headers
  const { headers: customHeaders = {} } = payloadOptions || {};

  const withSafiParam = '' || null;
  const withCredentials = !!withSafiParam;

  const isApiInNamespace = /^api\//.test(action.type);
  let dispatchApiError;

  if (isApiInNamespace) {
    dispatchApiError =
      bsbLookupActions.api.expGalaxyBeneficiaryV2.bsbLookup.get.error;
  } else {
    dispatchApiError = bsbLookupActions.galaxyBeneficiary.getBsbLookup.error;
  }

  try {
    const resource = 'bsbLookup';
    const resourcePath = 'bsbLookup';

    const apiBaseUrl = yield select(getApiBaseUrl);
    const apiBasePath = yield select(getApiBasePath);

    const customisedBaseUrl = yield select(getCustomisedApiBaseUrl);
    const customisedBasePath = yield select(getCustomisedApiBasePath);

    const baseUrl = customisedBaseUrl || apiBaseUrl;
    const basePath = customisedBasePath || apiBasePath;

    const url = baseUrl && basePath ? `${baseUrl}${basePath}` : '';

    if (url) {
      const safiHeaderParams = {};
      let devicePermissions;

      let dispatchApiResponse;
      if (isApiInNamespace) {
        dispatchApiResponse =
          bsbLookupActions.api.expGalaxyBeneficiaryV2.bsbLookup.get.receive;
      } else {
        dispatchApiResponse =
          bsbLookupActions.galaxyBeneficiary.getBsbLookup.receive;
      }

      const options = {
        ...payloadOptions,
        ...safiHeaderParams,
        applicationId: 'A017EC',
        headers: customHeaders,
        withCredentials,
      };

      const {
        data: response,
        headers,
        status,
      } = yield call(
        getBsbLookup,
        url,
        { path: pathParams, query: params },
        options
      );
      const formattedResponse = formatData(response);

      /**
       * Enhance the original response metadata with a flag to indicate
       * whether the `x-BrandId` was overridden for the request
       */
      const metadata = {
        ...meta,
        xBrandIdOverrideApplied: isBrandIdOverridden(),
      };

      yield put(
        dispatchApiResponse(formattedResponse, status, resource, metadata)
      );
    } else {
      yield put(
        dispatchApiError(
          { message: `Malformed url :: ${baseUrl}${basePath}${resourcePath}` },
          meta
        )
      );
    }
  } catch (exception) {
    yield put(dispatchApiError({ ...exception }, meta));
    if (withCredentials) {
      yield put({ type: 'SAFI/UPDATE', payload: { ...exception } });
    }
  }
}
