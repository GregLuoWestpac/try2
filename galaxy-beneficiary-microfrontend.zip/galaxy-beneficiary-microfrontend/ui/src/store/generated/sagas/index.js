import { all, takeEvery } from 'redux-saga/effects';

import { postBeneficiaryCreateData } from './beneficiaryCreate.saga';

import { beneficiaryCreateActions } from '../actions/beneficiaryCreateActions';
import { postBeneficiaryListData } from './beneficiaryList.saga';

import { beneficiaryListActions } from '../actions/beneficiaryListActions';
import { putBeneficiaryUpdateData } from './beneficiaryUpdate.saga';

import { beneficiaryUpdateActions } from '../actions/beneficiaryUpdateActions';
import { postBeneficiaryDetailsData } from './beneficiaryDetails.saga';

import { beneficiaryDetailsActions } from '../actions/beneficiaryDetailsActions';
import { postBeneficiaryArchiveData } from './beneficiaryArchive.saga';

import { beneficiaryArchiveActions } from '../actions/beneficiaryArchiveActions';
import { postBeneficiaryStatusUpdateData } from './beneficiaryStatusUpdate.saga';

import { beneficiaryStatusUpdateActions } from '../actions/beneficiaryStatusUpdateActions';
import { postAliasLookupData } from './aliasLookup.saga';

import { aliasLookupActions } from '../actions/aliasLookupActions';
import { getBsbLookupData } from './bsbLookup.saga';

import { bsbLookupActions } from '../actions/bsbLookupActions';
import { getDivisionListData } from './divisionList.saga';

import { divisionListActions } from '../actions/divisionListActions';
import { postAccountNameCheckData } from './accountNameCheck.saga';

import { accountNameCheckActions } from '../actions/accountNameCheckActions';

export function* rootExportSaga() {
  yield all([
    yield takeEvery(
      [
        beneficiaryCreateActions.api.expGalaxyBeneficiaryV2.beneficiaryCreate
          .post.request,
        beneficiaryCreateActions.galaxyBeneficiary.createBeneficiaries.request,
      ],
      postBeneficiaryCreateData
    ),
    yield takeEvery(
      [
        beneficiaryListActions.api.expGalaxyBeneficiaryV2.beneficiaryList.post
          .request,
        beneficiaryListActions.galaxyBeneficiary.retrieveBeneficiaries.request,
      ],
      postBeneficiaryListData
    ),
    yield takeEvery(
      [
        beneficiaryUpdateActions.api.expGalaxyBeneficiaryV2.beneficiaryUpdate
          .put.request,
        beneficiaryUpdateActions.galaxyBeneficiary.updateBeneficiary.request,
      ],
      putBeneficiaryUpdateData
    ),
    yield takeEvery(
      [
        beneficiaryDetailsActions.api.expGalaxyBeneficiaryV2.beneficiaryDetails
          .post.request,
        beneficiaryDetailsActions.galaxyBeneficiary.retrieveBeneficiary.request,
      ],
      postBeneficiaryDetailsData
    ),
    yield takeEvery(
      [
        beneficiaryArchiveActions.api.expGalaxyBeneficiaryV2.beneficiaryArchive
          .post.request,
        beneficiaryArchiveActions.galaxyBeneficiary.archiveBeneficiaries
          .request,
      ],
      postBeneficiaryArchiveData
    ),
    yield takeEvery(
      [
        beneficiaryStatusUpdateActions.api.expGalaxyBeneficiaryV2
          .beneficiaryStatusUpdate.post.request,
        beneficiaryStatusUpdateActions.galaxyBeneficiary.updateBeneficiaryStatus
          .request,
      ],
      postBeneficiaryStatusUpdateData
    ),
    yield takeEvery(
      [
        aliasLookupActions.api.expGalaxyBeneficiaryV2.aliasLookup.post.request,
        aliasLookupActions.galaxyBeneficiary.postAliasLookup.request,
      ],
      postAliasLookupData
    ),
    yield takeEvery(
      [
        bsbLookupActions.api.expGalaxyBeneficiaryV2.bsbLookup.get.request,
        bsbLookupActions.galaxyBeneficiary.getBsbLookup.request,
      ],
      getBsbLookupData
    ),
    yield takeEvery(
      [
        divisionListActions.api.expGalaxyBeneficiaryV2.divisionList.get.request,
        divisionListActions.galaxyBeneficiary.getDivisionList.request,
      ],
      getDivisionListData
    ),
    yield takeEvery(
      [
        accountNameCheckActions.api.expGalaxyBeneficiaryV2.accountNameCheck.post
          .request,
        accountNameCheckActions.galaxyBeneficiary.postAccountNameCheck.request,
      ],
      postAccountNameCheckData
    ),
  ]);
}
