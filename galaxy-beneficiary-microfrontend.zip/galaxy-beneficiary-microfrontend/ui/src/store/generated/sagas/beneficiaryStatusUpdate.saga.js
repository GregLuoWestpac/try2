import { get } from 'lodash';

// { all, fork } are applicable to only mutations
import { all, put, call, fork, select } from 'redux-saga/effects';

import { beneficiaryStatusUpdateActions } from '../actions/beneficiaryStatusUpdateActions';

import { updateBeneficiaryStatus } from '../services';
import {
  formatData,
  isBrandIdOverridden,
  getRootParentsByEntityId,
} from '../helpers/common';

import {
  getApiBaseUrl,
  getApiBasePath,
  getCustomisedApiBaseUrl,
  getCustomisedApiBasePath,
} from '../selectors';

export function* postBeneficiaryStatusUpdateData(action) {
  const {
    payload: { options: payloadOptions = {}, pathParams, params, query },
    meta,
  } = action;
  // Ability for applications to pass custom headers
  const { headers: customHeaders = {} } = payloadOptions || {};

  // set default settings to mergedMeta
  let mergedMeta = { refreshMethod: 'SIMPLE' };
  if (meta) {
    // We need to keep following line before try catch block
    mergedMeta = Object.assign({}, mergedMeta, meta);
  }

  const withSafiParam = '' || null;
  const withCredentials = !!withSafiParam;
  let dispatchApiResponse, dispatchApiError, dispatchRequest;
  const isApiInNamespace = /^api\//.test(action.type);

  if (isApiInNamespace) {
    dispatchApiResponse =
      beneficiaryStatusUpdateActions.api.expGalaxyBeneficiaryV2
        .beneficiaryStatusUpdate.post.receive;
    dispatchApiError =
      beneficiaryStatusUpdateActions.api.expGalaxyBeneficiaryV2
        .beneficiaryStatusUpdate.post.error;
    dispatchRequest = get(
      beneficiaryStatusUpdateActions.api.expGalaxyBeneficiaryV2
        .beneficiaryStatusUpdate.get,
      'request',
      null
    );
  } else {
    dispatchApiResponse =
      beneficiaryStatusUpdateActions.galaxyBeneficiary.updateBeneficiaryStatus
        .receive;
    dispatchApiError =
      beneficiaryStatusUpdateActions.galaxyBeneficiary.updateBeneficiaryStatus
        .error;
  }

  try {
    const resource = 'beneficiaryStatusUpdate';
    const resourcePath = 'beneficiaryStatusUpdate';

    const apiBaseUrl = yield select(getApiBaseUrl);
    const apiBasePath = yield select(getApiBasePath);

    const customisedBaseUrl = yield select(getCustomisedApiBaseUrl);
    const customisedBasePath = yield select(getCustomisedApiBasePath);

    const targetBaseUrl = customisedBaseUrl || apiBaseUrl;
    const targetBasePath = customisedBasePath || apiBasePath;

    const url =
      targetBaseUrl && targetBasePath
        ? `${targetBaseUrl}${targetBasePath}`
        : '';

    if (url) {
      const safiHeaderParams = {};
      let devicePermissions;

      const options = {
        ...payloadOptions,
        ...safiHeaderParams,
        applicationId: 'A017EC',
        customHeaders,
        withCredentials,
      };

      // In api.js we map from
      // export const post = (url, payload, params) => apiClient.post(url, payload, { params }).catch(handleError);
      // which will call axios.post(url [, params [, config]]);
      const {
        data: response,
        status,
        headers,
      } = yield call(
        updateBeneficiaryStatus,
        url,
        { path: pathParams, query, body: params },
        options
      );
      const formattedResponse = response ? formatData(response) : {};

      /**
       * Enhance the original response metadata with a flag to indicate
       * whether the `x-BrandId` was overridden for the request
       */
      const metadata = {
        ...mergedMeta,
        xBrandIdOverrideApplied: isBrandIdOverridden(),
      };

      yield put(
        dispatchApiResponse(formattedResponse, status, resource, metadata)
      );

      const { refreshMethod } = metadata;
      console.debug(`refreshMethod :: ${refreshMethod}`);

      switch (refreshMethod.toUpperCase()) {
        // Removing AUTO refreshMethod, as currently entityMap relationship is WIP.
        // currently no use case to use AUTO mode, so entityMap is hard-coded.
        case 'NONE':
          // We don't take action here
          break;
        case 'SIMPLE':
        default:
          if (dispatchRequest) {
            yield put(dispatchRequest({ pathParams, ...query }));
          }

          break;
      }
    } else {
      yield put(
        dispatchApiError(
          {
            message: `Malformed url :: ${targetBaseUrl}${targetBasePath}${resourcePath}`,
          },
          mergedMeta
        )
      );
    }
  } catch (exception) {
    yield put(dispatchApiError({ ...exception }, mergedMeta));
    if (withCredentials) {
      yield put({ type: 'SAFI/UPDATE', payload: { ...exception } });
    }
  }
}
