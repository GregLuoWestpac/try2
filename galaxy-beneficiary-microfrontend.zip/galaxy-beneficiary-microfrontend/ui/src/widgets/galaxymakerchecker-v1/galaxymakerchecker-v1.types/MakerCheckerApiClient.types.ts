export type ExpApiName =
  | 'getApprovalWorkflowDetails'
  | 'postApprovalWorkflowConsent'
  | 'postApprovalWorkflowList'
  | 'postAuthorisationIdCreate'
  | 'getActivitySummary'
  | 'getActivityList';

type RequestParams = {
  /** request path parameters */
  path?: Record<string, string>;
  /** request query parameters */
  query?: Record<string, any>;
  /** request body */
  body?: Record<string, any>;
};

type RequestOptions = {
  headers?: Record<string, string>;
  withCredentials?: boolean;
  [key: string]: any;
};

export type ServiceFunction = (
  url: string,
  params: RequestParams,
  options: RequestOptions
) => Promise<any>;

export type ApiCallDetails = {
  /** can be found in maker checker widget's openapi.yml */
  apiName: ExpApiName;
  params: RequestParams;
  /** Value that triggers the API call when changed. */
  trigger: string | number;
  options?: RequestOptions;
};

/**
 * type of config provided by withWidget wrapper,
 * which is sourced from `${widgetBasePath}/env/app-config.json`
 */
export type AppConfig = {
  appId: string;
  appName: string;
  api: {
    basicAuthKey: string;
    baseUrl: Record<string, string>;
    basePath: Record<string, string>;
  };
};

export type MakerCheckerApiClientProps = ApiCallDetails & {
  /** provides isLoading status, and also api details for debugging if showExplicitApiCallUpdate is true */
  onApiCallUpdate?: (data: {
    apiCallDetails?: ApiCallDetails;
    isLoading: boolean;
  }) => void;
  onApiResponse?: (data: any) => void;
  onApiError?: (err: any) => void;
  /** include ApiCallDetails in onApiCallUpdate callback */
  enableVerboseUpdate?: boolean;
  /** coming from withWidget wrapper */
  config?: AppConfig;
};
