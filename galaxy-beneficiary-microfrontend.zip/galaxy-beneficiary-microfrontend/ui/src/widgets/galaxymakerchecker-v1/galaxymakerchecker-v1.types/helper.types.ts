/** this file contains types which are based on the original types copied from widget */

import {
  PostApprovalWorkflowListData,
  GetApprovalWorkflowDetailsData,
} from './galaxyMakerCheckerExp.types';

export type InnerTypeNonNullable<T, Key extends keyof T> = Exclude<
  T[Key],
  undefined
>;
export type ArrayElement<T> = T extends (infer U)[] ? U : never;

/**
 * ApprovalWorkflow from PostApprovalWorkflowListData
 */
export type ApprovalWorkflow = ArrayElement<
  InnerTypeNonNullable<
    InnerTypeNonNullable<PostApprovalWorkflowListData, 'entities'>,
    'approvalWorkflowList'
  >
>;

/**
 * approvalWorkflowDetail from GetApprovalWorkflowDetailsData
 */
export type ApprovalWorkflowDetail = ArrayElement<
  InnerTypeNonNullable<
    InnerTypeNonNullable<GetApprovalWorkflowDetailsData, 'entities'>,
    'approvalWorkflowDetails'
  >
>;
