/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable import/no-unresolved */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import { FC, lazy, memo } from 'react';
import { WidgetBoundary, useManifest } from '@mep-ui/framework';
import isEmpty from 'lodash/isEmpty';
import { getWidgetManifest } from '../util';
import { MakerCheckerApiClientProps } from './galaxymakerchecker-v1.types';

const MakerCheckerApiClient = lazy(
  () =>
    // @ts-expect-error: Module will be resolved at runtime via Module Federation
    import('galaxymakerchecker-v1/MakerCheckerApiClient')
);

const GalaxyMakerCheckerWrapperComponent: FC<MakerCheckerApiClientProps> = (
  props
) => {
  const { isLoading, isError, manifest } = useManifest('galaxy-beneficiary');
  if (isError) {
    return 'Error occurred while fetching manifest';
  }
  if (isLoading || isEmpty(manifest)) {
    return null;
  }

  const widgetManifest = getWidgetManifest('galaxymakerchecker-v1', manifest);
  if (!widgetManifest) {
    console.error('Widget manifest not found for galaxy-maker-checker-v1');
    return null;
  }

  return (
    <WidgetBoundary
      // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
      // TODO: Temporarily commented out due to issues from remoteEntry.js file not being loaded correctly.
      widget={MakerCheckerApiClient}
      manifest={widgetManifest}
      {...props}
    />
  );
};
/**
 * makes sure GalaxyMakerCheckerWrapper is memoized to prevent unnecessary re-renders
 */
const GalaxyMakerCheckerWrapper = memo(GalaxyMakerCheckerWrapperComponent);

export { GalaxyMakerCheckerWrapper };
export default GalaxyMakerCheckerWrapper;

/**
 * example of usage:
 *
    <GalaxyMakerCheckerWrapper
        apiName="postApprovalWorkflowConsent"
        enableVerboseUpdate
        params={{
          path: undefined,
          query: undefined,
          body: {
            approvalWorkflowConsent: {
              approvalWorkflowId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              status: 'Approved',
              consentDatetimestamp: '2024-01-28T15:27:49.732Z',
              comment: {
                reason: 'string',
                description: 'string',
                documentId: 'string',
              },
            },
            entitlementsPayload: '{"userId":"abc123","roles":["VIEW"]}',
          },
        }}
        trigger={1}
        onApiCallUpdate={(data: any) => {
          console.log('API Call Update:', data);
        }}
        onApiResponse={(data: any) => {
          console.log('API Response:', data);
        }}
        onApiError={(err: any) => {
          console.error('API Error:', err);
        }}
      />
 */
