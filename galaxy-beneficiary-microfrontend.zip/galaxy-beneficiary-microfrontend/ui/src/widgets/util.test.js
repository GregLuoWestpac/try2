import { getWidgetManifest } from './util';

describe('getWidgetManifest', () => {
  const manifest = {
    widgets: [
      { name: 'WidgetA', source: 'sourceA.js' },
      { name: 'WidgetB', source: 'sourceB.js' },
      { name: 'WidgetC', source: 'sourceC.js' },
    ],
  };

  it('should return the correct widget manifest when widget exists', () => {
    const result = getWidgetManifest('WidgetB', manifest);
    expect(result).toEqual({ name: 'WidgetB', source: 'sourceB.js' });
  });

  it('should return undefined when widget does not exist', () => {
    const result = getWidgetManifest('WidgetX', manifest);
    expect(result).toBeUndefined();
  });

  it('should return undefined when widgets array is empty', () => {
    const emptyManifest = { widgets: [] };
    const result = getWidgetManifest('WidgetA', emptyManifest);
    expect(result).toBeUndefined();
  });

  it('should return undefined when widgets property is missing', () => {
    const noWidgetsManifest = {};
    const result = getWidgetManifest('WidgetA', noWidgetsManifest);
    expect(result).toBeUndefined();
  });

  it('should return the first matching widget if there are duplicates', () => {
    const dupManifest = {
      widgets: [
        { name: 'WidgetA', source: 'sourceA1.js' },
        { name: 'WidgetA', source: 'sourceA2.js' },
      ],
    };
    const result = getWidgetManifest('WidgetA', dupManifest);
    expect(result).toEqual({ name: 'WidgetA', source: 'sourceA1.js' });
  });
});
