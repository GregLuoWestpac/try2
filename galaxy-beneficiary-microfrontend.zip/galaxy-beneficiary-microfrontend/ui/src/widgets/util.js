/**
 * Retrieves the widget manifest config from provided manifest
 * @param {string} widgetName
 * @param {object} Manifest
 * @returns {{name: string, source: string}}
 */
export const getWidgetManifest = (widgetName, manifest) =>
  manifest?.widgets?.find((widget) => widget.name === widgetName);
