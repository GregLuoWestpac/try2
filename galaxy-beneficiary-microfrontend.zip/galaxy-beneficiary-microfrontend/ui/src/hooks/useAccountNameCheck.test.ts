/* eslint-disable @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-explicit-any */
import { renderHook, act } from '@testing-library/react';
import { useAccountNameCheck } from './useAccountNameCheck';

// Mock the mv-cop-accountname-check package
jest.mock('@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check', () => ({
  COP_COLOR_CODE: {
    BLUE: 'Blue',
    AMBER: 'Amber',
    RED: 'Red',
  },
}));

// Mock the CLOSED_ACCOUNT_CODES
jest.mock('../components/BeneficiaryForm/BeneficiaryForm.constants', () => ({
  CLOSED_ACCOUNT_CODES: ['ACNS', 'ACNS01', 'ACNS02'],
}));

describe('useAccountNameCheck', () => {
  const mockTrigger = jest.fn();
  const mockWatch = jest.fn();
  const mockGetValues = jest.fn();
  const mockClearErrors = jest.fn();
  const mockPostAccountNameCheck = jest.fn();
  const mockOnInvalidateCopCheck = jest.fn();
  const mockOnAccountValidationChange = jest.fn();

  const defaultFieldPaths = {
    bsb: 'bsb' as const,
    accountNumber: 'accountNumber' as const,
    accountName: 'accountName' as const,
    beneficiaryType: 'beneficiaryType' as const,
  };

  const createMockForm = () => ({
    trigger: mockTrigger,
    watch: mockWatch,
    getValues: mockGetValues,
    clearErrors: mockClearErrors,
  });

  beforeEach(() => {
    jest.clearAllMocks();
    mockWatch.mockImplementation((field: string) => {
      if (field === 'beneficiaryType') return 'BSB_ACCOUNT_NUMBER';
      if (field === 'bsb') return '123456';
      if (field === 'accountNumber') return '12345678';
      if (field === 'accountName') return 'Test Account';
      return '';
    });
    mockGetValues.mockImplementation((field: string) => {
      if (field === 'bsb') return '123456';
      if (field === 'accountNumber') return '12345678';
      if (field === 'accountName') return 'Test Account';
      return '';
    });
    mockTrigger.mockResolvedValue(true);
  });

  describe('initial state', () => {
    it('should return idle status initially', () => {
      const { result } = renderHook(() =>
        useAccountNameCheck({
          form: createMockForm() as any,
          fieldPaths: defaultFieldPaths,
          bsbBeneficiaryTypeValue: 'BSB_ACCOUNT_NUMBER',
        })
      );

      expect(result.current.copValidationStatus).toBe('idle');
      expect(result.current.isCheckDetailsClicked).toBe(false);
      expect(result.current.isAccountClosed).toBe(false);
    });

    it('should have empty validated field values initially', () => {
      const { result } = renderHook(() =>
        useAccountNameCheck({
          form: createMockForm() as any,
          fieldPaths: defaultFieldPaths,
          bsbBeneficiaryTypeValue: 'BSB_ACCOUNT_NUMBER',
        })
      );

      expect(result.current.validatedFieldValues.current).toEqual({
        bsb: '',
        accountNumber: '',
        accountName: '',
      });
    });
  });

  describe('handleCheckDetails', () => {
    it('should trigger field validation when Check Details is clicked', async () => {
      const { result } = renderHook(() =>
        useAccountNameCheck({
          form: createMockForm() as any,
          fieldPaths: defaultFieldPaths,
          bsbBeneficiaryTypeValue: 'BSB_ACCOUNT_NUMBER',
          postAccountNameCheck: mockPostAccountNameCheck,
        })
      );

      await act(async () => {
        await result.current.handleCheckDetails();
      });

      expect(mockTrigger).toHaveBeenCalledWith(['bsb', 'accountNumber', 'accountName']);
    });

    it('should call postAccountNameCheck when validation passes', async () => {
      mockTrigger.mockResolvedValue(true);

      const { result } = renderHook(() =>
        useAccountNameCheck({
          form: createMockForm() as any,
          fieldPaths: defaultFieldPaths,
          bsbBeneficiaryTypeValue: 'BSB_ACCOUNT_NUMBER',
          postAccountNameCheck: mockPostAccountNameCheck,
        })
      );

      await act(async () => {
        await result.current.handleCheckDetails();
      });

      expect(mockPostAccountNameCheck).toHaveBeenCalledWith({
        accountName: 'Test Account',
        accountNumber: '12345678',
        bsb: '123456',
      });
    });

    it('should not call postAccountNameCheck when validation fails', async () => {
      mockTrigger.mockResolvedValue(false);

      const { result } = renderHook(() =>
        useAccountNameCheck({
          form: createMockForm() as any,
          fieldPaths: defaultFieldPaths,
          bsbBeneficiaryTypeValue: 'BSB_ACCOUNT_NUMBER',
          postAccountNameCheck: mockPostAccountNameCheck,
        })
      );

      await act(async () => {
        await result.current.handleCheckDetails();
      });

      expect(mockPostAccountNameCheck).not.toHaveBeenCalled();
    });

    it('should set status to pending after calling postAccountNameCheck', async () => {
      const { result } = renderHook(() =>
        useAccountNameCheck({
          form: createMockForm() as any,
          fieldPaths: defaultFieldPaths,
          bsbBeneficiaryTypeValue: 'BSB_ACCOUNT_NUMBER',
          postAccountNameCheck: mockPostAccountNameCheck,
        })
      );

      await act(async () => {
        await result.current.handleCheckDetails();
      });

      expect(result.current.copValidationStatus).toBe('pending');
    });

    it('should store validated field values after successful check', async () => {
      const { result } = renderHook(() =>
        useAccountNameCheck({
          form: createMockForm() as any,
          fieldPaths: defaultFieldPaths,
          bsbBeneficiaryTypeValue: 'BSB_ACCOUNT_NUMBER',
          postAccountNameCheck: mockPostAccountNameCheck,
        })
      );

      await act(async () => {
        await result.current.handleCheckDetails();
      });

      expect(result.current.validatedFieldValues.current).toEqual({
        bsb: '123456',
        accountNumber: '12345678',
        accountName: 'Test Account',
      });
    });

    it('should set isCheckDetailsClicked when no postAccountNameCheck provided', async () => {
      const { result } = renderHook(() =>
        useAccountNameCheck({
          form: createMockForm() as any,
          fieldPaths: defaultFieldPaths,
          bsbBeneficiaryTypeValue: 'BSB_ACCOUNT_NUMBER',
          onAccountValidationChange: mockOnAccountValidationChange,
        })
      );

      await act(async () => {
        await result.current.handleCheckDetails();
      });

      expect(result.current.isCheckDetailsClicked).toBe(true);
      expect(mockOnAccountValidationChange).toHaveBeenCalledWith(true);
    });

    it('should reset lookupState.triggeredByReview on handleCheckDetails', async () => {
      const lookupState = {
        current: { triggeredByReview: true, fieldName: null as string | null },
      };

      const { result } = renderHook(() =>
        useAccountNameCheck({
          form: createMockForm() as any,
          fieldPaths: defaultFieldPaths,
          bsbBeneficiaryTypeValue: 'BSB_ACCOUNT_NUMBER',
          postAccountNameCheck: mockPostAccountNameCheck,
          lookupState,
        })
      );

      await act(async () => {
        await result.current.handleCheckDetails();
      });

      expect(lookupState.current.triggeredByReview).toBe(false);
    });
  });

  describe('copCheckResultData handling', () => {
    it('should set validated status when result is successful', async () => {
      const { result, rerender } = renderHook(
        (props) =>
          useAccountNameCheck({
            form: createMockForm() as any,
            fieldPaths: defaultFieldPaths,
            bsbBeneficiaryTypeValue: 'BSB_ACCOUNT_NUMBER',
            postAccountNameCheck: mockPostAccountNameCheck,
            ...props,
          }),
        {
          initialProps: {
            copCheckResultData: undefined as any,
            isCopLoading: false,
          },
        }
      );

      // First trigger check details to set pending state
      await act(async () => {
        await result.current.handleCheckDetails();
      });

      expect(result.current.copValidationStatus).toBe('pending');

      // Now simulate receiving successful result
      rerender({
        copCheckResultData: { matchedCOPStatusCode: 'MTCH', matchedCOPColour: 'Green' },
        isCopLoading: false,
      });

      expect(result.current.copValidationStatus).toBe('validated');
      expect(result.current.isCheckDetailsClicked).toBe(true);
    });

    it('should set closed status when account is closed', async () => {
      const { result, rerender } = renderHook(
        (props) =>
          useAccountNameCheck({
            form: createMockForm() as any,
            fieldPaths: defaultFieldPaths,
            bsbBeneficiaryTypeValue: 'BSB_ACCOUNT_NUMBER',
            postAccountNameCheck: mockPostAccountNameCheck,
            ...props,
          }),
        {
          initialProps: {
            copCheckResultData: undefined as any,
            isCopLoading: false,
          },
        }
      );

      // First trigger check details
      await act(async () => {
        await result.current.handleCheckDetails();
      });

      // Simulate receiving closed account result
      rerender({
        copCheckResultData: { matchedCOPStatusCode: 'ACNS', matchedCOPColour: 'Red' },
        isCopLoading: false,
      });

      expect(result.current.copValidationStatus).toBe('closed');
      expect(result.current.isAccountClosed).toBe(true);
    });

    it('should set closed status when matchedCOPColour is Red', async () => {
      const { result, rerender } = renderHook(
        (props) =>
          useAccountNameCheck({
            form: createMockForm() as any,
            fieldPaths: defaultFieldPaths,
            bsbBeneficiaryTypeValue: 'BSB_ACCOUNT_NUMBER',
            postAccountNameCheck: mockPostAccountNameCheck,
            ...props,
          }),
        {
          initialProps: {
            copCheckResultData: undefined as any,
            isCopLoading: false,
          },
        }
      );

      // First trigger check details
      await act(async () => {
        await result.current.handleCheckDetails();
      });

      // Simulate receiving Red status result (not in CLOSED_ACCOUNT_CODES but Red color)
      rerender({
        copCheckResultData: { matchedCOPStatusCode: 'NMTCH', matchedCOPColour: 'Red' },
        isCopLoading: false,
      });

      expect(result.current.copValidationStatus).toBe('closed');
      expect(result.current.isAccountClosed).toBe(true);
    });
  });

  describe('resetValidationState', () => {
    it('should reset all state to initial values', async () => {
      const { result, rerender } = renderHook(
        (props) =>
          useAccountNameCheck({
            form: createMockForm() as any,
            fieldPaths: defaultFieldPaths,
            bsbBeneficiaryTypeValue: 'BSB_ACCOUNT_NUMBER',
            postAccountNameCheck: mockPostAccountNameCheck,
            onAccountValidationChange: mockOnAccountValidationChange,
            ...props,
          }),
        {
          initialProps: {
            copCheckResultData: undefined as any,
            isCopLoading: false,
          },
        }
      );

      // Set up validated state
      await act(async () => {
        await result.current.handleCheckDetails();
      });

      rerender({
        copCheckResultData: { matchedCOPStatusCode: 'MTCH', matchedCOPColour: 'Green' },
        isCopLoading: false,
      });

      expect(result.current.copValidationStatus).toBe('validated');

      // Reset
      act(() => {
        result.current.resetValidationState();
      });

      expect(result.current.copValidationStatus).toBe('idle');
      expect(result.current.isCheckDetailsClicked).toBe(false);
      expect(result.current.validatedFieldValues.current).toEqual({
        bsb: '',
        accountNumber: '',
        accountName: '',
      });
      expect(mockOnAccountValidationChange).toHaveBeenCalledWith(false);
    });
  });

  describe('notifyCheckRequired', () => {
    it('should set status to checkRequired', () => {
      const { result } = renderHook(() =>
        useAccountNameCheck({
          form: createMockForm() as any,
          fieldPaths: defaultFieldPaths,
          bsbBeneficiaryTypeValue: 'BSB_ACCOUNT_NUMBER',
        })
      );

      act(() => {
        result.current.notifyCheckRequired();
      });

      expect(result.current.copValidationStatus).toBe('checkRequired');
    });
  });

  describe('field change detection', () => {
    it('should reset to idle when bsb changes after validation', async () => {
      let currentBsb = '123456';
      mockWatch.mockImplementation((field: string) => {
        if (field === 'bsb') return currentBsb;
        if (field === 'beneficiaryType') return 'BSB_ACCOUNT_NUMBER';
        if (field === 'accountNumber') return '12345678';
        if (field === 'accountName') return 'Test Account';
        return '';
      });

      const { result, rerender } = renderHook(
        (props) =>
          useAccountNameCheck({
            form: createMockForm() as any,
            fieldPaths: defaultFieldPaths,
            bsbBeneficiaryTypeValue: 'BSB_ACCOUNT_NUMBER',
            postAccountNameCheck: mockPostAccountNameCheck,
            onInvalidateCopCheck: mockOnInvalidateCopCheck,
            ...props,
          }),
        {
          initialProps: {
            copCheckResultData: undefined as any,
            isCopLoading: false,
          },
        }
      );

      // Validate first
      await act(async () => {
        await result.current.handleCheckDetails();
      });

      rerender({
        copCheckResultData: { matchedCOPStatusCode: 'MTCH', matchedCOPColour: 'Green' },
        isCopLoading: false,
      });

      expect(result.current.copValidationStatus).toBe('validated');

      // Change BSB
      currentBsb = '654321';
      rerender({
        copCheckResultData: { matchedCOPStatusCode: 'MTCH', matchedCOPColour: 'Green' },
        isCopLoading: false,
      });

      expect(result.current.copValidationStatus).toBe('idle');
      expect(mockOnInvalidateCopCheck).toHaveBeenCalled();
    });
  });

  describe('beneficiary type change', () => {
    it('should not set checkRequired when beneficiaryType is not BSB', () => {
      const beneficiaryType = 'PAYID';
      mockWatch.mockImplementation((field: string) => {
        if (field === 'beneficiaryType') return beneficiaryType;
        return '';
      });

      const lookupState = {
        current: { triggeredByReview: true, fieldName: null as string | null },
      };

      const { result } = renderHook(() =>
        useAccountNameCheck({
          form: createMockForm() as any,
          fieldPaths: defaultFieldPaths,
          bsbBeneficiaryTypeValue: 'BSB_ACCOUNT_NUMBER',
          onInvalidateCopCheck: mockOnInvalidateCopCheck,
          lookupState,
        })
      );

      expect(result.current.copValidationStatus).toBe('idle');
    });
  });

  // Note: lookupState.triggeredByReview is read imperatively by the form
  // validator (checkDetailsRequired) rather than via a useEffect, since ref
  // mutations don't trigger re-renders.
});
