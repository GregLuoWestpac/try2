/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import { renderHook, waitFor, act } from '@testing-library/react';
import { useOrganisationId } from './useOrganisationId';

// Mock functions for dependencies - declared before jest.mock() calls
const mockUsePlatformState = jest.fn();
const mockIsLocalUrl = jest.fn();
const mockUseGlobalSelector = jest.fn();

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  usePlatformState: jest.fn((...args: unknown[]) =>
    mockUsePlatformState(...args)
  ),
}));

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  isLocalUrl: () => mockIsLocalUrl(),
  useGlobalSelector: (selector: any) => mockUseGlobalSelector(selector),
}));

describe('useOrganisationId', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.runOnlyPendingTimers();
    jest.useRealTimers();
  });

  describe('Local Environment (isLocalUrl returns true)', () => {
    beforeEach(() => {
      mockIsLocalUrl.mockReturnValue(true);
      // Return values for both usePlatformState calls (W1_ORGANIZATION_SSO and w1c.selectedOrgCisKey)
      mockUsePlatformState.mockImplementation((key: string) => {
        if (key === 'w1/organisationSso') {
          return [{ orgId: { organisationId: '' } }];
        }
        return [undefined]; // for w1c.selectedOrgCisKey
      });
      // Mock useGlobalSelector to return undefined for all selectors
      mockUseGlobalSelector.mockReturnValue(undefined);
    });

    it('should return undefined initially in local environment', () => {
      const { result } = renderHook(() => useOrganisationId());

      expect(result.current).toBeUndefined();
    });

    it('should return mock organisationId after 500ms delay in local environment', async () => {
      const { result } = renderHook(() => useOrganisationId());

      expect(result.current).toBeUndefined();

      // Fast-forward time by 500ms
      jest.advanceTimersByTime(500);

      await waitFor(() => {
        expect(result.current).toBe('12345678910');
      });
    });

    it('should not return organisationId before 500ms elapses in local environment', () => {
      const { result } = renderHook(() => useOrganisationId());

      expect(result.current).toBeUndefined();

      // Fast-forward time by 400ms (not enough)
      jest.advanceTimersByTime(400);

      expect(result.current).toBeUndefined();
    });

    it('should cleanup timer on unmount in local environment', () => {
      const clearTimeoutSpy = jest.spyOn(global, 'clearTimeout');

      const { unmount } = renderHook(() => useOrganisationId());

      unmount();

      expect(clearTimeoutSpy).toHaveBeenCalled();

      clearTimeoutSpy.mockRestore();
    });

    it('should restart timer if hook is re-rendered in local environment', async () => {
      const { result, rerender } = renderHook(() => useOrganisationId());

      expect(result.current).toBeUndefined();

      // Advance 300ms
      jest.advanceTimersByTime(300);

      // Rerender the hook (simulates component re-render)
      rerender();

      // Timer should restart, so advancing 300ms more won't complete the full 500ms
      jest.advanceTimersByTime(300);

      expect(result.current).toBeUndefined();

      // Advance the remaining 200ms to complete the new 500ms cycle
      jest.advanceTimersByTime(200);

      await waitFor(() => {
        expect(result.current).toBe('12345678910');
      });
    });
  });

  describe('Non-Local Environment (isLocalUrl returns false)', () => {
    beforeEach(() => {
      mockIsLocalUrl.mockReturnValue(false);
      // Mock useGlobalSelector to return undefined by default
      mockUseGlobalSelector.mockReturnValue(undefined);
    });

    describe('when using organisationSSOData', () => {
      it('should return organisationId from platform state immediately when available', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: '98765432101' } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        const { result } = renderHook(() => useOrganisationId());

        expect(result.current).toBe('98765432101');
      });

      it('should return undefined when organisationId is undefined in platform state', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        const { result } = renderHook(() => useOrganisationId());

        expect(result.current).toBeUndefined();
      });

      it('should return undefined when organisationId is empty string in platform state', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: '' } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        const { result } = renderHook(() => useOrganisationId());

        expect(result.current).toBeUndefined();
      });

      it('should return undefined when orgId object is missing in platform state', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{}];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        const { result } = renderHook(() => useOrganisationId());

        expect(result.current).toBeUndefined();
      });

      it('should return undefined when platform state is null', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [null];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        const { result } = renderHook(() => useOrganisationId());

        expect(result.current).toBeUndefined();
      });

      it('should update orgId when organisationId changes in platform state', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        const { result, rerender } = renderHook(() => useOrganisationId());

        expect(result.current).toBeUndefined();

        // Simulate platform state update with new organisationId
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: '98765432101' } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        rerender();

        expect(result.current).toBe('98765432101');
      });

      it('should update orgId when organisationId changes from one value to another', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: '11111111111' } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        const { result, rerender } = renderHook(() => useOrganisationId());

        expect(result.current).toBe('11111111111');

        // Simulate platform state update with different organisationId
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: '22222222222' } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        rerender();

        expect(result.current).toBe('22222222222');
      });

      it('should update orgId to undefined when organisationId is removed from platform state', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: '98765432101' } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        const { result, rerender } = renderHook(() => useOrganisationId());

        expect(result.current).toBe('98765432101');

        // Simulate platform state update with undefined organisationId
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        rerender();

        expect(result.current).toBeUndefined();
      });

      it('should return undefined when cleanup function is called (no-op in non-local)', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: '98765432101' } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        const { result, unmount } = renderHook(() => useOrganisationId());

        expect(result.current).toBe('98765432101');

        // Unmount should not cause any issues
        unmount();

        // No errors should be thrown
        expect(true).toBe(true);
      });
    });

    describe('when using selectedOrgCisKey', () => {
      it('should return selectedOrgCisKey from platform state immediately when available', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return ['ciskey-98765432101']; // for w1c.selectedOrgCisKey
        });

        const { result } = renderHook(() => useOrganisationId());

        expect(result.current).toBe('ciskey-98765432101');
      });

      it('should return undefined when selectedOrgCisKey is undefined in platform state', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        const { result } = renderHook(() => useOrganisationId());

        expect(result.current).toBeUndefined();
      });

      it('should return undefined when selectedOrgCisKey is empty string in platform state', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return ['']; // for w1c.selectedOrgCisKey
        });

        const { result } = renderHook(() => useOrganisationId());

        expect(result.current).toBeUndefined();
      });

      it('should update orgId when selectedOrgCisKey changes in platform state', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        const { result, rerender } = renderHook(() => useOrganisationId());

        expect(result.current).toBeUndefined();

        // Simulate platform state update with new selectedOrgCisKey
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return ['ciskey-98765432101']; // for w1c.selectedOrgCisKey
        });

        rerender();

        expect(result.current).toBe('ciskey-98765432101');
      });

      it('should update orgId when selectedOrgCisKey changes from one value to another', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return ['ciskey-11111111111']; // for w1c.selectedOrgCisKey
        });

        const { result, rerender } = renderHook(() => useOrganisationId());

        expect(result.current).toBe('ciskey-11111111111');

        // Simulate platform state update with different selectedOrgCisKey
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return ['ciskey-22222222222']; // for w1c.selectedOrgCisKey
        });

        rerender();

        expect(result.current).toBe('ciskey-22222222222');
      });

      it('should update orgId to undefined when selectedOrgCisKey is removed from platform state', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return ['ciskey-98765432101']; // for w1c.selectedOrgCisKey
        });

        const { result, rerender } = renderHook(() => useOrganisationId());

        expect(result.current).toBe('ciskey-98765432101');

        // Simulate platform state update with undefined selectedOrgCisKey
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        rerender();

        expect(result.current).toBeUndefined();
      });

      it('should prioritize organisationSSOData over selectedOrgCisKey when both are available', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: '11111111111' } }];
          }
          return ['ciskey-22222222222']; // for w1c.selectedOrgCisKey
        });

        const { result } = renderHook(() => useOrganisationId());

        expect(result.current).toBe('11111111111');
      });

      it('should return undefined when cleanup function is called (no-op in non-local)', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return ['ciskey-98765432101']; // for w1c.selectedOrgCisKey
        });

        const { result, unmount } = renderHook(() => useOrganisationId());

        expect(result.current).toBe('ciskey-98765432101');

        // Unmount should not cause any issues
        unmount();

        // No errors should be thrown
        expect(true).toBe(true);
      });
    });

    describe('when using selectedCustomer.cisKey', () => {
      it('should return cisKey from selectedCustomer when platform states are undefined', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        mockUseGlobalSelector.mockImplementation((selector: any) => {
          const mockState = {
            global: {
              galaxy: {
                context: {
                  selectedCustomer: { cisKey: 'customer-ciskey-123' },
                  selectedOrganisation: undefined,
                  orgId: undefined,
                },
              },
            },
          };
          return selector(mockState);
        });

        const { result } = renderHook(() => useOrganisationId());

        expect(result.current).toBe('customer-ciskey-123');
      });

      it('should prioritize platform states over selectedCustomer.cisKey', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return ['platform-ciskey-456']; // for w1c.selectedOrgCisKey
        });

        mockUseGlobalSelector.mockImplementation((selector: any) => {
          const mockState = {
            global: {
              galaxy: {
                context: {
                  selectedCustomer: { cisKey: 'customer-ciskey-123' },
                  selectedOrganisation: undefined,
                  orgId: undefined,
                },
              },
            },
          };
          return selector(mockState);
        });

        const { result } = renderHook(() => useOrganisationId());

        expect(result.current).toBe('platform-ciskey-456');
      });
    });

    describe('when using selectedOrganisation.orgId', () => {
      it('should return orgId from selectedOrganisation when platform states and selectedCustomer are undefined', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        mockUseGlobalSelector.mockImplementation((selector: any) => {
          const mockState = {
            global: {
              galaxy: {
                context: {
                  selectedCustomer: undefined,
                  selectedOrganisation: { orgId: 'org-id-789' },
                  orgId: undefined,
                },
              },
            },
          };
          return selector(mockState);
        });

        const { result } = renderHook(() => useOrganisationId());

        expect(result.current).toBe('org-id-789');
      });

      it('should prioritize selectedCustomer.cisKey over selectedOrganisation.orgId', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        mockUseGlobalSelector.mockImplementation((selector: any) => {
          const mockState = {
            global: {
              galaxy: {
                context: {
                  selectedCustomer: { cisKey: 'customer-ciskey-123' },
                  selectedOrganisation: { orgId: 'org-id-789' },
                  orgId: undefined,
                },
              },
            },
          };
          return selector(mockState);
        });

        const { result } = renderHook(() => useOrganisationId());

        expect(result.current).toBe('customer-ciskey-123');
      });
    });

    describe('when using orgIdFromContext', () => {
      it('should return orgIdFromContext when all other sources are undefined', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        mockUseGlobalSelector.mockImplementation((selector: any) => {
          const mockState = {
            global: {
              galaxy: {
                context: {
                  selectedCustomer: undefined,
                  selectedOrganisation: undefined,
                  orgId: 'context-org-id-999',
                },
              },
            },
          };
          return selector(mockState);
        });

        const { result } = renderHook(() => useOrganisationId());

        expect(result.current).toBe('context-org-id-999');
      });

      it('should prioritize all other sources over orgIdFromContext', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: '11111111111' } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        mockUseGlobalSelector.mockImplementation((selector: any) => {
          const mockState = {
            global: {
              galaxy: {
                context: {
                  selectedCustomer: { cisKey: 'customer-ciskey-123' },
                  selectedOrganisation: { orgId: 'org-id-789' },
                  orgId: 'context-org-id-999',
                },
              },
            },
          };
          return selector(mockState);
        });

        const { result } = renderHook(() => useOrganisationId());

        expect(result.current).toBe('11111111111');
      });

      it('should return undefined when all sources are undefined', () => {
        mockUsePlatformState.mockImplementation((key: string) => {
          if (key === 'w1/organisationSso') {
            return [{ orgId: { organisationId: undefined } }];
          }
          return [undefined]; // for w1c.selectedOrgCisKey
        });

        mockUseGlobalSelector.mockReturnValue(undefined);

        const { result } = renderHook(() => useOrganisationId());

        expect(result.current).toBeUndefined();
      });
    });
  });

  describe('Edge Cases', () => {
    it('should handle switching from local to non-local environment', async () => {
      // Start in local environment
      mockIsLocalUrl.mockReturnValue(true);
      mockUsePlatformState.mockImplementation((key: string) => {
        if (key === 'w1/organisationSso') {
          return [{ orgId: { organisationId: '' } }];
        }
        return [undefined]; // for w1c.selectedOrgCisKey
      });

      const { result, rerender } = renderHook(() => useOrganisationId());

      expect(result.current).toBeUndefined();

      jest.advanceTimersByTime(500);

      await waitFor(() => {
        expect(result.current).toBe('12345678910');
      });

      // Switch to non-local environment with platform state
      mockIsLocalUrl.mockReturnValue(false);
      mockUsePlatformState.mockImplementation((key: string) => {
        if (key === 'w1/organisationSso') {
          return [{ orgId: { organisationId: '98765432101' } }];
        }
        return [undefined]; // for w1c.selectedOrgCisKey
      });

      rerender();

      // Should now use platform state value
      expect(result.current).toBe('98765432101');
    });

    it('should handle multiple rapid re-renders in local environment', async () => {
      mockIsLocalUrl.mockReturnValue(true);
      mockUsePlatformState.mockImplementation((key: string) => {
        if (key === 'w1/organisationSso') {
          return [{ orgId: { organisationId: '' } }];
        }
        return [undefined]; // for w1c.selectedOrgCisKey
      });

      const { result, rerender } = renderHook(() => useOrganisationId());

      // Multiple rapid re-renders
      rerender();
      rerender();
      rerender();

      expect(result.current).toBeUndefined();

      // Only the last timer should be active
      jest.advanceTimersByTime(500);

      await waitFor(() => {
        expect(result.current).toBe('12345678910');
      });
    });

    it('should handle multiple rapid re-renders in non-local environment', () => {
      mockIsLocalUrl.mockReturnValue(false);
      mockUsePlatformState.mockImplementation((key: string) => {
        if (key === 'w1/organisationSso') {
          return [{ orgId: { organisationId: '98765432101' } }];
        }
        return [undefined]; // for w1c.selectedOrgCisKey
      });

      const { result, rerender } = renderHook(() => useOrganisationId());

      // Multiple rapid re-renders
      rerender();
      rerender();
      rerender();

      // Should consistently return the platform state value
      expect(result.current).toBe('98765432101');
    });
  });

  describe('Hook Consumer Integration Tests', () => {
    it('should provide organisation ID for API calls', () => {
      mockIsLocalUrl.mockReturnValue(false);
      mockUsePlatformState.mockImplementation((key: string) => {
        if (key === 'w1/organisationSso') {
          return [{ orgId: { organisationId: '98765432101' } }];
        }
        return [undefined];
      });
      mockUseGlobalSelector.mockReturnValue(undefined);

      const { result } = renderHook(() => useOrganisationId());

      // Hook consumer would use this value in API calls
      expect(result.current).toBe('98765432101');
      expect(typeof result.current).toBe('string');
    });

    it('should handle conditional rendering based on organisation ID availability', async () => {
      mockIsLocalUrl.mockReturnValue(true);
      mockUsePlatformState.mockImplementation((key: string) => {
        if (key === 'w1/organisationSso') {
          return [{ orgId: { organisationId: '' } }];
        }
        return [undefined];
      });
      mockUseGlobalSelector.mockReturnValue(undefined);

      const { result } = renderHook(() => useOrganisationId());

      // Initially undefined - consumer would show loading state
      expect(result.current).toBeUndefined();

      // After delay - consumer would show content
      act(() => {
        jest.advanceTimersByTime(500);
      });

      // Hook consumer can now proceed with operations
      await waitFor(() => {
        expect(result.current).toBe('12345678910');
      });
    });

    it('should support data fetching when organisation ID becomes available', () => {
      mockIsLocalUrl.mockReturnValue(false);
      mockUsePlatformState.mockImplementation((key: string) => {
        if (key === 'w1/organisationSso') {
          return [{ orgId: { organisationId: undefined } }];
        }
        return [undefined];
      });
      mockUseGlobalSelector.mockReturnValue(undefined);

      const { result, rerender } = renderHook(() => useOrganisationId());

      // Initially no org ID - consumer waits
      expect(result.current).toBeUndefined();

      // Organisation ID becomes available
      mockUsePlatformState.mockImplementation((key: string) => {
        if (key === 'w1/organisationSso') {
          return [{ orgId: { organisationId: '98765432101' } }];
        }
        return [undefined];
      });

      rerender();

      // Consumer can now fetch data with org ID
      expect(result.current).toBe('98765432101');
    });

    it('should support fallback chain for different deployment scenarios', () => {
      mockIsLocalUrl.mockReturnValue(false);

      // Scenario: Platform state not available, fallback to global selector
      mockUsePlatformState.mockImplementation((key: string) => {
        if (key === 'w1/organisationSso') {
          return [{ orgId: { organisationId: undefined } }];
        }
        return [undefined];
      });
      mockUseGlobalSelector.mockImplementation((selector: any) => {
        const mockState = {
          global: {
            galaxy: {
              context: {
                selectedCustomer: { cisKey: 'fallback-ciskey-123' },
                selectedOrganisation: undefined,
                orgId: undefined,
              },
            },
          },
        };
        return selector(mockState);
      });

      const { result } = renderHook(() => useOrganisationId());

      // Hook consumer gets org ID from fallback source
      expect(result.current).toBe('fallback-ciskey-123');
    });

    it('should allow consumers to track organisation ID changes', () => {
      const orgIdHistory: (string | undefined)[] = [];

      mockIsLocalUrl.mockReturnValue(false);
      mockUsePlatformState.mockImplementation((key: string) => {
        if (key === 'w1/organisationSso') {
          return [{ orgId: { organisationId: '11111111111' } }];
        }
        return [undefined];
      });
      mockUseGlobalSelector.mockReturnValue(undefined);

      const { result, rerender } = renderHook(() => {
        const orgId = useOrganisationId();
        orgIdHistory.push(orgId);
        return orgId;
      });

      expect(result.current).toBe('11111111111');

      // Organisation changes
      mockUsePlatformState.mockImplementation((key: string) => {
        if (key === 'w1/organisationSso') {
          return [{ orgId: { organisationId: '22222222222' } }];
        }
        return [undefined];
      });

      rerender();

      // Consumer tracked the change
      expect(result.current).toBe('22222222222');
      expect(orgIdHistory.length).toBeGreaterThan(1);
    });

    it('should provide stable undefined value when no org ID is available', () => {
      mockIsLocalUrl.mockReturnValue(false);
      mockUsePlatformState.mockImplementation((key: string) => {
        if (key === 'w1/organisationSso') {
          return [{ orgId: { organisationId: undefined } }];
        }
        return [undefined];
      });
      mockUseGlobalSelector.mockReturnValue(undefined);

      const { result } = renderHook(() => useOrganisationId());

      // Consumer can safely check for undefined
      expect(result.current).toBeUndefined();

      // Consumer would disable features or show appropriate messaging
      const isOrgIdAvailable = result.current !== undefined;
      expect(isOrgIdAvailable).toBe(false);
    });
  });
});
