/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-explicit-any */

import { renderHook, waitFor } from '@testing-library/react';
import { useRevertBeneficiaryStatus } from './useRevertBeneficiaryStatus';
import { BENEFICIARY_COSMIC_STATUS } from '../store/types';

const mockHandleRedirectToBeneficiaryList = jest
  .fn()
  .mockResolvedValue(undefined);

jest.mock('../common/BeneficiaryList.util', () => ({
  useHandleRedirectToBeneficiaryList: () => mockHandleRedirectToBeneficiaryList,
}));

describe('useRevertBeneficiaryStatus', () => {
  const mockBeneficiaryStatusUpdate = jest.fn();

  const defaultProps = {
    selectedBeneficiaryId: 'test-beneficiary-id',
    isBeneficiaryStatusUpdateFetching: false,
    beneficiaryStatusUpdate: mockBeneficiaryStatusUpdate,
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('revertStatusAndRedirect function', () => {
    it('should call beneficiaryStatusUpdate with ACTIVE status when revertStatusAndRedirect is called', () => {
      const { result } = renderHook(() =>
        useRevertBeneficiaryStatus(defaultProps)
      );

      const errorMessage = 'Test error message';
      result.current.revertStatusAndRedirect({ errorMessage });

      expect(mockBeneficiaryStatusUpdate).toHaveBeenCalledWith({
        params: {
          beneficiary: {
            id: 'test-beneficiary-id',
            status: BENEFICIARY_COSMIC_STATUS.ACTIVE,
          },
        },
      });
    });

    it('should call beneficiaryStatusUpdate to initiate revert when revertStatusAndRedirect is called', () => {
      const { result } = renderHook(() =>
        useRevertBeneficiaryStatus(defaultProps)
      );

      const errorMessage = 'Test error message';
      result.current.revertStatusAndRedirect({ errorMessage });

      expect(mockBeneficiaryStatusUpdate).toHaveBeenCalled();
    });

    it('should store error message for later use', () => {
      const { result } = renderHook(() =>
        useRevertBeneficiaryStatus(defaultProps)
      );

      const errorMessage = 'Test error message';
      result.current.revertStatusAndRedirect({ errorMessage });

      // Error message is stored internally and will be used after revert completes
      expect(mockBeneficiaryStatusUpdate).toHaveBeenCalled();
    });
  });

  describe('revert completion flow', () => {
    it('should redirect to beneficiary list when status update completes', async () => {
      const { result, rerender } = renderHook(
        props => useRevertBeneficiaryStatus(props),
        { initialProps: defaultProps }
      );

      const errorMessage = 'Something went wrong. Please try again later.';
      result.current.revertStatusAndRedirect({ errorMessage });

      // Simulate status update in progress
      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: true,
      });

      // Simulate status update completion
      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: false,
      });

      await waitFor(() => {
        expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
          'danger',
          errorMessage
        );
      });
    });

    it('should redirect after status update completes', async () => {
      const { result, rerender } = renderHook(
        props => useRevertBeneficiaryStatus(props),
        { initialProps: defaultProps }
      );

      const errorMessage = 'Test error message';
      result.current.revertStatusAndRedirect({ errorMessage });

      // Simulate status update in progress
      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: true,
      });

      // Simulate status update completion
      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: false,
      });

      await waitFor(() => {
        expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalled();
      });
    });

    it('should handle status update completion even if update failed', async () => {
      const { result, rerender } = renderHook(
        props => useRevertBeneficiaryStatus(props),
        { initialProps: defaultProps }
      );

      const errorMessage = 'Test error message';
      result.current.revertStatusAndRedirect({ errorMessage });

      // Simulate status update in progress
      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: true,
      });

      // Simulate status update completion (regardless of success or error)
      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: false,
      });

      await waitFor(() => {
        expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
          'danger',
          errorMessage
        );
        expect(result.current.isRevertingToActive).toBe(false);
      });
    });
  });

  describe('error message handling', () => {
    it('should redirect with entitlement error message', async () => {
      const { result, rerender } = renderHook(
        props => useRevertBeneficiaryStatus(props),
        { initialProps: defaultProps }
      );

      const errorMessage =
        'You do not have permission to archive beneficiaries. Contact your administrator for more information.';
      result.current.revertStatusAndRedirect({ errorMessage });

      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: false,
      });

      await waitFor(() => {
        expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
          'danger',
          errorMessage
        );
      });
    });

    it('should redirect with generic error message', async () => {
      const { result, rerender } = renderHook(
        props => useRevertBeneficiaryStatus(props),
        { initialProps: defaultProps }
      );

      const errorMessage = 'Something went wrong. Please try again later.';
      result.current.revertStatusAndRedirect({ errorMessage });

      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: false,
      });

      await waitFor(() => {
        expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
          'danger',
          errorMessage
        );
      });
    });

    it('should redirect with update entitlement error message', async () => {
      const { result, rerender } = renderHook(
        props => useRevertBeneficiaryStatus(props),
        { initialProps: defaultProps }
      );

      const errorMessage =
        'You do not have permission to add or update beneficiaries. Contact your administrator for more information.';
      result.current.revertStatusAndRedirect({ errorMessage });

      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: false,
      });

      await waitFor(() => {
        expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
          'danger',
          errorMessage
        );
      });
    });
  });

  describe('multiple revert calls', () => {
    it('should handle multiple revert calls correctly', async () => {
      const { result, rerender } = renderHook(
        props => useRevertBeneficiaryStatus(props),
        { initialProps: defaultProps }
      );

      // First revert
      const firstErrorMessage = 'First error message';
      result.current.revertStatusAndRedirect({
        errorMessage: firstErrorMessage,
      });

      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: false,
      });

      await waitFor(() => {
        expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
          'danger',
          firstErrorMessage
        );
      });

      // Second revert
      jest.clearAllMocks();
      const secondErrorMessage = 'Second error message';
      result.current.revertStatusAndRedirect({
        errorMessage: secondErrorMessage,
      });

      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: false,
      });

      await waitFor(() => {
        expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
          'danger',
          secondErrorMessage
        );
      });
    });
  });

  describe('edge cases', () => {
    it('should not redirect if not reverting', async () => {
      renderHook(() => useRevertBeneficiaryStatus(defaultProps));

      await waitFor(
        () => {
          expect(mockHandleRedirectToBeneficiaryList).not.toHaveBeenCalled();
        },
        { timeout: 1000 }
      ).catch(() => {
        // Expected to timeout
        expect(mockHandleRedirectToBeneficiaryList).not.toHaveBeenCalled();
      });
    });

    it('should not redirect while status update is in progress', async () => {
      const props = {
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: true,
      };

      const { result } = renderHook(() => useRevertBeneficiaryStatus(props));

      const errorMessage = 'Test error message';
      result.current.revertStatusAndRedirect({ errorMessage });

      await waitFor(
        () => {
          expect(mockHandleRedirectToBeneficiaryList).not.toHaveBeenCalled();
        },
        { timeout: 1000 }
      ).catch(() => {
        // Expected to timeout
        expect(mockHandleRedirectToBeneficiaryList).not.toHaveBeenCalled();
      });
    });

    it('should handle empty error message', async () => {
      const { result, rerender } = renderHook(
        props => useRevertBeneficiaryStatus(props),
        { initialProps: defaultProps }
      );

      result.current.revertStatusAndRedirect({ errorMessage: '' });

      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: false,
      });

      await waitFor(() => {
        expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
          'danger',
          ''
        );
      });
    });
  });

  describe('integration with different selectedBeneficiaryId', () => {
    it('should use correct beneficiary id when reverting', () => {
      const customProps = {
        ...defaultProps,
        selectedBeneficiaryId: 'custom-beneficiary-id',
      };

      const { result } = renderHook(() =>
        useRevertBeneficiaryStatus(customProps)
      );

      result.current.revertStatusAndRedirect({ errorMessage: 'Test error' });

      expect(mockBeneficiaryStatusUpdate).toHaveBeenCalledWith({
        params: {
          beneficiary: {
            id: 'custom-beneficiary-id',
            status: BENEFICIARY_COSMIC_STATUS.ACTIVE,
          },
        },
      });
    });
  });
});
