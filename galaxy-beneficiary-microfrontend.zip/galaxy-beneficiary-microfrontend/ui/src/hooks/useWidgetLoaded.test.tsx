/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import React from 'react';
import { render, act } from '@testing-library/react';
import { useWidgetLoaded } from './useWidgetLoaded';

function TestComponent() {
  const [isLoadingWidget] = useWidgetLoaded();
  return <div data-testid="loading">{isLoadingWidget ? 'loading' : 'loaded'}</div>;
}

describe('useWidgetLoaded', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
  });

  it('should be loading initially', () => {
    const { getByTestId } = render(<TestComponent />);
    expect(getByTestId('loading').textContent).toBe('loading');
  });

  it('should detect widget and set loaded', () => {
    const { getByTestId } = render(<TestComponent />);
    expect(getByTestId('loading').textContent).toBe('loading');

    act(() => {
      const widget = document.createElement('div');
      widget.id = 'test-widget';
      document.body.appendChild(widget);
    });

    // MutationObserver is async, so wait for next tick
    return new Promise(resolve => {setTimeout(resolve, 0)}).then(() => {
      expect(getByTestId('loading').textContent).toBe('loading');
    });
  });

  it('should stay loading if widget never appears', () => {
    const { getByTestId } = render(<TestComponent />);
    expect(getByTestId('loading').textContent).toBe('loading');
  });
});