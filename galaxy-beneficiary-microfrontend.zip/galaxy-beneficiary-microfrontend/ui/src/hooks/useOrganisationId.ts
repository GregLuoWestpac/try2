/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { useEffect, useState } from 'react';
import { isLocalUrl, useGlobalSelector } from '@mep-ui/framework';
import { usePlatformState } from '@mesh-tenant-multiverse-common/react';
import { W1_ORGANIZATION_SSO } from '../common/constants';
import {
  GlobalState,
  SelectedCustomerType,
  OrganisationType,
} from '../store/types';

const mockOrganisationId = '12345678910';

/**
 * Custom hook to get organisation ID
 * In local environment: simulates delayed availability (500ms) to match real environment behavior
 * In non-local environment: retrieves from platform state
 */
export const useOrganisationId = () => {
  const [orgId, setOrgId] = useState<string | undefined>(undefined);

  const [organisationSSOData] = usePlatformState(W1_ORGANIZATION_SSO, {
    orgId: {
      organisationId: '',
    },
  });

  const [selectedOrgCisKey] = usePlatformState<string | undefined>(
    'w1c.selectedOrgCisKey',
    undefined
  );

  const selectedCustomer: SelectedCustomerType | undefined = useGlobalSelector(
    (state: GlobalState) => state?.global?.galaxy?.context?.selectedCustomer
  );

  const selectedOrganisation: OrganisationType | undefined = useGlobalSelector(
    (state: GlobalState) =>
      state?.global?.galaxy?.context?.selectedOrganisation || undefined
  );

  const orgIdFromContext: string | undefined = useGlobalSelector(
    (state: GlobalState) => state?.global?.galaxy?.context?.orgId || undefined
  );

  useEffect(() => {
    if (isLocalUrl()) {
      // Simulate the delay in getting orgId that occurs in real environments
      const timer = setTimeout(() => {
        setOrgId(mockOrganisationId);
      }, 500);

      return () => {
        clearTimeout(timer);
      };
    }
    // In non-local environments, use the actual organisation ID from platform state
    setOrgId(
      organisationSSOData?.orgId?.organisationId ||
        selectedOrgCisKey ||
        selectedCustomer?.cisKey ||
        selectedOrganisation?.orgId ||
        orgIdFromContext
    );

    return undefined;
  }, [
    organisationSSOData?.orgId?.organisationId,
    selectedOrgCisKey,
    selectedCustomer?.cisKey,
    selectedOrganisation?.orgId,
    orgIdFromContext,
  ]);

  console.log('useOrganisationId - orgId:', orgId);

  return orgId;
};
