import { useCallback, useEffect, useRef, useState } from 'react';
import {
  BENEFICIARY_COSMIC_STATUS,
  PostBeneficiaryStatusUpdateParams,
  PostBeneficiaryStatusUpdateParamsPayload,
} from '../store/types';
import { useHandleRedirectToBeneficiaryList } from '../common/BeneficiaryList.util';

export type UseRevertBeneficiaryStatusProps = {
  selectedBeneficiaryId: string;
  isBeneficiaryStatusUpdateFetching: boolean;
  beneficiaryStatusUpdate: (
    payload: PostBeneficiaryStatusUpdateParamsPayload
  ) => void;
};

export type RevertAndRedirectParams = {
  errorMessage: string;
};

export const useRevertBeneficiaryStatus = ({
  selectedBeneficiaryId,
  isBeneficiaryStatusUpdateFetching,
  beneficiaryStatusUpdate,
}: UseRevertBeneficiaryStatusProps) => {
  const [isRevertingToActive, setIsRevertingToActive] =
    useState<boolean>(false);
  const errorMessageAfterRevert = useRef<string>('');
  const handleRedirectToBeneficiaryList = useHandleRedirectToBeneficiaryList();

  // Monitor beneficiary status revert completion and redirect with error message
  useEffect(() => {
    if (isRevertingToActive && !isBeneficiaryStatusUpdateFetching) {
      // Status update completed (success or error), now redirect with stored error message
      setIsRevertingToActive(false);
      const errorMessage = errorMessageAfterRevert.current;
      errorMessageAfterRevert.current = '';
      handleRedirectToBeneficiaryList('danger', errorMessage).catch(
        () => undefined
      );
    }
  }, [isRevertingToActive, isBeneficiaryStatusUpdateFetching]);

  // Revert beneficiary status from ON_HOLD back to ACTIVE when errors occur
  const revertStatusAndRedirect = useCallback(
    ({ errorMessage }: RevertAndRedirectParams) => {
      errorMessageAfterRevert.current = errorMessage;
      // Update beneficiary status back to ACTIVE to rollback the ON_HOLD change
      const postBeneficiaryStatusUpdateParams: PostBeneficiaryStatusUpdateParams =
        {
          beneficiary: {
            id: selectedBeneficiaryId,
            status: BENEFICIARY_COSMIC_STATUS.ACTIVE,
          },
        };
      setIsRevertingToActive(true);
      beneficiaryStatusUpdate({ params: postBeneficiaryStatusUpdateParams });
    },
    [selectedBeneficiaryId, beneficiaryStatusUpdate]
  );

  return {
    revertStatusAndRedirect,
    isRevertingToActive,
  };
};
