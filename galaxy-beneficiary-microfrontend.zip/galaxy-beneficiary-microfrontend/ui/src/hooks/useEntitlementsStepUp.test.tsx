/* eslint-disable react/destructuring-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/react-in-jsx-scope */

import { render, act } from '@testing-library/react';
import { useGlobalSelector } from '@mep-ui/framework';
import {
  EntitlementMFAProps,
  useEntitlementsStepUp,
} from './useEntitlementsStepUp';
import { ERROR_CODES, MFA_CODE } from '../common';
import { PingmfaWidgetApp } from '../widgets/pingmfa/pingmfa-v1';

jest.mock('@mep-ui/framework', () => ({
  useGlobalDispatch: jest.fn(() => jest.fn()),
  useGlobalSelector: jest.fn(),
}));

// Capture callbackFromEntitlementsLib for test
let lastCallbackFromEntitlementsLib: any;
jest.mock(
  '@mesh-tenant-user-authorisation-policy-decision-engine/components',
  () => ({
    EntitlementsStepUp: (props: any) => {
      lastCallbackFromEntitlementsLib = props.callbackFromEntitlementsLib;
      return <div data-testid="entitlements-stepup-mock">{props.children}</div>;
    },
  })
);

jest.mock('../widgets/pingmfa/pingmfa-v1', () => ({
  PingmfaWidgetApp: () => <div data-testid="widget-app-mock">WidgetApp</div>,
}));

const mockSetIsStepUpModalVisible = jest.fn();
const dispatchFn = jest.fn();
const mockAppCorrelationId = 'test-correlation-id';

const getError = (code = ERROR_CODES.STEP_UP_REQUIRED) => ({
  code,
  message: 'Step up required',
});

describe('useEntitlementsStepUp', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    (useGlobalSelector as jest.Mock).mockImplementation(cb =>
      // eslint-disable-next-line @typescript-eslint/no-unsafe-return
      cb({ global: { instance: { appCorrelationId: mockAppCorrelationId } } })
    );
  });

  function TestComponent(props: EntitlementMFAProps) {
    const { renderEntitlementsStepUp } = useEntitlementsStepUp(props);
    return renderEntitlementsStepUp();
  }

  it('should render EntitlementsStepUp when step up is required and modal is visible', () => {
    const beneficiaryError = {
      status: 401,
      data: { errors: [getError()] },
    };
    const { container } = render(
      <TestComponent
        pingMfaWidget={<PingmfaWidgetApp />}
        propType="mfa"
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        dispatchFn={dispatchFn}
        dispatchFnParams={{ foo: 'bar' }}
        isStepUpModalVisible
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should not render EntitlementsStepUp if step up is not required', () => {
    const beneficiaryError = {
      status: 400,
      data: { errors: [getError()] },
    };
    const { container } = render(
      <TestComponent
        propType="mfa"
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        dispatchFn={dispatchFn}
        dispatchFnParams={{}}
        isStepUpModalVisible
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
      />
    );
    expect(container.innerHTML).toBe('');
  });

  it('should close modal on Escape keydown', () => {
    const beneficiaryError = {
      status: 401,
      data: { errors: [getError()] },
    };
    render(
      <TestComponent
        propType="mfa"
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        dispatchFn={dispatchFn}
        dispatchFnParams={{}}
        isStepUpModalVisible
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
      />
    );
    const event = new KeyboardEvent('keydown', { key: 'Escape' });
    act(() => {
      document.dispatchEvent(event);
    });
    expect(mockSetIsStepUpModalVisible).toHaveBeenCalledWith(false);
  });

  it('should close modal if callbackFromEntitlementsLib is called with MFA_CANCEL', () => {
    const beneficiaryError = {
      status: 401,
      data: { errors: [getError()] },
    };
    // Reset the callback before the test
    lastCallbackFromEntitlementsLib = undefined;
    function TestCallbackComponent(props: any) {
      const { renderEntitlementsStepUp } = useEntitlementsStepUp(props);
      return renderEntitlementsStepUp();
    }
    render(
      <TestCallbackComponent
        propType="mfa"
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        dispatchFn={dispatchFn}
        dispatchFnParams={{}}
        isStepUpModalVisible
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
      />
    );
    expect(typeof lastCallbackFromEntitlementsLib).toBe('function');
    act(() => {
      lastCallbackFromEntitlementsLib(false, mockAppCorrelationId, {
        code: MFA_CODE.MFA_CANCELLED,
        message: 'cancelled',
      });
    });
    expect(mockSetIsStepUpModalVisible).toHaveBeenCalledWith(false);
  });

  it('should close modal if callbackFromEntitlementsLib is called with MFA_LOCKED', () => {
    const beneficiaryError = {
      status: 401,
      data: { errors: [getError()] },
    };
    lastCallbackFromEntitlementsLib = undefined;
    function TestCallbackComponent(props: any) {
      const { renderEntitlementsStepUp } = useEntitlementsStepUp(props);
      return renderEntitlementsStepUp();
    }
    render(
      <TestCallbackComponent
        propType="mfa"
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        dispatchFn={dispatchFn}
        dispatchFnParams={{}}
        isStepUpModalVisible
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
      />
    );
    act(() => {
      lastCallbackFromEntitlementsLib(false, mockAppCorrelationId, {
        code: MFA_CODE.MFA_LOCKED,
        message: 'locked',
      });
    });
    expect(mockSetIsStepUpModalVisible).toHaveBeenCalledWith(false);
  });

  it('should close modal when callbackFromEntitlementsLib is called with stepUpResult true', () => {
    const beneficiaryError = {
      status: 401,
      data: { errors: [getError()] },
    };
    lastCallbackFromEntitlementsLib = undefined;
    function TestCallbackComponent(props: any) {
      const { renderEntitlementsStepUp } = useEntitlementsStepUp(props);
      return renderEntitlementsStepUp();
    }
    render(
      <TestCallbackComponent
        propType="mfa"
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        dispatchFn={dispatchFn}
        dispatchFnParams={{}}
        isStepUpModalVisible
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
      />
    );
    act(() => {
      lastCallbackFromEntitlementsLib(true, mockAppCorrelationId, null);
    });
    expect(mockSetIsStepUpModalVisible).toHaveBeenCalledWith(false);
  });

  it('should call setIsNonOtpMFAError when MFA_ERROR is received but not INVALID_OTP', () => {
    const mockSetIsNonOtpMFAError = jest.fn();
    const beneficiaryError = {
      status: 401,
      data: { errors: [getError()] },
    };
    lastCallbackFromEntitlementsLib = undefined;
    function TestCallbackComponent(props: any) {
      const { renderEntitlementsStepUp } = useEntitlementsStepUp(props);
      return renderEntitlementsStepUp();
    }
    render(
      <TestCallbackComponent
        propType="mfa"
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        dispatchFn={dispatchFn}
        dispatchFnParams={{}}
        isStepUpModalVisible
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
        setIsNonOtpMFAError={mockSetIsNonOtpMFAError}
      />
    );
    act(() => {
      lastCallbackFromEntitlementsLib(false, mockAppCorrelationId, {
        code: MFA_CODE.MFA_ERROR,
        message: 'Some other MFA error',
      });
    });
    expect(mockSetIsNonOtpMFAError).toHaveBeenCalledWith(true);
  });

  it('should not call setIsNonOtpMFAError with true when MFA_ERROR is INVALID_OTP', () => {
    const mockSetIsNonOtpMFAError = jest.fn();
    const beneficiaryError = {
      status: 401,
      data: { errors: [getError()] },
    };
    lastCallbackFromEntitlementsLib = undefined;
    function TestCallbackComponent(props: any) {
      const { renderEntitlementsStepUp } = useEntitlementsStepUp(props);
      return renderEntitlementsStepUp();
    }
    render(
      <TestCallbackComponent
        propType="mfa"
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        dispatchFn={dispatchFn}
        dispatchFnParams={{}}
        isStepUpModalVisible
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
        setIsNonOtpMFAError={mockSetIsNonOtpMFAError}
      />
    );
    act(() => {
      lastCallbackFromEntitlementsLib(false, mockAppCorrelationId, {
        code: MFA_CODE.MFA_ERROR,
        message: MFA_CODE.INVALID_OTP,
      });
    });
    expect(mockSetIsNonOtpMFAError).toHaveBeenCalledWith(false);
  });

  it('should render EntitlementsStepUp for makerChecker propType', () => {
    const beneficiaryError = {
      status: 401,
      data: { errors: [getError()] },
    };
    const mockUpdateTrigger = jest.fn();

    function TestMakerCheckerComponent(props: any) {
      const { renderEntitlementsStepUp } = useEntitlementsStepUp(props);
      return renderEntitlementsStepUp();
    }

    const { container } = render(
      <TestMakerCheckerComponent
        propType="makerChecker"
        updateTrigger={mockUpdateTrigger}
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        isStepUpModalVisible
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
        pingMfaWidget={<PingmfaWidgetApp />}
      />
    );
    expect(container).toBeTruthy();
    expect(
      container.querySelector('[data-testid="entitlements-stepup-mock"]')
    ).toBeInTheDocument();
  });

  it('should handle missing appCorrelationId in global state', () => {
    (useGlobalSelector as jest.Mock).mockImplementation(cb =>
      // eslint-disable-next-line @typescript-eslint/no-unsafe-return
      cb({ global: { instance: {} } })
    );

    const beneficiaryError = {
      status: 401,
      data: { errors: [getError()] },
    };
    const { container } = render(
      <TestComponent
        pingMfaWidget={<PingmfaWidgetApp />}
        propType="mfa"
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        dispatchFn={dispatchFn}
        dispatchFnParams={{ foo: 'bar' }}
        isStepUpModalVisible
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should not close modal on Escape keydown when defaultPrevented is true', () => {
    const beneficiaryError = {
      status: 401,
      data: { errors: [getError()] },
    };
    render(
      <TestComponent
        pingMfaWidget={<PingmfaWidgetApp />}
        propType="mfa"
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        dispatchFn={dispatchFn}
        dispatchFnParams={{}}
        isStepUpModalVisible
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
      />
    );
    const event = new KeyboardEvent('keydown', { key: 'Escape' });
    Object.defineProperty(event, 'defaultPrevented', { value: true });
    act(() => {
      document.dispatchEvent(event);
    });
    expect(mockSetIsStepUpModalVisible).not.toHaveBeenCalled();
  });

  it('should not add event listener when modal is not visible', () => {
    const beneficiaryError = {
      status: 401,
      data: { errors: [getError()] },
    };
    const addEventListenerSpy = jest.spyOn(document, 'addEventListener');
    render(
      <TestComponent
        pingMfaWidget={<PingmfaWidgetApp />}
        propType="mfa"
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        dispatchFn={dispatchFn}
        dispatchFnParams={{}}
        isStepUpModalVisible={false}
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
      />
    );
    expect(addEventListenerSpy).not.toHaveBeenCalledWith(
      'keydown',
      expect.any(Function),
      true
    );
    addEventListenerSpy.mockRestore();
  });
});
