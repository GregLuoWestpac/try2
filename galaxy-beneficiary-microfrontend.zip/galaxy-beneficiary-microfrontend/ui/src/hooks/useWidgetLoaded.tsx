/* eslint-disable react/function-component-definition */
/* eslint-disable consistent-return */
/* eslint-disable react/react-in-jsx-scope */
/* eslint-disable import/no-unresolved */

import { useEffect, useState } from "react";


export function useWidgetLoaded(): [boolean, React.Dispatch<React.SetStateAction<boolean>>] {
  const [isLoadingWidget, setIsLoadingWidget] = useState(true);
  const widgetId = 'maker-checker-api-client';

  useEffect(() => {
    if (!isLoadingWidget) return;
    const widget = document.getElementById(widgetId);
    if (widget) {
      setIsLoadingWidget(false);
      return;
    }
    const observer = new MutationObserver(() => {
      const found = document.getElementById(widgetId);
      if (found) {
        setIsLoadingWidget(false);
        observer.disconnect();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    return () => observer.disconnect();
  }, [isLoadingWidget]);

  return [isLoadingWidget, setIsLoadingWidget];
}