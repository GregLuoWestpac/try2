import { pages } from './routes';

describe('Routes', () => {
  it('should match the pages length', () => {
    expect(pages.length).toBe(1);
    expect(pages[0].children.length).toBe(7);
    expect(pages[0].children).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          index: true,
        }),
        expect.objectContaining({
          path: 'create-beneficiary',
        }),
        expect.objectContaining({
          path: 'view-beneficiary',
        }),
        expect.objectContaining({
          path: 'update-beneficiary',
        }),
        expect.objectContaining({
          path: 'beneficiary-task-details',
        }),
        expect.objectContaining({
          path: 'beneficiary-activity-details',
        }),
      ])
    );
  });
});
