/* eslint-disable react/jsx-props-no-spreading */
import React from 'react';
import {
  Provider,
  compose,
  useMFEConfig,
  useManifest,
} from '@mep-ui/framework';
import { CancelModalProvider } from '@mesh-tenant-multiverse-common/react';
import { MVPageLoader as PageLoader } from '@mesh-tenant-multiverse-ui-common/mv-pageloader';
import { useSetAgGridLicV2 as useSetAgGridLic } from '@mesh-tenant-multiverse-ui-common/mv-table-v2';
import isEmpty from 'lodash/isEmpty';
import PropTypes from 'prop-types';

import store from '../store/store';
import withManifest from './withManifest';

function Config({ children }) {
  const hasAgGridLicense = useSetAgGridLic();
  const { isLoading, manifest } = useManifest('galaxy-beneficiary');
  const { config, isFetching } = useMFEConfig({
    name: 'galaxy-beneficiary',
    store,
  });

  if (
    isEmpty(config) ||
    isFetching ||
    isLoading ||
    isEmpty(manifest) ||
    !hasAgGridLicense
  ) {
    return <PageLoader placement="middle" />;
  }
  return children;
}

Config.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.element,
    PropTypes.arrayOf(PropTypes.element),
  ]).isRequired,
};

const withMFE = WrapperComponent => {
  function WithMFE(props) {
    return (
      <Provider store={store}>
        <Config>
          <CancelModalProvider>
            <WrapperComponent {...props} />
          </CancelModalProvider>
        </Config>
      </Provider>
    );
  }

  const Enhanced = compose(withManifest)(WithMFE);
  return Enhanced;
};

export default withMFE;
