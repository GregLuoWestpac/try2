/* eslint-disable react/prop-types, react/jsx-props-no-spreading */
import { Navigate, useLocation } from '@mep-ui/framework-router-addon';
import { MVPageLoader as PageLoader } from '@mesh-tenant-multiverse-ui-common/mv-pageloader';
import { isUserAuthorised } from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import { Suspense } from 'react';
import { entitlementToPathMap } from '../fineGrainedEntitlementMap';

function withPageLoader(WrappedComponent) {
  function WithPageLoader(props) {
    const location = useLocation();
    const requiredEntitlement = entitlementToPathMap[location.pathname];
    const authStatus = isUserAuthorised(
      requiredEntitlement?.resource,
      requiredEntitlement?.action
    );

    if (!authStatus.authorised) return <Navigate to="/error" replace={true} />;

    return (
      <Suspense fallback={<PageLoader placement="middle" />}>
        <WrappedComponent {...props} />
      </Suspense>
    );
  }
  return WithPageLoader;
}

export default withPageLoader;
