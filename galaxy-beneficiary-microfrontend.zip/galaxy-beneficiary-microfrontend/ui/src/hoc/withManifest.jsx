import { useEffect } from 'react';
import { useGlobalDispatch, manifestActions } from '@mep-ui/framework';
import manifest from '../../public/manifest.json';

const withManifest = (WrappedComponent) =>
  // eslint-disable-next-line react/display-name, func-names
  function (props) {
    const dispatch = useGlobalDispatch();

    useEffect(() => {
      dispatch(manifestActions.receive(manifest, 'galaxy-beneficiary'));
    }, []);

    // eslint-disable-next-line react/react-in-jsx-scope, react/jsx-props-no-spreading
    return <WrappedComponent {...props} />;
  };

export default withManifest;