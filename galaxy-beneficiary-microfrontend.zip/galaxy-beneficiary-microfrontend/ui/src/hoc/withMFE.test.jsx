import { useMFEConfig, useManifest } from '@mep-ui/framework';
import { useSetAgGridLicV2 } from '@mesh-tenant-multiverse-ui-common/mv-table-v2';
import { render, screen } from '@testing-library/react';
import withMFE from './withMFE';

function Test() {
  return <div>Test</div>;
}

jest.mock('../store/store', () => ({}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-table-v2', () => ({
  useSetAgGridLicV2: jest.fn(),
  MVPageLoader: jest.fn(() => <div>Loading...</div>),
}));

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useMFEConfig: jest.fn(),
  useManifest: jest.fn(),
  Provider: ({ children }) => <div>{children}</div>,
}));

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  CancelModalProvider: ({ children }) => <div>{children}</div>,
}));

describe('withMFE', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  it('should match snapshot if manifest is fetching', () => {
    useManifest.mockReturnValue({
      isLoading: true,
      manifest: null,
    });
    useMFEConfig.mockReturnValue({
      isFetching: false,
      config: null,
    });
    const Hoc = withMFE(Test);
    const baseElement = render(<Hoc />);
    expect(baseElement).toMatchSnapshot();
  });

  it('should match snapshot if appconfig is fetching', () => {
    useManifest.mockReturnValue({
      isLoading: false,
      manifest: {
        name: 'bhumi-esgassessment',
      },
    });
    useMFEConfig.mockReturnValue({
      isFetching: true,
      config: null,
    });
    const Hoc = withMFE(Test);
    const baseElement = render(<Hoc />);
    expect(baseElement).toMatchSnapshot();
  });

  it('should match snapshot ', () => {
    useManifest.mockReturnValue({
      isLoading: false,
      manifest: {
        name: 'bhumi-esgassessment',
      },
    });
    useMFEConfig.mockReturnValue({
      isFetching: false,
      config: {
        name: 'bhumi-esgassessment',
      },
    });
    useSetAgGridLicV2.mockReturnValue(true);

    const Hoc = withMFE(Test);
    render(<Hoc />);
    expect(screen.getByText('Test')).toBeInTheDocument();
  });
});
