import { useGlobalDispatch } from '@mep-ui/framework';
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import { withIntent } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { INTENT_NAMES } from '../common/constants';
import { BeneficiaryListContainer } from '../containers';

export function Beneficiaries() {
  return (
    <MVCard title="Beneficiaries" bottomDivider={false}>
      <BeneficiaryListContainer />
    </MVCard>
  );
}

export default withIntent(
  useGlobalDispatch,
  INTENT_NAMES.BENEFICIARY_LISTS
)(Beneficiaries);
