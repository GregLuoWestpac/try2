import '@testing-library/jest-dom';
import { render } from '@testing-library/react';
import React from 'react';
import Beneficiaries from './Beneficiaries';

jest.mock('@mep-ui/framework-router-addon', () => {
  const mockNavigate = jest.fn();
  return {
    ...jest.requireActual('@mep-ui/framework-router-addon'),
    useNavigate: () => mockNavigate,
  };
});

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalDispatch: () => jest.fn(),
}));

jest.mock('../containers/BeneficiaryListContainer', () => ({
  BeneficiaryListContainer: function MockComponent() {
    return <div>Mock BeneficiaryListContainer</div>;
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: function MockComponent({ children }: { children: React.ReactNode }) {
    return <div>{children}</div>;
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  withIntent: () => (Component: React.ComponentType) => Component, // Mock `withIntent`
}));

describe('Testing the Beneficiaries', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  it('should match snapshot', () => {
    const { asFragment } = render(<Beneficiaries />);
    expect(asFragment()).toMatchSnapshot();
  });

  it('should show the BeneficiaryListContainer', () => {
    const { getByText } = render(<Beneficiaries />);
    const BeneficiaryListContainer = getByText('Mock BeneficiaryListContainer');
    expect(BeneficiaryListContainer).toBeInTheDocument();
  });
});
