import { useGlobalDispatch } from '@mep-ui/framework';
import { withIntent } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { INTENT_NAMES } from '../common/constants';
import BeneficiaryDetailsContainer from '../containers/BeneficiaryDetailsContainer/BeneficiaryDetailsContainer';

function BeneficiaryDetails() {
  return <BeneficiaryDetailsContainer />;
}

export default withIntent(
  useGlobalDispatch,
  INTENT_NAMES.VIEW_BENEFICIARY_DETAILS
)(BeneficiaryDetails);
