import { useGlobalDispatch } from '@mep-ui/framework';
import { withIntent } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { INTENT_NAMES } from '../common/constants';
import BeneficiaryTaskContainer from '../containers/BeneficiaryTaskContainer/BeneficiaryTaskContainer';

function BeneficiaryTask() {
  return <BeneficiaryTaskContainer />;
}

export default withIntent(
  useGlobalDispatch,
  INTENT_NAMES.VIEW_BENEFICIARY_TASK_DETAILS
)(BeneficiaryTask);
