import '@testing-library/jest-dom';
import { render } from '@testing-library/react';
import React from 'react';
import AddBeneficiary from './AddBeneficiary';

jest.mock('@mep-ui/framework-router-addon', () => {
  const mockNavigate = jest.fn();
  return {
    ...jest.requireActual('@mep-ui/framework-router-addon'),
    useNavigate: () => mockNavigate,
  };
});

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalDispatch: () => jest.fn(),
}));

jest.mock('../containers/AddBeneficiaryContainer', () => ({
  AddBeneficiaryContainer: function MockComponent() {
    return <div>AddBeneficiaryContainer</div>;
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: function MockComponent({ children }: { children: React.ReactNode }) {
    return <div>{children}</div>;
  },
}));
jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  withIntent: () => (Component: React.ComponentType) => Component, // Mock `withIntent`
}));

describe('AddBeneficiary', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  it('renders AddBeneficiaryContainer', () => {
    const { getByText } = render(<AddBeneficiary />);
    expect(getByText('AddBeneficiaryContainer')).toBeInTheDocument();
  });

  it('should should match snapshot', () => {
    const { container } = render(<AddBeneficiary />);
    expect(container).toMatchSnapshot();
  });
});
