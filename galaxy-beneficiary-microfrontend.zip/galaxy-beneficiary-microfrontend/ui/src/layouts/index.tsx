import React from 'react';
import withPageLoader from '../hoc/withPageLoader';

const Default = React.lazy(() => import('./Default'));
const BeneficiaryDetails = React.lazy(() => import('./BeneficiaryDetails'));
const UpdateBeneficiary = React.lazy(() => import('./UpdateBeneficiary'));
const Error = React.lazy(() => import('./Error'));
const AddBeneficiary = React.lazy(() => import('./AddBeneficiary'));
const Beneficiaries = React.lazy(() => import('./Beneficiaries'));
const BeneficiaryTask = React.lazy(() => import('./BeneficiaryTask'));
const BeneficiaryActivities = React.lazy(
  () => import('./BeneficiaryActivityDetails')
);

export const AsyncDefault = withPageLoader(Default);
export const AsyncHome = withPageLoader(Beneficiaries);
export const AsyncBeneficiaryDetails = withPageLoader(BeneficiaryDetails);
export const AsyncUpdateBeneficiary = withPageLoader(UpdateBeneficiary);
export const AsyncError = withPageLoader(Error);
export const AsyncAddBeneficiaries = withPageLoader(AddBeneficiary);
export const AsyncBeneficiaryTask = withPageLoader(BeneficiaryTask);
export const AsyncBeneficiaryActivities = withPageLoader(BeneficiaryActivities);
