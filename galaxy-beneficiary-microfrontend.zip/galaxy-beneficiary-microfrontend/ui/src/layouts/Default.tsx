import React from 'react';
import PropTypes from 'prop-types';

import { Route, Routes, Outlet } from '@mep-ui/framework-router-addon';

import withMFE from '../hoc/withMFE';

// eslint-disable-next-line no-unused-vars
export function Default({ routes, ...rest }) {
  /**
   * Provision only permissible routes passed from the
   * SinglePageApplication container
   */
  return (
    <>
      <Outlet />
      <Routes>
        {routes &&
          routes.map(({ path, id, element, index }) => {
            return (
              <Route index={index} path={path} key={id} element={element} />
            );
          })}
      </Routes>
    </>
  );
}

Default.propTypes = {
  routes: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
};

const EnhancedRoutes = withMFE(Default);

export default EnhancedRoutes;