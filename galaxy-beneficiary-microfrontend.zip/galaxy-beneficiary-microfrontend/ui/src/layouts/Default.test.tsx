/* eslint-disable import/no-named-as-default */

// Please modify as per you needs
import React from 'react';
import { render } from '@testing-library/react';
import { Default } from './Default';

jest.mock('../store/store', () => ({}));

jest.mock('@mep-ui/framework-router-addon', () => ({
  ...jest.requireActual('@mep-ui/framework-router-addon'),
  Outlet: () => <div data-testid="outlet">Outlet Content</div>,
  Routes: ({ children }: { children: React.ReactNode }) => (
    <div>{children}</div>
  ),
  Route: () => null,
}));

describe('Default', () => {
  it('should render with no routes', () => {
    const { container } = render(<Default routes={[]} />);

    expect(container).toMatchSnapshot();
  });

  it('should render with routes', () => {
    const { container } = render(
      <Default
        routes={[
          {
            path: '/path',
            id: 'id',
            element: () => <div>Test</div>,
            index: 0,
          },
        ]}
      />
    );

    expect(container).toMatchSnapshot();
  });
});
