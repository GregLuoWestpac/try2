import { useGlobalDispatch } from '@mep-ui/framework';
import { withIntent } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { INTENT_NAMES } from '../common/constants';
import { AddBeneficiaryContainer } from '../containers/AddBeneficiaryContainer';

export function AddBeneficiary() {
  return <AddBeneficiaryContainer />;
}

export default withIntent(
  useGlobalDispatch,
  INTENT_NAMES.CREATE_BENEFICIARY
)(AddBeneficiary);
