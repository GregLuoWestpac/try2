import '@testing-library/jest-dom';
import { render } from '@testing-library/react';
import React from 'react';
import { MemoryRouter } from 'react-router-dom';
import UpdateBeneficiary from './UpdateBeneficiary';

jest.mock('@mep-ui/framework-router-addon', () => {
  const mockNavigate = jest.fn();
  return {
    ...jest.requireActual('@mep-ui/framework-router-addon'),
    useNavigate: () => mockNavigate,
  };
});

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalDispatch: () => jest.fn(),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-utils'),
  withIntent: () => (Component: React.ComponentType) => Component, // Mock `withIntent`
}));
jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: function MockComponent({ children }: { children: React.ReactNode }) {
    return <div>{children}</div>;
  },
}));

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalDispatch: jest.fn(),
}));
jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useIntentListener: () => jest.fn(),
}));

jest.mock(
  '../containers/UpdateBeneficiaryContainer/UpdateBeneficiaryContainer',
  () => ({
    __esModule: true,
    default: () => <div>Mocked UpdateBeneficiaryContainer</div>,
  })
);

describe('UpdateBeneficiary', () => {
  it('should match snapshot', () => {
    const { container } = render(<UpdateBeneficiary />);
    expect(container).toMatchSnapshot();
  });

  it('should render UpdateBeneficiaryContainer', () => {
    const { getByText } = render(<UpdateBeneficiary />);
    expect(getByText('Mocked UpdateBeneficiaryContainer')).toBeInTheDocument();
  });
});
