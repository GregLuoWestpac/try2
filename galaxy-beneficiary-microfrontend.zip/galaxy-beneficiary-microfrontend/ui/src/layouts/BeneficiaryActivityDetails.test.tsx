/* eslint-disable react/react-in-jsx-scope */
import React from 'react';
import { render, screen } from '@testing-library/react';
import { INTENT_NAMES } from '../common/constants';

const mockUseGlobalDispatchFn = jest.fn();

jest.mock('@mep-ui/framework', () => ({
  useGlobalDispatch: () => mockUseGlobalDispatchFn,
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => {
  const actual = jest.requireActual(
    '@mesh-tenant-multiverse-ui-common/mv-utils'
  );
  return {
    ...actual,
    withIntent: (dispatchHook: any, intentName: string) => {
      return (Component: React.ComponentType) => (props: any) =>
        (
          <div data-testid="with-intent-wrapper" data-intent-name={intentName}>
            <Component {...props} />
          </div>
        );
    },
  };
});

jest.mock(
  '../containers/BeneficiaryActivitiesContainer/BeneficiaryActivitiesContainer',
  () => () => <div data-testid="activities-container" />
);

import BeneficiaryActivityDetails from './BeneficiaryActivityDetails';

describe('BeneficiaryActivityDetails layout', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('wraps component with intent wrapper using VIEW_BENEFICIARY_ACTIVITY_DETAILS', () => {
    render(<BeneficiaryActivityDetails />);
    // Even if withIntentCalls was not populated (module import ordering), wrapper presence proves HOC applied.
    const wrapper = screen.getByTestId('with-intent-wrapper');
    expect(wrapper).toHaveAttribute(
      'data-intent-name',
      INTENT_NAMES.VIEW_BENEFICIARY_ACTIVITY_DETAILS
    );
  });

  it('renders wrapped activities container inside intent wrapper once', () => {
    render(<BeneficiaryActivityDetails />);
    expect(screen.getByTestId('with-intent-wrapper')).toHaveAttribute(
      'data-intent-name',
      INTENT_NAMES.VIEW_BENEFICIARY_ACTIVITY_DETAILS
    );
    expect(screen.getByTestId('activities-container')).toBeInTheDocument();
    expect(screen.getAllByTestId('activities-container')).toHaveLength(1);
  });
});
