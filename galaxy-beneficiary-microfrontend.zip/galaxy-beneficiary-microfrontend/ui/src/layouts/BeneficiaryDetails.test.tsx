import '@testing-library/jest-dom';
import { render } from '@testing-library/react';
import React from 'react';
import { MemoryRouter } from 'react-router-dom';
import BeneficiaryDetails from './BeneficiaryDetails';

jest.mock('../store/store', () => ({
  __esModule: true,
  default: {
    dispatch: jest.fn(),
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-utils'),
  withIntent: () => (Component: React.ComponentType) => Component, // Mock `withIntent`
}));
jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: function MockComponent({ children }: { children: React.ReactNode }) {
    return <div>{children}</div>;
  },
}));

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalDispatch: jest.fn(),
}));
jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useIntentListener: () => jest.fn(),
}));

jest.mock(
  '../containers/BeneficiaryDetailsContainer/BeneficiaryDetailsContainer',
  () => {
    return function MockBeneficiaryDetailsContainer() {
      return <div>Mock BeneficiaryDetailsContainer</div>;
    };
  }
);

describe('BeneficiaryDetails', () => {
  it('should match snapshot', () => {
    const { container } = render(<BeneficiaryDetails />);
    expect(container).toMatchSnapshot();
  });

  it('should render BeneficiaryDetailsContainer', () => {
    const { getByText } = render(<BeneficiaryDetails />);
    expect(getByText('Mock BeneficiaryDetailsContainer')).toBeInTheDocument();
  });
});
