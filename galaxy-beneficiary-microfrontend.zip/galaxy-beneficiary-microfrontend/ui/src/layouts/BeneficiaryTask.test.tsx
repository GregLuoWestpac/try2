import '@testing-library/jest-dom';
import { render, screen } from '@testing-library/react';
import React from 'react';
import BeneficiaryTask from './BeneficiaryTask';

// Mock react-router-dom to avoid useRef issues with MemoryRouter
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn(),
  useLocation: () => ({ pathname: '/', search: '', hash: '', state: null }),
  useParams: () => ({}),
}));

jest.mock(
  '../containers/BeneficiaryTaskContainer/BeneficiaryTaskContainer',
  () => ({
    __esModule: true,
    default: function BeneficiaryTaskContainer() {
      return (
        <div data-testid="beneficiary-details-container">
          Mock BeneficiaryTaskContainer
        </div>
      );
    },
  })
);

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-utils'),
  withIntent: () => (Component: React.ComponentType) => Component,
}));

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useIntentListener: () => jest.fn(),
}));

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalDispatch: () => jest.fn(),
}));

describe('BeneficiaryDetails', () => {
  it('renders the BeneficiaryDetailsContainer', () => {
    render(<BeneficiaryTask />);
    expect(
      screen.getByTestId('beneficiary-details-container')
    ).toBeInTheDocument();
  });
});
