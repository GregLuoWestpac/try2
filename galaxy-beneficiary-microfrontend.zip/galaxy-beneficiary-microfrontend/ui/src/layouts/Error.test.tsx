// Note: the test case is generated from the template of @wdpui/create-react-library
// Please modify as per you needs
import React from 'react';
import { render } from '@testing-library/react';
import Error from './Error';

jest.mock('@westpac/ui', () => ({
  Grid: ({ children, className }: any) => (
    <div className={className}>{children}</div>
  ),
  GridItem: ({ children, className }: any) => (
    <div className={className}>{children}</div>
  ),
  Heading: ({ children, className, tag: Tag = 'h2' }: any) => (
    <Tag className={className}>{children}</Tag>
  ),
}));

jest.mock('@westpac/ui/icon', () => ({
  AlertIcon: () => <span data-testid="alert-icon">⚠</span>,
}));

describe('Error', () => {
  it('should render with Grid component', () => {
    const { container } = render(<Error />);
    expect(container).toMatchSnapshot();
  });
});
