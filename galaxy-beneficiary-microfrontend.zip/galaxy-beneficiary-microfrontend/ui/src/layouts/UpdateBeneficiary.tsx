import { useGlobalDispatch } from '@mep-ui/framework';
import { withIntent } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { INTENT_NAMES } from '../common/constants';
import UpdateBeneficiaryContainer from '../containers/UpdateBeneficiaryContainer/UpdateBeneficiaryContainer';

function UpdateBeneficiary() {
  return <UpdateBeneficiaryContainer />;
}

export default withIntent(
  useGlobalDispatch,
  INTENT_NAMES.UPDATE_BENEFICIARY
)(UpdateBeneficiary);
