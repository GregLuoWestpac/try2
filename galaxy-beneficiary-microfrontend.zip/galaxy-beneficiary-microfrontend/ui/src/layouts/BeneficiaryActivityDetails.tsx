import { useGlobalDispatch } from '@mep-ui/framework';
import { withIntent } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { INTENT_NAMES } from '../common/constants';
import BeneficiaryActivitiesContainer from '../containers/BeneficiaryActivitiesContainer/BeneficiaryActivitiesContainer';

function BeneficiaryActivityDetails() {
  return <BeneficiaryActivitiesContainer />;
}

export default withIntent(
  useGlobalDispatch,
  INTENT_NAMES.VIEW_BENEFICIARY_ACTIVITY_DETAILS
)(BeneficiaryActivityDetails);
