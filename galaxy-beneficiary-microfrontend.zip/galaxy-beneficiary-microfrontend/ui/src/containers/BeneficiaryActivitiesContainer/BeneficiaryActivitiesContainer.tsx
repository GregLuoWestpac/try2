import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from '@mep-ui/framework-router-addon';
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import { useClose } from '@mesh-tenant-multiverse-common/react';
import { Button, GridItem } from '@westpac/ui';
import {
  getFormattedDateTime,
  getURLParams,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { useGlobalSelector } from '@mep-ui/framework';
import { Beneficiary, GlobalState } from '../../store/types';
import { BeneficiaryActivityLogEntryType } from '../../common/Beneficiary.util';
import { BeneficiaryActivityLog } from '../../components/BeneficiaryActivityLog';
import {
  MVRefresh,
  MVRefreshHandle,
} from '@mesh-tenant-multiverse-ui-common/mv-refresh';
import GalaxyMakerCheckerWrapper from '../../widgets/galaxymakerchecker-v1';
import { ErrorHandler, PageLoader } from '../../components';
import { beneSubtitle } from '../../components/BeneficiaryActivityLog/BeneficiaryActivityLog.utils';
import { useWidgetLoaded } from '../../hooks/useWidgetLoaded';

function BeneficiaryActivitiesContainer() {
  const navigate = useNavigate();
  const [activityList, setActivityList] = useState<
    BeneficiaryActivityLogEntryType[]
  >([]);
  const [isActivityListFetching, setIsActivityListFetching] = useState(false);
  const [isActivityListFetchingError, setIsActivityListFetchingError] =
    useState(false);
  const refreshWidgetRef = useRef<MVRefreshHandle>(null);
  const [refreshTrigger, setRefreshTrigger] = useState<number | null>(null);
  const { closeTab } = useClose();
  const [isLoadingWidget] = useWidgetLoaded();

  const selectedBeneficiary: Beneficiary = useGlobalSelector(
    (state: GlobalState) => state?.global?.galaxy?.context?.selectedBeneficiary
  );
  const intentTimestamp: string | null = useGlobalSelector(
    (state: GlobalState) =>
      state?.global?.galaxy?.context?.intentTimestamp ?? null
  );

  useEffect(() => {
    if (!selectedBeneficiary || !selectedBeneficiary?.id) {
      navigate(`/beneficiary${getURLParams()}`);
    }
  }, []);

  useEffect(() => {
    setIsActivityListFetching(true);
    setRefreshTrigger(Date.now());
  }, [intentTimestamp]);

  const onRefresh = () => {
    setRefreshTrigger(Date.now());
    refreshWidgetRef.current?.refreshDateTime();
  };

  const onApiResponse = (res: any) => {
    const activityList = res?.data?.entities?.activityList;

    if (activityList) {
      const dateFormattedActivityList = activityList.map((item: any) => ({
        ...item,
        date: getFormattedDateTime(item?.date),
      }));
      setActivityList(dateFormattedActivityList);
      setIsActivityListFetching(false);
      setIsActivityListFetchingError(false);
    } else {
      console.error('API Error: error fetching activity list');
      setActivityList([]);
      setIsActivityListFetching(false);
      setIsActivityListFetchingError(true);
    }
  };

  const onApiError = (err: any) => {
    console.error('API Error: error fetching activity list');
    setActivityList([]);
    setIsActivityListFetching(false);
    setIsActivityListFetchingError(true);
  };

  const renderBeneficiaryActivityLogs = () => {
    return (
      <div className="my-2.5">
        {(isActivityListFetching || isLoadingWidget) && (
          <PageLoader iconSize="medium" />
        )}
        {isActivityListFetchingError && (
          <ErrorHandler
            onRefresh={() => {
              setIsActivityListFetching(true);
              setIsActivityListFetchingError(false);
              refreshWidgetRef.current?.refreshDateTime();
              setRefreshTrigger(Date.now());
            }}
            errorMessage="Something went wrong."
            className="mb-0"
          />
        )}
        {!isActivityListFetching && !isActivityListFetchingError && (
          <BeneficiaryActivityLog beneficiaryActivityDetails={activityList} />
        )}
      </div>
    );
  };

  return (
    <MVCard
      title="Beneficiary activity details"
      subtitle={beneSubtitle(selectedBeneficiary)}
      bottomDivider={false}
    >
      <div className="mb-0">
        <MVRefresh onRefresh={onRefresh} ref={refreshWidgetRef} />
      </div>
      {refreshTrigger && (
        <GalaxyMakerCheckerWrapper
          apiName="getActivityList"
          params={{}}
          options={{
            headers: { 'x-channelRequestId': selectedBeneficiary?.id },
          }}
          trigger={refreshTrigger}
          onApiResponse={onApiResponse}
          onApiError={onApiError}
        />
      )}
      {renderBeneficiaryActivityLogs()}
      <GridItem
        className="w-full border-t border-border pt-2.5 mt-0 flex gap-[9px]"
        span={12}
      >
        <Button
          soft
          look="hero"
          size="small"
          onClick={async () => await closeTab()}
          data-testid="close-button"
        >
          Close
        </Button>
      </GridItem>
    </MVCard>
  );
}

export default BeneficiaryActivitiesContainer;
