/* eslint-disable react/react-in-jsx-scope */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-var-requires */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import BeneficiaryActivitiesContainer from './BeneficiaryActivitiesContainer';

// Shim webpack chunk registry expected by mv-reacthookform
// eslint-disable-next-line @typescript-eslint/no-explicit-any
(global as any).webpackChunkmvReacthookform =
  (global as any).webpackChunkmvReacthookform || [];
// Mock mv-reacthookform date utilities used by code paths
jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  DATE_FORMAT_YYYYMMDD: 'YYYY-MM-DD',
  getToday: () => ({ toFormat: (_fmt: string) => '2025-12-02' }),
  getTodayAtLastYear: () => ({ toFormat: (_fmt: string) => '2024-12-02' }),
}));

// Mocks
const mockCloseTab = jest.fn();
const mockUseGlobalSelector = jest.fn();

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useClose: jest.fn(() => ({ closeTab: mockCloseTab })),
}));

// Mock hook to indicate widget has loaded (no loader)
jest.mock('ui/src/hooks/useWidgetLoaded', () => ({
  useWidgetLoaded: () => [false],
}));

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalSelector: (fn: any) => mockUseGlobalSelector(),
  useGlobalDispatch: () => jest.fn(),
  connect: () => (component: React.ComponentType<any>) => component,
  compose:
    (..._args: any[]) =>
    (component: React.ComponentType<any>) =>
      component,
}));
// Prevent null store errors from useManifest by returning a stubbed manifest
useManifest: () => ({
  isLoading: false,
  isError: false,
  manifest: { widgets: {} },
});

const mockNavigate = jest.fn();

jest.mock('@mep-ui/framework-router-addon', () => {
  const actual = jest.requireActual('@mep-ui/framework-router-addon');
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});

// Mock components
jest.mock('../../components/BeneficiaryActivityLog', () => ({
  BeneficiaryActivityLog: () => (
    <div data-testid="activity-log">Activity Log</div>
  ),
}));

// Mock shared components to avoid rendering ProgressIndicator from @westpac/ui
jest.mock('../../components', () => ({
  PageLoader: () => <div data-testid="page-loader-mock">Loading...</div>,
  ErrorHandler: ({ onRefresh }: any) => (
    <button data-testid="error-handler-mock" onClick={onRefresh}>
      Retry
    </button>
  ),
}));

// Mock GalaxyMakerCheckerWrapper to avoid relying on useManifest/module federation entirely
jest.mock('../../widgets/galaxymakerchecker-v1', () => ({
  __esModule: true,
  default: (props: any) => {
    // Ensure fetching flag is cleared
    props.onApiCallUpdate?.({ isLoading: false });
    // Simulate a successful API response after mount
    setTimeout(() => {
      props.onApiResponse?.({
        data: {
          entities: {
            activityList: [
              {
                date: '2024-01-10T10:15:22Z',
                user: 'Tester',
                activity: 'beneficiaryCreate',
                activityStatus: 'Authorised',
                activityDetail: {
                  accountDetail: '062-948 222227777',
                  accountName: 'Unit Test Pty Ltd',
                  beneficiaryNickname: 'UT Bene',
                },
              },
            ],
          },
        },
      });
    }, 0);
    return (
      <div
        data-testid="galaxy-maker-checker"
        data-api-name={props.apiName}
        data-trigger={props.trigger}
      />
    );
  },
}));

// Provide global chunk array to satisfy mv-refresh module federation expectations
// eslint-disable-next-line @typescript-eslint/no-explicit-any
(global as any).webpackChunkmvRefresh =
  (global as any).webpackChunkmvRefresh || [];
// Mock MVRefresh to avoid importing remote chunk
jest.mock('@mesh-tenant-multiverse-ui-common/mv-refresh', () => ({
  MVRefresh: ({ onRefresh }: any) => (
    <button data-testid="refresh-btn" onClick={onRefresh}>
      Refresh
    </button>
  ),
  MVRefreshHandle: jest.fn(),
}));

// Simplify MVCard to capture props
jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: ({ title, template, bottomDivider, children }: any) => (
    <div
      data-testid="mv-card"
      data-title={title}
      data-template={template}
      data-bottom-divider={bottomDivider}
    >
      {children}
    </div>
  ),
}));

// Simplify UI components
jest.mock('@westpac/ui', () => ({
  Button: ({
    children,
    onClick,
    className,
    'data-testid': dataTestId,
    look,
    size,
    soft,
  }: any) => (
    <button
      type="button"
      data-testid={dataTestId || 'button'}
      data-look={look}
      data-size={size}
      data-soft={soft ? 'true' : 'false'}
      className={className}
      onClick={onClick}
    >
      {children}
    </button>
  ),
  GridItem: ({ children, className, span }: any) => (
    <div data-testid="grid-item" data-span={span} className={className}>
      {children}
    </div>
  ),
}));

describe('BeneficiaryActivitiesContainer', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders MVCard with expected structural props', () => {
    render(<BeneficiaryActivitiesContainer />);
    const card = screen.getByTestId('mv-card');
    expect(card).toBeInTheDocument();
    expect(card).toHaveAttribute('data-title', 'Beneficiary activity details');
    expect(card).toHaveAttribute('data-bottom-divider', 'false');
  });

  it('renders close button with expected attributes', () => {
    render(<BeneficiaryActivitiesContainer />);
    const button = screen.getByTestId('close-button');
    expect(button).toBeInTheDocument();
    expect(button).toHaveTextContent('Close');
    expect(button).toHaveAttribute('data-look', 'hero');
    expect(button).toHaveAttribute('data-size', 'small');
    expect(button).toHaveAttribute('data-soft', 'true');
  });

  it('applies expected Tailwind utility classes to layout container', () => {
    render(<BeneficiaryActivitiesContainer />);
    const gridItem = screen.getByTestId('grid-item');
    const expectedClasses = ['w-full', 'pt-2.5', 'mt-0', 'flex', 'gap-[9px]'];
    expectedClasses.forEach(c => {
      expect(gridItem.className.split(' ')).toContain(c);
    });
  });

  it('invokes closeTab when Close button is clicked', async () => {
    render(<BeneficiaryActivitiesContainer />);
    const button = screen.getByTestId('close-button');
    fireEvent.click(button);
    await waitFor(() => {
      expect(mockCloseTab).toHaveBeenCalledTimes(1);
    });
  });

  it('does not call closeTab before interaction', () => {
    render(<BeneficiaryActivitiesContainer />);
    expect(mockCloseTab).not.toHaveBeenCalled();
  });

  it('displays BeneficiaryActivityLog when data is loaded successfully', async () => {
    // First selector call returns selectedBeneficiary, second returns intentTimestamp
    mockUseGlobalSelector
      .mockReturnValueOnce({
        id: 'bene-activity',
        nickname: 'Activity Bene',
        type: 'ACCOUNT',
        account: { accountId: { BSB: '062948', accountNumber: '222227777' } },
      })
      .mockReturnValueOnce(null);
    render(<BeneficiaryActivitiesContainer />);
    // Wait for loader to disappear
    await waitFor(() => {
      expect(screen.queryByTestId('page-loader-mock')).not.toBeInTheDocument();
    });
    // Then activity log should be present
    await waitFor(() => {
      expect(screen.getByTestId('activity-log')).toBeInTheDocument();
    });
  });

  it('calls navigate when selectedBeneficiary is missing', () => {
    mockUseGlobalSelector.mockReturnValueOnce(null);

    render(<BeneficiaryActivitiesContainer />);

    expect(mockNavigate).toHaveBeenCalledWith(
      expect.stringContaining('/beneficiary')
    );
  });

  it('shows ErrorHandler when API errors and hides activity log', async () => {
    // Ensure selected beneficiary present
    mockUseGlobalSelector.mockReturnValueOnce({
      id: 'bene-error',
      nickname: 'Error Bene',
      type: 'ACCOUNT',
      account: { accountId: { BSB: '062948', accountNumber: '222227777' } },
    });

    // Override widget mock temporarily to fire onApiError
    const widgetModule = require('../../widgets/galaxymakerchecker-v1');
    const OriginalWidget = widgetModule.default;
    widgetModule.default = (props: any) => {
      setTimeout(() => {
        props.onApiError?.(new Error('Network error'));
      }, 0);
      return (
        <div
          data-testid="galaxy-maker-checker"
          data-api-name={props.apiName}
          data-trigger={props.trigger}
        />
      );
    };

    render(<BeneficiaryActivitiesContainer />);

    // Wait for loader to disappear (fetching false after error)
    await waitFor(() => {
      expect(screen.queryByTestId('page-loader-mock')).not.toBeInTheDocument();
    });

    // Error handler should be visible, activity log should not
    expect(screen.getByTestId('error-handler-mock')).toBeInTheDocument();
    expect(screen.queryByTestId('activity-log')).not.toBeInTheDocument();

    // Restore original widget mock
    widgetModule.default = OriginalWidget;
  });
});
