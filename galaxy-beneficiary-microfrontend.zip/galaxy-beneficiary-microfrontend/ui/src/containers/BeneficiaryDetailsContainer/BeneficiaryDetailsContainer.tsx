/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import {
  compose,
  connect,
  useGlobalDispatch,
  useGlobalSelector,
} from '@mep-ui/framework';
import { useNavigate } from '@mep-ui/framework-router-addon';
import {
  useClose,
  usePlatformState,
} from '@mesh-tenant-multiverse-common/react';
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import {
  getURLParams,
  useHandleRaiseIntent,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { MVPageLoader as PageLoader } from '@mesh-tenant-multiverse-ui-common/mv-pageloader';
import {
  Actions,
  Resources,
  useAuthoriser,
} from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import { Button, Grid, GridItem, ProgressIndicator } from '@westpac/ui';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useOverlayTriggerState } from 'react-stately';
import {
  INTENT_NAMES,
  INTENTS_CONTEXT_NAME,
  PAGE_NAVIGATION,
  W1_ORGANIZATION_SSO,
} from '../../common';
import {
  BeneficiaryArchive,
  BeneficiarySummary,
  BeneficiaryActivity,
  ErrorHandler,
} from '../../components';
import NotificationAlert from '../../components/NotificationAlert/NotificationAlert';
import {
  beneficiaryArchiveActions,
  beneficiaryArchiveEntityActions,
  beneficiaryDetailsActions,
  beneficiaryDetailsEntityActions,
  beneficiaryStatusUpdateActions,
  beneficiaryStatusUpdateEntityActions,
  getAllBeneficiaryDetails,
  isBeneficiaryArchiveError as isBeneficiariesArchiveErrorSelector,
  isBeneficiaryArchiveFetching as isBeneficiariesArchiveFetchingSelector,
  isBeneficiaryDetailsError as isBeneficiaryDetailsErrorSelector,
  isBeneficiaryDetailsFetching as isBeneficiaryDetailsFetchingSelector,
  isBeneficiaryStatusUpdateError as isBeneficiaryStatusUpdateErrorSelector,
  isBeneficiaryStatusUpdateFetching as isBeneficiaryStatusUpdateFetchingSelector,
} from '../../store/generated';
import {
  getBeneficiaryArchiveErrors,
  getBeneficiaryStatusUpdateErrors,
} from '../../store/selectors';
import store from '../../store/store';
import {
  ArchiveBeneficiaryParamsPayload,
  type Beneficiary,
  BENEFICIARY_STATUS,
  BeneficiaryError,
  BeneficiaryOptionsPayload,
  GlobalState,
  type PostBeneficiaryDetailsParams,
  type PostBeneficiaryDetailsParamsPayload,
  PostBeneficiaryStatusUpdateParamsPayload,
  type RootState,
} from '../../store/types';

import { updateBeneficiaryKey } from '../../common/Beneficiary.util';
import { useHandleArchiveBeneficiary } from './hooks/useHandleArchiveBeneficiary';
import { GalaxyMakerCheckerWrapper } from '../../widgets/galaxymakerchecker-v1';
import { BeneficiaryActivitySummary } from '../../components/BeneficiaryActivity/BeneficiaryActivity.types';
import { useWidgetLoaded } from '../../hooks/useWidgetLoaded';
import { BeneficiaryPaymentDetails } from '../../components/BeneficiaryPaymentDetails/BeneficiaryPaymentDetails';

export type BeneficiaryDetailsContainerProps = {
  beneficiaryDetails: Beneficiary[];
  isBeneficiaryDetailsFetching: boolean;
  isBeneficiaryDetailsError: boolean;
  getBeneficiaryDetails: (params: PostBeneficiaryDetailsParamsPayload) => void;
  archiveBeneficiary: (
    params: ArchiveBeneficiaryParamsPayload,
    options: BeneficiaryOptionsPayload
  ) => void;
  isArchiveBeneficiaryFetching: boolean;
  isArchiveBeneficiaryError: boolean;
  archiveBeneficiaryErrors: BeneficiaryError | undefined;
  isBeneficiaryStatusUpdateError: boolean;
  isBeneficiaryStatusUpdateFetching: boolean;
  beneficiaryStatusUpdateErrors: BeneficiaryError;
  beneficiaryStatusUpdate: (
    payload: PostBeneficiaryStatusUpdateParamsPayload
  ) => void;
  clearBeneficiaryStatusUpdate: () => void;
  clearArchiveBeneficiary: () => void;
};

function BeneficiaryDetailsContainer({
  beneficiaryDetails,
  isBeneficiaryDetailsFetching,
  isBeneficiaryDetailsError,
  getBeneficiaryDetails,
  archiveBeneficiary,
  isArchiveBeneficiaryFetching = false,
  isArchiveBeneficiaryError = false,
  archiveBeneficiaryErrors,
  isBeneficiaryStatusUpdateError,
  isBeneficiaryStatusUpdateFetching,
  beneficiaryStatusUpdate,
  beneficiaryStatusUpdateErrors,
  clearArchiveBeneficiary,
  clearBeneficiaryStatusUpdate,
}: BeneficiaryDetailsContainerProps) {
  const [trigger, setTrigger] = useState<number | null>(null);

  const [isActivitySummaryFetching, setIsActivitySummaryFetching] =
    useState(true);
  const [isActivitySummaryFetchingError, setIsActivitySummaryFetchingError] =
    useState(false);
  const [activitySummary, setActivitySummary] =
    useState<BeneficiaryActivitySummary | null>(null);

  const [isLoadingWidget] = useWidgetLoaded();

  const hasActivityLoadedRef = useRef(false); // to track if activity has loaded at least once
  const [isLoading, setIsLoading] = useState(true);

  const navigate = useNavigate();
  const archiveBeneficiaryModalState = useOverlayTriggerState({});

  const [organisationSSOData] = usePlatformState(W1_ORGANIZATION_SSO, {
    orgId: {
      organisationId: '',
    },
  });

  const organisationId: string =
    window.location.hostname === 'localhost'
      ? '12345678910'
      : organisationSSOData?.orgId?.organisationId;

  const { authorised: isUserAuthorizedToUpdateBeneficiaries } = useAuthoriser(
    Resources.BENEFICIARY,
    Actions.MODIFY_BENEFICIARY
  );

  const { authorised: isUserAuthorizedToArchiveBeneficiaries } = useAuthoriser(
    Resources.BENEFICIARY,
    Actions.ARCHIVE_BENEFICIARY
  );

  const selectedBeneficiary: Beneficiary = useGlobalSelector(
    (state: GlobalState) => state?.global?.galaxy?.context?.selectedBeneficiary
  );

  const intentTimestamp: string | null = useGlobalSelector(
    (state: GlobalState) =>
      state?.global?.galaxy?.context?.intentTimestamp ?? null
  );

  const selectedBeneficiaryId = selectedBeneficiary?.id;

  const { closeTab } = useClose();

  const beneficiaryDetail = beneficiaryDetails?.[0] ?? {};

  const [shouldRefresh, setShouldRefresh] = useState(true);

  const resetShouldRefresh = () => {
    setShouldRefresh(false);
  };

  const handleRaiseIntent = useHandleRaiseIntent(
    useGlobalDispatch,
    useNavigate
  );

  const onOpenArchiveBeneficiaryModal = () => {
    archiveBeneficiaryModalState.open();
  };

  const handleCloseTab = async () => {
    await closeTab();
  };

  useEffect(() => {
    if (selectedBeneficiary?.id && shouldRefresh) {
      setIsActivitySummaryFetching(true);
      setTrigger(Date.now());
      const postBeneficiaryDetailsParams: PostBeneficiaryDetailsParams = {
        id: selectedBeneficiary.id,
      };

      const params: PostBeneficiaryDetailsParamsPayload = {
        params: postBeneficiaryDetailsParams,
        meta: {
          replaceEntities: ['beneficiaryDetails'],
        },
      };

      getBeneficiaryDetails(params);
      resetShouldRefresh();
    }
  }, [
    selectedBeneficiary?.id,
    intentTimestamp,
    shouldRefresh,
    getBeneficiaryDetails,
  ]);

  useEffect(() => {
    if (
      isLoadingWidget ||
      isBeneficiaryDetailsFetching ||
      !beneficiaryDetails?.length ||
      (!hasActivityLoadedRef.current && isActivitySummaryFetching) // first activity load (making sure activity-section spinner does not appear on first load)
    ) {
      setIsLoading(true);
    } else {
      setIsLoading(false);
    }
  }, [
    isLoadingWidget,
    isBeneficiaryDetailsFetching,
    isActivitySummaryFetching,
    beneficiaryDetails,
  ]);

  useEffect(() => {
    if (!selectedBeneficiary?.id) {
      navigate(`/beneficiary${getURLParams()}`);
    }
  }, []);

  const onApiResponse = (
    res: {
      data?: { entities?: { activitySummary?: BeneficiaryActivitySummary[] } };
    } = {}
  ) => {
    setIsActivitySummaryFetching(false);
    const summaryArray = res.data?.entities?.activitySummary;
    if (summaryArray && summaryArray.length > 0) {
      setActivitySummary(summaryArray[0]);
      setIsActivitySummaryFetchingError(false);
    } else {
      console.error('API Error: error fetching activity summary');
      setActivitySummary(null);
      setIsActivitySummaryFetchingError(true);
    }
    hasActivityLoadedRef.current = true;
  };

  const onApiError = () => {
    console.error('API Error: error fetching activity summary');
    setActivitySummary(null);
    setIsActivitySummaryFetching(false);
    setIsActivitySummaryFetchingError(true);
    hasActivityLoadedRef.current = true;
  };

  const refreshBeneficiaryActivity = useCallback(() => {
    setIsActivitySummaryFetching(true);
    setIsActivitySummaryFetchingError(false);
    setTrigger(Date.now());
  }, [setTrigger]);

  const onClickUpdateBeneficiary = async (beneficiary: Beneficiary) => {
    await handleRaiseIntent({
      intentName: INTENT_NAMES.UPDATE_BENEFICIARY,
      data: {
        beneficiaryToBeUpdated: beneficiary,
      },
      contextKey: updateBeneficiaryKey(beneficiary.id),
      intentContextName: INTENTS_CONTEXT_NAME.BENEFICIARY,
      targetPath: PAGE_NAVIGATION.UPDATE_BENEFICIARY,
    });
    await closeTab();
  };

  const { onArchiveClick } = useHandleArchiveBeneficiary({
    isArchiveBeneficiaryError,
    isArchiveBeneficiaryFetching,
    archiveBeneficiaryErrors,
    beneficiaryDetails,
    archiveBeneficiary,
    selectedBeneficiaryId,
    archiveBeneficiaryModalState,
    organisationId,
    isBeneficiaryStatusUpdateError,
    isBeneficiaryStatusUpdateFetching,
    beneficiaryStatusUpdate,
    clearArchiveBeneficiary,
    clearBeneficiaryStatusUpdate,
    beneficiaryStatusUpdateErrors,
  });

  const isArchiveBeneficiary =
    isArchiveBeneficiaryFetching || isBeneficiaryStatusUpdateFetching;

  if (isBeneficiaryDetailsError && !isBeneficiaryDetailsFetching) {
    return (
      <MVCard
        title="Beneficiary details"
        template="narrow"
        bottomDivider={false}
      >
        <ErrorHandler
          className="mb-2.5"
          width="full"
          errorMessage="Something went wrong."
          onRefresh={() => {
            setShouldRefresh(true);
            // incase the activity summary also failed previously
            if (!activitySummary || isActivitySummaryFetchingError) {
              refreshBeneficiaryActivity();
            }
          }}
        />
        <Grid>
          <GridItem
            span={12}
            className="w-full border-t border-border pt-2.5 mt-0 flex gap-[9px]"
          >
            <Button look="hero" soft size="small" onClick={handleCloseTab}>
              Close
            </Button>
          </GridItem>
        </Grid>
      </MVCard>
    );
  }

  const activityOptions =
    selectedBeneficiary?.id != null
      ? { headers: { 'x-channelRequestId': selectedBeneficiary.id } }
      : undefined;

  return (
    <>
      {trigger && (
        <GalaxyMakerCheckerWrapper
          apiName="getActivitySummary"
          params={{}}
          options={activityOptions}
          trigger={trigger}
          onApiResponse={onApiResponse}
          onApiError={onApiError}
        />
      )}

      {isArchiveBeneficiary && (
        <div className="fixed inset-0 flex justify-center items-center bg-border bg-opacity-75 z-50">
          <ProgressIndicator data-testid="progress-indicator" size="medium" />
        </div>
      )}
      <MVCard
        title="Beneficiary details"
        template="narrow"
        bottomDivider={!isLoading}
      >
        {isLoading ? (
          <PageLoader iconSize="medium" />
        ) : (
          <>
            <NotificationAlert />
            <Grid className="xsl:gap-0 sm:gap-0 !gap-0">
              <BeneficiaryArchive
                state={archiveBeneficiaryModalState}
                beneficiaryNickName={beneficiaryDetail.nickname}
                onArchiveClick={onArchiveClick}
              />
              <BeneficiarySummary beneficiaryDetails={beneficiaryDetail} />

              <BeneficiaryPaymentDetails
                beneficiaryDetails={beneficiaryDetail}
              />

              <BeneficiaryActivity
                activitySummary={activitySummary}
                isLoading={
                  isActivitySummaryFetching && hasActivityLoadedRef.current
                }
                isError={isActivitySummaryFetchingError}
                onRetry={() => {
                  refreshBeneficiaryActivity();
                }}
              />
            </Grid>
            <GridItem
              className="w-full border-t border-border pt-2.5 mt-0 flex gap-[9px]"
              span={12}
            >
              <Button
                soft
                look="hero"
                size="small"
                onClick={handleCloseTab}
                data-testid="close-button"
              >
                Close
              </Button>
              {beneficiaryDetail.status === BENEFICIARY_STATUS.ACTIVE && (
                <>
                  {isUserAuthorizedToUpdateBeneficiaries ? (
                    <Button
                      look="hero"
                      soft
                      size="small"
                      onClick={() =>
                        onClickUpdateBeneficiary(beneficiaryDetail)
                      }
                    >
                      Update
                    </Button>
                  ) : null}
                  {isUserAuthorizedToArchiveBeneficiaries ? (
                    <Button
                      onClick={onOpenArchiveBeneficiaryModal}
                      look="hero"
                      soft
                      data-testid="archive-button"
                      size="small"
                    >
                      Archive
                    </Button>
                  ) : null}
                </>
              )}
            </GridItem>
          </>
        )}
      </MVCard>
    </>
  );
}

const mapStateToProps = (state: RootState) => ({
  beneficiaryDetails: getAllBeneficiaryDetails(state),
  isBeneficiaryDetailsFetching: isBeneficiaryDetailsFetchingSelector(state),
  isBeneficiaryDetailsError: isBeneficiaryDetailsErrorSelector(state),
  isArchiveBeneficiaryFetching: isBeneficiariesArchiveFetchingSelector(state),
  isArchiveBeneficiaryError: isBeneficiariesArchiveErrorSelector(state),
  archiveBeneficiaryErrors: getBeneficiaryArchiveErrors(state),
  isBeneficiaryStatusUpdateFetching:
    isBeneficiaryStatusUpdateFetchingSelector(state),
  isBeneficiaryStatusUpdateError: isBeneficiaryStatusUpdateErrorSelector(state),
  beneficiaryStatusUpdateErrors: getBeneficiaryStatusUpdateErrors(state),
});

const mapDispatchToProps = {
  getBeneficiaryDetails:
    beneficiaryDetailsActions.api.expGalaxyBeneficiaryV2.beneficiaryDetails.post
      .request,
  clearBeneficiaryDetails:
    beneficiaryDetailsEntityActions.api.expGalaxyBeneficiaryV2
      .beneficiaryDetails.clear.request,
  archiveBeneficiary:
    beneficiaryArchiveActions.api.expGalaxyBeneficiaryV2.beneficiaryArchive.post
      .request,
  beneficiaryStatusUpdate:
    beneficiaryStatusUpdateActions.api.expGalaxyBeneficiaryV2
      .beneficiaryStatusUpdate.post.request,
  clearBeneficiaryStatusUpdate:
    beneficiaryStatusUpdateEntityActions.api.expGalaxyBeneficiaryV2
      .beneficiaryStatusUpdate.clear.request,
  clearArchiveBeneficiary:
    beneficiaryArchiveEntityActions.api.expGalaxyBeneficiaryV2
      .beneficiaryArchive.clear.request,
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps, null, {
    context: store.contextRef,
  })
)(BeneficiaryDetailsContainer);
