export { default as BeneficiaryDetailsContainer } from './BeneficiaryDetailsContainer';
