/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-explicit-any */

import { renderHook, waitFor } from '@testing-library/react';
import { useHandleArchiveBeneficiary } from './useHandleArchiveBeneficiary';
import {
  BENEFICIARY_COSMIC_STATUS,
  BENEFICIARY_STATUS,
  BENEFICIARY_TYPE,
} from '../../../store/types';

// Mock mv-reacthookform to prevent webpack chunk loading issues
jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  DATE_FORMAT_YYYYMMDD: 'YYYY-MM-DD',
  getToday: jest.fn(() => ({
    toFormat: jest.fn(() => '2024-01-01'),
  })),
  getTodayAtLastYear: jest.fn(() => ({
    toFormat: jest.fn(() => '2023-01-01'),
  })),
}));

const mockGlobalDispatch = jest.fn();
const mockHandleRedirectToBeneficiaryList = jest
  .fn()
  .mockResolvedValue(undefined);

jest.mock('@mep-ui/framework', () => ({
  useGlobalDispatch: () => mockGlobalDispatch,
}));

jest.mock('../../../common/BeneficiaryList.util', () => ({
  useHandleRedirectToBeneficiaryList: () => mockHandleRedirectToBeneficiaryList,
}));

const mockRevertStatusAndRedirect = jest.fn();
jest.mock('../../../hooks/useRevertBeneficiaryStatus', () => ({
  useRevertBeneficiaryStatus: () => ({
    revertStatusAndRedirect: mockRevertStatusAndRedirect,
    isRevertingToActive: false,
  }),
}));

describe('useHandleArchiveBeneficiary', () => {
  const mockArchiveBeneficiary = jest.fn();
  const mockBeneficiaryStatusUpdate = jest.fn();
  const mockClearArchiveBeneficiary = jest.fn();
  const mockClearBeneficiaryStatusUpdate = jest.fn();
  const mockArchiveBeneficiaryModalClose = jest.fn();

  const beneficiaryDetail: any = {
    id: 'test-beneficiary-id',
    externalId: 'test-external-id',
    nickname: 'Test Beneficiary',
    currency: 'AUD',
    org: 'test-org',
    status: BENEFICIARY_STATUS.ACTIVE,
    type: BENEFICIARY_TYPE.ACCOUNT,
    account: {
      accountId: {
        BSB: '123456',
        accountNumber: '12345678',
      },
      bankName: 'Test Bank',
      accountName: 'Test Account',
    },
  };

  const defaultProps = {
    isArchiveBeneficiaryError: false,
    isArchiveBeneficiaryFetching: false,
    archiveBeneficiaryErrors: undefined,
    beneficiaryDetails: [beneficiaryDetail],
    archiveBeneficiary: mockArchiveBeneficiary,
    selectedBeneficiaryId: 'test-beneficiary-id',
    archiveBeneficiaryModalState: { close: mockArchiveBeneficiaryModalClose },
    organisationId: 'test-org-id',
    isBeneficiaryStatusUpdateError: false,
    isBeneficiaryStatusUpdateFetching: false,
    beneficiaryStatusUpdate: mockBeneficiaryStatusUpdate,
    clearArchiveBeneficiary: mockClearArchiveBeneficiary,
    clearBeneficiaryStatusUpdate: mockClearBeneficiaryStatusUpdate,
    beneficiaryStatusUpdateErrors: {} as any,
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('onArchiveClick flow', () => {
    it('should call beneficiaryStatusUpdate with ON_HOLD status when onArchiveClick is called', () => {
      const { result } = renderHook(() =>
        useHandleArchiveBeneficiary(defaultProps)
      );

      result.current.onArchiveClick();

      expect(mockClearArchiveBeneficiary).toHaveBeenCalledTimes(1);
      expect(mockClearBeneficiaryStatusUpdate).toHaveBeenCalledTimes(1);
      expect(mockBeneficiaryStatusUpdate).toHaveBeenCalledWith({
        params: {
          beneficiary: {
            id: 'test-beneficiary-id',
            status: BENEFICIARY_COSMIC_STATUS.ON_HOLD,
          },
        },
      });
    });

    it('should close archive modal when onArchiveClick is called', () => {
      const { result } = renderHook(() =>
        useHandleArchiveBeneficiary(defaultProps)
      );

      result.current.onArchiveClick();

      expect(mockArchiveBeneficiaryModalClose).toHaveBeenCalledTimes(1);
    });
  });

  describe('status update success flow', () => {
    it('should call archiveBeneficiary when status update succeeds', async () => {
      const { result, rerender } = renderHook(
        props => useHandleArchiveBeneficiary(props),
        { initialProps: defaultProps }
      );

      // Initiate archive
      result.current.onArchiveClick();

      // Simulate status update in progress
      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: true,
      });

      // Simulate status update success
      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: false,
        isBeneficiaryStatusUpdateError: false,
      });

      await waitFor(() => {
        expect(mockArchiveBeneficiary).toHaveBeenCalledWith(
          {
            params: {
              beneficiary: {
                id: 'test-beneficiary-id',
                externalId: 'test-external-id',
                nickname: 'Test Beneficiary',
                currency: 'AUD',
                org: 'test-org',
                type: BENEFICIARY_TYPE.ACCOUNT,
                account: {
                  accountId: {
                    BSB: '123456',
                    accountNumber: '12345678',
                  },
                  bankName: 'Test Bank',
                  accountName: 'Test Account',
                },
              },
            },
            meta: {
              replaceEntities: ['beneficiaryArchive'],
            },
          },
          {
            headers: {
              'x-channelRequestId': 'test-beneficiary-id',
              'protected-orgId': 'test-org-id',
            },
          }
        );
      });
    });

    it('should redirect to beneficiary list when archive succeeds', async () => {
      const { result, rerender } = renderHook(
        props => useHandleArchiveBeneficiary(props),
        { initialProps: defaultProps }
      );

      // Initiate archive
      result.current.onArchiveClick();

      // Simulate status update success
      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: false,
        isBeneficiaryStatusUpdateError: false,
      });

      // Simulate archive success
      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: false,
        isBeneficiaryStatusUpdateError: false,
        isArchiveBeneficiaryFetching: false,
        isArchiveBeneficiaryError: false,
      });

      await waitFor(() => {
        expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
          'success',
          {
            nickname: 'Test Beneficiary',
            action: 'archive',
            isMakerCheckerApplicable: false,
          }
        );
      });
    });

    it('should exclude status field from beneficiary payload when archiving', async () => {
      const { result, rerender } = renderHook(
        props => useHandleArchiveBeneficiary(props),
        { initialProps: defaultProps }
      );

      result.current.onArchiveClick();

      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: false,
        isBeneficiaryStatusUpdateError: false,
      });

      await waitFor(() => {
        expect(mockArchiveBeneficiary).toHaveBeenCalled();
        const { calls } = mockArchiveBeneficiary.mock;
        const archivePayload = calls[0][0];
        expect(archivePayload.params.beneficiary).not.toHaveProperty('status');
      });
    });
  });

  describe('status update error flow', () => {
    it('should not proceed with archive when status update fails', async () => {
      const { result, rerender } = renderHook(
        props => useHandleArchiveBeneficiary(props),
        { initialProps: defaultProps }
      );

      // Initiate archive
      result.current.onArchiveClick();

      // Simulate status update in progress
      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: true,
      });

      // Simulate status update error
      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: false,
        isBeneficiaryStatusUpdateError: true,
        beneficiaryStatusUpdateErrors: {
          status: 500,
          data: { errors: [{ message: 'Internal server error' }] },
        } as any,
      });

      await waitFor(() => {
        expect(mockArchiveBeneficiary).not.toHaveBeenCalled();
      });
    });

    it('should show timeout error when status update fails without status', async () => {
      const { result, rerender } = renderHook(
        props => useHandleArchiveBeneficiary(props),
        { initialProps: defaultProps }
      );

      // Initiate archive
      result.current.onArchiveClick();

      // Simulate status update in progress
      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: true,
      });

      // Simulate status update error without status (timeout)
      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: false,
        isBeneficiaryStatusUpdateError: true,
        beneficiaryStatusUpdateErrors: {
          data: { errors: [{ message: 'Network error' }] },
        } as any,
      });

      await waitFor(() => {
        expect(mockGlobalDispatch).toHaveBeenCalledWith({
          type: 'galaxy/context/update',
          data: {
            notificationAlert: {
              type: 'danger',
              message: 'Something went wrong. Please try again.',
            },
          },
        });
        expect(mockArchiveBeneficiary).not.toHaveBeenCalled();
      });
    });

    it('should redirect with generic error when status update fails', async () => {
      const { result, rerender } = renderHook(
        props => useHandleArchiveBeneficiary(props),
        { initialProps: defaultProps }
      );

      // Initiate archive
      result.current.onArchiveClick();

      // Simulate status update in progress
      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: true,
      });

      // Simulate status update error with status
      rerender({
        ...defaultProps,
        isBeneficiaryStatusUpdateFetching: false,
        isBeneficiaryStatusUpdateError: true,
        beneficiaryStatusUpdateErrors: {
          status: 500,
          data: { errors: [{ message: 'Internal server error' }] },
        } as any,
      });

      await waitFor(() => {
        expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
          'danger',
          'Something went wrong. Please try again later.'
        );
        expect(mockArchiveBeneficiary).not.toHaveBeenCalled();
      });
    });
  });

  describe('archive beneficiary error flow', () => {
    it('should show timeout error notification when archive fails without status', async () => {
      const props = {
        ...defaultProps,
        isArchiveBeneficiaryError: true,
        isArchiveBeneficiaryFetching: false,
        archiveBeneficiaryErrors: {
          data: { errors: [{ message: 'Unknown error' }] },
        } as any,
      };

      renderHook(() => useHandleArchiveBeneficiary(props));

      await waitFor(() => {
        expect(mockGlobalDispatch).toHaveBeenCalledWith({
          type: 'galaxy/context/update',
          data: {
            notificationAlert: {
              type: 'danger',
              message: 'Something went wrong.',
            },
          },
        });
      });
    });

    it('should call revertStatusAndRedirect when archive fails with entitlement error (8210)', async () => {
      const props = {
        ...defaultProps,
        isArchiveBeneficiaryError: true,
        isArchiveBeneficiaryFetching: false,
        archiveBeneficiaryErrors: {
          status: 403,
          data: { errors: [{ code: 8210 }] },
        } as any,
      };

      renderHook(() => useHandleArchiveBeneficiary(props));

      await waitFor(() => {
        expect(mockRevertStatusAndRedirect).toHaveBeenCalledWith({
          errorMessage:
            'You do not have permission to archive beneficiaries. Contact your administrator for more information.',
        });
      });
    });

    it('should redirect with success for maker-checker flow when error code is 8125', async () => {
      const props = {
        ...defaultProps,
        isArchiveBeneficiaryError: true,
        isArchiveBeneficiaryFetching: false,
        archiveBeneficiaryErrors: {
          status: 401,
          data: { errors: [{ code: 8125 }] },
        } as any,
      };

      renderHook(() => useHandleArchiveBeneficiary(props));

      await waitFor(() => {
        expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
          'success',
          {
            nickname: 'Test Beneficiary',
            action: 'archive',
            isMakerCheckerApplicable: true,
          }
        );
      });
    });

    it('should call revertStatusAndRedirect for all other archive errors', async () => {
      const props = {
        ...defaultProps,
        isArchiveBeneficiaryError: true,
        isArchiveBeneficiaryFetching: false,
        archiveBeneficiaryErrors: {
          status: 500,
          data: { errors: [{ message: 'Internal server error' }] },
        } as any,
      };

      renderHook(() => useHandleArchiveBeneficiary(props));

      await waitFor(() => {
        expect(mockRevertStatusAndRedirect).toHaveBeenCalledWith({
          errorMessage: 'Something went wrong. Please try again later.',
        });
      });
    });
  });

  describe('edge cases', () => {
    it('should handle empty beneficiaryDetails array', () => {
      const props = {
        ...defaultProps,
        beneficiaryDetails: [],
      };

      const { result } = renderHook(() => useHandleArchiveBeneficiary(props));

      // Should not throw error
      expect(() => result.current.onArchiveClick()).not.toThrow();
      expect(mockBeneficiaryStatusUpdate).toHaveBeenCalled();
    });

    it('should handle undefined beneficiaryDetails', () => {
      const props = {
        ...defaultProps,
        beneficiaryDetails: undefined as any,
      };

      const { result } = renderHook(() => useHandleArchiveBeneficiary(props));

      // Should not throw error
      expect(() => result.current.onArchiveClick()).not.toThrow();
    });
  });

  describe('currencyAmount sanitization in archive flow', () => {
    it('should sanitize currencyAmount with empty amount when archiving', async () => {
      const beneficiaryWithEmptyAmount = {
        ...beneficiaryDetail,
        currencyAmount: {
          currencyCode: 'AUD',
          amount: '',
        },
      };

      const { result, rerender } = renderHook(
        props => useHandleArchiveBeneficiary(props),
        {
          initialProps: {
            ...defaultProps,
            beneficiaryDetails: [beneficiaryWithEmptyAmount],
          },
        }
      );

      result.current.onArchiveClick();

      // Simulate status update success
      rerender({
        ...defaultProps,
        beneficiaryDetails: [beneficiaryWithEmptyAmount],
        isBeneficiaryStatusUpdateFetching: false,
        isBeneficiaryStatusUpdateError: false,
      });

      await waitFor(() => {
        expect(mockArchiveBeneficiary).toHaveBeenCalled();
      });

      const archivePayload = mockArchiveBeneficiary.mock.calls[0][0];
      expect(archivePayload.params.beneficiary.currencyAmount).toEqual({
        currencyCode: 'AUD',
      });
      expect(
        archivePayload.params.beneficiary.currencyAmount
      ).not.toHaveProperty('amount');
    });

    it('should sanitize currencyAmount with whitespace amount when archiving', async () => {
      const beneficiaryWithWhitespaceAmount = {
        ...beneficiaryDetail,
        currencyAmount: {
          currencyCode: 'AUD',
          amount: '   ',
        },
      };

      const { result, rerender } = renderHook(
        props => useHandleArchiveBeneficiary(props),
        {
          initialProps: {
            ...defaultProps,
            beneficiaryDetails: [beneficiaryWithWhitespaceAmount],
          },
        }
      );

      result.current.onArchiveClick();

      // Simulate status update success
      rerender({
        ...defaultProps,
        beneficiaryDetails: [beneficiaryWithWhitespaceAmount],
        isBeneficiaryStatusUpdateFetching: false,
        isBeneficiaryStatusUpdateError: false,
      });

      await waitFor(() => {
        expect(mockArchiveBeneficiary).toHaveBeenCalled();
      });

      const archivePayload = mockArchiveBeneficiary.mock.calls[0][0];
      expect(archivePayload.params.beneficiary.currencyAmount).toEqual({
        currencyCode: 'AUD',
      });
      expect(
        archivePayload.params.beneficiary.currencyAmount
      ).not.toHaveProperty('amount');
    });

    it('should sanitize currencyAmount with non-numeric amount when archiving', async () => {
      const beneficiaryWithInvalidAmount = {
        ...beneficiaryDetail,
        currencyAmount: {
          currencyCode: 'AUD',
          amount: 'abc',
        },
      };

      const { result, rerender } = renderHook(
        props => useHandleArchiveBeneficiary(props),
        {
          initialProps: {
            ...defaultProps,
            beneficiaryDetails: [beneficiaryWithInvalidAmount],
          },
        }
      );

      result.current.onArchiveClick();

      // Simulate status update success
      rerender({
        ...defaultProps,
        beneficiaryDetails: [beneficiaryWithInvalidAmount],
        isBeneficiaryStatusUpdateFetching: false,
        isBeneficiaryStatusUpdateError: false,
      });

      await waitFor(() => {
        expect(mockArchiveBeneficiary).toHaveBeenCalled();
      });

      const archivePayload = mockArchiveBeneficiary.mock.calls[0][0];
      expect(archivePayload.params.beneficiary.currencyAmount).toEqual({
        currencyCode: 'AUD',
      });
    });

    it('should preserve valid amount in currencyAmount when archiving', async () => {
      const beneficiaryWithValidAmount = {
        ...beneficiaryDetail,
        currencyAmount: {
          currencyCode: 'AUD',
          amount: '100.00',
        },
      };

      const { result, rerender } = renderHook(
        props => useHandleArchiveBeneficiary(props),
        {
          initialProps: {
            ...defaultProps,
            beneficiaryDetails: [beneficiaryWithValidAmount],
          },
        }
      );

      result.current.onArchiveClick();

      // Simulate status update success
      rerender({
        ...defaultProps,
        beneficiaryDetails: [beneficiaryWithValidAmount],
        isBeneficiaryStatusUpdateFetching: false,
        isBeneficiaryStatusUpdateError: false,
      });

      await waitFor(() => {
        expect(mockArchiveBeneficiary).toHaveBeenCalled();
      });

      const archivePayload = mockArchiveBeneficiary.mock.calls[0][0];
      expect(archivePayload.params.beneficiary.currencyAmount).toEqual({
        currencyCode: 'AUD',
        amount: '100.00',
      });
    });

    it('should preserve zero amount in currencyAmount when archiving', async () => {
      const beneficiaryWithZeroAmount = {
        ...beneficiaryDetail,
        currencyAmount: {
          currencyCode: 'AUD',
          amount: '0',
        },
      };

      const { result, rerender } = renderHook(
        props => useHandleArchiveBeneficiary(props),
        {
          initialProps: {
            ...defaultProps,
            beneficiaryDetails: [beneficiaryWithZeroAmount],
          },
        }
      );

      result.current.onArchiveClick();

      // Simulate status update success
      rerender({
        ...defaultProps,
        beneficiaryDetails: [beneficiaryWithZeroAmount],
        isBeneficiaryStatusUpdateFetching: false,
        isBeneficiaryStatusUpdateError: false,
      });

      await waitFor(() => {
        expect(mockArchiveBeneficiary).toHaveBeenCalled();
      });

      const archivePayload = mockArchiveBeneficiary.mock.calls[0][0];
      expect(archivePayload.params.beneficiary.currencyAmount).toEqual({
        currencyCode: 'AUD',
        amount: '0',
      });
    });

    it('should handle beneficiary without currencyAmount when archiving', async () => {
      const beneficiaryWithoutCurrencyAmount = {
        id: 'test-beneficiary-id',
        externalId: 'test-external-id',
        nickname: 'Test Beneficiary',
        org: 'test-org',
        status: BENEFICIARY_STATUS.ACTIVE,
        type: BENEFICIARY_TYPE.ACCOUNT,
        account: {
          accountId: {
            BSB: '123456',
            accountNumber: '12345678',
          },
          bankName: 'Test Bank',
          accountName: 'Test Account',
        },
      };

      const { result, rerender } = renderHook(
        props => useHandleArchiveBeneficiary(props),
        {
          initialProps: {
            ...defaultProps,
            beneficiaryDetails: [beneficiaryWithoutCurrencyAmount as any],
          },
        }
      );

      result.current.onArchiveClick();

      // Simulate status update success
      rerender({
        ...defaultProps,
        beneficiaryDetails: [beneficiaryWithoutCurrencyAmount as any],
        isBeneficiaryStatusUpdateFetching: false,
        isBeneficiaryStatusUpdateError: false,
      });

      await waitFor(() => {
        expect(mockArchiveBeneficiary).toHaveBeenCalled();
      });

      const archivePayload = mockArchiveBeneficiary.mock.calls[0][0];
      expect(archivePayload.params.beneficiary).not.toHaveProperty(
        'currencyAmount'
      );
    });
  });
});
