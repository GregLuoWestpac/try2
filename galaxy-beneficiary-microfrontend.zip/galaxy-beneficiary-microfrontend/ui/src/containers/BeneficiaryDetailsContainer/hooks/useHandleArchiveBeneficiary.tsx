import { useCallback, useEffect, useState } from 'react';
import { useGlobalDispatch } from '@mep-ui/framework';
import { interpolateTemplate } from '../../../common/Beneficiary.util';
import { sanitizeCurrencyAmount } from '../../../components/BeneficiaryForm/BeneficiaryForm.utils';
import {
  BENEFICIARY_ARCHIVE_ENTITLEMENT_ERROR_MESSAGE,
  BENEFICIARY_ARCHIVE_GENERIC_ERROR_MESSAGE,
  BENEFICIARY_ARCHIVE_SENT_FOR_AUTHORISATION_MESSAGE,
  BENEFICIARY_ARCHIVE_SUCCESS_MESSAGE,
  BENEFICIARY_ARCHIVE_TIMEOUT_ERROR_MESSAGE,
  BENEFICIARY_STATUS_UPDATE_GENERIC_ERROR_MESSAGE,
  BENEFICIARY_STATUS_UPDATE_TIMEOUT_ERROR_MESSAGE,
} from '../../../common';
import { useHandleRedirectToBeneficiaryList } from '../../../common/BeneficiaryList.util';
import {
  ArchiveBeneficiaryParamsPayload,
  Beneficiary,
  BENEFICIARY_COSMIC_STATUS,
  BeneficiaryError,
  BeneficiaryOptionsPayload,
  PostBeneficiaryStatusUpdateParams,
  PostBeneficiaryStatusUpdateParamsPayload,
} from '../../../store/types';
import { Currency } from '../../../store/types/Beneficiary';
import { useRevertBeneficiaryStatus } from '../../../hooks/useRevertBeneficiaryStatus';

export type UseHandleArchiveBeneficiaryProps = {
  isArchiveBeneficiaryError: boolean;
  isArchiveBeneficiaryFetching: boolean;
  archiveBeneficiaryErrors: BeneficiaryError | undefined;
  beneficiaryDetails: Beneficiary[];
  archiveBeneficiary: (
    params: ArchiveBeneficiaryParamsPayload,
    options: BeneficiaryOptionsPayload
  ) => void;
  selectedBeneficiaryId: string;
  archiveBeneficiaryModalState: unknown;
  organisationId: string;
  isBeneficiaryStatusUpdateError: boolean;
  isBeneficiaryStatusUpdateFetching: boolean;
  beneficiaryStatusUpdate: (
    payload: PostBeneficiaryStatusUpdateParamsPayload
  ) => void;
  clearBeneficiaryStatusUpdate: () => void;
  clearArchiveBeneficiary: () => void;
  beneficiaryStatusUpdateErrors: BeneficiaryError;
};

export const useHandleArchiveBeneficiary = ({
  isArchiveBeneficiaryError,
  isArchiveBeneficiaryFetching,
  archiveBeneficiaryErrors,
  beneficiaryDetails,
  archiveBeneficiary,
  selectedBeneficiaryId,
  archiveBeneficiaryModalState,
  organisationId,
  isBeneficiaryStatusUpdateError,
  isBeneficiaryStatusUpdateFetching,
  beneficiaryStatusUpdate,
  clearArchiveBeneficiary,
  clearBeneficiaryStatusUpdate,
  beneficiaryStatusUpdateErrors,
}: UseHandleArchiveBeneficiaryProps) => {
  // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-call
  const globalDispatch = useGlobalDispatch();
  const handleRedirectToBeneficiaryList = useHandleRedirectToBeneficiaryList();
  const [isModalArchivedClick, setIsModalArchivedClick] = useState(false);
  const [isStatusUpdatePending, setIsStatusUpdatePending] =
    useState<boolean>(false);
  const beneficiaryDetail = beneficiaryDetails?.[0];

  const { revertStatusAndRedirect } = useRevertBeneficiaryStatus({
    selectedBeneficiaryId,
    isBeneficiaryStatusUpdateFetching,
    beneficiaryStatusUpdate,
  });

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { status, ...beneficiaryDetailWithoutStatus } = beneficiaryDetail || {};

  // Handle archive beneficiary error
  useEffect(() => {
    if (
      isArchiveBeneficiaryError &&
      !isArchiveBeneficiaryFetching &&
      archiveBeneficiaryErrors
    ) {
      const errorStatus = archiveBeneficiaryErrors?.status;
      const errorCode = archiveBeneficiaryErrors?.data?.errors?.[0]?.code;

      // Check for specific error scenarios
      const isBeneficiaryArchiveTimeoutError = !errorStatus;
      const isBeneficiaryArchiveEntitlementError =
        errorStatus === 403 && errorCode === 8210;
      const isBeneficiaryArchiveSentForAuthorisation =
        errorStatus === 401 && errorCode === 8125;

      // Handle timeout error (no response received)
      if (isBeneficiaryArchiveTimeoutError) {
        const data = {
          notificationAlert: {
            type: 'danger',
            message: BENEFICIARY_ARCHIVE_TIMEOUT_ERROR_MESSAGE,
          },
        };
        // eslint-disable-next-line @typescript-eslint/no-unsafe-call
        globalDispatch({
          type: 'galaxy/context/update',
          data,
        });

        return;
      }

      // Handle entitlement error (user lacks permission)
      if (isBeneficiaryArchiveEntitlementError) {
        // Revert beneficiary status from ON_HOLD to ACTIVE before redirecting
        revertStatusAndRedirect({
          errorMessage: BENEFICIARY_ARCHIVE_ENTITLEMENT_ERROR_MESSAGE,
        });
        return;
      }

      // Handle maker-checker scenario (requires authorisation)
      if (isBeneficiaryArchiveSentForAuthorisation) {
        handleRedirectToBeneficiaryList('success', {
          nickname: beneficiaryDetail?.nickname || '',
          action: 'archive',
          isMakerCheckerApplicable: true,
        }).catch(() => undefined);
        return;
      }

      // Handle all other errors
      // Revert beneficiary status from ON_HOLD to ACTIVE before redirecting
      revertStatusAndRedirect({
        errorMessage: BENEFICIARY_ARCHIVE_GENERIC_ERROR_MESSAGE,
      });
    }
  }, [isArchiveBeneficiaryError, revertStatusAndRedirect]);

  // Handle successful archive beneficiary
  useEffect(() => {
    if (
      isModalArchivedClick &&
      !isArchiveBeneficiaryFetching &&
      !isArchiveBeneficiaryError
    ) {
      handleRedirectToBeneficiaryList('success', {
        nickname: beneficiaryDetail?.nickname || '',
        action: 'archive',
        isMakerCheckerApplicable: false,
      }).catch(() => undefined);
    }
  }, [isModalArchivedClick, isArchiveBeneficiaryFetching]);

  // Execute the archive beneficiary API call
  const archiveBeneficiaryList = () => {
    // Sanitize currencyAmount to exclude invalid amount values
    const { currencyAmount, ...restBeneficiaryData } =
      beneficiaryDetailWithoutStatus || {};
    const sanitizedBeneficiary = {
      ...restBeneficiaryData,
      ...(currencyAmount && {
        currencyAmount: sanitizeCurrencyAmount(currencyAmount as Currency),
      }),
    } as Omit<Beneficiary, 'status'>;

    const payload: ArchiveBeneficiaryParamsPayload = {
      params: {
        beneficiary: sanitizedBeneficiary,
      },
      meta: {
        replaceEntities: ['beneficiaryArchive'],
      },
    };
    archiveBeneficiary(payload, {
      headers: {
        'x-channelRequestId': selectedBeneficiaryId,
        'protected-orgId': organisationId,
      },
    });
  };

  // Monitor beneficiary status update completion and proceed with archive
  useEffect(() => {
    const hasStatusUpdateSucceeded =
      isStatusUpdatePending &&
      !isBeneficiaryStatusUpdateFetching &&
      !isBeneficiaryStatusUpdateError;

    const hasStatusUpdateFailed =
      isStatusUpdatePending &&
      !isBeneficiaryStatusUpdateFetching &&
      isBeneficiaryStatusUpdateError;

    if (hasStatusUpdateSucceeded) {
      // Beneficiary status update to ON_HOLD succeeded, proceed with archive API call
      setIsStatusUpdatePending(false);
      archiveBeneficiaryList();
      setIsModalArchivedClick(true);
    } else if (hasStatusUpdateFailed) {
      // Beneficiary status update to ON_HOLD failed, show error and stop
      setIsStatusUpdatePending(false);

      // Check for beneficiary status update timeout error (no response received)
      const isBeneficiaryStatusUpdateTimeoutError =
        !beneficiaryStatusUpdateErrors?.status;

      // Handle beneficiary status update timeout error
      if (isBeneficiaryStatusUpdateTimeoutError) {
        const data = {
          notificationAlert: {
            type: 'danger',
            message: BENEFICIARY_STATUS_UPDATE_TIMEOUT_ERROR_MESSAGE,
          },
        };
        // eslint-disable-next-line @typescript-eslint/no-unsafe-call
        globalDispatch({
          type: 'galaxy/context/update',
          data,
        });
        return;
      }

      // Handle other beneficiary status update errors with generic message
      handleRedirectToBeneficiaryList(
        'danger',
        BENEFICIARY_STATUS_UPDATE_GENERIC_ERROR_MESSAGE
      ).catch(() => undefined);
    }
  }, [
    isStatusUpdatePending,
    isBeneficiaryStatusUpdateFetching,
    isBeneficiaryStatusUpdateError,
  ]);

  // Handle archive button click - first update status to ON_HOLD before archiving
  const onArchiveClick = useCallback(() => {
    clearArchiveBeneficiary();
    clearBeneficiaryStatusUpdate();
    // Update beneficiary status to ON_HOLD before archiving
    const postBeneficiaryStatusUpdateParams: PostBeneficiaryStatusUpdateParams =
      {
        beneficiary: {
          id: selectedBeneficiaryId,
          status: BENEFICIARY_COSMIC_STATUS.ON_HOLD,
        },
      };
    setIsStatusUpdatePending(true);
    beneficiaryStatusUpdate({ params: postBeneficiaryStatusUpdateParams });
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    // eslint-disable-next-line @typescript-eslint/no-unsafe-call
    archiveBeneficiaryModalState.close();
  }, [
    clearArchiveBeneficiary,
    clearBeneficiaryStatusUpdate,
    selectedBeneficiaryId,
    beneficiaryStatusUpdate,
    archiveBeneficiaryModalState,
  ]);

  return {
    onArchiveClick,
  };
};
