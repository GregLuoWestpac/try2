import React from 'react';
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import { Alert, Button } from '@westpac/ui';
import { useClose } from '@mesh-tenant-multiverse-common/react';
import { genericErrorMessage } from '../../common/constants';

type Props = {
  retry: () => void;
};

export function BeneficiaryDetailsErrorCard({ retry }: Props) {
  const { closeTab } = useClose();
  const handleCloseTab = async () => {
    await closeTab();
  };
  return (
    <MVCard title="Beneficiary details" template="narrow" bottomDivider>
      <Alert
        className="mb-2.5"
        look="danger"
        id="beneficiary-details-error-banner"
        iconSize="small"
      >
        {genericErrorMessage} Please{' '}
        <Button
          className="bg-danger-5 p-0 typography-body-11 h-0"
          look="link"
          soft
          onClick={retry}
        >
          try again
        </Button>
        .
      </Alert>
      <div className="w-full border-t border-border pt-2.5 mt-0">
        <Button look="hero" soft size="small" onClick={handleCloseTab}>
          Close
        </Button>
      </div>
    </MVCard>
  );
}

export default BeneficiaryDetailsErrorCard;
