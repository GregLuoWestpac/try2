/* eslint-disable react/button-has-type */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { useGlobalSelector } from '@mep-ui/framework';
import { BeneficiaryTaskDetailsContainer } from './BeneficiaryTaskContainer';
import { MakerCheckerApiClientProps } from '../../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types';

jest.mock('@mep-ui/framework', () => ({
  useGlobalSelector: jest.fn(),
  createSelector: (inputs: any[], combiner: (...args: any[]) => any) => {
    return (state: any) => combiner(...inputs.map(fn => fn(state)));
  },
  combineReducers: jest.fn(reducers => reducers),
  createStore: jest.fn(() => ({
    dispatch: jest.fn(),
    getState: jest.fn(),
    contextRef: {},
  })),
  connect: jest.fn(() => (Component: any) => Component),
  compose: jest.fn(
    (...funcs: any[]) =>
      (Component: any) =>
        Component
  ),
}));

jest.mock('../../store/generated', () => ({
  postBeneficiaryStatusUpdate: jest.fn(),
  clearBeneficiaryStatusUpdate: jest.fn(),
  beneficiaryStatusUpdateActions: {
    api: {
      expGalaxyBeneficiaryV2: {
        beneficiaryStatusUpdate: {
          post: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  beneficiaryStatusUpdateEntityActions: {
    api: {
      expGalaxyBeneficiaryV2: {
        beneficiaryStatusUpdate: {
          clear: jest.fn(),
        },
      },
    },
  },
}));

jest.mock('../../store/store', () => ({
  __esModule: true,
  default: {
    dispatch: jest.fn(),
    getState: jest.fn(),
  },
}));

jest.mock('@westpac/ui', () => ({
  ...jest.requireActual('@westpac/ui'),
  Tabs: function MockTabs({
    children,
    onSelectionChange = () => {},
  }: {
    children: React.ReactNode;
    onSelectionChange?: (key: string) => void;
  }) {
    return (
      <div>
        <div onClick={() => onSelectionChange('ForYouToAuthorise')}>
          ForYouToAuthorise
        </div>
        <div onClick={() => onSelectionChange('TrackAuthorisation')}>
          TrackAuthorisation
        </div>
        {children}
      </div>
    );
  },
  TabsPanel: function MockTabsPanel({
    key,
    title,
    children,
  }: {
    key: string;
    title: string;
    children: React.ReactNode;
  }) {
    return (
      <div key={key} title={title}>
        {children}
      </div>
    );
  },
}));

// Mock the details card component to render the beneficiaryDetail.nickname
jest.mock('./BeneficiaryTaskDetailsCard', () => ({
  BeneficiaryTaskDetailsCard: ({ beneficiaryDetail }: any) => (
    <div>Card with Nickname: {beneficiaryDetail.nickname}</div>
  ),
}));

jest.mock('./BeneficiaryDetailsErrorCard', () => ({
  BeneficiaryDetailsErrorCard: ({ retry }: { retry: () => void }) => (
    <div>
      Error Card
      <button onClick={retry}>Retry</button>
    </div>
  ),
}));

jest.mock('../../common/Beneficiary.util', () => ({
  transformApprovalWorkflowToBeneficiaryTaskDetail: (data: any) => ({
    ...data,
    nickname: data?.payloadObject?.beneficiaries?.[0]?.nickname ?? 'Test Nick',
  }),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-pageloader', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-pageloader'),
  MVPageLoader: function MockMVPageLoader() {
    return <div>Loading spinner</div>;
  },
}));

let mockApiError = false;
let mockApiResponseData: any = null;

// Mock the Module Federation widget; after a short delay, it calls onApiResponse or onApiError
jest.mock('../../widgets/galaxymakerchecker-v1', () => ({
  __esModule: true,
  GalaxyMakerCheckerWrapper: (props: MakerCheckerApiClientProps) => {
    setTimeout(() => {
      if (mockApiError) {
        props.onApiError?.('mock-error');
      } else if (mockApiResponseData) {
        props.onApiResponse?.(mockApiResponseData);
      } else {
        props.onApiResponse?.({
          data: {
            entities: {
              approvalWorkflowDetails: [
                {
                  approvalWorkflowId: 'mock-id',
                  payloadObject: {
                    beneficiaries: [
                      {
                        nickname: 'Payroll A/C Apple Tree Ltd',
                      },
                    ],
                  },
                },
              ],
            },
          },
        });
      }
    }, 0);
    return <div data-testid="mock-widget">GalaxyWidget</div>;
  },
}));

describe('BeneficiaryTaskDetailsContainer', () => {
  let mockUseGlobalSelectorReturns: Record<string, any> = {};

  const defaultProps = {
    isBeneficiaryStatusUpdateError: false,
    isBeneficiaryStatusUpdateFetching: false,
    beneficiaryStatusUpdate: null,
    beneficiaryStatusUpdateErrors: {},
    clearBeneficiaryStatusUpdate: jest.fn(),
  };

  beforeEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
    mockApiError = false;
    mockUseGlobalSelectorReturns = {};

    (useGlobalSelector as jest.Mock).mockImplementation(selector => {
      const mockState = {
        global: {
          galaxy: {
            context: {
              approvalWorkflowId:
                mockUseGlobalSelectorReturns.approvalWorkflowId ||
                'test-beneficiary-id',
              searchBy: mockUseGlobalSelectorReturns.searchBy || 'NICKNAME',
            },
          },
        },
      };
      return selector(mockState);
    });

    // Mock the DOM element that BeneficiaryTaskContainer looks for
    const mockElement = document.createElement('div');
    mockElement.id = 'maker-checker-api-client';
    document.body.appendChild(mockElement);
  });

  afterEach(() => {
    // Clean up the mock element
    const mockElement = document.getElementById('maker-checker-api-client');
    if (mockElement) {
      document.body.removeChild(mockElement);
    }
  });

  it('initially shows PageLoader then renders BeneficiaryTaskDetailsCard on success (matches snapshot)', async () => {
    mockUseGlobalSelectorReturns.approvalWorkflowId = 'test-beneficiary-id';

    const { asFragment } = render(
      <BeneficiaryTaskDetailsContainer {...defaultProps} />
    );
    expect(screen.getByText('Loading spinner')).toBeInTheDocument();
    expect(asFragment()).toMatchSnapshot('loader-state');

    const card = await screen.findByText(
      /Card with Nickname: Payroll A\/C Apple Tree Ltd/
    );
    expect(card).toBeInTheDocument();
    expect(asFragment()).toMatchSnapshot('success-state');
  });

  it('renders error message when API fails (matches snapshot)', async () => {
    mockApiError = true;
    mockUseGlobalSelectorReturns.approvalWorkflowId = 'test-beneficiary-id';

    const { asFragment } = render(<BeneficiaryTaskDetailsContainer />);
    expect(screen.getByText('Loading spinner')).toBeInTheDocument();
    expect(asFragment()).toMatchSnapshot('loader-before-error');
    const errorMsg = await screen.findByText('Error Card');
    expect(errorMsg).toBeInTheDocument();
    expect(asFragment()).toMatchSnapshot('error-state');
  });

  it('always mounts GalaxyMakerCheckerWrapper (matches snapshot)', async () => {
    mockUseGlobalSelectorReturns.approvalWorkflowId = 'abc123';

    const { asFragment } = render(<BeneficiaryTaskDetailsContainer />);
    const widget = await screen.findByTestId('mock-widget');
    expect(widget).toBeInTheDocument();
    expect(asFragment()).toMatchSnapshot('widget-mounted-loading');
  });

  it('shows loader when approvalWorkflowId is empty (matches snapshot)', () => {
    mockUseGlobalSelectorReturns.approvalWorkflowId = '';

    const { asFragment } = render(<BeneficiaryTaskDetailsContainer />);
    expect(screen.getByText('Loading spinner')).toBeInTheDocument();
    expect(asFragment()).toMatchSnapshot('loader-no-id');
  });

  it('renders error when API response has no approvalWorkflowDetails', async () => {
    mockUseGlobalSelectorReturns.approvalWorkflowId = 'test-id';
    mockApiResponseData = {
      data: {
        entities: {
          approvalWorkflowDetails: [],
        },
      },
    };

    render(<BeneficiaryTaskDetailsContainer {...defaultProps} />);

    const errorCard = await screen.findByText('Error Card');
    expect(errorCard).toBeInTheDocument();
  });

  it('renders error when API response has no entities', async () => {
    mockUseGlobalSelectorReturns.approvalWorkflowId = 'test-id';
    mockApiResponseData = {
      data: {},
    };

    render(<BeneficiaryTaskDetailsContainer />);

    const errorCard = await screen.findByText('Error Card');
    expect(errorCard).toBeInTheDocument();
  });

  it('retries API call when retry button is clicked', async () => {
    mockApiError = true;
    mockUseGlobalSelectorReturns.approvalWorkflowId = 'test-id';

    render(<BeneficiaryTaskDetailsContainer />);

    const errorCard = await screen.findByText('Error Card');
    expect(errorCard).toBeInTheDocument();

    // Reset error and click retry
    mockApiError = false;
    const retryButton = screen.getByText('Retry');
    fireEvent.click(retryButton);

    // Should show loading again
    expect(screen.getByText('Loading spinner')).toBeInTheDocument();
  });

  it('handles MutationObserver when widget element is not immediately present', async () => {
    // Remove the mock element to simulate widget not being present
    const mockElement = document.getElementById('maker-checker-api-client');
    if (mockElement) {
      document.body.removeChild(mockElement);
    }

    mockUseGlobalSelectorReturns.approvalWorkflowId = 'test-id';

    render(<BeneficiaryTaskDetailsContainer />);

    // Should show loading because widget is not found
    expect(screen.getByText('Loading spinner')).toBeInTheDocument();

    // Add the widget element after a delay
    setTimeout(() => {
      const newMockElement = document.createElement('div');
      newMockElement.id = 'maker-checker-api-client';
      document.body.appendChild(newMockElement);
    }, 100);

    // Widget should eventually be found and component should load
    const widget = await screen.findByTestId(
      'mock-widget',
      {},
      { timeout: 3000 }
    );
    expect(widget).toBeInTheDocument();
  });

  it('passes searchBy prop to BeneficiaryTaskDetailsCard', async () => {
    mockUseGlobalSelectorReturns.approvalWorkflowId = 'test-id';
    mockUseGlobalSelectorReturns.searchBy = 'ACCOUNT_NUMBER';
    // Reset to default success response
    mockApiError = false;
    mockApiResponseData = null;

    render(<BeneficiaryTaskDetailsContainer />);

    // Wait for the success card to appear (which means searchBy was passed correctly)
    const cardElement = await screen.findByText(/Card with Nickname:/);
    expect(cardElement).toBeInTheDocument();
  });

  it('resets state when approvalWorkflowId changes', () => {
    const { rerender } = render(
      <BeneficiaryTaskDetailsContainer {...defaultProps} />
    );

    // Change the approvalWorkflowId
    mockUseGlobalSelectorReturns.approvalWorkflowId = 'new-id';

    rerender(<BeneficiaryTaskDetailsContainer {...defaultProps} />);

    // Should show loading when ID changes
    expect(screen.getByText('Loading spinner')).toBeInTheDocument();
  });

  it('handles onApiError correctly and shows error card', async () => {
    mockApiError = true;
    mockUseGlobalSelectorReturns.approvalWorkflowId = 'test-id';

    render(<BeneficiaryTaskDetailsContainer />);

    // Should show error card when API error occurs
    const errorCard = await screen.findByText('Error Card');
    expect(errorCard).toBeInTheDocument();
  });

  it('covers MutationObserver callback when element is found', async () => {
    // Remove the mock element to simulate widget not being present initially
    const mockElement = document.getElementById('maker-checker-api-client');
    if (mockElement) {
      document.body.removeChild(mockElement);
    }

    mockUseGlobalSelectorReturns.approvalWorkflowId = 'test-id';

    render(<BeneficiaryTaskDetailsContainer />);

    // Should show loading because widget is not found
    expect(screen.getByText('Loading spinner')).toBeInTheDocument();

    // Directly add the element to trigger MutationObserver callback
    const newMockElement = document.createElement('div');
    newMockElement.id = 'maker-checker-api-client';
    document.body.appendChild(newMockElement);

    // Wait for the MutationObserver to detect the change and update state
    const widget = await screen.findByTestId(
      'mock-widget',
      {},
      { timeout: 3000 }
    );
    expect(widget).toBeInTheDocument();
  });

  it('handles empty approvalWorkflowId by not rendering GalaxyMakerCheckerWrapper', () => {
    // Explicitly set to empty string and clear previous mock state
    mockUseGlobalSelectorReturns = { approvalWorkflowId: '' };
    mockApiError = false;
    mockApiResponseData = null;

    render(<BeneficiaryTaskDetailsContainer />);

    // Should show loading spinner
    expect(screen.getByText('Loading spinner')).toBeInTheDocument();

    // Since approvalWorkflowId is empty, GalaxyMakerCheckerWrapper should not render
    // We can't test this directly, but we can test that the component stays in loading state
    expect(screen.queryByText(/Card with Nickname:/)).not.toBeInTheDocument();
  });

  it('covers missing else branch in MutationObserver callback', async () => {
    // Start with element not present
    const mockElement = document.getElementById('maker-checker-api-client');
    if (mockElement) {
      document.body.removeChild(mockElement);
    }

    // Mock MutationObserver to simulate the callback where element is NOT found
    let mockCallback: ((mutations: any[]) => void) | undefined;
    const mockDisconnect = jest.fn();
    const originalMutationObserver = global.MutationObserver;

    global.MutationObserver = jest.fn().mockImplementation(callback => {
      mockCallback = callback;
      return {
        observe: jest.fn(),
        disconnect: mockDisconnect,
      };
    });

    mockUseGlobalSelectorReturns.approvalWorkflowId = 'test-id';

    render(<BeneficiaryTaskDetailsContainer />);

    // Simulate MutationObserver callback where getElementById returns null
    // This covers the implicit else branch where the element is not found
    jest.spyOn(document, 'getElementById').mockReturnValue(null);

    // Trigger the callback with empty mutations
    if (mockCallback) {
      mockCallback([]);
    }

    // The disconnect should not be called if element is not found
    expect(mockDisconnect).not.toHaveBeenCalled();

    // Restore original implementations
    global.MutationObserver = originalMutationObserver;
    jest.restoreAllMocks();
  });

  it('covers cleanup function return from useEffect', () => {
    // Start with element not present to ensure MutationObserver is created
    const mockElement = document.getElementById('maker-checker-api-client');
    if (mockElement) {
      document.body.removeChild(mockElement);
    }

    const mockDisconnect = jest.fn();
    const originalMutationObserver = global.MutationObserver;

    global.MutationObserver = jest.fn().mockImplementation(() => ({
      observe: jest.fn(),
      disconnect: mockDisconnect,
    }));

    mockUseGlobalSelectorReturns.approvalWorkflowId = 'test-id';

    const { unmount } = render(
      <BeneficiaryTaskDetailsContainer {...defaultProps} />
    );

    // Unmount the component to trigger cleanup
    unmount();

    // The cleanup function should call disconnect
    expect(mockDisconnect).toHaveBeenCalled();

    // Restore
    global.MutationObserver = originalMutationObserver;
  });

  it('handles case where isLoadingWidget is false and widget already exists', () => {
    // Ensure widget element exists from the start
    const existingElement = document.getElementById('maker-checker-api-client');
    if (!existingElement) {
      const newMockElement = document.createElement('div');
      newMockElement.id = 'maker-checker-api-client';
      document.body.appendChild(newMockElement);
    }

    mockUseGlobalSelectorReturns.approvalWorkflowId = 'test-id';

    render(<BeneficiaryTaskDetailsContainer />);

    // Since widget exists, should eventually show the success card
    expect(screen.getByText('Loading spinner')).toBeInTheDocument();
  });

  it('covers early return when isLoadingWidget is false', () => {
    // Ensure widget element exists
    const existingElement = document.getElementById('maker-checker-api-client');
    if (!existingElement) {
      const newMockElement = document.createElement('div');
      newMockElement.id = 'maker-checker-api-client';
      document.body.appendChild(newMockElement);
    }

    // Track whether MutationObserver constructor is called
    const originalMutationObserver = global.MutationObserver;
    const mockMutationObserver = jest.fn().mockImplementation(() => ({
      observe: jest.fn(),
      disconnect: jest.fn(),
    }));
    global.MutationObserver = mockMutationObserver;

    mockUseGlobalSelectorReturns.approvalWorkflowId = 'test-id';

    render(<BeneficiaryTaskDetailsContainer />);

    // Since widget exists immediately, MutationObserver should not be created
    // This covers the early return when !isLoadingWidget
    expect(mockMutationObserver).not.toHaveBeenCalled();

    // Restore
    global.MutationObserver = originalMutationObserver;
  });
});
