/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import isEmpty from 'lodash/isEmpty';
import React, { useEffect, useRef, useState } from 'react';
import { useGlobalSelector, compose, connect } from '@mep-ui/framework';
import { MVPageLoader as PageLoader } from '@mesh-tenant-multiverse-ui-common/mv-pageloader';
import { GalaxyMakerCheckerWrapper } from '../../widgets/galaxymakerchecker-v1';
import { BeneficiaryTaskDetailsCard } from './BeneficiaryTaskDetailsCard';
import { BeneficiaryDetailsErrorCard } from './BeneficiaryDetailsErrorCard';
import { GetApprovalWorkflowDetailsData } from '../../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types';
import { transformApprovalWorkflowToBeneficiaryTaskDetail } from '../../common/Beneficiary.util';
import {
  BeneficiaryError,
  BeneficiaryTaskDetail,
  PostBeneficiaryStatusUpdateParamsPayload,
} from '../../store/types';
import {
  GlobalState,
  RootState,
  SearchByType,
} from '../../store/types/RootStates';
import {
  beneficiaryStatusUpdateActions,
  beneficiaryStatusUpdateEntityActions,
  isBeneficiaryStatusUpdateError as isBeneficiaryStatusUpdateErrorSelector,
  isBeneficiaryStatusUpdateFetching as isBeneficiaryStatusUpdateFetchingSelector,
} from '../../store/generated';
import { getBeneficiaryStatusUpdateErrors } from 'ui/src/store/selectors';
import store from '../../store/store';
import { usePlatformState } from '@mesh-tenant-multiverse-common/react';
import { W1_ORGANIZATION_SSO } from '../../common';

export type BeneficiaryTaskDetailsContainerProps = {
  isBeneficiaryStatusUpdateError: boolean;
  isBeneficiaryStatusUpdateFetching: boolean;
  beneficiaryStatusUpdate: (
    payload: PostBeneficiaryStatusUpdateParamsPayload
  ) => void;
  beneficiaryStatusUpdateErrors: BeneficiaryError;
  clearBeneficiaryStatusUpdate: () => void;
};

export function BeneficiaryTaskDetailsContainer({
  isBeneficiaryStatusUpdateError,
  beneficiaryStatusUpdateErrors,
  isBeneficiaryStatusUpdateFetching,
  beneficiaryStatusUpdate,
  clearBeneficiaryStatusUpdate,
}: BeneficiaryTaskDetailsContainerProps) {
  const approvalWorkflowId: string = useGlobalSelector(
    (state: GlobalState) => state?.global?.galaxy?.context?.approvalWorkflowId
  );

  const searchBy: SearchByType = useGlobalSelector(
    (state: GlobalState) => state?.global?.galaxy?.context?.searchBy
  );
  const [organisationSSOData] = usePlatformState(W1_ORGANIZATION_SSO, {
    orgId: {
      organisationId: '',
    },
  });

  const orgId = (window.location.hostname === 'localhost' ? "12345678910" : organisationSSOData?.orgId?.organisationId);
  const initialTsRef = useRef(Date.now());
  const [trigger, setTrigger] = useState<number>(initialTsRef.current);
  const [beneficiaryCardData, setBeneficiaryCardData] = useState<{
    beneficiaryDetail: BeneficiaryTaskDetail;
    entitlementsPayload: string;
  } | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<unknown>(null);
  const [isLoadingWidget, setIsLoadingWidget] = useState(true);

  useEffect(() => {
    if (!isEmpty(approvalWorkflowId)) {
      setError(null);
      setIsLoading(true);
      setBeneficiaryCardData(null);
    }
  }, [approvalWorkflowId]);

  const retry = () => {
    setError(null);
    setIsLoading(true);
    setTrigger(Date.now());
  };

  const onApiResponse = (
    res: { data?: GetApprovalWorkflowDetailsData } = {}
  ) => {
    setIsLoading(false);
    const approvalWorkflowDetail =
      res?.data?.entities?.approvalWorkflowDetails?.[0];
    if (approvalWorkflowDetail) {
      const beneficiaryDetail =
        transformApprovalWorkflowToBeneficiaryTaskDetail(
          approvalWorkflowDetail
        );
      setBeneficiaryCardData({
        beneficiaryDetail,
        entitlementsPayload: approvalWorkflowDetail.entitlementsPayload ?? '',
      });
    } else {
      setError('error fetching beneficiary details');
    }
  };

  const onApiError = (err: unknown) => {
    setIsLoading(false);
    setError(err);
  };

  useEffect(() => {
    if (!isLoadingWidget) return;
    const widget = document.getElementById('maker-checker-api-client');
    if (widget) {
      setIsLoadingWidget(false);
      return;
    }
    const observer = new MutationObserver(() => {
      const found = document.getElementById('maker-checker-api-client');
      if (found) {
        setIsLoadingWidget(false);
        observer.disconnect();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    return () => observer.disconnect();
  }, [isLoadingWidget]);

  const renderComponent = () => {
    if (isLoading || isEmpty(approvalWorkflowId) || isLoadingWidget) {
      return <PageLoader iconSize="medium" />;
    }
    if (error !== null || !beneficiaryCardData) {
      return <BeneficiaryDetailsErrorCard retry={retry} />;
    }
    const { beneficiaryDetail, entitlementsPayload } = beneficiaryCardData;
    return (
      <BeneficiaryTaskDetailsCard
        beneficiaryDetail={beneficiaryDetail}
        approvalWorkflowId={approvalWorkflowId}
        entitlementsPayload={entitlementsPayload}
        searchBy={searchBy}
        isBeneficiaryStatusUpdateError={isBeneficiaryStatusUpdateError}
        isBeneficiaryStatusUpdateFetching={isBeneficiaryStatusUpdateFetching}
        beneficiaryStatusUpdate={beneficiaryStatusUpdate}
        clearBeneficiaryStatusUpdate={clearBeneficiaryStatusUpdate}
        beneficiaryStatusUpdateErrors={beneficiaryStatusUpdateErrors}
      />
    );
  };

  return (
    <>
      {approvalWorkflowId && (
        <GalaxyMakerCheckerWrapper
          key={approvalWorkflowId}
          apiName="getApprovalWorkflowDetails"
          trigger={trigger}
          params={{ query: { approvalWorkflowId } }}
          options={{ headers: { ...(orgId && { 'protected-orgId': orgId }) } }}
          onApiResponse={onApiResponse}
          onApiError={onApiError}
        />
      )}
      {renderComponent()}
    </>
  );
}

const mapStateToProps = (state: RootState) => ({
  isBeneficiaryStatusUpdateFetching:
    isBeneficiaryStatusUpdateFetchingSelector(state),
  isBeneficiaryStatusUpdateError: isBeneficiaryStatusUpdateErrorSelector(state),
  beneficiaryStatusUpdateErrors: getBeneficiaryStatusUpdateErrors(state),
});

const mapDispatchToProps = {
  beneficiaryStatusUpdate:
    beneficiaryStatusUpdateActions.api.expGalaxyBeneficiaryV2
      .beneficiaryStatusUpdate.post.request,
  clearBeneficiaryStatusUpdate:
    beneficiaryStatusUpdateEntityActions.api.expGalaxyBeneficiaryV2
      .beneficiaryStatusUpdate.clear.request,
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps, null, {
    context: store.contextRef,
  })
)(BeneficiaryTaskDetailsContainer);
