import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { BeneficiaryDetailsErrorCard } from './BeneficiaryDetailsErrorCard';

// Mock the dependencies
jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: function MockMVCard({
    title,
    template,
    bottomDivider,
    children,
  }: {
    title: string;
    template: string;
    bottomDivider: boolean;
    children: React.ReactNode;
  }) {
    return (
      <div
        data-testid="mv-card"
        data-title={title}
        data-template={template}
        data-bottom-divider={bottomDivider}
      >
        {children}
      </div>
    );
  },
}));

// Create mock for closeTab function
const mockCloseTab = jest.fn();
jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useClose: jest.fn(() => ({ closeTab: mockCloseTab })),
}));

jest.mock('@westpac/ui', () => ({
  Alert: function MockAlert({
    className,
    look,
    id,
    iconSize,
    children,
  }: {
    className?: string;
    look: string;
    id: string;
    iconSize: string;
    children: React.ReactNode;
  }) {
    return (
      <div
        data-testid="alert"
        className={className}
        data-look={look}
        id={id}
        data-icon-size={iconSize}
      >
        {children}
      </div>
    );
  },
  Button: function MockButton({
    className,
    look,
    soft,
    onClick,
    children,
  }: {
    className?: string;
    look: string;
    soft: boolean;
    onClick: () => void;
    children: React.ReactNode;
  }) {
    return look === 'link' ? (
      <button
        data-testid="retry-button"
        className={className}
        data-look={look}
        data-soft={soft}
        onClick={onClick}
      >
        {children}
      </button>
    ) : (
      <button
        data-testid="close-button"
        className={className}
        data-look={look}
        data-soft={soft}
        onClick={mockCloseTab}
      >
        {children}
      </button>
    );
  },
}));

jest.mock('../../common/constants', () => ({
  genericErrorMessage: 'Something went wrong.',
}));

describe('BeneficiaryDetailsErrorCard', () => {
  const mockRetry = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    mockCloseTab.mockClear();
  });

  it('renders the error card with correct structure and props', () => {
    const { asFragment } = render(
      <BeneficiaryDetailsErrorCard retry={mockRetry} />
    );

    // Check if MVCard is rendered with correct props
    const mvCard = screen.getByTestId('mv-card');
    expect(mvCard).toBeInTheDocument();
    expect(mvCard).toHaveAttribute('data-title', 'Beneficiary details');
    expect(mvCard).toHaveAttribute('data-template', 'narrow');
    expect(mvCard).toHaveAttribute('data-bottom-divider', 'true');

    expect(asFragment()).toMatchSnapshot();
  });

  it('renders the alert with correct props and styling', () => {
    render(<BeneficiaryDetailsErrorCard retry={mockRetry} />);

    const alert = screen.getByTestId('alert');
    expect(alert).toBeInTheDocument();
    expect(alert).toHaveClass('mb-2.5');
    expect(alert).toHaveAttribute('data-look', 'danger');
    expect(alert).toHaveAttribute('id', 'beneficiary-details-error-banner');
    expect(alert).toHaveAttribute('data-icon-size', 'small');
  });

  it('displays the correct error message', () => {
    render(<BeneficiaryDetailsErrorCard retry={mockRetry} />);

    // Check for text content that is split across elements
    expect(screen.getByText(/Something went wrong\./)).toBeInTheDocument();
    expect(screen.getByText(/Please/)).toBeInTheDocument();
    expect(screen.getByText('try again')).toBeInTheDocument();
  });

  it('renders the retry button with correct props and styling', () => {
    render(<BeneficiaryDetailsErrorCard retry={mockRetry} />);

    const retryButton = screen.getByTestId('retry-button');
    expect(retryButton).toBeInTheDocument();
    expect(retryButton).toHaveClass('bg-danger-5 p-0 typography-body-11 h-0');
    expect(retryButton).toHaveAttribute('data-look', 'link');
    expect(retryButton).toHaveAttribute('data-soft', 'true');
    expect(retryButton).toHaveTextContent('try again');
  });

  it('renders the close button with correct props and styling and call closeTab on clicking', () => {
    render(<BeneficiaryDetailsErrorCard retry={mockRetry} />);

    const closeButton = screen.getByTestId('close-button');
    expect(closeButton).toBeInTheDocument();
    expect(closeButton).toHaveAttribute('data-look', 'hero');
    expect(closeButton).toHaveAttribute('data-soft', 'true');
    expect(closeButton).toHaveTextContent('Close');
    fireEvent.click(closeButton);

    // Verify that closeTab was called
    expect(mockCloseTab).toHaveBeenCalledTimes(1);
  });

  it('calls retry function when retry button is clicked', () => {
    render(<BeneficiaryDetailsErrorCard retry={mockRetry} />);

    const retryButton = screen.getByTestId('retry-button');
    fireEvent.click(retryButton);

    expect(mockRetry).toHaveBeenCalledTimes(1);
  });

  it('calls retry function multiple times when button is clicked multiple times', () => {
    render(<BeneficiaryDetailsErrorCard retry={mockRetry} />);

    const retryButton = screen.getByTestId('retry-button');
    fireEvent.click(retryButton);
    fireEvent.click(retryButton);
    fireEvent.click(retryButton);

    expect(mockRetry).toHaveBeenCalledTimes(3);
  });

  it('renders the complete error message text flow correctly', () => {
    render(<BeneficiaryDetailsErrorCard retry={mockRetry} />);

    // Check that the complete message flows correctly (without the extra space before the period)
    const alert = screen.getByTestId('alert');
    expect(alert).toHaveTextContent('Something went wrong. Please try again.');
  });

  it('matches snapshot for consistent rendering', () => {
    const { asFragment } = render(
      <BeneficiaryDetailsErrorCard retry={mockRetry} />
    );
    expect(asFragment()).toMatchSnapshot();
  });

  it('has proper accessibility attributes', () => {
    render(<BeneficiaryDetailsErrorCard retry={mockRetry} />);

    // Check that alert has proper id for accessibility
    const alert = screen.getByTestId('alert');
    expect(alert).toHaveAttribute('id', 'beneficiary-details-error-banner');

    // Check that button is accessible
    const retryButton = screen.getByTestId('retry-button');
    expect(retryButton).toBeInTheDocument();
    expect(retryButton).toHaveTextContent('try again');
  });
});
