/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-call */

/* eslint-disable react/function-component-definition */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-misused-promises */
import React, { useEffect, useCallback, useRef, useState } from 'react';
import { useGlobalDispatch, useGlobalSelector } from '@mep-ui/framework';
import { useNavigate } from '@mep-ui/framework-router-addon';
import {
  useClose,
  usePlatformState,
} from '@mesh-tenant-multiverse-common/react';
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import {
  useHandleRaiseIntent,
  isStaffPortal,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { Alert, Button, Grid, GridItem, ProgressIndicator } from '@westpac/ui';
import isEmpty from 'lodash/isEmpty';
import { useEntitlementsSafi } from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import get from 'lodash/get';
import { useOverlayTriggerState } from 'react-stately';
import {
  BENEFICIARY_ADD_CLIENT_TIMEOUT_ERROR_MESSAGE,
  BENEFICIARY_ADD_ENTITLEMENT_ERROR_MESSAGE,
  BENEFICIARY_ADD_EXIST_ERROR_MESSAGE,
  BENEFICIARY_ADD_GENERIC_ERROR_MESSAGE,
  BENEFICIARY_ADD_SERVER_TIMEOUT_ERROR_MESSAGE,
  BENEFICIARY_STATUS_UPDATE_GENERIC_ERROR_MESSAGE,
  BENEFICIARY_STATUS_UPDATE_TIMEOUT_ERROR_MESSAGE,
  BENEFICIARY_STATUS_UPDATE_UNKNOWN_ERROR_MESSAGE,
  ERROR_CODES,
  errorMessageListForAuthoriseBenReq,
  INTENT_NAMES,
  INTENTS_CONTEXT_NAME,
  PAGE_NAVIGATION,
  W1_ORGANIZATION_SSO,
} from '../../common';
import { BeneficiaryAuthorisationActivity } from '../../components/BeneficiaryAuthorisationActivity/BeneficiaryAuthorisationActivity';
import { BeneficiarySummary } from '../../components/BeneficiarySummary';
import { useEntitlementsStepUp } from '../../hooks/useEntitlementsStepUp';
import {
  BENEFICIARY_COSMIC_STATUS,
  BeneficiaryError,
  BeneficiaryTaskDetail,
  PostBeneficiaryStatusUpdateParams,
  PostBeneficiaryStatusUpdateParamsPayload,
  SearchBy,
  SearchByType,
} from '../../store/types';
import { ApprovalWorkflowConsent } from '../../store/types/ApprovalWorkflowConsent';
import { AUTHORISATION_STATUS } from '../../store/types/BeneficiaryAuthorisation';
import { GalaxyMakerCheckerWrapper } from '../../widgets/galaxymakerchecker-v1';
import { PostApprovalWorkflowConsentData } from '../../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types';
import { PingmfaWidgetApp } from '../../widgets/pingmfa/pingmfa-v1';
import { BeneficiaryPaymentDetails } from '../../components/BeneficiaryPaymentDetails/BeneficiaryPaymentDetails';
import { useHandleRedirectToBeneficiaryList } from '../../common/BeneficiaryList.util';
import NotificationAlert from '../../components/NotificationAlert/NotificationAlert';
import { DivisionDisplay } from '../../components/DivisionDisplay';
import { BeneficiaryTaskRejectModal } from '../../components';

const AUTHORISE_ADD = 'authorise_add';
const AUTHORISE_UPDATE = 'authorise_update';
const AUTHORISE_ARCHIVE = 'authorise_archive';
const REJECT_ADD = 'reject_add';
const REJECT_UPDATE = 'reject_update';
const REJECT_ARCHIVE = 'reject_archive';

type BeneficiaryTaskDetailsCardProps = {
  beneficiaryDetail: BeneficiaryTaskDetail;
  approvalWorkflowId: string;
  entitlementsPayload: string;
  searchBy: SearchByType;
  isBeneficiaryStatusUpdateError: boolean;
  beneficiaryStatusUpdateErrors: BeneficiaryError;
  isBeneficiaryStatusUpdateFetching: boolean;
  beneficiaryStatusUpdate: (
    payload: PostBeneficiaryStatusUpdateParamsPayload
  ) => void;
  clearBeneficiaryStatusUpdate: () => void;
};

export const BeneficiaryTaskDetailsCard = ({
  beneficiaryDetail,
  approvalWorkflowId,
  entitlementsPayload,
  searchBy,
  isBeneficiaryStatusUpdateError,
  beneficiaryStatusUpdateErrors,
  isBeneficiaryStatusUpdateFetching,
  beneficiaryStatusUpdate,
  clearBeneficiaryStatusUpdate,
}: BeneficiaryTaskDetailsCardProps) => {
  const { closeTab } = useClose();
  const handleCloseTab = async () => {
    await closeTab();
  };
  const [approvalWorkflowConsentPayload, setApprovalWorkflowConsentPayload] =
    useState<ApprovalWorkflowConsent>();
  const initialTsRef = useRef(Date.now());
  const [trigger, setTrigger] = useState(initialTsRef.current);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [userAction, setUserAction] = useState<string | null>(null);
  const globalDispatch = useGlobalDispatch();
  const handleRaiseIntent = useHandleRaiseIntent(
    useGlobalDispatch,
    useNavigate
  );
  const handleRedirectToBeneficiaryList = useHandleRedirectToBeneficiaryList();

  const [isStepUpModalVisible, setIsStepUpModalVisible] =
    useState<boolean>(false);
  const [error, setError] = useState<unknown>(null);
  const { populateHeader } = useEntitlementsSafi();
  const { renderEntitlementsStepUp } = useEntitlementsStepUp({
    pingMfaWidget: <PingmfaWidgetApp />,
    apiStatus: error?.status,
    errors: error?.data?.errors ?? [],
    isStepUpModalVisible,
    setIsStepUpModalVisible,
    updateTrigger: () => {
      setIsLoading(true);
      setTrigger(Date.now());
    },
    propType: 'makerChecker',
  });
  const [organisationSSOData] = usePlatformState(W1_ORGANIZATION_SSO, {
    orgId: {
      organisationId: '',
    },
  });
  const [isStatusUpdatePending, setIsStatusUpdatePending] =
    useState<boolean>(false);
  const rejectBeneficiaryTaskModalState = useOverlayTriggerState({});
  const orgId = organisationSSOData?.orgId?.organisationId;

  const navigateToBeneficiariesPage = useCallback(
    async ({
      action,
      notificationType,
      // eslint-disable-next-line no-shadow
      userAction,
      err,
    }: {
      action: string;
      notificationType: string;
      userAction: string;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      err?: any;
    }) => {
      await handleRaiseIntent({
        intentName: INTENT_NAMES.BENEFICIARY_LISTS,
        intentContextName: INTENTS_CONTEXT_NAME.BENEFICIARY,
        data: {
          selectedBeneficiariesTab: 'authorisation',
          notificationAlert: {
            message: {
              action,
              nickname: beneficiaryDetail.nickname,
              errorResponse: err,
              userAction,
            },
            type: notificationType,
          },
        },
        targetPath: PAGE_NAVIGATION.BENEFICIARY_LISTS,
      });
      await closeTab();
    },
    [
      INTENT_NAMES.BENEFICIARY_LISTS,
      INTENTS_CONTEXT_NAME.BENEFICIARY,
      PAGE_NAVIGATION.BENEFICIARY_LISTS,
    ]
  );

  const onAuthorisedClick = () => {
    setUserAction('authorise');
    setTrigger(Date.now());
    setIsLoading(true);
    setApprovalWorkflowConsentPayload({
      approvalWorkflowConsent: {
        approvalWorkflowId,
        status: 'APPROVED',
      },
      entitlementsPayload: isEmpty(entitlementsPayload)
        ? '{}'
        : entitlementsPayload,
    });
  };

  const onHandleRejectTask = (rejectReason?: string) => {
    setUserAction('reject');
    setTrigger(Date.now());
    setIsLoading(true);
    setApprovalWorkflowConsentPayload({
      approvalWorkflowConsent: {
        approvalWorkflowId,
        status: 'REJECTED',
        ...(rejectReason && {
          comment: {
            description: rejectReason,
            documentId: beneficiaryDetail.id,
          },
        }),
      },
      entitlementsPayload: isEmpty(entitlementsPayload)
        ? '{}'
        : entitlementsPayload,
    });
  };

  useEffect(() => {
    const hasStatusUpdateSucceeded =
      isStatusUpdatePending &&
      !isBeneficiaryStatusUpdateFetching &&
      !isBeneficiaryStatusUpdateError;

    const hasStatusUpdateFailed =
      isStatusUpdatePending &&
      !isBeneficiaryStatusUpdateFetching &&
      isBeneficiaryStatusUpdateError;

    if (hasStatusUpdateSucceeded) {
      // Status update succeeded, now proceed with beneficiary update
      setIsStatusUpdatePending(false);
      onHandleRejectTask();
    } else if (hasStatusUpdateFailed) {
      // Status update failed, show error and stop
      setIsStatusUpdatePending(false);

      // Handle beneficiary status update timeout error
      if (!beneficiaryStatusUpdateErrors?.status) {
        const data = {
          notificationAlert: {
            type: 'danger',
            message: BENEFICIARY_STATUS_UPDATE_TIMEOUT_ERROR_MESSAGE,
          },
        };
        globalDispatch({
          type: 'galaxy/context/update',
          data,
        });
        return;
      }
      // Handle other beneficiary status update error 409 and 4xx/5xx
      handleRedirectToBeneficiaryList(
        'danger',
        beneficiaryStatusUpdateErrors?.status === 409
          ? BENEFICIARY_STATUS_UPDATE_UNKNOWN_ERROR_MESSAGE
          : BENEFICIARY_STATUS_UPDATE_GENERIC_ERROR_MESSAGE
      ).catch(() => undefined);
    }
  }, [
    isStatusUpdatePending,
    isBeneficiaryStatusUpdateFetching,
    isBeneficiaryStatusUpdateError,
  ]);

  useEffect(() => {
    const existing = document.getElementById('widget-config-fetching-error');
    if (existing) {
      setIsLoading(false);
      return;
    }

    const observer = new MutationObserver(() => {
      const found = document.getElementById('widget-config-fetching-error');
      if (found) {
        setIsLoading(false);
        const data = {
          notificationAlert: {
            type: 'danger',
            message: BENEFICIARY_ADD_CLIENT_TIMEOUT_ERROR_MESSAGE,
          },
        };
        globalDispatch({
          type: 'galaxy/context/update',
          data,
        });
        observer.disconnect();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    return () => observer.disconnect();
  }, [isLoading]);

  const onClickReject = () => {
    rejectBeneficiaryTaskModalState.open();
  };

  const rejectRequest = (rejectReason: string) => {
    if (beneficiaryDetail.subType === 'addbeneficiary') {
      onHandleRejectTask(rejectReason);
      return;
    }
    clearBeneficiaryStatusUpdate();
    const postBeneficiaryStatusUpdateParams: PostBeneficiaryStatusUpdateParams =
      {
        beneficiary: {
          id: beneficiaryDetail.beneficiaryId,
          status: BENEFICIARY_COSMIC_STATUS.ACTIVE,
        },
      };
    setIsStatusUpdatePending(true);
    beneficiaryStatusUpdate({ params: postBeneficiaryStatusUpdateParams });
  };

  const getExpectedAction = (
    subType: BeneficiaryTaskDetail['subType'],
    isAuthorise: boolean
  ) => {
    switch (subType) {
      case 'amendbeneficiary':
        return isAuthorise ? AUTHORISE_UPDATE : REJECT_UPDATE;
      case 'archivebeneficiary':
        return isAuthorise ? AUTHORISE_ARCHIVE : REJECT_ARCHIVE;
      default:
        return isAuthorise ? AUTHORISE_ADD : REJECT_ADD;
    }
  };

  const onApiResponse = (
    res: { data?: PostApprovalWorkflowConsentData } = {}
  ) => {
    setIsLoading(false);
    setError(null);
    const approvalCode = res.data?.data?.approvalWorkflowConsent[0].code;
    const isAuthorise = approvalCode === 8120;
    const isReject = approvalCode === 8130;

    // Prevent mismatched actions
    if (
      (userAction === 'authorise' && isReject) ||
      (userAction === 'reject' && isAuthorise)
    ) {
      console.error(
        'Error: Mismatch between user action and backend response.'
      );
      setUserAction(null);
      return;
    }

    const expectedAction = getExpectedAction(
      beneficiaryDetail.subType,
      isAuthorise
    );

    if (isAuthorise || isReject) {
      navigateToBeneficiariesPage({
        action: expectedAction,
        notificationType: 'success',
        userAction: userAction || '',
      });
    } else {
      console.error('Unhandled approval code:', approvalCode);
    }
    setUserAction(null);
  };

  const onApiError = (err: any) => {
    setIsLoading(false);
    setError(err);
    const errorStatus = err?.status;
    const errorStatusCode = err.data?.errors?.[0]?.code;
    const noErrorStatusCode =
      errorStatusCode === null || errorStatusCode === undefined;

    const isTimeoutError = errorStatus === 504;
    const isEntitlementError =
      errorStatus === 403 && errorStatusCode === ERROR_CODES.NOT_ENTITLED;
    const isStepUpRequiredError =
      errorStatus === 401 && errorStatusCode === ERROR_CODES.STEP_UP_REQUIRED;

    // Client side timeout: no error status and no error code

    // Server side timeout: 504 Gateway Timeout and no error code
    if (isTimeoutError && noErrorStatusCode) {
      handleRedirectToBeneficiaryList(
        'danger',
        BENEFICIARY_ADD_SERVER_TIMEOUT_ERROR_MESSAGE
      ).catch(() => undefined);
      return;
    }
    // PDP / API error / SAFI deny
    if (!errorStatus && noErrorStatusCode) {
      handleRedirectToBeneficiaryList(
        'danger',
        BENEFICIARY_ADD_GENERIC_ERROR_MESSAGE
      ).catch(() => undefined);
      return;
    }
    // Entitlement error
    if (isEntitlementError) {
      handleRedirectToBeneficiaryList(
        'danger',
        BENEFICIARY_ADD_ENTITLEMENT_ERROR_MESSAGE
      ).catch(() => undefined);
      return;
    }
    // Issue authorising or rejecting DSR
    if (errorStatus >= 400 && errorStatusCode === 8135) {
      handleRedirectToBeneficiaryList(
        'danger',
        // Check if task already completed by another user
        errorStatus === 400 && err.data?.errors?.[0]?.details?.includes('1006')
          ? BENEFICIARY_ADD_EXIST_ERROR_MESSAGE
          : BENEFICIARY_ADD_SERVER_TIMEOUT_ERROR_MESSAGE
      ).catch(() => undefined);
      return;
    }
    //Issue with adding an existing beneficiary during the Create Beneficiary task.
    if (errorStatus === 409 && noErrorStatusCode) {
      handleRedirectToBeneficiaryList(
        'danger',
        BENEFICIARY_ADD_SERVER_TIMEOUT_ERROR_MESSAGE
      ).catch(() => undefined);
      return;
    }
    // MFA
    if (isStepUpRequiredError) {
      setIsStepUpModalVisible(true);
    } else {
      //fallback for other errors including 4xx and 5xx
      handleRedirectToBeneficiaryList(
        'danger',
        BENEFICIARY_ADD_GENERIC_ERROR_MESSAGE
      ).catch(() => undefined);
    }
    return;
  };

  const createConsentHeaders = () => {
    let channelRequestId: string | undefined;

    if (entitlementsPayload) {
      try {
        const parsed = JSON.parse(entitlementsPayload);
        channelRequestId = parsed?.makerRequest?.id;
      } catch (error) {
        channelRequestId = undefined;
      }
    }

    return {
      ...(orgId && {
        'protected-orgId': orgId,
      }),
      ...(window.encode_deviceprint
        ? populateHeader({}, window.encode_deviceprint)
        : {}),
      ...(channelRequestId && { 'x-channelRequestId': channelRequestId }),
    };
  };

  // api not reachable, need to show retry
  const showRetryMessage =
    error !== null &&
    (get(error, 'status') === undefined || get(error, 'status') === null);

  const getDivisionProps = () => {
    const divisionLabel = beneficiaryDetail?.divisionName;
    if (isStaffPortal() || !divisionLabel) return {};
    return { division: divisionLabel };
  };

  return (
    <>
      {(isLoading || isBeneficiaryStatusUpdateFetching) && (
        <div
          data-testid="progress-indicator"
          className="fixed inset-0 flex justify-center items-center bg-border bg-opacity-75 z-50"
        >
          <ProgressIndicator size="medium" />
        </div>
      )}

      <MVCard title="Beneficiary details" template="narrow" bottomDivider>
        <NotificationAlert key={trigger} />
        <BeneficiaryTaskRejectModal
          state={rejectBeneficiaryTaskModalState}
          rejectRequest={rejectRequest}
        />
        <Grid className="xsl:gap-0 sm:gap-0 !gap-0">
          {showRetryMessage && (
            <GridItem span={12}>
              <Alert
                className="mb-0"
                look="danger"
                id="beneficiary-details-error-banner"
                iconSize="small"
              >
                {errorMessageListForAuthoriseBenReq.UNREACHABLE}
              </Alert>
            </GridItem>
          )}
          <DivisionDisplay {...getDivisionProps()} />
          <BeneficiarySummary beneficiaryDetails={beneficiaryDetail} />
          <BeneficiaryPaymentDetails beneficiaryDetails={beneficiaryDetail} />
          <BeneficiaryAuthorisationActivity
            authorisationActivityDetails={beneficiaryDetail}
          />
          {(beneficiaryDetail.subType === 'amendbeneficiary' ||
            beneficiaryDetail.subType === 'archivebeneficiary') && (
            <GridItem span={12}>
              <Alert look="info" iconSize="small" className="mb-2.5">
                Any changes to beneficiaries will only affect new payments.
                Payments already created and submitted will not be updated with
                these changes.
              </Alert>
            </GridItem>
          )}
          <GridItem
            className="w-full border-t border-border pt-2.5 mt-0 flex gap-[9px]"
            span={12}
          >
            {beneficiaryDetail.status ===
              AUTHORISATION_STATUS.PENDING_AUTHORISATION &&
              searchBy === SearchBy.ApproverAndCreatedOnDateRange && (
                <>
                  <Button
                    look="primary"
                    size="small"
                    onClick={onAuthorisedClick}
                  >
                    Authorise
                  </Button>
                  <Button look="hero" size="small" onClick={onClickReject}>
                    Reject
                  </Button>
                </>
              )}
            <Button look="hero" soft size="small" onClick={handleCloseTab}>
              Close
            </Button>
            <React.Fragment key={trigger}>
              {approvalWorkflowConsentPayload &&
                trigger !== initialTsRef.current &&
                userAction && (
                  <GalaxyMakerCheckerWrapper
                    apiName="postApprovalWorkflowConsent"
                    params={{
                      body: approvalWorkflowConsentPayload,
                    }}
                    options={{
                      headers: createConsentHeaders() as Record<string, any>,
                    }}
                    trigger={trigger}
                    onApiResponse={onApiResponse}
                    onApiError={onApiError}
                  />
                )}
              {renderEntitlementsStepUp()}
            </React.Fragment>
          </GridItem>
        </Grid>
      </MVCard>
    </>
  );
};

export default BeneficiaryTaskDetailsCard;
