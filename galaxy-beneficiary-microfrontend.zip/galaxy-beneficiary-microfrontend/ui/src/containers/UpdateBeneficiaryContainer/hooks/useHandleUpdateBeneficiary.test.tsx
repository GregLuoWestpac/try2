/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-explicit-any */

import { renderHook, waitFor } from '@testing-library/react';
import { useHandleUpdateBeneficiary } from './useHandleUpdateBeneficiary';
import {
  BENEFICIARY_COSMIC_STATUS,
  BENEFICIARY_TYPE,
  CURRENCY,
} from '../../../store/types';
import { ERROR_CODES } from '../../../common';

// Mock mv-reacthookform to prevent webpack chunk loading issues
jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  DATE_FORMAT_YYYYMMDD: 'YYYY-MM-DD',
  getToday: jest.fn(() => ({
    toFormat: jest.fn(() => '2024-01-01'),
  })),
  getTodayAtLastYear: jest.fn(() => ({
    toFormat: jest.fn(() => '2023-01-01'),
  })),
}));

const mockGlobalDispatch = jest.fn();
const mockHandleRedirectToBeneficiaryList = jest
  .fn()
  .mockResolvedValue(undefined);

jest.mock('@mep-ui/framework', () => ({
  useGlobalDispatch: () => mockGlobalDispatch,
}));

jest.mock('../../../common/BeneficiaryList.util', () => ({
  useHandleRedirectToBeneficiaryList: () => mockHandleRedirectToBeneficiaryList,
}));

const mockRevertStatusAndRedirect = jest.fn();
jest.mock('../../../hooks/useRevertBeneficiaryStatus', () => ({
  useRevertBeneficiaryStatus: () => ({
    revertStatusAndRedirect: mockRevertStatusAndRedirect,
    isRevertingToActive: false,
  }),
}));

describe('useHandleUpdateBeneficiary', () => {
  const mockBeneficiaryStatusUpdate = jest.fn();
  const mockUpdateBeneficiaryDetailsWithExtraHeaders = jest.fn();
  const mockSetIsStepUpModalVisible = jest.fn();
  const mockClearBeneficiaryStatusUpdate = jest.fn();
  const mockClearUpdateBeneficiary = jest.fn();

  const defaultProps = {
    isUpdateBeneficiaryError: false,
    isUpdateBeneficiaryFetching: false,
    updateBeneficiaryErrors: {} as any,
    allBeneficiaryUpdate: [],
    beneficiaryStatusUpdate: mockBeneficiaryStatusUpdate,
    selectedBeneficiaryId: 'test-beneficiary-id',
    isBeneficiaryStatusUpdateError: false,
    isBeneficiaryStatusUpdateFetching: false,
    updateBeneficiaryParamsRef: { current: undefined },
    setIsStepUpModalVisible: mockSetIsStepUpModalVisible,
    updateBeneficiaryDetailsWithExtraHeaders:
      mockUpdateBeneficiaryDetailsWithExtraHeaders,
    clearBeneficiaryStatusUpdate: mockClearBeneficiaryStatusUpdate,
    clearUpdateBeneficiary: mockClearUpdateBeneficiary,
    beneficiaryStatusUpdateErrors: {} as any,
  };

  const mockUpdateData = {
    params: {
      beneficiary: {
        id: 'test-beneficiary-id',
        externalId: 'test-external-id',
        nickname: 'Test Nickname',
        type: BENEFICIARY_TYPE.ACCOUNT,
        currencyAmount: {
          amount: '100.00',
          currencyCode: CURRENCY.AUD,
        },
        account: {
          accountId: {
            BSB: '123456',
            accountNumber: '12345678',
          },
          bankName: 'Test Bank',
          accountName: 'Test Account',
        },
      },
    },
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('updateBeneficiaryDetails flow', () => {
    it('should call beneficiaryStatusUpdate with ON_HOLD status when updateBeneficiaryDetails is called', () => {
      const { result } = renderHook(() =>
        useHandleUpdateBeneficiary(defaultProps)
      );

      const options = { headers: { 'x-test': 'header' } };

      result.current.updateBeneficiaryDetails(mockUpdateData, options);

      expect(mockClearBeneficiaryStatusUpdate).toHaveBeenCalledTimes(1);
      expect(mockClearUpdateBeneficiary).toHaveBeenCalledTimes(1);
      expect(mockBeneficiaryStatusUpdate).toHaveBeenCalledWith({
        params: {
          beneficiary: {
            id: 'test-beneficiary-id',
            status: BENEFICIARY_COSMIC_STATUS.ON_HOLD,
          },
        },
      });
    });

    it('should store update params and options in refs when updateBeneficiaryDetails is called', () => {
      const updateBeneficiaryParamsRef = { current: undefined };
      const props = {
        ...defaultProps,
        updateBeneficiaryParamsRef,
      };
      const { result } = renderHook(() => useHandleUpdateBeneficiary(props));

      const options = { headers: { 'x-test': 'header' } };

      result.current.updateBeneficiaryDetails(mockUpdateData, options);

      expect(updateBeneficiaryParamsRef.current).toEqual(mockUpdateData);
    });
  });

  describe('status update success flow', () => {
    it('should call updateBeneficiaryDetailsWithExtraHeaders when status update succeeds', async () => {
      const options = { headers: { 'x-test': 'header' } };

      const updateBeneficiaryParamsRef = { current: undefined };

      const { result, rerender } = renderHook(
        props => useHandleUpdateBeneficiary(props),
        {
          initialProps: {
            ...defaultProps,
            updateBeneficiaryParamsRef,
          },
        }
      );

      // Initiate update
      result.current.updateBeneficiaryDetails(mockUpdateData, options);

      // Simulate status update in progress
      rerender({
        ...defaultProps,
        updateBeneficiaryParamsRef,
        isBeneficiaryStatusUpdateFetching: true,
      });

      // Simulate status update success
      rerender({
        ...defaultProps,
        updateBeneficiaryParamsRef,
        isBeneficiaryStatusUpdateFetching: false,
        isBeneficiaryStatusUpdateError: false,
      });

      await waitFor(() => {
        expect(mockSetIsStepUpModalVisible).toHaveBeenCalledWith(true);
        expect(
          mockUpdateBeneficiaryDetailsWithExtraHeaders
        ).toHaveBeenCalledWith(mockUpdateData, options);
      });
    });

    it('should not call updateBeneficiaryDetailsWithExtraHeaders if updateBeneficiaryParamsRef is empty', async () => {
      const updateBeneficiaryParamsRef = { current: undefined };
      const props = {
        ...defaultProps,
        updateBeneficiaryParamsRef,
        isBeneficiaryStatusUpdateFetching: false,
        isBeneficiaryStatusUpdateError: false,
      };

      renderHook(() => useHandleUpdateBeneficiary(props));

      await waitFor(() => {
        expect(mockSetIsStepUpModalVisible).not.toHaveBeenCalled();
        expect(
          mockUpdateBeneficiaryDetailsWithExtraHeaders
        ).not.toHaveBeenCalled();
      });
    });
  });
  describe('status update error flow', () => {
    it('should not proceed with update when status update fails', async () => {
      const options = { headers: {} };

      const updateBeneficiaryParamsRef = { current: mockUpdateData };
      const props = {
        ...defaultProps,
        updateBeneficiaryParamsRef,
      };

      const { result, rerender } = renderHook(
        p => useHandleUpdateBeneficiary(p),
        {
          initialProps: props,
        }
      );

      // Initiate update
      result.current.updateBeneficiaryDetails(mockUpdateData, options);

      // Simulate status update in progress
      rerender({
        ...props,
        isBeneficiaryStatusUpdateFetching: true,
      });

      // Simulate status update error
      rerender({
        ...props,
        isBeneficiaryStatusUpdateFetching: false,
        isBeneficiaryStatusUpdateError: true,
        beneficiaryStatusUpdateErrors: {
          status: 500,
          data: { errors: [{ message: 'Internal server error' }] },
        } as any,
      });

      await waitFor(() => {
        expect(
          mockUpdateBeneficiaryDetailsWithExtraHeaders
        ).not.toHaveBeenCalled();
        expect(mockSetIsStepUpModalVisible).not.toHaveBeenCalled();
      });
    });
  });

  describe('update beneficiary success flow', () => {
    it('should redirect to beneficiary list when update succeeds', async () => {
      const props = {
        ...defaultProps,
        isUpdateBeneficiaryFetching: false,
        isUpdateBeneficiaryError: false,
        allBeneficiaryUpdate: [{ id: 'test-beneficiary-id' } as any],
      };

      renderHook(() => useHandleUpdateBeneficiary(props));

      await waitFor(() => {
        expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
          'success',
          {
            nickname: '',
            action: 'update',
            isMakerCheckerApplicable: false,
          }
        );
      });
    });

    it('should use stored nickname when redirecting after successful update', async () => {
      const options = { headers: {} };

      const { result, rerender } = renderHook(
        props => useHandleUpdateBeneficiary(props),
        {
          initialProps: defaultProps,
        }
      );

      // Set nickname by calling updateBeneficiaryDetails
      result.current.updateBeneficiaryDetails(mockUpdateData, options);

      // Simulate successful update
      const successProps = {
        ...defaultProps,
        isUpdateBeneficiaryFetching: false,
        isUpdateBeneficiaryError: false,
        allBeneficiaryUpdate: [{ id: 'test-beneficiary-id' } as any],
      };
      rerender(successProps);

      await waitFor(() => {
        expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
          'success',
          {
            nickname: 'Test Nickname',
            action: 'update',
            isMakerCheckerApplicable: false,
          }
        );
      });
    });
  });

  describe('update beneficiary error flow', () => {
    it('should show timeout error notification when update fails without status', async () => {
      const props = {
        ...defaultProps,
        isUpdateBeneficiaryError: true,
        isUpdateBeneficiaryFetching: false,
        updateBeneficiaryErrors: {
          data: { errors: [{ message: 'Network error' }] },
        } as any,
      };

      renderHook(() => useHandleUpdateBeneficiary(props));

      await waitFor(() => {
        expect(mockGlobalDispatch).toHaveBeenCalledWith({
          type: 'galaxy/context/update',
          data: {
            notificationAlert: {
              type: 'danger',
              message: 'Something went wrong.',
            },
          },
        });
      });
    });

    it('should call revertStatusAndRedirect when update fails with entitlement error (8210)', async () => {
      const props = {
        ...defaultProps,
        isUpdateBeneficiaryError: true,
        isUpdateBeneficiaryFetching: false,
        updateBeneficiaryErrors: {
          status: 403,
          data: { errors: [{ code: 8210 }] },
        } as any,
      };

      renderHook(() => useHandleUpdateBeneficiary(props));

      await waitFor(() => {
        expect(mockRevertStatusAndRedirect).toHaveBeenCalledWith({
          errorMessage:
            'You do not have permission to add or update beneficiaries. Contact your administrator for more information.',
        });
      });
    });

    it('should redirect with success for maker-checker flow when error code is 8125', async () => {
      const { result, rerender } = renderHook(
        props => useHandleUpdateBeneficiary(props),
        { initialProps: defaultProps }
      );

      // Set nickname first
      result.current.updateBeneficiaryDetails(mockUpdateData, { headers: {} });

      // Then simulate error
      const errorProps = {
        ...defaultProps,
        isUpdateBeneficiaryError: true,
        isUpdateBeneficiaryFetching: false,
        updateBeneficiaryErrors: {
          status: 401,
          data: { errors: [{ code: 8125 }] },
        } as any,
      };
      rerender(errorProps);

      await waitFor(() => {
        expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
          'success',
          {
            nickname: 'Test Nickname',
            action: 'update',
            isMakerCheckerApplicable: true,
          }
        );
      });
    });

    it('should hide notification when step-up is required (error code 8200)', async () => {
      const props = {
        ...defaultProps,
        isUpdateBeneficiaryError: true,
        isUpdateBeneficiaryFetching: false,
        updateBeneficiaryErrors: {
          status: 401,
          data: { errors: [{ code: ERROR_CODES.STEP_UP_REQUIRED }] },
        } as any,
      };

      renderHook(() => useHandleUpdateBeneficiary(props));

      await waitFor(() => {
        expect(mockGlobalDispatch).toHaveBeenCalledWith({
          type: 'galaxy/context/update',
          data: {
            notificationAlert: null,
          },
        });
      });
    });

    it('should call revertStatusAndRedirect for other errors', async () => {
      const props = {
        ...defaultProps,
        isUpdateBeneficiaryError: true,
        isUpdateBeneficiaryFetching: false,
        updateBeneficiaryErrors: {
          status: 500,
          data: { errors: [{ message: 'Internal server error' }] },
        } as any,
      };

      renderHook(() => useHandleUpdateBeneficiary(props));

      await waitFor(() => {
        expect(mockRevertStatusAndRedirect).toHaveBeenCalledWith({
          errorMessage: 'Something went wrong. Please try again later.',
        });
      });
    });
  });
});
