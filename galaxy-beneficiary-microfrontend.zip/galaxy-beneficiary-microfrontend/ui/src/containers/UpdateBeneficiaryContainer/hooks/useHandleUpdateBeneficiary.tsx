import { useCallback, useEffect, useRef, useState } from 'react';
import { useGlobalDispatch } from '@mep-ui/framework';
import { interpolateTemplate } from '../../../common/Beneficiary.util';
import {
  BeneficiaryOptionsPayload,
  PostBeneficiaryStatusUpdateParams,
  PostBeneficiaryStatusUpdateParamsPayload,
  PutBeneficiaryParamsPayload,
} from '../../../store/types/Actions';
import {
  Beneficiary,
  BENEFICIARY_COSMIC_STATUS,
  BeneficiaryError,
} from '../../../store/types';
import { useHandleRedirectToBeneficiaryList } from '../../../common/BeneficiaryList.util';
import { useRevertBeneficiaryStatus } from '../../../hooks/useRevertBeneficiaryStatus';
import {
  BENEFICIARY_STATUS_UPDATE_GENERIC_ERROR_MESSAGE,
  BENEFICIARY_STATUS_UPDATE_TIMEOUT_ERROR_MESSAGE,
  BENEFICIARY_UPDATE_ENTITLEMENT_ERROR_MESSAGE,
  BENEFICIARY_UPDATE_GENERIC_ERROR_MESSAGE,
  BENEFICIARY_UPDATE_SENT_FOR_AUTHORISATION_MESSAGE,
  BENEFICIARY_UPDATE_SUCCESS_MESSAGE,
  BENEFICIARY_UPDATE_TIMEOUT_ERROR_MESSAGE,
  ERROR_CODES,
} from '../../../common';

export type UseHandleUpdateBeneficiaryProps = {
  isUpdateBeneficiaryError: boolean;
  isUpdateBeneficiaryFetching: boolean;
  updateBeneficiaryErrors: BeneficiaryError;
  allBeneficiaryUpdate: Beneficiary[];
  beneficiaryStatusUpdate: (
    payload: PostBeneficiaryStatusUpdateParamsPayload
  ) => void;
  selectedBeneficiaryId: string;
  isBeneficiaryStatusUpdateError: boolean;
  isBeneficiaryStatusUpdateFetching: boolean;
  updateBeneficiaryParamsRef: React.MutableRefObject<
    PutBeneficiaryParamsPayload | undefined
  >;
  setIsStepUpModalVisible: (isVisible: boolean) => void;
  updateBeneficiaryDetailsWithExtraHeaders: (
    data: PutBeneficiaryParamsPayload,
    options: BeneficiaryOptionsPayload
  ) => void;
  clearBeneficiaryStatusUpdate: () => void;
  clearUpdateBeneficiary: () => void;
  beneficiaryStatusUpdateErrors: BeneficiaryError;
};

export const useHandleUpdateBeneficiary = ({
  isUpdateBeneficiaryError,
  isUpdateBeneficiaryFetching,
  updateBeneficiaryErrors,
  allBeneficiaryUpdate,
  beneficiaryStatusUpdate,
  selectedBeneficiaryId,
  isBeneficiaryStatusUpdateError,
  isBeneficiaryStatusUpdateFetching,
  updateBeneficiaryParamsRef,
  setIsStepUpModalVisible,
  updateBeneficiaryDetailsWithExtraHeaders,
  clearBeneficiaryStatusUpdate,
  clearUpdateBeneficiary,
  beneficiaryStatusUpdateErrors,
}: UseHandleUpdateBeneficiaryProps) => {
  const [isStatusUpdatePending, setIsStatusUpdatePending] =
    useState<boolean>(false);
  const beneficiaryUpdateOptionsRef = useRef<
    BeneficiaryOptionsPayload | undefined
  >(undefined);
  const nicknameRef = useRef('');
  const handleRedirectToBeneficiaryList = useHandleRedirectToBeneficiaryList();

  const { revertStatusAndRedirect } = useRevertBeneficiaryStatus({
    selectedBeneficiaryId,
    isBeneficiaryStatusUpdateFetching,
    beneficiaryStatusUpdate,
  });

  // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-call
  const globalDispatch = useGlobalDispatch();

  // Handle update beneficiary error
  useEffect(() => {
    if (
      isUpdateBeneficiaryError &&
      !isUpdateBeneficiaryFetching &&
      updateBeneficiaryErrors
    ) {
      const errorStatus = updateBeneficiaryErrors?.status;
      const errorCode = updateBeneficiaryErrors?.data?.errors?.[0]?.code;

      // Check for specific error scenarios
      const isUpdateBeneficiaryTimeoutError = !errorStatus;
      const isUpdateBeneficiaryEntitlementError =
        errorStatus === 403 && errorCode === 8210;
      const isUpdateBeneficiarySentForAuthorisation =
        errorStatus === 401 && errorCode === 8125;
      const isUpdateBeneficiaryMfaRequiredError =
        errorStatus === 401 && errorCode === ERROR_CODES.STEP_UP_REQUIRED;

      // Handle timeout error (no response received)
      if (isUpdateBeneficiaryTimeoutError) {
        const data = {
          notificationAlert: {
            type: 'danger',
            message: BENEFICIARY_UPDATE_TIMEOUT_ERROR_MESSAGE,
          },
        };
        // eslint-disable-next-line @typescript-eslint/no-unsafe-call
        globalDispatch({
          type: 'galaxy/context/update',
          data,
        });

        return;
      }

      // Handle entitlement error (user lacks permission)
      if (isUpdateBeneficiaryEntitlementError) {
        // Revert beneficiary status from ON_HOLD to ACTIVE before redirecting
        revertStatusAndRedirect({
          errorMessage: BENEFICIARY_UPDATE_ENTITLEMENT_ERROR_MESSAGE,
        });
        return;
      }

      // Handle maker-checker scenario (requires authorisation)
      if (isUpdateBeneficiarySentForAuthorisation) {
        handleRedirectToBeneficiaryList('success', {
          nickname: nicknameRef.current || '',
          action: 'update',
          isMakerCheckerApplicable: true,
        }).catch(() => undefined);
        return;
      }

      // Handle MFA required error (step-up authentication needed)
      if (isUpdateBeneficiaryMfaRequiredError) {
        // Hide notification error when MFA modal is displayed
        const data = {
          notificationAlert: null,
        };
        // eslint-disable-next-line @typescript-eslint/no-unsafe-call
        globalDispatch({
          type: 'galaxy/context/update',
          data,
        });
        return;
      }

      // Handle all other errors
      // Revert beneficiary status from ON_HOLD to ACTIVE before redirecting
      revertStatusAndRedirect({
        errorMessage: BENEFICIARY_UPDATE_GENERIC_ERROR_MESSAGE,
      });
    }
  }, [isUpdateBeneficiaryError, revertStatusAndRedirect]);

  // Handle successful update beneficiary
  useEffect(() => {
    if (
      !isUpdateBeneficiaryFetching &&
      !isUpdateBeneficiaryError &&
      allBeneficiaryUpdate.length > 0
    ) {
      // since action has been completed, isMakerCheckerApplicable not applicable
      handleRedirectToBeneficiaryList('success', {
        nickname: nicknameRef.current || '',
        action: 'update',
        isMakerCheckerApplicable: false,
      }).catch(() => undefined);
    }
  }, [
    isUpdateBeneficiaryError,
    isUpdateBeneficiaryFetching,
    allBeneficiaryUpdate,
  ]);

  // Monitor beneficiary status update completion before proceeding with beneficiary update
  useEffect(() => {
    const hasStatusUpdateSucceeded =
      isStatusUpdatePending &&
      !isBeneficiaryStatusUpdateFetching &&
      !isBeneficiaryStatusUpdateError &&
      updateBeneficiaryParamsRef.current;

    const hasStatusUpdateFailed =
      isStatusUpdatePending &&
      !isBeneficiaryStatusUpdateFetching &&
      isBeneficiaryStatusUpdateError;

    if (hasStatusUpdateSucceeded) {
      // Beneficiary status update to ON_HOLD succeeded, proceed with beneficiary update
      setIsStatusUpdatePending(false);
      const paramsRef = updateBeneficiaryParamsRef.current;
      if (paramsRef) {
        setIsStepUpModalVisible(true);
        updateBeneficiaryDetailsWithExtraHeaders(
          paramsRef,
          beneficiaryUpdateOptionsRef.current || { headers: {} }
        );
      }
    } else if (hasStatusUpdateFailed) {
      // Beneficiary status update to ON_HOLD failed, show error and stop
      setIsStatusUpdatePending(false);

      // Check for timeout error (no response received)
      const isBeneficiaryStatusUpdateTimeoutError =
        !beneficiaryStatusUpdateErrors?.status;

      // Handle Beneficiary status update timeout error
      if (isBeneficiaryStatusUpdateTimeoutError) {
        const data = {
          notificationAlert: {
            type: 'danger',
            message: BENEFICIARY_STATUS_UPDATE_TIMEOUT_ERROR_MESSAGE,
          },
        };
        // eslint-disable-next-line @typescript-eslint/no-unsafe-call
        globalDispatch({
          type: 'galaxy/context/update',
          data,
        });
        return;
      }

      // Handle other beneficiary status update errors with generic message
      handleRedirectToBeneficiaryList(
        'danger',
        BENEFICIARY_STATUS_UPDATE_GENERIC_ERROR_MESSAGE
      ).catch(() => undefined);
    }
  }, [
    isStatusUpdatePending,
    isBeneficiaryStatusUpdateFetching,
    isBeneficiaryStatusUpdateError,
  ]);

  // Initiate beneficiary update by first updating status to ON_HOLD
  const updateBeneficiaryDetails = useCallback(
    (data: PutBeneficiaryParamsPayload, options: BeneficiaryOptionsPayload) => {
      clearBeneficiaryStatusUpdate();
      clearUpdateBeneficiary();
      nicknameRef.current = data?.params?.beneficiary?.nickname;
      const paramsRef = updateBeneficiaryParamsRef;
      paramsRef.current = data;
      beneficiaryUpdateOptionsRef.current = options;

      // Update beneficiary status to ON_HOLD before updating details
      const postBeneficiaryStatusUpdateParams: PostBeneficiaryStatusUpdateParams =
        {
          beneficiary: {
            id: selectedBeneficiaryId,
            status: BENEFICIARY_COSMIC_STATUS.ON_HOLD,
          },
        };
      setIsStatusUpdatePending(true);
      beneficiaryStatusUpdate({ params: postBeneficiaryStatusUpdateParams });
    },
    [
      selectedBeneficiaryId,
      setIsStepUpModalVisible,
      updateBeneficiaryParamsRef,
      beneficiaryStatusUpdate,
      clearBeneficiaryStatusUpdate,
      clearUpdateBeneficiary,
    ]
  );

  return {
    updateBeneficiaryDetails,
  };
};
