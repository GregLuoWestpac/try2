export { default as UpdateBeneficiaryContainer } from './UpdateBeneficiaryContainer';
