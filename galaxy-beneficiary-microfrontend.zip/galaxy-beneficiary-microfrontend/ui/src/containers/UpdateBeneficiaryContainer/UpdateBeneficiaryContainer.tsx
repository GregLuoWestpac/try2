/* eslint-disable react/react-in-jsx-scope */
/* eslint-disable @typescript-eslint/no-unsafe-enum-comparison */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable no-shadow */
/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable react/require-default-props */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { compose, connect, useGlobalSelector } from '@mep-ui/framework';
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import { MVPageLoader as PageLoader } from '@mesh-tenant-multiverse-ui-common/mv-pageloader';
import { COPCheckResultData } from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
import { useEffect, useRef, useState } from 'react';
// @ts-ignore
import { usePlatformState } from '@mesh-tenant-multiverse-common/react';
import { useEntitlementsSafi } from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import { W1_ORGANIZATION_SSO } from '../../common';
import {
  BeneficiaryForm,
  ErrorHandler,
  StaySafeFromScamsBanner,
} from '../../components';

import {
  aliasLookupActions,
  aliasLookupEntityActions,
  beneficiaryDetailsActions,
  beneficiaryUpdateActions,
  bsbLookupActions,
  bsbLookupEntityActions,
  getAllAliasLookup,
  getAllBeneficiaryDetails,
  getAllBsbLookup,
  getAllAccountNameCheck,
  isAliasLookupError as isAliasLookupErrorSelector,
  isAliasLookupFetching as isAliasLookupFetchingSelector,
  isBeneficiaryDetailsError as isBeneficiaryDetailsErrorSelector,
  isBeneficiaryDetailsFetching as isBeneficiaryDetailsFetchingSelector,
  isBeneficiaryStatusUpdateError as isBeneficiaryStatusUpdateErrorSelector,
  isBeneficiaryStatusUpdateFetching as isBeneficiaryStatusUpdateFetchingSelector,
  getAllBeneficiaryUpdate as getAllBeneficiaryUpdateSelector,
  isBeneficiaryUpdateError,
  isBeneficiaryUpdateFetching,
  isBsbLookupError as isBsbLookupErrorSelector,
  isBsbLookupFetching as isBsbLookupFetchingSelector,
  isAccountNameCheckFetching as isAccountNameCheckFetchingSelector,
  isAccountNameCheckError as isAccountNameCheckErrorSelector,
  accountNameCheckActions,
  accountNameCheckEntityActions,
  beneficiaryStatusUpdateActions,
  beneficiaryStatusUpdateEntityActions,
  beneficiaryUpdateEntityActions,
} from '../../store/generated';
import {
  getBeneficiaryUpdateErrors,
  getBeneficiaryStatusUpdateErrors,
} from '../../store/selectors';
import { getBsbLookupStatusCode } from '../../store/selectors/bsbLookup';
import store from '../../store/store';
import {
  Beneficiary,
  BeneficiaryError,
  BeneficiaryOptionsPayload,
  GetBSBLookupParamsPayload,
  GlobalState,
  PostAccountNameCheckParamsPayload,
  PostAliaLookupParamsPayload,
  PostBeneficiaryDetailsParams,
  PostBeneficiaryDetailsParamsPayload,
  PutBeneficiaryParamsPayload,
  RootState,
  RequestOptionsPayload,
  PostBeneficiaryStatusUpdateParamsPayload,
} from '../../store/types';
import { PayIDs } from '../../store/types/AliasLookup';
import { Branch } from '../../store/types/BsbLookup';

import NotificationAlert from '../../components/NotificationAlert/NotificationAlert';

import { useRedirectToBeneficiaryList } from '../../common/BeneficiaryList.util';
import { useEntitlementsStepUp } from '../../hooks/useEntitlementsStepUp';
import {
  doesAliasIdContainInvalidDataSelector,
  isPayIdNotValidSelector,
  isPayIdServiceNotAvailableSelector,
  isPayIdLimitExceededSelector,
} from '../../store/selectors/aliasLookup';
import {
  isCopLimitExceededSelector,
  isCopServiceNotAvailableSelector,
} from '../../store/selectors/accountNameCheck';
import { PingmfaWidgetApp } from '../../widgets/pingmfa/pingmfa-v1';
import { useHandleUpdateBeneficiary } from './hooks/useHandleUpdateBeneficiary';

export type UpdateBeneficiaryContainerProps = {
  getBsbLookup: (payload: GetBSBLookupParamsPayload) => void;
  allBranches: Branch[];
  isBsbLookupError: boolean;
  isBsbLookupFetching: boolean;
  bsbLookupApiStatus?: number;
  allAliasLookup: PayIDs[];
  isAliasLookupError: boolean;
  isAliasLookupFetching: boolean;
  doesAliasIdContainInvalidData: boolean;
  isPayIdNotValid: boolean;
  isPayIdLimitExceeded: boolean;
  isPayIdServiceNotAvailable: boolean;
  postAliasLookup: (
    payload: PostAliaLookupParamsPayload,
    options: RequestOptionsPayload
  ) => void;
  clearAliasLookup: () => void;
  clearBsbLookup: () => void;
  updateBeneficiary: (
    payload: PutBeneficiaryParamsPayload,
    options: BeneficiaryOptionsPayload
  ) => void;
  isUpdateBeneficiaryFetching: boolean;
  isUpdateBeneficiaryError: boolean;
  allBeneficiaryUpdate: Beneficiary[];
  updateBeneficiaryErrors: BeneficiaryError;
  beneficiaryStatusUpdateErrors: BeneficiaryError;
  isBeneficiaryDetailsFetching: boolean;
  isBeneficiaryDetailsError: boolean;
  beneficiaryDetails: Beneficiary[];
  getBeneficiaryDetails: (
    payload: PostBeneficiaryDetailsParamsPayload,
    options: BeneficiaryOptionsPayload
  ) => void;
  isBeneficiaryStatusUpdateFetching: boolean;
  isBeneficiaryStatusUpdateError: boolean;
  beneficiaryStatusUpdate: (
    payload: PostBeneficiaryStatusUpdateParamsPayload
  ) => void;
  clearBeneficiaryStatusUpdate: () => void;
  clearUpdateBeneficiary: () => void;
  // Account Name Check (CoP) props
  postAccountNameCheckAction: (
    params: PostAccountNameCheckParamsPayload,
    options?: RequestOptionsPayload
  ) => void;
  clearAccountNameCheck: () => void;
  isAccountNameCheckFetching: boolean;
  isAccountNameCheckError: boolean;
  isCopLimitExceeded: boolean;
  isCopServiceNotAvailable: boolean;
  allAccountNameCheck: COPCheckResultData[];
};

export function UpdateBeneficiaryContainer({
  getBsbLookup,
  allBranches,
  isBsbLookupError,
  isBsbLookupFetching,
  bsbLookupApiStatus,
  isAliasLookupError,
  isAliasLookupFetching,
  doesAliasIdContainInvalidData,
  isPayIdNotValid,
  isPayIdLimitExceeded,
  isPayIdServiceNotAvailable,
  allAliasLookup,
  postAliasLookup,
  updateBeneficiary,
  isUpdateBeneficiaryFetching,
  isUpdateBeneficiaryError,
  allBeneficiaryUpdate,
  clearAliasLookup,
  updateBeneficiaryErrors,
  beneficiaryStatusUpdateErrors,
  clearBsbLookup,
  isBeneficiaryDetailsFetching,
  isBeneficiaryDetailsError,
  getBeneficiaryDetails,
  beneficiaryDetails,
  isBeneficiaryStatusUpdateError,
  isBeneficiaryStatusUpdateFetching,
  beneficiaryStatusUpdate,
  clearBeneficiaryStatusUpdate,
  clearUpdateBeneficiary,
  // Account Name Check (CoP) props
  postAccountNameCheckAction,
  clearAccountNameCheck,
  isAccountNameCheckFetching,
  isAccountNameCheckError,
  isCopLimitExceeded,
  isCopServiceNotAvailable,
  allAccountNameCheck,
}: UpdateBeneficiaryContainerProps) {
  const [organisationSSOData] = usePlatformState(W1_ORGANIZATION_SSO, {
    orgId: {
      organisationId: '',
    },
  });

  const orgId =
    window.location.hostname === 'localhost'
      ? '12345678910'
      : organisationSSOData?.orgId?.organisationId;
  const handleRedirect = useRedirectToBeneficiaryList();
  const updateBeneficiaryParamsRef = useRef<
    PutBeneficiaryParamsPayload | undefined
  >(undefined);

  const { populateHeader } = useEntitlementsSafi();

  const [isStepUpModalVisible, setIsStepUpModalVisible] =
    useState<boolean>(false);

  const updateBeneficiaryDetailsWithExtraHeaders = (
    data: PutBeneficiaryParamsPayload,
    options: BeneficiaryOptionsPayload
  ) => {
    const extraHeaders = {
      ...(options || {}),
      headers: {
        ...(options?.headers || {}),
        ...(window.encode_deviceprint
          ? populateHeader({}, window.encode_deviceprint)
          : {}),
        ...(orgId && { 'protected-orgId': orgId }),
        'x-channelRequestId':
          updateBeneficiaryParamsRef.current?.params?.beneficiary?.id,
      } as Record<string, any>,
    };
    updateBeneficiary(data, extraHeaders);
  };
  const { renderEntitlementsStepUp } = useEntitlementsStepUp({
    pingMfaWidget: <PingmfaWidgetApp />,
    propType: 'mfa',
    errors: updateBeneficiaryErrors?.data?.errors,
    apiStatus: updateBeneficiaryErrors?.status,
    dispatchFn: updateBeneficiaryDetailsWithExtraHeaders,
    dispatchFnParams: updateBeneficiaryParamsRef.current?.params ?? {},
    isStepUpModalVisible,
    setIsStepUpModalVisible,
  });

  const selectedBeneficiary: Beneficiary = useGlobalSelector(
    (state: GlobalState) =>
      state?.global?.galaxy?.context?.beneficiaryToBeUpdated
  );

  const selectedBeneficiaryId = selectedBeneficiary?.id;

  const fetchBeneficiary = (id: string) => {
    if (!id) return;
    const postBeneficiaryDetailsParams: PostBeneficiaryDetailsParams = {
      id,
    };

    const params: PostBeneficiaryDetailsParamsPayload = {
      params: postBeneficiaryDetailsParams,
      meta: {
        replaceEntities: ['beneficiaryDetails'],
      },
    };

    getBeneficiaryDetails(params, { headers: {} });
  };

  useEffect(() => {
    if (!selectedBeneficiary) {
      (async () => {
        await handleRedirect();
      })();
    } else {
      fetchBeneficiary(selectedBeneficiary.id);
    }
  }, [selectedBeneficiary?.id]);

  const postAliasLookupUplift = (params: PostAliaLookupParamsPayload) => {
    postAliasLookup(params, {
      headers: window.encode_deviceprint
        ? { 'x-deviceFingerprint': window.encode_deviceprint() }
        : {},
    });
  };

  const { updateBeneficiaryDetails } = useHandleUpdateBeneficiary({
    isUpdateBeneficiaryError,
    isUpdateBeneficiaryFetching,
    updateBeneficiaryErrors,
    allBeneficiaryUpdate,
    beneficiaryStatusUpdate,
    selectedBeneficiaryId,
    isBeneficiaryStatusUpdateError,
    isBeneficiaryStatusUpdateFetching,
    updateBeneficiaryParamsRef,
    setIsStepUpModalVisible,
    updateBeneficiaryDetailsWithExtraHeaders,
    clearBeneficiaryStatusUpdate,
    clearUpdateBeneficiary,
    beneficiaryStatusUpdateErrors,
  });

  const shouldShowCopResults =
    !isAccountNameCheckFetching &&
    (allAccountNameCheck?.length > 0 ||
      isAccountNameCheckError ||
      isCopServiceNotAvailable);

  // CoP Account Name Check Handler - calls API
  const postAccountNameCheck = ({
    accountName,
    accountNumber,
    bsb,
  }: {
    accountName: string;
    accountNumber: string;
    bsb: string;
  }) => {
    // Clear previous results
    clearAccountNameCheck();

    // Make the API call
    const params: PostAccountNameCheckParamsPayload = {
      params: {
        payee: {
          accountName,
          accountId: {
            accountNumber,
            BSB: bsb,
          },
        },
      },
      meta: {
        replaceEntities: ['accountNameCheck'],
      },
    };

    postAccountNameCheckAction(params);
  };

  return (
    <MVCard
      title="Update beneficiary"
      template="narrow"
      bottomDivider={!isBeneficiaryDetailsError}
    >
      {isBeneficiaryDetailsFetching ? (
        <PageLoader />
      ) : (
        <>
          {isBeneficiaryDetailsError ? (
            <ErrorHandler
              width="full"
              className="mb-2.5"
              onRefresh={() => {
                fetchBeneficiary(selectedBeneficiary?.id);
              }}
              errorMessage="Something went wrong."
            />
          ) : (
            <>
              <StaySafeFromScamsBanner />
              <NotificationAlert />
            </>
          )}
          {renderEntitlementsStepUp()}
          <BeneficiaryForm
            beneficiaryToBeUpdated={beneficiaryDetails[0]}
            isBeneficiaryDetailsError={isBeneficiaryDetailsError}
            postAliasLookup={postAliasLookupUplift}
            isAliasLookupFetching={isAliasLookupFetching}
            isAliasLookupError={isAliasLookupError}
            doesAliasIdContainInvalidData={doesAliasIdContainInvalidData}
            isPayIdNotValid={isPayIdNotValid}
            isPayIdLimitExceeded={isPayIdLimitExceeded}
            isPayIdServiceNotAvailable={isPayIdServiceNotAvailable}
            payIDDetails={allAliasLookup}
            apiStatus={bsbLookupApiStatus}
            isBsbLookupError={isBsbLookupError}
            isBsbLookupFetching={isBsbLookupFetching}
            getBsbLookup={getBsbLookup}
            branches={allBranches}
            onUpdateBeneficiary={updateBeneficiaryDetails}
            isBeneficiaryUpdateFetching={isUpdateBeneficiaryFetching}
            isBeneficiaryUpdateError={isUpdateBeneficiaryError}
            clearAliasLookup={clearAliasLookup}
            clearBsbLookup={clearBsbLookup}
            isBeneficiaryStatusUpdateFetching={
              isBeneficiaryStatusUpdateFetching
            }
            // Account Name Check (CoP) props
            postAccountNameCheck={postAccountNameCheck}
            copCheckResultData={allAccountNameCheck?.[0]}
            isCopLoading={isAccountNameCheckFetching}
            isCopError={isAccountNameCheckError || isCopServiceNotAvailable}
            shouldShowCopResults={shouldShowCopResults}
            isCopLimitExceeded={isCopLimitExceeded}
            onInvalidateCopCheck={clearAccountNameCheck}
          />
        </>
      )}
    </MVCard>
  );
}

export const mapStateToProps = (state: RootState) => ({
  allBranches: getAllBsbLookup(state),
  isBsbLookupFetching: isBsbLookupFetchingSelector(state),
  isBsbLookupError: isBsbLookupErrorSelector(state),
  bsbLookupApiStatus: getBsbLookupStatusCode(state),
  allAliasLookup: getAllAliasLookup(state),
  isAliasLookupFetching: isAliasLookupFetchingSelector(state),
  isAliasLookupError: isAliasLookupErrorSelector(state),
  isPayIdNotValid: isPayIdNotValidSelector(state),
  isPayIdLimitExceeded: isPayIdLimitExceededSelector(state),
  doesAliasIdContainInvalidData: doesAliasIdContainInvalidDataSelector(state),
  isPayIdServiceNotAvailable: isPayIdServiceNotAvailableSelector(state),
  isUpdateBeneficiaryFetching: isBeneficiaryUpdateFetching(state),
  isUpdateBeneficiaryError: isBeneficiaryUpdateError(state),
  allBeneficiaryUpdate: getAllBeneficiaryUpdateSelector(state),
  updateBeneficiaryErrors: getBeneficiaryUpdateErrors(state),
  beneficiaryDetails: getAllBeneficiaryDetails(state),
  isBeneficiaryDetailsFetching: isBeneficiaryDetailsFetchingSelector(state),
  isBeneficiaryDetailsError: isBeneficiaryDetailsErrorSelector(state),
  isBeneficiaryStatusUpdateFetching:
    isBeneficiaryStatusUpdateFetchingSelector(state),
  isBeneficiaryStatusUpdateError: isBeneficiaryStatusUpdateErrorSelector(state),
  beneficiaryStatusUpdateErrors: getBeneficiaryStatusUpdateErrors(state),
  // Account Name Check (CoP) selectors
  allAccountNameCheck: getAllAccountNameCheck(state),
  isAccountNameCheckFetching: isAccountNameCheckFetchingSelector(state),
  isAccountNameCheckError: isAccountNameCheckErrorSelector(state),
  isCopLimitExceeded: isCopLimitExceededSelector(state),
  isCopServiceNotAvailable: isCopServiceNotAvailableSelector(state),
});

const mapDispatchToProps = {
  getBeneficiaryDetails:
    beneficiaryDetailsActions.api.expGalaxyBeneficiaryV2.beneficiaryDetails.post
      .request,
  getBsbLookup:
    bsbLookupActions.api.expGalaxyBeneficiaryV2.bsbLookup.get.request,
  clearBsbLookup:
    bsbLookupEntityActions.api.expGalaxyBeneficiaryV2.bsbLookup.clear.request,
  postAliasLookup:
    aliasLookupActions.api.expGalaxyBeneficiaryV2.aliasLookup.post.request,
  updateBeneficiary:
    beneficiaryUpdateActions.api.expGalaxyBeneficiaryV2.beneficiaryUpdate.put
      .request,
  clearAliasLookup:
    aliasLookupEntityActions.api.expGalaxyBeneficiaryV2.aliasLookup.clear
      .request,
  beneficiaryStatusUpdate:
    beneficiaryStatusUpdateActions.api.expGalaxyBeneficiaryV2
      .beneficiaryStatusUpdate.post.request,
  clearBeneficiaryStatusUpdate:
    beneficiaryStatusUpdateEntityActions.api.expGalaxyBeneficiaryV2
      .beneficiaryStatusUpdate.clear.request,
  clearUpdateBeneficiary:
    beneficiaryUpdateEntityActions.api.expGalaxyBeneficiaryV2.beneficiaryUpdate
      .clear.request,
  // Account Name Check (CoP) actions
  postAccountNameCheckAction:
    accountNameCheckActions.api.expGalaxyBeneficiaryV2.accountNameCheck.post
      .request,
  clearAccountNameCheck:
    accountNameCheckEntityActions.api.expGalaxyBeneficiaryV2.accountNameCheck
      .clear.request,
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps, null, {
    context: store.contextRef,
  })
)(UpdateBeneficiaryContainer);
