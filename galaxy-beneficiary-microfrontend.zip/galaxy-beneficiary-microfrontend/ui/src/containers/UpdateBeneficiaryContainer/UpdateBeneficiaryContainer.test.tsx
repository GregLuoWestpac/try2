import '@testing-library/jest-dom';
import { fireEvent, render, screen } from '@testing-library/react';
import React from 'react';
import { useEntitlementsSafi } from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import { isPayIdLimitExceededSelector } from 'ui/src/store/selectors/aliasLookup';
import * as selectors from '../../store/generated';
import {
  Beneficiary,
  BENEFICIARY_STATUS,
  BENEFICIARY_TYPE,
} from '../../store/types';
import { RootState } from '../../store/types/RootStates';
import {
  mapStateToProps,
  UpdateBeneficiaryContainer,
} from './UpdateBeneficiaryContainer';

const dummyBeneficiary = {
  id: '018549b2-9195-4d64-b62f-f241364f737e',
  nickname: 'Jane Doe',
};

const bsbMockBeneficiary: Beneficiary = {
  id: 'd0868661-b955-4e76-9f15-d97626f7df6b',
  externalId: 'd0868661-b955-4e76-9f15-d97626f7df6b',
  nickname: 'Bayer, Miller and MacGyver',
  currency: 'AUD',
  org: 'office',
  type: BENEFICIARY_TYPE.ACCOUNT,
  status: BENEFICIARY_STATUS.ACTIVE,
  account: {
    bsb: '014111',
    bankName: 'Westpac',
    accountName: 'Westpac Joint',
    accountNumber: '084765',
  },
};
const mockGetBeneficiaryDetails = jest.fn();
const mockUpdateBeneficiary = jest.fn();
const mockUseGlobalSelector = jest.fn();
const mockRevertStatusAndRedirect = jest.fn();

// Mock mv-reacthookform to prevent webpack chunk loading issues
jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  DATE_FORMAT_YYYYMMDD: 'YYYY-MM-DD',
  getToday: jest.fn(() => ({
    toFormat: jest.fn(() => '2024-01-01'),
  })),
  getTodayAtLastYear: jest.fn(() => ({
    toFormat: jest.fn(() => '2023-01-01'),
  })),
}));

// Mock useRevertBeneficiaryStatus hook to prevent status revert logic from interfering with container tests
jest.mock('../../hooks/useRevertBeneficiaryStatus', () => ({
  useRevertBeneficiaryStatus: () => ({
    revertStatusAndRedirect: mockRevertStatusAndRedirect,
  }),
}));

jest
  .spyOn(selectors, 'getAllBsbLookup')
  .mockReturnValue([{ id: 1, name: 'Branch 1' }]);
jest.spyOn(selectors, 'isBsbLookupFetching').mockReturnValue(true);
jest.spyOn(selectors, 'isBsbLookupError').mockReturnValue(false);
jest.mock('../../store/selectors/bsbLookup', () => ({
  getBsbLookupStatusCode: jest.fn().mockReturnValue(200),
}));
jest
  .spyOn(selectors, 'getAllAliasLookup')
  .mockReturnValue([{ aliasType: 'email', aliasId: 'test@example.com' }]);
jest.spyOn(selectors, 'isAliasLookupFetching').mockReturnValue(false);
jest.spyOn(selectors, 'isAliasLookupError').mockReturnValue(true);
jest.spyOn(selectors, 'getAllBeneficiaryUpdate').mockReturnValue([]);
jest.spyOn(selectors, 'isBeneficiaryStatusUpdateError').mockReturnValue(null);
jest
  .spyOn(selectors, 'isBeneficiaryStatusUpdateFetching')
  .mockReturnValue(null);
jest.mock('../../store/selectors/aliasLookup', () => ({
  isPayIdNotValidSelector: jest.fn().mockReturnValue(false),
  isPayIdLimitExceededSelector: jest.fn().mockReturnValue(false),
  doesAliasIdContainInvalidDataSelector: jest.fn().mockReturnValue(false),
  isPayIdServiceNotAvailableSelector: jest.fn().mockReturnValue(false),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  getURLParams: jest.fn().mockReturnValue(''),
  MVCard: function MockComponent({
    children,
    title,
  }: {
    children: React.ReactNode;
    title: string;
  }) {
    return (
      <div>
        <h1>{title}</h1>
        {children}
      </div>
    );
  },
  MVPageLoader: function MockMVPageLoader() {
    return <div data-testid="page-loader" />;
  },
}));

const mockNavigate = jest.fn();

jest.mock('@mep-ui/framework-router-addon', () => {
  const actual = jest.requireActual('@mep-ui/framework-router-addon');
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});

jest.mock('../../store/store', () => ({
  __esModule: true,
  default: {
    dispatch: jest.fn(),
  },
}));

jest.mock('../../components', () => ({
  ErrorHandler: ({
    onRefresh,
    errorMessage,
  }: {
    onRefresh?: () => void;
    errorMessage: string;
  }) => (
    <>
      <div>{errorMessage}</div>
      <button onClick={() => onRefresh?.()}>Try again</button>
    </>
  ),
  BeneficiaryForm: ({
    getBsbLookup,
    postAliasLookup,
    onUpdateBeneficiary,
  }: {
    postAliasLookup: (details: any) => void;
    getBsbLookup: (event: any) => void;
    onUpdateBeneficiary: any;
  }) => (
    <>
      <span>BeneficiaryForm</span>
      <input
        data-testid="beneficiary-form"
        onClick={() =>
          postAliasLookup &&
          postAliasLookup({
            params: {
              email: 'test@example.com',
              authBIC8: undefined, // or your AUTHBIC8 mock value
            },
            meta: {
              replaceEntities: ['aliasLookup'],
            },
          })
        }
        onBlur={event =>
          getBsbLookup &&
          getBsbLookup({
            bsb: event.target.value,
            meta: {
              replaceEntities: ['bsbLookup'],
            },
          })
        }
      />
      <button onClick={() => onUpdateBeneficiary({ params: dummyBeneficiary })}>
        Update beneficiary
      </button>
    </>
  ),
  StaySafeFromScamsBanner: () => <div>Stay safe from scams.</div>,
}));

const mockGlobalDispatch = jest.fn();

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalSelector: (selector: any) => mockUseGlobalSelector(selector),
  useGlobalDispatch: () => mockGlobalDispatch,
  connect: () => (Component: any) =>
    function (props: any) {
      return <Component {...props} />;
    },
}));

jest.mock(
  '@mesh-tenant-user-authorisation-policy-decision-engine/components',
  () => ({
    ...jest.requireActual(
      '@mesh-tenant-user-authorisation-policy-decision-engine/components'
    ),
    EntitlementsStepUp: ({ children }: { children: React.ReactNode }) => (
      <div data-testid="entitlements-stepup-mock">{children}</div>
    ),
    useEntitlementsSafi: jest.fn(),
  })
);

jest.mock('../../widgets/pingmfa/pingmfa-v1', () => ({
  PingmfaWidgetApp: () => <div data-testid="widget-app-mock">WidgetApp</div>,
}));

const mockHandleRedirectToBeneficiaryList = jest
  .fn()
  .mockResolvedValue(undefined);
const mockRedirectToBeneficiaryList = jest.fn();
jest.mock('../../common/BeneficiaryList.util', () => ({
  useRedirectToBeneficiaryList: () => mockRedirectToBeneficiaryList,
  useHandleRedirectToBeneficiaryList: () => mockHandleRedirectToBeneficiaryList,
}));

const defaultProps = {
  beneficiaryToBeUpdated: {},
  getBsbLookup: () => {},
  allBranches: [],
  isBsbLookupError: false,
  isBsbLookupFetching: false,
  allAliasLookup: [],
  isAliasLookupError: false,
  isAliasLookupFetching: false,
  isAliasLookupUnavailable: false,
  isPayIdNotValid: false,
  isPayIdLimitExceeded: false,
  doesAliasIdContainInvalidData: false,
  postAliasLookup: () => {},
  isUpdateBeneficiaryFetching: false,
  isBeneficiaryDetailsFetching: false,
  isBeneficiaryDetailsError: false,
  isUpdateBeneficiaryError: false,
  updateBeneficiary: () => {},
  getBeneficiaryDetails: mockGetBeneficiaryDetails,
  clearAliasLookup: () => {},
  updateBeneficiaryErrors: {},
  clearBsbLookup: () => {},
  beneficiaryDetails: [bsbMockBeneficiary],
  allBeneficiaryUpdate: [],
  clearBeneficiaryStatusUpdate: jest.fn(),
  isBeneficiaryStatusUpdateError: false,
  isBeneficiaryStatusUpdateFetching: false,
  beneficiaryStatusUpdate: jest.fn(),
  clearUpdateBeneficiary: jest.fn(),
  isPayIdServiceNotAvailable: false,
};

const populateHeaderMock = jest.fn();

describe('UpdateBeneficiaryContainer', () => {
  beforeEach(() => {
    mockUseGlobalSelector.mockImplementation(selector =>
      selector({
        global: {
          galaxy: {
            context: {
              beneficiaryToBeUpdated: dummyBeneficiary,
            },
          },
        },
      })
    );
    (useEntitlementsSafi as jest.Mock).mockReturnValue({
      populateHeader: populateHeaderMock,
    });
  });

  it('should match snapshot', () => {
    const { container } = render(
      <UpdateBeneficiaryContainer
        {...defaultProps}
        updateBeneficiary={mockUpdateBeneficiary}
        isUpdateBeneficiaryFetching={false}
        isUpdateBeneficiaryError={false}
      />
    );
    expect(screen.getAllByText('Update beneficiary')[0]).toBeInTheDocument();
    expect(screen.getByText('Stay safe from scams.')).toBeInTheDocument();
    expect(screen.getAllByText('Update beneficiary')[1]).toBeInTheDocument();
    expect(container).toMatchSnapshot();
  });

  it('should call updateBeneficiary with correct params on form submit', async () => {
    const mockBeneficiaryStatusUpdate = jest.fn();
    render(
      <UpdateBeneficiaryContainer
        {...defaultProps}
        updateBeneficiary={mockUpdateBeneficiary}
        beneficiaryStatusUpdate={mockBeneficiaryStatusUpdate}
        isUpdateBeneficiaryFetching={false}
        isUpdateBeneficiaryError={false}
      />
    );
    const updateButton = screen.getAllByText('Update beneficiary');
    fireEvent.click(updateButton[1]);

    // With the new implementation, beneficiaryStatusUpdate is called first
    expect(mockBeneficiaryStatusUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        params: expect.objectContaining({
          beneficiary: expect.objectContaining({
            id: dummyBeneficiary.id,
            status: 'ON-HOLD',
          }),
        }),
      })
    );
  });

  it('should select beneficiary from the global state correctly', () => {
    render(
      <UpdateBeneficiaryContainer
        {...defaultProps}
        updateBeneficiary={mockUpdateBeneficiary}
        isUpdateBeneficiaryFetching={false}
        isUpdateBeneficiaryError={false}
      />
    );
    expect(mockUseGlobalSelector).toHaveBeenCalled();
    expect(typeof mockUseGlobalSelector.mock.calls[0][0]).toBe('function');
  });

  it('should handle missing beneficiaryToBeUpdated gracefully', () => {
    mockUseGlobalSelector.mockImplementation(selector =>
      selector({
        global: {
          galaxy: {
            context: {
              beneficiaryToBeUpdated: undefined,
            },
          },
        },
      })
    );

    render(
      <UpdateBeneficiaryContainer
        {...defaultProps}
        updateBeneficiary={mockUpdateBeneficiary}
        isUpdateBeneficiaryFetching={false}
        isUpdateBeneficiaryError={false}
      />
    );

    expect(screen.getByTestId('beneficiary-form')).toBeInTheDocument();
    expect(screen.getAllByText('Update beneficiary')[0]).toBeInTheDocument();
    expect(screen.getByText('Stay safe from scams.')).toBeInTheDocument();
  });

  it('fetch beneficiary details when the component mounts', async () => {
    mockUseGlobalSelector.mockImplementation(selector =>
      selector({
        global: {
          galaxy: {
            context: {
              beneficiaryToBeUpdated: dummyBeneficiary,
            },
          },
        },
      })
    );
    render(<UpdateBeneficiaryContainer {...defaultProps} />);
    expect(mockGetBeneficiaryDetails).toHaveBeenCalledWith(
      expect.objectContaining({
        params: {
          id: dummyBeneficiary.id,
        },
      }),
      {
        headers: {},
      }
    );
  });

  it('loader is displayed during fetching', () => {
    render(
      <UpdateBeneficiaryContainer
        {...defaultProps}
        isBeneficiaryDetailsFetching
      />
    );
    const pageLoader = screen.getByTestId('page-loader');
    expect(pageLoader).toBeInTheDocument();
  });

  it('displays the try again error message when there is a beneficiary details fetch error', () => {
    render(
      <UpdateBeneficiaryContainer {...defaultProps} isBeneficiaryDetailsError />
    );
    const error = screen.getByText('Something went wrong.');
    expect(error).toBeInTheDocument();
  });
  it('allows to refresh beneficiary details where there is an error returned from the api', () => {
    const getBeneficiaryDetails = jest.fn();
    render(
      <UpdateBeneficiaryContainer
        {...defaultProps}
        isBeneficiaryDetailsError
        getBeneficiaryDetails={getBeneficiaryDetails}
      />
    );
    getBeneficiaryDetails.mockReset();
    const refreshBtn = screen.getByRole('button', { name: 'Try again' });
    fireEvent.click(refreshBtn);
    expect(getBeneficiaryDetails).toHaveBeenCalledTimes(1);
  });
});

describe('UpdateBeneficiaryContainer - handlePayIDLookup', () => {
  it('should call postAliasLookup with correct parameters when handlePayIDLookup is triggered', () => {
    const postAliasLookup = jest.fn();

    render(
      <UpdateBeneficiaryContainer
        {...defaultProps}
        getBsbLookup={jest.fn()}
        postAliasLookup={postAliasLookup}
      />
    );
    const beneficiaryForm = screen.getByTestId('beneficiary-form');
    expect(beneficiaryForm).toBeInTheDocument();
    beneficiaryForm.click();
    expect(postAliasLookup).toHaveBeenCalled();
  });
});

describe('UpdateBeneficiaryContainer - handleBSBLookup', () => {
  it('should call getBsbLookup with correct parameters when handleBSBLookup is triggered', () => {
    const getBsbLookup = jest.fn();

    render(
      <UpdateBeneficiaryContainer
        {...defaultProps}
        getBsbLookup={getBsbLookup}
        postAliasLookup={jest.fn()}
      />
    );

    const beneficiaryForm = screen.getByTestId('beneficiary-form');
    expect(beneficiaryForm).toBeInTheDocument();

    // Simulate the blur event
    fireEvent.blur(beneficiaryForm, { target: { value: '123456' } });

    expect(getBsbLookup).toHaveBeenCalledWith({
      bsb: '123456',
      meta: {
        replaceEntities: ['bsbLookup'],
      },
    });
  });
});

describe('UpdateBeneficiaryContainer - mapStateToProps', () => {
  it('should map state to props correctly', () => {
    const mockState: RootState = {} as unknown as RootState; // Mock state can be empty since selectors are mocked.

    const expectedProps = {
      allBranches: [{ id: 1, name: 'Branch 1' }],
      isBsbLookupFetching: true,
      isBsbLookupError: false,
      bsbLookupApiStatus: 200,
      allAliasLookup: [{ aliasType: 'email', aliasId: 'test@example.com' }],
      isAliasLookupFetching: false,
      isAliasLookupError: true,
      isPayIdNotValid: false,
      isPayIdLimitExceeded: false,
      doesAliasIdContainInvalidData: false,
      isUpdateBeneficiaryError: null,
      isUpdateBeneficiaryFetching: null,
      beneficiaryDetails: [],
      isPayIdServiceNotAvailable: false,
      isBeneficiaryDetailsFetching: null,
      isBeneficiaryDetailsError: null,
      updateBeneficiaryErrors: undefined,
      allBeneficiaryUpdate: [],
      isBeneficiaryStatusUpdateError: null,
      isBeneficiaryStatusUpdateFetching: null,
      beneficiaryStatusUpdateErrors: undefined,
      allAccountNameCheck: [],
      isAccountNameCheckFetching: null,
      isAccountNameCheckError: null,
      isCopLimitExceeded: false,
      isCopServiceNotAvailable: undefined,
    };

    const props = mapStateToProps(mockState);
    expect(props).toEqual(expectedProps);
  });
});

describe('UpdateBeneficiaryContainer - redirectIntentToBeneficiaryList', () => {
  it('should call globalDispatch when updateBeneficiaryErrors is empty and isBeneficiaryUpdateError is true', async () => {
    render(
      <UpdateBeneficiaryContainer
        {...defaultProps}
        isUpdateBeneficiaryError
        updateBeneficiaryErrors={{}}
      />
    );
    expect(mockGlobalDispatch).toHaveBeenCalledWith({
      type: 'galaxy/context/update',
      data: {
        notificationAlert: {
          type: 'danger',
          message: 'Something went wrong.',
        },
      },
    });
  });

  it('should call globalDispatch when updateBeneficiaryErrors returns 400 and isBeneficiaryUpdateError is true', async () => {
    const mockUpdateBeneficiaryErrors = {
      status: 400,
    };
    render(
      <UpdateBeneficiaryContainer
        {...defaultProps}
        isUpdateBeneficiaryError
        updateBeneficiaryErrors={mockUpdateBeneficiaryErrors}
      />
    );
    expect(mockGlobalDispatch).toHaveBeenCalledWith({
      type: 'galaxy/context/update',
      data: {
        notificationAlert: {
          type: 'danger',
          message: 'Something went wrong.',
        },
      },
    });
  });
});

describe('UpdateBeneficiaryContainer - handleRedirectToBeneficiaryList', () => {
  it('should call handleRedirectToBeneficiaryList with correct parameters when updateBeneficiaryErrors exist', () => {
    const mockUpdateBeneficiaryErrors = {
      status: 403,
      data: {
        errors: [
          {
            code: 8210,
            message: '',
          },
        ],
      },
    };

    render(
      <UpdateBeneficiaryContainer
        {...defaultProps}
        isUpdateBeneficiaryError
        updateBeneficiaryErrors={mockUpdateBeneficiaryErrors}
      />
    );

    // Error code 8210 (entitlement) triggers revertStatusAndRedirect, not direct redirect
    expect(mockRevertStatusAndRedirect).toHaveBeenCalledWith({
      errorMessage:
        'You do not have permission to add or update beneficiaries. Contact your administrator for more information.',
    });
  });

  it('should call handleRedirectToBeneficiaryList with correct parameters when updateBeneficiaryErrors exist with maker/checker applied', () => {
    const mockUpdateBeneficiaryErrors = {
      status: 401,
      data: {
        errors: [
          {
            code: 8125,
            message: '',
          },
        ],
      },
    };

    render(
      <UpdateBeneficiaryContainer
        {...defaultProps}
        isUpdateBeneficiaryError
        updateBeneficiaryErrors={mockUpdateBeneficiaryErrors}
      />
    );

    // Error code 8125 (maker-checker) now passes an object as the second parameter
    expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
      'success',
      {
        nickname: '',
        action: 'update',
        isMakerCheckerApplicable: true,
      }
    );
  });
});

describe('UpdateBeneficiaryContainer - undefined beneficiary', () => {
  beforeEach(() => {
    mockUseGlobalSelector.mockImplementation(selector =>
      selector({
        global: {
          galaxy: {
            context: {
              beneficiaryToBeUpdated: null,
            },
          },
        },
      })
    );
  });

  it('navigate to beneficiary list', () => {
    const { container } = render(
      <UpdateBeneficiaryContainer
        {...defaultProps}
        updateBeneficiary={mockUpdateBeneficiary}
        isUpdateBeneficiaryFetching={false}
        isUpdateBeneficiaryError={false}
      />
    );
    expect(mockRedirectToBeneficiaryList).toHaveBeenCalled();
  });
});

describe('UpdateBeneficiaryContainer - MFA modal error (8200)', () => {
  it('should dispatch to hide notification alert when MFA modal is open', () => {
    render(
      <UpdateBeneficiaryContainer
        {...defaultProps}
        isUpdateBeneficiaryError
        updateBeneficiaryErrors={{
          status: 401,
          data: {
            errors: [
              {
                code: 8200,
                message: '',
              },
            ],
          },
        }}
      />
    );

    expect(mockGlobalDispatch).toHaveBeenCalledWith({
      type: 'galaxy/context/update',
      data: { notificationAlert: null },
    });
  });
});

describe('UpdateBeneficiary Container - MFA Modal', () => {
  it('should close the step-up modal when Escape key is pressed', () => {
    // Render the component
    render(
      <UpdateBeneficiaryContainer
        {...defaultProps}
        isUpdateBeneficiaryError
        updateBeneficiaryErrors={{
          status: 401,
          data: {
            errors: [
              {
                code: 8200,
                message: '',
              },
            ],
          },
        }}
      />
    );

    const updateButton = screen.getAllByText('Update beneficiary');
    fireEvent.click(updateButton[1]);
    // Check that EntitlementsStepUp and PingmfaWidgetApp are rendered
    expect(
      document.querySelector('[data-testid="entitlements-stepup-mock"]')
    ).toBeInTheDocument();
    expect(
      document.querySelector('[data-testid="widget-app-mock"]')
    ).toBeInTheDocument();

    // Simulate the Escape keydown event
    fireEvent.keyDown(document, { key: 'Escape', code: 'Escape' });

    expect(
      document.querySelector('[data-testid="entitlements-stepup-mock"]')
    ).not.toBeInTheDocument();
    expect(
      document.querySelector('[data-testid="widget-app-mock"]')
    ).not.toBeInTheDocument();
  });
});
