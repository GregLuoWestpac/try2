export { default as AddBeneficiaryContainer } from './AddBeneficiaryContainer';
