/* eslint-disable react/react-in-jsx-scope */
/* eslint-disable @typescript-eslint/no-unsafe-enum-comparison */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable react/require-default-props */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { compose, connect, useGlobalDispatch } from '@mep-ui/framework';
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import { useEffect, useRef, useState } from 'react';
import { useEntitlementsSafi } from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import { COPCheckResultData } from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
import { ERROR_CODES } from '../../common';
import { useOrganisationId } from '../../hooks/useOrganisationId';
import { useHandleRedirectToBeneficiaryList } from '../../common/BeneficiaryList.util';
import {
  BeneficiaryForm,
  StaySafeFromScamsBanner,
  ErrorHandler,
} from '../../components';
import NotificationAlert, {
  getErrorMessage,
} from '../../components/NotificationAlert/NotificationAlert';
import { useEntitlementsStepUp } from '../../hooks/useEntitlementsStepUp';
import {
  beneficiaryCreateActions,
  getAllAliasLookup,
  getAllBeneficiaryCreate,
  getAllBsbLookup,
  getAllAccountNameCheck,
  isAliasLookupError as isAliasLookupErrorSelector,
  isAliasLookupFetching as isAliasLookupFetchingSelector,
  isBeneficiaryCreateError as isBeneficiariesErrorSelector,
  isBeneficiaryCreateFetching as isBeneficiariesFetchingSelector,
  isBsbLookupError as isBsbLookupErrorSelector,
  isBsbLookupFetching as isBsbLookupFetchingSelector,
  isDivisionListFetching as isDivisionListFetchingSelector,
  isDivisionListError as isDivisionListErrorSelector,
  getAllDivisionList,
  isAccountNameCheckFetching as isAccountNameCheckFetchingSelector,
  isAccountNameCheckError as isAccountNameCheckErrorSelector,
  accountNameCheckActions,
  accountNameCheckEntityActions,
} from '../../store/generated';
import {
  aliasLookupActions,
  aliasLookupEntityActions,
  bsbLookupActions,
  bsbLookupEntityActions,
  divisionListActions,
  divisionListEntityActions,
} from '../../store/generated/actions';
import { getAddBeneficiaryErrors } from '../../store/selectors';
import {
  doesAliasIdContainInvalidDataSelector,
  isPayIdNotValidSelector,
  isPayIdLimitExceededSelector,
  isPayIdServiceNotAvailableSelector,
} from '../../store/selectors/aliasLookup';
import {
  isCopLimitExceededSelector,
  isCopServiceNotAvailableSelector,
} from '../../store/selectors/accountNameCheck';
import { getBsbLookupStatusCode } from '../../store/selectors/bsbLookup';
import store from '../../store/store';
import {
  BeneficiaryError,
  BeneficiaryOptionsPayload,
  GetBSBLookupParamsPayload,
  PostAccountNameCheckParamsPayload,
  PostAliaLookupParamsPayload,
  PostBeneficiaryParamsPayload,
  RequestOptionsPayload,
  GetDivisionListParamsPayload,
} from '../../store/types';
import { Division } from '../../store/types/DivisonList';
import { PayIDs } from '../../store/types/AliasLookup';
import { Branch } from '../../store/types/BsbLookup';
import { RootState } from '../../store/types/RootStates';
import { PingmfaWidgetApp } from '../../widgets/pingmfa/pingmfa-v1';

export type AddBeneficiaryContainerProps = {
  getBsbLookup: (params: GetBSBLookupParamsPayload) => void;
  allBranches: Branch[];
  isBsbLookupError: boolean;
  isBsbLookupFetching: boolean;
  bsbLookupApiStatus?: number;
  allAliasLookup: PayIDs[];
  isAliasLookupError: boolean;
  isAliasLookupFetching: boolean;
  doesAliasIdContainInvalidData: boolean;
  isPayIdNotValid: boolean;
  isPayIdLimitExceeded: boolean;
  isPayIdServiceNotAvailable: boolean;
  postAliasLookup: (
    params: PostAliaLookupParamsPayload,
    options: RequestOptionsPayload
  ) => void;
  addBeneficiary: (
    params: PostBeneficiaryParamsPayload,
    options: BeneficiaryOptionsPayload
  ) => void;
  isBeneficiaryCreateFetching: boolean;
  isBeneficiaryCreateError: boolean;
  addBeneficiaryErrors: BeneficiaryError | undefined;
  clearAliasLookup: () => void;
  clearBsbLookup: () => void;
  getDivisionList: (
    params: GetDivisionListParamsPayload,
    options?: RequestOptionsPayload
  ) => void;
  clearDivisionList: () => void;
  isDivisionListFetching?: boolean;
  isDivisionListError?: boolean;
  allDivisionList?: Division[];
  // Account Name Check (CoP) props
  postAccountNameCheckAction: (
    params: PostAccountNameCheckParamsPayload,
    options?: RequestOptionsPayload
  ) => void;
  clearAccountNameCheck: () => void;
  isAccountNameCheckFetching: boolean;
  isAccountNameCheckError: boolean;
  isCopLimitExceeded: boolean;
  isCopServiceNotAvailable: boolean;
  allAccountNameCheck: COPCheckResultData[];
};

export function AddBeneficiaryContainer({
  getBsbLookup,
  allBranches,
  isBsbLookupError,
  isBsbLookupFetching,
  bsbLookupApiStatus,
  isAliasLookupError,
  isAliasLookupFetching,
  doesAliasIdContainInvalidData,
  isPayIdNotValid,
  isPayIdLimitExceeded,
  isPayIdServiceNotAvailable,
  allAliasLookup,
  postAliasLookup,
  addBeneficiary,
  isBeneficiaryCreateFetching,
  isBeneficiaryCreateError,
  addBeneficiaryErrors,
  clearAliasLookup,
  clearBsbLookup,
  getDivisionList,
  clearDivisionList,
  isDivisionListError,
  isDivisionListFetching,
  allDivisionList,
  // Account Name Check (CoP) props
  postAccountNameCheckAction,
  clearAccountNameCheck,
  isAccountNameCheckFetching,
  isAccountNameCheckError,
  isCopLimitExceeded,
  isCopServiceNotAvailable,
  allAccountNameCheck,
}: AddBeneficiaryContainerProps) {
  const shouldShowCopResults =
    !isAccountNameCheckFetching &&
    (allAccountNameCheck?.length > 0 || isAccountNameCheckError);

  const orgId = useOrganisationId();

  const nicknameRef = useRef('');
  const addBeneficiaryParamsRef = useRef<
    PostBeneficiaryParamsPayload | undefined
  >(undefined);
  const [isStepUpModalVisible, setIsStepUpModalVisible] = useState(false);

  const { populateHeader } = useEntitlementsSafi();

  const addBeneficiaryWithExtraHeaders = (
    params: PostBeneficiaryParamsPayload,
    options: BeneficiaryOptionsPayload
  ) => {
    const extraHeaders = {
      ...(options || {}),
      headers: {
        ...(options?.headers || {}),
        ...(window.encode_deviceprint
          ? populateHeader({}, window.encode_deviceprint)
          : {}),
        ...(orgId && { 'protected-orgId': orgId }),
        'x-channelRequestId':
          addBeneficiaryParamsRef.current?.params?.beneficiaries[0]?.id,
      },
    };

    addBeneficiary(
      params,
      extraHeaders as unknown as BeneficiaryOptionsPayload
    );
  };

  const { renderEntitlementsStepUp } = useEntitlementsStepUp({
    pingMfaWidget: <PingmfaWidgetApp />,
    propType: 'mfa',
    apiStatus: addBeneficiaryErrors?.status,
    errors: addBeneficiaryErrors?.data?.errors,
    dispatchFn: addBeneficiaryWithExtraHeaders,
    dispatchFnParams: addBeneficiaryParamsRef.current?.params ?? {},
    isStepUpModalVisible,
    setIsStepUpModalVisible,
  });

  const initiateBeneficiary = (
    params: PostBeneficiaryParamsPayload,
    options: BeneficiaryOptionsPayload
  ) => {
    setIsStepUpModalVisible(true);
    nicknameRef.current = params?.params?.beneficiaries[0]?.nickname || '';
    addBeneficiaryParamsRef.current = params;
    addBeneficiaryWithExtraHeaders(params, options);
  };
  const handleRedirectToBeneficiaryList = useHandleRedirectToBeneficiaryList();
  const globalDispatch = useGlobalDispatch();

  const fetchDivisionList = (organisationId?: string) => {
    if (!orgId) return;
    // Clear previous error state before fetching
    clearDivisionList();
    const params: GetDivisionListParamsPayload = {
      meta: {
        replaceEntities: ['divisionList'],
      },
    };
    getDivisionList(params, {
      headers: {
        ...(organisationId && {
          'protected-orgId': organisationId,
        }),
      },
    });
  };

  // CoP Account Name Check Handler - calls API
  const postAccountNameCheck = ({
    accountName,
    accountNumber,
    bsb,
  }: {
    accountName: string;
    accountNumber: string;
    bsb: string;
  }) => {
    // Clear previous results
    clearAccountNameCheck();

    // Make the API call
    const params: PostAccountNameCheckParamsPayload = {
      params: {
        payee: {
          accountName,
          accountId: {
            accountNumber,
            BSB: bsb,
          },
        },
      },
      meta: {
        replaceEntities: ['accountNameCheck'],
      },
    };

    postAccountNameCheckAction(params);
  };

  useEffect(() => {
    if (
      isBeneficiaryCreateError &&
      !isBeneficiaryCreateFetching &&
      addBeneficiaryErrors
    ) {
      if (!addBeneficiaryErrors?.status) {
        const data = {
          notificationAlert: {
            type: 'danger',
            message: 'Something went wrong. Please try again.',
          },
        };
        globalDispatch({
          type: 'galaxy/context/update',
          ...(data && { data: { ...data } }),
        });
      } else if (
        addBeneficiaryErrors?.status === 401 &&
        addBeneficiaryErrors?.data?.errors?.[0]?.code === 8125
      ) {
        handleRedirectToBeneficiaryList('success', {
          nickname: nicknameRef.current,
          action: 'add',
          isMakerCheckerApplicable: true,
        });
      } else if (
        addBeneficiaryErrors?.status === 401 &&
        addBeneficiaryErrors?.data?.errors?.[0]?.code ===
          ERROR_CODES.STEP_UP_REQUIRED
      ) {
        //  Hide notification error when MFA modal is displayed.
        const data = {
          notificationAlert: null,
        };
        globalDispatch({
          type: 'galaxy/context/update',
          ...(data && { data: { ...data } }),
        });
      } else {
        handleRedirectToBeneficiaryList(
          'danger',
          getErrorMessage(addBeneficiaryErrors, 'add or update beneficiaries')
        );
      }
    }
  }, [isBeneficiaryCreateError]);

  // Only fetch division list when orgId is available
  useEffect(() => {
    fetchDivisionList(orgId);
  }, [orgId]);

  const postAliasLookupUplift = (params: PostAliaLookupParamsPayload) => {
    postAliasLookup(params, {
      headers: window.encode_deviceprint
        ? { 'x-deviceFingerprint': window.encode_deviceprint() }
        : {},
    });
  };

  const isOrgIdAndDivisionListFetching = !orgId || isDivisionListFetching;
  const shouldShowMainBeneficiaryForm =
    !isOrgIdAndDivisionListFetching && !isDivisionListError;

  return (
    <MVCard
      title="Add a beneficiary"
      template="narrow"
      bottomDivider={shouldShowMainBeneficiaryForm}
    >
      {isDivisionListError && (
        <ErrorHandler
          width="full"
          className="my-2.5"
          onRefresh={() => {
            fetchDivisionList(orgId);
          }}
          errorMessage="Something went wrong."
        />
      )}
      {shouldShowMainBeneficiaryForm && (
        <>
          <StaySafeFromScamsBanner />
          <NotificationAlert />
        </>
      )}
      {renderEntitlementsStepUp()}

      <BeneficiaryForm
        postAliasLookup={postAliasLookupUplift}
        isAliasLookupFetching={isAliasLookupFetching}
        isAliasLookupError={isAliasLookupError}
        doesAliasIdContainInvalidData={doesAliasIdContainInvalidData}
        isPayIdNotValid={isPayIdNotValid}
        isPayIdServiceNotAvailable={isPayIdServiceNotAvailable}
        payIDDetails={allAliasLookup}
        apiStatus={bsbLookupApiStatus}
        isPayIdLimitExceeded={isPayIdLimitExceeded}
        isBsbLookupError={isBsbLookupError}
        isBsbLookupFetching={isBsbLookupFetching}
        getBsbLookup={getBsbLookup}
        branches={allBranches}
        addBeneficiary={initiateBeneficiary}
        isBeneficiaryCreateFetching={isBeneficiaryCreateFetching}
        isBeneficiaryCreateError={isBeneficiaryCreateError}
        clearAliasLookup={clearAliasLookup}
        clearBsbLookup={clearBsbLookup}
        isBeneficiaryDetailsError={false}
        isDivisionListError={isDivisionListError}
        isDivisionListFetching={isOrgIdAndDivisionListFetching}
        allDivisionList={allDivisionList}
        postAccountNameCheck={postAccountNameCheck}
        copCheckResultData={allAccountNameCheck?.[0]}
        isCopLoading={isAccountNameCheckFetching}
        isCopError={isAccountNameCheckError || isCopServiceNotAvailable}
        shouldShowCopResults={shouldShowCopResults}
        onInvalidateCopCheck={clearAccountNameCheck}
        isCopLimitExceeded={isCopLimitExceeded}
      />
    </MVCard>
  );
}

export const mapStateToProps = (state: RootState) => ({
  allBranches: getAllBsbLookup(state),
  isBsbLookupFetching: isBsbLookupFetchingSelector(state),
  isBsbLookupError: isBsbLookupErrorSelector(state),
  bsbLookupApiStatus: getBsbLookupStatusCode(state),
  allAliasLookup: getAllAliasLookup(state),
  isAliasLookupFetching: isAliasLookupFetchingSelector(state),
  isAliasLookupError: isAliasLookupErrorSelector(state),
  doesAliasIdContainInvalidData: doesAliasIdContainInvalidDataSelector(state),
  isPayIdNotValid: isPayIdNotValidSelector(state),
  isPayIdServiceNotAvailable: isPayIdServiceNotAvailableSelector(state),
  isPayIdLimitExceeded: isPayIdLimitExceededSelector(state),
  beneficiaryCreate: getAllBeneficiaryCreate(state),
  isBeneficiaryCreateFetching: isBeneficiariesFetchingSelector(state),
  isBeneficiaryCreateError: isBeneficiariesErrorSelector(state),
  addBeneficiaryErrors: getAddBeneficiaryErrors(state),
  allDivisionList: getAllDivisionList(state),
  isDivisionListFetching: isDivisionListFetchingSelector(state),
  isDivisionListError: isDivisionListErrorSelector(state),
  // Account Name Check (CoP) selectors
  allAccountNameCheck: getAllAccountNameCheck(state),
  isAccountNameCheckFetching: isAccountNameCheckFetchingSelector(state),
  isAccountNameCheckError: isAccountNameCheckErrorSelector(state),
  isCopLimitExceeded: isCopLimitExceededSelector(state),
  isCopServiceNotAvailable: isCopServiceNotAvailableSelector(state),
});

const mapDispatchToProps = {
  getBsbLookup:
    bsbLookupActions.api.expGalaxyBeneficiaryV2.bsbLookup.get.request,
  clearBsbLookup:
    bsbLookupEntityActions.api.expGalaxyBeneficiaryV2.bsbLookup.clear.request,
  postAliasLookup:
    aliasLookupActions.api.expGalaxyBeneficiaryV2.aliasLookup.post.request,
  addBeneficiary:
    beneficiaryCreateActions.api.expGalaxyBeneficiaryV2.beneficiaryCreate.post
      .request,
  clearAliasLookup:
    aliasLookupEntityActions.api.expGalaxyBeneficiaryV2.aliasLookup.clear
      .request,
  getDivisionList:
    divisionListActions.api.expGalaxyBeneficiaryV2.divisionList.get.request,
  // Account Name Check (CoP) actions
  postAccountNameCheckAction:
    accountNameCheckActions.api.expGalaxyBeneficiaryV2.accountNameCheck.post
      .request,
  clearAccountNameCheck:
    accountNameCheckEntityActions.api.expGalaxyBeneficiaryV2.accountNameCheck
      .clear.request,
  clearDivisionList:
    divisionListEntityActions.api.expGalaxyBeneficiaryV2.divisionList.clear
      .request,
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps, null, {
    context: store.contextRef,
  })
)(AddBeneficiaryContainer);
