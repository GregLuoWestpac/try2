/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import '@testing-library/jest-dom';
import { fireEvent, render, screen } from '@testing-library/react';
import { useEntitlementsSafi } from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import React from 'react';
import * as selectors from '../../store/generated';
import { RootState } from '../../store/types/RootStates';
import {
  AddBeneficiaryContainer,
  mapStateToProps,
} from './AddBeneficiaryContainer';

jest
  .spyOn(selectors, 'getAllBsbLookup')
  .mockReturnValue([{ id: 1, name: 'Branch 1' }]);
jest.spyOn(selectors, 'isBsbLookupFetching').mockReturnValue(true);
jest.spyOn(selectors, 'isBsbLookupError').mockReturnValue(false);
jest.mock('../../store/selectors/bsbLookup', () => ({
  getBsbLookupStatusCode: jest.fn().mockReturnValue(200),
}));
jest
  .spyOn(selectors, 'getAllAliasLookup')
  .mockReturnValue([{ aliasType: 'email', aliasId: 'test@example.com' }]);
jest.spyOn(selectors, 'isAliasLookupFetching').mockReturnValue(false);
jest.spyOn(selectors, 'isAliasLookupError').mockReturnValue(true);
jest.mock('../../store/selectors/aliasLookup', () => ({
  isPayIdNotValidSelector: jest.fn().mockReturnValue(false),
  isPayIdLimitExceededSelector: jest.fn().mockReturnValue(false),
  doesAliasIdContainInvalidDataSelector: jest.fn().mockReturnValue(false),
  isPayIdServiceNotAvailableSelector: jest.fn().mockReturnValue(false),
}));
jest.mock('../../store/selectors/accountNameCheck', () => ({
  isCopLimitExceededSelector: jest.fn().mockReturnValue(false),
  isCopServiceNotAvailableSelector: jest.fn().mockReturnValue(false),
}));
jest.spyOn(selectors, 'getAllAccountNameCheck').mockReturnValue([]);
jest.spyOn(selectors, 'isAccountNameCheckFetching').mockReturnValue(false);
jest.spyOn(selectors, 'isAccountNameCheckError').mockReturnValue(false);

jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: function MockComponent({
    children,
    title,
  }: {
    children: React.ReactNode;
    title: string;
  }) {
    return (
      <div>
        <h1>{title}</h1>
        {children}
      </div>
    );
  },
}));

const mockHandleRedirectToBeneficiaryList = jest.fn();
jest.mock('../../common/BeneficiaryList.util', () => ({
  useHandleRedirectToBeneficiaryList: () => mockHandleRedirectToBeneficiaryList,
}));

jest.mock('../../store/store', () => ({
  __esModule: true,
  default: {
    dispatch: jest.fn(),
  },
}));

jest.mock('../../components', () => ({
  BeneficiaryForm: ({
    getBsbLookup,
    postAliasLookup,
    addBeneficiary,
    postAccountNameCheck,
    onInvalidateCopCheck,
  }: {
    postAliasLookup: (details: unknown, options: unknown) => void;
    getBsbLookup: (event: unknown) => void;
    addBeneficiary: (details: unknown, options: unknown) => void;
    postAccountNameCheck?: (details: unknown) => void;
    onInvalidateCopCheck?: () => void;
  }) => (
    <>
      <span>BeneficiaryForm</span>
      <input
        data-testid="beneficiary-form"
        onClick={() =>
          postAliasLookup &&
          postAliasLookup(
            {
              params: {
                email: 'test@example.com',
                authBIC8: undefined, // or your AUTHBIC8 mock value
              },
              meta: {
                replaceEntities: ['aliasLookup'],
              },
            },
            {
              headers: { 'Content-Type': 'application/json' },
            }
          )
        }
        onBlur={event =>
          getBsbLookup &&
          getBsbLookup({
            bsb: event.target.value,
            meta: {
              replaceEntities: ['bsbLookup'],
            },
          })
        }
      />
      <button
        type="button"
        data-testid="add-or-update-beneficiary-button"
        onClick={() => addBeneficiary({}, {})}
      >
        Add Beneficiary
      </button>
      <button
        type="button"
        data-testid="check-details-button"
        onClick={() =>
          postAccountNameCheck &&
          postAccountNameCheck({
            accountName: 'Test Account',
            accountNumber: '12345678',
            bsb: '123456',
          })
        }
      >
        Check Details
      </button>
      <button
        type="button"
        data-testid="invalidate-cop-button"
        onClick={() => onInvalidateCopCheck && onInvalidateCopCheck()}
      >
        Invalidate CoP
      </button>
    </>
  ),
  StaySafeFromScamsBanner: () => <div>Stay safe from scams.</div>,
  ErrorHandler: ({
    errorMessage,
    onRefresh,
  }: {
    errorMessage: string;
    onRefresh: () => void;
  }) => (
    <div data-testid="error-handler">
      <span>{errorMessage}</span>
      <button type="button" data-testid="refresh-button" onClick={onRefresh}>
        Refresh
      </button>
    </div>
  ),
}));

const mockGlobalDispatch = jest.fn();
const mockGlobalSelector = jest.fn();

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  ssoActions: {
    sso: {
      signout: {
        request: jest.fn(),
      },
    },
  },
  useGlobalDispatch: () => mockGlobalDispatch,
  useGlobalSelector: () => mockGlobalSelector,
}));
jest.mock(
  '@mesh-tenant-user-authorisation-policy-decision-engine/components',
  () => ({
    EntitlementsStepUp: ({ children }: { children: React.ReactNode }) => (
      <div data-testid="entitlements-stepup-mock">{children}</div>
    ),
    useEntitlementsSafi: jest.fn(),
  })
);

jest.mock('../../widgets/pingmfa/pingmfa-v1', () => ({
  PingmfaWidgetApp: () => <div data-testid="widget-app-mock">WidgetApp</div>,
}));

jest.mock('../../hooks/useOrganisationId', () => ({
  useOrganisationId: () => '12345678910',
}));

// Default props to reduce repetition in tests
const defaultTestProps = {
  getBsbLookup: jest.fn(),
  allBranches: [],
  isBsbLookupError: false,
  isBsbLookupFetching: false,
  allAliasLookup: [],
  isAliasLookupError: false,
  isAliasLookupFetching: false,
  isPayIdServiceNotAvailable: false,
  isPayIdNotValid: false,
  isPayIdLimitExceeded: false,
  doesAliasIdContainInvalidData: false,
  postAliasLookup: jest.fn(),
  addBeneficiary: jest.fn(),
  isBeneficiaryCreateFetching: false,
  isBeneficiaryCreateError: false,
  addBeneficiaryErrors: {},
  clearAliasLookup: jest.fn(),
  clearBsbLookup: jest.fn(),
  getDivisionList: jest.fn(),
  clearDivisionList: jest.fn(),
  isDivisionListFetching: false,
  isDivisionListError: false,
  allDivisionList: [],
  // Account Name Check (CoP) props
  postAccountNameCheckAction: jest.fn(),
  clearAccountNameCheck: jest.fn(),
  isAccountNameCheckFetching: false,
  isAccountNameCheckError: false,
  isCopLimitExceeded: false,
  isCopServiceNotAvailable: false,
  allAccountNameCheck: [],
};

describe('AddBeneficiaryContainer', () => {
  it('should match snapshot', () => {
    const mockGetBsbLookup = (): void => {
      throw new Error('Function not implemented.');
    };
    const { container } = render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        getBsbLookup={mockGetBsbLookup}
      />
    );
    expect(screen.getByText('Add a beneficiary')).toBeInTheDocument();
    expect(screen.getByText('Stay safe from scams.')).toBeInTheDocument();
    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
    expect(container).toMatchSnapshot();
  });
});
describe('AddBeneficiaryContainer - handlePayIDLookup', () => {
  const populateHeaderMock = jest.fn();
  (useEntitlementsSafi as jest.Mock).mockReturnValue({
    populateHeader: populateHeaderMock,
  });
  it('should call postAliasLookup with correct parameters when handlePayIDLookup is triggered', () => {
    const postAliasLookup = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        postAliasLookup={postAliasLookup}
      />
    );
    const beneficiaryForm = screen.getByTestId('beneficiary-form');
    expect(beneficiaryForm).toBeInTheDocument();
    beneficiaryForm.click();
    expect(postAliasLookup).toHaveBeenCalled();
  });
});
describe('AddBeneficiaryContainer - handleBSBLookup', () => {
  const populateHeaderMock = jest.fn();
  (useEntitlementsSafi as jest.Mock).mockReturnValue({
    populateHeader: populateHeaderMock,
  });
  it('should call getBsbLookup with correct parameters when handleBSBLookup is triggered', () => {
    const getBsbLookup = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        getBsbLookup={getBsbLookup}
      />
    );

    const beneficiaryForm = screen.getByTestId('beneficiary-form');
    expect(beneficiaryForm).toBeInTheDocument();

    // Simulate the blur event
    fireEvent.blur(beneficiaryForm, { target: { value: '123456' } });

    expect(getBsbLookup).toHaveBeenCalledWith({
      bsb: '123456',
      meta: {
        replaceEntities: ['bsbLookup'],
      },
    });
  });
});

describe('AddBeneficiaryContainer - mapStateToProps', () => {
  it('should map state to props correctly', () => {
    const mockState: RootState = {} as unknown as RootState; // Mock state can be empty since selectors are mocked.

    const expectedProps = {
      allBranches: [{ id: 1, name: 'Branch 1' }],
      isBsbLookupFetching: true,
      isBsbLookupError: false,
      bsbLookupApiStatus: 200,
      allAliasLookup: [{ aliasType: 'email', aliasId: 'test@example.com' }],
      isAliasLookupFetching: false,
      isAliasLookupError: true,
      isPayIdNotValid: false,
      isPayIdLimitExceeded: false,
      doesAliasIdContainInvalidData: false,
      isPayIdServiceNotAvailable: false,
      isBeneficiaryCreateFetching: null,
      isBeneficiaryCreateError: null,
      isDivisionListError: null,
      isDivisionListFetching: null,
      allDivisionList: [],
      beneficiaryCreate: [],
      // Account Name Check (CoP) selectors
      allAccountNameCheck: [],
      isAccountNameCheckFetching: false,
      isAccountNameCheckError: false,
      isCopLimitExceeded: false,
      isCopServiceNotAvailable: false,
    };

    const props = mapStateToProps(mockState);
    expect(props).toEqual(expectedProps);
  });
});

describe('AddBeneficiaryContainer - handleRedirectToBeneficiaryList', () => {
  it('should redirect with getErrorMessage result for status 403 with error code 8210', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isBeneficiaryCreateError
        addBeneficiaryErrors={{
          status: 403,
          data: {
            errors: [
              {
                code: 8210,
                message: '',
              },
            ],
          },
        }}
      />
    );

    expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
      'danger',
      'You do not have permission to add or update beneficiaries. Contact your administrator for more information.'
    );
  });

  it('should call handleRedirectToBeneficiaryList with correct parameters when invoked when maker/checker is applied', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isBeneficiaryCreateError
        addBeneficiaryErrors={{
          status: 401,
          data: {
            errors: [
              {
                code: 8125,
                message: '',
              },
            ],
          },
        }}
      />
    );

    expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
      'success',
      {
        nickname: '', // gets from local state
        action: 'add',
        isMakerCheckerApplicable: true,
      }
    );
  });
});

describe('AddBeneficiaryContainer - MFA modal error (8200)', () => {
  it('should dispatch to hide notification alert when MFA modal is open', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isBeneficiaryCreateError
        addBeneficiaryErrors={{
          status: 401,
          data: {
            errors: [
              {
                code: 8200,
                message: '',
              },
            ],
          },
        }}
      />
    );

    expect(mockGlobalDispatch).toHaveBeenCalledWith({
      type: 'galaxy/context/update',
      data: { notificationAlert: null },
    });
  });
});

describe('AddBeneficiaryContainer - Error handling for various status codes', () => {
  it('should redirect with getErrorMessage result when addBeneficiaryErrors has status 400', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isBeneficiaryCreateError
        addBeneficiaryErrors={{
          status: 400,
          data: {
            errors: [
              {
                code: 1001,
                message: 'Bad request error',
              },
            ],
          },
        }}
      />
    );

    expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
      'danger',
      'Something went wrong. Please try again.'
    );
  });

  it('should dispatch inline danger notification when addBeneficiaryErrors has no status', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isBeneficiaryCreateError
        addBeneficiaryErrors={{
          data: {
            errors: [
              {
                code: 1002,
                message: 'Unknown error',
              },
            ],
          },
        }}
      />
    );

    expect(mockGlobalDispatch).toHaveBeenCalledWith({
      type: 'galaxy/context/update',
      data: {
        notificationAlert: {
          type: 'danger',
          message: 'Something went wrong. Please try again.',
        },
      },
    });
  });

  it('should redirect with getErrorMessage result when addBeneficiaryErrors has status 500', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isBeneficiaryCreateError
        addBeneficiaryErrors={{
          status: 500,
          data: {
            errors: [
              {
                code: 1003,
                message: 'Internal server error',
              },
            ],
          },
        }}
      />
    );

    expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
      'danger',
      'Something went wrong. Please try again later.'
    );
  });
});

describe('AddBeneficiaryContainer - MFA Modal', () => {
  it('renders EntitlementsStepUp and PingmfaWidgetApp when stepUpRequired and isStepUpModalVisible are true', () => {
    // Render the component and trigger the modal open
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isBeneficiaryCreateError
        addBeneficiaryErrors={{
          status: 401,
          data: { errors: [{ code: 8200, message: '' }] },
        }}
      />
    );

    const beneficiaryForm = screen.getByTestId(
      'add-or-update-beneficiary-button'
    );
    fireEvent.click(beneficiaryForm);
    // Check that EntitlementsStepUp and PingmfaWidgetApp are rendered
    expect(
      document.querySelector('[data-testid="entitlements-stepup-mock"]')
    ).toBeInTheDocument();
    expect(
      document.querySelector('[data-testid="widget-app-mock"]')
    ).toBeInTheDocument();
  });
  it('should close the step-up modal when Escape key is pressed', () => {
    // Render the component
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        addBeneficiaryErrors={{
          status: 401,
          data: { errors: [{ code: 8200, message: '' }] },
        }}
      />
    );

    const beneficiaryForm = screen.getByTestId(
      'add-or-update-beneficiary-button'
    );
    fireEvent.click(beneficiaryForm);
    // Check that EntitlementsStepUp and PingmfaWidgetApp are rendered
    expect(
      document.querySelector('[data-testid="entitlements-stepup-mock"]')
    ).toBeInTheDocument();
    expect(
      document.querySelector('[data-testid="widget-app-mock"]')
    ).toBeInTheDocument();

    fireEvent.keyDown(document, { key: 'Escape', code: 'Escape' });

    expect(
      document.querySelector('[data-testid="entitlements-stepup-mock"]')
    ).not.toBeInTheDocument();
    expect(
      document.querySelector('[data-testid="widget-app-mock"]')
    ).not.toBeInTheDocument();
  });
});

describe('AddBeneficiaryContainer - Division List Loading', () => {
  const populateHeaderMock = jest.fn();
  beforeEach(() => {
    jest.clearAllMocks();
    (useEntitlementsSafi as jest.Mock).mockReturnValue({
      populateHeader: populateHeaderMock,
    });
  });

  it('should call getDivisionList when orgId is available', () => {
    const getDivisionList = jest.fn();
    const clearDivisionList = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        getDivisionList={getDivisionList}
        clearDivisionList={clearDivisionList}
      />
    );

    expect(clearDivisionList).toHaveBeenCalled();
    expect(getDivisionList).toHaveBeenCalled();
  });

  it('should show BeneficiaryForm while division list is fetching', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isDivisionListFetching
        isDivisionListError={false}
      />
    );

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
    expect(screen.queryByTestId('error-handler')).not.toBeInTheDocument();
  });

  it('should show BeneficiaryForm when division list returns empty (no error)', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isDivisionListFetching={false}
        isDivisionListError={false}
        allDivisionList={[]}
      />
    );

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
    expect(screen.getByText('Stay safe from scams.')).toBeInTheDocument();
    expect(screen.queryByTestId('error-handler')).not.toBeInTheDocument();
  });

  it('should show BeneficiaryForm when division list returns with data', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isDivisionListFetching={false}
        isDivisionListError={false}
        allDivisionList={[
          { id: '1', divisionId: 'div1', divisionName: 'Division 1' },
        ]}
      />
    );

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
    expect(screen.getByText('Stay safe from scams.')).toBeInTheDocument();
  });
});

describe('AddBeneficiaryContainer - Division List Error', () => {
  const populateHeaderMock = jest.fn();
  beforeEach(() => {
    jest.clearAllMocks();
    (useEntitlementsSafi as jest.Mock).mockReturnValue({
      populateHeader: populateHeaderMock,
    });
  });

  it('should show ErrorHandler and hide BeneficiaryForm when division list has error', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isDivisionListFetching={false}
        isDivisionListError
      />
    );

    expect(screen.getByTestId('error-handler')).toBeInTheDocument();
    expect(screen.getByText('Something went wrong.')).toBeInTheDocument();
    // BeneficiaryForm is always rendered (it's outside the conditional)
    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
    // StaySafeFromScamsBanner is hidden when shouldShowMainBeneficiaryForm is false
    expect(screen.queryByText('Stay safe from scams.')).not.toBeInTheDocument();
  });

  it('should show ErrorHandler even while fetching when error flag exists', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isDivisionListFetching
        isDivisionListError
      />
    );

    // ErrorHandler is shown when isDivisionListError is true (regardless of fetching state)
    expect(screen.getByTestId('error-handler')).toBeInTheDocument();
    // StaySafeFromScamsBanner is hidden when shouldShowMainBeneficiaryForm is false
    expect(screen.queryByText('Stay safe from scams.')).not.toBeInTheDocument();
  });

  it('should call clearDivisionList and getDivisionList when refresh button is clicked', () => {
    const getDivisionList = jest.fn();
    const clearDivisionList = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        getDivisionList={getDivisionList}
        clearDivisionList={clearDivisionList}
        isDivisionListFetching={false}
        isDivisionListError
      />
    );

    // Clear the initial calls
    clearDivisionList.mockClear();
    getDivisionList.mockClear();

    const refreshButton = screen.getByTestId('refresh-button');
    fireEvent.click(refreshButton);

    expect(clearDivisionList).toHaveBeenCalled();
    expect(getDivisionList).toHaveBeenCalled();
  });

  it('should show BeneficiaryForm after retry succeeds (error clears)', () => {
    const { rerender } = render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isDivisionListFetching={false}
        isDivisionListError
      />
    );

    // Initially shows error
    expect(screen.getByTestId('error-handler')).toBeInTheDocument();
    // BeneficiaryForm is always rendered
    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();

    // After retry succeeds
    rerender(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isDivisionListFetching={false}
        isDivisionListError={false}
        allDivisionList={[]}
      />
    );

    // Now shows form
    expect(screen.queryByTestId('error-handler')).not.toBeInTheDocument();
    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
  });

  it('should show BeneficiaryForm after retry succeeds with divisions', () => {
    const { rerender } = render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isDivisionListFetching={false}
        isDivisionListError
      />
    );

    // Initially shows error
    expect(screen.getByTestId('error-handler')).toBeInTheDocument();

    // After retry succeeds with divisions
    rerender(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isDivisionListFetching={false}
        isDivisionListError={false}
        allDivisionList={[
          { id: '1', divisionId: 'div1', divisionName: 'Division 1' },
        ]}
      />
    );

    expect(screen.queryByTestId('error-handler')).not.toBeInTheDocument();
    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
    expect(screen.getByText('Stay safe from scams.')).toBeInTheDocument();
  });
});

describe('AddBeneficiaryContainer - useOrganisationId hook integration', () => {
  const populateHeaderMock = jest.fn();
  beforeEach(() => {
    jest.clearAllMocks();
    (useEntitlementsSafi as jest.Mock).mockReturnValue({
      populateHeader: populateHeaderMock,
    });
  });

  it('should pass orgId in protected-orgId header when fetching division list', () => {
    const getDivisionList = jest.fn();
    const clearDivisionList = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        getDivisionList={getDivisionList}
        clearDivisionList={clearDivisionList}
      />
    );

    expect(getDivisionList).toHaveBeenCalledWith(
      expect.objectContaining({
        meta: { replaceEntities: ['divisionList'] },
      }),
      expect.objectContaining({
        headers: { 'protected-orgId': '12345678910' },
      })
    );
  });
});

describe('AddBeneficiaryContainer - orgId undefined scenario', () => {
  const populateHeaderMock = jest.fn();
  let useOrganisationIdMock: jest.SpyInstance;

  beforeEach(() => {
    jest.clearAllMocks();
    (useEntitlementsSafi as jest.Mock).mockReturnValue({
      populateHeader: populateHeaderMock,
    });
    // Override the useOrganisationId mock for this describe block
    useOrganisationIdMock = jest
      .spyOn(require('../../hooks/useOrganisationId'), 'useOrganisationId')
      .mockReturnValue(undefined);
  });

  afterEach(() => {
    useOrganisationIdMock.mockRestore();
  });

  it('should not call getDivisionList when orgId is undefined', () => {
    const getDivisionList = jest.fn();
    const clearDivisionList = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        getDivisionList={getDivisionList}
        clearDivisionList={clearDivisionList}
      />
    );

    expect(getDivisionList).not.toHaveBeenCalled();
    // clearDivisionList should also not be called since we don't enter fetchDivisionList
    expect(clearDivisionList).not.toHaveBeenCalled();
  });

  it('should not include protected-orgId header in addBeneficiary when orgId is undefined', () => {
    const addBeneficiary = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        addBeneficiary={addBeneficiary}
      />
    );

    const addButton = screen.getByTestId('add-or-update-beneficiary-button');
    fireEvent.click(addButton);

    expect(addBeneficiary).toHaveBeenCalled();
    const callArgs = addBeneficiary.mock.calls[0][1];
    expect(callArgs.headers).not.toHaveProperty('protected-orgId');
  });

  it('should not call fetchDivisionList on refresh when orgId is undefined', () => {
    const getDivisionList = jest.fn();
    const clearDivisionList = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        getDivisionList={getDivisionList}
        clearDivisionList={clearDivisionList}
        isDivisionListFetching={false}
        isDivisionListError
      />
    );

    getDivisionList.mockClear();
    clearDivisionList.mockClear();

    const refreshButton = screen.getByTestId('refresh-button');
    fireEvent.click(refreshButton);

    // When orgId is undefined, clicking refresh should not fetch
    expect(getDivisionList).not.toHaveBeenCalled();
  });
});

describe('AddBeneficiaryContainer - Device Fingerprint Handling', () => {
  const populateHeaderMock = jest.fn();
  const originalEncodeDevicePrint = window.encode_deviceprint;

  beforeEach(() => {
    jest.clearAllMocks();
    (useEntitlementsSafi as jest.Mock).mockReturnValue({
      populateHeader: populateHeaderMock,
    });
  });

  afterEach(() => {
    // Restore original value
    if (originalEncodeDevicePrint) {
      window.encode_deviceprint = originalEncodeDevicePrint;
    } else {
      delete window.encode_deviceprint;
    }
  });

  it('should include x-deviceFingerprint header when window.encode_deviceprint exists for postAliasLookup', () => {
    const mockFingerprint = 'mock-device-fingerprint-123';
    window.encode_deviceprint = jest.fn(() => mockFingerprint);
    const postAliasLookup = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        postAliasLookup={postAliasLookup}
      />
    );

    const beneficiaryForm = screen.getByTestId('beneficiary-form');
    fireEvent.click(beneficiaryForm);

    expect(postAliasLookup).toHaveBeenCalledWith(
      expect.any(Object),
      expect.objectContaining({
        headers: { 'x-deviceFingerprint': mockFingerprint },
      })
    );
  });

  it('should not include x-deviceFingerprint header when window.encode_deviceprint is undefined', () => {
    delete window.encode_deviceprint;
    const postAliasLookup = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        postAliasLookup={postAliasLookup}
      />
    );

    const beneficiaryForm = screen.getByTestId('beneficiary-form');
    fireEvent.click(beneficiaryForm);

    expect(postAliasLookup).toHaveBeenCalledWith(
      expect.any(Object),
      expect.objectContaining({
        headers: {},
      })
    );
  });
});

describe('AddBeneficiaryContainer - addBeneficiaryWithExtraHeaders', () => {
  const populateHeaderMock = jest.fn().mockReturnValue({
    'step-up-type': 'mfa',
  });
  const originalEncodeDevicePrint = window.encode_deviceprint;

  beforeEach(() => {
    jest.clearAllMocks();
    (useEntitlementsSafi as jest.Mock).mockReturnValue({
      populateHeader: populateHeaderMock,
    });
  });

  afterEach(() => {
    if (originalEncodeDevicePrint) {
      window.encode_deviceprint = originalEncodeDevicePrint;
    } else {
      delete window.encode_deviceprint;
    }
  });

  it('should include protected-orgId header when orgId is available', () => {
    const addBeneficiary = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        addBeneficiary={addBeneficiary}
      />
    );

    const addButton = screen.getByTestId('add-or-update-beneficiary-button');
    fireEvent.click(addButton);

    expect(addBeneficiary).toHaveBeenCalledWith(
      expect.any(Object),
      expect.objectContaining({
        headers: expect.objectContaining({
          'protected-orgId': '12345678910',
        }),
      })
    );
  });

  it('should call populateHeader with device fingerprint when window.encode_deviceprint exists', () => {
    const mockFingerprint = 'test-fingerprint-456';
    window.encode_deviceprint = jest.fn(() => mockFingerprint);
    const addBeneficiary = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        addBeneficiary={addBeneficiary}
      />
    );

    const addButton = screen.getByTestId('add-or-update-beneficiary-button');
    fireEvent.click(addButton);

    expect(populateHeaderMock).toHaveBeenCalledWith(
      {},
      window.encode_deviceprint
    );
  });

  it('should not call populateHeader when window.encode_deviceprint is undefined', () => {
    delete window.encode_deviceprint;
    const addBeneficiary = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        addBeneficiary={addBeneficiary}
      />
    );

    const addButton = screen.getByTestId('add-or-update-beneficiary-button');
    fireEvent.click(addButton);

    expect(populateHeaderMock).not.toHaveBeenCalled();
  });

  it('should merge headers from populateHeader with other headers', () => {
    const mockFingerprint = 'fingerprint-merge-test';
    window.encode_deviceprint = jest.fn(() => mockFingerprint);
    populateHeaderMock.mockReturnValue({ 'step-up-type': 'mfa-token' });
    const addBeneficiary = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        addBeneficiary={addBeneficiary}
      />
    );

    const addButton = screen.getByTestId('add-or-update-beneficiary-button');
    fireEvent.click(addButton);

    expect(addBeneficiary).toHaveBeenCalledWith(
      expect.any(Object),
      expect.objectContaining({
        headers: expect.objectContaining({
          'step-up-type': 'mfa-token',
          'protected-orgId': '12345678910',
        }),
      })
    );
  });
});

describe('AddBeneficiaryContainer - initiateBeneficiary and nickname handling', () => {
  const populateHeaderMock = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    mockHandleRedirectToBeneficiaryList.mockClear();
    (useEntitlementsSafi as jest.Mock).mockReturnValue({
      populateHeader: populateHeaderMock,
    });
  });

  it('should store nickname in ref and pass it to redirect on maker/checker success', () => {
    // First render - trigger add beneficiary
    const addBeneficiary = jest.fn();
    const { rerender } = render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        addBeneficiary={addBeneficiary}
        isBeneficiaryCreateFetching={false}
        isBeneficiaryCreateError={false}
      />
    );

    const addButton = screen.getByTestId('add-or-update-beneficiary-button');
    fireEvent.click(addButton);

    // Now simulate maker/checker response
    rerender(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        addBeneficiary={addBeneficiary}
        isBeneficiaryCreateFetching={false}
        isBeneficiaryCreateError
        addBeneficiaryErrors={{
          status: 401,
          data: {
            errors: [{ code: 8125, message: '' }],
          },
        }}
      />
    );

    expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
      'success',
      expect.objectContaining({
        action: 'add',
        isMakerCheckerApplicable: true,
      })
    );
  });

  it('should set isStepUpModalVisible to true when initiateBeneficiary is called', () => {
    const addBeneficiary = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        addBeneficiary={addBeneficiary}
        isBeneficiaryCreateError
        addBeneficiaryErrors={{
          status: 401,
          data: { errors: [{ code: 8200, message: '' }] },
        }}
      />
    );

    const addButton = screen.getByTestId('add-or-update-beneficiary-button');
    fireEvent.click(addButton);

    // Check that EntitlementsStepUp is rendered (modal visible)
    expect(
      document.querySelector('[data-testid="entitlements-stepup-mock"]')
    ).toBeInTheDocument();
  });
});

describe('AddBeneficiaryContainer - Error handling edge cases', () => {
  const populateHeaderMock = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    mockGlobalDispatch.mockClear();
    mockHandleRedirectToBeneficiaryList.mockClear();
    (useEntitlementsSafi as jest.Mock).mockReturnValue({
      populateHeader: populateHeaderMock,
    });
  });

  it('should not trigger error handling when isBeneficiaryCreateFetching is true', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isBeneficiaryCreateFetching
        isBeneficiaryCreateError
        addBeneficiaryErrors={{
          status: 500,
          data: { errors: [{ code: 1003, message: 'Error' }] },
        }}
      />
    );

    expect(mockGlobalDispatch).not.toHaveBeenCalled();
    expect(mockHandleRedirectToBeneficiaryList).not.toHaveBeenCalled();
  });

  it('should not trigger error handling when addBeneficiaryErrors is undefined', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isBeneficiaryCreateFetching={false}
        isBeneficiaryCreateError
        addBeneficiaryErrors={undefined}
      />
    );

    expect(mockGlobalDispatch).not.toHaveBeenCalled();
    expect(mockHandleRedirectToBeneficiaryList).not.toHaveBeenCalled();
  });

  it('should not trigger error handling when isBeneficiaryCreateError is false', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isBeneficiaryCreateFetching={false}
        isBeneficiaryCreateError={false}
        addBeneficiaryErrors={{
          status: 500,
          data: { errors: [{ code: 1003, message: 'Error' }] },
        }}
      />
    );

    expect(mockGlobalDispatch).not.toHaveBeenCalled();
    expect(mockHandleRedirectToBeneficiaryList).not.toHaveBeenCalled();
  });

  it('should handle error with empty errors array', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isBeneficiaryCreateFetching={false}
        isBeneficiaryCreateError
        addBeneficiaryErrors={{
          status: 400,
          data: { errors: [] },
        }}
      />
    );

    // Should fall through to default error handling
    expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
      'danger',
      expect.any(String)
    );
  });

  it('should handle 401 error with non-matching error codes', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isBeneficiaryCreateFetching={false}
        isBeneficiaryCreateError
        addBeneficiaryErrors={{
          status: 401,
          data: { errors: [{ code: 9999, message: 'Unknown 401 error' }] },
        }}
      />
    );

    // Should fall through to default error handling (not maker/checker, not MFA)
    expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
      'danger',
      expect.any(String)
    );
  });

  it('should handle error with undefined data property', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isBeneficiaryCreateFetching={false}
        isBeneficiaryCreateError
        addBeneficiaryErrors={{
          status: 500,
        }}
      />
    );

    expect(mockHandleRedirectToBeneficiaryList).toHaveBeenCalledWith(
      'danger',
      expect.any(String)
    );
  });
});

describe('AddBeneficiaryContainer - Conditional rendering states', () => {
  const populateHeaderMock = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    (useEntitlementsSafi as jest.Mock).mockReturnValue({
      populateHeader: populateHeaderMock,
    });
  });

  it('should not show StaySafeFromScamsBanner when isDivisionListError is true', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isDivisionListFetching={false}
        isDivisionListError
      />
    );

    expect(screen.queryByText('Stay safe from scams.')).not.toBeInTheDocument();
    expect(screen.getByTestId('error-handler')).toBeInTheDocument();
  });

  it('should show StaySafeFromScamsBanner when loading completes without error', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isDivisionListFetching={false}
        isDivisionListError={false}
      />
    );

    expect(screen.getByText('Stay safe from scams.')).toBeInTheDocument();
    expect(screen.queryByTestId('error-handler')).not.toBeInTheDocument();
  });

  it('should always render BeneficiaryForm regardless of error state', () => {
    const { rerender } = render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isDivisionListFetching={false}
        isDivisionListError={false}
      />
    );

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();

    rerender(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isDivisionListFetching={false}
        isDivisionListError
      />
    );

    // BeneficiaryForm is always rendered, but banner and notification are hidden when error
    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
    expect(screen.queryByText('Stay safe from scams.')).not.toBeInTheDocument();
  });

  it('should render MVCard with correct title', () => {
    render(<AddBeneficiaryContainer {...defaultTestProps} />);

    expect(screen.getByText('Add a beneficiary')).toBeInTheDocument();
  });
});

describe('AddBeneficiaryContainer - clearAliasLookup and clearBsbLookup props', () => {
  const populateHeaderMock = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    (useEntitlementsSafi as jest.Mock).mockReturnValue({
      populateHeader: populateHeaderMock,
    });
  });

  it('should pass clearAliasLookup to BeneficiaryForm', () => {
    const clearAliasLookup = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        clearAliasLookup={clearAliasLookup}
      />
    );

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
    // The mock component doesn't expose clearAliasLookup, but we verify it's passed
  });

  it('should pass clearBsbLookup to BeneficiaryForm', () => {
    const clearBsbLookup = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        clearBsbLookup={clearBsbLookup}
      />
    );

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
    // The mock component doesn't expose clearBsbLookup, but we verify it's passed
  });
});

describe('AddBeneficiaryContainer - PayID validation states passed to form', () => {
  const populateHeaderMock = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    (useEntitlementsSafi as jest.Mock).mockReturnValue({
      populateHeader: populateHeaderMock,
    });
  });

  it('should render with isPayIdNotValid true', () => {
    render(<AddBeneficiaryContainer {...defaultTestProps} isPayIdNotValid />);

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
  });

  it('should render with isPayIdLimitExceeded true', () => {
    render(
      <AddBeneficiaryContainer {...defaultTestProps} isPayIdLimitExceeded />
    );

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
  });

  it('should render with isPayIdServiceNotAvailable true', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isPayIdServiceNotAvailable
      />
    );

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
  });

  it('should render with doesAliasIdContainInvalidData true', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        doesAliasIdContainInvalidData
      />
    );

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
  });
});

describe('AddBeneficiaryContainer - BSB lookup states passed to form', () => {
  const populateHeaderMock = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    (useEntitlementsSafi as jest.Mock).mockReturnValue({
      populateHeader: populateHeaderMock,
    });
  });

  it('should render with isBsbLookupFetching true', () => {
    render(
      <AddBeneficiaryContainer {...defaultTestProps} isBsbLookupFetching />
    );

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
  });

  it('should render with isBsbLookupError true', () => {
    render(<AddBeneficiaryContainer {...defaultTestProps} isBsbLookupError />);

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
  });

  it('should render with branches data', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        allBranches={[
          { bsb: '123456', bankName: 'Test Bank', branchName: 'Test Branch' },
        ]}
      />
    );

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
  });

  it('should render with bsbLookupApiStatus', () => {
    render(
      <AddBeneficiaryContainer {...defaultTestProps} bsbLookupApiStatus={200} />
    );

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
  });
});

describe('AddBeneficiaryContainer - Alias lookup states passed to form', () => {
  const populateHeaderMock = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    (useEntitlementsSafi as jest.Mock).mockReturnValue({
      populateHeader: populateHeaderMock,
    });
  });

  it('should render with isAliasLookupFetching true', () => {
    render(
      <AddBeneficiaryContainer {...defaultTestProps} isAliasLookupFetching />
    );

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
  });

  it('should render with isAliasLookupError true', () => {
    render(
      <AddBeneficiaryContainer {...defaultTestProps} isAliasLookupError />
    );

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
  });

  it('should render with allAliasLookup data', () => {
    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        allAliasLookup={[
          { aliasType: 'EMAL', aliasId: 'test@example.com', name: 'Test User' },
        ]}
      />
    );

    expect(screen.getByText('BeneficiaryForm')).toBeInTheDocument();
  });
});

describe('AddBeneficiaryContainer - postAccountNameCheck', () => {
  const populateHeaderMock = jest.fn();
  beforeEach(() => {
    (useEntitlementsSafi as jest.Mock).mockReturnValue({
      populateHeader: populateHeaderMock,
    });
  });

  it('should call postAccountNameCheckAction when postAccountNameCheck is triggered', () => {
    const postAccountNameCheckAction = jest.fn();
    const clearAccountNameCheck = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        postAccountNameCheckAction={postAccountNameCheckAction}
        clearAccountNameCheck={clearAccountNameCheck}
      />
    );

    const checkDetailsButton = screen.getByTestId('check-details-button');
    fireEvent.click(checkDetailsButton);

    expect(clearAccountNameCheck).toHaveBeenCalled();
    expect(postAccountNameCheckAction).toHaveBeenCalledWith({
      params: {
        payee: {
          accountName: 'Test Account',
          accountId: {
            accountNumber: '12345678',
            BSB: '123456',
          },
        },
      },
      meta: {
        replaceEntities: ['accountNameCheck'],
      },
    });
  });
});

describe('AddBeneficiaryContainer - onInvalidateCopCheck', () => {
  it('should call clearAccountNameCheck when onInvalidateCopCheck is triggered', () => {
    const clearAccountNameCheck = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        clearAccountNameCheck={clearAccountNameCheck}
      />
    );

    const invalidateButton = screen.getByTestId('invalidate-cop-button');
    fireEvent.click(invalidateButton);

    expect(clearAccountNameCheck).toHaveBeenCalled();
  });
});

describe('AddBeneficiaryContainer - Division List Error with Refresh', () => {
  it('should call getDivisionList when refresh button is clicked', () => {
    const getDivisionList = jest.fn();

    render(
      <AddBeneficiaryContainer
        {...defaultTestProps}
        isDivisionListError
        isDivisionListFetching={false}
        getDivisionList={getDivisionList}
      />
    );

    const refreshButton = screen.getByTestId('refresh-button');
    fireEvent.click(refreshButton);

    expect(getDivisionList).toHaveBeenCalled();
  });
});
