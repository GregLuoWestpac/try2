/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable react/react-in-jsx-scope */
import { fireEvent, render, screen } from '@testing-library/react';
import ApprovalWorkflowPanel from './ApprovalWorkflowPanel';

jest.mock('@westpac/ui', () => ({
  Alert: ({ children }: any) => <div data-testid="alert">{children}</div>,
  Button: ({ children, onClick }: any) => (
    <button data-testid="retry-btn" onClick={onClick}>
      {children}
    </button>
  ),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-pageloader', () => ({
  MVPageLoader: () => <div data-testid="page-loader">Loading</div>,
}));

jest.mock('./ApprovalWorkflowTable', () => ({
  __esModule: true,
  default: ({ allPostApprovalWorkflowListing }: any) => (
    <div data-testid="approval-workflow-table">
      {JSON.stringify(allPostApprovalWorkflowListing)}
    </div>
  ),
}));

jest.mock('../../common/constants', () => ({
  genericErrorMessage: 'Something went wrong.',
}));

describe('ApprovalWorkflowPanel', () => {
  const defaultProps = {
    hasApprovalWorkflowListingError: false,
    isApprovalWorkflowListingFetching: false,
    activeTab: '',
    allPostApprovalWorkflowListing: [],
    handleRetryApprovalWorkflow: jest.fn(),
  };

  beforeEach(() => {
    // Mock the DOM element that the component looks for
    const mockElement = document.createElement('div');
    mockElement.id = 'maker-checker-api-client';
    document.body.appendChild(mockElement);
  });

  afterEach(() => {
    jest.clearAllMocks();
    // Clean up the mock element
    const mockElement = document.getElementById('maker-checker-api-client');
    if (mockElement) {
      document.body.removeChild(mockElement);
    }
  });

  it('renders error Alert and retry Button when hasApprovalWorkflowListingError is true', () => {
    render(
      <ApprovalWorkflowPanel
        {...defaultProps}
        hasApprovalWorkflowListingError
      />
    );
    expect(screen.getByTestId('alert')).toBeInTheDocument();
    expect(screen.getByTestId('retry-btn')).toBeInTheDocument();
    expect(screen.getByText(/Something went wrong/)).toBeInTheDocument();
    expect(screen.getByText(/try again/)).toBeInTheDocument();
  });

  it('calls handleRetryApprovalWorkflow when retry Button is clicked', () => {
    const handleRetry = jest.fn();
    render(
      <ApprovalWorkflowPanel
        {...defaultProps}
        hasApprovalWorkflowListingError
        handleRetryApprovalWorkflow={handleRetry}
      />
    );
    fireEvent.click(screen.getByTestId('retry-btn'));
    expect(handleRetry).toHaveBeenCalled();
  });

  it('renders PageLoader when isApprovalWorkflowListingFetching is true', () => {
    render(
      <ApprovalWorkflowPanel
        {...defaultProps}
        isApprovalWorkflowListingFetching
      />
    );
    expect(screen.getByTestId('page-loader')).toBeInTheDocument();
  });

  it('renders ApprovalWorkflowTable with correct data for activeTab', () => {
    const data = [{ id: 1 }];
    render(
      <ApprovalWorkflowPanel
        {...defaultProps}
        activeTab="ForYouToAuthorise"
        allPostApprovalWorkflowListing={data}
      />
    );
    expect(screen.getByTestId('approval-workflow-table')).toBeInTheDocument();
    expect(screen.getByText(JSON.stringify(data))).toBeInTheDocument();
  });

  it('renders ApprovalWorkflowTable for unknown tab', () => {
    render(
      <ApprovalWorkflowPanel {...defaultProps} activeTab="UnknownTab" />
    );
    expect(screen.getByTestId('approval-workflow-table')).toBeInTheDocument();
    expect(screen.getByText('[]')).toBeInTheDocument();
  });

  it('renders ApprovalWorkflowTable when activeTab is empty', () => {
    render(
      <ApprovalWorkflowPanel {...defaultProps} activeTab="" />
    );
    expect(screen.getByTestId('approval-workflow-table')).toBeInTheDocument();
    expect(screen.getByText('[]')).toBeInTheDocument();
  });
});