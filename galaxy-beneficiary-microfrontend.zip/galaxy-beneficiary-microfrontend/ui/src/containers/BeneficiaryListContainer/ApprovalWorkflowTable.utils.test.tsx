/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-explicit-any */
import React from 'react';
import { render } from '@testing-library/react';
import { AUTHORISATION_STATUS, BENEFICIARY_TYPE } from '../../store/types';
import { StatusBadge, buildColumnDefs } from './ApprovalWorkflowTable.utils';

// Mock @westpac/ui to avoid React child rendering issues
jest.mock('@westpac/ui', () => ({
  Badge: ({ children, ...props }: any) => (
    <span data-testid="badge" {...props}>
      {children}
    </span>
  ),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  getTodayAtLastYear: () => ({ toFormat: () => '2024-01-18' }),
  getToday: () => ({ toFormat: () => '2025-01-18' }),
}));

describe('ApprovalWorkflowTable.utils', () => {
  describe('StatusBadge', () => {
    it('renders a badge with status', () => {
      const params: any = {
        data: { status: AUTHORISATION_STATUS.PENDING_AUTHORISATION },
      };
      const { container } = render(<StatusBadge {...params} />);
      expect(container).toBeInTheDocument();
    });
  });

  describe('buildColumnDefs', () => {
    it('returns an array of column definitions', () => {
      const columnDefs = buildColumnDefs();
      expect(columnDefs).toBeInstanceOf(Array);
      expect(columnDefs.length).toBeGreaterThan(0);
    });

    it('accountDetails valueGetter returns BSB format for ACCOUNT type', () => {
      const columnDefs = buildColumnDefs();
      const accountDetailsCol = columnDefs.find(
        col => col.field === 'accountDetails'
      );

      const params: any = {
        data: {
          account: {
            accountId: {
              BSB: '123456',
              accountNumber: '987654321',
            },
          },
        },
      };

      const result =
        typeof accountDetailsCol?.valueGetter === 'function'
          ? accountDetailsCol.valueGetter(params)
          : null;
      expect(result).toBe('123-456 987654321');
    });

    it('accountDetails valueGetter returns payIDValue for PayID type', () => {
      const columnDefs = buildColumnDefs();
      const accountDetailsCol = columnDefs.find(
        col => col.field === 'accountDetails'
      );

      const params: any = {
        data: {
          account: {
            payIDValue: 'test@example.com',
          },
        },
      };

      const result =
        typeof accountDetailsCol?.valueGetter === 'function'
          ? accountDetailsCol.valueGetter(params)
          : null;
      expect(result).toBe(' test@example.com');
    });

    it('accountName valueGetter returns accountName when available', () => {
      const columnDefs = buildColumnDefs();
      const accountNameCol = columnDefs.find(
        col => col.field === 'accountName'
      );

      const params: any = {
        data: {
          account: {
            accountName: 'Test Account',
          },
        },
      };

      const result =
        typeof accountNameCol?.valueGetter === 'function'
          ? accountNameCol.valueGetter(params)
          : null;
      expect(result).toBe('Test Account');
    });

    it('accountName valueGetter returns payIDName when accountName not available', () => {
      const columnDefs = buildColumnDefs();
      const accountNameCol = columnDefs.find(
        col => col.field === 'accountName'
      );

      const params: any = {
        data: {
          account: {
            payIDName: 'Test PayID Name',
          },
        },
      };

      const result =
        typeof accountNameCol?.valueGetter === 'function'
          ? accountNameCol.valueGetter(params)
          : null;
      expect(result).toBe('Test PayID Name');
    });

    it('type valueGetter returns BSB & account number for ACCOUNT type', () => {
      const columnDefs = buildColumnDefs();
      const typeCol = columnDefs.find(col => col.field === 'type');

      const params: any = {
        data: {
          type: BENEFICIARY_TYPE.ACCOUNT,
        },
      };

      const result =
        typeof typeCol?.valueGetter === 'function'
          ? typeCol.valueGetter(params)
          : null;
      expect(result).toBe('BSB & account number');
    });

    it('type valueGetter returns PayID for PayID type', () => {
      const columnDefs = buildColumnDefs();
      const typeCol = columnDefs.find(col => col.field === 'type');

      const params: any = {
        data: {
          type: BENEFICIARY_TYPE.PAYID,
        },
      };

      const result =
        typeof typeCol?.valueGetter === 'function'
          ? typeCol.valueGetter(params)
          : null;
      expect(result).toBe('PayID');
    });
  });
});
