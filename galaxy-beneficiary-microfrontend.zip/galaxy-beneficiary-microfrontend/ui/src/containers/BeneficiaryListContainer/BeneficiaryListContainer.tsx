/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-redundant-type-constituents */
/* eslint-disable no-nested-ternary */
/* eslint-disable react/no-unstable-nested-components */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import React, { Key, useEffect, useMemo, useRef, useState } from 'react';
import {
  compose,
  connect,
  useGlobalDispatch,
  useGlobalSelector,
} from '@mep-ui/framework';
import { useNavigate } from '@mep-ui/framework-router-addon';
import {
  useIsCompositeDesktop,
  usePlatformState,
} from '@mesh-tenant-multiverse-common/react';
import { MVRefresh } from '@mesh-tenant-multiverse-ui-common/mv-refresh';
import {
  isStaffPortal,
  useHandleRaiseIntent,
  getFormattedDateTime,
  convertSydneyLocalTimeToUtc,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import {
  Actions,
  Resources,
  useAuthoriser,
} from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import { Tabs, TabsPanel } from '@westpac/ui';
import { SubmitHandler, useForm } from 'react-hook-form';
import BeneficiaryListSearchForm from 'ui/src/components/BeneficiaryListSearchForm/BeneficiaryListSearchForm';
import {
  AuthorisationStatusTab,
  AuthorisationTab,
  BeneficiaryTab,
  INTENT_NAMES,
  INTENTS_CONTEXT_NAME,
  PAGE_NAVIGATION,
  W1_ORGANIZATION_SSO,
} from '../../common';
import {
  authorisationStatusOptions,
  authorisationTabOptions,
  defaultAuthorisationSearchFormData,
  mapApprovalWorkflowList,
} from '../../common/Beneficiary.util';
import { BeneficiaryList, ErrorHandler, PageLoader } from '../../components';
import {
  BeneficiaryListSearchFormData,
  BeneficiaryStatus,
} from '../../components/BeneficiaryListSearchForm/BeneficiaryListSearchForm.types';
import NotificationAlert, {
  NotificationAlertState,
} from '../../components/NotificationAlert/NotificationAlert';
import {
  beneficiaryArchiveEntityActions,
  beneficiaryListActions,
  beneficiaryListEntityActions,
  getAllBeneficiaryList,
  isBeneficiaryListError as isBeneficiariesErrorSelector,
  isBeneficiaryListFetching as isBeneficiariesFetchingSelector,
} from '../../store/generated';
import store from '../../store/store';
import {
  APPLICATION_CHANNEL,
  AUTHORISATION_STATUS,
  AuthorisationSearchFormType,
  AuthorisationStatusValues,
  AuthorisationTabValues,
  Beneficiary,
  GlobalState,
  PostBeneficiaryListParamsPayload,
  REQUEST_GROUP,
  RequestOptionsPayload,
  RootState,
  SearchBy,
  WORKFLOW_SUBTYPE,
  WORKFLOW_TYPE,
} from '../../store/types';
import { ApprovalWorkflowListing } from '../../store/types/ApprovalWorkflowListing';
import { GalaxyMakerCheckerWrapper } from '../../widgets/galaxymakerchecker-v1';
import { PostApprovalWorkflowListData } from '../../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types';
import ApprovalWorkflowPanel from './ApprovalWorkflowPanel';

import BeneficiaryAuthorisationsSearchSection from './BeneficiaryAuthorisationsSearchSection/BeneficiaryAuthorisationsSearchSection';
import { useOrganisationId } from '../../hooks/useOrganisationId';

export type BeneficiaryListProps = {
  allBeneficiaries: Beneficiary[];
  isBeneficiaryListFetching: boolean;
  isBeneficiaryListError: boolean;
  getBeneficiaryList: (
    params: PostBeneficiaryListParamsPayload,
    options: RequestOptionsPayload
  ) => void;
  clearBeneficiaryList: () => void;
  clearBeneficiaryArchive: () => void;
};

export function BeneficiaryListContainer({
  allBeneficiaries,
  isBeneficiaryListFetching = false,
  isBeneficiaryListError = false,
  getBeneficiaryList,
  clearBeneficiaryList,
  clearBeneficiaryArchive,
}: BeneficiaryListProps) {
  const isCompositeDesktop = useIsCompositeDesktop();
  const [organisationSSOData] = usePlatformState(W1_ORGANIZATION_SSO, {
    orgId: {
      organisationId: '',
    },
  });
  const orgIdForCustomerPortal =
    !isCompositeDesktop && window.location.hostname === 'localhost'
      ? '12345678910'
      : organisationSSOData?.orgId?.organisationId;

  const globalDispatch = useGlobalDispatch();
  const notificationAlert: NotificationAlertState = useGlobalSelector(
    (state: GlobalState) => state?.global?.galaxy?.context?.notificationAlert
  );

  const [activeTab, setActiveTab] = useState<string>(
    BeneficiaryTab.BeneficiariesList
  );

  const [approvalWorkflowTrigger, setApprovalWorkflowTrigger] = useState(0);

  const [isLoadingWidget, setIsLoadingWidget] = useState(true);

  // Authorisation panel state
  const [authorisationActiveTab, setAuthorisationActiveTab] = useState<
    AuthorisationTabValues | string
  >(AuthorisationTab.ForYouToAuthorise);

  const [statusActiveTab, setStatusActiveTab] = useState<
    AuthorisationStatusValues | string
  >(AuthorisationStatusTab.PendingAuthorisation);

  // ART-97614 - can remove this state when DSR fix has been implemented
  const [isTrackAuthorisationTabSelected, setIsTrackAuthorisationTabSelected] =
    useState(statusActiveTab === AuthorisationTab.TrackAuthorisation);

  const [authorisationSearchFormData, setAuthorisationSearchFormData] =
    useState<AuthorisationSearchFormType>({
      ...defaultAuthorisationSearchFormData,
      authorisationTab: AuthorisationTab.ForYouToAuthorise,
      authorisationStatusTab: AuthorisationStatusTab.PendingAuthorisation,
    });

  const [
    isBeneficiaryAuthorisationFetching,
    setIsBeneficiaryAuthorisationFetching,
  ] = useState(true);

  const [isAuthorisationFetchingError, setIsAuthorisationFetchingError] =
    useState(false);
  const [beneficiaryAuthorisationList, setBeneficiaryAuthorisationList] =
    useState<ApprovalWorkflowListing[]>([]);

  const [dateTimeAfterApiSuccess, setDateTimeAfterApiSuccess] =
    useState<string>(getFormattedDateTime);

  const orgId: string | undefined = useOrganisationId();

  const [isOrgIdFetching, setIsOrgIdFetching] = useState<boolean>(true);
  const organisationId = useMemo(() => {
    if (!isStaffPortal()) {
      return orgIdForCustomerPortal;
    }

    return orgId;
  }, [orgIdForCustomerPortal, orgId]);

  // Beneficiary list search form
  const {
    control,
    handleSubmit,
    formState: { errors },
    trigger,
  } = useForm<BeneficiaryListSearchFormData>({
    mode: 'onBlur',
    reValidateMode: 'onBlur',
  });

  // Authorisation search form
  const {
    control: authorisationControl,
    setError: authorisationSetError,
    clearErrors: authorisationClearErrors,
    handleSubmit: authorisationHandleSubmit,
    getValues: authorisationGetValues,
    trigger: authorisationTrigger,
  } = useForm<AuthorisationSearchFormType>({
    mode: 'onBlur',
    reValidateMode: 'onBlur',
    defaultValues: defaultAuthorisationSearchFormData,
  });

  const isBSBNumber = (value: string): string => {
    // Regex pattern: exactly 3 digits, hyphen, exactly 3 digits
    const bsbPattern = /^\d{3}-\d{3}$/;
    if (bsbPattern.test(value)) {
      return value.replace('-', '');
    }
    return value;
  };

  const fetchBeneficiaryList = (
    orgId?: string,
    searchParams?: BeneficiaryListSearchFormData
  ) => {
    const fetchBeneficiaryRequestParams: PostBeneficiaryListParamsPayload = {
      meta: {
        replaceEntities: ['beneficiaryList'],
      },
      params: {
        ...(searchParams &&
          searchParams?.beneficiarySearchCriteria && {
            searchCriteria: isBSBNumber(
              searchParams?.beneficiarySearchCriteria
            ),
          }),
        statuses: [
          BeneficiaryStatus.ACTIVE,
          BeneficiaryStatus.ON_HOLD,
          ...((searchParams?.archivedBeneficiaryStatus ??
            []) as unknown as BeneficiaryStatus[]),
        ],
      },
    };
    getBeneficiaryList(fetchBeneficiaryRequestParams, {
      headers: {
        ...(orgId && {
          'protected-orgId': orgId,
        }),
      },
    });
  };

  const handleAuthorisationSearch = (data: AuthorisationSearchFormType) => {
    setAuthorisationSearchFormData(data);
    setAuthorisationActiveTab(authorisationActiveTab);
    setApprovalWorkflowTrigger(Date.now());
  };

  const onAuthorisationSubmit = (data: AuthorisationSearchFormType) => {
    const dateRangeValues = authorisationGetValues('dateRange');

    const formData: AuthorisationSearchFormType = {
      ...data,
      authorisationTab: authorisationActiveTab,
      authorisationStatusTab: statusActiveTab,
      dateRange: dateRangeValues,
    };
    handleAuthorisationSearch(formData);
  };

  const onRefresh = () => {
    if (activeTab === BeneficiaryTab.BeneficiariesList) {
      void handleSubmit(onSubmit)();
    }
    if (activeTab === BeneficiaryTab.Authorisation) {
      void authorisationHandleSubmit(onAuthorisationSubmit)();
    }
  };

  const handleRaiseIntent = useHandleRaiseIntent(
    useGlobalDispatch,
    useNavigate
  );

  const onClickAddBeneficiary = async () => {
    await handleRaiseIntent({
      intentName: INTENT_NAMES.CREATE_BENEFICIARY,
      intentContextName: INTENTS_CONTEXT_NAME.BENEFICIARY,
      targetPath: PAGE_NAVIGATION.CREATE_BENEFICIARY,
    });
  };

  const hideNotificationAlert = () => {
    const data = {
      notificationAlert: {
        type: '',
        message: '',
      },
    };
    globalDispatch({
      type: 'galaxy/context/update',
      ...(data && { data: { ...data } }),
    });
  };

  const handleRefreshAndHideNotiAlert = () => {
    onRefresh();
    hideNotificationAlert();
  };

  useEffect(
    () => () => {
      hideNotificationAlert();
    },
    []
  );

  useEffect(() => {
    const isNonCompositeDesktop = !isCompositeDesktop;
    const hasOrgId = !!organisationId;
    const hasOrgIdForCompositeDesktop = isCompositeDesktop && hasOrgId;

    const shouldFetchData =
      isNonCompositeDesktop || hasOrgIdForCompositeDesktop;

    if (!notificationAlert && shouldFetchData) {
      setIsOrgIdFetching(false);
      fetchBeneficiaryList(organisationId);
    }
  }, [organisationId]);

  useEffect(() => {
    if (notificationAlert?.type) {
      onRefresh();
    }
  }, [notificationAlert]);

  useEffect(
    () => () => {
      clearBeneficiaryList();
    },
    []
  );

  useEffect(() => {
    if (!isLoadingWidget) return;
    const widget = document.getElementById('maker-checker-api-client');
    if (widget) {
      setIsLoadingWidget(false);
      return;
    }
    const observer = new MutationObserver(() => {
      const found = document.getElementById('maker-checker-api-client');
      if (found) {
        setIsLoadingWidget(false);
        observer.disconnect();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    return () => observer.disconnect();
  }, [isLoadingWidget]);

  const { authorised: isUserAuthorizedToCreateBeneficiaries } = useAuthoriser(
    Resources.BENEFICIARY,
    Actions.CREATE_BENEFICIARY
  );

  const onSubmit: SubmitHandler<BeneficiaryListSearchFormData> = (
    data: BeneficiaryListSearchFormData,
    e?: React.BaseSyntheticEvent
  ) => {
    e?.preventDefault();
    fetchBeneficiaryList(organisationId, data);
  };

  const handleApplyClick = (e?: React.MouseEvent) => {
    e?.preventDefault();
    void handleSubmit(onSubmit)();
  };

  // Authorisation form handlers
  const handleAuthorisationButtonGroupChange = (
    val: AuthorisationTabValues | string
  ) => {
    setAuthorisationActiveTab(val);
    setIsTrackAuthorisationTabSelected(
      val === AuthorisationTab.TrackAuthorisation
    );
  };

  const handleStatusButtonGroupChange = (
    val: AuthorisationStatusValues | string
  ) => {
    setStatusActiveTab(val);
  };

  const handleAuthorisationAccordionButtonClick = async (
    event: React.MouseEvent
  ) => {
    event.preventDefault();
    await authorisationHandleSubmit(onAuthorisationSubmit)();
  };

  const handleTabChange = async (key: string | Key) => {
    if (key !== activeTab) {
      setActiveTab(key.toString());

      if (key === BeneficiaryTab.Authorisation) {
        await authorisationTrigger([
          'dateRange.startDate',
          'dateRange.endDate',
        ]);

        await authorisationHandleSubmit(onAuthorisationSubmit)();
      }
      if (key === BeneficiaryTab.BeneficiariesList) {
        await trigger('beneficiarySearchCriteria');
        await handleSubmit(onSubmit)();
      }
    }
  };

  // Compute authorisation API params
  const postBeneficiaryAuthorisationListParams = useMemo(() => {
    const convertedDateRange = authorisationSearchFormData?.dateRange
      ? {
          fromDate: authorisationSearchFormData.dateRange.startDate
            ? convertSydneyLocalTimeToUtc(
                authorisationSearchFormData.dateRange.startDate
              )
            : undefined,
          toDate: authorisationSearchFormData.dateRange.endDate
            ? convertSydneyLocalTimeToUtc(
                authorisationSearchFormData.dateRange.endDate,
                'end'
              )
            : undefined,
        }
      : undefined;

    const baseParams = {
      types: [WORKFLOW_TYPE.W1C_BENEFICIARY],
      subTypes: [
        WORKFLOW_SUBTYPE.ADD_BENEFICIARY,
        WORKFLOW_SUBTYPE.UPDATE_BENEFICIARY,
        WORKFLOW_SUBTYPE.ARCHIVE_BENEFICIARY,
      ],
      requestGroup: REQUEST_GROUP,
      approvalChannel: APPLICATION_CHANNEL,
    };

    const workflowStatus =
      authorisationSearchFormData?.authorisationStatusTab ===
      AuthorisationStatusTab.PendingAuthorisation
        ? [AUTHORISATION_STATUS.PENDING_AUTHORISATION]
        : authorisationSearchFormData?.authorisationStatusTab ===
          AuthorisationStatusTab.RejectedByAuthoriser
        ? [AUTHORISATION_STATUS.REJECTED]
        : [
            AUTHORISATION_STATUS.PENDING_AUTHORISATION,
            AUTHORISATION_STATUS.REJECTED,
          ];

    return authorisationSearchFormData?.authorisationTab ===
      AuthorisationTab.ForYouToAuthorise
      ? {
          searchBy: SearchBy.ApproverAndCreatedOnDateRange,
          approverStatus: workflowStatus,
          workflowStatus,
          createdOnDateRange: convertedDateRange,
          ...baseParams,
        }
      : {
          searchBy: SearchBy.CreatedBy,
          workflowStatus,
          ...baseParams,
        };
  }, [authorisationSearchFormData]);

  const apiTrigger = useMemo(
    () =>
      `${JSON.stringify(
        postBeneficiaryAuthorisationListParams
      )}-${approvalWorkflowTrigger}`,
    [postBeneficiaryAuthorisationListParams, approvalWorkflowTrigger]
  );

  const isLoading = isBeneficiaryAuthorisationFetching || isLoadingWidget;

  useEffect(() => {
    if (
      isBeneficiaryAuthorisationFetching === false &&
      isAuthorisationFetchingError === false
    ) {
      setDateTimeAfterApiSuccess(getFormattedDateTime());
    }
  }, [isBeneficiaryAuthorisationFetching, isAuthorisationFetchingError]);

  useEffect(() => {
    if (
      isBeneficiaryListFetching === false &&
      isBeneficiaryListError === false
    ) {
      setDateTimeAfterApiSuccess(getFormattedDateTime());
    }
  }, [isBeneficiaryListFetching, isBeneficiaryListError]);

  const renderAuthorisationPanelContent = () => {
    if (isLoading) return <PageLoader iconSize="medium" />;

    if (isAuthorisationFetchingError)
      return (
        <ErrorHandler
          onRefresh={onRefresh}
          errorMessage="Something went wrong."
          className="mb-0"
        />
      );
    return (
      <ApprovalWorkflowPanel
        allPostApprovalWorkflowListing={beneficiaryAuthorisationList}
        activeTab={authorisationActiveTab}
        hasApprovalWorkflowListingError={isAuthorisationFetchingError}
        isApprovalWorkflowListingFetching={isBeneficiaryAuthorisationFetching}
        handleRetryApprovalWorkflow={onRefresh}
      />
    );
  };

  const StaffBeneficiaryList = (
    <>
      <BeneficiaryListSearchForm
        handleApplyClick={handleApplyClick}
        control={control}
      />

      <BeneficiaryList
        clearBeneficiaryArchive={clearBeneficiaryArchive}
        beneficiaries={allBeneficiaries}
        isUserAuthorizedToCreateBeneficiaries={
          isUserAuthorizedToCreateBeneficiaries
        }
        isBeneficiaryListFetching={isBeneficiaryListFetching}
        isBeneficiaryListError={isBeneficiaryListError}
        onClickAddBeneficiary={onClickAddBeneficiary}
        onRefresh={onRefresh}
      />
    </>
  );

  return (
    <>
      <div className="mb-0">
        <MVRefresh
          onRefresh={handleRefreshAndHideNotiAlert}
          lastSuccessfulDateTime={dateTimeAfterApiSuccess}
        />
      </div>
      <>
        <NotificationAlert />

        {!isStaffPortal() && (
          <GalaxyMakerCheckerWrapper
            apiName="postApprovalWorkflowList"
            params={{
              query: {
                pageSize: 50, // Changing pagesize to 50 to test performance of ApporvalWorkflowlist API.
              },
              body: postBeneficiaryAuthorisationListParams,
            }}
            trigger={apiTrigger}
            onApiCallUpdate={data => {
              const { isLoading: isFetching } = data;
              setIsBeneficiaryAuthorisationFetching(isFetching);
            }}
            onApiResponse={res => {
              const approvalWorkflowList = (
                res?.data as PostApprovalWorkflowListData
              )?.entities?.approvalWorkflowList;

              if (approvalWorkflowList) {
                const updatedData =
                  mapApprovalWorkflowList(approvalWorkflowList);
                setBeneficiaryAuthorisationList(updatedData);
                setIsAuthorisationFetchingError(false);
              } else {
                console.error(
                  'API Error: error fetching approval workflow list'
                );
                setBeneficiaryAuthorisationList([]);
                setIsAuthorisationFetchingError(true);
              }
            }}
            onApiError={(err: any) => {
              console.error('API Error: error fetching approval workflow list');
              setBeneficiaryAuthorisationList([]);
              setIsAuthorisationFetchingError(true);
            }}
          />
        )}

        <div className="mt-2.5">
          {isStaffPortal() ? (
            StaffBeneficiaryList
          ) : (
            <Tabs
              aria-label="Beneficiaries"
              look="default"
              orientation="horizontal"
              className="border-b-0"
              defaultSelectedKey={activeTab}
              onSelectionChange={handleTabChange}
            >
              <TabsPanel key="beneficiaries_List" title="Beneficiaries list">
                <>
                  <BeneficiaryListSearchForm
                    handleApplyClick={handleApplyClick}
                    control={control}
                  />

                  <BeneficiaryList
                    clearBeneficiaryArchive={clearBeneficiaryArchive}
                    beneficiaries={allBeneficiaries}
                    isUserAuthorizedToCreateBeneficiaries={
                      isUserAuthorizedToCreateBeneficiaries
                    }
                    isBeneficiaryListFetching={
                      isOrgIdFetching || isBeneficiaryListFetching
                    } // isOrgIdFetching is false for non-staff users and true for staff users only if orgId is not present
                    isBeneficiaryListError={isBeneficiaryListError}
                    onClickAddBeneficiary={onClickAddBeneficiary}
                    onRefresh={onRefresh}
                  />
                </>
              </TabsPanel>
              <TabsPanel key="authorisation" title="Authorisations">
                <>
                  <BeneficiaryAuthorisationsSearchSection
                    isApprovalWorkflowListingFetching={
                      isBeneficiaryAuthorisationFetching
                    }
                    authorisationActiveTab={authorisationActiveTab}
                    statusActiveTab={statusActiveTab}
                    authorisationTabOptions={authorisationTabOptions}
                    authorisationStatusOptions={authorisationStatusOptions}
                    onAuthorisationTabChange={
                      handleAuthorisationButtonGroupChange
                    }
                    onStatusChange={handleStatusButtonGroupChange}
                    control={authorisationControl}
                    setError={authorisationSetError}
                    clearErrors={authorisationClearErrors}
                    onAccordionSearch={handleAuthorisationAccordionButtonClick}
                    isTrackAuthorisationTabSelected={
                      isTrackAuthorisationTabSelected
                    }
                  />
                  <div className="pt-2.5">
                    {renderAuthorisationPanelContent()}
                  </div>
                </>
              </TabsPanel>
            </Tabs>
          )}
        </div>
      </>
    </>
  );
}

const mapStateToProps = (state: RootState) => ({
  allBeneficiaries: getAllBeneficiaryList(state),
  isBeneficiaryListFetching: isBeneficiariesFetchingSelector(state),
  isBeneficiaryListError: isBeneficiariesErrorSelector(state),
});

const mapDispatchToProps = {
  getBeneficiaryList:
    beneficiaryListActions.api.expGalaxyBeneficiaryV2.beneficiaryList.post
      .request,
  clearBeneficiaryList:
    beneficiaryListEntityActions.api.expGalaxyBeneficiaryV2.beneficiaryList
      .clear.request,
  clearBeneficiaryArchive:
    beneficiaryArchiveEntityActions.api.expGalaxyBeneficiaryV2
      .beneficiaryArchive.clear.request,
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps, null, {
    context: store.contextRef,
  })
)(BeneficiaryListContainer);
