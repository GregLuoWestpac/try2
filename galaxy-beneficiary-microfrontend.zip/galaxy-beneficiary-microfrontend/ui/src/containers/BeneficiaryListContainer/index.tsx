export { default as BeneficiaryListContainer } from './BeneficiaryListContainer';
