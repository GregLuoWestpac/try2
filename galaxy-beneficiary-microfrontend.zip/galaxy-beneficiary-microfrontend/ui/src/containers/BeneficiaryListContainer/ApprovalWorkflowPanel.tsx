/* eslint-disable react/function-component-definition */
/* eslint-disable consistent-return */
/* eslint-disable react/react-in-jsx-scope */
/* eslint-disable import/no-unresolved */
import { FC } from 'react';
import { Alert, Button } from '@westpac/ui';
import { MVPageLoader as PageLoader } from '@mesh-tenant-multiverse-ui-common/mv-pageloader';
import ApprovalWorkflowTable from './ApprovalWorkflowTable';
import { useWidgetLoaded } from '../../hooks/useWidgetLoaded';
import { ApprovalWorkflowListing } from '../../store/types/ApprovalWorkflowListing';

type ApprovalWorkflowPanelProps = {
  hasApprovalWorkflowListingError: boolean;
  isApprovalWorkflowListingFetching: boolean;
  activeTab: string;
  allPostApprovalWorkflowListing: ApprovalWorkflowListing[];
  handleRetryApprovalWorkflow: () => void;
};

export const ApprovalWorkflowPanel: FC<ApprovalWorkflowPanelProps> = ({
  hasApprovalWorkflowListingError,
  isApprovalWorkflowListingFetching,
  activeTab,
  allPostApprovalWorkflowListing,
  handleRetryApprovalWorkflow,
}) => {
  const [isLoadingWidget] = useWidgetLoaded();

  if (isApprovalWorkflowListingFetching || isLoadingWidget) {
    return <PageLoader iconSize="medium" />;
  }

  if (hasApprovalWorkflowListingError) {
    return (
      <div className="flex justify-center">
        <Alert look="danger" iconSize="small" className="mb-0">
          Something went wrong. Please{' '}
          <Button look="link" soft onClick={handleRetryApprovalWorkflow}>
            try again
          </Button>
          .
        </Alert>
      </div>
    );
  }

  return (
    <ApprovalWorkflowTable
      allPostApprovalWorkflowListing={allPostApprovalWorkflowListing}
      makerCheckerActionToggle={activeTab}
    />
  );
};

export default ApprovalWorkflowPanel;
