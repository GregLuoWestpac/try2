/* eslint-disable react/button-has-type */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-var-requires */
/* eslint-disable react/react-in-jsx-scope */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import '@testing-library/jest-dom';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ApprovalWorkflowListing } from '../../store/types/ApprovalWorkflowListing';
import ApprovalWorkflowTable, {
  ApprovalWorkflowTableProps,
} from './ApprovalWorkflowTable';

const mockHandleRaiseIntent = jest.fn();
const mockUseGlobalDispatch = jest.fn();
const mockUseNavigate = jest.fn();

jest.mock('@mep-ui/framework', () => ({
  useGlobalDispatch: () => mockUseGlobalDispatch,
}));

jest.mock('@mep-ui/framework-router-addon', () => ({
  useNavigate: () => mockUseNavigate,
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-table-v2', () => ({
  CellClickedEventV2: jest.fn(),
  CellKeyDownEventV2: jest.fn(),
  ColDefV2: jest.fn(),
  GetContextMenuItemsParamsV2: jest.fn(),
  MVTableV2: ({
    onCellClicked,
    onCellKeyDown,
    getContextMenuItems,
    rowData,
    ...props
  }: any) => {
    const handleCellClick = () => {
      if (rowData && rowData.length > 0) {
        onCellClicked({ data: rowData[0] });
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (rowData && rowData.length > 0) {
        onCellKeyDown({ data: rowData[0], event });
      }
    };

    const handleContextMenu = () => {
      if (rowData && rowData.length > 0) {
        const menuItems = getContextMenuItems({ node: { data: rowData[0] } });
        // Simulate clicking the first menu item action
        if (menuItems && menuItems.length > 0 && menuItems[0].action) {
          menuItems[0].action();
        }
        return menuItems;
      }
    };

    return (
      <div>
        <button data-testid="cell-click" onClick={handleCellClick}>
          Click Cell
        </button>
        <button
          data-testid="cell-keydown"
          onKeyDown={e => handleKeyDown(e.nativeEvent)}
        >
          Key Down Cell
        </button>
        <button data-testid="context-menu" onClick={handleContextMenu}>
          Context Menu
        </button>
        Mock MVTable
      </div>
    );
  },
  TableDataV2: jest.fn(),
  suppressHeaderKeyboardEventV2: jest.fn(),
  suppressKeyboardEventV2: jest.fn(),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  useHandleRaiseIntent: () => mockHandleRaiseIntent,
}));

jest.mock('./ApprovalWorkflowTable.utils', () => ({
  buildColumnDefs: jest.fn(() => []),
}));

jest.mock('../../common/constants', () => ({
  INTENTS_CONTEXT_NAME: {
    BENEFICIARY: 'fdc3.nothing',
  },
  INTENT_NAMES: {
    VIEW_BENEFICIARY_TASK_DETAILS: 'ViewBeneficiaryTaskDetails',
  },
  PAGE_NAVIGATION: {
    BENEFICIARY_TASK_DETAILS: '/beneficiary/task-details',
  },
  // AUTHORISATION_STATUS: {
  //   PENDING_AUTHORISATION: 'Pending authorisation',
  //   REJECTED: 'Rejected',
  // },
  //  AuthorisationAction: {
  //   ForYouToAuthorise: 'For you to authorise',
  //   TrackAuthorisation: 'Track authorisation',
  // },
  noRowMessage: 'No beneficiaries found',
}));

jest.mock('../../store/types', () => ({
  SearchBy: {
    ApproverAndCreatedOnDateRange: 'ApproverAndCreatedOnDateRange',
    CreatedBy: 'CreatedBy',
  },
}));

// jest.mock('../../store/types/BeneficiaryAuthorisation', () => ({
//   AUTHORISATION_STATUS: {
//     PENDING_AUTHORISATION: 'Pending authorisation',
//     REJECTED: 'Rejected',
//   },
//   AuthorisationTabValues: {
//     ForYouToAuthorise: 'ForYouToAuthorise',
//     TrackAuthorisation: 'TrackAuthorisation',
//   },
// }));

const mockPostApprovalWorkflowListing: ApprovalWorkflowListing[] = [
  {
    id: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
    status: 'Pending authorisation',
    creationDateTime: '2024-08-12T01:00:05.378Z',
    beneficiaryNickname: 'Test Beneficiary',
    authorisationType: '',
    type: '',
    authorisationRequest: '',
    account: {
      accountId: {
        BSB: '',
        accountNumber: '',
      },
      bankName: '',
      accountName: '',
    },
  },
];

const defaultProps: ApprovalWorkflowTableProps = {
  allPostApprovalWorkflowListing: mockPostApprovalWorkflowListing,
  makerCheckerActionToggle: 'ForYouToAuthorise',
};

describe('ApprovalWorkflowTable', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockHandleRaiseIntent.mockResolvedValue(undefined);
  });

  it('renders without crashing', () => {
    const { asFragment } = render(<ApprovalWorkflowTable {...defaultProps} />);
    expect(asFragment()).toMatchSnapshot();
  });

  it('displays MVTable with correct props', () => {
    render(<ApprovalWorkflowTable {...defaultProps} />);
    expect(screen.getByText('Mock MVTable')).toBeInTheDocument();
  });

  it('calls raiseIntentForAction when cell is clicked with ForYouToAuthorise tab', async () => {
    const user = userEvent.setup();
    render(<ApprovalWorkflowTable {...defaultProps} />);

    const cellClickButton = screen.getByTestId('cell-click');
    await user.click(cellClickButton);

    expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
      intentName: 'ViewBeneficiaryTaskDetails',
      intentContextName: 'fdc3.nothing',
      targetPath: '/beneficiary/task-details',
      data: {
        approvalWorkflowId: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
        searchBy: 'ApproverAndCreatedOnDateRange',
      },
      contextKey: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
    });
  });

  it('calls raiseIntentForAction when cell is clicked with TrackAuthorisation tab', async () => {
    const user = userEvent.setup();
    render(
      <ApprovalWorkflowTable
        {...defaultProps}
        makerCheckerActionToggle="TrackAuthorisation"
      />
    );

    const cellClickButton = screen.getByTestId('cell-click');
    await user.click(cellClickButton);

    expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
      intentName: 'ViewBeneficiaryTaskDetails',
      intentContextName: 'fdc3.nothing',
      targetPath: '/beneficiary/task-details',
      data: {
        approvalWorkflowId: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
        searchBy: 'CreatedBy',
      },
      contextKey: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
    });
  });

  it('provides context menu with "View beneficiary details" action for ForYouToAuthorise tab', async () => {
    const user = userEvent.setup();
    render(<ApprovalWorkflowTable {...defaultProps} />);

    const contextMenuButton = screen.getByTestId('context-menu');
    await user.click(contextMenuButton);

    expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
      intentName: 'ViewBeneficiaryTaskDetails',
      intentContextName: 'fdc3.nothing',
      targetPath: '/beneficiary/task-details',
      data: {
        approvalWorkflowId: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
        searchBy: 'ApproverAndCreatedOnDateRange',
      },
      contextKey: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
    });
  });

  it('provides context menu with "View beneficiary details" action for TrackAuthorisation tab', async () => {
    const user = userEvent.setup();
    render(
      <ApprovalWorkflowTable
        {...defaultProps}
        makerCheckerActionToggle="TrackAuthorisation"
      />
    );

    const contextMenuButton = screen.getByTestId('context-menu');
    await user.click(contextMenuButton);

    expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
      intentName: 'ViewBeneficiaryTaskDetails',
      intentContextName: 'fdc3.nothing',
      targetPath: '/beneficiary/task-details',
      data: {
        approvalWorkflowId: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
        searchBy: 'CreatedBy',
      },
      contextKey: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
    });
  });

  it('does not call raiseIntentForAction when workflow has no id', async () => {
    const workflowWithoutId: ApprovalWorkflowListing[] = [
      {
        ...mockPostApprovalWorkflowListing[0],
        id: undefined as any,
      },
    ];

    const user = userEvent.setup();
    render(
      <ApprovalWorkflowTable
        {...defaultProps}
        allPostApprovalWorkflowListing={workflowWithoutId}
      />
    );

    const cellClickButton = screen.getByTestId('cell-click');
    await user.click(cellClickButton);

    expect(mockHandleRaiseIntent).not.toHaveBeenCalled();
  });

  it('handles empty workflow listing', () => {
    render(
      <ApprovalWorkflowTable
        {...defaultProps}
        allPostApprovalWorkflowListing={[]}
      />
    );
    expect(screen.getByText('Mock MVTable')).toBeInTheDocument();
  });

  it('uses correct searchBy value based on authorisation tab', () => {
    const { rerender } = render(<ApprovalWorkflowTable {...defaultProps} />);
    expect(defaultProps.makerCheckerActionToggle).toBe('ForYouToAuthorise');
    rerender(
      <ApprovalWorkflowTable
        {...defaultProps}
        makerCheckerActionToggle="TrackAuthorisation"
      />
    );
    expect(screen.getByText('Mock MVTable')).toBeInTheDocument();
  });

  it('renders table with correct column definitions', () => {
    render(<ApprovalWorkflowTable {...defaultProps} />);
    expect(screen.getByText('Mock MVTable')).toBeInTheDocument();
    // eslint-disable-next-line global-require
    const { buildColumnDefs } = require('./ApprovalWorkflowTable.utils');
    expect(buildColumnDefs).toHaveBeenCalled();
  });
});
