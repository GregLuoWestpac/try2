/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/function-component-definition */
/* eslint-disable @typescript-eslint/no-floating-promises */
import { useGlobalDispatch } from '@mep-ui/framework';
import { useNavigate } from '@mep-ui/framework-router-addon';
import {
  CellClickedEventV2 as CellClickedEvent,
  ColDefV2 as ColDef,
  GetContextMenuItemsParamsV2 as GetContextMenuItemsParams,
  MVTableV2 as MVTable,
  TableDataV2 as TableData,
  onColumnPinnedV2 as onColumnPinned,
  suppressHeaderKeyboardEventV2 as suppressHeaderKeyboardEvent,
  suppressKeyboardEventV2 as suppressKeyboardEvent,
} from '@mesh-tenant-multiverse-ui-common/mv-table-v2';
import { useHandleRaiseIntent } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import React, { useMemo, useRef } from 'react';
import { ActionItem } from '../../common/Beneficiary.util';
import {
  INTENTS_CONTEXT_NAME,
  INTENT_NAMES,
  PAGE_NAVIGATION,
  noRowMessage,
} from '../../common/constants';
import { SearchBy } from '../../store/types';
import { ApprovalWorkflowListing } from '../../store/types/ApprovalWorkflowListing';
import {
  AUTHORISATION_STATUS,
  AuthorisationTabValues,
} from '../../store/types/BeneficiaryAuthorisation';
import { buildColumnDefs } from './ApprovalWorkflowTable.utils';

export type ApprovalWorkflowTableProps = {
  allPostApprovalWorkflowListing: ApprovalWorkflowListing[];
  makerCheckerActionToggle: AuthorisationTabValues | string;
};

const ApprovalWorkflowTable: React.FC<ApprovalWorkflowTableProps> = ({
  allPostApprovalWorkflowListing,
  makerCheckerActionToggle,
}) => {
  const tableContainerRef = useRef<HTMLDivElement>(null);
  const columnDefsMaker = useMemo(() => buildColumnDefs(), []);
  const handleRaiseIntent = useHandleRaiseIntent(
    useGlobalDispatch,
    useNavigate
  );

  const searchBy =
    makerCheckerActionToggle === 'ForYouToAuthorise'
      ? SearchBy.ApproverAndCreatedOnDateRange
      : SearchBy.CreatedBy;

  const raiseIntentForAction = async (
    approvalWorkflowId: string,
    intentName: string,
    targetPath: string
  ) => {
    await handleRaiseIntent({
      intentName,
      intentContextName: INTENTS_CONTEXT_NAME.BENEFICIARY,
      targetPath,
      data: { approvalWorkflowId, searchBy },
      contextKey: approvalWorkflowId,
    });
  };

  const selectWorkflow = async (selectedWorkflow: ApprovalWorkflowListing) => {
    const workflowId = selectedWorkflow?.id;
    if (!workflowId) return;
    await raiseIntentForAction(
      workflowId,
      INTENT_NAMES.VIEW_BENEFICIARY_TASK_DETAILS,
      PAGE_NAVIGATION.BENEFICIARY_TASK_DETAILS
    );
  };

  const getContextMenuItems = (
    params: GetContextMenuItemsParams<TableData>
  ) => {
    const status = params.node?.data?.status;
    const formattedWorkflow = params.node?.data as ApprovalWorkflowListing;

    const actionItemsArray: ActionItem[] = [
      {
        name: 'View beneficiary details',
        cssClasses: ['action-button', 'cursor-pointer'],
        action: async () => {
          await selectWorkflow(formattedWorkflow);
        },
      },
    ];

    if (
      makerCheckerActionToggle === 'ForYouToAuthorise' &&
      status === AUTHORISATION_STATUS.PENDING_AUTHORISATION
    ) {
      actionItemsArray.push({
        name: 'Authorise or reject beneficiary',
        cssClasses: ['action-button', 'cursor-pointer'],
        action: async () => {
          await selectWorkflow(formattedWorkflow);
        },
      });
    }

    return actionItemsArray;
  };

  const defaultColumnDef: ColDef = {
    menuTabs: ['generalMenuTab', 'filterMenuTab', 'columnsMenuTab'],
    filter: 'agTextColumnFilter',
    filterParams: {
      buttons: ['reset'],
      filterOptions: ['contains'],
    },
    minWidth: 119.5,
    suppressKeyboardEvent,
    suppressHeaderKeyboardEvent,
    suppressHeaderContextMenu: true,
    suppressHeaderFilterButton: false,
    suppressHeaderMenuButton: false,
  };

  const onCellClicked = (params: CellClickedEvent<TableData>) => {
    if (params.data) {
      selectWorkflow(params.data as any);
    }
  };

  return (
    <div ref={tableContainerRef}>
      <MVTable
        rowData={allPostApprovalWorkflowListing}
        defaultColumnDef={defaultColumnDef}
        columnDefs={columnDefsMaker}
        enableCellTextSelection
        onCellClicked={onCellClicked}
        onColumnPinned={onColumnPinned}
        noRowMessage={noRowMessage}
        getContextMenuItems={getContextMenuItems as any}
        columnMenu="legacy"
        containerRef={tableContainerRef}
        minHeight={153}
      />
    </div>
  );
};

export default ApprovalWorkflowTable;
