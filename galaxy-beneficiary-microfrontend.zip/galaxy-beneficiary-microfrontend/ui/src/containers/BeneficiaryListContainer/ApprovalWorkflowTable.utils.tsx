/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/restrict-template-expressions */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable react/destructuring-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable react/react-in-jsx-scope */
/* eslint-disable import/no-unresolved */
import {
  COMMON_COLUMN_DEFS,
  CustomCellRendererPropsV2 as CustomCellRendererProps,
  CustomColDef,
} from '@mesh-tenant-multiverse-ui-common/mv-table-v2';
import { formatBSB } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { Badge } from '@westpac/ui';
import {
  formatAuthorisationStatus,
  getFriendlyBeneficiaryStatus,
  mapAuthorisationRequestToWorkflowSubtype,
} from '../../common/Beneficiary.util';
import { AUTHORISATION_STATUS, BENEFICIARY_TYPE } from '../../store/types';

export function StatusBadge(params: CustomCellRendererProps) {
  const { status } = params.data;
  const statusFriendlyValue = getFriendlyBeneficiaryStatus(status);
  return (
    <Badge
      className="break-words whitespace-normal h-auto py-0.5"
      color={statusFriendlyValue.badgeColor}
      soft
    >
      {statusFriendlyValue.text}
    </Badge>
  );
}


const CUSTOM_COMMON_DEFS: { [key: string]: (params?: any) => CustomColDef } =
  Object.fromEntries(
    Object.entries(COMMON_COLUMN_DEFS || {}).map(([key, fn]) => [
      key,
      (params?: any) => ({ ...fn(params) }),
    ])
  ) as { [key: string]: (params?: any) => CustomColDef };

const {
  submittedDate,
  status,
  beneficiaryNickname,
  accountDetails,
  accountName,
  type,
  accListStatus,
  actions,
} = CUSTOM_COMMON_DEFS;

export const buildColumnDefs = (): CustomColDef[] =>
  [
    submittedDate({
      headerName: 'Sent for authorisation',
      minWidth: 120,
      maxWidth: 120,
      width: 120,
      filter: 'agDateColumnFilter',
    }),
    status({
      minWidth: 70,
      maxWidth: 110,
      cellRenderer: StatusBadge,
      filterParams: {
        suppressSelectAll: true,
        values: [
          AUTHORISATION_STATUS.PENDING_AUTHORISATION,
          AUTHORISATION_STATUS.REJECTED,
        ],
        valueFormatter: formatAuthorisationStatus,
      },
      suppressColumnsToolPanel: false,
    }),
    beneficiaryNickname({
      minWidth: 140,
      width: 200,
    }),
    accountDetails({
      minWidth: 140,
      width: 180,
      valueGetter: (params: any) =>
        params.data.account.accountId?.BSB
          ? `${formatBSB(params.data.account.accountId.BSB, 3)} ${
              params.data.account.accountId.accountNumber
            }`
          : `${' '}${params.data.account.payIDValue}`,
    }),

    accountName({
      minWidth: 140,
      width: 180,
      valueGetter: (params: any) =>
        params.data.account.accountName
          ? params.data.account.accountName
          : params.data.account.payIDName,
    }),
    type({
      minWidth: 120,
      width: 100,
      valueGetter: (params: any) =>
        params?.data?.type === BENEFICIARY_TYPE.ACCOUNT
          ? 'BSB & account number'
          : 'PayID',
      filter: 'agSetColumnFilter',
      filterParams: {
        suppressSelectAll: true,
        suppressMiniFilter: true,
      },
    }),
    accListStatus({
      headerName: 'Authorisation request',
      minWidth: 170,
      width: 170,
      valueGetter: (params: any) =>
        mapAuthorisationRequestToWorkflowSubtype(
          params.data.authorisationRequest
        ),
      sortable: true,
      resizable: true,
    }),
    actions({
      minWidth: 80,
      width: 80,
      suppressMovable: false,
      lockPosition: false,
      lockPinned: false,
      menuTabs: ['generalMenuTab'],
      pinned: false,
    }),
  ].map((col, index) => ({ ...col, columnIndex: index } as CustomColDef));