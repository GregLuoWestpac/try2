/* eslint-disable react/react-in-jsx-scope */
import {
  fireEvent,
  screen,
  queryByTestId,
  render,
  renderHook,
  waitFor,
} from '@testing-library/react';
import { useForm } from 'react-hook-form';
import React from 'react';
import BeneficiaryAuthorisationsSearchSection from './BeneficiaryAuthorisationsSearchSection';

// Mock form control and methods
const mockControl = {} as any;
const mockSetError = jest.fn();
const mockClearErrors = jest.fn();

const mockHandleSearch = jest.fn();

const defaultProps = {
  allPostApprovalWorkflowListing: [],
  hasApprovalWorkflowListingError: false,
  isApprovalWorkflowListingFetching: false,
  authorisationActiveTab: 'ForYouToAuthorise',
  statusActiveTab: 'PendingAuthorisation',
  onAuthorisationTabChange: jest.fn(),
  onStatusChange: jest.fn(),
  handleAuthorisationSearchSubmitForm: mockHandleSearch,
  isLoading: false,
  authorisationTabOptions: [],
  authorisationStatusOptions: [],
};

jest.mock('@mesh-tenant-multiverse-ui-common/mv-accordion', () => ({
  MVAccordion: function MockComponent({
    children,
    onButtonClick,
  }: {
    children: React.ReactNode;
    onButtonClick: () => void;
  }) {
    return (
      <div>
        <button onClick={onButtonClick}>Apply</button>
        <div>{children}</div>
      </div>
    );
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  MVDateRangePickerController: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div>{children}</div>;
  },
  getToday: jest.fn(() => ({
    minus: jest.fn(() => ({
      toFormat: jest.fn(() => '09/03/2025'),
    })),
    toFormat: jest.fn(() => '09/03/2025'),
  })),
  getTodayAtLastYear: jest.fn(() => ({
    toFormat: jest.fn(() => '09/03/2024'),
  })),
}));

jest.mock('@westpac/ui', () => ({
  ButtonGroup: function MockComponent({
    onChange,
    label,
  }: {
    onChange?: (value: string) => void;
    label?: string;
  }) {
    return (
      <button
        data-testid={`button-group-${label?.toLowerCase()}`}
        onClick={() => onChange?.('TestValue')}
      >
        {label} Button Group
      </button>
    );
  },
  GridItem: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div>{children}</div>;
  },
}));

describe('Testing BeneficiaryAuthorisationsSearchSection', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render without crashing', () => {
    const { container } = render(
      <BeneficiaryAuthorisationsSearchSection
        {...defaultProps}
        control={mockControl}
        setError={mockSetError}
        clearErrors={mockClearErrors}
        onAccordionSearch={mockHandleSearch}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should call onAccordionSearch when Apply button is clicked', async () => {
    const mockOnAccordionSearch = jest.fn();
    const { getByText } = render(
      <BeneficiaryAuthorisationsSearchSection
        {...defaultProps}
        control={mockControl}
        setError={mockSetError}
        clearErrors={mockClearErrors}
        onAccordionSearch={mockOnAccordionSearch}
      />
    );
    fireEvent.click(getByText('Apply'));
    await waitFor(() => {
      expect(mockOnAccordionSearch).toHaveBeenCalled();
    });
  });

  it('should call onAuthorisationTabChange when Authorisation ButtonGroup is clicked', async () => {
    const mockOnAuthorisationTabChange = jest.fn();
    const { getByTestId } = render(
      <BeneficiaryAuthorisationsSearchSection
        {...defaultProps}
        onAuthorisationTabChange={mockOnAuthorisationTabChange}
        control={mockControl}
        setError={mockSetError}
        clearErrors={mockClearErrors}
        onAccordionSearch={mockHandleSearch}
      />
    );
    fireEvent.click(getByTestId('button-group-authorisation'));
    await waitFor(() => {
      expect(mockOnAuthorisationTabChange).toHaveBeenCalledWith('TestValue');
    });
  });

  it('should call onStatusChange when Status ButtonGroup is clicked', async () => {
    const mockOnStatusChange = jest.fn();
    const { getByTestId } = render(
      <BeneficiaryAuthorisationsSearchSection
        {...defaultProps}
        onStatusChange={mockOnStatusChange}
        control={mockControl}
        setError={mockSetError}
        clearErrors={mockClearErrors}
        onAccordionSearch={mockHandleSearch}
      />
    );
    fireEvent.click(getByTestId('button-group-status'));
    await waitFor(() => {
      expect(mockOnStatusChange).toHaveBeenCalledWith('TestValue');
    });
  });

  it('should render with correct authorisation tab options', () => {
    const authorisationTabOptions = [
      { value: 'ForYouToAuthorise' as const, label: 'For You to Authorise' },
      { value: 'TrackAuthorisation' as const, label: 'Track Authorisation' },
    ];
    const { container } = render(
      <BeneficiaryAuthorisationsSearchSection
        {...defaultProps}
        authorisationTabOptions={authorisationTabOptions}
        control={mockControl}
        setError={mockSetError}
        clearErrors={mockClearErrors}
        onAccordionSearch={mockHandleSearch}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should render with correct status options', () => {
    const authorisationStatusOptions = [
      {
        value: 'PendingAuthorisation' as const,
        label: 'Pending Authorisation',
      },
      { value: 'RejectedByAuthoriser' as const, label: 'Rejected' },
      { value: 'All' as const, label: 'All' },
    ];
    const { container } = render(
      <BeneficiaryAuthorisationsSearchSection
        {...defaultProps}
        authorisationStatusOptions={authorisationStatusOptions}
        control={mockControl}
        setError={mockSetError}
        clearErrors={mockClearErrors}
        onAccordionSearch={mockHandleSearch}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should render MVDateRangePickerController with correct props', () => {
    const { container } = render(
      <BeneficiaryAuthorisationsSearchSection
        {...defaultProps}
        control={mockControl}
        setError={mockSetError}
        clearErrors={mockClearErrors}
        onAccordionSearch={mockHandleSearch}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should display loading state when isApprovalWorkflowListingFetching is true', () => {
    const { container } = render(
      <BeneficiaryAuthorisationsSearchSection
        {...defaultProps}
        isApprovalWorkflowListingFetching
        control={mockControl}
        setError={mockSetError}
        clearErrors={mockClearErrors}
        onAccordionSearch={mockHandleSearch}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should render with different authorisationActiveTab value', () => {
    const { container } = render(
      <BeneficiaryAuthorisationsSearchSection
        {...defaultProps}
        authorisationActiveTab="All"
        control={mockControl}
        setError={mockSetError}
        clearErrors={mockClearErrors}
        onAccordionSearch={mockHandleSearch}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should render with different statusActiveTab value', () => {
    const { container } = render(
      <BeneficiaryAuthorisationsSearchSection
        {...defaultProps}
        statusActiveTab="Authorised"
        control={mockControl}
        setError={mockSetError}
        clearErrors={mockClearErrors}
        onAccordionSearch={mockHandleSearch}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should match snapshot', () => {
    const { container } = render(
      <BeneficiaryAuthorisationsSearchSection
        {...defaultProps}
        control={mockControl}
        setError={mockSetError}
        clearErrors={mockClearErrors}
        onAccordionSearch={mockHandleSearch}
      />
    );
    expect(container).toMatchSnapshot();
  });

  it('should not display date picker when on the Track Authorisations tab', () => {
    const { container } = render(
      <BeneficiaryAuthorisationsSearchSection
        {...defaultProps}
        control={mockControl}
        setError={mockSetError}
        clearErrors={mockClearErrors}
        onAccordionSearch={mockHandleSearch}
        isTrackAuthorisationTabSelected={true}
      />
    );
    expect(container).toBeTruthy();
    expect(screen.queryByTestId('date-range')).not.toBeInTheDocument();
  });
});
