/* eslint-disable import/no-unresolved */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { MVAccordion } from '@mesh-tenant-multiverse-ui-common/mv-accordion';
import { MVDateRangePickerController } from '@mesh-tenant-multiverse-ui-common/mv-reacthookform';
import { ButtonGroup, GridItem } from '@westpac/ui';
import React, { useState } from 'react';
import {
  Control,
  FieldValues,
  UseFormSetError,
  UseFormClearErrors,
} from 'react-hook-form';
import {
  AuthorisationSearchFormType,
  AuthorisationStatusOption,
  AuthorisationTabOption,
} from '../../../store/types';

type Props = {
  isApprovalWorkflowListingFetching: boolean;
  authorisationActiveTab: string;
  statusActiveTab: string;
  onAuthorisationTabChange: (val: string) => void;
  onStatusChange: (val: string) => void;
  authorisationTabOptions: AuthorisationTabOption[];
  authorisationStatusOptions: AuthorisationStatusOption[];
  control: Control<AuthorisationSearchFormType>;
  setError: UseFormSetError<AuthorisationSearchFormType>;
  clearErrors: UseFormClearErrors<AuthorisationSearchFormType>;
  onAccordionSearch: (event: React.MouseEvent) => void;
  isTrackAuthorisationTabSelected?: boolean;
};

export default function BeneficiaryAuthorisationsSearchSection({
  isApprovalWorkflowListingFetching,
  authorisationActiveTab,
  statusActiveTab,
  onAuthorisationTabChange,
  onStatusChange,
  authorisationTabOptions,
  authorisationStatusOptions,
  control,
  setError,
  clearErrors,
  onAccordionSearch,
  isTrackAuthorisationTabSelected
}: Props) {
  const [isAccordionExpanded, setIsAccordionExpanded] = useState(true);
  return (
    <MVAccordion
      isExpanded={isAccordionExpanded}
      onToggle={setIsAccordionExpanded}
      onButtonClick={onAccordionSearch}
      loading={isApprovalWorkflowListingFetching}
    >
      <GridItem span={12} className="w-fit -mb-2">
        <ButtonGroup
          look="hero"
          size="small"
          label="Authorisation"
          value={authorisationActiveTab}
          buttons={authorisationTabOptions}
          onChange={onAuthorisationTabChange}
        />
      </GridItem>
      <GridItem span={12} className="w-fit -mb-2">
        <ButtonGroup
          look="hero"
          size="small"
          label="Status"
          value={statusActiveTab}
          buttons={authorisationStatusOptions}
          onChange={onStatusChange}
        />
      </GridItem>
      {/* ART-97614 - 400 error code received on approvalWorkflowList API due to date picker */}
      {/* Don't display date picker for maker-side display (Track Authorisations) */}
      {!isTrackAuthorisationTabSelected &&
        <GridItem span={12} className="w-fit">
          <MVDateRangePickerController
            data-testid="date-range"
            fieldName="dateRange"
            control={control as unknown as Control<FieldValues>}
            setError={setError}
            clearErrors={clearErrors}
          />
        </GridItem>
      }
    </MVAccordion>
  );
}
