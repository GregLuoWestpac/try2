// Temporary debug test
const { BENEFICIARY_TYPE } = require('./ui/src/store/types/Beneficiary.ts');

console.log('BENEFICIARY_TYPE.ACCOUNT:', BENEFICIARY_TYPE.ACCOUNT);
console.log('Type of BENEFICIARY_TYPE.ACCOUNT:', typeof BENEFICIARY_TYPE.ACCOUNT);

const beneficiaryAccount = {
  id: 'd0868661-b955-4e76-9f15-d97626f7d78b',
  type: BENEFICIARY_TYPE.ACCOUNT,
};

console.log('beneficiaryAccount.type:', beneficiaryAccount.type);
console.log('beneficiaryAccount.type === BENEFICIARY_TYPE.ACCOUNT:', beneficiaryAccount.type === BENEFICIARY_TYPE.ACCOUNT);

// Test the conditional logic
const watchBeneficiaryType = undefined; // As it would be on first render
const beneficiaryType = watchBeneficiaryType || beneficiaryAccount.type || BENEFICIARY_TYPE.ACCOUNT;

console.log('Final beneficiaryType:', beneficiaryType);
console.log('beneficiaryType evaluates to truthy:', !!beneficiaryType);
