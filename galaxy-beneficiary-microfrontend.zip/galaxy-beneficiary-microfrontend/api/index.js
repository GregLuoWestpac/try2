/* eslint-disable import/no-unresolved */
/* eslint-disable import/extensions */
/* eslint-disable global-require */
const concurrently = require('concurrently');
const { RUNTIME } = require('@mep-node/framework-constants');

if (RUNTIME.isLocal()) {
  concurrently(['npm run start-mock', 'npm run dev']);
} else {
  require('./build/api/index.js');
}
