export interface CreateBeneficiariesData {
  entities?: {
    beneficiaryCreate?: ({
      /**
       * Unique id for the beneficiary.
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * External id for the beneficiary, used for cross-system references.
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      externalId?: string;
      /**
       * Beneficiary Nickname
       * @minLength 1
       * @maxLength 70
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "John"
       */
      nickname?: string;
      /**
       * Status; example-> ACTIVE, INACTIVE
       * @example "ACTIVE"
       */
      status?: "ACTIVE" | "INACTIVE";
      /** A qualified amount and denomination of a monetary value. */
      currencyAmount?: {
        /** A positive or negative number string of up to four decimal places (including zero). Must have at least one digit after the decimal point. */
        amount?: string;
        /**
         * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
         * @pattern ^[A-Z]{3}$
         * @example "AUD"
         */
        currencyCode: string;
      };
      /**
       * CIS Key of the organisation
       * @pattern ^\d{11}$
       * @example "06089457589"
       */
      org?: string;
      /**
       * Beneficiary account type either Pay id or BSB & Account number
       * @example "BSB_ACCOUNT_NUMBER"
       */
      type?: "PAYID" | "BSB_ACCOUNT_NUMBER";
      /**
       * Unique payment identifier for end-to-end transaction tracking and reconciliation.
       * @maxLength 35
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "INV-123456790"
       */
      reference?: string;
      /**
       * Represents Account detail object
       * @example {"accountId":{"accountNumber":"01235674897","BSB":"035845"},"accountName":"Apple Tree","bankName":"Westpac Banking Corporation"}
       */
      account?:
        | {
            /**
             * Account ID (BSB and Account Number)
             * @example {"BSB":"035845","accountNumber":"10235674897"}
             */
            accountId: {
              /**
               * Bank State Branch Number
               * @pattern ^\d{6}$
               * @example "035845"
               */
              BSB: string;
              /**
               * Account Number
               * @minLength 6
               * @maxLength 28
               * @pattern ^[a-zA-Z\d.]+$
               * @example "01235674897"
               */
              accountNumber: string;
            };
            /**
             * Account Name
             * @minLength 1
             * @maxLength 140
             * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
             * @example "Apple Tree"
             */
            accountName: string;
            /**
             * Name of Bank
             * @minLength 1
             * @maxLength 70
             * @pattern ^[\w ]+$
             * @example "Westpac Banking Corporation"
             */
            bankName: string;
          }
        | (
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Email address.
                 * @example "EMAL"
                 */
                payIDType: "EMAL";
                /**
                 * PAY ID value representing an Email address
                 * @minLength 5
                 * @maxLength 256
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "john.doe@example.com"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing a Telephone number.
                 * @example "TELI"
                 */
                payIDType: "TELI";
                /**
                 * PAY ID value representing a Telephone number
                 * @minLength 2
                 * @maxLength 30
                 * @pattern ^\+([1-9]{1}[0-9]{1,2})[-]{0,1}[0-9]+$
                 * @example "+61412345678"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Organisation ID.
                 * @example "ORGN"
                 */
                payIDType: "ORGN";
                /**
                 * PAY ID value representing an Organisation number
                 * @minLength 2
                 * @maxLength 256
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "ORG-12345"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Australian Business Number (ABN).
                 * @example "AUBN"
                 */
                payIDType: "AUBN";
                /**
                 * PAY ID value representing an Australian Business Number (ABN)
                 * @minLength 9
                 * @maxLength 11
                 * @pattern ^\d+$
                 * @example "12345678910"
                 */
                payIDValue: string;
              }
          );
    } & {
      /**
       * CIS Key of the organisation
       * @pattern ^\d{11}$
       * @example "06089457589"
       */
      org?: string;
      /**
       * Beneficiary status; example-> ACTIVE, ARCHIVED, ON-HOLD
       * @example "ACTIVE"
       */
      status?: "ACTIVE" | "ARCHIVED" | "ON-HOLD";
    })[];
  };
  /** @example {"beneficiaryCreate":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    beneficiaryCreate?: string[];
  };
}

export interface RetrieveBeneficiariesData {
  entities?: {
    beneficiaryList?: ({
      /**
       * Unique id for the beneficiary.
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * External id for the beneficiary, used for cross-system references.
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      externalId?: string;
      /**
       * Beneficiary Nickname
       * @minLength 1
       * @maxLength 70
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "John"
       */
      nickname?: string;
      /**
       * Status; example-> ACTIVE, INACTIVE
       * @example "ACTIVE"
       */
      status?: "ACTIVE" | "INACTIVE";
      /** A qualified amount and denomination of a monetary value. */
      currencyAmount?: {
        /** A positive or negative number string of up to four decimal places (including zero). Must have at least one digit after the decimal point. */
        amount?: string;
        /**
         * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
         * @pattern ^[A-Z]{3}$
         * @example "AUD"
         */
        currencyCode: string;
      };
      /**
       * CIS Key of the organisation
       * @pattern ^\d{11}$
       * @example "06089457589"
       */
      org?: string;
      /**
       * Beneficiary account type either Pay id or BSB & Account number
       * @example "BSB_ACCOUNT_NUMBER"
       */
      type?: "PAYID" | "BSB_ACCOUNT_NUMBER";
      /**
       * Unique payment identifier for end-to-end transaction tracking and reconciliation.
       * @maxLength 35
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "INV-123456790"
       */
      reference?: string;
      /**
       * Represents Account detail object
       * @example {"accountId":{"accountNumber":"01235674897","BSB":"035845"},"accountName":"Apple Tree","bankName":"Westpac Banking Corporation"}
       */
      account?:
        | {
            /**
             * Account ID (BSB and Account Number)
             * @example {"BSB":"035845","accountNumber":"10235674897"}
             */
            accountId: {
              /**
               * Bank State Branch Number
               * @pattern ^\d{6}$
               * @example "035845"
               */
              BSB: string;
              /**
               * Account Number
               * @minLength 6
               * @maxLength 28
               * @pattern ^[a-zA-Z\d.]+$
               * @example "01235674897"
               */
              accountNumber: string;
            };
            /**
             * Account Name
             * @minLength 1
             * @maxLength 140
             * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
             * @example "Apple Tree"
             */
            accountName: string;
            /**
             * Name of Bank
             * @minLength 1
             * @maxLength 70
             * @pattern ^[\w ]+$
             * @example "Westpac Banking Corporation"
             */
            bankName: string;
          }
        | (
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Email address.
                 * @example "EMAL"
                 */
                payIDType: "EMAL";
                /**
                 * PAY ID value representing an Email address
                 * @minLength 5
                 * @maxLength 256
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "john.doe@example.com"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing a Telephone number.
                 * @example "TELI"
                 */
                payIDType: "TELI";
                /**
                 * PAY ID value representing a Telephone number
                 * @minLength 2
                 * @maxLength 30
                 * @pattern ^\+([1-9]{1}[0-9]{1,2})[-]{0,1}[0-9]+$
                 * @example "+61412345678"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Organisation ID.
                 * @example "ORGN"
                 */
                payIDType: "ORGN";
                /**
                 * PAY ID value representing an Organisation number
                 * @minLength 2
                 * @maxLength 256
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "ORG-12345"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Australian Business Number (ABN).
                 * @example "AUBN"
                 */
                payIDType: "AUBN";
                /**
                 * PAY ID value representing an Australian Business Number (ABN)
                 * @minLength 9
                 * @maxLength 11
                 * @pattern ^\d+$
                 * @example "12345678910"
                 */
                payIDValue: string;
              }
          );
    } & {
      /**
       * CIS Key of the organisation
       * @pattern ^\d{11}$
       * @example "06089457589"
       */
      org?: string;
      /**
       * Beneficiary status; example-> ACTIVE, ARCHIVED, ON-HOLD
       * @example "ACTIVE"
       */
      status?: "ACTIVE" | "ARCHIVED" | "ON-HOLD";
    })[];
    paging?: {
      /**
       * Paging Unique Id
       * @maxLength 3
       * @pattern ^\d+$
       * @example "1"
       */
      id?: string;
      /**
       * Number of items per page
       * @format int32
       * @example 50
       */
      pageSize?: number;
      /**
       * Total number of items available
       * @format int32
       * @example 160
       */
      count?: number;
      /**
       * Key for start of previous page
       * @maxLength 3
       * @pattern ^\d+$
       * @example "0"
       */
      previousPageKey?: string;
      /**
       * Key for start of next page
       * @maxLength 3
       * @pattern ^\d+$
       * @example "2"
       */
      nextPageKey?: string;
      /**
       * Indicator to show if there are more items available. If true, more records are available (by narrowing search parameters)
       * @example true
       */
      moreItems?: boolean;
    }[];
  };
  /** @example {"beneficiaryList":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    beneficiaryList?: string[];
  };
}

export interface UpdateBeneficiaryData {
  entities?: {
    beneficiaryUpdate?: ({
      /**
       * Unique id for the beneficiary.
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * External id for the beneficiary, used for cross-system references.
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      externalId?: string;
      /**
       * Beneficiary Nickname
       * @minLength 1
       * @maxLength 70
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "John"
       */
      nickname?: string;
      /**
       * Status; example-> ACTIVE, INACTIVE
       * @example "ACTIVE"
       */
      status?: "ACTIVE" | "INACTIVE";
      /** A qualified amount and denomination of a monetary value. */
      currencyAmount?: {
        /** A positive or negative number string of up to four decimal places (including zero). Must have at least one digit after the decimal point. */
        amount?: string;
        /**
         * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
         * @pattern ^[A-Z]{3}$
         * @example "AUD"
         */
        currencyCode: string;
      };
      /**
       * CIS Key of the organisation
       * @pattern ^\d{11}$
       * @example "06089457589"
       */
      org?: string;
      /**
       * Beneficiary account type either Pay id or BSB & Account number
       * @example "BSB_ACCOUNT_NUMBER"
       */
      type?: "PAYID" | "BSB_ACCOUNT_NUMBER";
      /**
       * Unique payment identifier for end-to-end transaction tracking and reconciliation.
       * @maxLength 35
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "INV-123456790"
       */
      reference?: string;
      /**
       * Represents Account detail object
       * @example {"accountId":{"accountNumber":"01235674897","BSB":"035845"},"accountName":"Apple Tree","bankName":"Westpac Banking Corporation"}
       */
      account?:
        | {
            /**
             * Account ID (BSB and Account Number)
             * @example {"BSB":"035845","accountNumber":"10235674897"}
             */
            accountId: {
              /**
               * Bank State Branch Number
               * @pattern ^\d{6}$
               * @example "035845"
               */
              BSB: string;
              /**
               * Account Number
               * @minLength 6
               * @maxLength 28
               * @pattern ^[a-zA-Z\d.]+$
               * @example "01235674897"
               */
              accountNumber: string;
            };
            /**
             * Account Name
             * @minLength 1
             * @maxLength 140
             * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
             * @example "Apple Tree"
             */
            accountName: string;
            /**
             * Name of Bank
             * @minLength 1
             * @maxLength 70
             * @pattern ^[\w ]+$
             * @example "Westpac Banking Corporation"
             */
            bankName: string;
          }
        | (
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Email address.
                 * @example "EMAL"
                 */
                payIDType: "EMAL";
                /**
                 * PAY ID value representing an Email address
                 * @minLength 5
                 * @maxLength 256
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "john.doe@example.com"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing a Telephone number.
                 * @example "TELI"
                 */
                payIDType: "TELI";
                /**
                 * PAY ID value representing a Telephone number
                 * @minLength 2
                 * @maxLength 30
                 * @pattern ^\+([1-9]{1}[0-9]{1,2})[-]{0,1}[0-9]+$
                 * @example "+61412345678"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Organisation ID.
                 * @example "ORGN"
                 */
                payIDType: "ORGN";
                /**
                 * PAY ID value representing an Organisation number
                 * @minLength 2
                 * @maxLength 256
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "ORG-12345"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Australian Business Number (ABN).
                 * @example "AUBN"
                 */
                payIDType: "AUBN";
                /**
                 * PAY ID value representing an Australian Business Number (ABN)
                 * @minLength 9
                 * @maxLength 11
                 * @pattern ^\d+$
                 * @example "12345678910"
                 */
                payIDValue: string;
              }
          );
    } & {
      /**
       * CIS Key of the organisation
       * @pattern ^\d{11}$
       * @example "06089457589"
       */
      org?: string;
      /**
       * Beneficiary status; example-> ACTIVE, ARCHIVED, ON-HOLD
       * @example "ACTIVE"
       */
      status?: "ACTIVE" | "ARCHIVED" | "ON-HOLD";
    })[];
  };
  /** @example {"beneficiaryUpdate":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    beneficiaryUpdate?: string[];
  };
}

export interface RetrieveBeneficiaryData {
  entities?: {
    beneficiaryDetails?: ({
      /**
       * Unique id for the beneficiary.
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * External id for the beneficiary, used for cross-system references.
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      externalId?: string;
      /**
       * Beneficiary Nickname
       * @minLength 1
       * @maxLength 70
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "John"
       */
      nickname?: string;
      /**
       * Status; example-> ACTIVE, INACTIVE
       * @example "ACTIVE"
       */
      status?: "ACTIVE" | "INACTIVE";
      /** A qualified amount and denomination of a monetary value. */
      currencyAmount?: {
        /** A positive or negative number string of up to four decimal places (including zero). Must have at least one digit after the decimal point. */
        amount?: string;
        /**
         * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
         * @pattern ^[A-Z]{3}$
         * @example "AUD"
         */
        currencyCode: string;
      };
      /**
       * CIS Key of the organisation
       * @pattern ^\d{11}$
       * @example "06089457589"
       */
      org?: string;
      /**
       * Beneficiary account type either Pay id or BSB & Account number
       * @example "BSB_ACCOUNT_NUMBER"
       */
      type?: "PAYID" | "BSB_ACCOUNT_NUMBER";
      /**
       * Unique payment identifier for end-to-end transaction tracking and reconciliation.
       * @maxLength 35
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "INV-123456790"
       */
      reference?: string;
      /**
       * Represents Account detail object
       * @example {"accountId":{"accountNumber":"01235674897","BSB":"035845"},"accountName":"Apple Tree","bankName":"Westpac Banking Corporation"}
       */
      account?:
        | {
            /**
             * Account ID (BSB and Account Number)
             * @example {"BSB":"035845","accountNumber":"10235674897"}
             */
            accountId: {
              /**
               * Bank State Branch Number
               * @pattern ^\d{6}$
               * @example "035845"
               */
              BSB: string;
              /**
               * Account Number
               * @minLength 6
               * @maxLength 28
               * @pattern ^[a-zA-Z\d.]+$
               * @example "01235674897"
               */
              accountNumber: string;
            };
            /**
             * Account Name
             * @minLength 1
             * @maxLength 140
             * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
             * @example "Apple Tree"
             */
            accountName: string;
            /**
             * Name of Bank
             * @minLength 1
             * @maxLength 70
             * @pattern ^[\w ]+$
             * @example "Westpac Banking Corporation"
             */
            bankName: string;
          }
        | (
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Email address.
                 * @example "EMAL"
                 */
                payIDType: "EMAL";
                /**
                 * PAY ID value representing an Email address
                 * @minLength 5
                 * @maxLength 256
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "john.doe@example.com"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing a Telephone number.
                 * @example "TELI"
                 */
                payIDType: "TELI";
                /**
                 * PAY ID value representing a Telephone number
                 * @minLength 2
                 * @maxLength 30
                 * @pattern ^\+([1-9]{1}[0-9]{1,2})[-]{0,1}[0-9]+$
                 * @example "+61412345678"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Organisation ID.
                 * @example "ORGN"
                 */
                payIDType: "ORGN";
                /**
                 * PAY ID value representing an Organisation number
                 * @minLength 2
                 * @maxLength 256
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "ORG-12345"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Australian Business Number (ABN).
                 * @example "AUBN"
                 */
                payIDType: "AUBN";
                /**
                 * PAY ID value representing an Australian Business Number (ABN)
                 * @minLength 9
                 * @maxLength 11
                 * @pattern ^\d+$
                 * @example "12345678910"
                 */
                payIDValue: string;
              }
          );
    } & {
      /**
       * CIS Key of the organisation
       * @pattern ^\d{11}$
       * @example "06089457589"
       */
      org?: string;
      /**
       * Beneficiary status; example-> ACTIVE, ARCHIVED, ON-HOLD
       * @example "ACTIVE"
       */
      status?: "ACTIVE" | "ARCHIVED" | "ON-HOLD";
    })[];
  };
  /** @example {"beneficiaryDetails":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    beneficiaryDetails?: string[];
  };
}

export interface ArchiveBeneficiariesData {
  entities?: {
    beneficiaryArchive?: {
      /**
       * unique id for the beneficiary
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id: string;
    }[];
  };
  /** @example {"beneficiaryArchive":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    beneficiaryArchive?: string[];
  };
}

export type UpdateBeneficiaryStatusData = any;

export interface PostAliasLookupData {
  entities?: {
    aliasLookup?: {
      /**
       * A unique id generated for a lookup result which is the mode of communication between the UI and Exp API
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * Alias Type of the beneficiary
       * @maxLength 4
       */
      aliasType?: "EMAL" | "TELI" | "AUBN" | "ORGN";
      /**
       * Nickname of the beneficiary
       * @minLength 1
       * @maxLength 70
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "John"
       */
      name?: string;
      /**
       * The date/time when the alias was resolved.
       * @format date-time
       */
      resolutionDateTime?: string;
      /**
       * The response code mapped from the provider service.
       * @minLength 1
       * @maxLength 5
       * @pattern ^[0-9]+$
       * @example 200
       */
      returnCode?: any;
    }[];
  };
  /** @example {"aliasLookup":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    aliasLookup?: string[];
  };
}

export interface GetBsbLookupData {
  entities?: {
    bsbLookup?: {
      /**
       * A unique id generated for a lookup result which is the mode of communication between the UI and Exp API
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * Represents the branch Id for which the reference data is to be retrieved
       * @minLength 1
       * @maxLength 30
       * @pattern ^[\w ]+$
       * @example "501226"
       */
      branchId?: string;
      /**
       * Bank State Branch Number
       * @pattern ^\d{6}$
       * @example "035845"
       */
      BSB?: string;
      /**
       * Name of the Branch
       * @minLength 1
       * @maxLength 70
       * @pattern ^[\w ]+$
       * @example "Central"
       */
      branchName?: string;
      /**
       * Name of the Bank
       * @minLength 1
       * @maxLength 70
       * @pattern ^[\w ]+$
       * @example "Central Bank"
       */
      bankName?: string;
      /**
       * Branch Identification code
       * @minLength 1
       * @maxLength 70
       * @pattern ^[\w ]+$
       * @example "03"
       */
      bankCode?: string;
      /**
       * A set of available predefined values representing the label names used by Westpac for its products and services
       * @example "WBC"
       */
      brand?: "WBC" | "SGB" | "BOM" | "BSA";
      /**
       * Status of the Branch
       * @example "OPERATIONAL"
       */
      branchStatus?: "OPERATIONAL" | "CLOSED";
      /**
       * Branch Available indicate if the BSB is valid for origination
       * @example true
       */
      branchAvailable?: boolean;
      /** Address of the Branch */
      address?: {
        /**
         * First line of the address
         * @minLength 1
         * @maxLength 100
         * @pattern ^[\w ]+$
         * @example "123 Main St"
         */
        addressLine1?: string;
        /**
         * Second line of the address
         * @minLength 0
         * @maxLength 100
         * @pattern ^[\w ]+$
         * @example "Suite 456"
         */
        addressLine2?: string;
        /**
         * City of the address
         * @minLength 1
         * @maxLength 50
         * @pattern ^[\w ]+$
         * @example "Sydney"
         */
        city?: string;
        /**
         * State of the address
         * @minLength 1
         * @maxLength 50
         * @pattern ^[\w ]+$
         * @example "NSW"
         */
        state?: string;
        /**
         * Postal code of the address
         * @minLength 4
         * @maxLength 10
         * @pattern ^[\d]+$
         * @example "2000"
         */
        postCode?: string;
      };
    }[];
  };
  /** @example {"bsbLookup":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    bsbLookup?: string[];
  };
}

export interface GetDivisionListData {
  entities?: {
    divisionList?: ({
      /**
       * Division Name
       * @maxLength 70
       * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
       * @example "AUD Group"
       */
      divisionName?: string;
      /**
       * Division id
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      divisionId?: string;
    } & {
      /**
       * A unique identifier
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
    })[];
  };
  /** @example {"divisionList":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    divisionList?: string[];
  };
}

export interface PostAccountNameCheckData {
  entities?: {
    accountNameCheck?: ({
      /**
       * A unique id generated for an entity which is the mode of communication between the UI and Exp API, via redux store
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       * @example "d0868661-b955-4e76-9f15-d97626f7df6b"
       */
      id?: string;
    } & {
      /**
       * Account Name
       * @minLength 1
       * @maxLength 140
       * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
       * @example "Apple Tree"
       */
      matchedCOPAccountName?: string;
      /**
       * ERDM encoded value
       * @pattern ^V[012AET]C[1-8]$
       * @example "V0C1"
       */
      matchedCOPStatusCode?: string;
      /**
       * PAYEE_NAME_CHECK_COLOUR value
       * @example "Blue"
       */
      matchedCOPColour?: "Blue" | "Amber" | "Red";
    })[];
  };
  /** @example {"accountNameCheck":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    accountNameCheck?: string[];
  };
}

/** healthcheck status */
export interface GetHealthCheckStatusData {
  status?: "success";
}
