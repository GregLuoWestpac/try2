/** Alias Resolution Request */
export interface AliasResolutionRequest {
  /**
   * Participants.BIC or Participants.Addressing Sponsor (in the Reference data) BIC8 given by the BO and used to pick up the corresponding sign DN.
   * @maxLength 8
   * @pattern ^[A-Z]{6,6}[A-Z2-9][A-NP-Z0-9]$
   */
  authBIC8?: string;
  /**
   * Specifies the Identifier that is linked to this Alias. Contains the actual value for the supplied type, so an email address, a phone number, ABN and organisation identifier. On the organisation identifier. The Identifier must be representative of the company name, organisation name, trading name, associated product, campaign or an identifier recognisable as associated with the specific business or organisation.
   * @maxLength 256
   * @pattern ^[\d@a-zA-Z0-9!#$%&'*+/=?^_`{|}~\.\x20-\x7E\+\-]+$
   */
  aliasId: string;
  aliasType: 'TELI' | 'EMAL' | 'AUBN' | 'ORGN';
}

/** Alias Resolution Request */
export interface AliasResolutionResponse {
  data?: {
    /** Contains the type of Alias Identifier. E.g. an email, a phone number or an Australian Business Number.(Reference ERD PaymentAliasIdentifierType) */
    aliasType?: string;
    /** Alias name by which a party is known and which is usually used to identify that party. */
    name?: string;
    /**
     * Date and time when PayId was resolved.
     * @format date-time
     */
    resolutionDateTime?: string;
    /** Full Legal Name of the Account Owner, defined by the Account Servicer */
    legalName?: string;
    /** Response code mapped from the provider service. */
    returnCode?: string;
  };
}
