/** healthcheck status */
export interface HealthCheckStatus {
  status?: 'success';
}

/** The details of the colocation branch and its individual branches. */
export interface ColocationBranch {
  /**
   * Unique identifier to find colocation details
   * @pattern ^[a-zA-Z0-9-_]{1,5}$
   * @example 123
   */
  colocationId?: string;
  /**
   * Colocation types; allowed values are DUAL,BIAB,SINGLE,DESTINATION (eg.DUAL)
   * @example "DUAL"
   */
  branchColocationType?: 'DUAL' | 'BIAB' | 'SINGLE' | 'DESTINATION';
  /** Single cash queue available-Yes or No */
  hasSCQ?: boolean;
  /**
   * Date of last update of colocation table.
   * @format date
   */
  lastUpdatedDate?: string;
  /**
   * @maxItems 2
   * @minItems 2
   */
  colocationBranches?: ColocationBranchDetail[];
}

/** Details of the branch for a given colocation id. */
export interface ColocationBranchDetail {
  /**
   * Westpac or other partners of Westpac group
   * @pattern ^[a-zA-Z0-9-_]{1,5}$
   * @example "WBC"
   */
  bankType?: string;
  /**
   * Value of branch ID
   * @example 192879
   */
  branchId?: string;
  /**
   * Role of branch in colocation; Host(H) or Partner(P)
   * @example "Host"
   */
  bankRole?: 'Host' | 'Partner';
  /**
   * This is the virtual cash drawer ID in Spider application for SCQ branches
   * @pattern ^[a-zA-Z0-9-_]{1,3}$
   */
  bankCashDrawer?: string;
}

export interface GetResponseColocationBranches {
  /** The details of the colocation branch and its individual branches. */
  data?: ColocationBranch;
}

export interface BranchResponse {
  data?: Branches;
}

export interface Branches {
  /** BranchData */
  branches?: BranchData;
}

/** BranchData */
export type BranchData = Branch[];

export interface Branch {
  /** Branch ID */
  branchId?: string;
  /** BSB */
  BSB?: string;
  /** Branch Name */
  branchName?: string;
  /** Bank Name */
  bankName?: string;
  /** Bank Identification Code (eg. 03) */
  bankCode?: string;
  /** A set of available predefined values representing the label names used by Westpac for its products and services. (eg. WBC) */
  brand?: 'WBC' | 'SGB' | 'BOM' | 'BSA';
  /** Branch Status */
  branchStatus?: 'OPERATIONAL' | 'CLOSED';
  /**
   * Branch Available indicate if the BSB is valid for origination
   * @default false
   */
  branchAvailable?: boolean;
  address?: Address;
}

export interface Address {
  /** addressLine1 */
  addressLine1?: string;
  /** addressLine2 */
  addressLine2?: string;
  /** city */
  city?: string;
  /** state */
  state?: string;
  /** postCode */
  postCode?: string;
}

/** Represents an individual error */
export interface Error {
  /**
   * Error Code
   * @format int32
   */
  code?: number;
  /** Error Message */
  message?: string;
  /** Comma separated list of fields, which caused the error condition */
  details?: string;
}
