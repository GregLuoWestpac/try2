/** Represents Beneficiary Response Object */
export interface BeneficiaryResponse {
  /**
   * unique id for the beneficiary
   * @minLength 0
   * @maxLength 50
   * @pattern ^[a-zA-Z0-9]+$
   * @example "123456789"
   */
  id?: string;
  /**
   * external id for the beneficiary
   * @minLength 0
   * @maxLength 50
   * @pattern ^[a-zA-Z0-9]+$
   * @example "123456789"
   */
  externalId?: string;
  /**
   * nickname for the beneficiary
   * @minLength 0
   * @maxLength 40
   * @example "office 1"
   */
  nickname?: string;
  /**
   * AUD
   * @minLength 0
   * @maxLength 3
   * @example "abc"
   */
  currency?: string;
  /**
   * org for the beneficiary
   * @minLength 0
   * @maxLength 50
   * @pattern ^[a-zA-Z0-9]+$
   * @example "office1"
   */
  org?: string;
  /** Represents Account detail object */
  account?: Account;
}

/** Represents Beneficiary Request Object */
export interface BeneficiaryRequest {
  /**
   * nickname for the beneficiary
   * @minLength 0
   * @maxLength 20
   * @pattern ^[a-zA-Z0-9\s]+$
   * @example "office 1"
   */
  nickname?: string;
  /**
   * currency used for the beneficiary
   * @minLength 0
   * @maxLength 3
   * @pattern ^([a-zA-Z])+$
   * @example "AUD"
   */
  currency?: string;
  /**
   * Name of Organisation
   * @minLength 0
   * @maxLength 50
   * @pattern ^([a-zA-Z])+$
   * @example "office"
   */
  org?: string;
  /** Represents Account detail object */
  account?: Account;
}

/** Represents Beneficiary Request Object */
export interface BeneficiaryUpdateRequest {
  /**
   * unique id for the beneficiary
   * @minLength 0
   * @maxLength 50
   * @pattern ^[a-zA-Z0-9]+$
   * @example "123456789"
   */
  id?: string;
  /**
   * external id for the beneficiary
   * @minLength 0
   * @maxLength 50
   * @pattern ^[a-zA-Z0-9]+$
   * @example "123456789"
   */
  externalId?: string;
  /**
   * nickname for the beneficiary
   * @minLength 0
   * @maxLength 20
   * @pattern ^[a-zA-Z0-9\s]+$
   * @example "office 1"
   */
  nickname?: string;
  /**
   * currency used for the beneficiary
   * @minLength 0
   * @maxLength 3
   * @pattern ^([a-zA-Z])+$
   * @example "AUD"
   */
  currency?: string;
  /**
   * Name of Organisation
   * @minLength 0
   * @maxLength 50
   * @pattern ^([a-zA-Z])+$
   * @example "office"
   */
  org?: string;
  /** Represents Account detail object */
  account?: Account;
}

/** Represents Account detail object */
export type Account = Bsb | PayID;

/** Represents Account detail object */
export interface Bsb {
  /**
   * bsb for the account
   * @minLength 0
   * @maxLength 6
   * @pattern ^[0-9]+$
   * @example "123456"
   */
  bsb?: string;
  /**
   * name of the account
   * @minLength 0
   * @maxLength 40
   * @example "payee 1"
   */
  accountName?: string;
  /**
   * account number
   * @minLength 0
   * @maxLength 20
   * @pattern ^[0-9]+$
   * @example "123456789"
   */
  accountNumber?: string;
}

/** Represents Account detail object */
export interface PayID {
  /**
   * alias type for the PayID, either email / phone / orgId / bsb
   * @minLength 0
   * @maxLength 20
   * @example "123456789"
   */
  payIDType?: string;
  /**
   * pay id name returned from the alias resolution
   * @minLength 0
   * @maxLength 256
   * @example "123456789"
   */
  payIDName?: string;
  /**
   * alias id for the PayID, either email / phone / orgId / bsb
   * @minLength 0
   * @maxLength 256
   * @example "123456789"
   */
  payIDValue?: string;
}

/** Represent an individual error. */
export interface Error {
  /**
   * Error Code.
   * @format int32
   */
  code: number;
  /** Error Message */
  message: string;
  /** Detailed information about the error */
  details?: string;
}
