/**
 * Payee Services API v1.1.1
 * Confirmation of Payee (COP) Services
 */

// ============ Enums ============

export type CustomerType = 'Individual' | 'Organisation';

export type COPStatusCode = 'Opt-In' | 'Opt-Out';

export type ArrangementStatus = 'Active' | 'Inactive';

export type BrandSilo = 'WPAC' | 'SGBBSA' | 'RAMS';

export type XUserIdScheme =
  | 'StaffSalaryNumber'
  | 'CustomerInternalId'
  | 'CustomerNumber'
  | 'SystemProcess'
  | 'CorporateUserId'
  | 'ProspectId';

export type CustomerIdScheme =
  | 'CustomerInternalId'
  | 'CustomerNumber'
  | 'PartyUID'
  | 'ExternalSystemCustomerId';

export type ViewType = 'summary' | 'detailed';

export type ArrangementRoleTypeFilter = 'OwnersOnly' | 'OwnersAndNonOwners';

export type OptOutReasonCode = 'COP001001' | 'COP001002';

export type OptInAllowedReasonCode =
  | 'OPTIN_TO_OPTIN_NOT_ALLOWED'
  | 'OPTOUT_TO_OPTIN_ALLOWED_FOR_INDV_NO_RESTRICTIONS';

export type OptOutAllowedReasonCode =
  | 'OPTIN_TO_OPTOUT_ALLOWED_FOR_INDV_ONLY'
  | 'OPTOUT_TO_OPTOUT_NOT_ALLOWED'
  | 'OPTIN_TO_OPTOUT_NOT_ALLOWED_WITHIN_N_DAYS_OF_LAST_OPT_IN'
  | 'OPTIN_TO_OPTOUT_ALLOWED_FOR_GREATER_THAN_N_DAYS_OF_LAST_OPT_IN';

export type StaffOverrideAllowedReasonCode =
  | 'NOT_ALLOWED'
  | 'OPTOUT_STAFF_ALLOWED_TO_OVERRIDE_DATE_RANGE_RESTRICTIONS';

export type CustomerAccountType = 'INDV' | 'NIND';

export type AccountCOPStatusShort = 'ACTV' | 'OOUT';

// ============ Common Schemas ============

/** Unique identifier for creditor or debtor party which is combination of BSB and account number */
export interface AccountId {
  /**
   * Unique identifier within a bank to identify creditor or debtor party
   * @example "345623189665"
   */
  accountNumber?: string;
  /**
   * A six-digit code used to identify the specific branch
   * @maxLength 6
   * @example "037724"
   */
  BSB?: string;
}

/** Account ID for requests - requires BSB */
export interface AccountIdRequest {
  /**
   * Unique identifier within a bank to identify creditor or debtor party
   * @example "345623189665"
   */
  accountNumber?: string;
  /**
   * A six-digit code used to identify the specific branch
   * @maxLength 6
   * @example "037724"
   */
  BSB: string;
}

/** Opt-out reason details */
export interface OptOutReason {
  /** Standard value which uniquely identifies Opt-Out reasons */
  code: OptOutReasonCode;
  /**
   * Description of the opt-out reason
   * @example "CoP opt-out as I am concerned about my name being shared"
   */
  description?: string;
}

/** Detailed information of Customer who operates their account as an Individual entity */
export interface IndividualPartyName {
  /** Prefix or salutation used by customer with their name */
  prefix?: {
    /**
     * Standard value to uniquely identify prefix of a name
     * @example "Mr."
     */
    code: string;
    /**
     * Detailed description of the prefix
     * @example "Mister"
     */
    description?: string;
  };
  /**
   * First name of Customer or Account Holder
   * @example "Paul"
   */
  firstName?: string;
  /**
   * Last name of Customer or Account Holder
   * @example "Walker"
   */
  lastName?: string;
  /**
   * Full name of Customer or Account Holder
   * @example "Paul Walker"
   */
  fullName?: string;
}

/** Detailed information of Customer where account belongs to a business entity or Organisation */
export interface OrganisationPartyName {
  /**
   * Name through which an Organisation identifies
   * @example "Sydney Swimmers Pvt Ltd"
   */
  name?: string;
}

/** Customer or Account-Holder name information */
export interface COPName {
  individual?: IndividualPartyName;
  organisation?: OrganisationPartyName;
}

/** Westpac Internal Role defined for an Arrangement */
export interface ArrangementRole {
  /** Detailed information about Arrangement Role */
  type?: {
    /**
     * Standard value which uniquely identifies arrangement role
     * @example "SOL"
     */
    code: string;
    /**
     * Detailed description of arrangement role
     * @example "Sole Trader"
     */
    description?: string;
  };
  /** Detailed information about Arrangement Role Status */
  status?: {
    /** Standard value which uniquely identifies arrangement role status */
    code: 'Active' | 'Inactive';
    /**
     * Detailed description of arrangement role status
     * @example "Active"
     */
    description?: string;
  };
}

/** Product information */
export interface Product {
  /**
   * Key/Name of the product in GCM
   * @maxLength 256
   * @example "7dc53df5703e49b38670b1c468f47f1f"
   */
  gcmProductKey?: string;
  /**
   * Product Short Name
   * @maxLength 30
   * @example "Westpac Student Reward Saver"
   */
  shortName?: string;
  /**
   * Product Long Name
   * @maxLength 60
   * @example "Westpac Choice eAccount"
   */
  longName?: string;
  /**
   * Product family name
   * @maxLength 256
   * @example "Consumer Savings"
   */
  productFamily?: string;
  /**
   * Digital Product Group
   * @maxLength 256
   * @example "TermDeposit"
   */
  digitalProductGroup?: string;
}

/** Westpac internal identifier through which customer or its account identifies within Organisation */
export interface Arrangement {
  /**
   * Unique identifier for a customer within Westpac internal systems
   * @example "5163213095118684"
   */
  arrangementId?: string;
  accountId?: AccountId;
  /**
   * Canonical Product Code of the product associated with a Customer
   * @example "7dc53df5703e49b38670b1c468f47f1f"
   */
  canonicalProductCode?: string;
  arrangementRole?: ArrangementRole;
  /** Current status of an Arrangement */
  status?: ArrangementStatus;
  /** Defines whether Arrangement can perform Confirmation-Of-Payee Services */
  isEligibleForCOPServices?: boolean;
  /**
   * Current Confirmation-Of-Payee services opted by an Arrangement
   * @example "Opt-In"
   */
  accountCOPStatus?: COPStatusCode;
  /**
   * Nick name associated with Customer Account
   * @example "Nick"
   */
  nickName?: string;
  /**
   * Alias name associated with Customer Account
   * @example "Sydney Swimmers Pvt Ltd"
   */
  aliasName?: string;
  /**
   * Short name associated with Customer Account
   * @example "SS Pvt Ltd"
   */
  shortName?: string;
  /**
   * Legal name associated with Customer Account
   * @example "Sydney Swimmers"
   */
  legalName?: string;
  product?: Product;
}

/** Response structure for Arrangement */
export interface ArrangementResponse {
  /**
   * Unique identifier for a customer within Westpac internal systems
   * @example "5163213095118684"
   */
  arrangementId: string;
  /**
   * Start time of the Arrangement
   * @format date-time
   */
  startDateTime?: string;
  /**
   * End time of the Arrangement
   * @format date-time
   */
  endDateTime?: string;
  accountId?: AccountId;
  /**
   * Canonical Product Code of the product associated with a Customer
   * @example "7dc53df5703e49b38670b1c468f47f1f"
   */
  canonicalProductCode: string;
  /** Current status of an Arrangement */
  status?: ArrangementStatus;
  /** Defines whether Arrangement can perform Confirmation-Of-Payee Services */
  isEligibleForCOPServices?: boolean;
  /**
   * Current Confirmation-Of-Payee services opted by an Arrangement
   * @example "Opt-In"
   */
  accountCOPStatus?: COPStatusCode;
}

/** Arrangement request for eligibility check */
export interface ArrangementRequest {
  /**
   * Unique identifier for a customer within Westpac internal systems
   * @example "5163213095118684"
   */
  arrangementId: string;
  accountId?: AccountIdRequest;
  /**
   * Canonical Product Code of the product associated with a Customer
   * @example "7dc53df5703e49b38670b1c468f47f1f"
   */
  canonicalProductCode: string;
}

/** Indicates whether Customer is allowed to Initiate Opt-In in future */
export interface OptInEligibility {
  /** Indicates whether customer can avail Opt-In Service */
  isAllowed: boolean;
  /** Detailed information in case customer chose Opt-In */
  allowedReason?: {
    /** Standard value which uniquely identifies why Opt-In is allowed or not allowed */
    code: OptInAllowedReasonCode;
    /** Detailed description */
    description?: string;
  };
}

/** Indicates whether Customer is allowed to Initiate Opt-Out in future */
export interface OptOutEligibility {
  /**
   * Number of days for which Customer is restricted to perform opt-out operation
   * @example 60
   */
  restrictedDuration: number;
  /** Indicates whether customer can avail Opt-Out Service */
  isAllowed: boolean;
  /** Detailed information in case customer chose Opt-out */
  allowedReason?: {
    /** Standard value which uniquely identifies why Opt-Out is allowed or not allowed */
    code: OptOutAllowedReasonCode;
    /** Detailed description */
    description?: string;
  };
}

/** Indicates whether Staff is allowed to update the confirmation-of-payee status */
export interface StaffOverrideEligibility {
  /** Indicates whether Staff can update the Confirmation-of-Payee services on behalf of Customer */
  isAllowed: boolean;
  /** Detailed information in case Staff is performing Confirmation-of-Payee-Operations */
  allowedReason?: {
    /** Standard value which uniquely identifies Staff Overridden reasons */
    code: StaffOverrideAllowedReasonCode;
    /** Detailed description */
    description?: string;
  };
}

/** Contains detailed information of current confirmation-of-payee status */
export interface COPStatusDetails {
  /** Information about current status for confirmation-of-payee Opt-In and Opt-Out services */
  currentStatusCode?: COPStatusCode;
  /** Indicates whether this is a Default time Opt-in */
  isFirstOperation?: boolean;
  optOutReason?: OptOutReason;
}

/** COP Preference information */
export interface COPPreference {
  type: COPStatusCode;
  optOutReason?: OptOutReason;
}

/** COP Preference status response */
export interface COPPreferenceStatus {
  currentStatusCode: COPStatusCode;
  previousStatusCode?: COPStatusCode;
}

/** Matched status for account name check */
export interface MatchedStatus {
  /**
   * ERDM encoded value
   * @maxLength 4
   * @example "V0C1"
   */
  code: string;
  /**
   * Detailed description of ERDM encode
   * @example "A match response was returned by Verify+ and CoP"
   */
  description?: string;
}

/** Error for partial success responses */
export interface ErrorPartialSuccess {
  /**
   * Error Code
   * @example 1007
   */
  code?: number;
  /**
   * Error Message
   * @example "Arrangement not found"
   */
  message?: string;
  /**
   * Detailed information about the error
   * @example "Arrangement not found for given Arrangement Identifier"
   */
  details?: string;
  /** Correlation key */
  correlationKey?: {
    /**
     * Full account number including BSB or Account Number or Credit Card number
     * @example "5163213095118684"
     */
    arrangementId?: string;
    /**
     * Canonical Product Code of the product
     * @minLength 32
     * @maxLength 32
     * @example "7dc53df5703e49b38670b1c468f47f1f"
     */
    canonicalProductCode?: string;
  };
}

/** Payee information for account name check */
export interface Payee {
  /**
   * Payee Known name
   * @minLength 1
   * @maxLength 140
   * @example "Paul Walker"
   */
  name: string;
  /**
   * Unique identifier to credit card held by a customer (usually 16 digits)
   * @maxLength 16
   * @example "3456007816789067"
   */
  creditCardNumber?: string;
  /** Unique identifier to identify creditor or debtor party */
  accountId?: {
    /**
     * Unique identifier within a bank to identify creditor or debtor party
     * @pattern ^[ -~]{1,34}$
     * @example "345623189665"
     */
    accountNumber: string;
    /**
     * A six-digit code used to identify the specific branch
     * @maxLength 6
     * @example "037724"
     */
    BSB: string;
  };
}

/** Payer information */
export interface Payer {
  /**
   * Payer's Bank Identifier Code
   * @pattern ^[A-Z0-9]{4,4}[A-Z]{2,2}[A-Z0-9]{2,2}[A-Z0-9]{3,3}$
   * @example "WPACAU2SXXX"
   */
  BIC: string;
}

/** COP Preferred Names */
export interface COPPreferredNames {
  /**
   * Customer Account Name
   * @minLength 1
   * @maxLength 140
   * @example "PAUL WALKER & SALLY WALKER"
   */
  accountName: string;
  /** Account AKA Names */
  accountAKANames?: Array<{
    /** @maxLength 140 */
    AKAName?: string;
  }>;
  /**
   * Customer Name
   * @maxLength 140
   * @example "PAUL WALKER"
   */
  customerName?: string;
}

// ============ Request Types ============

/** Request to create or update the confirmation-of-payee preference */
export interface COPPreferenceRequest {
  COPPreference: COPPreference;
  /** Indicates whether this is a Default first time Opt-in Customer */
  isFirstOperation?: boolean;
  /** Indicates whether COP preferences are chosen by Staff on behalf of customer */
  isStaffOverride?: boolean;
}

/** Confirmation of Payee Account eligibility Request */
export interface PostAccountEligibilityRequest {
  /** Arrangement list for eligibility check */
  arrangements: ArrangementRequest[];
}

/** Request for account name check */
export interface AccountNameCheckRequest {
  /**
   * Unique Random number generated by the source to identify Verify+ request
   * @maxLength 32
   * @example "ac7012c489d643f077cb6b21154588ad"
   */
  transactionId: string;
  payee: Payee;
  payer?: Payer;
}

/** Request for preferred names */
export interface COPPreferredNamesRequest {
  /** Account details */
  account: {
    /**
     * Unique identifier within a bank to identify creditor or debtor party
     * @pattern ^[ -~]{1,8}$
     * @example "12345678"
     */
    accountNumber: string;
    /**
     * A six-digit code used to identify the specific branch
     * @maxLength 6
     * @example "062000"
     */
    BSB: string;
  };
  /** Customer details for preferred names lookup */
  customer: {
    /**
     * Unique identifier to identify Customer within Westpac group
     * @example "00542728151"
     */
    id: string;
    /** The scheme (type) applicable for the Customer identifier */
    idScheme: CustomerIdScheme;
    /** Customer type */
    customerType: CustomerType;
  };
}

// ============ Response Types ============

/** Get COP Information Response */
export interface GetCOPInformationResponse {
  data?: {
    customerType?: CustomerType;
    COPStatus?: COPStatusDetails;
    optInEligibility?: OptInEligibility;
    optOutEligibility?: OptOutEligibility;
    staffOverrideEligibility?: StaffOverrideEligibility;
    COPName?: COPName;
    /** List of arrangements associated with a Customer or Account-holder */
    COPArrangements?: Arrangement[];
  };
}

/** Get COP Preference Response */
export interface GetCOPPreferenceResponse {
  data?: {
    COPStatus?: COPStatusDetails;
    optInEligibility?: OptInEligibility;
    optOutEligibility?: OptOutEligibility;
    staffOverrideEligibility?: StaffOverrideEligibility;
  };
}

/** Post COP Preference Response */
export interface PostCOPPreferenceResponse {
  data?: {
    customerType: CustomerType;
    COPPreferenceStaus: COPPreferenceStatus;
  };
}

/** Get COP Account List Response */
export interface GetCOPAccountListResponse {
  data?: {
    /** List of arrangements associated with a Customer or Account-holder */
    COPArrangements?: Arrangement[];
  };
}

/** Post Account Eligibility Response */
export interface PostAccountEligibilityResponse {
  data?: {
    /** List of arrangements associated with a Customer or Account-holder */
    arrangements?: ArrangementResponse[];
  };
  result?: {
    errors?: ErrorPartialSuccess[];
  };
}

/** Get Payee Name Response */
export interface GetPayeeNameResponse {
  data?: {
    customer?: COPName;
  };
}

/** Account Name Check Response */
export interface AccountNameCheckResponse {
  data: {
    /**
     * Payee Known name
     * @minLength 1
     * @maxLength 140
     * @example "Paul Walker"
     */
    matchedAccountName?: string;
    matchedStatus?: MatchedStatus;
  };
}

/** COP Preferred Names Response */
export interface COPPreferredNamesResponse {
  data: {
    /** Type of the Account which a customer holds */
    customerAccountType: CustomerAccountType;
    /** Account COP status */
    accountCOPStatus: AccountCOPStatusShort;
    COPPrefferedNames: COPPreferredNames;
  };
}

// ============ Error Response ============

/** Standard Error Response */
export interface ErrorResponse {
  result?: {
    errors?: Array<{
      code?: number;
      message?: string;
      details?: string;
    }>;
  };
}
