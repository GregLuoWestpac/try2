import { PdpQueryResult } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

export interface PdpQueryApiResponse {
  data: {
    requestId: string;
    timeStamp: string;
    deploymentPackageId: string;
    elapsedTime: number;
    results: PdpQueryResult[];
  };
}
