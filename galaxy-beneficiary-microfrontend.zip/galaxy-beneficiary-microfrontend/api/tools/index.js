const defaultPackageScripts = require('./common-scripts');

module.exports = {
  defaultPackageScripts,
};