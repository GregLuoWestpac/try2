const fs = require('fs');
const path = require('path');
const newman = require('newman');
const propertiesParser = require('properties-file');

const [hostname] = process.argv.slice(2);
const { log } = console;

(async () => {
  const file = fs.readFileSync(
    path.join(
      path.dirname(require.main.filename),
      '../api-tests/token.properties'
    ),
    'utf8'
  );
  const userCredentials = propertiesParser.parse(file);
  const postmanVars =
    (userCredentials &&
      Object.keys(userCredentials).map(key => ({
        key,
        value: `Bearer ${userCredentials[key]}`,
        description: key,
        type: 'text',
        enabled: true,
      }))) ||
    [];

  newman.run(
    {
      // eslint-disable-next-line global-require
      collection: require(`../api-tests/default/idempotent_tests_postman_collection.json`),
      reporters: 'cli',
      environment: {
        id: '4d8a1864-96ec-d01a-2663-440e70ee9d15',
        name: 'TEST',
        values: [
          ...postmanVars,
          {
            key: 'hostname',
            value: hostname,
            description: 'hostname',
            type: 'text',
            enabled: true,
          },
        ],
      },
      iterationCount: 1,
      insecure: true,
    },
    err => {
      if (err) {
        throw err;
      }
      log('collection run complete!');
    }
  );
})();