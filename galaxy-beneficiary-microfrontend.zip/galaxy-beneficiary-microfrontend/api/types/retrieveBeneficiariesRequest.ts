export type RetrieveBeneficiariesRequest = {
  ids: string[];
  query?: string;
  statuses? : ('ACTIVE' | 'ARCHIVED' | 'ON-HOLD')[];
};