export type accountNameCheckRequest = {
  payee: {
    accountName: string;
    accountId: {
      accountNumber: string;
      BSB: string;
    };
  };
};
