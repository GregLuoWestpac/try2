import '@mep-node/framework-constants';

declare module '@mep-node/framework-constants' {
  namespace ALLOWED_COOKIES {
    const W1AddnAuthorisation: string;
  }
}
