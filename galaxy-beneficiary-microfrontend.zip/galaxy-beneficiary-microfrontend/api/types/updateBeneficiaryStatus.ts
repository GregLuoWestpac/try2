export type UpdateBeneficiaryStatusData = {
  beneficiary: {
    /**
     * unique id for the beneficiary
     */
    id: string;
    /**
     * status of the beneficiary
     */
    status: 'ACTIVE' | 'ARCHIVED' | 'ON-HOLD';
  };
};
