/* eslint-disable node/no-missing-require */
const path = require('path');
const { ApiProvider, RUNTIME } = require('@mep-node/framework');
const {
  AuthDevMiddleware,
  AuthSSOMiddleware,
} = require('@mep-node/framework-auth-z-addon');

// NOTE:  run -> npm run routes to generate routes folder based on the openapi spec
const routes = require('../generated/routes');

const {
  AuthenticateTokenMiddleware,
} = require('./middleware/tokenValidationMiddleware');

// Can also be called with openapi_ref.yaml if the project
// uses dereferenced openapi specifications

// The routes variable corresponds to the generated
// expressJS routes from the generated/routes folder

// const someMiddleware = require('./from/some/local/path');
// const createSomeMiddlewareWithOptions = require('./from/some/path');

(async () => {
  const invocationPath = process.env.API_INVOCATION_PATH || './';
  const openapiPath = path.join(invocationPath, './openapi.yaml');

  const provider = new ApiProvider(openapiPath, routes);

  const { api } = await provider.initialise();
  // to be injected only for local testing, for env inject AuthSSOMiddleware
  if (RUNTIME.isLocal()) {
    api.registerMiddleware(AuthDevMiddleware);
  } else {
    api.registerMiddleware(AuthenticateTokenMiddleware);
    api.registerMiddleware(AuthSSOMiddleware);
  }

  // api.registerMiddleware(someMiddleware);
  // api.registerMiddleware(createSomeMiddlewareWithOptions({ Config }));

  provider.start();
})();
