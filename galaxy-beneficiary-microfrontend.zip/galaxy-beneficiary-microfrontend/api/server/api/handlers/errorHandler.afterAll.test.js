const httpMocks = require('node-mocks-http');
const handler = require('./errorHandler.afterAll');

const mockLogger = {
  trace: jest.fn(),
  info: jest.fn(),
  debug: jest.fn(),
  error: jest.fn(),
};

describe('errorHandler.afterAll', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should handle error with logger in res.locals', () => {
    const req = httpMocks.createRequest({
      swagger: {
        operation: { operationId: 'testOperationId' },
      },
    });
    const res = httpMocks.createResponse({
      locals: {
        logger: mockLogger,
      },
    });
    const next = jest.fn();
    const error = new Error('Test error');

    handler(error, req, res, next);

    expect(res.statusCode).toEqual(500);
    expect(mockLogger.error).toHaveBeenCalledTimes(2);
    expect(mockLogger.error).toHaveBeenCalledWith(
      '[ testOperationId ] —— Caught error thrown in afterAllErrorHandler'
    );
    expect(mockLogger.error).toHaveBeenCalledWith({ err: error });

    // Verify the response status is set to 500
    expect(res.statusCode).toEqual(500);

    // Verify that res.send was called (which sets the response body)
    expect(res.finished).toBe(true);
  });

  it('should handle error when logger is not provided (fallback to console)', () => {
    const req = httpMocks.createRequest({
      swagger: {
        operation: { operationId: 'fallbackOperationId' },
      },
    });
    const res = httpMocks.createResponse({
      locals: {}, // No logger provided
    });
    const next = jest.fn();
    const error = new Error('Fallback error');

    // Mock console to capture fallback behavior
    const originalConsoleError = console.error;
    console.error = jest.fn();

    handler(error, req, res, next);

    expect(res.statusCode).toEqual(500);
    expect(console.error).toHaveBeenCalledTimes(2);
    expect(console.error).toHaveBeenCalledWith(
      '[ fallbackOperationId ] —— Caught error thrown in afterAllErrorHandler'
    );
    expect(console.error).toHaveBeenCalledWith({ err: error });

    // Verify the response status is set to 500
    expect(res.statusCode).toEqual(500);

    // Verify that res.send was called (which sets the response body)
    expect(res.finished).toBe(true);

    // Restore original console.error
    console.error = originalConsoleError;
  });

  it('should handle error when res.locals is undefined', () => {
    const req = httpMocks.createRequest({
      swagger: {
        operation: { operationId: 'undefinedLocalsOperation' },
      },
    });
    const res = httpMocks.createResponse();
    // res.locals will be undefined by default
    const next = jest.fn();
    const error = new Error('Undefined locals error');

    // Mock console to capture fallback behavior
    const originalConsoleError = console.error;
    console.error = jest.fn();

    handler(error, req, res, next);

    expect(res.statusCode).toEqual(500);
    expect(console.error).toHaveBeenCalledTimes(2);
    expect(console.error).toHaveBeenCalledWith(
      '[ undefinedLocalsOperation ] —— Caught error thrown in afterAllErrorHandler'
    );
    expect(console.error).toHaveBeenCalledWith({ err: error });

    // Restore original console.error
    console.error = originalConsoleError;
  });

  it('should handle different types of errors', () => {
    const req = httpMocks.createRequest({
      swagger: {
        operation: { operationId: 'stringErrorOperation' },
      },
    });
    const res = httpMocks.createResponse({
      locals: {
        logger: mockLogger,
      },
    });
    const next = jest.fn();
    const stringError = 'String error message';

    handler(stringError, req, res, next);

    expect(res.statusCode).toEqual(500);
    expect(mockLogger.error).toHaveBeenCalledTimes(2);
    expect(mockLogger.error).toHaveBeenCalledWith(
      '[ stringErrorOperation ] —— Caught error thrown in afterAllErrorHandler'
    );
    expect(mockLogger.error).toHaveBeenCalledWith({ err: stringError });
  });

  it('should handle null or undefined errors', () => {
    const req = httpMocks.createRequest({
      swagger: {
        operation: { operationId: 'nullErrorOperation' },
      },
    });
    const res = httpMocks.createResponse({
      locals: {
        logger: mockLogger,
      },
    });
    const next = jest.fn();

    handler(null, req, res, next);

    expect(res.statusCode).toEqual(500);
    expect(mockLogger.error).toHaveBeenCalledTimes(2);
    expect(mockLogger.error).toHaveBeenCalledWith(
      '[ nullErrorOperation ] —— Caught error thrown in afterAllErrorHandler'
    );
    expect(mockLogger.error).toHaveBeenCalledWith({ err: null });
  });

  it('should extract operationId from swagger operation', () => {
    const req = httpMocks.createRequest({
      swagger: {
        operation: { operationId: 'extractedOperationId' },
      },
    });
    const res = httpMocks.createResponse({
      locals: {
        logger: mockLogger,
      },
    });
    const next = jest.fn();
    const error = new Error('Operation ID test');

    handler(error, req, res, next);

    expect(mockLogger.error).toHaveBeenCalledWith(
      '[ extractedOperationId ] —— Caught error thrown in afterAllErrorHandler'
    );
  });
});
