const afterAllErrorHandler = require('./errorHandler.afterAll');
const afterAllSuccessHandler = require('./successHandler.afterAll');

module.exports = [afterAllErrorHandler, afterAllSuccessHandler];