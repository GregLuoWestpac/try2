module.exports = function afterAllErrorHandler(err, req, res, next) {
  const {
    swagger: {
      operation: { operationId },
    },
  } = req;

  const {
    locals: { logger = console },
  } = res;

  logger.error(
    `[ ${operationId} ] —— Caught error thrown in afterAllErrorHandler`
  );
  logger.error({ err });

  res.status(500).send({
    errors: [
      {
        code: 10000,
        message: 'Internal Server Error',
        details: 'Please check application logs for details',
      },
    ],
  });
};