module.exports = function afterAllSuccessHandler(req, res, next) {
  const { logger } = res.locals;
  logger.trace(`Success handler :: after all`);
  next();
};