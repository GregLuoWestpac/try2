const handlers = require('./index');
const afterAllErrorHandler = require('./errorHandler.afterAll');
const afterAllSuccessHandler = require('./successHandler.afterAll');

describe('handlers/index.js', () => {
  it('should export an array of handlers', () => {
    expect(Array.isArray(handlers)).toBe(true);
    expect(handlers).toHaveLength(2);
  });

  it('should export afterAllErrorHandler as the first element', () => {
    expect(handlers[0]).toBe(afterAllErrorHandler);
  });

  it('should export afterAllSuccessHandler as the second element', () => {
    expect(handlers[1]).toBe(afterAllSuccessHandler);
  });

  it('should export handlers in the correct order', () => {
    expect(handlers).toEqual([afterAllErrorHandler, afterAllSuccessHandler]);
  });

  it('should export functions that can be called', () => {
    expect(typeof handlers[0]).toBe('function');
    expect(typeof handlers[1]).toBe('function');
  });

  it('should maintain references to the original handlers', () => {
    // Verify that the exported handlers are exactly the same as the imported ones
    expect(handlers[0]).toStrictEqual(afterAllErrorHandler);
    expect(handlers[1]).toStrictEqual(afterAllSuccessHandler);
  });

  it('should export error handler with correct function signature', () => {
    const errorHandler = handlers[0];
    // Error handlers should have 4 parameters (err, req, res, next)
    expect(errorHandler.length).toBe(4);
  });

  it('should export success handler with correct function signature', () => {
    const successHandler = handlers[1];
    // Success handlers should have 3 parameters (req, res, next)
    expect(successHandler.length).toBe(3);
  });

  it('should not modify the original handlers when accessing from export', () => {
    const originalErrorHandler = afterAllErrorHandler;
    const originalSuccessHandler = afterAllSuccessHandler;

    // Access handlers from the export
    const [exportedErrorHandler, exportedSuccessHandler] = handlers;

    // Verify originals are unchanged
    expect(afterAllErrorHandler).toBe(originalErrorHandler);
    expect(afterAllSuccessHandler).toBe(originalSuccessHandler);
    expect(exportedErrorHandler).toBe(originalErrorHandler);
    expect(exportedSuccessHandler).toBe(originalSuccessHandler);
  });

  it('should export immutable array structure', () => {
    const originalLength = handlers.length;
    const originalFirst = handlers[0];
    const originalSecond = handlers[1];

    // The exported array should maintain its structure
    expect(handlers.length).toBe(originalLength);
    expect(handlers[0]).toBe(originalFirst);
    expect(handlers[1]).toBe(originalSecond);
  });
});
