const httpMocks = require('node-mocks-http');
const handler = require('./successHandler.afterAll');

const logger = {
  trace: () => {},
  info: () => {},
  debug: () => {},
  error: () => {},
};

describe('successHandler.afterAll', () => {
  const req = httpMocks.createRequest();
  const res = httpMocks.createResponse({
    locals: {
      logger,
    },
  });
  const next = jest.fn();

  it('should have called next method', () => {
    handler(req, res, next);
    expect(next).toHaveBeenCalled();
  });
});