import { jwtDecode, TokenValidationPayload } from '../../utils/jwt';

const AuthenticateTokenMiddleware = (req, res, next) => {
  const { logger } = res.locals || {};

  if (req?.originalUrl.endsWith('/healthcheck')) {
    logger?.info(`Req originalUrl is healthcheck: ${req?.originalUrl}`);
    return next();
  }

  try {
    logger?.info(`Req header host: ${req?.headers?.host}`);
    const authHeader = req?.headers['authorization'];
    if (!authHeader) {
      const missingAuthHeaderError = {
        msg: 'Access token required, missing Authorization header',
      };
      logger?.error(missingAuthHeaderError);
      return res.status(401).json({ error: 'Access token required' });
    }

    const trimmedHeader = authHeader.trim();
    if (!trimmedHeader.startsWith('Bearer ')) {
      const missingTokenError = {
        msg: 'Access token required, malformed Authorization header',
      };
      logger?.error(missingTokenError);
      return res.status(401).json({ error: 'Access token required' });
    }

    const token = trimmedHeader.substring(7).trim();
    if (!token) {
      const missingTokenError = {
        msg: 'Access token required, missing Bearer token',
      };
      logger?.error(missingTokenError);
      return res.status(401).json({ error: 'Access token required' });
    }

    const decodedToken = jwtDecode<TokenValidationPayload>(token);
    if (!decodedToken) {
      const missingDecodedTokenError = {
        msg: 'Unauthorized',
      };
      logger?.error(missingDecodedTokenError);
      return res.status(401).json(missingDecodedTokenError);
    }

    // Check if this is a staff token - staff tokens have resource_uri and employeeID fields
    const resourceUri = decodedToken?.resource_uri;

    const urlObj = new URL(resourceUri);
    const targetPath = req?.originalUrl.split('?')[0];
    const trimmedUrlPathName = urlObj?.pathname.replace(
      /\/(staff|customer)/,
      ''
    );

    logger?.info(`originalUrl: ${targetPath}`);
    logger?.info(`Resource Uri: ${resourceUri}`);
    logger?.info(`UrlObj pathname: ${urlObj?.pathname}`);
    logger?.info(`trimmedUrlPathName: ${trimmedUrlPathName}`);
    logger?.info(`audience: ${decodedToken?.aud}`);

    if (!trimmedUrlPathName?.includes(targetPath)) {
      logger?.info(`Req target path mismatch: ${targetPath}`);
      const invalidTokenError = {
        msg: 'Unauthorized',
      };
      logger?.error(invalidTokenError);
      return res.status(401).json(invalidTokenError);
    } else {
      logger?.info('Auth token is valid');
      return next();
    }
  } catch (error) {
    const tokenDecodeError = {
      msg: 'Failed to decode token, error',
      error: error?.message,
    };
    logger?.error(tokenDecodeError);
    return res.status(401).json({ error: 'Unauthorized' });
  }
};

export { AuthenticateTokenMiddleware };
