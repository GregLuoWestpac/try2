import { DownstreamServiceResponseData } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { RetrieveBeneficiaryData } from '../../../interfaces/models/galaxyBeneficiaryExp';

export type ExpApiResponseData = RetrieveBeneficiaryData['entities'];

export const transformDownstreamResponseToUi = (
  response: DownstreamServiceResponseData
): ExpApiResponseData => {
  const { amount, currency: currencyCode, ...rest } = response.data;
  return {
    beneficiaryDetails: [
      {
        ...rest,
        currencyAmount: {
          ...(amount && typeof amount === 'string' && { amount }),
          ...(currencyCode &&
            typeof currencyCode === 'string' && { currencyCode }),
        },
      },
    ],
  };
};
