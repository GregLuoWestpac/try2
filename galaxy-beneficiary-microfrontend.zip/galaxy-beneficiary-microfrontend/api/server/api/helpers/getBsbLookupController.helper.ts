/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { DownstreamServiceResponseData } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { v4 } from 'uuid';
import { GetBsbLookupData } from '../../../interfaces/models/galaxyBeneficiaryExp';

export type ExpApiResponseData = GetBsbLookupData['entities'];

export type BsbLookupItem = ExpApiResponseData['bsbLookup'][number];

export const transformDownstreamResponseToUi = (
  response: DownstreamServiceResponseData
): ExpApiResponseData => {
  const bsbLookupData = Array.isArray(response?.data?.branches)
    ? (response?.data?.branches as BsbLookupItem[])
    : [];

  const mappedBsbLookupData =
    bsbLookupData.length > 0
      ? bsbLookupData.map(branch => ({
          ...branch,
          id: v4(),
          bankName: branch?.bankName,
        }))
      : [{ id: v4(), bankName: undefined }];

  return { bsbLookup: mappedBsbLookupData } as ExpApiResponseData;
};
