import { DownstreamServiceResponseData } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import {
  transformDownstreamResponseToUi,
  ExpApiResponseData,
} from './retrieveBeneficiaryController.helper';

describe('retrieveBeneficiaryController.helper', () => {
  describe('transformDownstreamResponseToUi', () => {
    it('should transform downstream response correctly', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          id: '123456789',
          externalId: 'EXT123',
          nickname: 'Test Beneficiary',
          currency: 'AUD',
          org: 'testOrg',
          status: 'ACTIVE',
          type: 'BANK_ACCOUNT',
          account: {
            accountNumber: '123456789',
            bsbNumber: '123-456',
            accountName: 'Test Account',
          },
        },
      };

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result).toEqual({
        beneficiaryDetails: [
          {
            id: '123456789',
            externalId: 'EXT123',
            nickname: 'Test Beneficiary',
            org: 'testOrg',
            status: 'ACTIVE',
            type: 'BANK_ACCOUNT',
            account: {
              accountNumber: '123456789',
              bsbNumber: '123-456',
              accountName: 'Test Account',
            },
            currencyAmount: {
              currencyCode: 'AUD',
            },
          },
        ],
      });
    });

    it('should handle beneficiary with PayID type', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          id: '987654321',
          externalId: 'EXT987',
          nickname: 'PayID Beneficiary',
          currency: 'AUD',
          org: 'testOrg',
          status: 'ACTIVE',
          type: 'PAYID',
          account: {
            payId: 'test@example.com',
            payIdType: 'EMAIL',
          },
        },
      };

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result).toEqual({
        beneficiaryDetails: [
          {
            id: '987654321',
            externalId: 'EXT987',
            nickname: 'PayID Beneficiary',
            org: 'testOrg',
            status: 'ACTIVE',
            type: 'PAYID',
            account: {
              payId: 'test@example.com',
              payIdType: 'EMAIL',
            },
            currencyAmount: {
              currencyCode: 'AUD',
            },
          },
        ],
      });
    });

    it('should handle empty beneficiary data', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {},
      };

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result).toEqual({
        beneficiaryDetails: [
          {
            currencyAmount: {},
          },
        ],
      });
    });

    it('should handle null data', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: null,
      };

      expect(() =>
        transformDownstreamResponseToUi(mockDownstreamResponse)
      ).toThrow(/Cannot destructure property 'amount'.*as it is null/);
    });

    it('should handle undefined data', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: undefined,
      };

      expect(() =>
        transformDownstreamResponseToUi(mockDownstreamResponse)
      ).toThrow(/Cannot destructure property 'amount'.*as it is undefined/);
    });

    it('should wrap single beneficiary data in an array', () => {
      const mockBeneficiaryData = {
        id: '555666777',
        nickname: 'Single Beneficiary',
        status: 'PENDING',
      };

      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: mockBeneficiaryData,
      };

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result.beneficiaryDetails).toBeInstanceOf(Array);
      expect(result.beneficiaryDetails).toHaveLength(1);
      expect(result.beneficiaryDetails[0]).toEqual({
        ...mockBeneficiaryData,
        currencyAmount: {},
      });
    });

    it('should maintain the structure expected by ExpApiResponseData type', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          id: '111222333',
          externalId: 'EXT111',
          nickname: 'Type Check Beneficiary',
          currency: 'USD',
          org: 'typeOrg',
          status: 'INACTIVE',
          type: 'BANK_ACCOUNT',
        },
      };

      const result: ExpApiResponseData = transformDownstreamResponseToUi(
        mockDownstreamResponse
      );

      expect(result).toHaveProperty('beneficiaryDetails');
      expect(Array.isArray(result.beneficiaryDetails)).toBe(true);
      expect(result.beneficiaryDetails[0]).toEqual({
        id: '111222333',
        externalId: 'EXT111',
        nickname: 'Type Check Beneficiary',
        org: 'typeOrg',
        status: 'INACTIVE',
        type: 'BANK_ACCOUNT',
        currencyAmount: {
          currencyCode: 'USD',
        },
      });
    });

    it('should handle response with amount as non-string (number)', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          id: '999888777',
          nickname: 'Number Amount Test',
          amount: 1000, // number instead of string
          currency: 'EUR',
        },
      };

      const result: ExpApiResponseData = transformDownstreamResponseToUi(
        mockDownstreamResponse
      );

      expect(result.beneficiaryDetails[0]).toEqual({
        id: '999888777',
        nickname: 'Number Amount Test',
        currencyAmount: {
          currencyCode: 'EUR',
        },
      });
      // amount should not be included because it's not a string
      expect(result.beneficiaryDetails[0].currencyAmount).not.toHaveProperty(
        'amount'
      );
    });
  });
});
