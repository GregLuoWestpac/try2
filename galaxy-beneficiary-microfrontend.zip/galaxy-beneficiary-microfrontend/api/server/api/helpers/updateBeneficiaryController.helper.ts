/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { DownstreamServiceResponseData } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { UpdateBeneficiaryData } from '../../../interfaces/models/galaxyBeneficiaryExp';
import { mapBeneficiariesDownstream } from './beneficiary.helper';

export type ExpApiResponseData = UpdateBeneficiaryData['entities'];

export const transformDownstreamResponseToUi = (
  response: DownstreamServiceResponseData
): ExpApiResponseData => {
  const beneficiariesData = mapBeneficiariesDownstream(response);
  return {
    beneficiaryUpdate: beneficiariesData,
  } as ExpApiResponseData;
};
