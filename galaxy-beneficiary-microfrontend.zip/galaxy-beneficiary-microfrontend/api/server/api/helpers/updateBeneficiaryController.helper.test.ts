import { transformDownstreamResponseToUi } from './updateBeneficiaryController.helper';
import { DownstreamServiceResponseData } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

describe('updateBeneficiaryController.helper', () => {
  describe('transformDownstreamResponseToUi', () => {
    it('should transform downstream response with complete beneficiary data', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          beneficiaries: {
            id: '2ca0fae8-cfd5-428a-818d-dc72806882c4',
            externalId: '3db1fae8-dfd5-528a-918d-ec82906882d5',
            nickname: 'John Doe',
            currency: 'AUD',
            type: 'account',
            account: {
              accountId: {
                BSB: '123456',
                accountNumber: '12345678',
              },
              accountName: 'John Doe Account',
              bankName: 'Test Bank',
            },
            status: 'ACTIVE',
            createdDateTime: '2024-01-01T10:00:00Z',
            lastModifiedDateTime: '2024-01-02T10:00:00Z',
          },
        },
        status: 200,
        statusText: 'OK',
        headers: {},
        config: {},
      } as DownstreamServiceResponseData;

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result).toEqual({
        beneficiaryUpdate: {
          id: '2ca0fae8-cfd5-428a-818d-dc72806882c4',
          externalId: '3db1fae8-dfd5-528a-918d-ec82906882d5',
          nickname: 'John Doe',
          currency: 'AUD',
          type: 'account',
          account: {
            accountId: {
              BSB: '123456',
              accountNumber: '12345678',
            },
            accountName: 'John Doe Account',
            bankName: 'Test Bank',
          },
          status: 'ACTIVE',
          createdDateTime: '2024-01-01T10:00:00Z',
          lastModifiedDateTime: '2024-01-02T10:00:00Z',
        },
      });
    });

    it('should transform downstream response with PayID beneficiary data', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          beneficiaries: {
            id: '4db2fae8-efd5-628a-a18d-fc92a06882e6',
            externalId: '5ec3fae8-ffd5-728a-b28d-gd93b07882f7',
            nickname: 'Jane Smith',
            currency: 'AUD',
            type: 'payid',
            account: {
              payIDValue: 'jane.smith@example.com',
              payIDType: 'EMAIL',
              payIDName: 'Jane Smith',
            },
            status: 'ACTIVE',
            createdDateTime: '2024-01-03T10:00:00Z',
            lastModifiedDateTime: '2024-01-04T10:00:00Z',
          },
        },
        status: 200,
        statusText: 'OK',
        headers: {},
        config: {},
      } as DownstreamServiceResponseData;

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result).toEqual({
        beneficiaryUpdate: {
          id: '4db2fae8-efd5-628a-a18d-fc92a06882e6',
          externalId: '5ec3fae8-ffd5-728a-b28d-gd93b07882f7',
          nickname: 'Jane Smith',
          currency: 'AUD',
          type: 'payid',
          account: {
            payIDValue: 'jane.smith@example.com',
            payIDType: 'EMAIL',
            payIDName: 'Jane Smith',
          },
          status: 'ACTIVE',
          createdDateTime: '2024-01-03T10:00:00Z',
          lastModifiedDateTime: '2024-01-04T10:00:00Z',
        },
      });
    });

    it('should transform downstream response with minimal beneficiary data', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          beneficiaries: {
            id: '6fd4fae8-gfd5-828a-c38d-hea4c08882g8',
            nickname: 'Minimal Ben',
            currency: 'AUD',
          },
        },
        status: 200,
        statusText: 'OK',
        headers: {},
        config: {},
      } as DownstreamServiceResponseData;

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result).toEqual({
        beneficiaryUpdate: {
          id: '6fd4fae8-gfd5-828a-c38d-hea4c08882g8',
          nickname: 'Minimal Ben',
          currency: 'AUD',
        },
      });
    });

    it('should handle empty beneficiaries data', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          beneficiaries: {},
        },
        status: 200,
        statusText: 'OK',
        headers: {},
        config: {},
      } as DownstreamServiceResponseData;

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result).toEqual({
        beneficiaryUpdate: {},
      });
    });

    it('should handle null beneficiaries data', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          beneficiaries: null,
        },
        status: 200,
        statusText: 'OK',
        headers: {},
        config: {},
      } as DownstreamServiceResponseData;

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result).toEqual({
        beneficiaryUpdate: null,
      });
    });

    it('should handle undefined beneficiaries data', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          beneficiaries: undefined,
        },
        status: 200,
        statusText: 'OK',
        headers: {},
        config: {},
      } as DownstreamServiceResponseData;

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result).toEqual({
        beneficiaryUpdate: undefined,
      });
    });

    it('should preserve all properties from beneficiaries data', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          beneficiaries: {
            id: '7ge5fae8-hfd5-928a-d48d-ifb5d09882h9',
            externalId: '8hf6fae8-ifd5-a28a-e58d-jgc6e0a882i0',
            nickname: 'Complete Test',
            currency: 'AUD',
            type: 'account',
            account: {
              accountId: {
                BSB: '654321',
                accountNumber: '87654321',
              },
              accountName: 'Complete Test Account',
              bankName: 'Complete Test Bank',
            },
            status: 'INACTIVE',
            createdDateTime: '2024-01-05T10:00:00Z',
            lastModifiedDateTime: '2024-01-06T10:00:00Z',
            customField: 'custom value',
            anotherField: 12345,
          },
        },
        status: 200,
        statusText: 'OK',
        headers: {},
        config: {},
      } as DownstreamServiceResponseData;

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result.beneficiaryUpdate).toHaveProperty(
        'id',
        '7ge5fae8-hfd5-928a-d48d-ifb5d09882h9'
      );
      expect(result.beneficiaryUpdate).toHaveProperty(
        'externalId',
        '8hf6fae8-ifd5-a28a-e58d-jgc6e0a882i0'
      );
      expect(result.beneficiaryUpdate).toHaveProperty(
        'nickname',
        'Complete Test'
      );
      expect(result.beneficiaryUpdate).toHaveProperty('currency', 'AUD');
      expect(result.beneficiaryUpdate).toHaveProperty('type', 'account');
      expect(result.beneficiaryUpdate).toHaveProperty('account');
      expect(result.beneficiaryUpdate).toHaveProperty('status', 'INACTIVE');
      expect(result.beneficiaryUpdate).toHaveProperty(
        'createdDateTime',
        '2024-01-05T10:00:00Z'
      );
      expect(result.beneficiaryUpdate).toHaveProperty(
        'lastModifiedDateTime',
        '2024-01-06T10:00:00Z'
      );
      expect(result.beneficiaryUpdate).toHaveProperty(
        'customField',
        'custom value'
      );
      expect(result.beneficiaryUpdate).toHaveProperty('anotherField', 12345);
    });

    it('should handle response with different data structure', () => {
      const mockDownstreamResponse: DownstreamServiceResponseData = {
        data: {
          beneficiaries: {
            id: '9ig7fae8-jfd5-b28a-f68d-khd7f0b882j1',
            nickname: 'Special Chars !@#$%',
            currency: 'USD',
            type: 'international',
            specialProperty: {
              nested: {
                value: 'deeply nested',
              },
            },
          },
        },
        status: 201,
        statusText: 'Created',
        headers: {
          'content-type': 'application/json',
        },
        config: {
          method: 'PUT',
        },
      } as DownstreamServiceResponseData;

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result).toEqual({
        beneficiaryUpdate: {
          id: '9ig7fae8-jfd5-b28a-f68d-khd7f0b882j1',
          nickname: 'Special Chars !@#$%',
          currency: 'USD',
          type: 'international',
          specialProperty: {
            nested: {
              value: 'deeply nested',
            },
          },
        },
      });
    });

    it('should throw error when data is missing', () => {
      const mockDownstreamResponse = {
        status: 200,
        statusText: 'OK',
        headers: {},
        config: {},
      } as unknown as DownstreamServiceResponseData;

      expect(() => {
        transformDownstreamResponseToUi(mockDownstreamResponse);
      }).toThrow();
    });

    it('should handle missing data.beneficiaries gracefully', () => {
      const mockDownstreamResponse = {
        data: {},
        status: 200,
        statusText: 'OK',
        headers: {},
        config: {},
      } as unknown as DownstreamServiceResponseData;

      const result = transformDownstreamResponseToUi(mockDownstreamResponse);

      expect(result).toEqual({
        beneficiaryUpdate: undefined,
      });
    });
  });
});
