/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  DownstreamServiceResponseData,
  Logger,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { v4 as uuidv4 } from 'uuid';
import { handleApiService } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { RUNTIME } from '@mep-node/framework-constants';
import { readMeshSecrets } from '../../utils/secretsUtil';
import { setParamsForPaymentCounter } from '../../utils/setParams';
import {
  transformDownstreamResponseToUi,
  transformRequestForDownstream,
  payIDLimitCounter,
} from './postAliasLookupController.helper';

// Mock uuid
jest.mock('uuid', () => ({
  v4: jest.fn(() => 'mocked-uuid-123'),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  handleApiService: jest.fn(),
}));

jest.mock('../../utils/setParams', () => ({
  setParamsForPaymentCounter: jest.fn(),
}));

jest.mock('../../utils/secretsUtil', () => ({
  readMeshSecrets: jest.fn(),
}));

jest.mock('@mep-node/framework-constants', () => ({
  RUNTIME: { isLocal: jest.fn() },
}));

describe('transformDownstreamResponseToUi', () => {
  it('should return aliasLookup with a generated id and response data', () => {
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        alias: 'john_doe',
        accountId: '12345',
        status: 'active',
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      aliasLookup: [
        {
          id: 'mocked-uuid-123',
          aliasType: undefined,
          name: undefined,
          resolutionDateTime: undefined,
          returnCode: undefined,
        },
      ],
    });

    expect(uuidv4).toHaveBeenCalled();
  });

  it('should handle empty response.data', () => {
    const mockResponse: DownstreamServiceResponseData = {
      data: {},
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      aliasLookup: [
        {
          id: 'mocked-uuid-123',
        },
      ],
    });
  });
});

describe('transformRequestForDownstream', () => {
  it('should transform request with email alias correctly', () => {
    const request = {
      authBIC8: 'AUTH1234',
      email: 'john.doe@example.com',
    };

    const result = transformRequestForDownstream(request);

    expect(result).toEqual({
      aliasId: 'john.doe@example.com',
      aliasType: 'EMAL',
      authBIC8: 'AUTH1234',
    });
  });

  it('should transform request with phone alias correctly', () => {
    const request = {
      authBIC8: 'AUTH5678',
      phone: '1234567890',
    };

    const result = transformRequestForDownstream(request);

    expect(result).toEqual({
      aliasId: '1234567890',
      aliasType: 'TELI',
      authBIC8: 'AUTH5678',
    });
  });

  it('should transform request with orgn alias correctly', () => {
    const request = {
      authBIC8: 'AUTH9101',
      orgn: 'ORG123',
    };

    const result = transformRequestForDownstream(request);

    expect(result).toEqual({
      aliasId: 'ORG123',
      aliasType: 'ORGN',
      authBIC8: 'AUTH9101',
    });
  });

  it('should transform request with aubn alias correctly', () => {
    const request = {
      authBIC8: 'AUTH1122',
      aubn: 'AUBN456',
    };

    const result = transformRequestForDownstream(request);

    expect(result).toEqual({
      aliasId: 'AUBN456',
      aliasType: 'AUBN',
      authBIC8: 'AUTH1122',
    });
  });

  it('should handle unexpected alias types gracefully', () => {
    const request = {
      authBIC8: 'AUTH3344',
      unknownAlias: 'UNKNOWN',
    };

    const result = transformRequestForDownstream(request);

    expect(result).toEqual({
      aliasId: 'UNKNOWN',
      aliasType: undefined,
      authBIC8: 'AUTH3344',
    });
  });
});

describe('payIDLimitCounter', () => {
  const mockReq = {} as any;
  const mockRes = {} as any;
  const orgID = 'test';
  const sessionId = 'test';
  const name = 'PAYID';

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should call setParamsForPaymentCounter with correct arguments when apiClient.name is "getSessionIdCounter"', async () => {
    const apiClient = { name: 'getSessionIdCounter' };
    const mockData = { count: 42 };
    const mockApiHeaders = {};
    const appConfig = {};

    (handleApiService as jest.Mock).mockResolvedValue({
      data: { data: mockData },
    });

    await payIDLimitCounter(apiClient, mockRes, mockReq, orgID, sessionId);

    const { setDownstreamParams } = (handleApiService as jest.Mock).mock
      .calls[0][0];
    expect(typeof setDownstreamParams).toBe('function');

    // Call the actual downstream param function
    setDownstreamParams(mockApiHeaders, mockRes, mockReq, appConfig);

    expect(setParamsForPaymentCounter).toHaveBeenCalledWith(
      mockApiHeaders,
      mockRes,
      undefined,
      appConfig,
      undefined,
      { name, customerId: 'test', sessionId: 'test' } // PathParams
    );
  });

  it('should call setParamsForPaymentCounter with correct arguments when apiClient.name is "getPaymentCounter"', async () => {
    const apiClient = { name: 'getPaymentCounter' };
    const mockData = { count: 42 };
    const mockApiHeaders = {};
    const appConfig = {};

    (handleApiService as jest.Mock).mockResolvedValue({
      data: { data: mockData },
    });

    await payIDLimitCounter(apiClient, mockRes, mockReq, orgID, sessionId);

    const { setDownstreamParams } = (handleApiService as jest.Mock).mock
      .calls[0][0];
    expect(typeof setDownstreamParams).toBe('function');

    // Call the actual downstream param function
    setDownstreamParams(mockApiHeaders, mockRes, mockReq, appConfig);

    expect(setParamsForPaymentCounter).toHaveBeenCalledWith(
      mockApiHeaders,
      mockRes,
      undefined,
      appConfig,
      undefined,
      { name, customerId: 'test' } // PathParams
    );
  });

  it('should call setParamsForPaymentCounter with correct arguments when apiClient.name is not "getPaymentCounter" or "getSessionIdCounter"', async () => {
    const apiClient = { name: 'incrementSessionIdCounter' };
    const mockData = { count: 10 };
    const mockApiHeaders = {};
    const appConfig = {};

    (handleApiService as jest.Mock).mockResolvedValue({
      data: { data: mockData },
    });

    await payIDLimitCounter(apiClient, mockRes, mockReq, orgID, sessionId);

    const { setDownstreamParams } = (handleApiService as jest.Mock).mock
      .calls[0][0];
    expect(typeof setDownstreamParams).toBe('function');

    // Call the actual downstream param function
    setDownstreamParams(mockApiHeaders, mockRes, mockReq, appConfig);

    expect(setParamsForPaymentCounter).toHaveBeenCalledWith(
      mockApiHeaders,
      mockRes,
      {},
      appConfig,
      undefined,
      { name, customerId: 'test', sessionId: 'test' } // PathParams
    );
  });

  it('should handle errors thrown from handleApiService', async () => {
    const apiClient = { name: 'someAPI' };

    (handleApiService as jest.Mock).mockRejectedValue(
      new Error('Downstream error')
    );

    await expect(
      payIDLimitCounter(apiClient, mockRes, mockReq, orgID, sessionId)
    ).rejects.toThrow('Downstream error');
  });
});

describe('getPayIDType', () => {
  const { getPayIDType } = require('./postAliasLookupController.helper');

  it('should return "MOBILE" for TELI alias type', () => {
    const result = getPayIDType('TELI123');
    expect(result).toBe('MOBILE');
  });

  it('should return "EMAIL" for EMAL alias type', () => {
    const result = getPayIDType('EMAL456');
    expect(result).toBe('EMAIL');
  });

  it('should return "ABN" for AUBN alias type', () => {
    const result = getPayIDType('AUBN789');
    expect(result).toBe('ABN');
  });

  it('should return "ORGN" for ORGN alias type', () => {
    const result = getPayIDType('ORGN101');
    expect(result).toBe('ORGN');
  });

  it('should return undefined for unknown alias type', () => {
    const result = getPayIDType('UNKNOWN');
    expect(result).toBeUndefined();
  });

  it('should handle empty string', () => {
    const result = getPayIDType('');
    expect(result).toBeUndefined();
  });

  it('should handle alias type that partially matches', () => {
    const result = getPayIDType('PRETELI');
    expect(result).toBe('MOBILE');
  });

  it('should handle case sensitivity', () => {
    const result = getPayIDType('teli123');
    expect(result).toBeUndefined();
  });

  it('should handle multiple matches - prioritize TELI', () => {
    const result = getPayIDType('TELIEMAL');
    expect(result).toBe('MOBILE');
  });

  it('should handle EMAL when TELI is not present', () => {
    const result = getPayIDType('SOMEEMALDATA');
    expect(result).toBe('EMAIL');
  });

  it('should handle AUBN when TELI and EMAL are not present', () => {
    const result = getPayIDType('SOMEAUBNDATA');
    expect(result).toBe('ABN');
  });

  it('should handle ORGN when other types are not present', () => {
    const result = getPayIDType('SOMEORGNDATA');
    expect(result).toBe('ORGN');
  });
});
