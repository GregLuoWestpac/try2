/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable consistent-return */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-enum-comparison */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable no-console */
import { v4 } from 'uuid';
import {
  DownstreamServiceResponse,
  DownstreamServiceResponseData,
  handleApiService,
  PathParams,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { PostAliasLookupData } from '../../../interfaces/models/galaxyBeneficiaryExp';
import { setParamsForPaymentCounter } from '../../utils/setParams';
import { PAYID_TYPE } from '../../utils/apiConstants';

export type ExpApiResponseData = PostAliasLookupData['entities'];

export const transformDownstreamResponseToUi = (
  response: DownstreamServiceResponseData
): ExpApiResponseData =>
  ({
    aliasLookup: [
      {
        id: v4(),
        aliasType: response.data.aliasType as PAYID_TYPE,
        name: response.data.name as string,
        resolutionDateTime: response.data.resolutionDateTime as string,
        returnCode: response.data.returnCode,
      },
    ],
  } as ExpApiResponseData);

export const transformRequestForDownstream = request => {
  const { authBIC8, action, ...rest } = request;

  const aliasTypeMapping = {
    phone: 'TELI',
    email: 'EMAL',
    orgn: 'ORGN',
    aubn: 'AUBN',
  };

  const [key, id] = Object.entries(rest)[0]; // Extract the first key-value pair (e.g., "email": "john.doe@example.com")

  return {
    aliasId: id,
    aliasType: aliasTypeMapping[key],
    action,
    authBIC8,
  };
};

export const payIDLimitCounter = async (
  apiClient,
  res,
  req,
  userId,
  sessionId?
) => {
  const isGetSessionCounter = apiClient.name === 'getSessionIdCounter';
  const isGetPaymentCounter = apiClient.name === 'getPaymentCounter';
  console.log('userId:', userId, 'sessionId:', sessionId);
  const pathParams: PathParams = {
    name: 'PAYID',
    customerId: userId,
    ...(!isGetPaymentCounter && { sessionId }),
  };
  const bodyParams =
    isGetSessionCounter || isGetPaymentCounter ? undefined : {};
  const queryParams = undefined;

  const { data: paymentCounterDownstreamResponse }: DownstreamServiceResponse =
    await handleApiService({
      req,
      res,
      apiClient,
      setDownstreamParams: (apiHeaders, response, request, appConfig) => {
        const paymentCounterParams = setParamsForPaymentCounter(
          apiHeaders,
          response,
          bodyParams,
          appConfig,
          queryParams,
          pathParams
        );
        console.log('Payment Counter Downstream Params:', paymentCounterParams);
        return paymentCounterParams;
      },
    });
  return paymentCounterDownstreamResponse.data;
};

export const getPayIDType = (aliasId): string => {
  if (aliasId.includes('TELI')) {
    return 'MOBILE';
  } else if (aliasId.includes('EMAL')) {
    return 'EMAIL';
  } else if (aliasId.includes('AUBN')) {
    return 'ABN';
  } else if (aliasId.includes('ORGN')) {
    return 'ORGN';
  }
};
