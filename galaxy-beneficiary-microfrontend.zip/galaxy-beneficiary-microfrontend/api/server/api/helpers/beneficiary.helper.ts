import { DownstreamServiceResponseData } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

export const mapBeneficiariesDownstream = (
  response: DownstreamServiceResponseData
) => {
  const beneficiaries = response.data.beneficiaries;
  if (!Array.isArray(beneficiaries)) return beneficiaries;
  return beneficiaries.map(beneficiary => {
    const { amount, currency: currencyCode, ...rest } = beneficiary;
    return {
      ...rest,
      currencyAmount: {
        ...(amount && { amount }),
        ...(currencyCode && { currencyCode }),
      },
    };
  });
};
