/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { v4 } from 'uuid';
import { DownstreamServiceResponseData } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { RetrieveBeneficiariesData } from '../../../interfaces/models/galaxyBeneficiaryExp';
import { mapBeneficiariesDownstream } from './beneficiary.helper';

export type ExpApiResponseData = RetrieveBeneficiariesData['entities'];
export type PagingItem = ExpApiResponseData['paging'][number];

export const transformDownstreamResponseToUi = (
  response: DownstreamServiceResponseData
): ExpApiResponseData => {
  const beneficiariesData = mapBeneficiariesDownstream(response);
  const pagingItem =
    Array.isArray(response.paging) &&
    typeof response.paging[0] === 'object' &&
    response.paging[0] !== null
      ? (response.paging[0] as PagingItem)
      : {};

  const pagingData = [
    {
      id: v4(),
      pageSize: pagingItem.pageSize,
      count: pagingItem.count,
      previousPageKey: pagingItem.previousPageKey,
      nextPageKey: pagingItem.nextPageKey,
      moreItems: pagingItem.moreItems,
    },
  ];

  return {
    beneficiaryList: beneficiariesData,
    paging: pagingData,
  } as ExpApiResponseData;
};
