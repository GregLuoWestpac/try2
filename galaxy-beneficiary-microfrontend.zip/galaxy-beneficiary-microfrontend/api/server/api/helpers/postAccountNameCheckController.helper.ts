import { v4 } from 'uuid';
import { Response, Request } from 'express';
import { getColorForCoPStatusCode, CoPApiStatusCode} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import type { APIClient } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { AccountNameCheckResponse } from '../../../interfaces/models/downstream/payeeServicesV1';
import { PostAccountNameCheckData } from '../../../interfaces/models/galaxyBeneficiaryExp';
import { getLimitCounter } from '../../utils/limitCounter';
import { MATCHED_STATUS_SESSION_AND_DAILY } from '../../utils/apiConstants';

export type ExpApiResponseData =
  PostAccountNameCheckData['entities']['accountNameCheck'];

export const transformDownstreamResponseToUi = (
  response: AccountNameCheckResponse
): ExpApiResponseData => {
  if (!response.data) {
    return [{ id: v4() }];
  }

  const { matchedAccountName, matchedStatus } = response.data || {};

  return [
    {
      id: v4(),
      matchedCOPAccountName: matchedAccountName,
      matchedCOPStatusCode: matchedStatus?.code,
      matchedCOPColour:  matchedStatus?.code !== undefined ? getColorForCoPStatusCode(matchedStatus?.code as CoPApiStatusCode) : undefined
    },
  ];
};

/**
 * Increments CoP counters based on matchedStatus code
 * - V*C3/V*C4 codes: increment both session and daily counters
 * - Other codes: increment daily counter only
 * - Missing matchedStatus: no increment
 */
export const incrementCopCounters = async (
  matchedStatus: string | undefined,
  incrementSessionIdCounter: APIClient,
  incrementPaymentCounter: APIClient,
  res: Response,
  req: Request,
  userId: string,
  sessionIndex?: string
): Promise<{ incremented: boolean; message?: string }> => {
  const { logger } = res.locals as {
    logger?: { warn: (msg: string) => void; info: (msg: string) => void };
  };

  if (!matchedStatus) {
    logger?.info(
      'matchedStatus not present in response, skipping counter increment'
    );
    return { incremented: false, message: 'no matchedStatus' };
  }

  const shouldIncrementBoth =
    MATCHED_STATUS_SESSION_AND_DAILY.has(matchedStatus);

  const incrementCounterResponse = shouldIncrementBoth
    ? await getLimitCounter(
        'COP',
        incrementSessionIdCounter,
        res,
        req,
        userId,
        sessionIndex
      )
    : await getLimitCounter('COP', incrementPaymentCounter, res, req, userId);

  if (!incrementCounterResponse?.counters) {
    const warningMsg = shouldIncrementBoth
      ? 'COP limit failed to increment session and daily counters'
      : 'COP limit failed to increment daily counter';
    logger?.warn(warningMsg);
    return { incremented: false, message: warningMsg };
  }

  return { incremented: true };
};

/**
 * Increments daily counter on API error (400/500)
 */
export const incrementDailyCounterOnError = async (
  errorStatus: number | undefined,
  incrementPaymentCounter: APIClient,
  res: Response,
  req: Request,
  userId: string
): Promise<void> => {
  const { logger } = res.locals as { logger?: { warn: (msg: string) => void } };

  if (errorStatus !== 400 && errorStatus !== 500) {
    return;
  }

  try {
    await getLimitCounter('COP', incrementPaymentCounter, res, req, userId);
  } catch {
    logger?.warn('Failed to increment daily counter on API error');
  }
};
