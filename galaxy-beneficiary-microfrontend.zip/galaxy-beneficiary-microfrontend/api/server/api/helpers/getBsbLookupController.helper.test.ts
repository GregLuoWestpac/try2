import { DownstreamServiceResponseData } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import {
  transformDownstreamResponseToUi,
  ExpApiResponseData,
} from './getBsbLookupController.helper';

// Mock uuid to always return the same value
jest.mock('uuid', () => ({
  v4: jest.fn(() => 'mock-uuid'),
}));

describe('transformDownstreamResponseToUi', () => {
  it('should transform downstream response to UI format', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '123',
            BSB: '123456',
            branchName: 'Test Branch',
            bankName: 'Test Bank',
            bankCode: '03',
            brand: 'WBC',
            branchStatus: 'OPERATIONAL',
            branchAvailable: true,
            address: {
              addressLine1: '123 Main St',
              city: 'Sydney',
              state: 'NSW',
              postCode: '2000',
            },
          },
        ],
      },
    };

    const expectedTransformedData: ExpApiResponseData = {
      bsbLookup: [
        {
          id: 'mock-uuid',
          branchId: '123',
          BSB: '123456',
          branchName: 'Test Branch',
          bankName: 'Test Bank',
          bankCode: '03',
          brand: 'WBC',
          branchStatus: 'OPERATIONAL',
          branchAvailable: true,
          address: {
            addressLine1: '123 Main St',
            city: 'Sydney',
            state: 'NSW',
            postCode: '2000',
          },
        },
      ],
    };

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual(expectedTransformedData);
  });

  it('should handle empty branches array', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {
      data: {
        branches: [],
      },
    };

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should handle missing branches property', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {
      data: {},
    };

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should handle null branches', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {
      data: {
        branches: null,
      },
    };

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should handle missing data property', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {} as any;

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should map branch with missing bankName to default value', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '456',
            BSB: '654321',
            branchName: 'Another Branch',
            // bankName is missing
            bankCode: '04',
            brand: 'ANZ',
            branchStatus: 'CLOSED',
            branchAvailable: false,
          },
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          branchId: '456',
          BSB: '654321',
          branchName: 'Another Branch',
          bankName: undefined,
          bankCode: '04',
          brand: 'ANZ',
          branchStatus: 'CLOSED',
          branchAvailable: false,
        },
      ],
    });
  });

  it('should map multiple branches correctly', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '789',
            BSB: '789012',
            branchName: 'First Branch',
            bankName: 'First Bank',
            bankCode: '05',
            brand: 'NAB',
          },
          {
            branchId: '890',
            BSB: '890123',
            branchName: 'Second Branch',
            // bankName is missing for this one
            bankCode: '06',
            brand: 'CBA',
          },
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          branchId: '789',
          BSB: '789012',
          branchName: 'First Branch',
          bankName: 'First Bank',
          bankCode: '05',
          brand: 'NAB',
        },
        {
          id: 'mock-uuid',
          branchId: '890',
          BSB: '890123',
          branchName: 'Second Branch',
          bankName: undefined,
          bankCode: '06',
          brand: 'CBA',
        },
      ],
    });
  });

  it('should handle when response.data.branches is not an array', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {
      data: {
        branches: 'not-an-array' as any, // Non-array value
      },
    };

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should handle branch with existing bankName and preserve it', () => {
    const mockDownstreamResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '999',
            BSB: '999999',
            branchName: 'Existing Bank Branch',
            bankName: 'Existing Bank Name', // This should be preserved
            bankCode: '07',
            brand: 'TEST',
          },
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockDownstreamResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          branchId: '999',
          BSB: '999999',
          branchName: 'Existing Bank Branch',
          bankName: 'Existing Bank Name',
          bankCode: '07',
          brand: 'TEST',
        },
      ],
    });
  });

  it('should handle response with valid branches array (covering Array.isArray true branch)', () => {
    // This test specifically targets the Array.isArray(response?.data?.branches) true branch
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '123',
            BSB: '123456',
            branchName: 'Valid Branch',
            bankName: 'Valid Bank',
          },
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result.bsbLookup).toHaveLength(1);
    expect(result.bsbLookup[0]).toEqual({
      id: 'mock-uuid',
      branchId: '123',
      BSB: '123456',
      branchName: 'Valid Branch',
      bankName: 'Valid Bank',
    });
  });

  it('should test branch?.bankName truthiness in mapping', () => {
    // This test specifically ensures both truthy and falsy branch?.bankName paths are hit
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '1',
            bankName: '', // Falsy bankName
          },
          {
            branchId: '2',
            bankName: null, // Falsy bankName
          },
          {
            branchId: '3',
            bankName: undefined, // Falsy bankName
          },
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result.bsbLookup).toHaveLength(3);
    expect(result.bsbLookup[0].bankName).toBe(''); // Empty string preserved
    expect(result.bsbLookup[1].bankName).toBe(null); // null preserved
    expect(result.bsbLookup[2].bankName).toBe(undefined); // undefined preserved
  });

  it('should handle response where data exists but branches is undefined', () => {
    // This should specifically test the response?.data part of the conditional
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        // branches property doesn't exist at all
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should handle response where data is undefined but response exists', () => {
    // This should test the response?.data?.branches chain
    const mockResponse: DownstreamServiceResponseData = {
      // data property doesn't exist
    } as any;

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should cover false branch when response is completely undefined', () => {
    // This targets the Array.isArray(response?.data?.branches) false branch
    const result = transformDownstreamResponseToUi(undefined as any);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should cover false branch when branches is a primitive value', () => {
    // This specifically targets Array.isArray() returning false
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: 'string-instead-of-array' as any,
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should cover branch where bankName is explicitly false', () => {
    // This targets the branch?.bankName || fallback branch more explicitly
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '1',
            bankName: false as any, // Explicitly falsy value
          },
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          branchId: '1',
          bankName: false,
        },
      ],
    });
  });

  it('should cover branch where bankName is 0', () => {
    // This targets another falsy value for branch?.bankName ||
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '1',
            bankName: 0 as any, // Falsy number
          },
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          branchId: '1',
          bankName: 0,
        },
      ],
    });
  });

  it('should ensure truthy bankName preserves original value', () => {
    // This ensures the truthy branch of branch?.bankName || is covered
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '1',
            bankName: 'Valid Bank Name', // Truthy value
          },
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          branchId: '1',
          bankName: 'Valid Bank Name',
        },
      ],
    });
  });

  it('should handle branch object that is null', () => {
    // This tests the branch? optional chaining
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [null as any], // null branch
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should handle branch object that is undefined', () => {
    // This tests the branch? optional chaining
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [undefined as any], // undefined branch
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should handle array with mixed valid and invalid branches', () => {
    // This targets the Array.isArray true branch with edge cases
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          {
            branchId: '1',
            bankName: 'Valid Bank',
          },
          null, // invalid branch
          {
            branchId: '2',
            // no bankName property
          },
        ] as any,
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result.bsbLookup).toHaveLength(3);
    expect(result.bsbLookup[0]).toEqual({
      id: 'mock-uuid',
      branchId: '1',
      bankName: 'Valid Bank',
    });
    expect(result.bsbLookup[1]).toEqual({
      id: 'mock-uuid',
      bankName: undefined,
    });
    expect(result.bsbLookup[2]).toEqual({
      id: 'mock-uuid',
      branchId: '2',
      bankName: undefined,
    });
  });

  it('should handle response.data.branches as empty array specifically', () => {
    // This specifically tests when Array.isArray returns true for an empty array
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [], // Empty array - Array.isArray should return true
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      bsbLookup: [
        {
          id: 'mock-uuid',
          bankName: undefined,
        },
      ],
    });
  });

  it('should handle array with truthy and falsy bankName values to test branch coverage', () => {
    // This specifically tests both branches of the branch?.bankName || expression
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        branches: [
          { branchId: '1', bankName: 'Truthy Bank' }, // truthy branch
          { branchId: '2' }, // falsy branch (no bankName)
        ],
      },
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result.bsbLookup).toHaveLength(2);
    expect(result.bsbLookup[0]).toEqual({
      id: 'mock-uuid',
      branchId: '1',
      bankName: 'Truthy Bank', // preserved truthy value
    });
    expect(result.bsbLookup[1]).toEqual({
      id: 'mock-uuid',
      branchId: '2',
      bankName: undefined, // fallback for falsy value
    });
  });

  // Enhanced test coverage for better code quality and edge cases
  describe('Enhanced Coverage Tests', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('should handle realistic Australian bank branch data', () => {
      const mockResponse: DownstreamServiceResponseData = {
        data: {
          branches: [
            {
              branchId: '501226',
              BSB: '032001',
              branchName: 'Sydney CBD',
              bankName: 'Westpac Banking Corporation',
              bankCode: '03',
              brand: 'WBC',
              branchStatus: 'OPERATIONAL',
              branchAvailable: true,
              address: {
                addressLine1: '275 Kent Street',
                addressLine2: 'Level 1',
                city: 'Sydney',
                state: 'NSW',
                postCode: '2000',
              },
            },
            {
              branchId: '234567',
              BSB: '083001',
              branchName: 'Melbourne Central',
              bankName: 'Bank of Melbourne',
              bankCode: '083',
              brand: 'BOM',
              branchStatus: 'CLOSED',
              branchAvailable: false,
              address: {
                addressLine1: '456 Collins Street',
                city: 'Melbourne',
                state: 'VIC',
                postCode: '3000',
              },
            },
          ],
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result.bsbLookup).toHaveLength(2);
      expect(result.bsbLookup[0]).toMatchObject({
        id: expect.any(String),
        branchId: '501226',
        BSB: '032001',
        branchName: 'Sydney CBD',
        bankName: 'Westpac Banking Corporation',
        bankCode: '03',
        brand: 'WBC',
        branchStatus: 'OPERATIONAL',
        branchAvailable: true,
        address: expect.objectContaining({
          addressLine1: '275 Kent Street',
          addressLine2: 'Level 1',
          city: 'Sydney',
          state: 'NSW',
          postCode: '2000',
        }),
      });
      expect(result.bsbLookup[1]).toMatchObject({
        id: expect.any(String),
        branchId: '234567',
        BSB: '083001',
        branchName: 'Melbourne Central',
        bankName: 'Bank of Melbourne',
        bankCode: '083',
        brand: 'BOM',
        branchStatus: 'CLOSED',
        branchAvailable: false,
      });
    });

    it('should maintain data integrity when spreading branch properties', () => {
      const mockResponse: DownstreamServiceResponseData = {
        data: {
          branches: [
            {
              branchId: '12345',
              BSB: '123456',
              branchName: 'Test Branch',
              bankName: 'Test Bank',
              bankCode: '12',
              brand: 'WBC',
              branchStatus: 'OPERATIONAL',
              branchAvailable: true,
              customProperty: 'should be preserved',
              nested: {
                deep: {
                  value: 'preserved',
                },
              },
            },
          ],
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result.bsbLookup[0]).toHaveProperty(
        'customProperty',
        'should be preserved'
      );
      expect(result.bsbLookup[0]).toHaveProperty(
        'nested.deep.value',
        'preserved'
      );
      expect(result.bsbLookup[0]).toHaveProperty('id', 'mock-uuid');
      expect(result.bsbLookup[0]).toHaveProperty('bankName', 'Test Bank');
    });

    it('should handle large datasets efficiently', () => {
      const largeBranchesArray = Array.from({ length: 1000 }, (_, index) => ({
        branchId: `branch-${index}`,
        BSB: `${String(index).padStart(6, '0')}`,
        branchName: `Branch ${index}`,
        bankName: `Bank ${index}`,
        bankCode: `${String(index % 100).padStart(2, '0')}`,
        brand: 'WBC' as const,
        branchStatus: 'OPERATIONAL' as const,
        branchAvailable: true,
      }));

      const mockResponse: DownstreamServiceResponseData = {
        data: {
          branches: largeBranchesArray,
        },
      };

      const startTime = performance.now();
      const result = transformDownstreamResponseToUi(mockResponse);
      const endTime = performance.now();
      const executionTime = endTime - startTime;

      expect(result.bsbLookup).toHaveLength(1000);
      expect(executionTime).toBeLessThan(100); // Should complete in under 100ms
      expect(result.bsbLookup[0]).toHaveProperty('id', 'mock-uuid');
      expect(result.bsbLookup[999]).toHaveProperty('id', 'mock-uuid');
      expect(result.bsbLookup[500]).toMatchObject({
        branchId: 'branch-500',
        BSB: '000500',
        branchName: 'Branch 500',
        bankName: 'Bank 500',
      });
    });

    it('should handle various falsy values for bankName correctly', () => {
      const mockResponse: DownstreamServiceResponseData = {
        data: {
          branches: [
            { branchId: '1', bankName: '' }, // empty string
            { branchId: '2', bankName: null }, // null
            { branchId: '3', bankName: undefined }, // undefined
            { branchId: '4', bankName: 0 }, // number 0
            { branchId: '5', bankName: false }, // boolean false
            { branchId: '6', bankName: NaN }, // NaN
            { branchId: '7' }, // missing property
          ],
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result.bsbLookup).toHaveLength(7);
      expect(result.bsbLookup[0].bankName).toBe(''); // empty string preserved
      expect(result.bsbLookup[1].bankName).toBe(null); // null preserved
      expect(result.bsbLookup[2].bankName).toBe(undefined); // undefined preserved
      expect(result.bsbLookup[3].bankName).toBe(0); // 0 preserved
      expect(result.bsbLookup[4].bankName).toBe(false); // false preserved
      expect(result.bsbLookup[5].bankName).toBeNaN(); // NaN preserved
      expect(result.bsbLookup[6].bankName).toBe(undefined); // missing property
    });

    it('should preserve exact branch structure with spread operator', () => {
      const complexBranch = {
        branchId: 'complex-123',
        BSB: '123456',
        branchName: 'Complex Branch',
        bankName: 'Complex Bank',
        bankCode: '99',
        brand: 'SGB' as const,
        branchStatus: 'OPERATIONAL' as const,
        branchAvailable: true,
        address: {
          addressLine1: '123 Complex Street',
          addressLine2: 'Suite 456',
          city: 'Complex City',
          state: 'NSW',
          postCode: '1234',
        },
      };

      const mockResponse: DownstreamServiceResponseData = {
        data: {
          branches: [complexBranch],
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      // Check that all original properties are preserved
      expect(result.bsbLookup[0]).toMatchObject({
        ...complexBranch,
        id: 'mock-uuid',
        bankName: 'Complex Bank', // This should be the same as original
      });

      // Ensure the spread operator worked correctly
      expect(result.bsbLookup[0].address).toEqual(complexBranch.address);
      expect(result.bsbLookup[0]).toHaveProperty('id');
    });

    it('should handle array with only null and undefined branches to achieve 100% branch coverage', () => {
      // This test specifically targets the edge case where branches array contains only null/undefined
      const mockResponse: DownstreamServiceResponseData = {
        data: {
          branches: [null, undefined, null],
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result.bsbLookup).toHaveLength(3);
      result.bsbLookup.forEach(item => {
        expect(item).toEqual({
          id: 'mock-uuid',
          bankName: undefined,
        });
      });
    });

    it('should verify return type matches ExpApiResponseData interface', () => {
      const mockResponse: DownstreamServiceResponseData = {
        data: {
          branches: [
            {
              branchId: 'type-test',
              BSB: '123456',
              branchName: 'Type Test Branch',
              bankName: 'Type Test Bank',
            },
          ],
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      // Verify the result structure matches expected ExpApiResponseData
      expect(result).toHaveProperty('bsbLookup');
      expect(Array.isArray(result.bsbLookup)).toBe(true);
      expect(result.bsbLookup[0]).toHaveProperty('id');
      expect(typeof result.bsbLookup[0].id).toBe('string');

      // Type-safe assignment test (TypeScript compilation check)
      const typedResult: ExpApiResponseData = result;
      expect(typedResult.bsbLookup).toBeDefined();
    });

    it('should handle extreme edge cases gracefully', () => {
      // Test with completely missing data
      const result1 = transformDownstreamResponseToUi(
        {} as DownstreamServiceResponseData
      );
      expect(result1).toEqual({
        bsbLookup: [
          {
            id: 'mock-uuid',
            bankName: undefined,
          },
        ],
      });

      // Test with null data property
      const result2 = transformDownstreamResponseToUi({
        data: null,
      } as unknown as DownstreamServiceResponseData);
      expect(result2).toEqual({
        bsbLookup: [
          {
            id: 'mock-uuid',
            bankName: undefined,
          },
        ],
      });
    });

    it('should handle mixed data types in branches array without breaking', () => {
      const mockResponse: DownstreamServiceResponseData = {
        data: {
          branches: [
            // Valid branch
            {
              branchId: 'valid-1',
              bankName: 'Valid Bank',
            },
            // Valid branch after others
            {
              branchId: 'valid-2',
              bankName: 'Another Valid Bank',
            },
          ],
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result.bsbLookup).toHaveLength(2);

      // Valid branches should be processed correctly
      expect(result.bsbLookup[0]).toMatchObject({
        id: 'mock-uuid',
        branchId: 'valid-1',
        bankName: 'Valid Bank',
      });

      expect(result.bsbLookup[1]).toMatchObject({
        id: 'mock-uuid',
        branchId: 'valid-2',
        bankName: 'Another Valid Bank',
      });
    });

    it('should verify UUID generation is called correctly for each branch', () => {
      const mockUuid = require('uuid');
      jest.clearAllMocks();

      const mockResponse: DownstreamServiceResponseData = {
        data: {
          branches: [
            { branchId: '1', bankName: 'Bank 1' },
            { branchId: '2', bankName: 'Bank 2' },
            { branchId: '3', bankName: 'Bank 3' },
          ],
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      // UUID should be called once for each branch
      expect(mockUuid.v4).toHaveBeenCalledTimes(3);
      expect(result.bsbLookup).toHaveLength(3);
      result.bsbLookup.forEach(item => {
        expect(item.id).toBe('mock-uuid');
      });
    });

    it('should verify UUID generation is called once for empty branches array', () => {
      const mockUuid = require('uuid');
      jest.clearAllMocks();

      const mockResponse: DownstreamServiceResponseData = {
        data: {
          branches: [],
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      // UUID should be called once for the default empty case
      expect(mockUuid.v4).toHaveBeenCalledTimes(1);
      expect(result.bsbLookup).toHaveLength(1);
      expect(result.bsbLookup[0]).toEqual({
        id: 'mock-uuid',
        bankName: undefined,
      });
    });

    it('should handle performance test with realistic bank data patterns', () => {
      // Test with a more realistic dataset similar to what might come from a real API
      const australianBanks = [
        {
          bankName: 'Commonwealth Bank of Australia',
          bankCode: '06',
          brand: 'CBA',
        },
        {
          bankName: 'Westpac Banking Corporation',
          bankCode: '03',
          brand: 'WBC',
        },
        {
          bankName: 'Australia and New Zealand Banking Group',
          bankCode: '01',
          brand: 'ANZ',
        },
        { bankName: 'National Australia Bank', bankCode: '08', brand: 'NAB' },
        { bankName: 'Bank of Melbourne', bankCode: '183', brand: 'BOM' },
        { bankName: 'St.George Bank', bankCode: '112', brand: 'SGB' },
      ];

      const branches = australianBanks.flatMap(bank =>
        Array.from({ length: 10 }, (_, i) => ({
          branchId: `${bank.bankCode}-${String(i + 1).padStart(3, '0')}`,
          BSB: `${bank.bankCode}${String(i + 1).padStart(3, '0')}`,
          branchName: `${bank.brand} Branch ${i + 1}`,
          bankName: bank.bankName,
          bankCode: bank.bankCode,
          brand: bank.brand as 'WBC' | 'SGB' | 'BOM' | 'BSA',
          branchStatus: 'OPERATIONAL' as const,
          branchAvailable: true,
        }))
      );

      const mockResponse: DownstreamServiceResponseData = {
        data: { branches },
      };

      const startTime = performance.now();
      const result = transformDownstreamResponseToUi(mockResponse);
      const endTime = performance.now();

      expect(result.bsbLookup).toHaveLength(60); // 6 banks × 10 branches
      expect(endTime - startTime).toBeLessThan(50); // Should be very fast

      // Verify first and last entries
      expect(result.bsbLookup[0]).toMatchObject({
        id: 'mock-uuid',
        branchId: '06-001',
        BSB: '06001',
        bankName: 'Commonwealth Bank of Australia',
      });

      expect(result.bsbLookup[59]).toMatchObject({
        id: 'mock-uuid',
        branchId: '112-010',
        BSB: '112010',
        bankName: 'St.George Bank',
      });
    });

    it('should maintain immutability of original branch objects', () => {
      const originalBranch = {
        branchId: 'immutable-test',
        BSB: '123456',
        branchName: 'Immutable Branch',
        bankName: 'Immutable Bank',
        nested: {
          property: 'original-value',
        },
      };

      const mockResponse: DownstreamServiceResponseData = {
        data: {
          branches: [originalBranch],
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      // Original object should not be modified
      expect(originalBranch).not.toHaveProperty('id');
      expect(originalBranch.nested.property).toBe('original-value');

      // Result should have the added properties
      expect(result.bsbLookup[0]).toHaveProperty('id', 'mock-uuid');
      expect(result.bsbLookup[0]).toHaveProperty('branchId', 'immutable-test');
      expect(result.bsbLookup[0]).toHaveProperty('bankName', 'Immutable Bank');
    });

    it('should ensure 100% branch coverage for bsbLookupData.length > 0 condition', () => {
      // This test specifically targets the true branch of `bsbLookupData.length > 0`
      const mockResponse: DownstreamServiceResponseData = {
        data: {
          branches: [
            {
              branchId: 'coverage-test-1',
              bankName: 'Coverage Bank 1',
            },
          ],
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      // Verify we hit the true branch of the length check
      expect(result.bsbLookup).toHaveLength(1);
      expect(result.bsbLookup[0]).toEqual({
        id: 'mock-uuid',
        branchId: 'coverage-test-1',
        bankName: 'Coverage Bank 1',
      });
    });

    it('should ensure 100% branch coverage for bsbLookupData.length === 0 condition', () => {
      // This test specifically targets the false branch of `bsbLookupData.length > 0`
      const mockResponse: DownstreamServiceResponseData = {
        data: {
          branches: [], // Empty array - should trigger the false branch
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      // Verify we hit the false branch of the length check
      expect(result.bsbLookup).toHaveLength(1);
      expect(result.bsbLookup[0]).toEqual({
        id: 'mock-uuid',
        bankName: undefined,
      });
    });

    it('should verify consistent UUID pattern and data transformation quality', () => {
      const mockResponse: DownstreamServiceResponseData = {
        data: {
          branches: [
            { branchId: 'quality-test', bankName: 'Quality Bank' },
            { branchId: 'quality-test-2', bankName: 'Quality Bank 2' },
          ],
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      // Verify all branches get IDs
      expect(result.bsbLookup.every(item => item.id === 'mock-uuid')).toBe(
        true
      );
      expect(result.bsbLookup[0].branchId).toBe('quality-test');
      expect(result.bsbLookup[0].bankName).toBe('Quality Bank');
      expect(result.bsbLookup[1].branchId).toBe('quality-test-2');
      expect(result.bsbLookup[1].bankName).toBe('Quality Bank 2');
    });
  });
});
