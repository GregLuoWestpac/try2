// transformDownstreamResponseToUi.test.ts
import { DownstreamServiceResponseData } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { v4 as uuidv4 } from 'uuid';
import {
  transformDownstreamResponseToUi,
  ExpApiResponseData,
  PagingItem,
} from './retrieveBeneficiariesController.helper';

// Mock uuid to return a consistent value for testing
jest.mock('uuid', () => ({
  v4: jest.fn(() => 'mock-uuid'),
}));

describe('transformDownstreamResponseToUi', () => {
  it('should transform downstream response correctly', () => {
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        beneficiaries: [
          { id: '1', name: 'John Doe' },
          { id: '2', name: 'Jane Doe' },
        ],
      },
      paging: [
        {
          pageSize: 10,
          count: 2,
          previousPageKey: null,
          nextPageKey: 'next-key',
        },
      ] as any,
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      beneficiaryList: [
        { id: '1', name: 'John Doe', currencyAmount: {} },
        { id: '2', name: 'Jane Doe', currencyAmount: {} },
      ],
      paging: [
        {
          id: 'mock-uuid',
          pageSize: 10,
          count: 2,
          previousPageKey: null,
          nextPageKey: 'next-key',
          moreItems: undefined,
        },
      ],
    });
  });

  it('should handle missing paging data', () => {
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        beneficiaries: [],
      },
      paging: undefined,
    };

    const result = transformDownstreamResponseToUi(mockResponse);

    expect(result).toEqual({
      beneficiaryList: [],
      paging: [
        {
          id: 'mock-uuid',
          pageSize: undefined,
          count: undefined,
          previousPageKey: undefined,
          nextPageKey: undefined,
          moreItems: undefined,
        },
      ],
    });
  });
});
