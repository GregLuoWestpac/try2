import {
  transformDownstreamResponseToUi,
  incrementCopCounters,
  incrementDailyCounterOnError,
} from './postAccountNameCheckController.helper';
import { AccountNameCheckResponse } from '../../../interfaces/models/downstream/payeeServicesV1';
import { getLimitCounter } from '../../utils/limitCounter';

// Mock uuid
jest.mock('uuid', () => ({
  v4: jest.fn(() => 'mocked-uuid-123'),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  getColorForCoPStatusCode: jest.fn((code?: string) => {
    if (!code) return undefined;
    if (code === 'V0C1') return 'Blue';
    if (code.includes('C3') || code.includes('C4')) return 'Amber';
    return 'Red';
  }),
}));

jest.mock('../../utils/limitCounter', () => ({
  getLimitCounter: jest.fn(),
}));

describe('postAccountNameCheckController.helper', () => {
  describe('transformDownstreamResponseToUi', () => {
    it('should transform downstream response with matchedAccountName and matchedStatus', () => {
      const mockResponse: AccountNameCheckResponse = {
        data: {
          matchedAccountName: 'Paul Walker',
          matchedStatus: {
            code: 'V0C1',
            description: 'A match response was returned by Verify+ and CoP',
          },
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result).toEqual([
        {
          id: 'mocked-uuid-123',
          matchedCOPAccountName: 'Paul Walker',
          matchedCOPColour: 'Blue',
          matchedCOPStatusCode: 'V0C1',
        },
      ]);
    });

    it('should handle response with only matchedAccountName (no matchedStatus)', () => {
      const mockResponse: AccountNameCheckResponse = {
        data: {
          matchedAccountName: 'John Doe',
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result).toEqual([
        {
          id: 'mocked-uuid-123',
          matchedCOPAccountName: 'John Doe',
          matchedCOPColour: undefined,
          matchedCOPStatusCode: undefined,
        },
      ]);
    });

    it('should handle response with matchedStatus but no matchedAccountName', () => {
      const mockResponse: AccountNameCheckResponse = {
        data: {
          matchedStatus: {
            code: 'V2C3',
            description: 'No match found',
          },
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result).toEqual([
        {
          id: 'mocked-uuid-123',
          matchedCOPAccountName: undefined,
          matchedCOPStatusCode: 'V2C3',
          matchedCOPColour: 'Amber',
        },
      ]);
    });

    it('should handle empty data object', () => {
      const mockResponse: AccountNameCheckResponse = {
        data: {},
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result).toEqual([
        {
          id: 'mocked-uuid-123',
          matchedCOPAccountName: undefined,
          matchedCOPStatusCode: undefined,
        },
      ]);
    });

    it('should only include matchedStatus code in the output', () => {
      const mockResponse: AccountNameCheckResponse = {
        data: {
          matchedAccountName: 'Apple Tree',
          matchedStatus: {
            code: 'V0C1',
            description: 'This description should not appear in output',
          },
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result[0].matchedCOPStatusCode).toEqual('V0C1');
    });
  });

  describe('incrementCopCounters', () => {
    /* eslint-disable @typescript-eslint/no-explicit-any */
    const mockRes = {
      locals: {
        logger: { info: jest.fn(), warn: jest.fn() },
      },
    } as any;
    const mockReq = {} as any;
    /* eslint-enable @typescript-eslint/no-explicit-any */
    const mockIncrementSessionIdCounter = jest.fn();
    const mockIncrementPaymentCounter = jest.fn();

    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('should return incremented: false when matchedStatus is missing', async () => {
      const result = await incrementCopCounters(
        undefined,
        mockIncrementSessionIdCounter,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123',
        'sessionIndex123'
      );

      expect(result).toEqual({
        incremented: false,
        message: 'no matchedStatus',
      });
      expect(mockRes.locals.logger.info).toHaveBeenCalledWith(
        'matchedStatus not present in response, skipping counter increment'
      );
    });

    it('should call incrementSessionIdCounter for V1C3 matchedStatus', async () => {
      (getLimitCounter as jest.Mock).mockResolvedValueOnce({
        counters: [{ session: { counter: 2 }, counter: 2 }],
      });

      const result = await incrementCopCounters(
        'V1C3',
        mockIncrementSessionIdCounter,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123',
        'sessionIndex123'
      );

      expect(result).toEqual({ incremented: true });
      expect(getLimitCounter).toHaveBeenCalledWith(
        'COP',
        mockIncrementSessionIdCounter,
        mockRes,
        mockReq,
        'userId123',
        'sessionIndex123'
      );
    });

    it('should call incrementPaymentCounter for V0C1 matchedStatus (daily only)', async () => {
      (getLimitCounter as jest.Mock).mockResolvedValueOnce({
        counters: [{ counter: 2 }],
      });

      const result = await incrementCopCounters(
        'V0C1',
        mockIncrementSessionIdCounter,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123',
        'sessionIndex123'
      );

      expect(result).toEqual({ incremented: true });
      expect(getLimitCounter).toHaveBeenCalledWith(
        'COP',
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123'
      );
    });

    it('should return warning message when counter increment fails', async () => {
      (getLimitCounter as jest.Mock).mockResolvedValueOnce({});

      const result = await incrementCopCounters(
        'V0C1',
        mockIncrementSessionIdCounter,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123',
        'sessionIndex123'
      );

      expect(result.incremented).toBe(false);
      expect(result.message).toBe(
        'COP limit failed to increment daily counter'
      );
      expect(mockRes.locals.logger.warn).toHaveBeenCalledWith(
        'COP limit failed to increment daily counter'
      );
    });

    it.each([
      'V1C3',
      'V1C4',
      'V2C3',
      'V2C4',
      'VAC3',
      'VTC3',
      'VEC3',
      'VAC4',
      'VTC4',
      'VEC4',
    ])(
      'should use incrementSessionIdCounter for %s matchedStatus',
      async statusCode => {
        (getLimitCounter as jest.Mock).mockResolvedValueOnce({
          counters: [{ session: { counter: 2 }, counter: 2 }],
        });

        await incrementCopCounters(
          statusCode,
          mockIncrementSessionIdCounter,
          mockIncrementPaymentCounter,
          mockRes,
          mockReq,
          'userId123',
          'sessionIndex123'
        );

        expect(getLimitCounter).toHaveBeenCalledWith(
          'COP',
          mockIncrementSessionIdCounter,
          expect.anything(),
          expect.anything(),
          expect.anything(),
          expect.anything()
        );
      }
    );
  });

  describe('incrementDailyCounterOnError', () => {
    /* eslint-disable @typescript-eslint/no-explicit-any */
    const mockRes = {
      locals: {
        logger: { warn: jest.fn() },
      },
    } as any;
    const mockReq = {} as any;
    /* eslint-enable @typescript-eslint/no-explicit-any */
    const mockIncrementPaymentCounter = jest.fn();

    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('should increment counter on 400 error', async () => {
      (getLimitCounter as jest.Mock).mockResolvedValueOnce({
        counters: [{ counter: 2 }],
      });

      await incrementDailyCounterOnError(
        400,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123'
      );

      expect(getLimitCounter).toHaveBeenCalledWith(
        'COP',
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123'
      );
    });

    it('should increment counter on 500 error', async () => {
      (getLimitCounter as jest.Mock).mockResolvedValueOnce({
        counters: [{ counter: 2 }],
      });

      await incrementDailyCounterOnError(
        500,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123'
      );

      expect(getLimitCounter).toHaveBeenCalledWith(
        'COP',
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123'
      );
    });

    it('should not increment counter on 404 error', async () => {
      await incrementDailyCounterOnError(
        404,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123'
      );

      expect(getLimitCounter).not.toHaveBeenCalled();
    });

    it('should not increment counter when status is undefined', async () => {
      await incrementDailyCounterOnError(
        undefined,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123'
      );

      expect(getLimitCounter).not.toHaveBeenCalled();
    });

    it('should handle getLimitCounter error gracefully', async () => {
      (getLimitCounter as jest.Mock).mockRejectedValueOnce(
        new Error('API error')
      );

      await incrementDailyCounterOnError(
        400,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123'
      );

      expect(mockRes.locals.logger.warn).toHaveBeenCalledWith(
        'Failed to increment daily counter on API error'
      );
    });
  });
});
