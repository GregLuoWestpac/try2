import { DownstreamServiceResponseData } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { mapBeneficiariesDownstream } from './beneficiary.helper';

describe('mapBeneficiariesDownstream', () => {
  it('should transform beneficiaries with amount and currency into currencyAmount object', () => {
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        beneficiaries: [
          {
            id: '1',
            name: 'John Doe',
            amount: 1000,
            currency: 'AUD',
            type: 'ACCOUNT',
          },
          {
            id: '2',
            name: 'Jane Smith',
            amount: 2500,
            currency: 'USD',
            type: 'PAYID',
          },
        ],
      },
    };

    const result = mapBeneficiariesDownstream(mockResponse);

    expect(result).toEqual([
      {
        id: '1',
        name: 'John Doe',
        type: 'ACCOUNT',
        currencyAmount: {
          amount: 1000,
          currencyCode: 'AUD',
        },
      },
      {
        id: '2',
        name: 'Jane Smith',
        type: 'PAYID',
        currencyAmount: {
          amount: 2500,
          currencyCode: 'USD',
        },
      },
    ]);
  });

  it('should handle beneficiaries with only amount', () => {
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        beneficiaries: [
          {
            id: '1',
            name: 'John Doe',
            amount: 500,
            type: 'ACCOUNT',
          },
        ],
      },
    };

    const result = mapBeneficiariesDownstream(mockResponse);

    expect(result).toEqual([
      {
        id: '1',
        name: 'John Doe',
        type: 'ACCOUNT',
        currencyAmount: {
          amount: 500,
        },
      },
    ]);
  });

  it('should handle beneficiaries with only currency', () => {
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        beneficiaries: [
          {
            id: '1',
            name: 'John Doe',
            currency: 'EUR',
            type: 'ACCOUNT',
          },
        ],
      },
    };

    const result = mapBeneficiariesDownstream(mockResponse);

    expect(result).toEqual([
      {
        id: '1',
        name: 'John Doe',
        type: 'ACCOUNT',
        currencyAmount: {
          currencyCode: 'EUR',
        },
      },
    ]);
  });

  it('should handle beneficiaries without amount or currency', () => {
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        beneficiaries: [
          {
            id: '1',
            name: 'John Doe',
            type: 'ACCOUNT',
          },
        ],
      },
    };

    const result = mapBeneficiariesDownstream(mockResponse);

    expect(result).toEqual([
      {
        id: '1',
        name: 'John Doe',
        type: 'ACCOUNT',
        currencyAmount: {},
      },
    ]);
  });

  it('should handle empty beneficiaries array', () => {
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        beneficiaries: [],
      },
    };

    const result = mapBeneficiariesDownstream(mockResponse);

    expect(result).toEqual([]);
  });

  it('should return beneficiaries as-is if not an array', () => {
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        beneficiaries: null,
      },
    };

    const result = mapBeneficiariesDownstream(mockResponse);

    expect(result).toBeNull();
  });

  it('should return beneficiaries as-is if undefined', () => {
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        beneficiaries: undefined,
      },
    };

    const result = mapBeneficiariesDownstream(mockResponse);

    expect(result).toBeUndefined();
  });

  it('should return beneficiaries as-is if object instead of array', () => {
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        beneficiaries: { id: '1', name: 'Single Object' },
      },
    };

    const result = mapBeneficiariesDownstream(mockResponse);

    expect(result).toEqual({ id: '1', name: 'Single Object' });
  });

  it('should preserve all other properties while transforming', () => {
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        beneficiaries: [
          {
            id: '1',
            externalId: 'ext-123',
            nickname: 'My Account',
            status: 'ACTIVE',
            type: 'ACCOUNT',
            amount: 1000,
            currency: 'AUD',
            org: 'test-org',
            account: {
              bsb: '123456',
              accountNumber: '987654321',
            },
            createdDate: '2024-01-01',
            lastModifiedDate: '2024-01-15',
          },
        ],
      },
    };

    const result = mapBeneficiariesDownstream(mockResponse);

    expect(result).toEqual([
      {
        id: '1',
        externalId: 'ext-123',
        nickname: 'My Account',
        status: 'ACTIVE',
        type: 'ACCOUNT',
        org: 'test-org',
        account: {
          bsb: '123456',
          accountNumber: '987654321',
        },
        createdDate: '2024-01-01',
        lastModifiedDate: '2024-01-15',
        currencyAmount: {
          amount: 1000,
          currencyCode: 'AUD',
        },
      },
    ]);
  });

  it('should handle amount as zero', () => {
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        beneficiaries: [
          {
            id: '1',
            name: 'Zero Amount',
            amount: 0,
            currency: 'AUD',
            type: 'ACCOUNT',
          },
        ],
      },
    };

    const result = mapBeneficiariesDownstream(mockResponse);

    // Note: amount: 0 is falsy, so it won't be included in currencyAmount
    expect(result).toEqual([
      {
        id: '1',
        name: 'Zero Amount',
        type: 'ACCOUNT',
        currencyAmount: {
          currencyCode: 'AUD',
        },
      },
    ]);
  });

  it('should handle multiple beneficiaries with mixed data', () => {
    const mockResponse: DownstreamServiceResponseData = {
      data: {
        beneficiaries: [
          {
            id: '1',
            name: 'Full Data',
            amount: 1000,
            currency: 'AUD',
            type: 'ACCOUNT',
          },
          {
            id: '2',
            name: 'No Amount',
            currency: 'USD',
            type: 'PAYID',
          },
          {
            id: '3',
            name: 'No Currency',
            amount: 500,
            type: 'ACCOUNT',
          },
          {
            id: '4',
            name: 'Neither',
            type: 'PAYID',
          },
        ],
      },
    };

    const result = mapBeneficiariesDownstream(mockResponse);

    expect(result).toEqual([
      {
        id: '1',
        name: 'Full Data',
        type: 'ACCOUNT',
        currencyAmount: {
          amount: 1000,
          currencyCode: 'AUD',
        },
      },
      {
        id: '2',
        name: 'No Amount',
        type: 'PAYID',
        currencyAmount: {
          currencyCode: 'USD',
        },
      },
      {
        id: '3',
        name: 'No Currency',
        type: 'ACCOUNT',
        currencyAmount: {
          amount: 500,
        },
      },
      {
        id: '4',
        name: 'Neither',
        type: 'PAYID',
        currencyAmount: {},
      },
    ]);
  });
});
