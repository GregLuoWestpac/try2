/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { Request, Response, NextFunction } from 'express';
import {
  accessControlExposeHeaders,
  APIClient,
  APIClientError,
  DownstreamServiceResponse,
  handleApiService,
  handleControllerError,
  normaliseData,
  STATUS_CODES,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import { infBnkngChnlBrchntwkV2Services } from '../../generated/api-clients';
import {
  BsbLookupItem,
  ExpApiResponseData,
  transformDownstreamResponseToUi,
} from '../helpers/getBsbLookupController.helper';

/**
 * getBsbLookupController
 * @param {object} req - Implicit HTTP request object based on http.IncomingMessage
 * @param {object} res - Implicit HTTP response object based on http.ServerResponse
 */
const getBsbLookupController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { logger } = res.locals;

  const { getBranchReferenceData } = infBnkngChnlBrchntwkV2Services;
  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);
  try {
    const downstreamResponse: DownstreamServiceResponse =
      await handleApiService({
        req,
        res,
        apiClient: getBranchReferenceData as unknown as APIClient,
      });

    const branches = downstreamResponse?.data?.data
      ?.branches as BsbLookupItem[];
    if (branches?.length === 0) {
      res.status(404).end();
    }
    const expApiResponseData: ExpApiResponseData =
      transformDownstreamResponseToUi(downstreamResponse.data);

    const normalisedData = normaliseData(
      'bsbLookup',
      expApiResponseData.bsbLookup,
      normalise
    );

    res.status(STATUS_CODES.OK).json(normalisedData).end();
  } catch (error: unknown) {
    handleControllerError({ error: error as APIClientError, res, logger });
    next(error);
  }
  next();
};

export = getBsbLookupController;
