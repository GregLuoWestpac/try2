import { Request, Response, NextFunction } from 'express';
import {
  handleApiService,
  handleControllerError,
  STATUS_CODES,
  normaliseData,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { transformDownstreamResponseToUi } from '../helpers/retrieveBeneficiaryController.helper';
import { beneficiaryManagementV1Services } from '../../generated/api-clients';
import retrieveBeneficiaryController from './retrieveBeneficiaryController';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  handleApiService: jest.fn(),
  handleControllerError: jest.fn(),
  STATUS_CODES: { OK: 200 },
  normaliseData: jest.fn(),
}));

jest.mock('../helpers/retrieveBeneficiaryController.helper', () => ({
  transformDownstreamResponseToUi: jest.fn(),
}));

describe('retrieveBeneficiaryController', () => {
  let req: Partial<Request>;
  let res: any;
  let next: NextFunction;

  beforeEach(() => {
    req = {
      body: { id: 'd0868661-b955-4e76-9f15-d97626f7d78b' },
    };
    res = {
      locals: {
        logger: {
          error: jest.fn(),
          warn: jest.fn(),
          log: jest.fn(),
          info: jest.fn(),
          debug: jest.fn(),
        },
      },
      status: jest.fn().mockReturnThis(), // Mock status to return `this`
      json: jest.fn().mockReturnThis(), // Mock json to return `this`
      setHeader: jest.fn(),
      end: jest.fn(), // Mock end to complete the chain
    };
    next = jest.fn();
  });

  it('should return normalized data when API call is successful', async () => {
    const mockApiResponse = {
      data: {
        id: 'd0868661-b955-4e76-9f15-d97626f7d78b',
        externalId: '123456789',
        nickname: 'office 1',
        currency: 'abc',
        org: 'office1',
        account: {},
      },
    };

    // Mock the API service and helper functions
    (handleApiService as jest.Mock).mockResolvedValue(mockApiResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      mockApiResponse.data
    );
    (normaliseData as jest.Mock).mockReturnValue(mockApiResponse.data);

    // Call the controller function
    await retrieveBeneficiaryController(req as Request, res as Response, next);

    // Assert that the controller calls the service, transforms data, and returns the correct response
    expect(handleApiService).toHaveBeenCalledWith(
      expect.objectContaining({
        req: expect.any(Object), // Accept any object for req
        res: expect.any(Object),
        apiClient: beneficiaryManagementV1Services.getBeneficiaryDetail,
        pathParams: { id: 'd0868661-b955-4e76-9f15-d97626f7d78b' },
      })
    );

    expect(transformDownstreamResponseToUi).toHaveBeenCalledWith(
      mockApiResponse.data
    );
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK); // Ensure status is set
    expect(res.json).toHaveBeenCalledWith(mockApiResponse.data); // Ensure json is called with data
    expect(res.end).toHaveBeenCalled(); // Ensure end is called to complete the response
  });

  it('should handle errors and call handleControllerError', async () => {
    const mockError = new Error('API error');
    (handleApiService as jest.Mock).mockRejectedValue(mockError);

    // Call the controller function
    await retrieveBeneficiaryController(req as Request, res as Response, next);

    // Ensure the error handling function is called
    expect(handleControllerError).toHaveBeenCalledWith({
      error: mockError,
      res,
      logger: res.locals.logger,
    });

    // Ensure that next is called with the error
    expect(next).toHaveBeenCalledWith(mockError);
  });
});
