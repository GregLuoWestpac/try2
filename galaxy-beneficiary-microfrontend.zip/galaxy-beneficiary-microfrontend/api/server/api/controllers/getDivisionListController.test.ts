/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable prefer-promise-reject-errors */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-explicit-any */

import {
  handleControllerError,
  getDivisionsFromPdpQueryResult,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { createRequest, createResponse } from 'node-mocks-http';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-apiutils'),
  handleControllerError: jest.fn(),
  getDivisionsFromPdpQueryResult: jest.fn(),
}));

const controller = require('./getDivisionListController').default;
describe('getDivisionListController', () => {
  let req: any;
  let res: any;
  let next: jest.Mock;
  let mockLogger: any;

  beforeEach(() => {
    req = createRequest();
    res = createResponse();
    mockLogger = { info: jest.fn(), error: jest.fn(), warn: jest.fn() };
    res.locals = {
      apiHeaders: { 'x-userId': 'test-user' },
      logger: mockLogger,
    };
    next = jest.fn();
    jest.clearAllMocks();
    // Set default env var for local development tests
    process.env.MOCKED_ACCESS_TOKEN = 'test-access-token';
  });

  it('should respond with normalised division list data and status 200', async () => {
    const mockDivisionList = {
      requestId: 'c7b2a8a7-fc42-4711-9188-75e211a0a7af',
      timeStamp: '2025-10-13T04:40:44.974216619Z',
      deploymentPackageId: '01e240ed-c16f-4ab5-b2ab-c138adcd87cd',
      elapsedTime: 1672,
      results: [
        {
          attribute: 'RequestAttributes.DivisionId',
          value: 'a39d00a7-8710-4333-adbf-bb82e8c9bacf',
          decision: 'PERMIT',
          statements: [
            {
              id: 'd4aa185e-7e51-4e03-af8f-4e8efd03b18a',
              name: 'Division details',
              code: 'filter-response',
              payload: '{"name":"BYE ABC"}',
              obligatory: false,
              fulfilled: false,
              attributes: {},
            },
          ],
        },
      ],
    };
    const mockPDPResponse = { divisions: mockDivisionList };
    const mockTransformedResponse = mockDivisionList;
    const mockNormalisedData = { divisionList: mockDivisionList };

    (getDivisionsFromPdpQueryResult as jest.Mock).mockResolvedValue(
      mockPDPResponse
    );

    // Mock transform helper and normaliseData
    jest
      .spyOn(
        require('../helpers/getDivisionListController.helper'),
        'transformGetDivisionListResponse'
      )
      .mockReturnValue(mockTransformedResponse);

    jest
      .spyOn(
        require('@mesh-tenant-multiverse-ui-common/mv-apiutils'),
        'normaliseData'
      )
      .mockReturnValue(mockNormalisedData);

    await controller(req, res, next);

    expect(getDivisionsFromPdpQueryResult).toHaveBeenCalled();
    expect(res.statusCode).toBe(200);
    expect(res._getJSONData()).toEqual(mockNormalisedData);
    expect(res._isEndCalled()).toBe(true);
    expect(next).not.toHaveBeenCalled();
  });

  it('should call handleControllerError and next on error', async () => {
    const error = new Error('Test error');
    (getDivisionsFromPdpQueryResult as jest.Mock).mockRejectedValue(error);

    await controller(req, res, next);

    expect(handleControllerError).toHaveBeenCalledWith(
      expect.objectContaining({ error, res, logger: mockLogger })
    );
    expect(next).toHaveBeenCalledWith(error);
  });

  it('should use secrets in non-local runtime', async () => {
    const mockSecrets = { pdpClientToken: 'secret-token', org: 'secret-org' };
    jest
      .spyOn(require('@mep-node/framework-constants').RUNTIME, 'isLocal')
      .mockReturnValue(false);
    jest
      .spyOn(require('../../utils/secretsUtil'), 'readMeshSecrets')
      .mockReturnValue(mockSecrets);

    (getDivisionsFromPdpQueryResult as jest.Mock).mockResolvedValue({
      divisions: [],
    });

    await controller(req, res, next);

    expect(
      require('../../utils/secretsUtil').readMeshSecrets
    ).toHaveBeenCalledWith(mockLogger);
    expect(getDivisionsFromPdpQueryResult).toHaveBeenCalledWith(
      expect.objectContaining({
        pdpClientToken: 'secret-token',
        orgCisKey: 'secret-org',
      })
    );
  });

  it('should use test token in local runtime', async () => {
    jest
      .spyOn(require('@mep-node/framework-constants').RUNTIME, 'isLocal')
      .mockReturnValue(true);

    (getDivisionsFromPdpQueryResult as jest.Mock).mockResolvedValue({
      divisions: [],
    });

    await controller(req, res, next);

    expect(req.headers['x-access-token']).toBeUndefined(); // token is set on apiHeaders, not req.headers
    expect(res.locals.apiHeaders['x-access-token']).toBe('test-access-token');
    expect(mockLogger.warn).toHaveBeenCalledWith(
      'Using mocked access token for local development'
    );
    expect(getDivisionsFromPdpQueryResult).toHaveBeenCalledWith(
      expect.objectContaining({
        pdpClientToken: 'test-token',
      })
    );
  });
});
