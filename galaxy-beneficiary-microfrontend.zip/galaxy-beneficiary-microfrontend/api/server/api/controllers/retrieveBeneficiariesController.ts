/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { RUNTIME } from '@mep-node/framework-constants';
import { Request, Response, NextFunction } from 'express';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import {
  handleControllerError,
  handleApiService,
  normaliseDataWithPaging,
  APIClientError,
  STATUS_CODES,
  DownstreamServiceResponse,
  transformPdpQueryResult,
  getBeneficiaryIdsFromPdpQueryResult,
  accessControlExposeHeaders,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { PDP_QUERY_ACTIONS } from '@mesh-tenant-user-authorisation-policy-decision-engine/entitlements-api-lib';
import {
  beneficiaryManagementV1Services,
  userAuthorisationPolicyDecisionEngineApiV1Services,
} from '../../generated/api-clients';
import {
  transformDownstreamResponseToUi,
  ExpApiResponseData,
} from '../helpers/retrieveBeneficiariesController.helper';
import { readMeshSecrets } from '../../utils/secretsUtil';
import { RetrieveBeneficiariesRequest } from '../../../types/retrieveBeneficiariesRequest';
import { detectInjectionVulnerability } from '@mesh-tenant-multiverse-ui-common/mv-injection-checker';
const retrieveBeneficiariesController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { logger } = res.locals;
  const protectedOrgCisKeyId = req.get('protected-orgId');

  const { ListBeneficiaries } = beneficiaryManagementV1Services;
  const { queryDecisionRequest } =
    userAuthorisationPolicyDecisionEngineApiV1Services;
  const requestBody: RetrieveBeneficiariesRequest = {
    ids: [],
    ...(req.body?.searchCriteria ? { query: req.body?.searchCriteria } : {}),
    ...(req.body?.statuses ? { statuses: req.body?.statuses } : {}),
  }; // list of beneficiary ids to be sent to downsatream
  let downstreamResponse: DownstreamServiceResponse;

  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);
  try {
    const propertiesToValidate: Record<string, string> = {
      query: 'query',
    };

    const { vulnerabilityDetected, message, vulnerableFields } =
      detectInjectionVulnerability(requestBody, propertiesToValidate);
    if (vulnerabilityDetected) {
      logger.trace(`${message} Vulnerable fields:`, vulnerableFields);
      return res.status(STATUS_CODES.BAD_REQUEST).json(message).end();
    }
    if (!RUNTIME.isLocal()) {
      const meshSecretsContent = readMeshSecrets(logger);
      const { pdpClientToken } = meshSecretsContent;
      if (!pdpClientToken) {
        logger.error('pdpClientToken is not defined.');
      }

      const pdpQueryResults = await getBeneficiaryIdsFromPdpQueryResult({
        req,
        res,
        queryDecisionRequest,
        pdpClientToken,
        orgCisKey: protectedOrgCisKeyId,
        requestAction: PDP_QUERY_ACTIONS.VIEW_BENEFICIARY,
      });

      if (pdpQueryResults?.length > 0) {
        requestBody.ids = transformPdpQueryResult(pdpQueryResults);
      } else {
        logger.error('No data in the PDP Query result');
        downstreamResponse = {
          data: {
            data: { beneficiaries: [] },
            result: null,
          },
        } as unknown as DownstreamServiceResponse;
      }
    }

    if (!downstreamResponse) {
      downstreamResponse = await handleApiService({
        req,
        res,
        requestBody,
        apiClient: ListBeneficiaries,
      });
    }
    const expApiResponseData: ExpApiResponseData =
      transformDownstreamResponseToUi(downstreamResponse.data);

    const normalisedData = normaliseDataWithPaging(
      'beneficiaryList',
      expApiResponseData,
      normalise
    );

    res.status(STATUS_CODES.OK).json(normalisedData).end();
  } catch (error: unknown) {
    handleControllerError({ error: error as APIClientError, res, logger });
    next(error);
  }
};

export = retrieveBeneficiariesController;
