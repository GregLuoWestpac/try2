import { RUNTIME } from '@mep-node/framework-constants';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import { buildCreateBeneficiaryController } from '@mesh-tenant-multiverse-ui-common/mv-apibeneficiarycreate';
import { ControllerParams } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { beneficiaryManagementV1Services } from '../../generated/api-clients';
import { readMeshSecrets } from '../../utils/secretsUtil';

const controllerParams: ControllerParams = {
  RUNTIME,
  normalise,
  apiClient: beneficiaryManagementV1Services,
  readMeshSecrets,
};

const createBeneficiariesController =
  buildCreateBeneficiaryController(controllerParams);

export = createBeneficiariesController;
