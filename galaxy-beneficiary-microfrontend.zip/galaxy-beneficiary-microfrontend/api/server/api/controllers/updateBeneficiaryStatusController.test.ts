/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  handleApiService,
  handleControllerError,
  Logger,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { NextFunction, Request, Response } from 'express';
import { beneficiaryManagementV1Services } from '../../generated/api-clients';
import updateBeneficiaryStatusController from './updateBeneficiaryStatusController';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  handleControllerError: jest.fn(),
  handleApiService: jest.fn(),
  normaliseData: jest.fn(),
  STATUS_CODES: { NO_CONTENT: 204 },
}));

jest.mock('../../generated/api-clients', () => ({
  beneficiaryManagementV1Services: {
    updateBeneficiaryStatus: jest.fn(),
  },
}));

describe('updateBeneficiaryStatusController', () => {
  let req: Partial<Request>;
  let res: any;
  let next: NextFunction;
  let logger: Logger;

  beforeEach(() => {
    req = {
      body: {
        beneficiary: {
          id: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
          status: 'ACTIVE',
        },
      },
    };

    res = {
      locals: {},
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      setHeader: jest.fn(),
      end: jest.fn(),
    };

    next = jest.fn();
    logger = res.locals.logger;
  });

  it('should return successful downstream data', async () => {
    (handleApiService as jest.Mock).mockReturnValue({ status: 204 });

    await updateBeneficiaryStatusController(
      req as Request,
      res as Response,
      next
    );

    expect(handleApiService).toHaveBeenCalledWith({
      req,
      res,
      apiClient: beneficiaryManagementV1Services.updateBeneficiaryStatus,
      setDownstreamParams: expect.any(Function),
      pathParams: {
        id: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      },
      requestBody: {
        status: 'ACTIVE',
      },
    });
    expect(res.status).toHaveBeenCalledWith(204);
    expect(res.json).toHaveBeenCalledWith(undefined);
  });
  it('should handle error response', async () => {
    const error = new Error('Test error');
    (handleApiService as jest.Mock).mockRejectedValue(error);

    await updateBeneficiaryStatusController(
      req as Request,
      res as Response,
      next
    );

    expect(handleControllerError).toHaveBeenCalledWith({ error, res, logger });
    expect(next).toHaveBeenCalledWith(error);
  });
});
