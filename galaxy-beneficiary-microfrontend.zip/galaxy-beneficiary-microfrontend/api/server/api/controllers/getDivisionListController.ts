/* eslint-disable @typescript-eslint/no-unnecessary-type-assertion */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { Request, Response, NextFunction } from 'express';
import { RUNTIME } from '@mep-node/framework-constants';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import {
  handleControllerError,
  normaliseData,
  STATUS_CODES,
  getDivisionsFromPdpQueryResult,
  ApiResponse,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { userAuthorisationPolicyDecisionEngineApiV1Services } from '../../generated/api-clients';
import { readMeshSecrets } from '../../utils/secretsUtil';
import {
  transformGetDivisionListResponse,
  ExpApiResponseData,
} from '../helpers/getDivisionListController.helper';
import { BENEFICIARY_REQUEST_ACTION } from '../../utils/apiConstants';

const getDivisionListController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { apiHeaders, logger } = res.locals;
  const { OK } = STATUS_CODES;

  const protectedOrgId = req.get('protected-orgid');
  const userId = apiHeaders['x-userId'];
  const { queryDecisionRequest } =
    userAuthorisationPolicyDecisionEngineApiV1Services;
  let pdpClientToken: string;
  let org: string;
  try {
    if (!RUNTIME.isLocal()) {
      const meshSecretsContent = readMeshSecrets(logger);
      org = meshSecretsContent?.org;
      pdpClientToken = meshSecretsContent?.pdpClientToken;
    } else {
      if (process.env.NODE_ENV === 'production') {
        throw new Error(
          'Mock token path must not be used in production. ' +
            'Check RUNTIME.isLocal() configuration.'
        );
      }
      const mockedAccessToken = process.env.MOCKED_ACCESS_TOKEN;
      if (!mockedAccessToken) {
        throw new Error(
          'MOCKED_ACCESS_TOKEN environment variable must be set for local development. ' +
            'Add it to your local .env file.'
        );
      }
      logger.warn('Using mocked access token for local development');
      apiHeaders['x-access-token'] = mockedAccessToken;
      pdpClientToken = process.env.MOCKED_PDP_CLIENT_TOKEN || 'test-token';
    }
    const divisionListPDPResponse = await getDivisionsFromPdpQueryResult({
      res,
      req,
      queryDecisionRequest,
      pdpClientToken,
      orgCisKey: protectedOrgId ?? org,
      userId,
      requestAction: BENEFICIARY_REQUEST_ACTION,
    });

    const getDivisionResponse = transformGetDivisionListResponse(
      divisionListPDPResponse
    );

    // amend normalisedData, avoid missing divisionList field in entity when division list in result is empty
    const schemaKey = 'divisionList';
    const normalisedData = normaliseData(
      schemaKey,
      getDivisionResponse,
      normalise
    ) as ApiResponse<{ divisionList: ExpApiResponseData }> & {
      entities?: Record<string, unknown[]>;
      result?: Record<string, unknown[]>;
    };

    if (
      normalisedData &&
      'result' in normalisedData &&
      !Array.isArray(normalisedData.entities?.[schemaKey]) &&
      Array.isArray(normalisedData.result?.[schemaKey])
    ) {
      (normalisedData as { entities: Record<string, unknown[]> }).entities ??=
        {};
      (normalisedData as { entities: Record<string, unknown[]> }).entities[
        schemaKey
      ] = [];
    }

    res.status(OK).json(normalisedData).end();
  } catch (error) {
    handleControllerError({ error, res, logger });
    next(error);
  }
};

export default getDivisionListController;
