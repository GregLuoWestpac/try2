import {
  handleApiService,
  handleControllerError,
  Logger,
  normaliseData,
  STATUS_CODES,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { NextFunction, Request, Response } from 'express';
import archiveBeneficiariesController from './archiveBeneficiariesController';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  handleApiService: jest.fn(),
  handleControllerError: jest.fn(),
  STATUS_CODES: { OK: 200, BAD_REQUEST: 400 },
  normaliseData: jest.fn(),
}));

describe('archiveBeneficiariesController', () => {
  let req: Partial<Request>;
  let res: any;
  let next: NextFunction;
  let logger: Logger;

  beforeEach(() => {
    req = {
      body: {
        beneficiary: {
          id: '159a4a84-062b-4a79-a567-8ced0d6656e4',
          externalId: '159a4a84-062b-4a79-a567-8ced0d6656e4',
          nickname: 'Alpha Beta',
          currency: 'AUD',
          org: '19546900027',
          status: 'ACTIVE',
          type: 'BSB_ACCOUNT_NUMBER',
          account: {
            accountId: {
              accountNumber: '848330094',
              BSB: '646001',
            },
            accountName: 'Alpha Beta',
            bankName: 'Maitland Mutual Building Soc Ltd',
          },
        },
      },
    };
    res = {
      locals: { logger: { error: jest.fn() } },
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      setHeader: jest.fn(),
      end: jest.fn(),
    };
    next = jest.fn();
    logger = res.locals.logger;
  });

  it('should archive beneficiaries and return normalized data', async () => {
    const mockDownstreamResponse = undefined;
    const id = req.body.beneficiary?.id;
    const mockExpApiResponseData = [{ id }];
    const mockNormalisedData = {};

    (handleApiService as jest.Mock).mockResolvedValue(mockDownstreamResponse);
    (normaliseData as jest.Mock).mockReturnValue(mockNormalisedData);

    await archiveBeneficiariesController(req as Request, res as Response, next);

    expect(handleApiService).toHaveBeenCalledWith({
      req,
      res,
      apiClient: expect.any(Function),
      setDownstreamParams: expect.any(Function),
      pathParams: {
        id,
      },
    });
    expect(normaliseData).toHaveBeenCalledWith(
      'beneficiaryArchive',
      mockExpApiResponseData,
      expect.any(Function)
    );
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK);
    expect(res.json).toHaveBeenCalledWith(mockNormalisedData);
    expect(res.end).toHaveBeenCalled();
  });

  it('should handle errors and call next with error', async () => {
    const mockError = new Error('Test error');
    (handleApiService as jest.Mock).mockRejectedValue(mockError);

    await archiveBeneficiariesController(req as Request, res as Response, next);

    expect(handleControllerError).toHaveBeenCalledWith({
      error: mockError,
      res,
      logger,
    });
    expect(next).toHaveBeenCalledWith(mockError);
  });

  it('should handle null or undefined downstream response', async () => {
    (handleApiService as jest.Mock).mockResolvedValue(null);
    (normaliseData as jest.Mock).mockReturnValue(null);

    await archiveBeneficiariesController(req as Request, res as Response, next);

    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK);
    expect(res.json).toHaveBeenCalledWith(null);
    expect(res.end).toHaveBeenCalled();
  });

  it('should pass x-channelRequestId in headers to handleApiService', async () => {
    req = {
      body: { beneficiary: { id: 'archive-id' } },
      headers: { 'x-channelRequestId': 'test-archive-id' },
    };
    const mockDownstreamResponse = undefined;
    const id = req.body.beneficiary.id;
    const mockNormalisedData = {};

    (handleApiService as jest.Mock).mockResolvedValue(mockDownstreamResponse);
    (normaliseData as jest.Mock).mockReturnValue(mockNormalisedData);

    await archiveBeneficiariesController(req as Request, res as Response, next);

    expect(handleApiService).toHaveBeenCalledWith({
      req: expect.objectContaining({
        headers: expect.objectContaining({
          'x-channelRequestId': 'test-archive-id',
        }),
      }),
      res,
      apiClient: expect.any(Function),
      setDownstreamParams: expect.any(Function),
      pathParams: {
        id,
      },
    });
  });

  it('should handle unexpected response format gracefully', async () => {
    const mockDownstreamResponse = { unexpectedKey: 'unexpectedValue' };

    (handleApiService as jest.Mock).mockResolvedValue(mockDownstreamResponse);

    await archiveBeneficiariesController(req as Request, res as Response, next);

    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK);
    expect(res.end).toHaveBeenCalled();
  });
});
