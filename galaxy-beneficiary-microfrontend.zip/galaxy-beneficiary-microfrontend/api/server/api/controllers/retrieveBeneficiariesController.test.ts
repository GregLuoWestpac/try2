/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response, NextFunction } from 'express';
import {
  handleApiService,
  normaliseDataWithPaging,
  STATUS_CODES,
  transformPdpQueryResult,
  getBeneficiaryIdsFromPdpQueryResult,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { RUNTIME } from '@mep-node/framework-constants';
import { transformDownstreamResponseToUi } from '../helpers/retrieveBeneficiariesController.helper';
import { beneficiaryManagementV1Services } from '../../generated/api-clients';
import retrieveBeneficiariesController from './retrieveBeneficiariesController';
import { readMeshSecrets } from '../../utils/secretsUtil';
import { detectInjectionVulnerability } from '@mesh-tenant-multiverse-ui-common/mv-injection-checker';
jest.mock('@mesh-tenant-multiverse-ui-common/mv-injection-checker', () => ({
  detectInjectionVulnerability: jest.fn(() => ({
    vulnerabilityDetected: false,
    message: '',
    vulnerableFields: [],
  })),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  handleApiService: jest.fn(),
  handleControllerError: jest.fn(),
  STATUS_CODES: { OK: 200, BAD_REQUEST: 400 },
  normaliseDataWithPaging: jest.fn(),
  transformPdpQueryResult: jest.fn(),
  getBeneficiaryIdsFromPdpQueryResult: jest.fn(),
}));

jest.mock('@mep-node/framework-constants', () => ({
  RUNTIME: { isLocal: jest.fn() },
}));

jest.mock('../../utils/secretsUtil', () => ({
  readMeshSecrets: jest.fn(),
}));

jest.mock('@mep-node/framework-response-normaliser-addon', () => ({
  normaliseData: jest.fn(),
}));

jest.mock('../helpers/retrieveBeneficiariesController.helper', () => ({
  transformDownstreamResponseToUi: jest.fn(),
}));

jest.mock(
  '@mesh-tenant-user-authorisation-policy-decision-engine/entitlements-api-lib',
  () => ({
    PDP_QUERY_ACTIONS: {
      VIEW_BENEFICIARY: 'VIEW_BENEFICIARY',
    },
  })
);

describe('retrieveBeneficiariesController - with PDP logic', () => {
  let req: Partial<Request>;
  let res: any;
  let next: NextFunction;

  beforeEach(() => {
    req = {
      get: jest.fn().mockReturnValue('mock-orgId'),
      body: {},
    };
    res = {
      locals: {
        logger: {
          error: jest.fn(),
          warn: jest.fn(),
          log: jest.fn(),
          info: jest.fn(),
          debug: jest.fn(),
          trace: jest.fn(),
        },
      },
      status: jest.fn().mockReturnThis(),
      setHeader: jest.fn(),
      json: jest.fn().mockReturnThis(),
      send: jest.fn().mockReturnThis(),
      end: jest.fn(),
    };
    next = jest.fn();
    jest.clearAllMocks();
  });

  it('should call PDP flow and return beneficiary list', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (readMeshSecrets as jest.Mock).mockReturnValue({
      pdpClientToken: 'mock-token',
    });
    (getBeneficiaryIdsFromPdpQueryResult as jest.Mock).mockResolvedValue([
      { id: '1' },
      { id: '2' },
    ]);
    (transformPdpQueryResult as jest.Mock).mockReturnValue(['1', '2']);

    const mockApiResponse = {
      data: {
        beneficiaries: [
          {
            id: '123456789',
            externalId: '123456789',
            nickname: 'office 1',
            currency: 'abc',
            org: 'office1',
            status: 'ACTIVE',
            type: 'PAYID',
            account: {},
          },
        ],
      },
      paging: {
        id: '1',
        pageSize: 50,
        count: 160,
        previousPageKey: '0',
        nextPageKey: '2',
        moreItems: true,
      },
    };

    // Mock the API service and helper functions
    (handleApiService as jest.Mock).mockResolvedValue(mockApiResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      mockApiResponse.data
    );
    (normaliseDataWithPaging as jest.Mock).mockReturnValue(
      mockApiResponse.data
    );

    // Call the controller function
    await retrieveBeneficiariesController(
      req as Request,
      res as Response,
      next
    );

    // Assert that the controller calls the service, transforms data, and returns the correct response
    expect(handleApiService).toHaveBeenCalledWith({
      req,
      res,
      requestBody: {
        ids: ['1', '2'],
      },
      apiClient: beneficiaryManagementV1Services.ListBeneficiaries,
    });

    expect(transformDownstreamResponseToUi).toHaveBeenCalledWith(
      mockApiResponse.data
    );
    expect(readMeshSecrets).toHaveBeenCalled();
    expect(getBeneficiaryIdsFromPdpQueryResult).toHaveBeenCalled();
    expect(transformPdpQueryResult).toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK); // Ensure status is set
    expect(res.json).toHaveBeenCalledWith(mockApiResponse.data); // Ensure json is called with data
    expect(res.end).toHaveBeenCalled(); // Ensure end is called to complete the response
  });

  it('should handle when PDP Query returns no ids', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (readMeshSecrets as jest.Mock).mockReturnValue({
      pdpClientToken: 'mock-token',
    });
    (getBeneficiaryIdsFromPdpQueryResult as jest.Mock).mockResolvedValue([]);
    // Call the controller function
    await retrieveBeneficiariesController(
      req as Request,
      res as Response,
      next
    );

    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK);
    expect(res.json).toHaveBeenCalled();
    expect(handleApiService).not.toHaveBeenCalled();
    expect(res.end).toHaveBeenCalled();
  });

  it('should call handleApiService directly if running locally', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(true);

    const mockApiResponse = {
      data: {
        beneficiaries: [
          {
            id: 'local123',
            externalId: 'local123',
            nickname: 'Local Office',
            currency: 'xyz',
            org: 'localOrg',
            status: 'ACTIVE',
            type: 'PAYID',
            account: {},
          },
        ],
      },
      paging: {
        id: '1',
        pageSize: 10,
        count: 10,
        previousPageKey: null,
        nextPageKey: null,
        moreItems: false,
      },
    };

    (handleApiService as jest.Mock).mockResolvedValue(mockApiResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      mockApiResponse.data
    );
    (normaliseDataWithPaging as jest.Mock).mockReturnValue(
      mockApiResponse.data
    );

    await retrieveBeneficiariesController(
      req as Request,
      res as Response,
      next
    );

    expect(RUNTIME.isLocal).toHaveBeenCalled();
    expect(handleApiService).toHaveBeenCalledWith({
      req,
      res,
      requestBody: { ids: [] },
      apiClient: beneficiaryManagementV1Services.ListBeneficiaries,
    });
    expect(transformDownstreamResponseToUi).toHaveBeenCalledWith(
      mockApiResponse.data
    );
    expect(normaliseDataWithPaging).toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK);
    expect(res.json).toHaveBeenCalledWith(mockApiResponse.data);
    expect(res.end).toHaveBeenCalled();
  });

  it('should construct pdpQueryRequestBody with orgId from query parameter', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (readMeshSecrets as jest.Mock).mockReturnValue({
      pdpClientToken: 'mock-token',
    });

    await retrieveBeneficiariesController(
      req as Request,
      res as Response,
      next
    );

    expect(getBeneficiaryIdsFromPdpQueryResult).toHaveBeenCalledWith(
      expect.objectContaining({
        orgCisKey: 'mock-orgId',
      })
    );
  });

  it('should log error when pdpClientToken is not defined', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (readMeshSecrets as jest.Mock).mockReturnValue({
      pdpClientToken: undefined, // Missing token
    });
    (getBeneficiaryIdsFromPdpQueryResult as jest.Mock).mockResolvedValue([]);

    await retrieveBeneficiariesController(
      req as Request,
      res as Response,
      next
    );

    expect(res.locals.logger.error).toHaveBeenCalledWith(
      'pdpClientToken is not defined.'
    );
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK);
    expect(res.end).toHaveBeenCalled();
  });

  it('should handle errors and call handleControllerError', async () => {
    const mockError = new Error('Test error');
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(true);
    (handleApiService as jest.Mock).mockRejectedValue(mockError);

    const {
      handleControllerError,
    } = require('@mesh-tenant-multiverse-ui-common/mv-apiutils');

    await retrieveBeneficiariesController(
      req as Request,
      res as Response,
      next
    );

    expect(handleControllerError).toHaveBeenCalledWith({
      error: mockError,
      res,
      logger: res.locals.logger,
    });
    expect(next).toHaveBeenCalledWith(mockError);
  });

  describe('Injection vulnerability detection', () => {
    beforeEach(() => {
      req.body = {
        searchCriteria: 'John Doe',
      };
    });

    it('should block request when query contains injection vulnerability', async () => {
      // Mock detectInjectionVulnerability to return vulnerability detected
      (detectInjectionVulnerability as jest.Mock).mockReturnValueOnce({
        vulnerabilityDetected: true,
        message: 'Injection vulnerabilities detected.',
        vulnerableFields: ['query'],
      });

      (RUNTIME.isLocal as jest.Mock).mockReturnValue(true);

      await retrieveBeneficiariesController(
        req as Request,
        res as Response,
        next
      );

      // Verify vulnerability was logged
      expect(res.locals.logger.trace).toHaveBeenCalledWith(
        'Injection vulnerabilities detected. Vulnerable fields:',
        ['query']
      );

      // Verify request was blocked with 400 status
      expect(res.status).toHaveBeenCalledWith(STATUS_CODES.BAD_REQUEST);
      expect(res.json).toHaveBeenCalledWith(
        'Injection vulnerabilities detected.'
      );
      expect(res.end).toHaveBeenCalled();

      // Verify handleApiService was NOT called
      expect(handleApiService).not.toHaveBeenCalled();
    });

    it('should block request with multiple vulnerable fields', async () => {
      req.body = {
        searchCriteria: '<script>alert("XSS")</script>',
      };

      (detectInjectionVulnerability as jest.Mock).mockReturnValueOnce({
        vulnerabilityDetected: true,
        message: 'Injection vulnerabilities detected.',
        vulnerableFields: ['query', 'statuses[0]'],
      });

      (RUNTIME.isLocal as jest.Mock).mockReturnValue(true);

      await retrieveBeneficiariesController(
        req as Request,
        res as Response,
        next
      );

      expect(res.locals.logger.trace).toHaveBeenCalledWith(
        'Injection vulnerabilities detected. Vulnerable fields:',
        ['query', 'statuses[0]']
      );
      expect(res.status).toHaveBeenCalledWith(STATUS_CODES.BAD_REQUEST);
      expect(res.json).toHaveBeenCalledWith(
        'Injection vulnerabilities detected.'
      );
      expect(handleApiService).not.toHaveBeenCalled();
    });

    it('should allow request when no vulnerabilities are detected', async () => {
      req.body = {
        searchCriteria: 'John Doe',
      };

      (detectInjectionVulnerability as jest.Mock).mockReturnValueOnce({
        vulnerabilityDetected: false,
        message: '',
        vulnerableFields: [],
      });

      (RUNTIME.isLocal as jest.Mock).mockReturnValue(true);

      const mockApiResponse = {
        data: {
          beneficiaries: [],
        },
        paging: {},
      };

      (handleApiService as jest.Mock).mockResolvedValue(mockApiResponse);
      (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
        mockApiResponse.data
      );
      (normaliseDataWithPaging as jest.Mock).mockReturnValue(
        mockApiResponse.data
      );

      await retrieveBeneficiariesController(
        req as Request,
        res as Response,
        next
      );

      // Verify vulnerability check was performed with correct arguments
      expect(detectInjectionVulnerability).toHaveBeenCalledWith(
        { ids: [], query: 'John Doe' },
        { query: 'query' }
      );

      // Verify request proceeded normally
      expect(handleApiService).toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK);
      expect(res.locals.logger.trace).not.toHaveBeenCalled();
    });

    it('should check vulnerability in PDP flow', async () => {
      req.body = {
        searchCriteria: 'Safe Query',
      };

      (detectInjectionVulnerability as jest.Mock).mockReturnValueOnce({
        vulnerabilityDetected: false,
        message: '',
        vulnerableFields: [],
      });

      (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
      (readMeshSecrets as jest.Mock).mockReturnValue({
        pdpClientToken: 'mock-token',
      });
      (getBeneficiaryIdsFromPdpQueryResult as jest.Mock).mockResolvedValue([
        { id: '1' },
      ]);
      (transformPdpQueryResult as jest.Mock).mockReturnValue(['1']);

      const mockApiResponse = {
        data: { beneficiaries: [] },
        paging: {},
      };

      (handleApiService as jest.Mock).mockResolvedValue(mockApiResponse);
      (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
        mockApiResponse.data
      );
      (normaliseDataWithPaging as jest.Mock).mockReturnValue(
        mockApiResponse.data
      );

      await retrieveBeneficiariesController(
        req as Request,
        res as Response,
        next
      );

      // Verify vulnerability check happens before PDP logic
      expect(detectInjectionVulnerability).toHaveBeenCalled();
      expect(getBeneficiaryIdsFromPdpQueryResult).toHaveBeenCalled();
      expect(handleApiService).toHaveBeenCalled();
    });

    it('should block request in PDP flow when vulnerability detected', async () => {
      req.body = {
        searchCriteria: "'; DROP TABLE users; --",
      };

      (detectInjectionVulnerability as jest.Mock).mockReturnValueOnce({
        vulnerabilityDetected: true,
        message: 'Injection vulnerabilities detected.',
        vulnerableFields: ['query'],
      });

      (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
      (readMeshSecrets as jest.Mock).mockReturnValue({
        pdpClientToken: 'mock-token',
      });

      await retrieveBeneficiariesController(
        req as Request,
        res as Response,
        next
      );

      // Verify request was blocked before PDP logic
      expect(res.status).toHaveBeenCalledWith(STATUS_CODES.BAD_REQUEST);
      expect(getBeneficiaryIdsFromPdpQueryResult).not.toHaveBeenCalled();
      expect(handleApiService).not.toHaveBeenCalled();
    });

    it('should handle vulnerability check with undefined req.body', async () => {
      req.body = undefined as any;

      (detectInjectionVulnerability as jest.Mock).mockReturnValueOnce({
        vulnerabilityDetected: false,
        message: '',
        vulnerableFields: [],
      });

      (RUNTIME.isLocal as jest.Mock).mockReturnValue(true);

      const mockApiResponse = {
        data: { beneficiaries: [] },
        paging: {},
      };

      (handleApiService as jest.Mock).mockResolvedValue(mockApiResponse);
      (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
        mockApiResponse.data
      );
      (normaliseDataWithPaging as jest.Mock).mockReturnValue(
        mockApiResponse.data
      );

      await retrieveBeneficiariesController(
        req as Request,
        res as Response,
        next
      );

      // Should still call detectInjectionVulnerability
      expect(detectInjectionVulnerability).toHaveBeenCalled();
      expect(handleApiService).toHaveBeenCalled();
    });

    it('should detect SQL injection patterns', async () => {
      req.body = {
        searchCriteria: "1' OR '1'='1",
      };

      (detectInjectionVulnerability as jest.Mock).mockReturnValueOnce({
        vulnerabilityDetected: true,
        message: 'Injection vulnerabilities detected.',
        vulnerableFields: ['query'],
      });

      (RUNTIME.isLocal as jest.Mock).mockReturnValue(true);

      await retrieveBeneficiariesController(
        req as Request,
        res as Response,
        next
      );

      expect(res.status).toHaveBeenCalledWith(STATUS_CODES.BAD_REQUEST);
      expect(res.locals.logger.trace).toHaveBeenCalled();
    });

    it('should detect NoSQL injection patterns', async () => {
      req.body = {
        searchCriteria: '{"$ne": null}',
      };

      (detectInjectionVulnerability as jest.Mock).mockReturnValueOnce({
        vulnerabilityDetected: true,
        message: 'Injection vulnerabilities detected.',
        vulnerableFields: ['query'],
      });

      (RUNTIME.isLocal as jest.Mock).mockReturnValue(true);

      await retrieveBeneficiariesController(
        req as Request,
        res as Response,
        next
      );

      expect(detectInjectionVulnerability).toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(STATUS_CODES.BAD_REQUEST);
      expect(res.json).toHaveBeenCalledWith(
        'Injection vulnerabilities detected.'
      );
      expect(res.end).toHaveBeenCalled();
      expect(handleApiService).not.toHaveBeenCalled();
    });
  });
});
