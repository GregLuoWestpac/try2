import { normalise } from '@mep-node/framework-response-normaliser-addon';
import {
  accessControlExposeHeaders,
  APIClient,
  APIClientError,
  handleApiService,
  handleControllerError,
  normaliseData,
  STATUS_CODES,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { NextFunction, Request, Response } from 'express';
import { beneficiaryManagementV1Services } from '../../generated/api-clients';
import { setParamsForArchiveBeneficiary } from '../../utils/setParams';

const archiveBeneficiariesController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { logger } = res.locals;
  const { updateBeneficiaryStatus } = beneficiaryManagementV1Services;

  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);
  try {
    const id = req.body.beneficiary.id;

    await handleApiService({
      req,
      res,
      apiClient: updateBeneficiaryStatus as unknown as APIClient,
      setDownstreamParams: setParamsForArchiveBeneficiary,
      pathParams: {
        id,
      },
    });

    const normalisedData = normaliseData(
      'beneficiaryArchive',
      [{ id }],
      normalise
    );

    res.status(STATUS_CODES.OK).json(normalisedData).end();
  } catch (error: unknown) {
    handleControllerError({ error: error as APIClientError, res, logger });
    next(error);
  }
};

export = archiveBeneficiariesController;
