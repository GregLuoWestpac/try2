import { Request, Response, NextFunction } from 'express';
import getHealthCheckStatusController from './getHealthCheckStatusController';

describe('getHealthCheckStatusController', () => {
  let req: Partial<Request>;
  let res: any;
  let next: NextFunction;

  beforeEach(() => {
    req = {};
    res = {
      locals: {
        logger: {
          trace: jest.fn(),
          error: jest.fn(),
          warn: jest.fn(),
          info: jest.fn(),
          debug: jest.fn(),
        },
      },
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
    };
    next = jest.fn();
    jest.clearAllMocks();
  });

  it('should return health check status successfully', () => {
    getHealthCheckStatusController(req as Request, res as Response, next);

    expect(res.locals.logger.trace).toHaveBeenCalledWith(
      'HealthCheck controller'
    );
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith({ status: 'success' });
    expect(next).toHaveBeenCalled();
  });

  it('should call next() to continue to the next middleware', () => {
    getHealthCheckStatusController(req as Request, res as Response, next);

    expect(next).toHaveBeenCalledTimes(1);
    expect(next).toHaveBeenCalledWith();
  });

  it('should log trace message with correct text', () => {
    getHealthCheckStatusController(req as Request, res as Response, next);

    expect(res.locals.logger.trace).toHaveBeenCalledTimes(1);
    expect(res.locals.logger.trace).toHaveBeenCalledWith(
      'HealthCheck controller'
    );
  });

  it('should return status 200 with success message', () => {
    getHealthCheckStatusController(req as Request, res as Response, next);

    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith({ status: 'success' });
  });

  it('should work even if logger is not available', () => {
    // Test robustness - though the controller expects logger to be there
    res.locals = {};

    expect(() => {
      getHealthCheckStatusController(req as Request, res as Response, next);
    }).toThrow(); // This should throw since logger.trace is called on undefined
  });

  it('should handle the complete flow in correct order', () => {
    const mockCalls: string[] = [];

    res.locals.logger.trace = jest.fn(() => mockCalls.push('trace'));
    res.status = jest.fn(() => {
      mockCalls.push('status');
      return res;
    });
    res.json = jest.fn(() => {
      mockCalls.push('json');
      return res;
    });
    next = jest.fn(() => mockCalls.push('next'));

    getHealthCheckStatusController(req as Request, res as Response, next);

    expect(mockCalls).toEqual(['trace', 'status', 'json', 'next']);
  });
});
