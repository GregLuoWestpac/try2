import { Request, Response, NextFunction } from 'express';
import {
  handleApiService,
  normaliseData,
  handleControllerError,
  STATUS_CODES,
  Logger,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { detectInjectionVulnerabilityForBeneficiary } from '@mesh-tenant-multiverse-ui-common/mv-apibeneficiarycreate';
import { BENEFICIARY_TYPE } from '../../utils/apiConstants';
import updateBeneficiaryController from './updateBeneficiaryController';
import {
  ExpApiResponseData,
  transformDownstreamResponseToUi,
} from '../helpers/updateBeneficiaryController.helper';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  handleApiService: jest.fn(),
  handleControllerError: jest.fn(),
  STATUS_CODES: { OK: 200, BAD_REQUEST: 400 },
  normaliseData: jest.fn(),
  accessControlExposeHeaders: 'x-custom-header,x-another-header',
}));

jest.mock('@mep-node/framework-response-normaliser-addon', () => ({
  normalise: jest.fn(),
}));

jest.mock('../../generated/api-clients', () => ({
  beneficiaryManagementV1Services: {
    updateBeneficiary: jest.fn(),
    updateBeneficiaryStatus: jest.fn(),
  },
}));

jest.mock('../helpers/updateBeneficiaryController.helper', () => ({
  transformDownstreamResponseToUi: jest.fn(),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apibeneficiarycreate', () => ({
  detectInjectionVulnerabilityForBeneficiary: jest.fn(),
}));

jest.mock('../../utils/apiConstants', () => ({
  BENEFICIARY_TYPE: {
    ACCOUNT: 'ACCOUNT',
    BPAY: 'BPAY',
  },
}));

describe('updateBeneficiaryController', () => {
  let req: Partial<Request>;
  let res: any;
  let next: NextFunction;
  let logger: Logger;

  beforeEach(() => {
    req = {
      body: { beneficiary: { id: '3fa85f64-5717-4562-b3fc-2c963f66afa6' } },
    };
    res = {
      locals: {
        logger: {
          trace: jest.fn(),
          info: jest.fn(),
          error: jest.fn(),
        },
      },
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      setHeader: jest.fn(),
      end: jest.fn(),
    };
    next = jest.fn();
    logger = res.locals.logger;
  });

  it('should update beneficiary and return normalized data', async () => {
    const mockDownstreamResponse = { data: {} };
    const mockExpApiResponseData: ExpApiResponseData = {
      beneficiaryUpdate: [],
    };
    const mockNormalisedData = {};

    (handleApiService as jest.Mock).mockResolvedValue(mockDownstreamResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      mockExpApiResponseData
    );
    (normaliseData as jest.Mock).mockReturnValue(mockNormalisedData);
    (detectInjectionVulnerabilityForBeneficiary as jest.Mock).mockReturnValue({
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    });

    await updateBeneficiaryController(req as Request, res as Response, next);
    expect(handleApiService).toHaveBeenCalledWith(
      expect.objectContaining({
        req: expect.any(Object),
        res: expect.any(Object),
        apiClient: expect.any(Function),
        pathParams: { id: '3fa85f64-5717-4562-b3fc-2c963f66afa6' },
        requestBody: expect.any(Object),
      })
    );

    expect(res.setHeader).toHaveBeenCalledWith(
      'Access-Control-Expose-Headers',
      'x-custom-header,x-another-header'
    );
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK);
    expect(res.json).toHaveBeenCalledWith(mockNormalisedData);
    expect(res.end).toHaveBeenCalled();
  });

  it('should pass x-channelRequestId in headers to handleApiService', async () => {
    req = {
      body: { beneficiary: { id: '3fa85f64-5717-4562-b3fc-2c963f66afa6' } },
      headers: { 'x-channelRequestId': 'test-channel-id' },
    };
    const mockDownstreamResponse = { data: {} };
    const mockExpApiResponseData: ExpApiResponseData = {
      beneficiaryUpdate: [],
    };
    const mockNormalisedData = {};

    (handleApiService as jest.Mock).mockResolvedValue(mockDownstreamResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      mockExpApiResponseData
    );
    (normaliseData as jest.Mock).mockReturnValue(mockNormalisedData);

    await updateBeneficiaryController(req as Request, res as Response, next);

    // Check that handleApiService received the header
    expect(handleApiService).toHaveBeenCalledWith(
      expect.objectContaining({
        req: expect.objectContaining({
          headers: expect.objectContaining({
            'x-channelRequestId': 'test-channel-id',
          }),
        }),
      })
    );
  });

  it('should handle errors and call next with error', async () => {
    const mockError = new Error('Test error');
    (handleApiService as jest.Mock).mockRejectedValue(mockError);
    (detectInjectionVulnerabilityForBeneficiary as jest.Mock).mockReturnValue({
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    });
    await updateBeneficiaryController(req as Request, res as Response, next);

    expect(handleControllerError).toHaveBeenCalledWith({
      error: mockError,
      res,
      logger,
    });
    expect(next).toHaveBeenCalledWith(mockError);
  });

  it('should return BAD_REQUEST if detectInjectionVulnerabilityForBeneficiary detects vulnerability', async () => {
    (detectInjectionVulnerabilityForBeneficiary as jest.Mock).mockReturnValue({
      vulnerabilityDetected: true,
      message: 'Injection detected',
      vulnerableFields: ['accountName'],
    });
    req.body = {
      beneficiary: {
        id: '2ca0fae8-cfd5-428a-818d-dc72806882c4',
        nickname: 'TestNickName',
        currency: 'AUD',
        type: BENEFICIARY_TYPE.ACCOUNT,
        account: {
          accountId: {
            BSB: '232323',
            accountNumber: '2133213123',
          },
          accountName: 'bad<script>',
          bankName: 'West bank',
        },
      },
    };

    await updateBeneficiaryController(req as Request, res as Response, next);

    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.BAD_REQUEST);
    expect(res.json).toHaveBeenCalledWith('Injection detected');
    expect(res.end).toHaveBeenCalled();
  });

  it('should properly destructure beneficiary id and pass requestBody without id', async () => {
    const mockDownstreamResponse = { data: {} };
    const mockExpApiResponseData: ExpApiResponseData = {
      beneficiaryUpdate: [],
    };
    const mockNormalisedData = {};

    req.body = {
      beneficiary: {
        id: 'test-id-123',
        nickname: 'Test Nickname',
        currency: 'AUD',
        type: 'ACCOUNT',
      },
    };

    (handleApiService as jest.Mock).mockResolvedValue(mockDownstreamResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      mockExpApiResponseData
    );
    (normaliseData as jest.Mock).mockReturnValue(mockNormalisedData);
    (detectInjectionVulnerabilityForBeneficiary as jest.Mock).mockReturnValue({
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    });

    await updateBeneficiaryController(req as Request, res as Response, next);

    expect(handleApiService).toHaveBeenCalledWith(
      expect.objectContaining({
        pathParams: { id: 'test-id-123' },
        requestBody: {
          nickname: 'Test Nickname',
          currency: 'AUD',
          type: 'ACCOUNT',
        },
      })
    );
  });

  it('should call normaliseData with correct parameters', async () => {
    const mockDownstreamResponse = { data: { someData: 'test' } };
    const mockExpApiResponseData: ExpApiResponseData = {
      beneficiaryUpdate: [{ id: '123', nickname: 'test beneficiary' }],
    };
    const mockNormalisedData = { normalised: 'data' };

    (handleApiService as jest.Mock).mockResolvedValue(mockDownstreamResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      mockExpApiResponseData
    );
    (normaliseData as jest.Mock).mockReturnValue(mockNormalisedData);
    (detectInjectionVulnerabilityForBeneficiary as jest.Mock).mockReturnValue({
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    });

    await updateBeneficiaryController(req as Request, res as Response, next);

    expect(transformDownstreamResponseToUi).toHaveBeenCalledWith({
      someData: 'test',
    });
    expect(normaliseData).toHaveBeenCalledWith(
      'beneficiaryUpdate',
      [{ id: '123', nickname: 'test beneficiary' }],
      expect.any(Function)
    );
  });

  it('should log vulnerability detection when vulnerability is found', async () => {
    (detectInjectionVulnerabilityForBeneficiary as jest.Mock).mockReturnValue({
      vulnerabilityDetected: true,
      message: 'XSS attempt detected',
      vulnerableFields: ['nickname', 'accountName'],
    });

    req.body = {
      beneficiary: {
        id: 'test-id',
        nickname: '<script>alert("xss")</script>',
      },
    };

    await updateBeneficiaryController(req as Request, res as Response, next);

    expect(logger.trace).toHaveBeenCalledWith(
      'XSS attempt detected Vulnerable fields:',
      ['nickname', 'accountName']
    );
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.BAD_REQUEST);
    expect(res.json).toHaveBeenCalledWith('XSS attempt detected');
  });

  it('should call updateBeneficiaryStatus before updateBeneficiary', async () => {
    // Clear previous mocks to ensure clean state
    jest.clearAllMocks();

    const mockDownstreamResponse = { data: {} };
    const mockExpApiResponseData: ExpApiResponseData = {
      beneficiaryUpdate: [],
    };
    const mockNormalisedData = {};

    (handleApiService as jest.Mock).mockResolvedValue(mockDownstreamResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      mockExpApiResponseData
    );
    (normaliseData as jest.Mock).mockReturnValue(mockNormalisedData);
    (detectInjectionVulnerabilityForBeneficiary as jest.Mock).mockReturnValue({
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    });

    await updateBeneficiaryController(req as Request, res as Response, next);

    // Verify handleApiService was called twice
    expect(handleApiService).toHaveBeenCalledTimes(2);

    // First call should be to updateBeneficiaryStatus with status: 'ACTIVE'
    expect(handleApiService).toHaveBeenNthCalledWith(
      1,
      expect.objectContaining({
        pathParams: { id: '3fa85f64-5717-4562-b3fc-2c963f66afa6' },
        requestBody: { status: 'ACTIVE' },
      })
    );

    // Second call should be to updateBeneficiary
    expect(handleApiService).toHaveBeenNthCalledWith(
      2,
      expect.objectContaining({
        pathParams: { id: '3fa85f64-5717-4562-b3fc-2c963f66afa6' },
        requestBody: expect.any(Object),
      })
    );
  });

  it('should handle error when updateBeneficiaryStatus fails', async () => {
    // Clear previous mocks to ensure clean state
    jest.clearAllMocks();

    const mockError = new Error('Status update failed');
    (handleApiService as jest.Mock).mockRejectedValueOnce(mockError);
    (detectInjectionVulnerabilityForBeneficiary as jest.Mock).mockReturnValue({
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    });

    await updateBeneficiaryController(req as Request, res as Response, next);

    expect(handleControllerError).toHaveBeenCalledWith({
      error: mockError,
      res,
      logger,
    });
    expect(next).toHaveBeenCalledWith(mockError);
  });

  it('should return 400 when vulnerability is detected', async () => {
    jest.clearAllMocks(); // Clear all previous mock calls

    (detectInjectionVulnerabilityForBeneficiary as jest.Mock).mockReturnValue({
      vulnerabilityDetected: true,
      message: 'Injection vulnerability detected',
      vulnerableFields: ['nickname'],
    });

    await updateBeneficiaryController(req as Request, res as Response, next);

    expect(logger.trace).toHaveBeenCalledWith(
      'Injection vulnerability detected Vulnerable fields:',
      ['nickname']
    );
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.BAD_REQUEST);
    expect(res.json).toHaveBeenCalledWith('Injection vulnerability detected');
    expect(res.end).toHaveBeenCalled();
    expect(handleApiService).not.toHaveBeenCalled();
  });
});
