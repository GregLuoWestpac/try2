/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-var-requires */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable no-unsafe-optional-chaining */
import {
  handleControllerError,
  handleApiService,
  APIClientError,
  STATUS_CODES,
  DownstreamServiceResponse,
  normaliseData,
  accessControlExposeHeaders,
  jwtDecode,
  APIClient,
  SetDownstreamParams,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { NextFunction, Request, Response } from 'express';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import { RUNTIME, ALLOWED_COOKIES } from '@mep-node/framework-constants';
import {
  ID,
  getIpAddress,
  getDeviceFingerPrint,
} from '@mep-node/framework-utilities';
import { UserAgentType } from '../../generated/api-clients/types/capCustsvcmgtCustsecyverifctnAdaptvauthV2';
import {
  paymentAliasResolutionV2Services,
  channelPaymentUtilsV1Services,
  capCustsvcmgtCustsecyverifctnAdaptvauthV2Services,
} from '../../generated/api-clients';
import {
  transformDownstreamResponseToUi,
  ExpApiResponseData,
  transformRequestForDownstream,
  payIDLimitCounter,
  getPayIDType,
} from '../helpers/postAliasLookupController.helper';
import { LIMIT_EXCEEEDED_ERROR } from '../../utils/apiConstants';

type DecodedToken = {
  userId?: string;
  userIdScheme?: string;
  sessionIndex?: string;
};

type PayIDLimitCounterResponse = {
  counters?: Array<{
    session?: { counter: number };
    counter: number;
  }>;
};

const postAliasLookupController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { logger, apiHeaders, Cookie, sessionIndex } = res.locals;
  const { postResolutionView } = paymentAliasResolutionV2Services;
  const { getSessionIdCounter, incrementSessionIdCounter, getPaymentCounter } =
    channelPaymentUtilsV1Services;
  const { analyse } = capCustsvcmgtCustsecyverifctnAdaptvauthV2Services;

  const requestBody = transformRequestForDownstream(req.body);
  const name = String(requestBody.aliasId);
  const type = String(requestBody.aliasType);
  const source = String(requestBody.action);

  const IPAddress = getIpAddress(req);
  const deviceTokenFromCookie = Cookie.get(ALLOWED_COOKIES.W1AddnAuthorisation);
  const deviceFingerPrint = getDeviceFingerPrint(req, res);

  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);

  const xAccessToken = apiHeaders['x-access-token'] as string;
  let decodedToken: DecodedToken = {};

  if (RUNTIME.isLocal()) {
    decodedToken = {
      userId: 'sampleUserId',
      sessionIndex: 'sampleSessionId',
    };
  } else {
    try {
      decodedToken = jwtDecode(xAccessToken);
      res.locals.apiHeaders['x-userIdScheme'] = 'CustomerInternalId';
    } catch (error) {
      const tokenDecodeError = {
        msg: 'Error decoding token',
        payload: { error },
      };
      logger?.error(tokenDecodeError);
      res.status(401).json({ error: 'Access token invalid' });
      return;
    }
  }

  try {
    let isSAFIAllowed = false;
    let sessionCounter: number;
    let userCounter: number;

    try {
      const { counters }: PayIDLimitCounterResponse = await payIDLimitCounter(
        getSessionIdCounter,
        res,
        req,
        decodedToken.userId,
        decodedToken.sessionIndex
      );
      if (counters.length === 0) {
        const data: PayIDLimitCounterResponse = await payIDLimitCounter(
          getPaymentCounter,
          res,
          req,
          decodedToken.userId
        );
        sessionCounter = 1;
        userCounter = data?.counters?.[0]?.counter + 1 || 1;
      } else {
        sessionCounter = counters?.[0]?.session?.counter + 1;
        userCounter = counters?.[0]?.counter + 1;
      }
    } catch (error: unknown) {
      const apiError = error as APIClientError;
      const { status, data } = apiError?.error || {};
      if (
        Number(status) === 404 &&
        Number(data?.result?.errors?.[0]?.code) === 1003
      ) {
        sessionCounter = 1;
        userCounter = 1;
      } else {
        handleControllerError({ error: apiError, res, logger });
        next(error);
        return;
      }
    }

    if (!RUNTIME.isLocal()) {
      // Build browser information headers (like Operations.js does on line 173)
      const deviceFingerPrintHeader = req.get('x-devicefingerprint');
      let browserInformation = {};

      if (deviceFingerPrintHeader) {
        browserInformation = {
          userAgent: req.get('user-agent') || '',
          httpAccept: req.get('accept') || '',
          httpReferer: req.get('referer') || '',
          httpAcceptedEncoding: req.get('accept-encoding') || '',
          httpAcceptedLanguage: req.get('accept-language') || '',
          httpAcceptedCharacters: req.get('accept-charset') || '',
        };
      }

      // Build the SAFI analyse request body (following Operations.js pattern)
      const safiAnalyseRequestBody = {
        eventType: 'CLIENT_DEFINED',
        clientDefinedEventType: 'PAYID_LOOKUP',
        tenantId: 'WPACW1',
        eventMetaData: [
          {
            name: 'TENANT',
            value: 'Treasury',
            datatype: 'STRING',
          },
          {
            name: 'COUNTER',
            value: String(sessionCounter),
            datatype: 'INTEGER',
          },
          {
            name: 'COUNTER_24HOUR',
            value: String(userCounter),
            datatype: 'INTEGER',
          },
          {
            name: 'PAYEEPAYIDTYPE',
            value: getPayIDType(type),
            datatype: 'STRING',
          },
          {
            name: 'PAYEEPAYIDVALUE',
            value: name,
            datatype: 'STRING',
          },
          {
            name: 'SOURCE',
            value: source,
            datatype: 'STRING',
          },
        ],
        userAgentType: UserAgentType.BROWSER, // or MOBILE_APP based on device experience
        clientTransactionId: {
          sessionId: ID.generate(true),
          transactionId: apiHeaders['x-appCorrelationId'] || ID.generate(true),
        },
        browserInformation, // This is where the headers from line 173 go
        device: {
          IPAddress,
          deviceFingerPrint,
          deviceToken: deviceTokenFromCookie,
        },
        verificationReferenceId: sessionIndex,
        customer: {
          customerType: 'Individual',
          customerId: {
            id: apiHeaders['x-userId'],
            idScheme: apiHeaders['x-userIdScheme'],
          },
        },
      };

      // Custom setDownstreamParams function for SAFI analyse
      const setSAFIDownstreamParams: SetDownstreamParams = (
        inputHeaders,
        response,
        safiRequestBody
      ) => ({
        header: {
          ...inputHeaders,
          'x-originatingSystemId': 'A014A6', // Override for SAFI call
        },
        body: safiRequestBody,
        query: {
          brandSilo: response.locals.brandSilo,
          pageSize: '0', // As per Operations.js
        },
      });

      // Call SAFI analyse using handleApiService
      const analyseResponse: DownstreamServiceResponse = await handleApiService(
        {
          req,
          res,
          apiClient: analyse as APIClient,
          setDownstreamParams: setSAFIDownstreamParams,
          requestBody: safiAnalyseRequestBody,
        }
      );

      const analyseResult = analyseResponse?.data?.data?.analyseResult;
      const deviceToken = analyseResponse?.data?.data?.deviceToken;

      if (deviceToken) {
        const today = new Date();
        const maxExpiryDate = new Date().setDate(today.getDate() + 365);
        Cookie.set(
          ALLOWED_COOKIES.W1AddnAuthorisation,
          deviceToken,
          res.locals.xBrandId,
          {
            expires: new Date(maxExpiryDate),
          }
        );
      }

      isSAFIAllowed = analyseResult === 'ALLOW';
    } else {
      isSAFIAllowed = true; // for Local testing
    }

    if (isSAFIAllowed) {
      const downstreamResponse: DownstreamServiceResponse =
        await handleApiService({
          req,
          res,
          apiClient: postResolutionView,
          requestBody,
        });

      const incrementPaymentCounterResponse = await payIDLimitCounter(
        incrementSessionIdCounter,
        res,
        req,
        decodedToken.userId,
        decodedToken?.sessionIndex
      );

      if (!incrementPaymentCounterResponse.counters) {
        throw new Error(
          'PayID limit failed to increment after successful lookup'
        );
      }

      const expApiResponseData: ExpApiResponseData =
        transformDownstreamResponseToUi(downstreamResponse.data);

      const normalisedData = normaliseData(
        'aliasLookup',
        expApiResponseData.aliasLookup,
        normalise
      );

      res.status(STATUS_CODES.OK).json(normalisedData);
    } else {
      res.status(STATUS_CODES.BAD_REQUEST).json(LIMIT_EXCEEEDED_ERROR);
    }
  } catch (error: unknown) {
    const apiError = error as APIClientError;
    try {
      if (apiError?.error?.status === 400) {
        await payIDLimitCounter(
          incrementSessionIdCounter,
          res,
          req,
          decodedToken.userId,
          decodedToken.sessionIndex
        );
      }
    } catch (incrementError) {
      handleControllerError({
        error: incrementError as APIClientError,
        res,
        logger,
      });
      next(incrementError);
      return;
    }
    handleControllerError({ error: apiError, res, logger });
    next(error);
  }
};

export = postAliasLookupController;
