/* eslint-disable import/first */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response, NextFunction } from 'express';

// Mocks must be declared before importing controller
jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  handleApiService: jest.fn(),
  handleControllerError: jest.fn(),
  normaliseData: jest.fn(),
  accessControlExposeHeaders: 'x-userIdScheme,x-expose',
  STATUS_CODES: { OK: 200, BAD_REQUEST: 400 },
  jwtDecode: jest.fn(),
}));
jest.mock('@mep-node/framework-constants', () => ({
  RUNTIME: { isLocal: jest.fn() },
  ALLOWED_COOKIES: { W1AddnAuthorisation: 'W1AddnAuthorisation' },
}));
jest.mock('@mep-node/framework-response-normaliser-addon', () => ({
  normalise: jest.fn(() => (x: unknown) => x),
}));
jest.mock('@mep-node/framework-utilities', () => ({
  ID: { generate: jest.fn(() => 'session-uuid') },
  getIpAddress: jest.fn(() => '127.0.0.1'),
  getDeviceFingerPrint: jest.fn(() => 'fingerprint-123'),
}));
jest.mock('../helpers/postAliasLookupController.helper', () => ({
  transformRequestForDownstream: jest.fn(),
  transformDownstreamResponseToUi: jest.fn(),
  payIDLimitCounter: jest.fn(),
  getPayIDType: jest.fn(),
}));
jest.mock('../../generated/api-clients', () => ({
  paymentAliasResolutionV2Services: {
    postResolutionView: { name: 'postResolutionView' },
  },
  channelPaymentUtilsV1Services: {
    getSessionIdCounter: { name: 'getSessionIdCounter' },
    getPaymentCounter: { name: 'getPaymentCounter' },
    incrementSessionIdCounter: { name: 'incrementSessionIdCounter' },
  },
  capCustsvcmgtCustsecyverifctnAdaptvauthV2Services: {
    analyse: { name: 'analyse' },
  },
}));

// Import after mocks
import {
  handleApiService,
  handleControllerError,
  normaliseData,
  STATUS_CODES,
  jwtDecode,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { RUNTIME } from '@mep-node/framework-constants';
import postAliasLookupController from './postAliasLookupController';
import {
  transformRequestForDownstream,
  transformDownstreamResponseToUi,
  payIDLimitCounter,
  getPayIDType,
} from '../helpers/postAliasLookupController.helper';
import { LIMIT_EXCEEEDED_ERROR } from '../../utils/apiConstants';

type CountersResponse = {
  counters?: Array<{ counter: number; session?: { counter: number } }>;
};
interface TestLocals {
  logger: { info: jest.Mock; error: jest.Mock };
  apiHeaders: Record<string, string>;
  Cookie: { get: jest.Mock; set: jest.Mock };
  sessionIndex?: string;
  brandSilo?: string;
  xBrandId?: string;
}
const makeReq = (body: Record<string, unknown>) =>
  ({
    body,
    get: jest.fn().mockImplementation((header: string) => {
      // Return a device fingerprint only when explicitly asked in tests (can be extended)
      if (header.toLowerCase() === 'x-devicefingerprint') return undefined; // falsy keeps browserInformation empty
      return undefined;
    }),
  } as Partial<Request>);
const makeRes = (): Response & { locals: TestLocals } =>
  ({
    locals: {
      logger: { info: jest.fn(), error: jest.fn() },
      apiHeaders: {
        'x-access-token': 'token',
        'x-appCorrelationId': 'corr-1',
        'x-userId': 'U1',
        'x-userIdScheme': 'CustomerInternalId',
      },
      Cookie: { get: jest.fn().mockReturnValue(undefined), set: jest.fn() },
      sessionIndex: 'S1',
      brandSilo: 'brand-1',
      xBrandId: 'brand-1',
    },
    setHeader: jest.fn(),
    status: jest.fn().mockReturnThis(),
    json: jest.fn().mockReturnThis(),
  } as unknown as Response & { locals: TestLocals });

const downstreamData = { data: { alias: 'aliasA', accountId: 'ACC1' } };
const transformed = {
  aliasLookup: [{ id: 'uuid-1', alias: 'aliasA', accountId: 'ACC1' }],
};
const normalised = {
  aliasLookup: [
    { id: 'uuid-1', alias: 'aliasA', accountId: 'ACC1', _meta: {} },
  ],
};

beforeEach(() => {
  jest.clearAllMocks();
  (transformRequestForDownstream as jest.Mock).mockReturnValue({
    aliasId: 'aliasA',
    aliasType: 'EMAL',
    action: 'LOOKUP',
    authBIC8: 'AUTH1234',
  });
  (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(transformed);
  (normaliseData as jest.Mock).mockReturnValue(normalised);
  (getPayIDType as jest.Mock).mockReturnValue('EMAIL');
});

describe('postAliasLookupController (SAFI integration)', () => {
  let req: Partial<Request>;
  let res: Response & { locals: TestLocals };
  let next: jest.MockedFunction<NextFunction>;
  beforeEach(() => {
    req = makeReq({ email: 'aliasA', action: 'LOOKUP', authBIC8: 'AUTH1234' });
    res = makeRes();
    next = jest.fn();
  });

  const setCounters = (
    initial: CountersResponse,
    increment?: CountersResponse
  ) => {
    (payIDLimitCounter as jest.Mock)
      .mockReset()
      .mockResolvedValueOnce(initial)
      .mockResolvedValueOnce(increment ?? initial);
  };

  test('local success path sets headers and skips JWT/SAFI analyse', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(true);
    setCounters({ counters: [{ counter: 2, session: { counter: 1 } }] });
    // Only one downstream call in local (postResolutionView)
    (handleApiService as jest.Mock).mockResolvedValueOnce(downstreamData);
    await postAliasLookupController(req as Request, res as Response, next);
    expect(res.setHeader).toHaveBeenCalledWith(
      'Access-Control-Expose-Headers',
      expect.stringContaining('x-userIdScheme')
    );
    expect(jwtDecode).not.toHaveBeenCalled();
    expect(handleControllerError).not.toHaveBeenCalled();
    expect(handleApiService).toHaveBeenCalledTimes(1);
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK);
    expect(res.json).toHaveBeenCalledWith(normalised);
  });

  test('non-local success SAFI ALLOW and increment succeeds', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (jwtDecode as jest.Mock).mockReturnValue({
      userId: 'U1',
      sessionIndex: 'S1',
    });
    setCounters(
      { counters: [{ counter: 5, session: { counter: 3 } }] },
      { counters: [{ counter: 6 }] }
    );
    // First call SAFI analyse, second call downstream postResolutionView
    (handleApiService as jest.Mock)
      .mockResolvedValueOnce({ data: { data: { analyseResult: 'ALLOW' } } })
      .mockResolvedValueOnce(downstreamData);
    await postAliasLookupController(req as Request, res as Response, next);
    expect(handleApiService).toHaveBeenCalledTimes(2);
    expect(payIDLimitCounter).toHaveBeenCalledTimes(2);
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK);
    expect(res.json).toHaveBeenCalledWith(normalised);
  });

  test('non-local SAFI builds browserInformation when device fingerprint header present', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (jwtDecode as jest.Mock).mockReturnValue({
      userId: 'U1',
      sessionIndex: 'S1',
    });
    setCounters(
      { counters: [{ counter: 1, session: { counter: 1 } }] },
      { counters: [{ counter: 2 }] }
    );
    // Custom req with fingerprint header and some other headers defined
    (req as any).get = jest.fn().mockImplementation((header: string) => {
      const h = header.toLowerCase();
      if (h === 'x-devicefingerprint') return 'fp-123';
      if (h === 'user-agent') return 'UA-Test';
      if (h === 'accept') return 'application/json';
      if (h === 'referer') return 'http://example.com';
      if (h === 'accept-encoding') return 'gzip';
      if (h === 'accept-language') return 'en-AU';
      if (h === 'accept-charset') return 'utf-8';
      return undefined;
    });
    (handleApiService as jest.Mock)
      .mockResolvedValueOnce({ data: { data: { analyseResult: 'ALLOW' } } })
      .mockResolvedValueOnce(downstreamData);
    await postAliasLookupController(req as Request, res as Response, next);
    const firstCallArg = (handleApiService as jest.Mock).mock.calls[0][0];
    expect(firstCallArg.requestBody.browserInformation).toMatchObject({
      userAgent: 'UA-Test',
      httpAccept: 'application/json',
      httpReferer: 'http://example.com',
      httpAcceptedEncoding: 'gzip',
      httpAcceptedLanguage: 'en-AU',
      httpAcceptedCharacters: 'utf-8',
    });
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK);
  });

  test('non-local SAFI sets device token cookie when deviceToken returned', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (jwtDecode as jest.Mock).mockReturnValue({
      userId: 'U1',
      sessionIndex: 'S1',
    });
    setCounters(
      { counters: [{ counter: 2, session: { counter: 1 } }] },
      { counters: [{ counter: 3 }] }
    );
    (handleApiService as jest.Mock)
      .mockResolvedValueOnce({
        data: { data: { analyseResult: 'ALLOW', deviceToken: 'abc123' } },
      })
      .mockResolvedValueOnce(downstreamData);
    await postAliasLookupController(req as Request, res as Response, next);
    expect(res.locals.Cookie.set).toHaveBeenCalledWith(
      expect.any(String),
      'abc123',
      res.locals.xBrandId,
      expect.objectContaining({ expires: expect.any(Date) })
    );
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK);
  });

  test('SAFI DENY returns BAD_REQUEST with limit exceeded', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (jwtDecode as jest.Mock).mockReturnValue({
      userId: 'U1',
      sessionIndex: 'S1',
    });
    setCounters({ counters: [{ counter: 1, session: { counter: 1 } }] });
    (handleApiService as jest.Mock).mockResolvedValueOnce({
      data: { data: { analyseResult: 'DENY' } },
    });
    await postAliasLookupController(req as Request, res as Response, next);
    expect(handleApiService).toHaveBeenCalledTimes(1);
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.BAD_REQUEST);
    expect(res.json).toHaveBeenCalledWith(LIMIT_EXCEEEDED_ERROR);
  });

  test('should be called twice when payIDLimitCounter is returned with empty counters array', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (jwtDecode as jest.Mock).mockReturnValue({
      userId: 'U1',
      sessionIndex: 'S1',
    });
    (payIDLimitCounter as jest.Mock)
      .mockReset()
      .mockResolvedValueOnce({ counters: [] });
    (handleApiService as jest.Mock)
      .mockResolvedValueOnce({ data: { data: { analyseResult: 'ALLOW' } } })
      .mockResolvedValueOnce(downstreamData);
    await postAliasLookupController(req as Request, res as Response, next);
    expect(payIDLimitCounter).toHaveBeenCalledTimes(3);
  });

  test('initial counter 404 code 1003 sets counters zero then proceeds', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (jwtDecode as jest.Mock).mockReturnValue({
      userId: 'U1',
      sessionIndex: 'S1',
    });
    (payIDLimitCounter as jest.Mock)
      .mockReset()
      .mockRejectedValueOnce({
        error: { status: 404, data: { result: { errors: [{ code: 1003 }] } } },
      })
      .mockResolvedValueOnce({ counters: [{ counter: 7 }] });
    (handleApiService as jest.Mock)
      .mockResolvedValueOnce({ data: { data: { analyseResult: 'ALLOW' } } })
      .mockResolvedValueOnce(downstreamData);
    await postAliasLookupController(req as Request, res as Response, next);
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK);
  });

  test('initial counter generic error uses handleControllerError & next', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (jwtDecode as jest.Mock).mockReturnValue({
      userId: 'U1',
      sessionIndex: 'S1',
    });
    const err = new Error('counter fail');
    (payIDLimitCounter as jest.Mock).mockRejectedValueOnce(err);
    await postAliasLookupController(req as Request, res as Response, next);
    expect(handleControllerError).toHaveBeenCalled();
    expect(next).toHaveBeenCalledWith(err);
  });

  test('missing increment counters triggers throw caught by outer catch', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (jwtDecode as jest.Mock).mockReturnValue({
      userId: 'U1',
      sessionIndex: 'S1',
    });
    (payIDLimitCounter as jest.Mock)
      .mockResolvedValueOnce({
        counters: [{ counter: 2, session: { counter: 1 } }],
      })
      .mockResolvedValueOnce({});
    (handleApiService as jest.Mock)
      .mockResolvedValueOnce({ data: { data: { analyseResult: 'ALLOW' } } })
      .mockResolvedValueOnce(downstreamData);
    await postAliasLookupController(req as Request, res as Response, next);
    expect(handleControllerError).toHaveBeenCalledTimes(1);
    expect(next).toHaveBeenCalledTimes(1);
  });

  test('downstream 400 triggers nested increment success', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (jwtDecode as jest.Mock).mockReturnValue({
      userId: 'U1',
      sessionIndex: 'S1',
    });
    (payIDLimitCounter as jest.Mock)
      .mockResolvedValueOnce({
        counters: [{ counter: 1, session: { counter: 1 } }],
      })
      .mockResolvedValueOnce({ counters: [{ counter: 2 }] });
    (handleApiService as jest.Mock)
      .mockResolvedValueOnce({ data: { data: { analyseResult: 'ALLOW' } } })
      .mockRejectedValueOnce({
        error: { status: 400 },
        message: 'Bad Request',
      });
    await postAliasLookupController(req as Request, res as Response, next);
    expect(payIDLimitCounter).toHaveBeenCalledTimes(2);
    expect(handleControllerError).toHaveBeenCalled();
    expect(next).toHaveBeenCalled();
  });

  test('downstream 400 with nested increment failure triggers only increment error path (early return)', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (jwtDecode as jest.Mock).mockReturnValue({
      userId: 'U1',
      sessionIndex: 'S1',
    });
    (payIDLimitCounter as jest.Mock)
      .mockResolvedValueOnce({ counters: [{ counter: 1 }] })
      .mockRejectedValueOnce(new Error('increment fail'));
    (handleApiService as jest.Mock)
      .mockResolvedValueOnce({ data: { data: { analyseResult: 'ALLOW' } } })
      .mockRejectedValueOnce({
        error: { status: 400 },
        message: 'Bad Request',
      });
    await postAliasLookupController(req as Request, res as Response, next);
    // Early return after increment failure => only one error handler invocation
    expect(handleControllerError).toHaveBeenCalledTimes(1);
    expect(next).toHaveBeenCalledTimes(1);
  });

  test('downstream non-400 error triggers only outer catch', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (jwtDecode as jest.Mock).mockReturnValue({
      userId: 'U1',
      sessionIndex: 'S1',
    });
    (payIDLimitCounter as jest.Mock).mockResolvedValueOnce({
      counters: [{ counter: 1 }],
    });
    (handleApiService as jest.Mock)
      .mockResolvedValueOnce({ data: { data: { analyseResult: 'ALLOW' } } })
      .mockRejectedValueOnce({
        error: { status: 500 },
        message: 'Server Error',
      });
    await postAliasLookupController(req as Request, res as Response, next);
    expect(payIDLimitCounter).toHaveBeenCalledTimes(1);
    expect(handleControllerError).toHaveBeenCalledTimes(1);
    expect(next).toHaveBeenCalledTimes(1);
  });

  test('jwt decode failure returns 401 early without further processing', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (jwtDecode as jest.Mock).mockImplementation(() => {
      throw new Error('decode fail');
    });
    await postAliasLookupController(req as Request, res as Response, next);
    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith({ error: 'Access token invalid' });
    expect(payIDLimitCounter).not.toHaveBeenCalled();
    expect(handleApiService).not.toHaveBeenCalled();
  });

  test('missing userId still passes through when SAFI ALLOW (fallback scenarios)', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
    (jwtDecode as jest.Mock).mockReturnValue({ sessionIndex: 'S1' });
    setCounters(
      { counters: [{ counter: 2, session: { counter: 1 } }] },
      { counters: [{ counter: 3 }] }
    );
    (handleApiService as jest.Mock)
      .mockResolvedValueOnce({ data: { data: { analyseResult: 'ALLOW' } } })
      .mockResolvedValueOnce(downstreamData);
    await postAliasLookupController(req as Request, res as Response, next);
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK);
  });
});
