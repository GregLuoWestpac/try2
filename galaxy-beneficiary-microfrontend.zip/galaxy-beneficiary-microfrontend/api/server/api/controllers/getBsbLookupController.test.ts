/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  handleApiService,
  handleControllerError,
  Logger,
  normaliseData,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { NextFunction, Request, Response } from 'express';
import { infBnkngChnlBrchntwkV2Services } from '../../generated/api-clients';
import { transformDownstreamResponseToUi } from '../helpers/getBsbLookupController.helper';
import getBsbLookupController from './getBsbLookupController';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  handleControllerError: jest.fn(),
  handleApiService: jest.fn(),
  normaliseData: jest.fn(),
  STATUS_CODES: { OK: 200 },
}));

jest.mock('../../generated/api-clients', () => ({
  infBnkngChnlBrchntwkV2Services: {
    getBranchReferenceData: jest.fn(),
  },
}));

jest.mock('../helpers/getBsbLookupController.helper', () => ({
  transformDownstreamResponseToUi: jest.fn(),
}));

describe('getBsbLookupController', () => {
  let req: Partial<Request>;
  let res: any;
  let next: NextFunction;
  let logger: Logger;

  beforeEach(() => {
    req = {
      query: { bsb: '123456' },
    };

    res = {
      locals: {},
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      setHeader: jest.fn(),
      end: jest.fn(),
    };

    next = jest.fn();
    logger = res.locals.logger;
  });

  it('should return normalized data when downstream API succeeds', async () => {
    const mockDownstreamResponse = {
      data: {
        branches: [
          {
            branchId: '123',
            BSB: '123456',
            branchName: 'Test Branch',
            bankName: 'Test Bank',
          },
        ],
      },
    };

    const mockTransformedData = {
      bsbLookup: [
        {
          branchId: '123',
          BSB: '123456',
          branchName: 'Test Branch',
          bankName: 'Test Bank',
        },
      ],
    };
    const mockNormalizedData = {
      entities: {
        bsbLookup: [
          {
            branchId: '123',
            BSB: '123456',
            branchName: 'Test Branch',
            bankName: 'Test Bank',
          },
        ],
      },
    };

    (handleApiService as jest.Mock).mockResolvedValue(mockDownstreamResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      mockTransformedData
    );
    (normaliseData as jest.Mock).mockReturnValue(mockNormalizedData);

    await getBsbLookupController(req as Request, res as Response, next);

    expect(handleApiService).toHaveBeenCalledWith({
      req,
      res,
      apiClient: infBnkngChnlBrchntwkV2Services.getBranchReferenceData,
    });
    expect(transformDownstreamResponseToUi).toHaveBeenCalledWith(
      mockDownstreamResponse.data
    );
    expect(normaliseData).toHaveBeenCalledWith(
      'bsbLookup',
      mockTransformedData.bsbLookup,
      expect.any(Function)
    );
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(mockNormalizedData);
    expect(res.end).toHaveBeenCalled();
  });
  it('should handle error response', async () => {
    const error = new Error('Test error');
    (handleApiService as jest.Mock).mockRejectedValue(error);

    await getBsbLookupController(req as Request, res as Response, next);

    expect(handleControllerError).toHaveBeenCalledWith({ error, res, logger });
    expect(next).toHaveBeenCalledWith(error);
  });
});
