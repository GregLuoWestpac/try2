import { Request, Response, NextFunction } from 'express';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import {
  handleControllerError,
  handleApiService,
  APIClientError,
  normaliseData,
  STATUS_CODES,
  DownstreamServiceResponse,
  accessControlExposeHeaders,
  APIClient,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { beneficiaryManagementV1Services } from '../../generated/api-clients';
import {
  transformDownstreamResponseToUi,
  ExpApiResponseData,
} from '../helpers/retrieveBeneficiaryController.helper';
import { setParamsForGetBeneficiary } from '../../utils/setParams';

const retrieveBeneficiaryController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { logger } = res.locals;

  const { getBeneficiaryDetail } = beneficiaryManagementV1Services;
  const { id } = req.body;

  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);
  try {
    const downstreamResponse: DownstreamServiceResponse =
      await handleApiService({
        req,
        res,
        apiClient: getBeneficiaryDetail as unknown as APIClient,
        setDownstreamParams: setParamsForGetBeneficiary,
        pathParams: { id },
      });

    const expApiResponseData: ExpApiResponseData =
      transformDownstreamResponseToUi(downstreamResponse.data);
    const normalisedData = normaliseData(
      'beneficiaryDetails',
      expApiResponseData.beneficiaryDetails,
      normalise
    );

    res.status(STATUS_CODES.OK).json(normalisedData).end();
  } catch (error: unknown) {
    handleControllerError({ error: error as APIClientError, res, logger });
    next(error);
  }
};

export = retrieveBeneficiaryController;
