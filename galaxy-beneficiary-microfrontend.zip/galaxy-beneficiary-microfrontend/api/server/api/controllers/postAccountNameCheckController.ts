import { Request, Response, NextFunction } from 'express';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import {
  handleControllerError,
  handleApiService,
  APIClientError,
  APIClient,
  normaliseData,
  STATUS_CODES,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable no-unsafe-optional-chaining */

import {
  payeeServicesV1Services,
  channelPaymentUtilsV1Services,
} from '../../generated/api-clients';
import { accountNameCheckRequest } from '../../../types/accountNameCheckRequest';
import { setParamsForAccountNameCheck } from '../../utils/setParams';
import { AccountNameCheckResponse } from '../../../interfaces/models/downstream/payeeServicesV1';
import {
  transformDownstreamResponseToUi,
  ExpApiResponseData,
  incrementCopCounters,
  incrementDailyCounterOnError,
} from '../helpers/postAccountNameCheckController.helper';
import { getLimitCounter } from '../../utils/limitCounter';
import {
  COP_LIMIT_EXCEEDED_ERROR,
  COP_SESSION_LIMIT,
  COP_DAILY_LIMIT,
} from '../../utils/apiConstants';
import { decodeAccessToken } from '../../utils/tokenDecoder';
import type { DecodedToken } from '../../utils/tokenDecoder';
import { getCounterLimits } from '../../utils/counterLimitUtils';

const postAccountNameCheckController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { logger } = res.locals;
  const { accountNameCheck } = payeeServicesV1Services;
  const {
    getSessionIdCounter,
    incrementSessionIdCounter,
    getPaymentCounter,
    incrementPaymentCounter,
  } = channelPaymentUtilsV1Services;
  const { payee } = req.body as accountNameCheckRequest;

  let decodedToken: DecodedToken;
  try {
    decodedToken = decodeAccessToken(res);
  } catch (error) {
    // `handleControllerError` expects an APIClientError-like shape (e.g. `error.status`).
    // Wrap token decode failures to avoid runtime type mismatches.
    const apiError =
      {
        error: {
          status: 401,
          data: {
            errors: [
              {
                message:
                  error instanceof Error
                    ? error.message
                    : 'Failed to decode access token',
              },
            ],
          },
        },
      } as unknown as APIClientError;

    handleControllerError({
      error: apiError,
      res,
      logger,
    });
    next(error);
    return;
  }

  try {
    // AC3: Check session and daily limits before calling Verify+CoP lookup
    const counterLimits = await getCounterLimits({
      getSessionIdCounter: getSessionIdCounter as unknown as APIClient,
      getPaymentCounter: getPaymentCounter as unknown as APIClient,
      limitCounterFn: (apiClient, response, request, userId, sessionIndex) =>
        getLimitCounter(
          'COP',
          apiClient,
          response,
          request,
          userId,
          sessionIndex
        ),
      res,
      req,
      userId: decodedToken.userId,
      sessionIndex: decodedToken.sessionIndex,
      next,
    });

    if (!counterLimits) {
      return; // Error already handled in getCounterLimits
    }

    const { sessionCounter, userCounter } = counterLimits;

    // AC3: Check if limits exceeded - session limit is 20, daily limit is 50
    if (sessionCounter > COP_SESSION_LIMIT || userCounter > COP_DAILY_LIMIT) {
      res.status(STATUS_CODES.BAD_REQUEST).json(COP_LIMIT_EXCEEDED_ERROR);
      return;
    }

    // AC4: Limits passed, proceed with account name check
    const downstreamResponse = await handleApiService({
      req,
      res,
      apiClient: accountNameCheck as unknown as APIClient,
      setDownstreamParams: setParamsForAccountNameCheck,
      requestBody: { payee },
    });

    const responseData = downstreamResponse.data as AccountNameCheckResponse;
    const matchedStatus = responseData?.data?.matchedStatus?.code;

    // Increment counters based on matchedStatus
    await incrementCopCounters(
      matchedStatus,
      incrementSessionIdCounter,
      incrementPaymentCounter,
      res,
      req,
      decodedToken.userId,
      decodedToken?.sessionIndex
    );

    const expApiResponseData: ExpApiResponseData =
      transformDownstreamResponseToUi(responseData);

    const normalisedData = normaliseData(
      'accountNameCheck',
      expApiResponseData,
      normalise
    );

    res.status(downstreamResponse.status).json(normalisedData).end();
  } catch (error: unknown) {
    const apiError = error as APIClientError;

    // Increment daily counter only on 400/500 errors
    if (decodedToken?.userId) {
      try {
        await incrementDailyCounterOnError(
          apiError?.error?.status,
          incrementPaymentCounter,
          res,
          req,
          decodedToken.userId
        );
      } catch (counterError) {
        logger?.warn('Failed to increment daily counter on error', {
          counterError,
        });
      }
    }

    handleControllerError({ error: apiError, res, logger });
    next(error);
  }
};

export = postAccountNameCheckController;
