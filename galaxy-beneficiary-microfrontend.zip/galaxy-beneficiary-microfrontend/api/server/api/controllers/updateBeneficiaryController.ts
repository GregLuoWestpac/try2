/* eslint-disable consistent-return */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { Request, Response, NextFunction } from 'express';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import {
  handleControllerError,
  handleApiService,
  normaliseData,
  STATUS_CODES,
  APIClientError,
  accessControlExposeHeaders,
  APIClient,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { detectInjectionVulnerabilityForBeneficiary } from '@mesh-tenant-multiverse-ui-common/mv-apibeneficiarycreate';
import { beneficiaryManagementV1Services } from '../../generated/api-clients';
import {
  ExpApiResponseData,
  transformDownstreamResponseToUi,
} from '../helpers/updateBeneficiaryController.helper';
import { setParamsForStatusUpdateBeneficiary } from '../../utils/setParams';

const updateBeneficiaryController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { logger } = res.locals;

  const { updateBeneficiary, updateBeneficiaryStatus } =
    beneficiaryManagementV1Services;
  const { id, currencyAmount, ...restBeneficiaryRawData } =
    req.body.beneficiary;

  const beneficiaryWithoutId = {
    ...restBeneficiaryRawData,
    ...(currencyAmount && {
      ...(currencyAmount.amount && { amount: currencyAmount.amount }),
      ...(currencyAmount.currencyCode && {
        currency: currencyAmount.currencyCode,
      }),
    }),
  };

  const { vulnerabilityDetected, message, vulnerableFields } =
    detectInjectionVulnerabilityForBeneficiary(beneficiaryWithoutId);
  if (vulnerabilityDetected) {
    logger.trace(`${message} Vulnerable fields:`, vulnerableFields);
    return res.status(STATUS_CODES.BAD_REQUEST).json(message).end();
  }

  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);
  try {
    await handleApiService({
      req,
      res,
      apiClient: updateBeneficiaryStatus as unknown as APIClient,
      setDownstreamParams: setParamsForStatusUpdateBeneficiary,
      pathParams: { id },
      requestBody: { status: 'ACTIVE' },
    });

    const downstreamResponse = await handleApiService({
      req,
      res,
      apiClient: updateBeneficiary as APIClient,
      pathParams: { id },
      requestBody: beneficiaryWithoutId,
    });

    const expApiResponseData: ExpApiResponseData =
      transformDownstreamResponseToUi(downstreamResponse.data);

    const normalisedData = normaliseData(
      'beneficiaryUpdate',
      expApiResponseData.beneficiaryUpdate,
      normalise
    );

    res.status(STATUS_CODES.OK).json(normalisedData).end();
  } catch (error: unknown) {
    handleControllerError({ error: error as APIClientError, res, logger });
    next(error);
  }
};

export = updateBeneficiaryController;
