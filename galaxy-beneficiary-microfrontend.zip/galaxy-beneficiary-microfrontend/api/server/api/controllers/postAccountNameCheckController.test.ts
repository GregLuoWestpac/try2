/* eslint-disable import/first */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response, NextFunction } from 'express';

// Mocks must be declared before importing controller
jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  handleApiService: jest.fn(),
  handleControllerError: jest.fn(),
  normaliseData: jest.fn(),
  jwtDecode: jest.fn(),
  STATUS_CODES: { OK: 200, BAD_REQUEST: 400, INTERNAL_SERVER_ERROR: 500 },
}));

jest.mock('@mep-node/framework-response-normaliser-addon', () => ({
  normalise: jest.fn(() => (x: unknown) => x),
}));

jest.mock('@mep-node/framework-constants', () => ({
  RUNTIME: {
    isLocal: jest.fn(),
  },
}));

jest.mock('../helpers/postAccountNameCheckController.helper', () => ({
  transformDownstreamResponseToUi: jest.fn(),
  incrementCopCounters: jest.fn().mockResolvedValue({ incremented: true }),
  incrementDailyCounterOnError: jest.fn().mockResolvedValue(undefined),
}));

jest.mock('../../utils/limitCounter', () => ({
  getLimitCounter: jest.fn(),
}));

// Mock the generated API clients - match the actual export structure
jest.mock('../../generated/api-clients', () => ({
  payeeServicesV1Services: {
    accountNameCheck: { name: 'accountNameCheck' },
  },
  channelPaymentUtilsV1Services: {
    getSessionIdCounter: { name: 'getSessionIdCounter' },
    incrementSessionIdCounter: { name: 'incrementSessionIdCounter' },
    getPaymentCounter: { name: 'getPaymentCounter' },
    incrementPaymentCounter: { name: 'incrementPaymentCounter' },
  },
}));

jest.mock('../../utils/setParams', () => ({
  setParamsForAccountNameCheck: jest.fn(),
}));

// Import after mocks
import {
  handleApiService,
  handleControllerError,
  normaliseData,
  jwtDecode,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { RUNTIME } from '@mep-node/framework-constants';
import postAccountNameCheckController from './postAccountNameCheckController';
import {
  transformDownstreamResponseToUi,
  incrementCopCounters,
  incrementDailyCounterOnError,
} from '../helpers/postAccountNameCheckController.helper';
import { getLimitCounter } from '../../utils/limitCounter';
import { TokenDecodeError } from '../../utils/tokenDecoder';

interface TestLocals {
  logger: { info: jest.Mock; error: jest.Mock; warn?: jest.Mock };
  apiHeaders: Record<string, string>;
}

const makeReq = (body: Record<string, unknown>) =>
  ({
    body,
    headers: {},
  } as unknown as Request);

const makeRes = (): Response & { locals: TestLocals } =>
  ({
    locals: {
      logger: { info: jest.fn(), error: jest.fn(), warn: jest.fn() },
      apiHeaders: {
        'x-access-token': 'test-token',
        'x-appCorrelationId': 'corr-123',
        'x-userId': 'user-123',
        'x-userIdScheme': 'CustomerInternalId',
      },
    },
    status: jest.fn().mockReturnThis(),
    json: jest.fn().mockReturnThis(),
    end: jest.fn().mockReturnThis(),
  } as unknown as Response & { locals: TestLocals });

const downstreamData = {
  data: {
    matchedAccountName: 'Paul Walker',
    matchedStatus: {
      code: 'V0C1',
      description: 'A match response was returned by Verify+ and CoP',
    },
  },
};

const transformed = [
  {
    id: 'mocked-uuid-123',
    matchedAccountName: 'Paul Walker',
    matchedStatus: {
      code: 'V0C1',
    },
    matchedColor: 'Blue',
  },
];

const normalised = {
  entities: {
    accountNameCheck: [
      {
        id: 'mocked-uuid-123',
        matchedAccountName: 'Paul Walker',
        matchedStatus: {
          code: 'V0C1',
        },
        matchedColor: 'Blue',
      },
    ],
  },
  result: {
    accountNameCheck: ['mocked-uuid-123'],
  },
};

beforeEach(() => {
  jest.clearAllMocks();
  (RUNTIME.isLocal as jest.Mock).mockReturnValue(true); // Default to local mode
  (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(transformed);
  (normaliseData as jest.Mock).mockReturnValue(normalised);
  (getLimitCounter as jest.Mock).mockResolvedValue({
    counters: [{ session: { counter: 1 }, counter: 1 }],
  });
});

describe('postAccountNameCheckController', () => {
  let req: Partial<Request>;
  let res: Response & { locals: TestLocals };
  let next: jest.MockedFunction<NextFunction>;

  beforeEach(() => {
    req = makeReq({
      payee: {
        name: 'Paul Walker',
        accountId: {
          accountNumber: '345623189665',
          BSB: '037724',
        },
      },
    });
    res = makeRes();
    next = jest.fn();
  });

  test('should successfully process account name check request', async () => {
    (handleApiService as jest.Mock).mockResolvedValueOnce({
      status: 200,
      data: downstreamData,
    });

    await postAccountNameCheckController(req as Request, res as Response, next);

    expect(handleApiService).toHaveBeenCalledTimes(1);
    expect(handleApiService).toHaveBeenCalledWith(
      expect.objectContaining({
        req,
        res,
        requestBody: {
          payee: {
            name: 'Paul Walker',
            accountId: {
              accountNumber: '345623189665',
              BSB: '037724',
            },
          },
        },
      })
    );
    expect(transformDownstreamResponseToUi).toHaveBeenCalledWith(
      downstreamData
    );
    expect(normaliseData).toHaveBeenCalledWith(
      'accountNameCheck',
      transformed,
      expect.any(Function)
    );
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(normalised);
    expect(res.end).toHaveBeenCalled();
    expect(handleControllerError).not.toHaveBeenCalled();
  });

  test('should handle downstream API error', async () => {
    const apiError = {
      error: {
        status: 500,
        message: 'Internal Server Error',
      },
    };
    (handleApiService as jest.Mock).mockRejectedValueOnce(apiError);

    await postAccountNameCheckController(req as Request, res as Response, next);

    expect(handleApiService).toHaveBeenCalledTimes(1);
    expect(handleControllerError).toHaveBeenCalledWith({
      error: apiError,
      res,
      logger: res.locals.logger,
    });
    expect(next).toHaveBeenCalledWith(apiError);
  });

  test('should handle 400 Bad Request from downstream', async () => {
    const badRequestError = {
      error: {
        status: 400,
        message: 'Bad Request',
        data: {
          result: {
            errors: [
              {
                code: 1001,
                message: 'Invalid input parameter',
                details: 'The supplied parameter value is missing or invalid.',
              },
            ],
          },
        },
      },
    };
    (handleApiService as jest.Mock).mockRejectedValueOnce(badRequestError);

    await postAccountNameCheckController(req as Request, res as Response, next);

    expect(handleControllerError).toHaveBeenCalledWith({
      error: badRequestError,
      res,
      logger: res.locals.logger,
    });
    expect(next).toHaveBeenCalledWith(badRequestError);
  });

  test('should call transformDownstreamResponseToUi with correct response data', async () => {
    const customDownstreamData = {
      data: {
        matchedAccountName: 'Apple Tree',
        matchedStatus: {
          code: 'V0C2',
          description: 'Close match found',
        },
      },
    };
    (handleApiService as jest.Mock).mockResolvedValueOnce({
      status: 200,
      data: customDownstreamData,
    });

    await postAccountNameCheckController(req as Request, res as Response, next);

    expect(transformDownstreamResponseToUi).toHaveBeenCalledWith(
      customDownstreamData
    );
  });

  test('should handle empty payee in request body', async () => {
    req = makeReq({ payee: {} });
    (handleApiService as jest.Mock).mockResolvedValueOnce({
      status: 200,
      data: downstreamData,
    });

    await postAccountNameCheckController(req as Request, res as Response, next);

    expect(handleApiService).toHaveBeenCalledWith(
      expect.objectContaining({
        requestBody: { payee: {} },
      })
    );
  });

  test('should handle counters.length === 0 scenario', async () => {
    jest.clearAllMocks();
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(true);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(transformed);
    (normaliseData as jest.Mock).mockReturnValue(normalised);

    (getLimitCounter as jest.Mock)
      .mockResolvedValueOnce({ counters: [] })
      .mockResolvedValueOnce({ counters: [{ counter: 5 }] });

    (handleApiService as jest.Mock).mockResolvedValueOnce({
      status: 200,
      data: downstreamData,
    });

    await postAccountNameCheckController(req as Request, res as Response, next);

    // When counters.length === 0, getLimitCounter is called twice:
    // 1st call gets empty counters, 2nd call gets user counter
    expect(getLimitCounter).toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(200);
  });

  test('should handle getLimitCounter error with 404 and code 1003', async () => {
    const error404 = {
      error: {
        status: 404,
        data: {
          result: {
            errors: [{ code: 1003 }],
          },
        },
      },
    };

    (getLimitCounter as jest.Mock).mockRejectedValueOnce(error404);
    (handleApiService as jest.Mock).mockResolvedValueOnce({
      status: 200,
      data: downstreamData,
    });

    await postAccountNameCheckController(req as Request, res as Response, next);

    expect(res.status).toHaveBeenCalledWith(200);
    expect(handleControllerError).not.toHaveBeenCalled();
  });

  test('should handle getLimitCounter error and call handleControllerError', async () => {
    const genericError = {
      error: {
        status: 500,
        data: { message: 'Internal error' },
      },
    };

    (getLimitCounter as jest.Mock).mockRejectedValueOnce(genericError);

    await postAccountNameCheckController(req as Request, res as Response, next);

    expect(handleControllerError).toHaveBeenCalledWith({
      error: genericError,
      res,
      logger: res.locals.logger,
    });
    expect(next).toHaveBeenCalledWith(genericError);
  });

  test('should handle JWT decode error in non-local environment', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValueOnce(false);
    const tokenError = new Error('Invalid token');
    (jwtDecode as jest.Mock).mockImplementation(() => {
      throw tokenError;
    });

    await postAccountNameCheckController(req as Request, res as Response, next);

    expect(handleControllerError).toHaveBeenCalledWith({
      error: expect.objectContaining({
        error: expect.objectContaining({
          status: 401,
        }),
      }),
      res,
      logger: res.locals.logger,
    });
    expect(next).toHaveBeenCalledWith(expect.any(TokenDecodeError));
  });

  test('should log warning when increment counter returns empty counters object', async () => {
    (getLimitCounter as jest.Mock).mockResolvedValueOnce({
      counters: [{ session: { counter: 1 }, counter: 1 }],
    });

    // Mock incrementCopCounters to return incremented: false with a warning message
    (incrementCopCounters as jest.Mock).mockResolvedValueOnce({
      incremented: false,
      message: 'COP limit failed to increment daily counter',
    });

    (handleApiService as jest.Mock).mockResolvedValueOnce({
      status: 200,
      data: downstreamData,
    });

    await postAccountNameCheckController(req as Request, res as Response, next);

    expect(incrementCopCounters).toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(200);
  });

  test('should increment daily counter on downstream 400 error', async () => {
    const error400 = {
      error: {
        status: 400,
        message: 'Bad Request',
      },
    };

    const mockGetLimitCounter = getLimitCounter as jest.Mock;
    mockGetLimitCounter.mockClear();
    mockGetLimitCounter.mockResolvedValueOnce({
      counters: [{ session: { counter: 1 }, counter: 1 }],
    });

    (handleApiService as jest.Mock).mockRejectedValueOnce(error400);

    await postAccountNameCheckController(req as Request, res as Response, next);

    // incrementDailyCounterOnError should be called for 400 errors
    expect(incrementDailyCounterOnError).toHaveBeenCalledWith(
      400,
      expect.anything(),
      expect.anything(),
      expect.anything(),
      expect.anything()
    );
    expect(handleControllerError).toHaveBeenCalledWith({
      error: error400,
      res,
      logger: res.locals.logger,
    });
    expect(next).toHaveBeenCalledWith(error400);
  });

  test('should increment daily counter on downstream 5xx error', async () => {
    const error500 = {
      error: {
        status: 500,
        message: 'Internal Server Error',
      },
    };

    const mockGetLimitCounter = getLimitCounter as jest.Mock;
    mockGetLimitCounter.mockClear();
    mockGetLimitCounter.mockResolvedValueOnce({
      counters: [{ session: { counter: 1 }, counter: 1 }],
    });

    (handleApiService as jest.Mock).mockRejectedValueOnce(error500);

    await postAccountNameCheckController(req as Request, res as Response, next);

    // incrementDailyCounterOnError should be called for 500 errors
    expect(incrementDailyCounterOnError).toHaveBeenCalledWith(
      500,
      expect.anything(),
      expect.anything(),
      expect.anything(),
      expect.anything()
    );
    expect(handleControllerError).toHaveBeenCalledWith({
      error: error500,
      res,
      logger: res.locals.logger,
    });
    expect(next).toHaveBeenCalledWith(error500);
  });

  test('should not increment counter on other HTTP errors (not 400/500)', async () => {
    const error404 = {
      error: {
        status: 404,
        message: 'Not Found',
      },
    };

    const mockGetLimitCounter = getLimitCounter as jest.Mock;
    mockGetLimitCounter.mockClear();
    mockGetLimitCounter.mockResolvedValueOnce({
      counters: [{ session: { counter: 1 }, counter: 1 }],
    });

    (handleApiService as jest.Mock).mockRejectedValueOnce(error404);

    await postAccountNameCheckController(req as Request, res as Response, next);

    // incrementDailyCounterOnError is called but should do nothing for 404 errors
    expect(incrementDailyCounterOnError).toHaveBeenCalledWith(
      404,
      expect.anything(),
      expect.anything(),
      expect.anything(),
      expect.anything()
    );
    expect(handleControllerError).toHaveBeenCalledWith({
      error: error404,
      res,
      logger: res.locals.logger,
    });
    expect(next).toHaveBeenCalledWith(error404);
  });

  describe('matchedStatus counter increment logic', () => {
    test('should increment both session and daily counters for V1C3 matchedStatus', async () => {
      const dataWithV1C3 = {
        data: {
          matchedAccountName: 'Paul Walker',
          matchedStatus: { code: 'V1C3' },
        },
      };

      const mockGetLimitCounter = getLimitCounter as jest.Mock;
      mockGetLimitCounter.mockClear();
      mockGetLimitCounter.mockResolvedValueOnce({
        counters: [{ session: { counter: 1 }, counter: 1 }],
      });

      (handleApiService as jest.Mock).mockResolvedValueOnce({
        status: 200,
        data: dataWithV1C3,
      });

      await postAccountNameCheckController(
        req as Request,
        res as Response,
        next
      );

      // incrementCopCounters should be called with V1C3 matchedStatus
      expect(incrementCopCounters).toHaveBeenCalledWith(
        'V1C3',
        expect.anything(),
        expect.anything(),
        expect.anything(),
        expect.anything(),
        expect.anything(),
        expect.anything()
      );
    });

    test('should increment only daily counter for V0C1 matchedStatus', async () => {
      const mockGetLimitCounter = getLimitCounter as jest.Mock;
      mockGetLimitCounter.mockClear();
      mockGetLimitCounter.mockResolvedValueOnce({
        counters: [{ session: { counter: 1 }, counter: 1 }],
      });

      (handleApiService as jest.Mock).mockResolvedValueOnce({
        status: 200,
        data: downstreamData, // V0C1 - not in the session+daily list
      });

      await postAccountNameCheckController(
        req as Request,
        res as Response,
        next
      );

      // incrementCopCounters should be called with V0C1 matchedStatus
      expect(incrementCopCounters).toHaveBeenCalledWith(
        'V0C1',
        expect.anything(),
        expect.anything(),
        expect.anything(),
        expect.anything(),
        expect.anything(),
        expect.anything()
      );
    });

    test('should not increment any counter when matchedStatus is missing', async () => {
      const dataWithoutMatchedStatus = {
        data: {
          matchedAccountName: 'Paul Walker',
        },
      };

      const mockGetLimitCounter = getLimitCounter as jest.Mock;
      mockGetLimitCounter.mockClear();
      mockGetLimitCounter.mockResolvedValueOnce({
        counters: [{ session: { counter: 1 }, counter: 1 }],
      });

      (handleApiService as jest.Mock).mockResolvedValueOnce({
        status: 200,
        data: dataWithoutMatchedStatus,
      });

      await postAccountNameCheckController(
        req as Request,
        res as Response,
        next
      );

      // incrementCopCounters should be called with undefined matchedStatus
      expect(incrementCopCounters).toHaveBeenCalledWith(
        undefined,
        expect.anything(),
        expect.anything(),
        expect.anything(),
        expect.anything(),
        expect.anything(),
        expect.anything()
      );
    });

    test.each([
      'V1C3',
      'V1C4',
      'V2C3',
      'V2C4',
      'VAC3',
      'VTC3',
      'VEC3',
      'VAC4',
      'VTC4',
      'VEC4',
    ])(
      'should increment both counters for %s matchedStatus',
      async statusCode => {
        const dataWithCode = {
          data: {
            matchedAccountName: 'Test User',
            matchedStatus: { code: statusCode },
          },
        };

        const mockGetLimitCounter = getLimitCounter as jest.Mock;
        mockGetLimitCounter.mockClear();
        mockGetLimitCounter.mockResolvedValueOnce({
          counters: [{ session: { counter: 1 }, counter: 1 }],
        });

        (handleApiService as jest.Mock).mockResolvedValueOnce({
          status: 200,
          data: dataWithCode,
        });

        await postAccountNameCheckController(
          req as Request,
          res as Response,
          next
        );

        // incrementCopCounters should be called with the correct matchedStatus
        expect(incrementCopCounters).toHaveBeenCalledWith(
          statusCode,
          expect.anything(),
          expect.anything(),
          expect.anything(),
          expect.anything(),
          expect.anything(),
          expect.anything()
        );
      }
    );
  });

  describe('CoP limit checks', () => {
    const setupLimitCheck = (sessionCounter: number, userCounter: number) => {
      (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
      (jwtDecode as jest.Mock).mockReturnValue({
        userId: 'user123',
        sessionIndex: 'session123',
      });
      (handleApiService as jest.Mock).mockClear();
      (getLimitCounter as jest.Mock).mockClear();
      (getLimitCounter as jest.Mock).mockResolvedValue({
        counters: [
          { session: { counter: sessionCounter }, counter: userCounter },
        ],
      });
    };

    test('proceeds with account name check when limits not exceeded', async () => {
      setupLimitCheck(10, 25);
      (handleApiService as jest.Mock).mockResolvedValueOnce({
        status: 200,
        data: downstreamData,
      });

      await postAccountNameCheckController(
        req as Request,
        res as Response,
        next
      );

      expect(handleApiService).toHaveBeenCalledTimes(1);
      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith(normalised);
    });

    test('returns limit exceeded error when session limit reached', async () => {
      setupLimitCheck(20, 10);

      await postAccountNameCheckController(
        req as Request,
        res as Response,
        next
      );

      expect(handleApiService).not.toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          result: expect.objectContaining({
            errors: expect.arrayContaining([
              expect.objectContaining({ code: 3000 }),
            ]),
          }),
        })
      );
    });

    test('returns limit exceeded error when daily limit reached', async () => {
      setupLimitCheck(10, 50);

      await postAccountNameCheckController(
        req as Request,
        res as Response,
        next
      );

      expect(handleApiService).not.toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          result: expect.objectContaining({
            errors: expect.arrayContaining([
              expect.objectContaining({ code: 3000 }),
            ]),
          }),
        })
      );
    });

    test('returns limit exceeded error when both limits exceeded', async () => {
      setupLimitCheck(25, 60);

      await postAccountNameCheckController(
        req as Request,
        res as Response,
        next
      );

      expect(handleApiService).not.toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(400);
    });
  });
});
