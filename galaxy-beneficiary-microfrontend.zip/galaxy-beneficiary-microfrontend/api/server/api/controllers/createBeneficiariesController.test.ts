import { NextFunction } from 'express';
import { createRequest, createResponse } from 'node-mocks-http';

// Create mock controller function
const mockControllerFunction = jest.fn().mockResolvedValue(undefined);

// Mock all the dependencies before importing anything else
jest.mock('@mep-node/framework-constants', () => ({
  RUNTIME: {
    APP_NAME: 'test-app',
    NODE_ENV: 'test',
  },
}));

jest.mock('@mep-node/framework-response-normaliser-addon', () => ({
  normalise: jest.fn().mockReturnValue('normalized-data'),
}));

jest.mock('../../generated/api-clients', () => ({
  beneficiaryManagementV1Services: {
    createBeneficiary: jest.fn(),
    createBeneficiaries: jest.fn(),
  },
}));

jest.mock('../../utils/secretsUtil', () => ({
  readMeshSecrets: jest.fn().mockReturnValue({}),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apibeneficiarycreate', () => ({
  buildCreateBeneficiaryController: jest
    .fn()
    .mockReturnValue(mockControllerFunction),
}));

describe('createBeneficiariesController', () => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let createBeneficiariesController: any;

  beforeEach(() => {
    jest.clearAllMocks();
    // Re-import the controller to get a fresh instance
    // eslint-disable-next-line @typescript-eslint/no-var-requires, global-require
    createBeneficiariesController = require('./createBeneficiariesController');
  });

  it('should export the controller function', () => {
    expect(typeof createBeneficiariesController).toBe('function');
  });

  it('should call the controller function when invoked', async () => {
    const req = createRequest({
      method: 'POST',
      url: '/beneficiaries',
      body: {
        name: 'Test Beneficiary',
        accountNumber: '123456789',
      },
    });
    const res = createResponse();
    const next: NextFunction = jest.fn();

    await createBeneficiariesController(req, res, next);

    expect(mockControllerFunction).toHaveBeenCalledWith(req, res, next);
  });

  it('should handle errors gracefully', async () => {
    const mockError = new Error('Test error');
    mockControllerFunction.mockRejectedValueOnce(mockError);

    const req = createRequest({
      method: 'POST',
      url: '/beneficiaries',
      body: { name: 'Test' },
    });
    const res = createResponse();
    const next: NextFunction = jest.fn();

    await expect(createBeneficiariesController(req, res, next)).rejects.toThrow(
      'Test error'
    );
  });

  it('should pass request body correctly', async () => {
    const requestBody = {
      name: 'John Doe',
      accountNumber: '987654321',
      bsb: '123456',
      accountType: 'savings',
    };

    const req = createRequest({
      method: 'POST',
      url: '/beneficiaries',
      body: requestBody,
    });
    const res = createResponse();
    const next: NextFunction = jest.fn();

    await createBeneficiariesController(req, res, next);

    expect(mockControllerFunction).toHaveBeenCalledWith(req, res, next);
    expect(req.body).toEqual(requestBody);
  });
});
