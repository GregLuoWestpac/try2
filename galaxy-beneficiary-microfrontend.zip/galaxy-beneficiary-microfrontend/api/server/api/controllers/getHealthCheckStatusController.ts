import { Request, Response, NextFunction } from 'express';

/**
 * A generic health check status controller
 * @param {object} req - Implicit HTTP request object based on http.IncomingMessage
 * @param {object} res - Implicit HTTP response object based on http.ServerResponse
 */
const getHealthCheckStatusController = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { logger } = res.locals;

  // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access, @typescript-eslint/no-unsafe-call
  logger.trace('HealthCheck controller');

  res.status(200).json({ status: 'success' });

  next();
};

export = getHealthCheckStatusController;
