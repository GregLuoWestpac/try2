import { Request, Response, NextFunction } from 'express';
import {
  handleControllerError,
  handleApiService,
  APIClientError,
  APIClient,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { beneficiaryManagementV1Services } from '../../generated/api-clients';
import { UpdateBeneficiaryStatusData } from '../../../types/updateBeneficiaryStatus';
import { setParamsForStatusUpdateBeneficiary } from '../../utils/setParams';

const updateBeneficiaryStatusController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { logger } = res.locals;
  const { updateBeneficiaryStatus } = beneficiaryManagementV1Services;
  const { id, status } = (req.body as UpdateBeneficiaryStatusData).beneficiary;

  try {
    const downstreamResponse = await handleApiService({
      req,
      res,
      apiClient: updateBeneficiaryStatus as unknown as APIClient,
      setDownstreamParams: setParamsForStatusUpdateBeneficiary,
      pathParams: { id },
      requestBody: { status },
    });
    res.status(downstreamResponse.status).json(downstreamResponse.data);
  } catch (error: unknown) {
    handleControllerError({ error: error as APIClientError, res, logger });
    next(error);
  }
};

export = updateBeneficiaryStatusController;
