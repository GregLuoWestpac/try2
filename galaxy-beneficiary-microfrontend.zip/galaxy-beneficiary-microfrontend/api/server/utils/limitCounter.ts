import { Request, Response } from 'express';
import {
  DownstreamServiceResponse,
  handleApiService,
  PathParams,
  QueryParams,
  APIClient,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { setParamsForPaymentCounter } from './setParams';

/**
 * Generic function to get/increment payment limit counter
 * Used for both CoP and PayID counter operations
 *
 * @param counterName - The counter name (e.g., 'COP', 'PAYID')
 * @param apiClient - The API client to use for the request
 * @param res - Express response object
 * @param req - Express request object
 * @param userId - Customer ID for the counter
 * @param sessionId - Optional session ID (not used for payment counter)
 * @returns The counter data from downstream response
 */
export const getLimitCounter = async (
  counterName: string,
  apiClient: APIClient,
  res: Response,
  req: Request,
  userId: string,
  sessionId?: string
) => {
  const isGetSessionCounter = apiClient.name === 'getSessionIdCounter';
  const isGetPaymentCounter = apiClient.name === 'getPaymentCounter';

  const pathParams: PathParams = {
    name: counterName,
    customerId: userId,
    ...(!isGetPaymentCounter && { sessionId }),
  };
  const bodyParams =
    isGetSessionCounter || isGetPaymentCounter ? undefined : {};
  const queryParams: QueryParams | undefined = undefined;

  const { data: paymentCounterDownstreamResponse }: DownstreamServiceResponse =
    await handleApiService({
      req,
      res,
      apiClient,
      setDownstreamParams: (apiHeaders, response, request, appConfig) => {
        const paymentCounterParams = setParamsForPaymentCounter(
          apiHeaders,
          response,
          bodyParams,
          appConfig,
          queryParams,
          pathParams
        );
        return paymentCounterParams;
      },
    });
  return paymentCounterDownstreamResponse.data;
};
