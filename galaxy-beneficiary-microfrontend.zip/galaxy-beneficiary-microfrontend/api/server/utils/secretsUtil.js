/* eslint-disable security/detect-non-literal-fs-filename */
/* eslint-disable node/no-extraneous-require */
const fs = require('fs');
const path = require('path');

// read decrypted secrets file(s) from directory /secrets
const secretsDir = '/secrets';
const secretsFile = `${secretsDir}/.gitkeep`;

// secrets command uses the platform keys to encrypt your secrets and
// secrets will be made available in the container inside your secrets directory
const readMeshSecrets = logger => {
  if (fs.existsSync(secretsDir)) {
    const decryptedFileContent = fs.readFileSync(secretsFile, 'utf8');
    logger?.info('readMeshSecrets - decryptedFileContent found');
    return JSON.parse(decryptedFileContent);
  }

  // cannot find directory '/secrets'
  // log event
  const diagnosticsOutputMessage = `Cannot find the directory: ${secretsDir}`;
  logger?.info(
    `readMeshSecrets - diagnosticsOutputMessage -`,
    diagnosticsOutputMessage
  );
  return null;
};

module.exports = {
  readMeshSecrets,
};
