const handler = data => {
  let error;
  switch (data) {
    case 400:
      error = { errorMessage: 'Bad Request' };
      break;
    case 404:
      error = { errorMessage: 'Requested resource not found' };
      break;
    case 403:
      error = { errorMessage: 'Forbidden access', errorCode: 403 };
      break;
    case 500:
      error = { errorMessage: 'Internal server error' };
      break;
    default:
      error = { errorMessage: 'Internal server error' };
      break;
  }
  return error;
};

module.exports = {
  errorHandler: handler,
};