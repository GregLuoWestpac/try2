import { Request, Response, NextFunction } from 'express';
import {
  handleControllerError,
  APIClientError,
  APIClient,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

export type CounterResponse = {
  counters?: Array<{
    session?: { counter: number };
    counter: number;
  }>;
};

export type CounterResult = {
  sessionCounter: number;
  userCounter: number;
};

export type CounterLimitOptions = {
  getSessionIdCounter: APIClient;
  getPaymentCounter: APIClient;
  limitCounterFn: (
    client: APIClient,
    res: Response,
    req: Request,
    userId?: string,
    sessionIndex?: string
  ) => Promise<CounterResponse>;
  res: Response;
  req: Request;
  userId?: string;
  sessionIndex?: string;
  next?: NextFunction;
};

/**
 * Retrieves session and user counter values for limit checking
 * @param options - Configuration options for counter limit checking
 * @returns Counter values or null if error occurs
 */
export const getCounterLimits = async (
  options: CounterLimitOptions
): Promise<CounterResult | null> => {
  const {
    getSessionIdCounter,
    getPaymentCounter,
    limitCounterFn,
    res,
    req,
    userId,
    sessionIndex,
    next,
  } = options;
  const { logger } = res.locals;

  try {
    const { counters }: CounterResponse = await limitCounterFn(
      getSessionIdCounter,
      res,
      req,
      userId,
      sessionIndex
    );

    if (!counters || counters.length === 0) {
      const data: CounterResponse = await limitCounterFn(
        getPaymentCounter,
        res,
        req,
        userId
      );
      const userCounter = (data?.counters?.[0]?.counter ?? 0) + 1;
      return {
        sessionCounter: 1,
        userCounter,
      };
    }

    const sessionCounter = (counters?.[0]?.session?.counter ?? 0) + 1;
    const userCounter = (counters?.[0]?.counter ?? 0) + 1;
    return {
      sessionCounter,
      userCounter,
    };
  } catch (error: unknown) {
    const apiError = error as APIClientError;
    const { status, data } = apiError?.error || {};

    // Handle 404 error with code 1003 - counter not found, initialize to 1
    if (
      Number(status) === 404 &&
      Number(data?.result?.errors?.[0]?.code) === 1003
    ) {
      return {
        sessionCounter: 1,
        userCounter: 1,
      };
    }

    // For other errors, handle and propagate
    handleControllerError({ error: apiError, res, logger });
    if (next) {
      next(error);
    }
    return null;
  }
};
