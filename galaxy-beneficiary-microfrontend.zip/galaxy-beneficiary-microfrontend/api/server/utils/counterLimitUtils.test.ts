/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response, NextFunction } from 'express';
import {
  handleControllerError,
  APIClientError,
  APIClient,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { getCounterLimits, CounterResponse } from './counterLimitUtils';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  handleControllerError: jest.fn(),
}));

describe('counterLimitUtils', () => {
  let mockRes: Partial<Response>;
  let mockReq: Partial<Request>;
  let mockNext: jest.MockedFunction<NextFunction>;
  let mockLogger: { info: jest.Mock; error: jest.Mock; warn: jest.Mock };
  let mockGetSessionIdCounter: APIClient;
  let mockGetPaymentCounter: APIClient;
  let mockLimitCounterFn: jest.MockedFunction<any>;

  beforeEach(() => {
    jest.clearAllMocks();
    mockLogger = {
      info: jest.fn(),
      error: jest.fn(),
      warn: jest.fn(),
    };

    mockRes = {
      locals: {
        logger: mockLogger,
      },
    } as any;

    mockReq = {} as Request;
    mockNext = jest.fn();

    mockGetSessionIdCounter = {} as APIClient;
    mockGetPaymentCounter = {} as APIClient;
    mockLimitCounterFn = jest.fn();
  });

  describe('getCounterLimits', () => {
    it('should return counter values when session counter exists', async () => {
      const mockCounterResponse: CounterResponse = {
        counters: [
          {
            session: { counter: 5 },
            counter: 10,
          },
        ],
      };
      mockLimitCounterFn.mockResolvedValueOnce(mockCounterResponse);

      const result = await getCounterLimits({
        getSessionIdCounter: mockGetSessionIdCounter,
        getPaymentCounter: mockGetPaymentCounter,
        limitCounterFn: mockLimitCounterFn,
        res: mockRes as Response,
        req: mockReq as Request,
        userId: 'user123',
        sessionIndex: 'session456',
        next: mockNext,
      });

      expect(result).toEqual({
        sessionCounter: 6,
        userCounter: 11,
      });
      expect(mockLimitCounterFn).toHaveBeenCalledWith(
        mockGetSessionIdCounter,
        mockRes,
        mockReq,
        'user123',
        'session456'
      );
    });

    it('should fallback to payment counter when session counter is empty', async () => {
      const emptySessionResponse: CounterResponse = {
        counters: [],
      };
      const mockPaymentResponse: CounterResponse = {
        counters: [
          {
            counter: 3,
          },
        ],
      };
      mockLimitCounterFn
        .mockResolvedValueOnce(emptySessionResponse)
        .mockResolvedValueOnce(mockPaymentResponse);

      const result = await getCounterLimits({
        getSessionIdCounter: mockGetSessionIdCounter,
        getPaymentCounter: mockGetPaymentCounter,
        limitCounterFn: mockLimitCounterFn,
        res: mockRes as Response,
        req: mockReq as Request,
        userId: 'user123',
        sessionIndex: 'session456',
        next: mockNext,
      });

      expect(result).toEqual({
        sessionCounter: 1,
        userCounter: 4,
      });
      expect(mockLimitCounterFn).toHaveBeenCalledTimes(2);
      expect(mockLimitCounterFn).toHaveBeenNthCalledWith(
        2,
        mockGetPaymentCounter,
        mockRes,
        mockReq,
        'user123'
      );
    });

    it('should fallback to payment counter when counters is undefined', async () => {
      const undefinedCountersResponse: CounterResponse = {};
      const mockPaymentResponse: CounterResponse = {
        counters: [
          {
            counter: 5,
          },
        ],
      };
      mockLimitCounterFn
        .mockResolvedValueOnce(undefinedCountersResponse)
        .mockResolvedValueOnce(mockPaymentResponse);

      const result = await getCounterLimits({
        getSessionIdCounter: mockGetSessionIdCounter,
        getPaymentCounter: mockGetPaymentCounter,
        limitCounterFn: mockLimitCounterFn,
        res: mockRes as Response,
        req: mockReq as Request,
        userId: 'user123',
        sessionIndex: 'session456',
        next: mockNext,
      });

      expect(result).toEqual({
        sessionCounter: 1,
        userCounter: 6,
      });
      expect(mockLimitCounterFn).toHaveBeenCalledTimes(2);
    });

    it('should initialize to 1 when payment counter is empty', async () => {
      const emptySessionResponse: CounterResponse = {
        counters: [],
      };
      const emptyPaymentResponse: CounterResponse = {
        counters: [{ counter: 0 }],
      };
      mockLimitCounterFn
        .mockResolvedValueOnce(emptySessionResponse)
        .mockResolvedValueOnce(emptyPaymentResponse);

      const result = await getCounterLimits({
        getSessionIdCounter: mockGetSessionIdCounter,
        getPaymentCounter: mockGetPaymentCounter,
        limitCounterFn: mockLimitCounterFn,
        res: mockRes as Response,
        req: mockReq as Request,
        userId: 'user123',
        sessionIndex: 'session456',
        next: mockNext,
      });

      expect(result).toEqual({
        sessionCounter: 1,
        userCounter: 1,
      });
    });

    it('should handle 404 error with code 1003 and initialize counters to 1', async () => {
      const apiError: APIClientError = {
        error: {
          status: 404,
          data: {
            result: {
              errors: [
                {
                  code: 1003,
                  message: 'Counter not found',
                },
              ],
            },
          },
        },
      } as any;
      mockLimitCounterFn.mockRejectedValueOnce(apiError);

      const result = await getCounterLimits({
        getSessionIdCounter: mockGetSessionIdCounter,
        getPaymentCounter: mockGetPaymentCounter,
        limitCounterFn: mockLimitCounterFn,
        res: mockRes as Response,
        req: mockReq as Request,
        userId: 'user123',
        sessionIndex: 'session456',
        next: mockNext,
      });

      expect(result).toEqual({
        sessionCounter: 1,
        userCounter: 1,
      });
      expect(handleControllerError).not.toHaveBeenCalled();
    });

    it('should handle other errors and call handleControllerError', async () => {
      const apiError: APIClientError = {
        error: {
          status: 500,
          data: {
            message: 'Internal server error',
          },
        },
      } as any;
      mockLimitCounterFn.mockRejectedValueOnce(apiError);

      const result = await getCounterLimits({
        getSessionIdCounter: mockGetSessionIdCounter,
        getPaymentCounter: mockGetPaymentCounter,
        limitCounterFn: mockLimitCounterFn,
        res: mockRes as Response,
        req: mockReq as Request,
        userId: 'user123',
        sessionIndex: 'session456',
        next: mockNext,
      });

      expect(result).toBeNull();
      expect(handleControllerError).toHaveBeenCalledWith({
        error: apiError,
        res: mockRes,
        logger: mockLogger,
      });
      expect(mockNext).toHaveBeenCalledWith(apiError);
    });

    it('should handle 404 error with different error code', async () => {
      const apiError: APIClientError = {
        error: {
          status: 404,
          data: {
            result: {
              errors: [
                {
                  code: 9999,
                  message: 'Not found',
                },
              ],
            },
          },
        },
      } as any;
      mockLimitCounterFn.mockRejectedValueOnce(apiError);

      const result = await getCounterLimits({
        getSessionIdCounter: mockGetSessionIdCounter,
        getPaymentCounter: mockGetPaymentCounter,
        limitCounterFn: mockLimitCounterFn,
        res: mockRes as Response,
        req: mockReq as Request,
        userId: 'user123',
        sessionIndex: 'session456',
        next: mockNext,
      });

      expect(result).toBeNull();
      expect(handleControllerError).toHaveBeenCalled();
    });

    it('should work without next function provided', async () => {
      const apiError: APIClientError = {
        error: {
          status: 500,
          data: {
            message: 'Internal server error',
          },
        },
      } as any;
      mockLimitCounterFn.mockRejectedValueOnce(apiError);

      const result = await getCounterLimits({
        getSessionIdCounter: mockGetSessionIdCounter,
        getPaymentCounter: mockGetPaymentCounter,
        limitCounterFn: mockLimitCounterFn,
        res: mockRes as Response,
        req: mockReq as Request,
        userId: 'user123',
        sessionIndex: 'session456',
      });

      expect(result).toBeNull();
      expect(handleControllerError).toHaveBeenCalled();
    });

    it('should handle missing session counter gracefully', async () => {
      const mockCounterResponse: CounterResponse = {
        counters: [
          {
            counter: 7,
          },
        ],
      };
      mockLimitCounterFn.mockResolvedValueOnce(mockCounterResponse);

      const result = await getCounterLimits({
        getSessionIdCounter: mockGetSessionIdCounter,
        getPaymentCounter: mockGetPaymentCounter,
        limitCounterFn: mockLimitCounterFn,
        res: mockRes as Response,
        req: mockReq as Request,
        userId: 'user123',
        sessionIndex: 'session456',
        next: mockNext,
      });

      expect(result).toEqual({
        sessionCounter: 1, // undefined ?? 0 + 1 = 1
        userCounter: 8,
      });
    });
  });
});
