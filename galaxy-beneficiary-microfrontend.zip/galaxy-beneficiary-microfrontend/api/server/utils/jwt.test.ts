import { jwtDecode } from './jwt';

// Polyfill atob for Node if not present
beforeAll(() => {
  if (typeof (global as any).atob === 'undefined') {
    (global as any).atob = (b64: string) =>
      Buffer.from(b64, 'base64').toString('binary');
  }
});

// Helper to create base64url encoded segments
function base64UrlEncode(obj: Record<string, any>): string {
  const json = JSON.stringify(obj);
  const b64 = Buffer.from(json, 'utf8').toString('base64');
  return b64.replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

function buildJwt(payload: Record<string, any>): string {
  const header = base64UrlEncode({ alg: 'none', typ: 'JWT' });
  const body = base64UrlEncode(payload);
  const signature = ''; // Not verified in jwtDecode utility
  return `${header}.${body}.${signature}`;
}

describe('jwtDecode utility', () => {
  it('should decode a valid JWT payload', () => {
    const token = buildJwt({
      resource_uri: 'https://example.com/api/test',
      userId: 'abc',
      exp: 999999,
    });
    const decoded = jwtDecode(token);
    expect(decoded).toEqual(
      expect.objectContaining({
        resource_uri: 'https://example.com/api/test',
        userId: 'abc',
        exp: 999999,
      })
    );
  });

  it('should return null for token with fewer than 3 segments', () => {
    const badToken = 'abc.def';
    const decoded = jwtDecode(badToken);
    expect(decoded).toBeNull();
  });

  it('should throw InvalidTokenError for non-string token input', () => {
    expect(() => jwtDecode(123 as any)).toThrow(/Invalid token specified/);
  });

  it('should return null for invalid base64 JSON payload', () => {
    // Construct a token with invalid JSON in payload
    const header = 'e30'; // {}
    const invalidPayload = Buffer.from('{"incomplete":true', 'utf8')
      .toString('base64')
      .replace(/=/g, '')
      .replace(/\+/g, '-')
      .replace(/\//g, '_');
    const token = `${header}.${invalidPayload}.sig`; // 3 parts but payload won't parse
    const decoded = jwtDecode(token);
    expect(decoded).toBeNull();
  });

  it('should correctly handle url-safe base64 characters - and _', () => {
    const payload = { test: 'dash-and_underscore' };
    const token = buildJwt(payload);
    const decoded = jwtDecode(token);
    expect(decoded).toEqual(expect.objectContaining(payload));
  });

  it('should log error and return null when JSON.parse fails', () => {
    const consoleSpy = jest.spyOn(console, 'error').mockImplementation();

    // Create a token with invalid JSON that will fail JSON.parse
    const header = 'e30';
    const invalidJsonPayload = Buffer.from('not valid json', 'utf8')
      .toString('base64')
      .replace(/=/g, '')
      .replace(/\+/g, '-')
      .replace(/\//g, '_');
    const token = `${header}.${invalidJsonPayload}.sig`;

    const decoded = jwtDecode(token);

    expect(decoded).toBeNull();
    expect(consoleSpy).toHaveBeenCalled();

    consoleSpy.mockRestore();
  });
});
