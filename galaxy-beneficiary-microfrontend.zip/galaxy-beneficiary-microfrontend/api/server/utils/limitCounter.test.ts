import { getLimitCounter } from './limitCounter';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  handleApiService: jest.fn(),
}));

jest.mock('./setParams', () => ({
  setParamsForPaymentCounter: jest.fn(),
}));

const {
  handleApiService,
} = require('@mesh-tenant-multiverse-ui-common/mv-apiutils');
const { setParamsForPaymentCounter } = require('./setParams');

describe('getLimitCounter', () => {
  /* eslint-disable @typescript-eslint/no-explicit-any */
  let mockApiClient: any;
  let mockRes: any;
  let mockReq: any;
  /* eslint-enable @typescript-eslint/no-explicit-any */
  const userId = 'user123';
  const sessionId = 'session456';

  beforeEach(() => {
    jest.clearAllMocks();
    mockApiClient = {
      name: 'incrementSessionIdCounter',
    };
    mockRes = {};
    mockReq = {};

    setParamsForPaymentCounter.mockReturnValue({
      params: 'test-params',
    });
  });

  it('should get counter for CoP with session counter', async () => {
    mockApiClient.name = 'getSessionIdCounter';
    handleApiService.mockResolvedValue({
      data: { data: { count: 5 } },
    });

    const result = await getLimitCounter(
      'COP',
      mockApiClient,
      mockRes,
      mockReq,
      userId,
      sessionId
    );

    expect(handleApiService).toHaveBeenCalledWith({
      req: mockReq,
      res: mockRes,
      apiClient: mockApiClient,
      setDownstreamParams: expect.any(Function),
    });
    expect(result).toEqual({ count: 5 });
  });

  it('should get counter for PayID with payment counter', async () => {
    mockApiClient.name = 'getPaymentCounter';
    handleApiService.mockResolvedValue({
      data: { data: { count: 10 } },
    });

    const result = await getLimitCounter(
      'PAYID',
      mockApiClient,
      mockRes,
      mockReq,
      userId
    );

    expect(handleApiService).toHaveBeenCalledWith({
      req: mockReq,
      res: mockRes,
      apiClient: mockApiClient,
      setDownstreamParams: expect.any(Function),
    });
    expect(result).toEqual({ count: 10 });
  });

  it('should increment counter with correct path params', async () => {
    handleApiService.mockResolvedValue({
      data: { data: { count: 1 } },
    });

    await getLimitCounter(
      'COP',
      mockApiClient,
      mockRes,
      mockReq,
      userId,
      sessionId
    );

    const setDownstreamParamsCall =
      handleApiService.mock.calls[0][0].setDownstreamParams;
    setDownstreamParamsCall({}, mockRes, mockReq, {});

    expect(setParamsForPaymentCounter).toHaveBeenCalledWith(
      {},
      mockRes,
      {},
      {},
      undefined,
      {
        name: 'COP',
        customerId: userId,
        sessionId,
      }
    );
  });

  it('should not include sessionId for payment counter', async () => {
    mockApiClient.name = 'getPaymentCounter';
    handleApiService.mockResolvedValue({
      data: { data: { count: 15 } },
    });

    await getLimitCounter(
      'PAYID',
      mockApiClient,
      mockRes,
      mockReq,
      userId,
      sessionId
    );

    const setDownstreamParamsCall =
      handleApiService.mock.calls[0][0].setDownstreamParams;
    setDownstreamParamsCall({}, mockRes, mockReq, {});

    expect(setParamsForPaymentCounter).toHaveBeenCalledWith(
      {},
      mockRes,
      undefined,
      {},
      undefined,
      {
        name: 'PAYID',
        customerId: userId,
      }
    );
  });

  it('should include sessionId for session counter', async () => {
    mockApiClient.name = 'getSessionIdCounter';
    handleApiService.mockResolvedValue({
      data: { data: { count: 20 } },
    });

    await getLimitCounter(
      'COP',
      mockApiClient,
      mockRes,
      mockReq,
      userId,
      sessionId
    );

    const setDownstreamParamsCall =
      handleApiService.mock.calls[0][0].setDownstreamParams;
    setDownstreamParamsCall({}, mockRes, mockReq, {});

    expect(setParamsForPaymentCounter).toHaveBeenCalledWith(
      {},
      mockRes,
      undefined,
      {},
      undefined,
      {
        name: 'COP',
        customerId: userId,
        sessionId,
      }
    );
  });

  it('should handle custom counter names', async () => {
    handleApiService.mockResolvedValue({
      data: { data: { count: 25 } },
    });

    const result = await getLimitCounter(
      'CUSTOM_COUNTER',
      mockApiClient,
      mockRes,
      mockReq,
      userId,
      sessionId
    );

    const setDownstreamParamsCall =
      handleApiService.mock.calls[0][0].setDownstreamParams;
    setDownstreamParamsCall({}, mockRes, mockReq, {});

    expect(setParamsForPaymentCounter).toHaveBeenCalledWith(
      {},
      mockRes,
      {},
      {},
      undefined,
      {
        name: 'CUSTOM_COUNTER',
        customerId: userId,
        sessionId,
      }
    );
    expect(result).toEqual({ count: 25 });
  });
});
