import {
  setParamsForArchiveBeneficiary,
  setParamsForPaymentCounter,
  setParamsForGetBeneficiary,
  setParamsForStatusUpdateBeneficiary,
} from './setParams';

// Mock the mv-apiutils module
jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  getHeader: jest.fn(),
}));

import { getHeader } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

describe('setParams', () => {
  let mockInputHeaders: any;
  let mockRes: any;
  let mockRequestBody: any;
  let mockAppConfig: any;
  let mockQuery: any;
  let mockPath: any;

  beforeEach(() => {
    mockInputHeaders = {
      Authorization: 'Bearer token123',
      'X-User-Id': 'user123',
    };

    mockRes = {
      locals: {
        brandSilo: 'test-brand-silo',
      },
    } as any;

    mockRequestBody = {
      testField: 'testValue',
    };

    mockAppConfig = {
      organisationId: 'default-org-id',
      apiUrl: 'https://api.example.com',
    };

    mockQuery = {
      limit: '10',
      offset: '0',
    };

    mockPath = {
      beneficiaryId: 'ben123',
      userId: 'user456',
    };

    // Reset all mocks
    jest.clearAllMocks();
  });

  describe('setParamsForArchiveBeneficiary', () => {
    it('should return correct parameters for archiving a beneficiary', () => {
      const result = setParamsForArchiveBeneficiary(
        mockInputHeaders,
        mockRes,
        mockRequestBody,
        mockAppConfig,
        mockQuery,
        mockPath
      );

      expect(result).toEqual({
        header: {
          ...mockInputHeaders,
          'Content-Type': 'application/merge-patch+json',
        },
        body: {
          status: 'ARCHIVED',
        },
        query: mockQuery,
        path: mockPath,
      });
    });

    it('should preserve existing headers while adding Content-Type', () => {
      const customHeaders = {
        Authorization: 'Bearer custom-token',
        'X-Custom-Header': 'custom-value',
      };

      const result = setParamsForArchiveBeneficiary(
        customHeaders,
        mockRes,
        mockRequestBody,
        mockAppConfig,
        mockQuery,
        mockPath
      );

      expect(result.header).toEqual({
        Authorization: 'Bearer custom-token',
        'X-Custom-Header': 'custom-value',
        'Content-Type': 'application/merge-patch+json',
      });
    });

    it('should override Content-Type if already present', () => {
      const headersWithContentType = {
        ...mockInputHeaders,
        'Content-Type': 'application/json',
      };

      const result = setParamsForArchiveBeneficiary(
        headersWithContentType,
        mockRes,
        mockRequestBody,
        mockAppConfig,
        mockQuery,
        mockPath
      );

      expect(result.header['Content-Type']).toBe(
        'application/merge-patch+json'
      );
    });

    it('should handle empty headers', () => {
      const result = setParamsForArchiveBeneficiary(
        {},
        mockRes,
        mockRequestBody,
        mockAppConfig,
        mockQuery,
        mockPath
      );

      expect(result.header).toEqual({
        'Content-Type': 'application/merge-patch+json',
      });
    });

    it('should always set status to ARCHIVED regardless of request body', () => {
      const customRequestBody = {
        status: 'ACTIVE',
        someOtherField: 'value',
      };

      const result = setParamsForArchiveBeneficiary(
        mockInputHeaders,
        mockRes,
        customRequestBody,
        mockAppConfig,
        mockQuery,
        mockPath
      );

      expect(result.body).toEqual({
        status: 'ARCHIVED',
      });
    });

    it('should handle null/undefined parameters gracefully', () => {
      const result = setParamsForArchiveBeneficiary(
        null as any,
        mockRes,
        null,
        mockAppConfig,
        undefined as any,
        null as any
      );

      expect(result).toEqual({
        header: {
          'Content-Type': 'application/merge-patch+json',
        },
        body: {
          status: 'ARCHIVED',
        },
        query: undefined,
        path: null,
      });
    });
  });

  describe('setParamsForPaymentCounter', () => {
    it('should return parameters as-is without modification', () => {
      const result = setParamsForPaymentCounter(
        mockInputHeaders,
        mockRes,
        mockRequestBody,
        mockAppConfig,
        mockQuery,
        mockPath
      );

      expect(result).toEqual({
        header: mockInputHeaders,
        query: mockQuery,
        path: mockPath,
        body: mockRequestBody,
      });
    });

    it('should preserve all input parameters exactly', () => {
      const customBody = {
        amount: 100,
        currency: 'USD',
        description: 'Test payment',
      };

      const customQuery = {
        type: 'instant',
        reference: 'ref123',
      };

      const customPath = {
        accountId: 'acc456',
        transactionId: 'txn789',
      };

      const result = setParamsForPaymentCounter(
        mockInputHeaders,
        mockRes,
        customBody,
        mockAppConfig,
        customQuery,
        customPath
      );

      expect(result.header).toBe(mockInputHeaders);
      expect(result.body).toBe(customBody);
      expect(result.query).toBe(customQuery);
      expect(result.path).toBe(customPath);
    });

    it('should handle empty/null parameters', () => {
      const result = setParamsForPaymentCounter(
        {},
        mockRes,
        null,
        mockAppConfig,
        undefined,
        {}
      );

      expect(result).toEqual({
        header: {},
        query: undefined,
        path: {},
        body: null,
      });
    });
  });

  describe('setParamsForGetBeneficiary', () => {
    const mockGetHeaderReturn = {
      Authorization: 'Bearer processed-token',
      'X-Processed-Header': 'processed-value',
    };

    beforeEach(() => {
      (getHeader as jest.Mock).mockReturnValue(mockGetHeaderReturn);
    });

    it('should return correct parameters with processed headers', () => {
      const result = setParamsForGetBeneficiary(
        mockInputHeaders,
        mockRes,
        mockRequestBody,
        mockAppConfig,
        mockQuery,
        mockPath
      );

      expect(result).toEqual({
        header: mockGetHeaderReturn,
        body: undefined,
        query: {
          brandSilo: 'test-brand-silo',
          ...mockQuery,
        },
        path: mockPath,
      });
    });

    it('should call getHeader with correct parameters', () => {
      setParamsForGetBeneficiary(
        mockInputHeaders,
        mockRes,
        mockRequestBody,
        mockAppConfig,
        mockQuery,
        mockPath
      );

      expect(getHeader).toHaveBeenCalledWith(
        mockInputHeaders,
        mockRes,
        mockAppConfig
      );
      expect(getHeader).toHaveBeenCalledTimes(1);
    });

    it('should use brandSilo from res.locals when available', () => {
      const result = setParamsForGetBeneficiary(
        mockInputHeaders,
        mockRes,
        mockRequestBody,
        mockAppConfig,
        mockQuery,
        mockPath
      );

      expect(result.query.brandSilo).toBe('test-brand-silo');
    });

    it('should fallback to appConfig.organisationId when brandSilo is not available', () => {
      const resWithoutBrandSilo = {
        locals: {},
      } as any;

      const result = setParamsForGetBeneficiary(
        mockInputHeaders,
        resWithoutBrandSilo,
        mockRequestBody,
        mockAppConfig,
        mockQuery,
        mockPath
      );

      expect(result.query.brandSilo).toBe('default-org-id');
    });

    it('should fallback to appConfig.organisationId when res.locals.brandSilo is null', () => {
      const resWithNullBrandSilo = {
        locals: {
          brandSilo: null,
        },
      } as any;

      const result = setParamsForGetBeneficiary(
        mockInputHeaders,
        resWithNullBrandSilo,
        mockRequestBody,
        mockAppConfig,
        mockQuery,
        mockPath
      );

      expect(result.query.brandSilo).toBe('default-org-id');
    });

    it('should merge query parameters correctly', () => {
      const customQuery = {
        filter: 'active',
        sort: 'name',
      };

      const result = setParamsForGetBeneficiary(
        mockInputHeaders,
        mockRes,
        mockRequestBody,
        mockAppConfig,
        customQuery,
        mockPath
      );

      expect(result.query).toEqual({
        brandSilo: 'test-brand-silo',
        filter: 'active',
        sort: 'name',
      });
    });

    it('should handle empty query parameters', () => {
      const result = setParamsForGetBeneficiary(
        mockInputHeaders,
        mockRes,
        mockRequestBody,
        mockAppConfig,
        {},
        mockPath
      );

      expect(result.query).toEqual({
        brandSilo: 'test-brand-silo',
      });
    });

    it('should handle null query parameters', () => {
      const result = setParamsForGetBeneficiary(
        mockInputHeaders,
        mockRes,
        mockRequestBody,
        mockAppConfig,
        null as any,
        mockPath
      );

      expect(result.query.brandSilo).toBe('test-brand-silo');
    });

    it('should always set body to undefined', () => {
      const result = setParamsForGetBeneficiary(
        mockInputHeaders,
        mockRes,
        { someData: 'test' },
        mockAppConfig,
        mockQuery,
        mockPath
      );

      expect(result.body).toBeUndefined();
    });

    it('should preserve path parameters unchanged', () => {
      const customPath = {
        beneficiaryId: 'ben789',
        accountId: 'acc123',
      };

      const result = setParamsForGetBeneficiary(
        mockInputHeaders,
        mockRes,
        mockRequestBody,
        mockAppConfig,
        mockQuery,
        customPath
      );

      // Check that the function preserves the custom path correctly
      expect(result).toHaveProperty('header');
      expect(result).toHaveProperty('body');
      expect(result).toHaveProperty('query');
      expect((result as any).path).toEqual(customPath);
    });

    it('should handle missing res.locals gracefully', () => {
      const resWithoutLocals = {} as any;

      // This test reveals that the function doesn't handle missing res.locals
      // The function would need to be updated to handle this case properly
      expect(() => {
        setParamsForGetBeneficiary(
          mockInputHeaders,
          resWithoutLocals,
          mockRequestBody,
          mockAppConfig,
          mockQuery,
          mockPath
        );
      }).toThrow('Cannot read properties of undefined');
    });
  });

  describe('setParamsForStatusUpdateBeneficiary', () => {
    it('should set merge-patch content type and preserve other headers', () => {
      const inputHeaders = {
        Authorization: 'Bearer token',
        'X-Custom': 'abc',
        'Content-Type': 'application/json',
      } as Record<string, string>;

      const res = {} as any;
      const appConfig = {} as any;
      const body = { status: 'ACTIVE', reason: 'user action' } as any;
      const query = { foo: 'bar' } as any;
      const path = { beneficiaryId: '123' } as any;

      const result = setParamsForStatusUpdateBeneficiary(
        inputHeaders,
        res,
        body,
        appConfig,
        query,
        path
      );

      expect(result.header.Authorization).toBe('Bearer token');
      expect(result.header['X-Custom']).toBe('abc');
      expect(result.header['Content-Type']).toBe(
        'application/merge-patch+json'
      );
    });

    it('should pass through body, query, and path unchanged', () => {
      const inputHeaders = {} as Record<string, string>;
      const res = {} as any;
      const appConfig = {} as any;
      const body = { status: 'SUSPENDED' } as any;
      const query = { a: 1, b: 2 } as any;
      const path = { id: 'xyz' } as any;

      const result = setParamsForStatusUpdateBeneficiary(
        inputHeaders,
        res,
        body,
        appConfig,
        query,
        path
      );

      expect(result.body).toEqual(body);
      expect(result.query).toEqual(query);
      expect(result.path).toEqual(path);
    });

    it('should handle empty headers by only setting Content-Type', () => {
      const result = setParamsForStatusUpdateBeneficiary(
        {},
        {} as any,
        { status: 'ACTIVE' },
        {} as any,
        {},
        {}
      );

      expect(result.header).toEqual({
        'Content-Type': 'application/merge-patch+json',
      });
    });
  });
});
