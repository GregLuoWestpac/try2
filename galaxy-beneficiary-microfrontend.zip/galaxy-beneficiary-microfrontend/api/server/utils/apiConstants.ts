export const PAYID_DAILY_LIMIT = 10;
export const COP_SESSION_LIMIT = 20;
export const COP_DAILY_LIMIT = 50;

// matchedStatus codes that require both session and daily counter increment
export const MATCHED_STATUS_SESSION_AND_DAILY = new Set([
  'V1C3',
  'V1C4',
  'V2C3',
  'V2C4',
  'VAC3',
  'VTC3',
  'VEC3',
  'VAC4',
  'VTC4',
  'VEC4',
]);

export const LIMIT_EXCEEEDED_ERROR = {
  result: {
    errors: [
      {
        code: 2000,
        message: 'PayID limit exceeded',
        details:
          'PayID verification cannot be completed. Please try again later.',
      },
    ],
  },
};

export const COP_LIMIT_EXCEEDED_ERROR = {
  result: {
    errors: [
      {
        code: 3000,
        message: 'CoP limit exceeded',
        details: 'We could not confirm the account name match.',
      },
    ],
  },
};

export enum PAYID_TYPE {
  PHONE = 'TELI',
  EMAIL = 'EMAL',
  ABN_ACN = 'AUBN',
  ORGANISATION_ID = 'ORGN',
}

export enum BENEFICIARY_STATUS {
  ACTIVE = 'ACTIVE',
  ARCHIVED = 'ARCHIVED',
  PENDING_AUTHORISATION = 'PENDING_AUTHORISATION',
}
export enum BENEFICIARY_TYPE {
  ACCOUNT = 'BSB_ACCOUNT_NUMBER',
  PAYID = 'PAYID',
}

export const BENEFICIARY_REQUEST_ACTION = 'CREATE_BENEFICIARY';
