const { errorHandler } = require('./errorHandler');

describe('errorHandler', () => {
  it('should return expected value for 400', () => {
    expect(errorHandler(400)).toStrictEqual({ errorMessage: 'Bad Request' });
  });
  it('should return expected value for 404', () => {
    expect(errorHandler(404)).toStrictEqual({
      errorMessage: 'Requested resource not found',
    });
  });
  it('should return expected value for 403', () => {
    expect(errorHandler(403)).toStrictEqual({
      errorMessage: 'Forbidden access',
      errorCode: 403,
    });
  });
  it('should return expected value for 500', () => {
    expect(errorHandler(500)).toStrictEqual({
      errorMessage: 'Internal server error',
    });
  });
  it('should return default value', () => {
    expect(errorHandler(405)).toStrictEqual({
      errorMessage: 'Internal server error',
    });
  });
});