/* eslint-disable @typescript-eslint/no-explicit-any */
import { Response } from 'express';
import { RUNTIME } from '@mep-node/framework-constants';
import { jwtDecode } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import {
  decodeAccessToken,
  DecodedToken,
  TokenDecodeError,
} from './tokenDecoder';

jest.mock('@mep-node/framework-constants', () => ({
  RUNTIME: {
    isLocal: jest.fn(),
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  jwtDecode: jest.fn(),
}));

describe('tokenDecoder', () => {
  let mockRes: Partial<Response>;

  beforeEach(() => {
    jest.clearAllMocks();

    mockRes = {
      locals: {
        apiHeaders: {
          'x-access-token': 'valid-jwt-token',
        },
      },
    } as any;
  });

  describe('decodeAccessToken', () => {
    it('should return mock token in local environment', () => {
      (RUNTIME.isLocal as jest.Mock).mockReturnValue(true);

      const result = decodeAccessToken(mockRes as Response);

      expect(result).toEqual({
        userId: 'sampleUserId',
        sessionIndex: 'sampleSessionId',
      });
      expect(jwtDecode).not.toHaveBeenCalled();
    });

    it('should decode JWT token successfully in non-local environment', () => {
      (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
      const mockDecodedToken: DecodedToken = {
        userId: 'user123',
        userIdScheme: 'CustomerInternalId',
        sessionIndex: 'session456',
      };
      (jwtDecode as jest.Mock).mockReturnValue(mockDecodedToken);

      const result = decodeAccessToken(mockRes as Response);

      expect(result).toEqual(mockDecodedToken);
      expect(jwtDecode).toHaveBeenCalledWith('valid-jwt-token');
      expect(mockRes.locals.apiHeaders['x-userIdScheme']).toBe(
        'CustomerInternalId'
      );
    });

    it('should throw TokenDecodeError when userId is missing', () => {
      (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
      const tokenWithoutUserId = {
        userIdScheme: 'CustomerInternalId',
        sessionIndex: 'session456',
      };
      (jwtDecode as jest.Mock).mockReturnValue(tokenWithoutUserId);

      expect(() => decodeAccessToken(mockRes as Response)).toThrow(
        TokenDecodeError
      );
      expect(() => decodeAccessToken(mockRes as Response)).toThrow(
        'userId not found in token'
      );
    });

    it('should throw error when JWT decode fails', () => {
      (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
      const decodeError = new Error('Invalid token');
      (jwtDecode as jest.Mock).mockImplementation(() => {
        throw decodeError;
      });

      expect(() => decodeAccessToken(mockRes as Response)).toThrow();
    });

    it('should throw error when x-access-token header is missing', () => {
      (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
      mockRes.locals.apiHeaders['x-access-token'] = undefined;
      (jwtDecode as jest.Mock).mockImplementation(() => {
        throw new Error('No token provided');
      });

      expect(() => decodeAccessToken(mockRes as Response)).toThrow();
    });

    it('should throw error for malformed JWT token', () => {
      (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
      mockRes.locals.apiHeaders['x-access-token'] = 'malformed.token.here';
      (jwtDecode as jest.Mock).mockImplementation(() => {
        throw new Error('Malformed token');
      });

      expect(() => decodeAccessToken(mockRes as Response)).toThrow();
    });

    it('should throw error for expired JWT token', () => {
      (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);
      (jwtDecode as jest.Mock).mockImplementation(() => {
        throw new Error('Token expired');
      });

      expect(() => decodeAccessToken(mockRes as Response)).toThrow();
    });
  });
});
