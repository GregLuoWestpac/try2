const { readMeshSecrets } = require('./secretsUtil');
/* eslint-disable security/detect-non-literal-fs-filename */
/* eslint-disable node/no-extraneous-require */
const fs = require('fs');
jest.mock('fs');

afterEach(() => {
  jest.clearAllMocks();
});

describe('readMeshSecrets', () => {
  // test case should return decryptedFileContent if secrets directory exists
  it('should return decryptedFileContent if secrets directory exists', () => {
    const logger = {
      info: jest.fn(),
    };
    const decryptedFileContent = {
      pdpClientToken: 'test-token',
      org: 'test-org',
    };
    fs.existsSync.mockReturnValue(true);
    fs.readFileSync.mockReturnValue(JSON.stringify(decryptedFileContent));

    const result = readMeshSecrets(logger);

    expect(result).toEqual(decryptedFileContent);

    expect(logger.info).toHaveBeenCalledWith(
      'readMeshSecrets - decryptedFileContent found'
    );
  });

  //below test case added by github copilot for increasing coverage

  //  test case should return null if secrets directory does not exist
  it('should return null if secrets directory does not exist', () => {
    const logger = {
      info: jest.fn(),
    };

    fs.existsSync.mockReturnValue(false);

    const result = readMeshSecrets(logger);
    expect(result).toBeNull();
    expect(logger.info).toHaveBeenCalledWith(
      'readMeshSecrets - diagnosticsOutputMessage -',
      'Cannot find the directory: /secrets'
    );
  });

  // test case should handle logger being undefined
  it('should work without logger when secrets directory exists', () => {
    const decryptedFileContent = {
      pdpClientToken: 'test-token',
      org: 'test-org',
    };
    fs.existsSync.mockReturnValue(true);
    fs.readFileSync.mockReturnValue(JSON.stringify(decryptedFileContent));

    const result = readMeshSecrets(); // no logger passed

    expect(result).toEqual(decryptedFileContent);
  });

  // test case should handle logger being undefined when directory doesn't exist
  it('should work without logger when secrets directory does not exist', () => {
    fs.existsSync.mockReturnValue(false);

    const result = readMeshSecrets(); // no logger passed

    expect(result).toBeNull();
  });

  // test case should handle invalid JSON in secrets file
  it('should throw error when secrets file contains invalid JSON', () => {
    const logger = {
      info: jest.fn(),
    };
    fs.existsSync.mockReturnValue(true);
    fs.readFileSync.mockReturnValue('invalid json content');

    expect(() => {
      readMeshSecrets(logger);
    }).toThrow();

    expect(logger.info).toHaveBeenCalledWith(
      'readMeshSecrets - decryptedFileContent found'
    );
  });
});
