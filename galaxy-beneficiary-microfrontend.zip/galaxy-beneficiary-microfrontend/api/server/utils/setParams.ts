import {
  SetDownstreamParams,
  SetDownstreamParamsWithPath,
  getHeader,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

const setParamsForArchiveBeneficiary: SetDownstreamParamsWithPath = (
  inputHeaders,
  res,
  requestBody,
  appConfig,
  query,
  path
) => {
  const body = {
    status: 'ARCHIVED',
  };

  return {
    header: {
      ...inputHeaders,
      'Content-Type': 'application/merge-patch+json',
    },
    body,
    query,
    path,
  };
};

const setParamsForPaymentCounter: SetDownstreamParamsWithPath = (
  inputHeaders,
  res,
  body,
  appConfig,
  query,
  path
) => {
  return {
    header: inputHeaders,
    query,
    path,
    body,
  };
};
export { setParamsForArchiveBeneficiary, setParamsForPaymentCounter };

export const setParamsForGetBeneficiary: SetDownstreamParams = (
  apiHeaders,
  res,
  requestBody,
  appConfig,
  queryParams,
  pathParams
) => {
  return {
    header: getHeader(apiHeaders, res, appConfig),
    body: undefined,
    query: {
      brandSilo: res.locals.brandSilo || appConfig.organisationId,
      ...queryParams,
    },
    path: pathParams,
  };
};

export const setParamsForStatusUpdateBeneficiary: SetDownstreamParamsWithPath =
  (inputHeaders, res, body, appConfig, query, path) => {
    return {
      header: {
        ...inputHeaders,
        'Content-Type': 'application/merge-patch+json',
      },
      body,
      query,
      path,
    };
  };

export const setParamsForAccountNameCheck: SetDownstreamParamsWithPath = (
  inputHeaders,
  res,
  body,
  appConfig,
  query,
  path
) => {
  return {
    header: {
      ...inputHeaders,
      'Content-Type': 'application/json',
    },
    body,
    query,
    path,
  };
};
