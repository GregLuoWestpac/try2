import {
  InvalidTokenError,
  JwtHeader,
  RoleBaseJwtModel,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

// Custom interface for token validation middleware
export interface TokenValidationPayload {
  resource_uri?: string;
  userId?: string;
  sub?: string;
  exp?: number;
  [key: string]: any; // Allow other claims
}

export function jwtDecode<T = JwtHeader | RoleBaseJwtModel>(
  token: string
): T | null {
  if (typeof token != 'string') {
    throw new InvalidTokenError('Invalid token specified: must be a string');
  }
  try {
    const parts = token.split('.');
    if (parts.length != 3) {
      throw new Error('Invalid JWT format');
    }
    const payload = parts[1];
    const decodedPayload = atob(payload.replace(/-/g, '+').replace(/_/g, '/'));
    if (!decodedPayload) {
      throw new Error('Invalid JWT format');
    }
    return JSON.parse(decodedPayload) as T;
  } catch (error) {
    console.error('Failed to decode JWT:', error.message);
    return null;
  }
}
