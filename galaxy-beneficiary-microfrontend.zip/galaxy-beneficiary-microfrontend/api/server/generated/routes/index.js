const createBeneficiariesRoute = require('./createBeneficiariesRoute');
const retrieveBeneficiariesRoute = require('./retrieveBeneficiariesRoute');
const updateBeneficiaryRoute = require('./updateBeneficiaryRoute');
const retrieveBeneficiaryRoute = require('./retrieveBeneficiaryRoute');
const archiveBeneficiariesRoute = require('./archiveBeneficiariesRoute');
const updateBeneficiaryStatusRoute = require('./updateBeneficiaryStatusRoute');
const postAliasLookupRoute = require('./postAliasLookupRoute');
const getBsbLookupRoute = require('./getBsbLookupRoute');
const getDivisionListRoute = require('./getDivisionListRoute');
const postAccountNameCheckRoute = require('./postAccountNameCheckRoute');
const getHealthCheckStatusRoute = require('./getHealthCheckStatusRoute');

module.exports = {
  createBeneficiariesRoute,
  retrieveBeneficiariesRoute,
  updateBeneficiaryRoute,
  retrieveBeneficiaryRoute,
  archiveBeneficiariesRoute,
  updateBeneficiaryStatusRoute,
  postAliasLookupRoute,
  getBsbLookupRoute,
  getDivisionListRoute,
  postAccountNameCheckRoute,
  getHealthCheckStatusRoute,
};
