const path = require('path');

const get = require('lodash/get');
const some = require('lodash/some');
const keys = require('lodash/keys');
const every = require('lodash/every');
const entries = require('lodash/entries');
const isEmpty = require('lodash/isEmpty');
const mergeWith = require('lodash/mergeWith');
const intersection = require('lodash/intersection');

const cwd = process.cwd();

const MATCHES = {
  ALL: every,
  ANY: some,
};

const throwEx = (type, message) => {
  throw { type, message }; // eslint-disable-line no-throw-literal
};

// eslint-disable-next-line consistent-return
const isAllowsPermitForRole = (allows, userRoles) => {
  if (Array.isArray(allows)) {
    const isWildcardMatch = allows.includes('*');

    const roleIntersect = intersection(allows, userRoles);
    const isIntersectMatch = !!roleIntersect.length;

    const shouldAllow = isWildcardMatch || isIntersectMatch;

    const assumedRoles =
      (!isWildcardMatch && isIntersectMatch && roleIntersect) ||
      (isWildcardMatch && ['*']);

    const permission = Object.assign(
      {},
      { allow: shouldAllow },
      assumedRoles && { assumedRoles }
    );

    return permission;
  }

  throwEx('System', 'Allows does not exist or is not an array');
};

const isSettingExistAndRoleInAllows = (obj, setting) =>
  !isEmpty(get(obj, `${setting}`));

const getValueByDottedString = (obj = {}, dotStr = '') => {
  if (dotStr.indexOf('.') >= 0) {
    const reducer = (accumulator, currentValue) =>
      accumulator[currentValue] ? accumulator[currentValue] : {};
    const result = dotStr.split('.').reduce(reducer, obj);

    return isEmpty(result) ? undefined : result;
  }

  return obj[dotStr];
};

const compareBodyParamKeys = (policyParam, params, matches) => {
  const result = matches(entries(policyParam), ([key, value]) => {
    const paramValue = getValueByDottedString(params, key);
    const shouldAllow = paramValue && value.includes(paramValue);

    return shouldAllow;
  });

  return result;
};

const compareParamKeys = (policyParam, params, matches) => {
  const result = matches(entries(policyParam), ([key, value]) => {
    const paramValue = params[key];
    const shouldAllow = isEmpty(value) || value.includes(paramValue);

    return shouldAllow;
  });

  return result;
};

const compareFineGrainPolicy = (policy, params, matches) => {
  if (isEmpty(policy)) {
    return true;
  }

  // eslint-disable-next-line consistent-return
  const result = matches(entries(policy), ([key, value]) => {
    const param = params[key];
    switch (key) {
      case 'header':
      case 'path':
      case 'query': {
        const match = compareParamKeys(value, param, matches);
        return match;
      }

      case 'body': {
        const match = compareBodyParamKeys(value, param, matches);
        return match;
      }

      default:
        throwEx('System', `${key} not supported`);
        break;
    }
  });

  return result;
};

const isMatchFineGrainPolicy = (config, params) => {
  if (!config) {
    return false;
  }

  const { all, any } = config;

  if (!all && !any) {
    return false;
  }

  const resultAll = !all || compareFineGrainPolicy(all, params, MATCHES.ALL);
  const resultAny = !any || compareFineGrainPolicy(any, params, MATCHES.ANY);

  return resultAll && resultAny;
};

const hasPermission = (
  apiPath,
  apiMethod,
  params,
  userRoles,
  entitlementObj = null
) => {
  const policyPath = path.join(cwd, './northEdge.entitlements.json');

  // eslint-disable-next-line global-require, import/no-dynamic-require
  const policy = !entitlementObj ? require(policyPath) : entitlementObj;

  if (policy === null) {
    throwEx('System', `Policy file not found -> ${policyPath}`);
  }

  if (!isEmpty(policy.allows)) {
    const permission = isAllowsPermitForRole(policy.allows, userRoles);
    if (permission.allow) {
      return permission;
    }
  }

  if (isSettingExistAndRoleInAllows(policy, apiPath)) {
    const { allows } = policy[apiPath];

    if (!isEmpty(allows)) {
      const permission = isAllowsPermitForRole(allows, userRoles);
      if (permission.allow) {
        return permission;
      }
    }
  }

  const pathObj = policy[apiPath];
  if (isSettingExistAndRoleInAllows(pathObj, apiMethod)) {
    const { allows } = pathObj[apiMethod];

    if (!isEmpty(allows)) {
      const permission = isAllowsPermitForRole(allows, userRoles);
      if (permission.allow) {
        return permission;
      }
    }
  }

  const methodObj = pathObj[apiMethod];
  const { matches } = methodObj;
  const userRolesMatch = matches && intersection(keys(matches), userRoles);

  if (!isEmpty(userRolesMatch)) {
    for (let idx = 0; idx < userRolesMatch.length; idx++) {
      const role = userRolesMatch[idx];
      const policyMatchConfigForRole = matches[role];
      const policyMachForRole = isMatchFineGrainPolicy(
        policyMatchConfigForRole,
        params
      );

      if (policyMachForRole) {
        const permission = {
          allow: policyMachForRole,
          assumedRoles: [role],
        };

        return permission;
      }
    }

    return { allow: false };
  }

  return { allow: false };
};

module.exports = { hasPermission };
