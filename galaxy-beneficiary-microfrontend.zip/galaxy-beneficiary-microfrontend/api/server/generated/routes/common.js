const entitlement = require('./entitlement');

/**
 * Function to return entitlement middleware
 * Base on input originPath and method, it will create and return a middleware with entitlement check embedded
 * @param {string} originPath
 * @param {string} method
 * @returns {function} ExpressJS middleware function with entitlement check
 */
const getEntitlementMiddleWare =
  (operationId, originPath, method) => (req, res, next) => {
    const { logger, USER_ROLES } = (res && res.locals) || {};

    /**
     * [WDPUI-1714](https://jira.srv.westpac.com.au/browse/WDPUI-1714)
     *
     * Interpret the `role` claim as an array or string
     * but always return an array
     */
    const roles = USER_ROLES;

    const errors = [];

    if (!logger) {
      const error = {
        code: 10000,
        message: 'Internal Server Error',
        details: 'Please check application logs for details',
      };

      errors.push(error);

      logger.error(
        'Logging instance not found. Make sure the logger middleware is instantiated.'
      );

      res.status(500).json({ result: { errors } }).end();

      return;
    }

    const params = {
      header: req.headers,
      query: req.query,
      body: req.body,
      path: req.params,
    };

    try {
      logger.trace({
        payload: {
          operationId,
          originPath,
          method,
          message: `Evaluating entitlements for '${roles}'`,
        },
      });

      const { allow, assumedRoles } = entitlement.hasPermission(
        originPath,
        method,
        params,
        roles
      );

      if (!allow) {
        const error = {
          code: 10001,
          message: 'Site access denied.',
          details: 'You have not been provisioned to access this application.',
        };

        errors.push(error);

        logger.error(
          `${roles} are not permitted to call ${operationId} on ${originPath}`
        );

        res.status(403).json({ result: { errors } }).end();

        return;
      }

      logger.trace(
        `North-edge entitlement check passed for ${operationId} on ${originPath} with assumed roles ${assumedRoles}`
      );

      res.locals.assumedRolesOnNorthEdge = assumedRoles;
      res.locals.wdpPassEntitlement = true;
      res.locals.wdpOperationId = operationId;

      next();
    } catch ({ type, message }) {
      const error = {
        code: 10002,
        message: 'Site access denied.',
        details: 'We are unable to verify your access provisions at this time.',
      };

      errors.push(error);

      logger.error({
        payload: {
          operationId,
          originPath,
          method,
          message:
            'Entitlement policy not configured correctly for the application',
          details: `${type && `${type.toUpperCase()}:`} => ${message}`,
        },
      });

      res.status(403).json({ result: { errors } }).end();

      return; // eslint-disable-line no-useless-return
    }
  };

const getRouteLoggerMiddleware =
  (operationId, originPath, method) => (req, res, next) => {
    const { logger } = (res && res.locals) || {};
    logger.trace({
      payload: {
        operationId,
        originPath,
        httpMethod: method,
        message: `beneficiary.${operationId}.Start`,
      },
    });
    next();
  };

const getHaltOnTimedOutMiddleware =
  (resource, timeoutIn) => (req, res, next) => {
    const { logger } = (res && res.locals) || {};
    logger.trace(
      `Setting the request timeout for ${resource} to ${timeoutIn} ms`
    );

    const { locals } = res;
    const abortController = new AbortController();
    req.abortController = abortController;
    res.locals = {
      ...locals,
      timeoutIn,
      signal: abortController.signal,
      abortController,
    };

    if (!req.timedout) {
      next();
    } else {
      throw new Error(`408: Request Timeout`);
    }
  };

/**
 * Middleware to handle request timeouts by aborting ongoing operations
 * using the AbortController signal stored in res.locals.signal.
 */
const getAbortOnTimeoutMiddleware =
  (path, timeoutIn) => (err, req, res, next) => {
    if (req.timedout) {
      if (res.locals.signal && !res.locals.signal.aborted) {
        res.locals.abortController.abort();
        console.warn(
          `Request timed out and aborted for path: ${path}, timeout: ${timeoutIn}ms`
        );
      }
    } else {
      next(err);
    }
  };

module.exports = {
  getEntitlementMiddleWare,
  getRouteLoggerMiddleware,
  getHaltOnTimedOutMiddleware,
  getAbortOnTimeoutMiddleware,
};
