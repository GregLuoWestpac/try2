const beneficiaryManagementV1Services = require('./beneficiaryManagementV1Services');
const infBnkngChnlBrchntwkV2Services = require('./infBnkngChnlBrchntwkV2Services');
const paymentAliasResolutionV2Services = require('./paymentAliasResolutionV2Services');
const channelPaymentUtilsV1Services = require('./channelPaymentUtilsV1Services');
const capCustsvcmgtCustsecyverifctnAdaptvauthV2Services = require('./capCustsvcmgtCustsecyverifctnAdaptvauthV2Services');
const payeeServicesV1Services = require('./payeeServicesV1Services');
const userAuthorisationPolicyDecisionEngineApiV1Services = require('./userAuthorisationPolicyDecisionEngineApiV1Services');

module.exports = {
  beneficiaryManagementV1Services,
  infBnkngChnlBrchntwkV2Services,
  paymentAliasResolutionV2Services,
  channelPaymentUtilsV1Services,
  capCustsvcmgtCustsecyverifctnAdaptvauthV2Services,
  payeeServicesV1Services,
  userAuthorisationPolicyDecisionEngineApiV1Services,
};
