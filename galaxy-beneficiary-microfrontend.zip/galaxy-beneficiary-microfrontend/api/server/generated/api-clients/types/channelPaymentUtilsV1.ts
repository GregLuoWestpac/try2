/* eslint-disable */
/* tslint:disable */
/*
 * ---------------------------------------------------------------
 * ## THIS FILE WAS GENERATED VIA SWAGGER-TYPESCRIPT-API        ##
 * ##                                                           ##
 * ## AUTHOR: acacode                                           ##
 * ## SOURCE: https://github.com/acacode/swagger-typescript-api ##
 * ---------------------------------------------------------------
 */

/**
 * Name of the counter
 * @minLength 1
 * @maxLength 50
 * @pattern ^[a-zA-Z0-9-_]+$
 * @example "PAYID"
 */
export type Name = string;

/**
 * CISKey of the customer. Basically the customer internal id.
 * @minLength 1
 * @maxLength 15
 * @pattern ^[A-Za-z0-9]+$
 * @example "Cust123456"
 */
export type CustomerId = string;

/**
 * session id for the customer session
 * @format uuid
 * @pattern ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$
 * @example "550e8400-e29b-41d4-a716-446655440000"
 */
export type SessionId = string;

/** @example {"names":["PAYID","WPAC"]} */
export interface ResetRequest {
  /**
   * @minItems 1
   * @uniqueItems true
   */
  names: Name[];
}

export interface CounterResponse {
  /** @example "PAYID" */
  name: string;
  /** @example "123456" */
  customerId: string;
  /** @example 2 */
  counter: number;
}

export type SessionCounterResponse = CounterResponse & {
  session: {
    /**
     * @format uuid
     * @example "550e8400-e29b-41d4-a716-446655440000"
     */
    id?: string;
    /** @example 1 */
    counter?: number;
  };
};

/** Success response for payment limit */
export interface PaymentLimitResponse {
  counters?: CounterResponse[];
}

/** Success response for session limit */
export interface SessionLimitResponse {
  counters?: SessionCounterResponse[];
}

/** Success response for get payment count */
export interface GetPaymentCounterResponse {
  counters?: CounterResponse[];
}

/** Success response for get session count */
export interface GetSessionCounterResponse {
  counters?: SessionCounterResponse[];
}

export namespace Payment {
  /**
   * @description Get payment counter for a specific customerId
   * @tags getPayIdLimit
   * @name GetPaymentCounter
   * @summary Get payment counter
   * @request GET:/payment/counters/{name}/customers/{customerId}
   * @secure
   */
  export namespace GetPaymentCounter {
    export type RequestParams = {
      /** CISKey of the customer. Basically the customer internal id. */
      customerId: CustomerId;
      /** Name of the counter */
      name: Name;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = {
      /** Success response for get payment count */
      data?: GetPaymentCounterResponse;
    };
  }
  /**
   * @description increment payment limit counter
   * @tags incrementPayIdLimit
   * @name IncrementPaymentCounter
   * @summary Increment payment limit counter
   * @request POST:/payment/counters/{name}/customers/{customerId}
   * @secure
   */
  export namespace IncrementPaymentCounter {
    export type RequestParams = {
      /** CISKey of the customer. Basically the customer internal id. */
      customerId: CustomerId;
      /** Name of the counter */
      name: Name;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = {
      /** Success response for payment limit */
      data?: PaymentLimitResponse;
    };
  }
  /**
   * @description reset payment counter
   * @tags resetPayIdLimit
   * @name ResetPaymentCounter
   * @summary Reset payment counter
   * @request POST:/payment/counters/do/reset
   * @secure
   */
  export namespace ResetPaymentCounter {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ResetRequest;
    export type RequestHeaders = {};
    export type ResponseBody = void;
  }
  /**
   * @description increment session id counter
   * @tags incrementSessionIdLimit
   * @name IncrementSessionIdCounter
   * @summary Increment session id counter
   * @request POST:/payment/counters/{name}/customers/{customerId}/sessions/{sessionId}
   * @secure
   */
  export namespace IncrementSessionIdCounter {
    export type RequestParams = {
      /** CISKey of the customer. Basically the customer internal id. */
      customerId: CustomerId;
      /** Name of the counter */
      name: Name;
      /** session id for the customer session */
      sessionId: SessionId;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = {
      /** Success response for session limit */
      data?: SessionLimitResponse;
    };
  }
  /**
   * @description get session id counter
   * @tags getSessionIdLimit
   * @name GetSessionIdCounter
   * @summary Get session id counter
   * @request GET:/payment/counters/{name}/customers/{customerId}/sessions/{sessionId}
   * @secure
   */
  export namespace GetSessionIdCounter {
    export type RequestParams = {
      /** CISKey of the customer. Basically the customer internal id. */
      customerId: CustomerId;
      /** Name of the counter */
      name: Name;
      /** session id for the customer session */
      sessionId: SessionId;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = {
      /** Success response for get session count */
      data?: GetSessionCounterResponse;
    };
  }
}
