/* eslint-disable */
/* tslint:disable */
/*
 * ---------------------------------------------------------------
 * ## THIS FILE WAS GENERATED VIA SWAGGER-TYPESCRIPT-API        ##
 * ##                                                           ##
 * ## AUTHOR: acacode                                           ##
 * ## SOURCE: https://github.com/acacode/swagger-typescript-api ##
 * ---------------------------------------------------------------
 */

/** healthcheck status */
export interface HealthCheckStatus {
  status?: "success";
}

/** The details of the colocation branch and its individual branches. */
export interface ColocationBranch {
  /**
   * Unique identifier to find colocation details
   * @pattern ^[a-zA-Z0-9-_]{1,5}$
   * @example 123
   */
  colocationId?: string;
  /**
   * Colocation types; allowed values are DUAL,BIAB,SINGLE,DESTINATION (eg.DUAL)
   * @example "DUAL"
   */
  branchColocationType?: "DUAL" | "BIAB" | "SINGLE" | "DESTINATION";
  /** Single cash queue available-Yes or No */
  hasSCQ?: boolean;
  /**
   * Date of last update of colocation table.
   * @format date
   */
  lastUpdatedDate?: string;
  /**
   * @maxItems 2
   * @minItems 2
   */
  colocationBranches?: ColocationBranchDetail[];
}

/** Details of the branch for a given colocation id. */
export interface ColocationBranchDetail {
  /**
   * Westpac or other partners of Westpac group
   * @pattern ^[a-zA-Z0-9-_]{1,5}$
   * @example "WBC"
   */
  bankType?: string;
  /**
   * Value of branch ID
   * @example 192879
   */
  branchId?: string;
  /**
   * Role of branch in colocation; Host(H) or Partner(P)
   * @example "Host"
   */
  bankRole?: "Host" | "Partner";
  /**
   * This is the virtual cash drawer ID in Spider application for SCQ branches
   * @pattern ^[a-zA-Z0-9-_]{1,3}$
   */
  bankCashDrawer?: string;
}

export interface GetResponseColocationBranches {
  /** The details of the colocation branch and its individual branches. */
  data?: ColocationBranch;
}

export interface BranchResponse {
  data?: Branches;
}

export interface Branches {
  /** BranchData */
  branches?: BranchData;
}

/** BranchData */
export type BranchData = Branch[];

export interface Branch {
  /** Branch ID */
  branchId?: string;
  /** BSB */
  BSB?: string;
  /** Branch Name */
  branchName?: string;
  /** Bank Identification Code (eg. 03) */
  bankCode?: string;
  /** A set of available predefined values representing the label names used by Westpac for its products and services. (eg. WBC) */
  brand?: "WBC" | "SGB" | "BOM" | "BSA";
  /** Branch Status */
  branchStatus?: "OPERATIONAL" | "CLOSED";
  /**
   * Branch Available indicate if the BSB is valid for origination
   * @default false
   */
  branchAvailable?: boolean;
  /**
   * Bank Name
   * @example "Westpac"
   */
  bankName?: string;
  /**
   * true or false, indicates that the branch supports Direct Entry (DE) Payment Type
   * @default false
   */
  isDirectEntrySupported?: boolean;
  /**
   * true or false, indicates that the branch supports Real Time Gross Settlement (RTGS) Payment Type
   * @default false
   */
  isRTGSSupported?: boolean;
  address?: Address;
}

export interface Address {
  /** addressLine1 */
  addressLine1?: string;
  /** addressLine2 */
  addressLine2?: string;
  /** city */
  city?: string;
  /** state */
  state?: string;
  /** postCode */
  postCode?: string;
}

/** Represents an individual error */
export interface Error {
  /**
   * Error Code
   * @format int32
   */
  code?: number;
  /** Error Message */
  message?: string;
  /** Comma separated list of fields, which caused the error condition */
  details?: string;
}

export namespace Branches {
  /**
   * @description Retrieves the colocation branch data for given BranchId
   * @tags ColocationBranchReferenceData
   * @name GetColocationBranchData
   * @request GET:/branches/colocations
   * @secure
   */
  export namespace GetColocationBranchData {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Represents the branch Id for which the reference data is to be retrieved. Ex. 501226 */
      branchId: string;
    };
    export type RequestBody = never;
    export type RequestHeaders = {
      /** Globally unique message identifier  - GUID. This uniquely identifies this call. */
      "x-messageId": string;
      /** Consumer generated message identifier for correlation purposes. e.g. Can be used to group together a number of API calls comprising a business transaction. */
      "x-appCorrelationId": string;
      /** The organisation the caller is operating in. */
      "x-organisationId": "WPAC" | "SGB" | "BSA" | "BOM" | "BTPL" | "UBS" | "VIRG";
      /** System Id of Application e.g. MA-005 */
      "x-originatingSystemId": string;
      /** The originating consumption channel invoking the API (eg. Partner, Staff, Customer). Note that an API consuming another API should pass the value supplied by the calling application. Further information regarding this header can be found at https://confluence.srv.westpac.com.au/x/cbH-B. */
      "x-consumerType": "Partner" | "Public" | "Staff" | "Customer" | "Prospect" | "Other";
    };
    export type ResponseBody = GetResponseColocationBranches;
  }
  /**
   * @description Retrieves the branch reference data for given BSB / BranchId
   * @tags BranchReferenceData
   * @name GetBranchReferenceData
   * @request GET:/branches
   * @secure
   */
  export namespace GetBranchReferenceData {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Represents the BSB for which the reference data is to be retrieved. Ex. 012010 */
      BSB?: string;
      /** Represents the branch Id for which the reference data is to be retrieved. Ex. 501226 */
      branchId?: string;
      /**
       * Represents the postal code range for which the reference data is to be retrieved. Ex. btn:2015,2020
       * @pattern ^btn:(\d*?),(\d*?)$
       */
      postalCodeRange?: string;
      /** A set of available predefined values representing the label names used by Westpac for its products and services. */
      brand?: "WBC" | "SGB" | "BOM" | "BSA";
    };
    export type RequestBody = never;
    export type RequestHeaders = {
      /** Globally unique message identifier  - GUID. This uniquely identifies this call. */
      "x-messageId": string;
      /** Consumer generated message identifier for correlation purposes. e.g. Can be used to group together a number of API calls comprising a business transaction. */
      "x-appCorrelationId": string;
      /** The organisation the caller is operating in. */
      "x-organisationId": "WPAC" | "SGB" | "BSA" | "BOM" | "BTPL" | "UBS" | "VIRG";
      /** System Id of Application e.g. MA-005 */
      "x-originatingSystemId": string;
      /** The originating consumption channel invoking the API (eg. Partner, Staff, Customer). Note that an API consuming another API should pass the value supplied by the calling application. Further information regarding this header can be found at https://confluence.srv.westpac.com.au/x/cbH-B. */
      "x-consumerType": "Partner" | "Public" | "Staff" | "Customer" | "Prospect" | "Other";
    };
    export type ResponseBody = BranchResponse;
  }
}
