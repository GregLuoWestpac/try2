/* eslint-disable */
/* tslint:disable */
/*
 * ---------------------------------------------------------------
 * ## THIS FILE WAS GENERATED VIA SWAGGER-TYPESCRIPT-API        ##
 * ##                                                           ##
 * ## AUTHOR: acacode                                           ##
 * ## SOURCE: https://github.com/acacode/swagger-typescript-api ##
 * ---------------------------------------------------------------
 */

/**
 * Type of Customer
 * <table><tr><th><u>Possible Customer Types<u></th></tr><tr><td>Individual</td></tr><tr><td>Organisation</td></tr></table>
 */
export enum CustomerType {
  Individual = 'Individual',
  Organisation = 'Organisation',
}

/**
 * OptOutReason
 * Detailed reason for chosing Opt-Out for Confirmation-of-Payee-Services by Customer. It will only populate, if customer choosing Opt-Out
 */
export interface OptOutReason {
  /** Standard value which uniquely identifies Opt-Out reasons */
  code: 'COP001001' | 'COP001002';
  /**
   * <br> Description
   * <table>
   *   <tr>
   *     <td>ENUM Code</td>
   *     <td>Description</td>
   *   </tr>
   *   <tr>
   *     <td>COP001001</td>
   *     <td>CoP opt-out as I am concerned about my name being shared.</td>
   *   </tr>
   *   <tr>
   *     <td>COP001002</td>
   *     <td>CoP opt-out but prefer not to say.</td>
   *   </tr>
   * </table>
   * @format string
   * @example "CoP opt-out as I am concerned about my name being shared"
   */
  description?: string;
}

/** Given name through which Customer or Account-Holder indentifies. It can be individual name  or a business entity name */
export interface COPName {
  /** Detailed information of Customer who operates their account as an Individual entity. */
  individual?: IndividualPartyName;
  /** Detailed information of Customer where account belongs to a business entity or Organisation. */
  organisation?: OrganisationPartyName;
}

/** Detailed information of Customer who operates their account as an Individual entity. */
export interface IndividualPartyName {
  /**
   * prefix
   * Prefix or Saluation use by customer with their name.
   */
  prefix?: {
    /**
     * Standard value to uniquely identified prefix of a name.
     * @format string
     * @example "Mr."
     */
    code: string;
    /**
     * Detailed description of a standard value which uniquely identified prefix of a name.
     * @format string
     * @example "Mister"
     */
    description?: string;
  };
  /**
   * First name of Customer or Account Holder
   * @format string
   * @example "Paul"
   */
  firstName?: string;
  /**
   * Last name of Customer or Account Holder
   * @format string
   * @example "Walker"
   */
  lastName?: string;
  /**
   * Full name of Customer or Account Holder
   * @format string
   * @example "Paul Walker"
   */
  fullName?: string;
}

/** Detailed information of Customer where account belongs to a business entity or Organisation. */
export interface OrganisationPartyName {
  /**
   * Name through which a Organisation identifies.
   * @format string
   * @example "Sydney Swimmers Pvt Ltd"
   */
  name?: string;
}

/** Westpac internal identifier through which customer or it's account identifies within Organisation. */
export interface Arrangement {
  /**
   * Unique identifier for a customer within Westpac internal systems
   * @format string
   * @example "5163213095118684"
   */
  arrangementId?: string;
  /** Unique indentifier for creditor or debtor party which is combination of bsb and accountnumber. */
  accountId?: AccountId;
  /**
   * Canonical Product Code of the product associated with a Customer
   * @format string
   * @example "7dc53df5703e49b38670b1c468f47f1f"
   */
  canonicalProductCode?: string;
  /** Westpac Internal Role defined for a Arrangment */
  arrangementRole?: ArrangementRole;
  /** Current status of a Arrangment, associated with Customer or Account. */
  status?: 'Active' | 'Inactive';
  /** Defines whether Arrangment can perform Confirmation-Of-Payee Services (Opt-In/ Opt-Out) */
  isEligibleForCOPServices?: boolean;
  /**
   * Current Confirmation-Of-Payee services opted by a Arrangement, associated with Customer or Account.
   * @example "Opt-In"
   */
  accountCOPStatus?: 'Opt-In' | 'Opt-Out';
  /**
   * Nick name associated with Customer Account
   * @format string
   * @example "Nick"
   */
  nickName?: string;
  /**
   * Alias name associated with Customer Account
   * @format string
   * @example "Sydney Swimmers Pvt Ltd"
   */
  aliasName?: string;
  /**
   * Short name associated with Customer Account.
   * @format string
   * @example "SS Pvt Ltd"
   */
  shortName?: string;
  /**
   * Legal name associated with Customer Account.
   * @format string
   * @example "Sydney Swimmers"
   */
  legalName?: string;
  product?: Product;
}

/** Westpac Internal Role defined for a Arrangment */
export interface ArrangementRole {
  /**
   * roleType
   * Detailed information about Arrangment Role.
   */
  type?: {
    /**
     * Standard value which uniquely identifies arrangement role.
     * @format string
     * @example "SOL"
     */
    code: string;
    /**
     * Detailed description of a standard value which uniquely identifies arrangement role.
     * @format string
     * @example "Sole Trader"
     */
    description?: string;
  };
  /**
   * roleStatus
   * Detailed information about Arrangment Role Status.
   */
  status?: {
    /** Standard value which uniquely identifies arrangement role status */
    code: 'Active' | 'Inactive';
    /**
     * Detailed description of a standard value which uniquely identifies arrangement role status.
     * @format string
     * @example "Active"
     */
    description?: string;
  };
}

/** Indicates whether Customer is allowed to Initiate Opt-In in future. */
export interface OptInEligibility {
  /** Indicates whether customer can avail Opt-In Service */
  isAllowed: boolean;
  /**
   * optInAllowedReason
   * Detailed information in case customer chose Opt-In Confirmation-of-Payee-Service.
   */
  allowedReason?: {
    /** Standard value which uniquely identifies why Opt-In is allowed or not allowed. */
    code:
      | 'OPTIN_TO_OPTIN_NOT_ALLOWED'
      | 'OPTOUT_TO_OPTIN_ALLOWED_FOR_INDV_NO_RESTRICTIONS';
    /**
     * <br> Description
     *   <table>
     *   <tr>
     *     <td>ENUM Code</td>
     *     <td>Description</td>
     *   </tr>
     *   <tr>
     *     <td>OPTIN_TO_OPTIN_NOT_ALLOWED</td>
     *     <td>OptIn to OptIn not allowed</td>
     *   </tr>
     *   <tr>
     *     <td>OPTOUT_TO_OPTIN_ALLOWED_FOR_INDV_NO_RESTRICTIONS</td>
     *     <td>OptOut to OptIn allowed for INDV - No restrictions</td>
     *   </tr>
     *   </table>
     * @format string
     * @example "Opt-In to Opt-In is not allowed."
     */
    description?: string;
  };
}

/** Indicates whether Customer is allowed to Initiate Opt-Out in future. */
export interface OptOutEligibility {
  /**
   * Number days for which Customer is restricted to perform opt-out operation.
   * @example 60
   */
  restrictedDuration: number;
  /** Indicates whether customer can avail Opt-Out Service */
  isAllowed: boolean;
  /**
   * optOutAllowedReason
   * Detailed information in case customer chose Opt-out Confirmation-of-Payee-Service.
   */
  allowedReason?: {
    /** Standard value which uniquely identifies why Opt-Out is allowed or not allowed */
    code:
      | 'OPTIN_TO_OPTOUT_ALLOWED_FOR_INDV_ONLY'
      | 'OPTOUT_TO_OPTOUT_NOT_ALLOWED'
      | 'OPTIN_TO_OPTOUT_NOT_ALLOWED_WITHIN_N_DAYS_OF_LAST_OPT_IN'
      | 'OPTIN_TO_OPTOUT_ALLOWED_FOR_GREATER_THAN_N_DAYS_OF_LAST_OPT_IN';
    /**
     * <br> Description
     * <table>
     *   <tr>
     *     <td>ENUM Code</td>
     *     <td>Description</td>
     *   </tr>
     *   <tr>
     *     <td>OPTIN_TO_OPTOUT_ALLOWED_FOR_INDV_ONLY</td>
     *     <td>OptIn to OptOut allowed for INDV Only</td>
     *   </tr>
     *   <tr>
     *     <td>OPTOUT_TO_OPTOUT_NOT_ALLOWED</td>
     *     <td>OptOut to OptOut NOT allowed</td>
     *   </tr>
     *   <tr>
     *     <td>OPTIN_TO_OPTOUT_NOT_ALLOWED_WITHIN_N_DAYS_OF_LAST_OPT_IN</td>
     *     <td>OptIn to OptOut NOT allowed within N days of last Opt-In</td>
     *   </tr>
     *   <tr>
     *     <td>OPTIN_TO_OPTOUT_ALLOWED_FOR_GREATER_THAN_N_DAYS_OF_LAST_OPT_IN</td>
     *     <td>OptIn to OptOut allowed for greater than N days of last Opt-In</td>
     *   </tr>
     * </table>
     * @format string
     * @example "OptIn to OptOut allowed for INDV Only"
     */
    description?: string;
  };
}

/** Indicates whether Staff is allowed to update the confirmation-of-payee status from OptIn to OptOut or vice-versa. */
export interface StaffOverrideEligibility {
  /** Indicates whether Staff can update the Confirmation-of-Payee services , on behalf of Customer */
  isAllowed: boolean;
  /**
   * staffOverrideAllowed
   * Detailed information in case Staff is performing Confirmation-of-Payee-Operations.
   */
  allowedReason?: {
    /**
     * code
     * Standard value which uniquely identifies Staff Overridden reasons
     */
    code:
      | 'NOT_ALLOWED'
      | 'OPTOUT_STAFF_ALLOWED_TO_OVERRIDE_DATE_RANGE_RESTRICTIONS';
    /**
     * description
     * <br> Description
     *   <table>
     *   <tr>
     *     <td>ENUM Code</td>
     *     <td>Description</td>
     *   </tr>
     *   <tr>
     *     <td>NOT_ALLOWED</td>
     *     <td>Not Allowed</td>
     *   </tr>
     *   <tr>
     *     <td>OPTOUT_STAFF_ALLOWED_TO_OVERRIDE_DATE_RANGE_RESTRICTIONS</td>
     *     <td>OptOut- Staff Allowed to override date range restrictions</td>
     *   </tr>
     *   </table>
     * @format string
     * @example "Not Allowed"
     */
    description?: string;
  };
}

/** Contains detailed information of current confirmation-of-payee status */
export interface COPStatusDetails {
  /** Information about current status for confirmation-of-payee Opt-In and Opt-Out services. */
  currentStatusCode?: 'Opt-Out' | 'Opt-In';
  /** Indicates whether, this is a Default time Opt-in */
  isFirstOperation?: boolean;
  /** Detailed reason for chosing Opt-Out for Confirmation-of-Payee-Services by Customer. It will only populate, if customer choosing Opt-Out */
  optOutReason?: OptOutReason;
}

/** Unique indentifier for creditor or debtor party which is combination of bsb and accountnumber. */
export interface AccountId {
  /**
   * Unique Indentifier within a bank to indentify creditor or debtor party.
   * @format string
   * @example "345623189665"
   */
  accountNumber?: string;
  /**
   * A six-digit code used to identify the specific branch
   * @format string
   * @maxLength 6
   * @example "037724"
   */
  BSB?: string;
}

/** Request to create or update the confirmation-of -payee preference i.e opt-in or opt-out. */
export interface COPPreferenceRequest {
  /** Detailed information about COP preference opted by a customer or by staff. Available COP preferences are Opt-In or Opt-Out */
  COPPreference: COPPreference;
  /** Indicates whether, this is a Default first time Opt-in Customer. */
  isFirstOperation?: boolean;
  /** Indicates whether, this is cop preference are chosen by Staff on behalf of customer. */
  isStaffOverride?: boolean;
}

/** Detailed information about COP preference opted by a customer or by staff. Available COP preferences are Opt-In or Opt-Out */
export interface COPPreference {
  type: 'Opt-Out' | 'Opt-In';
  /** Detailed reason for chosing Opt-Out for Confirmation-of-Payee-Services by Customer. It will only populate, if customer choosing Opt-Out */
  optOutReason?: OptOutReason;
}

/**  Information about COP preference status */
export interface COPPreferenceStaus {
  currentStatusCode: 'Opt-Out' | 'Opt-In';
  previousStatusCode?: 'Opt-In' | 'Opt-Out';
}

/** Confirmation of Payee Account eligibility Request */
export interface PostAccountEligibilityRequest {
  /** Indicates whether this is a Default first time Opt-in Customer. */
  arrangements: ArrangementReq[];
}

/** Westpac internal identifier through which customer or it's account identifies within Organisation. */
export interface ArrangementReq {
  /** Unique identifier for a customer within Westpac internal systems */
  arrangementId: ArrangementId;
  /** Unique indentifier for creditor or debtor party which is combination of bsb and accountnumber. */
  accountId?: AccountIdreq;
  /** Canonical Product Code of the product associated with a Customer */
  canonicalProductCode: CanonicalProductCode;
}

/**
 * Unique identifier for a customer within Westpac internal systems
 * @format string
 * @example "5163213095118684"
 */
export type ArrangementId = string;

/** Unique indentifier for creditor or debtor party which is combination of bsb and accountnumber. */
export interface AccountIdreq {
  /**
   * Unique Indentifier within a bank to indentify creditor or debtor party.
   * @format string
   * @example "345623189665"
   */
  accountNumber?: string;
  /**
   * A six-digit code used to identify the specific branch
   * @format string
   * @maxLength 6
   * @example "037724"
   */
  BSB: string;
}

/**
 * Canonical Product Code of the product associated with a Customer
 * @format string
 * @example "7dc53df5703e49b38670b1c468f47f1f"
 */
export type CanonicalProductCode = string;

/** Response structure for Arrangement */
export interface ArrangementRes {
  /** Unique identifier for a customer within Westpac internal systems */
  arrangementId: ArrangementId;
  /**
   * Start time of the Arrangment
   * @format date-time
   */
  startDateTime?: string;
  /**
   * end time of the Arrangment
   * @format date-time
   */
  endDateTime?: string;
  /** Unique indentifier for creditor or debtor party which is combination of bsb and accountnumber. */
  accountId?: AccountId;
  /** Canonical Product Code of the product associated with a Customer */
  canonicalProductCode: CanonicalProductCode;
  /** Current status of a Arrangment, associated with Customer or Account. */
  status?: 'Active' | 'Inactive';
  /** Defines whether Arrangment can perform Confirmation-Of-Payee Services (Opt-In/ Opt-Out) */
  isEligibleForCOPServices?: boolean;
  /**
   * Current Confirmation-Of-Payee services opted by a Arrangement, associated with Customer or Account.
   * @example "Opt-In"
   */
  accountCOPStatus?: 'Opt-In' | 'Opt-Out';
}

/** Represent an individual error. */
export interface ErrorPartialSuccess {
  /**
   * Error Code.
   * @format int32
   * @example 1007
   */
  code?: number;
  /**
   * Error Message
   * @format string
   * @example "Arrangement not found"
   */
  message?: string;
  /**
   * Detailed information about the error
   * @format string
   * @example "Arrangement not found for given Arrangement Identifier"
   */
  details?: string;
  /** Represent correlationKey. */
  correlationKey?: Correlation;
}

/** Represent correlationKey. */
export interface Correlation {
  /**
   * Full account number including BSB  or Account Number or Credit Card number etc.
   *  e.g. 032000123456
   * @format string
   * @example "5163213095118684"
   */
  arrangementId?: string;
  /**
   * Canonical Product Code of the product.
   *  Sample value "7dc53df5703e49b38670b1c468f47f1f"
   * @format string
   * @minLength 32
   * @maxLength 32
   * @example "7dc53df5703e49b38670b1c468f47f1f"
   */
  canonicalProductCode?: string;
}

/** Possible values for brandsilo */
export enum BrandSilo {
  WPAC = 'WPAC',
  SGBBSA = 'SGBBSA',
  RAMS = 'RAMS',
}

/** Possible values for X-User ID Scheme */
export enum XuserIdScheme {
  StaffSalaryNumber = 'StaffSalaryNumber',
  CustomerInternalId = 'CustomerInternalId',
  CustomerNumber = 'CustomerNumber',
  SystemProcess = 'SystemProcess',
  CorporateUserId = 'CorporateUserId',
  ProspectId = 'ProspectId',
}

/** Possible values for Customer ID Scheme */
export enum CustomerIdScheme {
  CustomerInternalId = 'CustomerInternalId',
  CustomerNumber = 'CustomerNumber',
  PartyUID = 'PartyUID',
  ExternalSystemCustomerId = 'ExternalSystemCustomerId',
}

/** Possible values for Customer Type */
export enum ViewType {
  Summary = 'summary',
  Detailed = 'detailed',
}

/** Possible values for Customer Type */
export enum ArrangementRoleType {
  OwnersOnly = 'OwnersOnly',
  OwnersAndNonOwners = 'OwnersAndNonOwners',
}

export interface Product {
  /**
   * Key/Name of the product in GCM
   * @format string
   * @maxLength 256
   * @example "7dc53df5703e49b38670b1c468f47f1f"
   */
  gcmProductKey?: string;
  /**
   * Product Short Name
   * @format string
   * @maxLength 30
   * @example "Westpac Student Reward Saver"
   */
  shortName?: string;
  /**
   * Product Long Name
   * @format string
   * @maxLength 60
   * @example "Westpac Choice eAccount"
   */
  longName?: string;
  /**
   * Product family name  as Consumer Savings, Business Cards, Consumer Cards etc.
   * @format string
   * @maxLength 256
   * @example "Consumer Savings"
   */
  productFamily?: string;
  /**
   * Digital Product Group eg SavingAndTransaction, Mortgage,TermLoan,TermDeposit etc.
   * @format string
   * @maxLength 256
   * @example "TermDeposit"
   */
  digitalProductGroup?: string;
}

/** Request for account name check. */
export interface AccountNameCheckRequest {
  /**
   * Unique Random number generated by the source to identify Verify+ request
   * @format string
   * @maxLength 32
   * @example "ac7012c489d643f077cb6b21154588ad"
   */
  transactionId: string;
  /** Basic information about the Payee. Also, Either Credit Card or AccountId Must be populeted. Both Credit Card and AccountId must not pass together. */
  payee: Payee;
  /** Basic information about the Payer */
  payer?: Payer;
}

/** Request for preferred names. */
export interface COPPrefferedNamesRequest {
  /** Unique indentifier for creditor or debtor party which is combination of bsb and accountnumber. */
  account: {
    /**
     * Unique Indentifier within a bank to indentify creditor or debtor party.
     * @pattern ^[ -~]{1,8}$
     * @example "12345678"
     */
    accountNumber: string;
    /**
     * A six-digit code used to identify the specific branch
     * @format string
     * @maxLength 6
     * @example "062000"
     */
    BSB: string;
  };
  /** Customer details for preferred names lookup. */
  customer: {
    /**
     * Unique indentifier  to identify Customer within Westpac group.This is the customer CustomerInternalId or CustomerNumber or PartyUID or ExternalSystemCustomerId.
     * @example "00542728151"
     */
    id: string;
    /** The scheme (type) applicable for the Customer identifier. Currently API only supports CustomerInternalId */
    idScheme:
      | 'CustomerInternalId'
      | 'CustomerNumber'
      | 'PartyUID'
      | 'ExternalSystemCustomerId';
    /** Customer type */
    customerType: 'Individual' | 'Organisation';
  };
}

/** Basic information about the Payee. Also, Either Credit Card or AccountId Must be populeted. Both Credit Card and AccountId must not pass together. */
export interface Payee {
  /**
   * Payee Known name
   * @format string
   * @minLength 1
   * @maxLength 140
   * @example "Paul Walker"
   */
  name: string;
  /**
   * Unique Indentifier to credit card hold by a customer usually a 16 digit number without hyphens
   * @format string
   * @maxLength 16
   * @example "3456007816789067"
   */
  creditCardNumber?: string;
  /** Unique Indentifier to indentify creditor or debtor party. */
  accountId?: {
    /**
     * Unique Indentifier within a bank to indentify creditor or debtor party.
     * @pattern ^[ -~]{1,34}$
     * @example "345623189665"
     */
    accountNumber: string;
    /**
     * A six-digit code used to identify the specific branch
     * @format string
     * @maxLength 6
     * @example "037724"
     */
    BSB: string;
  };
}

/** Basic information about the Payer */
export interface Payer {
  /**
   * Payer's Bank Identifier Code
   * @pattern ^[A-Z0-9]{4,4}[A-Z]{2,2}[A-Z0-9]{2,2}[A-Z0-9]{3,3}$
   * @example "WPACAU2SXXX"
   */
  BIC: string;
}

/**
 * <table> <tr> <td>Code</td> <td>Description</td> </tr> <tr> <td>V0C1</td> <td>A match response was returned by Verify+ and CoP</td> </tr> <tr> <td>V0C2</td> <td>A match response was returned by Verify+ and a close match response response returned by CoP</td> </tr> <tr> <td>V0C3</td> <td>A match response was returned by Verify+ and a no match response returned by CoP for an individual customer.</td> </tr> <tr> <td>V0C4</td> <td>A match response was returned by Verify+ and a no match response returned by CoP for a non individual customer </td> </tr> <tr> <td>V0C5</td> <td>A match response was returned by Verify+ and an opted out response response returned by CoP  </td> </tr> <tr> <td>V0C6</td> <td>A match response was returned by Verify+ and a technical error response returned by CoP </td> </tr> <tr> <td>V0C7</td> <td>A match response was returned by Verify+ and closed account response returned by CoP  </td> </tr> <tr> <td>V0C8</td> <td>A match response was returned by Verify+ and participant unavailable code response returned by CoP  </td> </tr>
 * <tr> <td>V1C1</td> <td>A not enough payments response was returned by Verify+ a match response returned by CoP</td> </tr> <tr> <td>V1C2</td> <td>A not enough payments response was returned by Verify+ and a close match response response returned by CoP  </td> </tr> <tr> <td>V1C3</td> <td>A not enough payments response was returned by Verify+ and a no match response returned by CoP for an individual customer</td> </tr> <tr> <td>V1C4</td> <td>A not enough payments response was returned by Verify+ and a no match response returned by CoP for a non individual customer </td> </tr> <tr> <td>V1C5</td> <td>A not enough payments response was returned by Verify+ and an opted out response response returned by CoP  </td> </tr> <tr> <td>V1C6</td> <td>A not enough payments response was returned by Verify+ and a technical error response returned by CoP </td> </tr> <tr> <td>V1C7</td> <td>A not enough payments response was returned by Verify+ and closed account response returned by CoP  </td> </tr> <tr> <td>V1C8</td> <td>A not enough payments response was returned by Verify+ and participant unavailable code response returned by CoP  </td> </tr>
 * <tr> <td>V2C1</td> <td>A no match response was returned by Verify+ a match response returned by CoP</td> </tr> <tr> <td>V2C2</td> <td>A no match response was returned by Verify+ and a close match response response returned by CoP</td> </tr> <tr> <td>V2C3</td> <td>A no match response was returned by Verify+ and a no match response returned by CoP for an individual customer</td> </tr> <tr> <td>V2C4</td> <td>A no match response was returned by Verify+ and a no match response returned by CoP for a non individual customer</td> </tr> <tr> <td>V2C5</td> <td>A no match response was returned by Verify+ and an opted out response response returned by CoP</td> </tr> <tr> <td>V2C6</td> <td>A no match response was returned by Verify+ and a technical error response returned by CoP </td> </tr> <tr> <td>V2C7</td> <td>A no match response was returned by Verify+ and closed account response returned by CoP </td> </tr> <tr> <td>V2C8</td> <td>A no match response was returned by Verify+ and participant unavailable code response returned by CoP</td> </tr>
 * <tr> <td>VAC1</td> <td>A no matching rules response was returned by Verify+ and  a match response returned by CoP</td> </tr> <tr> <td>VAC2</td> <td>A no matching rules response was returned by Verify+ and a close match response response returned by CoP  </td> </tr> <tr> <td>VAC3</td> <td>A no matching rules response was returned by Verify+ and a no match response returned by CoP for an individual customer </td> </tr> <tr> <td>VAC4</td> <td>A no matching rules response was returned by Verify+ and a no match response returned by CoP for a non individual customer </td> </tr> <tr> <td>VAC5</td> <td>A no matching rules response was returned by Verify+ and an opted out response response returned by CoP </td> </tr> <tr> <td>VAC6</td> <td>A no matching rules response was returned by Verify+ and a technical error response returned by CoP </td> </tr> <tr> <td>VAC7</td> <td>A no matching rules response was returned by Verify+ and closed account response returned by CoP </td> </tr> <tr> <td>VAC8</td> <td>A no matching rules response was returned by Verify+ and participant unavailable code response returned by CoP</td> </tr>
 * <tr> <td>VEC1</td> <td>An error response was returned by Verify+ a match response returned by CoP</td> </tr> <tr> <td>VEC2</td> <td>An error response was returned by Verify+ and a close match response response returned by CoP  </td> </tr> <tr> <td>VEC3</td> <td>An error response was returned by Verify+ and a no match response returned by CoP for an individual customer  </td> </tr> <tr> <td>VEC4</td> <td>An error response was returned by Verify+ and a no match response returned by CoP for a non individual customer </td> </tr> <tr> <td>VEC5</td> <td>An error response was returned by Verify+ and an opted out response response returned by CoP  </td> </tr> <tr> <td>VEC6</td> <td>An error response was returned by Verify+ and a technical error response returned by CoP  </td> </tr> <tr> <td>VEC7</td> <td>An error response was returned by Verify+ and closed account response returned by CoP </td> </tr> <tr> <td>VEC8</td> <td>An error response was returned by Verify+ and participant unavailable code response returned by CoP </td> </tr>
 * <tr> <td>VTC1</td> <td>A timeout occurred for the Verify+ a match response returned by CoP</td> </tr> <tr> <td>VTC2</td> <td>A timeout occurred for the Verify+ and a close match response response returned by CoP    </td> </tr> <tr> <td>VTC3</td> <td>A timeout occurred for the Verify+ and a no match response returned by CoP for an individual customer </td> </tr> <tr> <td>VTC4</td> <td>A timeout occurred for the Verify+ and a no match response returned by CoP for a non individual customer</td> </tr> <tr> <td>VTC5</td> <td>A timeout occurred for the Verify+ and an opted out response response returned by CoP  </td> </tr> <tr> <td>VTC6</td> <td>A timeout occurred for the Verify+ and a technical error response returned by CoP  </td> </tr> <tr> <td>VTC7</td> <td>A timeout occurred for the Verify+ and closed account response returned by CoP  </td> </tr> <tr> <td>VTC8</td> <td>A timeout occurred for the Verify+ and participant unavailable code response returned by CoP </td> </tr> </table>
 */
export interface MatchedStatus {
  /**
   * ERDM encoded value
   * @format string
   * @maxLength 4
   * @example "V0C1"
   */
  code: string;
  /**
   * Detailed description of ERDM encode.
   * @format string
   * @example "A match response was returned by Verify+ and CoP"
   */
  description?: string;
}

export namespace Customers {
  /**
   * @description Provide detailed confirmation-Of-Payee information for a specified Westpac internal customer.
   * @tags getCopInformation
   * @name GetCopInformation
   * @request GET:/customers/{customerId}/cop/information
   * @secure
   */
  export namespace GetCopInformation {
    export type RequestParams = {
      /**
       * Customer Identification number for which COP information retrieve
       * @format string
       */
      customerId: string;
    };
    export type RequestQuery = {
      /** The Brand Silo the caller is operating in. Brand Silo is a concept used in Westpac to segregate Customer records based on a combination of the organisation that owns the customer relationship and the systems environment in which their identity records are created and maintained. A Brand Silo is a classification whereas a Brand is a descriptive entity associated with an Organisation. */
      brandSilo: BrandSilo;
      /** Internal Westpac Customer scheme type */
      customerIdScheme: CustomerIdScheme;
      /** Internal Westpac customer type classification. If not provided, value will be derived internally. */
      customerType?: CustomerType;
      /** Describe what level of information requested. Summary view only contains CoP Status and its eligibility. Detailed view provide more information along with each account details. Default is summary */
      viewType?: ViewType;
    };
    export type RequestBody = never;
    export type RequestHeaders = {
      /**
       * The unique identifier for the user invoking the API (e.g. Staff salary number, Customer CIS/GCIS key, Partner CIS/GCIS key or other identifier).
       * @pattern ^[0-9A-Za-z]{1,100}$
       */
      'x-userId': string;
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      'x-userIdScheme': XuserIdScheme;
    };
    export type ResponseBody = {
      data?: {
        /**
         * Type of Customer
         * <table><tr><th><u>Possible Customer Types<u></th></tr><tr><td>Individual</td></tr><tr><td>Organisation</td></tr></table>
         */
        customerType?: CustomerType;
        /** Contains detailed information of current confirmation-of-payee status */
        COPStatus?: COPStatusDetails;
        /** Indicates whether Customer is allowed to Initiate Opt-In in future. */
        optInEligibility?: OptInEligibility;
        /** Indicates whether Customer is allowed to Initiate Opt-Out in future. */
        optOutEligibility?: OptOutEligibility;
        /** Indicates whether Staff is allowed to update the confirmation-of-payee status from OptIn to OptOut or vice-versa. */
        staffOverrideEligibility?: StaffOverrideEligibility;
        /** Given name through which Customer or Account-Holder indentifies. It can be individual name  or a business entity name */
        COPName?: COPName;
        /** List of arrangments associated with a Customer or Account-holder */
        COPArrangements?: Arrangement[];
      };
    };
  }
  /**
   * @description Provide detailed confirmation-Of-Payee preferences for a specified Westpac internal customer.
   * @tags getCopPreference
   * @name GetCopPreference
   * @request GET:/customers/{customerId}/cop/preference
   * @secure
   */
  export namespace GetCopPreference {
    export type RequestParams = {
      /**
       * Customer Identification number for which COP information retrieve
       * @format string
       */
      customerId: string;
    };
    export type RequestQuery = {
      /** The Brand Silo the caller is operating in. Brand Silo is a concept used in Westpac to segregate Customer records based on a combination of the organisation that owns the customer relationship and the systems environment in which their identity records are created and maintained. A Brand Silo is a classification whereas a Brand is a descriptive entity associated with an Organisation. */
      brandSilo: BrandSilo;
      /** Internal Westpac Customer scheme type */
      customerIdScheme: CustomerIdScheme;
      /** Internal Westpac customer type classification. If not provided, value will be derived internally. */
      customerType: CustomerType;
    };
    export type RequestBody = never;
    export type RequestHeaders = {
      /**
       * The unique identifier for the user invoking the API (e.g. Staff salary number, Customer CIS/GCIS key, Partner CIS/GCIS key or other identifier).
       * @pattern ^[0-9A-Za-z]{1,100}$
       */
      'x-userId': string;
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      'x-userIdScheme': XuserIdScheme;
    };
    export type ResponseBody = {
      data?: {
        /** Contains detailed information of current confirmation-of-payee status */
        COPStatus?: COPStatusDetails;
        /** Indicates whether Customer is allowed to Initiate Opt-In in future. */
        optInEligibility?: OptInEligibility;
        /** Indicates whether Customer is allowed to Initiate Opt-Out in future. */
        optOutEligibility?: OptOutEligibility;
        /** Indicates whether Staff is allowed to update the confirmation-of-payee status from OptIn to OptOut or vice-versa. */
        staffOverrideEligibility?: StaffOverrideEligibility;
      };
    };
  }
  /**
   * @description Create or update confirmation-Of-Payee preference for a specified Westpac internal customer..
   * @tags createUpdateCopPreference
   * @name PostCopPreference
   * @request POST:/customers/{customerId}/cop/preference
   * @secure
   */
  export namespace PostCopPreference {
    export type RequestParams = {
      /**
       * Customer Identification number for which COP information retrieve
       * @format string
       */
      customerId: string;
    };
    export type RequestQuery = {
      /** The Brand Silo the caller is operating in. Brand Silo is a concept used in Westpac to segregate Customer records based on a combination of the organisation that owns the customer relationship and the systems environment in which their identity records are created and maintained. A Brand Silo is a classification whereas a Brand is a descriptive entity associated with an Organisation. */
      brandSilo: BrandSilo;
      /** Internal Westpac Customer scheme type */
      customerIdScheme: CustomerIdScheme;
      /** Internal Westpac customer type classification. If not provided, value will be derived internally. */
      customerType?: CustomerType;
    };
    export type RequestBody = COPPreferenceRequest;
    export type RequestHeaders = {
      /**
       * The unique identifier for the user invoking the API (e.g. Staff salary number, Customer CIS/GCIS key, Partner CIS/GCIS key or other identifier).
       * @pattern ^[0-9A-Za-z]{1,100}$
       */
      'x-userId': string;
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      'x-userIdScheme': XuserIdScheme;
    };
    export type ResponseBody = {
      data?: {
        /**
         * Type of Customer
         * <table><tr><th><u>Possible Customer Types<u></th></tr><tr><td>Individual</td></tr><tr><td>Organisation</td></tr></table>
         */
        customerType: CustomerType;
        /**  Information about COP preference status */
        COPPreferenceStaus: COPPreferenceStaus;
      };
    };
  }
  /**
   * @description Get the list of account for the customer with the CoP status
   * @tags getCoPStatusAccountList
   * @name GetCoPStatusAccountList
   * @request GET:/customers/{customerId}/cop/accounts
   * @secure
   */
  export namespace GetCoPStatusAccountList {
    export type RequestParams = {
      /**
       * Customer Identification number for which COP information retrieved
       * @format string
       */
      customerId: string;
    };
    export type RequestQuery = {
      /** Internal Westpac Customer scheme type */
      customerIdScheme: CustomerIdScheme;
      /** Internal Westpac customer type classification. If not provided, value will be derived internally. */
      customerType: CustomerType;
      /** The Brand Silo the caller is operating in. Brand Silo is a concept used in Westpac to segregate Customer records based on a combination of the organisation that owns the customer relationship and the systems environment in which their identity records are created and maintained. A Brand Silo is a classification whereas a Brand is a descriptive entity associated with an Organisation. */
      brandSilo: BrandSilo;
      /** arrangement type that needs to be supported. */
      arrangementRoleType?: ArrangementRoleType;
    };
    export type RequestBody = never;
    export type RequestHeaders = {
      /**
       * The unique identifier for the user invoking the API (e.g. Staff salary number, Customer CIS/GCIS key, Partner CIS/GCIS key or other identifier).
       * @pattern ^[0-9A-Za-z]{1,100}$
       */
      'x-userId': string;
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      'x-userIdScheme': XuserIdScheme;
    };
    export type ResponseBody = {
      data?: {
        /** List of arrangments associated with a Customer or Account-holder */
        COPArrangements?: Arrangement[];
      };
    };
  }
  /**
   * @description Get the list of account for the customer with the CoP status
   * @tags getPayeeName
   * @name GetPayeeName
   * @request GET:/customers/{customerId}/payeeName
   * @secure
   */
  export namespace GetPayeeName {
    export type RequestParams = {
      /**
       * Customer Identification number for which COP information retrieved
       * @format string
       */
      customerId: string;
    };
    export type RequestQuery = {
      /** Internal Westpac Customer scheme type */
      customerIdScheme: CustomerIdScheme;
      /** Internal Westpac customer type classification. If not provided, value will be derived internally. */
      customerType: CustomerType;
      /** The Brand Silo the caller is operating in. Brand Silo is a concept used in Westpac to segregate Customer records based on a combination of the organisation that owns the customer relationship and the systems environment in which their identity records are created and maintained. A Brand Silo is a classification whereas a Brand is a descriptive entity associated with an Organisation. */
      brandSilo: BrandSilo;
    };
    export type RequestBody = never;
    export type RequestHeaders = {
      /**
       * The unique identifier for the user invoking the API (e.g. Staff salary number, Customer CIS/GCIS key, Partner CIS/GCIS key or other identifier).
       * @pattern ^[0-9A-Za-z]{1,100}$
       */
      'x-userId': string;
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      'x-userIdScheme': XuserIdScheme;
    };
    export type ResponseBody = {
      data?: {
        /** Given name through which Customer or Account-Holder indentifies. It can be individual name  or a business entity name */
        customer?: COPName;
      };
    };
  }
}

export namespace Cop {
  /**
   * @description Get the list of account for the customer with the CoP status
   * @tags postCopAccountEligibility
   * @name PostAccountEligibility
   * @request POST:/cop/eligibility
   * @secure
   */
  export namespace PostAccountEligibility {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = PostAccountEligibilityRequest;
    export type RequestHeaders = {
      /**
       * The unique identifier for the user invoking the API (e.g. Staff salary number, Customer CIS/GCIS key, Partner CIS/GCIS key or other identifier).
       * @pattern ^[0-9A-Za-z]{1,100}$
       */
      'x-userId': string;
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      'x-userIdScheme': XuserIdScheme;
      /**
       * Identifies the BSB from which this request originated.
       * @pattern ^\d{3}-\d{3}$
       */
      'x-originatingBSB'?: string;
    };
    export type ResponseBody = {
      data?: {
        /** List of arrangments associated with a Customer or Account-holder */
        arrangements?: ArrangementRes[];
      };
      result?: {
        errors?: ErrorPartialSuccess[];
      };
    };
  }
  /**
   * @description This api shows all the COP prefered Names for a particular Account including Business Trading Names.
   * @tags CoPPrefferedNames
   * @name CopPrefferedNames
   * @request POST:/cop/preferred-names
   * @secure
   */
  export namespace CopPrefferedNames {
    export type RequestParams = {};
    export type RequestQuery = {
      /** The Brand Silo the caller is operating in. Brand Silo is a concept used in Westpac to segregate Customer records based on a combination of the organisation that owns the customer relationship and the systems environment in which their identity records are created and maintained. A Brand Silo is a classification whereas a Brand is a descriptive entity associated with an Organisation. */
      brandSilo: BrandSilo;
    };
    export type RequestBody = COPPrefferedNamesRequest;
    export type RequestHeaders = {
      /**
       * The unique identifier for the user invoking the API (e.g. Staff salary number, Customer CIS/GCIS key, Partner CIS/GCIS key or other identifier).
       * @pattern ^[0-9A-Za-z]{1,100}$
       */
      'x-userId': string;
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      'x-userIdScheme': XuserIdScheme;
    };
    export type ResponseBody = {
      data: {
        /** Type of the Account which a customer holds. */
        customerAccountType: 'INDV' | 'NIND';
        /** Account COP status */
        accountCOPStatus: 'ACTV' | 'OOUT';
        COPPrefferedNames: {
          /**
           * Customer Account Name
           * @format string
           * @minLength 1
           * @maxLength 140
           * @example "PAUL WALKER & SALLY WALKER"
           */
          accountName: string;
          /**
           * Account AKA Names
           * @example [{"AKAName":"P WALKER"},{"AKAName":"S WALKER"},{"AKAName":"P and S WALKERS"}]
           */
          accountAKANames?: {
            /** @maxLength 140 */
            AKAName?: string;
          }[];
          /**
           * Customer Name
           * @maxLength 140
           * @example "PAUL WALKER"
           */
          customerName?: string;
        };
      };
    };
  }
}

export namespace AccountNameCheck {
  /**
   * @description This api validate internal customer name , in case of On-Us  or external customer Name in case of off-us scenarios. Consumer can pass either AccountId or Credit Card Number. Both Credit Card Number and AccountId must not pass together.
   * @tags accountNameCheck
   * @name AccountNameCheck
   * @request POST:/accountNameCheck
   * @secure
   */
  export namespace AccountNameCheck {
    export type RequestParams = {};
    export type RequestQuery = {
      /** The Brand Silo the caller is operating in. Brand Silo is a concept used in Westpac to segregate Customer records based on a combination of the organisation that owns the customer relationship and the systems environment in which their identity records are created and maintained. A Brand Silo is a classification whereas a Brand is a descriptive entity associated with an Organisation. */
      brandSilo: BrandSilo;
    };
    export type RequestBody = AccountNameCheckRequest;
    export type RequestHeaders = {
      /**
       * The unique identifier for the user invoking the API (e.g. Staff salary number, Customer CIS/GCIS key, Partner CIS/GCIS key or other identifier).
       * @pattern ^[0-9A-Za-z]{1,100}$
       */
      'x-userId': string;
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      'x-userIdScheme': XuserIdScheme;
      /**
       * The unique identifier for the party on whose behalf the user identified by x-userId is acting.
       * @format string
       */
      'x-onBehalfOfId'?: string;
      /** The scheme (type) applicable for the party on whose behalf the user identified by x-userId is acting. */
      'x-onBehalfOfIdScheme'?: 'CustomerInternalId';
    };
    export type ResponseBody = {
      data: {
        /**
         * Payee Known name
         * @format string
         * @minLength 1
         * @maxLength 140
         * @example "Paul Walker"
         */
        matchedAccountName?: string;
        /**
         * <table> <tr> <td>Code</td> <td>Description</td> </tr> <tr> <td>V0C1</td> <td>A match response was returned by Verify+ and CoP</td> </tr> <tr> <td>V0C2</td> <td>A match response was returned by Verify+ and a close match response response returned by CoP</td> </tr> <tr> <td>V0C3</td> <td>A match response was returned by Verify+ and a no match response returned by CoP for an individual customer.</td> </tr> <tr> <td>V0C4</td> <td>A match response was returned by Verify+ and a no match response returned by CoP for a non individual customer </td> </tr> <tr> <td>V0C5</td> <td>A match response was returned by Verify+ and an opted out response response returned by CoP  </td> </tr> <tr> <td>V0C6</td> <td>A match response was returned by Verify+ and a technical error response returned by CoP </td> </tr> <tr> <td>V0C7</td> <td>A match response was returned by Verify+ and closed account response returned by CoP  </td> </tr> <tr> <td>V0C8</td> <td>A match response was returned by Verify+ and participant unavailable code response returned by CoP  </td> </tr>
         * <tr> <td>V1C1</td> <td>A not enough payments response was returned by Verify+ a match response returned by CoP</td> </tr> <tr> <td>V1C2</td> <td>A not enough payments response was returned by Verify+ and a close match response response returned by CoP  </td> </tr> <tr> <td>V1C3</td> <td>A not enough payments response was returned by Verify+ and a no match response returned by CoP for an individual customer</td> </tr> <tr> <td>V1C4</td> <td>A not enough payments response was returned by Verify+ and a no match response returned by CoP for a non individual customer </td> </tr> <tr> <td>V1C5</td> <td>A not enough payments response was returned by Verify+ and an opted out response response returned by CoP  </td> </tr> <tr> <td>V1C6</td> <td>A not enough payments response was returned by Verify+ and a technical error response returned by CoP </td> </tr> <tr> <td>V1C7</td> <td>A not enough payments response was returned by Verify+ and closed account response returned by CoP  </td> </tr> <tr> <td>V1C8</td> <td>A not enough payments response was returned by Verify+ and participant unavailable code response returned by CoP  </td> </tr>
         * <tr> <td>V2C1</td> <td>A no match response was returned by Verify+ a match response returned by CoP</td> </tr> <tr> <td>V2C2</td> <td>A no match response was returned by Verify+ and a close match response response returned by CoP</td> </tr> <tr> <td>V2C3</td> <td>A no match response was returned by Verify+ and a no match response returned by CoP for an individual customer</td> </tr> <tr> <td>V2C4</td> <td>A no match response was returned by Verify+ and a no match response returned by CoP for a non individual customer</td> </tr> <tr> <td>V2C5</td> <td>A no match response was returned by Verify+ and an opted out response response returned by CoP</td> </tr> <tr> <td>V2C6</td> <td>A no match response was returned by Verify+ and a technical error response returned by CoP </td> </tr> <tr> <td>V2C7</td> <td>A no match response was returned by Verify+ and closed account response returned by CoP </td> </tr> <tr> <td>V2C8</td> <td>A no match response was returned by Verify+ and participant unavailable code response returned by CoP</td> </tr>
         * <tr> <td>VAC1</td> <td>A no matching rules response was returned by Verify+ and  a match response returned by CoP</td> </tr> <tr> <td>VAC2</td> <td>A no matching rules response was returned by Verify+ and a close match response response returned by CoP  </td> </tr> <tr> <td>VAC3</td> <td>A no matching rules response was returned by Verify+ and a no match response returned by CoP for an individual customer </td> </tr> <tr> <td>VAC4</td> <td>A no matching rules response was returned by Verify+ and a no match response returned by CoP for a non individual customer </td> </tr> <tr> <td>VAC5</td> <td>A no matching rules response was returned by Verify+ and an opted out response response returned by CoP </td> </tr> <tr> <td>VAC6</td> <td>A no matching rules response was returned by Verify+ and a technical error response returned by CoP </td> </tr> <tr> <td>VAC7</td> <td>A no matching rules response was returned by Verify+ and closed account response returned by CoP </td> </tr> <tr> <td>VAC8</td> <td>A no matching rules response was returned by Verify+ and participant unavailable code response returned by CoP</td> </tr>
         * <tr> <td>VEC1</td> <td>An error response was returned by Verify+ a match response returned by CoP</td> </tr> <tr> <td>VEC2</td> <td>An error response was returned by Verify+ and a close match response response returned by CoP  </td> </tr> <tr> <td>VEC3</td> <td>An error response was returned by Verify+ and a no match response returned by CoP for an individual customer  </td> </tr> <tr> <td>VEC4</td> <td>An error response was returned by Verify+ and a no match response returned by CoP for a non individual customer </td> </tr> <tr> <td>VEC5</td> <td>An error response was returned by Verify+ and an opted out response response returned by CoP  </td> </tr> <tr> <td>VEC6</td> <td>An error response was returned by Verify+ and a technical error response returned by CoP  </td> </tr> <tr> <td>VEC7</td> <td>An error response was returned by Verify+ and closed account response returned by CoP </td> </tr> <tr> <td>VEC8</td> <td>An error response was returned by Verify+ and participant unavailable code response returned by CoP </td> </tr>
         * <tr> <td>VTC1</td> <td>A timeout occurred for the Verify+ a match response returned by CoP</td> </tr> <tr> <td>VTC2</td> <td>A timeout occurred for the Verify+ and a close match response response returned by CoP    </td> </tr> <tr> <td>VTC3</td> <td>A timeout occurred for the Verify+ and a no match response returned by CoP for an individual customer </td> </tr> <tr> <td>VTC4</td> <td>A timeout occurred for the Verify+ and a no match response returned by CoP for a non individual customer</td> </tr> <tr> <td>VTC5</td> <td>A timeout occurred for the Verify+ and an opted out response response returned by CoP  </td> </tr> <tr> <td>VTC6</td> <td>A timeout occurred for the Verify+ and a technical error response returned by CoP  </td> </tr> <tr> <td>VTC7</td> <td>A timeout occurred for the Verify+ and closed account response returned by CoP  </td> </tr> <tr> <td>VTC8</td> <td>A timeout occurred for the Verify+ and participant unavailable code response returned by CoP </td> </tr> </table>
         */
        matchedStatus?: MatchedStatus;
      };
    };
  }
}
