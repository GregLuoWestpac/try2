/* eslint-disable */
/* tslint:disable */
/*
 * ---------------------------------------------------------------
 * ## THIS FILE WAS GENERATED VIA SWAGGER-TYPESCRIPT-API        ##
 * ##                                                           ##
 * ## AUTHOR: acacode                                           ##
 * ## SOURCE: https://github.com/acacode/swagger-typescript-api ##
 * ---------------------------------------------------------------
 */

/**
 * nickname of the beneficiary
 * @minLength 1
 * @maxLength 70
 * @pattern ^[a-zA-Z0-9\- !,.:\;?_]+$
 * @example "office 1"
 */
export type Nickname = string;

/**
 * account name of the beneficiary
 * @minLength 1
 * @maxLength 140
 * @pattern ^[a-zA-Z0-9\- !,.:\;?_]+$
 * @example "Apple Tree"
 */
export type AccountName = string;

/**
 * status of the beneficiaries ACTIVE, ON-HOLD OR ARCHIVED
 * @example "ARCHIVED"
 */
export enum Status {
  ACTIVE = "ACTIVE",
  ARCHIVED = "ARCHIVED",
  ONHOLD = "ON-HOLD",
}

/**
 * beneficiary account type either PayId or BSB & Account number
 * @example "BSB_ACCOUNT_NUMBER"
 */
export enum Type {
  PAYID = "PAYID",
  BSB_ACCOUNT_NUMBER = "BSB_ACCOUNT_NUMBER",
}

/**
 * Name of Organisation
 * @minLength 0
 * @maxLength 15
 * @pattern ^[0-9]+$
 * @example "18342800027"
 */
export type Org = string;

/**
 * currency used by the beneficiary
 * @minLength 1
 * @maxLength 3
 * @pattern ^[A-Z]{3}$
 * @example "AUD"
 */
export type Currency = string;

/**
 * unique id of the beneficiary
 * @format uuid
 * @example "4b2b93ad-d6b8-4b6d-a446-0a5b56f1a804"
 */
export type BeneficiaryId = string;

/**
 * external id of the beneficiary from legacy system
 * @format uuid
 * @example "4b2b93ad-d6b8-4b6d-a446-0a5b56f1a804"
 */
export type ExternalId = string;

/**
 * indicates if the payment for the beneficiary is the first payment (true) or not (false)
 * @example true
 */
export type IsNew = boolean;

/**
 * Payment amount to be paid
 * @pattern ^\d{1,13}\.?\d{1,4}$
 */
export type Amount = string;

/**
 * A reference assigned by the initiating party to unambiguously identify the payment
 * @maxLength 35
 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
 */
export type Reference = string;

/**
 * id required by IROM api
 * @format uuid
 * @example "9129cb19-bc35-4ef5-91dc-0deb09d2e577"
 */
export type DivisionId = string;

/**
 * BeneficiaryResponse
 * Represents Beneficiary Response Object
 */
export interface BeneficiaryResponse {
  /** unique id of the beneficiary */
  id?: BeneficiaryId;
  /** external id of the beneficiary from legacy system */
  externalId?: ExternalId;
  /** nickname of the beneficiary */
  nickname?: Nickname;
  /** id required by IROM api */
  divisionId?: DivisionId;
  /** currency used by the beneficiary */
  currency?: Currency;
  /** Name of Organisation */
  org?: Org;
  /** status of the beneficiaries ACTIVE, ON-HOLD OR ARCHIVED */
  status?: Status;
  /** beneficiary account type either PayId or BSB & Account number */
  type?: Type;
  /** Represents Account detail object as json string */
  account?: Account;
  /** indicates if the payment for the beneficiary is the first payment (true) or not (false) */
  isNew?: IsNew;
  /** A reference assigned by the initiating party to unambiguously identify the payment */
  reference?: Reference;
  /** Payment amount to be paid */
  amount?: Amount;
}

/**
 * CreateBeneficiaryRequest
 * Represents Beneficiary Request Object
 */
export interface BeneficiaryRequest {
  /** unique id of the beneficiary */
  id: BeneficiaryId;
  /** external id of the beneficiary from legacy system */
  externalId?: ExternalId;
  /** nickname of the beneficiary */
  nickname: Nickname;
  /** id required by IROM api */
  divisionId?: DivisionId;
  /** currency used by the beneficiary */
  currency: Currency;
  /** Name of Organisation */
  org: Org;
  /** beneficiary account type either PayId or BSB & Account number */
  type: Type;
  /** Represents Account detail object as json string */
  account: Account;
  /** @default true */
  isNew?: IsNew;
  /** A reference assigned by the initiating party to unambiguously identify the payment */
  reference?: Reference;
  /** Payment amount to be paid */
  amount?: Amount;
}

/**
 * UpdateBeneficiaryRequest
 * Represents Beneficiary Request Object
 */
export interface BeneficiaryUpdateRequest {
  /** nickname of the beneficiary */
  nickname: Nickname;
  /** currency used by the beneficiary */
  currency: Currency;
  /** beneficiary account type either PayId or BSB & Account number */
  type: Type;
  /** Represents Account detail object as json string */
  account: Account;
  /** indicates if the payment for the beneficiary is the first payment (true) or not (false) */
  isNew?: IsNew;
  /** A reference assigned by the initiating party to unambiguously identify the payment */
  reference?: Reference;
  /** Payment amount to be paid */
  amount?: Amount;
}

/**
 * ListBeneficiariesRequest
 * Represents List Beneficiary Request Object
 */
export interface ListBeneficiariesRequest {
  /** list of beneficiary ids to search and retrieve */
  ids: BeneficiaryId[];
  /**
   * Text to search in nickname and account fields. It supports partial and case insensitive search.
   * The given text should be a substring of either nickname or accountName to be considered as a match.
   * @minLength 1
   * @maxLength 256
   * @pattern ^(.+)$
   * @example "1123456"
   */
  query?: string;
  /** list of beneficiary status to filter the search. Given statues are ORed in the search */
  statuses?: Status[];
}

/**
 * Represents Account detail object as json string
 * @example {"accountId":{"BSB":"123456","accountNumber":"123456789"},"accountName":"John Doe","bankName":"Westpac Banking Corporation"}
 */
export type Account = BankDetails | PayIdDetails;

/** Represents Account detail object */
export interface BankDetails {
  /** Account ID (BSB and Account Number) of the beneficiary */
  accountId: {
    /**
     * BSB for the account
     * @minLength 6
     * @maxLength 6
     * @pattern ^[0-9]+$
     * @example "123456"
     */
    BSB: string;
    /**
     * Account number
     * @minLength 1
     * @maxLength 28
     * @pattern ^[a-zA-Z0-9.]+$
     * @example "123456789"
     */
    accountNumber: string;
  };
  /** account name of the beneficiary */
  accountName: AccountName;
  /**
   * Name of the Bank
   * @minLength 1
   * @maxLength 70
   * @pattern ^[\w ]+$
   * @example "Westpac Banking Corporation"
   */
  bankName: string;
}

/** Represents Account detail object */
export interface PayIdDetails {
  /**
   * alias type for the PayID, either email / phone / orgId / bsb
   * @minLength 1
   * @maxLength 20
   * @example "123456789"
   */
  payIDType: string;
  /**
   * pay id name returned from the alias resolution
   * @minLength 1
   * @maxLength 256
   * @example "123456789"
   */
  payIDName: string;
  /**
   * alias id for the PayID, either email / phone / orgId / bsb
   * @minLength 1
   * @maxLength 256
   * @example "123456789"
   */
  payIDValue: string;
}

export namespace Beneficiaries {
  /**
   * @description create beneficiaries
   * @tags createBeneficiaries
   * @name CreateBeneficiaries
   * @summary create beneficiaries
   * @request POST:/beneficiaries
   * @secure
   */
  export namespace CreateBeneficiaries {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = {
      beneficiaries?: BeneficiaryRequest[];
    };
    export type RequestHeaders = {};
    export type ResponseBody = {
      /** CreateBeneficiariesData */
      data?: {
        beneficiaries?: BeneficiaryResponse[];
      };
    };
  }
  /**
   * @description get the details of the beneficiary by id
   * @tags getBeneficiary
   * @name GetBeneficiaryDetail
   * @summary retrieve a beneficiary detail
   * @request GET:/beneficiaries/{id}
   * @secure
   */
  export namespace GetBeneficiaryDetail {
    export type RequestParams = {
      /** unique id of the beneficiary */
      id: BeneficiaryId;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = {
      /** GetBeneficiaryDetailData */
      data?: BeneficiaryResponse;
    };
  }
  /**
   * @description update beneficiary details by id
   * @tags updateBeneficiary
   * @name UpdateBeneficiary
   * @summary update a beneficiary
   * @request PUT:/beneficiaries/{id}
   * @secure
   */
  export namespace UpdateBeneficiary {
    export type RequestParams = {
      /** unique id of the beneficiary to be updated */
      id: BeneficiaryId;
    };
    export type RequestQuery = {};
    export type RequestBody = BeneficiaryUpdateRequest;
    export type RequestHeaders = {};
    export type ResponseBody = {
      /** UpdateBeneficiaryData */
      data?: {
        beneficiaries?: BeneficiaryResponse[];
      };
    };
  }
  /**
   * @description Update beneficiary status to ARCHIVED
   * @tags updateBeneficiaryStatus
   * @name UpdateBeneficiaryStatus
   * @summary Update a property of a beneficiary; limited to status property with value ARCHIVED
   * @request PATCH:/beneficiaries/{id}
   * @secure
   */
  export namespace UpdateBeneficiaryStatus {
    export type RequestParams = {
      /** unique id of the beneficiary to update the status */
      id: BeneficiaryId;
    };
    export type RequestQuery = {};
    export type RequestBody = {
      /** status of the beneficiaries ACTIVE, ON-HOLD OR ARCHIVED */
      status: Status;
    };
    export type RequestHeaders = {};
    export type ResponseBody = void;
  }
  /**
   * @description retrieve a list of beneficiaries by ids and other search parameters
   * @tags listBeneficiaries
   * @name ListBeneficiaries
   * @summary retrieve a list of beneficiaries by ids and other search parameters
   * @request POST:/beneficiaries/summary
   * @secure
   */
  export namespace ListBeneficiaries {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * current page for pagination
       * @default 0
       * @example 0
       */
      pageKey?: number;
      /**
       * page size for the pagination
       * @default 1000
       * @example 100
       */
      pageSize?: number;
      /**
       * for sorting with the sorting pattern, + for asc and - for desc
       * @default "+nickname"
       * @pattern ^[\+\-][a-zA-Z]+[a-zA-Z0-9]*$
       * @example "+nickname"
       */
      sort?: string;
    };
    export type RequestBody = ListBeneficiariesRequest;
    export type RequestHeaders = {};
    export type ResponseBody = {
      /** ListBeneficiariesData */
      data?: {
        beneficiaries?: BeneficiaryResponse[];
      };
      /** pageDetails */
      paging?: {
        /**
         * Number of items per page
         * @format int32
         * @min 1
         * @example 50
         */
        pageSize?: number;
        /**
         * Total number of items available
         * @format int32
         * @example 160
         */
        count?: number;
        /**
         * Key for start of previous page. -1 if no previous page exists
         * @format int32
         * @min 0
         * @example 0
         */
        previousPageKey?: number;
        /**
         * Key for start of next page. -1 if no next page exists
         * @format int32
         * @min 0
         * @example 2
         */
        nextPageKey?: number;
        /**
         * Indicator to show if there are more items available. If true, more records are available (by narrowing search parameters)
         * @example true
         */
        moreItems?: boolean;
      };
    };
  }
}
