/* eslint-disable */
/* tslint:disable */
/*
 * ---------------------------------------------------------------
 * ## THIS FILE WAS GENERATED VIA SWAGGER-TYPESCRIPT-API        ##
 * ##                                                           ##
 * ## AUTHOR: acacode                                           ##
 * ## SOURCE: https://github.com/acacode/swagger-typescript-api ##
 * ---------------------------------------------------------------
 */

/** adaptive authentication analysis request data. Currently it is not caterred for non payment transactions */
export interface AdaptiveAuthenticationAnalysisRequest {
  customer: Customer;
  /** Type of the event initiated. */
  tenantId?: "WPACW1";
  /** The key to identify the customer last successful authentication timestamp value stored in redis cache. Based on different purpose, the value can be session index value extract from JWT token if last successful authentication timestamp is session based, or command/action id if timestamp is command/action based, or other value. The API will take this value combined with customer CIS key as Redis cache key and perform CRUD functions. This field is not required by open banking flow. */
  verificationReferenceId?: string;
  browserInformation?: BrowserInformation;
  /** It shows whether the request is coming from browser or mobile app */
  userAgentType?: UserAgentType;
  device: Device;
  /** Contains consumer session and transaction IDs */
  clientTransactionId: ClientTransactionId;
  /** Type of the event initiated. */
  eventType:
    | "SESSION_SIGNIN"
    | "FAILED_LOGIN_ATTEMPT"
    | "ENROLL"
    | "UPDATE_USER"
    | "OLB_ENROLL"
    | "FAILED_OLB_ENROLL_ATTEMPT"
    | "ACTIVATE_CARD"
    | "OPEN_NEW_ACCOUNT"
    | "REQUEST_CREDIT"
    | "DEPOSIT"
    | "OPTIONS_TRADE"
    | "CHANGE_LOGIN_ID"
    | "CHANGE_EMAIL"
    | "CHANGE_PHONE"
    | "CHANGE_ADDRESS"
    | "CHANGE_PASSWORD"
    | "CHANGE_LIFE_QUESTIONS"
    | "FAILED_CHANGE_PASSWORD_ATTEMPT"
    | "CHANGE_ALERT_SETTINGS"
    | "CHANGE_STATEMENT_SETTINGS"
    | "CHANGE_AUTH_DATA"
    | "SEND_SECURE_MESSAGE"
    | "READ_SECURE_MESSAGE"
    | "VIEW_CHECK"
    | "VIEW_STATEMENT"
    | "REQUEST_CHECK_COPY"
    | "REQUEST_STATEMENT_COPY"
    | "REQUEST_CHECKS"
    | "REQUEST_NEW_CARD"
    | "REQUEST_NEW_PIN"
    | "EXTRA_AUTH"
    | "USER_DETAILS"
    | "CLIENT_DEFINED"
    | "WITHDRAW"
    | "CARD_PIN_CHANGE"
    | "PAYMENT"
    | "CREATE_USER"
    | "ADD_PAYEE"
    | "EDIT_PAYEE"
    | "STOCK_TRADE";
  /** The sub event type is used for providing more details for event type. If eventType is "CLIENT_DEFINED", then this fields will be ignored. e.g. PAYMENT_SUBMITTER, DEVICE_ACTIVATION, BATCH_PAYMENTS, ADVANCED_SETTINGS, CHEQUE. Values will need to be identified based on Specific Bussiness Usecase. Reach to  Digital Security Team dldigitalsecurity@westpac.com.au , for more details. */
  subEventType?: string;
  /** If eventType is "CLIENT_DEFINED", this field is mandatory to providing client defined event. Otherwise, the value will be ignored. */
  clientDefinedEventType?: string;
  /** A list of custom facts for further information about the event. */
  eventMetaData?: Fact[];
  /**
   * A boolean flag indicating whether this authentication cycle is intended to initialize/activate the updated device. Set to true the authentication cycle will be allowed to proceed for devices that are in the “LINKED” status. This flag is to be set only when a SAFI logical device has been updated.
   * @default false
   */
  hasDeviceUpdated?: boolean;
  /** Network of the profile */
  network?: Network;
  /**
   * Human-readable description of the event or transaction.
   * @example "Single Self Authorise Payment"
   */
  eventDescription?: string;
  /** Contains all transaction-specific details including accounts, amount, and execution method. */
  transactionData?: {
    /** Amount details of the transaction. */
    amount?: {
      /**
       * Amount of the transaction in cents.
       * @format int64
       * @example 10000
       */
      amount?: number;
      /**
       * 3-letter currency code (ISO 4217), e.g., AUD.
       * @maxLength 3
       * @example "AUD"
       */
      currency?: string;
    };
    /**
     * Date the payment is first executed, if scheduled or recurring. Format: yyyy-mm-dd.
     * @format date
     * @example "2025-06-01"
     */
    dueDate?: string;
    /**
     * How quickly the transaction will be executed.
     * @example "OVER_NIGHT"
     */
    executionSpeed?: "SEVERAL_DAYS" | "OVER_NIGHT" | "FEW_HOURS" | "REAL_TIME";
    /** Information about the sender's (funding) account. */
    myAccountData?: {
      /** Current balance of the funding account. */
      accountBalance?: {
        /**
         * Funding account balance in cents.
         * @format int64
         * @example 100000
         */
        amount?: number;
        /**
         * 3-letter currency code (ISO 4217), e.g., AUD.
         * @maxLength 3
         * @example "AUD"
         */
        currency?: string;
      };
      /**
       * Country of the funding account (e.g., AU).
       * @maxLength 3
       * @example "AU"
       */
      accountCountry?: string;
      /**
       * Funding account number to be debited.
       * @maxLength 50
       * @example "506937"
       */
      accountNumber?: string;
      /**
       * Funding account BSB.
       * @maxLength 50
       * @example "734102"
       */
      routingCode?: string;
    };
    /**
     * Indicates same-bank or inter-bank transfer.
     * @example "OTHER_BANK"
     */
    otherAccountBankType?: "SAME_BANK" | "OTHER_BANK";
    /** Information about the payee (recipient) account. */
    otherAccountData?: {
      /**
       * Payee account country.
       * @maxLength 3
       * @example "AU"
       */
      accountCountry?: string;
      /**
       * Payee account number.
       * @maxLength 50
       * @example "45435"
       */
      accountNumber?: string;
      /**
       * Payee account BSB.
       * @maxLength 50
       * @example "38776190001"
       */
      routingCode?: string;
      /**
       * Payee account SWIFT code (for international payments only).
       * @maxLength 255
       * @example "CTBAAU2S"
       */
      swiftCode?: string;
    };
    /**
     * Ownership relationship between sender and recipient.
     * @example "ME_TO_YOU"
     */
    otherAccountOwnershipType?: "ME_TO_ME" | "ME_TO_YOU";
    /**
     * Indicates whether the transaction is immediate, scheduled, or recurring.
     * @example "SCHEDULED"
     */
    schedule?: "IMMEDIATE" | "SCHEDULED" | "RECURRING";
    /**
     * Type of transfer mechanism used.
     * @example "WIRE"
     */
    transferMediumType?:
      | "INTERNAL"
      | "BILLPAY_MAIL"
      | "BILLPAY_ELEC"
      | "BALANCE_TRANSFER"
      | "ACH"
      | "WIRE"
      | "INTL_WIRE"
      | "CHECK";
  };
}

/** It shows whether the request is coming from browser or mobile app */
export enum UserAgentType {
  BROWSER = "BROWSER",
  MOBILE_APP = "MOBILE_APP",
}

export interface BrowserInformation {
  /**
   * The HTTP accept header value is retrieved from the HTTP request header. This is used for device profiling, and is a potential fraud predictor. Value can be empty if the request is from mobile APP.
   * @example "image/jpeg, application/x-ms-application, image/gif, application/xaml+xml"
   */
  httpAccept?: string;
  /**
   * The HTTP accept header character set is retrieved from the HTTP request header. This is used for device profiling, and is a potential fraud predictor. Value can be empty if the request is from mobile APP.
   * @example "utf-8, iso-8859-1"
   */
  httpAcceptedCharacters?: string;
  /**
   * The HTTP accept header character set is retrieved from the HTTP request header. This is used for device profiling, and is a potential fraud predictor. Value can be empty if the request is from mobile APP.
   * @example "deflate, gzip"
   */
  httpAcceptedEncoding?: string;
  /**
   * The HTTP accept language is retrieved from the HTTP request header. This is used for device profiling, and is a potential fraud predictor. Value can be empty if the request is from mobile APP.
   * @example "fr-CH, fr"
   */
  httpAcceptedLanguage?: string;
  /**
   * The HTTP referer header value is retrieved from the HTTP request header. Value can be empty if the request is from mobile APP.
   * @example "https://developer.mozilla.org/en-US/docs/Web/JavaScript"
   */
  httpReferer?: string;
  /**
   * The user agent string is retrieved from the HTTP request header and is used in device profiling. Value can be empty if the request is from mobile APP.
   * @example "Mozilla/5.0 (Macintosh; Intel Mac OS X x.y; rv:42.0) Gecko/20100101 Firefox/42.0"
   */
  userAgent?: string;
}

export interface Device {
  /** The token (or cookie) issued by previous (SAFI) AAoP webservice calls. */
  deviceToken?: string;
  /** 1. For mobile application, the value should be base64 encoded JSON structure containing a mobile device's fingerprint.(PMDP Cookie). 2. For browser, the value is generated by the RSA JavaScript. */
  deviceFingerPrint?: string;
  /** This element is to be populated with the source IP address of the device that generated the HTTP request. This is used for device and geo IP profiling and provides real time link analysis. */
  IPAddress: string;
}

/** Custom fact */
export interface Fact {
  /**
   * name of the key e.g CUSTOMERTYPE, APPVERSION, TIMELASTAUTHWITHINREGION, 2FADEVICETYPEUSED. Values will need to be identified based on Specific Bussiness Usecase. Reach to  Digital Security Team dldigitalsecurity@westpac.com.au , for more details.
   * @example "TRANSACTIONTYPE"
   */
  name: string;
  /**
   * value of the key e.g EVERDAY
   * @example "BPAY"
   */
  value?: string;
  /** The data type of the value field. eg.STRING/INTEGER */
  datatype: "STRING" | "BOOLEAN" | "FLOAT" | "DOUBLE" | "INTEGER" | "DATE" | "IP";
}

/** Network of the profile */
export interface Network {
  /**
   * It is the PartyUID in GCM.
   * @example "0A2743AA-3D93-11e5-9A2A-8000004AFE80"
   */
  id: string;
  /** Network type of a profile. */
  type?: "Family" | "Advanced";
}

/** adaptive authentication analysis response data */
export interface AdaptiveAuthenticationAnalysisResponse {
  data?: {
    /** Device token generated SAFI and should be used in next request. */
    deviceToken?: string;
    /** Contains SAFI session ID and transaction ID */
    SAFITransactionId?: SAFITransactionId;
    /** Result of Asessement. Possible values are ALLOW, DENY, CHALLENGE, DELAY_AND_REVIEW or REVIEW */
    analyseResult?: "ALLOW" | "DENY" | "CHALLENGE" | "REVIEW" | "DELAY_AND_REVIEW";
    /** The name of the rule that SAFI used to decide the analyse result based on the request. */
    ruleTriggered?: string;
    /**
     * The risk score given by SAFI to show the rick level
     * @format int32
     */
    riskScore?: number;
    challenge?: ChallengeWithSecondFactorInformation;
    /**
     * The indicator flag shows whether global bypass is enabled or not. This field is only used by RRB/SGBBSA
     * @default false
     */
    isGlobalBypass?: boolean;
  };
  result?: {
    errors?: Error[];
  };
}

export interface SecondFactorInformation {
  /** Second Factor Exemption Status from IDM (For SGBBSA/RRB only) */
  secondFactorExemptionStatus?: "NONE" | "TEMPORARY" | "PERMANENT";
}

export type ChallengeWithSecondFactorInformation = ChallengeAnalysis & SecondFactorInformation;

export type ChallengeAnalysis = Authentication & AuthenticationDeviceInformation;

export type Challenge = Authentication & AuthenticationDeviceInformation & ReAttemptReason;

/** The information of authentication device. */
export interface AuthenticationDeviceInformation {
  /** The raw phone number of the mobile phone authentication device. It only has value if the device type is SMSOTP. */
  phoneNumber?: string;
  /** The securID token serial number. It only has value if the device type is SECURID. */
  tokenSerialNumber?: string;
}

/** The authentication method which is acceptable for the specific AAoP business rules that triggered the challenge request. It will be contained in analysis response if the response action code is CHALLENGE. It will be empty if no active device is found. Also it will be empty with error object in the result if retrieving authentication device has error. */
export interface Authentication {
  /** the name of the referenced two factor authenticator type (which also matched the name of the MCF plugin). */
  authenticationDeviceType: "PUSHOTP" | "SMSOTP" | "SECURID" | "EXEMPTION_TEMP" | "EXEMPTION_PERM" | "EXTERNALMETHOD2";
  /** The device identifier which should be used to trigger challenge and authentication call in current flow. This field is mandatory in the requests for WPAC. */
  authenticationDeviceId?: string;
}

/** The boolean value which will be used only in case when device type is PUSHOTP */
export interface ReAttemptReason {
  /** Reason for reattempt challenge when the device type is changing.  Changing from Push to SMS. Customer initiated for customer choose to resent via SMS.  System fallback is due to 3 times push code failed,  system defaulted to SMS. This applies to WPAC use case only. Set to RESEND_VIA_PUSH when customer click on ‘Resend’ button when device type is PushOTP Set to RESEND_VIA_SMS when customer click on ‘Resend_VIA SMS’ when device type is PushOTP Set to SYSTEM_FALLBACK when customer has 3 incorrect OTP and verification result having ‘ACCESS_DENIED_AUTHENTICATOR_DEPROVISIONED’ */
  reAttemptReason?: "RESEND_VIA_PUSH" | "RESEND_VIA_SMS" | "SYSTEM_FALLBACK";
}

/** Contains SAFI session ID and transaction ID */
export interface SAFITransactionId {
  /**
   * SAFI session Id to be used for subsequent calls to SAFI system. This field is only required for Challenge and Authentication requests
   * @maxLength 200
   */
  sessionId?: string;
  /**
   * SAFI transaction Id to be used for subsequent calls to SAFI system. This field is only required for Challenge and Authentication requests.
   * @maxLength 200
   */
  transactionId: string;
}

/** Contains consumer session and transaction IDs */
export interface ClientTransactionId {
  /**
   * Session id from client to identify the flow in logs.
   * @maxLength 200
   */
  sessionId: string;
  /**
   * Transaction id from client to identify the flow in logs. The value should be the same as x-appCorrelationId, and it has to remain same in the flow.
   * @maxLength 200
   */
  transactionId: string;
}

export interface Customer {
  customerId: CustomerId;
  /**
   * The type of the customer. It is required for SGBBSA(RRB).
   * @default "Individual"
   */
  customerType?: "Individual" | "Organisation";
}

export interface CustomerId {
  /**
   * The customer id
   * @example "12345678901"
   */
  id: string;
  /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
  idScheme: "CustomerInternalId";
}

export interface CustomerWithCustomerNumber {
  customerId: CustomerIdWithNumber;
  /**
   * The type of the customer. It is required for SGBBSA(RRB).
   * @default "Individual"
   */
  customerType?: "Individual" | "Organisation";
}

export interface CustomerIdWithNumber {
  /**
   * The customer id
   * @example "12345678901"
   */
  id: string;
  /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
  idScheme: "CustomerInternalId" | "CustomerNumber";
}

/** initialise the adaptive authentication challenge request */
export interface AdaptiveAuthenticationChallengeInitiationRequest {
  customer: CustomerWithCustomerNumber;
  /** The key to identify the customer last successful authentication timestamp value stored in redis cache. Based on different purpose, the value can be session index value extract from JWT token if last successful authentication timestamp is session based, or command/action id if timestamp is command/action based, or other value. The API will take this value combined with customer CIS key as Redis cache key and perform CRUD functions. This field is not required by open banking flow */
  verificationReferenceId?: string;
  /** Brand name. This is ERDM view BRAND. This field is required for SGBBSA but will be ignored for WPAC. */
  brand?: "WBC" | "SGB" | "BSA" | "BOM" | "RAMS" | "BTPL";
  browserInformation?: BrowserInformation;
  /** It shows whether the request is coming from browser or mobile app */
  userAgentType?: UserAgentType;
  device: Device;
  /** Contains SAFI session ID and transaction ID */
  SAFITransactionId: SAFITransactionId;
  /** Contains consumer session and transaction IDs */
  clientTransactionId: ClientTransactionId;
  challenge: Challenge;
  /**
   * The text body of the SMS message to be sent to the customer including the placeholder string that will be replaces with the onetime password.The placeholder is "SMSOTP"
   * @example "To access your contact details enter SMS Code: SMSOTP. Unexpected SMS? Call 1300 655 505. "
   */
  SMSTextMessage?: string;
  /**
   * Indicate whether the request is triggered for the first time. By default the request is triggered by WDP exp API framework, and the value of this field is false. This value is only for SGBBSA(RRB) as extra action should be done by this API if customer initiated the request. For WPAC, this field is ignored.
   * @default false
   */
  isReinitiation?: boolean;
  /**
   * A boolean flag indicating whether this authentication cycle is intended to initialize/activate this device. Set to true the authentication cycle will be allowed to proceed for devices that are in the “LINKED” status. This flag is to be set only when a SAFI logical device needs activation.
   * @default false
   */
  isForDeviceActivation?: boolean;
  /** Network of the profile */
  network?: Network;
}

/** adaptive authentication challenge response data */
export interface AdaptiveAuthenticationChallengeInitiationResponse {
  data?: {
    /** device Token generated by API (SAFI) and should be used in next request. */
    deviceToken?: string;
    /** Indicates whether the challenge is delivered to given mobile device. Possible values are SUCCESS or FAILED. */
    SMSDeliveryStatus?: "SUCCESS" | "FAILED";
    /**
     * The number of remaining challenge attempts before the customer is suspended in this network. WPAC doesn't have this field in response.
     * @format int32
     */
    remainingChallengeAttempts?: number;
    /** Indicator to allow OTP to be resend via SMS.Field only relevant for PushOTP (WPAC only).  This will be true when customer had requested to resend via Push once */
    isResendSMSAllow?: boolean;
    /** Indicator to allow OTP to be resend via PUSH.Field only relevant for PushOTP (WPAC only).  This will be true when customer had requested to resend via Push again and no of attempts are not over. */
    isResendPushAllow?: boolean;
    /** Fallback device details for switching to SMS device. (WPAC use case) */
    fallbackChallengeDevice?: FallbackChallengeDevice;
  };
  result?: {
    errors?: Error[];
  };
}

/** Fallback device details for switching to SMS device. (WPAC use case) */
export interface FallbackChallengeDevice {
  /** the name of the referenced two factor authenticator type (which also matched the name of the MCF plugin). */
  authenticationDeviceType?: "SMSOTP";
  /** The device identifier which should be used to trigger challenge and authentication call in current flow. This field is mandatory in the requests for WPAC. */
  authenticationDeviceId?: string;
  /** The raw phone number of the mobile phone authentication device. It only has value if the device type is SMSOTP. */
  phoneNumber?: string;
}

/** adaptive authentication challenge verification request data */
export interface AdaptiveAuthenticationChallengeVerificationRequest {
  customer: CustomerWithCustomerNumber;
  /** The key refers to the customer last successful authentication timestamp value stored in redis cache. Based on different purpose, the value can be session index value extract from JWT token if last successful authentication timestamp is session based, or command/action id if timestamp is command/action based, or other value. The API will take this value combined with customer CIS key as Redis cache key and perform CRUD functions. This field is not required by open banking flow */
  verificationReferenceId?: string;
  browserInformation?: BrowserInformation;
  /** It shows whether the request is coming from browser or mobile app */
  userAgentType?: UserAgentType;
  device: Device;
  /** Contains SAFI session ID and transaction ID */
  SAFITransactionId: SAFITransactionId;
  /** Contains consumer session and transaction IDs */
  clientTransactionId: ClientTransactionId;
  /** The authentication method which is acceptable for the specific AAoP business rules that triggered the challenge request. It will be contained in analysis response if the response action code is CHALLENGE. It will be empty if no active device is found. Also it will be empty with error object in the result if retrieving authentication device has error. */
  authentication: Authentication;
  /**
   * the code value which client entered for authentication. If the authenticationType is SMSOTP, maxlength of this field is 12. If the authenticationType is SECURID, then maxLength is 9
   * @pattern ^[0-9]+$
   */
  authenticationCode?: string;
  /**
   * This field is only used for authentication device type is SECURID. When the previous verification response with NEXT_CODE_REQUIRED, the consumer has to send subsequent verification request with this field set to true.
   * @default false
   */
  isNextTokenCode?: boolean;
  /**
   * It instructs SAFI to create a long-term link between this user and the device is being used for authentication.
   * @default true
   */
  shouldBindDevice?: boolean;
  /** Network of the profile */
  network?: Network;
}

/** adaptive authentication challenge verification response data. */
export interface AdaptiveAuthenticationChallengeVerificationResponse {
  data?: {
    /** device Token generated by SAFI and should be used in next request. */
    deviceToken?: string;
    /**
     * An enumerated value indicating the detailed outcome of the authenticate call.
     * ACCESS_OK - Correct OTP or SECURID token code was provided. In this case, no SAFI transaction identifier will return.
     * ACCESS_DENIED - Wrong SECURID provided.
     * ACCESS_DENIED_OTP_INCORRECT - Wrong OTP provided.
     * ACCESS_DENIED_AUTHENTICATOR_SUSPENDED - Wrong OTP provided and authenticator is suspended.
     * ACCESS_DENIED_AUTHENTICATOR_DEPROVISIONED - Wrong push otp provided and autheticator is deprovisioned.
     * NEXT_CODE_REQUIRED - authenticate() needs to be invoked one more time setting the value of nextTokenCode to the next tokencode displayed by the SECURID token.
     * EXEMPTION_EXPIRED_OR_NON_EXISTING - This exemption instance has expired.
     * EXEMPTION_VALID - The authentication cycle could be successfully initliazed.
     */
    verificationResult?:
      | "ACCESS_OK"
      | "ACCESS_DENIED"
      | "ACCESS_DENIED_OTP_INCORRECT"
      | "ACCESS_DENIED_AUTHENTICATOR_SUSPENDED"
      | "ACCESS_DENIED_AUTHENTICATOR_DEPROVISIONED"
      | "NEXT_CODE_REQUIRED"
      | "EXEMPTION_EXPIRED_OR_NON_EXISTING"
      | "EXEMPTION_VALID";
    /**
     * If the authentication failed this element will be populated with the number of remaining authentication attempts before the device/customer is suspended in this network.
     * @format int32
     */
    remainingVerificationAttempts?: number;
    /** Fallback device details for switching to SMS device. (WPAC use case) */
    fallbackChallengeDevice?: FallbackChallengeDevice;
  };
  result?: {
    errors?: Error[];
  };
}

/** adaptive authentication notify request data. Currently it is only for notify SAFI the authentication result */
export interface AdaptiveAuthenticationNotifyRequest {
  customer: Customer;
  /** The key to identify the customer last successful authentication timestamp value stored in redis cache. Based on different purpose, the value can be session index value extract from JWT token if last successful authentication timestamp is session based, or command/action id if timestamp is command/action based, or other value. The API will take this value combined with customer CIS key as Redis cache key and perform CRUD functions. This field is not required by open banking flow */
  verificationReferenceId?: string;
  browserInformation?: BrowserInformation;
  /** It shows whether the request is coming from browser or mobile app */
  userAgentType?: UserAgentType;
  device?: Device;
  /** Contains consumer session and transaction IDs */
  clientTransactionId: ClientTransactionId;
  /** Type of the event initiated. */
  tenantId?: "WPACW1";
  /** Contains SAFI session ID and transaction ID */
  SAFITransactionId: SAFITransactionId;
  /**
   * The key to identify if the customer authentication was successful or not.
   * @default false
   */
  isAuthenticationSuccessful: boolean;
}

/** adaptive authentication notify response data */
export interface AdaptiveAuthenticationNotifyResponse {
  data?: {
    /** Device token generated to be used in the subsequent request. */
    deviceToken?: string;
    /** Contains SAFI session ID and transaction ID */
    SAFITransactionId?: SAFITransactionId;
  };
}

/** retrieve last authorised time response data */
export interface RetrieveTimeLastAuthWithinRegionResponse {
  data?: {
    /**
     * Customer's last successful authenticated time.
     * @format date-time
     */
    lastAuthorisedTime?: string;
  };
}

/** udpate last authorised time request */
export interface UpdateTimeLastAuthWithinRegionRequest {
  /**
   * Customer's last successful authenticated time. The value can be empty string where the operation is considered to remove the record from Redis for the given session ID
   * @format date-time
   */
  lastAuthorisedTime: string;
}

/** udpate last authorised time response data */
export interface UpdateTimeLastAuthWithinRegionResponse {
  data?: {
    /** The status of saving or udpating customer's last successful authenticated time */
    result?: "SUCCESS" | "PARTIAL_SUCCESS";
  };
  result?: {
    errors?: Error[];
  };
}

/** udpate last authorised time response data */
export interface DeleteTimeLastAuthWithinRegionResponse {
  data?: {
    /** The status of deleting customer's last successful authenticated time */
    result?: "SUCCESS" | "PARTIAL_SUCCESS";
  };
  result?: {
    errors?: Error[];
  };
}

/** healthcheck status */
export interface HealthCheckStatus {
  status?: "success";
}

/** Error response */
export interface ErrorResponse {
  /** Array of errors */
  result?: ErrorResult;
}

/** Array of errors */
export interface ErrorResult {
  errors?: Error[];
}

/** Represent an individual error. */
export interface Error {
  /**
   * Error Code.
   * @format int32
   */
  code: number;
  /** Error Message */
  message: string;
  /** Detailed information about the error */
  details?: string;
}

export namespace AdaptiveAuthenticationAnalysis {
  /**
   * @description This resource is used to perform real-time risk analysis for an online operation instigated by a customer.
   * @tags Analyse
   * @name Analyse
   * @request POST:/adaptiveAuthenticationAnalysis
   * @secure
   */
  export namespace Analyse {
    export type RequestParams = {};
    export type RequestQuery = {
      /** The Brand Silo the caller is operating in. Brand Silo is a concept used in Westpac to segregate Customer records based on a combination of the organisation that "owns" the customer relationship and the systems environment in which their identity records are created and maintained. A Brand Silo is a classification whereas a Brand is a descriptive entity associated with an Organisation. */
      brandSilo: "WPAC" | "SGBBSA" | "RAMS" | "BTPL";
    };
    export type RequestBody = AdaptiveAuthenticationAnalysisRequest;
    export type RequestHeaders = {
      /** Globally unique message identifier  - GUID. This uniquely identifies this call. */
      "x-messageId": string;
      /** Consumer generated message identifier for correlation purposes. e.g. Can be used to group together a number of API calls comprising a business transaction. */
      "x-appCorrelationId": string;
      /** The organisation the caller is operating in. */
      "x-organisationId": "WPAC" | "SGB" | "BSA" | "BOM" | "BTPL" | "UBS" | "VIRG" | "RAMS" | "BAS" | "WNZL";
      /** DEPRECATED. The type of channel from which the request has originated. */
      "x-channelType"?:
        | "Branch"
        | "Online"
        | "Contact Centre"
        | "ATM"
        | "Mobile"
        | "IVR Telephony"
        | "Relationship Managed"
        | "External Broker"
        | "External EFA"
        | "External"
        | "Unknown"
        | "Internal";
      /** The originating consumption channel invoking the API (eg. Partner, Staff, Customer). Note that an API consuming another API should pass the value supplied by the calling application. Further information regarding this header can be found at https://confluence.srv.westpac.com.au/x/cbH-B. */
      "x-consumerType": "Partner" | "Public" | "Staff" | "Customer" | "Prospect" | "Other";
      /** Alfabet Id of calling application e.g. A00304. Must be propagated to APIs being invoked. Exception for partners calling in via partner APIs, do not populate this header as the partner’s consuming application name (eg. ptr-corelogic-valex) will be injected into this field by the gateway. */
      "x-originatingSystemId": string;
      /** The unique identifier for the user invoking the API (eg. Staff salary number, Customer CIS/GCIS key, Partner CIS/GCIS key or other identifier). */
      "x-userId"?: string;
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      "x-userIdScheme"?:
        | "StaffSalaryNumber"
        | "CustomerInternalId"
        | "CustomerNumber"
        | "SystemProcess"
        | "CorporateUserId"
        | "ProspectId";
      /** Identifies the BSB from which this request originated. The format should be XXY-ZZZ. The first two digits (XX) specify the bank or financial institution. The third digit (Y) tells which state the branch is located in. The last three digits (ZZZ) specify the address of the branch. */
      "x-originatingBSB"?: string;
    };
    export type ResponseBody = AdaptiveAuthenticationAnalysisResponse;
  }
}

export namespace AdaptiveAuthenticationChallengeInitiation {
  /**
   * @description Initiate a challenge call for the online events
   * @tags Challenge initiation
   * @name ChallengeInitiation
   * @request POST:/adaptiveAuthenticationChallengeInitiation
   * @secure
   */
  export namespace ChallengeInitiation {
    export type RequestParams = {};
    export type RequestQuery = {
      /** The Brand Silo the caller is operating in. Brand Silo is a concept used in Westpac to segregate Customer records based on a combination of the organisation that "owns" the customer relationship and the systems environment in which their identity records are created and maintained. A Brand Silo is a classification whereas a Brand is a descriptive entity associated with an Organisation. */
      brandSilo: "WPAC" | "SGBBSA" | "RAMS" | "BTPL";
    };
    export type RequestBody = AdaptiveAuthenticationChallengeInitiationRequest;
    export type RequestHeaders = {
      /** Globally unique message identifier  - GUID. This uniquely identifies this call. */
      "x-messageId": string;
      /** Consumer generated message identifier for correlation purposes. e.g. Can be used to group together a number of API calls comprising a business transaction. */
      "x-appCorrelationId": string;
      /** The organisation the caller is operating in. */
      "x-organisationId": "WPAC" | "SGB" | "BSA" | "BOM" | "BTPL" | "UBS" | "VIRG" | "RAMS" | "BAS" | "WNZL";
      /** The originating consumption channel invoking the API (eg. Partner, Staff, Customer). Note that an API consuming another API should pass the value supplied by the calling application. Further information regarding this header can be found at https://confluence.srv.westpac.com.au/x/cbH-B. */
      "x-consumerType": "Partner" | "Public" | "Staff" | "Customer" | "Prospect" | "Other";
      /** DEPRECATED. The type of channel from which the request has originated. */
      "x-channelType"?:
        | "Branch"
        | "Online"
        | "Contact Centre"
        | "ATM"
        | "Mobile"
        | "IVR Telephony"
        | "Relationship Managed"
        | "External Broker"
        | "External EFA"
        | "External"
        | "Unknown"
        | "Internal";
      /** Alfabet Id of calling application e.g. A00304. Must be propagated to APIs being invoked. Exception for partners calling in via partner APIs, do not populate this header as the partner’s consuming application name (eg. ptr-corelogic-valex) will be injected into this field by the gateway. */
      "x-originatingSystemId": string;
      /** The unique identifier for the user invoking the API (eg. Staff salary number, Customer CIS/GCIS key, Partner CIS/GCIS key or other identifier). */
      "x-userId"?: string;
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      "x-userIdScheme"?:
        | "StaffSalaryNumber"
        | "CustomerInternalId"
        | "CustomerNumber"
        | "SystemProcess"
        | "CorporateUserId"
        | "ProspectId";
      /** Identifies the BSB from which this request originated. The format should be XXY-ZZZ. The first two digits (XX) specify the bank or financial institution. The third digit (Y) tells which state the branch is located in. The last three digits (ZZZ) specify the address of the branch. */
      "x-originatingBSB"?: string;
    };
    export type ResponseBody = AdaptiveAuthenticationChallengeInitiationResponse;
  }
}

export namespace AdaptiveAuthenticationChallengeVerification {
  /**
   * @description This is the verification call to validate the authentication code that have been provided by the customer.
   * @tags Challenge verification
   * @name ChallengeVerification
   * @request POST:/adaptiveAuthenticationChallengeVerification
   * @secure
   */
  export namespace ChallengeVerification {
    export type RequestParams = {};
    export type RequestQuery = {
      /** The Brand Silo the caller is operating in. Brand Silo is a concept used in Westpac to segregate Customer records based on a combination of the organisation that "owns" the customer relationship and the systems environment in which their identity records are created and maintained. A Brand Silo is a classification whereas a Brand is a descriptive entity associated with an Organisation. */
      brandSilo: "WPAC" | "SGBBSA" | "RAMS" | "BTPL";
    };
    export type RequestBody = AdaptiveAuthenticationChallengeVerificationRequest;
    export type RequestHeaders = {
      /** Globally unique message identifier  - GUID. This uniquely identifies this call. */
      "x-messageId": string;
      /** Consumer generated message identifier for correlation purposes. e.g. Can be used to group together a number of API calls comprising a business transaction. */
      "x-appCorrelationId": string;
      /** The organisation the caller is operating in. */
      "x-organisationId": "WPAC" | "SGB" | "BSA" | "BOM" | "BTPL" | "UBS" | "VIRG" | "RAMS" | "BAS" | "WNZL";
      /** The originating consumption channel invoking the API (eg. Partner, Staff, Customer). Note that an API consuming another API should pass the value supplied by the calling application. Further information regarding this header can be found at https://confluence.srv.westpac.com.au/x/cbH-B. */
      "x-consumerType": "Partner" | "Public" | "Staff" | "Customer" | "Prospect" | "Other";
      /** DEPRECATED. The type of channel from which the request has originated. */
      "x-channelType"?:
        | "Branch"
        | "Online"
        | "Contact Centre"
        | "ATM"
        | "Mobile"
        | "IVR Telephony"
        | "Relationship Managed"
        | "External Broker"
        | "External EFA"
        | "External"
        | "Unknown"
        | "Internal";
      /** Alfabet Id of calling application e.g. A00304. Must be propagated to APIs being invoked. Exception for partners calling in via partner APIs, do not populate this header as the partner’s consuming application name (eg. ptr-corelogic-valex) will be injected into this field by the gateway. */
      "x-originatingSystemId": string;
      /** The unique identifier for the user invoking the API (eg. Staff salary number, Customer CIS/GCIS key, Partner CIS/GCIS key or other identifier). */
      "x-userId"?: string;
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      "x-userIdScheme"?:
        | "StaffSalaryNumber"
        | "CustomerInternalId"
        | "CustomerNumber"
        | "SystemProcess"
        | "CorporateUserId"
        | "ProspectId";
      /** Identifies the BSB from which this request originated. The format should be XXY-ZZZ. The first two digits (XX) specify the bank or financial institution. The third digit (Y) tells which state the branch is located in. The last three digits (ZZZ) specify the address of the branch. */
      "x-originatingBSB"?: string;
    };
    export type ResponseBody = AdaptiveAuthenticationChallengeVerificationResponse;
  }
}

export namespace EventNotification {
  /**
   * @description This resource is to notify SAFI the authentication result if the authentication is not performed by SAFI, but analyse is done by SAFI.
   * @tags Notify
   * @name EventNotification
   * @request POST:/eventNotification
   * @secure
   */
  export namespace EventNotification {
    export type RequestParams = {};
    export type RequestQuery = {
      /** The Brand Silo the caller is operating in. Brand Silo is a concept used in Westpac to segregate Customer records based on a combination of the organisation that "owns" the customer relationship and the systems environment in which their identity records are created and maintained. A Brand Silo is a classification whereas a Brand is a descriptive entity associated with an Organisation. */
      brandSilo: "WPAC" | "SGBBSA" | "RAMS" | "BTPL";
    };
    export type RequestBody = AdaptiveAuthenticationNotifyRequest;
    export type RequestHeaders = {
      /** Globally unique message identifier  - GUID. This uniquely identifies this call. */
      "x-messageId": string;
      /** Consumer generated message identifier for correlation purposes. e.g. Can be used to group together a number of API calls comprising a business transaction. */
      "x-appCorrelationId": string;
      /** The organisation the caller is operating in. */
      "x-organisationId": "WPAC" | "SGB" | "BSA" | "BOM" | "BTPL" | "UBS" | "VIRG" | "RAMS" | "BAS" | "WNZL";
      /** The originating consumption channel invoking the API (eg. Partner, Staff, Customer). Note that an API consuming another API should pass the value supplied by the calling application. Further information regarding this header can be found at https://confluence.srv.westpac.com.au/x/cbH-B. */
      "x-consumerType": "Partner" | "Public" | "Staff" | "Customer" | "Prospect" | "Other";
      /** DEPRECATED. The type of channel from which the request has originated. */
      "x-channelType"?:
        | "Branch"
        | "Online"
        | "Contact Centre"
        | "ATM"
        | "Mobile"
        | "IVR Telephony"
        | "Relationship Managed"
        | "External Broker"
        | "External EFA"
        | "External"
        | "Unknown"
        | "Internal";
      /** Alfabet Id of calling application e.g. A00304. Must be propagated to APIs being invoked. Exception for partners calling in via partner APIs, do not populate this header as the partner’s consuming application name (eg. ptr-corelogic-valex) will be injected into this field by the gateway. */
      "x-originatingSystemId": string;
      /** The unique identifier for the user invoking the API (eg. Staff salary number, Customer CIS/GCIS key, Partner CIS/GCIS key or other identifier). */
      "x-userId"?: string;
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      "x-userIdScheme"?:
        | "StaffSalaryNumber"
        | "CustomerInternalId"
        | "CustomerNumber"
        | "SystemProcess"
        | "CorporateUserId"
        | "ProspectId";
    };
    export type ResponseBody = AdaptiveAuthenticationNotifyResponse;
  }
}

export namespace Customers {
  /**
   * @description Retrieve last successful authenticated time for a given session ID. The value can be either saved by the API when customer is successfully authenticated,  or saved by previous lastAuthorisedTime put request.
   * @tags Last Authorised Time Within Region
   * @name GetTimeLastAuthWithinRegion
   * @request GET:/customers/{customerId}/sessions/{sessionId}/lastAuthorisedTime
   * @secure
   */
  export namespace GetTimeLastAuthWithinRegion {
    export type RequestParams = {
      /** The customer id. e.g. 12345678901 */
      customerId: string;
      /** session index value extract from JWT token */
      sessionId: string;
    };
    export type RequestQuery = {
      /** The Brand Silo the caller is operating in. Brand Silo is a concept used in Westpac to segregate Customer records based on a combination of the organisation that "owns" the customer relationship and the systems environment in which their identity records are created and maintained. A Brand Silo is a classification whereas a Brand is a descriptive entity associated with an Organisation. */
      brandSilo: "WPAC" | "SGBBSA" | "RAMS" | "BTPL";
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      customerIdScheme: "CustomerInternalId";
    };
    export type RequestBody = never;
    export type RequestHeaders = {
      /** Globally unique message identifier  - GUID. This uniquely identifies this call. */
      "x-messageId": string;
      /** Consumer generated message identifier for correlation purposes. e.g. Can be used to group together a number of API calls comprising a business transaction. */
      "x-appCorrelationId": string;
      /** The organisation the caller is operating in. */
      "x-organisationId": "WPAC" | "SGB" | "BSA" | "BOM" | "BTPL" | "UBS" | "VIRG" | "RAMS" | "BAS" | "WNZL";
      /** The originating consumption channel invoking the API (eg. Partner, Staff, Customer). Note that an API consuming another API should pass the value supplied by the calling application. Further information regarding this header can be found at https://confluence.srv.westpac.com.au/x/cbH-B. */
      "x-consumerType": "Partner" | "Public" | "Staff" | "Customer" | "Prospect" | "Other";
      /** Alfabet Id of calling application e.g. A00304. Must be propagated to APIs being invoked. Exception for partners calling in via partner APIs, do not populate this header as the partner’s consuming application name (eg. ptr-corelogic-valex) will be injected into this field by the gateway. */
      "x-originatingSystemId": string;
      /** The unique identifier for the user invoking the API (eg. Staff salary number, Customer CIS/GCIS key, Partner CIS/GCIS key or other identifier). */
      "x-userId"?: string;
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      "x-userIdScheme"?:
        | "StaffSalaryNumber"
        | "CustomerInternalId"
        | "CustomerNumber"
        | "SystemProcess"
        | "CorporateUserId"
        | "ProspectId";
    };
    export type ResponseBody = RetrieveTimeLastAuthWithinRegionResponse;
  }
  /**
   * @description Create or udpate last successful authenticated time for a given session ID
   * @tags Last Authorised Time Within Region
   * @name UpdateTimeLastAuthWithinRegion
   * @request PUT:/customers/{customerId}/sessions/{sessionId}/lastAuthorisedTime
   * @secure
   */
  export namespace UpdateTimeLastAuthWithinRegion {
    export type RequestParams = {
      /** The customer id. e.g. 12345678901 */
      customerId: string;
      /** session index value extract from JWT token */
      sessionId: string;
    };
    export type RequestQuery = {
      /** The Brand Silo the caller is operating in. Brand Silo is a concept used in Westpac to segregate Customer records based on a combination of the organisation that "owns" the customer relationship and the systems environment in which their identity records are created and maintained. A Brand Silo is a classification whereas a Brand is a descriptive entity associated with an Organisation. */
      brandSilo: "WPAC" | "SGBBSA" | "RAMS" | "BTPL";
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      customerIdScheme: "CustomerInternalId";
    };
    export type RequestBody = UpdateTimeLastAuthWithinRegionRequest;
    export type RequestHeaders = {
      /** Globally unique message identifier  - GUID. This uniquely identifies this call. */
      "x-messageId": string;
      /** Consumer generated message identifier for correlation purposes. e.g. Can be used to group together a number of API calls comprising a business transaction. */
      "x-appCorrelationId": string;
      /** The organisation the caller is operating in. */
      "x-organisationId": "WPAC" | "SGB" | "BSA" | "BOM" | "BTPL" | "UBS" | "VIRG" | "RAMS" | "BAS" | "WNZL";
      /** The originating consumption channel invoking the API (eg. Partner, Staff, Customer). Note that an API consuming another API should pass the value supplied by the calling application. Further information regarding this header can be found at https://confluence.srv.westpac.com.au/x/cbH-B. */
      "x-consumerType": "Partner" | "Public" | "Staff" | "Customer" | "Prospect" | "Other";
      /** Alfabet Id of calling application e.g. A00304. Must be propagated to APIs being invoked. Exception for partners calling in via partner APIs, do not populate this header as the partner’s consuming application name (eg. ptr-corelogic-valex) will be injected into this field by the gateway. */
      "x-originatingSystemId": string;
      /** The unique identifier for the user invoking the API (eg. Staff salary number, Customer CIS/GCIS key, Partner CIS/GCIS key or other identifier). */
      "x-userId"?: string;
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      "x-userIdScheme"?:
        | "StaffSalaryNumber"
        | "CustomerInternalId"
        | "CustomerNumber"
        | "SystemProcess"
        | "CorporateUserId"
        | "ProspectId";
    };
    export type ResponseBody = UpdateTimeLastAuthWithinRegionResponse;
  }
  /**
   * @description Delete the existing last successful authenticated time for a given session ID
   * @tags Last Authorised Time Within Region
   * @name DeleteTimeLastAuthWithinRegion
   * @request DELETE:/customers/{customerId}/sessions/{sessionId}/lastAuthorisedTime
   * @secure
   */
  export namespace DeleteTimeLastAuthWithinRegion {
    export type RequestParams = {
      /** The customer id. e.g. 12345678901 */
      customerId: string;
      /** session index value extract from JWT token */
      sessionId: string;
    };
    export type RequestQuery = {
      /** The Brand Silo the caller is operating in. Brand Silo is a concept used in Westpac to segregate Customer records based on a combination of the organisation that "owns" the customer relationship and the systems environment in which their identity records are created and maintained. A Brand Silo is a classification whereas a Brand is a descriptive entity associated with an Organisation. */
      brandSilo: "WPAC" | "SGBBSA" | "RAMS" | "BTPL";
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      customerIdScheme: "CustomerInternalId";
    };
    export type RequestBody = never;
    export type RequestHeaders = {
      /** Globally unique message identifier  - GUID. This uniquely identifies this call. */
      "x-messageId": string;
      /** Consumer generated message identifier for correlation purposes. e.g. Can be used to group together a number of API calls comprising a business transaction. */
      "x-appCorrelationId": string;
      /** The organisation the caller is operating in. */
      "x-organisationId": "WPAC" | "SGB" | "BSA" | "BOM" | "BTPL" | "UBS" | "VIRG" | "RAMS" | "BAS" | "WNZL";
      /** The originating consumption channel invoking the API (eg. Partner, Staff, Customer). Note that an API consuming another API should pass the value supplied by the calling application. Further information regarding this header can be found at https://confluence.srv.westpac.com.au/x/cbH-B. */
      "x-consumerType": "Partner" | "Public" | "Staff" | "Customer" | "Prospect" | "Other";
      /** Alfabet Id of calling application e.g. A00304. Must be propagated to APIs being invoked. Exception for partners calling in via partner APIs, do not populate this header as the partner’s consuming application name (eg. ptr-corelogic-valex) will be injected into this field by the gateway. */
      "x-originatingSystemId": string;
      /** The unique identifier for the user invoking the API (eg. Staff salary number, Customer CIS/GCIS key, Partner CIS/GCIS key or other identifier). */
      "x-userId"?: string;
      /** The scheme (type) applicable for the user identifier of the consumer invoking the API. */
      "x-userIdScheme"?:
        | "StaffSalaryNumber"
        | "CustomerInternalId"
        | "CustomerNumber"
        | "SystemProcess"
        | "CorporateUserId"
        | "ProspectId";
    };
    export type ResponseBody = DeleteTimeLastAuthWithinRegionResponse;
  }
}
