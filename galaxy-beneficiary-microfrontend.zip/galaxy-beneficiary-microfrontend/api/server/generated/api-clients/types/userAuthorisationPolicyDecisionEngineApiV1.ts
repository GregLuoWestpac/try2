/* eslint-disable */
/* tslint:disable */
/*
 * ---------------------------------------------------------------
 * ## THIS FILE WAS GENERATED VIA SWAGGER-TYPESCRIPT-API        ##
 * ##                                                           ##
 * ## AUTHOR: acacode                                           ##
 * ## SOURCE: https://github.com/acacode/swagger-typescript-api ##
 * ---------------------------------------------------------------
 */

/**
 * A string that can contain uppercase and lowercase letters,
 * alphanumeric characters, backslash, hyphen, underscore, and period.
 * @minLength 0
 * @maxLength 25
 * @pattern ^[a-zA-Z0-9]+[\-_.]+$
 */
export type StringPattern = string;

export interface IndividualDecisionRequest {
  domain?: StringPattern;
  action?: StringPattern;
  service?: StringPattern;
  identityProvider?: StringPattern;
  /** @example "{"resource": "account:Iud7ta2B0yrG","action": "create_payment"}" */
  attributes: Record<string, StringPattern>;
}

export interface BatchDecisionRequest {
  requests: IndividualDecisionRequest[];
}

export interface IndividualDecisionResponse {
  /** @example "12345678-90ab-cdef-1234-567890abcdef" */
  id: string;
  /** @example "12345678-90ab-cdef-1234-567890abcdef" */
  deploymentPackageId: string;
  /**
   * @format date-time
   * @example "2024-06-11T03:12:19.720485Z"
   */
  timestamp: string;
  /** @example 184024 */
  elapsedTime: number;
  /** @example "PERMIT" */
  decision: string;
  /** @example true */
  authorized: boolean;
  statements?: {
    /** @example "12345678-90ab-cdef-1234-567890abcdef" */
    id?: string;
    /** @example "Statement Name" */
    name?: string;
    /** @example "Statement Code" */
    code?: string;
    /** @example "{"data": "some data"}" */
    payload?: string;
    /** @example true */
    obligatory?: boolean;
    /** @example false */
    fulfilled?: boolean;
    /** @example "{"resource": "account:Iud7ta2B0yrG","action": "create_payment"}" */
    attributes?: Record<string, string>;
  }[];
  status: {
    /** @example "OKAY" */
    code?: string;
    messages?: string[];
    errors?: string[];
  };
}

export interface BatchDecisionResponse {
  responses: IndividualDecisionResponse[];
}

export interface QueryDecisionRequest {
  /** @maxItems 3 */
  query: (
    | {
        /**
         * A string that can contain uppercase and lowercase letters,
         * alphanumeric characters, backslash, hyphen, underscore, and period.
         */
        attribute: StringPattern;
        values?: StringPattern[];
      }
    | {
        /**
         * A string that can contain uppercase and lowercase letters,
         * alphanumeric characters, backslash, hyphen, underscore, and period.
         */
        attribute: StringPattern;
        /**
         * A string that can contain uppercase and lowercase letters,
         * alphanumeric characters, backslash, hyphen, underscore, and period.
         */
        value?: StringPattern;
      }
  )[];
  context: IndividualDecisionRequest;
}

export interface QueryDecisionResponse {
  /** @example "4ec1b233-41ab-4656-a9ae-254da30a933d" */
  requestId: string;
  /**
   * @format date-time
   * @example "2024-06-11T03:12:19.720485Z"
   */
  timeStamp: string;
  /** @example "91b29834-3f6f-48cd-912a-5a1014922946" */
  deploymentPackageId: string;
  /** @example 1234 */
  elapsedTime: number;
  results: {
    attribute?: string;
    values?: string[];
    results?: {
      attribute?: string;
      values?: string[];
      decision?: string;
    }[];
  }[];
}

export interface ErrorResponse {
  /** @example 403 */
  status?: number;
  /** @example "Restricted" */
  message?: string;
  /** @example "Not permitted per regulation" */
  detail?: string;
}

export namespace GovernanceEngine {
  /**
   * No description
   * @tags PDP Governance
   * @name AuthorizeIndividualDecision
   * @summary Authorize client with individual decision
   * @request POST:/governance-engine
   * @secure
   */
  export namespace AuthorizeIndividualDecision {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = IndividualDecisionRequest;
    export type RequestHeaders = {
      /** Bearer token for authorization. */
      Authorization?: string;
      /** Expected response format. */
      Accept?: string;
      /** Content type of the request body. */
      "Content-Type"?: string;
      /** Must be a GUID (Globally unique message identifier). This uniquely identifies this call. This MUST NOT be propagatedy. */
      "x-messageId": string;
      /** Must be a GUID (Globally unique message identifier). Consumer generated message identifier for correlation purposes. e.g. This is used to group together a number of downstream API/provider calls initiated from a single API call, comprising a business transaction. This MUST be propagated. */
      "x-appCorrelationId": string;
      /** Alfabet Id of calling application e.g. A00304. */
      "x-originatingSystemId": string;
    };
    export type ResponseBody = IndividualDecisionResponse;
  }
  /**
   * No description
   * @tags PDP Governance
   * @name AuthorizeBatchDecision
   * @summary Authorize client with batch decision
   * @request POST:/governance-engine/batch
   * @secure
   */
  export namespace AuthorizeBatchDecision {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BatchDecisionRequest;
    export type RequestHeaders = {
      /** Bearer token for authorization. */
      Authorization?: string;
      /** Expected response format. */
      Accept?: string;
      /** Content type of the request body. */
      "Content-Type"?: string;
      /** Must be a GUID (Globally unique message identifier). This uniquely identifies this call. This MUST NOT be propagatedy. */
      "x-messageId": string;
      /** Must be a GUID (Globally unique message identifier). Consumer generated message identifier for correlation purposes. e.g. This is used to group together a number of downstream API/provider calls initiated from a single API call, comprising a business transaction. This MUST be propagated. */
      "x-appCorrelationId": string;
      /** Alfabet Id of calling application e.g. A00304. */
      "x-originatingSystemId": string;
    };
    export type ResponseBody = BatchDecisionResponse;
  }
  /**
   * No description
   * @tags PDP Governance
   * @name QueryDecisionRequest
   * @summary Query decision request
   * @request POST:/governance-engine/query
   * @secure
   */
  export namespace QueryDecisionRequest {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = QueryDecisionRequest;
    export type RequestHeaders = {
      /** Bearer token for authorization. */
      Authorization?: string;
      /** Expected response format. */
      Accept?: string;
      /** Content type of the request body. */
      "Content-Type"?: string;
      /** Must be a GUID (Globally unique message identifier). This uniquely identifies this call. This MUST NOT be propagatedy. */
      "x-messageId": string;
      /** Must be a GUID (Globally unique message identifier). Consumer generated message identifier for correlation purposes. e.g. This is used to group together a number of downstream API/provider calls initiated from a single API call, comprising a business transaction. This MUST be propagated. */
      "x-appCorrelationId": string;
      /** Alfabet Id of calling application e.g. A00304. */
      "x-originatingSystemId": string;
    };
    export type ResponseBody = QueryDecisionResponse;
  }
}
