const {
  mapPathWithParam,
  mapQueryWithParam,
  mapStandardParams,
  fetchData,
  MULTIPART_TYPES,
  getDownstreamApiBaseUrl,
  isDependencyMappingsConfigAvailable,
} = require('./common');

const { hasPermission } = require('./entitlement');

const apiPath = '/cap/custsvcmgt/custsecyverifctn/adaptvauth/v2';
const expApiName = 'beneficiary';

/**
 * @typedef {Object} BaseResponse
 * @prop {number} status - HTTP status code
 * @prop {string} statusText - HTTP status text
 * @prop {any} headers - HTTP headers
 * @prop {boolean} ok - Indicates if the response is successful
 * @prop {boolean} empty - Indicates if the response is empty
 */

/**
 * analyse - This resource is used to perform real-time risk analysis for an online operation instigated by a customer.
 *
 * api : capCustsvcmgtCustsecyverifctnAdaptvauthV2
 *
 * resource : /adaptiveAuthenticationAnalysis
 *
 * method : post
 *
 * @param {string} baseUrl - Baseurl for downstream api
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *                `header` - request header parameters
 *
 *                `path` -   request path parameters
 *
 *                `query` -  request query parameters
 *
 *                `body` -   request body
 *
 * @param {Object} apiConfig -  Configuration for request and response pertaining to the underlying API
 *
 *                `request` -  Request config for the underlying connection
 *
 *                `response` - Response config for the underlying connection
 *
 * @param {Object} req - The ExpressJS request object
 *
 * @param {Object} res - The ExpressJS response object
 *
 * @import { AdaptiveAuthenticationAnalysis } from "./types/capCustsvcmgtCustsecyverifctnAdaptvauthV2"
 * @typedef {BaseResponse & {data: AdaptiveAuthenticationAnalysis.Analyse.ResponseBody}} AnalyseResponse
 * @return {Promise<AnalyseResponse>} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
const analyse = (baseUrl, params, apiConfig, req, res) => {
  const errors = [];
  const originPath = '/adaptiveAuthenticationAnalysis';
  const downStreamServiceName = 'cap-custsvcmgt-custsecyverifctn-adaptvauth-v2';
  const requestMethod = 'post';
  const operationId = 'analyse';
  const consumes = '';

  const { logger, timeoutIn = 15000 } = res.locals;
  const {
    locals: { Config },
  } = res.app;
  const { skipDependencyUrlMapping, enableSystemTest, mockoonBaseUrl } =
    Config.get('app-config');

  if (!logger) {
    const error = {
      code: 10000,
      message: 'Internal Server Error',
      details: 'Please check application logs for details',
    };

    errors.push(error);

    res.status(500).json({ result: { errors } }).end();

    const exception = new TypeError(
      'Logging instance not found. Make sure the logger middleware is instantiated.',
      'Services.js',
      68
    );

    return Promise.reject(exception);
  }

  /**
   * [WDPUI-1714](https://jira.srv.westpac.com.au/browse/WDPUI-1714)
   *
   * Interpret the `role` claim as an array or string
   * but always return an array
   */
  const { USER_ROLES: roles } = res.locals;

  // Wrapped in try{}catch(){}
  // Since the entitlement enforcer throws,
  // we need a way to catch the error and gracefully
  // reject the promise
  try {
    logger.trace({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message: `Evaluating entitlements for '${roles}'`,
      },
    });

    const { allow, assumedRoles } = hasPermission(
      downStreamServiceName,
      originPath,
      requestMethod,
      params,
      roles
    );

    if (!allow) {
      const error = {
        code: 10003,
        message: 'Access denied.',
        details: 'You have not been provisioned to access this information',
      };

      errors.push(error);

      const message = `${roles} are not permitted to call ${operationId} on ${downStreamServiceName}`;
      logger.error({
        payload: {
          message,
          downStreamServiceName,
          operationId,
          originPath,
          requestMethod,
        },
      });

      res.status(403).json({ result: { errors } }).end();

      const exception = new Error(message);

      return Promise.reject(exception);
    }

    logger.trace(
      `South-edge entitlement check passed for ${operationId} on ${originPath} with assumed roles ${assumedRoles}`
    );
  } catch ({ type, message }) {
    const error = {
      code: 10004,
      message: 'Access denied',
      details: 'We are unable to verify your access provisions at this time',
    };

    errors.push(error);

    const errorDetails = `${type && `${type.toUpperCase()}:`} => ${message}`;

    logger.error({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message:
          'Entitlement policy not configured correctly for the application',
        details: errorDetails,
      },
    });

    res.status(403).json({ result: { errors } }).end();

    const exception = new Error(errorDetails);

    return Promise.reject(exception);
  }

  const requestPayload = mapStandardParams(params, apiConfig, timeoutIn, req);
  const pathSuffix = params.path
    ? mapPathWithParam(originPath, params.path)
    : originPath;
  const querySuffix = mapQueryWithParam(params.query);

  let apiEndPoint = `${baseUrl}${apiPath}${pathSuffix}${querySuffix}`;

  if (isDependencyMappingsConfigAvailable) {
    if (skipDependencyUrlMapping) {
      logger.trace(
        `Skipping dynamic dependency url mapping as skipDependencyUrlMapping flag is set to true in app-config.json`
      );
    } else {
      const downstreamApiBaseUrl = getDownstreamApiBaseUrl(
        downStreamServiceName,
        logger
      );
      if (downstreamApiBaseUrl) {
        apiEndPoint = `${downstreamApiBaseUrl}${apiPath}${pathSuffix}${querySuffix}`;
      }
    }
  }
  /**
    Process.env.MOCKS_ENABLED is set by deployment pipeline based on mockoon-data.json file.
    If its enabled, sidecar will be available with mocks.
    Verify if x-systemTest header is present or enableSystemTest is defined in app-config.json to support downstream mock
  **/
  if (process.env.MOCKS_ENABLED === 'True') {
    logger.trace(
      `MockoonMocks :: MOCKS_ENABLED flag is ${process.env.MOCKS_ENABLED}. Verifying if x-systemTest header or enableSystemTest flag is set.`
    );
    const isSystemTestEnabled = req.headers['x-systemtest'] === 'true';
    if (isSystemTestEnabled || enableSystemTest) {
      const mockoonUrl = mockoonBaseUrl || 'http://localhost:3010';
      apiEndPoint = `${mockoonUrl}${apiPath}${pathSuffix}${querySuffix}`;
      logger.trace(`MockoonMocks :: enabling component mock based on (${isSystemTestEnabled},${enableSystemTest}).
        Overriding the apiBaseUrl to ${mockoonUrl}`);
    }
  }

  logger.trace({
    payload: {
      message: `${expApiName}.DownstreamAPI.Start`,
      apiEndPoint,
      downStreamServiceName,
      operationId,
      originPath,
      requestMethod,
      requestPayload,
    },
  });

  /**
   * For document upload api which has multipart upload,
   * maxContentLength & maxBodyLength params should be added as part of config
   * Since the swagger is encoded using hex, we've to replace &#x2F; by /
   */

  let defaultConfigOptions = {};

  if (MULTIPART_TYPES.includes(consumes.replace('&#x2F;', '/'))) {
    defaultConfigOptions = {
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    };
  }

  const log = (data, message, level = 'debug') =>
    logger[level]({
      payload: {
        message,
        apiEndPoint,
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        data,
        defaultConfigOptions,
      },
    });
  const { signal } = res.locals;
  const configValues = {
    ...requestPayload,
    ...defaultConfigOptions,
    method: requestMethod,
    signal,
  };

  const request = {
    apiEndPoint,
    logger: log,
    configValues,
  };

  return fetchData(request);
};

/**
 * challengeInitiation - Initiate a challenge call for the online events
 *
 * api : capCustsvcmgtCustsecyverifctnAdaptvauthV2
 *
 * resource : /adaptiveAuthenticationChallengeInitiation
 *
 * method : post
 *
 * @param {string} baseUrl - Baseurl for downstream api
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *                `header` - request header parameters
 *
 *                `path` -   request path parameters
 *
 *                `query` -  request query parameters
 *
 *                `body` -   request body
 *
 * @param {Object} apiConfig -  Configuration for request and response pertaining to the underlying API
 *
 *                `request` -  Request config for the underlying connection
 *
 *                `response` - Response config for the underlying connection
 *
 * @param {Object} req - The ExpressJS request object
 *
 * @param {Object} res - The ExpressJS response object
 *
 * @import { AdaptiveAuthenticationChallengeInitiation } from "./types/capCustsvcmgtCustsecyverifctnAdaptvauthV2"
 * @typedef {BaseResponse & {data: AdaptiveAuthenticationChallengeInitiation.ChallengeInitiation.ResponseBody}} ChallengeInitiationResponse
 * @return {Promise<ChallengeInitiationResponse>} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
const challengeInitiation = (baseUrl, params, apiConfig, req, res) => {
  const errors = [];
  const originPath = '/adaptiveAuthenticationChallengeInitiation';
  const downStreamServiceName = 'cap-custsvcmgt-custsecyverifctn-adaptvauth-v2';
  const requestMethod = 'post';
  const operationId = 'challengeInitiation';
  const consumes = '';

  const { logger, timeoutIn = 15000 } = res.locals;
  const {
    locals: { Config },
  } = res.app;
  const { skipDependencyUrlMapping, enableSystemTest, mockoonBaseUrl } =
    Config.get('app-config');

  if (!logger) {
    const error = {
      code: 10000,
      message: 'Internal Server Error',
      details: 'Please check application logs for details',
    };

    errors.push(error);

    res.status(500).json({ result: { errors } }).end();

    const exception = new TypeError(
      'Logging instance not found. Make sure the logger middleware is instantiated.',
      'Services.js',
      68
    );

    return Promise.reject(exception);
  }

  /**
   * [WDPUI-1714](https://jira.srv.westpac.com.au/browse/WDPUI-1714)
   *
   * Interpret the `role` claim as an array or string
   * but always return an array
   */
  const { USER_ROLES: roles } = res.locals;

  // Wrapped in try{}catch(){}
  // Since the entitlement enforcer throws,
  // we need a way to catch the error and gracefully
  // reject the promise
  try {
    logger.trace({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message: `Evaluating entitlements for '${roles}'`,
      },
    });

    const { allow, assumedRoles } = hasPermission(
      downStreamServiceName,
      originPath,
      requestMethod,
      params,
      roles
    );

    if (!allow) {
      const error = {
        code: 10003,
        message: 'Access denied.',
        details: 'You have not been provisioned to access this information',
      };

      errors.push(error);

      const message = `${roles} are not permitted to call ${operationId} on ${downStreamServiceName}`;
      logger.error({
        payload: {
          message,
          downStreamServiceName,
          operationId,
          originPath,
          requestMethod,
        },
      });

      res.status(403).json({ result: { errors } }).end();

      const exception = new Error(message);

      return Promise.reject(exception);
    }

    logger.trace(
      `South-edge entitlement check passed for ${operationId} on ${originPath} with assumed roles ${assumedRoles}`
    );
  } catch ({ type, message }) {
    const error = {
      code: 10004,
      message: 'Access denied',
      details: 'We are unable to verify your access provisions at this time',
    };

    errors.push(error);

    const errorDetails = `${type && `${type.toUpperCase()}:`} => ${message}`;

    logger.error({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message:
          'Entitlement policy not configured correctly for the application',
        details: errorDetails,
      },
    });

    res.status(403).json({ result: { errors } }).end();

    const exception = new Error(errorDetails);

    return Promise.reject(exception);
  }

  const requestPayload = mapStandardParams(params, apiConfig, timeoutIn, req);
  const pathSuffix = params.path
    ? mapPathWithParam(originPath, params.path)
    : originPath;
  const querySuffix = mapQueryWithParam(params.query);

  let apiEndPoint = `${baseUrl}${apiPath}${pathSuffix}${querySuffix}`;

  if (isDependencyMappingsConfigAvailable) {
    if (skipDependencyUrlMapping) {
      logger.trace(
        `Skipping dynamic dependency url mapping as skipDependencyUrlMapping flag is set to true in app-config.json`
      );
    } else {
      const downstreamApiBaseUrl = getDownstreamApiBaseUrl(
        downStreamServiceName,
        logger
      );
      if (downstreamApiBaseUrl) {
        apiEndPoint = `${downstreamApiBaseUrl}${apiPath}${pathSuffix}${querySuffix}`;
      }
    }
  }
  /**
    Process.env.MOCKS_ENABLED is set by deployment pipeline based on mockoon-data.json file.
    If its enabled, sidecar will be available with mocks.
    Verify if x-systemTest header is present or enableSystemTest is defined in app-config.json to support downstream mock
  **/
  if (process.env.MOCKS_ENABLED === 'True') {
    logger.trace(
      `MockoonMocks :: MOCKS_ENABLED flag is ${process.env.MOCKS_ENABLED}. Verifying if x-systemTest header or enableSystemTest flag is set.`
    );
    const isSystemTestEnabled = req.headers['x-systemtest'] === 'true';
    if (isSystemTestEnabled || enableSystemTest) {
      const mockoonUrl = mockoonBaseUrl || 'http://localhost:3010';
      apiEndPoint = `${mockoonUrl}${apiPath}${pathSuffix}${querySuffix}`;
      logger.trace(`MockoonMocks :: enabling component mock based on (${isSystemTestEnabled},${enableSystemTest}).
        Overriding the apiBaseUrl to ${mockoonUrl}`);
    }
  }

  logger.trace({
    payload: {
      message: `${expApiName}.DownstreamAPI.Start`,
      apiEndPoint,
      downStreamServiceName,
      operationId,
      originPath,
      requestMethod,
      requestPayload,
    },
  });

  /**
   * For document upload api which has multipart upload,
   * maxContentLength & maxBodyLength params should be added as part of config
   * Since the swagger is encoded using hex, we've to replace &#x2F; by /
   */

  let defaultConfigOptions = {};

  if (MULTIPART_TYPES.includes(consumes.replace('&#x2F;', '/'))) {
    defaultConfigOptions = {
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    };
  }

  const log = (data, message, level = 'debug') =>
    logger[level]({
      payload: {
        message,
        apiEndPoint,
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        data,
        defaultConfigOptions,
      },
    });
  const { signal } = res.locals;
  const configValues = {
    ...requestPayload,
    ...defaultConfigOptions,
    method: requestMethod,
    signal,
  };

  const request = {
    apiEndPoint,
    logger: log,
    configValues,
  };

  return fetchData(request);
};

/**
 * challengeVerification - This is the verification call to validate the authentication code that have been provided by the customer.
 *
 * api : capCustsvcmgtCustsecyverifctnAdaptvauthV2
 *
 * resource : /adaptiveAuthenticationChallengeVerification
 *
 * method : post
 *
 * @param {string} baseUrl - Baseurl for downstream api
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *                `header` - request header parameters
 *
 *                `path` -   request path parameters
 *
 *                `query` -  request query parameters
 *
 *                `body` -   request body
 *
 * @param {Object} apiConfig -  Configuration for request and response pertaining to the underlying API
 *
 *                `request` -  Request config for the underlying connection
 *
 *                `response` - Response config for the underlying connection
 *
 * @param {Object} req - The ExpressJS request object
 *
 * @param {Object} res - The ExpressJS response object
 *
 * @import { AdaptiveAuthenticationChallengeVerification } from "./types/capCustsvcmgtCustsecyverifctnAdaptvauthV2"
 * @typedef {BaseResponse & {data: AdaptiveAuthenticationChallengeVerification.ChallengeVerification.ResponseBody}} ChallengeVerificationResponse
 * @return {Promise<ChallengeVerificationResponse>} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
const challengeVerification = (baseUrl, params, apiConfig, req, res) => {
  const errors = [];
  const originPath = '/adaptiveAuthenticationChallengeVerification';
  const downStreamServiceName = 'cap-custsvcmgt-custsecyverifctn-adaptvauth-v2';
  const requestMethod = 'post';
  const operationId = 'challengeVerification';
  const consumes = '';

  const { logger, timeoutIn = 15000 } = res.locals;
  const {
    locals: { Config },
  } = res.app;
  const { skipDependencyUrlMapping, enableSystemTest, mockoonBaseUrl } =
    Config.get('app-config');

  if (!logger) {
    const error = {
      code: 10000,
      message: 'Internal Server Error',
      details: 'Please check application logs for details',
    };

    errors.push(error);

    res.status(500).json({ result: { errors } }).end();

    const exception = new TypeError(
      'Logging instance not found. Make sure the logger middleware is instantiated.',
      'Services.js',
      68
    );

    return Promise.reject(exception);
  }

  /**
   * [WDPUI-1714](https://jira.srv.westpac.com.au/browse/WDPUI-1714)
   *
   * Interpret the `role` claim as an array or string
   * but always return an array
   */
  const { USER_ROLES: roles } = res.locals;

  // Wrapped in try{}catch(){}
  // Since the entitlement enforcer throws,
  // we need a way to catch the error and gracefully
  // reject the promise
  try {
    logger.trace({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message: `Evaluating entitlements for '${roles}'`,
      },
    });

    const { allow, assumedRoles } = hasPermission(
      downStreamServiceName,
      originPath,
      requestMethod,
      params,
      roles
    );

    if (!allow) {
      const error = {
        code: 10003,
        message: 'Access denied.',
        details: 'You have not been provisioned to access this information',
      };

      errors.push(error);

      const message = `${roles} are not permitted to call ${operationId} on ${downStreamServiceName}`;
      logger.error({
        payload: {
          message,
          downStreamServiceName,
          operationId,
          originPath,
          requestMethod,
        },
      });

      res.status(403).json({ result: { errors } }).end();

      const exception = new Error(message);

      return Promise.reject(exception);
    }

    logger.trace(
      `South-edge entitlement check passed for ${operationId} on ${originPath} with assumed roles ${assumedRoles}`
    );
  } catch ({ type, message }) {
    const error = {
      code: 10004,
      message: 'Access denied',
      details: 'We are unable to verify your access provisions at this time',
    };

    errors.push(error);

    const errorDetails = `${type && `${type.toUpperCase()}:`} => ${message}`;

    logger.error({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message:
          'Entitlement policy not configured correctly for the application',
        details: errorDetails,
      },
    });

    res.status(403).json({ result: { errors } }).end();

    const exception = new Error(errorDetails);

    return Promise.reject(exception);
  }

  const requestPayload = mapStandardParams(params, apiConfig, timeoutIn, req);
  const pathSuffix = params.path
    ? mapPathWithParam(originPath, params.path)
    : originPath;
  const querySuffix = mapQueryWithParam(params.query);

  let apiEndPoint = `${baseUrl}${apiPath}${pathSuffix}${querySuffix}`;

  if (isDependencyMappingsConfigAvailable) {
    if (skipDependencyUrlMapping) {
      logger.trace(
        `Skipping dynamic dependency url mapping as skipDependencyUrlMapping flag is set to true in app-config.json`
      );
    } else {
      const downstreamApiBaseUrl = getDownstreamApiBaseUrl(
        downStreamServiceName,
        logger
      );
      if (downstreamApiBaseUrl) {
        apiEndPoint = `${downstreamApiBaseUrl}${apiPath}${pathSuffix}${querySuffix}`;
      }
    }
  }
  /**
    Process.env.MOCKS_ENABLED is set by deployment pipeline based on mockoon-data.json file.
    If its enabled, sidecar will be available with mocks.
    Verify if x-systemTest header is present or enableSystemTest is defined in app-config.json to support downstream mock
  **/
  if (process.env.MOCKS_ENABLED === 'True') {
    logger.trace(
      `MockoonMocks :: MOCKS_ENABLED flag is ${process.env.MOCKS_ENABLED}. Verifying if x-systemTest header or enableSystemTest flag is set.`
    );
    const isSystemTestEnabled = req.headers['x-systemtest'] === 'true';
    if (isSystemTestEnabled || enableSystemTest) {
      const mockoonUrl = mockoonBaseUrl || 'http://localhost:3010';
      apiEndPoint = `${mockoonUrl}${apiPath}${pathSuffix}${querySuffix}`;
      logger.trace(`MockoonMocks :: enabling component mock based on (${isSystemTestEnabled},${enableSystemTest}).
        Overriding the apiBaseUrl to ${mockoonUrl}`);
    }
  }

  logger.trace({
    payload: {
      message: `${expApiName}.DownstreamAPI.Start`,
      apiEndPoint,
      downStreamServiceName,
      operationId,
      originPath,
      requestMethod,
      requestPayload,
    },
  });

  /**
   * For document upload api which has multipart upload,
   * maxContentLength & maxBodyLength params should be added as part of config
   * Since the swagger is encoded using hex, we've to replace &#x2F; by /
   */

  let defaultConfigOptions = {};

  if (MULTIPART_TYPES.includes(consumes.replace('&#x2F;', '/'))) {
    defaultConfigOptions = {
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    };
  }

  const log = (data, message, level = 'debug') =>
    logger[level]({
      payload: {
        message,
        apiEndPoint,
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        data,
        defaultConfigOptions,
      },
    });
  const { signal } = res.locals;
  const configValues = {
    ...requestPayload,
    ...defaultConfigOptions,
    method: requestMethod,
    signal,
  };

  const request = {
    apiEndPoint,
    logger: log,
    configValues,
  };

  return fetchData(request);
};

/**
 * eventNotification - This resource is to notify SAFI the authentication result if the authentication is not performed by SAFI, but analyse is done by SAFI.
 *
 * api : capCustsvcmgtCustsecyverifctnAdaptvauthV2
 *
 * resource : /eventNotification
 *
 * method : post
 *
 * @param {string} baseUrl - Baseurl for downstream api
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *                `header` - request header parameters
 *
 *                `path` -   request path parameters
 *
 *                `query` -  request query parameters
 *
 *                `body` -   request body
 *
 * @param {Object} apiConfig -  Configuration for request and response pertaining to the underlying API
 *
 *                `request` -  Request config for the underlying connection
 *
 *                `response` - Response config for the underlying connection
 *
 * @param {Object} req - The ExpressJS request object
 *
 * @param {Object} res - The ExpressJS response object
 *
 * @import { EventNotification } from "./types/capCustsvcmgtCustsecyverifctnAdaptvauthV2"
 * @typedef {BaseResponse & {data: EventNotification.EventNotification.ResponseBody}} EventNotificationResponse
 * @return {Promise<EventNotificationResponse>} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
const eventNotification = (baseUrl, params, apiConfig, req, res) => {
  const errors = [];
  const originPath = '/eventNotification';
  const downStreamServiceName = 'cap-custsvcmgt-custsecyverifctn-adaptvauth-v2';
  const requestMethod = 'post';
  const operationId = 'eventNotification';
  const consumes = '';

  const { logger, timeoutIn = 15000 } = res.locals;
  const {
    locals: { Config },
  } = res.app;
  const { skipDependencyUrlMapping, enableSystemTest, mockoonBaseUrl } =
    Config.get('app-config');

  if (!logger) {
    const error = {
      code: 10000,
      message: 'Internal Server Error',
      details: 'Please check application logs for details',
    };

    errors.push(error);

    res.status(500).json({ result: { errors } }).end();

    const exception = new TypeError(
      'Logging instance not found. Make sure the logger middleware is instantiated.',
      'Services.js',
      68
    );

    return Promise.reject(exception);
  }

  /**
   * [WDPUI-1714](https://jira.srv.westpac.com.au/browse/WDPUI-1714)
   *
   * Interpret the `role` claim as an array or string
   * but always return an array
   */
  const { USER_ROLES: roles } = res.locals;

  // Wrapped in try{}catch(){}
  // Since the entitlement enforcer throws,
  // we need a way to catch the error and gracefully
  // reject the promise
  try {
    logger.trace({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message: `Evaluating entitlements for '${roles}'`,
      },
    });

    const { allow, assumedRoles } = hasPermission(
      downStreamServiceName,
      originPath,
      requestMethod,
      params,
      roles
    );

    if (!allow) {
      const error = {
        code: 10003,
        message: 'Access denied.',
        details: 'You have not been provisioned to access this information',
      };

      errors.push(error);

      const message = `${roles} are not permitted to call ${operationId} on ${downStreamServiceName}`;
      logger.error({
        payload: {
          message,
          downStreamServiceName,
          operationId,
          originPath,
          requestMethod,
        },
      });

      res.status(403).json({ result: { errors } }).end();

      const exception = new Error(message);

      return Promise.reject(exception);
    }

    logger.trace(
      `South-edge entitlement check passed for ${operationId} on ${originPath} with assumed roles ${assumedRoles}`
    );
  } catch ({ type, message }) {
    const error = {
      code: 10004,
      message: 'Access denied',
      details: 'We are unable to verify your access provisions at this time',
    };

    errors.push(error);

    const errorDetails = `${type && `${type.toUpperCase()}:`} => ${message}`;

    logger.error({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message:
          'Entitlement policy not configured correctly for the application',
        details: errorDetails,
      },
    });

    res.status(403).json({ result: { errors } }).end();

    const exception = new Error(errorDetails);

    return Promise.reject(exception);
  }

  const requestPayload = mapStandardParams(params, apiConfig, timeoutIn, req);
  const pathSuffix = params.path
    ? mapPathWithParam(originPath, params.path)
    : originPath;
  const querySuffix = mapQueryWithParam(params.query);

  let apiEndPoint = `${baseUrl}${apiPath}${pathSuffix}${querySuffix}`;

  if (isDependencyMappingsConfigAvailable) {
    if (skipDependencyUrlMapping) {
      logger.trace(
        `Skipping dynamic dependency url mapping as skipDependencyUrlMapping flag is set to true in app-config.json`
      );
    } else {
      const downstreamApiBaseUrl = getDownstreamApiBaseUrl(
        downStreamServiceName,
        logger
      );
      if (downstreamApiBaseUrl) {
        apiEndPoint = `${downstreamApiBaseUrl}${apiPath}${pathSuffix}${querySuffix}`;
      }
    }
  }
  /**
    Process.env.MOCKS_ENABLED is set by deployment pipeline based on mockoon-data.json file.
    If its enabled, sidecar will be available with mocks.
    Verify if x-systemTest header is present or enableSystemTest is defined in app-config.json to support downstream mock
  **/
  if (process.env.MOCKS_ENABLED === 'True') {
    logger.trace(
      `MockoonMocks :: MOCKS_ENABLED flag is ${process.env.MOCKS_ENABLED}. Verifying if x-systemTest header or enableSystemTest flag is set.`
    );
    const isSystemTestEnabled = req.headers['x-systemtest'] === 'true';
    if (isSystemTestEnabled || enableSystemTest) {
      const mockoonUrl = mockoonBaseUrl || 'http://localhost:3010';
      apiEndPoint = `${mockoonUrl}${apiPath}${pathSuffix}${querySuffix}`;
      logger.trace(`MockoonMocks :: enabling component mock based on (${isSystemTestEnabled},${enableSystemTest}).
        Overriding the apiBaseUrl to ${mockoonUrl}`);
    }
  }

  logger.trace({
    payload: {
      message: `${expApiName}.DownstreamAPI.Start`,
      apiEndPoint,
      downStreamServiceName,
      operationId,
      originPath,
      requestMethod,
      requestPayload,
    },
  });

  /**
   * For document upload api which has multipart upload,
   * maxContentLength & maxBodyLength params should be added as part of config
   * Since the swagger is encoded using hex, we've to replace &#x2F; by /
   */

  let defaultConfigOptions = {};

  if (MULTIPART_TYPES.includes(consumes.replace('&#x2F;', '/'))) {
    defaultConfigOptions = {
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    };
  }

  const log = (data, message, level = 'debug') =>
    logger[level]({
      payload: {
        message,
        apiEndPoint,
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        data,
        defaultConfigOptions,
      },
    });
  const { signal } = res.locals;
  const configValues = {
    ...requestPayload,
    ...defaultConfigOptions,
    method: requestMethod,
    signal,
  };

  const request = {
    apiEndPoint,
    logger: log,
    configValues,
  };

  return fetchData(request);
};

/**
 * getTimeLastAuthWithinRegion - Retrieve last successful authenticated time for a given session ID. The value can be either saved by the API when customer is successfully authenticated,  or saved by previous lastAuthorisedTime put request.
 *
 * api : capCustsvcmgtCustsecyverifctnAdaptvauthV2
 *
 * resource : /customers/{customerId}/sessions/{sessionId}/lastAuthorisedTime
 *
 * method : get
 *
 * @param {string} baseUrl - Baseurl for downstream api
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *                `header` - request header parameters
 *
 *                `path` -   request path parameters
 *
 *                `query` -  request query parameters
 *
 *                `body` -   request body
 *
 * @param {Object} apiConfig -  Configuration for request and response pertaining to the underlying API
 *
 *                `request` -  Request config for the underlying connection
 *
 *                `response` - Response config for the underlying connection
 *
 * @param {Object} req - The ExpressJS request object
 *
 * @param {Object} res - The ExpressJS response object
 *
 * @import { Customers } from "./types/capCustsvcmgtCustsecyverifctnAdaptvauthV2"
 * @typedef {BaseResponse & {data: Customers.GetTimeLastAuthWithinRegion.ResponseBody}} GetTimeLastAuthWithinRegionResponse
 * @return {Promise<GetTimeLastAuthWithinRegionResponse>} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
const getTimeLastAuthWithinRegion = (baseUrl, params, apiConfig, req, res) => {
  const errors = [];
  const originPath =
    '/customers/{customerId}/sessions/{sessionId}/lastAuthorisedTime';
  const downStreamServiceName = 'cap-custsvcmgt-custsecyverifctn-adaptvauth-v2';
  const requestMethod = 'get';
  const operationId = 'getTimeLastAuthWithinRegion';
  const consumes = '*&#x2F;*';

  const { logger, timeoutIn = 15000 } = res.locals;
  const {
    locals: { Config },
  } = res.app;
  const { skipDependencyUrlMapping, enableSystemTest, mockoonBaseUrl } =
    Config.get('app-config');

  if (!logger) {
    const error = {
      code: 10000,
      message: 'Internal Server Error',
      details: 'Please check application logs for details',
    };

    errors.push(error);

    res.status(500).json({ result: { errors } }).end();

    const exception = new TypeError(
      'Logging instance not found. Make sure the logger middleware is instantiated.',
      'Services.js',
      68
    );

    return Promise.reject(exception);
  }

  /**
   * [WDPUI-1714](https://jira.srv.westpac.com.au/browse/WDPUI-1714)
   *
   * Interpret the `role` claim as an array or string
   * but always return an array
   */
  const { USER_ROLES: roles } = res.locals;

  // Wrapped in try{}catch(){}
  // Since the entitlement enforcer throws,
  // we need a way to catch the error and gracefully
  // reject the promise
  try {
    logger.trace({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message: `Evaluating entitlements for '${roles}'`,
      },
    });

    const { allow, assumedRoles } = hasPermission(
      downStreamServiceName,
      originPath,
      requestMethod,
      params,
      roles
    );

    if (!allow) {
      const error = {
        code: 10003,
        message: 'Access denied.',
        details: 'You have not been provisioned to access this information',
      };

      errors.push(error);

      const message = `${roles} are not permitted to call ${operationId} on ${downStreamServiceName}`;
      logger.error({
        payload: {
          message,
          downStreamServiceName,
          operationId,
          originPath,
          requestMethod,
        },
      });

      res.status(403).json({ result: { errors } }).end();

      const exception = new Error(message);

      return Promise.reject(exception);
    }

    logger.trace(
      `South-edge entitlement check passed for ${operationId} on ${originPath} with assumed roles ${assumedRoles}`
    );
  } catch ({ type, message }) {
    const error = {
      code: 10004,
      message: 'Access denied',
      details: 'We are unable to verify your access provisions at this time',
    };

    errors.push(error);

    const errorDetails = `${type && `${type.toUpperCase()}:`} => ${message}`;

    logger.error({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message:
          'Entitlement policy not configured correctly for the application',
        details: errorDetails,
      },
    });

    res.status(403).json({ result: { errors } }).end();

    const exception = new Error(errorDetails);

    return Promise.reject(exception);
  }

  const requestPayload = mapStandardParams(params, apiConfig, timeoutIn, req);
  const pathSuffix = params.path
    ? mapPathWithParam(originPath, params.path)
    : originPath;
  const querySuffix = mapQueryWithParam(params.query);

  let apiEndPoint = `${baseUrl}${apiPath}${pathSuffix}${querySuffix}`;

  if (isDependencyMappingsConfigAvailable) {
    if (skipDependencyUrlMapping) {
      logger.trace(
        `Skipping dynamic dependency url mapping as skipDependencyUrlMapping flag is set to true in app-config.json`
      );
    } else {
      const downstreamApiBaseUrl = getDownstreamApiBaseUrl(
        downStreamServiceName,
        logger
      );
      if (downstreamApiBaseUrl) {
        apiEndPoint = `${downstreamApiBaseUrl}${apiPath}${pathSuffix}${querySuffix}`;
      }
    }
  }
  /**
    Process.env.MOCKS_ENABLED is set by deployment pipeline based on mockoon-data.json file.
    If its enabled, sidecar will be available with mocks.
    Verify if x-systemTest header is present or enableSystemTest is defined in app-config.json to support downstream mock
  **/
  if (process.env.MOCKS_ENABLED === 'True') {
    logger.trace(
      `MockoonMocks :: MOCKS_ENABLED flag is ${process.env.MOCKS_ENABLED}. Verifying if x-systemTest header or enableSystemTest flag is set.`
    );
    const isSystemTestEnabled = req.headers['x-systemtest'] === 'true';
    if (isSystemTestEnabled || enableSystemTest) {
      const mockoonUrl = mockoonBaseUrl || 'http://localhost:3010';
      apiEndPoint = `${mockoonUrl}${apiPath}${pathSuffix}${querySuffix}`;
      logger.trace(`MockoonMocks :: enabling component mock based on (${isSystemTestEnabled},${enableSystemTest}).
        Overriding the apiBaseUrl to ${mockoonUrl}`);
    }
  }

  logger.trace({
    payload: {
      message: `${expApiName}.DownstreamAPI.Start`,
      apiEndPoint,
      downStreamServiceName,
      operationId,
      originPath,
      requestMethod,
      requestPayload,
    },
  });

  /**
   * For document upload api which has multipart upload,
   * maxContentLength & maxBodyLength params should be added as part of config
   * Since the swagger is encoded using hex, we've to replace &#x2F; by /
   */

  let defaultConfigOptions = {};

  if (MULTIPART_TYPES.includes(consumes.replace('&#x2F;', '/'))) {
    defaultConfigOptions = {
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    };
  }

  const log = (data, message, level = 'debug') =>
    logger[level]({
      payload: {
        message,
        apiEndPoint,
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        data,
        defaultConfigOptions,
      },
    });
  const { signal } = res.locals;
  const configValues = {
    ...requestPayload,
    ...defaultConfigOptions,
    method: requestMethod,
    signal,
  };

  const request = {
    apiEndPoint,
    logger: log,
    configValues,
  };

  return fetchData(request);
};

/**
 * updateTimeLastAuthWithinRegion - Create or udpate last successful authenticated time for a given session ID
 *
 * api : capCustsvcmgtCustsecyverifctnAdaptvauthV2
 *
 * resource : /customers/{customerId}/sessions/{sessionId}/lastAuthorisedTime
 *
 * method : put
 *
 * @param {string} baseUrl - Baseurl for downstream api
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *                `header` - request header parameters
 *
 *                `path` -   request path parameters
 *
 *                `query` -  request query parameters
 *
 *                `body` -   request body
 *
 * @param {Object} apiConfig -  Configuration for request and response pertaining to the underlying API
 *
 *                `request` -  Request config for the underlying connection
 *
 *                `response` - Response config for the underlying connection
 *
 * @param {Object} req - The ExpressJS request object
 *
 * @param {Object} res - The ExpressJS response object
 *
 * @import { Customers } from "./types/capCustsvcmgtCustsecyverifctnAdaptvauthV2"
 * @typedef {BaseResponse & {data: Customers.UpdateTimeLastAuthWithinRegion.ResponseBody}} UpdateTimeLastAuthWithinRegionResponse
 * @return {Promise<UpdateTimeLastAuthWithinRegionResponse>} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
const updateTimeLastAuthWithinRegion = (
  baseUrl,
  params,
  apiConfig,
  req,
  res
) => {
  const errors = [];
  const originPath =
    '/customers/{customerId}/sessions/{sessionId}/lastAuthorisedTime';
  const downStreamServiceName = 'cap-custsvcmgt-custsecyverifctn-adaptvauth-v2';
  const requestMethod = 'put';
  const operationId = 'updateTimeLastAuthWithinRegion';
  const consumes = '';

  const { logger, timeoutIn = 15000 } = res.locals;
  const {
    locals: { Config },
  } = res.app;
  const { skipDependencyUrlMapping, enableSystemTest, mockoonBaseUrl } =
    Config.get('app-config');

  if (!logger) {
    const error = {
      code: 10000,
      message: 'Internal Server Error',
      details: 'Please check application logs for details',
    };

    errors.push(error);

    res.status(500).json({ result: { errors } }).end();

    const exception = new TypeError(
      'Logging instance not found. Make sure the logger middleware is instantiated.',
      'Services.js',
      68
    );

    return Promise.reject(exception);
  }

  /**
   * [WDPUI-1714](https://jira.srv.westpac.com.au/browse/WDPUI-1714)
   *
   * Interpret the `role` claim as an array or string
   * but always return an array
   */
  const { USER_ROLES: roles } = res.locals;

  // Wrapped in try{}catch(){}
  // Since the entitlement enforcer throws,
  // we need a way to catch the error and gracefully
  // reject the promise
  try {
    logger.trace({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message: `Evaluating entitlements for '${roles}'`,
      },
    });

    const { allow, assumedRoles } = hasPermission(
      downStreamServiceName,
      originPath,
      requestMethod,
      params,
      roles
    );

    if (!allow) {
      const error = {
        code: 10003,
        message: 'Access denied.',
        details: 'You have not been provisioned to access this information',
      };

      errors.push(error);

      const message = `${roles} are not permitted to call ${operationId} on ${downStreamServiceName}`;
      logger.error({
        payload: {
          message,
          downStreamServiceName,
          operationId,
          originPath,
          requestMethod,
        },
      });

      res.status(403).json({ result: { errors } }).end();

      const exception = new Error(message);

      return Promise.reject(exception);
    }

    logger.trace(
      `South-edge entitlement check passed for ${operationId} on ${originPath} with assumed roles ${assumedRoles}`
    );
  } catch ({ type, message }) {
    const error = {
      code: 10004,
      message: 'Access denied',
      details: 'We are unable to verify your access provisions at this time',
    };

    errors.push(error);

    const errorDetails = `${type && `${type.toUpperCase()}:`} => ${message}`;

    logger.error({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message:
          'Entitlement policy not configured correctly for the application',
        details: errorDetails,
      },
    });

    res.status(403).json({ result: { errors } }).end();

    const exception = new Error(errorDetails);

    return Promise.reject(exception);
  }

  const requestPayload = mapStandardParams(params, apiConfig, timeoutIn, req);
  const pathSuffix = params.path
    ? mapPathWithParam(originPath, params.path)
    : originPath;
  const querySuffix = mapQueryWithParam(params.query);

  let apiEndPoint = `${baseUrl}${apiPath}${pathSuffix}${querySuffix}`;

  if (isDependencyMappingsConfigAvailable) {
    if (skipDependencyUrlMapping) {
      logger.trace(
        `Skipping dynamic dependency url mapping as skipDependencyUrlMapping flag is set to true in app-config.json`
      );
    } else {
      const downstreamApiBaseUrl = getDownstreamApiBaseUrl(
        downStreamServiceName,
        logger
      );
      if (downstreamApiBaseUrl) {
        apiEndPoint = `${downstreamApiBaseUrl}${apiPath}${pathSuffix}${querySuffix}`;
      }
    }
  }
  /**
    Process.env.MOCKS_ENABLED is set by deployment pipeline based on mockoon-data.json file.
    If its enabled, sidecar will be available with mocks.
    Verify if x-systemTest header is present or enableSystemTest is defined in app-config.json to support downstream mock
  **/
  if (process.env.MOCKS_ENABLED === 'True') {
    logger.trace(
      `MockoonMocks :: MOCKS_ENABLED flag is ${process.env.MOCKS_ENABLED}. Verifying if x-systemTest header or enableSystemTest flag is set.`
    );
    const isSystemTestEnabled = req.headers['x-systemtest'] === 'true';
    if (isSystemTestEnabled || enableSystemTest) {
      const mockoonUrl = mockoonBaseUrl || 'http://localhost:3010';
      apiEndPoint = `${mockoonUrl}${apiPath}${pathSuffix}${querySuffix}`;
      logger.trace(`MockoonMocks :: enabling component mock based on (${isSystemTestEnabled},${enableSystemTest}).
        Overriding the apiBaseUrl to ${mockoonUrl}`);
    }
  }

  logger.trace({
    payload: {
      message: `${expApiName}.DownstreamAPI.Start`,
      apiEndPoint,
      downStreamServiceName,
      operationId,
      originPath,
      requestMethod,
      requestPayload,
    },
  });

  /**
   * For document upload api which has multipart upload,
   * maxContentLength & maxBodyLength params should be added as part of config
   * Since the swagger is encoded using hex, we've to replace &#x2F; by /
   */

  let defaultConfigOptions = {};

  if (MULTIPART_TYPES.includes(consumes.replace('&#x2F;', '/'))) {
    defaultConfigOptions = {
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    };
  }

  const log = (data, message, level = 'debug') =>
    logger[level]({
      payload: {
        message,
        apiEndPoint,
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        data,
        defaultConfigOptions,
      },
    });
  const { signal } = res.locals;
  const configValues = {
    ...requestPayload,
    ...defaultConfigOptions,
    method: requestMethod,
    signal,
  };

  const request = {
    apiEndPoint,
    logger: log,
    configValues,
  };

  return fetchData(request);
};

/**
 * deleteTimeLastAuthWithinRegion - Delete the existing last successful authenticated time for a given session ID
 *
 * api : capCustsvcmgtCustsecyverifctnAdaptvauthV2
 *
 * resource : /customers/{customerId}/sessions/{sessionId}/lastAuthorisedTime
 *
 * method : delete
 *
 * @param {string} baseUrl - Baseurl for downstream api
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *                `header` - request header parameters
 *
 *                `path` -   request path parameters
 *
 *                `query` -  request query parameters
 *
 *                `body` -   request body
 *
 * @param {Object} apiConfig -  Configuration for request and response pertaining to the underlying API
 *
 *                `request` -  Request config for the underlying connection
 *
 *                `response` - Response config for the underlying connection
 *
 * @param {Object} req - The ExpressJS request object
 *
 * @param {Object} res - The ExpressJS response object
 *
 * @import { Customers } from "./types/capCustsvcmgtCustsecyverifctnAdaptvauthV2"
 * @typedef {BaseResponse & {data: Customers.DeleteTimeLastAuthWithinRegion.ResponseBody}} DeleteTimeLastAuthWithinRegionResponse
 * @return {Promise<DeleteTimeLastAuthWithinRegionResponse>} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
const deleteTimeLastAuthWithinRegion = (
  baseUrl,
  params,
  apiConfig,
  req,
  res
) => {
  const errors = [];
  const originPath =
    '/customers/{customerId}/sessions/{sessionId}/lastAuthorisedTime';
  const downStreamServiceName = 'cap-custsvcmgt-custsecyverifctn-adaptvauth-v2';
  const requestMethod = 'delete';
  const operationId = 'deleteTimeLastAuthWithinRegion';
  const consumes = '*&#x2F;*';

  const { logger, timeoutIn = 15000 } = res.locals;
  const {
    locals: { Config },
  } = res.app;
  const { skipDependencyUrlMapping, enableSystemTest, mockoonBaseUrl } =
    Config.get('app-config');

  if (!logger) {
    const error = {
      code: 10000,
      message: 'Internal Server Error',
      details: 'Please check application logs for details',
    };

    errors.push(error);

    res.status(500).json({ result: { errors } }).end();

    const exception = new TypeError(
      'Logging instance not found. Make sure the logger middleware is instantiated.',
      'Services.js',
      68
    );

    return Promise.reject(exception);
  }

  /**
   * [WDPUI-1714](https://jira.srv.westpac.com.au/browse/WDPUI-1714)
   *
   * Interpret the `role` claim as an array or string
   * but always return an array
   */
  const { USER_ROLES: roles } = res.locals;

  // Wrapped in try{}catch(){}
  // Since the entitlement enforcer throws,
  // we need a way to catch the error and gracefully
  // reject the promise
  try {
    logger.trace({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message: `Evaluating entitlements for '${roles}'`,
      },
    });

    const { allow, assumedRoles } = hasPermission(
      downStreamServiceName,
      originPath,
      requestMethod,
      params,
      roles
    );

    if (!allow) {
      const error = {
        code: 10003,
        message: 'Access denied.',
        details: 'You have not been provisioned to access this information',
      };

      errors.push(error);

      const message = `${roles} are not permitted to call ${operationId} on ${downStreamServiceName}`;
      logger.error({
        payload: {
          message,
          downStreamServiceName,
          operationId,
          originPath,
          requestMethod,
        },
      });

      res.status(403).json({ result: { errors } }).end();

      const exception = new Error(message);

      return Promise.reject(exception);
    }

    logger.trace(
      `South-edge entitlement check passed for ${operationId} on ${originPath} with assumed roles ${assumedRoles}`
    );
  } catch ({ type, message }) {
    const error = {
      code: 10004,
      message: 'Access denied',
      details: 'We are unable to verify your access provisions at this time',
    };

    errors.push(error);

    const errorDetails = `${type && `${type.toUpperCase()}:`} => ${message}`;

    logger.error({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message:
          'Entitlement policy not configured correctly for the application',
        details: errorDetails,
      },
    });

    res.status(403).json({ result: { errors } }).end();

    const exception = new Error(errorDetails);

    return Promise.reject(exception);
  }

  const requestPayload = mapStandardParams(params, apiConfig, timeoutIn, req);
  const pathSuffix = params.path
    ? mapPathWithParam(originPath, params.path)
    : originPath;
  const querySuffix = mapQueryWithParam(params.query);

  let apiEndPoint = `${baseUrl}${apiPath}${pathSuffix}${querySuffix}`;

  if (isDependencyMappingsConfigAvailable) {
    if (skipDependencyUrlMapping) {
      logger.trace(
        `Skipping dynamic dependency url mapping as skipDependencyUrlMapping flag is set to true in app-config.json`
      );
    } else {
      const downstreamApiBaseUrl = getDownstreamApiBaseUrl(
        downStreamServiceName,
        logger
      );
      if (downstreamApiBaseUrl) {
        apiEndPoint = `${downstreamApiBaseUrl}${apiPath}${pathSuffix}${querySuffix}`;
      }
    }
  }
  /**
    Process.env.MOCKS_ENABLED is set by deployment pipeline based on mockoon-data.json file.
    If its enabled, sidecar will be available with mocks.
    Verify if x-systemTest header is present or enableSystemTest is defined in app-config.json to support downstream mock
  **/
  if (process.env.MOCKS_ENABLED === 'True') {
    logger.trace(
      `MockoonMocks :: MOCKS_ENABLED flag is ${process.env.MOCKS_ENABLED}. Verifying if x-systemTest header or enableSystemTest flag is set.`
    );
    const isSystemTestEnabled = req.headers['x-systemtest'] === 'true';
    if (isSystemTestEnabled || enableSystemTest) {
      const mockoonUrl = mockoonBaseUrl || 'http://localhost:3010';
      apiEndPoint = `${mockoonUrl}${apiPath}${pathSuffix}${querySuffix}`;
      logger.trace(`MockoonMocks :: enabling component mock based on (${isSystemTestEnabled},${enableSystemTest}).
        Overriding the apiBaseUrl to ${mockoonUrl}`);
    }
  }

  logger.trace({
    payload: {
      message: `${expApiName}.DownstreamAPI.Start`,
      apiEndPoint,
      downStreamServiceName,
      operationId,
      originPath,
      requestMethod,
      requestPayload,
    },
  });

  /**
   * For document upload api which has multipart upload,
   * maxContentLength & maxBodyLength params should be added as part of config
   * Since the swagger is encoded using hex, we've to replace &#x2F; by /
   */

  let defaultConfigOptions = {};

  if (MULTIPART_TYPES.includes(consumes.replace('&#x2F;', '/'))) {
    defaultConfigOptions = {
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    };
  }

  const log = (data, message, level = 'debug') =>
    logger[level]({
      payload: {
        message,
        apiEndPoint,
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        data,
        defaultConfigOptions,
      },
    });
  const { signal } = res.locals;
  const configValues = {
    ...requestPayload,
    ...defaultConfigOptions,
    method: requestMethod,
    signal,
  };

  const request = {
    apiEndPoint,
    logger: log,
    configValues,
  };

  return fetchData(request);
};

module.exports = {
  analyse,
  challengeInitiation,
  challengeVerification,
  eventNotification,
  getTimeLastAuthWithinRegion,
  updateTimeLastAuthWithinRegion,
  deleteTimeLastAuthWithinRegion,
};
