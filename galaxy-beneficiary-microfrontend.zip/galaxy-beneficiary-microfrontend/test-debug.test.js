import { getDefaultFormValues } from './ui/src/components/BeneficiaryForm/BeneficiaryForm.utils.tsx';
import { BENEFICIARY_TYPE, BENEFICIARY_STATUS } from './ui/src/store/types/Beneficiary.ts';

describe('Debug getDefaultFormValues', () => {
  it('should return correct beneficiaryType for beneficiaryAccount', () => {
    const beneficiaryAccount = {
      id: 'd0868661-b955-4e76-9f15-d97626f7d78b',
      externalId: 'd0868661-b955-4e76-9f15-d97626f7d78b',
      nickname: 'Bayer, Miller and MacGyver',
      currency: 'AUD',
      org: 'office',
      status: BENEFICIARY_STATUS.ACTIVE,
      type: BENEFICIARY_TYPE.ACCOUNT,
      account: {
        accountId: {
          BSB: '062948',
          accountNumber: '22222123',
        },
        bankName: 'Westpac Banking Corporation',
        accountName: 'Westpac Joint',
      },
    };

    const result = getDefaultFormValues(beneficiaryAccount);

    console.log('getDefaultFormValues result:', result);
    console.log('beneficiaryType in result:', result.beneficiaryType);
    console.log('BENEFICIARY_TYPE.ACCOUNT:', BENEFICIARY_TYPE.ACCOUNT);

    expect(result.beneficiaryType).toBe(BENEFICIARY_TYPE.ACCOUNT);
  });
});
