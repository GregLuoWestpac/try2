// Debug test to verify getDefaultFormValues
const beneficiaryAccount = {
  id: 'd0868661-b955-4e76-9f15-d97626f7d78b',
  externalId: 'd0868661-b955-4e76-9f15-d97626f7d78b',
  nickname: 'Bayer, Miller and MacGyver',
  currency: 'AUD',
  org: 'office',
  status: 'ACTIVE',
  type: 'BSB_ACCOUNT_NUMBER',
  account: {
    accountId: {
      BSB: '062948',
      accountNumber: '22222123',
    },
    bankName: 'Westpac Banking Corporation',
    accountName: 'Westpac Joint',
  },
};

console.log('Input beneficiaryAccount:', JSON.stringify(beneficiaryAccount, null, 2));
console.log('Expected result should have beneficiaryType:', beneficiaryAccount.type);
