const fs = require('fs');
const path = require('path');
const { generateApi } = require('swagger-typescript-api');

async function generateExpApiType() {
  const inputPath = path.join(__dirname, '../../openapi.yaml');
  const outputPath = path.join(__dirname, '../../types');

  await generateApi({
    input: inputPath,
    output: outputPath,
    extractResponseBody: true,
    generateClient: false,
    modular: true,
  });
}

async function generateTypeTemplate() {
  await generateExpApiType();

  const inputFilePath = path.join(__dirname, '../../types/data-contracts.ts');
  const outputFilePath = path.join(__dirname, '../../api/interfaces/models/galaxyPaymentExp.ts');

  // Read the content from the input file
  const inputContent = fs.readFileSync(inputFilePath, 'utf8');

  // Remove the first 10 lines
  const modifiedContent = inputContent.split('\n').slice(10).join('\n');

  // Write the modified content to the output file
  fs.writeFileSync(outputFilePath, modifiedContent, 'utf8');

   // Delete the /types folder
   const typesDirPath = path.join(__dirname, '../../types');
   if (fs.existsSync(typesDirPath)) {
     fs.rmSync(typesDirPath, { recursive: true, force: true });
   }

   process.exit();
}

generateTypeTemplate();
