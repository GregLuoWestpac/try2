#!/bin/bash

# Mapping of combined input to environment and swimlane using regular arrays
env_keys=("dev1" "dev-w1c1" "dev-w1c2" "sit1" "sit-w1c1" "sit-w1c2" "sit-w1c3")
env_values=("dev1:" "dev1:dev-w1c1" "dev1:dev-w1c2" "sit1:" "sit1:sit-w1c1" "sit1:sit-w1c2" "sit1:sit-w1c3")

# Function to get value from env_map
get_env_value() {
    key=$1
    for i in "${!env_keys[@]}"; do
        if [ "${env_keys[$i]}" = "$key" ]; then
            echo "${env_values[$i]}"
            return
        fi
    done
    echo ""
}

# Extract environment and swimlane from combined input
combined_input="$1"
env_value=$(get_env_value "$combined_input")
IFS=':' read -r environment swimlane <<EOF
$env_value
EOF

# Use current branch as revision if not provided
if [ -z "$2" ]; then
  revision=$(git rev-parse --abbrev-ref HEAD)
else
  revision="$2"
fi

if [[ "$OSTYPE" == "darwin"* ]]; then
  source ~/.zshrc
fi

# Run the Mesh Status command
mesh status --component_name galaxy-payment

# Run the Mesh Build command and capture its output
build_output=$(mktemp)
yes | mesh build --component_name galaxy-payment --revision "$revision" -v | tee "$build_output"
build_status=$?

# Check if the build command was successful
if [ $build_status -ne 0 ]; then
  echo "Build error: Mesh build command failed."
  rm "$build_output"
  exit 1
fi

# Link to build the container
echo ""
echo ""
echo "Link to build the Payment MFE:"
echo "https://bamboo-wdp.srv.westpac.com.au/browse/WDPBUILDMFE-ID2016"

# Extract the build number from the output
build_number=$(grep -o 'Build number [0-9]\+' "$build_output" | awk '{print $3}')

# Check if the build number was found
if [ -z "$build_number" ]; then
  echo "Build number not found in the build output."
  rm "$build_output"
  exit 1
fi

# Run the Mesh Deploy command with the extracted build number
yes | mesh deploy --component_name galaxy-payment --environment "$environment" $(if [ -n "$swimlane" ]; then echo --swimlane "$swimlane"; fi) --build_number "$build_number" --wait $(if [ "$swimlane" = "sit-w1c2" ]; then echo -x ENABLE_COMPONENT_TESTS=True; fi)
deploy_status=$?

# Output the build number
echo "Build number: $build_number"

# Link to deploy the container
echo ""
echo ""
echo "Link to deploy the Payment MFE:"
echo "https://bamboo-wdp.srv.westpac.com.au/browse/WDPDEPLOYMFEDEV1-MFEDEPLOYDEV1"

# Check if the deploy command was successful
if [ $deploy_status -ne 0 ]; then
  echo "Deploy error: Mesh deploy command failed."
  rm "$build_output"
  exit 1
fi

# Run the Mesh Status command
mesh status --component_name galaxy-payment

# Clean up the temporary file
rm "$build_output"
