# cleanup-test-output.ps1
npm run test:update 2>&1 | ForEach-Object {
    $_ -replace '\x1B\[[0-9;]*[A-Za-z]', ''
}
