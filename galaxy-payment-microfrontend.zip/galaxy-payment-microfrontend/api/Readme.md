![WDP-UI](https://confluence.srv.westpac.com.au/download/attachments/40095124/WDP%20UI%20Heading.png?version=1&modificationDate=1494312288563&api=v2)

# WDP UI Skeleton Experience API

WDP UI starter Experience API project code with examples of best practises and patterns.

## Getting Started

These instructions will get you a copy of the sample skeleton Experience API up and running on your local machine for development and testing purposes.

### Installation

From your command line:

```
# Clone this repository
git clone ssh://git@bitbucket.srv.westpac.com.au/ui-www/galaxy-payment-microfrontend.git

# Go into the repository
cd galaxy-payment-microfrontend

# Install dependencies
npm install

# Run the Experience API
npm start

```

#### Consuming the API

We recommend using [postman](https://www.getpostman.com/) for API development testing.


### Detailed Documentation

- [WDP UI Experience API Confluence Page](https://confluence.srv.westpac.com.au/display/WDPIPAAS/WDP+UI+Experience+API)
- [Experience API Training Materials](https://confluence.srv.westpac.com.au/display/WDPIPAAS/Experience+API)
- [API Entitlements](https://confluence.srv.westpac.com.au/pages/viewpage.action?pageId=132648545)