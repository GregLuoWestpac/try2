export const paymentMethodDescription = {
  FastPayment: 'Fast Payment',
  Osko: 'Osko',
  FundsTransfer: 'Funds transfer',
  PayTo: 'PayTo',
  DE: 'Pay Anyone',
} as const;

export const paymentInformationStatus = {
  ACSC: 'ACSC',
  ACSP: 'ACSP',
  RJCT: 'RJCT',
  RCVD: 'RCVD',
  PATC: 'PATC',
  SBMT: 'SBMT',
} as const;

export const paymentDetailsStatus = {
  Processed: 'Processed',
  Processing: 'Processing',
  Failed: 'Failed',
  Submitted: 'Submitted',
} as const;

export const instructionForDebtorAgentCode = {
  OnMe: 'On-Me',
} as const;

export const serviceLevelCode = {
  fastPaymentCatSct: 'npp.clear.01-catsct.',
  fastPaymentSct: 'npp.clear.01-sct.',
  osko: 'npp.clear.01-x2p1.',
  payTo: 'npp.mpis.01-mpis.01',
  DE: 'NURG',
} as const;

export const StatusMap = {
  ACSC: 'Processed',
  ACSP: 'Processing',
  RJCT: 'Failed',
  RCVD: 'Processing',
  PATC: 'Processing',
  SBMT: 'Processing',
} as const;

export const paymentProductMap = {
  DE: 'PP000020',
  OSKO: 'PP000004',
  SCT: 'PP000005',
  CAT_SCT: 'PP000012',
  TRANSFER: 'PP000016',
} as const;

export const defaultPaymentType = 'OSKO' as const;
export const defaultPaymentProductId = 'PP000004' as const;

export const identificationTypes = {
  PRIVATE: 'PrivateIdentification',
  ORGANISATION: 'OrganisationIdentification',
  OTHER_ACCOUNT: 'OtherAccountIdentification',
} as const;

export const serviceLevelTypes = {
  PROPRIETARY: 'ServiceLevelProprietary',
} as const;

export const purposeTypes = {
  CODE: 'PurposeCode',
} as const;

export const schemeNameTypes = {
  CODE: 'SchemeNameCode',
} as const;

export const amountTypes = {
  INSTRUCTED: 'InstructedAmount',
} as const;

export type InjectionVulnerabilityResult = {
  vulnerabilityDetected: boolean;
  message: string;
  vulnerableFields: string[];
};

export enum PDP_QUERY_ATTRIBUTES {
  INITIATE_PAYMENT = 'INITIATE_PAYMENT',
  INITIATE_TRANSFER = 'INITIATE_TRANSFER',
}
