export function formatCurrencyString(input: string): string {
  const num = Number(input);
  if (Number.isNaN(num) || input === '' || num <= 0) {
    return input;
  }

  const decimalPart = input.split('.')[1];

  if (decimalPart && decimalPart.length > 2) {
    return input;
  }

  return num.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}