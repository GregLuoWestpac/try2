import { Request, Response, NextFunction } from 'express';
import { accessControlExposeHeaders } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

/*
 * Middleware to expose custom headers (for AppDynamics/customer headers etc.)
 */
const AccessControlExposeHeadersMiddleware = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const { logger } = res.locals || {};
  try {
    res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);
  } catch (error) {
    logger?.error(
      'Failed to set Access-Control-Expose-Headers:',
      error && (error as Error).message ? (error as Error).message : error
    );
  }

  next();
};

export { AccessControlExposeHeadersMiddleware };
