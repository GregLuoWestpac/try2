import { AuthenticateTokenMiddleware } from './tokenValidationMiddleware';

jest.mock('../../utils/jwt', () => ({
  jwtDecode: jest.fn(),
}));

import { jwtDecode } from '../../utils/jwt';

describe('AuthenticateTokenMiddleware', () => {
  const next = jest.fn();

  const createRes = () => {
    return {
      locals: { logger: { info: jest.fn(), error: jest.fn() } },
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
    } as any;
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('passes through for /healthcheck', () => {
    const req: any = { originalUrl: '/healthcheck', headers: {} };
    const res: any = createRes();

    AuthenticateTokenMiddleware(req, res, next);

    expect(next).toHaveBeenCalled();
    expect(res.status).not.toHaveBeenCalled();
  });

  it('returns 401 when Authorization header missing', () => {
    const req: any = { originalUrl: '/api/account', headers: {} };
    const res: any = createRes();

    AuthenticateTokenMiddleware(req, res, next);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith({ error: 'Access token required' });
    expect(res.locals.logger.error).toHaveBeenCalled();
    expect(next).not.toHaveBeenCalled();
  });

  it('returns 401 for malformed Authorization header', () => {
    const req: any = {
      originalUrl: '/api/account',
      headers: { authorization: 'Token abc' },
    };
    const res: any = createRes();

    AuthenticateTokenMiddleware(req, res, next);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith({ error: 'Access token required' });
    expect(res.locals.logger.error).toHaveBeenCalled();
    expect(next).not.toHaveBeenCalled();
  });

  it('returns 401 when Bearer token is empty', () => {
    const req: any = {
      originalUrl: '/api/account',
      headers: { authorization: 'Bearer ' },
    };
    const res: any = createRes();

    AuthenticateTokenMiddleware(req, res, next);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith({ error: 'Access token required' });
    expect(next).not.toHaveBeenCalled();
  });

  it('returns 401 when jwtDecode returns null', () => {
    (jwtDecode as jest.Mock).mockReturnValueOnce(null);
    const req: any = {
      originalUrl: '/api/account',
      headers: { authorization: 'Bearer token' },
    };
    const res: any = createRes();

    AuthenticateTokenMiddleware(req, res, next);

    expect(jwtDecode).toHaveBeenCalledWith('token');
    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith({ msg: 'Unauthorized' });
    expect(next).not.toHaveBeenCalled();
  });

  it('returns 401 when resource_uri pathname does not include target path', () => {
    (jwtDecode as jest.Mock).mockReturnValueOnce({
      resource_uri: 'https://example.com/staff/api/other',
    });
    const req: any = {
      originalUrl: '/api/account',
      headers: { authorization: 'Bearer token' },
    };
    const res: any = createRes();

    AuthenticateTokenMiddleware(req, res, next);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith({ msg: 'Unauthorized' });
    expect(next).not.toHaveBeenCalled();
  });

  it('calls next when token resource_uri matches the request path', () => {
    (jwtDecode as jest.Mock).mockReturnValueOnce({
      resource_uri: 'https://example.com/staff/api/account',
      aud: 'aud',
    });
    const req: any = {
      originalUrl: '/api/account',
      headers: { authorization: 'Bearer token' },
    };
    const res: any = createRes();

    AuthenticateTokenMiddleware(req, res, next);

    expect(jwtDecode).toHaveBeenCalledWith('token');
    expect(res.locals.logger.info).toHaveBeenCalled();
    expect(next).toHaveBeenCalled();
  });
});
