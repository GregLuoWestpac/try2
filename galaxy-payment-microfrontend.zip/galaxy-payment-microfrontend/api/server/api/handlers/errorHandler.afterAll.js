module.exports = function afterAllErrorHandler(err, req, res, next) {
  const { logger } = res.locals;
  logger.trace(`Error handler :: after all`);
  next();
};