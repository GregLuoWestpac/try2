/* eslint-disable consistent-return */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-enum-comparison */
import { v4 } from 'uuid';
import type {
  BeneficiaryObject,
  CreditAccountObject,
  ExpPostPaymentDetails,
} from '../../../interfaces/models/PaymentDetails';
import type { InfPostPaymentDetailsResponse } from '../../../interfaces/models/downstream/infBnkngEvntPymntevntInstlPymntevntV1Services';
import {
  paymentDetailsStatus,
  paymentInformationStatus,
  paymentMethodDescription,
  instructionForDebtorAgentCode,
  serviceLevelCode,
} from '../common/constants';
import { mapPaymentMethod } from '../../utils/commonHelper';

export const mapPaymentDetailsStatusCode = (code?: string) => {
  switch (code) {
    case paymentInformationStatus.ACSC:
      return paymentDetailsStatus.Processed;
    case paymentInformationStatus.ACSP:
      return paymentDetailsStatus.Processing;
    case paymentInformationStatus.RJCT:
      return paymentDetailsStatus.Failed;
    case paymentInformationStatus.RCVD:
      return paymentDetailsStatus.Processing;
    case paymentInformationStatus.PATC:
      return paymentDetailsStatus.Processing;
    case paymentInformationStatus.SBMT:
      return paymentDetailsStatus.Processing;
    default:
      return undefined;
  }
};

export const spacedBsbAndAccountNumber = (accountId: string) => {
  if (accountId == null || accountId.length <= 6) {
    return accountId;
  }
  return `${accountId.slice(0, 6)} ${accountId.slice(6)}`;
};

const getBeneficiaryAndCreditAccount = (
  creditTransferTransaction: any,
  creditorName: string,
  creditorAccountName: string,
  creditorAccountId: string,
  aliasId: string,
  aliasType: string
) => {
  let beneficiary: BeneficiaryObject | undefined;
  let creditAccount: CreditAccountObject | undefined;

  if (creditTransferTransaction.instructionForDebtorAgent === instructionForDebtorAgentCode.OnMe
    && !(aliasId && aliasType)
  ) {
    creditAccount = {
      nickName: creditorAccountName,
      accountId: creditorAccountId,
    };
  } else if (aliasId && aliasType) {
    beneficiary = {
      name: creditorName,
      nickName: creditorAccountName,
      accountId: aliasId,
    };
  } else {
    beneficiary = {
      name: creditorName,
      nickName: creditorAccountName,
      accountId: creditorAccountId,
    };
  }

  return { beneficiary, creditAccount };
};

export const transformDownstreamResponseToUi = (
  downstreamResponseData: InfPostPaymentDetailsResponse
): ExpPostPaymentDetails => {
  const { paymentDetails = {}, postingDetails = [] } =
    downstreamResponseData.data;

  const {
    debtorAccount = {},
    creditTransferTransactionInformation: [creditTransferTransaction = {}] = [
      {},
    ],
  } = paymentDetails;

  // Required
  const status = mapPaymentDetailsStatusCode(
    paymentDetails?.paymentInformation?.paymentInformationStatus
  );
  const creationDateTime = paymentDetails?.creationDateTime;
  const amount = creditTransferTransaction?.instructedAmount?.amount;
  const amountCurrency = creditTransferTransaction?.instructedAmount?.currency;
  const reversalIndicator = postingDetails.find(
    postingDetail => postingDetail?.debitCreditIndicator === 'C'
  )?.reversalIndicator;
  const debtorAccountName = debtorAccount?.name;
  const debtorAccountId = spacedBsbAndAccountNumber(
    debtorAccount?.identification
  );
  const creditorName = creditTransferTransaction?.creditor?.name;
  const creditorAccountName = creditTransferTransaction?.creditorAccount?.name;
  const creditorAccountId = spacedBsbAndAccountNumber(
    creditTransferTransaction?.creditorAccount?.identification
  );
  const receiptNumber = paymentDetails?.referenceData?.paymentId;
  const paymentMethod = mapPaymentMethod(
    creditTransferTransaction?.paymentTypeInformation?.serviceLevel,
    creditTransferTransaction?.instructionForDebtorAgent
  );

  // Optional
  const debitDescription =
    paymentDetails?.supplementaryData?.debitDescription ?? '';
  const remittanceInformation =
    creditTransferTransaction?.remittanceInformation?.unstructured ?? [];
  const creditorDescription = remittanceInformation.join('');
  const reference =
    creditTransferTransaction?.instructionForDebtorAgent === instructionForDebtorAgentCode.OnMe
      ? null
      : creditTransferTransaction?.endToEndIdentification;
  const { aliasId, aliasType } = creditTransferTransaction?.supplementaryData || {};
  const supplementaryData = (aliasId || aliasType) ? { aliasId, aliasType } : null;

  const { beneficiary, creditAccount } = getBeneficiaryAndCreditAccount(
    creditTransferTransaction,
    creditorName,
    creditorAccountName,
    creditorAccountId,
    aliasId,
    aliasType
  );

  return [
    {
      id: v4(),
      status,
      creationDateTime,
      amount: {
        amount,
        currency: amountCurrency,
      },
      reversalIndicator,
      debitAccount: {
        nickName: debtorAccountName,
        accountId: debtorAccountId,
      },
      debitDescription,
      ...(beneficiary && {
        beneficiary,
      }),
      ...(creditAccount && {
        creditAccount,
      }),
      creditorDescription,
      reference,
      ...(supplementaryData && {
        supplementaryData,
      }),
      ...(paymentMethod && {
        paymentMethod: {
          description: paymentMethod,
        },
      }),
      receiptNumber,
    },
  ];
};

export const validateExpPaymentDetails = ([
  paymentDetails,
]: ExpPostPaymentDetails) => {
  const validations = [
    { field: 'status', isValid: () => paymentDetails?.status != null },
    {
      field: 'amount.amount',
      isValid: () => paymentDetails?.amount?.amount != null,
    },
    {
      field: 'amount.currency',
      isValid: () => paymentDetails?.amount?.currency != null,
    },
    {
      field: 'debitAccount.nickName',
      isValid: () => paymentDetails?.debitAccount?.nickName != null,
    },
    {
      field: 'debitAccount.accountId',
      isValid: () => paymentDetails?.debitAccount?.accountId != null,
    },
    {
      field: 'creditAccount.nickName',
      isValid: () => paymentDetails?.creditAccount?.nickName != null,
    },
    {
      field: 'creditAccount.accountId',
      isValid: () => paymentDetails?.creditAccount?.accountId != null,
    },
    {
      field: 'creditorDescription',
      isValid: () => paymentDetails?.creditorDescription != null,
    },
    { field: 'reference', isValid: () => paymentDetails?.reference != null },
    {
      field: 'paymentMethod.description',
      isValid: () => paymentDetails?.paymentMethod?.description != null,
    },
    {
      field: 'receiptNumber',
      isValid: () => paymentDetails?.receiptNumber != null,
    },
  ];

  const invalidValidation = validations.find(
    validation => !validation.isValid()
  );

  if (invalidValidation) {
    return { isValid: false, invalidField: invalidValidation.field };
  }
  return { isValid: true, invalidField: null };
};
