import { capProdsvcadmProddealacctadmInstlArrngmntsvcngV1ServicesSuccessMocked } from './postArrangementDetailsController.helper.mock';
import { transformDownstreamResponseToUi } from './postArrangementDetailsController.helper';
import { Request } from 'express';

jest.mock('uuid', () => ({
  v4: jest.fn(() => 'cd8d54cb-def0-4ff1-9a72-853332597d53'),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-apiutils'),
  convertSydneyLocalTimeToUtc: jest.fn(date => date),
}));

describe('transformDownstreamResponseToUi', () => {
  const mockRequest = {
    body: { accountId: { BSB: '035845', accountNumber: '10235674897' } },
  } as Request;
  it('should transform a valid downstream response correctly', () => {
    const result = transformDownstreamResponseToUi(
      capProdsvcadmProddealacctadmInstlArrngmntsvcngV1ServicesSuccessMocked,
      200,
      mockRequest
    );
    expect(result).toEqual([
      {
        id: 'cd8d54cb-def0-4ff1-9a72-853332597d53',
        accountId: '035845 10235674897',
        accountNumber: '035845 10235674897',
        entityName: 'ABC Ltd',
        accountName: 'Payroll',
        accountType: 'Corporate Investment Account',
        status: 'ACTIVE',
        currencyCode: 'AUD',
        currentBalance: '-100.9566',
        availableBalance: '-100.9566',
        overdraftLimit: '100.00',
        startDateTime: '2024-04-16 21:56:38',
        closedDateTime: '2024-05-02 14:06:15',
        accountLinks: [
          {
            id: 'd0191d90-81de-49c0-b789-db464c9f7f5a',
            sourceAccountId: {
              BSB: '035845',
              accountNumber: '10235674897',
            },
            targetAccountId: {
              BSB: '035845',
              accountNumber: '10235674897',
            },
            type: 'INTEREST_APPLICATION',
          },
        ],
        debitRateWithinLimit: {
          interestRate: 0.0285,
          fixedVariableType: 'VARIABLE',
          calculationMethod: 'BAND',
          bankInterestRateIndex: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
          indexRate: 0.35,
          indexRateName: 'RBACASH',
          operator: 'ADD',
          spread: 0.01,
        },
        debitRateWithinLimitTierBands: [
          {
            startRange: 0,
            endRange: 1000,
            interestRate: 0.0285,
            operator: 'ADD',
            spread: 0.01,
          },
        ],
        debitRateAboveLimit: {
          interestRate: 0.0285,
          fixedVariableType: 'VARIABLE',
          calculationMethod: 'BAND',
          bankInterestRateIndex: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
          indexRate: 0.35,
          indexRateName: 'RBACASH',
          operator: 'ADD',
          spread: 0.01,
        },
        debitRateAboveLimitTierBands: [
          {
            startRange: 0,
            endRange: 1000,
            interestRate: 0.0285,
            operator: 'ADD',
            spread: 0.01,
          },
        ],
        debitRateAboveLimitOverride: {
          interestRate: 0.0285,
          fixedVariableType: 'VARIABLE',
          calculationMethod: 'BAND',
          bankInterestRateIndex: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
          indexRate: 0.35,
          indexRateName: 'RBACASH',
          operator: 'ADD',
          spread: 0.01,
        },
        debitRateAboveLimitOverrideTierBands: [
          {
            startRange: 0,
            endRange: 1000,
            interestRate: 0.0285,
            operator: 'ADD',
            spread: 0.01,
          },
        ],
        creditRate: {
          interestRate: 0.0285,
          fixedVariableType: 'VARIABLE',
          calculationMethod: 'BAND',
          bankInterestRateIndex: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
          indexRate: 0.35,
          indexRateName: 'RBACASH',
          operator: 'ADD',
          spread: 0.01,
        },
        creditRateTierBands: [
          {
            startRange: 0,
            endRange: 1000,
            interestRate: 0.0285,
            operator: 'ADD',
            spread: 0.01,
          },
        ],
        creditRateCompoundingFrequency: {
          day: 6,
          dayOfWeek: 'MON',
          frequencyType: 'TRIGGERED_DAILY',
          month: 'JAN',
          year: 'string',
        },
      },
    ]);
    const arrangement = result[0];
    expect(arrangement.debitRateWithinLimit).not.toHaveProperty('tierBands');
    expect(arrangement.debitRateAboveLimit).not.toHaveProperty('tierBands');
    expect(arrangement.debitRateAboveLimitOverride).not.toHaveProperty(
      'tierBands'
    );
    expect(arrangement.creditRate).not.toHaveProperty('tierBands');
    expect(arrangement.creditRate).not.toHaveProperty('compoundingFrequency');
  });

  it('should return an empty array if arrangement is missing', () => {
    const capProdsvcadmProddealacctadmInstlArrngmntsvcngV1ServicesSuccessMocked =
      { data: {} };
    expect(
      transformDownstreamResponseToUi(
        capProdsvcadmProddealacctadmInstlArrngmntsvcngV1ServicesSuccessMocked,
        200,
        mockRequest
      )
    ).toEqual([]);
  });

  it('should handle missing nested fields gracefully', () => {
    const result = transformDownstreamResponseToUi(
      capProdsvcadmProddealacctadmInstlArrngmntsvcngV1ServicesSuccessMocked,
      200,
      mockRequest
    );
    // Only check for the fields that must exist and their types, not deep equality
    expect(result).toHaveLength(1);
    const arrangement = result[0];
    expect(arrangement).toMatchObject({
      id: 'cd8d54cb-def0-4ff1-9a72-853332597d53',
      accountNumber: '035845 10235674897',
      entityName: 'ABC Ltd',
      accountName: 'Payroll',
      accountType: 'Corporate Investment Account',
      status: 'ACTIVE',
      currencyCode: 'AUD',
      overdraftLimit: '100.00',
      startDateTime: '2024-04-16 21:56:38',
      closedDateTime: '2024-05-02 14:06:15',
    });
    expect(Array.isArray(arrangement.accountLinks)).toBe(true);
    expect(Array.isArray(arrangement.debitRateWithinLimitTierBands)).toBe(true);
    expect(Array.isArray(arrangement.debitRateAboveLimitTierBands)).toBe(true);
    expect(
      Array.isArray(arrangement.debitRateAboveLimitOverrideTierBands)
    ).toBe(true);
    expect(Array.isArray(arrangement.creditRateTierBands)).toBe(true);
    expect(typeof arrangement.debitRateWithinLimit).toBe('object');
    expect(typeof arrangement.debitRateAboveLimit).toBe('object');
    expect(typeof arrangement.debitRateAboveLimitOverride).toBe('object');
    expect(typeof arrangement.creditRate).toBe('object');
    expect(typeof arrangement.creditRateCompoundingFrequency).toBe('object');
    // Ensure unwanted properties are not present
    expect(arrangement.debitRateWithinLimit).not.toHaveProperty('tierBands');
    expect(arrangement.debitRateAboveLimit).not.toHaveProperty('tierBands');
    expect(arrangement.debitRateAboveLimitOverride).not.toHaveProperty(
      'tierBands'
    );
    expect(arrangement.creditRate).not.toHaveProperty('tierBands');
    expect(arrangement.creditRate).not.toHaveProperty('compoundingFrequency');
  });
});
