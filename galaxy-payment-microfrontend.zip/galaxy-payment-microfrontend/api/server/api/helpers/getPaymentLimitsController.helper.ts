import {
  LimitRule,
  SearchLimitRuleResponse,
} from 'api/interfaces/models/downstream/paymentLimitsServiceV1';
import { GetPaymentLimitsData } from '../../../interfaces/models/galaxyPaymentExp';

export type ExpApiResponseData = {
  paymentLimits: GetPaymentLimitsData['entities']['paymentLimits'];
};

export const transformDownstreamResponseToUi = (
  response: SearchLimitRuleResponse
): ExpApiResponseData => {
  const limitRules: LimitRule[] =
    (response?.data?.limitRules as LimitRule[]) ?? [];
  const expApiLimitRules = limitRules.map((rule: LimitRule, i: number) => ({
    ...rule,
    id: String(rule.id),
  }));

  return {
    paymentLimits: expApiLimitRules,
  };
};
