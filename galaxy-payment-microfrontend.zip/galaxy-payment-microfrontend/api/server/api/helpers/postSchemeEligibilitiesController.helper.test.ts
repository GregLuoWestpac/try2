import { v4 as uuidv4 } from 'uuid';
import { filterAndSortDownstreamResponse, transformDownstreamResponseToUi } from './postSchemeEligibilitiesController.helper';
import { PaymentSchemeEligibilityResponse as DownstreamPaymentSchemeEligibilityResponse } from '../../../interfaces/models/downstream/paymentSchemeEligibilityV1';
import { mapPaymentMethod } from '../../utils/commonHelper';

jest.mock('uuid', () => ({
  v4: jest.fn(),
}));

jest.mock('../../utils/commonHelper', () => ({
  mapPaymentMethod: jest.fn(),
}));

describe('postSchemeEligibilitiesController helper', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should transform the downstream response to UI response', () => {
    const mockUuid = '1234-5678-91011';
    (uuidv4 as jest.Mock).mockReturnValue(mockUuid);
    (mapPaymentMethod as jest.Mock).mockImplementation((name) => `Fast Payment`);

    const downstreamResponse: DownstreamPaymentSchemeEligibilityResponse = {
      data: {
        eligibleServices: [
          { name: "npp.clear.01-sct.01", "status": "AVAILABLE" },
        ],
        paymentMethod: 'OFF_US',
      },
    };

    const expectedResponse = [
      {
        id: mockUuid,
        paymentMethod: {
          code: "npp.clear.01-sct.01",
          description: 'Fast Payment',
        },
      }
    ];

    const result = transformDownstreamResponseToUi(downstreamResponse, false);
    expect(result).toEqual(expectedResponse);
    expect(uuidv4).toHaveBeenCalledTimes(1);
  });

  it('should include ON_US payment method when paymentMethod is ON_US', () => {
    const mockUuid = '1234-5678-91011';
    (uuidv4 as jest.Mock).mockReturnValue(mockUuid);
    (mapPaymentMethod as jest.Mock).mockImplementation((name) => `Fast Payment`);
    
    const downstreamResponse: DownstreamPaymentSchemeEligibilityResponse = {
      data: {
        eligibleServices: [],
        paymentMethod: 'ON_US',
      },
    };

    const expectedResponse = [
      {
        id: mockUuid,
        paymentMethod: {
          code: undefined,
          description: 'Fast Payment',
        },
      },
    ];

    const result = transformDownstreamResponseToUi(downstreamResponse, false);
    expect(result).toEqual(expectedResponse);
    expect(uuidv4).toHaveBeenCalledTimes(1);
  });

  it('should include DE payment scheme when supported', () => {
    const mockUuid = '1234-5678-91011';
    (uuidv4 as jest.Mock).mockReturnValue(mockUuid);
    (mapPaymentMethod as jest.Mock).mockImplementation((name) => `Fast Payment`);

    const downstreamResponse: DownstreamPaymentSchemeEligibilityResponse = {
      data: {
        eligibleServices: [
          { name: "npp.clear.01-sct.01", "status": "AVAILABLE" },
        ],
        paymentMethod: 'OFF_US',
        paymentSchemes: ['DE'],
      },
    };

    const expectedResponse = [
      {
        id: mockUuid,
        paymentMethod: {
          code: 'npp.clear.01-sct.01',
          description: 'Fast Payment',
        },
      },
      {
        id: mockUuid,
        paymentMethod: {
          code: 'NURG',
          description: 'Pay Anyone',
        },
      }
    ];

    const result = transformDownstreamResponseToUi(downstreamResponse, false);
    expect(result).toEqual(expectedResponse);
    expect(uuidv4).toHaveBeenCalledTimes(2);
  });
  describe('filterAndSortDownstreamResponse', () => {
    it('should group eligible services based on priority and return latest version', () => {
      const downstreamResponse: DownstreamPaymentSchemeEligibilityResponse = {
        data: {
          eligibleServices: [
            { name: 'npp.clear.01-sct.01', status: 'Fast Payment' },
            { name: 'npp.clear.01-sct.04', status: 'Fast Payment' },
            { name: 'npp.clear.01-x2p1.04', status: 'Osko' },
            { name: 'npp.clear.01-x2p1.03', status: 'Osko' },
          ],
          paymentMethod: 'OFF_US',
        },
      };

      const expectedServices = [
        { name: 'npp.clear.01-x2p1.04', status: 'Osko' },
        { name: 'npp.clear.01-sct.04', status: 'Fast Payment' },
      ];

      const result = filterAndSortDownstreamResponse(downstreamResponse);
      expect(result).toEqual(expectedServices);
    });

    it('should return latest version and de-duplicate same versions', () => {
      const downstreamResponse: DownstreamPaymentSchemeEligibilityResponse = {
        data: {
          eligibleServices: [
            { name: 'npp.clear.01-sct.01', status: 'Fast Payment' },
            { name: 'npp.clear.01-sct.01', status: 'Fast Payment' },
            { name: 'npp.clear.01-x2p1.04', status: 'Osko' },
            { name: 'npp.clear.01-x2p1.03', status: 'Osko' },
          ],
          paymentMethod: 'OFF_US',
        },
      };

      const expectedServices = [
        { name: 'npp.clear.01-x2p1.04', status: 'Osko' },
        { name: 'npp.clear.01-sct.01', status: 'Fast Payment' },
      ];

      const result = filterAndSortDownstreamResponse(downstreamResponse);
      expect(result).toEqual(expectedServices);
    });
  });
});
