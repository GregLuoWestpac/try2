import { transformGetDivisionListResponse } from './getDivisionListController.helper';
import { PdpQueryResult } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

jest.mock('uuid', () => ({
  v4: jest.fn(() => 'mock-uuid'),
}));

describe('transformGetDivisionListResponse', () => {
  it('should return an empty array if input is not an array', () => {
    // @ts-ignore
    expect(transformGetDivisionListResponse(undefined)).toEqual([]);
    // @ts-ignore
    expect(transformGetDivisionListResponse(null)).toEqual([]);
    // @ts-ignore
    expect(transformGetDivisionListResponse({})).toEqual([]);
  });

  it('should return an empty array if input array is empty', () => {
    expect(transformGetDivisionListResponse([])).toEqual([]);
  });

  it('should transform a single PdpQueryResult correctly', () => {
    const input: PdpQueryResult[] = [
      {
        value: 'division-id-1',
        statements: [
          {
            payload: JSON.stringify({ name: 'Division One' }),
            id: '',
            name: '',
            code: '',
            obligatory: false,
            fulfilled: false,
            attributes: undefined,
          },
        ],
        decision: '',
      },
    ];
    const result = transformGetDivisionListResponse(input);
    expect(result).toEqual([
      {
        id: 'mock-uuid',
        divisionName: 'Division One',
        divisionId: 'division-id-1',
      },
    ]);
  });

  it('should handle missing statements and payload gracefully', () => {
    const input: PdpQueryResult[] = [
      {
        value: 'division-id-2',
        statements: [],
      },
      {
        value: 'division-id-3',
      } as any,
    ];
    const result = transformGetDivisionListResponse(input);
    expect(result).toEqual([
      {
        id: 'mock-uuid',
        divisionName: '',
        divisionId: 'division-id-2',
      },
      {
        id: 'mock-uuid',
        divisionName: '',
        divisionId: 'division-id-3',
      },
    ]);
  });

  it('should sort divisions by divisionName', () => {
    const input: PdpQueryResult[] = [
      {
        value: 'id-2',
        statements: [
          {
            payload: JSON.stringify({ name: 'Bravo' }),
            id: '',
            name: '',
            code: '',
            obligatory: false,
            fulfilled: false,
            attributes: undefined,
          },
        ],
        decision: '',
      },
      {
        value: 'id-1',
        statements: [
          {
            payload: JSON.stringify({ name: 'Alpha' }),
            id: '',
            name: '',
            code: '',
            obligatory: false,
            fulfilled: false,
            attributes: undefined,
          },
        ],
        decision: '',
      },
    ];
    const result = transformGetDivisionListResponse(input);
    expect(result[0].divisionName).toBe('Alpha');
    expect(result[1].divisionName).toBe('Bravo');
  });

  it('should set divisionName to empty string if not present in payload', () => {
    const input: PdpQueryResult[] = [
      {
        value: 'id-5',
        statements: [
          {
            payload: JSON.stringify({}),
            id: '',
            name: '',
            code: '',
            obligatory: false,
            fulfilled: false,
            attributes: undefined,
          },
        ],
        decision: '',
      },
    ];
    const result = transformGetDivisionListResponse(input);
    expect(result[0].divisionName).toBe('');
  });

  it('should set divisionId to empty string if value is missing', () => {
    const input: PdpQueryResult[] = [
      {
        statements: [
          {
            payload: JSON.stringify({ name: 'NoIdDivision' }),
          },
        ],
      } as any,
    ];
    const result = transformGetDivisionListResponse(input);
    expect(result[0].divisionId).toBe('');
    expect(result[0].divisionName).toBe('NoIdDivision');
  });
});
