import { validateWithLibrary } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { ChannelTypeCode } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import get from 'lodash/get';
import { PaymentDetailsResponse } from '../../../interfaces/models/downstream/infBnkngEvntPymntevntInstlPymntevntV1Services';
import {
  PaymentReturnInitiationRequest,
  PaymentReturnRequest,
  PostPaymentReturnsRequest,
} from '../../../interfaces/models/PaymentReturns';
import { ReturnType, SchemeName } from '../../utils/constants';
import {
  detectInjectionVulnerability,
  generatePaymentReturnInitiationRequestDataForCAP,
  generatePaymentReturnsRequestDataForCAP,
  getRemittanceInformation,
  transformPaymentReturnsResponseFromCAPToUI,
  postPaymentReturnCapApiPayload,
  postPaymentReturnInitiationCapApiPayload,
  transformPaymentReturnCapApiResponseToUI,
} from './postPaymentReturnsController.helper';

jest.mock('lodash/get', () => jest.fn());

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-apiutils'),
  validateWithLibrary: jest.fn(),
}));

const mockChannelTypeCode = 'W1C_U_A_CP' as ChannelTypeCode;
const mockDeviceId = 'device-123';

describe('generatePaymentReturnsRequestDataForCAP', () => {
  const mockDataFromUI: PostPaymentReturnsRequest = {
    clientContext: {
      channelType: mockChannelTypeCode,
    },
    transactionInformation: {
      returnedInterbankSettlementAmount: {
        amount: '12.00',
        currency: 'AUD',
      },
      returnReason: {
        reasonCode: 'FOCR',
        additionalInformation: 'Testing outward return',
        returnType: ReturnType.SolicitedReturn,
      },
      supplementaryData: {
        groupCaseId: 'TESTss123456',
        ofiCaseId: 'TEST123456',
        serviceLevel: 'npp.clear.01-x2p1.04',
        paymentDetailsIdType: 'NPPID',
      },
      debtor: {
        issuer: '',
        identification: '',
        name: '',
      },
      debitDescription: '',
      creditor: {
        issuer: '',
        identification: '',
        name: '',
      },
      creditDescription: '',
      paymentReference: '',
      toAnotherAccount: '',
    },
    originalMessageIdentification: '',
  };
  const paymentId = 'WS4184190731718';
  const messageIdentification = 'd3f7fa4be0db482081bec0ba61f7cd43';
  const mockDate = new Date('2024-07-09T04:27:09.589Z');
  global.Date = jest.fn(() => mockDate) as any;
  const paymentDetailsResponseData: PaymentDetailsResponse = {
    paymentDetails: {
      supplementaryData: {
        nppSchemeData: {
          instructingAgent: {
            BICFI: 'CTBAAUSNXXX',
          },
          instructedAgent: {
            BICFI: 'WPACAU3SXXX',
          },
          interbankSettlementAmount: {
            currency: 'AUD',
            amount: '12.00',
          },
          settlementMethod: '',
          acceptanceDateTime: undefined,
          interbankSettlementDate: mockDate,
        },
        debitDescription: '',
      },
      messageIdentification: 'CTBAAUSNXXX20240507000001158103526',
      referenceData: {
        nppMessageDefinitionId: 'pacs.008.001.05',
        nppTransactionId: 'CTBAAUSNXXX20240507000001158103526',
        paymentId: 'WP4123966521137',
        instructionTraceIdentification: '',
        nppDirection: '',
        appCorrelationId: '',
        originatingSystemId: '',
        userId: '',
        userIdSchemeName: '',
      },
      creationDateTime: mockDate,
      creditTransferTransactionInformation: [
        {
          instructionIdentification: '0a220cd176b74ce2adac32b45cb175ad',
          endToEndIdentification: 'PAGFISPOC',
          transactionTraceIdentification: '',
          paymentTypeInformation: {
            serviceLevel: 'npp.clear.01-sct.04',
            localInstrument: '',
            categoryPurpose: 'OTHR',
            instructionPriority: '',
          },
          instructedAmount: {
            amount: '1234.00',
            currency: 'AUD',
          },
          creditor: {
            name: 'creditorName',
          },
          creditorAccount: {
            identification: '035845258524248',
            schemeName: 'BBAN',
            issuer: '035845',
            name: '',
          },
          creditorAgent: {
            BICFI: 'WPACAU3SXXX',
          },
          remittanceInformation: {
            unstructured: ['NikitaDM'],
            creditorReference: '',
          },
          transactionStatus: '',
          statusReasonInformation: [{ reason: '', additionalInformation: '' }],
          regulatoryReporting: { details: { code: '', type: '' } },
          instructionForDebtorAgent: '',
          instructionForCreditorAgent: '',
          supplementaryData: {
            beneficiaryId: '',
            templateId: '',
          },
        },
      ],
      initiatingParty: {
        name: '',
        identification: '',
      },
      groupStatus: '',
      statusReasonInformation: [
        {
          reason: '',
          additionalInformation: '',
        },
      ],
      paymentInformation: {
        paymentMethod: '',
        requestedExecutionDate: undefined,
        numberOfTransactions: '',
        controlSum: '',
        paymentInformationStatus: '',
        statusReasonInformation: [
          {
            reason: '',
            additionalInformation: '',
          },
        ],
      },
      paymentTypeInformation: {
        serviceLevel: '',
        localInstrument: '',
        categoryPurpose: 'OTHR',
        instructionPriority: '',
      },
      debtor: {
        name: 'Tania England',
        identification: '062001456789',
        issuer: '062001',
        contactDetailsName: '',
        privateIdentification: mockDate,
        addressLine: ['Sydney NSW'],
      },
      debtorAccount: {
        identification: '062001456789',
        schemeName: 'BBAN',
        issuer: '062001',
        name: 'Tania England',
      },
      debtorAgent: {
        BICFI: 'CTBAAUSNXXX',
      },
    },
    postingDetails: [
      {
        accountLedgerTransactionId: '',
        accountId: '',
        accountSubscriptionId: '',
        valueDate: mockDate,
        debitCreditIndicator: '',
        postingAmount: {
          amount: '',
          currency: '',
        },
        coreAdapter: '',
      },
    ],
  };
  const FLAN = 'Test';
  const ABN = '123456';
  const ACN = '1234';
  const logger = {
    info: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
    trace: jest.fn(),
    debug: jest.fn(),
  };

  it('should generate the correct PaymentReturnRequest object', () => {
    const expectedData: PaymentReturnRequest = {
      messageIdentification: 'd3f7fa4be0db482081bec0ba61f7cd43',
      creationDateTime: mockDate.toISOString(),
      numberOfTransactions: '1',
      settlementInformation: {
        settlementMethod: 'CLRG',
      },
      instructingAgent: {
        BICFI: 'CTBAAUSNXXX',
      },
      instructedAgent: {
        BICFI: 'WPACAU3SXXX',
      },
      originalGroupInformation: {
        originalMessageIdentification: 'CTBAAUSNXXX20240507000001158103526',
        originalMessageNameIdentification: 'pacs.008.001.05',
        originalCreationDateTime: mockDate.toString(),
      },
      transactionInformation: {
        returnIdentification: 'd3f7fa4be0db482081bec0ba61f7cd43',
        originalInstructionIdentification: '0a220cd176b74ce2adac32b45cb175ad',
        originalEndToEndIdentification: 'PAGFISPOC',
        originalTransactionIdentification: 'CTBAAUSNXXX20240507000001158103526',
        originalInterbankSettlementAmount: {
          currency: 'AUD',
          amount: '12.00',
        },
        returnedInterbankSettlementAmount: {
          currency: 'AUD',
          amount: '12.00',
        },
        returnedInstructedAmount: {
          currency: 'AUD',
          amount: '12.00',
        },
        interbankSettlementDate: mockDate.toISOString(),
        chargeBearer: 'SLEV',
        returnReasonInformation: [
          {
            reason: 'FOCR',
            additionalInformation: ['Testing outward return'],
          },
        ],
        originalTransactionReference: {
          paymentTypeInformation: {
            serviceLevel: 'npp.clear.01-sct.04',
            categoryPurpose: 'OTHR',
          },
          remittanceInformation: {
            unstructured: ['NikitaDM'],
            structured: {
              creditorReferenceInformation: {
                reference: '',
              },
            },
          },
          debtor: {
            name: 'Tania England',
            identification: '062001456789',
            issuer: '062001',
          },
          debtorAccount: {
            identification: '062001456789',
            schemeName: 'BBAN',
            issuer: '062001',
            name: 'Tania England',
          },
          debtorAgent: {
            BICFI: 'CTBAAUSNXXX',
          },
          creditor: {
            name: 'creditorName',
          },
          creditorAccount: {
            identification: '035845258524248',
            schemeName: 'BBAN',
            issuer: '035845',
          },
          creditorAgent: {
            BICFI: 'WPACAU3SXXX',
          },
        },
        supplementaryData: {
          paymentId: 'WS4184190731718',
          originalPaymentId: 'WP4123966521137',
          groupCase: {
            identification: 'TESTss123456',
            creator: {
              BICFI: 'WPACAU3SXXX',
            },
          },
          OFICase: {
            identification: 'TEST123456',
            creator: {
              BICFI: 'CTBAAUSNXXX',
            },
          },
          originalCreditorAdditionalData: {
            FLAN: 'Test',
            ABN: '123456',
          },
          cancellationReasonCode: undefined,
        },
      },
      clientContext: {
        channelType: mockChannelTypeCode,
        deviceId: mockDeviceId,
      },
    };

    const paymetReturnRequestData = generatePaymentReturnsRequestDataForCAP(
      mockDataFromUI,
      paymentId,
      messageIdentification,
      paymentDetailsResponseData,
      FLAN,
      ABN,
      ACN,
      mockDeviceId
    );

    expect(paymetReturnRequestData).toEqual(expectedData);
  });
  it('should generate the correct PaymentReturnRequest object for on-platform payment method', () => {
    const mockDataFromUI: PostPaymentReturnsRequest = {
      clientContext: {
        channelType: mockChannelTypeCode,
      },
      transactionInformation: {
        returnedInterbankSettlementAmount: {
          amount: '12.00',
          currency: 'AUD',
        },
        returnReason: {
          reasonCode: 'FOCR',
          additionalInformation: 'Testing outward return',
          cancellationCode: 'AGNT',
          returnType: ReturnType.SolicitedReturn,
        },
        supplementaryData: {
          groupCaseId: 'TESTss123456',
          ofiCaseId: 'TEST123456',
          serviceLevel: '',
          paymentDetailsIdType: 'PMTID',
        },
        debtor: {
          issuer: '',
          identification: '',
          name: '',
        },
        debitDescription: '',
        creditor: {
          issuer: '',
          identification: '',
          name: '',
        },
        creditDescription: '',
        paymentReference: '',
        toAnotherAccount: 'Yes',
      },
      originalMessageIdentification: '',
    };

    const expectedData: PaymentReturnRequest = {
      messageIdentification: 'd3f7fa4be0db482081bec0ba61f7cd43',
      creationDateTime: mockDate.toISOString(),
      numberOfTransactions: '1',
      settlementInformation: {
        settlementMethod: 'CLRG',
      },
      originalGroupInformation: {
        originalMessageIdentification: 'CTBAAUSNXXX20240507000001158103526',
        originalMessageNameIdentification: 'pacs.008.001.05',
        originalCreationDateTime: mockDate.toString(),
      },
      transactionInformation: {
        returnIdentification: 'd3f7fa4be0db482081bec0ba61f7cd43',
        originalInstructionIdentification: '0a220cd176b74ce2adac32b45cb175ad',
        originalEndToEndIdentification: 'PAGFISPOC',
        originalTransactionIdentification: 'CTBAAUSNXXX20240507000001158103526',
        returnedInterbankSettlementAmount: {
          currency: 'AUD',
          amount: '12.00',
        },
        returnedInstructedAmount: {
          currency: 'AUD',
          amount: '12.00',
        },
        interbankSettlementDate: mockDate.toISOString(),
        chargeBearer: 'SLEV',
        returnReasonInformation: [
          {
            reason: 'FOCR',
            additionalInformation: ['Testing outward return'],
          },
        ],
        originalTransactionReference: {
          paymentTypeInformation: {
            categoryPurpose: 'OTHR',
          },
          remittanceInformation: {
            unstructured: ['NikitaDM'],
            structured: {
              creditorReferenceInformation: {
                reference: '',
              },
            },
          },
          debtor: {
            name: 'Tania England',
            identification: '062001456789',
            issuer: '062001',
          },
          debtorAccount: {
            identification: '062001456789',
            schemeName: 'BBAN',
            issuer: '062001',
            name: 'Tania England',
          },
          debtorAgent: {
            BICFI: 'CTBAAUSNXXX',
          },
          creditor: {
            name: 'creditorName',
          },
          creditorAccount: {
            identification: '035845258524248',
            schemeName: 'BBAN',
            issuer: '035845',
          },
          creditorAgent: {
            BICFI: 'WPACAU3SXXX',
          },
        },
        supplementaryData: {
          paymentId: 'WS4184190731718',
          originalPaymentId: 'WP4123966521137',
          groupCase: {
            identification: 'TESTss123456',
            creator: {
              BICFI: 'WPACAU3SXXX',
            },
          },
          OFICase: {
            identification: 'TEST123456',
            creator: {
              BICFI: 'CTBAAUSNXXX',
            },
          },
          originalCreditorAdditionalData: {
            FLAN: 'Test',
            ABN: '123456',
          },
          cancellationReasonCode: 'AGNT',
        },
      },
      clientContext: {
        channelType: mockChannelTypeCode,
        deviceId: mockDeviceId,
      },
    };

    const paymetReturnRequestData = generatePaymentReturnsRequestDataForCAP(
      mockDataFromUI,
      paymentId,
      messageIdentification,
      paymentDetailsResponseData,
      FLAN,
      ABN,
      ACN,
      mockDeviceId
    );

    expect(paymetReturnRequestData).toEqual(expectedData);
  });
  it('should generate the correct PaymentReturnRequest object without category Purpose ', () => {
    const paymentDetailsResponseData: PaymentDetailsResponse = {
      paymentDetails: {
        supplementaryData: {
          nppSchemeData: {
            instructingAgent: {
              BICFI: 'CTBAAUSNXXX',
            },
            instructedAgent: {
              BICFI: 'WPACAU3SXXX',
            },
            interbankSettlementAmount: {
              currency: 'AUD',
              amount: '12.00',
            },
            settlementMethod: '',
            acceptanceDateTime: undefined,
            interbankSettlementDate: mockDate,
          },
          debitDescription: '',
        },
        messageIdentification: 'CTBAAUSNXXX20240507000001158103526',
        referenceData: {
          nppMessageDefinitionId: 'pacs.008.001.05',
          nppTransactionId: 'CTBAAUSNXXX20240507000001158103526',
          paymentId: 'WP4123966521137',
          instructionTraceIdentification: '',
          nppDirection: '',
          appCorrelationId: '',
          originatingSystemId: '',
          userId: '',
          userIdSchemeName: '',
        },
        creationDateTime: mockDate,
        creditTransferTransactionInformation: [
          {
            instructionIdentification: '0a220cd176b74ce2adac32b45cb175ad',
            endToEndIdentification: 'PAGFISPOC',
            transactionTraceIdentification: '',
            paymentTypeInformation: {
              serviceLevel: 'npp.clear.01-sct.04',
              localInstrument: '',
              categoryPurpose: '',
              instructionPriority: '',
            },
            instructedAmount: {
              amount: '1234.00',
              currency: 'AUD',
            },
            creditor: {
              name: 'creditorName',
            },
            creditorAccount: {
              identification: '035845258524248',
              schemeName: 'BBAN',
              issuer: '035845',
              name: '',
            },
            creditorAgent: {
              BICFI: 'WPACAU3SXXX',
            },
            remittanceInformation: {
              unstructured: ['NikitaDM'],
              creditorReference: '',
            },
            transactionStatus: '',
            statusReasonInformation: [
              { reason: '', additionalInformation: '' },
            ],
            regulatoryReporting: { details: { code: '', type: '' } },
            instructionForDebtorAgent: '',
            instructionForCreditorAgent: '',
            supplementaryData: {
              beneficiaryId: '',
              templateId: '',
            },
          },
        ],
        initiatingParty: {
          name: '',
          identification: '',
        },
        groupStatus: '',
        statusReasonInformation: [
          {
            reason: '',
            additionalInformation: '',
          },
        ],
        paymentInformation: {
          paymentMethod: '',
          requestedExecutionDate: undefined,
          numberOfTransactions: '',
          controlSum: '',
          paymentInformationStatus: '',
          statusReasonInformation: [
            {
              reason: '',
              additionalInformation: '',
            },
          ],
        },
        paymentTypeInformation: {
          serviceLevel: '',
          localInstrument: '',
          categoryPurpose: 'OTHR',
          instructionPriority: '',
        },
        debtor: {
          name: 'Tania England',
          identification: '062001456789',
          issuer: '062001',
          contactDetailsName: '',
          privateIdentification: mockDate,
          addressLine: ['Sydney NSW'],
        },
        debtorAccount: {
          identification: '062001456789',
          schemeName: 'BBAN',
          issuer: '062001',
          name: 'Tania England',
        },
        debtorAgent: {
          BICFI: 'CTBAAUSNXXX',
        },
      },
      postingDetails: [
        {
          accountLedgerTransactionId: '',
          accountId: '',
          accountSubscriptionId: '',
          valueDate: mockDate,
          debitCreditIndicator: '',
          postingAmount: {
            amount: '',
            currency: '',
          },
          coreAdapter: '',
        },
      ],
    };
    const expectedData: PaymentReturnRequest = {
      messageIdentification: 'd3f7fa4be0db482081bec0ba61f7cd43',
      creationDateTime: mockDate.toISOString(),
      numberOfTransactions: '1',
      settlementInformation: {
        settlementMethod: 'CLRG',
      },
      instructingAgent: {
        BICFI: 'CTBAAUSNXXX',
      },
      instructedAgent: {
        BICFI: 'WPACAU3SXXX',
      },
      originalGroupInformation: {
        originalMessageIdentification: 'CTBAAUSNXXX20240507000001158103526',
        originalMessageNameIdentification: 'pacs.008.001.05',
        originalCreationDateTime: mockDate.toString(),
      },
      transactionInformation: {
        returnIdentification: 'd3f7fa4be0db482081bec0ba61f7cd43',
        originalInstructionIdentification: '0a220cd176b74ce2adac32b45cb175ad',
        originalEndToEndIdentification: 'PAGFISPOC',
        originalTransactionIdentification: 'CTBAAUSNXXX20240507000001158103526',
        originalInterbankSettlementAmount: {
          currency: 'AUD',
          amount: '12.00',
        },
        returnedInterbankSettlementAmount: {
          currency: 'AUD',
          amount: '12.00',
        },
        returnedInstructedAmount: {
          currency: 'AUD',
          amount: '12.00',
        },
        interbankSettlementDate: mockDate.toISOString(),
        chargeBearer: 'SLEV',
        returnReasonInformation: [
          {
            reason: 'FOCR',
            additionalInformation: ['Testing outward return'],
          },
        ],
        originalTransactionReference: {
          paymentTypeInformation: {
            serviceLevel: 'npp.clear.01-sct.04',
          },
          remittanceInformation: {
            unstructured: ['NikitaDM'],
            structured: {
              creditorReferenceInformation: {
                reference: '',
              },
            },
          },
          debtor: {
            name: 'Tania England',
            identification: '062001456789',
            issuer: '062001',
          },
          debtorAccount: {
            identification: '062001456789',
            schemeName: 'BBAN',
            issuer: '062001',
            name: 'Tania England',
          },
          debtorAgent: {
            BICFI: 'CTBAAUSNXXX',
          },
          creditor: {
            name: 'creditorName',
          },
          creditorAccount: {
            identification: '035845258524248',
            schemeName: 'BBAN',
            issuer: '035845',
          },
          creditorAgent: {
            BICFI: 'WPACAU3SXXX',
          },
        },
        supplementaryData: {
          paymentId: 'WS4184190731718',
          originalPaymentId: 'WP4123966521137',
          groupCase: {
            identification: 'TESTss123456',
            creator: {
              BICFI: 'WPACAU3SXXX',
            },
          },
          OFICase: {
            identification: 'TEST123456',
            creator: {
              BICFI: 'CTBAAUSNXXX',
            },
          },
          originalCreditorAdditionalData: {
            FLAN: 'Test',
            ABN: '123456',
          },
          cancellationReasonCode: undefined,
        },
      },
      clientContext: {
        channelType: mockChannelTypeCode,
        deviceId: mockDeviceId,
      },
    };

    const paymetReturnRequestData = generatePaymentReturnsRequestDataForCAP(
      mockDataFromUI,
      paymentId,
      messageIdentification,
      paymentDetailsResponseData,
      FLAN,
      ABN,
      ACN,
      mockDeviceId
    );

    expect(paymetReturnRequestData).toEqual(expectedData);
  });
  it('should include ABN in paymentReturnRequest only ABN is present', () => {
    const mockABN = '123456';
    const mockACN = null;
    const paymetReturnRequestData = generatePaymentReturnsRequestDataForCAP(
      mockDataFromUI,
      paymentId,
      messageIdentification,
      paymentDetailsResponseData,
      FLAN,
      mockABN,
      mockACN,
      mockDeviceId
    );
    expect(
      paymetReturnRequestData.transactionInformation.supplementaryData
        .originalCreditorAdditionalData.ABN
    ).toEqual(mockABN);
  });
  it('should include ABN in paymentReturnRequest when both ABN and ACN are present', () => {
    const mockABN = '123456';
    const mockACN = '1234';
    const paymetReturnRequestData = generatePaymentReturnsRequestDataForCAP(
      mockDataFromUI,
      paymentId,
      messageIdentification,
      paymentDetailsResponseData,
      FLAN,
      mockABN,
      mockACN,
      mockDeviceId
    );
    expect(
      paymetReturnRequestData.transactionInformation.supplementaryData
        .originalCreditorAdditionalData.ABN
    ).toEqual(mockABN);
  });
  it('should include ACN in paymentReturnRequest when ABN is null or empty', () => {
    const mockABN = null;
    const mockACN = '123456';
    const paymetReturnRequestData = generatePaymentReturnsRequestDataForCAP(
      mockDataFromUI,
      paymentId,
      messageIdentification,
      paymentDetailsResponseData,
      FLAN,
      mockABN,
      mockACN,
      mockDeviceId
    );
    expect(
      paymetReturnRequestData.transactionInformation.supplementaryData
        .originalCreditorAdditionalData.ABN
    ).toEqual(mockACN);
    const mockABN2 = '';
    const paymetReturnRequestData2 = generatePaymentReturnsRequestDataForCAP(
      mockDataFromUI,
      paymentId,
      messageIdentification,
      paymentDetailsResponseData,
      FLAN,
      mockABN2,
      mockACN,
      mockDeviceId
    );
    expect(
      paymetReturnRequestData2.transactionInformation.supplementaryData
        .originalCreditorAdditionalData.ABN
    ).toEqual(mockACN);
    const mockABN3 = undefined;
    const paymetReturnRequestData3 = generatePaymentReturnsRequestDataForCAP(
      mockDataFromUI,
      paymentId,
      messageIdentification,
      paymentDetailsResponseData,
      FLAN,
      mockABN3,
      mockACN,
      mockDeviceId
    );
    expect(
      paymetReturnRequestData3.transactionInformation.supplementaryData
        .originalCreditorAdditionalData.ABN
    ).toEqual(mockACN);
  });
  it('should include mandateIdentification in paymentReturnRequest only mandateIdentification is present', () => {
    const mockABN = '123456';
    const mockACN = null;
    const mandateIdentification = '123456789-123456789-123456789-12345';
    const paymentDetailsRes = {
      paymentDetails: {
        ...paymentDetailsResponseData.paymentDetails,
        referenceData: {
          ...paymentDetailsResponseData.paymentDetails.referenceData,
          mandateIdentification,
        },
      },
      postingDetails: { ...paymentDetailsResponseData.postingDetails },
    };
    const paymentReturnRequestData = generatePaymentReturnsRequestDataForCAP(
      mockDataFromUI,
      paymentId,
      messageIdentification,
      paymentDetailsRes,
      FLAN,
      mockABN,
      mockACN,
      mockDeviceId
    );
    expect(
      paymentReturnRequestData.transactionInformation
        .originalTransactionReference.mandateRelatedInformation
        .mandateIdentification
    ).toEqual(mandateIdentification);
  });

  it('should generate the correct PaymentReturnRequest with empty values for optional fields', () => {
    const mockDataFromUI: PostPaymentReturnsRequest = {
      clientContext: {
        channelType: mockChannelTypeCode,
      },
      transactionInformation: {
        returnedInterbankSettlementAmount: {
          amount: '12.00',
          currency: 'AUD',
        },
        returnReason: {
          reasonCode: 'FOCR',
          additionalInformation: 'Testing outward return',
          cancellationCode: 'AGNT',
          returnType: ReturnType.SolicitedReturn,
        },
        supplementaryData: {
          groupCaseId: '',
          ofiCaseId: '',
          serviceLevel: 'Fast payment',
          paymentDetailsIdType: 'PMTID',
        },
        debtor: {
          issuer: '',
          identification: '',
          name: '',
        },
        debitDescription: '',
        creditor: {
          issuer: '',
          identification: '',
          name: '',
        },
        creditDescription: '',
        paymentReference: '',
        toAnotherAccount: '',
      },
      originalMessageIdentification: '',
    };
    const expectedData: PaymentReturnRequest = {
      messageIdentification: 'd3f7fa4be0db482081bec0ba61f7cd43',
      creationDateTime: mockDate.toISOString(),
      numberOfTransactions: '1',
      settlementInformation: {
        settlementMethod: 'CLRG',
      },
      instructingAgent: {
        BICFI: 'CTBAAUSNXXX',
      },
      instructedAgent: {
        BICFI: 'WPACAU3SXXX',
      },
      originalGroupInformation: {
        originalMessageIdentification: 'CTBAAUSNXXX20240507000001158103526',
        originalMessageNameIdentification: 'pacs.008.001.05',
        originalCreationDateTime: mockDate.toString(),
      },
      transactionInformation: {
        returnIdentification: 'd3f7fa4be0db482081bec0ba61f7cd43',
        originalInstructionIdentification: '0a220cd176b74ce2adac32b45cb175ad',
        originalEndToEndIdentification: 'PAGFISPOC',
        originalTransactionIdentification: 'CTBAAUSNXXX20240507000001158103526',
        originalInterbankSettlementAmount: {
          currency: 'AUD',
          amount: '12.00',
        },
        returnedInterbankSettlementAmount: {
          currency: 'AUD',
          amount: '12.00',
        },
        returnedInstructedAmount: {
          currency: 'AUD',
          amount: '12.00',
        },
        interbankSettlementDate: mockDate.toISOString(),
        chargeBearer: 'SLEV',
        returnReasonInformation: [
          {
            reason: 'FOCR',
            additionalInformation: ['Testing outward return'],
          },
        ],
        originalTransactionReference: {
          paymentTypeInformation: {
            categoryPurpose: 'OTHR',
            serviceLevel: 'npp.clear.01-sct.04',
          },
          remittanceInformation: {
            unstructured: ['NikitaDM'],
            structured: {
              creditorReferenceInformation: {
                reference: '',
              },
            },
          },
          debtor: {
            name: 'Tania England',
            identification: '062001456789',
            issuer: '062001',
          },
          debtorAccount: {
            identification: '062001456789',
            schemeName: 'BBAN',
            issuer: '062001',
            name: 'Tania England',
          },
          debtorAgent: {
            BICFI: 'CTBAAUSNXXX',
          },
          creditor: {
            name: 'creditorName',
          },
          creditorAccount: {
            identification: '035845258524248',
            schemeName: 'BBAN',
            issuer: '035845',
          },
          creditorAgent: {
            BICFI: 'WPACAU3SXXX',
          },
        },
        supplementaryData: {
          paymentId: 'WS4184190731718',
          originalPaymentId: 'WP4123966521137',
          originalCreditorAdditionalData: {
            FLAN: 'Test',
            ABN: '123456',
          },
          cancellationReasonCode: 'AGNT',
        },
      },
      clientContext: {
        channelType: mockChannelTypeCode,
        deviceId: mockDeviceId,
      },
    };

    const paymetReturnRequestData = generatePaymentReturnsRequestDataForCAP(
      mockDataFromUI,
      paymentId,
      messageIdentification,
      paymentDetailsResponseData,
      FLAN,
      ABN,
      ACN,
      mockDeviceId
    );

    expect(paymetReturnRequestData).toEqual(expectedData);
  });

  it('should generate the correct PaymentReturnInitiation object for payment method as Osko', () => {
    const expectedData: PaymentReturnInitiationRequest = {
      messageIdentification: 'd3f7fa4be0db482081bec0ba61f7cd43',
      creationDateTime: mockDate.toISOString(),
      initiatingParty: {
        name: 'agent',
        identification: 'M12345',
      },
      paymentInformation: {
        paymentMethod: 'TRF',
        requestedExecutionDate: mockDate.toISOString(),
        numberOfTransactions: '1',
      },
      debtor: {
        name: 'creditorName',
      },
      debtorAccount: {
        identification: '035845258524248',
        schemeName: 'BBAN',
        issuer: '035845',
        name: 'debtor',
      },
      debtorAgent: {
        BICFI: 'WPACAU3SXXX',
      },
      creditTransferTransactionInformation: [
        {
          instructionIdentification: 'd3f7fa4be0db482081bec0ba61f7cd43',
          endToEndIdentification: 'NOTPROVIDED',
          paymentTypeInformation: {
            serviceLevel: 'npp.clear.01-x2p1.04',
            categoryPurpose: 'OTHR',
          },
          instructedAmount: {
            amount: '12.00',
            currency: 'AUD',
          },
          creditor: {
            name: '',
          },
          creditorAccount: {
            identification: '',
            schemeName: 'BBAN',
            issuer: '',
          },
          creditorAgent: {
            BICFI: 'XXXXXXXXXXX',
          },
          remittanceInformation: {
            unstructured: ['/CaseId/TEST123456/Testing outward return'],
          },
        },
      ],
      supplementaryData: {
        paymentId: 'WS4184190731718',
        debitDescription: null,
      },
      clientContext: {
        channelType: mockChannelTypeCode,
        deviceId: mockDeviceId,
      },
    };

    const userId = 'M12345';
    const userIdScheme = 'agent';

    const paymetReturnRequestData =
      generatePaymentReturnInitiationRequestDataForCAP(
        userId,
        userIdScheme,
        mockDataFromUI,
        paymentId,
        messageIdentification,
        paymentDetailsResponseData,
        mockDeviceId
      );

    expect(paymetReturnRequestData).toEqual(expectedData);
  });

  it('should generate the correct PaymentReturnInitiation object for payment method as Fast Payment', () => {
    const mockDataFromUI: PostPaymentReturnsRequest = {
      clientContext: {
        channelType: mockChannelTypeCode,
      },
      transactionInformation: {
        returnedInterbankSettlementAmount: {
          amount: '12.00',
          currency: 'AUD',
        },
        returnReason: {
          reasonCode: 'FOCR',
          additionalInformation: 'Testing outward return',
          cancellationCode: 'AGNT',
          returnType: ReturnType.SolicitedReturn,
        },
        supplementaryData: {
          groupCaseId: 'TESTss123456',
          ofiCaseId: 'TEST123456',
          serviceLevel: 'npp.clear.01-sct.04',
          paymentDetailsIdType: 'PMTID',
        },
        debtor: {
          issuer: '',
          identification: '',
          name: '',
        },
        debitDescription: '',
        creditor: {
          issuer: '',
          identification: '',
          name: '',
        },
        creditDescription: '',
        paymentReference: '',
        toAnotherAccount: 'Yes',
      },
      originalMessageIdentification: '',
    };

    const expectedData: PaymentReturnInitiationRequest = {
      messageIdentification: 'd3f7fa4be0db482081bec0ba61f7cd43',
      creationDateTime: mockDate.toISOString(),
      initiatingParty: {
        name: 'agent',
        identification: 'M12345',
      },
      paymentInformation: {
        paymentMethod: 'TRF',
        requestedExecutionDate: mockDate.toISOString(),
        numberOfTransactions: '1',
      },
      debtor: {
        name: 'creditorName',
      },
      debtorAccount: {
        identification: '035845258524248',
        schemeName: 'BBAN',
        issuer: '035845',
        name: 'debtor',
      },
      debtorAgent: {
        BICFI: 'WPACAU3SXXX',
      },
      creditTransferTransactionInformation: [
        {
          instructionIdentification: 'd3f7fa4be0db482081bec0ba61f7cd43',
          endToEndIdentification: 'NOTPROVIDED',
          paymentTypeInformation: {
            serviceLevel: 'npp.clear.01-sct.04',
            categoryPurpose: 'OTHR',
          },
          instructedAmount: {
            amount: '12.00',
            currency: 'AUD',
          },
          creditor: {
            name: '',
          },
          creditorAccount: {
            identification: '',
            schemeName: 'BBAN',
            issuer: '',
          },
          creditorAgent: {
            BICFI: 'XXXXXXXXXXX',
          },
          remittanceInformation: {
            unstructured: ['/CaseId/TEST123456/Testing outward return'],
          },
        },
      ],
      supplementaryData: {
        paymentId: 'WS4184190731718',
        debitDescription: null,
      },
      clientContext: {
        channelType: mockChannelTypeCode,
        deviceId: mockDeviceId,
      },
    };

    const userId = 'M12345';
    const userIdScheme = 'agent';

    const paymetReturnRequestData =
      generatePaymentReturnInitiationRequestDataForCAP(
        userId,
        userIdScheme,
        mockDataFromUI,
        paymentId,
        messageIdentification,
        paymentDetailsResponseData,
        mockDeviceId
      );

    expect(paymetReturnRequestData).toEqual(expectedData);
  });

  it('should generate the correct PaymentReturnInitiation object for payment method as PayTo', () => {
    const mockDataFromUI: PostPaymentReturnsRequest = {
      clientContext: {
        channelType: mockChannelTypeCode,
      },
      transactionInformation: {
        returnedInterbankSettlementAmount: {
          amount: '12.00',
          currency: 'AUD',
        },
        returnReason: {
          reasonCode: 'FOCR',
          additionalInformation: 'Testing outward return',
          returnType: ReturnType.SolicitedReturn,
        },
        supplementaryData: {
          groupCaseId: 'TESTss123456',
          ofiCaseId: 'TEST123456',
          serviceLevel: 'npp.clear.01-sct.04',
          paymentDetailsIdType: 'PMTID',
        },
        debtor: {
          issuer: '',
          identification: '',
          name: '',
        },
        debitDescription: '',
        creditor: {
          issuer: '',
          identification: '',
          name: '',
        },
        creditDescription: '',
        paymentReference: '',
        toAnotherAccount: 'Yes',
      },
      originalMessageIdentification: '',
    };
    const expectedData: PaymentReturnInitiationRequest = {
      messageIdentification: 'd3f7fa4be0db482081bec0ba61f7cd43',
      creationDateTime: mockDate.toISOString(),
      initiatingParty: {
        name: 'agent',
        identification: 'M12345',
      },
      paymentInformation: {
        paymentMethod: 'TRF',
        requestedExecutionDate: mockDate.toISOString(),
        numberOfTransactions: '1',
      },
      debtor: {
        name: 'creditorName',
      },
      debtorAccount: {
        identification: '035845258524248',
        schemeName: 'BBAN',
        issuer: '035845',
        name: 'debtor',
      },
      debtorAgent: {
        BICFI: 'WPACAU3SXXX',
      },
      creditTransferTransactionInformation: [
        {
          instructionIdentification: 'd3f7fa4be0db482081bec0ba61f7cd43',
          endToEndIdentification: 'NOTPROVIDED',
          paymentTypeInformation: {
            categoryPurpose: 'OTHR',
            serviceLevel: 'npp.clear.01-sct.04',
          },
          instructedAmount: {
            amount: '12.00',
            currency: 'AUD',
          },
          creditor: {
            name: '',
          },
          creditorAccount: {
            identification: '',
            schemeName: 'BBAN',
            issuer: '',
          },
          creditorAgent: {
            BICFI: 'XXXXXXXXXXX',
          },
          remittanceInformation: {
            unstructured: [
              '/CaseId/TEST123456/MndtId/123456789-123456789-123456789-12345/Testing outward return',
            ],
          },
        },
      ],
      supplementaryData: {
        paymentId: 'WS4184190731718',
        debitDescription: null,
      },
      clientContext: {
        channelType: mockChannelTypeCode,
        deviceId: mockDeviceId,
      },
    };
    const userId = 'M12345';
    const userIdScheme = 'agent';
    const paymentDetailsRes = {
      paymentDetails: {
        ...paymentDetailsResponseData.paymentDetails,
        referenceData: {
          ...paymentDetailsResponseData.paymentDetails.referenceData,
          mandateIdentification: '123456789-123456789-123456789-12345',
        },
      },
      postingDetails: { ...paymentDetailsResponseData.postingDetails },
    };

    const paymentReturnRequestData =
      generatePaymentReturnInitiationRequestDataForCAP(
        userId,
        userIdScheme,
        mockDataFromUI,
        paymentId,
        messageIdentification,
        paymentDetailsRes,
        mockDeviceId
      );

    expect(paymentReturnRequestData).toEqual(expectedData);
  });

  it('transforms payments CAP data to UI format correctly', () => {
    const capData = {
      data: {
        paymentStatusReport: {
          messageIdentification: 'WPACAU2SXXX20180711Y30000001218911',
          creationDateTime: '2024-02-01T02:43:55.281Z',
          groupInformation: {
            originalCreationDateTime: '2024-02-01T02:43:55.281Z',
            originalNumberOfTransactions: '1000',
            originalControlSum: '6568954',
            groupStatus: 'Deferred',
            statusReasonInformation: [
              {
                reason: 'You should provide a reason',
                additionalInformation:
                  ' Date and time at which the original message was sent',
              },
            ],
          },
          paymentInformation: {
            paymentInformationStatus: 'Online',
            statusReasonInformation: [
              {
                reason: 'Checked',
                additionalInformation:
                  'Date and time at which the original message was sent',
              },
            ],
            transactionInformation: [
              {
                originalEndToEndIdentification: '4545454563632000',
                statusReasonInformation: [
                  {
                    reason: 'string',
                    additionalInformation: 'Date and time at mesg sent',
                  },
                ],
                transactionStatus: 'Deferred',
                additionalInformation: 'Again the same info',
              },
            ],
            supplementaryData: {
              paymentId: '9f712e23-6b5f-4b63-aa72-ad149c716c9f',
            },
          },
        },
      },
    };
    const mockedMessageIdentification = 'd0868661-b955-4e76-9f15-d97626f7df6b';
    const isPaymentReturn = false;
    const result = transformPaymentReturnsResponseFromCAPToUI(
      isPaymentReturn,
      capData,
      logger,
      202,
      123456789,
      mockedMessageIdentification
    );
    expect(result).toHaveLength(1);
  });

  it('transforms returns CAP data to UI format correctly', () => {
    const capData = {
      data: {
        paymentReturnStatusReport: {
          messageIdentification: '23092054868f49ba8a4bc94647e82075',
          creationDateTime: '2024-07-23T01:18:10.396Z',
          groupInformation: {
            groupStatus: 'RJCT',
            statusReasonInformation: [
              {
                reason: 'ValidationFailure',
              },
            ],
          },
          transactionInformation: {
            transactionStatus: 'RJCT',
            statusReasonInformation: [
              {
                reason: 'ValidationFailure',
                additionalInformation:
                  '{"message":"OriginalTransactionIdentification is mandatory","path":"$.transactionInformation[0]"}',
              },
            ],
            supplementaryData: {
              paymentId: 'WP4123966521137',
            },
          },
        },
      },
    };
    const mockedMessageIdentification = 'd0868661-b955-4e76-9f15-d97626f7df6b';
    const isPaymentReturn = true;
    const result = transformPaymentReturnsResponseFromCAPToUI(
      isPaymentReturn,
      capData,
      logger,
      201,
      123456789,
      mockedMessageIdentification
    );
    expect(result).toHaveLength(1);
  });
  it('should return an array with a single item when additionalInfo is less than or equal to 140 characters and ofiCaseId is not present', () => {
    const additionalInfo =
      'Customer requested a refund due to incorrect charge.';
    const result = getRemittanceInformation(additionalInfo);
    expect(result).toEqual([additionalInfo]);
  });

  it('should return an array with a single item when additionalInfo is less than or equal to 140 characters and ofiCaseId is present', () => {
    const additionalInfo =
      'Customer requested a refund due to incorrect charge.';
    const ofiCaseId = 'TEST123456';
    const expected = `/CaseId/${ofiCaseId}/${additionalInfo}`;
    const result = getRemittanceInformation(additionalInfo, ofiCaseId);
    expect(result).toEqual([expected]);
  });

  it('should return an array with two items when additionalInfo is greater than 140 characters and ofiCaseId is not present', () => {
    const additionalInfo =
      'Payment return request has been logged. Review the transaction and details. To payment return request has been logged. Review the transaction and details.';
    const ofiCaseId = '';
    const expected = [
      'Payment return request has been logged. Review the transaction and details. To payment return request has been logged. Review the transactio',
      'n and details.',
    ];
    const result = getRemittanceInformation(additionalInfo, ofiCaseId);
    expect(result).toEqual(expected);
  });

  it('should return an array with two items when additionalInfo is greater than 140 characters and ofiCaseId is present', () => {
    const additionalInfo =
      'Payment return request has been logged. Review the transaction and details. To payment return request has been logged. Review the transaction and details.';
    const ofiCaseId = 'TEST123456';
    const expected = [
      `/CaseId/TEST123456/Payment return request has been logged. Review the transaction and details. To payment return request has been logged. Re`,
      'view the transaction and details.',
    ];
    const result = getRemittanceInformation(additionalInfo, ofiCaseId);
    expect(result).toEqual(expected);
  });
});

describe('getRemittanceInformation()', () => {
  it('should return formatted mandate Id', () => {
    const additionalInfo = 'test info';
    const ofiCaseId = '';
    const mandateId = '123456789-123456789-123456789-12345';
    const [formattedMandateId] = getRemittanceInformation(
      additionalInfo,
      ofiCaseId,
      mandateId
    );
    expect(formattedMandateId).toBe(
      '/MndtId/123456789-123456789-123456789-12345/test info'
    );
  });

  it('should not return formatted mandate Id when it is empty', () => {
    const additionalInfo = 'test info';
    const ofiCaseId = '';
    const mandateId = '';
    const remittanceInfo = getRemittanceInformation(
      additionalInfo,
      ofiCaseId,
      mandateId
    );
    expect(remittanceInfo.length).toBe(1);
    expect(remittanceInfo[0]).toBe(additionalInfo);
  });
});

describe('detectInjectionVulnerability', () => {
  const mockGet = get as jest.Mock;
  const mockValidate = validateWithLibrary as jest.Mock;
  const baseRequest: PostPaymentReturnsRequest = {
    clientContext: {
      channelType: mockChannelTypeCode,
    },
    originalMessageIdentification: '',
    transactionInformation: {
      debtor: {
        name: 'John',
        issuer: '121212',
        identification: '2121212',
      },
      creditor: {
        name: 'Doe',
        issuer: '121212',
        identification: '2121212',
      },
      debitDescription: 'Monthly bill',
      creditDescription: '',
      paymentReference: 'REF1234',
      toAnotherAccount: '',
      returnedInterbankSettlementAmount: {
        amount: '',
        currency: '',
      },
      returnReason: {
        reasonCode: '',
        additionalInformation: '',
        returnType: '',
      },
      supplementaryData: {
        groupCaseId: '',
        ofiCaseId: '',
        serviceLevel: '',
        paymentDetailsIdType: '',
      },
    },
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should return no vulnerabilities when all values are safe', () => {
    mockGet.mockImplementation((obj, path) => {
      return path.split('.').reduce((o, k) => (o ? o[k] : undefined), obj);
    });
    mockValidate.mockReturnValue(false);
    const result = detectInjectionVulnerability(baseRequest);
    expect(result).toEqual({
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    });
    expect(mockValidate).toHaveBeenCalledTimes(4);
  });

  it('should detect a vulnerability in debtor name', () => {
    mockGet.mockImplementation((obj, path) => {
      return path === 'transactionInformation.debtor.name'
        ? '<script>alert("XSS==")</script>'
        : path.split('.').reduce((o, k) => (o ? o[k] : undefined), obj);
    });

    mockValidate.mockImplementation((value: string) => value.includes('alert'));

    const result = detectInjectionVulnerability(baseRequest);
    expect(result.vulnerabilityDetected).toBe(true);
    expect(result.vulnerableFields).toContain(
      'transactionInformation.debtor.name'
    );
  });

  it('should skip null or empty values', () => {
    mockGet.mockReturnValue(null);
    mockValidate.mockReturnValue(false);

    const result = detectInjectionVulnerability(baseRequest);
    expect(result).toEqual({
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    });
    expect(mockValidate).not.toHaveBeenCalled();
  });

  it('should detect multiple vulnerabilities', () => {
    mockGet.mockImplementation((obj, path) => {
      switch (path) {
        case 'transactionInformation.debtor.name':
          return 'John<script>';
        case 'transactionInformation.creditor.name':
          return 'Doe<script>';
        default:
          return path.split('.').reduce((o, k) => (o ? o[k] : undefined), obj);
      }
    });

    mockValidate.mockImplementation((value: string) =>
      value.includes('<script>')
    );

    const result = detectInjectionVulnerability(baseRequest);
    expect(result.vulnerabilityDetected).toBe(true);
    expect(result.vulnerableFields.length).toBe(2);
    expect(result.vulnerableFields).toContain(
      'transactionInformation.debtor.name'
    );
    expect(result.vulnerableFields).toContain(
      'transactionInformation.creditor.name'
    );
  });

  it('should handle missing nested fields safely', () => {
    const incompleteRequest = { transactionInformation: {} };

    mockGet.mockReturnValue(undefined);
    mockValidate.mockReturnValue(false);

    const result = detectInjectionVulnerability(incompleteRequest as any);
    expect(result).toEqual({
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    });
    expect(mockValidate).not.toHaveBeenCalled();
  });
});

jest.mock('uuid', () => ({
  v4: () => 'mock-uuid-12345',
}));

jest.mock('../../utils/commonHelper', () => ({
  removeEmptyKeys: jest.fn((obj) => obj),
}));

describe('postPaymentReturnCapApiPayload', () => {
  let mockDataFromUI: PostPaymentReturnsRequest;
  let mockPaymentId: string;
  let mockMessageIdentification: string;
  let mockDeviceId: string;

  beforeEach(() => {
    mockPaymentId = 'payment-123';
    mockMessageIdentification = 'message-456';
    mockDeviceId = 'device-789';

    mockDataFromUI = {
      clientContext: {
        channelType: 'ONLINE',
      },
      originalMessageIdentification: 'original-msg-123',
      transactionInformation: {
        returnReason: {
          reasonCode: 'AC04',
          additionalInformation: 'Account closed',
          returnType: 'RETURN',
          cancellationCode: 'CANC001',
        },
        debtor: {
          issuer: '012345',
          identification: '123456789',
          name: 'John Doe',
        },
        debitDescription: 'Return payment',
        creditor: {
          issuer: '678901',
          identification: '987654321',
          name: 'Jane Smith',
        },
        creditDescription: 'Credit return',
        paymentReference: 'REF123',
        toAnotherAccount: 'No',
        returnedInterbankSettlementAmount: {
          currency: 'AUD',
          amount: '1000.00',
        },
        supplementaryData: {
          paymentDetailsIdType: 'PAYMENTID',
        },
      },
    } as PostPaymentReturnsRequest;
  });

  describe('Basic functionality', () => {
    it('should create correct payload structure with all required fields', () => {
      const result = postPaymentReturnCapApiPayload(
        mockDataFromUI,
        mockPaymentId,
        mockMessageIdentification,
        mockDeviceId
      );

      const expectedData = {
        paymentReturn: {
          returnIdentification: mockMessageIdentification,
          returnReasonInformation: {
            returnReason: {
              code: 'AC04',
              additionalInformation: ['Account closed'],
            },
            cancellationReason: {
              code: 'CANC001',
            },
          },
          relatedPaymentInformation: {
            originalPaymentId: 'original-msg-123',
            originalPaymentIdType: 'PAYMT_INSTR_ID',
          },
          returnedInstructedAmount: {
            currencyCode: 'AUD',
            amount: '1000.00',
          },
          originalTransactionReference: {
            creditorAccount: {
              identification: {
                other: {
                  identification: '012345123456789',
                  schemeName: {
                    schemeNameType: 'SchemeNameCode',
                    code: SchemeName.BBAN,
                  },
                },
              },
            },
          },
          clientContext: {
            deviceId: mockDeviceId,
            channelType: 'ONLINE',
            initiatingUser: {
              orgCISKey: '',
            },
          },
        },
        paymentDomainMetadata: {
          channelId: 'ONLINE',
          paymentInstructionId: mockPaymentId,
          WBCE2EPaymentId: 'mock-uuid-12345',
        },
      };
      
      expect(result).toEqual(expectedData);
    });

    it('should handle NPPID payment details ID type', () => {
      mockDataFromUI.transactionInformation.supplementaryData.paymentDetailsIdType = 'NPPID';

      const result = postPaymentReturnCapApiPayload(
        mockDataFromUI,
        mockPaymentId,
        mockMessageIdentification,
        mockDeviceId
      );

      expect(result.paymentReturn.relatedPaymentInformation.originalPaymentIdType).toBe('SCHEME_E2E_ID');
    });

    it('should split long additional information correctly', () => {
      const longInfo = 'A'.repeat(150);
      mockDataFromUI.transactionInformation.returnReason.additionalInformation = longInfo;

      const result = postPaymentReturnCapApiPayload(
        mockDataFromUI,
        mockPaymentId,
        mockMessageIdentification,
        mockDeviceId
      );

      expect(result.paymentReturn.returnReasonInformation.returnReason.additionalInformation).toEqual([
        'A'.repeat(100),
        'A'.repeat(50),
      ]);
    });
  });
});

describe('postPaymentReturnInitiationCapApiPayload', () => {
  let mockDataFromUI: PostPaymentReturnsRequest;
  let mockPaymentId: string;
  let mockMessageIdentification: string;
  let mockDeviceId: string;

  beforeEach(() => {
    mockPaymentId = 'payment-456';
    mockMessageIdentification = 'message-789';
    mockDeviceId = 'device-012';

    mockDataFromUI = {
      clientContext: {
        channelType: 'MOBILE',
      },
      originalMessageIdentification: 'original-msg-456',
      transactionInformation: {
        returnReason: {
          reasonCode: 'AM04',
          additionalInformation: 'Insufficient funds',
          returnType: 'RETURN',
          cancellationCode: 'CANC002',
        },
        debtor: {
          issuer: '111111',
          identification: '999888777',
          name: 'Test Debtor',
        },
        debitDescription: 'Test debit description',
        creditor: {
          issuer: '222222',
          identification: '666555444',
          name: 'Test Creditor',
        },
        creditDescription: 'Test credit description',
        paymentReference: 'TEST-REF-456',
        toAnotherAccount: 'Yes',
        returnedInterbankSettlementAmount: {
          currency: 'AUD',
          amount: '500.50',
        },
        supplementaryData: {
          paymentDetailsIdType: 'NPPID',
          serviceLevel: 'npp.clear.01',
          ofiCaseId: 'OFI123',
        },
      },
    } as PostPaymentReturnsRequest;
  });

  describe('Basic functionality', () => {
    it('should create correct payload structure with all required fields', () => {
      const result = postPaymentReturnInitiationCapApiPayload(
        mockDataFromUI,
        mockPaymentId,
        mockMessageIdentification,
        mockDeviceId
      );

      const expectedData = {
        paymentReturn: {
          returnIdentification: mockMessageIdentification,
          returnReasonInformation: {
            returnReason: {
              code: 'AM04',
              additionalInformation: ['/CaseId/OFI123/Insufficient funds'],
            },
            cancellationReason: {
              code: 'CANC002',
            },
          },
          relatedPaymentInformation: {
            originalPaymentId: 'original-msg-456',
            originalPaymentIdType: 'SCHEME_E2E_ID',
          },
          returnedInstructedAmount: {
            currencyCode: 'AUD',
            amount: '500.50',
          },
          originalTransactionReference: {
            creditorAccount: {
              identification: {
                other: {
                  identification: '111111999888777',
                  schemeName: {
                    schemeNameType: 'SchemeNameCode',
                    code: SchemeName.BBAN,
                  },
                },
              },
            },
          },
          paymentTypeInformation: {
            serviceLevel: {
              proprietary: 'npp.clear.01',
              serviceLevelType: 'ServiceLevelProprietary',
            },
          },
          alternateCreditor: {
            creditor: {
              name: 'Test Creditor',
            },
            creditorAccount: {
              identification: '222222666555444',
              issuer: '222222',
              name: 'Test Creditor',
              schemeName: {
                code: 'BBAN',
                schemeNameType: 'SchemeNameCode',
              },
            },
            endToEndIdentification: 'TEST-REF-456',
            debitDescription: 'Test debit description',
          },
          clientContext: {
            deviceId: mockDeviceId,
            channelType: 'MOBILE',
            initiatingUser: {
              orgCISKey: '',
              divisionId: '',
            },
          },
        },
        paymentDomainMetadata: {
          channelId: 'MOBILE',
          paymentInstructionId: mockPaymentId,
          WBCE2EPaymentId: 'mock-uuid-12345',
        },
      };

      expect(result).toEqual(expectedData);
    });

    it('should handle missing payment reference with default value', () => {
      delete mockDataFromUI.transactionInformation.paymentReference;

      const result = postPaymentReturnInitiationCapApiPayload(
        mockDataFromUI,
        mockPaymentId,
        mockMessageIdentification,
        mockDeviceId
      );

      expect(result.paymentReturn.alternateCreditor.endToEndIdentification).toBe('NOTPROVIDED');
    });

    it('should use getRemittanceInformation for additional information processing', () => {
      const result = postPaymentReturnInitiationCapApiPayload(
        mockDataFromUI,
        mockPaymentId,
        mockMessageIdentification,
        mockDeviceId
      );
      expect(Array.isArray(result.paymentReturn.returnReasonInformation.returnReason.additionalInformation)).toBe(true);
    });
  });
});

describe('transformPaymentReturnCapApiResponseToUI', () => {
  let mockLogger: any;
  let mockPaymentId: string;
  let mockMessageIdentification: string;

  beforeEach(() => {
    mockLogger = {
      info: jest.fn(),
      error: jest.fn(),
      warn: jest.fn(),
    };
    mockPaymentId = 'payment-123';
    mockMessageIdentification = 'message-456';
  });

  describe('Successful API responses', () => {
    it('should transform 201 response with complete payment status report', () => {
      const mockCapData = {
        data: {
          paymentStatusReport: {
            originalGroupInformationAndStatus: {
              originalCreationDateTime: '2023-12-09T10:00:00Z',
              groupStatus: 'ACSC',
              statusReasonInformation: {
                reason: {
                  code: 'AC01',
                },
                additionalInformation: 'Payment accepted and settled',
              },
            },
            originalPaymentInformationAndStatus: {
              paymentInformationStatus: 'ACSC',
              statusReasonInformation: {
                reason: {
                  code: 'AC01',
                },
                additionalInformation: 'Payment processed successfully',
              },
              transactionInformationAndStatus: {
                transactionStatus: 'ACSC',
                statusReasonInformation: {
                  reason: {
                    code: 'AC01',
                  },
                  additionalInformation: 'Transaction completed successfully',
                },
              },
            },
          },
        },
      };

      const result = transformPaymentReturnCapApiResponseToUI(
        mockCapData,
        mockLogger,
        201,
        mockPaymentId,
        mockMessageIdentification
      );

      expect(result).toHaveLength(1);
      expect(result[0]).toEqual({
        id: mockMessageIdentification,
        groupInformation: {
          originalCreationDateTime: '2023-12-09T10:00:00Z',
          groupStatus: 'ACSC',
          statusReasonInformation: {
            reason: 'AC01',
            additionalInformation: 'Payment accepted and settled',
          },
        },
        paymentInformation: {
          paymentInformationStatus: 'ACSC',
          statusReasonInformation: {
            reason: 'AC01',
            additionalInformation: 'Payment processed successfully',
          },
        },
        transactionStatusInformation: {
          transactionStatus: 'ACSC',
          statusReasonInformation: {
            reason: 'AC01',
            additionalInformation: 'Transaction completed successfully',
          },
        },
        supplementaryData: {
          id: mockPaymentId,
        },
      });
    });

    it('should transform 202 response with complete payment status report', () => {
      const mockCapData = {
        data: {
          paymentStatusReport: {
            originalGroupInformationAndStatus: {
              originalCreationDateTime: '2023-12-09T11:00:00Z',
              groupStatus: 'PDNG',
              statusReasonInformation: {
                reason: {
                  code: 'PNDG',
                },
                additionalInformation: 'Payment pending processing',
              },
            },
            originalPaymentInformationAndStatus: {
              paymentInformationStatus: 'PDNG',
              statusReasonInformation: {
                reason: {
                  code: 'PNDG',
                },
                additionalInformation: 'Payment under review',
              },
              transactionInformationAndStatus: {
                transactionStatus: 'PDNG',
                statusReasonInformation: {
                  reason: {
                    code: 'PNDG',
                  },
                  additionalInformation: 'Transaction queued for processing',
                },
              },
            },
          },
        },
      };

      const result = transformPaymentReturnCapApiResponseToUI(
        mockCapData,
        mockLogger,
        202,
        mockPaymentId,
        mockMessageIdentification
      );

      expect(result).toHaveLength(1);
      expect(result[0].groupInformation.groupStatus).toBe('PDNG');
      expect(result[0].paymentInformation.paymentInformationStatus).toBe('PDNG');
      expect(result[0].transactionStatusInformation.transactionStatus).toBe('PDNG');
    });
    it('should handle missing additional information with default empty string', () => {
      const mockCapData = {
        data: {
          paymentStatusReport: {
            originalGroupInformationAndStatus: {
              originalCreationDateTime: '2023-12-09T12:00:00Z',
              groupStatus: 'RJCT',
              statusReasonInformation: {
                reason: {
                  code: 'AC04',
                },
                additionalInformation: '',
              },
            },
            originalPaymentInformationAndStatus: {
              paymentInformationStatus: 'RJCT',
              statusReasonInformation: {
                reason: {
                  code: 'AC04',
                },
                additionalInformation: '',
              },
              transactionInformationAndStatus: {
                transactionStatus: 'RJCT',
                statusReasonInformation: {
                  reason: {
                    code: 'AC04',
                  },
                  additionalInformation: '',
                },
              },
            },
          },
        },
      };

      const result = transformPaymentReturnCapApiResponseToUI(
        mockCapData,
        mockLogger,
        201,
        mockPaymentId,
        mockMessageIdentification
      );

      expect(result[0].groupInformation.statusReasonInformation.additionalInformation).toBe('');
      expect(result[0].paymentInformation.statusReasonInformation.additionalInformation).toBe('');
      expect(result[0].transactionStatusInformation.statusReasonInformation.additionalInformation).toBe('');
    });
  });

  describe('Error and edge cases', () => {
    it('should return empty array when no data in response', () => {
      const mockCapData = {
        data: null,
      } as any;

      const result = transformPaymentReturnCapApiResponseToUI(
        mockCapData,
        mockLogger,
        201,
        mockPaymentId,
        mockMessageIdentification
      );

      expect(result).toEqual([]);
      expect(mockLogger.info).toHaveBeenCalledWith('No data received in success case');
    });

    it('should return undefined for non-success status codes', () => {
      const mockCapData = {
        data: {
          paymentStatusReport: {
            originalGroupInformationAndStatus: {
              originalCreationDateTime: '',
              groupStatus: 'RJCT',
              statusReasonInformation: {
                reason: {
                  code: 'FF01',
                },
                additionalInformation: 'Invalid file format',
              },
            },
            originalPaymentInformationAndStatus: {
              paymentInformationStatus: 'RJCT',
              statusReasonInformation: {
                reason: {
                  code: 'FF01',
                },
                additionalInformation: 'Invalid file format',
              },
              transactionInformationAndStatus: {
                transactionStatus: 'RJCT',
                statusReasonInformation: {
                  reason: {
                    code: 'FF01',
                  },
                  additionalInformation: 'Invalid file format',
                },
              },
            },
          },
        },
      };

      const result = transformPaymentReturnCapApiResponseToUI(
        mockCapData,
        mockLogger,
        400,
        mockPaymentId,
        mockMessageIdentification
      );

      expect(result).toBeUndefined();
    });

    it('should call removeEmptyKeys to clean up the response object', () => {
      const { removeEmptyKeys } = require('../../utils/commonHelper');
      const mockCapData = {
        data: {
          paymentStatusReport: {
            originalGroupInformationAndStatus: {
              originalCreationDateTime: '',
              groupStatus: 'RJCT',
              statusReasonInformation: {
                reason: {
                  code: 'BE05',
                },
                additionalInformation: 'Unrecognised initiating party',
              },
            },
            originalPaymentInformationAndStatus: {
              paymentInformationStatus: 'RJCT',
              statusReasonInformation: {
                reason: {
                  code: 'BE05',
                },
                additionalInformation: 'Unrecognised initiating party',
              },
              transactionInformationAndStatus: {
                transactionStatus: 'RJCT',
                statusReasonInformation: {
                  reason: {
                    code: 'BE05',
                  },
                  additionalInformation: 'Unrecognised initiating party',
                },
              },
            },
          },
        },
      };

      transformPaymentReturnCapApiResponseToUI(
        mockCapData,
        mockLogger,
        201,
        mockPaymentId,
        mockMessageIdentification
      );

      expect(removeEmptyKeys).toHaveBeenCalled();
    });
  });
});
