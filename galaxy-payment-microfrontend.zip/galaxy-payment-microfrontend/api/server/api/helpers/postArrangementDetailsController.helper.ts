import { v4 } from 'uuid';
import { Request } from 'express';
import cloneDeep from 'lodash/cloneDeep';
import {
  RetrieveArrangementDetailResponse as DownstreamServiceResponseData,
  HeadlineCreditInterestItem,
  HeadlineInterestItem,
  TierBandRate,
  CompoundingFrequency,
  Balance,
  ArrangementOwner,
  AccountLink,
} from '../../../interfaces/models/downstream/capProdsvcadmProddealacctadmInstlArrngmntsvcngV1';
import { PostArrangementDetailsData } from 'api/interfaces/models/galaxyPaymentExp';
import { convertSydneyLocalTimeToUtc } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { AccountId } from 'api/interfaces/models/common';
import {
  ACCOUNT_LINK_TYPES,
  ACCOUNT_RATE_CALCULATION_METHODS,
} from '../../utils/constants';

export type AccountStatus = 'ACTIVE' | 'INACTIVE';
export interface ArrangementsResponse {
  id: string;
  accountNumber: string;
  entityName: string;
  accountName: string;
  accountType: string;
  status: AccountStatus;
  currencyCode: string;
  currentBalance: string;
  availableBalance: string;
  overdraftLimit: string;
}

export interface ExpApiArrangementDetails extends ArrangementsResponse {
  accountId: string;
  startDateTime: string;
  closedDateTime: string;
  accountLinks: any;
  debitRateWithinLimit: HeadlineCreditInterestItem;
  debitRateWithinLimitTierBands?: TierBandRate[];
  debitRateAboveLimit: HeadlineCreditInterestItem;
  debitRateAboveLimitTierBands?: TierBandRate[];
  debitRateAboveLimitOverride: HeadlineCreditInterestItem;
  debitRateAboveLimitOverrideTierBands?: TierBandRate[];
  creditRate: HeadlineCreditInterestItem;
  creditRateTierBands?: TierBandRate[];
  creditRateCompoundingFrequency?: CompoundingFrequency;
}

export interface ArrangementsData {
  accountId: AccountId;
  aliasName: string;
  productName: string;
  status: AccountStatus;
  currencyCode: string;
  currentBalance: Balance;
  availableBalance: Balance;
  overdraftLimit: string;
  arrangementOwners: ArrangementOwner[];
}

export interface ArrangementDetailsFromCapApi extends ArrangementsData {
  startDateTime: string;
  endDateTime: string;

  accountLinks: AccountLink[];
  accountRates: {
    debitInterest: HeadlineInterestItem;
    creditInterest: HeadlineCreditInterestItem;
  };
}

export type ExpApiResponseData =
  PostArrangementDetailsData['entities']['arrangementDetails'];

export const transformDownstreamResponseToUi = (
  capData: DownstreamServiceResponseData,
  apiStatus: number,
  req: Request
): ExpApiResponseData => {
  let arrangementDetails: ExpApiArrangementDetails[] = [];
  // Support both single object and array input
  const capDataArray = Array.isArray(capData) ? capData : [capData];
  if (apiStatus === 200) {
    capDataArray.forEach(singleCapData => {
      const dataFromCap = singleCapData?.data?.arrangement;
      if (dataFromCap) {
        const expArrangementDetails = transformArrangementDetailsFromCapToExp(
          dataFromCap,
          req
        );
        arrangementDetails.push(expArrangementDetails);
      }
    });
  }
  return arrangementDetails as unknown as ExpApiResponseData;
};

export function transformArrangementFromCapToExp(
  dataFromCap: ArrangementDetailsFromCapApi
): ArrangementsResponse {
  return {
    id: v4(),
    accountNumber: `${dataFromCap?.accountId?.BSB ?? ''} ${
      dataFromCap?.accountId?.accountNumber ?? ''
    }`,
    entityName:
      dataFromCap?.arrangementOwners?.length &&
      !dataFromCap?.arrangementOwners?.every(
        owner => Object.keys(owner).length === 0
      )
        ? dataFromCap.arrangementOwners
            .map(owner => owner?.organisation?.fullName ?? '')
            .join(' and ')
        : '',
    accountName: dataFromCap?.aliasName ?? '',
    accountType: dataFromCap?.productName ?? '',
    status: dataFromCap?.status?.toUpperCase?.() as AccountStatus,
    currencyCode: dataFromCap?.currencyCode ?? '',
    currentBalance:
      dataFromCap?.currentBalance?.position === 'DR'
        ? `-${dataFromCap?.currentBalance?.amount ?? ''}`
        : dataFromCap?.currentBalance?.amount ?? '',
    availableBalance:
      dataFromCap?.availableBalance?.position === 'DR'
        ? `-${dataFromCap?.availableBalance?.amount ?? ''}`
        : dataFromCap?.availableBalance?.amount ?? '',
    overdraftLimit: dataFromCap?.overdraftLimit ?? '',
  };
}

export function transformArrangementDetailsFromCapToExp(
  dataFromCap: ArrangementDetailsFromCapApi,
  req: Request
): ExpApiArrangementDetails {
  const data: ArrangementDetailsFromCapApi = cloneDeep(dataFromCap);
  const expArrangement: ArrangementsResponse =
    transformArrangementFromCapToExp(data);

  const requestedAccountId: AccountId = req.body?.accountId;
  const filteredAccountLinks: AccountLink[] =
    data.accountLinks
      ?.filter(link => link?.type === ACCOUNT_LINK_TYPES.INTEREST_APPLICATION)
      ?.filter(link =>
        isEqualAccountId(link?.sourceAccountId, requestedAccountId)
      ) ?? [];

  const expArrangementDetails = {
    ...expArrangement,

    accountId: `${dataFromCap?.accountId?.BSB ?? ''} ${
      dataFromCap?.accountId?.accountNumber ?? ''
    }`,

    startDateTime: convertSydneyLocalTimeToUtc(data?.startDateTime),
    closedDateTime: convertSydneyLocalTimeToUtc(data?.endDateTime, 'end'),

    accountLinks: filteredAccountLinks,

    ...rateBuilder(
      'debitRateWithinLimit',
      'debitRateWithinLimitTierBands',
      data?.accountRates?.debitInterest?.rateWithinLimit
    ),

    ...rateBuilder(
      'debitRateAboveLimit',
      'debitRateAboveLimitTierBands',
      data?.accountRates?.debitInterest?.rateAboveLimit
    ),

    ...rateBuilder(
      'debitRateAboveLimitOverride',
      'debitRateAboveLimitOverrideTierBands',
      data?.accountRates?.debitInterest?.rateAboveLimitOverride
    ),

    ...rateBuilder(
      'creditRate',
      'creditRateTierBands',
      data?.accountRates?.creditInterest
    ),

    creditRateCompoundingFrequency:
      data?.accountRates?.creditInterest?.compoundingFrequency,
  } as ExpApiArrangementDetails;

  delete expArrangementDetails.debitRateWithinLimit?.tierBands;
  delete expArrangementDetails.debitRateAboveLimit?.tierBands;
  delete expArrangementDetails.debitRateAboveLimitOverride?.tierBands;
  delete expArrangementDetails.creditRate?.tierBands;
  delete expArrangementDetails.creditRate?.compoundingFrequency;

  return expArrangementDetails;
}

export function rateBuilder(
  rateKey: string,
  tierBandsKey: string,
  rateObject?: HeadlineCreditInterestItem
) {
  if (!rateObject) return {};

  if (rateKey === 'creditRate') {
    return {
      [rateKey]: {
        ...rateObject,
        tierBands: modifyStartRange(rateObject?.tierBands),
      },
      ...(isCalculationMethodBandOrTier(rateObject?.calculationMethod) && {
        [tierBandsKey]:
          rateObject?.tierBands ?? modifyStartRange(rateObject?.tierBands),
      }),
    };
  }

  return {
    [rateKey]: rateObject,
    ...(isCalculationMethodBandOrTier(rateObject?.calculationMethod) && {
      [tierBandsKey]: rateObject?.tierBands,
    }),
  };
}

export function modifyStartRange(tiers?: TierBandRate[]) {
  if (!tiers) return tiers;
  tiers.forEach(
    (t, index) =>
      (t.startRange += index === 0 || index === tiers.length - 1 ? 0 : 0.01)
  );
  return tiers;
}

export function isCalculationMethodBandOrTier(
  calculationMethod: keyof typeof ACCOUNT_RATE_CALCULATION_METHODS
): boolean {
  return (
    calculationMethod === ACCOUNT_RATE_CALCULATION_METHODS.BAND ||
    calculationMethod === ACCOUNT_RATE_CALCULATION_METHODS.TIER
  );
}

export function isEqualAccountId(
  accountId1: AccountId,
  accountId2: AccountId
): boolean {
  return (
    accountId1?.BSB === accountId2?.BSB &&
    accountId1?.accountNumber === accountId2?.accountNumber
  );
}
