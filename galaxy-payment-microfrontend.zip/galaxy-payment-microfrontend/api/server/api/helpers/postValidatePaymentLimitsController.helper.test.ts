import { transformDownstreamResponseToUi } from './postValidatePaymentLimitsController.helper';
import { LimitCheckResponse } from 'api/interfaces/models/downstream/paymentLimitsServiceV1';

jest.mock('uuid', () => ({
    v4: jest.fn().mockReturnValue('d8427d22-2aec-4a8f-9cc2-632b54800532'),
}));

describe('transformDownstreamResponseToUi', () => {
    it('should return an array with validatePaymentLimits from response.data', () => {
        const mockValidatePaymentLimits = { id: "d8427d22-2aec-4a8f-9cc2-632b54800532", isSuccess: true };
        const mockResponse: LimitCheckResponse = {
            data: mockValidatePaymentLimits
        } as LimitCheckResponse;

        const result = transformDownstreamResponseToUi(mockResponse);

        expect(result).toEqual([mockValidatePaymentLimits]);
    });

    it('should handle empty data object', () => {
        const mockResponse: LimitCheckResponse = {
            data: {}
        } as LimitCheckResponse;

        const result = transformDownstreamResponseToUi(mockResponse);

        expect(result).toEqual([{}]);
    });

    it('should handle undefined data', () => {
        const mockResponse: LimitCheckResponse = {
            data: undefined
        } as unknown as LimitCheckResponse;

        const result = transformDownstreamResponseToUi(mockResponse);

        expect(result).toEqual([{}]);
    });
});