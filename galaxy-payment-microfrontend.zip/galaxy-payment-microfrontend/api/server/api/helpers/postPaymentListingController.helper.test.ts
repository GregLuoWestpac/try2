import { instructionForDebtorAgentCode, paymentMethodDescription, StatusMap } from '../common/constants';
import {
  getPaymentStatus,
  getPaymentMethod,
  formatAccountId,
  isPaymentDateTimeValid,
  transformPaymentListingResponseFromCAPToUI,
  fetchPaymentListingParamsFromUI
} from './postPaymentListingController.helper';

describe('getPaymentStatus', () => {
  it('should return the correct status based on paymentInformationStatus', () => {
    const payment = {
      paymentInformation: {
        paymentInformationStatus: 'ACSC',
      },
    };
    expect(getPaymentStatus(payment)).toBe(StatusMap.ACSC);
  });

  it('should return SBMT status mapping for SBMT paymentInformationStatus', () => {
    const payment = {
      paymentInformation: {
        paymentInformationStatus: 'SBMT',
      },
    };
    expect(getPaymentStatus(payment)).toBe(StatusMap.SBMT);
  });

  it('should return PATC status mapping for PATC paymentInformationStatus', () => {
    const payment = {
      paymentInformation: {
        paymentInformationStatus: 'PATC',
      },
    };
    expect(getPaymentStatus(payment)).toBe(StatusMap.PATC);
  });

  it('should return an empty string if paymentInformationStatus is not in StatusMap', () => {
    const payment = {
      paymentInformation: {
        paymentInformationStatus: 'UNKNOWN',
      },
    };
    expect(getPaymentStatus(payment)).toBe('');
  });

  it('should return an empty string if paymentInformationStatus is undefined', () => {
    const payment = {
      paymentInformation: {},
    };
    expect(getPaymentStatus(payment)).toBe('');
  });

  it('should return an empty string if paymentInformation is undefined', () => {
    const payment = {};
    expect(getPaymentStatus(payment)).toBe('');
  });
});

describe('getPaymentMethod', () => {
  it('should return "Funds Transfer" when instructionForDebtorAgentfromDownStream is "On-Me"', () => {
    const payment = {
      creditTransferTransactionInformation: [
        {
          instructionForDebtorAgent: instructionForDebtorAgentCode.OnMe,
        },
      ],
    };
    expect(getPaymentMethod(payment)).toBe(paymentMethodDescription.FundsTransfer);
  });

  it('should return "Fast Payment" when serviceLevelFromDownStream starts with "npp.clear.01-catsct."', () => {
    const payment = {
      creditTransferTransactionInformation: [
        {
          paymentTypeInformation: {
            serviceLevel: 'npp.clear.01-catsct.somevalue',
          },
        },
      ],
    };
    expect(getPaymentMethod(payment)).toBe(paymentMethodDescription.FastPayment);
  });

  it('should return "Fast Payment" when serviceLevelFromDownStream starts with "npp.clear.01-sct."', () => {
    const payment = {
      creditTransferTransactionInformation: [
        {
          paymentTypeInformation: {
            serviceLevel: 'npp.clear.01-sct.somevalue',
          },
        },
      ],
    };
    expect(getPaymentMethod(payment)).toBe(paymentMethodDescription.FastPayment);
  });

  it('should return "Osko" when serviceLevelFromDownStream starts with "npp.clear.01-x2p1."', () => {
    const payment = {
      creditTransferTransactionInformation: [
        {
          paymentTypeInformation: {
            serviceLevel: 'npp.clear.01-x2p1.somevalue',
          },
        },
      ],
    };
    expect(getPaymentMethod(payment)).toBe(paymentMethodDescription.Osko);
  });

  it('should return "Fast Payment" when both serviceLevelFromDownStream and instructionForDebtorAgentfromDownStream are undefined', () => {
    const payment = {
      creditTransferTransactionInformation: [
        {
          paymentTypeInformation: {
            serviceLevel: undefined,
          },
          instructionForDebtorAgent: undefined,
        },
      ],
    };
    expect(getPaymentMethod(payment)).toBe(paymentMethodDescription.FastPayment);
  });
});

describe('formatAccountId', () => {
  const accountId = {
    BSB: '123456',
    accountNumber: '215566',
  };
  it('should concatinate the bsb n accounnumber', () => {
    expect(formatAccountId(accountId)).toBe('123456215566');
  });
});

describe('isPaymentDateTimeValid', () => {
  let res;

  beforeEach(() => {
    res = {
      status: jest.fn().mockReturnThis(),
      send: jest.fn(),
    };
  });

  it('should return an error if the first date is after the second date', () => {
    const paymentDateTime = 'btn:2024-08-26T12:00:00,2024-08-25T12:00:00';
    isPaymentDateTimeValid(paymentDateTime, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.send).toHaveBeenCalledWith({
      result: {
        errors: [
          {
            code: 202,
            message: 'Input Validation Failed',
            details:
              'paymentDateTime: First date cannot be after the second date.',
          },
        ],
      },
    });
  });

  it('should return an error if the date range is more than 90 days', () => {
    const paymentDateTime = 'btn:2024-01-01T12:00:00,2024-04-01T12:00:00';
    isPaymentDateTimeValid(paymentDateTime, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.send).toHaveBeenCalledWith({
      result: {
        errors: [
          {
            code: 202,
            message: 'Input Validation Failed',
            details:
              'paymentDateTime: Date time range has to be less or equal to 90 days.',
          },
        ],
      },
    });
  });

  it('should not return an error for valid date range', () => {
    const paymentDateTime = 'btn:2024-01-01T12:00:00,2024-02-01T12:00:00';
    isPaymentDateTimeValid(paymentDateTime, res);

    expect(res.status).not.toHaveBeenCalled();
    expect(res.send).not.toHaveBeenCalled();
  });
});

describe('transformPaymentListingResponseFromCAPToUI', () => {
  it('should transform a valid downstream API response correctly', () => {
    const downStreamAPIData = {
      data: {
        paymentList: [
          {
            paymentInformation: {
              paymentInformationStatus: 'ACSC',
            },
            creationDateTime: '2024-08-15T12:34:56Z',
            creditTransferTransactionInformation: [
              {
                instructedAmount: {
                  amount: '100.00',
                  currency: 'USD',
                },
                creditor: {
                  name: 'John Doe',
                },
                creditorAccount: {
                  name: 'John Doe Account',
                  identification: '123456789',
                },
                paymentTypeInformation: {
                  serviceLevel: 'npp.clear.01-catsct.somevalue',
                },
                supplementaryData: {
                  aliasId: '601428737',
                  aliasType: 'TELI',
                },
              },
            ],
            debtorAccount: {
              name: 'Jane Doe',
              identification: '987654321',
            },
            supplementaryData: {
              debitDescription: 'Payment for services',
            },
            referenceData: {
              paymentId: 'receipt123',
              instructionTraceIdentification: 'trace123',
            },
          },
        ],
      },
    };
    const apiStatus = 200;

    const result = transformPaymentListingResponseFromCAPToUI(downStreamAPIData, apiStatus, {});

    expect(result.paymentListing).toHaveLength(1);
    expect(result.paymentListing[0]).toMatchObject({
      status: 'Processed',
      creationDateTime: '2024-08-15T12:34:56Z',
      amount: '100.00',
      currency: 'USD',
      debitAccountName: 'Jane Doe',
      debitAccountIdentification: '987654321',
      debitDescription: 'Payment for services',
      beneficiaryName: 'John Doe',
      creditAccountName: 'John Doe Account',
      creditAccountIdentification: null,
      paymentMethod: 'Fast Payment',
      receiptNumber: 'receipt123',
      instructionTraceIdentification: 'trace123',
      supplementaryData: {
        aliasId: '601428737',
        aliasType: 'TELI',
      },
    });
  });

  it('should handle an empty downstream API response gracefully', () => {
    const downStreamAPIData = {
      data: {
        paymentList: [],
      },
    };
    const apiStatus = 200;

    const result = transformPaymentListingResponseFromCAPToUI(downStreamAPIData, apiStatus, {});

    expect(result.paymentListing).toHaveLength(0);
    expect(result.paging).toHaveLength(1);
  });

  it('should return only the first 1000 records if more than 1000 are returned from backend', () => {
    const paymentList = Array.from({ length: 1500 }, (_, i) => ({
      paymentInformation: { paymentInformationStatus: 'ACSC' },
      creationDateTime: '2024-08-15T12:34:56Z',
      creditTransferTransactionInformation: [
        {
          instructedAmount: { amount: '100.00', currency: 'USD' },
          creditor: { name: 'John Doe' },
          creditorAccount: { name: 'John Doe Account', identification: '123456789' },
          paymentTypeInformation: { serviceLevel: 'npp.clear.01-catsct.somevalue' },
          supplementaryData: { aliasId: '601428737', aliasType: 'TELI' },
        },
      ],
      debtorAccount: { name: 'Jane Doe', identification: '987654321' },
      supplementaryData: { debitDescription: 'Payment for services' },
      referenceData: { paymentId: 'receipt123', instructionTraceIdentification: 'trace123' },
    }));

    const downStreamAPIData = { data: { paymentList } };
    const apiStatus = 200;

    const result = transformPaymentListingResponseFromCAPToUI(downStreamAPIData, apiStatus, {});
    expect(result.paymentListing).toHaveLength(1000);
  });

  it('should throw an error for an invalid API status', () => {
    const downStreamAPIData = {
      data: {
        paymentList: [],
      },
    };
    const apiStatus = 500;

    expect(() => {
      transformPaymentListingResponseFromCAPToUI(downStreamAPIData, apiStatus, {});
    }).toThrow('Error: Unable to retrieve data');
  });

  it('should handle missing fields in the downstream API response', () => {
    const downStreamAPIData = {
      data: {
        paymentList: [
          {
            paymentInformation: {
              paymentInformationStatus: 'ACSC',
            },
            creationDateTime: '2024-08-15T12:34:56Z',
            creditTransferTransactionInformation: [
              {
                instructedAmount: {
                  amount: '100.00',
                  currency: 'USD',
                },
                creditor: {
                  name: 'John Doe',
                },
                creditorAccount: {
                  name: 'John Doe Account',
                  identification: '123456789',
                },
                paymentTypeInformation: {
                  serviceLevel: 'npp.clear.01-catsct.somevalue',
                },
              },
            ],
            debtorAccount: {
              name: 'Jane Doe',
              identification: '987654321',
            },
            referenceData: {
              paymentId: 'receipt123',
              instructionTraceIdentification: 'trace123',
            },
          },
        ],
      },
    };
    const apiStatus = 200;

    const result = transformPaymentListingResponseFromCAPToUI(downStreamAPIData, apiStatus, {});

    expect(result.paymentListing).toHaveLength(1);
    expect(result.paymentListing[0]).toMatchObject({
      status: 'Processed',
      creationDateTime: '2024-08-15T12:34:56Z',
      amount: '100.00',
      currency: 'USD',
      debitAccountName: 'Jane Doe',
      debitAccountIdentification: '987654321',
      beneficiaryName: 'John Doe',
      creditAccountName: 'John Doe Account',
      creditAccountIdentification: '123456789',
      paymentMethod: 'Fast Payment',
      receiptNumber: 'receipt123',
      instructionTraceIdentification: 'trace123',
    });
    expect(result.paymentListing[0].debitDescription).toBeUndefined();
    expect(result.paymentListing[0].supplementaryData.aliasId).toBeUndefined();
    expect(result.paymentListing[0].supplementaryData.aliasType).toBeUndefined();
  });
});

describe('fetchPaymentListingParamsFromUI', () => {
  let res;
  const orgCisKey = 'test-org-key';
  const accountIdsFromPDP = ['123456215566'];
  const divisionIdsFromPDP = ['division1'];

  beforeEach(() => {
    res = {
      status: jest.fn().mockReturnThis(),
      send: jest.fn(),
    };
  });

  it('should return formatted parameters for valid input with all parameters', () => {
    const datafromUI = {
      paymentDirection: 'O',
      paymentStatus: 'Processed',
      amountRange: 'btn:100.00,500.00',
    };
    const paymentDateTime = 'btn:2024-01-01T00:00:00Z,2024-02-01T00:00:00Z';

    const result = fetchPaymentListingParamsFromUI(
      datafromUI,
      paymentDateTime,
      res,
      orgCisKey,
      accountIdsFromPDP,
      divisionIdsFromPDP
    );

    expect(result).toEqual({
      orgCisKey: 'test-org-key',
      accountIds: ['123456215566'],
      divisionIds: ['division1'],
      paymentDirection: 'O',
      fromDateTime: '2024-01-01T00:00:00Z',
      toDateTime: '2024-02-01T00:00:00Z',
      amountRange: {
        fromAmount: '100.00',
        toAmount: '500.00'
      },
      paymentStatus: 'Processed'
    });
    expect(res.status).not.toHaveBeenCalled();
    expect(res.send).not.toHaveBeenCalled();
  });

  it('should return formatted parameters without optional fields when not provided', () => {
    const datafromUI = {
      paymentDirection: 'O',
    };
    const paymentDateTime = 'btn:2024-01-01T00:00:00Z,2024-02-01T00:00:00Z';

    const result = fetchPaymentListingParamsFromUI(
      datafromUI,
      paymentDateTime,
      res,
      orgCisKey,
      accountIdsFromPDP
    );

    expect(result).toEqual({
      orgCisKey: 'test-org-key',
      accountIds: ['123456215566'],
      paymentDirection: 'O',
      fromDateTime: '2024-01-01T00:00:00Z',
      toDateTime: '2024-02-01T00:00:00Z',
      amountRange: null,
      paymentStatus: undefined
    });
  });

  it('should handle invalid amountRange format gracefully', () => {
    const datafromUI = {
      paymentDirection: 'O',
      amountRange: 'invalid-format',
    };
    const paymentDateTime = 'btn:2024-01-01T00:00:00Z,2024-02-01T00:00:00Z';

    const result = fetchPaymentListingParamsFromUI(
      datafromUI,
      paymentDateTime,
      res,
      orgCisKey,
      accountIdsFromPDP
    );

    expect(result).toEqual({
      orgCisKey: 'test-org-key',
      accountIds: ['123456215566'],
      paymentDirection: 'O',
      amountRange: null,
      fromDateTime: '2024-01-01T00:00:00Z',
      toDateTime: '2024-02-01T00:00:00Z',
      paymentStatus: undefined
    });
  });

  it('should return null if both data and payment time are not passed', () => {
    const result = fetchPaymentListingParamsFromUI(null, null, res, orgCisKey);

    expect(result).toBeNull();
  });



  it('should return null if datafromUI is missing', () => {
    const paymentDateTime = 'btn:2024-01-01T12:00:00,2024-02-01T12:00:00';

    const result = fetchPaymentListingParamsFromUI(null, paymentDateTime, res, orgCisKey);

    expect(result).toBeNull();
    expect(res.status).not.toHaveBeenCalled();
    expect(res.send).not.toHaveBeenCalled();
  });

  it('should return null if paymentDateTime is missing', () => {
    const datafromUI = {
      paymentDirection: 'O',
    };

    const result = fetchPaymentListingParamsFromUI(datafromUI, null, res, orgCisKey);

    expect(result).toBeNull();
    expect(res.status).not.toHaveBeenCalled();
    expect(res.send).not.toHaveBeenCalled();
  });
});

