import {
  transformDownstreamResponseToUi,
  incrementCopCounters,
  incrementDailyCounterOnError,
} from './postAccountNameCheckController.helper';
import { AccountNameCheckResponse } from '../../../interfaces/models/downstream/payeeServicesV1';
import { getLimitCounter } from '../../utils/limitCounter';

// Mock uuid
jest.mock('uuid', () => ({
  v4: jest.fn(() => 'mocked-uuid-123'),
}));

// Mock the mv-apiutils package to provide getColorForCoPStatusCode
jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  getColorForCoPStatusCode: jest.fn((code?: string) => {
    if (!code) return undefined;

    // Blue status codes
    const blueCodes = [
      'V0C1',
      'V0C2',
      'VAC1',
      'VTC1',
      'VEC1',
      'VAC2',
      'VTC2',
      'VEC2',
      'V0C6',
      'V0C8',
    ];
    if (blueCodes.includes(code)) return 'Blue';

    // Red status codes
    const redCodes = ['V0C7', 'V1C7', 'V2C7', 'VAC7', 'VTC7', 'VEC7'];
    if (redCodes.includes(code)) return 'Red';

    // Amber status codes (default for all others)
    return 'Amber';
  }),
}));

jest.mock('../../utils/limitCounter', () => ({
  getLimitCounter: jest.fn(),
}));

describe('postAccountNameCheckController.helper', () => {
  describe('transformDownstreamResponseToUi', () => {
    it('should transform downstream response with matchedAccountName and matchedStatus - Blue color', () => {
      const mockResponse: AccountNameCheckResponse = {
        data: {
          matchedAccountName: 'Paul Walker',
          matchedStatus: {
            code: 'V0C1',
            description: 'A match response was returned by Verify+ and CoP',
          },
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result).toEqual([
        {
          id: 'mocked-uuid-123',
          matchedCOPAccountName: 'Paul Walker',
          matchedCOPStatusCode: 'V0C1',
          matchedCOPColour: 'Blue',
        },
      ]);
    });

    it('should transform downstream response with Amber color code', () => {
      const mockResponse: AccountNameCheckResponse = {
        data: {
          matchedAccountName: 'Jane Doe',
          matchedStatus: {
            code: 'V2C3',
            description: 'CoP no match and Verify no match',
          },
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result).toEqual([
        {
          id: 'mocked-uuid-123',
          matchedCOPAccountName: 'Jane Doe',
          matchedCOPStatusCode: 'V2C3',
          matchedCOPColour: 'Amber',
        },
      ]);
    });

    it('should transform downstream response with Red color code', () => {
      const mockResponse: AccountNameCheckResponse = {
        data: {
          matchedAccountName: 'John Smith',
          matchedStatus: {
            code: 'V0C7',
            description: 'CoP error and Account closed or not found',
          },
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result).toEqual([
        {
          id: 'mocked-uuid-123',
          matchedCOPAccountName: 'John Smith',
          matchedCOPStatusCode: 'V0C7',
          matchedCOPColour: 'Red',
        },
      ]);
    });

    it('should return default response when response.data is undefined', () => {
      const mockResponse: AccountNameCheckResponse = {
        data: undefined,
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result).toEqual([
        {
          id: 'mocked-uuid-123',
        },
      ]);
    });

    it('should return default response when response.data is null', () => {
      const mockResponse = {
        data: null,
      } as unknown as AccountNameCheckResponse;

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result).toEqual([
        {
          id: 'mocked-uuid-123',
        },
      ]);
    });

    it('should handle response with matchedStatus but no matchedAccountName', () => {
      const mockResponse: AccountNameCheckResponse = {
        data: {
          matchedStatus: {
            code: 'V2C4',
            description: 'CoP no match [NON-IND] and Verify no match',
          },
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result).toEqual([
        {
          id: 'mocked-uuid-123',
          matchedCOPAccountName: undefined,
          matchedCOPStatusCode: 'V2C4',
          matchedCOPColour: 'Amber',
        },
      ]);
    });

    it('should handle response with matchedAccountName but no matchedStatus', () => {
      const mockResponse: AccountNameCheckResponse = {
        data: {
          matchedAccountName: 'Test Name',
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result).toEqual([
        {
          id: 'mocked-uuid-123',
          matchedCOPAccountName: 'Test Name',
          matchedCOPStatusCode: undefined,
          matchedCOPColour: undefined,
        },
      ]);
    });

    it('should handle response with empty data object', () => {
      const mockResponse: AccountNameCheckResponse = {
        data: {},
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result).toEqual([
        {
          id: 'mocked-uuid-123',
          matchedCOPAccountName: undefined,
          matchedCOPStatusCode: undefined,
          matchedCOPColour: undefined,
        },
      ]);
    });

    it('should not include matchedStatus description in the output', () => {
      const mockResponse: AccountNameCheckResponse = {
        data: {
          matchedAccountName: 'Apple Tree',
          matchedStatus: {
            code: 'V0C2',
            description: 'This description should not appear in output',
          },
        },
      };

      const result = transformDownstreamResponseToUi(mockResponse);

      expect(result[0].matchedCOPStatusCode).toBe('V0C2');
      expect(result[0].matchedCOPColour).toBe('Blue');
    });
  });

  describe('getColorForCoPStatusCode - Blue status codes', () => {
    const blueCodes = [
      'V0C1',
      'V0C2',
      'VAC1',
      'VTC1',
      'VEC1',
      'VAC2',
      'VTC2',
      'VEC2',
      'V0C6',
      'V0C8',
    ];

    blueCodes.forEach(code => {
      it(`should return Blue for status code ${code}`, () => {
        const mockResponse: AccountNameCheckResponse = {
          data: {
            matchedAccountName: 'Test Name',
            matchedStatus: { code },
          },
        };

        const result = transformDownstreamResponseToUi(mockResponse);
        expect(result[0].matchedCOPColour).toBe('Blue');
      });
    });
  });

  describe('getColorForCoPStatusCode - Amber status codes', () => {
    const amberCodes = [
      'V1C1',
      'V2C1',
      'V1C2',
      'V2C2',
      'V1C6',
      'V1C8',
      'V2C6',
      'V2C8',
      'VAC6',
      'VAC8',
      'VTC6',
      'VTC8',
      'VEC6',
      'VEC8',
      'V0C3',
      'V0C4',
      'V1C3',
      'V1C4',
      'V2C3',
      'V2C4',
      'VAC3',
      'VTC3',
      'VEC3',
      'VAC4',
      'VTC4',
      'VEC4',
      'V0C5',
      'V1C5',
      'V2C5',
      'VAC5',
      'VTC5',
      'VEC5',
    ];

    amberCodes.forEach(code => {
      it(`should return Amber for status code ${code}`, () => {
        const mockResponse: AccountNameCheckResponse = {
          data: {
            matchedAccountName: 'Test Name',
            matchedStatus: { code },
          },
        };

        const result = transformDownstreamResponseToUi(mockResponse);
        expect(result[0].matchedCOPColour).toBe('Amber');
      });
    });
  });

  describe('getColorForCoPStatusCode - Red status codes', () => {
    const redCodes = ['V0C7', 'V1C7', 'V2C7', 'VAC7', 'VTC7', 'VEC7'];

    redCodes.forEach(code => {
      it(`should return Red for status code ${code}`, () => {
        const mockResponse: AccountNameCheckResponse = {
          data: {
            matchedAccountName: 'Test Name',
            matchedStatus: { code },
          },
        };

        const result = transformDownstreamResponseToUi(mockResponse);
        expect(result[0].matchedCOPColour).toBe('Red');
      });
    });
  });


  describe('incrementCopCounters', () => {
    /* eslint-disable @typescript-eslint/no-explicit-any */
    const mockRes = {
      locals: {
        logger: { info: jest.fn(), warn: jest.fn() },
      },
    } as any;
    const mockReq = {} as any;
    /* eslint-enable @typescript-eslint/no-explicit-any */
    const mockIncrementSessionIdCounter = jest.fn();
    const mockIncrementPaymentCounter = jest.fn();

    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('should return incremented: false when matchedStatus is missing', async () => {
      const result = await incrementCopCounters(
        undefined,
        mockIncrementSessionIdCounter,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123',
        'sessionIndex123'
      );

      expect(result).toEqual({
        incremented: false,
        message: 'no matchedStatus',
      });
      expect(mockRes.locals.logger.info).toHaveBeenCalledWith(
        'matchedStatus not present in response, skipping counter increment'
      );
    });

    it('should call incrementSessionIdCounter for V1C3 matchedStatus', async () => {
      (getLimitCounter as jest.Mock).mockResolvedValueOnce({
        counters: [{ session: { counter: 2 }, counter: 2 }],
      });

      const result = await incrementCopCounters(
        'V1C3',
        mockIncrementSessionIdCounter,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123',
        'sessionIndex123'
      );

      expect(result).toEqual({ incremented: true });
      expect(getLimitCounter).toHaveBeenCalledWith(
        'COP',
        mockIncrementSessionIdCounter,
        mockRes,
        mockReq,
        'userId123',
        'sessionIndex123'
      );
    });

    it('should call incrementPaymentCounter for V0C1 matchedStatus (daily only)', async () => {
      (getLimitCounter as jest.Mock).mockResolvedValueOnce({
        counters: [{ counter: 2 }],
      });

      const result = await incrementCopCounters(
        'V0C1',
        mockIncrementSessionIdCounter,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123',
        'sessionIndex123'
      );

      expect(result).toEqual({ incremented: true });
      expect(getLimitCounter).toHaveBeenCalledWith(
        'COP',
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123'
      );
    });

    it('should return warning message when counter increment fails', async () => {
      (getLimitCounter as jest.Mock).mockResolvedValueOnce({});

      const result = await incrementCopCounters(
        'V0C1',
        mockIncrementSessionIdCounter,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123',
        'sessionIndex123'
      );

      expect(result.incremented).toBe(false);
      expect(result.message).toBe(
        'COP limit failed to increment daily counter'
      );
      expect(mockRes.locals.logger.warn).toHaveBeenCalledWith(
        'COP limit failed to increment daily counter'
      );
    });

    it.each([
      'V1C3',
      'V1C4',
      'V2C3',
      'V2C4',
      'VAC3',
      'VTC3',
      'VEC3',
      'VAC4',
      'VTC4',
      'VEC4',
    ])(
      'should use incrementSessionIdCounter for %s matchedStatus',
      async statusCode => {
        (getLimitCounter as jest.Mock).mockResolvedValueOnce({
          counters: [{ session: { counter: 2 }, counter: 2 }],
        });

        await incrementCopCounters(
          statusCode,
          mockIncrementSessionIdCounter,
          mockIncrementPaymentCounter,
          mockRes,
          mockReq,
          'userId123',
          'sessionIndex123'
        );

        expect(getLimitCounter).toHaveBeenCalledWith(
          'COP',
          mockIncrementSessionIdCounter,
          expect.anything(),
          expect.anything(),
          expect.anything(),
          expect.anything()
        );
      }
    );
  });

  describe('incrementDailyCounterOnError', () => {
    /* eslint-disable @typescript-eslint/no-explicit-any */
    const mockRes = {
      locals: {
        logger: { warn: jest.fn() },
      },
    } as any;
    const mockReq = {} as any;
    /* eslint-enable @typescript-eslint/no-explicit-any */
    const mockIncrementPaymentCounter = jest.fn();

    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('should increment counter on 400 error', async () => {
      (getLimitCounter as jest.Mock).mockResolvedValueOnce({
        counters: [{ counter: 2 }],
      });

      await incrementDailyCounterOnError(
        400,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123'
      );

      expect(getLimitCounter).toHaveBeenCalledWith(
        'COP',
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123'
      );
    });

    it('should increment counter on 500 error', async () => {
      (getLimitCounter as jest.Mock).mockResolvedValueOnce({
        counters: [{ counter: 2 }],
      });

      await incrementDailyCounterOnError(
        500,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123'
      );

      expect(getLimitCounter).toHaveBeenCalledWith(
        'COP',
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123'
      );
    });

    it('should not increment counter on 404 error', async () => {
      await incrementDailyCounterOnError(
        404,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123'
      );

      expect(getLimitCounter).not.toHaveBeenCalled();
    });

    it('should not increment counter when status is undefined', async () => {
      await incrementDailyCounterOnError(
        undefined,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123'
      );

      expect(getLimitCounter).not.toHaveBeenCalled();
    });

    it('should handle getLimitCounter error gracefully', async () => {
      (getLimitCounter as jest.Mock).mockRejectedValueOnce(
        new Error('API error')
      );

      await incrementDailyCounterOnError(
        400,
        mockIncrementPaymentCounter,
        mockRes,
        mockReq,
        'userId123'
      );

      expect(mockRes.locals.logger.warn).toHaveBeenCalledWith(
        'Failed to increment daily counter on API error'
      );
    });
  });
});
