import { v4 as uuid } from 'uuid';
import { PdpQueryResult } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { GetDivisionListData } from '../../../interfaces/models/galaxyPaymentExp';

export type ExpApiResponseData = GetDivisionListData['entities'];
export type DivisionList = ExpApiResponseData['divisionList'][number] & {
  id: string;
};

export const transformGetDivisionListResponse = (
  data: PdpQueryResult[]
): DivisionList[] => {
  if (!Array.isArray(data)) {
    return [];
  }

  return data
    .map((result: PdpQueryResult) => {
      const statement = result?.statements?.[0];
      const payloadData = JSON.parse(statement?.payload || '{}');
      const divisionName = payloadData?.name;
      return {
        id: uuid(),
        divisionName: divisionName || '',
        divisionId: result.value || '',
      };
    })
    .sort((a, b) => a.divisionName.localeCompare(b.divisionName));
};
