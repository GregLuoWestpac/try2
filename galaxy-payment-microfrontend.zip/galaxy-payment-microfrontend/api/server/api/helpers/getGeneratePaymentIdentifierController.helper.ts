import { v4 as uuidv4 } from 'uuid';
import { DownstreamServiceResponseData } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

/**
 * Transforms the downstream CAP API response to include a generated id for each item.
 * @param response - The response from the CAP API.
 * @returns An object formatted for normalization.
 */
export const transformDownstreamResponseToUi = (
  response: DownstreamServiceResponseData
): Array<{ id: string; paymentId: string; creationDateTime: string }> => {
  if (!response?.data) {
    return [];
  }

  const { id = '', creationDateTime = '' } = response.data as {
    id: string;
    creationDateTime: string;
  };

  return [
    {
      id: uuidv4(),
      paymentId: id,
      creationDateTime,
    },
  ];
};
