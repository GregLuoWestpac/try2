import { DownstreamServiceResponseData } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { v4 } from 'uuid';
import { RetrieveBeneficiariesData } from '../../../interfaces/models/galaxyPaymentExp';
import isArray from 'lodash/isArray';

export type ExpApiResponseData = RetrieveBeneficiariesData['entities'];

export const transformDownstreamResponseToUi = (
  response: DownstreamServiceResponseData
): ExpApiResponseData => {
  let beneficiaries: ExpApiResponseData['beneficiaryList'] = [];

  if (isArray(response.data?.beneficiaries)) {
    beneficiaries = response.data?.beneficiaries?.map(beneficiaryRawData => {
      const { currency: currencyCode, amount, ...rest } = beneficiaryRawData;
      return {
        ...rest,
        currencyAmount: {
          currencyCode,
          ...(amount && { amount }),
        },
      };
    });
  }

  const pagingData = [
    {
      id: v4(),
      pageSize: response.paging?.pageSize,
      count: response.paging?.count,
      previousPageKey: response.paging?.previousPageKey,
      nextPageKey: response.paging?.nextPageKey,
    },
  ];

  return {
    beneficiaryList: beneficiaries,
    paging: pagingData,
  } as ExpApiResponseData;
};
