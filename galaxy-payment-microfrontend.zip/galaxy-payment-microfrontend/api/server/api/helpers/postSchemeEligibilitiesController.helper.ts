import { APIError } from '@mep-node/framework-utilities';
import get from 'lodash/get';
import isNil from 'lodash/isNil';
import isUndefined from 'lodash/isUndefined';
import { v4 } from 'uuid';
import {
  PaymentSchemeEligibilityResponse as DownstreamPaymentSchemeEligibilityResponse,
  EligibleServicesItem,
  PaymentSchemeEligibilityResponse,
} from '../../../interfaces/models/downstream/paymentSchemeEligibilityV1';
import { PostSchemeEligibilitiesData } from '../../../interfaces/models/galaxyPaymentExp';
import { mapPaymentMethod } from '../../utils/commonHelper';
import {
  paymentMethodDescription,
  serviceLevelCode,
} from '../common/constants';

function getServicePriority(
  service: EligibleServicesItem,
  paymentMethod: string
) {
  if (service.name.startsWith(serviceLevelCode.osko)) {
    // Osko
    return 1;
  }
  if (service.name.startsWith(serviceLevelCode.fastPaymentSct)) {
    // Fast Payment (SCT)
    return 2;
  }
  return undefined;
}

export type ExpApiResponseData =
  PostSchemeEligibilitiesData['entities']['schemeEligibilities'];

export const transformDownstreamResponseToUi = (
  response: DownstreamPaymentSchemeEligibilityResponse,
  returnAllSchemes: boolean
): ExpApiResponseData => {
  const eligibleServices = filterAndSortDownstreamResponse(response);

  const mappedServices = eligibleServices.map(service => ({
    id: v4(),
    paymentMethod: {
      code: service.name,
      description: mapPaymentMethod(service.name),
    },
  }));

  if (response.data.paymentMethod === 'ON_US') {
    mappedServices.unshift({
      id: v4(),
      paymentMethod: {
        code: undefined,
        description: paymentMethodDescription.FastPayment,
      },
    });
  }

  const doesSupportDePayment =
    response.data.paymentMethod !== 'ON_US' &&
    response.data?.paymentSchemes?.includes('DE');

  if (doesSupportDePayment) {
    mappedServices.push({
      id: v4(),
      paymentMethod: {
        code: serviceLevelCode.DE,
        description: paymentMethodDescription.DE,
      },
    });
  }

  if (returnAllSchemes) return mappedServices;

  return mappedServices
    .slice(0, 1)
    .concat(doesSupportDePayment ? mappedServices.slice(-1) : []);
};

export function validateRequestBody(body: Record<string, any>) {
  const issuer = get(body, 'creditorAccount.issuer');
  const schemeName = get(body, 'creditorAccount.schemeName');
  const payAlias = get(body, 'creditorAccount.payAlias');

  if (!isNil(payAlias) && (!isNil(issuer) || !isNil(schemeName))) {
    return new APIError(
      'Only one of issuer or payAlias is accepted',
      400,
      {
        code: 10001,
        details: 'Only one of issuer or payAlias is accepted',
        message: 'Only one of issuer or payAlias is accepted',
      },
      {}
    );
  }

  if (isNil(payAlias) && (isNil(issuer) || isNil(schemeName))) {
    return new APIError(
      'Need to provide both issuer and schemeName',
      400,
      {
        code: 10001,
        details: 'Need to provide both issuer and schemeName',
        message: 'Need to provide both issuer and schemeName',
      },
      {}
    );
  }
}

export function filterAndSortDownstreamResponse(
  downstreamResponse: PaymentSchemeEligibilityResponse
) {
  const eligibleServices: EligibleServicesItem[] = get(
    downstreamResponse,
    'data.eligibleServices',
    []
  );
  const paymentMethod = get(downstreamResponse, 'data.paymentMethod');

  const services = eligibleServices
    .filter(service => !isUndefined(getServicePriority(service, paymentMethod)))
    .sort(
      (a, b) =>
        getServicePriority(a, paymentMethod) -
        getServicePriority(b, paymentMethod)
    );

  // Group services by status and keep the latest version
  const groupedServicesMap = new Map<string, EligibleServicesItem>();

  services.forEach(service => {
    const prefix = service.name.substring(0, service.name.lastIndexOf('.'));
    const existingService = groupedServicesMap.get(prefix);
    const existingVersion = existingService
      ? parseInt(existingService.name.split('.').pop() || '0')
      : 0;
    const currentVersion = parseInt(service.name.split('.').pop() || '0');

    if (!existingService || currentVersion > existingVersion) {
      groupedServicesMap.set(prefix, service);
    }
  });
  return Array.from(groupedServicesMap.values());
}
