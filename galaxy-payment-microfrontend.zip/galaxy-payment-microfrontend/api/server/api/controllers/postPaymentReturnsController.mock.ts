import { v4 as uuid } from 'uuid';

export const postPaymentReturnsControllerMocked: any = {
    id: uuid(),
    creationDateTime: '2024-01-28T15:27:49.732Z',
    groupInformation: {
        originalCreationDateTime: '2024-01-28T15:27:49.732Z',
        groupStatus: 'ACCP',
    },
    groupStatusReasonInformation: [
        {
            reason: 'ACCP',
            additionalInformation: 'Accepted',
        },
    ],
    transactionStatusInformation: [{
        transactionStatus: 'ACCP',
        statusReasonInformation: [{
        reason: 'ACCP',
        additionalInformation: 'Accepted',
        }],
        supplementaryData: {
        id: uuid(),
        },
    }]
}