import { NextFunction, Request, Response } from 'express';
import {
  PostPaymentsRequest,
  PostPaymentsResponse,
} from '../../../interfaces/models/Payments';
import { ApiResponse } from '../../../interfaces/types/common';
import paymentCreateController from './paymentCreateController';

const postPaymentCreateForNewBeneficiaryController = async (
  req: Request<never, Record<string, unknown>, PostPaymentsRequest>,
  res: Response<ApiResponse<PostPaymentsResponse> | string>,
  next: NextFunction
) => {
  await paymentCreateController(
    req,
    res,
    next,
    'paymentCreateForNewBeneficiary'
  );
};

module.exports = postPaymentCreateForNewBeneficiaryController;
