/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
import {
  handleControllerError,
  APIClientError,
  STATUS_CODES,
  accessControlExposeHeaders,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { RUNTIME, ALLOWED_COOKIES } from '@mep-node/framework-constants';
import {
  ID,
  getIpAddress,
  getDeviceFingerPrint,
} from '@mep-node/framework-utilities';
import {
  getAliasLookupByBeneficiaryIdHandler,
  getAliasLookupByPayIdAndTypeHandler,
  validateAliasLookupRequestBody,
  AliasLookupEXPRequestBody,
} from '@mesh-tenant-multiverse-ui-common/mv-apialiaslookup';

import { NextFunction, Request, Response } from 'express';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import {
  paymentAliasResolutionV2Services,
  beneficiaryManagementV1Services,
  capCustsvcmgtCustsecyverifctnAdaptvauthV2Services,
  channelPaymentUtilsV1Services,
} from '../../generated/api-clients';

const postAliasLookupController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { logger } = res.locals;
  const body = req.body as AliasLookupEXPRequestBody;

  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);

  try {
    // Validate request body
    const validation = validateAliasLookupRequestBody(body);
    if (!validation.isValid) {
      res.status(STATUS_CODES.BAD_REQUEST).json({
        code: 'INVALID_REQUEST_BODY',
      });
      return;
    }

    // Route to appropriate handler based on request body
    if (body.id) {
      const getAliasLookupByBeneficiaryIdParams: any = {
        normalise,
        paymentAliasResolutionV2Services,
        beneficiaryManagementV1Services,
      };
      // Beneficiary ID lookup flow
      await getAliasLookupByBeneficiaryIdHandler(
        req,
        res,
        next,
        getAliasLookupByBeneficiaryIdParams
      );
    } else {
      // PayID + authBIC8 lookup flow
      const getAliasLookupByPayIdAndTypParams: any = {
        normalise,
        paymentAliasResolutionV2Services,
        capCustsvcmgtCustsecyverifctnAdaptvauthV2Services,
        channelPaymentUtilsV1Services,
        payIDSource: 'Add Beneficiary',
        ALLOWED_COOKIES,
        RUNTIME,
        ID,
        getIpAddress,
        getDeviceFingerPrint,
      };
      await getAliasLookupByPayIdAndTypeHandler(
        req,
        res,
        next,
        getAliasLookupByPayIdAndTypParams
      );
    }
  } catch (error: unknown) {
    const apiError = error as APIClientError;
    handleControllerError({ error: apiError, res, logger });
    next(error);
  }
};

export = postAliasLookupController;
