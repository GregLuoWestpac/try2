import { Request, Response, NextFunction } from 'express';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import { handleControllerError, handleApiService, normaliseData, accessControlExposeHeaders, APIClient } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { CONSTANTS } from '../../utils/constants';
import { paymentSchemeEligibilityV1Services } from '../../generated/api-clients';
import { transformDownstreamResponseToUi, ExpApiResponseData, validateRequestBody } from '../helpers/postSchemeEligibilitiesController.helper';

const postSchemeEligibilitiesController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { logger } = res.locals;
  const {
    httpStatus: { OK, BAD_REQUEST },
  } = CONSTANTS;
  const { postPaymentSchemeEligibility: postSchemeEligibilities } = paymentSchemeEligibilityV1Services;
  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);
  try {

    const error = validateRequestBody(req.body);

    const { returnAllSchemes = false } = req.body;

    if (error) {
      return res.status(BAD_REQUEST).json({
        result: {
          errors: [{
            "code": 202,
            "message": "Request validation failure",
            "details": error.message
          }]
        }
      }).end();
    }
    let data = {}
    try {
      data = (await handleApiService({
        req,
        res,
        apiClient: postSchemeEligibilities as APIClient,
        requestBody: req.body,
      })).data;
    } catch (e) {
      res.status(500).json(e?.error?.data).end();
      return;
    }
    if (typeof data === 'object' && data !== null && 'result' in data && typeof data.result == "object" && "errors" in data.result) {
      res.status(400).json(data).end();
      return;
    }
    const expApiResponseData: ExpApiResponseData = transformDownstreamResponseToUi(
      data, returnAllSchemes
    );
    const normalisedData = normaliseData('schemeEligibilities', expApiResponseData, normalise);
    if ("result" in normalisedData && normalisedData.result.schemeEligibilities.length === 0) {
      return res.status(400).json({
        result: {
          errors: [{
            "code": 1001,
            "message": "Request validation failure",
          }]
        }
      }).end();
    }
    res.status(OK).json(normalisedData).end();
  } catch (error) {
    handleControllerError({ error, res, logger });
    next(error);
  }
};

module.exports = postSchemeEligibilitiesController;