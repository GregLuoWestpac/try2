
import { Response } from 'express';
import { transformDownstreamResponseToUi } from '../helpers/postValidatePaymentLimitsController.helper';
import { handleControllerError, normaliseData, handleApiService, STATUS_CODES, decodeAndValidateToken, DecodedTokenResult } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { RUNTIME } from '@mep-node/framework-constants';
import { paymentLimitsServiceV1Services } from '../../generated/api-clients';
import { setParamsForPostValidatePaymentLimits } from '../../utils/setParams';

const postValidatePaymentLimitsController = require('./postValidatePaymentLimitsController');

jest.mock('../helpers/postValidatePaymentLimitsController.helper');
jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils');
jest.mock('../../utils/commonHelper');
jest.mock('../../generated/api-clients');
jest.mock('../../utils/setParams');

jest.mock('uuid', () => ({
    v4: jest.fn().mockReturnValue('d8427d22-2aec-4a8f-9cc2-632b54800532'),
}));

const mockLogger = { info: jest.fn(), error: jest.fn(), warn: jest.fn(), debug: jest.fn(), log: jest.fn() };
const mockRes = () => {
    const res: Partial<Response> = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn().mockReturnThis(),
        end: jest.fn().mockReturnThis(),
        locals: { logger: mockLogger, apiHeaders: { some: 'header' } } as any,
        get: jest.fn()
    };
    return res as Response;
};

describe('postValidatePaymentLimitsController', () => {
    let res: Response;

    beforeEach(() => {
        res = mockRes();
        (res.locals as any).logger = mockLogger;
        (res.locals as any).httpStatus = { OK: 200 };

				// Mock the paymentLimitsServiceV1Services
        (paymentLimitsServiceV1Services as any) = {
            checkPaymentLimit: jest.fn()
        };
    });

    afterEach(() => {
        jest.clearAllMocks();
    });


    it('should respond with normalised data on success (non-local)', async () => {
        jest.spyOn(RUNTIME, 'isLocal').mockReturnValue(false);
        const decodedToken: DecodedTokenResult = { userId: 'user-123', userIAMId: 'iam-999' };
        (decodeAndValidateToken as jest.Mock).mockReturnValue(decodedToken);
        const req = {
            get: jest.fn()
                .mockImplementationOnce(() => 'org-456'),
            body: {
                instructionIdentification: 'inst-1',
                scheme: 'scheme-1',
                settlementAmount: 100
            }
        } as any;
        const res = mockRes();
        const next = jest.fn();
        const downstreamResponse = { data: { some: 'downstream' } };
        (handleApiService as jest.Mock).mockResolvedValue(downstreamResponse);
        const expApiResponseData = { entities: [{ id: 'd8427d22-2aec-4a8f-9cc2-632b54800532' }], paging: { count: 1 } };
        (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(expApiResponseData);
        const normalisedData = { data: 'normalised' };
        (normaliseData as jest.Mock).mockReturnValue(normalisedData);

        await postValidatePaymentLimitsController(req, res, next);

        expect(decodeAndValidateToken).toHaveBeenCalledWith({
            apiHeaders: res.locals.apiHeaders,
            logger: res.locals.logger,
            options: {
                requiredFields: ['userId', 'userIAMId'],
                fieldMappings: { userId: 'userId', userIAMId: 'iamID' }
            }
        });
        expect(handleApiService).toHaveBeenCalledWith({
            req,
            res,
            apiClient: expect.anything(),
						setDownstreamParams: setParamsForPostValidatePaymentLimits,
            requestBody: {
                instructionIdentification: 'inst-1',
                scheme: 'scheme-1',
                userCISKey: 'user-123',
                userIAMId: 'iam-999',
                organisationCISKey: 'org-456',
                settlementAmount: 100
            }
        });
        expect(transformDownstreamResponseToUi).toHaveBeenCalledWith(downstreamResponse.data);
        expect(normaliseData).toHaveBeenCalledWith('validatePaymentLimits', expApiResponseData, expect.anything());
        expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK);
        expect(res.json).toHaveBeenCalledWith(normalisedData);
        expect(res.end).toHaveBeenCalled();
        expect(next).not.toHaveBeenCalledWith(expect.any(Error));
    });

    it('should respond with normalised data on success (local env)', async () => {
        jest.spyOn(RUNTIME, 'isLocal').mockReturnValue(true);
        const req = {
            get: jest.fn()
                .mockImplementationOnce(() => 'org-456'),
            body: {
                instructionIdentification: 'inst-1',
                scheme: 'scheme-1',
                settlementAmount: 100
            }
        } as any;
        const res = mockRes();
        const next = jest.fn();
        const downstreamResponse = { data: { some: 'downstream' } };
        (handleApiService as jest.Mock).mockResolvedValue(downstreamResponse);
        const expApiResponseData = { entities: [{ id: 'd8427d22-2aec-4a8f-9cc2-632b54800532' }], paging: { count: 1 } };
        (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(expApiResponseData);
        const normalisedData = { data: 'normalised' };
        (normaliseData as jest.Mock).mockReturnValue(normalisedData);

        await postValidatePaymentLimitsController(req, res, next);

        expect(decodeAndValidateToken).not.toHaveBeenCalled();
        expect(handleApiService).toHaveBeenCalledWith({
            req,
            res,
            apiClient: expect.anything(),
						setDownstreamParams: setParamsForPostValidatePaymentLimits,
            requestBody: {
                instructionIdentification: 'inst-1',
                scheme: 'scheme-1',
                userCISKey: '',
                userIAMId: '',
                organisationCISKey: 'org-456',
                settlementAmount: 100
            }
        });
        expect(transformDownstreamResponseToUi).toHaveBeenCalledWith(downstreamResponse.data);
        expect(normaliseData).toHaveBeenCalledWith('validatePaymentLimits', expApiResponseData, expect.anything());
        expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK);
        expect(res.json).toHaveBeenCalledWith(normalisedData);
        expect(res.end).toHaveBeenCalled();
        expect(next).not.toHaveBeenCalledWith(expect.any(Error));
    });

    it('should handle errors and call next with error', async () => {
        jest.spyOn(RUNTIME, 'isLocal').mockReturnValue(false);
        const req = {
            get: jest.fn()
                .mockImplementationOnce(() => 'org-456'),
            body: {
                instructionIdentification: 'inst-1',
                scheme: 'scheme-1',
                settlementAmount: 100
            }
        } as any;
        const res = mockRes();
        const next = jest.fn();
        const error = new Error('fail');
        (handleApiService as jest.Mock).mockRejectedValue(error);

        await postValidatePaymentLimitsController(req, res, next);

        expect(handleControllerError).toHaveBeenCalledWith({ error, res, logger: res.locals.logger });
        expect(next).toHaveBeenCalledWith(error);
    });
});
