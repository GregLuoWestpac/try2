import { RUNTIME } from '@mep-node/framework-constants';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import {
  decodeAndValidateToken,
  DecodedTokenResult,
  DownstreamServiceResponse,
  handleApiService,
  handleControllerError,
  normaliseData,
  STATUS_CODES,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { NextFunction, Request, Response } from 'express';
import get from 'lodash/get';
import {
  LimitCheckRequest,
  LimitCheckResponse,
} from '../../../interfaces/models/downstream/paymentLimitsServiceV1';
import { paymentLimitsServiceV1Services } from '../../generated/api-clients';
import { transformDownstreamResponseToUi } from '../helpers/postValidatePaymentLimitsController.helper';
import { setParamsForPostValidatePaymentLimits } from '../../utils/setParams';

const postValidatePaymentLimitsController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { logger } = res.locals;
  const { checkPaymentLimit } = paymentLimitsServiceV1Services;

  try {
    const { apiHeaders } = res.locals;

    const { instructionIdentification, scheme, settlementAmount } =
      req.body as LimitCheckRequest;

    // TODO: Populating IAMID in the access token is part of Nov changes for W1
    let decodedToken: DecodedTokenResult = { userId: '', userIAMId: '' };
    if (!RUNTIME.isLocal()) {
      decodedToken = decodeAndValidateToken({
        apiHeaders,
        logger,
        options: {
          requiredFields: ['userId', 'userIAMId'],
          fieldMappings: { userId: 'userId', userIAMId: 'iamID' },
        },
      });
    }

    const organisationCISKey = req.get('protected-orgId');
    const userCISKey = decodedToken.userId;
    const userIAMId = decodedToken.userIAMId;

    const requestBody = {
      instructionIdentification,
      scheme,
      userCISKey,
      userIAMId,
      organisationCISKey,
      settlementAmount,
    };

    const downstreamResponse: DownstreamServiceResponse =
      await handleApiService({
        req,
        res,
        apiClient: checkPaymentLimit,
        setDownstreamParams: setParamsForPostValidatePaymentLimits,
        requestBody,
      });

    const paymentLimitsFromDownstreamResponse = get(
      downstreamResponse,
      'data',
      {}
    ) as LimitCheckResponse;

    const expApiResponseData = transformDownstreamResponseToUi(
      paymentLimitsFromDownstreamResponse
    );

    const normalisedData = normaliseData(
      'validatePaymentLimits',
      expApiResponseData,
      normalise
    );

    res.status(STATUS_CODES.OK).json(normalisedData).end();
  } catch (error) {
    handleControllerError({ error, res, logger });
    next(error);
  }
};

module.exports = postValidatePaymentLimitsController;
