import { Request, Response, NextFunction } from 'express';
import { RUNTIME } from '@mep-node/framework-constants';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import {
  ApiResponse,
  handleControllerError,
  normaliseData,
  STATUS_CODES,
  getDivisionsFromPdpQueryResult,
  ApiSuccessResponse,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { readMeshSecrets } from '../../utils/secretsUtils';
import { userAuthorisationPolicyDecisionEngineApiV1Services } from '../../generated/api-clients';
import { PDP_QUERY_ATTRIBUTES } from '../common/constants';
import { transformGetDivisionListResponse } from '../helpers/getDivisionListController.helper';
import { setupPDPCredentials } from '../../utils/commonHelper';

interface Division {
  id: string;
  divisionName: string;
  divisionId: string;
}

type ExpApiResponseData = Division[];

const getDivisionListController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { apiHeaders, logger } = res.locals;
  const { OK } = STATUS_CODES;

  const protectedOrgId = req.get('protected-orgid');
  const userId = apiHeaders?.['x-userId'];
  const { queryDecisionRequest } =
    userAuthorisationPolicyDecisionEngineApiV1Services;
  const pdpQueryAction =
    typeof req?.query?.pdpQueryAction === 'string'
      ? req.query.pdpQueryAction
      : undefined;

  try {
    const { pdpClientToken, org } = setupPDPCredentials(logger, apiHeaders);
    const divisionListPDPResponse = await getDivisionsFromPdpQueryResult({
      res,
      req,
      queryDecisionRequest,
      pdpClientToken,
      orgCisKey: protectedOrgId ?? org,
      userId,
      requestAction: pdpQueryAction,
    });

    const getDivisionResponse = transformGetDivisionListResponse(
      divisionListPDPResponse
    );

    // amend normalisedData, avoid missing divisionList field in entity when division list in result is empty
    const schemaKey = 'divisionList';
    const normalisedData = normaliseData(
      schemaKey,
      getDivisionResponse,
      normalise
    ) as ApiResponse<{ divisionList: ExpApiResponseData }>;
    const { entities, result } =
      (normalisedData as ApiSuccessResponse<{
        divisionList: ExpApiResponseData;
      }>) ?? {};
    if (
      !Array.isArray(entities?.[schemaKey]) &&
      Array.isArray(result?.[schemaKey])
    ) {
      (normalisedData as any).entities ??= {};
      (normalisedData as any).entities[schemaKey] = [];
    }

    res.status(OK).json(normalisedData).end();
  } catch (error) {
    handleControllerError({ error, res, logger });
    next(error);
  }
};

module.exports = getDivisionListController;
