/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable import/no-import-module-exports */
import { Request, Response, NextFunction } from 'express';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import { ApiResponse } from '../../../interfaces/types/common';
import {
  PostPaymentListingEXPAPIResponse,
  PostPaymentListingCAPRequest,
} from '../../../interfaces/types/paymentListing';
import { CONSTANTS } from '../../utils/constants';
import {
  paymentListingSchema,
  pagingSchema,
} from '../schema/postPaymentSearch.schema';
import { transformPaymentListingResponseFromCAPToUI } from '../helpers/postPaymentListingController.helper';
import { postPaymentListingFromDownstream } from '../services/paymentListingService';
import { accessControlExposeHeaders, handleControllerError } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

const postPaymentListingController = async (
  req: Request<never, Record<string, unknown>, PostPaymentListingCAPRequest>,
  res: Response<ApiResponse<PostPaymentListingEXPAPIResponse>>,
  next: NextFunction
) => {
  const { logger } = res.locals;
  const queryParams = req.query || {};

  logger.trace('post payment listing controller');

  const {
    postPaymentListingControllerTitle,
    httpStatus: { OK },
  } = CONSTANTS;

  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);
  try {
    logger.info(`${postPaymentListingControllerTitle} - Start`);
    const paymentListingData = await postPaymentListingFromDownstream(req, res);

    const transformedData = transformPaymentListingResponseFromCAPToUI(
      paymentListingData.responseData,
      paymentListingData.status,
      queryParams
    );

    const normalisedData: ApiResponse<PostPaymentListingEXPAPIResponse> =
      normalise(transformedData, {
        paymentListing: [paymentListingSchema],
        paging: [pagingSchema],
      });
    if (transformedData?.paymentListing?.length === 0) {
      normalisedData.entities.paymentListing = [];
    }
    delete normalisedData.result.paging;

    res.status(OK).send(normalisedData);

    logger.info(`${postPaymentListingControllerTitle} - End`);
  } catch (error) {
    handleControllerError({
      error,
      res,
      logger
    });
    next(error);
  }
};

module.exports = postPaymentListingController;
