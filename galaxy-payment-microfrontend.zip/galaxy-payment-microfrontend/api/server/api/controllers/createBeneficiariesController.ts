import { RUNTIME } from '@mep-node/framework-constants';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import { beneficiaryManagementV1Services } from '../../generated/api-clients';
import { buildCreateBeneficiaryController } from '@mesh-tenant-multiverse-ui-common/mv-apibeneficiarycreate';
import { ControllerParams } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { readMeshSecrets } from '../../utils/secretsUtils';

const controllerParams: ControllerParams = {
  RUNTIME,
  normalise,
  apiClient: beneficiaryManagementV1Services,
  readMeshSecrets
};

const createBeneficiariesController =
  buildCreateBeneficiaryController(controllerParams);

module.exports = createBeneficiariesController;