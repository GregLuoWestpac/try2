import { Request, Response, NextFunction } from 'express';

// Inline mock data
const transformedData = {
  id: '18fcc682-abbe-459f-8fc3-a8b3b8369dcd',
  name: 'Test Beneficiary',
  accountNumber: '123456789',
  bsb: '123-456',
};

const normalisedData = {
  entities: { beneficiaries: { [transformedData.id]: transformedData } },
  result: [transformedData.id],
};

import { CONSTANTS } from '../../utils/constants';
import { handleControllerError } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
const postAliasLookupByBeneIdController = require('./postAliasLookupByBeneIdController');

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apialiaslookup', () => ({
  validateAliasLookupByBeneIdRequestBody: jest.fn(() => ({ isValid: true })),
  getAliasLookupByBeneficiaryIdHandler: jest.fn(),
}));

jest.mock('../../utils/constants', () => ({
  CONSTANTS: { httpStatus: { OK: 200 } },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-apiutils'),
  handleControllerError: jest.fn(),
  handleApiService: jest.fn(),
  normaliseData: jest.fn(() => normalisedData),
}));

describe('postAliasLookupByBeneIdController', () => {
  let req: Partial<Request>;
  let res: Partial<Response>;
  let next: NextFunction;
  beforeEach(() => {
    req = {
      body: {
        id: '18fcc682-abbe-459f-8fc3-a8b3b8369dcd',
      },
    };
    res = {
      locals: {
        status: jest.fn().mockReturnThis(),
        json: jest.fn().mockReturnThis(),
        send: jest.fn().mockReturnThis(),
        setHeader: jest.fn(),
        end: jest.fn(),
        //@ts-ignore
        logger: {
          debug: jest.fn(),
        },
      },
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
      setHeader: jest.fn(),
    };
    next = jest.fn();
    jest.clearAllMocks();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should return 200 with transformed and normalized data when successful', async () => {
    // Mock the handler to simulate success and respond via res
    const {
      getAliasLookupByBeneficiaryIdHandler,
    } = require('@mesh-tenant-multiverse-ui-common/mv-apialiaslookup');
    (getAliasLookupByBeneficiaryIdHandler as jest.Mock).mockImplementationOnce(
      async (_req: any, r: any, _next: any) => {
        // simulate handler writing response
        r.status(CONSTANTS.httpStatus.OK);
        r.json(normalisedData);
      }
    );

    // Call the controller
    await postAliasLookupByBeneIdController(
      req as Request,
      res as Response,
      next
    );

    // Assert that the beneficiary-id handler was called
    const {
      getAliasLookupByBeneficiaryIdHandler: calledHandler,
    } = require('@mesh-tenant-multiverse-ui-common/mv-apialiaslookup');
    expect(calledHandler).toHaveBeenCalledTimes(1);
    expect(calledHandler).toHaveBeenCalledWith(
      req,
      res,
      next,
      expect.any(Object)
    );

    // Assert that the response status and JSON were set correctly
    expect(res.status).toHaveBeenCalledWith(CONSTANTS.httpStatus.OK);
    expect(res.json).toHaveBeenCalledWith(normalisedData);
  });
  it('should handle errors and call handleControllerError', async () => {
    const mockError = new Error('Test error');
    const {
      getAliasLookupByBeneficiaryIdHandler,
    } = require('@mesh-tenant-multiverse-ui-common/mv-apialiaslookup');
    (getAliasLookupByBeneficiaryIdHandler as jest.Mock).mockRejectedValueOnce(
      mockError
    );

    await postAliasLookupByBeneIdController(
      req as Request,
      res as Response,
      next
    );

    expect(handleControllerError).toHaveBeenCalledWith({
      error: mockError,
      res,
      logger: res.locals.logger,
    });
    expect(next).toHaveBeenCalledWith(mockError);
  });

  it('should throw an error if id is missing in the request body', async () => {
    req.body.id = undefined;

    const {
      getAliasLookupByBeneficiaryIdHandler,
    } = require('@mesh-tenant-multiverse-ui-common/mv-apialiaslookup');
    (getAliasLookupByBeneficiaryIdHandler as jest.Mock).mockRejectedValueOnce(
      new Error('payid flow error')
    );

    await postAliasLookupByBeneIdController(
      req as Request,
      res as Response,
      next
    );
    expect(handleControllerError).toHaveBeenCalled();
    expect(next).toHaveBeenCalled();
  });
});
