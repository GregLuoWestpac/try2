import { Request, Response, NextFunction } from 'express';
import { v4 as uuid } from 'uuid';
import {
  PostPaymentReturnsRequest,
  PostPaymentReturnExpResponse,
} from '../../../interfaces/models/PaymentReturns';
import {
  CONSTANTS,
} from '../../utils/constants';
import {
  postPaymentReturnsSchemaBuilder,
  SCHEMA_KEY,
} from '../schema/postPaymentReturn.schema';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import { ApiResponse } from '../../../interfaces/types/common';
import { accessControlExposeHeaders, handleControllerError } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { postPaymentReturnServiceFromDownstream } from '../services/postPaymentReturnService';
import { transformPaymentReturnCapApiResponseToUI } from '../helpers/postPaymentReturnsController.helper';

const postPaymentReturnsController = async (
  req: Request<never, Record<string, unknown>, PostPaymentReturnsRequest>,
  res: Response<ApiResponse<PostPaymentReturnExpResponse> | string>,
  next: NextFunction
) => {
  const { logger } = res.locals;

  logger.trace('post payment return controller');

  const { postPaymentReturnControllerTitle } = CONSTANTS;

  const normaliseData = (
    response: PostPaymentReturnExpResponse[]
  ): ApiResponse<PostPaymentReturnExpResponse> => {
    return normalise({ [SCHEMA_KEY]: response }, postPaymentReturnsSchemaBuilder);
  };

  let paymentReturnData;

  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);
  try {
    logger.info(`${postPaymentReturnControllerTitle} - Start`);
    const messageIdentification = uuid().replace(/-/g, '');
    paymentReturnData = await postPaymentReturnServiceFromDownstream(
      req,
      res,
      messageIdentification
    );
    res
      .status(paymentReturnData.status)
      .json(
        normaliseData(
          transformPaymentReturnCapApiResponseToUI(
            paymentReturnData.responseData,
            logger,
            paymentReturnData.status,
            paymentReturnData.paymentId,
            messageIdentification
          )
        )
      )
      .send();
    logger.info(`${postPaymentReturnControllerTitle} - End`);
  } catch (error: any) {
    handleControllerError({
      error,
      res,
      logger
    });
    next(error);
  }
};

module.exports = postPaymentReturnsController;
