/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
import {
  handleControllerError,
  APIClientError,
  STATUS_CODES,
  accessControlExposeHeaders,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import {
  getAliasLookupByBeneficiaryIdHandler,
  validateAliasLookupByBeneIdRequestBody,
  AliasLookupByBeneIdEXPRequestBody,
} from '@mesh-tenant-multiverse-ui-common/mv-apialiaslookup';

import { NextFunction, Request, Response } from 'express';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import {
  paymentAliasResolutionV2Services,
  beneficiaryManagementV1Services,
} from '../../generated/api-clients';

const postAliasLookupByBeneIdController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { logger } = res.locals;
  const body = req.body as AliasLookupByBeneIdEXPRequestBody;

  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);

  try {
    // Validate request body
    const validation = validateAliasLookupByBeneIdRequestBody(body);
    if (!validation.isValid) {
      res.status(STATUS_CODES.BAD_REQUEST).json({
        code: 'INVALID_REQUEST_BODY',
      });
      return;
    }
    const getAliasLookupByBeneficiaryIdParams: any = {
      normalise,
      paymentAliasResolutionV2Services,
      beneficiaryManagementV1Services,
    };
    await getAliasLookupByBeneficiaryIdHandler(
      req,
      res,
      next,
      getAliasLookupByBeneficiaryIdParams
    );
  } catch (error: unknown) {
    const apiError = error as APIClientError;
    handleControllerError({ error: apiError, res, logger });
    next(error);
  }
};

export = postAliasLookupByBeneIdController;
