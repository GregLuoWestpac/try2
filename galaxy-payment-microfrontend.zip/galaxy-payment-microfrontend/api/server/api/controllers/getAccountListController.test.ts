import { NextFunction } from 'express';
import { createRequest, createResponse } from 'node-mocks-http';
import { normalise } from '@mep-node/framework-response-normaliser-addon';

// Mock all the dependencies before importing anything else
jest.mock('@mep-node/framework-constants', () => ({
  RUNTIME: {
    APP_NAME: 'test-app',
    NODE_ENV: 'test',
  },
}));

jest.mock('@mep-node/framework-response-normaliser-addon', () => ({
  normalise: jest.fn().mockReturnValue('normalized-data'),
}));

jest.mock('../../generated/api-clients', () => ({
  userAuthorisationPolicyDecisionEngineApiV1Services: {
    getAccountList: jest.fn(),
  },
}));

jest.mock('../../utils/secretsUtils', () => ({
  readMeshSecrets: jest.fn().mockReturnValue({}),
}));

const mockControllerFunction = jest.fn().mockResolvedValue(undefined);
jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiaccountlist', () => ({
  buildGetAccountListController: jest
    .fn()
    .mockReturnValue(mockControllerFunction),
}));

describe('getAccountListController', () => {
  let req: any;
  let res: any;
  let next: NextFunction;

  // Create a default response object with mock headers and locals
  const getDefaultRes = () => {
    const logger = {
      info: jest.fn(),
      error: jest.fn(),
      warn: jest.fn(),
      debug: jest.fn(),
    };

    const response = createResponse({
      locals: {
        apiHeaders: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'x-appCorrelationId': '1234Id',
          'x-brandId': 'WBC',
          'x-channelType': 'Branch',
          'x-messageId': '12345678uisajsi',
        },
        normalise,
        logger,
      },
    });

    response.app = {
      locals: {
        Config: {
          get: jest.fn().mockReturnValue({
            requestConfig: {},
            responseConfig: {},
          }),
        },
      },
    } as any;

    return response;
  };

  beforeEach(() => {
    req = createRequest();
    res = getDefaultRes();
    next = jest.fn();

    // Reset all mocks
    jest.resetAllMocks();
    mockControllerFunction.mockResolvedValue(undefined);
  });

  describe('Controller Creation and Export', () => {
    it('should create controller with correct parameters and export it', async () => {
      // Import the required mocked modules
      const {
        buildGetAccountListController,
      } = require('@mesh-tenant-multiverse-ui-common/mv-apiaccountlist');
      const {
        userAuthorisationPolicyDecisionEngineApiV1Services,
      } = require('../../generated/api-clients');
      const { readMeshSecrets } = require('../../utils/secretsUtils');
      const { RUNTIME } = require('@mep-node/framework-constants');

      // Import the controller module
      const controller = require('./getAccountListController');

      // Verify buildGetAccountListController was called with correct parameters
      expect(buildGetAccountListController).toHaveBeenCalledWith({
        RUNTIME,
        normalise,
        apiClient: userAuthorisationPolicyDecisionEngineApiV1Services,
        readMeshSecrets,
      });

      // Verify the exported controller is the function returned by buildGetAccountListController
      expect(controller).toBe(mockControllerFunction);
    });

    it('should export a function', () => {
      const controller = require('./getAccountListController');
      expect(typeof controller).toBe('function');
    });
  });

  describe('Controller Function Execution', () => {
    it('should call the controller function with correct parameters', async () => {
      const controller = require('./getAccountListController');

      await controller(req, res, next);

      expect(mockControllerFunction).toHaveBeenCalledWith(req, res, next);
    });

    it('should handle successful execution', async () => {
      mockControllerFunction.mockResolvedValue(undefined);
      const controller = require('./getAccountListController');

      await expect(controller(req, res, next)).resolves.toBeUndefined();
      expect(mockControllerFunction).toHaveBeenCalledWith(req, res, next);
    });

    it('should propagate errors from the controller function', async () => {
      const error = new Error('Test error');
      mockControllerFunction.mockRejectedValue(error);
      const controller = require('./getAccountListController');

      await expect(controller(req, res, next)).rejects.toThrow('Test error');
      expect(mockControllerFunction).toHaveBeenCalledWith(req, res, next);
    });
  });

  describe('Dependency Integration', () => {
    it('should be tested through the Controller Creation test', () => {
      // This test ensures that the dependencies are being tested
      // The actual dependency verification is done in the "Controller Creation and Export" test
      // where we verify that buildGetAccountListController is called with the correct parameters
      expect(true).toBe(true);
    });
  });

  describe('Module Properties', () => {
    it('should export the expected controller function', () => {
      const controller = require('./getAccountListController');

      // Verify the controller is the mocked function we expect
      expect(controller).toBe(mockControllerFunction);
      expect(typeof controller).toBe('function');
    });

    it('should maintain CommonJS module format', () => {
      // Test that the module is properly exported using module.exports
      const controller = require('./getAccountListController');

      expect(controller).toBeDefined();
      expect(typeof controller).toBe('function');
    });
  });
});
