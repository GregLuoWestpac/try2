import { NextFunction, Request, Response } from 'express';
import {
  PostPaymentsRequest,
  PostPaymentsResponse,
} from '../../../interfaces/models/Payments';
import { ApiResponse } from '../../../interfaces/types/common';

// Mock the paymentCreateController
const mockPostPaymentCreateController = jest.fn();
jest.mock('./paymentCreateController', () => mockPostPaymentCreateController);

describe('postPaymentCreateForNewBeneficiaryController', () => {
  let mockReq: Request<never, Record<string, unknown>, PostPaymentsRequest>;
  let mockRes: Response<ApiResponse<PostPaymentsResponse> | string>;
  let mockNext: NextFunction;
  let postPaymentCreateForNewBeneficiaryController: any;

  beforeEach(() => {
    jest.clearAllMocks();

    // Import the controller after mocking
    postPaymentCreateForNewBeneficiaryController = require('./postPaymentCreateForNewBeneficiaryController');

    // Create mock request, response, and next function
    mockReq = {
      body: {
        clientContext: { channelType: 'W1C_O_A_D_CP' },
        creditTransferTransactionInformation: [
          {
            creditor: { name: 'New Beneficiary' },
            creditorAccount: {
              identification: '123456789',
              schemeName: 'BBAN',
            },
            instructedAmount: { amount: '500.00', currency: 'AUD' },
          },
        ],
        debtor: { name: 'Test Debtor' },
        debtorAccount: { identification: '987654321' },
        supplementaryData: { debitDescription: 'Payment to new beneficiary' },
      },
    } as Request<never, Record<string, unknown>, PostPaymentsRequest>;

    mockRes = {
      locals: {
        logger: {
          info: jest.fn(),
          error: jest.fn(),
          trace: jest.fn(),
          debug: jest.fn(),
          warn: jest.fn(),
        },
        apiHeaders: {
          'x-userId': 'M123456',
        },
      },
      setHeader: jest.fn(),
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      end: jest.fn(),
    } as unknown as Response<ApiResponse<PostPaymentsResponse> | string>;

    mockNext = jest.fn() as NextFunction;
  });

  it('should delegate to paymentCreateController', async () => {
    // Act
    await postPaymentCreateForNewBeneficiaryController(
      mockReq,
      mockRes,
      mockNext
    );

    // Assert
    expect(mockPostPaymentCreateController).toHaveBeenCalledTimes(1);
    expect(mockPostPaymentCreateController).toHaveBeenCalledWith(
      mockReq,
      mockRes,
      mockNext,
      'paymentCreateForNewBeneficiary'
    );
  });

  it('should pass through any errors from the paymentCreateController', async () => {
    // Arrange
    const testError = new Error('Test error from controller');
    mockPostPaymentCreateController.mockRejectedValue(testError);

    // Act & Assert
    await expect(
      postPaymentCreateForNewBeneficiaryController(mockReq, mockRes, mockNext)
    ).rejects.toThrow('Test error from controller');

    expect(mockPostPaymentCreateController).toHaveBeenCalledWith(
      mockReq,
      mockRes,
      mockNext,
      'paymentCreateForNewBeneficiary'
    );
  });

  it('should resolve successfully when paymentCreateController resolves', async () => {
    // Arrange
    mockPostPaymentCreateController.mockResolvedValue(undefined);

    // Act
    await postPaymentCreateForNewBeneficiaryController(
      mockReq,
      mockRes,
      mockNext
    );

    // Assert
    expect(mockPostPaymentCreateController).toHaveBeenCalledWith(
      mockReq,
      mockRes,
      mockNext,
      'paymentCreateForNewBeneficiary'
    );
  });

  it('should maintain correct function signature and types', () => {
    // Assert that the controller is a function
    expect(typeof postPaymentCreateForNewBeneficiaryController).toBe(
      'function'
    );

    // Assert that it's an async function (returns a Promise)
    const result = postPaymentCreateForNewBeneficiaryController(
      mockReq,
      mockRes,
      mockNext
    );
    expect(result).toBeInstanceOf(Promise);
  });

  it('should handle new beneficiary payment request structures', async () => {
    // Arrange - typical new beneficiary payment request
    const newBeneficiaryReq = {
      body: {
        clientContext: { channelType: 'MOBILE' },
        creditTransferTransactionInformation: [
          {
            creditor: {
              name: 'John Doe - New Beneficiary',
              address: {
                addressLine: ['123 Test Street'],
                country: 'AU',
              },
            },
            creditorAccount: {
              identification: '123456789012',
              schemeName: 'BBAN',
              name: 'John Doe Savings',
            },
            creditorAgent: {
              BICFI: 'WPACAU2SXXX',
            },
            instructedAmount: {
              amount: '1000.00',
              currency: 'AUD',
            },
            remittanceInformation: {
              unstructured: ['Payment to new beneficiary'],
            },
          },
        ],
        debtor: { name: 'Test Account Holder' },
        debtorAccount: { identification: '987654321098' },
        supplementaryData: {
          debitDescription: 'Transfer to new beneficiary',
          beneficiaryId: 'NEW_BENEFICIARY_001',
        },
      },
    } as unknown as Request<
      never,
      Record<string, unknown>,
      PostPaymentsRequest
    >;

    // Act
    await postPaymentCreateForNewBeneficiaryController(
      newBeneficiaryReq,
      mockRes,
      mockNext
    );

    // Assert
    expect(mockPostPaymentCreateController).toHaveBeenCalledWith(
      newBeneficiaryReq,
      mockRes,
      mockNext,
      'paymentCreateForNewBeneficiary'
    );
  });

  it('should handle different response configurations for new beneficiary payments', async () => {
    // Arrange
    const differentRes = {
      locals: {
        logger: {
          info: jest.fn(),
          error: jest.fn(),
          trace: jest.fn(),
          debug: jest.fn(),
          warn: jest.fn(),
        },
        apiHeaders: {
          'x-userId': 'M654321',
          'x-brandId': 'RAMS',
          'x-channelType': 'MOBILE',
          'x-messageId': 'NEW_BENEFICIARY_MSG_001',
        },
      },
    } as unknown as Response<ApiResponse<PostPaymentsResponse> | string>;

    // Act
    await postPaymentCreateForNewBeneficiaryController(
      mockReq,
      differentRes,
      mockNext
    );

    // Assert
    expect(mockPostPaymentCreateController).toHaveBeenCalledWith(
      mockReq,
      differentRes,
      mockNext,
      'paymentCreateForNewBeneficiary'
    );
  });

  it('should handle multiple new beneficiary transactions in single request', async () => {
    // Arrange - request with multiple new beneficiaries
    const multipleReq = {
      body: {
        clientContext: { channelType: 'WEB' },
        creditTransferTransactionInformation: [
          {
            creditor: { name: 'New Beneficiary 1' },
            creditorAccount: {
              identification: '111111111',
              schemeName: 'BBAN',
            },
            instructedAmount: { amount: '250.00', currency: 'AUD' },
          },
          {
            creditor: { name: 'New Beneficiary 2' },
            creditorAccount: {
              identification: '222222222',
              schemeName: 'BBAN',
            },
            instructedAmount: { amount: '750.00', currency: 'AUD' },
          },
        ],
        debtor: { name: 'Multi-Transfer Account' },
        debtorAccount: { identification: '999999999' },
        supplementaryData: {
          debitDescription: 'Multiple new beneficiary payments',
        },
      },
    } as unknown as Request<
      never,
      Record<string, unknown>,
      PostPaymentsRequest
    >;

    // Act
    await postPaymentCreateForNewBeneficiaryController(
      multipleReq,
      mockRes,
      mockNext
    );

    // Assert
    expect(mockPostPaymentCreateController).toHaveBeenCalledWith(
      multipleReq,
      mockRes,
      mockNext,
      'paymentCreateForNewBeneficiary'
    );
  });

  it('should not modify request or response objects before delegation', async () => {
    // Arrange
    const originalReq = { ...mockReq };
    const originalRes = { ...mockRes };

    // Act
    await postPaymentCreateForNewBeneficiaryController(
      mockReq,
      mockRes,
      mockNext
    );

    // Assert
    expect(mockReq).toEqual(originalReq);
    expect(mockRes).toEqual(originalRes);
    expect(mockPostPaymentCreateController).toHaveBeenCalledWith(
      mockReq,
      mockRes,
      mockNext,
      'paymentCreateForNewBeneficiary'
    );
  });
});
