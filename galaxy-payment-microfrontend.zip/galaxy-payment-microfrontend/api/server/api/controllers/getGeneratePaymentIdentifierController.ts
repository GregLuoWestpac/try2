import { Request, Response, NextFunction } from 'express';
import { CONSTANTS } from '../../utils/constants';
import {
  handleControllerError,
  handleApiService,
  normaliseData,
  accessControlExposeHeaders,
  APIClient,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { IdentifierGenerator } from '../../generated/api-clients/customerPaymentInstructionIdV1Services';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import { transformDownstreamResponseToUi } from '../helpers/getGeneratePaymentIdentifierController.helper';
import { setParamsForGetDownStreamApi } from '../../utils/setParams';

const getGeneratePaymentIdentifier = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const {
    httpStatus: { CREATED },
  } = CONSTANTS;
  const { logger } = res.locals;

  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);
  try {
    const response = await handleApiService({
      req,
      res,
      apiClient: IdentifierGenerator as APIClient,
      setDownstreamParams: setParamsForGetDownStreamApi,
    });

    const transformedResponse = transformDownstreamResponseToUi(response.data);

    const normalisedData = normaliseData(
      'paymentIdentifier',
      transformedResponse,
      normalise
    );

    res.status(CREATED).json(normalisedData).end();
  } catch (error) {
    logger.error('Error in getGeneratePaymentIdentifier');

    handleControllerError({
      error,
      res,
      logger,
    });
    next(error);
  }
};

module.exports = getGeneratePaymentIdentifier;
