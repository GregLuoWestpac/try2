import { RUNTIME } from '@mep-node/framework-constants';
import {
  decodeAndValidateToken,
  DecodedTokenResult,
  handleApiService,
  handleControllerError,
  normaliseDataWithPaging,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { Response } from 'express';
import { transformDownstreamResponseToUi } from '../helpers/getPaymentLimitsController.helper';

const getPaymentLimitsController = require('./getPaymentLimitsController');

jest.mock('../helpers/getPaymentLimitsController.helper');
jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils');
jest.mock('../../utils/commonHelper');

const mockLogger = {
  info: jest.fn(),
  error: jest.fn(),
  warn: jest.fn(),
  debug: jest.fn(),
  log: jest.fn(),
};
const mockRes = () => {
  const res: Partial<Response> = {
    status: jest.fn().mockReturnThis(),
    json: jest.fn().mockReturnThis(),
    end: jest.fn().mockReturnThis(),
    locals: { logger: mockLogger, apiHeaders: { some: 'header' } } as any,
    get: jest.fn(),
  };
  return res as Response;
};

describe('getPaymentLimitsController', () => {
  let res: Response;

  beforeEach(() => {
    res = mockRes();
    (res.locals as any).logger = mockLogger;
    (res.locals as any).httpStatus = { OK: 200 };
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should respond with normalised data on success (non-local)', async () => {
    jest.spyOn(RUNTIME, 'isLocal').mockReturnValue(false);
    const decodedToken: DecodedTokenResult = { userId: 'user-123' };
    (decodeAndValidateToken as jest.Mock).mockReturnValue(decodedToken);
    const req = {
      get: jest
        .fn()
        .mockImplementationOnce(() => 'org-456')
        .mockImplementationOnce(() => 'channel-789'),
    } as any;
    const res = mockRes();
    const next = jest.fn();
    const paymentLimitsResponse = { data: { some: 'downstream' } };
    (handleApiService as jest.Mock).mockResolvedValue(paymentLimitsResponse);
    const expApiResponseData = {
      paymentLimits: [{ id: 1 }],
      paging: { count: 1 },
    };
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      expApiResponseData
    );
    const normalisedData = { data: 'normalised' };
    (normaliseDataWithPaging as jest.Mock).mockReturnValue(normalisedData);
    (res.locals as any).httpStatus = { OK: 200 };

    await getPaymentLimitsController(req, res, next);

    expect(decodeAndValidateToken).toHaveBeenCalledWith({
      apiHeaders: res.locals.apiHeaders,
      logger: res.locals.logger,
      options: {
        requiredFields: ['userId'],
        fieldMappings: { userId: 'userId' },
      },
    });
    expect(handleApiService).toHaveBeenCalledWith({
      req,
      res,
      apiClient: expect.anything(),
      setDownstreamParams: expect.anything(),
      requestBody: {
        userCISKey: 'user-123',
        organisationCISKey: 'org-456',
        channelId: 'channel-789',
      },
      reqMethod: 'POST',
    });
    expect(transformDownstreamResponseToUi).toHaveBeenCalledWith(
      paymentLimitsResponse.data
    );
    expect(normaliseDataWithPaging).toHaveBeenCalledWith(
      'paymentLimits',
      {
        paymentLimits: expApiResponseData.paymentLimits,
        paging: expApiResponseData.paging,
      },
      expect.anything()
    );
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(normalisedData);
    expect(res.end).toHaveBeenCalled();
    expect(next).not.toHaveBeenCalledWith(expect.any(Error));
  });

  it('should respond with normalised data on success (local env)', async () => {
    jest.spyOn(RUNTIME, 'isLocal').mockReturnValue(true);
    const req = {
      get: jest
        .fn()
        .mockImplementationOnce(() => 'org-456')
        .mockImplementationOnce(() => 'channel-789'),
    } as any;
    const res = mockRes();
    const next = jest.fn();
    const paymentLimitsResponse = { data: { some: 'downstream' } };
    (handleApiService as jest.Mock).mockResolvedValue(paymentLimitsResponse);
    const expApiResponseData = {
      paymentLimits: [{ id: 1 }],
      paging: { count: 1 },
    };
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      expApiResponseData
    );
    const normalisedData = { data: 'normalised' };
    (normaliseDataWithPaging as jest.Mock).mockReturnValue(normalisedData);
    (res.locals as any).httpStatus = { OK: 200 };

    await getPaymentLimitsController(req, res, next);

    expect(decodeAndValidateToken).not.toHaveBeenCalled();
    expect(handleApiService).toHaveBeenCalledWith({
      req,
      res,
      apiClient: expect.anything(),
      setDownstreamParams: expect.anything(),
      requestBody: {
        userCISKey: '',
        organisationCISKey: 'org-456',
        channelId: 'channel-789',
      },
      reqMethod: 'POST',
    });
    expect(transformDownstreamResponseToUi).toHaveBeenCalledWith(
      paymentLimitsResponse.data
    );
    expect(normaliseDataWithPaging).toHaveBeenCalledWith(
      'paymentLimits',
      {
        paymentLimits: expApiResponseData.paymentLimits,
        paging: expApiResponseData.paging,
      },
      expect.anything()
    );
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(normalisedData);
    expect(res.end).toHaveBeenCalled();
    expect(next).not.toHaveBeenCalledWith(expect.any(Error));
  });

  it('should handle errors and call next with error', async () => {
    jest.spyOn(RUNTIME, 'isLocal').mockReturnValue(false);
    const req = {
      get: jest
        .fn()
        .mockImplementationOnce(() => 'org-456')
        .mockImplementationOnce(() => 'channel-789'),
    } as any;
    const res = mockRes();
    const next = jest.fn();
    const error = new Error('fail');
    (handleApiService as jest.Mock).mockRejectedValue(error);
    (res.locals as any).httpStatus = { OK: 200 };

    await getPaymentLimitsController(req, res, next);

    expect(handleControllerError).toHaveBeenCalledWith({
      error,
      res,
      logger: res.locals.logger,
    });
    expect(next).toHaveBeenCalledWith(error);
  });
});
