import { RUNTIME } from '@mep-node/framework-constants';
import {
  handleApiService,
  handleControllerError,
  normaliseDataWithPaging,
  STATUS_CODES,
  transformPdpQueryResult,
  getBeneficiaryIdsFromPdpQueryResult,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { NextFunction, Request, Response } from 'express';
import { readMeshSecrets } from '../../utils/secretsUtils';
import { transformDownstreamResponseToUi } from '../helpers/retrieveBeneficiariesController.helper';

const retrieveBeneficiariesController = require('./retrieveBeneficiariesController');

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-apiutils'),
  handleApiService: jest.fn(),
  handleControllerError: jest.fn(),
  STATUS_CODES: { OK: 200 },
  normaliseDataWithPaging: jest.fn(),
  transformPdpQueryResult: jest.fn(),
  getPdpQueryResults: jest.fn(),
  getBeneficiaryIdsFromPdpQueryResult: jest.fn(),
}));

jest.mock('../../utils/secretsUtils', () => ({
  readMeshSecrets: jest.fn(),
}));

jest.mock('../../generated/api-clients', () => ({
  beneficiaryManagementV1Services: {
    RetrieveBeneficiary: jest.fn(),
  },
  userAuthorisationPolicyDecisionEngineApiV1Services: {
    queryDecisionRequest: jest.fn(),
  },
}));

jest.mock('@mep-node/framework-constants', () => ({
  RUNTIME: {
    isLocal: jest.fn(),
  },
}));

jest.mock('@mep-node/framework-response-normaliser-addon', () => ({
  normalise: jest.fn(),
}));

jest.mock(
  '@mesh-tenant-user-authorisation-policy-decision-engine/entitlements-api-lib',
  () => ({
    PDP_QUERY_ACTIONS: {
      VIEW_BENEFICIARY: 'VIEW_BENEFICIARY',
    },
  })
);

jest.mock('../helpers/retrieveBeneficiariesController.helper', () => ({
  transformDownstreamResponseToUi: jest.fn(),
}));

describe('retrieveBeneficiariesController', () => {
  let req: Partial<Request>;
  let res: Partial<Response>;
  let next: NextFunction;
  let logger: any;

  beforeEach(() => {
    req = {
      query: {},
      body: {},
      get: jest.fn(),
    };
    res = {
      locals: {
        //@ts-ignore
        logger: {
          info: jest.fn(),
          error: jest.fn(),
        },
        apiHeaders: { 'x-userId': 'test-user' },
      },
      status: jest.fn().mockReturnThis(),
      setHeader: jest.fn(),
      json: jest.fn(),
      end: jest.fn(),
    };
    next = jest.fn();
    logger = res.locals.logger;
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should return beneficiaries when downstream service responds successfully', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(true);

    const mockResponse = {
      data: {
        beneficiaries: [{ id: '123', name: 'Test Beneficiary' }],
      },
    };

    (handleApiService as jest.Mock).mockResolvedValue(mockResponse);

    await retrieveBeneficiariesController(
      req as Request,
      res as Response,
      next
    );

    expect(handleApiService).toHaveBeenCalled();
  });

  it('should call PDP flow and return beneficiary list in server', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(false);

    (readMeshSecrets as jest.Mock).mockReturnValue({
      pdpClientToken: 'mock-token',
      org: 'mock-org',
    });
    // Mock getBeneficiaryIdsFromPdpQueryResult to return PdpQueryResult[]
    const mockPdpQueryResults = [
      {
        attribute: 'beneficiaryId',
        value: '1',
        decision: 'Permit',
        statements: [
          {
            id: 'stmt1',
            name: 'Statement 1',
            code: 'S1',
            payload: '{}',
            obligatory: true,
            fulfilled: true,
            attributes: {},
          },
        ],
      },
      {
        attribute: 'beneficiaryId',
        value: '2',
        decision: 'Permit',
        statements: [
          {
            id: 'stmt2',
            name: 'Statement 2',
            code: 'S2',
            payload: '{}',
            obligatory: false,
            fulfilled: true,
            attributes: {},
          },
        ],
      },
    ];
    (getBeneficiaryIdsFromPdpQueryResult as jest.Mock).mockResolvedValue(mockPdpQueryResults);
    (transformPdpQueryResult as jest.Mock).mockReturnValue(mockPdpQueryResults.map(r => r.value));

    const mockApiResponse = {
      data: {
        beneficiaries: [
          {
            id: '123456789',
            externalId: '123456789',
            nickname: 'office 1',
            currency: 'abc',
            org: 'office1',
            account: {},
          },
        ],
      },
      paging: {
        id: '1',
        pageSize: 50,
        count: 160,
        previousPageKey: '0',
        nextPageKey: '2',
        moreItems: true,
      },
    };

    // Mock the API service and helper functions
    (handleApiService as jest.Mock).mockResolvedValue(mockApiResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      mockApiResponse.data
    );
    (normaliseDataWithPaging as jest.Mock).mockReturnValue(
      mockApiResponse.data
    );

    // Call the controller function
    await retrieveBeneficiariesController(
      req as Request,
      res as Response,
      next
    );

    // Assert that the controller calls the service, transforms data, and returns the correct response
    expect(handleApiService).toHaveBeenCalled();
    expect(transformDownstreamResponseToUi).toHaveBeenCalledWith(
      mockApiResponse.data
    );
    expect(readMeshSecrets).toHaveBeenCalled();
    expect(transformPdpQueryResult).toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(STATUS_CODES.OK); // Ensure status is set
    expect(res.json).toHaveBeenCalledWith(mockApiResponse.data); // Ensure json is called with data
  });

  it('should handle errors and call next with the error', async () => {
    (RUNTIME.isLocal as jest.Mock).mockReturnValue(true);

    const mockError = new Error('Downstream service error');
    (handleApiService as jest.Mock).mockRejectedValue(mockError);

    await retrieveBeneficiariesController(
      req as Request,
      res as Response,
      next
    );

    expect(handleApiService).toHaveBeenCalled();
    expect(handleControllerError).toHaveBeenCalled();
  });
});
