const postArrangementDetailsController = require('./postArrangementDetailsController');
import { Request, Response, NextFunction } from 'express';
import httpMocks from 'node-mocks-http';
import {
  handleApiService,
  handleControllerError,
  normaliseData,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { transformDownstreamResponseToUi } from '../helpers/postArrangementDetailsController.helper';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils');
jest.mock('../helpers/postArrangementDetailsController.helper');

describe('postArrangementDetailsController', () => {
  let req: Request;
  let res: Response;
  let next: NextFunction;
  let logger: any;

  beforeEach(() => {
    req = httpMocks.createRequest({
      method: 'POST',
      body: { accountIds: ['123'] },
    }) as unknown as Request;
    res = httpMocks.createResponse() as unknown as Response;
    logger = { error: jest.fn(), info: jest.fn() };
    (res as any).locals = { logger };
    (res as any).status = jest.fn().mockReturnThis();
    (res as any).json = jest.fn().mockReturnThis();
    (res as any).end = jest.fn();
    next = jest.fn();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should respond with normalised data on success', async () => {
    // Arrange
    const mockDownstreamResponse = { data: [{ foo: 'bar' }] };
    const mockTransformed = [
      {
        id: 'arr1',
        aliasName: 'A',
        productName: 'P',
        tenXAccountStatus: 'ACTIVE',
        arrangementOwners: [],
      },
    ];
    const mockNormalised = {
      entities: {
        arrangementDetails: [
          {
            id: 'arr1',
            aliasName: 'A',
            productName: 'P',
            tenXAccountStatus: 'ACTIVE',
            arrangementOwners: [],
          },
        ],
      },
    };

    (handleApiService as jest.Mock).mockResolvedValue(mockDownstreamResponse);
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      mockTransformed
    );
    (normaliseData as jest.Mock).mockReturnValue(mockNormalised);

    // Act
    await postArrangementDetailsController(req, res, next);

    // Assert
    expect(handleApiService).toHaveBeenCalled();
    expect(transformDownstreamResponseToUi).toHaveBeenCalledWith(
      [mockDownstreamResponse.data],
      expect.any(Number),
      expect.any(Object)
    );
    expect(normaliseData).toHaveBeenCalledWith(
      'arrangementDetails',
      mockTransformed,
      expect.any(Function)
    );
    expect(res.status).toHaveBeenCalledWith(expect.any(Number));
    expect(res.json).toHaveBeenCalledWith(mockNormalised);
    expect(res.end).toHaveBeenCalled();
    expect(next).not.toHaveBeenCalledWith(expect.any(Error));
  });

  it('should handle errors and call next with error', async () => {
    // Arrange
    const error = new Error('fail');
    (handleApiService as jest.Mock).mockRejectedValue(error);
    (handleControllerError as jest.Mock).mockImplementation(() => {});

    // Act
    await postArrangementDetailsController(req, res, next);

    // Assert
    expect(handleControllerError).toHaveBeenCalledWith(
      expect.objectContaining({ error, res, logger })
    );
    expect(next).toHaveBeenCalledWith(error);
    expect(res.status).not.toHaveBeenCalled();
    expect(res.json).not.toHaveBeenCalled();
    expect(res.end).not.toHaveBeenCalled();
  });
});
