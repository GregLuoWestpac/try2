const getGeneratePaymentIdentifier = require('./getGeneratePaymentIdentifierController');
import {
  handleApiService,
  normaliseData,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { transformDownstreamResponseToUi } from '../helpers/getGeneratePaymentIdentifierController.helper';
import { CONSTANTS } from '../../utils/constants';
import { IdentifierGenerator } from '../../generated/api-clients/customerPaymentInstructionIdV1Services';
import { setParamsForGetDownStreamApi } from '../../utils/setParams';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-apiutils'),
  handleApiService: jest.fn(),
  normaliseData: jest.fn(),
}));

jest.mock('../helpers/getGeneratePaymentIdentifierController.helper', () => ({
  transformDownstreamResponseToUi: jest.fn(),
}));

jest.mock('../../utils/constants', () => ({
  CONSTANTS: { httpStatus: { CREATED: 201, INTERNAL_SERVER_ERROR: 500 } },
}));

describe('getGeneratePaymentIdentifier', () => {
  let req: any;
  let res: any;
  let next: jest.Mock;

  beforeEach(() => {
    req = { body: { channelId: 'WP' } };
    res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      setHeader: jest.fn(),
      end: jest.fn(),
      locals: {
        logger: {
          error: jest.fn(),
          info: jest.fn(),
        },
      },
    };
    next = jest.fn();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should return 201 with the correct response structure for a valid request', async () => {
    (handleApiService as jest.Mock).mockResolvedValue({
      data: {
        paymentId: 'WS4120429206235',
        creationDateTime: '2024-04-29T03:00:18.258Z',
      },
    });

    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue([
      {
        id: 'mocked-uuid',
        paymentId: 'WS4120429206235',
        creationDateTime: '2024-04-29T03:00:18.258Z',
      },
    ]);

    (normaliseData as jest.Mock).mockReturnValue({
      entities: {
        paymentIdentifier: [
          {
            id: 'mocked-uuid',
            paymentId: 'WS4120429206235',
            creationDateTime: '2024-04-29T03:00:18.258Z',
          },
        ],
      },
      result: {
        paymentIdentifier: ['mocked-uuid'],
      },
    });

    await getGeneratePaymentIdentifier(req, res, next);

    expect(handleApiService).toHaveBeenCalledWith({
      req,
      res,
      apiClient: IdentifierGenerator,
      setDownstreamParams: setParamsForGetDownStreamApi,
    });

    expect(transformDownstreamResponseToUi).toHaveBeenCalledWith({
      paymentId: 'WS4120429206235',
      creationDateTime: '2024-04-29T03:00:18.258Z',
    });

    expect(normaliseData).toHaveBeenCalledWith(
      'paymentIdentifier',
      [
        {
          id: 'mocked-uuid',
          paymentId: 'WS4120429206235',
          creationDateTime: '2024-04-29T03:00:18.258Z',
        },
      ],
      expect.any(Function)
    );

    expect(res.status).toHaveBeenCalledWith(CONSTANTS.httpStatus.CREATED);
    expect(res.json).toHaveBeenCalledWith({
      entities: {
        paymentIdentifier: [
          {
            id: 'mocked-uuid',
            paymentId: 'WS4120429206235',
            creationDateTime: '2024-04-29T03:00:18.258Z',
          },
        ],
      },
      result: {
        paymentIdentifier: ['mocked-uuid'],
      },
    });
    expect(res.end).toHaveBeenCalled();
  });
});
