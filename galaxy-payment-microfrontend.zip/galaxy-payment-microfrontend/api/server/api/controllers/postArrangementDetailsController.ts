import { normalise } from '@mep-node/framework-response-normaliser-addon';
import {
  handleApiService,
  handleControllerError,
  normaliseData,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import {
  Arrangement,
  RetrieveArrangementDetailResponse,
} from 'api/interfaces/models/downstream/capProdsvcadmProddealacctadmInstlArrngmntsvcngV1';
import { NextFunction, Request, Response } from 'express';
import get from 'lodash/get';
import { ApiResponse } from '../../../interfaces/types/common';
import { capProdsvcadmProddealacctadmInstlArrngmntsvcngV1Services } from '../../generated/api-clients';
import { CONSTANTS } from '../../utils/constants';
import {
  ExpApiResponseData,
  transformDownstreamResponseToUi,
} from '../helpers/postArrangementDetailsController.helper';

const postArrangementDetailsController = async (
  req: Request,
  res: Response<ApiResponse<Arrangement>>,
  next: NextFunction
) => {
  const { logger } = res.locals;
  const {
    httpStatus: { OK },
  } = CONSTANTS;

  const { postArrangementDetails } =
    capProdsvcadmProddealacctadmInstlArrngmntsvcngV1Services;

  try {
    // Ensure accountIds is an array
    const accountIds: any[] = req?.body?.accountIds || [];

    // For each accountId, call the downstream service once and collect all promises
    const allPromises = accountIds.map(accountId =>
      handleApiService({
        req,
        res,
        apiClient: postArrangementDetails,
        requestBody: { accountId },
      })
    );
    // Await all downstream calls
    const allResponses = await Promise.all(allPromises);
    // For each response, extract data, transform, and normalise
    const list: any = [];
    allResponses.forEach(downstreamResponse => {
      const paymentLimits = get(
        downstreamResponse,
        'data',
        {}
      ) as RetrieveArrangementDetailResponse;

      list.push(paymentLimits);
    });
    const expApiResponseData: ExpApiResponseData =
      transformDownstreamResponseToUi(list, res.statusCode, req);
    const normalisedDataArray = normaliseData<Arrangement>(
      'arrangementDetails',
      expApiResponseData as any,
      normalise
    );

    res.status(OK).json(normalisedDataArray).end();
  } catch (error) {
    handleControllerError({ error, res, logger });
    next(error);
  }
};

module.exports = postArrangementDetailsController;
