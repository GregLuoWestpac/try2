import { AccountArrangementsResponse } from '../../../interfaces/models/downstream/capProdsvcadmProddealacctadmInstlArrngmntsvcngV1Services';

export const capProdsvcadmProddealacctadmInstlArrngmntsvcngV1ServicesPartialSuccessMocked: AccountArrangementsResponse =
  {
    data: {
      arrangements: [
        {
          accountId: {
            BSB: '035845',
            accountNumber: '104072331',
          },
          aliasName: 'Payroll A/C',
          productName:
            'Banded Rate - Weekly - One Band with Zero Percent Interest',
          status: 'ACTIVE',
          currencyCode: 'AUD',
          currentBalance: {
            amount: '15155.38',
            currencyCode: 'AUD',
            position: 'CR',
          },
          availableBalance: {
            amount: '15155.38',
            currencyCode: 'AUD',
            position: 'CR',
          },
          overdraftLimit: '0.000',
          arrangementOwners: [
            {
              customerIds: [
                {
                  customerId: 'string',
                  customerIdScheme: 'CustomerInternalId',
                },
              ],
              legalEntityType: {
                code: 'string',
                description: 'string',
              },
              organisation: {
                fullName: 'string',
                ABN: 'STRING',
                ACN: 'STRING',
                ARBN: 'STRING',
              },
            },
          ],
        },
        {
          accountId: {
            BSB: '035845',
            accountNumber: '639583115',
          },
          aliasName: 'Supplier',
          productName:
            'Tiered Rate - Weekly - One Tier with Zero Percent Interest',
          status: 'ACTIVE',
          currencyCode: 'AUD',
          currentBalance: {
            amount: '54060.0',
            currencyCode: 'AUD',
            position: 'CR',
          },
          availableBalance: {
            amount: '54060.0',
            currencyCode: 'AUD',
            position: 'CR',
          },
          overdraftLimit: '0.000',
          arrangementOwners: [
            {
              customerIds: [
                {
                  customerId: 'string',
                  customerIdScheme: 'CustomerInternalId',
                },
              ],
              legalEntityType: {
                code: 'string',
                description: 'string',
              },
              organisation: {
                fullName: 'string',
                ABN: 'STRING',
                ACN: 'STRING',
                ARBN: 'STRING',
              },
            },
          ],
        },
        {
          accountId: {
            BSB: '035845',
            accountNumber: '586750585',
          },
          aliasName: 'Finance',
          productName: 'Flat Rate - Weekly - Zero Percent Margin',
          status: 'ACTIVE',
          currencyCode: 'AUD',
          currentBalance: {
            amount: '13122.37',
            currencyCode: 'AUD',
            position: 'CR',
          },
          availableBalance: {
            amount: '13122.37',
            currencyCode: 'AUD',
            position: 'CR',
          },
          overdraftLimit: '0.000',
          arrangementOwners: [
            {
              customerIds: [
                {
                  customerId: 'string',
                  customerIdScheme: 'CustomerInternalId',
                },
              ],
              legalEntityType: {
                code: 'string',
                description: 'string',
              },
              organisation: {
                fullName: 'string',
                ABN: 'STRING',
                ACN: 'STRING',
                ARBN: 'STRING',
              },
            },
          ],
        },
        {
          accountId: {
            BSB: '035845',
            accountNumber: '231283156',
          },
          aliasName:
            'Tiered Rate - Weekly - One Tier with Zero Percent Interest',
          productName:
            'Tiered Rate - Weekly - One Tier with Zero Percent Interest',
          status: 'ACTIVE',
          currencyCode: 'AUD',
          currentBalance: {
            amount: '0.0',
            currencyCode: 'AUD',
            position: 'CR',
          },
          availableBalance: {
            amount: '0.0',
            currencyCode: 'AUD',
            position: 'CR',
          },
          overdraftLimit: '0.000',
          arrangementOwners: [
            {
              customerIds: [
                {
                  customerId: 'string',
                  customerIdScheme: 'CustomerInternalId',
                },
              ],
              legalEntityType: {
                code: 'string',
                description: 'string',
              },
              organisation: {
                fullName: 'string',
                ABN: 'STRING',
                ACN: 'STRING',
                ARBN: 'STRING',
              },
            },
          ],
        },
      ],
    },
    result: {
      errors: [
        {
          code: 0,
          message: 'string',
          details: 'string',
          correlationKey: {
            accountId: {
              BSB: '035845',
              accountNumber:
                '123456789 --[SHOULD BE MASKED PARTIALLY] --> ******6789',
            },
          },
        },
      ],
    },
  };

export const capProdsvcadmProddealacctadmInstlArrngmntsvcngV1ServicesSuccessMocked: AccountArrangementsResponse =
  {
    data: {
      arrangements: [
        {
          accountId: {
            BSB: '035845',
            accountNumber: '104072331',
          },
          aliasName: 'Payroll A/C',
          productName:
            'Banded Rate - Weekly - One Band with Zero Percent Interest',
          status: 'ACTIVE',
          currencyCode: 'AUD',
          currentBalance: {
            amount: '15155.38',
            currencyCode: 'AUD',
            position: 'CR',
          },
          availableBalance: {
            amount: '15155.38',
            currencyCode: 'AUD',
            position: 'CR',
          },
          overdraftLimit: '0.000',
          arrangementOwners: [
            {
              customerIds: [
                {
                  customerId: 'string',
                  customerIdScheme: 'CustomerInternalId',
                },
              ],
              legalEntityType: {
                code: 'string',
                description: 'string',
              },
              organisation: {
                fullName: 'string',
                ABN: 'STRING',
                ACN: 'STRING',
                ARBN: 'STRING',
              },
            },
          ],
        },
        {
          accountId: {
            BSB: '035845',
            accountNumber: '639583115',
          },
          aliasName: 'Supplier',
          productName:
            'Tiered Rate - Weekly - One Tier with Zero Percent Interest',
          status: 'ACTIVE',
          currencyCode: 'AUD',
          currentBalance: {
            amount: '54060.0',
            currencyCode: 'AUD',
            position: 'CR',
          },
          availableBalance: {
            amount: '54060.0',
            currencyCode: 'AUD',
            position: 'CR',
          },
          overdraftLimit: '0.000',
          arrangementOwners: [
            {
              customerIds: [
                {
                  customerId: 'string',
                  customerIdScheme: 'CustomerInternalId',
                },
              ],
              legalEntityType: {
                code: 'string',
                description: 'string',
              },
              organisation: {
                fullName: 'string',
                ABN: 'STRING',
                ACN: 'STRING',
                ARBN: 'STRING',
              },
            },
          ],
        },
        {
          accountId: {
            BSB: '035845',
            accountNumber: '586750585',
          },
          aliasName: 'Finance',
          productName: 'Flat Rate - Weekly - Zero Percent Margin',
          status: 'ACTIVE',
          currencyCode: 'AUD',
          currentBalance: {
            amount: '13122.37',
            currencyCode: 'AUD',
            position: 'CR',
          },
          availableBalance: {
            amount: '13122.37',
            currencyCode: 'AUD',
            position: 'CR',
          },
          overdraftLimit: '0.000',
          arrangementOwners: [
            {
              customerIds: [
                {
                  customerId: 'string',
                  customerIdScheme: 'CustomerInternalId',
                },
              ],
              legalEntityType: {
                code: 'string',
                description: 'string',
              },
              organisation: {
                fullName: 'string',
                ABN: 'STRING',
                ACN: 'STRING',
                ARBN: 'STRING',
              },
            },
          ],
        },
        {
          accountId: {
            BSB: '035845',
            accountNumber: '231283156',
          },
          aliasName:
            'Tiered Rate - Weekly - One Tier with Zero Percent Interest',
          productName:
            'Tiered Rate - Weekly - One Tier with Zero Percent Interest',
          status: 'ACTIVE',
          currencyCode: 'AUD',
          currentBalance: {
            amount: '0.0',
            currencyCode: 'AUD',
            position: 'CR',
          },
          availableBalance: {
            amount: '0.0',
            currencyCode: 'AUD',
            position: 'CR',
          },
          overdraftLimit: '0.000',
          arrangementOwners: [
            {
              customerIds: [
                {
                  customerId: 'string',
                  customerIdScheme: 'CustomerInternalId',
                },
              ],
              legalEntityType: {
                code: 'string',
                description: 'string',
              },
              organisation: {
                fullName: 'string',
                ABN: 'STRING',
                ACN: 'STRING',
                ARBN: 'STRING',
              },
            },
          ],
        },
      ],
    },
  };
