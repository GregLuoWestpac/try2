import { NextFunction, Request, Response } from 'express';
import { normalise } from '@mep-node/framework-response-normaliser-addon';

import {
  handleApiService,
  handleControllerError,
  normaliseData,
  accessControlExposeHeaders,
  APIClient,
  DownstreamServiceResponse,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { v4 as uuid } from 'uuid';
import {
  PostPaymentsRequest,
  PostPaymentsResponse,
} from '../../../interfaces/models/Payments';
import { ApiResponse } from '../../../interfaces/types/common';
import { capProdsvcfulflmntPymntprocsngPymntinitV2Services } from '../../generated/api-clients';
import { paymentAliasResolutionV2Services } from '../../generated/api-clients';
import { CONSTANTS } from '../../utils/constants';
import { getDeviceIdFromRequest } from '../../utils/commonHelper';
import { setParamsForPostPayments } from '../../utils/setParams';
import {
  transformPaymentsResponseFromCAPToUI,
  generatePaymentsRequestDataForCAP,
  detectInjectionVulnerability,
} from '../helpers/paymentCreateController.helper';

const paymentCreateController = async (
  req: Request<never, Record<string, unknown>, PostPaymentsRequest>,
  res: Response<ApiResponse<PostPaymentsResponse> | string>,
  next: NextFunction,
  entityName: string = 'paymentCreate'
) => {
  const { logger, apiHeaders } = res.locals;
  const {
    httpStatus: { BAD_REQUEST },
  } = CONSTANTS;

  const { paymentSubmission } =
    capProdsvcfulflmntPymntprocsngPymntinitV2Services;

  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);

  try {
    // Validate for injection vulnerabilities
    const injectionVulnerabilityResult = detectInjectionVulnerability(req.body);
    if (injectionVulnerabilityResult.vulnerabilityDetected) {
      return res
        .status(BAD_REQUEST)
        .json(injectionVulnerabilityResult.message)
        .end();
    }

    // Extract required data from request
    const userId = apiHeaders['x-userId'];
    const deviceId = getDeviceIdFromRequest(req);
    const messageIdentification = uuid().replace(/-/g, '');
    const channelRequestId = req.get('x-channelRequestId');
    const orgId = req.get('protected-orgId');

    // Check if this is a PayID payment and resolve if needed
    let resolvedPayIDAccount:
      | { bsb: string; accountNumber: string }
      | undefined;
    const creditInfo = req.body?.creditTransferTransactionInformation;
    const credit = Array.isArray(creditInfo) ? creditInfo[0] : creditInfo;

    if (
      credit?.supplementaryData?.aliasType &&
      credit?.supplementaryData?.aliasId
    ) {
      const { postResolutionView } = paymentAliasResolutionV2Services;
      const aliasLookupRequest = {
        aliasId: credit.supplementaryData.aliasId,
        aliasType: credit.supplementaryData.aliasType,
        authBIC8: 'WPACAU3S', // Hardcoded value just like aliaslookup request body
      };

      const aliasLookupResponse: DownstreamServiceResponse =
        await handleApiService({
          req,
          res,
          apiClient: postResolutionView as APIClient,
          requestBody: aliasLookupRequest,
        });

      if (aliasLookupResponse?.data?.data) {
        const resolvedData = aliasLookupResponse.data.data as {
          issuer: string;
          accountId: string;
        };
        resolvedPayIDAccount = {
          bsb: resolvedData.issuer,
          accountNumber: resolvedData.accountId,
        };
      }
    }

    // Transform UI request to CAP format
    const transformedRequestBody = generatePaymentsRequestDataForCAP(
      req.body,
      userId,
      messageIdentification,
      deviceId,
      channelRequestId,
      orgId,
      resolvedPayIDAccount
    );
    // Call downstream service using handleApiService
    const postPaymentsResponse: DownstreamServiceResponse =
      await handleApiService({
        req,
        res,
        apiClient: paymentSubmission as APIClient,
        setDownstreamParams: (apiHeaders, res, requestBody, appConfig) =>
          setParamsForPostPayments(
            apiHeaders,
            res,
            transformedRequestBody as unknown as Record<string, unknown>,
            appConfig
          ),
      });

    // Transform response from CAP to UI format
    const transformedResponse = transformPaymentsResponseFromCAPToUI(
      postPaymentsResponse.data,
      logger,
      postPaymentsResponse.status,
      (postPaymentsResponse as any)?.paymentId,
      messageIdentification
    );

    // Normalize the response
    const normalisedData = normaliseData(
      entityName,
      transformedResponse,
      normalise
    ) as ApiResponse<PostPaymentsResponse>;

    res.status(postPaymentsResponse.status).json(normalisedData).end();
  } catch (error) {
    handleControllerError({
      error,
      res,
      logger,
    });
    next(error);
  }
};

export default paymentCreateController;
