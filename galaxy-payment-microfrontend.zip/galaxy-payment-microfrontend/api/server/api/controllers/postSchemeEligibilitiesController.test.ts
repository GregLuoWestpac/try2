import { NextFunction } from 'express';
import { createRequest, createResponse } from 'node-mocks-http';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-apiutils'),
  handleControllerError: jest.fn(),
  handleApiService: jest.fn(),
}));

// Mock the API clients at the top level
jest.mock('../../generated/api-clients/index.js', () => ({
  paymentSchemeEligibilityV1Services: {
    postPaymentSchemeEligibility: jest.fn(),
  },
}));

const getDefaultRes = () => {
  const logger = {
    info: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
  };

  const res = createResponse({
    locals: {
      logger,
    },
  });

  res.app = {
    // @ts-ignore
    locals: {
      // @ts-ignore
      Config: {
        get: jest.fn().mockReturnValue({
          requestConfig: {},
          responseConfig: {},
        }),
      },
    },
  };

  return res;
};

describe('postSchemeEligibilitiesController', () => {
  let next: jest.Mock<NextFunction>;
  let mockHandleApiService: jest.Mock;

  beforeEach(() => {
    jest.resetModules();
    next = jest.fn();
    const { handleApiService } = require('@mesh-tenant-multiverse-ui-common/mv-apiutils');
    mockHandleApiService = handleApiService as jest.Mock;
  });

  it('should return 200 on success', async () => {
    const req = createRequest({
      body: {
        debtorAccount: { issuer: '111111', schemeName: 'BBAN' },
        creditorAccount: { issuer: '222222', schemeName: 'BBAN' },
      },
    });
    const res = getDefaultRes();

    // Mock the handleApiService to return successful response
    mockHandleApiService.mockResolvedValue({
      data: {
        data: {
          eligibleServices: [
            {
              name: 'npp.clear.01-sct.01',
              status: 'Fast Payment',
            },
          ],
          paymentMethod: 'ON_US',
        },
      },
      status: 200,
      statusText: 'HTTP OK',
      empty: false,
      ok: true,
    });

    const postSchemeEligibilitiesController = require('./postSchemeEligibilitiesController');

    await postSchemeEligibilitiesController(req, res, next);
    expect(res.statusCode).toBe(200);
  });

  it('should handle errors', async () => {
    const req = createRequest({
      body: {
        debtorAccount: {
          issuer: '111111',
          schemeName: 'BBAN',
        },
        creditorAccount: {
          issuer: '222222',
          schemeName: 'BBAN',
        },
      },
    });
    const res = getDefaultRes();

    // Mock the handleApiService to throw an error
    mockHandleApiService.mockRejectedValue({
      error: {
        data: {
          message: 'Test error',
        },
      },
    });

    const postSchemeEligibilitiesController = require('./postSchemeEligibilitiesController');
    
    await postSchemeEligibilitiesController(req, res, next);
    expect(res.statusCode).toBe(500);
  });

  it('should return 400 if both issuer and payAlias are provided', async () => {
    const req = createRequest({
      body: {
        debtorAccount: { issuer: '111111', schemeName: 'BBAN' },
        creditorAccount: {
          issuer: '222222',
          schemeName: 'BBAN',
          payAlias: {
            id: 'tay.tay@westpac.com.au',
            type: 'EMAL',
            authBIC8: 'WPACAU3S',
          },
        },
      },
    });
    const res = getDefaultRes();
    const postSchemeEligibilitiesController = require('./postSchemeEligibilitiesController');

    await postSchemeEligibilitiesController(req, res, next);
    expect(res.statusCode).toBe(400);
  });
});
