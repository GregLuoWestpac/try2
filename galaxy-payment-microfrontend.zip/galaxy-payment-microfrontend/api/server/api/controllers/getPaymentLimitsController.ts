import { RUNTIME } from '@mep-node/framework-constants';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import {
  decodeAndValidateToken,
  DecodedTokenResult,
  handleApiService,
  handleControllerError,
  normaliseDataWithPaging,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import {
  LimitRule,
  SearchLimitRuleResponse,
} from 'api/interfaces/models/downstream/paymentLimitsServiceV1';
import { NextFunction, Request, Response } from 'express';
import get from 'lodash/get';
import { ApiResponse } from '../../../interfaces/types/common';
import { paymentLimitsServiceV1Services } from '../../generated/api-clients';
import { CONSTANTS } from '../../utils/constants';
import { setParamsForGetPaymentLimit } from '../../utils/setParams';
import { transformDownstreamResponseToUi } from '../helpers/getPaymentLimitsController.helper';

const getPaymentLimitsController = async (
  req: Request,
  res: Response<ApiResponse<LimitRule>>,
  next: NextFunction
) => {
  const { logger, apiHeaders } = res.locals;
  const {
    httpStatus: { OK },
  } = CONSTANTS;

  try {
    const { getLimitRules } = paymentLimitsServiceV1Services;

    let decodedToken: DecodedTokenResult = { userId: '' };
    if (!RUNTIME.isLocal()) {
      decodedToken = decodeAndValidateToken({
        apiHeaders,
        logger,
        options: {
          requiredFields: ['userId'],
          fieldMappings: { userId: 'userId' },
        },
      });
    }
    const userCISKey = decodedToken.userId;
    const organisationCISKey = req.get('protected-orgId');
    const channelId = req.get('x-originatingSystemId');
    const requestBody = {
      userCISKey,
      organisationCISKey,
      channelId,
    };

    const paymentLimitsResponse = await handleApiService({
      req,
      res,
      apiClient: getLimitRules,
      setDownstreamParams: setParamsForGetPaymentLimit,
      requestBody,
      reqMethod: 'POST',
    });

    const paymentLimitsFromDownstreamResponse = get(
      paymentLimitsResponse,
      'data',
      {}
    ) as SearchLimitRuleResponse;

    const expApiResponseData = transformDownstreamResponseToUi(
      paymentLimitsFromDownstreamResponse
    );

    const normalisedData = normaliseDataWithPaging(
      'paymentLimits',
      expApiResponseData,
      normalise
    ) as ApiResponse<LimitRule>;

    res.status(OK).json(normalisedData).end();
  } catch (error) {
    handleControllerError({ error, res, logger });
    next(error);
  }
};

module.exports = getPaymentLimitsController;
