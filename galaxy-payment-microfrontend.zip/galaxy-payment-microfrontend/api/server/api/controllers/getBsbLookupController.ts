import { RUNTIME } from '@mep-node/framework-constants';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import { buildGetBsbLookupController } from '@mesh-tenant-multiverse-ui-common/mv-apiBsbLookup';
import { infBnkngChnlBrchntwkV2Services } from '../../generated/api-clients';
import { ControllerParams } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

const controllerParams: ControllerParams = {
  RUNTIME,
  normalise,
  apiClient: infBnkngChnlBrchntwkV2Services,
};

const getBsbLookupController =
  buildGetBsbLookupController(controllerParams);

module.exports = getBsbLookupController;