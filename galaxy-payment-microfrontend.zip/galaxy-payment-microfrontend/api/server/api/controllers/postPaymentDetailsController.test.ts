import { Request, Response, NextFunction } from 'express';
import { postPaymentDetailsFromDownstream } from '../services/postPaymentDetailsService';
import { normaliseData } from '../schema/postPaymentDetails.schema';
import { transformDownstreamResponseToUi } from '../helpers/postPaymentDetails.helper';

const postPaymentDetailsController = require('./postPaymentDetailsController');

jest.mock('../services/postPaymentDetailsService', () => ({
  postPaymentDetailsFromDownstream: jest.fn(),
}));

jest.mock('../../utils/constants', () => ({
  CONSTANTS: {
    httpStatus: { OK: 200 },
  },
}));

jest.mock('../schema/postPaymentDetails.schema', () => ({
  normaliseData: jest.fn(),
}));

jest.mock('../helpers/postPaymentDetails.helper', () => ({
  transformDownstreamResponseToUi: jest.fn(),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({ ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-apiutils'), handleControllerError: jest.fn(), }));

describe('postPaymentDetailsController', () => {
  let req: Partial<Request>;
  let res: Partial<Response>;
  let next: NextFunction;

  beforeEach(() => {
    req = {};
    res = {
      locals: {
        //@ts-ignore
        logger: {
          debug: jest.fn(),
        },
      },
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      send: jest.fn().mockReturnThis(),
      setHeader: jest.fn(),
      end: jest.fn(),
    };
    next = jest.fn();
  });

  it('should handle successful response', async () => {
    const mockResponse = { data: 'mockData' };
    const transformedResponse = { transformed: 'data' };
    const normalisedResponse = { normalised: 'data' };

    (postPaymentDetailsFromDownstream as jest.Mock).mockResolvedValue(
      mockResponse
    );
    (transformDownstreamResponseToUi as jest.Mock).mockReturnValue(
      transformedResponse
    );
    (normaliseData as jest.Mock).mockReturnValue(normalisedResponse);

    await postPaymentDetailsController(req as Request, res as Response, next);

    expect(postPaymentDetailsFromDownstream).toHaveBeenCalledWith(req, res);
    expect(transformDownstreamResponseToUi).toHaveBeenCalledWith(mockResponse);
    expect(normaliseData).toHaveBeenCalledWith(transformedResponse);
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(normalisedResponse);
    expect(res.end).toHaveBeenCalled();
  });

  // it('should handle errors', async () => {
  //   //const error = new Error('Test error');
  //  // (postPaymentDetailsFromDownstream as jest.Mock).mockRejectedValue(error);

  //   await postPaymentDetailsController(req as Request, res as Response, next);

  //  // expect(next).toHaveBeenCalledWith(error);
  //  expect(handleControllerError).toHaveBeenCalled();

  // });
});
