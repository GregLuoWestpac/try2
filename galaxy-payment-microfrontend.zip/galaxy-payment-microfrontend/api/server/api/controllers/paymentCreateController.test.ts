import { NextFunction, Request, Response } from 'express';
import {
  PostPaymentsRequest,
  PostPaymentsResponse,
} from '../../../interfaces/models/Payments';
import { ApiResponse } from '../../../interfaces/types/common';

// Mock the dependencies
jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-apiutils'),
  handleApiService: jest.fn(),
  handleControllerError: jest.fn(),
  normaliseData: jest.fn(),
  accessControlExposeHeaders:
    'x-total-count,x-page-count,x-page-number,x-page-size',
}));

jest.mock('../helpers/paymentCreateController.helper', () => ({
  transformPaymentsResponseFromCAPToUI: jest.fn(),
  generatePaymentsRequestDataForCAP: jest.fn(),
  detectInjectionVulnerability: jest.fn(),
}));

jest.mock('../../utils/commonHelper', () => ({
  getDeviceIdFromRequest: jest.fn(),
}));

jest.mock('uuid', () => ({
  v4: jest.fn(),
}));

describe('paymentCreateController', () => {
  let mockReq: Request<never, Record<string, unknown>, PostPaymentsRequest>;
  let mockRes: Response<ApiResponse<PostPaymentsResponse> | string>;
  let mockNext: NextFunction;
  let paymentCreateController: any;

  beforeEach(() => {
    jest.clearAllMocks();

    // Import the controller after mocking
    paymentCreateController = require('./paymentCreateController').default;

    // Create mock request, response, and next function
    mockReq = {
      body: {
        clientContext: { channelType: 'ONLINE' },
        creditTransferTransactionInformation: [
          {
            creditor: { name: 'Test Creditor' },
            instructedAmount: { amount: '100.00', currency: 'AUD' },
          },
        ],
        debtor: { name: 'Test Debtor' },
        debtorAccount: { identification: '123456789' },
        supplementaryData: { debitDescription: 'Test payment' },
      },
      get: jest.fn().mockReturnValue('test-channel-id'),
    } as any;

    mockRes = {
      locals: {
        logger: {
          info: jest.fn(),
          error: jest.fn(),
          trace: jest.fn(),
          debug: jest.fn(),
          warn: jest.fn(),
        },
        apiHeaders: {
          'x-userId': 'testuser',
        },
      },
      setHeader: jest.fn(),
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      end: jest.fn().mockReturnThis(),
    } as any;

    mockNext = jest.fn() as NextFunction;
  });

  it('should handle successful payment processing', async () => {
    // Arrange
    const {
      handleApiService,
      normaliseData,
    } = require('@mesh-tenant-multiverse-ui-common/mv-apiutils');
    const {
      detectInjectionVulnerability,
      generatePaymentsRequestDataForCAP,
      transformPaymentsResponseFromCAPToUI,
    } = require('../helpers/paymentCreateController.helper');
    const { getDeviceIdFromRequest } = require('../../utils/commonHelper');
    const { v4: uuid } = require('uuid');

    // Mock no vulnerabilities detected
    detectInjectionVulnerability.mockReturnValue({
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    });

    // Mock helper functions
    getDeviceIdFromRequest.mockReturnValue('test-device-id');
    uuid.mockReturnValue('test-message-id');
    generatePaymentsRequestDataForCAP.mockReturnValue({
      messageIdentification: 'test-message-id',
    });

    // Mock successful API response
    const mockApiResponse = {
      data: { paymentStatusReport: { messageIdentification: 'test-id' } },
      status: 201,
    };
    handleApiService.mockResolvedValue(mockApiResponse);

    // Mock transformation functions
    transformPaymentsResponseFromCAPToUI.mockReturnValue([
      { id: 'test-payment' },
    ]);
    normaliseData.mockReturnValue({
      data: { paymentCreate: [{ id: 'test-payment' }] },
    });

    // Act
    await paymentCreateController(mockReq, mockRes, mockNext);

    // Assert
    expect(mockRes.setHeader).toHaveBeenCalled();
    expect(handleApiService).toHaveBeenCalled();
    expect(mockRes.status).toHaveBeenCalledWith(201);
    expect(mockRes.json).toHaveBeenCalled();
    expect(mockRes.end).toHaveBeenCalled();
  });

  it('should return 400 when injection vulnerability is detected', async () => {
    // Arrange
    const {
      detectInjectionVulnerability,
    } = require('../helpers/paymentCreateController.helper');

    detectInjectionVulnerability.mockReturnValue({
      vulnerabilityDetected: true,
      message: 'Injection vulnerabilities detected.',
      vulnerableFields: ['test.field'],
    });

    // Act
    await paymentCreateController(mockReq, mockRes, mockNext);

    // Assert
    expect(mockRes.status).toHaveBeenCalledWith(400);
    expect(mockRes.json).toHaveBeenCalledWith(
      'Injection vulnerabilities detected.'
    );
    expect(mockRes.end).toHaveBeenCalled();
  });

  it('should handle API service errors', async () => {
    // Arrange
    const {
      handleApiService,
      handleControllerError,
    } = require('@mesh-tenant-multiverse-ui-common/mv-apiutils');
    const {
      detectInjectionVulnerability,
    } = require('../helpers/paymentCreateController.helper');

    // Mock no vulnerabilities
    detectInjectionVulnerability.mockReturnValue({
      vulnerabilityDetected: false,
      message: '',
      vulnerableFields: [],
    });

    // Mock API service error
    const testError = new Error('API service error');
    handleApiService.mockRejectedValue(testError);

    // Act
    await paymentCreateController(mockReq, mockRes, mockNext);

    // Assert
    expect(handleControllerError).toHaveBeenCalledWith({
      error: testError,
      res: mockRes,
      logger: mockRes.locals.logger,
    });
    expect(mockNext).toHaveBeenCalledWith(testError);
  });

  it('should maintain correct function signature and types', () => {
    // Assert that the controller is a function
    expect(typeof paymentCreateController).toBe('function');

    // Assert that it's an async function (returns a Promise)
    const result = paymentCreateController(mockReq, mockRes, mockNext);
    expect(result).toBeInstanceOf(Promise);
  });
});
