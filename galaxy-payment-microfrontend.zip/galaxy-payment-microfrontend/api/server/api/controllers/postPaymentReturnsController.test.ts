import { Request, Response, NextFunction } from 'express';
import { createRequest, createResponse } from 'node-mocks-http';
import { v4 as uuid } from 'uuid';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import { handleControllerError, accessControlExposeHeaders } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { postPaymentReturnServiceFromDownstream } from '../services/postPaymentReturnService';
import { transformPaymentReturnCapApiResponseToUI } from '../helpers/postPaymentReturnsController.helper';
import { postPaymentReturnsSchemaBuilder, SCHEMA_KEY } from '../schema/postPaymentReturn.schema';
import {
  PostPaymentReturnsRequest,
  PostPaymentReturnExpResponse,
} from '../../../interfaces/models/PaymentReturns';

const postPaymentReturnsController = require('./postPaymentReturnsController');

jest.mock('uuid', () => ({
  v4: jest.fn(),
}));

jest.mock('@mep-node/framework-response-normaliser-addon', () => ({
  normalise: jest.fn(),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-apiutils'),
  handleControllerError: jest.fn(),
  accessControlExposeHeaders: 'x-app-correlation-id,x-message-id',
}));

jest.mock('../services/postPaymentReturnService', () => ({
  postPaymentReturnServiceFromDownstream: jest.fn(),
}));

jest.mock('../helpers/postPaymentReturnsController.helper', () => ({
  transformPaymentReturnCapApiResponseToUI: jest.fn(),
}));

jest.mock('../schema/postPaymentReturn.schema', () => ({
  postPaymentReturnsSchemaBuilder: 'mockSchemaBuilder',
  SCHEMA_KEY: 'paymentreturns',
}));

jest.mock('../../utils/constants', () => ({
  CONSTANTS: {
    postPaymentReturnControllerTitle: 'postPaymentReturn Controller',
  },
}));

describe('postPaymentReturnsController', () => {
  let req: any;
  let res: any;
  let next: NextFunction;

  const mockLogger = {
    trace: jest.fn(),
    info: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
    debug: jest.fn(),
  };

  const mockUuid = '12345678-1234-1234-1234-123456789abc';
  const mockMessageIdentification = '12345678123412341234123456789abc';

  const getDefaultRes = () => {
    const res = createResponse({
      locals: {
        logger: mockLogger,
        apiHeaders: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'x-appCorrelationId': '1234Id',
          'x-brandId': 'WBC',
          'x-channelType': 'Branch',
          'x-messageId': '12345678uisajsi',
        },
      },
    });
    
    jest.spyOn(res, 'setHeader');
    
    return res;
  };

  const getDefaultReq = () => {
    return createRequest({
      body: {
        clientContext: {
          channelType: 'web',
        },
        originalMessageIdentification: 'original-msg-123',
        transactionInformation: {
          returnReason: {
            reasonCode: 'AC01',
            additionalInformation: 'Incorrect account number',
            returnType: 'RETURN',
          },
          debtor: {
            issuer: 'BSB',
            identification: '123456',
            name: 'John Doe',
          },
          debitDescription: 'Debit transaction',
          creditor: {
            issuer: 'BSB',
            identification: '654321',
            name: 'Jane Smith',
          },
          creditDescription: 'Credit transaction',
          paymentReference: 'REF123',
          toAnotherAccount: 'N',
          returnedInterbankSettlementAmount: {
            currency: 'AUD',
            amount: '100.00',
          },
          supplementaryData: {
            paymentDetailsIdType: 'PAYMENT_ID',
            ofiCaseId: 'OFI123',
            serviceLevel: 'SEPA',
            groupCaseId: 'GROUP123',
          },
        },
      } as PostPaymentReturnsRequest,
    });
  };

  beforeEach(() => {
    jest.clearAllMocks();

    req = getDefaultReq();
    res = getDefaultRes();
    next = jest.fn();

    (uuid as jest.Mock).mockReturnValue(mockUuid);
    (normalise as jest.Mock).mockReturnValue({ normalized: 'data' });
  });

  describe('successful execution', () => {
   it('should successfully process payment return request and return normalized response', async () => {
      const mockServiceResponse = {
        status: 201,
        responseData: { id: 'payment-456' },
        paymentId: 'payment-456',
      };

      const mockTransformedResponse: PostPaymentReturnExpResponse[] = [
        {
          id: 'payment-456',
          groupInformation: {
            originalCreationDateTime: '2023-12-09T11:00:00Z',
            groupStatus: 'PENDING',
          },
          paymentInformation: {
            paymentInformationStatus: 'PENDING',
          },
          transactionStatusInformation: {
            transactionStatus: 'PENDING',
          },
          supplementaryData: {
            id: 'payment-456',
          },
        },
      ];

      (postPaymentReturnServiceFromDownstream as jest.Mock).mockResolvedValue(mockServiceResponse);
      (transformPaymentReturnCapApiResponseToUI as jest.Mock).mockReturnValue(mockTransformedResponse);


      await postPaymentReturnsController(req, res, next);

      expect(res.statusCode).toBe(201);
      expect(transformPaymentReturnCapApiResponseToUI).toHaveBeenCalledWith(
        mockServiceResponse.responseData,
        mockLogger,
        201,
        mockServiceResponse.paymentId,
        mockMessageIdentification
      );
    });

    it('should generate unique message identification without hyphens', async () => {
      const uuidWithHyphens = '12345678-1234-5678-9abc-123456789def';
      const expectedMessageId = '12345678123456789abc123456789def';
      
      (uuid as jest.Mock).mockReturnValue(uuidWithHyphens);
      
      const mockServiceResponse = {
        status: 200,
        responseData: { id: 'payment-789' },
        paymentId: 'payment-789',
      };

      (postPaymentReturnServiceFromDownstream as jest.Mock).mockResolvedValue(mockServiceResponse);
      (transformPaymentReturnCapApiResponseToUI as jest.Mock).mockReturnValue([]);


      await postPaymentReturnsController(req, res, next);

      expect(postPaymentReturnServiceFromDownstream).toHaveBeenCalledWith(
        req,
        res,
        expectedMessageId
      );
    });
  });

  describe('error handling', () => {
    it('should handle service errors and call handleControllerError', async () => {
      const mockError = new Error('Service failed');
      (postPaymentReturnServiceFromDownstream as jest.Mock).mockRejectedValue(mockError);

      await postPaymentReturnsController(req, res, next);

      expect(handleControllerError).toHaveBeenCalledWith({
        error: mockError,
        res,
        logger: mockLogger,
      });
      expect(next).toHaveBeenCalledWith(mockError);
      expect(mockLogger.info).toHaveBeenCalledWith('postPaymentReturn Controller - Start');
      expect(mockLogger.info).not.toHaveBeenCalledWith('postPaymentReturn Controller - End');
    });

    it('should handle transformation errors', async () => {
      const mockServiceResponse = {
        status: 201,
        responseData: { id: 'payment-error' },
        paymentId: 'payment-error',
      };
      const transformError = new Error('Transform failed');

      (postPaymentReturnServiceFromDownstream as jest.Mock).mockResolvedValue(mockServiceResponse);
      (transformPaymentReturnCapApiResponseToUI as jest.Mock).mockImplementation(() => {
        throw transformError;
      });

      await postPaymentReturnsController(req, res, next);

      expect(handleControllerError).toHaveBeenCalledWith({
        error: transformError,
        res,
        logger: mockLogger,
      });
      expect(next).toHaveBeenCalledWith(transformError);
    });

    it('should handle normalization errors', async () => {
      const mockServiceResponse = {
        status: 201,
        responseData: { id: 'payment-norm-error' },
        paymentId: 'payment-norm-error',
      };
      const mockTransformedResponse: PostPaymentReturnExpResponse[] = [
        {
          id: 'payment-norm-error',
          groupInformation: {
            originalCreationDateTime: '2023-12-09T12:00:00Z',
            groupStatus: 'RJCT',
          },
          paymentInformation: {
            paymentInformationStatus: 'RJCT',
          },
          transactionStatusInformation: {
            transactionStatus: 'RJCT',
          },
          supplementaryData: {
            id: 'payment-norm-error',
          },
        },
      ];
      const normError = new Error('Normalization failed');

      (postPaymentReturnServiceFromDownstream as jest.Mock).mockResolvedValue(mockServiceResponse);
      (transformPaymentReturnCapApiResponseToUI as jest.Mock).mockReturnValue(mockTransformedResponse);
      (normalise as jest.Mock).mockImplementation(() => {
        throw normError;
      });

      await postPaymentReturnsController(req, res, next);

      expect(handleControllerError).toHaveBeenCalledWith({
        error: normError,
        res,
        logger: mockLogger,
      });
      expect(next).toHaveBeenCalledWith(normError);
    });
  });

  describe('edge cases', () => {
    it('should handle empty response data', async () => {
      const mockServiceResponse = {
        status: 201,
        responseData: null,
        paymentId: null,
      };

      (postPaymentReturnServiceFromDownstream as jest.Mock).mockResolvedValue(mockServiceResponse);
      (transformPaymentReturnCapApiResponseToUI as jest.Mock).mockReturnValue([]);

      await postPaymentReturnsController(req, res, next);

      expect(transformPaymentReturnCapApiResponseToUI).toHaveBeenCalledWith(
        null,
        mockLogger,
        201,
        null,
        mockMessageIdentification
      );
      expect(res.statusCode).toBe(201);
    });
  });
});
