/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable prefer-promise-reject-errors */
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import { handleControllerError } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { NextFunction } from 'express';
import { createRequest, createResponse } from 'node-mocks-http';
import {
  capProdsvcadmProddealacctadmInstlArrngmntsvcngV1ServicesPartialSuccessMocked,
  capProdsvcadmProddealacctadmInstlArrngmntsvcngV1ServicesSuccessMocked,
} from './getArrangementsController.mock';
jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-apiutils'),
  handleControllerError: jest.fn(),
}));
const getArrangementsController = require('./getArrangementsController');

//create a mock response header
const ctrlResponseMockHeader = {
  locals: {
    apiHeaders: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'x-appCorrelationId': '1234Id',
      'x-brandId': 'WBC',
      'x-channelType': 'Branch',
      'x-messageId': '12345678uisajsi',
    },
    normalise,
  },
};

//create a function that returns a default response object with the mock header passed in as an argument
const getDefaultRes = () => {
  const logger = {
    info: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
  };

  const res = createResponse({
    ...ctrlResponseMockHeader,
    locals: {
      ...ctrlResponseMockHeader.locals,
      logger, // Include your mock logger here
    },
  });

  res.app = {
    // @ts-ignore
    locals: {
      // @ts-ignore
      Config: {
        get: jest.fn().mockReturnValue({
          requestConfig: {},
          responseConfig: {},
        }),
      },
    },
  };

  return res;
};

// create test suite for getArrangementsController
describe('getArrangementsController', () => {
  //create a request, response object and a next function
  // let req: Partial<Request>;
  // let res: Partial<Response>;
  const next: jest.Mock<NextFunction> = jest.fn();

  // reset the modules before each test
  beforeEach(() => {
    // req = {};
    // res = {
    //   status: jest.fn().mockReturnThis(),
    //   json: jest.fn(),
    //   send: jest.fn(),
    //   locals: {
    //     //@ts-ignore
    //     logger: jest.fn(),
    //   }
    // };
    jest.resetModules();
  });

  // create a test case to return 400 incase of partial success
  xit('should return 400 incase of partial success ', async () => {
    // create a request object
    const req = createRequest();

    // create a response object
    const res = getDefaultRes();

    // mock the getArrangements function
    jest.doMock('../../generated/api-clients/index.js', () => ({
      capProdsvcadmProddealacctadmInstlArrngmntsvcngV1Services: {
        getArrangements: jest.fn(() => {
          return Promise.resolve({
            data: capProdsvcadmProddealacctadmInstlArrngmntsvcngV1ServicesPartialSuccessMocked,
            status: 400,
            statusText: 'HTTP OK',
            empty: false,
            ok: true,
          });
        }),
      },
    }));

    // import the getArrangementsController
    const getArrangementsController = require('./getArrangementsController');

    // call the getArrangementsController function
    await getArrangementsController(req, res, next);
    expect(res.statusCode).toBe(400);
  });

  // create a test case to return 200 incase of success
  it('should return 200 incase of success ', async () => {
    // create a request object
    const req = createRequest();

    // create a response object
    const res = getDefaultRes();

    // mock the getArrangements function
    jest.doMock('../../generated/api-clients/index.js', () => ({
      capProdsvcadmProddealacctadmInstlArrngmntsvcngV1Services: {
        getArrangements: jest.fn(() => {
          return Promise.resolve({
            data: capProdsvcadmProddealacctadmInstlArrngmntsvcngV1ServicesSuccessMocked,
            status: 200,
            statusText: 'HTTP OK',
            empty: false,
            ok: true,
          });
        }),
      },
    }));

    // import the getArrangementsController
    const getArrangementsController = require('./getArrangementsController');

    // call the getArrangementsController function
    await getArrangementsController(req, res, next);
    expect(res.statusCode).toBe(200);
  });

  // create a test case to return 204 incase of empty response
  xit('should send blank response', async () => {
    const req = createRequest();
    const res = getDefaultRes();

    // mock the getLegalEntity function
    jest.doMock('../../generated/api-clients/index.js', () => ({
      capProdsvcadmProddealacctadmInstlArrngmntsvcngV1Services: {
        getArrangements: jest.fn(() => {
          return Promise.resolve({
            data: {},
            status: 204,
            statusText: 'HTTP OK',
            empty: true,
            ok: true,
          });
        }),
      },
    }));

    const getArrangementsController = require('./getArrangementsController');

    await getArrangementsController(req, res, next);

    // const result = res._getJSONData();
    expect(res.statusCode).toBe(204);
  });

  it('should handle errors', async () => {
    // create a request object
    const req = createRequest();

    // create a response object
    const res = getDefaultRes();

    // import the getArrangementsController

    // call the getArrangementsController function
    await getArrangementsController(req, res, next);

    expect(handleControllerError).toHaveBeenCalled();
  });

  // it('should include active only when arrangementStatus query is ACTIVE', async () => {
  //   // create a request object
  //   const req = createRequest({
  //     query: {
  //       arrangementStatus: 'ACTIVE'
  //     }
  //   });

  //   // create a response object
  //   const res = getDefaultRes();

  //   // mock the getArrangements function
  //   jest.doMock('../../generated/api-clients/index.js', () => ({
  //     capProdsvcadmProddealacctadmInstlArrngmntsvcngV1Services: {
  //       getArrangements: jest.fn(() => {
  //         return Promise.resolve({
  //           data: capProdsvcadmProddealacctadmInstlArrngmntsvcngV1ServicesSuccessMocked,
  //           status: 200,
  //           statusText: 'HTTP OK',
  //           empty: false,
  //           ok: true,
  //         });
  //       }),
  //     },
  //   }));

  //   // import the getArrangementsController
  //  // const getArrangementsController = require('./getArrangementsController');

  //   // call the getArrangementsController function
  //   await getArrangementsController(req, res, next);
  //   const result = res._getJSONData();
  //   expect(res.statusCode).toBe(200);
  //   expect(result.entities.arrangements.length).toBeGreaterThan(0);
  //   result.entities.arrangements.forEach((arrangement: any) => {
  //     expect(arrangement.status).toBe('ACTIVE');
  //   });
  //   // cannot use match snapshot, since the id on record is refreshed on every call
  //   // expect(result).toMatchSnapshot();
  // });
});
