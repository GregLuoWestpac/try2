import { RUNTIME } from '@mep-node/framework-constants';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import {
  accessControlExposeHeaders,
  APIClientError,
  DownstreamServiceResponse,
  getBeneficiaryIdsFromPdpQueryResult,
  handleApiService,
  handleControllerError,
  normaliseDataWithPaging,
  STATUS_CODES,
  transformPdpQueryResult,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { PDP_QUERY_ACTIONS } from '@mesh-tenant-user-authorisation-policy-decision-engine/entitlements-api-lib';
import { NextFunction, Request, Response } from 'express';
import {
  beneficiaryManagementV1Services,
  userAuthorisationPolicyDecisionEngineApiV1Services,
} from '../../generated/api-clients';
import { readMeshSecrets } from '../../utils/secretsUtils';
import {
  ExpApiResponseData,
  transformDownstreamResponseToUi,
} from '../helpers/retrieveBeneficiariesController.helper';

const retrieveBeneficiariesController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { logger, apiHeaders } = res.locals;
  const protectedOrgCisKeyId = req.get('protected-orgId');

  const { queryDecisionRequest } =
    userAuthorisationPolicyDecisionEngineApiV1Services;
  const { ListBeneficiaries } = beneficiaryManagementV1Services;

  const userId = apiHeaders['x-userId'];

  let beneficiaryIds: string[] = [];
  let downstreamResponse: DownstreamServiceResponse;
  const { divisionId, ...restBody } = req.body; // removing divisionId from the body as it's not required for BeneficiariesList API
  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);
  try {
    if (!RUNTIME.isLocal()) {
      const meshSecretsContent = readMeshSecrets(['pdpClientToken'], logger);
      const { pdpClientToken } = meshSecretsContent;
      const pdpQueryResults = await getBeneficiaryIdsFromPdpQueryResult({
        req,
        res,
        queryDecisionRequest,
        pdpClientToken,
        userId,
        ...(divisionId ? { divisionId: divisionId as string } : {}),
        orgCisKey: protectedOrgCisKeyId,
        requestAction: PDP_QUERY_ACTIONS.INITIATE_PAYMENT,
      });

      if (pdpQueryResults?.length > 0) {
        beneficiaryIds = transformPdpQueryResult(pdpQueryResults);
      } else {
        logger.error('No data in the PDP Query result');

        downstreamResponse = {
          data: {
            data: { beneficiaries: [] },
            paging: null,
          },
        } as unknown as DownstreamServiceResponse;
      }
    }

    if (!downstreamResponse) {
      downstreamResponse = await handleApiService({
        req,
        res,
        apiClient: ListBeneficiaries,
        requestBody: {
          ...restBody,
          ids: beneficiaryIds,
          ...(restBody?.statuses ? { statuses: restBody?.statuses } : {}),
        },
      });
    }
    const expApiResponseData: ExpApiResponseData =
      transformDownstreamResponseToUi(downstreamResponse.data);

    const normalisedData = normaliseDataWithPaging(
      'beneficiaryList',
      expApiResponseData,
      normalise
    );

    res.status(STATUS_CODES.OK).json(normalisedData).end();
  } catch (error: unknown) {
    handleControllerError({ error: error as APIClientError, res, logger });
    next(error);
  }
};

module.exports = retrieveBeneficiariesController;
