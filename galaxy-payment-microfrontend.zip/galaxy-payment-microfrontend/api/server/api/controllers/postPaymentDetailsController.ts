/* eslint-disable import/no-import-module-exports */
import { Request, Response, NextFunction } from 'express';
import { postPaymentDetailsFromDownstream } from '../services/postPaymentDetailsService';
import { CONSTANTS } from '../../utils/constants';
import { normaliseData } from '../schema/postPaymentDetails.schema';
import { transformDownstreamResponseToUi } from '../helpers/postPaymentDetails.helper';
import { accessControlExposeHeaders, handleControllerError } from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

const postPaymentDetailsController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const {
    httpStatus: { OK },
  } = CONSTANTS;
  const { logger } = res.locals;
  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);
  try {
    const paymentDetailsFromDownstreamResponse =
      await postPaymentDetailsFromDownstream(req, res);
    const paymentDetails = transformDownstreamResponseToUi(
      paymentDetailsFromDownstreamResponse
    );
    const normalisedPaymentDetails = normaliseData(paymentDetails);
    res.status(OK).json(normalisedPaymentDetails).end();
  } catch (error) {
    handleControllerError({
      error,
      res,
      logger
    });
    next(error);
  }
};

module.exports = postPaymentDetailsController;
