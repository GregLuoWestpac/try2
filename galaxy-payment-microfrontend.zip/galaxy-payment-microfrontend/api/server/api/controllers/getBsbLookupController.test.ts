import { Request, Response, NextFunction } from 'express';

// Mock all dependencies before importing the controller
jest.mock('@mep-node/framework-constants', () => ({
  RUNTIME: {
    isLocal: jest.fn(() => false),
    component_name: 'test',
    environment: 'test'
  }
}));

jest.mock('@mep-node/framework-response-normaliser-addon', () => ({
  normalise: jest.fn()
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils');

jest.mock('../../generated/api-clients', () => ({
  infBnkngChnlBrchntwkV2Services: {
    getBranchReferenceData: jest.fn()
  }
}));


// Mock the buildGetBsbLookupController to return a simple function
const mockController = jest.fn().mockImplementation(async (req, res, next) => {
  res.status(200).json({ data: 'success' });
});

const mockBuildGetBsbLookupController = jest.fn(() => mockController);

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiBsbLookup', () => ({
  buildGetBsbLookupController: mockBuildGetBsbLookupController,
}), { virtual: true });

// Import the controller after mocking
const getBsbLookupController = require('./getBsbLookupController');

describe('getBsbLookupController', () => {
  let mockReq: Partial<Request>;
  let mockRes: Partial<Response>;
  let mockNext: NextFunction;

  beforeEach(() => {
    mockReq = {
      query: {},
      get: jest.fn(),
    };

    mockRes = {
      locals: {
        logger: { info: jest.fn(), error: jest.fn(), warn: jest.fn(), debug: jest.fn() },
        apiBaseUrl: 'http://test-api',
        xBrandId: 'test-brand',
        brandSilo: 'test-silo',
        apiHeaders: {},
      } as any,
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      end: jest.fn(),
    };

    mockNext = jest.fn();

    // Reset all mocks
    jest.clearAllMocks();
  });

  describe('Module Structure', () => {
    it('should export a function', () => {
      expect(typeof getBsbLookupController).toBe('function');
    });

    it('should maintain CommonJS module format', () => {
      const controllerModule = require('./getBsbLookupController');
      expect(controllerModule).toBeDefined();
      expect(typeof controllerModule).toBe('function');
    });
  });

  describe('Controller Creation', () => {
    it('should use buildGetBsbLookupController dependency', () => {
      // Test that the module loads without error and uses the mocked dependency
      expect(getBsbLookupController).toBeDefined();
      expect(typeof getBsbLookupController).toBe('function');
    });

    it('should maintain expected module structure', () => {
      // The controller should be created with the pattern we expect
      const controllerModule = require('./getBsbLookupController');
      expect(controllerModule).toBe(getBsbLookupController);
    });
  });

  describe('Controller Execution', () => {
    it('should execute without throwing errors', async () => {
      expect(async () => {
        await getBsbLookupController(
          mockReq as Request,
          mockRes as Response,
          mockNext
        );
      }).not.toThrow();
    });

    it('should handle request and response objects', async () => {
      // The controller should accept the standard Express middleware signature
      expect(() => {
        getBsbLookupController(
          mockReq as Request,
          mockRes as Response,
          mockNext
        );
      }).not.toThrow();
    });
  });

  describe('Basic Functionality', () => {
    it('should be callable as a function', () => {
      expect(typeof getBsbLookupController).toBe('function');
      expect(getBsbLookupController.length).toBeGreaterThanOrEqual(0);
    });

    it('should not throw when called with mock arguments', () => {
      expect(() => {
        getBsbLookupController(mockReq, mockRes, mockNext);
      }).not.toThrow();
    });
  });
});
