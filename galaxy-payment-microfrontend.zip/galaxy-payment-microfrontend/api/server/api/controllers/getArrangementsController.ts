import { Request, Response, NextFunction } from 'express';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import { ApiResponse } from '../../../interfaces/types/common';
import { ArrangementsResponse } from '../../../interfaces/models/Arrangements';
import { getArrangementsFromDownstream } from '../services/arrangementsService';
import { accessControlExposeHeaders, handleControllerError, normaliseDataWithPaging } from '@mesh-tenant-multiverse-ui-common/mv-apiutils'
import { CONSTANTS } from '../../utils/constants';
import {
  SCHEMA_KEY,
  SCHEMA_KEY_PAGING,
} from '../schema/getArrangements.schema';
import { transformArrangementsResponse } from '../helpers/getArrangementsController.helper';


const getArrangementsController = async (
  req: Request,
  res: Response<ApiResponse<ArrangementsResponse>>,
  next: NextFunction
) => {
  const { logger } = res.locals;
  const {
    httpStatus: { OK },
  } = CONSTANTS;

  const queryParams = req.query || {};
  res.setHeader('Access-Control-Expose-Headers', accessControlExposeHeaders);
  try {
    const arrangementsFromDownstreamResponse = await getArrangementsFromDownstream(req, res);
    const arrangementsTransformed = transformArrangementsResponse(
      arrangementsFromDownstreamResponse,
      queryParams
    );
    const paging =
      arrangementsTransformed && arrangementsTransformed?.paging
        ? arrangementsTransformed?.paging
        : {};
    const normalisedData = normaliseDataWithPaging(
      SCHEMA_KEY,
      {
        [SCHEMA_KEY]: arrangementsTransformed.arrangements || [],
        [SCHEMA_KEY_PAGING]: paging,
      },
      normalise
    ) as ApiResponse<ArrangementsResponse>;
    res
      .status(OK)
      .json(normalisedData)
      .end();
  } catch (error) {
    handleControllerError({
      error,
      res,
      logger
    });
    next(error);
  }
};

module.exports = getArrangementsController;
