import { RUNTIME } from '@mep-node/framework-constants';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import { userAuthorisationPolicyDecisionEngineApiV1Services } from '../../generated/api-clients';
import { readMeshSecrets } from '../../utils/secretsUtils';
import {
  buildGetAccountListController,
  ControllerParams,
} from '@mesh-tenant-multiverse-ui-common/mv-apiaccountlist';

const controllerParams: ControllerParams = {
  RUNTIME,
  normalise,
  apiClient: userAuthorisationPolicyDecisionEngineApiV1Services,
  readMeshSecrets,
};

const getAccountListController =
  buildGetAccountListController(controllerParams);

module.exports = getAccountListController;
