import { NextFunction, Request, Response } from 'express';
import {
  PostPaymentsRequest,
  PostPaymentsResponse,
} from '../../../interfaces/models/Payments';
import { ApiResponse } from '../../../interfaces/types/common';

// Mock the paymentCreateController
jest.mock('./paymentCreateController', () => jest.fn());

describe('postTransferCreateController', () => {
  let mockReq: Request<never, Record<string, unknown>, PostPaymentsRequest>;
  let mockRes: Response<ApiResponse<PostPaymentsResponse> | string>;
  let mockNext: NextFunction;
  let postTransferCreateController: any;
  let mockPostPaymentCreateController: jest.Mock;

  beforeEach(() => {
    jest.clearAllMocks();

    // Import the mocked paymentCreateController
    mockPostPaymentCreateController =
      require('./paymentCreateController') as jest.Mock;

    // Import the controller after mocking
    postTransferCreateController = require('./postTransferCreateController');

    // Create mock request, response, and next function
    mockReq = {
      body: {
        clientContext: { channelType: 'W1C_O_A_D_CP' },
        creditTransferTransactionInformation: [
          {
            creditor: { name: 'Transfer Recipient' },
            creditorAccount: {
              identification: '123456789',
              schemeName: 'BBAN',
            },
            instructedAmount: { amount: '1000.00', currency: 'AUD' },
          },
        ],
        debtor: { name: 'Transfer Sender' },
        debtorAccount: { identification: '987654321' },
        supplementaryData: { debitDescription: 'Fund transfer' },
      },
    } as unknown as Request<
      never,
      Record<string, unknown>,
      PostPaymentsRequest
    >;

    mockRes = {
      locals: {
        logger: {
          info: jest.fn(),
          error: jest.fn(),
          trace: jest.fn(),
          debug: jest.fn(),
          warn: jest.fn(),
        },
        apiHeaders: {
          'x-userId': 'M123456',
        },
      },
    } as unknown as Response<ApiResponse<PostPaymentsResponse> | string>;

    mockNext = jest.fn() as NextFunction;
  });

  it('should delegate to paymentCreateController', async () => {
    // Act
    await postTransferCreateController(mockReq, mockRes, mockNext);

    // Assert
    expect(mockPostPaymentCreateController).toHaveBeenCalledTimes(1);
    expect(mockPostPaymentCreateController).toHaveBeenCalledWith(
      mockReq,
      mockRes,
      mockNext,
      'transferCreate'
    );
  });

  it('should pass through any errors from the paymentCreateController', async () => {
    // Arrange
    const testError = new Error('Test error from paymentCreateController');
    mockPostPaymentCreateController.mockRejectedValue(testError);

    // Act & Assert
    await expect(
      postTransferCreateController(mockReq, mockRes, mockNext)
    ).rejects.toThrow('Test error from paymentCreateController');

    expect(mockPostPaymentCreateController).toHaveBeenCalledWith(
      mockReq,
      mockRes,
      mockNext,
      'transferCreate'
    );
  });

  it('should resolve successfully when paymentCreateController resolves', async () => {
    // Arrange
    mockPostPaymentCreateController.mockResolvedValue(undefined);

    // Act
    await postTransferCreateController(mockReq, mockRes, mockNext);

    // Assert
    expect(mockPostPaymentCreateController).toHaveBeenCalledWith(
      mockReq,
      mockRes,
      mockNext,
      'transferCreate'
    );
  });

  it('should maintain correct function signature and types', () => {
    // Assert that the controller is a function
    expect(typeof postTransferCreateController).toBe('function');

    // Assert that it's an async function (returns a Promise)
    const result = postTransferCreateController(mockReq, mockRes, mockNext);
    expect(result).toBeInstanceOf(Promise);
  });

  it('should handle transfer request structures', async () => {
    // Arrange - typical transfer request
    const transferReq = {
      body: {
        clientContext: { channelType: 'MOBILE' },
        creditTransferTransactionInformation: [
          {
            creditor: {
              name: 'John Smith - Transfer Recipient',
              address: {
                addressLine: ['456 Transfer Ave'],
                country: 'AU',
              },
            },
            creditorAccount: {
              identification: '111222333444',
              schemeName: 'BBAN',
              name: 'John Smith Checking',
            },
            creditorAgent: {
              BICFI: 'WPACAU2SXXX',
            },
            instructedAmount: {
              amount: '2500.00',
              currency: 'AUD',
            },
            remittanceInformation: {
              unstructured: ['Transfer funds'],
            },
            endToEndIdentification: 'TRANSFER001',
          },
        ],
        debtor: { name: 'Alice Johnson - Sender' },
        debtorAccount: { identification: '555666777888' },
        supplementaryData: {
          debitDescription: 'Transfer to John Smith',
        },
        paymentMethod: 'TRF',
        paymentTypeInformation: {
          serviceLevel: 'NORM',
        },
      },
    } as unknown as Request<
      never,
      Record<string, unknown>,
      PostPaymentsRequest
    >;

    // Act
    await postTransferCreateController(transferReq, mockRes, mockNext);

    // Assert
    expect(mockPostPaymentCreateController).toHaveBeenCalledWith(
      transferReq,
      mockRes,
      mockNext,
      'transferCreate'
    );
  });

  it('should handle different response configurations for transfers', async () => {
    // Arrange
    const differentRes = {
      locals: {
        logger: {
          info: jest.fn(),
          error: jest.fn(),
          trace: jest.fn(),
          debug: jest.fn(),
          warn: jest.fn(),
        },
        apiHeaders: {
          'x-userId': 'M654321',
          'x-brandId': 'WBC',
          'x-channelType': 'WEB',
          'x-messageId': 'TRANSFER_MSG_001',
        },
      },
    } as unknown as Response<ApiResponse<PostPaymentsResponse> | string>;

    // Act
    await postTransferCreateController(mockReq, differentRes, mockNext);

    // Assert
    expect(mockPostPaymentCreateController).toHaveBeenCalledWith(
      mockReq,
      differentRes,
      mockNext,
      'transferCreate'
    );
  });

  it('should handle inter-bank transfer transactions', async () => {
    // Arrange - inter-bank transfer request
    const interBankReq = {
      body: {
        clientContext: { channelType: 'INTERNET_BANKING' },
        creditTransferTransactionInformation: [
          {
            creditor: { name: 'External Bank Recipient' },
            creditorAccount: {
              identification: '999888777666',
              schemeName: 'BBAN',
            },
            creditorAgent: {
              BICFI: 'OTHERAU2SXXX',
              name: 'Other Bank',
            },
            instructedAmount: {
              amount: '5000.00',
              currency: 'AUD',
            },
            chargeBearer: 'DEBT',
            remittanceInformation: {
              unstructured: ['Inter-bank transfer'],
            },
          },
        ],
        debtor: { name: 'Corporate Account Holder' },
        debtorAccount: { identification: '123123123123' },
        supplementaryData: {
          debitDescription: 'Inter-bank transfer payment',
        },
        paymentMethod: 'TRF',
        paymentTypeInformation: {
          serviceLevel: 'URGP',
          instructionPriority: 'HIGH',
        },
      },
    } as unknown as Request<
      never,
      Record<string, unknown>,
      PostPaymentsRequest
    >;

    // Act
    await postTransferCreateController(interBankReq, mockRes, mockNext);

    // Assert
    expect(mockPostPaymentCreateController).toHaveBeenCalledWith(
      interBankReq,
      mockRes,
      mockNext,
      'transferCreate'
    );
  });

  it('should handle multiple transfer transactions in single request', async () => {
    // Arrange - request with multiple transfers
    const multipleTransfersReq = {
      body: {
        clientContext: { channelType: 'BRANCH' },
        creditTransferTransactionInformation: [
          {
            creditor: { name: 'Transfer Recipient 1' },
            creditorAccount: {
              identification: '111111111',
              schemeName: 'BBAN',
            },
            instructedAmount: { amount: '1500.00', currency: 'AUD' },
            endToEndIdentification: 'TXN001',
          },
          {
            creditor: { name: 'Transfer Recipient 2' },
            creditorAccount: {
              identification: '222222222',
              schemeName: 'BBAN',
            },
            instructedAmount: { amount: '2500.00', currency: 'AUD' },
            endToEndIdentification: 'TXN002',
          },
          {
            creditor: { name: 'Transfer Recipient 3' },
            creditorAccount: {
              identification: '333333333',
              schemeName: 'BBAN',
            },
            instructedAmount: { amount: '750.00', currency: 'AUD' },
            endToEndIdentification: 'TXN003',
          },
        ],
        debtor: { name: 'Bulk Transfer Account' },
        debtorAccount: { identification: '888888888' },
        supplementaryData: {
          debitDescription: 'Bulk transfer payments',
        },
        paymentInformation: {
          numberOfTransactions: '3',
        },
      },
    } as unknown as Request<
      never,
      Record<string, unknown>,
      PostPaymentsRequest
    >;

    // Act
    await postTransferCreateController(multipleTransfersReq, mockRes, mockNext);

    // Assert
    expect(mockPostPaymentCreateController).toHaveBeenCalledWith(
      multipleTransfersReq,
      mockRes,
      mockNext,
      'transferCreate'
    );
  });

  it('should handle scheduled transfer requests', async () => {
    // Arrange - scheduled transfer request
    const scheduledTransferReq = {
      body: {
        clientContext: { channelType: 'MOBILE' },
        creditTransferTransactionInformation: [
          {
            creditor: { name: 'Scheduled Transfer Recipient' },
            creditorAccount: {
              identification: '444444444',
              schemeName: 'BBAN',
            },
            instructedAmount: { amount: '800.00', currency: 'AUD' },
            remittanceInformation: {
              unstructured: ['Monthly transfer payment'],
            },
          },
        ],
        debtor: { name: 'Regular Transfer Account' },
        debtorAccount: { identification: '777777777' },
        supplementaryData: {
          debitDescription: 'Scheduled transfer',
        },
        paymentInformation: {
          requestedExecutionDate: '2025-11-01T00:00:00.000Z',
        },
        paymentTypeInformation: {
          serviceLevel: 'NORM',
          categoryPurpose: 'TRAD',
        },
      },
    } as unknown as Request<
      never,
      Record<string, unknown>,
      PostPaymentsRequest
    >;

    // Act
    await postTransferCreateController(scheduledTransferReq, mockRes, mockNext);

    // Assert
    expect(mockPostPaymentCreateController).toHaveBeenCalledWith(
      scheduledTransferReq,
      mockRes,
      mockNext,
      'transferCreate'
    );
  });

  it('should not modify request or response objects before delegation', async () => {
    // Arrange
    const originalReq = { ...mockReq };
    const originalRes = { ...mockRes };

    // Act
    await postTransferCreateController(mockReq, mockRes, mockNext);

    // Assert
    expect(mockReq).toEqual(originalReq);
    expect(mockRes).toEqual(originalRes);
    expect(mockPostPaymentCreateController).toHaveBeenCalledWith(
      mockReq,
      mockRes,
      mockNext,
      'transferCreate'
    );
  });
});
