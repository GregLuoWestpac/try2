import { normalise } from '@mep-node/framework-response-normaliser-addon';
import { normaliseData } from './postPaymentDetails.schema';
import { ExpPostPaymentDetails } from '../../../interfaces/models/PaymentDetails';

jest.mock('@mep-node/framework-response-normaliser-addon', () => ({
  normalise: jest.fn(),
}));

describe('normaliseData', () => {
  const mockPaymentDetails: ExpPostPaymentDetails[0] = {
    id: 'd0868661-b955-4e76-9f15-d97626f7df6b',
    status: 'Processed',
  };

  const SCHEMA_KEY = 'paymentDetails';

  it('should normalise data correctly', () => {
    const expectedNormalisedData = {
      entities: {
        paymentDetails: [mockPaymentDetails],
      },
      result: [mockPaymentDetails.id],
    };

    (normalise as jest.Mock).mockReturnValue(expectedNormalisedData);

    const result = normaliseData([mockPaymentDetails]);

    expect(normalise).toHaveBeenCalledWith(
      { [SCHEMA_KEY]: [mockPaymentDetails] },
      expect.any(Object)
    );
    expect(result).toEqual(expectedNormalisedData);
  });

  it('should handle empty data', () => {
    const emptyData: ExpPostPaymentDetails = {} as ExpPostPaymentDetails;
    const expectedNormalisedData = {
      entities: {
        paymentDetails: [],
      },
      result: [],
    };

    (normalise as jest.Mock).mockReturnValue(expectedNormalisedData);

    const result = normaliseData(emptyData);

    expect(normalise).toHaveBeenCalledWith(
      { [SCHEMA_KEY]: emptyData },
      expect.any(Object)
    );
    expect(result).toEqual(expectedNormalisedData);
  });
});
