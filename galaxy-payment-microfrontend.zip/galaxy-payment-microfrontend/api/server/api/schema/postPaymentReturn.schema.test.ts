import { normalise as normalizeJson } from '@mep-node/framework-response-normaliser-addon';

import { postPaymentReturnsSchemaBuilder } from './postPaymentReturn.schema';

describe('postProducts.schema', () => {
  describe('postPaymentReturnsSchemaBuilder', () => {
    it('should return a normalised response with entities and result', () => {
      const normalisedResponse = {
        entities: {
          paymentreturns: [
            {
              id: '123',
            },
          ],
        },
        result: {
          paymentreturns: ['123'],
        },
      };

      expect(
        normalizeJson(
          {
            paymentreturns: [
              {
                id: '123',
              },
            ],
          },
          postPaymentReturnsSchemaBuilder
        )
      ).toEqual(normalisedResponse);
    });
  });
});
