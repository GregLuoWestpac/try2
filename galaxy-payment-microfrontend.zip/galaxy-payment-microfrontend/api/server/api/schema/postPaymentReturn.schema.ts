import { schema } from 'normalizr';
import { PostPaymentReturnsResponse } from '../../../interfaces/models/PaymentReturns';

const SCHEMA_KEY = 'paymentreturns';

const paymentReturnsSchema = new schema.Entity<PostPaymentReturnsResponse>(SCHEMA_KEY);

const postPaymentReturnsSchemaBuilder = new schema.Object({
  [SCHEMA_KEY]: new schema.Array(paymentReturnsSchema),
});

export { postPaymentReturnsSchemaBuilder, SCHEMA_KEY };
