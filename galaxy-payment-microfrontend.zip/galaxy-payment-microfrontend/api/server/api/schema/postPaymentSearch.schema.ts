import { schema } from 'normalizr';

import {
  PostPaymentListingResponse,
  PostpaymentListingPagingResponse,
} from '../../../interfaces/types/paymentListing';

const SCHEMA_KEY = 'paymentListing';
const SCHEMA_KEY_PAGING = 'paging';

const paymentListingSchema = new schema.Entity<PostPaymentListingResponse>(
  SCHEMA_KEY
);
const pagingSchema = new schema.Entity<PostpaymentListingPagingResponse>(
  SCHEMA_KEY_PAGING
);

const postPaymentListingSchemaBuilder = new schema.Object({
  [SCHEMA_KEY]: new schema.Array(paymentListingSchema),
});
const postPaymentListingPagingSchemaBuilder = new schema.Object({
  [SCHEMA_KEY_PAGING]: new schema.Array(pagingSchema),
});

export {
  postPaymentListingSchemaBuilder,
  SCHEMA_KEY,
  postPaymentListingPagingSchemaBuilder,
  SCHEMA_KEY_PAGING,
  paymentListingSchema,
  pagingSchema,
};
