import { schema } from 'normalizr';

import {
  ArrangementsResponse,
  PagingResponse,
} from '../../../interfaces/models/Arrangements';

const SCHEMA_KEY = 'arrangements';
const SCHEMA_KEY_PAGING = 'paging';
const arrangementsSchema = new schema.Entity<ArrangementsResponse>(SCHEMA_KEY);
const pagingSchema = new schema.Entity<PagingResponse>(SCHEMA_KEY_PAGING);

export { arrangementsSchema, pagingSchema, SCHEMA_KEY, SCHEMA_KEY_PAGING };
