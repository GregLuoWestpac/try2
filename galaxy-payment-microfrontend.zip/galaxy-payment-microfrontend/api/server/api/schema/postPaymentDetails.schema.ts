import { schema } from 'normalizr';
import { normalise } from '@mep-node/framework-response-normaliser-addon';
import { ExpPostPaymentDetails } from '../../../interfaces/models/PaymentDetails';

const SCHEMA_KEY = 'paymentDetails';

const paymentDetailsSchema = new schema.Entity<ExpPostPaymentDetails>(
  SCHEMA_KEY
);

// TODO: Add more schema entities if needed
const postPaymentDetailsSchemaBuilder = new schema.Object({
  [SCHEMA_KEY]: new schema.Array(paymentDetailsSchema),
});

const normaliseData = (data: ExpPostPaymentDetails) =>
  normalise({ [SCHEMA_KEY]: data }, postPaymentDetailsSchemaBuilder);

export { normaliseData };
