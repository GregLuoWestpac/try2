const http = require('http');
const https = require('https');
const fs = require('fs');
// eslint-disable-next-line node/no-extraneous-require
const fetch = require('node-fetch');
const { URLSearchParams } = require('url');
// Configuration options for localhost http urls
const httpAgent = new http.Agent({
  rejectUnauthorized: false,
});

// Default configuration options
// when calling fetch
// rejectUnauthorized: false
// provided to get pas SELF_SIGNED_CERT
// error
const httpsAgent = new https.Agent({
  rejectUnauthorized: false,
});

const MULTIPART_TYPES = ['multipart/form-data'];

const dependencyMappingsFilPath = '/local/wdp-dependency-mappings.json';
/**
 This file is only available on MESH_BUILDS.
 Sample wdp-dependency-mappings.json:
 {
   "dependencyMappings": [
     {
       "componentName": "cap-technolmgt-pltf-integ-ref-first-propagator-v1",
       "basePath": "/cap/technolmgt/pltf/integ/ref/first/propagator/v1",
       "authority": "propagator-10ie",
       "scheme": "http"
     }
   ]
 }
**/

const isDependencyMappingsConfigAvailable = fs.existsSync(
  dependencyMappingsFilPath
);

let DEPENDENCY_MAPPINGS;

/**
 * Checks if DEPENDENCY_MAPPINGS is already available, else tries to read the wdp-dependency-mappings.json file and returns the dependency mapping object
 * @returns Object
 */
const getDependencyMappings = () => {
  if (DEPENDENCY_MAPPINGS) {
    return DEPENDENCY_MAPPINGS;
  }

  if (isDependencyMappingsConfigAvailable) {
    const dependencyMappingConfig = require(dependencyMappingsFilPath);
    DEPENDENCY_MAPPINGS =
      dependencyMappingConfig &&
      dependencyMappingConfig.dependencyMappings &&
      dependencyMappingConfig.dependencyMappings.reduce(
        (result, { componentName, scheme, authority }) => ({
          ...result,
          [componentName]: `${scheme}://${authority}`,
        }),
        {}
      );
  }

  return DEPENDENCY_MAPPINGS;
};

/**
 * Looks up wdp-dependency-mappings.json for the api in context and returns the downstream api base url
 *
 * @param {String} apiName
 * @param {Function} logger
 * @returns String
 */
const getDownstreamApiBaseUrl = (apiName, logger) => {
  try {
    const dependencyMappings = getDependencyMappings();
    return dependencyMappings && dependencyMappings[apiName];
  } catch (error) {
    logger.error(
      `getDownstreamApiBaseUrl :: Error occurred while determining the downstream API URL for ${apiName}`,
      {
        err: error,
      }
    );
    return undefined;
  }
};

const mapPathWithParam = (path, pathParams) => {
  let newPath = path;
  if (pathParams) {
    // eslint-disable-next-line guard-for-in, no-restricted-syntax
    for (const param in pathParams) {
      newPath = newPath.replace(`{${param}}`, pathParams[param]);
    }
  }
  return newPath;
};

/**
 *
 * @param {object} queryParams  - Request query parameters object
 * @returns {string}
 */
const mapQueryWithParam = queryParams => {
  let querySuffix = '';
  if (queryParams) {
    // Axios strips out null or undefined attributes while passing queryParams
    // Replicating the same behaviour for fetch as well
    const modifiedQueryParams = Object.entries(queryParams).reduce(
      (result, [key, value]) => {
        if (value !== null && value !== undefined) {
          return { ...result, [key]: value };
        }
        return result;
      },
      {}
    );
    const searchParams = new URLSearchParams(modifiedQueryParams).toString();
    querySuffix = `?${searchParams}`;
  }
  return querySuffix;
};

/**
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *                `header` - request header parameters
 *
 *                `path` -   request path parameters
 *
 *                `query` -  request query parameters
 *
 *                `body` -   request body
 *
 * @param {Object} apiConfig -  Configuration for request and response pertaining to the underlying API
 *
 *                `request` -  Request config for the underlying connection
 *
 *                `response` - Response config for the underlying connection
 *
 * @param {Number} timeoutIn - Request timeout as configured for the Exp API resource
 *                             or defaulted to 15000 ms which is propagated to the
 *                             underlying connection
 *
 * @param {Object} req -  The ExpressJS request object
 */
const mapStandardParams = (params, apiConfig, timeoutIn, req) => {
  const { path, header, query, body } = params;
  const { request, response: responseConfig } = apiConfig;
  const requestConfig = {
    ...request,
    timeout: timeoutIn,
  };

  return {
    path,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'x-messageId': req.header('x-messageId'),
      'x-appCorrelationId': req.header('x-appCorrelationId'),
      'x-channelType': req.header('x-channelType'),
      'x-brandId': req.header('x-brandId'),
      ...header,
    },
    parameters: query,
    data: body, // this can be FormData instance
    requestConfig,
    responseConfig,
  };
};

// Refactor based on API design guidelines
// where status 204 is not valid for method get
const isEmpty = ({ status, data }) => {
  if (status === 204) {
    return true;
  }
  return !data;
};

const getRequestBody = data => {
  try {
    // eslint-disable-next-line node/no-extraneous-require, global-require
    const FormData = require('form-data');
    if (data instanceof FormData) {
      return data;
    }
    // eslint-disable-next-line no-empty
  } catch (e) {}

  return JSON.stringify(data);
};

const MakeDataRequest = (url, runtimeOptions) => ({
  ...runtimeOptions,
  body: runtimeOptions.data ? getRequestBody(runtimeOptions.data) : undefined, // only applicable to PUT POST PATCH
  timeout: runtimeOptions.requestConfig.timeout,
  maxRedirects: runtimeOptions.requestConfig.maxRedirects,
  params: runtimeOptions.parameters,
  agent: url.startsWith('http:') ? httpAgent : httpsAgent,
  headers: {
    ...runtimeOptions.headers,
  },
});

const MakeDataResponse = (response, data, logger) => {
  const { status, statusText, ok } = response;
  const headers = response?.headers?.raw() || {};
  const responseLog = {
    status,
    statusText,
    headers,
    data,
  };
  logger(responseLog, 'payment.DownstreamAPI.Response', 'debug');

  return {
    ...responseLog,
    ok,
    empty: isEmpty(responseLog),
  };
};

const MakeErrorResponse = (response, data, message, logger) => {
  const { status, statusText } = response || {};
  const headers = response?.headers?.raw() || {};
  const error = {
    status: status || 500,
    statusText: statusText || 'Internal Server Error',
    headers,
    message,
    data,
  };
  logger(error, 'payment.DownstreamAPI.Error', 'error');
  // eslint-disable-next-line prefer-promise-reject-errors
  return Promise.reject({ type: 'Error', error });
};

/**
 * @param {object} url - endpoint
 * @param {object} logger
 * @param {object} config - normalised runtime options (processed by mapStandardParams)
 */
const fetchApiClient = async (url, logger, config = {}) => {
  let data;
  let response;
  let errorMessage = '';
  try {
    response = await fetch(url, config);

    // Handle 204 No Content response
    if (response.status === 204) {
      return MakeDataResponse(response, data, logger);
    }

    const contentType = response.headers.get('content-type') || '';
    const [type] = contentType.split(';');

    switch (type) {
      case 'application/json':
      case 'application/vnd.api+json':
        // Only parse JSON if there is a response body
        const text = await response.text();
        data = text ? JSON.parse(text) : null;
        break;
      case 'application/x-yaml':
      case 'application/xml':
        data = await response.text();
        break;
      default:
        break;
    }

    if (response.ok) {
      return MakeDataResponse(response, data, logger);
    }
  } catch (error) {
    errorMessage = error.code;
  }
  return MakeErrorResponse(response, data, errorMessage, logger);
};

const fetchData = async request => {
  const { apiEndPoint, logger, configValues } = request;
  const apiConfig = MakeDataRequest(apiEndPoint, configValues);
  const response = await fetchApiClient(apiEndPoint, logger, apiConfig);
  return response;
};

module.exports = {
  mapPathWithParam,
  mapQueryWithParam,
  mapStandardParams,
  fetchData,
  MULTIPART_TYPES,
  getDownstreamApiBaseUrl,
  isDependencyMappingsConfigAvailable,
};
