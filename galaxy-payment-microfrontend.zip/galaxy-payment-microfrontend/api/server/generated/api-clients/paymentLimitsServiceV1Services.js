const {
  mapPathWithParam,
  mapQueryWithParam,
  mapStandardParams,
  fetchData,
  MULTIPART_TYPES,
  getDownstreamApiBaseUrl,
  isDependencyMappingsConfigAvailable,
} = require('./common');

const { hasPermission } = require('./entitlement');

const apiPath = '/cap/payment/limits/service/v1';
const expApiName = 'payment';

/**
 * @typedef {Object} BaseResponse
 * @prop {number} status - HTTP status code
 * @prop {string} statusText - HTTP status text
 * @prop {any} headers - HTTP headers
 * @prop {boolean} ok - Indicates if the response is successful
 * @prop {boolean} empty - Indicates if the response is empty
 */

/**
 * getLimitRules - Retrieve limit rules based on the specified criteria. By default, it returns all limit rules. You can filter by &#x60;level&#x60;, &#x60;userCISKey&#x60;, &#x60;organisationCISKey&#x60;, &#x60;channelId&#x60;, &#x60;scheme&#x60; and &#x60;currencyCode&#x60;.
&lt;br&#x2F;&gt;&lt;br&#x2F;&gt;
The &#x60;level&#x60; parameter determines the type of limit rule to retrieve, such as User, OrganisationChannel, or SchemeChannel.
The &#x60;userCISKey&#x60; is used to filter User limit rules.
The &#x60;organisationCISKey&#x60; is used to filter User and OrganisationChannel limit rules.
The &#x60;channelId&#x60; is used to filter OrganisationChannel and SchemeChannel limit rules.
The &#x60;scheme&#x60; is used to filter SchemeChannel limit rules.
Refer to example for different use cases.

 *
 * api : paymentLimitsServiceV1
 *
 * resource : /rules/search
 *
 * method : post
 *
 * @param {string} baseUrl - Baseurl for downstream api
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *                `header` - request header parameters
 *
 *                `path` -   request path parameters
 *
 *                `query` -  request query parameters
 *
 *                `body` -   request body
 *
 * @param {Object} apiConfig -  Configuration for request and response pertaining to the underlying API
 *
 *                `request` -  Request config for the underlying connection
 *
 *                `response` - Response config for the underlying connection
 *
 * @param {Object} req - The ExpressJS request object
 *
 * @param {Object} res - The ExpressJS response object
 *
 * @import { Rulessearch } from "./types/paymentLimitsServiceV1"
 * @typedef {BaseResponse & {data: Rulessearch.GetLimitRules.ResponseBody}} GetLimitRulesResponse
 * @return {Promise<GetLimitRulesResponse>} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
const getLimitRules = (baseUrl, params, apiConfig, req, res) => {
  const errors = [];
  const originPath = '/rules/search';
  const downStreamServiceName = 'payment-limits-service-v1';
  const requestMethod = 'post';
  const operationId = 'getLimitRules';
  const consumes = '';

  const { logger, timeoutIn = 15000 } = res.locals;
  const {
    locals: { Config },
  } = res.app;
  const { skipDependencyUrlMapping, enableSystemTest, mockoonBaseUrl } =
    Config.get('app-config');

  if (!logger) {
    const error = {
      code: 10000,
      message: 'Internal Server Error',
      details: 'Please check application logs for details',
    };

    errors.push(error);

    res.status(500).json({ result: { errors } }).end();

    const exception = new TypeError(
      'Logging instance not found. Make sure the logger middleware is instantiated.',
      'Services.js',
      68
    );

    return Promise.reject(exception);
  }

  /**
   * [WDPUI-1714](https://jira.srv.westpac.com.au/browse/WDPUI-1714)
   *
   * Interpret the `role` claim as an array or string
   * but always return an array
   */
  const { USER_ROLES: roles } = res.locals;

  // Wrapped in try{}catch(){}
  // Since the entitlement enforcer throws,
  // we need a way to catch the error and gracefully
  // reject the promise
  try {
    logger.trace({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message: `Evaluating entitlements for '${roles}'`,
      },
    });

    const { allow, assumedRoles } = hasPermission(
      downStreamServiceName,
      originPath,
      requestMethod,
      params,
      roles
    );

    if (!allow) {
      const error = {
        code: 10003,
        message: 'Access denied.',
        details: 'You have not been provisioned to access this information',
      };

      errors.push(error);

      const message = `${roles} are not permitted to call ${operationId} on ${downStreamServiceName}`;
      logger.error({
        payload: {
          message,
          downStreamServiceName,
          operationId,
          originPath,
          requestMethod,
        },
      });

      res.status(403).json({ result: { errors } }).end();

      const exception = new Error(message);

      return Promise.reject(exception);
    }

    logger.trace(
      `South-edge entitlement check passed for ${operationId} on ${originPath} with assumed roles ${assumedRoles}`
    );
  } catch ({ type, message }) {
    const error = {
      code: 10004,
      message: 'Access denied',
      details: 'We are unable to verify your access provisions at this time',
    };

    errors.push(error);

    const errorDetails = `${type && `${type.toUpperCase()}:`} => ${message}`;

    logger.error({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message:
          'Entitlement policy not configured correctly for the application',
        details: errorDetails,
      },
    });

    res.status(403).json({ result: { errors } }).end();

    const exception = new Error(errorDetails);

    return Promise.reject(exception);
  }

  const requestPayload = mapStandardParams(params, apiConfig, timeoutIn, req);
  const pathSuffix = params.path
    ? mapPathWithParam(originPath, params.path)
    : originPath;
  const querySuffix = mapQueryWithParam(params.query);

  let apiEndPoint = `${baseUrl}${apiPath}${pathSuffix}${querySuffix}`;

  if (isDependencyMappingsConfigAvailable) {
    if (skipDependencyUrlMapping) {
      logger.trace(
        `Skipping dynamic dependency url mapping as skipDependencyUrlMapping flag is set to true in app-config.json`
      );
    } else {
      const downstreamApiBaseUrl = getDownstreamApiBaseUrl(
        downStreamServiceName,
        logger
      );
      if (downstreamApiBaseUrl) {
        apiEndPoint = `${downstreamApiBaseUrl}${apiPath}${pathSuffix}${querySuffix}`;
      }
    }
  }
  /**
    Process.env.MOCKS_ENABLED is set by deployment pipeline based on mockoon-data.json file.
    If its enabled, sidecar will be available with mocks.
    Verify if x-systemTest header is present or enableSystemTest is defined in app-config.json to support downstream mock
  **/
  if (process.env.MOCKS_ENABLED === 'True') {
    logger.trace(
      `MockoonMocks :: MOCKS_ENABLED flag is ${process.env.MOCKS_ENABLED}. Verifying if x-systemTest header or enableSystemTest flag is set.`
    );
    const isSystemTestEnabled = req.headers['x-systemtest'] === 'true';
    if (isSystemTestEnabled || enableSystemTest) {
      const mockoonUrl = mockoonBaseUrl || 'http://localhost:3010';
      apiEndPoint = `${mockoonUrl}${apiPath}${pathSuffix}${querySuffix}`;
      logger.trace(`MockoonMocks :: enabling component mock based on (${isSystemTestEnabled},${enableSystemTest}).
        Overriding the apiBaseUrl to ${mockoonUrl}`);
    }
  }

  logger.trace({
    payload: {
      message: `${expApiName}.DownstreamAPI.Start`,
      apiEndPoint,
      downStreamServiceName,
      operationId,
      originPath,
      requestMethod,
      requestPayload,
    },
  });

  /**
   * For document upload api which has multipart upload,
   * maxContentLength & maxBodyLength params should be added as part of config
   * Since the swagger is encoded using hex, we've to replace &#x2F; by /
   */

  let defaultConfigOptions = {};

  if (MULTIPART_TYPES.includes(consumes.replace('&#x2F;', '/'))) {
    defaultConfigOptions = {
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    };
  }

  const log = (data, message, level = 'debug') =>
    logger[level]({
      payload: {
        message,
        apiEndPoint,
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        data,
        defaultConfigOptions,
      },
    });

  const configValues = {
    ...requestPayload,
    ...defaultConfigOptions,
    method: requestMethod,
  };

  const request = {
    apiEndPoint,
    logger: log,
    configValues,
  };

  return fetchData(request);
};

/**
 * createLimitRule - Create a limit rule for a user, organisation channel, or scheme channel.

 *
 * api : paymentLimitsServiceV1
 *
 * resource : /rules
 *
 * method : post
 *
 * @param {string} baseUrl - Baseurl for downstream api
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *                `header` - request header parameters
 *
 *                `path` -   request path parameters
 *
 *                `query` -  request query parameters
 *
 *                `body` -   request body
 *
 * @param {Object} apiConfig -  Configuration for request and response pertaining to the underlying API
 *
 *                `request` -  Request config for the underlying connection
 *
 *                `response` - Response config for the underlying connection
 *
 * @param {Object} req - The ExpressJS request object
 *
 * @param {Object} res - The ExpressJS response object
 *
 * @import { Rules } from "./types/paymentLimitsServiceV1"
 * @typedef {BaseResponse & {data: Rules.CreateLimitRule.ResponseBody}} CreateLimitRuleResponse
 * @return {Promise<CreateLimitRuleResponse>} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
const createLimitRule = (baseUrl, params, apiConfig, req, res) => {
  const errors = [];
  const originPath = '/rules';
  const downStreamServiceName = 'payment-limits-service-v1';
  const requestMethod = 'post';
  const operationId = 'createLimitRule';
  const consumes = '';

  const { logger, timeoutIn = 15000 } = res.locals;
  const {
    locals: { Config },
  } = res.app;
  const { skipDependencyUrlMapping, enableSystemTest, mockoonBaseUrl } =
    Config.get('app-config');

  if (!logger) {
    const error = {
      code: 10000,
      message: 'Internal Server Error',
      details: 'Please check application logs for details',
    };

    errors.push(error);

    res.status(500).json({ result: { errors } }).end();

    const exception = new TypeError(
      'Logging instance not found. Make sure the logger middleware is instantiated.',
      'Services.js',
      68
    );

    return Promise.reject(exception);
  }

  /**
   * [WDPUI-1714](https://jira.srv.westpac.com.au/browse/WDPUI-1714)
   *
   * Interpret the `role` claim as an array or string
   * but always return an array
   */
  const { USER_ROLES: roles } = res.locals;

  // Wrapped in try{}catch(){}
  // Since the entitlement enforcer throws,
  // we need a way to catch the error and gracefully
  // reject the promise
  try {
    logger.trace({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message: `Evaluating entitlements for '${roles}'`,
      },
    });

    const { allow, assumedRoles } = hasPermission(
      downStreamServiceName,
      originPath,
      requestMethod,
      params,
      roles
    );

    if (!allow) {
      const error = {
        code: 10003,
        message: 'Access denied.',
        details: 'You have not been provisioned to access this information',
      };

      errors.push(error);

      const message = `${roles} are not permitted to call ${operationId} on ${downStreamServiceName}`;
      logger.error({
        payload: {
          message,
          downStreamServiceName,
          operationId,
          originPath,
          requestMethod,
        },
      });

      res.status(403).json({ result: { errors } }).end();

      const exception = new Error(message);

      return Promise.reject(exception);
    }

    logger.trace(
      `South-edge entitlement check passed for ${operationId} on ${originPath} with assumed roles ${assumedRoles}`
    );
  } catch ({ type, message }) {
    const error = {
      code: 10004,
      message: 'Access denied',
      details: 'We are unable to verify your access provisions at this time',
    };

    errors.push(error);

    const errorDetails = `${type && `${type.toUpperCase()}:`} => ${message}`;

    logger.error({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message:
          'Entitlement policy not configured correctly for the application',
        details: errorDetails,
      },
    });

    res.status(403).json({ result: { errors } }).end();

    const exception = new Error(errorDetails);

    return Promise.reject(exception);
  }

  const requestPayload = mapStandardParams(params, apiConfig, timeoutIn, req);
  const pathSuffix = params.path
    ? mapPathWithParam(originPath, params.path)
    : originPath;
  const querySuffix = mapQueryWithParam(params.query);

  let apiEndPoint = `${baseUrl}${apiPath}${pathSuffix}${querySuffix}`;

  if (isDependencyMappingsConfigAvailable) {
    if (skipDependencyUrlMapping) {
      logger.trace(
        `Skipping dynamic dependency url mapping as skipDependencyUrlMapping flag is set to true in app-config.json`
      );
    } else {
      const downstreamApiBaseUrl = getDownstreamApiBaseUrl(
        downStreamServiceName,
        logger
      );
      if (downstreamApiBaseUrl) {
        apiEndPoint = `${downstreamApiBaseUrl}${apiPath}${pathSuffix}${querySuffix}`;
      }
    }
  }
  /**
    Process.env.MOCKS_ENABLED is set by deployment pipeline based on mockoon-data.json file.
    If its enabled, sidecar will be available with mocks.
    Verify if x-systemTest header is present or enableSystemTest is defined in app-config.json to support downstream mock
  **/
  if (process.env.MOCKS_ENABLED === 'True') {
    logger.trace(
      `MockoonMocks :: MOCKS_ENABLED flag is ${process.env.MOCKS_ENABLED}. Verifying if x-systemTest header or enableSystemTest flag is set.`
    );
    const isSystemTestEnabled = req.headers['x-systemtest'] === 'true';
    if (isSystemTestEnabled || enableSystemTest) {
      const mockoonUrl = mockoonBaseUrl || 'http://localhost:3010';
      apiEndPoint = `${mockoonUrl}${apiPath}${pathSuffix}${querySuffix}`;
      logger.trace(`MockoonMocks :: enabling component mock based on (${isSystemTestEnabled},${enableSystemTest}).
        Overriding the apiBaseUrl to ${mockoonUrl}`);
    }
  }

  logger.trace({
    payload: {
      message: `${expApiName}.DownstreamAPI.Start`,
      apiEndPoint,
      downStreamServiceName,
      operationId,
      originPath,
      requestMethod,
      requestPayload,
    },
  });

  /**
   * For document upload api which has multipart upload,
   * maxContentLength & maxBodyLength params should be added as part of config
   * Since the swagger is encoded using hex, we've to replace &#x2F; by /
   */

  let defaultConfigOptions = {};

  if (MULTIPART_TYPES.includes(consumes.replace('&#x2F;', '/'))) {
    defaultConfigOptions = {
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    };
  }

  const log = (data, message, level = 'debug') =>
    logger[level]({
      payload: {
        message,
        apiEndPoint,
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        data,
        defaultConfigOptions,
      },
    });

  const configValues = {
    ...requestPayload,
    ...defaultConfigOptions,
    method: requestMethod,
  };

  const request = {
    apiEndPoint,
    logger: log,
    configValues,
  };

  return fetchData(request);
};

/**
 * updateLimitRule - Update an existing limit rule for a user, organisation channel, or scheme channel.
Only amount value can be updated. Depends on the level of the limit rule, you can update &#x60;transactionAmount&#x60;, &#x60;dailyAmount&#x60; or both.

 *
 * api : paymentLimitsServiceV1
 *
 * resource : /rules/{id}
 *
 * method : patch
 *
 * @param {string} baseUrl - Baseurl for downstream api
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *                `header` - request header parameters
 *
 *                `path` -   request path parameters
 *
 *                `query` -  request query parameters
 *
 *                `body` -   request body
 *
 * @param {Object} apiConfig -  Configuration for request and response pertaining to the underlying API
 *
 *                `request` -  Request config for the underlying connection
 *
 *                `response` - Response config for the underlying connection
 *
 * @param {Object} req - The ExpressJS request object
 *
 * @param {Object} res - The ExpressJS response object
 *
 * @import { Rules } from "./types/paymentLimitsServiceV1"
 * @typedef {BaseResponse & {data: Rules.UpdateLimitRule.ResponseBody}} UpdateLimitRuleResponse
 * @return {Promise<UpdateLimitRuleResponse>} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
const updateLimitRule = (baseUrl, params, apiConfig, req, res) => {
  const errors = [];
  const originPath = '/rules/{id}';
  const downStreamServiceName = 'payment-limits-service-v1';
  const requestMethod = 'patch';
  const operationId = 'updateLimitRule';
  const consumes = '';

  const { logger, timeoutIn = 15000 } = res.locals;
  const {
    locals: { Config },
  } = res.app;
  const { skipDependencyUrlMapping, enableSystemTest, mockoonBaseUrl } =
    Config.get('app-config');

  if (!logger) {
    const error = {
      code: 10000,
      message: 'Internal Server Error',
      details: 'Please check application logs for details',
    };

    errors.push(error);

    res.status(500).json({ result: { errors } }).end();

    const exception = new TypeError(
      'Logging instance not found. Make sure the logger middleware is instantiated.',
      'Services.js',
      68
    );

    return Promise.reject(exception);
  }

  /**
   * [WDPUI-1714](https://jira.srv.westpac.com.au/browse/WDPUI-1714)
   *
   * Interpret the `role` claim as an array or string
   * but always return an array
   */
  const { USER_ROLES: roles } = res.locals;

  // Wrapped in try{}catch(){}
  // Since the entitlement enforcer throws,
  // we need a way to catch the error and gracefully
  // reject the promise
  try {
    logger.trace({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message: `Evaluating entitlements for '${roles}'`,
      },
    });

    const { allow, assumedRoles } = hasPermission(
      downStreamServiceName,
      originPath,
      requestMethod,
      params,
      roles
    );

    if (!allow) {
      const error = {
        code: 10003,
        message: 'Access denied.',
        details: 'You have not been provisioned to access this information',
      };

      errors.push(error);

      const message = `${roles} are not permitted to call ${operationId} on ${downStreamServiceName}`;
      logger.error({
        payload: {
          message,
          downStreamServiceName,
          operationId,
          originPath,
          requestMethod,
        },
      });

      res.status(403).json({ result: { errors } }).end();

      const exception = new Error(message);

      return Promise.reject(exception);
    }

    logger.trace(
      `South-edge entitlement check passed for ${operationId} on ${originPath} with assumed roles ${assumedRoles}`
    );
  } catch ({ type, message }) {
    const error = {
      code: 10004,
      message: 'Access denied',
      details: 'We are unable to verify your access provisions at this time',
    };

    errors.push(error);

    const errorDetails = `${type && `${type.toUpperCase()}:`} => ${message}`;

    logger.error({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message:
          'Entitlement policy not configured correctly for the application',
        details: errorDetails,
      },
    });

    res.status(403).json({ result: { errors } }).end();

    const exception = new Error(errorDetails);

    return Promise.reject(exception);
  }

  const requestPayload = mapStandardParams(params, apiConfig, timeoutIn, req);
  const pathSuffix = params.path
    ? mapPathWithParam(originPath, params.path)
    : originPath;
  const querySuffix = mapQueryWithParam(params.query);

  let apiEndPoint = `${baseUrl}${apiPath}${pathSuffix}${querySuffix}`;

  if (isDependencyMappingsConfigAvailable) {
    if (skipDependencyUrlMapping) {
      logger.trace(
        `Skipping dynamic dependency url mapping as skipDependencyUrlMapping flag is set to true in app-config.json`
      );
    } else {
      const downstreamApiBaseUrl = getDownstreamApiBaseUrl(
        downStreamServiceName,
        logger
      );
      if (downstreamApiBaseUrl) {
        apiEndPoint = `${downstreamApiBaseUrl}${apiPath}${pathSuffix}${querySuffix}`;
      }
    }
  }
  /**
    Process.env.MOCKS_ENABLED is set by deployment pipeline based on mockoon-data.json file.
    If its enabled, sidecar will be available with mocks.
    Verify if x-systemTest header is present or enableSystemTest is defined in app-config.json to support downstream mock
  **/
  if (process.env.MOCKS_ENABLED === 'True') {
    logger.trace(
      `MockoonMocks :: MOCKS_ENABLED flag is ${process.env.MOCKS_ENABLED}. Verifying if x-systemTest header or enableSystemTest flag is set.`
    );
    const isSystemTestEnabled = req.headers['x-systemtest'] === 'true';
    if (isSystemTestEnabled || enableSystemTest) {
      const mockoonUrl = mockoonBaseUrl || 'http://localhost:3010';
      apiEndPoint = `${mockoonUrl}${apiPath}${pathSuffix}${querySuffix}`;
      logger.trace(`MockoonMocks :: enabling component mock based on (${isSystemTestEnabled},${enableSystemTest}).
        Overriding the apiBaseUrl to ${mockoonUrl}`);
    }
  }

  logger.trace({
    payload: {
      message: `${expApiName}.DownstreamAPI.Start`,
      apiEndPoint,
      downStreamServiceName,
      operationId,
      originPath,
      requestMethod,
      requestPayload,
    },
  });

  /**
   * For document upload api which has multipart upload,
   * maxContentLength & maxBodyLength params should be added as part of config
   * Since the swagger is encoded using hex, we've to replace &#x2F; by /
   */

  let defaultConfigOptions = {};

  if (MULTIPART_TYPES.includes(consumes.replace('&#x2F;', '/'))) {
    defaultConfigOptions = {
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    };
  }

  const log = (data, message, level = 'debug') =>
    logger[level]({
      payload: {
        message,
        apiEndPoint,
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        data,
        defaultConfigOptions,
      },
    });

  const configValues = {
    ...requestPayload,
    ...defaultConfigOptions,
    method: requestMethod,
  };

  const request = {
    apiEndPoint,
    logger: log,
    configValues,
  };

  return fetchData(request);
};

/**
 * checkPaymentLimit - Check if the payment amount is within the allowed limit (transaction and daily limits).
 *
 * api : paymentLimitsServiceV1
 *
 * resource : /limit-check
 *
 * method : post
 *
 * @param {string} baseUrl - Baseurl for downstream api
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *                `header` - request header parameters
 *
 *                `path` -   request path parameters
 *
 *                `query` -  request query parameters
 *
 *                `body` -   request body
 *
 * @param {Object} apiConfig -  Configuration for request and response pertaining to the underlying API
 *
 *                `request` -  Request config for the underlying connection
 *
 *                `response` - Response config for the underlying connection
 *
 * @param {Object} req - The ExpressJS request object
 *
 * @param {Object} res - The ExpressJS response object
 *
 * @import { Limit-check } from "./types/paymentLimitsServiceV1"
 * @typedef {BaseResponse & {data: Limit-check.CheckPaymentLimit.ResponseBody}} CheckPaymentLimitResponse
 * @return {Promise<CheckPaymentLimitResponse>} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
const checkPaymentLimit = (baseUrl, params, apiConfig, req, res) => {
  const errors = [];
  const originPath = '/limit-check';
  const downStreamServiceName = 'payment-limits-service-v1';
  const requestMethod = 'post';
  const operationId = 'checkPaymentLimit';
  const consumes = '';

  const { logger, timeoutIn = 15000 } = res.locals;
  const {
    locals: { Config },
  } = res.app;
  const { skipDependencyUrlMapping, enableSystemTest, mockoonBaseUrl } =
    Config.get('app-config');

  if (!logger) {
    const error = {
      code: 10000,
      message: 'Internal Server Error',
      details: 'Please check application logs for details',
    };

    errors.push(error);

    res.status(500).json({ result: { errors } }).end();

    const exception = new TypeError(
      'Logging instance not found. Make sure the logger middleware is instantiated.',
      'Services.js',
      68
    );

    return Promise.reject(exception);
  }

  /**
   * [WDPUI-1714](https://jira.srv.westpac.com.au/browse/WDPUI-1714)
   *
   * Interpret the `role` claim as an array or string
   * but always return an array
   */
  const { USER_ROLES: roles } = res.locals;

  // Wrapped in try{}catch(){}
  // Since the entitlement enforcer throws,
  // we need a way to catch the error and gracefully
  // reject the promise
  try {
    logger.trace({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message: `Evaluating entitlements for '${roles}'`,
      },
    });

    const { allow, assumedRoles } = hasPermission(
      downStreamServiceName,
      originPath,
      requestMethod,
      params,
      roles
    );

    if (!allow) {
      const error = {
        code: 10003,
        message: 'Access denied.',
        details: 'You have not been provisioned to access this information',
      };

      errors.push(error);

      const message = `${roles} are not permitted to call ${operationId} on ${downStreamServiceName}`;
      logger.error({
        payload: {
          message,
          downStreamServiceName,
          operationId,
          originPath,
          requestMethod,
        },
      });

      res.status(403).json({ result: { errors } }).end();

      const exception = new Error(message);

      return Promise.reject(exception);
    }

    logger.trace(
      `South-edge entitlement check passed for ${operationId} on ${originPath} with assumed roles ${assumedRoles}`
    );
  } catch ({ type, message }) {
    const error = {
      code: 10004,
      message: 'Access denied',
      details: 'We are unable to verify your access provisions at this time',
    };

    errors.push(error);

    const errorDetails = `${type && `${type.toUpperCase()}:`} => ${message}`;

    logger.error({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message:
          'Entitlement policy not configured correctly for the application',
        details: errorDetails,
      },
    });

    res.status(403).json({ result: { errors } }).end();

    const exception = new Error(errorDetails);

    return Promise.reject(exception);
  }

  const requestPayload = mapStandardParams(params, apiConfig, timeoutIn, req);
  const pathSuffix = params.path
    ? mapPathWithParam(originPath, params.path)
    : originPath;
  const querySuffix = mapQueryWithParam(params.query);

  let apiEndPoint = `${baseUrl}${apiPath}${pathSuffix}${querySuffix}`;

  if (isDependencyMappingsConfigAvailable) {
    if (skipDependencyUrlMapping) {
      logger.trace(
        `Skipping dynamic dependency url mapping as skipDependencyUrlMapping flag is set to true in app-config.json`
      );
    } else {
      const downstreamApiBaseUrl = getDownstreamApiBaseUrl(
        downStreamServiceName,
        logger
      );
      if (downstreamApiBaseUrl) {
        apiEndPoint = `${downstreamApiBaseUrl}${apiPath}${pathSuffix}${querySuffix}`;
      }
    }
  }
  /**
    Process.env.MOCKS_ENABLED is set by deployment pipeline based on mockoon-data.json file.
    If its enabled, sidecar will be available with mocks.
    Verify if x-systemTest header is present or enableSystemTest is defined in app-config.json to support downstream mock
  **/
  if (process.env.MOCKS_ENABLED === 'True') {
    logger.trace(
      `MockoonMocks :: MOCKS_ENABLED flag is ${process.env.MOCKS_ENABLED}. Verifying if x-systemTest header or enableSystemTest flag is set.`
    );
    const isSystemTestEnabled = req.headers['x-systemtest'] === 'true';
    if (isSystemTestEnabled || enableSystemTest) {
      const mockoonUrl = mockoonBaseUrl || 'http://localhost:3010';
      apiEndPoint = `${mockoonUrl}${apiPath}${pathSuffix}${querySuffix}`;
      logger.trace(`MockoonMocks :: enabling component mock based on (${isSystemTestEnabled},${enableSystemTest}).
        Overriding the apiBaseUrl to ${mockoonUrl}`);
    }
  }

  logger.trace({
    payload: {
      message: `${expApiName}.DownstreamAPI.Start`,
      apiEndPoint,
      downStreamServiceName,
      operationId,
      originPath,
      requestMethod,
      requestPayload,
    },
  });

  /**
   * For document upload api which has multipart upload,
   * maxContentLength & maxBodyLength params should be added as part of config
   * Since the swagger is encoded using hex, we've to replace &#x2F; by /
   */

  let defaultConfigOptions = {};

  if (MULTIPART_TYPES.includes(consumes.replace('&#x2F;', '/'))) {
    defaultConfigOptions = {
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    };
  }

  const log = (data, message, level = 'debug') =>
    logger[level]({
      payload: {
        message,
        apiEndPoint,
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        data,
        defaultConfigOptions,
      },
    });

  const configValues = {
    ...requestPayload,
    ...defaultConfigOptions,
    method: requestMethod,
  };

  const request = {
    apiEndPoint,
    logger: log,
    configValues,
  };

  return fetchData(request);
};

/**
 * verifyPaymentLimitCheck - Verify if payment limit check has previously done for the given instruction id.
 *
 * api : paymentLimitsServiceV1
 *
 * resource : /limit-check/verify/{instructionIdentification}
 *
 * method : get
 *
 * @param {string} baseUrl - Baseurl for downstream api
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *                `header` - request header parameters
 *
 *                `path` -   request path parameters
 *
 *                `query` -  request query parameters
 *
 *                `body` -   request body
 *
 * @param {Object} apiConfig -  Configuration for request and response pertaining to the underlying API
 *
 *                `request` -  Request config for the underlying connection
 *
 *                `response` - Response config for the underlying connection
 *
 * @param {Object} req - The ExpressJS request object
 *
 * @param {Object} res - The ExpressJS response object
 *
 * @import { Limit-checkverify } from "./types/paymentLimitsServiceV1"
 * @typedef {BaseResponse & {data: Limit-checkverify.VerifyPaymentLimitCheck.ResponseBody}} VerifyPaymentLimitCheckResponse
 * @return {Promise<VerifyPaymentLimitCheckResponse>} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
const verifyPaymentLimitCheck = (baseUrl, params, apiConfig, req, res) => {
  const errors = [];
  const originPath = '/limit-check/verify/{instructionIdentification}';
  const downStreamServiceName = 'payment-limits-service-v1';
  const requestMethod = 'get';
  const operationId = 'verifyPaymentLimitCheck';
  const consumes = '';

  const { logger, timeoutIn = 15000 } = res.locals;
  const {
    locals: { Config },
  } = res.app;
  const { skipDependencyUrlMapping, enableSystemTest, mockoonBaseUrl } =
    Config.get('app-config');

  if (!logger) {
    const error = {
      code: 10000,
      message: 'Internal Server Error',
      details: 'Please check application logs for details',
    };

    errors.push(error);

    res.status(500).json({ result: { errors } }).end();

    const exception = new TypeError(
      'Logging instance not found. Make sure the logger middleware is instantiated.',
      'Services.js',
      68
    );

    return Promise.reject(exception);
  }

  /**
   * [WDPUI-1714](https://jira.srv.westpac.com.au/browse/WDPUI-1714)
   *
   * Interpret the `role` claim as an array or string
   * but always return an array
   */
  const { USER_ROLES: roles } = res.locals;

  // Wrapped in try{}catch(){}
  // Since the entitlement enforcer throws,
  // we need a way to catch the error and gracefully
  // reject the promise
  try {
    logger.trace({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message: `Evaluating entitlements for '${roles}'`,
      },
    });

    const { allow, assumedRoles } = hasPermission(
      downStreamServiceName,
      originPath,
      requestMethod,
      params,
      roles
    );

    if (!allow) {
      const error = {
        code: 10003,
        message: 'Access denied.',
        details: 'You have not been provisioned to access this information',
      };

      errors.push(error);

      const message = `${roles} are not permitted to call ${operationId} on ${downStreamServiceName}`;
      logger.error({
        payload: {
          message,
          downStreamServiceName,
          operationId,
          originPath,
          requestMethod,
        },
      });

      res.status(403).json({ result: { errors } }).end();

      const exception = new Error(message);

      return Promise.reject(exception);
    }

    logger.trace(
      `South-edge entitlement check passed for ${operationId} on ${originPath} with assumed roles ${assumedRoles}`
    );
  } catch ({ type, message }) {
    const error = {
      code: 10004,
      message: 'Access denied',
      details: 'We are unable to verify your access provisions at this time',
    };

    errors.push(error);

    const errorDetails = `${type && `${type.toUpperCase()}:`} => ${message}`;

    logger.error({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message:
          'Entitlement policy not configured correctly for the application',
        details: errorDetails,
      },
    });

    res.status(403).json({ result: { errors } }).end();

    const exception = new Error(errorDetails);

    return Promise.reject(exception);
  }

  const requestPayload = mapStandardParams(params, apiConfig, timeoutIn, req);
  const pathSuffix = params.path
    ? mapPathWithParam(originPath, params.path)
    : originPath;
  const querySuffix = mapQueryWithParam(params.query);

  let apiEndPoint = `${baseUrl}${apiPath}${pathSuffix}${querySuffix}`;

  if (isDependencyMappingsConfigAvailable) {
    if (skipDependencyUrlMapping) {
      logger.trace(
        `Skipping dynamic dependency url mapping as skipDependencyUrlMapping flag is set to true in app-config.json`
      );
    } else {
      const downstreamApiBaseUrl = getDownstreamApiBaseUrl(
        downStreamServiceName,
        logger
      );
      if (downstreamApiBaseUrl) {
        apiEndPoint = `${downstreamApiBaseUrl}${apiPath}${pathSuffix}${querySuffix}`;
      }
    }
  }
  /**
    Process.env.MOCKS_ENABLED is set by deployment pipeline based on mockoon-data.json file.
    If its enabled, sidecar will be available with mocks.
    Verify if x-systemTest header is present or enableSystemTest is defined in app-config.json to support downstream mock
  **/
  if (process.env.MOCKS_ENABLED === 'True') {
    logger.trace(
      `MockoonMocks :: MOCKS_ENABLED flag is ${process.env.MOCKS_ENABLED}. Verifying if x-systemTest header or enableSystemTest flag is set.`
    );
    const isSystemTestEnabled = req.headers['x-systemtest'] === 'true';
    if (isSystemTestEnabled || enableSystemTest) {
      const mockoonUrl = mockoonBaseUrl || 'http://localhost:3010';
      apiEndPoint = `${mockoonUrl}${apiPath}${pathSuffix}${querySuffix}`;
      logger.trace(`MockoonMocks :: enabling component mock based on (${isSystemTestEnabled},${enableSystemTest}).
        Overriding the apiBaseUrl to ${mockoonUrl}`);
    }
  }

  logger.trace({
    payload: {
      message: `${expApiName}.DownstreamAPI.Start`,
      apiEndPoint,
      downStreamServiceName,
      operationId,
      originPath,
      requestMethod,
      requestPayload,
    },
  });

  /**
   * For document upload api which has multipart upload,
   * maxContentLength & maxBodyLength params should be added as part of config
   * Since the swagger is encoded using hex, we've to replace &#x2F; by /
   */

  let defaultConfigOptions = {};

  if (MULTIPART_TYPES.includes(consumes.replace('&#x2F;', '/'))) {
    defaultConfigOptions = {
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    };
  }

  const log = (data, message, level = 'debug') =>
    logger[level]({
      payload: {
        message,
        apiEndPoint,
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        data,
        defaultConfigOptions,
      },
    });

  const configValues = {
    ...requestPayload,
    ...defaultConfigOptions,
    method: requestMethod,
  };

  const request = {
    apiEndPoint,
    logger: log,
    configValues,
  };

  return fetchData(request);
};

/**
 * cleanupLimitCheckHistory - Cleans up limit check history older than configured days
 *
 * api : paymentLimitsServiceV1
 *
 * resource : /scheduled/maintenance/limit-check-history/cleanup
 *
 * method : post
 *
 * @param {string} baseUrl - Baseurl for downstream api
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *                `header` - request header parameters
 *
 *                `path` -   request path parameters
 *
 *                `query` -  request query parameters
 *
 *                `body` -   request body
 *
 * @param {Object} apiConfig -  Configuration for request and response pertaining to the underlying API
 *
 *                `request` -  Request config for the underlying connection
 *
 *                `response` - Response config for the underlying connection
 *
 * @param {Object} req - The ExpressJS request object
 *
 * @param {Object} res - The ExpressJS response object
 *
 * @import { Scheduledmaintenancelimit-check-historycleanup } from "./types/paymentLimitsServiceV1"
 * @typedef {BaseResponse & {data: Scheduledmaintenancelimit-check-historycleanup.CleanupLimitCheckHistory.ResponseBody}} CleanupLimitCheckHistoryResponse
 * @return {Promise<CleanupLimitCheckHistoryResponse>} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
const cleanupLimitCheckHistory = (baseUrl, params, apiConfig, req, res) => {
  const errors = [];
  const originPath = '/scheduled/maintenance/limit-check-history/cleanup';
  const downStreamServiceName = 'payment-limits-service-v1';
  const requestMethod = 'post';
  const operationId = 'cleanupLimitCheckHistory';
  const consumes = '';

  const { logger, timeoutIn = 15000 } = res.locals;
  const {
    locals: { Config },
  } = res.app;
  const { skipDependencyUrlMapping, enableSystemTest, mockoonBaseUrl } =
    Config.get('app-config');

  if (!logger) {
    const error = {
      code: 10000,
      message: 'Internal Server Error',
      details: 'Please check application logs for details',
    };

    errors.push(error);

    res.status(500).json({ result: { errors } }).end();

    const exception = new TypeError(
      'Logging instance not found. Make sure the logger middleware is instantiated.',
      'Services.js',
      68
    );

    return Promise.reject(exception);
  }

  /**
   * [WDPUI-1714](https://jira.srv.westpac.com.au/browse/WDPUI-1714)
   *
   * Interpret the `role` claim as an array or string
   * but always return an array
   */
  const { USER_ROLES: roles } = res.locals;

  // Wrapped in try{}catch(){}
  // Since the entitlement enforcer throws,
  // we need a way to catch the error and gracefully
  // reject the promise
  try {
    logger.trace({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message: `Evaluating entitlements for '${roles}'`,
      },
    });

    const { allow, assumedRoles } = hasPermission(
      downStreamServiceName,
      originPath,
      requestMethod,
      params,
      roles
    );

    if (!allow) {
      const error = {
        code: 10003,
        message: 'Access denied.',
        details: 'You have not been provisioned to access this information',
      };

      errors.push(error);

      const message = `${roles} are not permitted to call ${operationId} on ${downStreamServiceName}`;
      logger.error({
        payload: {
          message,
          downStreamServiceName,
          operationId,
          originPath,
          requestMethod,
        },
      });

      res.status(403).json({ result: { errors } }).end();

      const exception = new Error(message);

      return Promise.reject(exception);
    }

    logger.trace(
      `South-edge entitlement check passed for ${operationId} on ${originPath} with assumed roles ${assumedRoles}`
    );
  } catch ({ type, message }) {
    const error = {
      code: 10004,
      message: 'Access denied',
      details: 'We are unable to verify your access provisions at this time',
    };

    errors.push(error);

    const errorDetails = `${type && `${type.toUpperCase()}:`} => ${message}`;

    logger.error({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message:
          'Entitlement policy not configured correctly for the application',
        details: errorDetails,
      },
    });

    res.status(403).json({ result: { errors } }).end();

    const exception = new Error(errorDetails);

    return Promise.reject(exception);
  }

  const requestPayload = mapStandardParams(params, apiConfig, timeoutIn, req);
  const pathSuffix = params.path
    ? mapPathWithParam(originPath, params.path)
    : originPath;
  const querySuffix = mapQueryWithParam(params.query);

  let apiEndPoint = `${baseUrl}${apiPath}${pathSuffix}${querySuffix}`;

  if (isDependencyMappingsConfigAvailable) {
    if (skipDependencyUrlMapping) {
      logger.trace(
        `Skipping dynamic dependency url mapping as skipDependencyUrlMapping flag is set to true in app-config.json`
      );
    } else {
      const downstreamApiBaseUrl = getDownstreamApiBaseUrl(
        downStreamServiceName,
        logger
      );
      if (downstreamApiBaseUrl) {
        apiEndPoint = `${downstreamApiBaseUrl}${apiPath}${pathSuffix}${querySuffix}`;
      }
    }
  }
  /**
    Process.env.MOCKS_ENABLED is set by deployment pipeline based on mockoon-data.json file.
    If its enabled, sidecar will be available with mocks.
    Verify if x-systemTest header is present or enableSystemTest is defined in app-config.json to support downstream mock
  **/
  if (process.env.MOCKS_ENABLED === 'True') {
    logger.trace(
      `MockoonMocks :: MOCKS_ENABLED flag is ${process.env.MOCKS_ENABLED}. Verifying if x-systemTest header or enableSystemTest flag is set.`
    );
    const isSystemTestEnabled = req.headers['x-systemtest'] === 'true';
    if (isSystemTestEnabled || enableSystemTest) {
      const mockoonUrl = mockoonBaseUrl || 'http://localhost:3010';
      apiEndPoint = `${mockoonUrl}${apiPath}${pathSuffix}${querySuffix}`;
      logger.trace(`MockoonMocks :: enabling component mock based on (${isSystemTestEnabled},${enableSystemTest}).
        Overriding the apiBaseUrl to ${mockoonUrl}`);
    }
  }

  logger.trace({
    payload: {
      message: `${expApiName}.DownstreamAPI.Start`,
      apiEndPoint,
      downStreamServiceName,
      operationId,
      originPath,
      requestMethod,
      requestPayload,
    },
  });

  /**
   * For document upload api which has multipart upload,
   * maxContentLength & maxBodyLength params should be added as part of config
   * Since the swagger is encoded using hex, we've to replace &#x2F; by /
   */

  let defaultConfigOptions = {};

  if (MULTIPART_TYPES.includes(consumes.replace('&#x2F;', '/'))) {
    defaultConfigOptions = {
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    };
  }

  const log = (data, message, level = 'debug') =>
    logger[level]({
      payload: {
        message,
        apiEndPoint,
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        data,
        defaultConfigOptions,
      },
    });

  const configValues = {
    ...requestPayload,
    ...defaultConfigOptions,
    method: requestMethod,
  };

  const request = {
    apiEndPoint,
    logger: log,
    configValues,
  };

  return fetchData(request);
};

/**
 * resetLimits - Resets the organisation channel daily limits and user daily limits to their original values at the start of each day.
 *
 * api : paymentLimitsServiceV1
 *
 * resource : /scheduled/maintenance/limits-reset
 *
 * method : post
 *
 * @param {string} baseUrl - Baseurl for downstream api
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *                `header` - request header parameters
 *
 *                `path` -   request path parameters
 *
 *                `query` -  request query parameters
 *
 *                `body` -   request body
 *
 * @param {Object} apiConfig -  Configuration for request and response pertaining to the underlying API
 *
 *                `request` -  Request config for the underlying connection
 *
 *                `response` - Response config for the underlying connection
 *
 * @param {Object} req - The ExpressJS request object
 *
 * @param {Object} res - The ExpressJS response object
 *
 * @import { Scheduledmaintenancelimits-reset } from "./types/paymentLimitsServiceV1"
 * @typedef {BaseResponse & {data: Scheduledmaintenancelimits-reset.ResetLimits.ResponseBody}} ResetLimitsResponse
 * @return {Promise<ResetLimitsResponse>} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
const resetLimits = (baseUrl, params, apiConfig, req, res) => {
  const errors = [];
  const originPath = '/scheduled/maintenance/limits-reset';
  const downStreamServiceName = 'payment-limits-service-v1';
  const requestMethod = 'post';
  const operationId = 'resetLimits';
  const consumes = '';

  const { logger, timeoutIn = 15000 } = res.locals;
  const {
    locals: { Config },
  } = res.app;
  const { skipDependencyUrlMapping, enableSystemTest, mockoonBaseUrl } =
    Config.get('app-config');

  if (!logger) {
    const error = {
      code: 10000,
      message: 'Internal Server Error',
      details: 'Please check application logs for details',
    };

    errors.push(error);

    res.status(500).json({ result: { errors } }).end();

    const exception = new TypeError(
      'Logging instance not found. Make sure the logger middleware is instantiated.',
      'Services.js',
      68
    );

    return Promise.reject(exception);
  }

  /**
   * [WDPUI-1714](https://jira.srv.westpac.com.au/browse/WDPUI-1714)
   *
   * Interpret the `role` claim as an array or string
   * but always return an array
   */
  const { USER_ROLES: roles } = res.locals;

  // Wrapped in try{}catch(){}
  // Since the entitlement enforcer throws,
  // we need a way to catch the error and gracefully
  // reject the promise
  try {
    logger.trace({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message: `Evaluating entitlements for '${roles}'`,
      },
    });

    const { allow, assumedRoles } = hasPermission(
      downStreamServiceName,
      originPath,
      requestMethod,
      params,
      roles
    );

    if (!allow) {
      const error = {
        code: 10003,
        message: 'Access denied.',
        details: 'You have not been provisioned to access this information',
      };

      errors.push(error);

      const message = `${roles} are not permitted to call ${operationId} on ${downStreamServiceName}`;
      logger.error({
        payload: {
          message,
          downStreamServiceName,
          operationId,
          originPath,
          requestMethod,
        },
      });

      res.status(403).json({ result: { errors } }).end();

      const exception = new Error(message);

      return Promise.reject(exception);
    }

    logger.trace(
      `South-edge entitlement check passed for ${operationId} on ${originPath} with assumed roles ${assumedRoles}`
    );
  } catch ({ type, message }) {
    const error = {
      code: 10004,
      message: 'Access denied',
      details: 'We are unable to verify your access provisions at this time',
    };

    errors.push(error);

    const errorDetails = `${type && `${type.toUpperCase()}:`} => ${message}`;

    logger.error({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message:
          'Entitlement policy not configured correctly for the application',
        details: errorDetails,
      },
    });

    res.status(403).json({ result: { errors } }).end();

    const exception = new Error(errorDetails);

    return Promise.reject(exception);
  }

  const requestPayload = mapStandardParams(params, apiConfig, timeoutIn, req);
  const pathSuffix = params.path
    ? mapPathWithParam(originPath, params.path)
    : originPath;
  const querySuffix = mapQueryWithParam(params.query);

  let apiEndPoint = `${baseUrl}${apiPath}${pathSuffix}${querySuffix}`;

  if (isDependencyMappingsConfigAvailable) {
    if (skipDependencyUrlMapping) {
      logger.trace(
        `Skipping dynamic dependency url mapping as skipDependencyUrlMapping flag is set to true in app-config.json`
      );
    } else {
      const downstreamApiBaseUrl = getDownstreamApiBaseUrl(
        downStreamServiceName,
        logger
      );
      if (downstreamApiBaseUrl) {
        apiEndPoint = `${downstreamApiBaseUrl}${apiPath}${pathSuffix}${querySuffix}`;
      }
    }
  }
  /**
    Process.env.MOCKS_ENABLED is set by deployment pipeline based on mockoon-data.json file.
    If its enabled, sidecar will be available with mocks.
    Verify if x-systemTest header is present or enableSystemTest is defined in app-config.json to support downstream mock
  **/
  if (process.env.MOCKS_ENABLED === 'True') {
    logger.trace(
      `MockoonMocks :: MOCKS_ENABLED flag is ${process.env.MOCKS_ENABLED}. Verifying if x-systemTest header or enableSystemTest flag is set.`
    );
    const isSystemTestEnabled = req.headers['x-systemtest'] === 'true';
    if (isSystemTestEnabled || enableSystemTest) {
      const mockoonUrl = mockoonBaseUrl || 'http://localhost:3010';
      apiEndPoint = `${mockoonUrl}${apiPath}${pathSuffix}${querySuffix}`;
      logger.trace(`MockoonMocks :: enabling component mock based on (${isSystemTestEnabled},${enableSystemTest}).
        Overriding the apiBaseUrl to ${mockoonUrl}`);
    }
  }

  logger.trace({
    payload: {
      message: `${expApiName}.DownstreamAPI.Start`,
      apiEndPoint,
      downStreamServiceName,
      operationId,
      originPath,
      requestMethod,
      requestPayload,
    },
  });

  /**
   * For document upload api which has multipart upload,
   * maxContentLength & maxBodyLength params should be added as part of config
   * Since the swagger is encoded using hex, we've to replace &#x2F; by /
   */

  let defaultConfigOptions = {};

  if (MULTIPART_TYPES.includes(consumes.replace('&#x2F;', '/'))) {
    defaultConfigOptions = {
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    };
  }

  const log = (data, message, level = 'debug') =>
    logger[level]({
      payload: {
        message,
        apiEndPoint,
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        data,
        defaultConfigOptions,
      },
    });

  const configValues = {
    ...requestPayload,
    ...defaultConfigOptions,
    method: requestMethod,
  };

  const request = {
    apiEndPoint,
    logger: log,
    configValues,
  };

  return fetchData(request);
};

module.exports = {
  getLimitRules,
  createLimitRule,
  updateLimitRule,
  checkPaymentLimit,
  verifyPaymentLimitCheck,
  cleanupLimitCheckHistory,
  resetLimits,
};
