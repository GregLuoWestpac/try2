const {
  mapPathWithParam,
  mapQueryWithParam,
  mapStandardParams,
  fetchData,
  MULTIPART_TYPES,
  getDownstreamApiBaseUrl,
  isDependencyMappingsConfigAvailable,
} = require('./common');

const { hasPermission } = require('./entitlement');

const apiPath = '/cap/prodsvcfulflmnt/pymntprocsng/pymntinit/v2';
const expApiName = 'payment';

/**
 * @typedef {Object} BaseResponse
 * @prop {number} status - HTTP status code
 * @prop {string} statusText - HTTP status text
 * @prop {any} headers - HTTP headers
 * @prop {boolean} ok - Indicates if the response is successful
 * @prop {boolean} empty - Indicates if the response is empty
 */

/**
 * paymentSubmission - Submits payment instructions for further processing.
 *
 * api : capProdsvcfulflmntPymntprocsngPymntinitV2
 *
 * resource : /payment
 *
 * method : post
 *
 * @param {string} baseUrl - Baseurl for downstream api
 * @param {Object} params - Request parameters to be propagated to the underlying API
 *
 *                `header` - request header parameters
 *
 *                `path` -   request path parameters
 *
 *                `query` -  request query parameters
 *
 *                `body` -   request body
 *
 * @param {Object} apiConfig -  Configuration for request and response pertaining to the underlying API
 *
 *                `request` -  Request config for the underlying connection
 *
 *                `response` - Response config for the underlying connection
 *
 * @param {Object} req - The ExpressJS request object
 *
 * @param {Object} res - The ExpressJS response object
 *
 * @import { Payment } from "./types/capProdsvcfulflmntPymntprocsngPymntinitV2"
 * @typedef {BaseResponse & {data: Payment.PaymentSubmission.ResponseBody}} PaymentSubmissionResponse
 * @return {Promise<PaymentSubmissionResponse>} - Resolved with `{ ...response, ok, empty }` or rejected with `{ type, error }`
 */
const paymentSubmission = (baseUrl, params, apiConfig, req, res) => {
  const errors = [];
  const originPath = '/payment';
  const downStreamServiceName = 'cap-prodsvcfulflmnt-pymntprocsng-pymntinit-v2';
  const requestMethod = 'post';
  const operationId = 'paymentSubmission';
  const consumes = '';

  const { logger, timeoutIn = 15000 } = res.locals;
  const {
    locals: { Config },
  } = res.app;
  const { skipDependencyUrlMapping, enableSystemTest, mockoonBaseUrl } =
    Config.get('app-config');

  if (!logger) {
    const error = {
      code: 10000,
      message: 'Internal Server Error',
      details: 'Please check application logs for details',
    };

    errors.push(error);

    res.status(500).json({ result: { errors } }).end();

    const exception = new TypeError(
      'Logging instance not found. Make sure the logger middleware is instantiated.',
      'Services.js',
      68
    );

    return Promise.reject(exception);
  }

  /**
   * [WDPUI-1714](https://jira.srv.westpac.com.au/browse/WDPUI-1714)
   *
   * Interpret the `role` claim as an array or string
   * but always return an array
   */
  const { USER_ROLES: roles } = res.locals;

  // Wrapped in try{}catch(){}
  // Since the entitlement enforcer throws,
  // we need a way to catch the error and gracefully
  // reject the promise
  try {
    logger.trace({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message: `Evaluating entitlements for '${roles}'`,
      },
    });

    const { allow, assumedRoles } = hasPermission(
      downStreamServiceName,
      originPath,
      requestMethod,
      params,
      roles
    );

    if (!allow) {
      const error = {
        code: 10003,
        message: 'Access denied.',
        details: 'You have not been provisioned to access this information',
      };

      errors.push(error);

      const message = `${roles} are not permitted to call ${operationId} on ${downStreamServiceName}`;
      logger.error({
        payload: {
          message,
          downStreamServiceName,
          operationId,
          originPath,
          requestMethod,
        },
      });

      res.status(403).json({ result: { errors } }).end();

      const exception = new Error(message);

      return Promise.reject(exception);
    }

    logger.trace(
      `South-edge entitlement check passed for ${operationId} on ${originPath} with assumed roles ${assumedRoles}`
    );
  } catch ({ type, message }) {
    const error = {
      code: 10004,
      message: 'Access denied',
      details: 'We are unable to verify your access provisions at this time',
    };

    errors.push(error);

    const errorDetails = `${type && `${type.toUpperCase()}:`} => ${message}`;

    logger.error({
      payload: {
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        message:
          'Entitlement policy not configured correctly for the application',
        details: errorDetails,
      },
    });

    res.status(403).json({ result: { errors } }).end();

    const exception = new Error(errorDetails);

    return Promise.reject(exception);
  }

  const requestPayload = mapStandardParams(params, apiConfig, timeoutIn, req);
  const pathSuffix = params.path
    ? mapPathWithParam(originPath, params.path)
    : originPath;
  const querySuffix = mapQueryWithParam(params.query);

  let apiEndPoint = `${baseUrl}${apiPath}${pathSuffix}${querySuffix}`;

  if (isDependencyMappingsConfigAvailable) {
    if (skipDependencyUrlMapping) {
      logger.trace(
        `Skipping dynamic dependency url mapping as skipDependencyUrlMapping flag is set to true in app-config.json`
      );
    } else {
      const downstreamApiBaseUrl = getDownstreamApiBaseUrl(
        downStreamServiceName,
        logger
      );
      if (downstreamApiBaseUrl) {
        apiEndPoint = `${downstreamApiBaseUrl}${apiPath}${pathSuffix}${querySuffix}`;
      }
    }
  }
  /**
    Process.env.MOCKS_ENABLED is set by deployment pipeline based on mockoon-data.json file.
    If its enabled, sidecar will be available with mocks.
    Verify if x-systemTest header is present or enableSystemTest is defined in app-config.json to support downstream mock
  **/
  if (process.env.MOCKS_ENABLED === 'True') {
    logger.trace(
      `MockoonMocks :: MOCKS_ENABLED flag is ${process.env.MOCKS_ENABLED}. Verifying if x-systemTest header or enableSystemTest flag is set.`
    );
    const isSystemTestEnabled = req.headers['x-systemtest'] === 'true';
    if (isSystemTestEnabled || enableSystemTest) {
      const mockoonUrl = mockoonBaseUrl || 'http://localhost:3010';
      apiEndPoint = `${mockoonUrl}${apiPath}${pathSuffix}${querySuffix}`;
      logger.trace(`MockoonMocks :: enabling component mock based on (${isSystemTestEnabled},${enableSystemTest}).
        Overriding the apiBaseUrl to ${mockoonUrl}`);
    }
  }

  logger.trace({
    payload: {
      message: `${expApiName}.DownstreamAPI.Start`,
      apiEndPoint,
      downStreamServiceName,
      operationId,
      originPath,
      requestMethod,
      requestPayload,
    },
  });

  /**
   * For document upload api which has multipart upload,
   * maxContentLength & maxBodyLength params should be added as part of config
   * Since the swagger is encoded using hex, we've to replace &#x2F; by /
   */

  let defaultConfigOptions = {};

  if (MULTIPART_TYPES.includes(consumes.replace('&#x2F;', '/'))) {
    defaultConfigOptions = {
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    };
  }

  const log = (data, message, level = 'debug') =>
    logger[level]({
      payload: {
        message,
        apiEndPoint,
        operationId,
        requestMethod,
        downStreamServiceName,
        originPath,
        data,
        defaultConfigOptions,
      },
    });
  const { signal } = res.locals;
  const configValues = {
    ...requestPayload,
    ...defaultConfigOptions,
    method: requestMethod,
    signal,
  };

  const request = {
    apiEndPoint,
    logger: log,
    configValues,
  };

  return fetchData(request);
};

module.exports = {
  paymentSubmission,
};
