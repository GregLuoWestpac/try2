const capProdsvcadmProddealacctadmInstlArrngmntsvcngV1Services = require('./capProdsvcadmProddealacctadmInstlArrngmntsvcngV1Services');
const capProdsvcfulflmntPymntprocsngPymntinitV1Services = require('./capProdsvcfulflmntPymntprocsngPymntinitV1Services');
const infBnkngEvntPymntevntInstlPymntevntV1Services = require('./infBnkngEvntPymntevntInstlPymntevntV1Services');
const paymentAliasResolutionV2Services = require('./paymentAliasResolutionV2Services');
const paymentSchemeEligibilityV1Services = require('./paymentSchemeEligibilityV1Services');
const beneficiaryManagementV1Services = require('./beneficiaryManagementV1Services');
const paymentLimitsServiceV1Services = require('./paymentLimitsServiceV1Services');
const customerPaymentInstructionIdV1Services = require('./customerPaymentInstructionIdV1Services');
const channelPaymentUtilsV1Services = require('./channelPaymentUtilsV1Services');
const infBnkngChnlBrchntwkV2Services = require('./infBnkngChnlBrchntwkV2Services');
const capCustsvcmgtCustsecyverifctnAdaptvauthV2Services = require('./capCustsvcmgtCustsecyverifctnAdaptvauthV2Services');
const capProdsvcfulflmntPymntprocsngPymntinitV2Services = require('./capProdsvcfulflmntPymntprocsngPymntinitV2Services');
const paymentReturnV1Services = require('./paymentReturnV1Services');
const payeeServicesV1Services = require('./payeeServicesV1Services');
const userAuthorisationPolicyDecisionEngineApiV1Services = require('./userAuthorisationPolicyDecisionEngineApiV1Services');

module.exports = {
  capProdsvcadmProddealacctadmInstlArrngmntsvcngV1Services,
  capProdsvcfulflmntPymntprocsngPymntinitV1Services,
  infBnkngEvntPymntevntInstlPymntevntV1Services,
  paymentAliasResolutionV2Services,
  paymentSchemeEligibilityV1Services,
  beneficiaryManagementV1Services,
  paymentLimitsServiceV1Services,
  customerPaymentInstructionIdV1Services,
  channelPaymentUtilsV1Services,
  infBnkngChnlBrchntwkV2Services,
  capCustsvcmgtCustsecyverifctnAdaptvauthV2Services,
  capProdsvcfulflmntPymntprocsngPymntinitV2Services,
  paymentReturnV1Services,
  payeeServicesV1Services,
  userAuthorisationPolicyDecisionEngineApiV1Services,
};
