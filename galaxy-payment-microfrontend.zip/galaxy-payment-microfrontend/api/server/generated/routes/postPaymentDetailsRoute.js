const {
  get,
  isEmpty,
  isFunction,
  startsWith,
  differenceWith,
} = require('lodash');
const timeout = require('connect-timeout');

const {
  getRouteLoggerMiddleware,
  getEntitlementMiddleWare,
  getHaltOnTimedOutMiddleware,
  getAbortOnTimeoutMiddleware,
} = require('./common');

let controller = require('../../api/controllers/postPaymentDetailsController');
let handlers = require('../../api/handlers');

controller = controller.__esModule ? controller.default : controller;
handlers = handlers.__esModule ? handlers.default : handlers;

/**
 * Operation id : postPaymentDetails
 * Function to get expressjs route function
 * ie : app.use(postPaymentDetailsRoute(basePath, app, ctrl, validator));
 *
 * @param {string} basePath - Base path for current api
 * @param {object} app - Express server instance
 * @returns {function} Generated route function for end point /paymentDetails
 */

const postPaymentDetailsRoute = (basePath, app) => {
  const { Config } = app.locals;
  const timeoutConfig = Config.get(`app-config.timeouts`);

  const urlBasePath = `${basePath}/paymentDetails`;

  const beforeAll = handlers.reduce(
    (acc, current) =>
      (startsWith(current.name, 'beforeAll') && [...acc, current]) || acc,
    []
  );

  const afterAll = handlers.reduce(
    (acc, current) =>
      (startsWith(current.name, 'afterAll') && [...acc, current]) || acc,
    []
  );

  const others = differenceWith(handlers, [...beforeAll, ...afterAll]);

  /**
   * The value of the timeout configured under the appConfig
   * `timeouts` key for the experience API resource.
   *
   * Default to 15 seconds if no configuration is found
   * Timeout values need to configured on a per resource
   * basis which would need to go through some form of
   * governance
   */
  const timeoutIn = get(timeoutConfig, '/paymentDetails', 15000);

  const middleware = [];

  if (!isEmpty(beforeAll)) {
    middleware.push(beforeAll);
  }

  middleware.push(
    getEntitlementMiddleWare('postPaymentDetails', '/paymentDetails', 'post'),
    getRouteLoggerMiddleware('postPaymentDetails', urlBasePath, 'post'),
    timeout(timeoutIn),
    getHaltOnTimedOutMiddleware('/paymentDetails', timeoutIn)
  );

  if (!isEmpty(others)) {
    middleware.push(others);
  }

  if (isFunction(controller)) {
    middleware.push(controller);
  } else {
    throw new Error(`Controller is not function : ${controller}`);
  }
  middleware.push(getAbortOnTimeoutMiddleware('/paymentDetails', timeoutIn));
  if (!isEmpty(afterAll)) {
    middleware.push(afterAll);
  }

  app.post(urlBasePath, middleware);
};

module.exports = postPaymentDetailsRoute;
