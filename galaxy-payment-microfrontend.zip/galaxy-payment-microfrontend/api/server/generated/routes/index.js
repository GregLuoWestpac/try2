const getHealthCheckStatusRoute = require('./getHealthCheckStatusRoute');
const getArrangementsRoute = require('./getArrangementsRoute');
const paymentCreateRoute = require('./paymentCreateRoute');
const postPaymentReturnsRoute = require('./postPaymentReturnsRoute');
const postPaymentDetailsRoute = require('./postPaymentDetailsRoute');
const postPaymentListingRoute = require('./postPaymentListingRoute');
const postAliasLookupRoute = require('./postAliasLookupRoute');
const postAliasLookupByBeneIdRoute = require('./postAliasLookupByBeneIdRoute');
const postSchemeEligibilitiesRoute = require('./postSchemeEligibilitiesRoute');
const getGeneratePaymentIdentifierRoute = require('./getGeneratePaymentIdentifierRoute');
const retrieveBeneficiariesRoute = require('./retrieveBeneficiariesRoute');
const getPaymentLimitsRoute = require('./getPaymentLimitsRoute');
const postValidatePaymentLimitsRoute = require('./postValidatePaymentLimitsRoute');
const postArrangementDetailsRoute = require('./postArrangementDetailsRoute');
const getAccountListRoute = require('./getAccountListRoute');
const createBeneficiariesRoute = require('./createBeneficiariesRoute');
const postPaymentCreateForNewBeneficiaryRoute = require('./postPaymentCreateForNewBeneficiaryRoute');
const getBsbLookupRoute = require('./getBsbLookupRoute');
const getDivisionListRoute = require('./getDivisionListRoute');
const postTransferCreateRoute = require('./postTransferCreateRoute');
const postAccountNameCheckRoute = require('./postAccountNameCheckRoute');

module.exports = {
  getHealthCheckStatusRoute,
  getArrangementsRoute,
  paymentCreateRoute,
  postPaymentReturnsRoute,
  postPaymentDetailsRoute,
  postPaymentListingRoute,
  postAliasLookupRoute,
  postAliasLookupByBeneIdRoute,
  postSchemeEligibilitiesRoute,
  getGeneratePaymentIdentifierRoute,
  retrieveBeneficiariesRoute,
  getPaymentLimitsRoute,
  postValidatePaymentLimitsRoute,
  postArrangementDetailsRoute,
  getAccountListRoute,
  createBeneficiariesRoute,
  postPaymentCreateForNewBeneficiaryRoute,
  getBsbLookupRoute,
  getDivisionListRoute,
  postTransferCreateRoute,
  postAccountNameCheckRoute,
};
