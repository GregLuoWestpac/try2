import { Response } from 'express';
import {
  setParamsForGetPayees,
  setParamsForPostArrangements,
  setParamsForPostPayments,
  setParamsForPaymentIdentifierGenerator,
  setParamsForPaymentDetails,
  setParamsForPostPaymentReturns,
  setParamsForPostPaymentDetails,
} from './setParams';
import { AppConfig } from '../../interfaces/models/common';
import { ApiHeaders } from '../../interfaces/types';
import {
  AliasType,
  ExpPostAliasLookupRequestbody,
} from '../../interfaces/models/AliasLookup';
import { ARRANGEMENT_STATUS } from './enums';

describe('setParams For the endpoints', () => {
  const inputHeaders = {
    'Content-Type': 'application/json',
    'x-originatingBSB': '112879',
  };
  const res = {
    locals: {
      BSB: '112879',
      brandSilo: 'WPAC',
    },
  } as Response;
  const mockedAppConfig = {
    appName: 'Galaxy Payment API Project',
    appId: 'com.westpac.expapi.galaxy',
    appBasePath: '/exp/galaxy/payment/v2',
    originatingSystemId: 'A014A6',
    originatingBSB: '112-879',
    consumerType: 'Customer',
    customerType: 'Organisation',
    servicePort: '8080',
    requestConfig: {},
    apiBaseUrl: 'apiBaseUrl',
    responseConfig: {
      timeout: 15000,
    },
  };
  const requestBody = {
    name: 'John Doe',
    age: 30,
  };
  const pathParamForInfoAPI = '9f194fa6-06a3-40b4-b184';

  it('should return correct header, body and query', () => {
    const result = setParamsForPostArrangements(
      inputHeaders,
      res,
      requestBody,
      mockedAppConfig
    );
    expect(result).toEqual({
      body: {
        age: 30,
        name: 'John Doe',
      },
      header: {
        'Content-Type': 'application/json',
        'x-originatingBSB': '112879',
      },
      query: {
        brandSilo: 'WPAC',
        arrangementStatus: ARRANGEMENT_STATUS.ACTIVE_AND_INACTIVE,
      },
    });
  });

  it('should return correct header when BSB is not present in setParamsForPostPayments', () => {
    const result = setParamsForPostPayments(
      inputHeaders,
      res,
      requestBody,
      mockedAppConfig as any
    );
    expect(result).toEqual({
      body: {
        name: 'John Doe',
        age: 30,
      },
      header: {
        'Content-Type': 'application/json',
        'x-originatingBSB': '112879',
        'x-idempotency-key': '',
        'x-systemtest': '',
      },
      query: { brandSilo: 'WPAC', customerType: 'Organisation' },
    });
  });

  it('should return correct header  setParamsForGetPayees', () => {
    const response = {
      locals: {
        BSB: '112-879',
        brandSilo: 'WPAC',
      },
    } as Response;
    const result = setParamsForGetPayees(
      inputHeaders,
      response,
      pathParamForInfoAPI,
      mockedAppConfig
    );
    expect(result).toEqual({
      header: {
        'Content-Type': 'application/json',
        'x-originatingBSB': '112-879',
        'x-systemtest': '',
      },
      path: { id: pathParamForInfoAPI },
      query: {
        brandSilo: 'WPAC',
      },
    });
  });

  it('should return correct header when BSB is not present in res.locals', () => {
    const resWithoutBSB = {
      locals: {
        brandSilo: 'WPAC',
      },
    } as Response;
    const result = setParamsForPostArrangements(
      inputHeaders,
      resWithoutBSB,
      requestBody,
      mockedAppConfig
    );
    expect(result).toEqual({
      header: {
        'Content-Type': 'application/json',
        'x-originatingBSB': '112-879',
      },
      body: {
        name: 'John Doe',
        age: 30,
      },
      query: {
        brandSilo: 'WPAC',
        arrangementStatus: 'ACTIVE_AND_INACTIVE',
      },
    });
  });

  it('should return correct header when brandSilo is not present in res.locals', () => {
    const resWithoutBrandSilo = {
      locals: {
        BSB: '112-879',
      },
    } as Response;
    const result = setParamsForPostArrangements(
      inputHeaders,
      resWithoutBrandSilo,
      requestBody,
      mockedAppConfig
    );
    expect(result).toEqual({
      header: {
        'Content-Type': 'application/json',
        'x-originatingBSB': '112-879',
      },
      body: {
        name: 'John Doe',
        age: 30,
      },
      query: {
        brandSilo: undefined,
        arrangementStatus: 'ACTIVE_AND_INACTIVE',
      },
    });
  });

  it('should return correct header for setParamsForPaymentDetails', () => {
    const result = setParamsForPaymentDetails(inputHeaders, requestBody);
    expect(result).toEqual({
      body: {
        name: 'John Doe',
        age: 30,
      },
      header: {
        'Content-Type': 'application/json',
        'x-originatingBSB': '112879',
        'x-organisationId': 'WPAC',
        'x-consumerType': 'Staff',
      },
    });
  });

  it('should return correct header for setParamsForPostPaymentReturns', () => {
    const result = setParamsForPostPaymentReturns(
      inputHeaders,
      res,
      {
        appName: 'Galaxy Payment API Project',
        appId: 'com.westpac.expapi.galaxy',
        appBasePath: '/exp/galaxy/payment/v2',
        originatingSystemId: 'A014A6',
        originatingBSB: '112879',
        customerType: 'Organisation',
        servicePort: '8080',
        requestConfig: { requestConfig: '' },
        apiBaseUrl: 'apiBaseUrl',
        responseConfig: {
          timeout: 15000,
        },
      },
      requestBody
    );
    expect(result).toEqual({
      body: {
        name: 'John Doe',
        age: 30,
      },
      header: {
        'Content-Type': 'application/json',
        'x-originatingBSB': '112879',
        'x-idempotency-key': '',
        'x-organisationId': 'WPAC',
        'x-consumerType': 'Staff',
        'x-systemtest': '',
        'x-userIdScheme': 'StaffSalaryNumber',
      },
      query: { customerType: 'Organisation', brandSilo: 'WPAC'},
    });
  });
});

describe('setParamsForPaymentIdentifierGenerator', () => {
  it('should set the parameters correctly', () => {
    const inputHeaders = {};
    const res = {} as Response<any, Record<string, any>>;
    const requestBody = 'WP';

    const result = setParamsForPaymentIdentifierGenerator(
      inputHeaders,
      res,
      requestBody
    );

    expect(result).toEqual({
      header: { 'x-systemtest': '' },
      body: undefined,
      query: {
        channelId: requestBody,
      },
    });
  });
});

describe('setParamsForPostPaymentDetails', () => {
  const inputHeaders = {
    'x-originatingSystemId': 'A014A6',
  };
  const res = {
    locals: {
      BSB: '112-879',
      brandSilo: 'WPAC',
    },
  } as Response<unknown, Record<string, unknown>>;
  const body = { keyIdentifier: 'string', keyType: 'ITRID' };
  const mockedAppConfig = {
    appName: 'Galaxy Payment API Project',
    appId: 'com.westpac.expapi.galaxy',
    appBasePath: '/exp/galaxy/payment/v2',
    originatingSystemId: 'A014A6',
    originatingBSB: '112-879',
    consumerType: 'Customer',
    customerType: 'Organisation',
    servicePort: '8080',
    requestConfig: { requestConfig: '' },
    apiBaseUrl: 'apiBaseUrl',
    responseConfig: {
      timeout: 15000,
    },
  };

  it('should return correct parameters for valid input', () => {
    const expectedOutput = {
      header: {
        'x-originatingSystemId': 'A014A6',
        'x-originatingBSB': '112-879',
      },
      body: {
        id: 'string',
        idType: 'ITRID',
      },
      query: {
        brandSilo: 'WPAC',
      },
    };

    const result = setParamsForPostPaymentDetails(
      inputHeaders,
      res,
      body,
      mockedAppConfig
    );
    expect(result).toEqual(expectedOutput);
  });
});

describe('setParamsForPostAliasLookup', () => {
  let mockRes: Partial<Response>;
  let mockReq: Partial<Request>;
  let mockAppConfig: Partial<AppConfig>;

  const mockApiHeaders: ApiHeaders = { 'x-channelType': 'internal' };
  const mockBody: ExpPostAliasLookupRequestbody = {
    type: AliasType.EMAL,
    id: 'john.doe@abc.com',
    authBIC8: 'BANKUS33',
  };
});
