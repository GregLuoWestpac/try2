import { Response } from 'express';
import { RUNTIME } from '@mep-node/framework-constants';
import {
  jwtDecode,
  APIClientError,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';

export type DecodedToken = {
  userId: string;
  userIdScheme?: string;
  sessionIndex?: string;
};

export class TokenDecodeError extends Error {
  constructor(message: string, public readonly cause?: unknown) {
    super(message);
    this.name = 'TokenDecodeError';
  }
}

/**
 * Decodes JWT token from request headers
 * @param res - Express response object containing locals with logger and apiHeaders
 * @returns Decoded token with required userId
 * @throws TokenDecodeError if token is invalid or userId is missing
 */
export const decodeAccessToken = (res: Response): DecodedToken => {
  /* eslint-disable @typescript-eslint/no-unsafe-assignment */
  /* eslint-disable @typescript-eslint/no-unsafe-member-access */
  const { apiHeaders } = res.locals;
  const xAccessToken = apiHeaders['x-access-token'] as string;

  // In local environment, return mock token
  if (RUNTIME.isLocal()) {
    return {
      userId: 'sampleUserId',
      sessionIndex: 'sampleSessionId',
    };
  }

  // Decode token and set user ID scheme header
  let decodedToken: DecodedToken;
  try {
    decodedToken = jwtDecode(xAccessToken) as DecodedToken;
  } catch (error) {
    throw new TokenDecodeError('Failed to decode access token', error);
  }

  if (!decodedToken.userId) {
    throw new TokenDecodeError('userId not found in token');
  }

  res.locals.apiHeaders['x-userIdScheme'] = 'CustomerInternalId';
  return decodedToken;
};
