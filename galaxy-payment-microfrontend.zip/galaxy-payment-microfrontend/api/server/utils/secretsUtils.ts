/* eslint-disable security/detect-non-literal-fs-filename */

import { Logger } from '../../interfaces/types';

/* eslint-disable node/no-extraneous-require */
const fs = require('fs');

// read decrypted secrets file(s) from directory /secrets
const secretsDir = '/secrets';
const secretsFile = `${secretsDir}/.gitkeep`;

// secrets command uses the platform keys to encrypt your secrets and
// secrets will be made available in the container inside your secrets directory
export const readMeshSecrets = (fields: string[], logger: Logger): Record<string, string> => {
  try {
    if (fs.existsSync(secretsDir)) {
      const decryptedFileContent = fs.readFileSync(secretsFile, 'utf8');
      logger?.info('readMeshSecrets - decryptedFileContent found');
      const meshSecrets = JSON.parse(decryptedFileContent);
      for (const field of fields) {
        if (!meshSecrets[field]) {
          logger?.warn(`readMeshSecrets - field ${field} not found in mesh secrets`);
        }
      }
      return meshSecrets;
    }

    // cannot find directory '/secrets'
    // log event
    const diagnosticsOutputMessage = `Cannot find the directory: ${secretsDir}`;
    logger?.info(
      `readMeshSecrets - diagnosticsOutputMessage -`,
      diagnosticsOutputMessage
    );
    return {};
  } catch (error) {
    logger.error(`Something went wrong from reading mesh secrets. - ${error}`);
    return {};
  }
};
