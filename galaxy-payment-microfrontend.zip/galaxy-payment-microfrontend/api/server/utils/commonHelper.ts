import {
  jwtDecode,
  InvalidTokenError,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import {
  instructionForDebtorAgentCode,
  paymentMethodDescription,
  serviceLevelCode,
} from '../api/common/constants';
import { IncomingHttpHeaders } from 'http';
import { Request } from 'express';
import { RUNTIME } from '@mep-node/framework-constants';
import { readMeshSecrets } from '../utils/secretsUtils';
import { PDPCredentials } from './constants';

export const removeEmptyKeys = data => {
  // This helper function will filter null, undefined, '' , {} and return all the fields which has some values
  for (const value in data)
    if (data[value] && typeof data[value] === 'object') {
      removeEmptyKeys(data[value]);
      const keyList = Object.values(data[value]);
      if (keyList.length === 0) {
        delete data[value];
      }
    } else if (!data[value]) {
      delete data[value];
    }
};

export const mapPaymentMethod = (
  paymentMethodCode?: string,
  instructionForDebtorAgent?: string
) => {
  if (instructionForDebtorAgent === instructionForDebtorAgentCode.OnMe)
    return paymentMethodDescription.FundsTransfer;
  if (
    paymentMethodCode === undefined ||
    paymentMethodCode === null ||
    paymentMethodCode?.startsWith(serviceLevelCode.fastPaymentCatSct) ||
    paymentMethodCode?.startsWith(serviceLevelCode.fastPaymentSct)
  )
    return paymentMethodDescription.FastPayment;
  if (paymentMethodCode?.startsWith(serviceLevelCode.osko))
    return paymentMethodDescription.Osko;
  if (paymentMethodCode === serviceLevelCode.payTo)
    return paymentMethodDescription.PayTo;
  if (paymentMethodCode.startsWith(serviceLevelCode.DE)) {
    return paymentMethodDescription.DE;
  }

  return undefined;
};

/**
 * Extract original IP (first IP) from x-forwarded-for header.
 * Always returns a string, can be empty if header is missing or invalid.
 */
export const getOriginalIPFromXForwardedFor = (
  xForwardedFor: IncomingHttpHeaders['x-forwarded-for']
): string => {
  if (Array.isArray(xForwardedFor)) {
    return xForwardedFor[0] || '';
  } else if (typeof xForwardedFor === 'string') {
    return xForwardedFor.split(',')[0].trim();
  }
  return '';
};

/**
 * Extract device ID (original client IP) from express request.
 */
export const getDeviceIdFromRequest = (req: Request): string => {
  const xForwardedFor = req.headers['x-forwarded-for'];
  // || is used rather than ?? to handle empty string
  const clientIP =
    getOriginalIPFromXForwardedFor(xForwardedFor) ||
    (xForwardedFor as string) ||
    req.socket.remoteAddress; // Direct connection IP
  return clientIP;
};

export const setupPDPCredentials = (
  logger: any,
  apiHeaders?: any
): PDPCredentials => {
  let pdpClientToken: string;
  let org: string | undefined;

  if (!RUNTIME.isLocal()) {
    const fields = ['pdpClientToken', 'org'];
    const meshSecretsContent = readMeshSecrets(fields, logger);
    org = meshSecretsContent?.org;
    pdpClientToken = meshSecretsContent?.pdpClientToken;
  } else {
    if (process.env.NODE_ENV === 'production') {
      throw new Error(
        'Mock token path must not be used in production. ' +
          'Check RUNTIME.isLocal() configuration.'
      );
    }
    const mockedAccessToken = process.env.MOCKED_ACCESS_TOKEN;
    if (!mockedAccessToken) {
      throw new Error(
        'MOCKED_ACCESS_TOKEN environment variable must be set for local development. ' +
          'Add it to your local .env file.'
      );
    }
    logger.warn('Using mocked access token for local development');
    apiHeaders['x-access-token'] = mockedAccessToken;
    pdpClientToken = process.env.MOCKED_PDP_CLIENT_TOKEN || 'test-token';
  }

  return { pdpClientToken, org };
};
