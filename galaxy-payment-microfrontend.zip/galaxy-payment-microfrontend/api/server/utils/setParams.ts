/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import {
  getHeader,
  SetDownstreamParams,
  SetDownstreamParamsWithPath,
} from '@mesh-tenant-multiverse-ui-common/mv-apiutils';
import { Response } from 'express';
import { AppConfig } from '../../interfaces/models/common';
import { ExpPostPaymentDetailsRequestBody } from '../../interfaces/models/PaymentDetails';
import { ApiHeaders } from '../../interfaces/types';
import { HeaderForPaymentReturns } from './constants';
import { ARRANGEMENT_STATUS } from './enums';


export const setParamsForPostArrangements = (
  inputHeaders: ApiHeaders,
  res: Response,
  requestBody,
  appConfig,
  apiConfig?: Record<string, any>
) => {
  const body = { ...requestBody };
  const xSystemTest = res?.req?.get('x-systemtest') || '';
  return {
    header: {
      ...inputHeaders,
      'x-originatingBSB': res.locals.BSB || appConfig.originatingBSB,
      ...(xSystemTest && {
        'x-systemtest': xSystemTest,
      }),
    },
    body,
    query: {
      brandSilo: res.locals.brandSilo || appConfig.organisationId,
      arrangementStatus:
        apiConfig?.arrangementStatus === ARRANGEMENT_STATUS.ACTIVE
          ? ARRANGEMENT_STATUS.ACTIVE
          : ARRANGEMENT_STATUS.ACTIVE_AND_INACTIVE,
    },
  };
};

export const setParamsForPostPayments: SetDownstreamParams = (
  inputHeaders,
  res,
  requestBody,
  appConfig
) => {
  const body = { ...requestBody };
  return {
    header: {
      ...inputHeaders,
      'x-originatingBSB': res.locals.BSB || appConfig.originatingBSB,
      'x-systemtest': res?.req?.get('x-systemtest') || '',
      'x-idempotency-key': res?.req?.get('x-idempotency-key') || '',
    },
    body,
    query: {
      // TODO: Need to check with Mesh UI team for the best practice to get customer type
      customerType: res.locals.customerType || appConfig.customerType,
      brandSilo: res.locals.brandSilo,
    },
  };
};

export const setParamsForGetPayees = (
  inputHeaders: ApiHeaders,
  res: Response,
  id: string,
  appConfig
) => {
  const path = { id };
  return {
    path,
    header: {
      ...inputHeaders,
      'x-originatingBSB': res.locals.BSB || appConfig.originatingBSB,
      'x-systemtest': res?.req?.get('x-systemtest') || '',
    },
    query: {
      brandSilo: res.locals.brandSilo,
    },
  };
};

export const setParamsForPaymentIdentifierGenerator = (
  inputHeaders: ApiHeaders,
  res: Response,
  requestBody: string
) => ({
  header: {
    ...inputHeaders,
    'x-systemtest': res?.req?.get('x-systemtest') || '',
  },
  query: {
    channelId: requestBody,
  },
});

export const setParamsForPaymentListing = (
  inputHeaders: ApiHeaders,
  res: Response,
  dataFromUI: {
    orgCisKey: string;
    accountIds: string[];
    divisionIds?: string[];
    paymentDirection: string;
    fromDateTime: string;
    toDateTime: string;
    amountRange?: {
      fromAmount: string;
      toAmount: string;
    };
    paymentStatus?: string;
  }
) => {
  const xSystemTest = res?.req?.get('x-systemtest') || '';
  return {
    header: {
      ...inputHeaders,
      ...(xSystemTest && {
        'x-systemtest': xSystemTest,
      }),
    },
    body: {
      orgCisKey: dataFromUI.orgCisKey,
      accountIds: dataFromUI.accountIds,
      ...(dataFromUI.divisionIds && dataFromUI.divisionIds.length > 0 && { divisionIds: dataFromUI.divisionIds }),
      paymentDirection: dataFromUI.paymentDirection,
      fromDateTime: dataFromUI.fromDateTime,
      toDateTime: dataFromUI.toDateTime,
      ...(dataFromUI.paymentStatus && { paymentStatus: dataFromUI.paymentStatus }),
      ...(dataFromUI.amountRange && { amountRange: dataFromUI.amountRange }),
    },
  };
};
export const setParamsForPaymentDetails = (
  inputHeaders: ApiHeaders,
  requestBody
) => {
  const body = { ...requestBody };
  return {
    header: {
      ...inputHeaders,
      'x-organisationId': HeaderForPaymentReturns.OrganisationId,
      'x-consumerType': HeaderForPaymentReturns.ConsumerType,
    },
    body,
  };
};

export const setParamsForPostPaymentDetails = (
  inputHeaders: ApiHeaders,
  res: Response,
  body: ExpPostPaymentDetailsRequestBody,
  appConfig: AppConfig
) => {
  const isSystemTest = res?.req?.get('x-systemtest');
  return {
    header: {
      ...inputHeaders,
      'x-originatingBSB': res.locals.BSB || appConfig.originatingBSB,
      ...(isSystemTest && { 'x-systemtest': isSystemTest }),
    },
    body: {
      id: body.keyIdentifier,
      idType: body.keyType,
    },
    query: {
      brandSilo: res.locals.brandSilo,
    },
  };
};

export const setParamsForPostPaymentReturns = (
  inputHeaders: ApiHeaders,
  res: Response,
  appConfig: AppConfig,
  requestBody
) => {
  const body = { ...requestBody };

  return {
    header: {
      ...inputHeaders,
      'x-organisationId': HeaderForPaymentReturns.OrganisationId,
      'x-consumerType': HeaderForPaymentReturns.ConsumerType,
      'x-idempotency-key': res?.req?.get('x-idempotency-key') || '',
      'x-systemtest': res?.req?.get('x-systemtest') || '',
      'x-userIdScheme': HeaderForPaymentReturns.UserIdScheme,
    },
    body,
    query: {
      customerType: res.locals.customerType || appConfig.customerType,
      brandSilo: res.locals.brandSilo,
    },
  };
};

export const setParamsForGetDownStreamApi: SetDownstreamParams = (
  apiHeaders,
  res,
  requestBody,
  appConfig,
  queryParams,
  pathParams
) => {
  return {
    header: getHeader(apiHeaders, res, appConfig),
    body: undefined,
    query: {
      brandSilo: res.locals.brandSilo || appConfig.organisationId,
      channelId: queryParams.channelId,
      ...queryParams,
    },
    path: pathParams,
  };
};

export const setParamsForPostValidatePaymentLimits: SetDownstreamParams = (
  apiHeaders,
  res,
  requestBody,
  appConfig,
  queryParams
) => {
  const body = { ...requestBody };
  const xSystemTest = res?.req?.get('x-systemtest') || '';

  return {
    header: {
      ...apiHeaders,
      ...(xSystemTest && {
        'x-systemtest': xSystemTest,
      }),
      'x-idempotency-key': res?.req?.get('x-idempotency-key') || '',
    },
    body,
    query: {
      brandSilo: res.locals.brandSilo || appConfig.organisationId,
      ...queryParams,
    },
  };
};

export const setParamsForPostPaymentReturnsRequest = (
  inputHeaders: ApiHeaders,
  res: Response,
  appConfig: AppConfig,
  requestBody
) => {
  const body = { ...requestBody };

  return {
    header: {
      ...inputHeaders,
      'x-organisationId': HeaderForPaymentReturns.OrganisationId,
      'x-consumerType': HeaderForPaymentReturns.ConsumerType,
      'x-idempotency-key': res?.req?.get('x-idempotency-key') || '',
      'x-systemtest': res?.req?.get('x-systemtest') || '',
      'x-userIdScheme': HeaderForPaymentReturns.UserIdScheme,
      'x-swimlane': 'demo',
      'x-originatingBSB': res.locals.BSB || appConfig.originatingBSB,
    },
    body,
    query: {
      brandSilo: res.locals.brandSilo,
      customerType: res.locals.customerType || appConfig.customerType,
    },
  };
};

export const setParamsForGetPaymentLimit = (
  apiHeaders,
  res,
  requestBody,
  appConfig,
  queryParams,
  pathParams
) => {
  return {
    header: getHeader(apiHeaders, res, appConfig),
    body: requestBody,
    query: {
      brandSilo: res.locals.brandSilo || appConfig.organisationId,
      ...queryParams,
    },
    ...(pathParams && { path: pathParams }),
  };
};

export const setParamsForPaymentCounter: SetDownstreamParamsWithPath = (
  inputHeaders,
  res,
  body,
  appConfig,
  query,
  path
) => {
  return {
    header: inputHeaders,
    query,
    path,
    body,
  };
};

export const setParamsForAccountNameCheck: SetDownstreamParamsWithPath =
  (inputHeaders, res, body, appConfig, query, path) => {
    return {
      header: {
        ...inputHeaders,
        'Content-Type': 'application/json',
      },
      body,
      query,
      path,
    };
  } 

