import { STATUS_CODES } from './enums';

interface ErrorScenarios {
  GENERIC_ERROR: string;
  INVALID_REQUEST: string;
}

interface Headers {
  APP_CORRELATION_ID: string;
}

export interface PDPCredentials {
  pdpClientToken: string;
  org?: string;
}

export interface Constants {
  healthCheckControllerTitle: string;
  getArrangementsControllerTitle: string;
  postPaymentsControllerTitle: string;
  postPaymentListingControllerTitle: string;
  postPaymentReturnControllerTitle: string;
  customerInternalId: string;
  errorScenarios: ErrorScenarios;
  httpStatus: typeof STATUS_CODES;
  headers: Headers;
}

export const CONSTANTS: Constants = {
  healthCheckControllerTitle: 'healthcheck Controller',
  getArrangementsControllerTitle: 'getArrangements Controller',
  postPaymentsControllerTitle: 'postPayments Controller',
  postPaymentListingControllerTitle: 'postPaymentListing Controller',
  postPaymentReturnControllerTitle: 'postPaymentReturn Controller',
  customerInternalId: 'CustomerInternalId',
  errorScenarios: {
    GENERIC_ERROR: 'GENERIC_ERROR',
    INVALID_REQUEST: 'INVALID_REQUEST',
  },
  httpStatus: {
    ...STATUS_CODES,
  },
  headers: {
    APP_CORRELATION_ID: 'x-appcorrelationid',
  },
};

export const requestBodyForPymtIdentifierForCAP = 'WP';
export const requestBodyForPymtReturnIdentifierForCAP = 'WS';
export const numberOfTransactions = '1';
export const notProvided = 'NOTPROVIDED';
export const defaultDebtorName = 'debtor';
export const defaultOriginalMsgNameIdentification = 'pain.001';

export enum Currency {
  AUD = 'AUD',
}

export enum HeaderForPaymentReturns {
  OrganisationId = 'WPAC',
  ConsumerType = 'Staff',
  UserIdScheme = 'StaffSalaryNumber',
}

export enum SettlementMethod {
  CLRG = 'CLRG',
}

export enum ChargeBearer {
  SLEV = 'SLEV',
}

export enum BICFI {
  WPACAU3SXXX = 'WPACAU3SXXX',
  XXXXXXXXXXX = 'XXXXXXXXXXX',
}

export enum PaymentMethod {
  TRF = 'TRF',
}

export enum ServiceLevel {
  Osko = 'npp.clear.01-x2p1.04',
  FastPayment = 'npp.clear.01-sct.04',
}

export enum SchemeName {
  BBAN = 'BBAN',
}

export enum ToAnotherAccount {
  No = 'No',
  Yes = 'Yes',
}

export enum ReturnType {
  SolicitedReturn = 'Solicited return',
  UnsolicitedReturn = 'Unsolicited return',
}

export const ACCOUNT_LINK_TYPES = {
  INTEREST_APPLICATION: 'INTEREST_APPLICATION',
  BALANCE_OFFSET: 'BALANCE_OFFSET',
} as const;

export const ACCOUNT_RATE_CALCULATION_METHODS = {
  FLAT: 'FLAT',
  BAND: 'BAND',
  TIER: 'TIER',
} as const;
export enum AuthBIC8 {
  WPACAU3S = 'WPACAU3S',
}
