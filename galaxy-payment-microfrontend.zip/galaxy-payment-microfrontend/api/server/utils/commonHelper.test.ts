import { removeEmptyKeys, mapPaymentMethod, getOriginalIPFromXForwardedFor, getDeviceIdFromRequest } from './commonHelper';
import { paymentMethodDescription } from '../api/common/constants';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-apiutils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-apiutils'),
  jwtDecode: jest.fn(),
}));

describe('removeEmptyKeys', () => {
  it('should remove null and undefined values', () => {
    const input = {
      name: 'Rachita',
      age: null,
      address: undefined,
    };

    removeEmptyKeys(input);

    expect(input).toEqual({ name: 'Rachita' });
  });

  it('should remove empty strings', () => {
    const input = {
      name: '',
      email: 'qwerty@ymail.com',
    };

    removeEmptyKeys(input);

    expect(input).toEqual({ email: 'qwerty@ymail.com' });
  });

  it('should remove empty objects', () => {
    const input = {
      person: {
        firstName: 'John',
        lastName: '',
      },
      preferences: {},
    };

    removeEmptyKeys(input);

    expect(input).toEqual({ person: { firstName: 'John' } });
  });

  it('should not modify non-empty values', () => {
    const input = {
      name: 'Jane',
      age: 30,
      address: {
        city: 'New York',
      },
    };

    removeEmptyKeys(input);

    expect(input).toEqual({
      name: 'Jane',
      age: 30,
      address: {
        city: 'New York',
      },
    });
  });
});

describe('mapPaymentMethod', () => {
  it('should return FundsTransfer when instructionForDebtorAgent is "On-Me" and paymentMethodCode is undefined', () => {
    const result = mapPaymentMethod(undefined, 'On-Me');
    expect(result).toBe(paymentMethodDescription.FundsTransfer);
  });

  it('should return undefined when both instructionForDebtorAgent and paymentMethodCode are undefined', () => {
    const result = mapPaymentMethod(undefined, undefined);
    expect(result).toBe(paymentMethodDescription.FastPayment);
  });

  it('should return FastPayment when paymentMethodCode is npp.clear.01-catsct.01 and instructionForDebtorAgent is undefined', () => {
    const result = mapPaymentMethod('npp.clear.01-catsct.01', undefined);
    expect(result).toBe(paymentMethodDescription.FastPayment);
  });

  it('should return FastPayment when paymentMethodCode is npp.clear.01-sct.01 and instructionForDebtorAgent is undefined', () => {
    const result = mapPaymentMethod('npp.clear.01-sct.01', undefined);
    expect(result).toBe(paymentMethodDescription.FastPayment);
  });

  it('should return Osko when paymentMethodCode is npp.clear.01-x2p1.01 and instructionForDebtorAgent is undefined', () => {
    const result = mapPaymentMethod('npp.clear.01-x2p1.01', undefined);
    expect(result).toBe(paymentMethodDescription.Osko);
  });

  it('should return PayTo when paymentMethodCode is npp.mpis.01-mpis.01 and instructionForDebtorAgent is undefined', () => {
    const result = mapPaymentMethod('npp.mpis.01-mpis.01', undefined);
    expect(result).toBe(paymentMethodDescription.PayTo);
  });
});
describe('getOriginalIPFromXForwardedFor', () => {
  it('should return first IP from comma-separated string', () => {
    const ip = getOriginalIPFromXForwardedFor('123.45.67.89, 98.76.54.32');
    expect(ip).toBe('123.45.67.89');
  });

  it('should return first IP from array', () => {
    const ip = getOriginalIPFromXForwardedFor(['123.45.67.89', '98.76.54.32']);
    expect(ip).toBe('123.45.67.89');
  });

  it('should trim spaces from IP', () => {
    const ip = getOriginalIPFromXForwardedFor(' 123.45.67.89 , 98.76.54.32');
    expect(ip).toBe('123.45.67.89');
  });

  it('should return empty string if header is missing', () => {
    const ip = getOriginalIPFromXForwardedFor(undefined);
    expect(ip).toBe('');
  });
});

describe('getDeviceIdFromRequest', () => {
  it('should extract IP from x-forwarded-for header (string)', () => {
    const req: any = {
      headers: { 'x-forwarded-for': '123.45.67.89, 98.76.54.32' },
      socket: { remoteAddress: '10.0.0.1' }
    };
    expect(getDeviceIdFromRequest(req)).toBe('123.45.67.89');
  });

  it('should extract IP from x-forwarded-for header (array)', () => {
    const req: any = {
      headers: { 'x-forwarded-for': ['123.45.67.89', '98.76.54.32'] },
      socket: { remoteAddress: '10.0.0.1' }
    };
    expect(getDeviceIdFromRequest(req)).toBe('123.45.67.89');
  });

  it('should fallback to remoteAddress if x-forwarded-for is missing', () => {
    const req: any = {
      headers: {},
      socket: { remoteAddress: '10.0.0.1' }
    };
    expect(getDeviceIdFromRequest(req)).toBe('10.0.0.1');
  });

  it('should fallback to x-forwarded-for if getOriginalIPFromXForwardedFor returns empty', () => {
    const req: any = {
      headers: { 'x-forwarded-for': '' },
      socket: { remoteAddress: '10.0.0.1' }
    };
    expect(getDeviceIdFromRequest(req)).toBe('10.0.0.1');
  });
});
