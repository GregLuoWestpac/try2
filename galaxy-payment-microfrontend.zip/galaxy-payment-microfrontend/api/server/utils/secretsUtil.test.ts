import { readMeshSecrets } from './secretsUtils';
/* eslint-disable security/detect-non-literal-fs-filename */
/* eslint-disable node/no-extraneous-require */
const fs = require('fs');
jest.mock('fs');

afterEach(() => {
  jest.clearAllMocks();
});

describe('readMeshSecrets', () => {
  // test case should return decryptedFileContent if secrets directory exists
  it('should return decryptedFileContent if secrets directory exists', () => {
    const logger = {
      info: jest.fn(),
    };
    const decryptedFileContent = {
      pdpClientToken: 'test-token',
      org: 'test-org',
    };
    fs.existsSync.mockReturnValue(true);
    fs.readFileSync.mockReturnValue(JSON.stringify(decryptedFileContent));
    // const result = readMeshSecrets(logger);

    const fields = ['pdpClientToken', 'org'];
    // @ts-ignore
    const result = readMeshSecrets(fields, logger);

    expect(result).toEqual(decryptedFileContent);

    expect(logger.info).toHaveBeenCalledWith(
      'readMeshSecrets - decryptedFileContent found'
    );
  });

  //below test case added by github copilot for increasing coverage

  //  test case should return null if secrets directory does not exist
  it('should return null if secrets directory does not exist', () => {
    const logger = {
      info: jest.fn(),
    };

    fs.existsSync.mockReturnValue(false);
    // @ts-ignore
    const result = readMeshSecrets([], logger);
    expect(result).toEqual({});
    expect(logger.info).toHaveBeenCalledWith(
      'readMeshSecrets - diagnosticsOutputMessage -',
      'Cannot find the directory: /secrets'
    );
  });
});
