import { PerformanceObserver } from 'perf_hooks';
import { RUNTIME } from '@mep-node/framework';
import {
  Brands,
  BrandSilos,
  OrganisationIds,
} from '@mep-node/framework-constants';
import { Config } from '@mep-node/framework-config-provider';

import { Logger, CacheProvider, ApiHeaders } from '../../interfaces/types';
// import { AppResponse } from '../../interfaces/models';
import { UserType } from '../../server/utils/enums';

type SwaggerOperation = {
  operationId: string;
};

interface Swagger {
  operation: SwaggerOperation;
}

interface AppLocals {
  RUNTIME: typeof RUNTIME;
  Config: typeof Config;
}

interface AppResponse {
  locals: AppLocals;
}

interface UserName {
  lastName: string;
  firstName: string;
}

declare global {
  namespace Express {
    interface Request {
      swagger?: Swagger;
    }
    interface Locals extends AppLocals {
      logger: Logger;
      apiBaseUrl: string;
      xBrandId: keyof typeof Brands;
      brandSilo: keyof typeof BrandSilos;
      xOrganisationId: keyof typeof OrganisationIds;
      CONSUMER_TYPE: string;
      BSB: string;
      USER_ROLES: string[];
      USER_NAME: UserName;
      apiHeaders: ApiHeaders;
      USER: string;
      USER_TYPE: keyof typeof UserType;
      CacheProvider?: CacheProvider;
      performance?: Performance;
      assumedRolesOnNorthEdge: string[];
      wdpPassEntitlement: boolean;
      wdpOperationId: string;
      timeoutIn: number;
      dispatchEventAsync?: (
        event: string,
        topic: string,
        payload: any,
        status: number
      ) => Promise<void>;
      [key: string]: unknown;
    }
    interface Response {
      app: AppResponse;
    }
  }
}
