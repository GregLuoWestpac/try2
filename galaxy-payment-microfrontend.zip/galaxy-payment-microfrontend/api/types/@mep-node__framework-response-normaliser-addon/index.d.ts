declare module '@mep-node/framework-response-normaliser-addon' {
  import { Schema, NormalizedSchema } from 'normalizr';

  export function normalise<
    T = any,
    E = { [key: string]: { [key: string]: T } | undefined },
    R = any
  >(data: any, schema: Schema<T>): NormalizedSchema<E, R>;
}

import '@mep-node/framework-constants';

declare module '@mep-node/framework-constants' {
  namespace ALLOWED_COOKIES {
    const W1AddnAuthorisation: string;
  }
}
