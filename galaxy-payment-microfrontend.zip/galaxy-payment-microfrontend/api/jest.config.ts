/* eslint-disable */
export default {
  displayName: 'api',
  verbose: true,
  testEnvironment: 'node',
  testMatch: ['<rootDir>/server/**/*.test.{js,ts}'],
  maxWorkers: process.env.CI ? 1 : '50%',
  workerIdleMemoryLimit: '512MB',
  transform: {
    '^.+\\.[tj]s$': [
      'ts-jest',
      {
        tsconfig: '<rootDir>/tsconfig.spec.json',
      },
    ],
  },
  moduleFileExtensions: ['ts', 'js', 'html'],
  coverageDirectory: '../coverage/api',
  collectCoverage: true,
  coverageReporters: ['html', 'json', 'lcov', 'text'],
  collectCoverageFrom: [
    'server/**/*.[jt]s',
    '!server/generated/**/*.[jt]s',
    '!server/api/index.[jt]s',
    '!server/api/__fixtures__/*.[jt]s',
  ],
  coverageThreshold: {
    global: {
      branches: 15,
      functions: 15,
      lines: 15,
      statements: 15,
    },
  },
  reporters: [
    'default',
    [
      'jest-junit',
      {
        suiteName: 'jest tests',
        outputDirectory: 'coverage/api',
        classNameTemplate: '{classname}-{title}',
        titleTemplate: '{classname}-{title}',
        ancestorSeparator: ' › ',
        usePathForSuiteName: 'true',
      },
    ],
  ],
};
