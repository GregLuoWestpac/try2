import { FinancialInstitutionIdentification } from './common';

/**
 * Post Payment request to XApi
 */
export interface PostPaymentsRequest {
  clientContext: {
    channelType?: string;
  };
  creationDateTime: string;
  creditTransferTransactionInformation: {
    creditor: {
      name: string;
    };
    creditorAccount?: {
      identification: string;
      issuer: string;
      name?: string;
      schemeName: string;
      type?: string;
    };
    creditorAgent: {
      BICFI: string;
      financialInstitutionIdentification?: FinancialInstitutionIdentification;
    };
    endToEndIdentification?: string;
    instructedAmount: {
      amount: string;
      currency: string;
    };
    instructionForDebtorAgent?: string;
    remittanceInformation?: {
      unstructured?: string;
    }[];
    supplementaryData?: {
      isNewPayee?: boolean;
      aliasId?: string;
      aliasType?: string;
      beneficiaryId?: string;
      aliasResolutionTime?: string;
      aliasRegistrationTime?: string;
      aliasLastUpdateTime?: string;
      divisionId?: string;
      orgId?: string;
    };
    paymentTypeInformation?: {
      categoryPurpose?: string;
      instructionPriority?: string;
      serviceLevel?: string;
    };
  }[];
  debtor?: {
    identification?: string;
    issuer?: string;
    name?: string;
  };
  debtorAccount: {
    identification: string;
    issuer: string;
    name?: string;
    schemeName: string;
    type?: string;
  };
  debtorAgent?: {
    BICFI: string;
    financialInstitutionIdentification?: FinancialInstitutionIdentification;
  };
  initiatingParty: {
    identification: string;
    name?: string;
  };
  instructionForDebtorAgent?: string;
  paymentInformation?: {
    numberOfTransactions?: string;
    requestedExecutionDate: string;
  };
  paymentMethod: string;
  supplementaryData: {
    divisionId?: string;
    debitDescription?: string;
    instructionTraceIdentification?: string;
    paymentProductId?: string;
  };
  entitlementData?: {
    supplementaryData: {
      name: string;
      value: string;
      datatype: 'STRING' | 'BOOLEAN';
    }[];
  };
}

export interface PostPaymentsResponse {
  creationDateTime: string;
  groupInformation?: {
    groupStatus?: string;
    originalControlSum?: string;
  };
  groupStatusReasonInformation?: [
    {
      reason?: string;
      additionalInformation?: string;
    }
  ];
  id: string;
  paymentInformation: {
    paymentInformationStatus?: string;
    paymentId: string;
  };
  paymentStatusReasonInformation?: [
    {
      reason?: string;
      additionalInformation?: string;
    }
  ];
  transactionInformation?: [
    {
      transactionStatus?: string;
      statusReasonInformation?: [
        {
          reason?: string;
          additionalInformation?: string;
        }
      ];
    }
  ];
}

/**
 * Payment initiation request to CAP downstream api V2
 */
export interface PaymentInitiationRequest {
  customerCreditTransferInitiation: {
    groupHeader: {
      messageIdentification: string;
      creationDateTime: string;
      initiatingParty: {
        identification: {
          identificationType: string;
          anyBIC?: string;
          LEI?: string;
          other: {
            identification: string;
            schemeName: {
              code: string;
            };
            issuer: string;
          }[];
        };
        name: string;
      };
      numberOfTransactions: number;
    };
    paymentInformation: {
      paymentInformationIdentification?: string;
      paymentMethod: string;
      paymentTypeInformation?: {
        instructionPriority?: string;
        serviceLevel?: {
          serviceLevelType: string;
          proprietary: string;
        };
        categoryPurpose?: {
          purposeType: string;
          proprietary: string;
        };
      };
      requestedExecutionDate?: {
        dateType: string;
        date: string;
      };
      poolingAdjustmentDate?: string;
      debtor?: {
        name: string;
        identification?: {
          identificationType: string;
          anyBIC?: string;
          LEI?: string;
          other?: {
            identification: string;
            schemeName: {
              code: string;
            };
            issuer: string;
          }[];
        };
        postalAddress?: {
          addressType?: {
            code: string;
          };
          department?: string;
          subDepartment?: string;
          streetName?: string;
          buildingNumber?: string;
          buildingName?: string;
          floor?: string;
          postBox?: string;
          room?: string;
          postCode?: string;
          townName?: string;
          townLocationName?: string;
          districtName?: string;
          countrySubDivision?: string;
          country?: string;
          addressLine?: string[];
        };
        contactDetails?: {
          namePrefix?: string;
          name?: string;
          phoneNumber?: string;
          mobileNumber?: string;
          faxNumber?: string;
          emailAddress?: string;
          emailPurpose?: string;
          jobTitle?: string;
          responsibility?: string;
          department?: string;
          other?: {
            channelType: string;
            identification: string;
          }[];
          preferredMethod?: string;
        };
      };
      debtorAccount?: {
        identification?: {
          identificationType: string;
          IBAN?: string;
        };
        type?: {
          code: string;
          proprietary?: string;
        };
        name?: string;
      };
      debtorAgent?: {
        financialInstitutionIdentification: {
          BICFI: string;
          clearingSystemMemberIdentification?: {
            clearingSystemIdentification?: {
              code: string;
              proprietary?: string;
            };
            memberIdentification: string;
          };
          name?: string;
          postalAddress?: {
            addressType?: {
              code: string;
            };
            department?: string;
            subDepartment?: string;
            streetName?: string;
            buildingNumber?: string;
            buildingName?: string;
            floor?: string;
            postBox?: string;
            room?: string;
            postCode?: string;
            townName?: string;
            townLocationName?: string;
            districtName?: string;
            countrySubDivision?: string;
            country?: string;
            addressLine?: string[];
          };
        };
      };
      ultimateDebtor?: {
        name: string;
        postalAddress?: {
          addressType?: {
            code: string;
          };
          department?: string;
          subDepartment?: string;
          streetName?: string;
          buildingNumber?: string;
          buildingName?: string;
          floor?: string;
          postBox?: string;
          room?: string;
          postCode?: string;
          townName?: string;
          townLocationName?: string;
          districtName?: string;
          countrySubDivision?: string;
          country?: string;
          addressLine?: string[];
        };
      };
      chargeBearer?: string;
      chargesAccount?: {
        identification: {
          identificationType: string;
          IBAN: string;
        };
      };
      creditTransferTransactionInformation: {
        paymentIdentification: {
          instructionIdentification: string;
          endToEndIdentification?: string;
        };
        amount: {
          amountType: string;
          instructedAmount: string;
          currencyCode: string;
        };
        exchangeRateInformation?: {
          unitCurrency: string;
          exchangeRate: string;
          rateType: string;
          contractIdentification: string;
        };
        intermediaryAgent1?: {
          financialInstitutionIdentification: {
            BICFI: string;
            clearingSystemMemberIdentification?: {
              clearingSystemIdentification?: {
                code: string;
                proprietary?: string;
              };
              memberIdentification: string;
            };
            name?: string;
            postalAddress?: {
              addressType?: {
                code: string;
              };
              department?: string;
              subDepartment?: string;
              streetName?: string;
              buildingNumber?: string;
              buildingName?: string;
              floor?: string;
              postBox?: string;
              room?: string;
              postCode?: string;
              townName?: string;
              townLocationName?: string;
              districtName?: string;
              countrySubDivision?: string;
              country?: string;
              addressLine?: string[];
            };
          };
        };
        intermediaryAgent2?: {
          financialInstitutionIdentification: {
            BICFI: string;
            clearingSystemMemberIdentification?: {
              clearingSystemIdentification?: {
                code: string;
                proprietary?: string;
              };
              memberIdentification: string;
            };
            name?: string;
            postalAddress?: {
              addressType?: {
                code: string;
              };
              department?: string;
              subDepartment?: string;
              streetName?: string;
              buildingNumber?: string;
              buildingName?: string;
              floor?: string;
              postBox?: string;
              room?: string;
              postCode?: string;
              townName?: string;
              townLocationName?: string;
              districtName?: string;
              countrySubDivision?: string;
              country?: string;
              addressLine?: string[];
            };
          };
        };
        intermediaryAgent3?: {
          financialInstitutionIdentification: {
            BICFI: string;
            clearingSystemMemberIdentification?: {
              clearingSystemIdentification?: {
                code: string;
                proprietary?: string;
              };
              memberIdentification: string;
            };
            name?: string;
            postalAddress?: {
              addressType?: {
                code: string;
              };
              department?: string;
              subDepartment?: string;
              streetName?: string;
              buildingNumber?: string;
              buildingName?: string;
              floor?: string;
              postBox?: string;
              room?: string;
              postCode?: string;
              townName?: string;
              townLocationName?: string;
              districtName?: string;
              countrySubDivision?: string;
              country?: string;
              addressLine?: string[];
            };
          };
        };
        creditorAgent: {
          financialInstitutionIdentification: {
            BICFI: string;
            clearingSystemMemberIdentification?: {
              clearingSystemIdentification?: {
                code: string;
                proprietary?: string;
              };
              memberIdentification: string;
            };
            name?: string;
            postalAddress?: {
              addressType?: {
                code: string;
              };
              department?: string;
              subDepartment?: string;
              streetName?: string;
              buildingNumber?: string;
              buildingName?: string;
              floor?: string;
              postBox?: string;
              room?: string;
              postCode?: string;
              townName?: string;
              townLocationName?: string;
              districtName?: string;
              countrySubDivision?: string;
              country?: string;
              addressLine?: string[];
            };
          };
        };
        creditor: {
          name: string;
          postalAddress?: {
            addressType?: {
              code: string;
            };
            department?: string;
            subDepartment?: string;
            streetName?: string;
            buildingNumber?: string;
            buildingName?: string;
            floor?: string;
            postBox?: string;
            room?: string;
            postCode?: string;
            townName?: string;
            townLocationName?: string;
            districtName?: string;
            countrySubDivision?: string;
            country?: string;
            addressLine?: string[];
          };
          identification?: {
            identificationType: string;
            anyBIC?: string;
            LEI?: string;
            other?: {
              identification: string;
              schemeName: {
                code: string;
              };
              issuer: string;
            }[];
          };
          countryOfResidence?: string;
          contactDetails?: {
            namePrefix?: string;
            name?: string;
            phoneNumber?: string;
            mobileNumber?: string;
            faxNumber?: string;
            emailAddress?: string;
            emailPurpose?: string;
            jobTitle?: string;
            responsibility?: string;
            department?: string;
            other?: {
              channelType: string;
              identification: string;
            }[];
            preferredMethod?: string;
          };
        };
        creditorAccount?: {
          identification?: {
            identificationType: string;
            IBAN?: string;
          };
          type?: {
            code: string;
            proprietary?: string;
          };
          name?: string;
          proxy?: {
            type: {
              code: string;
              proprietary?: string;
            };
            identification: string;
          };
        };
        instructionForCreditorAgent?: {
          code: string;
          instructionInformation: string;
        }[];
        purpose?: {
          purposeType: string;
          code: string;
        };
        remittanceInformation?: {
          unstructured?: string[];
        };
      };
    };
    supplementaryData: {
      placeAndName?: string;
      envelope: {
        isNewPayee?: boolean;
        personalArn?: string;
        personalVoucherCode?: string;
        personalLoanAccountNumber?: string;
        channelType: string;
        paymentIdentifier?: string;
        paymentFrequencyType?: string;
        authenticationLevel?: string;
        numberOfDebits?: number;
        clearingChannel?: string;
        debtorTransactionInfo?: {
          debitPaymentIdentifier?: string;
          creditorAgentCode?: string;
          debitSerialNumber?: string;
          accountCountryCode?: string;
          debitNarrative?: string;
          fallbackDebtorName?: string;
          fallbackFLAN?: string;
        };
        relatedPaymentInformation?: {
          originalPaymentIdentifier?: string;
          originalTransactionId?: string;
        };
        returnReason?: {
          returnReasonCode?: string;
        };
        riskAnalysisType?: {
          deviceId?: string;
          riskScore?: string;
          ruleName?: string;
        };
        aliasResolutionTime?: string;
        aliasRegistrationTime?: string;
        aliasLastUpdateTime?: string;
      };
    };
  };
  paymentDomainMetadata: {
    paymentProductId: string;
    channelId: string;
    orchestrationPlanId?: string;
    paymentInstructionId: string;
    schemeE2EId?: string;
    bulkInstructionId?: string;
    WBCE2EPaymentId?: string;
  };
}
