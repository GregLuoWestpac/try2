
/** Contains a list of logs */
export interface LogRequest {
  logs: {
    /**
     * the unique id representing the log record
     * @pattern ^[\w-]{7,14}$
     */
    id: string;
    /**
     * the utc timestamp of the log record as per rfc-3339 (https://tools.ietf.org/html/rfc3339#section-5.6)
     * @format date-time
     */
    timestamp: string;
    /**
     * The ui functional area that triggers the log.
     * @pattern ^[\w-@/]{1,100}$
     * @example "@wdpui/common-with-theme"
     */
    scope: string;
    /** The log level for filtering. */
    level: 'ERROR' | 'WARN' | 'INFO' | 'DEBUG' | 'SILLY';
    /**
     * The message including payload information that is intended for logging.
     * @maxLength 2000
     * @pattern ^[\w\-:;,.+#\[\]@()${}=!'"\\\/ ]+$
     * @example "{"type": "@@redux-form/REGISTER_FIELD","meta":{"form": "payments"},"payload":{"name":"name","type":"Field"}}"
     */
    message?: string;
  }[];
}

/** A single log record */
export interface Log {
  /**
   * the unique id representing the log record
   * @pattern ^[\w-]{7,14}$
   */
  id: string;
  /**
   * the utc timestamp of the log record as per rfc-3339 (https://tools.ietf.org/html/rfc3339#section-5.6)
   * @format date-time
   */
  timestamp: string;
  /**
   * The ui functional area that triggers the log.
   * @pattern ^[\w-@/]{1,100}$
   * @example "@wdpui/common-with-theme"
   */
  scope: string;
  /** The log level for filtering. */
  level: 'ERROR' | 'WARN' | 'INFO' | 'DEBUG' | 'SILLY';
  /**
   * The message including payload information that is intended for logging.
   * @maxLength 2000
   * @pattern ^[\w\-:;,.+#\[\]@()${}=!'"\\\/ ]+$
   * @example "{"type": "@@redux-form/REGISTER_FIELD","meta":{"form": "payments"},"payload":{"name":"name","type":"Field"}}"
   */
  message?: string;
}

/** Contains a generic success response */
export type Success = string;

/** Contains list of Errors */
export interface Errors {
  errors?: {
    /**
     * Error Code
     * @format int32
     * @example 400
     */
    code: number;
    /**
     * Error Message
     * @maxLength 32
     * @pattern ^[\w ]+$
     * @example "Bad Request"
     */
    message: string;
    /**
     * Detailed information about the error. If it is an error scenario where an error mappping is required as per MAD teams' specification, the string will contain the UIError object.
     * @maxLength 32
     * @pattern ^[\w ]+$
     * @example "Check logs for details"
     */
    details?: string;
  }[];
}

/** Contains list of Errors */
export interface ErrorResult {
  /** Contains list of Errors */
  result?: {
    errors?: {
      /**
       * Error Code
       * @format int32
       * @example 400
       */
      code: number;
      /**
       * Error Message
       * @maxLength 32
       * @pattern ^[\w ]+$
       * @example "Bad Request"
       */
      message: string;
      /**
       * Detailed information about the error. If it is an error scenario where an error mappping is required as per MAD teams' specification, the string will contain the UIError object.
       * @maxLength 32
       * @pattern ^[\w ]+$
       * @example "Check logs for details"
       */
      details?: string;
    }[];
  };
}

/** Represents an individual error */
export interface Error {
  /**
   * Error Code
   * @format int32
   * @example 400
   */
  code: number;
  /**
   * Error Message
   * @maxLength 32
   * @pattern ^[\w ]+$
   * @example "Bad Request"
   */
  message: string;
  /**
   * Detailed information about the error. If it is an error scenario where an error mappping is required as per MAD teams' specification, the string will contain the UIError object.
   * @maxLength 32
   * @pattern ^[\w ]+$
   * @example "Check logs for details"
   */
  details?: string;
}

export interface ErrorResponse {
  /** Contains list of Errors */
  result?: {
    errors?: {
      /**
       * Error Code
       * @format int32
       * @example 400
       */
      code: number;
      /**
       * Error Message
       * @maxLength 32
       * @pattern ^[\w ]+$
       * @example "Bad Request"
       */
      message: string;
      /**
       * Detailed information about the error. If it is an error scenario where an error mappping is required as per MAD teams' specification, the string will contain the UIError object.
       * @maxLength 32
       * @pattern ^[\w ]+$
       * @example "Check logs for details"
       */
      details?: string;
    }[];
  };
}

/** Contains list of Errors */
export interface SafiErrors {
  errors?: {
    /**
     * Error Code
     * @format int32
     */
    code?: number;
    /** Error Message */
    message?: string;
    /** Detailed information about the error. If it is an error scenario where an error mappping is required as per MAD teams' specification, the string will contain the UIError object. */
    details?: {
      /** safi analyse result code. */
      analysis?: 'ALLOW' | 'DENY' | 'CHALLENGE' | 'DELAY_AND_REVIEW' | 'REVIEW';
      /** safi analyse result with challenge type. */
      challengeType?: 'SMSOTP' | 'SECURID' | 'EXEMPTION_TEMP' | 'EXEMPTION_PERM';
      /**
       * safi analyse result challenge details has masked phoneNumber.
       * @maxLength 16
       * @pattern ^[\w]+$
       */
      phoneNumber?: string;
      /**
       * An encrypted string which has safi initiated transaction and device token details.
       * @maxLength 8000
       * @pattern ^[a-zA-Z0-9+=\/]+$
       */
      token?: string;
    };
  }[];
}

/** Contains list of Errors */
export interface SafiErrorResult {
  /** Contains list of Errors */
  result?: {
    errors?: {
      /**
       * Error Code
       * @format int32
       */
      code?: number;
      /** Error Message */
      message?: string;
      /** Detailed information about the error. If it is an error scenario where an error mappping is required as per MAD teams' specification, the string will contain the UIError object. */
      details?: {
        /** safi analyse result code. */
        analysis?: 'ALLOW' | 'DENY' | 'CHALLENGE' | 'DELAY_AND_REVIEW' | 'REVIEW';
        /** safi analyse result with challenge type. */
        challengeType?: 'SMSOTP' | 'SECURID' | 'EXEMPTION_TEMP' | 'EXEMPTION_PERM';
        /**
         * safi analyse result challenge details has masked phoneNumber.
         * @maxLength 16
         * @pattern ^[\w]+$
         */
        phoneNumber?: string;
        /**
         * An encrypted string which has safi initiated transaction and device token details.
         * @maxLength 8000
         * @pattern ^[a-zA-Z0-9+=\/]+$
         */
        token?: string;
      };
    }[];
  };
}

/** Detailed information about the error. If it is an error scenario where an error mappping is required as per MAD teams' specification, the string will contain the UIError object. */
export interface SAFIErrorDetails {
  /** safi analyse result code. */
  analysis?: 'ALLOW' | 'DENY' | 'CHALLENGE' | 'DELAY_AND_REVIEW' | 'REVIEW';
  /** safi analyse result with challenge type. */
  challengeType?: 'SMSOTP' | 'SECURID' | 'EXEMPTION_TEMP' | 'EXEMPTION_PERM';
  /**
   * safi analyse result challenge details has masked phoneNumber.
   * @maxLength 16
   * @pattern ^[\w]+$
   */
  phoneNumber?: string;
  /**
   * An encrypted string which has safi initiated transaction and device token details.
   * @maxLength 8000
   * @pattern ^[a-zA-Z0-9+=\/]+$
   */
  token?: string;
}

/** Represents a safi error. This error would tell what sort of safi challenge is requested and also returns token which should be used in each subsequent calls. */
export interface SafiError {
  /**
   * Error Code
   * @format int32
   */
  code?: number;
  /** Error Message */
  message?: string;
  /** Detailed information about the error. If it is an error scenario where an error mappping is required as per MAD teams' specification, the string will contain the UIError object. */
  details?: {
    /** safi analyse result code. */
    analysis?: 'ALLOW' | 'DENY' | 'CHALLENGE' | 'DELAY_AND_REVIEW' | 'REVIEW';
    /** safi analyse result with challenge type. */
    challengeType?: 'SMSOTP' | 'SECURID' | 'EXEMPTION_TEMP' | 'EXEMPTION_PERM';
    /**
     * safi analyse result challenge details has masked phoneNumber.
     * @maxLength 16
     * @pattern ^[\w]+$
     */
    phoneNumber?: string;
    /**
     * An encrypted string which has safi initiated transaction and device token details.
     * @maxLength 8000
     * @pattern ^[a-zA-Z0-9+=\/]+$
     */
    token?: string;
  };
}

/** Contains list of Errors */
export interface SafiVerificationErrors {
  errors?: {
    /**
     * Error Code
     * @format int32
     */
    code?: number;
    /** Error Message */
    message?: string;
    /** Detailed information about the error. */
    details?: {
      /** safi analyse result code. */
      analysis?: 'ALLOW' | 'DENY' | 'CHALLENGE' | 'DELAY_AND_REVIEW' | 'REVIEW';
      /** safi analyse result with challenge type. */
      challengeType?: 'SMSOTP' | 'SECURID' | 'EXEMPTION_TEMP' | 'EXEMPTION_PERM';
      /**
       * safi analyse result challenge details has masked phoneNumber.
       * @maxLength 16
       * @pattern ^[\w]+$
       */
      phoneNumber?: string;
      /**
       * An encrypted string which has safi initiated transaction and device token details.
       * @maxLength 8000
       * @pattern ^[a-zA-Z0-9+=\/]+$
       */
      token?: string;
      /** safi verification result code. */
      verification?: 'ACCESS_DENIED_OTP_INCORRECT' | 'NEXT_CODE_REQUIRED';
      /**
       * If the authentication failed this element will be populated with the number of remaining authentication attempts before the device is suspended in this network.
       * @format int32
       */
      remainingAttempts?: number;
    };
  }[];
}

/** Represents a safi error. This error would tell what sort of safi challenge is requested and also returns token which should be used in each subsequent calls. */
export interface SafiVerificationError {
  /**
   * Error Code
   * @format int32
   */
  code?: number;
  /** Error Message */
  message?: string;
  /** Detailed information about the error. */
  details?: {
    /** safi analyse result code. */
    analysis?: 'ALLOW' | 'DENY' | 'CHALLENGE' | 'DELAY_AND_REVIEW' | 'REVIEW';
    /** safi analyse result with challenge type. */
    challengeType?: 'SMSOTP' | 'SECURID' | 'EXEMPTION_TEMP' | 'EXEMPTION_PERM';
    /**
     * safi analyse result challenge details has masked phoneNumber.
     * @maxLength 16
     * @pattern ^[\w]+$
     */
    phoneNumber?: string;
    /**
     * An encrypted string which has safi initiated transaction and device token details.
     * @maxLength 8000
     * @pattern ^[a-zA-Z0-9+=\/]+$
     */
    token?: string;
    /** safi verification result code. */
    verification?: 'ACCESS_DENIED_OTP_INCORRECT' | 'NEXT_CODE_REQUIRED';
    /**
     * If the authentication failed this element will be populated with the number of remaining authentication attempts before the device is suspended in this network.
     * @format int32
     */
    remainingAttempts?: number;
  };
}

/** healthcheck status */
export interface HealthCheckStatus {
  status?: 'success';
}

/** returns the context handover data from redis cache */
export interface GetContextHandover {
  /** N/A */
  entities?: {
    /** N/A */
    contexts?: {
      /**
       * An unique context ref identifier.
       * @maxLength 14
       * @pattern ^[\w-]+$
       */
      id?: string;
      /** List of fields stored as key value pairs in the redis */
      fields?: {
        /**
         * field name.
         * @maxLength 256
         * @pattern ^[\w-]+$
         */
        fieldName?: string;
        /**
         * value of the field
         * @maxLength 256
         * @pattern ^[\w-\s\.]+$
         */
        value?: string;
      }[];
    }[];
  };
  result?: {
    /** A list of ids relating to the resource that was requested */
    contexts?: string[];
  };
}

/** N/A */
export interface GetContextHandoverEntities {
  /** N/A */
  contexts?: {
    /**
     * An unique context ref identifier.
     * @maxLength 14
     * @pattern ^[\w-]+$
     */
    id?: string;
    /** List of fields stored as key value pairs in the redis */
    fields?: {
      /**
       * field name.
       * @maxLength 256
       * @pattern ^[\w-]+$
       */
      fieldName?: string;
      /**
       * value of the field
       * @maxLength 256
       * @pattern ^[\w-\s\.]+$
       */
      value?: string;
    }[];
  }[];
}

/** A list of ids relating to the resource that was requested */
export type EntityResult = string[];

/** post the context handover data from redis cache */
export interface PostContextHandover {
  /**
   * AppId (Alfabet Id) of the targetApplication
   * @maxLength 30
   * @pattern ^[a-zA-Z0-9]+$
   */
  targetApplicationId: string;
  /** N/A */
  fields: {
    /**
     * field name.
     * @maxLength 256
     * @pattern ^[\w-]+$
     */
    fieldName?: string;
    /**
     * value of the field
     * @maxLength 256
     * @pattern ^[\w-\s\.]+$
     */
    value?: string;
  }[];
}

/** returns the context handover data and reference id for the posted contexts */
export interface PostContextsResponseEntities {
  /** N/A */
  entities?: {
    /** N/A */
    contexts?: {
      /**
       * It corresponds to the referenceId attribute from cap api response.
       * @maxLength 14
       * @pattern ^[\w-]+$
       */
      id?: string;
      /**
       * It corresponds to the referenceId attribute from cap api response.
       * @maxLength 14
       * @pattern ^[\w-]+$
       */
      referenceId?: string;
      /**
       * The url that the application is expected to redirect.
       * @maxLength 2000
       * @pattern ^((http[s]?):\/)?\/?([^:\/\s]+)((\/\w+)*\/)([\w\-\.]+[^#?\s]+)(.*)?(#[\w\-]+)?$
       */
      redirectUrl?: string;
      /**
       * The target frame for destination application.
       * @maxLength 256
       * @pattern ^[\w-]+$
       */
      targetFrameName?: string;
    }[];
  };
  result?: {
    /** A list of ids relating to the resource that was requested */
    contexts?: string[];
  };
}

/** N/A */
export interface PostContextsEntities {
  /** N/A */
  contexts?: {
    /**
     * It corresponds to the referenceId attribute from cap api response.
     * @maxLength 14
     * @pattern ^[\w-]+$
     */
    id?: string;
    /**
     * It corresponds to the referenceId attribute from cap api response.
     * @maxLength 14
     * @pattern ^[\w-]+$
     */
    referenceId?: string;
    /**
     * The url that the application is expected to redirect.
     * @maxLength 2000
     * @pattern ^((http[s]?):\/)?\/?([^:\/\s]+)((\/\w+)*\/)([\w\-\.]+[^#?\s]+)(.*)?(#[\w\-]+)?$
     */
    redirectUrl?: string;
    /**
     * The target frame for destination application.
     * @maxLength 256
     * @pattern ^[\w-]+$
     */
    targetFrameName?: string;
  }[];
}

/**
 * A unique identifier
 * @format uuid
 * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
 */
export type UUID = string;

export interface AmountObj {
  /**
   * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
   * @pattern ^\w{3}$
   * @example "AUD"
   */
  currencyCode?: string;
  /**
   * @pattern ^\d{1,13}\.\d{1,4}$
   * @example "1000.0000"
   */
  amount?: string;
  /** @example "CR" */
  position?: 'CR' | 'DR';
}

/**
 * Account ID (BSB and Account Number)
 * @example {"BSB":"035845","accountNumber":"10235674897"}
 */
export interface AccountIdObj {
  /**
   * Bank State Branch Number
   * @pattern ^\d{6}$
   * @example "135845"
   */
  BSB: string;
  /**
   * Account Number
   * @minLength 1
   * @maxLength 28
   * @pattern ^[a-zA-Z\d.]+$
   * @example "01235674897"
   */
  accountNumber: string;
}

/** Account Information for debtor or creditor */
export interface DebtorOrCreditorObj {
  /**
   * account name
   * @maxLength 255
   * @pattern ^[\w\- \/\'\(\)\&\+\@]+$
   * @example "John S"
   */
  name?: string;
  /**
   * account alias name (nickname)
   * @maxLength 255
   * @pattern ^[\w\- \/\'\(\)\&\+\@]+$
   * @example "Payroll account"
   */
  nickName?: string;
  /**
   * Full account number with format <BSB  Account Number> -> "035845 123456789"
   * @maxLength 35
   * @pattern ^[a-zA-Z\d. ].+$
   * @example "035845 103784254"
   */
  accountId?: string;
}

/**
 * @pattern ^\d{1,13}\.\d{1,4}$
 * @example "1000.0000"
 */
export type AmountStr = string;

/**
 * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
 * @pattern ^\w{3}$
 * @example "AUD"
 */
export type CurrencyCode = string;

/**
 * Full account number with format <BSB  Account Number> -> "035845 123456789"
 * @maxLength 35
 * @pattern ^[a-zA-Z\d. ].+$
 * @example "035845 103784254"
 */
export type AccountIdStr = string;

/** @example "Processed" */
export enum PaymentStatus {
  Processing = 'Processing',
  Processed = 'Processed',
  Failed = 'Failed',
}

/**
 * Field allowing some special characters
 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
 */
export type ISG_APPROVED_STRING = string;

/**
 * Field allowing some special characters
 * @pattern ^[\w\- \/\'\(\)\&\+\@]+$
 */
export type NAME_STRING = string;

/**
 * Field allowing emoji characters
 * @pattern ^(?!.*<\/).*
 */
export type EMOJI_STRING = string;

/** @example "Fast Payment" */
export enum PaymentMethodDescription {
  FundsTransfer = 'Funds transfer',
  FastPayment = 'Fast Payment',
  Osko = 'Osko',
  PayTo = 'PayTo',
  PayAnyone = 'Pay Anyone',
}

/**
 * @maxLength 35
 * @pattern ^[a-z0-9.-]+$
 * @example "npp.clear.01-sct.01"
 */
export type PaymentMethodCode = string;

/** The description of the identification of the payment scheme along with payment scheme code (only for staffs) */
export interface PaymentMethodObject {
  /**
   * @maxLength 35
   * @pattern ^[a-z0-9.-]+$
   * @example "npp.clear.01-sct.01"
   */
  code?: string;
  /** @example "Fast Payment" */
  description?: 'Funds transfer' | 'Fast Payment' | 'Osko' | 'PayTo' | 'Pay Anyone';
}

/**
 * Code allocated to a financial institution by the ISO 9362 Registration Authority as described in ISO 9362 "Banking - Banking telecommunication messages - Business identifier code (BIC)".<br> Usage- Caller to set this field to the new WIB BIC 'WPACAU2SONE'.
 * @maxLength 11
 * @pattern ^\w+$
 */
export type BICFI = string;

/** balance amount details. */
export interface CurrencyAndAmount {
  /**
   * The payment amount before deduction of charges, expressed in the currency as ordered by the initiating party.<br> Usage- Caller to map payment amount to this field.
   * @pattern \d{1,13}\.?\d{0,3}$
   */
  amount: string;
  /**
   * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
   * @pattern ^\w{3}$
   * @example "AUD"
   */
  currency: string;
}

/** Status reason information */
export interface StatusReasonInformationItems {
  /**
   * Status reason description.
   *
   *   Group status reason can have values -
   *     AccountEligibilityFailure
   *     DuplicatePayment
   *     ExternalValidationEnrichmentFailed
   *     PostingFailed
   *     PostingSucceeded
   *     ValidationFailure
   *
   *   Instruction status reason can have values -
   *     AccountEligibilityFailure
   *     InsufficientAccountBalance
   *     DebitPostingFailed
   *     DebitPostingSucceeded
   *     ExternalValidationEnrichmentFailed
   *     FraudCheckDeclined
   *     FraudCheckDelayed
   *     FraudCheckNotAvailable
   *     FraudCheckOnHold
   *     FraudCheckReferred
   *     FundsReservationFailed
   *     FundsReservationSucceeded
   *     InvalidExecutionDate
   *     ValidationFailure
   *
   *   Transaction status reason can have values -
   *     ClearingAndSettlementRejected
   *     AccountEligibilityFailure
   *     CreditPostingAborted
   *     CreditPostingFailed
   *     SchemeDeterminationFailed
   *     ValidationFailure
   * @maxLength 50
   * @pattern /^[\w ]+$/
   */
  reason?: string;
  /**
   * Further information about the above status reason from downstream.
   * @maxLength 120
   * @pattern /^[\w ]+$/
   */
  additionalInformation?: string;
}

/**
 * Information supplied to enable the matching/reconciliation of an entry with the items that the payment is intended to settle, such as commercial invoices in an accounts'' receivable system.
 * @maxItems 2
 */
export type Unstructured = string[];

/** Set of elements used to identify a person or an organisation. */
export interface PartyDetailsObj {
  /**
   * Unique and unambiguous identification of a person. For example, CIS Key of the debtor account.<br> Usage- Caller to map debtor's identification to this field.
   * @maxLength 35
   * @pattern /^[\w ]+$/
   */
  identification?: string;
  /**
   * Entity that assigns the identification.  Example- WPAC <br> Usage- Caller to set this field to 'WPAC'.
   * @maxLength 35
   * @pattern /^[\w ]+$/
   */
  issuer?: string;
  /**
   * Name by which a party is known, and which is usually used to identify sending party.<br> Usage- Caller to map debtor's name to this field.
   * @maxLength 140
   * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
   */
  name?: string;
}

/** Provides the details to identify an account. */
export interface AccountDetailsObj {
  /**
   * Full account number including BSB (without any separators or spaces).<br> Usage- Caller to map debit account number to this field.
   * @maxLength 34
   * @pattern ^[A-Za-z0-9\.]+$
   */
  identification?: string;
  /**
   * Entity that assigns the identification.<br> Usage- Caller to map this field to the 6-digit BSB number of the debit account.
   * @maxLength 6
   * @pattern ^\d{6}$
   */
  issuer?: string;
  /**
   * Name by which a party is known, and which is usually used to identify that party. For NPP payment, this is the Full Legal Account Name (FLAN). <br> Usage- For NPP payments, this field is expected to be provided by the payment enrichment system.
   * @maxLength 70
   * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
   */
  name?: string;
  /**
   * Name of the identification scheme, in a coded form as published in an external list.<br>
   *  Usage- Caller to set this field to 'BBAN' to represent Australian Bank-State-Branch Code (BSB) identification.
   * @maxLength 4
   * @pattern ^\w+$
   */
  schemeName?: string;
  /**
   * Debtor's account type represented as Canonical Product Code (CPC).<br> Usage- For future use.
   * @maxLength 35
   * @pattern ^\w+$
   */
  type?: string;
}

/**
 * aka Payment Alias also known as PayID.  This field will be populated if there was a payId type payment,
 * <br>Usage format-
 *    <br>For type TELI-  The telephone number must consist of a “+” followed by the country code (from 1 to 3 characters) then a “-“ & finally, any combination of numbers (up to 30 characters).Format pattern- ^\+[0-9]{1,3}-[1-9]{1,1}[0-9]{1,29}$ Example- +61-123456789
 *   <br> For type EMAL- Consists of a character string with a maximum length of 256 characters. This must include the “@” symbol with leading and trailing characters and no white spaces. Only lower case characters will be supported.
 *    Format pattern- Maximum of 256 characters ^(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)$ Example- 123@NPP.com
 *   <br> For type AUBN- This is assigned by the Australian Taxation Office to identify an individual Australian Business. Consists of a nine-to-eleven digit number. If the length is 9 digits than the last digit is the check digit. If the length is 11 digits, then an algorithm is used to validate the entire value as there is no check digit as such. Format pattern- ^((\d{9})|(\d{11}))$ Example- 601428737
 *    <br> For type ORGN- The Identifier must be representative of the company name, organisation name, trading name, associated product, campaign or an identifier recognisable as associated with the specific business or organisation, with no whitespace at the beginning or end. Maximum of 256 characters in lower case, to be drawn from Printable ASCII (decimal 32-126) and without leading or trailing whitespace. For avoidance of doubt, upper case letters (A-Z, decimal 65-90) are excluded.
 *    Format pattern- ^[!-@[-~][ -@[-~]{0,254}[!-@[-~]$ Example- ABC Pty. Ltd. Sydney NSW
 * @maxLength 256
 * @pattern ^[\d@a-zA-Z0-9!#$%&'*+\/=?^_`{|}~\.\x20-\x7E\+\-]+$
 * @example "tay.tay@westpac.com.au"
 */
export type AliasId = string;

/**
 * For a PayID payment, the type of the PayID.
 *   <br>TELI- Telephone Number
 *   <br>EMAL- Email Address
 *   <br>AUBN- Australian Business Number
 *   <br>ORGN- Organisation ID
 * @maxLength 4
 */
export enum AliasType {
  EMAL = 'EMAL',
  TELI = 'TELI',
  AUBN = 'AUBN',
  ORGN = 'ORGN',
}

/**
 * W1C to set this field to the BIC 'WPACAU3S'.
 * @maxLength 8
 * @default "WPACAU3S"
 */
export enum AuthBIC8 {
  WPACAU3S = 'WPACAU3S',
}

/** Payment Alias also known as PayID. */
export interface AliasObject {
  /**
   * aka Payment Alias also known as PayID.  This field will be populated if there was a payId type payment,
   * <br>Usage format-
   *    <br>For type TELI-  The telephone number must consist of a “+” followed by the country code (from 1 to 3 characters) then a “-“ & finally, any combination of numbers (up to 30 characters).Format pattern- ^\+[0-9]{1,3}-[1-9]{1,1}[0-9]{1,29}$ Example- +61-123456789
   *   <br> For type EMAL- Consists of a character string with a maximum length of 256 characters. This must include the “@” symbol with leading and trailing characters and no white spaces. Only lower case characters will be supported.
   *    Format pattern- Maximum of 256 characters ^(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)$ Example- 123@NPP.com
   *   <br> For type AUBN- This is assigned by the Australian Taxation Office to identify an individual Australian Business. Consists of a nine-to-eleven digit number. If the length is 9 digits than the last digit is the check digit. If the length is 11 digits, then an algorithm is used to validate the entire value as there is no check digit as such. Format pattern- ^((\d{9})|(\d{11}))$ Example- 601428737
   *    <br> For type ORGN- The Identifier must be representative of the company name, organisation name, trading name, associated product, campaign or an identifier recognisable as associated with the specific business or organisation, with no whitespace at the beginning or end. Maximum of 256 characters in lower case, to be drawn from Printable ASCII (decimal 32-126) and without leading or trailing whitespace. For avoidance of doubt, upper case letters (A-Z, decimal 65-90) are excluded.
   *    Format pattern- ^[!-@[-~][ -@[-~]{0,254}[!-@[-~]$ Example- ABC Pty. Ltd. Sydney NSW
   * @maxLength 256
   * @pattern ^[\d@a-zA-Z0-9!#$%&'*+\/=?^_`{|}~\.\x20-\x7E\+\-]+$
   * @example "tay.tay@westpac.com.au"
   */
  id?: string;
  /**
   * For a PayID payment, the type of the PayID.
   *   <br>TELI- Telephone Number
   *   <br>EMAL- Email Address
   *   <br>AUBN- Australian Business Number
   *   <br>ORGN- Organisation ID
   * @maxLength 4
   */
  type?: 'EMAL' | 'TELI' | 'AUBN' | 'ORGN';
  /**
   * W1C to set this field to the BIC 'WPACAU3S'.
   * @maxLength 8
   * @default "WPACAU3S"
   */
  authBIC8?: 'WPACAU3S';
}

/**
 * BSB for account.
 * @maxLength 6
 * @pattern ^\d{6}$
 */
export type AccountIssuer = string;

/** Schema code for example BBAN. */
export enum AccountSchemeName {
  BBAN = 'BBAN',
}

/**
 * A unique id generated to reference a specific payment transaction
 * @maxLength 36
 * @pattern ^\w+$
 */
export type PaymentId = string;

/**
 * Date and time at which the message was created.
 * @format date-time
 * @example "2024-01-28T15:27:49.732Z"
 */
export type CreationDateTime = string;

/**
 * Channel sending the request. Can be empty or null.
 *   e.g.
 * - W1C_O_B_D_CP - W1C_O_A_D_SP
 * @maxLength 100
 * @pattern ^[A-Z0-9_-]+$
 */
export type ChannelType = string;

/**
 * Beneficiary status; example-> ACTIVE, ARCHIVED
 * @example "ACTIVE"
 */
export enum BeneficiaryStatus {
  ACTIVE = 'ACTIVE',
  ARCHIVED = 'ARCHIVED',
}

/**
 * Beneficiary account type either Pay id or BSB & Account number
 * @example "BSB_AND_ACC"
 */
export enum BeneficiaryAccountType {
  PAYID = 'PAYID',
  BSB_AND_ACC = 'BSB_AND_ACC',
}

/**
 * Represents Account detail object
 * @example {"bsb":135845,"bankName":"Westpac Banking Corporation","accountNumber":11235674897,"accountName":"Apple Tree","payIDName":"John","payIDType":"EMAL","payIDValue":"john.doe@example.com"}
 */
export type Account =
  | {
      /**
       * Bank State Branch Number
       * @pattern ^\d{6}$
       * @example "135845"
       */
      bsb: string;
      /**
       * Name of Bank
       * @minLength 1
       * @maxLength 70
       * @pattern ^[\w ]+$
       * @example "Westpac Banking Corporation"
       */
      bankName: string;
      /**
       * Account Number
       * @minLength 1
       * @maxLength 28
       * @pattern ^[a-zA-Z\d.]+$
       * @example "01235674897"
       */
      accountNumber: string;
      /**
       * Account Name
       * @minLength 1
       * @maxLength 140
       * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
       * @example "Apple Tree"
       */
      accountName: string;
    }
  | ((
      | {
          /**
           * PayID type representing an Email address.
           * @example "EMAL"
           */
          payIDType: 'EMAL';
          /**
           * PAY ID value representing an Email address
           * @minLength 5
           * @maxLength 256
           * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
           * @example "john.doe@example.com"
           */
          payIDValue: string;
        }
      | {
          /**
           * PayID type representing a Telephone number.
           * @example "TELI"
           */
          payIDType: 'TELI';
          /**
           * PAY ID value representing a Telephone number
           * @minLength 2
           * @maxLength 30
           * @pattern ^\+([1-9]{1}[0-9]{1,2})[0-9]+$
           * @example "+61412345678"
           */
          payIDValue: string;
        }
      | {
          /**
           * PayID type representing an Organisation ID.
           * @example "ORGN"
           */
          payIDType: 'ORGN';
          /**
           * PAY ID value representing an Organisation number
           * @minLength 2
           * @maxLength 256
           * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
           * @example "ORG-12345"
           */
          payIDValue: string;
        }
      | {
          /**
           * PayID type representing an Australian Business Number (ABN).
           * @example "AUBN"
           */
          payIDType: 'AUBN';
          /**
           * PAY ID value representing an Australian Business Number (ABN)
           * @minLength 9
           * @maxLength 11
           * @pattern ^\d+$
           * @example "12345678910"
           */
          payIDValue: string;
        }
    ) & {
      /**
       * Beneficiary Nickname
       * @minLength 1
       * @maxLength 70
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "John"
       */
      payIDName: string;
    });

/** Object representing an account identified by BSB, bank name, account name, and account number. */
export interface BsbAccountObj {
  /**
   * Bank State Branch Number
   * @pattern ^\d{6}$
   * @example "135845"
   */
  bsb: string;
  /**
   * Name of Bank
   * @minLength 1
   * @maxLength 70
   * @pattern ^[\w ]+$
   * @example "Westpac Banking Corporation"
   */
  bankName: string;
  /**
   * Account Number
   * @minLength 1
   * @maxLength 28
   * @pattern ^[a-zA-Z\d.]+$
   * @example "01235674897"
   */
  accountNumber: string;
  /**
   * Account Name
   * @minLength 1
   * @maxLength 140
   * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
   * @example "Apple Tree"
   */
  accountName: string;
}

/**
 * Bank State Branch Number
 * @pattern ^\d{6}$
 * @example "135845"
 */
export type BSB = string;

/** Represents PayID object */
export type PayID = (
  | {
      /**
       * PayID type representing an Email address.
       * @example "EMAL"
       */
      payIDType: 'EMAL';
      /**
       * PAY ID value representing an Email address
       * @minLength 5
       * @maxLength 256
       * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
       * @example "john.doe@example.com"
       */
      payIDValue: string;
    }
  | {
      /**
       * PayID type representing a Telephone number.
       * @example "TELI"
       */
      payIDType: 'TELI';
      /**
       * PAY ID value representing a Telephone number
       * @minLength 2
       * @maxLength 30
       * @pattern ^\+([1-9]{1}[0-9]{1,2})[0-9]+$
       * @example "+61412345678"
       */
      payIDValue: string;
    }
  | {
      /**
       * PayID type representing an Organisation ID.
       * @example "ORGN"
       */
      payIDType: 'ORGN';
      /**
       * PAY ID value representing an Organisation number
       * @minLength 2
       * @maxLength 256
       * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
       * @example "ORG-12345"
       */
      payIDValue: string;
    }
  | {
      /**
       * PayID type representing an Australian Business Number (ABN).
       * @example "AUBN"
       */
      payIDType: 'AUBN';
      /**
       * PAY ID value representing an Australian Business Number (ABN)
       * @minLength 9
       * @maxLength 11
       * @pattern ^\d+$
       * @example "12345678910"
       */
      payIDValue: string;
    }
) & {
  /**
   * Beneficiary Nickname
   * @minLength 1
   * @maxLength 70
   * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
   * @example "John"
   */
  payIDName: string;
};

/** PAY ID with email */
export interface EmailPayID {
  /**
   * PayID type representing an Email address.
   * @example "EMAL"
   */
  payIDType: 'EMAL';
  /**
   * PAY ID value representing an Email address
   * @minLength 5
   * @maxLength 256
   * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
   * @example "john.doe@example.com"
   */
  payIDValue: string;
}

/** PAY ID with telephone number */
export interface TeliPayID {
  /**
   * PayID type representing a Telephone number.
   * @example "TELI"
   */
  payIDType: 'TELI';
  /**
   * PAY ID value representing a Telephone number
   * @minLength 2
   * @maxLength 30
   * @pattern ^\+([1-9]{1}[0-9]{1,2})[0-9]+$
   * @example "+61412345678"
   */
  payIDValue: string;
}

/** PAY ID with Organisation number */
export interface OrgnPayID {
  /**
   * PayID type representing an Organisation ID.
   * @example "ORGN"
   */
  payIDType: 'ORGN';
  /**
   * PAY ID value representing an Organisation number
   * @minLength 2
   * @maxLength 256
   * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
   * @example "ORG-12345"
   */
  payIDValue: string;
}

/** PAY ID with Australian Business number */
export interface AubnPayID {
  /**
   * PayID type representing an Australian Business Number (ABN).
   * @example "AUBN"
   */
  payIDType: 'AUBN';
  /**
   * PAY ID value representing an Australian Business Number (ABN)
   * @minLength 9
   * @maxLength 11
   * @pattern ^\d+$
   * @example "12345678910"
   */
  payIDValue: string;
}

/**
 * PayID type representing an Email address.
 * @example "EMAL"
 */
export enum PayIDTypeEmail {
  EMAL = 'EMAL',
}

/**
 * PayID type representing a Telephone number.
 * @example "TELI"
 */
export enum PayIDTypeTeli {
  TELI = 'TELI',
}

/**
 * PayID type representing an Organisation ID.
 * @example "ORGN"
 */
export enum PayIDTypeOrgn {
  ORGN = 'ORGN',
}

/**
 * PayID type representing an Australian Business Number (ABN).
 * @example "AUBN"
 */
export enum PayIDTypeAubn {
  AUBN = 'AUBN',
}

/**
 * PAY ID value representing an Email address
 * @minLength 5
 * @maxLength 256
 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
 * @example "john.doe@example.com"
 */
export type PayIDValueEmail = string;

/**
 * PAY ID value representing a Telephone number
 * @minLength 2
 * @maxLength 30
 * @pattern ^\+([1-9]{1}[0-9]{1,2})[0-9]+$
 * @example "+61412345678"
 */
export type PayIDValueTeli = string;

/**
 * PAY ID value representing an Organisation number
 * @minLength 2
 * @maxLength 256
 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
 * @example "ORG-12345"
 */
export type PayIDValueOrgn = string;

/**
 * PAY ID value representing an Australian Business Number (ABN)
 * @minLength 9
 * @maxLength 11
 * @pattern ^\d+$
 * @example "12345678910"
 */
export type PayIDValueAubn = string;

/**
 * Account Name
 * @minLength 1
 * @maxLength 140
 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
 * @example "Apple Tree"
 */
export type AccountName = string;

/**
 * Account Number
 * @minLength 1
 * @maxLength 28
 * @pattern ^[a-zA-Z\d.]+$
 * @example "01235674897"
 */
export type AccountNumber = string;

/**
 * Name of Bank
 * @minLength 1
 * @maxLength 70
 * @pattern ^[\w ]+$
 * @example "Westpac Banking Corporation"
 */
export type BankName = string;

/** Service level Identification Code */
export enum ServiceLevelIdentification {
  AUBSB = 'AUBSB',
}

/** Payment scheme. */
export enum PaymentLimitSchemeType {
  NPP = 'NPP',
  DE = 'DE',
}

/** Client context information */
export interface ClientContext {
  /**
   * Channel sending the request. Can be empty or null.
   *   e.g.
   * - W1C_O_B_D_CP - W1C_O_A_D_SP
   * @maxLength 100
   * @pattern ^[A-Z0-9_-]+$
   */
  channelType?: string;
}

/** healthcheck status */
export interface GetHealthCheckStatusData {
  status?: 'success';
}

export interface GetArrangementsData {
  entities?: {
    arrangements?: {
      /**
       * A unique id generated for an arrangement which is the mode of communication between the UI and Exp API
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id: string;
      /**
       * Full account number with format <BSB  Account Number> -> "035845 123456789"
       * @maxLength 35
       * @pattern ^[0-9]{6} [a-zA-Z\d.]{6,28}$
       * @example "035845 103784254"
       */
      accountNumber: string;
      /**
       * Arrangement owners' legal name
       * @maxLength 1000
       * @pattern ^[\w\- \/\'\(\)\&\+\@]+$
       */
      entityName: string;
      /**
       * Arrangement alias name
       * @maxLength 1000
       * @pattern ^[\w\- \/\'\(\)\&\+\@]+$
       */
      accountName: string;
      /**
       * Arrangement type; it is product name in master product system
       * @maxLength 1000
       * @pattern ^[\w ]+$
       */
      accountType: string;
      /** Arrangement status; example-> ACTIVE, INACTIVE */
      status: 'ACTIVE' | 'INACTIVE';
      /**
       * Arrangement currency code; example -> AUD
       * @pattern ^\w{3}$
       */
      currencyCode: string;
      /** The current balance held for the arrangement */
      currentBalance: string;
      /** The available balance held for the arrangement */
      availableBalance: string;
      /**
       * Arrangement available overdraft limit (credit limit)
       * @pattern ^\d{1,13}\.\d{1,4}$
       * @example "1000.0000"
       */
      overdraftLimit: string;
    }[];
    paging?: {
      /**
       * Paging Unique Id
       * @maxLength 3
       * @pattern ^\d+$
       * @example "1"
       */
      id?: string;
      /**
       * Number of items per page
       * @format int32
       * @example 50
       */
      pageSize?: number;
      /**
       * Total number of items available
       * @format int32
       * @example 160
       */
      count?: number;
      /**
       * Key for start of previous page
       * @maxLength 3
       * @pattern ^\d+$
       * @example "0"
       */
      previousPageKey?: string;
      /**
       * Key for start of next page
       * @maxLength 3
       * @pattern ^\d+$
       * @example "2"
       */
      nextPageKey?: string;
      /**
       * Indicator to show if there are more items available. If true, more records are available (by narrowing search parameters)
       * @example true
       */
      moreItems?: boolean;
    }[];
  };
  /** @example {"arrangements":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    arrangements?: string[];
  };
}

export interface PaymentCreateData {
  entities?: {
    paymentCreate?: {
      /**
       * Date and time at which the message was created.
       * @format date-time
       */
      creationDateTime?: string;
      /** Provides details on the original group, to which the message refers */
      groupInformation: {
        /**
         * Specifies the ISO status at the group level.Usage- For future use.
         * @maxLength 32
         * @pattern ^[\w ]+$
         */
        groupStatus: string;
        /**
         * Total of all individual amounts included in the original message, irrespective of currencies.
         * @maxLength 32
         * @pattern ^[\w ]+$
         */
        originalControlSum?: string;
        /**
         * Date and time at which the original message was created.
         * @format date-time
         */
        originalCreationDateTime: string;
        /**
         * Number of individual transactions contained in the original message.
         * @maxLength 32
         * @pattern ^[\w ]+$
         */
        originalNumberOfTransactions: string;
      };
      groupStatusReasonInformation?: {
        /**
         * Status reason description.
         *
         *   Group status reason can have values -
         *     AccountEligibilityFailure
         *     DuplicatePayment
         *     ExternalValidationEnrichmentFailed
         *     PostingFailed
         *     PostingSucceeded
         *     ValidationFailure
         *
         *   Instruction status reason can have values -
         *     AccountEligibilityFailure
         *     InsufficientAccountBalance
         *     DebitPostingFailed
         *     DebitPostingSucceeded
         *     ExternalValidationEnrichmentFailed
         *     FraudCheckDeclined
         *     FraudCheckDelayed
         *     FraudCheckNotAvailable
         *     FraudCheckOnHold
         *     FraudCheckReferred
         *     FundsReservationFailed
         *     FundsReservationSucceeded
         *     InvalidExecutionDate
         *     ValidationFailure
         *
         *   Transaction status reason can have values -
         *     ClearingAndSettlementRejected
         *     AccountEligibilityFailure
         *     CreditPostingAborted
         *     CreditPostingFailed
         *     SchemeDeterminationFailed
         *     ValidationFailure
         * @maxLength 50
         * @pattern ^[\w ]+$
         */
        reason?: string;
        /**
         * Further information about the above status reason from downstream.
         * @maxLength 120
         * @pattern ^[\w ]+$
         */
        additionalInformation?: string;
      }[];
      /**
       * Point to point reference, as assigned by the instructing party, and sent to the next party in the chain to identify the message. This field is mapped from the messageId in the CAP response.
       * @maxLength 35
       * @pattern ^[\w ]+$
       */
      id?: string;
      /** Information concerning the original payment information, to which the status report message refers. */
      paymentInformation?: {
        /**
         * Specifies the ISO status of the payment. Usage- Possible values -<br> ACSC- Accepted Settlement Completed (success) <br> ACSP- Accepted Settlement In Process (auto retry in progress in case of technical failure)<br> RJCT- Rejected
         * @maxLength 32
         * @pattern ^[\w ]+$
         */
        paymentInformationStatus: string;
        /**
         * Usage- Echoed from the request. This is mapped from the CAP response nested in supplementaryDataResponseObject
         * @maxLength 32
         * @pattern ^[\w ]+$
         */
        paymentId?: string;
      };
      paymentStatusReasonInformation?: {
        /**
         * Status reason description.
         *
         *   Group status reason can have values -
         *     AccountEligibilityFailure
         *     DuplicatePayment
         *     ExternalValidationEnrichmentFailed
         *     PostingFailed
         *     PostingSucceeded
         *     ValidationFailure
         *
         *   Instruction status reason can have values -
         *     AccountEligibilityFailure
         *     InsufficientAccountBalance
         *     DebitPostingFailed
         *     DebitPostingSucceeded
         *     ExternalValidationEnrichmentFailed
         *     FraudCheckDeclined
         *     FraudCheckDelayed
         *     FraudCheckNotAvailable
         *     FraudCheckOnHold
         *     FraudCheckReferred
         *     FundsReservationFailed
         *     FundsReservationSucceeded
         *     InvalidExecutionDate
         *     ValidationFailure
         *
         *   Transaction status reason can have values -
         *     ClearingAndSettlementRejected
         *     AccountEligibilityFailure
         *     CreditPostingAborted
         *     CreditPostingFailed
         *     SchemeDeterminationFailed
         *     ValidationFailure
         * @maxLength 50
         * @pattern ^[\w ]+$
         */
        reason?: string;
        /**
         * Further information about the above status reason from downstream.
         * @maxLength 120
         * @pattern ^[\w ]+$
         */
        additionalInformation?: string;
      }[];
      transactionInformation?: {
        /** Specifies the ISO status of the credit transaction within the payment, in case of on-us payments. <br> Usage-  Possible values- ACSC - Accepted Settlement Completed (success) RJCT - Rejected (posting rejected) ACSP - Accepted Settlement In Process (auto retry in progress in case of technical failure */
        transactionStatus?: 'ACSC' | 'RJCT' | 'ACSP';
        statusReasonInformation?: {
          /**
           * Status reason description.
           *
           *   Group status reason can have values -
           *     AccountEligibilityFailure
           *     DuplicatePayment
           *     ExternalValidationEnrichmentFailed
           *     PostingFailed
           *     PostingSucceeded
           *     ValidationFailure
           *
           *   Instruction status reason can have values -
           *     AccountEligibilityFailure
           *     InsufficientAccountBalance
           *     DebitPostingFailed
           *     DebitPostingSucceeded
           *     ExternalValidationEnrichmentFailed
           *     FraudCheckDeclined
           *     FraudCheckDelayed
           *     FraudCheckNotAvailable
           *     FraudCheckOnHold
           *     FraudCheckReferred
           *     FundsReservationFailed
           *     FundsReservationSucceeded
           *     InvalidExecutionDate
           *     ValidationFailure
           *
           *   Transaction status reason can have values -
           *     ClearingAndSettlementRejected
           *     AccountEligibilityFailure
           *     CreditPostingAborted
           *     CreditPostingFailed
           *     SchemeDeterminationFailed
           *     ValidationFailure
           * @maxLength 50
           * @pattern ^[\w ]+$
           */
          reason?: string;
          /**
           * Further information about the above status reason from downstream.
           * @maxLength 120
           * @pattern ^[\w ]+$
           */
          additionalInformation?: string;
        }[];
      }[];
    }[];
  };
  /** @example {"paymentCreate":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    paymentCreate?: string[];
  };
}

export interface PostPaymentReturnsData {
  entities?: {
    paymentreturns?: {
      /**
       * Point to point reference, as assigned by the instructing party, and sent to the next party in the chain to identify the message. This field is mapped from the messageId in the CAP response.
       * @maxLength 35
       * @pattern /^[\w ]+$/
       */
      id: string;
      /**
       * Date and time at which the message was created.
       * @format date-time
       */
      creationDateTime: string;
      /** Provides details on the original group, to which the message refers */
      groupInformation?: {
        /**
         * Date and time at which the original message was created.
         * @format date-time
         */
        originalCreationDateTime?: string;
        /**
         * Specifies the ISO status at the group level.Usage- For future use.
         * @maxLength 32
         * @pattern /^[\w ]+$/
         */
        groupStatus?: string;
      };
      groupStatusReasonInformation?: {
        /**
         * Status reason description.
         *
         *   Group status reason can have values -
         *     AccountEligibilityFailure
         *     DuplicatePayment
         *     ExternalValidationEnrichmentFailed
         *     PostingFailed
         *     PostingSucceeded
         *     ValidationFailure
         *
         *   Instruction status reason can have values -
         *     AccountEligibilityFailure
         *     InsufficientAccountBalance
         *     DebitPostingFailed
         *     DebitPostingSucceeded
         *     ExternalValidationEnrichmentFailed
         *     FraudCheckDeclined
         *     FraudCheckDelayed
         *     FraudCheckNotAvailable
         *     FraudCheckOnHold
         *     FraudCheckReferred
         *     FundsReservationFailed
         *     FundsReservationSucceeded
         *     InvalidExecutionDate
         *     ValidationFailure
         *
         *   Transaction status reason can have values -
         *     ClearingAndSettlementRejected
         *     AccountEligibilityFailure
         *     CreditPostingAborted
         *     CreditPostingFailed
         *     SchemeDeterminationFailed
         *     ValidationFailure
         * @maxLength 50
         * @pattern /^[\w ]+$/
         */
        reason?: string;
        /**
         * Further information about the above status reason from downstream.
         * @maxLength 120
         * @pattern /^[\w ]+$/
         */
        additionalInformation?: string;
      }[];
      transactionStatusInformation?: {
        /** Specifies the ISO status of the credit transaction within the payment, in case of on-us payments. <br> Usage-  Possible values- ACSC - Accepted Settlement Completed (success) RJCT - Rejected (posting rejected) ACSP - Accepted Settlement In Process (auto retry in progress in case of technical failure */
        transactionStatus?: 'ACSC' | 'RJCT' | 'ACSP';
        statusReasonInformation?: {
          /**
           * Status reason description.
           *
           *   Group status reason can have values -
           *     AccountEligibilityFailure
           *     DuplicatePayment
           *     ExternalValidationEnrichmentFailed
           *     PostingFailed
           *     PostingSucceeded
           *     ValidationFailure
           *
           *   Instruction status reason can have values -
           *     AccountEligibilityFailure
           *     InsufficientAccountBalance
           *     DebitPostingFailed
           *     DebitPostingSucceeded
           *     ExternalValidationEnrichmentFailed
           *     FraudCheckDeclined
           *     FraudCheckDelayed
           *     FraudCheckNotAvailable
           *     FraudCheckOnHold
           *     FraudCheckReferred
           *     FundsReservationFailed
           *     FundsReservationSucceeded
           *     InvalidExecutionDate
           *     ValidationFailure
           *
           *   Transaction status reason can have values -
           *     ClearingAndSettlementRejected
           *     AccountEligibilityFailure
           *     CreditPostingAborted
           *     CreditPostingFailed
           *     SchemeDeterminationFailed
           *     ValidationFailure
           * @maxLength 50
           * @pattern /^[\w ]+$/
           */
          reason?: string;
          /**
           * Further information about the above status reason from downstream.
           * @maxLength 120
           * @pattern /^[\w ]+$/
           */
          additionalInformation?: string;
        }[];
        /** W1C Echoed from the request. */
        supplementaryData?: {
          /**
           * Usage- Echoed from the request, mapped from originalEndToEndIdentification.
           * @maxLength 32
           * @pattern ^\w+$
           */
          id?: string;
        };
      }[];
    }[];
  };
  result?: {
    /** A list of ids relating to the resource that was requested */
    paymentreturns?: string[];
  };
}

export interface PostPaymentDetailsData {
  entities?: {
    paymentDetails?: {
      /**
       * A unique id generated for each record which is the mode of communication between the UI and Exp API
       * @format uuid
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * payment status; This property can have these values -> Submitted, Processing, Processed, Failed
       * @example "Processed"
       */
      status?: 'Processing' | 'Processed' | 'Failed';
      /**
       * Date and time at which the message was created.
       * @format date-time
       * @example "2024-01-28T15:27:49.732Z"
       */
      creationDateTime?: string;
      /** The transaction amount */
      amount?: {
        /**
         * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
         * @pattern ^\w{3}$
         * @example "AUD"
         */
        currencyCode?: string;
        /**
         * @pattern ^\d{1,13}\.\d{1,4}$
         * @example "1000.0000"
         */
        amount?: string;
        /** @example "CR" */
        position?: 'CR' | 'DR';
      };
      /** @example true */
      reversalIndicator?: boolean;
      /** Debtor's account nickname and account number in multi-line; applicable for outbound payment and funds transfer. */
      debitAccount?: {
        /**
         * account name
         * @maxLength 255
         * @pattern ^[\w\- \/\'\(\)\&\+\@]+$
         * @example "John S"
         */
        name?: string;
        /**
         * account alias name (nickname)
         * @maxLength 255
         * @pattern ^[\w\- \/\'\(\)\&\+\@]+$
         * @example "Payroll account"
         */
        nickName?: string;
        /**
         * Full account number with format <BSB  Account Number> -> "035845 123456789"
         * @maxLength 35
         * @pattern ^[a-zA-Z\d. ].+$
         * @example "035845 103784254"
         */
        accountId?: string;
      };
      /**
       * Debit description
       * @maxLength 35
       * @pattern ^(?!.*<\/).*
       * @example "some text here"
       */
      debitDescription?: string;
      /** Creditor's name, nickname, and account number in multi-line; applicable for outbound payments */
      beneficiary?: {
        /**
         * account name
         * @maxLength 255
         * @pattern ^[\w\- \/\'\(\)\&\+\@]+$
         * @example "John S"
         */
        name?: string;
        /**
         * account alias name (nickname)
         * @maxLength 255
         * @pattern ^[\w\- \/\'\(\)\&\+\@]+$
         * @example "Payroll account"
         */
        nickName?: string;
        /**
         * Full account number with format <BSB  Account Number> -> "035845 123456789"
         * @maxLength 35
         * @pattern ^[a-zA-Z\d. ].+$
         * @example "035845 103784254"
         */
        accountId?: string;
      };
      /** Creditor's account nickname and account number in multi-line; applicable for funds transafer. */
      creditAccount?: {
        /**
         * account name
         * @maxLength 255
         * @pattern ^[\w\- \/\'\(\)\&\+\@]+$
         * @example "John S"
         */
        name?: string;
        /**
         * account alias name (nickname)
         * @maxLength 255
         * @pattern ^[\w\- \/\'\(\)\&\+\@]+$
         * @example "Payroll account"
         */
        nickName?: string;
        /**
         * Full account number with format <BSB  Account Number> -> "035845 123456789"
         * @maxLength 35
         * @pattern ^[a-zA-Z\d. ].+$
         * @example "035845 103784254"
         */
        accountId?: string;
      };
      /**
       * Credit description
       * @maxLength 280
       * @pattern ^(?!.*<\/).*
       * @example "some text here"
       */
      creditorDescription?: string;
      /**
       * A supplied reference for the credit transfer information, that appears on both the debtor and the creditor's account.
       * For example, the identification used to reconcile an accounts payable with an accounts receivable (e.g. a receipt or invoice number)
       * @maxLength 35
       * @pattern ^[\w\. -]+$
       * @example "some text here"
       */
      reference?: string;
      /** The description of the identification of the payment scheme along with payment scheme code (only for staffs) */
      paymentMethod?: {
        /**
         * @maxLength 35
         * @pattern ^[a-z0-9.-]+$
         * @example "npp.clear.01-sct.01"
         */
        code?: string;
        /** @example "Fast Payment" */
        description?: 'Funds transfer' | 'Fast Payment' | 'Osko' | 'PayTo' | 'Pay Anyone';
      };
      /** Additional Westpac Data Elements to support the PAYMENT transaction (Credit). */
      supplementaryData?: {
        /**
         * Payment Alias also known as PayID.  <br>Usage format-
         *   <br>For type TELI-  The telephone number must consist of a “+” followed by the country code (from 1 to 3 characters) then
         *   a “-“ & finally, any combination of numbers (up to 30 characters).Format pattern- ^\+[0-9]{1,3}-[1-9]{1,1}[0-9]{1,29}$ Example- +61-123456789
         *   <br> For type EMAL- Consists of a character string with a maximum length of 256 characters. This must include the
         *   “@” symbol with leading and trailing characters and no white spaces. Only lower case characters will be supported.
         *     Format pattern- Maximum of 256 characters ^(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)$
         *     Example- 123@NPP.com
         *   <br> For type AUBN- This is assigned by the Australian Taxation Office to identify an individual Australian Business.
         *   Consists of a nine-to-eleven digit number. If the length is 9 digits than the last digit is the check digit.
         *   If the length is 11 digits, then an algorithm is used to validate the entire value as there is no check digit as such.
         *   Format pattern- ^((\d{9})|(\d{11}))$ Example- 601428737
         *   <br> For type ORGN- The Identifier must be representative of the company name, organisation name, trading name,
         *   associated product, campaign or an identifier recognisable as associated with the specific business or organisation,
         *   with no whitespace at the beginning or end. Maximum of 256 characters in lower case, to be drawn from Printable ASCII
         *   (decimal 32-126) and without leading or trailing whitespace. For avoidance of doubt, upper case letters (A-Z, decimal 65-90) are excluded.
         *   Format pattern- ^[!-@[-~][ -@[-~]{0,254}[!-@[-~]$ Example- ABC Pty. Ltd. Sydney NSW
         *   <br>Usage- For future use.
         * @maxLength 2048
         * @pattern ^[\w ]+$
         * @example "601428737"
         */
        aliasId?: string;
        /**
         * For a PayID payment, the type of the PayID.
         *   <br>TELI- Telephone Number
         *   <br>EMAL- Email Address
         *   <br>AUBN- Australian Business Number
         *   <br>ORGN- Organisation ID
         * @maxLength 4
         */
        aliasType?: 'EMAL' | 'TELI' | 'AUBN' | 'ORGN';
      };
      /**
       * The unique transaction ID generated by Channel / FIS to trace transactions for customers to allow them to query.
       * @maxLength 36
       * @pattern ^[\w-]+$
       * @example "WP123456789"
       */
      receiptNumber?: string;
    }[];
  };
  /** @example {"paymentDetails":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    paymentDetails?: string[];
  };
}

export interface PostPaymentListingData {
  entities?: {
    paymentListing?: {
      /**
       * A unique id generated for each record which is the mode of communication between the UI and Exp API
       * @format uuid
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       * @example "d0868661-b955-4e76-9f15-d97626f7df6b"
       */
      id?: string;
      /**
       * payment status; This property can have these values -> Submitted, Processing, Processed, Failed
       * @example "Processed"
       */
      status?: 'Processing' | 'Processed' | 'Failed';
      /**
       * Date and time at which the message was created in ISO 8601 format.
       * @format date-time
       * @example "2024-01-28T15:27:49.732Z"
       */
      creationDateTime?: string;
      /**
       * The transaction amount
       * @pattern ^\d{1,13}\.\d{1,4}$
       * @example "1000.0000"
       */
      amount?: string;
      /**
       * The transaction currency. Standard ISO 4217 currency names.
       * @pattern ^[A-Z]{3}$
       * @example "AUD"
       */
      currency?: string;
      /**
       * Debtor's account nickname
       * @maxLength 176
       * @pattern ^[\w\- \/\'\(\)\&\+\@]+$
       * @example "Finances"
       */
      debitAccountName?: string;
      /**
       * Debtor's account number in multi-line
       * @maxLength 176
       * @pattern ^[a-zA-Z0-9.]+$
       * @example "035845103784254"
       */
      debitAccountIdentification?: string;
      /**
       * Debit description
       * @maxLength 35
       * @pattern ^(?!.*<\/).*
       */
      debitDescription?: string;
      /**
       * The Beneficiary name, applicable for outbound payments
       * @maxLength 176
       * @pattern ^[\w\- \/\'\(\)\&\+\@]+$
       * @example "John Citizen"
       */
      beneficiaryName?: string;
      /**
       * Creditor's account nickname
       * @maxLength 176
       * @pattern ^[\w\- \/\'\(\)\&\+\@]+$
       * @example "Supplier"
       */
      creditAccountName?: string;
      /**
       * Creditor's account identifier (For Non PayID Payments this will be a BSB+AccountNumber)
       * @maxLength 176
       * @pattern ^[a-zA-Z0-9.]+$
       * @example "35845103784254"
       */
      creditAccountIdentification?: string;
      /**
       * The description of the identification of the payment scheme
       * @example "Fast Payment"
       */
      paymentMethod?: 'Funds transfer' | 'Fast Payment' | 'Osko' | 'PayTo' | 'Pay Anyone';
      /**
       * The unique transaction ID generated by Channel / FIS to trace transactions for customers to allow them to query.
       * @maxLength 36
       * @pattern ^\w+$
       * @example "WP123456789"
       */
      receiptNumber?: string;
      /**
       * ITRID - Instruction Trace ID.
       * @format uuid
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       * @example "e4d2844e-5207-43f3-839a-1f4895846a18"
       */
      instructionTraceIdentification?: string;
      /** Additional Westpac Data Elements to support the PAYMENT transaction (Credit). */
      supplementaryData?: {
        /**
         * aka Payment Alias also known as PayID.  This field will be populated if there was a payId type payment,
         * <br>Usage format-
         *    <br>For type TELI-  The telephone number must consist of a “+” followed by the country code (from 1 to 3 characters) then a “-“ & finally, any combination of numbers (up to 30 characters).Format pattern- ^\+[0-9]{1,3}-[1-9]{1,1}[0-9]{1,29}$ Example- +61-123456789
         *   <br> For type EMAL- Consists of a character string with a maximum length of 256 characters. This must include the “@” symbol with leading and trailing characters and no white spaces. Only lower case characters will be supported.
         *    Format pattern- Maximum of 256 characters ^(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)$ Example- 123@NPP.com
         *   <br> For type AUBN- This is assigned by the Australian Taxation Office to identify an individual Australian Business. Consists of a nine-to-eleven digit number. If the length is 9 digits than the last digit is the check digit. If the length is 11 digits, then an algorithm is used to validate the entire value as there is no check digit as such. Format pattern- ^((\d{9})|(\d{11}))$ Example- 601428737
         *    <br> For type ORGN- The Identifier must be representative of the company name, organisation name, trading name, associated product, campaign or an identifier recognisable as associated with the specific business or organisation, with no whitespace at the beginning or end. Maximum of 256 characters in lower case, to be drawn from Printable ASCII (decimal 32-126) and without leading or trailing whitespace. For avoidance of doubt, upper case letters (A-Z, decimal 65-90) are excluded.
         *    Format pattern- ^[!-@[-~][ -@[-~]{0,254}[!-@[-~]$ Example- ABC Pty. Ltd. Sydney NSW
         * @maxLength 256
         * @pattern ^[\d@a-zA-Z0-9!#$%&'*+\/=?^_`{|}~\.\x20-\x7E\+\-]+$
         * @example "tay.tay@westpac.com.au"
         */
        aliasId?: string;
        /**
         * For a PayID payment, the type of the PayID.
         *   <br>TELI- Telephone Number
         *   <br>EMAL- Email Address
         *   <br>AUBN- Australian Business Number
         *   <br>ORGN- Organisation ID
         * @maxLength 4
         */
        aliasType?: 'EMAL' | 'TELI' | 'AUBN' | 'ORGN';
      };
    }[];
    paging?: {
      /**
       * Paging Unique Id
       * @maxLength 3
       * @pattern ^\d+$
       * @example "1"
       */
      id?: string;
      /**
       * Number of items per page
       * @format int32
       * @example 50
       */
      pageSize?: number;
      /**
       * Total number of items available
       * @format int32
       * @example 160
       */
      count?: number;
      /**
       * Key for start of previous page
       * @maxLength 3
       * @pattern ^\d+$
       * @example "0"
       */
      previousPageKey?: string;
      /**
       * Key for start of next page
       * @maxLength 3
       * @pattern ^\d+$
       * @example "2"
       */
      nextPageKey?: string;
      /**
       * Indicator to show if there are more items available. If true, more records are available (by narrowing search parameters)
       * @example true
       */
      moreItems?: boolean;
    }[];
  };
  /** @example {"paymentListing":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    paymentListing?: string[];
  };
}

export interface PostAliasLookupData {
  entities?: {
    aliasLookup?: {
      /**
       * A unique id generated for a lookup result which is the mode of communication between the UI and Exp API
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * Alias Type of the beneficiary
       * @maxLength 4
       */
      aliasType?: 'EMAL' | 'TELI' | 'AUBN' | 'ORGN';
      /**
       * Nickname of the beneficiary
       * @minLength 1
       * @maxLength 70
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "John"
       */
      name?: string;
      /**
       * The date/time when the alias was resolved.
       * @format date-time
       */
      resolutionDateTime?: string;
      /**
       * The response code mapped from the provider service.
       * @minLength 1
       * @maxLength 5
       * @pattern ^[0-9]+$
       * @example 200
       */
      returnCode?: any;
    }[];
  };
  /** @example {"aliasLookup":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    aliasLookup?: string[];
  };
}

export interface PostAliasLookupByBeneIdData {
  entities?: {
    aliasLookupByBeneId?: {
      /**
       * A unique id generated for a lookup result which is the mode of communication between the UI and Exp API
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * Alias Type of the beneficiary
       * @maxLength 4
       */
      aliasType?: 'EMAL' | 'TELI' | 'AUBN' | 'ORGN';
      /**
       * Nickname of the beneficiary
       * @minLength 1
       * @maxLength 70
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "John"
       */
      name?: string;
      /**
       * The date/time when the alias was resolved.
       * @format date-time
       */
      resolutionDateTime?: string;
      /**
       * The response code mapped from the provider service.
       * @minLength 1
       * @maxLength 5
       * @pattern ^[0-9]+$
       * @example 200
       */
      returnCode?: any;
    }[];
  };
  /** @example {"aliasLookupByBeneId":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    aliasLookupByBeneId?: string[];
  };
}

export interface PostSchemeEligibilitiesData {
  entities?: {
    schemeEligibilities?: {
      /**
       * A unique id generated for each record which is the mode of communication between the UI and Exp API
       * @format uuid
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /** The description of the identification of the payment scheme along with payment scheme code (only for staffs) */
      paymentMethod?: {
        /**
         * @maxLength 35
         * @pattern ^[a-z0-9.-]+$
         * @example "npp.clear.01-sct.01"
         */
        code?: string;
        /** @example "Fast Payment" */
        description?: 'Funds transfer' | 'Fast Payment' | 'Osko' | 'PayTo' | 'Pay Anyone';
      };
    }[];
  };
  /** @example {"schemeEligibilities":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    schemeEligibilities?: string[];
  };
}

export interface GetGeneratePaymentIdentifierData {
  entities?: {
    paymentIdentifier?: string;
  };
  /** @example {"paymentIdentifier":["6550a5e9-0b08-47a2-8dc8-91b9e4207802"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    paymentIdentifier?: string[];
  };
}

export interface RetrieveBeneficiariesData {
  entities?: {
    beneficiaryList?: {
      /**
       * Unique id for the beneficiary.
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * External id for the beneficiary, used for cross-system references.
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      externalId?: string;
      /**
       * Beneficiary Nickname
       * @minLength 1
       * @maxLength 70
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "John"
       */
      nickname?: string;
      /**
       * Status; example-> ACTIVE, INACTIVE
       * @example "ACTIVE"
       */
      status?: 'ACTIVE' | 'INACTIVE';
      /** A qualified amount and denomination of a monetary value. */
      currencyAmount?: {
        /** A positive or negative number string of up to four decimal places (including zero). Must have at least one digit after the decimal point. */
        amount?: string;
        /**
         * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
         * @pattern ^[A-Z]{3}$
         * @example "AUD"
         */
        currencyCode: string;
      };
      /**
       * CIS Key of the organisation
       * @pattern ^\d{11}$
       * @example "06089457589"
       */
      org?: string;
      /**
       * Beneficiary account type either Pay id or BSB & Account number
       * @example "BSB_ACCOUNT_NUMBER"
       */
      type?: 'PAYID' | 'BSB_ACCOUNT_NUMBER';
      /**
       * Unique payment identifier for end-to-end transaction tracking and reconciliation.
       * @maxLength 35
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "INV-123456790"
       */
      reference?: string;
      /**
       * Represents Account detail object
       * @example {"accountId":{"accountNumber":"01235674897","BSB":"035845"},"accountName":"Apple Tree","bankName":"Westpac Banking Corporation"}
       */
      account?:
        | {
            /**
             * Account ID (BSB and Account Number)
             * @example {"BSB":"035845","accountNumber":"10235674897"}
             */
            accountId: {
              /**
               * Bank State Branch Number
               * @pattern ^\d{6}$
               * @example "035845"
               */
              BSB: string;
              /**
               * Account Number
               * @minLength 6
               * @maxLength 28
               * @pattern ^[a-zA-Z\d.]+$
               * @example "01235674897"
               */
              accountNumber: string;
            };
            /**
             * Account Name
             * @minLength 1
             * @maxLength 140
             * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
             * @example "Apple Tree"
             */
            accountName: string;
            /**
             * Name of Bank
             * @minLength 1
             * @maxLength 70
             * @pattern ^[\w ]+$
             * @example "Westpac Banking Corporation"
             */
            bankName: string;
          }
        | (
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Email address.
                 * @example "EMAL"
                 */
                payIDType: 'EMAL';
                /**
                 * PAY ID value representing an Email address
                 * @minLength 5
                 * @maxLength 256
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "john.doe@example.com"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing a Telephone number.
                 * @example "TELI"
                 */
                payIDType: 'TELI';
                /**
                 * PAY ID value representing a Telephone number
                 * @minLength 2
                 * @maxLength 30
                 * @pattern ^\+([1-9]{1}[0-9]{1,2})[-]{0,1}[0-9]+$
                 * @example "+61412345678"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Organisation ID.
                 * @example "ORGN"
                 */
                payIDType: 'ORGN';
                /**
                 * PAY ID value representing an Organisation number
                 * @minLength 2
                 * @maxLength 256
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "ORG-12345"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Australian Business Number (ABN).
                 * @example "AUBN"
                 */
                payIDType: 'AUBN';
                /**
                 * PAY ID value representing an Australian Business Number (ABN)
                 * @minLength 9
                 * @maxLength 11
                 * @pattern ^\d+$
                 * @example "12345678910"
                 */
                payIDValue: string;
              }
          );
    }[];
    paging?: {
      /**
       * Paging Unique Id
       * @maxLength 3
       * @pattern ^\d+$
       * @example "1"
       */
      id?: string;
      /**
       * Number of items per page
       * @format int32
       * @example 50
       */
      pageSize?: number;
      /**
       * Total number of items available
       * @format int32
       * @example 160
       */
      count?: number;
      /**
       * Key for start of previous page
       * @maxLength 3
       * @pattern ^\d+$
       * @example "0"
       */
      previousPageKey?: string;
      /**
       * Key for start of next page
       * @maxLength 3
       * @pattern ^\d+$
       * @example "2"
       */
      nextPageKey?: string;
      /**
       * Indicator to show if there are more items available. If true, more records are available (by narrowing search parameters)
       * @example true
       */
      moreItems?: boolean;
    }[];
  };
  /** @example {"beneficiaryList":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    beneficiaryList?: string[];
  };
}

export interface GetPaymentLimitsData {
  /** Entities containing payment limits */
  entities?: {
    /** List of payment limit objects */
    paymentLimits?: {
      /**
       * A unique id generated for each record which is the mode of communication between the UI and Exp API
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /** The level at which the payment limit applies */
      level?: 'User' | 'OrganisationChannel' | 'SchemeChannel';
      /**
       * Unique identifier for the channel
       * @pattern ^A[0-9A-F]{5}$
       */
      channelId?: string;
      /** Type of scheme for the payment limit */
      scheme?: 'NPP' | 'DE';
      /**
       * Timestamp when the payment limit was recorded
       * @format date-time
       */
      recordedTs?: string;
      /** Transaction limit details */
      transactionLimit?: {
        /**
         * Transaction limit amount
         * @deprecated
         */
        amount?: {
          /**
           * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
           * @pattern ^[A-Z]{3}$
           * @example "AUD"
           */
          currencyCode?: string;
          /**
           * A positive number string of up to four decimal places (including zero). Must have at least one digit after the decimal point.
           * @pattern ^\d{1,13}\.\d{1,4}$
           * @example "1000.0000"
           */
          amount?: string;
          /** @example "CR" */
          position?: 'CR' | 'DR';
        };
      };
      /** Daily limit details */
      dailyLimit?: {
        /**
         * Daily limit amount
         * @deprecated
         */
        amount?: {
          /**
           * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
           * @pattern ^[A-Z]{3}$
           * @example "AUD"
           */
          currencyCode?: string;
          /**
           * A positive number string of up to four decimal places (including zero). Must have at least one digit after the decimal point.
           * @pattern ^\d{1,13}\.\d{1,4}$
           * @example "1000.0000"
           */
          amount?: string;
          /** @example "CR" */
          position?: 'CR' | 'DR';
        };
        /**
         * Remaining daily limit amount
         * @deprecated
         */
        remainingAmount?: {
          /**
           * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
           * @pattern ^[A-Z]{3}$
           * @example "AUD"
           */
          currencyCode?: string;
          /**
           * A positive number string of up to four decimal places (including zero). Must have at least one digit after the decimal point.
           * @pattern ^\d{1,13}\.\d{1,4}$
           * @example "1000.0000"
           */
          amount?: string;
          /** @example "CR" */
          position?: 'CR' | 'DR';
        };
      };
    }[];
  };
  /**
   * Result object containing payment limits entity result
   * @example {"paymentLimits":["5ab2ba7e-8f5f-45dc-9bc6-0d18ffb53c2e"]}
   */
  result?: {
    /** Entity result for payment limits */
    paymentLimits?: string[];
  };
}

export interface PostValidatePaymentLimitsData {
  entities?: {
    /** List of validate payment limits entities */
    validatePaymentLimits?: {
      /**
       * Unique identifier for the validation result
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id: string;
      /** Indicates if the payment limit validation was successful */
      isSuccess: boolean;
      /** Error code for the validation */
      code?: number;
      /**
       * Message describing the validation result
       * @maxLength 100
       * @pattern ^[\w ]+$
       */
      message?: string;
      /**
       * Additional details about the validation result
       * @maxLength 100
       * @pattern ^[\w ]+$
       */
      details?: string;
    }[];
  };
  /**
   * Result object containing validation results
   * @example {"validatePaymentLimits":["5ab2ba7e-8f5f-45dc-9bc6-0d18ffb53c2e"]}
   */
  result?: {
    /** Entity result for validate payment limits */
    validatePaymentLimits?: string[];
  };
}

export interface PostArrangementDetailsData {
  entities?: {
    arrangementDetails?: {
      /**
       * A unique id generated for an arrangement which is the mode of communication between the UI and Exp API
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * Full account number with format <BSB  Account Number> -> "035845 123456789"
       * @maxLength 35
       * @pattern ^[0-9]{6} [a-zA-Z\d.]{6,28}$
       * @example "035845 103784254"
       */
      accountId?: string;
      /**
       * Entity Name
       * @minLength 1
       * @maxLength 250
       * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
       * @example "Bayer, Miller and MacGyver"
       */
      entityName?: string;
      /**
       * Arrangement alias name
       * @maxLength 50
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       */
      accountName?: string;
      /**
       * Account type; it is product name in master product system
       * @minLength 1
       * @maxLength 250
       * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
       * @example "Corporate Investment Account"
       */
      accountType?: string;
      /**
       * Status; example-> ACTIVE, INACTIVE
       * @example "ACTIVE"
       */
      status?: 'ACTIVE' | 'INACTIVE';
      /**
       * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
       * @pattern ^[A-Z]{3}$
       * @example "AUD"
       */
      currencyCode?: string;
      /** The current balance held for the arrangement */
      currentBalance?: string;
      /** The available balance held for the arrangement */
      availableBalance?: string;
      /**
       * Arrangement available overdraft limit (credit limit)
       * @pattern ^\d{1,13}\.\d{1,4}$
       * @example "1000.0000"
       */
      overdraftLimit?: string;
      /**
       * Start Date for the arrangement converted to ISO 8601 format
       * @format date-time
       * @example "2024-01-28T15:27:49.732Z"
       */
      startDateTime?: string;
      /**
       * Start Date for the arrangement converted to ISO 8601 format
       * @format date-time
       * @example "2024-05-12T11:56:42.124Z"
       */
      closedDateTime?: string;
      /** Contains list of account link */
      accountLinks?: {
        /**
         * A unique identifier
         * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
         */
        id: string;
        /**
         * Account ID (BSB and Account Number)
         * @example {"BSB":"035845","accountNumber":"10235674897"}
         */
        sourceAccountId: {
          /**
           * Bank State Branch Number
           * @pattern ^\d{6}$
           * @example "035845"
           */
          BSB: string;
          /**
           * Account Number
           * @minLength 6
           * @maxLength 28
           * @pattern ^[a-zA-Z\d.]+$
           * @example "01235674897"
           */
          accountNumber: string;
        };
        /**
         * Account ID (BSB and Account Number)
         * @example {"BSB":"035845","accountNumber":"10235674897"}
         */
        targetAccountId: {
          /**
           * Bank State Branch Number
           * @pattern ^\d{6}$
           * @example "035845"
           */
          BSB: string;
          /**
           * Account Number
           * @minLength 6
           * @maxLength 28
           * @pattern ^[a-zA-Z\d.]+$
           * @example "01235674897"
           */
          accountNumber: string;
        };
        /**
         * Link type
         * @example "INTEREST_APPLICATION"
         */
        type: 'INTEREST_APPLICATION' | 'BALANCE_OFFSET';
      }[];
      /** Authorised debit interest */
      debitRateWithinLimit?: {
        /**
         * Interest Rate, this field will only be populated if `calculationMethod` is `FLAT`.
         * @example 0.0285
         */
        interestRate?: number;
        /** @example "VARIABLE" */
        fixedVariableType: 'FIXED' | 'VARIABLE';
        /**
         * If value is `TIER` or `BAND`, the respective `...TierBands` field will be populated with the respective rates.
         * @example "BAND"
         */
        calculationMethod: 'TIER' | 'BAND' | 'FLAT';
      };
      /** Authorised debit interest Tiers / Bands. This is populated if `debitRateWithinLimit.calculationMethod` is `TIER` or `BAND`. */
      debitRateWithinLimitTierBands?: {
        /** @example 0 */
        startRange: number;
        /** @example 1000 */
        endRange: number;
        /**
         * Percentage value with 1-2 digits before the decimal point and 1-4 digits after
         * @pattern ^\d{1,2}\.\d{1,4}$
         * @example "12.3456"
         */
        interestRate: string;
        /**
         * Percentage value with 1-2 digits before the decimal point and 1-4 digits after
         * @pattern ^\d{1,2}\.\d{1,4}$
         * @example "12.3456"
         */
        spread?: string;
        /** @example "ADD" */
        operator?: 'ADD' | 'SUBTRACT';
      }[];
      /** Beyond authorised limit */
      debitRateAboveLimit?: {
        /**
         * Interest Rate, this field will only be populated if `calculationMethod` is `FLAT`.
         * @example 0.0285
         */
        interestRate?: number;
        /** @example "VARIABLE" */
        fixedVariableType: 'FIXED' | 'VARIABLE';
        /**
         * If value is `TIER` or `BAND`, the respective `...TierBands` field will be populated with the respective rates.
         * @example "BAND"
         */
        calculationMethod: 'TIER' | 'BAND' | 'FLAT';
      };
      /** Beyond authorised limit Tiers / Bands. This is populated if `debitRateAboveLimit.calculationMethod` is `TIER` or `BAND`. */
      debitRateAboveLimitTierBands?: {
        /** @example 0 */
        startRange: number;
        /** @example 1000 */
        endRange: number;
        /**
         * Percentage value with 1-2 digits before the decimal point and 1-4 digits after
         * @pattern ^\d{1,2}\.\d{1,4}$
         * @example "12.3456"
         */
        interestRate: string;
        /**
         * Percentage value with 1-2 digits before the decimal point and 1-4 digits after
         * @pattern ^\d{1,2}\.\d{1,4}$
         * @example "12.3456"
         */
        spread?: string;
        /** @example "ADD" */
        operator?: 'ADD' | 'SUBTRACT';
      }[];
      /** Unauthorised debit interest. */
      debitRateAboveLimitOverride?: {
        /**
         * Interest Rate, this field will only be populated if `calculationMethod` is `FLAT`.
         * @example 0.0285
         */
        interestRate?: number;
        /** @example "VARIABLE" */
        fixedVariableType: 'FIXED' | 'VARIABLE';
        /**
         * If value is `TIER` or `BAND`, the respective `...TierBands` field will be populated with the respective rates.
         * @example "BAND"
         */
        calculationMethod: 'TIER' | 'BAND' | 'FLAT';
      };
      /** Unauthorised debit interest Tiers / Bands. This is populated if `debitRateAboveLimitOverride.calculationMethod` is `TIER` or `BAND`. */
      debitRateAboveLimitOverrideTierBands?: {
        /** @example 0 */
        startRange: number;
        /** @example 1000 */
        endRange: number;
        /**
         * Percentage value with 1-2 digits before the decimal point and 1-4 digits after
         * @pattern ^\d{1,2}\.\d{1,4}$
         * @example "12.3456"
         */
        interestRate: string;
        /**
         * Percentage value with 1-2 digits before the decimal point and 1-4 digits after
         * @pattern ^\d{1,2}\.\d{1,4}$
         * @example "12.3456"
         */
        spread?: string;
        /** @example "ADD" */
        operator?: 'ADD' | 'SUBTRACT';
      }[];
      /** Credit interest */
      creditRate?: {
        /**
         * Interest Rate, this field will only be populated if `calculationMethod` is `FLAT`.
         * @example 0.0285
         */
        interestRate?: number;
        /** @example "VARIABLE" */
        fixedVariableType: 'FIXED' | 'VARIABLE';
        /**
         * If value is `TIER` or `BAND`, the respective `...TierBands` field will be populated with the respective rates.
         * @example "BAND"
         */
        calculationMethod: 'TIER' | 'BAND' | 'FLAT';
      };
      /** Credit interest Tiers / Bands. This is populated if `creditRate.calculationMethod` is `TIER` or `BAND`. If `creditRate.calculationMethod` is `FLAT`, this will be undefined. */
      creditRateTierBands?: {
        /** @example 0 */
        startRange: number;
        /** @example 1000 */
        endRange: number;
        /**
         * Percentage value with 1-2 digits before the decimal point and 1-4 digits after
         * @pattern ^\d{1,2}\.\d{1,4}$
         * @example "12.3456"
         */
        interestRate: string;
        /**
         * Percentage value with 1-2 digits before the decimal point and 1-4 digits after
         * @pattern ^\d{1,2}\.\d{1,4}$
         * @example "12.3456"
         */
        spread?: string;
        /** @example "ADD" */
        operator?: 'ADD' | 'SUBTRACT';
      }[];
      /** Interest Compounding Frequency (Set on product level in Bank Manager). This is the value displayed as 'Interest Accrual Cycle' */
      creditRateCompoundingFrequency?: {
        /**
         * Day of the month in numeric string format
         * @pattern ^([1-9]|[12][0-9]|3[01])$
         * @example "6"
         */
        day?: string;
        /** Day of the week in three-letter uppercase abbreviation format */
        dayOfWeek?: 'MON' | 'TUE' | 'WED' | 'THU' | 'FRI' | 'SAT' | 'SUN';
        /** Indicates the frequency type - DAILY (every day), WEEKLY_DAY (on the specified day each week), ANNIVERSARY_OF_ACCOUNT (monthly or annual), MONTH (on the specified day of the month) */
        frequencyType:
          | 'TRIGGERED_DAILY'
          | 'MONTHLY_ANNIVERSARY'
          | 'ON_ACCOUNT_CLOSING'
          | 'WEEKLY_DAY'
          | 'DAILY'
          | 'PER_OCCURRENCE'
          | 'MONTH_BEGINNING'
          | 'MONTH_END'
          | 'MONTH_ANNIVERSARY_OF_ACCOUNT'
          | 'ANNUAL_ANNIVERSARY_OF_ACCOUNT'
          | 'WEEKLY'
          | 'MONTH'
          | 'ANNUAL'
          | 'DAYS_FROM_CALCULATION';
        /** Month in three-letter uppercase abbreviation format */
        month?: 'JAN' | 'FEB' | 'MAR' | 'APR' | 'MAY' | 'JUN' | 'JUL' | 'AUG' | 'SEP' | 'OCT' | 'NOV' | 'DEC';
        /**
         * The relevant financial year
         * @pattern ^\d{4}$
         * @example "2025"
         */
        year?: string;
      };
    }[];
  };
  /** @example {"arrangementDetails":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    arrangementDetails?: string[];
  };
}

export interface GetAccountListData {
  entities?: {
    accountList?: {
      /**
       * A unique id generated for an arrangement which is the mode of communication between the UI and Exp API
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * Full account number with format <BSB  Account Number> -> "035845 123456789"
       * @maxLength 35
       * @pattern ^[0-9]{6} [a-zA-Z\d.]{6,28}$
       * @example "035845 103784254"
       */
      accountId?: string;
      /**
       * Account Name
       * @minLength 1
       * @maxLength 140
       * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
       * @example "Apple Tree"
       */
      accountName?: string;
      /**
       * Account type; it is product name in master product system
       * @minLength 1
       * @maxLength 250
       * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
       * @example "Corporate Investment Account"
       */
      accountType?: string;
      /**
       * Status; example-> ACTIVE, INACTIVE
       * @example "ACTIVE"
       */
      status?: 'ACTIVE' | 'INACTIVE';
      /**
       * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
       * @pattern ^[A-Z]{3}$
       * @example "AUD"
       */
      currencyCode?: string;
    }[];
  };
  /** @example {"accountList":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    accountList?: string[];
  };
}

export interface CreateBeneficiariesData {
  entities?: {
    beneficiaryCreate?: ({
      /**
       * Unique id for the beneficiary.
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * External id for the beneficiary, used for cross-system references.
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      externalId?: string;
      /**
       * Beneficiary Nickname
       * @minLength 1
       * @maxLength 70
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "John"
       */
      nickname?: string;
      /**
       * Status; example-> ACTIVE, INACTIVE
       * @example "ACTIVE"
       */
      status?: 'ACTIVE' | 'INACTIVE';
      /** A qualified amount and denomination of a monetary value. */
      currencyAmount?: {
        /** A positive or negative number string of up to four decimal places (including zero). Must have at least one digit after the decimal point. */
        amount?: string;
        /**
         * A code allocated to a currency by a Maintenance Agency under an international identification scheme, as described in the latest edition of the international standard ISO 4217 “Codes for the representation of currencies and funds”.<br> Usage- Caller to set 'AUD' to this field.
         * @pattern ^[A-Z]{3}$
         * @example "AUD"
         */
        currencyCode: string;
      };
      /**
       * CIS Key of the organisation
       * @pattern ^\d{11}$
       * @example "06089457589"
       */
      org?: string;
      /**
       * Beneficiary account type either Pay id or BSB & Account number
       * @example "BSB_ACCOUNT_NUMBER"
       */
      type?: 'PAYID' | 'BSB_ACCOUNT_NUMBER';
      /**
       * Unique payment identifier for end-to-end transaction tracking and reconciliation.
       * @maxLength 35
       * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
       * @example "INV-123456790"
       */
      reference?: string;
      /**
       * Represents Account detail object
       * @example {"accountId":{"accountNumber":"01235674897","BSB":"035845"},"accountName":"Apple Tree","bankName":"Westpac Banking Corporation"}
       */
      account?:
        | {
            /**
             * Account ID (BSB and Account Number)
             * @example {"BSB":"035845","accountNumber":"10235674897"}
             */
            accountId: {
              /**
               * Bank State Branch Number
               * @pattern ^\d{6}$
               * @example "035845"
               */
              BSB: string;
              /**
               * Account Number
               * @minLength 6
               * @maxLength 28
               * @pattern ^[a-zA-Z\d.]+$
               * @example "01235674897"
               */
              accountNumber: string;
            };
            /**
             * Account Name
             * @minLength 1
             * @maxLength 140
             * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
             * @example "Apple Tree"
             */
            accountName: string;
            /**
             * Name of Bank
             * @minLength 1
             * @maxLength 70
             * @pattern ^[\w ]+$
             * @example "Westpac Banking Corporation"
             */
            bankName: string;
          }
        | (
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Email address.
                 * @example "EMAL"
                 */
                payIDType: 'EMAL';
                /**
                 * PAY ID value representing an Email address
                 * @minLength 5
                 * @maxLength 256
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "john.doe@example.com"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing a Telephone number.
                 * @example "TELI"
                 */
                payIDType: 'TELI';
                /**
                 * PAY ID value representing a Telephone number
                 * @minLength 2
                 * @maxLength 30
                 * @pattern ^\+([1-9]{1}[0-9]{1,2})[-]{0,1}[0-9]+$
                 * @example "+61412345678"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Organisation ID.
                 * @example "ORGN"
                 */
                payIDType: 'ORGN';
                /**
                 * PAY ID value representing an Organisation number
                 * @minLength 2
                 * @maxLength 256
                 * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
                 * @example "ORG-12345"
                 */
                payIDValue: string;
              }
            | {
                /**
                 * Beneficiary Nickname
                 * @minLength 1
                 * @maxLength 70
                 * @pattern ^(?!.*(;|--|\{|\}|<|>|%|#|"|=)).*[\s\S]*$
                 * @example "John"
                 */
                payIDName: string;
                /**
                 * PayID type representing an Australian Business Number (ABN).
                 * @example "AUBN"
                 */
                payIDType: 'AUBN';
                /**
                 * PAY ID value representing an Australian Business Number (ABN)
                 * @minLength 9
                 * @maxLength 11
                 * @pattern ^\d+$
                 * @example "12345678910"
                 */
                payIDValue: string;
              }
          );
    } & {
      /**
       * CIS Key of the organisation
       * @pattern ^\d{11}$
       * @example "06089457589"
       */
      org?: string;
      /**
       * Beneficiary status; example-> ACTIVE, ARCHIVED, ON-HOLD
       * @example "ACTIVE"
       */
      status?: 'ACTIVE' | 'ARCHIVED' | 'ON-HOLD';
    })[];
  };
  /** @example {"beneficiaryCreate":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    beneficiaryCreate?: string[];
  };
}

export interface PostPaymentCreateForNewBeneficiaryData {
  entities?: {
    paymentCreateForNewBeneficiary?: {
      /**
       * Date and time at which the message was created.
       * @format date-time
       */
      creationDateTime?: string;
      /** Provides details on the original group, to which the message refers */
      groupInformation: {
        /**
         * Specifies the ISO status at the group level.Usage- For future use.
         * @maxLength 32
         * @pattern ^[\w ]+$
         */
        groupStatus: string;
        /**
         * Total of all individual amounts included in the original message, irrespective of currencies.
         * @maxLength 32
         * @pattern ^[\w ]+$
         */
        originalControlSum?: string;
        /**
         * Date and time at which the original message was created.
         * @format date-time
         */
        originalCreationDateTime: string;
        /**
         * Number of individual transactions contained in the original message.
         * @maxLength 32
         * @pattern ^[\w ]+$
         */
        originalNumberOfTransactions: string;
      };
      groupStatusReasonInformation?: {
        /**
         * Status reason description.
         *
         *   Group status reason can have values -
         *     AccountEligibilityFailure
         *     DuplicatePayment
         *     ExternalValidationEnrichmentFailed
         *     PostingFailed
         *     PostingSucceeded
         *     ValidationFailure
         *
         *   Instruction status reason can have values -
         *     AccountEligibilityFailure
         *     InsufficientAccountBalance
         *     DebitPostingFailed
         *     DebitPostingSucceeded
         *     ExternalValidationEnrichmentFailed
         *     FraudCheckDeclined
         *     FraudCheckDelayed
         *     FraudCheckNotAvailable
         *     FraudCheckOnHold
         *     FraudCheckReferred
         *     FundsReservationFailed
         *     FundsReservationSucceeded
         *     InvalidExecutionDate
         *     ValidationFailure
         *
         *   Transaction status reason can have values -
         *     ClearingAndSettlementRejected
         *     AccountEligibilityFailure
         *     CreditPostingAborted
         *     CreditPostingFailed
         *     SchemeDeterminationFailed
         *     ValidationFailure
         * @maxLength 50
         * @pattern ^[\w ]+$
         */
        reason?: string;
        /**
         * Further information about the above status reason from downstream.
         * @maxLength 120
         * @pattern ^[\w ]+$
         */
        additionalInformation?: string;
      }[];
      /**
       * Point to point reference, as assigned by the instructing party, and sent to the next party in the chain to identify the message. This field is mapped from the messageId in the CAP response.
       * @maxLength 35
       * @pattern ^[\w ]+$
       */
      id?: string;
      /** Information concerning the original payment information, to which the status report message refers. */
      paymentInformation?: {
        /**
         * Specifies the ISO status of the payment. Usage- Possible values -<br> ACSC- Accepted Settlement Completed (success) <br> ACSP- Accepted Settlement In Process (auto retry in progress in case of technical failure)<br> RJCT- Rejected
         * @maxLength 32
         * @pattern ^[\w ]+$
         */
        paymentInformationStatus: string;
        /**
         * Usage- Echoed from the request. This is mapped from the CAP response nested in supplementaryDataResponseObject
         * @maxLength 32
         * @pattern ^[\w ]+$
         */
        paymentId?: string;
      };
      paymentStatusReasonInformation?: {
        /**
         * Status reason description.
         *
         *   Group status reason can have values -
         *     AccountEligibilityFailure
         *     DuplicatePayment
         *     ExternalValidationEnrichmentFailed
         *     PostingFailed
         *     PostingSucceeded
         *     ValidationFailure
         *
         *   Instruction status reason can have values -
         *     AccountEligibilityFailure
         *     InsufficientAccountBalance
         *     DebitPostingFailed
         *     DebitPostingSucceeded
         *     ExternalValidationEnrichmentFailed
         *     FraudCheckDeclined
         *     FraudCheckDelayed
         *     FraudCheckNotAvailable
         *     FraudCheckOnHold
         *     FraudCheckReferred
         *     FundsReservationFailed
         *     FundsReservationSucceeded
         *     InvalidExecutionDate
         *     ValidationFailure
         *
         *   Transaction status reason can have values -
         *     ClearingAndSettlementRejected
         *     AccountEligibilityFailure
         *     CreditPostingAborted
         *     CreditPostingFailed
         *     SchemeDeterminationFailed
         *     ValidationFailure
         * @maxLength 50
         * @pattern ^[\w ]+$
         */
        reason?: string;
        /**
         * Further information about the above status reason from downstream.
         * @maxLength 120
         * @pattern ^[\w ]+$
         */
        additionalInformation?: string;
      }[];
      transactionInformation?: {
        /** Specifies the ISO status of the credit transaction within the payment, in case of on-us payments. <br> Usage-  Possible values- ACSC - Accepted Settlement Completed (success) RJCT - Rejected (posting rejected) ACSP - Accepted Settlement In Process (auto retry in progress in case of technical failure */
        transactionStatus?: 'ACSC' | 'RJCT' | 'ACSP';
        statusReasonInformation?: {
          /**
           * Status reason description.
           *
           *   Group status reason can have values -
           *     AccountEligibilityFailure
           *     DuplicatePayment
           *     ExternalValidationEnrichmentFailed
           *     PostingFailed
           *     PostingSucceeded
           *     ValidationFailure
           *
           *   Instruction status reason can have values -
           *     AccountEligibilityFailure
           *     InsufficientAccountBalance
           *     DebitPostingFailed
           *     DebitPostingSucceeded
           *     ExternalValidationEnrichmentFailed
           *     FraudCheckDeclined
           *     FraudCheckDelayed
           *     FraudCheckNotAvailable
           *     FraudCheckOnHold
           *     FraudCheckReferred
           *     FundsReservationFailed
           *     FundsReservationSucceeded
           *     InvalidExecutionDate
           *     ValidationFailure
           *
           *   Transaction status reason can have values -
           *     ClearingAndSettlementRejected
           *     AccountEligibilityFailure
           *     CreditPostingAborted
           *     CreditPostingFailed
           *     SchemeDeterminationFailed
           *     ValidationFailure
           * @maxLength 50
           * @pattern ^[\w ]+$
           */
          reason?: string;
          /**
           * Further information about the above status reason from downstream.
           * @maxLength 120
           * @pattern ^[\w ]+$
           */
          additionalInformation?: string;
        }[];
      }[];
    }[];
  };
  /** @example {"paymentCreateForNewBeneficiary":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    paymentCreateForNewBeneficiary?: string[];
  };
}

export interface GetBsbLookupData {
  entities?: {
    bsbLookup?: {
      /**
       * A unique id generated for a lookup result which is the mode of communication between the UI and Exp API
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
      /**
       * Represents the branch Id for which the reference data is to be retrieved
       * @minLength 1
       * @maxLength 30
       * @pattern ^[\w ]+$
       * @example "501226"
       */
      branchId?: string;
      /**
       * Bank State Branch Number
       * @pattern ^\d{6}$
       * @example "035845"
       */
      BSB?: string;
      /**
       * Name of the Branch
       * @minLength 1
       * @maxLength 70
       * @pattern ^[\w ]+$
       * @example "Central"
       */
      branchName?: string;
      /**
       * Name of Bank
       * @minLength 1
       * @maxLength 70
       * @pattern ^[\w ]+$
       * @example "Westpac Banking Corporation"
       */
      bankName?: string;
      /**
       * Branch Identification code
       * @minLength 1
       * @maxLength 70
       * @pattern ^[\w ]+$
       * @example "03"
       */
      bankCode?: string;
      /**
       * A set of available predefined values representing the label names used by Westpac for its products and services
       * @example "WBC"
       */
      brand?: 'WBC' | 'SGB' | 'BOM' | 'BSA';
      /**
       * Status of the Branch
       * @example "OPERATIONAL"
       */
      branchStatus?: 'OPERATIONAL' | 'CLOSED';
      /**
       * Branch Available indicate if the BSB is valid for origination
       * @example true
       */
      branchAvailable?: boolean;
      /** Address of the Branch */
      address?: {
        /**
         * First line of the address
         * @minLength 1
         * @maxLength 100
         * @pattern ^[\w ]+$
         * @example "123 Main St"
         */
        addressLine1?: string;
        /**
         * Second line of the address
         * @minLength 0
         * @maxLength 100
         * @pattern ^[\w ]+$
         * @example "Suite 456"
         */
        addressLine2?: string;
        /**
         * City of the address
         * @minLength 1
         * @maxLength 50
         * @pattern ^[\w ]+$
         * @example "Sydney"
         */
        city?: string;
        /**
         * State of the address
         * @minLength 1
         * @maxLength 50
         * @pattern ^[\w ]+$
         * @example "NSW"
         */
        state?: string;
        /**
         * postcode
         * @maxLength 10
         * @pattern ^\w+$
         */
        postCode?: string;
      };
    }[];
  };
  /** @example {"bsbLookup":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    bsbLookup?: string[];
  };
}

export interface GetDivisionListData {
  entities?: {
    divisionList?: ({
      /**
       * Division Name
       * @maxLength 70
       * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
       * @example "AUD Group"
       */
      divisionName?: string;
      /**
       * Division id
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      divisionId?: string;
    } & {
      /**
       * A unique identifier
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       */
      id?: string;
    })[];
  };
  /** @example {"divisionList":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    divisionList?: string[];
  };
}

export interface PostTransferCreateData {
  entities?: {
    transferCreate?: {
      /**
       * Date and time at which the message was created.
       * @format date-time
       */
      creationDateTime?: string;
      /** Provides details on the original group, to which the message refers */
      groupInformation: {
        /**
         * Specifies the ISO status at the group level.Usage- For future use.
         * @maxLength 32
         * @pattern ^[\w ]+$
         */
        groupStatus: string;
        /**
         * Total of all individual amounts included in the original message, irrespective of currencies.
         * @maxLength 32
         * @pattern ^[\w ]+$
         */
        originalControlSum?: string;
        /**
         * Date and time at which the original message was created.
         * @format date-time
         */
        originalCreationDateTime: string;
        /**
         * Number of individual transactions contained in the original message.
         * @maxLength 32
         * @pattern ^[\w ]+$
         */
        originalNumberOfTransactions: string;
      };
      groupStatusReasonInformation?: {
        /**
         * Status reason description.
         *
         *   Group status reason can have values -
         *     AccountEligibilityFailure
         *     DuplicatePayment
         *     ExternalValidationEnrichmentFailed
         *     PostingFailed
         *     PostingSucceeded
         *     ValidationFailure
         *
         *   Instruction status reason can have values -
         *     AccountEligibilityFailure
         *     InsufficientAccountBalance
         *     DebitPostingFailed
         *     DebitPostingSucceeded
         *     ExternalValidationEnrichmentFailed
         *     FraudCheckDeclined
         *     FraudCheckDelayed
         *     FraudCheckNotAvailable
         *     FraudCheckOnHold
         *     FraudCheckReferred
         *     FundsReservationFailed
         *     FundsReservationSucceeded
         *     InvalidExecutionDate
         *     ValidationFailure
         *
         *   Transaction status reason can have values -
         *     ClearingAndSettlementRejected
         *     AccountEligibilityFailure
         *     CreditPostingAborted
         *     CreditPostingFailed
         *     SchemeDeterminationFailed
         *     ValidationFailure
         * @maxLength 50
         * @pattern ^[\w ]+$
         */
        reason?: string;
        /**
         * Further information about the above status reason from downstream.
         * @maxLength 120
         * @pattern ^[\w ]+$
         */
        additionalInformation?: string;
      }[];
      /**
       * Point to point reference, as assigned by the instructing party, and sent to the next party in the chain to identify the message. This field is mapped from the messageId in the CAP response.
       * @maxLength 35
       * @pattern ^[\w ]+$
       */
      id?: string;
      /** Information concerning the original payment information, to which the status report message refers. */
      paymentInformation?: {
        /**
         * Specifies the ISO status of the payment. Usage- Possible values -<br> ACSC- Accepted Settlement Completed (success) <br> ACSP- Accepted Settlement In Process (auto retry in progress in case of technical failure)<br> RJCT- Rejected
         * @maxLength 32
         * @pattern ^[\w ]+$
         */
        paymentInformationStatus: string;
        /**
         * Usage- Echoed from the request. This is mapped from the CAP response nested in supplementaryDataResponseObject
         * @maxLength 32
         * @pattern ^[\w ]+$
         */
        paymentId?: string;
      };
      paymentStatusReasonInformation?: {
        /**
         * Status reason description.
         *
         *   Group status reason can have values -
         *     AccountEligibilityFailure
         *     DuplicatePayment
         *     ExternalValidationEnrichmentFailed
         *     PostingFailed
         *     PostingSucceeded
         *     ValidationFailure
         *
         *   Instruction status reason can have values -
         *     AccountEligibilityFailure
         *     InsufficientAccountBalance
         *     DebitPostingFailed
         *     DebitPostingSucceeded
         *     ExternalValidationEnrichmentFailed
         *     FraudCheckDeclined
         *     FraudCheckDelayed
         *     FraudCheckNotAvailable
         *     FraudCheckOnHold
         *     FraudCheckReferred
         *     FundsReservationFailed
         *     FundsReservationSucceeded
         *     InvalidExecutionDate
         *     ValidationFailure
         *
         *   Transaction status reason can have values -
         *     ClearingAndSettlementRejected
         *     AccountEligibilityFailure
         *     CreditPostingAborted
         *     CreditPostingFailed
         *     SchemeDeterminationFailed
         *     ValidationFailure
         * @maxLength 50
         * @pattern ^[\w ]+$
         */
        reason?: string;
        /**
         * Further information about the above status reason from downstream.
         * @maxLength 120
         * @pattern ^[\w ]+$
         */
        additionalInformation?: string;
      }[];
      transactionInformation?: {
        /** Specifies the ISO status of the credit transaction within the payment, in case of on-us payments. <br> Usage-  Possible values- ACSC - Accepted Settlement Completed (success) RJCT - Rejected (posting rejected) ACSP - Accepted Settlement In Process (auto retry in progress in case of technical failure */
        transactionStatus?: 'ACSC' | 'RJCT' | 'ACSP';
        statusReasonInformation?: {
          /**
           * Status reason description.
           *
           *   Group status reason can have values -
           *     AccountEligibilityFailure
           *     DuplicatePayment
           *     ExternalValidationEnrichmentFailed
           *     PostingFailed
           *     PostingSucceeded
           *     ValidationFailure
           *
           *   Instruction status reason can have values -
           *     AccountEligibilityFailure
           *     InsufficientAccountBalance
           *     DebitPostingFailed
           *     DebitPostingSucceeded
           *     ExternalValidationEnrichmentFailed
           *     FraudCheckDeclined
           *     FraudCheckDelayed
           *     FraudCheckNotAvailable
           *     FraudCheckOnHold
           *     FraudCheckReferred
           *     FundsReservationFailed
           *     FundsReservationSucceeded
           *     InvalidExecutionDate
           *     ValidationFailure
           *
           *   Transaction status reason can have values -
           *     ClearingAndSettlementRejected
           *     AccountEligibilityFailure
           *     CreditPostingAborted
           *     CreditPostingFailed
           *     SchemeDeterminationFailed
           *     ValidationFailure
           * @maxLength 50
           * @pattern ^[\w ]+$
           */
          reason?: string;
          /**
           * Further information about the above status reason from downstream.
           * @maxLength 120
           * @pattern ^[\w ]+$
           */
          additionalInformation?: string;
        }[];
      }[];
    }[];
  };
  /** @example {"transferCreate":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    transferCreate?: string[];
  };
}

export interface PostAccountNameCheckData {
  entities?: {
    accountNameCheck?: ({
      /**
       * A unique id generated for an entity which is the mode of communication between the UI and Exp API, via redux store
       * @pattern ^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$
       * @example "d0868661-b955-4e76-9f15-d97626f7df6b"
       */
      id?: string;
    } & {
      /**
       * Account Name
       * @minLength 1
       * @maxLength 140
       * @pattern ^[a-zA-Z0-9\- !,.:\;?_@]*$
       * @example "Apple Tree"
       */
      matchedCOPAccountName?: string;
      /**
       * ERDM encoded value
       * @pattern ^V[012AET]C[1-8]$
       * @example "V0C1"
       */
      matchedCOPStatusCode?: string;
      /**
       * The matched colour based on ERDM encoded value
       * @example "Blue"
       */
      matchedCOPColour?: 'Blue' | 'Amber' | 'Red';
    })[];
  };
  /** @example {"accountNameCheck":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result?: {
    /** A list of ids relating to the resource that was requested */
    accountNameCheck?: string[];
  };
}
