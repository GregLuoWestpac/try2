export interface PostPaymentReturnsRequest {
  clientContext: {
    channelType?: string;
    orgCisKey?: string; 
  };
  originalMessageIdentification: string;
  transactionInformation: {
    returnReason: {
      reasonCode: string;
      additionalInformation: string;
      cancellationCode?: string;
      returnType: string;
    };
    debtor: {
      issuer: string;
      identification: string;
      name: string;
    };
    debitDescription: string;
    creditor: {
      issuer: string;
      identification: string;
      name: string;
    };
    creditDescription: string;
    paymentReference: string;
    toAnotherAccount: string;
    returnedInterbankSettlementAmount: {
      currency: string;
      amount: string;
    };
    supplementaryData: {
      paymentDetailsIdType: string;
      ofiCaseId: string;
      serviceLevel: string;
      groupCaseId: string;
    };
  };
}
export interface PostPaymentReturnsResponse {
  id: string;
  creationDateTime: string;
  groupInformation?: {
    originalCreationDateTime?: string;
    groupStatus?: string;
  };
  groupStatusReasonInformation?: [
    {
      reason?: string;
      additionalInformation?: string;
    }
  ];
  transactionStatusInformation: [
    {
      transactionStatus?: string;
      statusReasonInformation?: [
        {
          reason?: string;
          additionalInformation?: string;
        }
      ];
      supplementaryData: {
        id: string;
      };
    }
  ];
}
export interface PaymentReturnRequest {
  messageIdentification: string;
  creationDateTime: string;
  numberOfTransactions: string;
  settlementInformation: {
    settlementMethod: string;
  };
  instructingAgent?: {
    BICFI: string;
  };
  instructedAgent?: {
    BICFI: string;
  };
  originalGroupInformation: {
    originalMessageIdentification: string;
    originalMessageNameIdentification: string;
    originalCreationDateTime: string;
  };
  transactionInformation: {
    returnIdentification: string;
    originalInstructionIdentification: string;
    originalEndToEndIdentification: string;
    originalTransactionIdentification: string;
    originalInterbankSettlementAmount?: {
      currency: string;
      amount: string;
    };
    returnedInterbankSettlementAmount: {
      currency: string;
      amount: string;
    };
    returnedInstructedAmount: {
      currency: string;
      amount: string;
    };
    interbankSettlementDate: string;
    chargeBearer: string;
    returnReasonInformation: [
      {
        reason: string;
        additionalInformation: string[];
      }
    ];
    originalTransactionReference: {
      paymentTypeInformation?: {
        serviceLevel?: string;
        categoryPurpose?: string;
      };
      remittanceInformation: {
        unstructured: string[];
        structured: {
          creditorReferenceInformation: {
            reference: string;
          };
        };
      };
      debtor: {
        name: string;
        identification: string;
        issuer: string;
      };
      debtorAccount: {
        identification: string;
        schemeName: string;
        issuer: string;
        name: string;
      };
      debtorAgent: {
        BICFI: string;
      };
      creditor: {
        name: string;
      };
      creditorAccount: {
        identification: string;
        schemeName: string;
        issuer: string;
      };
      creditorAgent: {
        BICFI: string;
      };
      mandateRelatedInformation?: {
        mandateIdentification: string;
      };
    };
    supplementaryData: {
      paymentId: string;
      originalPaymentId: string;
      groupCase?: {
        identification: string;
        creator: {
          BICFI: string;
        };
      };
      OFICase?: {
        identification: string;
        creator: {
          BICFI: string;
        };
      };
      cancellationReasonCode?: string;
      originalCreditorAdditionalData: {
        FLAN: string;
        ABN: string;
      };
    };
  };
  clientContext: {
    channelType?: string;
    deviceId?: string;
  };
}

export interface PaymentReturnInitiationRequest {
  messageIdentification: string;
  creationDateTime: string;
  initiatingParty: {
    name: string;
    identification: string;
  };
  paymentInformation: {
    paymentMethod: string;
    requestedExecutionDate: string;
    numberOfTransactions: string;
  };
  debtor: {
    name: string;
  };
  debtorAccount: {
    identification: string;
    schemeName: string;
    issuer: string;
    name: string;
  };
  debtorAgent: {
    BICFI: string;
  };
  creditTransferTransactionInformation: [
    {
      instructionIdentification: string;
      endToEndIdentification: string;
      paymentTypeInformation: {
        serviceLevel: string;
        categoryPurpose?: string;
      };
      instructedAmount: {
        amount: string;
        currency: string;
      };
      creditor: {
        name: string;
      };
      creditorAccount: {
        identification: string;
        schemeName: string;
        issuer: string;
      };
      creditorAgent: {
        BICFI: string;
      };
      remittanceInformation: {
        unstructured: string[];
      };
    }
  ];
  supplementaryData: {
    paymentId: string;
    debitDescription: string;
  };
  clientContext: {
    channelType?: string;
    deviceId?: string;
  };
}
export interface PostPaymentReturnOriginalCreditorRequest {
  paymentReturn: {
    returnIdentification: string;
    returnReasonInformation: {
      returnReason: {
        code: string;
        additionalInformation: string[];
      };
      cancellationReason: {
        code: string;
      };
    };
    relatedPaymentInformation: {
      originalPaymentId: string;
      originalPaymentIdType: string;
    };
    returnedInstructedAmount: {
      currencyCode: string;
      amount: string;
    };
    originalTransactionReference: {
      creditorAccount: {
        identification: {
          other: {
            identification: string;
            schemeName: {
              schemeNameType: string;
              code: string;
            };
          };
        };
      };
    };
    clientContext: {
      deviceId: string;
      channelType: string;
      initiatingUser: {
        orgCISKey: string;
      };
    };
    caseInformation?: {
      groupCase?: {
        identification: string;
        creator: {
          BICFI: string;
        };
      };
      OFICase?: {
        identification: string;
      };
    };
  },
  paymentDomainMetadata: {
    channelId: string;
    paymentInstructionId: string;
    WBCE2EPaymentId: string;
  };
}

export interface PostPaymentReturnAltCreditorRequest {
  paymentReturn: {
    returnIdentification: string;
    returnReasonInformation: {
      returnReason: {
        code: string;
        additionalInformation: string[];
      };
      cancellationReason: {
        code: string;
      };
    };
    relatedPaymentInformation: {
      originalPaymentId: string;
      originalPaymentIdType: string;
    };
    returnedInstructedAmount: {
      currencyCode: string;
      amount: string;
    };
    originalTransactionReference: {
      creditorAccount: {
        identification: {
          other: {
            identification: string;
            schemeName: {
              schemeNameType: string;
              code: string;
            };
          };
        };
      };
    };
    paymentTypeInformation:{
      serviceLevel: {
        serviceLevelType: string;
        proprietary: string;
      };
    };
    alternateCreditor:{
      creditor: {
        name: string;
      },
      creditorAccount: {
        identification: string;
        schemeName: {
          schemeNameType: string;
          code: string;
        };
        issuer: string;
        name: string;
      };
      endToEndIdentification: string;
      debitDescription: string;
    }
    clientContext: {
      deviceId: string;
      channelType: string;
      initiatingUser: {
        orgCISKey: string
        divisionId: string;
      };
    };
    caseInformation?: {
      groupCase?: {
        identification: string;
        creator: {
          BICFI: string;
        };
      };
      OFICase?: {
        identification: string;
      };
    };
  },
  paymentDomainMetadata: {
    channelId: string;
    paymentInstructionId: string;
    WBCE2EPaymentId: string;
  };
}

export interface PostPaymentReturnExpResponse {
  id: string;
  groupInformation?: {
    originalCreationDateTime?: string;
    groupStatus?: string;
    statusReasonInformation?: {
      reason?: string;
      additionalInformation?: string;
    }
  },
  paymentInformation: {
    paymentInformationStatus: string;
    statusReasonInformation?: {
      reason?: string;
      additionalInformation?: string;
    }
  },
  transactionStatusInformation?: {
    transactionStatus?: string;
    statusReasonInformation?: {
      reason?: string;
      additionalInformation?: string;
    }
  },
  supplementaryData: {
    id: string;
  };
}

export interface PostPaymentReturnCapApiResponse {
  data: {
    paymentStatusReport?: {
      originalGroupInformationAndStatus: {
        originalCreationDateTime: string;
        groupStatus: string;
        statusReasonInformation: {
          reason: {
            code: string;
          };
          additionalInformation: string;
        };
      };
      originalPaymentInformationAndStatus: {
        paymentInformationStatus: string;
        statusReasonInformation?: {
          reason: {
            code: string;
          };
          additionalInformation: string;
        };
        transactionInformationAndStatus?: {
          transactionStatus: string;
          statusReasonInformation: {
            reason: {
              code: string;
            };
            additionalInformation: string;
          };
        };
      };
    };
  };
}


