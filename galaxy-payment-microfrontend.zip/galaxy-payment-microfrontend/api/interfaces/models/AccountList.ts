export interface AccountListEntity {
  accountId: string;
  accountName: string;
  accountType: string;
  status: string;
  currencyCode: string;
}

export interface AccountListEntities {
  accountList: AccountListEntity[];
}

export interface AccountListResult {
  accountList: string[];
}

export interface AccountListResponse {
  entities: AccountListEntities;
  result: AccountListResult;
  errors?: string[];
}