import { AnyObj } from '../types';

export interface AppConfig {
  appId: string;
  appName: string;
  requestConfig: AnyObj;
  responseConfig: AnyObj;
  apiBaseUrl: string;
  swimlaneApi?: string;
  supportLocal?: boolean;
  logLevel?: string;
  blockObjectLogging?: boolean;
  loggedonUserType?: string;
  appBasePath?: string;
  originatingSystemId?: string;
  consumerType?: string;
  servicePort?: string;
  originatingBSB?: string;
  customerType?: string;
}

export type DownstreamResponse<T> = {
  data: T;
};

export type DownstreamError = {
  status: number;
  statusText: string;
  statusCode: number;
  data?: {
    result: AnyObj;
  }
};

export type DownstreamErrorResponse = {
  error: DownstreamError;
};

export type AccountId = {
  BSB: string;
  accountNumber: string;
}
export interface FinancialInstitutionIdentification {
  clearingSystemMemberIdentification?: {
    clearingSystemIdentification?: {
      code?: string;
    };
  };
}

export interface PagingResponse {
  id: string;
  pageSize: string;
  count: string;
  previousPageKey: string;
  nextPageKey: string;
}