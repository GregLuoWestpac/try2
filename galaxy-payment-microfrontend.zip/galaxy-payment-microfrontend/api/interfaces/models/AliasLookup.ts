export interface ExpPostAliasLookupRequestbody {
  /**
   * pecifies the Identifier that is linked to this Alias. Contains the actual value for the supplied type, so an email address, a phone number, ABN and organisation identifier.
   * The Identifier must be representative of the company name, organisation name, trading name, associated product, campaign or an identifier recognisable as associated with the specific business or organisation.
   * @pattern ^[\d@a-zA-Z0-9!#$%&'*+/=?^_`{|}~\.\x20-\x7E\+\-]+$
   * @example "company123@example.com"
   */
  id: string;

  /**
   * The type of alias being provided, as defined by the AliasType enum. Options include:
   * - TELI: Telephone identifier
   * - EMAL: Email address
   * - AUBN: Australian Business Number
   * - ORGN: Organization identifier
   */
  type: AliasType;

  /**
   * An 8-character Bank Identifier Code (BIC), used for authorization in the alias lookup process.
   * Participants.BIC or Participants.Addressing Sponsor (in the Reference data) BIC8 given by the BO and used to pick up the corresponding sign DN.
   * @pattern ^[A-Z]{6,6}[A-Z2-9][A-NP-Z0-9]$
   * @example "BANKUS33"
   */
  authBIC8: string;
}

export enum AliasType {
  TELI = 'TELI',
  EMAL = 'EMAL',
  AUBN = 'AUBN',
  ORGN = 'ORGN',
}

export type ExpPostAliasLookup =
  ExpPostAliasLookupResponse['entities']['aliasLookup'];

export interface ExpPostAliasLookupResponse {
  entities: {
    aliasLookup: {
      /**
       * A unique id generated for each record which is the mode of communication between the UI and Exp API.
       * @format uuid
       * @example "d0868661-b955-4e76-9f15-d97626f7df6b"
       */
      id: string;
      /**
       * Alias name by which a party is known and which is usually used to identify that party.
       * This should be matched against the saved payee name.
       */
      name: string;
      /**
       * The date and time when the alias was resolved.
       * @example "2024-11-15T10:45:30Z"
       */
      resolutionDateTime: string;
    }[];
  };
  /** @example {"aliasLookup":["d0868661-b955-4e76-9f15-d97626f7df6b"]} */
  result: {
    /** A list of ids relating to the resource that was requested */
    aliasLookup: string[];
  };
}
