import { PdpQueryResult } from "@mesh-tenant-multiverse-ui-common/mv-apiutils";
import { AccountId } from "./common";

export interface ArrangementsResponse {
  id: string;
  /** includes bsb */
  accountNumber: string;
  entityName: string;
  accountName: string;
  accountType: string;
  status: string;
  currencyCode: string;
  currentBalance: string;
  availableBalance: string;
  overdraftLimit: string;
}
export interface ListAccountsResponse {
  accountIds: AccountId[];
}

export interface PdpQueryApiResponse {
  data: {
    requestId: string;
    timeStamp: string;
    deploymentPackageId: string;
    elapsedTime: number;
    results: PdpQueryResult[];
  }
};


export interface PagingResponse {
  id: string;
  pageSize: string;
  count: string;
  previousPageKey: string;
  nextPageKey: string;
}

export interface ArrangementsResponseWithPaging {
  arrangements: ArrangementsResponse[];
  paging: PagingResponse[];
}