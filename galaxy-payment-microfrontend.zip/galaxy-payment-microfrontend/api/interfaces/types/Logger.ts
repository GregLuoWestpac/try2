import BunyanLogger from 'bunyan';

export type Logger = BunyanLogger | Console;
