import { AxiosResponse } from 'axios';
import { createRequest } from 'node-mocks-http';
import { NormalizedSchema } from 'normalizr';
import { Response } from 'express';
import { APIError } from '@mep-node/framework-utilities';

export type AnyObj<V = unknown> = { [key: string]: V };

export type AnyFunc<R = unknown, A = unknown> = (...args: A[]) => R;

export type AtLeast<T, K extends keyof T> = Partial<T> & Pick<T, K>;

export type ApiDownstreamResponse<T> = AxiosResponse<T>;

export type ApiHeaders = AnyObj<string>;

export type ApiRequest = Response & ReturnType<typeof createRequest>;

type Entity<T> = {
  [name: string]: T[];
};

export type ApiSuccessResponse<E> = NormalizedSchema<Entity<E>, Entity<string>>;

export type ApiResponse<E> = ApiSuccessResponse<E> | APIError;

/**
 * Base response interface that includes standard HTTP response properties
 * This matches the BaseResponse defined in the generated API client files
 */
export interface BaseResponse {
  /** HTTP status code */
  status: number;
  /** HTTP status text */
  statusText: string;
  /** HTTP headers */
  headers: any;
  /** Indicates if the response is successful */
  ok: boolean;
  /** Indicates if the response is empty */
  empty: boolean;
  /** Axios request configuration */
  config?: any;
}
