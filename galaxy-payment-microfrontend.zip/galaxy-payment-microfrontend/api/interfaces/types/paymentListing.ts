export type PostPaymentlistingRequestForCAP = {
  accountId: string;
  paymentDirection: string;
};

export type AliasType = 'TELI' | 'EMAL' | 'AUBN' | 'ORGN';

export type PostPaymentListingResponse = {
  id: string;
  status: string;
  creationDateTime: string;
  amount: string;
  currency: string;
  debitAccountName: string;
  debitAccountIdentification: string;
  debitDescription: string;
  beneficiaryName: string;
  creditAccountName: string;
  creditAccountIdentification: number | string;
  paymentMethod: string;
  receiptNumber: string;
  instructionTraceIdentification: string;
  supplementaryData?: {
    aliasId: string;
    aliasType: AliasType;
  }
};

export type PostpaymentListingPagingResponse = {
  id: string;
  pageSize: number;
  count: number;
  previousPageKey: string;
  nextPageKey: string;
  moreItems: boolean;
};

export type PostPaymentListingEXPAPIResponse = {
  paymentListing: PostPaymentListingResponse[];
  paging: PostpaymentListingPagingResponse[];
};

export type PostPaymentListingCAPRequest = {
  paymentDirection: string;
  fromDateTime: string;
  toDateTime: string;
  hasDivisions: boolean;
  divisionId?: string;
  accountId?: {
    BSB: string;
    accountNumber: string;
  }
  amountRange?: {
    fromAmount: string;
    toAmount: string;
  };
  paymentStatus?: string;
};

export type PaymentListingCAPResponse = {
  numberOfPayments: number;
  morePaymentsIndicator: boolean;
  paymentList: PaymentList[];
};

export type PaymentList = {
  referenceData: {
    paymentId: string;
    instructionTraceIdentification: string;
  };
  creationDateTime: string;
  paymentInformation: {
    paymentInformationStatus: string;
  };
  debtor: {
    name: string;
  };
  debtorAccount: {
    identification: string;
    name: string;
  };
  creditTransferTransactionInformation: CreditTransferTransactionInformation[];
  supplementaryData: {
    debitDescription: string;
  };
};

export type CreditTransferTransactionInformation = {
  endToEndIdentification: string;
  paymentTypeInformation: {
    serviceLevel: string;
  };
  instructedAmount: {
    amount: string;
    currency: string;
  };
  creditor: {
    name: string;
  };
  creditorAccount: {
    identification: string;
    name: string;
  };
  instructionForDebtorAgent: string;
  supplementaryData: {
    aliasId: string;
    aliasType: AliasType;
  };
};
