import { pages } from './routes';

describe('Routes', () => {
  it('should match the pages length', () => {
    expect(pages.length).toBe(1);
    expect(pages[0].children.length).toBe(7);
    expect(pages[0].children).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          path: 'make-payment',
        }),
      ])
    );
  });
});
