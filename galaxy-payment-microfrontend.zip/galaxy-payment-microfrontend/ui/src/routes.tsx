import {
  paymentDetailsPageTitle,
  returnDetailsPageTitle,
  paymentStatusPageTitle,
} from './common/constants';
import {
  AsyncDefault,
  AsyncError,
  AsyncHome,
  AsyncInitiateReturn,
  AsyncMakePayment,
  AsyncPaymentDetails,
  AsyncPaymentTaskDetails,
  AsyncTransferFunds,
} from './layouts';
/**
 * The routes exported are stitched together
 * in the RouteRegistry of the master SPA
 * along-with the other micro apps
 *
 * NOTE:
 * - The top level route if exposing nested routes MUST not have the `exact` property defined
 * - The top level route if exposing nested routes MUST not have the `element` property defined
 * - Instead the top level `routes` array used to define the nested routes MUST define the top-level route first
 *   along-with the `element` property and optionally the `exact` property if so desired
 *
 * [Reference route config](https://reactrouter.com/web/example/route-config)
 * [Reference exact prop](https://reactrouter.com/web/api/Route/exact-bool)
 */
export const pages = [
  {
    id: 'pages.galaxy.payment.home',
    path: '/payment/*',
    isPublic: true, // change to true for local testing / test without any role based access
    name: 'Galaxy-Payment',
    element: <AsyncDefault />,
    title: 'Payments',
    /*
    // sample query params definition for route validation
    queryParams: {
      test: {
        required: true,
        pattern: /^\w{1,4}/,
        maxLength: 4
      },
    },
    */
    children: [
      {
        id: 'pages.galaxy.payment.homepage',
        index: true,
        isPublic: true, // change to true for local testing / test without any role based access
        name: paymentStatusPageTitle,
        title: paymentStatusPageTitle,
        element: <AsyncHome />,
        /*
        // sample query params definition for route validation
        queryParams: {
          test: {
            required: true,
            pattern: /^\w{1,4}/,
            maxLength: 4
          },
        },
        */
      },
      {
        id: 'pages.galaxy.payment.makepayment',
        path: 'make-payment',
        isPublic: true,
        name: paymentDetailsPageTitle,
        title: 'Make a payment',
        element: <AsyncMakePayment />,
        exact: true,
      },
      {
        id: 'pages.galaxy.payment.transferfunds',
        path: 'transfer-funds',
        name: 'Transfer details | Westpac One',
        title: 'Transfer funds',
        isPublic: true,
        element: <AsyncTransferFunds />,
        exact: true,
      },
      {
        id: 'pages.galaxy.payment.paymentdetails',
        path: 'payment-details',
        isPublic: true,
        name: paymentDetailsPageTitle,
        title: 'Payment details',
        element: <AsyncPaymentDetails />,
        exact: true,
      },
      {
        id: 'pages.galaxy.payment.paymenttaskdetails',
        path: 'payment-task-details',
        isPublic: true,
        name: paymentDetailsPageTitle,
        title: 'Payment task details',
        element: <AsyncPaymentTaskDetails />,
        exact: true,
      },
      {
        id: 'pages.galaxy.payment.error',
        name: 'Payments Error | Westpac One',
        title: 'Payments - Error',
        path: '*',
        isPublic: true,
        element: <AsyncError />,
      },
      {
        id: 'pages.galaxy.payment.initiateReturn',
        path: 'initiate-return',
        isPublic: false,
        roles: [
          'A014A6-galaxy-service-and-operations',
          'A014A6-galaxy-pac-management',
        ],
        name: returnDetailsPageTitle,
        title: 'Return details',
        element: <AsyncInitiateReturn />,
        exact: true,
      },
    ],
  },
];

export default pages;
