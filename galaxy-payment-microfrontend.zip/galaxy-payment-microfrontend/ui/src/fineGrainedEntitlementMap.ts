import {
  Actions,
  Resources,
} from '@mesh-tenant-user-authorisation-policy-decision-engine/components';

export const entitlementToPathMap = {
  '/payment': {
    resource: Resources.ACCOUNTS,
    action: Actions.VIEW_PAYMENTS,
  },
  '/payment/make-payment': {
    resource: Resources.ACCOUNTS,
    action: Actions.INITIATE_PAYMENT,
  },
  '/payment/transfer-funds': {
    resource: Resources.ACCOUNTS,
    action: Actions.INITIATE_TRANSFER,
  },
  '/payment/payment-details': {
    resource: Resources.ACCOUNTS,
    action: Actions.VIEW_PAYMENTS,
  },
  '/payment/payment-task-details': {
    resource: Resources.ACCOUNTS,
    action: Actions.VIEW_PAYMENTS,
  },
  '/payment/initiate-return': {
    resource: Resources.ACCOUNTS,
    action: Actions.INITIATE_PAYMENT_RETURN,
  },
};
