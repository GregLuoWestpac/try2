export { default as GalaxyLink } from './GalaxyLink';
