// test cases completely generated using github copilot

import { getAppUrlWithParams } from '@mesh-tenant-multiverse-ui-common/mv-utils';

import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import GalaxyLink from './GalaxyLink';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-utils'),
  getAppUrlWithParams: jest.fn(),
}));

describe('GalaxyLink', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  it('renders GalaxyLink Component', () => {
    (getAppUrlWithParams as jest.Mock).mockReturnValue('/mocked-url');
    render(
      <BrowserRouter>
        {/* Wrap your component with BrowserRouter */}
        <GalaxyLink to="/test">Test Link</GalaxyLink>
      </BrowserRouter>
    );

    const linkElement = screen.getByText('Test Link');
    expect(linkElement).toBeInTheDocument();
    expect(linkElement).toHaveAttribute('href', '/mocked-url');
    // expect linkelement to be of type string
    expect(typeof linkElement).toBe('object');
  });
});
