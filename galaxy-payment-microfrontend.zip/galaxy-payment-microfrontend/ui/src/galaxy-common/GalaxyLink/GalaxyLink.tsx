// eslint-disable-next-line
// @ts-ignore
import { Link } from '@mep-ui/framework-router-addon';
import { getAppUrlWithParams } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { LinkProps } from 'react-router-dom';

function GalaxyLink(props: LinkProps) {
  const newUrl =
    typeof props?.to === 'string' ? getAppUrlWithParams(props?.to) : props?.to;
  return (
    <Link {...props} to={newUrl}>
      {props?.children}
    </Link>
  );
}

export default GalaxyLink;
