import { Grid, GridItem } from '@westpac/ui';
import { ReactNode } from 'react';

type SearchSectionWrapperProps = {
  children: ReactNode;
};

function SearchSectionWrapper({
  children,
}: SearchSectionWrapperProps) {
  return (
    <div className="border border-border px-2.5 py-2.5">
      <Grid>
        <GridItem span={7} className="flex flex-col gap-2.5">
          {children}
        </GridItem>
      </Grid>
    </div>
  );
}

export { SearchSectionWrapper };
