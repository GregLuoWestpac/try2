import { formatBSBFromAccNo } from '@mesh-tenant-multiverse-ui-common/mv-utils';

export function AccountNumberWithGap({
  accountNumber,
}: {
  accountNumber: string;
}) {
  const [bsb, accNo] = accountNumber.replace('  ', ' ').split(' ');
  if (bsb && accNo) {
    return (
      <div className="flex gap-1.5">
        <div>{formatBSBFromAccNo(bsb)}</div>
        <div>{accNo}</div>
      </div>
    );
  }

  return accountNumber;
}
