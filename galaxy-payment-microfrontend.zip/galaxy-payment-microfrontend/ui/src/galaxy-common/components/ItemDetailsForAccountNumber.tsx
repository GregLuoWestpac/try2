import { AutocompleteItemDetailsTemplate } from '@mesh-tenant-multiverse-ui-common/mv-reacthookform';
import { memo } from 'react';
import { Account } from '../../store/types';
import { AccountNumberWithGap } from './AccountNumberWithGap';

function ItemDetailsForAccountNumberInner({
  item: { accountName, accountId },
}: {
  item: Account;
}) {
  return (
    <AutocompleteItemDetailsTemplate
      line1={accountName}
      line2={<AccountNumberWithGap accountNumber={accountId} />}
    />
  );
}

export const ItemDetailsForAccountNumber = memo(
  ItemDetailsForAccountNumberInner
) as typeof ItemDetailsForAccountNumberInner;
