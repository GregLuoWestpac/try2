import { formatBSBFromAccNo } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { render } from '@testing-library/react';
import { AccountNumberWithGap } from './AccountNumberWithGap';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  formatBSBFromAccNo: jest.fn(),
  convertSydneyLocalTimeToUtc: jest.fn((date: string) => date ? `${date}T00:00:00.000Z` : ''),
}));

describe('AccountNumberWithGap', () => {
  it('should render formatted BSB and account number with gap', () => {
    (formatBSBFromAccNo as jest.Mock).mockReturnValue('formattedBSB');
    const { container } = render(
      <AccountNumberWithGap accountNumber="123456 78901234" />
    );
    expect(container.textContent).toBe('formattedBSB78901234');
  });

  it('should render the original account number if BSB or account number is missing', () => {
    const { container } = render(
      <AccountNumberWithGap accountNumber="123456" />
    );
    expect(container.textContent).toBe('123456');
  });
});
