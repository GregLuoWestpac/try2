/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { AutocompleteItemDetailsTemplate } from '@mesh-tenant-multiverse-ui-common/mv-reacthookform';
import { render } from '@testing-library/react';
import { Arrangement } from '../../store/types';
import { ItemDetailsForAccountNumber } from './ItemDetailsForAccountNumber';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  AutocompleteItemDetailsTemplate: jest.fn(() => (
    <div>AutocompleteItemDetailsTemplate</div>
  )),
}));

jest.mock('./AccountNumberWithGap', () => ({
  AccountNumberWithGap: jest.fn(() => <div>AccountNumberWithGap</div>),
}));

describe('ItemDetailsForAccountNumber', () => {
  const mockItem: Arrangement = {
    id: '123456789',
    accountNumber: '123456789',
    accountName: 'Test Account',
    entityName: 'Test Entity',
    availableBalance: '1000',
    currentBalance: '1500',
    accountType: 'type',
    currencyCode: '99',
    overdraftLimit: 'limit',
  };

  it('should render AutocompleteItemDetailsTemplate with correct props', () => {
    const { getByText } = render(
      <ItemDetailsForAccountNumber item={mockItem} />
    );

    expect(AutocompleteItemDetailsTemplate).toHaveBeenCalledWith(
      expect.objectContaining({
        line1: 'Test Account',
        line2: expect.any(Object),
      }),
      {}
    );

    expect(getByText('AutocompleteItemDetailsTemplate')).toBeInTheDocument();
  });
});
