import { AutocompleteId } from '@mesh-tenant-multiverse-ui-common/mv-reacthookform';
import {
  formatBSB,
  formatBSBFromAccNo,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import pick from 'lodash/pick';
import { Account } from 'ui/src/store/types';
import {
  AccountOfBSBAndACC,
  AccountOfPayId,
  Beneficiary,
  BeneTypes,
} from '../../common/types';

export function inputValueFnForAccountNumber<T extends AutocompleteId>(
  item: T
) {
  if (!item) return '';
  const newItem = item as unknown as Account;

  const newId = formatBSBFromAccNo(newItem.accountId).replace(' ', '  ');

  if (newId && newItem.accountName) {
    return `${newItem.accountName}  |  ${newId}`;
  }

  return newId;
}

export function inputValueFnForBeneficiary<T extends AutocompleteId>(item: T) {
  if (!item) return '';
  const newItem = item as unknown as Beneficiary;

  let newId = newItem.id || '';
  if (newItem.type === BeneTypes.PAYID) {
    newId = (newItem.account as AccountOfPayId)?.payIDValue;
  } else {
    const account = newItem.account as AccountOfBSBAndACC;
    newId = `${formatBSB(account?.accountId?.BSB, 3)}  ${
      account?.accountId?.accountNumber
    }`;
  }

  if (newId && newItem.nickname) {
    return `${newItem.nickname}  |  ${newId}`;
  }

  return newId;
}

export function filterFnForAccountNumber<T extends AutocompleteId>(
  item: T,
  input: string
) {
  const account = item as unknown as Account;

  const newItem = {
    ...pick(account, ['accountId', 'accountName']),
    idWithDash: formatBSBFromAccNo(account.accountId),
  };

  return Object.values(newItem).some((value) =>
    JSON.stringify(value).toLowerCase().includes(input.toLowerCase())
  );
}

export function filterFnForBeneficiary<T extends AutocompleteId>(
  item: T,
  input: string
) {
  let name = '';
  let idWithDash = '';
  let id = '';
  let nickname = '';
  const beneficiary = item as unknown as Beneficiary;
  nickname = beneficiary.nickname;

  if (beneficiary.type === BeneTypes.PAYID) {
    const account = beneficiary.account as AccountOfPayId;
    name = account.payIDName;
    id = account.payIDValue;
    idWithDash = '';
  } else {
    const account = beneficiary.account as AccountOfBSBAndACC;
    name = account?.accountName;
    id = `${account?.accountId?.BSB} ${account?.accountId?.accountNumber}`;
    idWithDash = formatBSBFromAccNo(id);
  }

  const newItem = {
    id,
    name,
    nickname,
    idWithDash,
  };

  return Object.values(newItem).some((value) =>
    JSON.stringify(value).toLowerCase().includes(input.toLowerCase())
  );
}
