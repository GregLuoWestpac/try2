const currentDate = new Date();
const formatterDateTime = new Intl.DateTimeFormat('en-AU', {
  day: 'numeric',
  month: 'short',
  year: 'numeric',
  hour12: true,
  hour: 'numeric',
  minute: '2-digit',
  second: '2-digit',
});

const timeZoneAbbreviation = new Intl.DateTimeFormat('en-AU', {
  timeZoneName: 'short',
})
  .formatToParts(currentDate)
  .find((part) => part.type === 'timeZoneName')?.value;

export const ConfirmationDate = `${formatterDateTime.format(
  currentDate,
)} (${timeZoneAbbreviation})`.replace(/,/g, '');

const formatterDate = new Intl.DateTimeFormat('en-AU', {
  day: 'numeric',
  month: 'short',
  year: 'numeric',
});

export const transferDate = `${formatterDate.format(
  currentDate,
)} (${timeZoneAbbreviation})`;

export const formatDate = (timestamp: Date | number | string): string => {
  const date = new Date(timestamp);
  const formattedDate = date.toISOString();

  return formattedDate;
};
