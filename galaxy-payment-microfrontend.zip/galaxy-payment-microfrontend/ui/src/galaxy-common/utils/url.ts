export const getPath = (link?: string) => {
  let basePath = '';
  const currentUrl = new URL(window.location.href);

  if (currentUrl.pathname.startsWith('/galaxy')) {
    basePath = '/galaxy';
  }

  const subPath = link ? `/${link}` : '';

  return basePath + subPath;
};
