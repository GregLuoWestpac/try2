import {
  filterFnForAccountNumber,
  filterFnForBeneficiary,
  inputValueFnForAccountNumber,
  inputValueFnForBeneficiary,
} from './autocomplete.utils';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  formatBSB: (bsb: string) => `BSB-${bsb}`,
  formatBSBFromAccNo: (accNo: string) => (accNo ? `BSBACC-${accNo}` : ''),
  convertSydneyLocalTimeToUtc: jest.fn((date: string) => date ? `${date}T00:00:00.000Z` : ''),
}));

describe('autocomplete.utils', () => {
  describe('inputValueFnForAccountNumber', () => {
    it('should return empty string if item is falsy', () => {
      expect(inputValueFnForAccountNumber(undefined as any)).toBe('');
    });

    it('should return formatted string with accountName and formatted accountId', () => {
      const item = {
        id: '1',
        accountName: 'Test Account',
        accountId: '123456',
      };
      expect(inputValueFnForAccountNumber(item)).toBe(
        'Test Account  |  BSBACC-123456'
      );
    });

    it('should return formatted accountId if accountName is missing', () => {
      const item = {
        id: '1',
        accountId: '654321',
      };
      expect(inputValueFnForAccountNumber(item)).toBe('BSBACC-654321');
    });
  });

  describe('inputValueFnForBeneficiary', () => {
    it('should return empty string if item is falsy', () => {
      expect(inputValueFnForBeneficiary(undefined as any)).toBe('');
    });

    it('should return formatted string for PAYID type', () => {
      const item = {
        id: 'id1',
        nickname: 'Nick',
        type: 'PAYID',
        account: {
          payIDValue: 'payid@example.com',
        },
      };
      expect(inputValueFnForBeneficiary(item as any)).toBe(
        'Nick  |  payid@example.com'
      );
    });

    it('should return formatted string for BSB_ACCOUNT_NUMBER type', () => {
      const item = {
        id: 'id2',
        nickname: 'Nick2',
        type: 'BSB_ACCOUNT_NUMBER',
        account: {
          accountId: { BSB: '123456', accountNumber: '789012' },
        },
      };
      expect(inputValueFnForBeneficiary(item as any)).toBe(
        'Nick2  |  BSB-123456  789012'
      );
    });

    it('should return formatted id if nickname is missing', () => {
      const item = {
        id: 'id3',
        type: 'PAYID',
        account: {
          payIDValue: 'payid2@example.com',
        },
      };
      expect(inputValueFnForBeneficiary(item as any)).toBe(
        'payid2@example.com'
      );
    });
  });

  describe('filterFnForAccountNumber', () => {
    it('should return true if input matches accountName', () => {
      const item = {
        id: '1',
        accountName: 'My Account',
        accountId: '123456',
      };
      expect(filterFnForAccountNumber(item, 'my account')).toBe(true);
    });

    it('should return true if input matches formatted accountId', () => {
      const item = {
        id: '1',
        accountName: 'Other',
        accountId: '654321',
      };
      expect(filterFnForAccountNumber(item, 'bsbacc-654321')).toBe(true);
    });

    it('should return false if input does not match', () => {
      const item = {
        id: '1',
        accountName: 'Other',
        accountId: '654321',
      };
      expect(filterFnForAccountNumber(item, 'no-match')).toBe(false);
    });
  });

  describe('filterFnForBeneficiary', () => {
    it('should return true if input matches nickname for PAYID', () => {
      const item = {
        id: 'id1',
        nickname: 'Nick',
        type: 'PAYID',
        account: {
          payIDName: 'Payee Name',
          payIDValue: 'payid@example.com',
        },
      };
      expect(filterFnForBeneficiary(item as any, 'nick')).toBe(true);
    });

    it('should return true if input matches accountName for BSB_ACCOUNT_NUMBER', () => {
      const item = {
        id: 'id2',
        nickname: 'Nick2',
        type: 'BSB_ACCOUNT_NUMBER',
        account: {
          accountName: 'Account Name',
          accountId: {
            BSB: '123456',
            accountId: '789012',
          },
        },
      };
      expect(filterFnForBeneficiary(item as any, 'account name')).toBe(true);
    });

    it('should return true if input matches formatted idWithDash for BSB_ACCOUNT_NUMBER', () => {
      const item = {
        id: 'id3',
        nickname: 'Nick3',
        type: 'BSB_ACCOUNT_NUMBER',
        account: {
          accountId: {
            BSB: '654321',
            accountNumber: '123456',
          },
          accountName: 'Account Name',
        },
      };
      expect(filterFnForBeneficiary(item as any, 'bsbacc-654321 123456')).toBe(
        true
      );
    });

    it('should return false if input does not match any field', () => {
      const item = {
        id: 'id4',
        nickname: 'Nick4',
        type: 'PAYID',
        account: {
          payIDName: 'Payee Name',
          payIDValue: 'payid@example.com',
        },
      };
      expect(filterFnForBeneficiary(item as any, 'no-match')).toBe(false);
    });
  });
});
