// TODO: Move it to galaxy common repo after signed off.
export function scrollToTop() {
  window.scrollTo({
    top: 0,
    behavior: 'instant',
  });
}
