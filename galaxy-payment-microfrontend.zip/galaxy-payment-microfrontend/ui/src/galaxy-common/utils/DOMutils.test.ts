// the below test case is completely generated using github copilot
import { scrollToTop } from './DOMUtils';

describe('scrollToTop', () => {
  it('should scroll to top', () => {
    const scrollToMock = jest.fn();
    window.scrollTo = scrollToMock;

    scrollToTop();

    expect(scrollToMock).toHaveBeenCalledWith({
      top: 0,
      behavior: 'instant',
    });
  });
});
