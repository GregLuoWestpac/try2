/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/unbound-method */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable no-underscore-dangle */
import { ConfirmationDate, transferDate } from './datetime';

describe('Date Formatters', () => {
  xit('formats ConfirmationDate correctly', () => {
    const confirmationDateFormat =
      /^\d{1,2} \w{3} \d{4} \d{1,2}:\d{2}:\d{2} (am|pm) \(\w{3,9}\)$/;
    expect(ConfirmationDate).toMatch(confirmationDateFormat);
  });

  xit('formats transferDate correctly', () => {
    const transferDateFormat = /^\d{1,2} \w{3} \d{4} \(\w{3,4}\)$/;
    expect(transferDate).toMatch(transferDateFormat);
  });
});
