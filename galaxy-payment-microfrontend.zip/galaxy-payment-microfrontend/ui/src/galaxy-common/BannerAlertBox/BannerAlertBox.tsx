import { Alert, Grid, GridItem } from '@westpac/ui';
import React from 'react';

export interface BannerAlertBoxProps {
  children: any;
  id: string;
  styling: 'success' | 'info' | 'warning' | 'danger' | 'system';
}

function BannerAlertBox({
  children,
  id,
  styling,
}: BannerAlertBoxProps): React.JSX.Element {
  return (
    <Grid id="BannerAlertBox" className="flex flex-col">
      <Alert
        id={id}
        look={styling}
        className="m-0.5 mt-5.5 [&>a]:hover:visited:focus:font-bold"
        iconSize="small"
      >
        <GridItem>{children}</GridItem>
      </Alert>
    </Grid>
  );
}

export default BannerAlertBox;
