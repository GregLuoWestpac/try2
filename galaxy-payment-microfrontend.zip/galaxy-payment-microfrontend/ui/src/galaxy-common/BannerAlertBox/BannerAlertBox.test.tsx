
import { render } from '@testing-library/react';
import BannerAlertBox from './BannerAlertBox';

describe('BannerAlertBox', () => {
  it('should match snapshot', () => {
    const { container } = render(
      <BannerAlertBox children={undefined} id="" styling="info" />,
    );
    expect(container).toMatchSnapshot();
  });

  // it('should throw an error if required props are missing', () => {
  //   const originalError = console.error;
  //   console.error = jest.fn();

  //   // Render the component without required props
  //   expect(() =>
  //     render(<BannerAlertBox children={undefined} id="" styling="info" />),
  //   ).toThrow();

  //   console.error = originalError;
  // });
});
