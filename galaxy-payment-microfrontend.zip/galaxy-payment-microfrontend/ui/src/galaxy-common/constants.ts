export const AEDT = 'AEDT' as const;
export const AEST = 'AEST' as const;

export const gridSize = 8;

export const breakpoints = {
  xs: 480,
  md: 768,
  lg: 992,
  xl: 1200,
};

export const currencyRegex = /^(\d{1,3},)*\d{1,3}\.\d{2}$/;
