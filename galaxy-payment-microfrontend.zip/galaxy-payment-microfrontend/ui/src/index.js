/**
 * Polyfill stable language features. These imports will be optimized by `@babel/preset-env`.
 *
 * See: https://github.com/zloirock/core-js#babel
 */
import React from 'react';
import { registerRoutes } from '@mep-ui/framework';

import { pages } from './routes';
import './index.css';

globalThis.React = React;

export const init = () => {
  registerRoutes(pages);
};

/**
 * Initializing registration while importing itself.
 * This would be useful when project teams inject microfrontend dynamically.
 * In case of traditional micro apps, they've to import reducers, routes, sagas, etc manually as of today
 */
init();
