import { BranchBrand, BranchStatus } from '../../common/constants';
import { EntityCollection } from './Common';

export type Branch = {
  BSB?: string;
  branchName?: string;
  bankName?: string;
  bankCode?: string;
  brand?: BranchBrand;
  branchStatus?: BranchStatus;
  branchAvailable?: boolean;
  address?: {
    addressLine1?: string;
    addressLine2?: string;
    city?: string;
    state?: string;
    postCode?: string;
  };
};

export interface BsbLookupData {
  entities?: {
    bsbLookup?: Branch[];
  };
  result?: {
    /** A list of ids relating to the resource that was requested */
    bsbLookup?: string[];
  };
}

export type BsbLookupEntities = EntityCollection<Branch>;
