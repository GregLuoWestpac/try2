/* eslint-disable import/no-cycle */
import { ErrorResponse } from '../../common/types';

type State = {
  statusCode?: number;
  errors?: ErrorResponse[];
};

type PostState = {
  post: State;
};

export type GalaxyApiState = {
  api: {
    expGalaxyPaymentV2: {
      transferCreate: PostState;
      paymentCreate: PostState;
      paymentCreateForNewBeneficiary: PostState;
      beneficiaryCreate: PostState;
      paymentReturns: PostState;
      aliasLookup: PostState;
      schemeEligibilities: PostState;
      paymentIdentifier: PostState;
      paymentLimits: {
        get: State;
      };
      validatePaymentLimits: PostState;
    };
  };
};
