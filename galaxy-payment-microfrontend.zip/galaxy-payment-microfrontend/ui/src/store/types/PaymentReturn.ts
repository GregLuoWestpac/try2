import { EntityCollection } from './Common';

export type PaymentReturn = [
  {
    id: string;
    creationDateTime: string;
    groupInformation: {
      originalCreationDateTime: string;
      groupStatus: string;
    };
    groupStatusReasonInformation: [
      {
        reason: string;
        additionalInformation: string;
      }
    ];
    transactionStatusInformation: [
      {
        transactionStatus: string;
        statusReasonInformation: [
          {
            reason: string;
            additionalInformation: string;
          }
        ];
        supplementaryData: {
          id: string;
        };
      }
    ];
  }
]

export type PaymentReturnEntities = EntityCollection<PaymentReturn>;

export type PaymentReturnResponse = [
  {
    id: string;
    groupInformation?: {
      originalCreationDateTime?: string;
      groupStatus?: string;
      statusReasonInformation?: {
        reason?: string;
        additionalInformation?: string;
      }
    },
    paymentInformation: {
      paymentInformationStatus: string;
      statusReasonInformation?: {
        reason?: string;
        additionalInformation?: string;
      }
    },
    transactionStatusInformation?: {
      transactionStatus?: string;
      statusReasonInformation?: {
        reason?: string;
        additionalInformation?: string;
      }
    },
    supplementaryData: {
      id: string;
    };
  }
]

export type PaymentReturnResponseEntities = EntityCollection<PaymentReturnResponse>;
