export type AccountNameCheckMatchedColor = 'Blue' | 'Amber' | 'Red';

export type PostAccountNameCheckParams = {
  params: {
    payee: {
      accountName: string;
      accountId: {
        accountNumber: string;
        BSB: string;
      };
    };
  };
  meta?: Record<string, unknown>;
};
