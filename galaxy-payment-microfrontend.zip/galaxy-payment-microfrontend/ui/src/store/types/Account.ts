export type Account = {
  id: string;
  accountId: string;
  accountName: string;
  accountType: string;
  status: string;
  currencyCode: string;
};