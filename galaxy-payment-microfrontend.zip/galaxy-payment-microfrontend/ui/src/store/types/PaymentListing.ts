export type PaymentListing = {
  id: string;
  status: string;
  creationDateTime: string;
  amount: string;
  currency: string;
  debitAccountName: string;
  debitAccountIdentification: string;
  debitDescription: string;
  beneficiaryName: string;
  creditAccountName: string;
  creditAccountIdentification: string;
  paymentMethod: string;
  receiptNumber: string;
  instructionTraceIdentification: string;
};
