import { CoPApiStatus } from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
import { ChannelTypeCode } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { ChannelIds, PDP_QUERY_ACTIONS } from '../../common/constants';
import { Beneficiary } from '../../common/types';
import { BeneficiaryStatus } from '../../containers/MakePaymentContainer/common';
import { MetaData } from './Common';
import type { FinancialInstitutionIdentification } from './Payment';

export type PostPaymentsParams = {
  clientContext: {
    channelType?: ChannelTypeCode;
  };
  creditTransferTransactionInformation: {
    creditor: {
      name: string;
    };
    creditorAccount?: {
      identification?: string;
      issuer?: string;
      name?: string;
      schemeName?: string;
      type?: string;
    };
    creditorAgent: {
      BICFI: string;
      financialInstitutionIdentification?: FinancialInstitutionIdentification;
    };
    endToEndIdentification?: string;
    instructedAmount: {
      amount: string;
      currency: string;
    };
    instructionForDebtorAgent?: string;
    paymentTypeInformation?: {
      categoryPurpose?: string;
      instructionPriority?: string;
      localInstrument?: string;
      serviceLevel?: string;
    };
    remittanceInformation?: {
      unstructured?: string[];
    };
    supplementaryData?: {
      isNewPayee?: boolean;
      aliasId?: string;
      beneficiaryId?: string;
      templateId?: string;
      aliasType?: string;
    };
  }[];
  debtor?: {
    identification?: string;
    issuer?: string;
    name?: string;
  };
  debtorAccount: {
    identification: string;
    issuer: string;
    name?: string;
    schemeName: string;
    type?: string;
  };
  debtorAgent?: {
    BICFI: string;
    financialInstitutionIdentification?: FinancialInstitutionIdentification;
  };
  initiatingParty: {
    name?: string;
  };
  instructionForDebtorAgent?: string;
  paymentInformation?: {
    controlSum?: string;
    numberOfTransactions?: string;
  };
  paymentMethod: string;
  paymentTypeInformation?: {
    categoryPurpose?: string;
    instructionPriority?: string;
    localInstrument?: string;
    serviceLevel?: string;
  };
  supplementaryData: {
    debitDescription?: string;
    instructionTraceIdentification?: string;
    divisionId?: string;
    paymentProductId?: string;
    matchedCOPAccountName?: string;
    matchedCOPStatusCode?: CoPApiStatus;
  };
  entitlementData?: {
    supplementaryData: {
      name: string;
      value: string;
      datatype: 'STRING' | 'BOOLEAN';
    }[];
  };
};

export type PostGeneratePaymentIdParams = {
  channelId: ChannelIds;
};

export type PostValidatePaymentsLimitParams = {
  instructionIdentification: string;
  scheme: string;
  settlementAmount: {
    value: string;
    currencyCode: string;
  };
};

export type PostValidatePaymentsLimitParamsPayload = {
  params: PostValidatePaymentsLimitParams;
  meta?: MetaData;
};

export type PostValidatePaymentsLimitOptionsPayload = {
  headers: Record<string, string>;
};

export type PostPaymentReturnsParams = {
  clientContext: {
    channelType?: ChannelTypeCode;
    orgCisKey?: string;
  };
  originalMessageIdentification: string;
  transactionInformation: {
    returnReason: {
      reasonCode: string;
      additionalInformation: string;
      cancellationCode?: string;
      returnType?: string;
    };
    debtor: {
      issuer: string;
      identification: string;
      name: string;
    };
    debitDescription: string;
    creditor: {
      issuer: string;
      identification: string;
      name: string;
    };
    creditDescription: string;
    paymentReference: string;
    toAnotherAccount: string;
    returnedInterbankSettlementAmount: {
      currency: string;
      amount: string;
    };
    supplementaryData: {
      paymentDetailsIdType: string;
      ofiCaseId: string;
      serviceLevel?: string;
      groupCaseId: string;
    };
  };
};

export type PostPaymentsParamsPayload = {
  params: PostPaymentsParams;
};

export type PostPaymentsOptionsPayload = {
  headers: Record<string, string>;
};

export type AddBeneficiaryObject = Omit<
  Beneficiary,
  'org' | 'status' | 'externalId'
>;

export type PostBeneficiaryParamsPayload = {
  params: {
    beneficiaries: AddBeneficiaryObject[];
  };
};

export type BeneficiaryOptionsPayload = {
  headers: Record<string, string>;
};

export type PostPaymentReturnsParamsPayload = {
  params: PostPaymentReturnsParams;
};

export type PostPaymentReturnsOptionsPayload = {
  headers: Record<string, string>;
};

export type PostPaymentListingParams = {
  accountId?: {
    BSB: string;
    accountNumber: string;
  };
  paymentDirection: string;
  hasDivisions: boolean;
  paymentStatus?: string;
  amountRange?: string;
  divisionId?: string;
};

export type PostPaymentListingQueryParams = {
  paymentDateTime: string;
};

export type PostPaymentListingParamsPayload = {
  params: PostPaymentListingParams;
  query: PostPaymentListingQueryParams;
  meta?: MetaData;
};

export type PostArrangementParamsPayload = {
  meta?: MetaData;
  pdpQueryAction: PDP_QUERY_ACTIONS;
};

export type PostBeneficiaryListParamsPayload = {
  meta?: MetaData;
  params: { statuses?: BeneficiaryStatus[]; divisionId?: string };
};

export type GetArrangementParamsPayload = {
  meta?: MetaData;
  arrangementStatus: string;
  pdpQueryAction: PDP_QUERY_ACTIONS;
};

export type RequestOptionsPayload = {
  withCredentials?: boolean;
  headers?: Record<string, unknown>;
};

export type PostPaymentDetailsParams = {
  keyIdentifier: string;
  keyType: string;
  accountId: {
    BSB: string;
    accountNumber: string;
  };
};

export type PostPaymentDetailsParamsPayload = {
  params: PostPaymentDetailsParams;
  meta?: MetaData;
};

export type PostAliasLookupParams = {
  id?: string;
  authBIC8?: string;
  email?: string;
  phone?: string;
  orgn?: string;
  aubn?: string;
};

export type PostAliasLookupByBeneIdParams = {
  id: string;
};

export type PostAliasLookupParamsPayload = {
  params: PostAliasLookupParams;
  meta?: MetaData;
};

export type PostAliasLookupByBeneIdParamsPayload = {
  params: PostAliasLookupByBeneIdParams;
  meta?: MetaData;
};

export type PostAliasLookupErrorResponse = {
  data: {
    errors: string[];
  };
  statusText: string;
  status: number;
  meta?: MetaData;
};

export type fetchSchemeEligibilitiesParams = {
  debtorAccount: {
    issuer: string;
    schemeName: string;
  };
  creditorAccount: {
    issuer?: string;
    schemeName?: string;
    payAlias?: {
      id?: string;
      type?: string;
      authBIC8?: string;
    };
  };
  returnAllSchemes?: boolean;
};

export type fetchSchemeEligibilitiesPayload = {
  params: fetchSchemeEligibilitiesParams;
  meta?: MetaData;
};

export type AccountIds = [
  {
    BSB: string;
    accountNumber: string;
  }
];

export type ArrangementDetailsParamsPayload = {
  params: AccountIds;
  meta?: MetaData;
};

export type PostAccountListParamsPayload = {
  meta?: MetaData;
  pdpQueryAction: PDP_QUERY_ACTIONS;
};

export type GetAccountListParamsPayload = {
  meta?: MetaData;
  pdpQueryAction: PDP_QUERY_ACTIONS;
  accountStatus?: 'ACTIVE' | 'ACTIVE_AND_INACTIVE';
  divisionId?: string;
};
export type getDivisionListParamsPayload = {
  pdpQueryAction: PDP_QUERY_ACTIONS;
  meta?: MetaData;
};

export type GetBSBLookupParamsPayload = {
  BSB: string;
};

export type PostAliaLookupParamsPayload = {
  params: PostAliasLookupParams;
  meta?: MetaData;
};
