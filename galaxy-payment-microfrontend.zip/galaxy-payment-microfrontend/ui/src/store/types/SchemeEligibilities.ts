import { EntityCollection } from "./Common";

type SchemeEligibility = {
  id: string;
  paymentMethod: {
    code: string,
    description: string
  }
}
export type SchemeEligibilityEntities = EntityCollection<SchemeEligibility>;
