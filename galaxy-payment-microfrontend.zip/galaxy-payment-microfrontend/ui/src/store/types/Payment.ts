import type { PaymentMethod } from 'ui/src/common/constants';
import { EntityCollection } from './Common';

export interface AccountObject {
  name?: string;
  nickName?: string;
  accountId?: string;
}

export interface paymentMethodObject {
  code?: string;
  description?: string;
}

export type PostPayment = {
  id: string;
  status: 'Processed' | 'Submitted' | 'Processing' | 'Failed';
  creationDateTime: string;
  amount: string;
  currency: 'AUD';
  debitAccount: string;
  debitDescription: string;
  beneficiary: string;
  creditAccount: string;
  paymentMethod: string;
  receiptNumber: string;
  instructionTraceIdentification: string;
};

export type Payment = {
  creationDateTime: string;
  groupInformation: {
    groupStatus: string;
    originalControlSum: string;
    originalCreationDateTime: string;
  };
  groupStatusReasonInformation: [
    {
      reason: string;
      additionalInformation: string;
    }
  ];
  id: string;
  paymentInformation: {
    paymentInformationStatus: string;
    paymentId: string;
  };
  paymentStatusReasonInformation: [
    {
      reason: string;
      additionalInformation: string;
    }
  ];
  transactionInformation: [
    {
      transactionStatus: string;
      statusReasonInformation: [
        {
          reason: string;
          additionalInformation: string;
        }
      ];
    }
  ];
};

export type PaymentEntitiesById = Record<string, Payment>;

export type PaymentEntities = EntityCollection<Payment>;

export type PaymentMethods = EntityCollection<PaymentMethod>;

export type PaymentResult = {
  payments: string[];
};

export type PaymentData = {
  entities: PaymentEntities;
  result: PaymentResult;
};

export interface FinancialInstitutionIdentification {
  clearingSystemMemberIdentification?: {
    clearingSystemIdentification?: {
      code?: string;
    };
  };
}
