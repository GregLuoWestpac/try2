import type { PaymentListAlertProps } from '../../containers/PaymentListContainer/PaymentListAlert';
import { Account } from './Account';
import { AliasLookupEntities } from './AliasLookup';
import { BsbLookupEntities } from './BsbLookup';
import { GalaxyApiState } from './GalaxyApiState';
import type { Payment, PaymentEntities } from './Payment';
import { PaymentReturnResponseEntities } from './PaymentReturn';
import { SchemeEligibilityEntities } from './SchemeEligibilities';

export type UserProfile = {
  givenName?: string;
  familyName?: string;
};

export type CustomerData = { cisKey?: string; tenXPartyKey?: string };

export type RootState = {
  entities: {
    expGalaxyPaymentV2: {
      payments: PaymentEntities;
      paymentreturns: PaymentReturnResponseEntities;
      bsbLookup: BsbLookupEntities;
      aliasLookup: AliasLookupEntities;
      aliasLookupByBeneId: AliasLookupEntities;
      schemeEligibilities: SchemeEligibilityEntities;
    };
  };
  galaxy: GalaxyApiState;
};

export const SearchBy = {
  CreatedBy: 'CreatedBy',
  ApproverAndCreatedOnDateRange: 'ApproverAndCreatedOnDateRange',
} as const;

export type SearchByType = (typeof SearchBy)[keyof typeof SearchBy];

export type GlobalState = {
  global: {
    user: {
      user?: {
        profile?: UserProfile;
      };
    };
    galaxy?: {
      context?: {
        selectedTransactionDetails?: any;
        selectedPayment?: Payment;
        selectedPaymentFormValues?: Account;
        approvalWorkflowId?: string;
        alertMessages: PaymentListAlertProps[];
        selectedCustomer?: CustomerData;
        // automatically added from when raise intent
        intentTimestamp?: string;
        contextKey?: string;
        cisKey?: string;
        tenXPartyKey?: string;
        // TODO: Remove below 2 props when the W1 team fixes the context key usePageContext hook
        id?: Record<string, string>;
        orgId?: string;
        searchBy?: SearchByType;
      };
    };
    instance?: {
      appCorrelationId?: string;
    };
  };
};
