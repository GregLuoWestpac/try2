// TODO: please verify if this is a duplicate of ui/src/store/types/Beneficiary.ts
// TODO: Need to update the type from the response of beneficiary exp api
export type Beneficiary = {
  id: string;
  nickname: string;
  description: string;
  payeeType: string;
  domestic: {
    payeeAccountType: string;
    accountName: string;
    account: {
      BSB: string;
      accountNumber: string;
    };
    aliasId: string;
  };
};
