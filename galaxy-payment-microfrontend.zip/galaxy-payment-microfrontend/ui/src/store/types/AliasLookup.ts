import { EntityCollection } from './Common';

export type PostAliasLookup = {
  id: string;
  aliasType: string;
  name: string;
  resolutionDateTime: string;
  returnCode: number;
};

export interface PostAliasLookupData {
  entities?: {
    aliasLookup?: PostAliasLookup[];
  };
  result?: {
    /** A list of ids relating to the resource that was requested */
    aliasLookup?: string[];
  };
}

export type AliasLookupEntities = EntityCollection<PostAliasLookup>;
