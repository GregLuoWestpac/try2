export type Arrangement = {
  id: string;
  /**  with bsb, eg. '035845 222288885' */
  accountNumber: string;
  entityName: string;
  accountName: string;
  accountType: string;
  currencyCode: string;
  currentBalance: string;
  availableBalance: string;
  overdraftLimit: string;
};
export interface Paging {
  id: string;
  pageSize: string;
  count: string;
  previousPageKey: string;
  nextPageKey: string;
}

export type TierBands = {
  startRange: number;
  endRange?: number | '' | null;
  interestRate: number;
  operator?: string;
  spread?: number;
};
type CompoundingFrequency = {
  day: any;
  dayOfWeek: any;
  month: any;
  year: any;
  frequencyType?: string;
};

export const ACCOUNT_RATE_CALCULATION_METHODS = {
  FLAT: 'FLAT',
  BAND: 'BAND',
  TIER: 'TIER',
} as const;

type InterestRate = {
  interestRate: number;
  tierBands?: TierBands[];
  fixedVariableType: string;
  calculationMethod: keyof typeof ACCOUNT_RATE_CALCULATION_METHODS;
  compoundingFrequency?: CompoundingFrequency;
};

export type ArrangementDetails = Arrangement & {
  accountId: string;
  openedDateTime: string;
  closedDateTime: string;
  accountLinks: any;
  debitRateWithinLimit: InterestRate;
  debitRateWithinLimitTierBands?: TierBands[];
  debitRateAboveLimit: InterestRate;
  debitRateAboveLimitTierBands?: TierBands[];
  debitRateAboveLimitOverride: InterestRate;
  debitRateAboveLimitOverrideTierBands?: TierBands[];
  creditRate: InterestRate;
  creditRateTierBands?: TierBands[];
  creditRateCompoundingFrequency?: CompoundingFrequency;
};
