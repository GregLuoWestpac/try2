export interface Approver {
  userId: string;
}

/**
 * formatted approval workflow listing stored in redux, for ui display such as MVTable
 */
export type ApprovalWorkflowListing = {
  id: string;
  status: string;
  creationDateTime: string;
  amount: string;
  currency: string;
  debitAccountName: string;
  debitAccountIdentification: string;
  debitDescription: string;
  beneficiaryName: string;
  creditAccountName: string;
  creditAccountIdentification: string;
  paymentMethod: string;
  receiptNumber: string;
  instructionTraceIdentification: string;
  approvers: Approver[];
};
