import { RootState } from '../types';

export const getPostAddBeneficiaryStatusCode = (state: RootState) =>
  state?.galaxy?.api?.expGalaxyPaymentV2?.beneficiaryCreate?.post?.statusCode;

export const getPostAddBeneficiaryErrors = (state: RootState) =>
  state?.galaxy?.api?.expGalaxyPaymentV2?.beneficiaryCreate?.post?.errors;
