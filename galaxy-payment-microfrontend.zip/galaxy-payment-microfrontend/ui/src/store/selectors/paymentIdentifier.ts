import { RootState } from '../types';

export const getPostPaymentIdentifierStatusCode = (state: RootState) =>
  state?.galaxy?.api?.expGalaxyPaymentV2?.paymentIdentifier?.post?.statusCode;

export const getPostPaymentIdentifierErrors = (state: RootState) =>
  state?.galaxy?.api?.expGalaxyPaymentV2?.paymentIdentifier?.post?.errors;