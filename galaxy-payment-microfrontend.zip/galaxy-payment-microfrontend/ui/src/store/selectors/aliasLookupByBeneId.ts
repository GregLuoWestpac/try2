/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { RootState } from '../types';

export const getPostAliasLookupByBeneIdStatusCode = (state: RootState) =>
  state?.entities?.expGalaxyPaymentV2?.aliasLookupByBeneId?.error?.status;
export const getPostAliasLookupByBeneIdErrorCode = (state: RootState) =>
  state?.entities?.expGalaxyPaymentV2?.aliasLookupByBeneId?.error?.data
    ?.errors?.[0]?.code;
