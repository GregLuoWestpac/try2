import { RootState } from '../types';
import { getPostPaymentCreateStatusCode } from './paymentCreate';

describe('getPostPaymentCreateStatusCode', () => {
  it('should return the correct status code', () => {
    const mockState = {
      galaxy: {
        api: {
          expGalaxyPaymentV2: {
            paymentCreate: {
              post: {
                statusCode: 200,
              },
            },
          },
        },
      },
    } as RootState;

    const result = getPostPaymentCreateStatusCode(mockState);
    expect(result).toEqual(200);
  });

  it('should return undefined if the path does not exist', () => {
    const mockState = {} as RootState;

    const result = getPostPaymentCreateStatusCode(mockState);
    expect(result).toBeUndefined();
  });
});
