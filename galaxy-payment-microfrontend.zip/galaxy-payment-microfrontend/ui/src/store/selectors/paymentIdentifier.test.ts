import { RootState } from '../types';
import { getPostPaymentIdentifierStatusCode, getPostPaymentIdentifierErrors } from './paymentIdentifier';

describe('getPostPaymentIdentifierStatusCode', () => {
  it('should return the correct status code', () => {
    const mockState = {
      galaxy: {
        api: {
          expGalaxyPaymentV2: {
            paymentIdentifier: {
              post: {
                statusCode: 200,
              },
            },
          },
        },
      },
    } as RootState;

    const result = getPostPaymentIdentifierStatusCode(mockState);
    expect(result).toEqual(200);
  });

  it('should return undefined if the path does not exist', () => {
    const mockState = {} as RootState;

    const result = getPostPaymentIdentifierStatusCode(mockState);
    expect(result).toBeUndefined();
  });
});

describe('getPostPaymentIdentifierErrors', () => {
  it('should return the correct errors', () => {
    const mockState = {
      galaxy: {
        api: {
          expGalaxyPaymentV2: {
            paymentIdentifier: {
              post: {
                errors: [
                  { code: 400, message: 'Error 1', details: 'Invalid input' },
                  { code: 404, message: 'Error 2', details: 'Not found' },
                ],
              },
            },
          },
        },
      },
    } as RootState;

    const result = getPostPaymentIdentifierErrors(mockState);
    expect(result?.[0]?.code).toEqual(400);
  });

  it('should return undefined if the path does not exist', () => {
    const mockState = {} as RootState;

    const result = getPostPaymentIdentifierErrors(mockState);
    expect(result).toBeUndefined();
  });
});
