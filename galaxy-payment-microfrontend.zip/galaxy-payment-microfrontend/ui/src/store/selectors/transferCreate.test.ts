import { RootState } from '../types';
import { getPostTransferCreateStatusCode } from './transferCreate';

describe('getPostTransferCreateStatusCode', () => {
  it('should return the correct status code', () => {
    const mockState = {
      galaxy: {
        api: {
          expGalaxyPaymentV2: {
            transferCreate: {
              post: {
                statusCode: 200,
              },
            },
          },
        },
      },
    } as RootState;

    const result = getPostTransferCreateStatusCode(mockState);
    expect(result).toEqual(200);
  });

  it('should return undefined if the path does not exist', () => {
    const mockState = {} as RootState;

    const result = getPostTransferCreateStatusCode(mockState);
    expect(result).toBeUndefined();
  });
});
