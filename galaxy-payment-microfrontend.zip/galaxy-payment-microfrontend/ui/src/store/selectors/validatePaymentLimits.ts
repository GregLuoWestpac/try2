import { RootState } from '../types';

export const getValidatePaymentLimitsStatusCode = (state: RootState) =>
  state?.galaxy?.api?.expGalaxyPaymentV2?.validatePaymentLimits?.post?.statusCode;

export const getValidatePaymentLimitsErrors = (state: RootState) =>
  state?.galaxy?.api?.expGalaxyPaymentV2?.validatePaymentLimits?.post?.errors;
