import { RootState } from '../types';

export const getPostPaymentReturnStatusCode = (state: RootState) =>
  state?.galaxy?.api?.expGalaxyPaymentV2?.paymentReturns?.post?.statusCode;

export const getPostPaymentReturnErrorResponse = (state: RootState) =>
  state?.entities?.expGalaxyPaymentV2?.paymentreturns?.error?.data?.errors[0];
