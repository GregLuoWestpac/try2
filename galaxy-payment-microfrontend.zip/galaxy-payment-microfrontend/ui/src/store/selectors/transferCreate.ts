/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { createSelector } from '@mep-ui/framework';
import { HTTP_STATUS_CODES } from '@mesh-tenant-multiverse-ui-common/mv-constants';
import { RootState } from '../types';

export const getPostTransferCreateStatusCode = (state: RootState) =>
  state?.galaxy?.api?.expGalaxyPaymentV2?.transferCreate?.post?.statusCode;

export const getPostTransferCreateErrors = (state: RootState) =>
  state?.galaxy?.api?.expGalaxyPaymentV2?.transferCreate?.post?.errors;

export const isAuthenticatedError = createSelector(
  [getPostTransferCreateStatusCode],
  (statusCode: number) => statusCode === HTTP_STATUS_CODES.UNAUTHORIZED
);
