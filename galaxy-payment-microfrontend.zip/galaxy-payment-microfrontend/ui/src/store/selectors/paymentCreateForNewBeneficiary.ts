/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import { RootState } from '../types';

export const getPostPaymentCreateForNewBeneficiaryStatusCode = (
  state: RootState
) =>
  state?.galaxy?.api?.expGalaxyPaymentV2?.paymentCreateForNewBeneficiary?.post
    ?.statusCode;

export const getPostPaymentCreateForNewBeneficiaryErrors = (state: RootState) =>
  state?.galaxy?.api?.expGalaxyPaymentV2?.paymentCreateForNewBeneficiary?.post
    ?.errors;
