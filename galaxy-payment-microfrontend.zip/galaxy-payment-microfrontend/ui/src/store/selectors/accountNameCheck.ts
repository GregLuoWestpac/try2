/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import { createSelector } from '@mep-ui/framework';

/**
 * Selectors for Account Name Check (CoP) API responses
 * Follows same pattern as aliasLookup.ts selectors
 * Uses 'any' type for state to match generated selector patterns
 */

export const getPostAccountNameCheckStatusCode = (
  state: any
): number | undefined =>
  state?.entities?.expGalaxyPaymentV2?.accountNameCheck?.error?.status;

export const getPostAccountNameCheckErrorCode = (
  state: any
): number | undefined =>
  state?.entities?.expGalaxyPaymentV2?.accountNameCheck?.error?.data
    ?.errors?.[0]?.code;

export const getPostAccountNameCheckError = (state: any): any =>
  state?.entities?.expGalaxyPaymentV2?.accountNameCheck?.error;

/**
 * AC3: Check if CoP limit is exceeded
 * Returns true when status is 400 and error code is 3000 (COP_LIMIT_EXCEEDED_ERROR)
 */
export const isCopLimitExceededSelector = createSelector(
  [getPostAccountNameCheckStatusCode, getPostAccountNameCheckErrorCode],
  (statusCode: number, errorCode: number) =>
    statusCode === 400 && errorCode === 3000
);

/**
 * Check if the account name check service is not available
 * Returns true for any error that's not a limit exceeded error
 */
export const isCopServiceNotAvailableSelector = createSelector(
  [
    getPostAccountNameCheckStatusCode,
    getPostAccountNameCheckErrorCode,
    (state: any): boolean | undefined =>
      state?.entities?.expGalaxyPaymentV2?.accountNameCheck?.isError,
  ],
  (statusCode: number, errorCode: number, isError: boolean) =>
    (statusCode === 400 && errorCode !== 3000) ||
    (statusCode >= 401 && statusCode <= 499) ||
    (statusCode >= 500 && statusCode <= 599) ||
    (statusCode == null && isError)
);
