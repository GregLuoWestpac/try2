/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { createSelector } from '@mep-ui/framework';
import { HTTP_STATUS_CODES } from '@mesh-tenant-multiverse-ui-common/mv-constants';
import { RootState } from '../types';

export const getPostPaymentCreateStatusCode = (state: RootState) =>
  state?.galaxy?.api?.expGalaxyPaymentV2?.paymentCreate?.post?.statusCode;

export const getPostPaymentCreateErrors = (state: RootState) =>
  state?.galaxy?.api?.expGalaxyPaymentV2?.paymentCreate?.post?.errors;

export const isAuthenticatedError = createSelector(
  [getPostPaymentCreateStatusCode],
  (statusCode: number) => statusCode === HTTP_STATUS_CODES.UNAUTHORIZED
);
