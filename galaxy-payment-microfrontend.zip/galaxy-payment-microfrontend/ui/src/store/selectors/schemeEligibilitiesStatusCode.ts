import { RootState } from '../types';

export const getPostSchemeEligibilityStatusCode = (state: RootState) =>
  state?.galaxy?.api?.expGalaxyPaymentV2?.schemeEligibilities.post.statusCode
