import {
  getPostAccountNameCheckStatusCode,
  getPostAccountNameCheckErrorCode,
  getPostAccountNameCheckError,
  isCopLimitExceededSelector,
  isCopServiceNotAvailableSelector,
} from './accountNameCheck';

describe('accountNameCheck selectors', () => {
  describe('getPostAccountNameCheckStatusCode', () => {
    it('should return status code when present', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {
              error: {
                status: 400,
              },
            },
          },
        },
      };

      expect(getPostAccountNameCheckStatusCode(state)).toBe(400);
    });

    it('should return undefined when status is not present', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {},
          },
        },
      };

      expect(getPostAccountNameCheckStatusCode(state)).toBeUndefined();
    });

    it('should return undefined when accountNameCheck is not present', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {},
        },
      };

      expect(getPostAccountNameCheckStatusCode(state)).toBeUndefined();
    });
  });

  describe('getPostAccountNameCheckErrorCode', () => {
    it('should return error code when present', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {
              error: {
                data: {
                  errors: [{ code: 3000 }],
                },
              },
            },
          },
        },
      };

      expect(getPostAccountNameCheckErrorCode(state)).toBe(3000);
    });

    it('should return undefined when error code is not present', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {
              error: {
                data: {
                  errors: [],
                },
              },
            },
          },
        },
      };

      expect(getPostAccountNameCheckErrorCode(state)).toBeUndefined();
    });
  });

  describe('getPostAccountNameCheckError', () => {
    it('should return error object when present', () => {
      const errorObj = {
        status: 400,
        data: { errors: [{ code: 3000 }] },
      };
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {
              error: errorObj,
            },
          },
        },
      };

      expect(getPostAccountNameCheckError(state)).toEqual(errorObj);
    });

    it('should return undefined when error is not present', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {},
          },
        },
      };

      expect(getPostAccountNameCheckError(state)).toBeUndefined();
    });
  });

  describe('isCopLimitExceededSelector', () => {
    it('should return true when status is 400 and error code is 3000', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {
              error: {
                status: 400,
                data: {
                  errors: [{ code: 3000 }],
                },
              },
            },
          },
        },
      };

      expect(isCopLimitExceededSelector(state)).toBe(true);
    });

    it('should return false when status is 400 but error code is not 3000', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {
              error: {
                status: 400,
                data: {
                  errors: [{ code: 1001 }],
                },
              },
            },
          },
        },
      };

      expect(isCopLimitExceededSelector(state)).toBe(false);
    });

    it('should return false when status is not 400', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {
              error: {
                status: 500,
                data: {
                  errors: [{ code: 3000 }],
                },
              },
            },
          },
        },
      };

      expect(isCopLimitExceededSelector(state)).toBe(false);
    });

    it('should return false when no error present', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {},
          },
        },
      };

      expect(isCopLimitExceededSelector(state)).toBe(false);
    });
  });

  describe('isCopServiceNotAvailableSelector', () => {
    it('should return true when status is 400 and error code is not 3000', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {
              error: {
                status: 400,
                data: {
                  errors: [{ code: 1001 }],
                },
              },
            },
          },
        },
      };

      expect(isCopServiceNotAvailableSelector(state)).toBe(true);
    });

    it('should return true when status is 500', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {
              error: {
                status: 500,
              },
            },
          },
        },
      };

      expect(isCopServiceNotAvailableSelector(state)).toBe(true);
    });

    it('should return true when status is 503', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {
              error: {
                status: 503,
              },
            },
          },
        },
      };

      expect(isCopServiceNotAvailableSelector(state)).toBe(true);
    });

    it('should return true when status is 401', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {
              error: {
                status: 401,
              },
            },
          },
        },
      };

      expect(isCopServiceNotAvailableSelector(state)).toBe(true);
    });

    it('should return false when status is 400 and error code is 3000 (limit exceeded)', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {
              error: {
                status: 400,
                data: {
                  errors: [{ code: 3000 }],
                },
              },
            },
          },
        },
      };

      expect(isCopServiceNotAvailableSelector(state)).toBe(false);
    });

    it('should return true when isError is true but no status code', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {
              isError: true,
            },
          },
        },
      };

      expect(isCopServiceNotAvailableSelector(state)).toBe(true);
    });

    it('should return false when no error', () => {
      const state = {
        entities: {
          expGalaxyPaymentV2: {
            accountNameCheck: {
              isError: false,
            },
          },
        },
      };

      expect(isCopServiceNotAvailableSelector(state)).toBe(false);
    });
  });
});
