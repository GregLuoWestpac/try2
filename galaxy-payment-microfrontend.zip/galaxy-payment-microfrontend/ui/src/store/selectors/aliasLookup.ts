/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { createSelector } from '@mep-ui/framework';
import { isAliasLookupError as isAliasLookupErrorSelector } from '../generated';
import { RootState } from '../types';

export const getPostLookupStatusCode = (state: RootState) =>
  state?.entities?.expGalaxyPaymentV2?.aliasLookup?.error?.status;
export const getPostLookupErrorCode = (state: RootState) =>
  state?.entities?.expGalaxyPaymentV2?.aliasLookup?.error?.data?.errors?.[0]
    ?.code;

export const doesAliasIdContainInvalidDataSelector = createSelector(
  [getPostLookupStatusCode, getPostLookupErrorCode],
  (statusCode: number, errorCode: number) =>
    statusCode === 400 && errorCode === 2
);

export const isPayIdNotValidSelector = createSelector(
  [getPostLookupStatusCode, getPostLookupErrorCode],
  (statusCode: number, errorCode: number) =>
    statusCode === 400 &&
    (errorCode === 2001 || errorCode === 2002 || errorCode === 2003)
);

export const isPayIdServiceNotAvailableSelector = createSelector(
  [getPostLookupStatusCode, getPostLookupErrorCode, isAliasLookupErrorSelector],
  (statusCode: number, errorCode: number, isAliasLookupError: boolean) =>
    (statusCode === 400 &&
      errorCode !== 2 &&
      errorCode !== 2000 &&
      errorCode !== 2001 &&
      errorCode !== 2002 &&
      errorCode !== 2003) ||
    (statusCode >= 401 && statusCode <= 499) ||
    (statusCode >= 500 && statusCode <= 599) ||
    (statusCode == null && isAliasLookupError)
);

export const isPayIdLimitExceededSelector = createSelector(
  [getPostLookupStatusCode, getPostLookupErrorCode],
  (statusCode: number, errorCode: number) =>
    statusCode === 400 && errorCode === 2000
);
