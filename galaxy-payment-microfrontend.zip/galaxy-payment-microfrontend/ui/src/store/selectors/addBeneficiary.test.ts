import { RootState } from '../types';
import {
  getPostAddBeneficiaryErrors,
  getPostAddBeneficiaryStatusCode,
} from './addBeneficiary';

describe('getPostAddBeneficiaryStatusCode', () => {
  it('should return the correct status code', () => {
    const mockState = {
      galaxy: {
        api: {
          expGalaxyPaymentV2: {
            beneficiaryCreate: {
              post: {
                statusCode: 200,
              },
            },
          },
        },
      },
    } as RootState;

    const result = getPostAddBeneficiaryStatusCode(mockState);
    expect(result).toEqual(200);
  });

  it('should return undefined if the path does not exist', () => {
    const mockState = {} as RootState;

    const result = getPostAddBeneficiaryStatusCode(mockState);
    expect(result).toBeUndefined();
  });
});

describe('getPostAddBeneficiaryErrors', () => {
  it('should return the correct errors', () => {
    const mockState = {
      galaxy: {
        api: {
          expGalaxyPaymentV2: {
            beneficiaryCreate: {
              post: {
                errors: [
                  { code: 400, message: 'Error 1', details: 'Invalid input' },
                  { code: 404, message: 'Error 2', details: 'Not found' },
                ],
              },
            },
          },
        },
      },
    } as RootState;

    const result = getPostAddBeneficiaryErrors(mockState);
    expect(result?.[0]?.code).toEqual(400);
  });

  it('should return undefined if the path does not exist', () => {
    const mockState = {} as RootState;

    const result = getPostAddBeneficiaryErrors(mockState);
    expect(result).toBeUndefined();
  });
});
