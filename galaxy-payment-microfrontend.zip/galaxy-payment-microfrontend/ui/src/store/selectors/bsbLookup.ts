import { RootState } from '../types';

export const getBsbLookupErrorStatusCode = (state: RootState) =>
  state?.entities?.expGalaxyPaymentV2?.bsbLookup?.error?.status;
