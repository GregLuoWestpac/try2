import { RootState } from "../types";

export const getPaymentLimitsStatusCode=(state: RootState)=>
    state?.galaxy?.api?.expGalaxyPaymentV2?.paymentLimits?.get?.statusCode;


export const getPaymentLimitsErrors=(state: RootState)=>
    state?.galaxy?.api?.expGalaxyPaymentV2?.paymentLimits?.get?.errors;
