import { createSelector } from '@mep-ui/framework';
import get from 'lodash/get';

export const getMFEs = (state) => get(state, `microfrontends`, {});

export const getMFESlice = createSelector([getMFEs], (mfes) =>
  get(mfes, 'payment', {})
);
