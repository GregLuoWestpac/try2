import { RootState } from '../types';
import {
  getPostPaymentCreateForNewBeneficiaryErrors,
  getPostPaymentCreateForNewBeneficiaryStatusCode,
} from './paymentCreateForNewBeneficiary';

describe('getPostPaymentCreateForNewBeneficiaryStatusCode', () => {
  it('should return the correct status code', () => {
    const mockState = {
      galaxy: {
        api: {
          expGalaxyPaymentV2: {
            paymentCreateForNewBeneficiary: {
              post: {
                statusCode: 200,
              },
            },
          },
        },
      },
    } as RootState;

    const result = getPostPaymentCreateForNewBeneficiaryStatusCode(mockState);
    expect(result).toEqual(200);
  });

  it('should return undefined if the path does not exist', () => {
    const mockState = {} as RootState;

    const result = getPostPaymentCreateForNewBeneficiaryStatusCode(mockState);
    expect(result).toBeUndefined();
  });
});

describe('getPostPaymentCreateForNewBeneficiaryErrors', () => {
  it('should return the correct errors', () => {
    const mockState = {
      galaxy: {
        api: {
          expGalaxyPaymentV2: {
            paymentCreateForNewBeneficiary: {
              post: {
                errors: [
                  { code: 400, message: 'Error 1', details: 'Invalid input' },
                  { code: 404, message: 'Error 2', details: 'Not found' },
                ],
              },
            },
          },
        },
      },
    } as RootState;

    const result = getPostPaymentCreateForNewBeneficiaryErrors(mockState);
    expect(result?.[0]?.code).toEqual(400);
  });

  it('should return undefined if the path does not exist', () => {
    const mockState = {} as RootState;

    const result = getPostPaymentCreateForNewBeneficiaryErrors(mockState);
    expect(result).toBeUndefined();
  });
});
