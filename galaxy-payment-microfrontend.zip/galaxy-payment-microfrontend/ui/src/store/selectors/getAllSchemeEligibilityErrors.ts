import { createSelector } from '@mep-ui/framework';
import get from 'lodash/get';
import { getSchemeEligibilitiesSlice } from '../generated';

export const getAllSchemeEligibilityErrors = createSelector(
  [getSchemeEligibilitiesSlice],
  (slice: any) => get(slice, 'error.data.errors')
);
