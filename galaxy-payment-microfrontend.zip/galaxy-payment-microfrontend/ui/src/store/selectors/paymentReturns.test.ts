import { RootState } from '../types';
import { getPostPaymentReturnStatusCode } from './paymentReturns';

describe('getPostPaymentReturnStatusCode', () => {
  it('should return the correct status code', () => {
    const mockState = {
      galaxy: {
        api: {
          expGalaxyPaymentV2: {
            paymentReturns: {
              post: {
                statusCode: 200,
              },
            },
          },
        },
      },
    } as RootState;

    const result = getPostPaymentReturnStatusCode(mockState);
    expect(result).toEqual(200);
  });

  it('should return undefined if the path does not exist', () => {
    const mockState = {} as RootState;

    const result = getPostPaymentReturnStatusCode(mockState);
    expect(result).toBeUndefined();
  });
});
