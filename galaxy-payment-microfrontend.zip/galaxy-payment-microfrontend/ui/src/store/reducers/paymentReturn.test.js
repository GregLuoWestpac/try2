import { paymentReturnsApiReducer, defaultState } from './paymentReturns';
import { paymentreturnsActions } from '../generated';

describe('paymentReturnsApiReducer', () => {
  it('paymentreturnsActions.api.expGalaxyPaymentV2.paymentreturns.post.receive', () => {
    const action = {
      type: paymentreturnsActions.api.expGalaxyPaymentV2.paymentreturns.post.receive,
      meta: {
        statusCode: 200,
      },
    };

    const newState = paymentReturnsApiReducer(defaultState, action);

    expect(newState).toEqual({
      post: {
        statusCode: 200,
      },
    });
  });

  it('should handle paymentreturnsActions.api.expGalaxyPaymentV2.paymentreturns.post.error', () => {
    const action = {
      type: paymentreturnsActions.api.expGalaxyPaymentV2.paymentreturns.post.error,
      payload: {
        error: {
          status: 500,
        },
      },
    };

    const newState = paymentReturnsApiReducer(defaultState, action);

    expect(newState).toEqual({
      post: {
        statusCode: 500,
      },
    });
  });
});
