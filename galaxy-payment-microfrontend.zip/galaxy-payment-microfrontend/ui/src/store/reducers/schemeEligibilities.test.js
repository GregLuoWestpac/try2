import { schemeEligibilitiesApiReducer, defaultState } from './schemeEligibilities';
import { schemeEligibilitiesActions } from '../generated';

describe('schemeEligibilitiesApiReducer', () => {
  it('should return the initial state', () => {
    expect(schemeEligibilitiesApiReducer(undefined, {})).toEqual(defaultState);
  });

  it('should handle post.receive action', () => {
    const action = {
      type: schemeEligibilitiesActions.api.expGalaxyPaymentV2.schemeEligibilities.post.receive,
      payload: {
        result: {
          errors: [{ code: 400 }],
        },
      },
    };
    const expectedState = {
      post: {
        statusCode: 400,
      },
    };
    expect(schemeEligibilitiesApiReducer(defaultState, action)).toEqual(expectedState);
  });

  it('should handle post.receive action with no errors', () => {
    const action = {
      type: schemeEligibilitiesActions.api.expGalaxyPaymentV2.schemeEligibilities.post.receive,
      payload: {
        result: {},
      },
    };
    const expectedState = {
      post: {
        statusCode: undefined,
      },
    };
    expect(schemeEligibilitiesApiReducer(defaultState, action)).toEqual(expectedState);
  });

  it('should handle post.error action', () => {
    const action = {
      type: schemeEligibilitiesActions.api.expGalaxyPaymentV2.schemeEligibilities.post.error,
      payload: {
        error: {
          data: {
            errors: [{ code: 500 }],
          },
        },
      },
    };
    const expectedState = {
      post: {
        statusCode: 500,
      },
    };
    expect(schemeEligibilitiesApiReducer(defaultState, action)).toEqual(expectedState);
  });

  it('should handle post.error action with no errors', () => {
    const action = {
      type: schemeEligibilitiesActions.api.expGalaxyPaymentV2.schemeEligibilities.post.error,
      payload: {
        error: {
          data: {},
        },
      },
    };
    const expectedState = {
      post: {
        statusCode: null,
      },
    };
    expect(schemeEligibilitiesApiReducer(defaultState, action)).toEqual(expectedState);
  });
});
