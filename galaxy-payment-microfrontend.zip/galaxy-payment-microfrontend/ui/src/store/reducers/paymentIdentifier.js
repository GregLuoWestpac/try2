/* eslint-disable default-param-last */
import { handleActions } from 'redux-actions';
import { paymentIdentifierActions } from '../generated';

export const defaultState = {
  get: {
    statusCode: null,
  },
};

export const paymentIdentifierApiReducer = handleActions(
  {
    [paymentIdentifierActions.api.expGalaxyPaymentV2.paymentIdentifier.get
      .receive]: (state = defaultState, action) => {
      const statusCode = action?.meta?.statusCode;

      return {
        ...state,
        get: {
          ...state.get,
          ...(statusCode && {
            statusCode,
          }),
        },
      };
    },
    [paymentIdentifierActions.api.expGalaxyPaymentV2.paymentIdentifier.get
      .error]: (state = defaultState, action) => {
      const statusCode = action?.payload?.error?.status;
      const errors = action?.payload?.error?.data?.errors;
      return {
        ...state,
        get: {
          ...state.get,
          ...(statusCode && {
            statusCode,
          }),
          ...(errors && {
            errors,
          }),
        },
      };
    },
  },
  defaultState
);
