import { transferCreateApiReducer, defaultState } from './transferCreate';
import {
  transferCreateActions,
  transferCreateEntityActions,
} from '../generated';

describe('transferCreateApiReducer', () => {
  it('should handle transferCreateActions.api.expGalaxyPaymentV2.transferCreate.post.receive', () => {
    const action = {
      type: transferCreateActions.api.expGalaxyPaymentV2.transferCreate.post
        .receive,
      meta: {
        statusCode: 201,
      },
    };

    const newState = transferCreateApiReducer(defaultState, action);

    expect(newState).toEqual({
      post: {
        statusCode: 201,
      },
    });
  });

  it('should handle transferCreateActions.api.expGalaxyPaymentV2.transferCreate.post.error with status code', () => {
    const action = {
      type: transferCreateActions.api.expGalaxyPaymentV2.transferCreate.post
        .error,
      payload: {
        error: {
          status: 500,
        },
      },
    };

    const newState = transferCreateApiReducer(defaultState, action);

    expect(newState).toEqual({
      post: {
        statusCode: 500,
      },
    });
  });

  it('should handle transferCreateActions.api.expGalaxyPaymentV2.transferCreate.post.error with status code and errors', () => {
    const action = {
      type: transferCreateActions.api.expGalaxyPaymentV2.transferCreate.post
        .error,
      payload: {
        error: {
          status: 401,
          data: {
            errors: [
              {
                code: 8125,
                message: 'Authoriser Approval Required',
              },
            ],
          },
        },
      },
    };

    const newState = transferCreateApiReducer(defaultState, action);

    expect(newState).toEqual({
      post: {
        statusCode: 401,
        errors: [
          {
            code: 8125,
            message: 'Authoriser Approval Required',
          },
        ],
      },
    });
  });

  it('should handle transferCreateEntityActions.api.expGalaxyPaymentV2.transferCreate.clear.request', () => {
    const initialState = {
      post: {
        statusCode: 401,
        errors: [{ code: 8125, message: 'Authoriser Approval Required' }],
      },
    };

    const action = {
      type: transferCreateEntityActions.api.expGalaxyPaymentV2.transferCreate
        .clear.request,
    };

    const newState = transferCreateApiReducer(initialState, action);

    expect(newState).toEqual(defaultState);
  });

  it('should return current state for unknown action', () => {
    const action = {
      type: 'UNKNOWN_ACTION',
    };

    const newState = transferCreateApiReducer(defaultState, action);

    expect(newState).toEqual(defaultState);
  });
});
