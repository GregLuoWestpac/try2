import { handleActions } from 'redux-actions';
import { paymentreturnsActions } from '../generated';

export const defaultState = {
  post: {
    statusCode: null,
  },
};

export const paymentReturnsApiReducer = handleActions(
  {
    [paymentreturnsActions.api.expGalaxyPaymentV2.paymentreturns.post.receive]: (
      state = defaultState,
      action,
    ) => {
      const statusCode = action?.meta?.statusCode;

      return {
        ...state,
        post: {
          ...state.post,
          ...(statusCode && {
            statusCode,
          }),
        },
      };
    },
    [paymentreturnsActions.api.expGalaxyPaymentV2.paymentreturns.post.error]: (
      state = defaultState,
      action,
    ) => {
      const statusCode = action?.payload?.error?.status;
      return {
        ...state,
        post: {
          ...state.post,
          ...(statusCode && {
            statusCode,
          }),
        },
      };
    },
  },
  defaultState,
);
