import { paymentCreateApiReducer, defaultState } from './paymentCreate';
import { paymentCreateActions } from '../generated';

describe('paymentCreateApiReducer', () => {
  it('should handle paymentCreateActions.api.expGalaxyPaymentV2.paymentCreate.post.receive', () => {
    const action = {
      type: paymentCreateActions.api.expGalaxyPaymentV2.paymentCreate.post.receive,
      meta: {
        statusCode: 200,
      },
    };

    const newState = paymentCreateApiReducer(defaultState, action);

    expect(newState).toEqual({
      post: {
        statusCode: 200,
      },
    });
  });

  it('should handle paymentCreateActions.api.expGalaxyPaymentV2.paymentCreate.post.error', () => {
    const action = {
      type: paymentCreateActions.api.expGalaxyPaymentV2.paymentCreate.post.error,
      payload: {
        error: {
          status: 500,
        },
      },
    };

    const newState = paymentCreateApiReducer(defaultState, action);

    expect(newState).toEqual({
      post: {
        statusCode: 500,
      },
    });
  });
});
