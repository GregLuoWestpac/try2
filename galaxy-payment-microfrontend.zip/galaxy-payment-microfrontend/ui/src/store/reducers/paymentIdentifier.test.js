import { paymentIdentifierApiReducer, defaultState } from './paymentIdentifier';
import { paymentIdentifierActions } from '../generated';

describe('paymentIdentifierApiReducer', () => {
  it('paymentIdentifierActions.api.expGalaxyPaymentV2.paymentIdentifier.get.receive', () => {
    const action = {
      type: paymentIdentifierActions.api.expGalaxyPaymentV2.paymentIdentifier.get.receive,
      meta: {
        statusCode: 200,
      },
    };

    const newState = paymentIdentifierApiReducer(defaultState, action);

    expect(newState).toEqual({
      get: {
        statusCode: 200,
      },
    });
  });

  it('should handle paymentIdentifierActions.api.expGalaxyPaymentV2.paymentIdentifier.get.error', () => {
    const action = {
      type: paymentIdentifierActions.api.expGalaxyPaymentV2.paymentIdentifier.get.error,
      payload: {
        error: {
          status: 500,
        },
      },
    };

    const newState = paymentIdentifierApiReducer(defaultState, action);

    expect(newState).toEqual({
      get: {
        statusCode: 500,
      },
    });
  });
});
