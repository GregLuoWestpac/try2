/* eslint-disable default-param-last */
import { handleActions } from 'redux-actions';
import { beneficiaryCreateActions } from '../generated';

const defaultState = {
  post: {
    statusCode: null,
  },
};

export const beneficiaryCreateApiReducer = handleActions(
  {
    [beneficiaryCreateActions.api.expGalaxyPaymentV2.beneficiaryCreate.post
      .receive]: (state = defaultState, action) => {
      const statusCode = action?.meta?.statusCode;

      return {
        ...state,
        post: {
          ...state.post,
          ...(statusCode && {
            statusCode,
          }),
        },
      };
    },
    [beneficiaryCreateActions.api.expGalaxyPaymentV2.beneficiaryCreate.post
      .error]: (state = defaultState, action) => {
      const statusCode = action?.payload?.error?.status;
      const errors = action?.payload?.error?.data?.errors;
      return {
        ...state,
        post: {
          ...state.post,
          ...(statusCode && {
            statusCode,
          }),
          ...(errors && {
            errors,
          }),
        },
      };
    },
  },
  defaultState
);
