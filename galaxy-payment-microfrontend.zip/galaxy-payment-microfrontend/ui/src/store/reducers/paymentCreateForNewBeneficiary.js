/* eslint-disable default-param-last */
import { handleActions } from 'redux-actions';
import { paymentCreateForNewBeneficiaryActions } from '../generated';

export const defaultState = {
  post: {
    statusCode: null,
  },
};

export const paymentCreateForNewBeneficiaryApiReducer = handleActions(
  {
    [paymentCreateForNewBeneficiaryActions.api.expGalaxyPaymentV2
      .paymentCreateForNewBeneficiary.post.receive]: (
      state = defaultState,
      action
    ) => {
      const statusCode = action?.meta?.statusCode;

      return {
        ...state,
        post: {
          ...state.post,
          ...(statusCode && {
            statusCode,
          }),
        },
      };
    },
    [paymentCreateForNewBeneficiaryActions.api.expGalaxyPaymentV2
      .paymentCreateForNewBeneficiary.post.error]: (
      state = defaultState,
      action
    ) => {
      const statusCode = action?.payload?.error?.status;
      const errors = action?.payload?.error?.data?.errors;
      return {
        ...state,
        post: {
          ...state.post,
          ...(statusCode && {
            statusCode,
          }),
          ...(errors && {
            errors,
          }),
        },
      };
    },
  },
  defaultState
);
