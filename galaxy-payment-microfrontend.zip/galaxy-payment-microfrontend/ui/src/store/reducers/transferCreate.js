/* eslint-disable default-param-last */
import { handleActions } from 'redux-actions';
import {
  transferCreateActions,
  transferCreateEntityActions,
} from '../generated';

export const defaultState = {
  post: {
    statusCode: null,
  },
};

export const transferCreateApiReducer = handleActions(
  {
    [transferCreateActions.api.expGalaxyPaymentV2.transferCreate.post.receive]:
      (state = defaultState, action) => {
        const statusCode = action?.meta?.statusCode;

        return {
          ...state,
          post: {
            ...state.post,
            ...(statusCode && {
              statusCode,
            }),
          },
        };
      },
    [transferCreateActions.api.expGalaxyPaymentV2.transferCreate.post.error]: (
      state = defaultState,
      action
    ) => {
      const statusCode = action?.payload?.error?.status;
      const errors = action?.payload?.error?.data?.errors;
      return {
        ...state,
        post: {
          ...state.post,
          ...(statusCode && {
            statusCode,
          }),
          ...(errors && {
            errors,
          }),
        },
      };
    },
    [transferCreateEntityActions.api.expGalaxyPaymentV2.transferCreate.clear
      .request]: () => defaultState,
  },
  defaultState
);
