import { handleActions } from 'redux-actions';
import { schemeEligibilitiesActions } from '../generated';

export const defaultState = {
  post: {
    statusCode: null,
  },
};

export const schemeEligibilitiesApiReducer = handleActions(
  {
    [schemeEligibilitiesActions.api.expGalaxyPaymentV2.schemeEligibilities.post.receive]: (
      state = defaultState,
      action = undefined,
    ) => {
      const statusCode = action?.payload?.result?.errors?.[0]?.code;
      return {
        ...state,
        post: {
          ...state.post,
          statusCode: statusCode || undefined,
        },
      };
    },
    [schemeEligibilitiesActions.api.expGalaxyPaymentV2.schemeEligibilities.post.error]: (
      state = defaultState,
      action = undefined,
    ) => {
      const statusCode = action?.payload?.error?.data?.errors?.[0]?.code;
      return {
        ...state,
        post: {
          ...state.post,
          ...(statusCode && {
            statusCode,
          }),
        },
      };
    },
  },
  defaultState,
);
