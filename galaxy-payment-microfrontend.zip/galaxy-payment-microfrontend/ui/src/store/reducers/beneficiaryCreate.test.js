import { beneficiaryCreateActions } from '../generated';
import { beneficiaryCreateApiReducer, defaultState } from './beneficiaryCreate';

describe('beneficiaryCreateApiReducer', () => {
  it('beneficiaryCreateActions.api.expGalaxyPaymentV2.beneficiaryCreate.post.receive', () => {
    const action = {
      type: beneficiaryCreateActions.api.expGalaxyPaymentV2.beneficiaryCreate
        .post.receive,
      meta: {
        statusCode: 200,
      },
    };

    const newState = beneficiaryCreateApiReducer(defaultState, action);

    expect(newState).toEqual({
      post: {
        statusCode: 200,
      },
    });
  });

  it('should handle beneficiaryCreateActions.api.expGalaxyPaymentV2.beneficiaryCreate.post.error', () => {
    const action = {
      type: beneficiaryCreateActions.api.expGalaxyPaymentV2.beneficiaryCreate
        .post.error,
      payload: {
        error: {
          status: 500,
        },
      },
    };

    const newState = beneficiaryCreateApiReducer(defaultState, action);

    expect(newState).toEqual({
      post: {
        statusCode: 500,
      },
    });
  });
});
