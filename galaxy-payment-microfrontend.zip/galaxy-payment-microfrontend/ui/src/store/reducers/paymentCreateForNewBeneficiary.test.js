import { paymentCreateForNewBeneficiaryActions } from '../generated';
import {
  defaultState,
  paymentCreateForNewBeneficiaryApiReducer,
} from './paymentCreateForNewBeneficiary';

describe('paymentCreateForNewBeneficiaryApiReducer', () => {
  it('paymentCreateForNewBeneficiaryActions.api.expGalaxyPaymentV2.paymentCreateForNewBeneficiary.post.receive', () => {
    const action = {
      type: paymentCreateForNewBeneficiaryActions.api.expGalaxyPaymentV2
        .paymentCreateForNewBeneficiary.post.receive,
      meta: {
        statusCode: 200,
      },
    };

    const newState = paymentCreateForNewBeneficiaryApiReducer(
      defaultState,
      action
    );

    expect(newState).toEqual({
      post: {
        statusCode: 200,
      },
    });
  });

  it('should handle paymentCreateForNewBeneficiaryActions.api.expGalaxyPaymentV2.paymentCreateForNewBeneficiary.post.error', () => {
    const action = {
      type: paymentCreateForNewBeneficiaryActions.api.expGalaxyPaymentV2
        .paymentCreateForNewBeneficiary.post.error,
      payload: {
        error: {
          status: 500,
        },
      },
    };

    const newState = paymentCreateForNewBeneficiaryApiReducer(
      defaultState,
      action
    );

    expect(newState).toEqual({
      post: {
        statusCode: 500,
      },
    });
  });
});
