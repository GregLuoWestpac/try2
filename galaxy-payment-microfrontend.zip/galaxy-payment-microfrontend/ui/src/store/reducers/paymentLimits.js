/* eslint-disable default-param-last */
import { handleActions } from 'redux-actions';
import { paymentLimitsActions } from '../generated';

export const defaultState = {
  post: {
    statusCode: null,
  },
};

export const paymentLimitsApiReducer = handleActions(
  {
    [paymentLimitsActions.api.expGalaxyPaymentV2.paymentLimits.get.receive]: (
      state = defaultState,
      action
    ) => {
      const statusCode = action?.meta?.statusCode;

      return {
        ...state,
        post: {
          ...state.post,
          ...(statusCode && {
            statusCode,
          }),
        },
      };
    },
    [paymentLimitsActions.api.expGalaxyPaymentV2.paymentLimits.get.error]: (
      state = defaultState,
      action
    ) => {
      const statusCode = action?.payload?.error?.status;
      const errors = action?.payload?.error?.data?.errors;
      return {
        ...state,
        post: {
          ...state.post,
          ...(statusCode && {
            statusCode,
          }),
          ...(errors && {
            errors,
          }),
        },
      };
    },
  },
  defaultState
);
