/* eslint-disable default-param-last */
import { handleActions } from 'redux-actions';
import { paymentCreateActions, paymentCreateEntityActions } from '../generated';

export const defaultState = {
  post: {
    statusCode: null,
  },
};

export const paymentCreateApiReducer = handleActions(
  {
    [paymentCreateActions.api.expGalaxyPaymentV2.paymentCreate.post.receive]: (
      state = defaultState,
      action
    ) => {
      const statusCode = action?.meta?.statusCode;

      return {
        ...state,
        post: {
          ...state.post,
          ...(statusCode && {
            statusCode,
          }),
        },
      };
    },
    [paymentCreateActions.api.expGalaxyPaymentV2.paymentCreate.post.error]: (
      state = defaultState,
      action
    ) => {
      const statusCode = action?.payload?.error?.status;
      const errors = action?.payload?.error?.data?.errors;
      return {
        ...state,
        post: {
          ...state.post,
          ...(statusCode && {
            statusCode,
          }),
          ...(errors && {
            errors,
          }),
        },
      };
    },
    [paymentCreateEntityActions.api.expGalaxyPaymentV2.paymentCreate.clear
      .request]: () => defaultState,
  },
  defaultState
);
