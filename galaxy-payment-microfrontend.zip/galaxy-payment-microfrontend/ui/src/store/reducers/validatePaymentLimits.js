/* eslint-disable default-param-last */
import { handleActions } from 'redux-actions';
import { validatePaymentLimitsActions } from '../generated';

export const defaultState = {
  post: {
    statusCode: null,
  },
};

export const validatePaymentLimitsApiReducer = handleActions(
  {
    [validatePaymentLimitsActions.api.expGalaxyPaymentV2.validatePaymentLimits
      .post.receive]: (state = defaultState, action) => {
      const statusCode = action?.meta?.statusCode;

      return {
        ...state,
        post: {
          ...state.post,
          statusCode: statusCode ? { ...statusCode } : null,
        },
      };
    },
    [validatePaymentLimitsActions.api.expGalaxyPaymentV2.validatePaymentLimits
      .post.error]: (state = defaultState, action) => {
      const statusCode = action?.payload?.error?.status;
      const errors = action?.payload?.error?.data?.errors;
      return {
        ...state,
        post: {
          ...state.post,
          statusCode: statusCode ? { ...statusCode } : null,
          errors: errors || null,
        },
      };
    },
  },
  defaultState
);
