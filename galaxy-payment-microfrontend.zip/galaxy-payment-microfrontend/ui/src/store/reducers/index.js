import { combineReducers } from '@mep-ui/framework';
import { beneficiaryCreateApiReducer } from './beneficiaryCreate';
import { paymentCreateForNewBeneficiaryApiReducer } from './paymentCreateForNewBeneficiary';
import { paymentIdentifierApiReducer } from './paymentIdentifier';
import { paymentLimitsApiReducer } from './paymentLimits';
import { paymentReturnsApiReducer } from './paymentReturns';
import { paymentCreateApiReducer } from './paymentCreate';
import { schemeEligibilitiesApiReducer } from './schemeEligibilities';
import { transferCreateApiReducer } from './transferCreate';
import { validatePaymentLimitsApiReducer } from './validatePaymentLimits';

const expGalaxyPaymentV2Reducer = combineReducers({
  paymentCreate: paymentCreateApiReducer,
  paymentReturns: paymentReturnsApiReducer,
  paymentCreateForNewBeneficiary: paymentCreateForNewBeneficiaryApiReducer,
  beneficiaryCreate: beneficiaryCreateApiReducer,
  schemeEligibilities: schemeEligibilitiesApiReducer,
  paymentIdentifier: paymentIdentifierApiReducer,
  transferCreate: transferCreateApiReducer,
  validatePaymentLimits: validatePaymentLimitsApiReducer,
  paymentLimits: paymentLimitsApiReducer,
});

const apiReducer = combineReducers({
  expGalaxyPaymentV2: expGalaxyPaymentV2Reducer,
});

export const reducer = {
  api: apiReducer,
};

export default reducer;
