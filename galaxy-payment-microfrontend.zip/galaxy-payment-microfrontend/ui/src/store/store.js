import {
  apiClientMiddleware,
  appConfigReducer,
  combineReducers,
  createStore,
} from '@mep-ui/framework';
import createSagaMiddleware from 'redux-saga';
import { reducer as galaxyPaymentEntityReducer } from './generated';
import galaxyReducer from './reducers';
import { rootMFESaga } from './sagas';

import { checkEntitlementError } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import {
  PAYMENT_CREATE_ERROR_ACTION,
  PAYMENT_NEW_BENEFICIARY_ERROR_ACTION,
  TRANSFER_CREATE_ERROR_ACTION,
  PAYMENT_IDENTIFIER_ERROR_ACTION,
  CREATE_BENEFICIARY_ERROR_ACTION,
} from '../common/constants';

const sagaMiddleware = createSagaMiddleware();

//@ts-ignore:next-line
const checkEntErrorMiddleware = (store) => (next) => (action) => {
  checkEntitlementError(action, [
    PAYMENT_CREATE_ERROR_ACTION,
    PAYMENT_IDENTIFIER_ERROR_ACTION,
    CREATE_BENEFICIARY_ERROR_ACTION,
    PAYMENT_NEW_BENEFICIARY_ERROR_ACTION,
    TRANSFER_CREATE_ERROR_ACTION,
  ]);
  return next(action);
};

const middlewares = [
  sagaMiddleware,
  apiClientMiddleware,
  checkEntErrorMiddleware,
];

const store = createStore({
  name: 'galaxy-payment',
  reducer: {
    config: appConfigReducer,
    // capabilities: combineReducers({}),
    entities: combineReducers({ ...galaxyPaymentEntityReducer }),
    galaxy: combineReducers({ ...galaxyReducer }),
  },
  middlewares, // any custom middlewares to be added
  initialState: {},
});

sagaMiddleware.run(rootMFESaga);

export default store;
