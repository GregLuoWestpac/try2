/* eslint-disable default-param-last */
import { createActions, handleActions } from 'redux-actions';

export const actions = createActions({
  microFrontends: {
    payment: {
      load: (data) => ({ data, isLoaded: true }),
      test: (data) => ({ data }),
    },
  },
});

const reducer = handleActions(
  {
    [actions.microFrontends.payment.test]: (state = {}, { payload }) => ({
      ...state,
      ...payload,
    }),
    [actions.microFrontends.payment.load]: (state = {}, { payload }) => ({
      ...state,
      ...payload,
    }),
  },
  {}
);

export const mfeReducer = {
  payment: reducer,
};