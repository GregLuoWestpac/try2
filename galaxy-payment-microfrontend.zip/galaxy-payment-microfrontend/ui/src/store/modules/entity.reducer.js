export const entityReducer = {
  // ...referenceWidgetEntityReducer
};
