import { all } from 'redux-saga/effects';
import { watchAppConfig } from '@mep-ui/framework';

import { rootExportSaga as galaxyPaymentSagas } from '../generated';
import { watchMfeAsyncHandler } from './mfe.saga';

export function* rootMFESaga() {
  yield all([watchMfeAsyncHandler(), watchAppConfig(), galaxyPaymentSagas()]);
}
