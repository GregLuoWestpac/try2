/* eslint-disable no-promise-executor-return */
import { put, takeLatest } from 'redux-saga/effects';

import { actions } from '../modules';

const delay = (ms) => new Promise((res) => setTimeout(res, ms));

function* mfeAsyncHandler() {
  yield delay(1000);
  yield put(actions.microFrontends.payment.load('saga invoking action'));
}

export function* watchMfeAsyncHandler() {
  yield takeLatest(
    actions.microFrontends.payment.test().type,
    mfeAsyncHandler
  );
}