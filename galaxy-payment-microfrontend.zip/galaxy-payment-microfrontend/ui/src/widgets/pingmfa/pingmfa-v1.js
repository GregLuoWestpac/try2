import { WidgetBoundary, useManifest } from '@mep-ui/framework';
import isEmpty from 'lodash/isEmpty';
import { lazy, memo } from 'react';
import { PageLoader } from '../../components';

const WidgetBootStrapAsync = lazy(() =>
  // eslint-disable-next-line import/no-unresolved
  import('pingmfa-v1/StepUp')
);
function WidgetBootStrapWrapper(props) {
  const { isLoading, isError, manifest } = useManifest('galaxy-payment');
  if (isError) {
    return 'Error occurred while fetching manifest';
  }
  if (isLoading || isEmpty(manifest)) {
    return <PageLoader />;
  }

  const widgetManifest = manifest?.widgets?.find(
    (widget) => widget.name === 'pingmfa-v1'
  );

  return (
    <WidgetBoundary
      widget={WidgetBootStrapAsync}
      manifest={widgetManifest}
      // eslint-disable-next-line react/jsx-props-no-spreading
      {...props}
    />
  );
}

export const PingmfaWidgetApp = memo(WidgetBootStrapWrapper);
