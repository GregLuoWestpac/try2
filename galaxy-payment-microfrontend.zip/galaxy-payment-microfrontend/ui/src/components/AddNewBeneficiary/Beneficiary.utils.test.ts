import { PAYID_TYPE } from 'ui/src/common/types';
import { ERROR_MESSAGES } from '../../common/constants';
import {
  FriendlyPayIDType,
  getMappedFormFieldNameWithPayIDType,
  nameLikedFieldsValidationRules,
  validatePhone,
  validateEmail,
  validateAbnAcn,
  validateOrganisationId,
  payIdLookupErrorMessage,
  PayIDTypeForAPI,
  validateField,
} from './Beneficiary.utils';

describe('getFriendlyPayIDType', () => {
  it('should return the correct label for each PayID type', () => {
    expect(FriendlyPayIDType[PAYID_TYPE.PHONE]).toBe('Phone number');
    expect(FriendlyPayIDType[PAYID_TYPE.EMAIL]).toBe('Email');
    expect(FriendlyPayIDType[PAYID_TYPE.ABN_ACN]).toBe('ABN / ACN');
    expect(FriendlyPayIDType[PAYID_TYPE.ORGANISATION_ID]).toBe(
      'Organisation ID'
    );
  });
  it('should return the correct mapped form field name for each PayID type', () => {
    expect(getMappedFormFieldNameWithPayIDType(PAYID_TYPE.PHONE)).toBe(
      'beneficiary.phone'
    );
    expect(getMappedFormFieldNameWithPayIDType(PAYID_TYPE.EMAIL)).toBe(
      'beneficiary.email'
    );
    expect(getMappedFormFieldNameWithPayIDType(PAYID_TYPE.ABN_ACN)).toBe(
      'beneficiary.abnAcn'
    );
    expect(
      getMappedFormFieldNameWithPayIDType(PAYID_TYPE.ORGANISATION_ID)
    ).toBe('beneficiary.organisationId');
  });
});

describe('nameLikedFieldsValidationRules', () => {
  const rules = nameLikedFieldsValidationRules;

  it('should return true for valid input', () => {
    if (typeof rules?.validate !== 'function') {
      throw new Error('Validation rule is not a function');
    }
    const result = rules.validate(
      'ValidName123',
      {} as Record<string, unknown>
    );
    expect(result).toBe(true);
  });

  it('should return an error message for input with forbidden characters', () => {
    if (typeof rules?.validate !== 'function') {
      throw new Error('Validation rule is not a function');
    }
    const result = rules?.validate(
      'Invalid<Name>',
      {} as Record<string, unknown>
    );
    expect(typeof result).toBe('string');
    expect(result).toContain(
      'You cannot use the following special characters ;  --  {  }  <  >  %  #  "  ='
    );
  });
});

describe('validatePhone', () => {
  it('should return an error message for empty input', () => {
    const result = validatePhone('');
    expect(result).toBe(ERROR_MESSAGES.PHONE);
  });

  it('should return an error message for input with less than 2 digits after hyphen', () => {
    const result = validatePhone('61-1');
    expect(result).toBe(ERROR_MESSAGES.PHONE);
  });

  it('should return true for valid phone number input', () => {
    const result = validatePhone('61-12');
    expect(result).toBe(true);
  });
});

describe('validateEmail', () => {
  it('should return an error message for empty input', () => {
    const result = validateEmail('');
    expect(result).toBe(ERROR_MESSAGES.EMAIL_REQUIRED);
  });

  it('should return an error message for input shorter than 5 characters', () => {
    const result = validateEmail('a@b');
    expect(result).toBe(ERROR_MESSAGES.EMAIL_REQUIRED);
  });

  it('should return an error message for input with forbidden characters', () => {
    const result = validateEmail('invalid<email>@example.com');
    expect(typeof result).toBe('string');
    expect(result).toContain(
      'You cannot use the following special characters ;  --  {  }  <  >  %  #  "  ='
    );
  });

  it('should return an error message for invalid email format', () => {
    const result = validateEmail('invalid-email-format');
    expect(result).toBe(ERROR_MESSAGES.EMAIL_REQUIRED);
  });

  it('should return true for valid email input', () => {
    const result = validateEmail('valid.email@example.com');
    expect(result).toBe(true);
  });
});

describe('validateAbnAcn', () => {
  it('should return an error message for empty input', () => {
    const result = validateAbnAcn('');
    expect(result).toBe(ERROR_MESSAGES.ABN);
  });

  it('should return an error message for input shorter than 9 characters', () => {
    const result = validateAbnAcn('12345678');
    expect(result).toBe(ERROR_MESSAGES.ABN);
  });

  it('should return an error message for input longer than 11 characters', () => {
    const result = validateAbnAcn('123456789012');
    expect(result).toBe(ERROR_MESSAGES.ABN);
  });

  it('should return true for valid ABN/ACN input', () => {
    const result = validateAbnAcn('123456789');
    expect(result).toBe(true);
  });
});

describe('validateOrganisationId', () => {
  it('should return an error message for empty input', () => {
    const result = validateOrganisationId('');
    expect(result).toBe(ERROR_MESSAGES.ORGANISATION_REQUIRED);
  });

  it('should return an error message for input shorter than 2 characters', () => {
    const result = validateOrganisationId('A');
    expect(result).toBe(ERROR_MESSAGES.ORGANISATION_REQUIRED);
  });

  it('should return an error message for input with forbidden characters', () => {
    const result = validateOrganisationId('Invalid{ID}');
    expect(typeof result).toBe('string');
    expect(result).toContain(
      'You cannot use the following special characters ;  --  {  }  <  >  %  #  "  ='
    );
  });

  it('should return true for valid Organisation ID input', () => {
    const result = validateOrganisationId('ValidOrganisationID123');
    expect(result).toBe(true);
  });
});

describe('payIdLookupErrorMessage', () => {
  it('should return the provided error message if it exists', () => {
    const result = payIdLookupErrorMessage(
      ERROR_MESSAGES.PAYID_SERVICE_UNAVAILABLE
    );
    expect(result).toBe(ERROR_MESSAGES.PAYID_SERVICE_UNAVAILABLE);
  });

  it('should return true if no error message is provided', () => {
    const result = payIdLookupErrorMessage(undefined);
    expect(result).toBe(undefined);
  });
});

describe('PayIDTypeForAPI mapping', () => {
  it('maps each PAYID_TYPE to correct API string', () => {
    expect(PayIDTypeForAPI[PAYID_TYPE.PHONE]).toBe('phone');
    expect(PayIDTypeForAPI[PAYID_TYPE.EMAIL]).toBe('email');
    expect(PayIDTypeForAPI[PAYID_TYPE.ABN_ACN]).toBe('aubn');
    expect(PayIDTypeForAPI[PAYID_TYPE.ORGANISATION_ID]).toBe('orgn');
  });
});

describe('getMappedFormFieldNameWithPayIDType edge cases', () => {
  it('returns Unknown for undefined', () => {
    expect(getMappedFormFieldNameWithPayIDType(undefined)).toBe('Unknown');
  });
  it('returns Unknown for invalid value', () => {
    // Cast to force invalid enum value at runtime while satisfying TS
    expect(
      getMappedFormFieldNameWithPayIDType('INVALID' as unknown as PAYID_TYPE)
    ).toBe('Unknown');
  });
});

describe('validateField dispatcher', () => {
  it('validates phone field', () => {
    expect(validateField('phone', '')).toBe(ERROR_MESSAGES.PHONE);
    expect(validateField('phone', '61-12')).toBe(true);
  });
  it('validates email field', () => {
    expect(validateField('email', '')).toBe(ERROR_MESSAGES.EMAIL_REQUIRED);
  });
  it('validates abnAcn field', () => {
    expect(validateField('abnAcn', '123')).toBe(ERROR_MESSAGES.ABN);
  });
  it('validates organisationId field', () => {
    expect(validateField('organisationId', '')).toBe(
      ERROR_MESSAGES.ORGANISATION_REQUIRED
    );
  });
  it('returns undefined for unknown field name', () => {
    expect(validateField('unknownField', 'whatever')).toBeUndefined();
  });
});

describe('payIdLookupErrorMessage extended cases', () => {
  const allowed = [
    ERROR_MESSAGES.PAYID_SERVICE_UNAVAILABLE,
    ERROR_MESSAGES.PAYID_CHECK_LIMIT_EXCEEDED,
    ERROR_MESSAGES.INVALID_PAYID,
    ERROR_MESSAGES.PHONE,
    ERROR_MESSAGES.EMAIL_REQUIRED,
    ERROR_MESSAGES.ABN_ACN,
    ERROR_MESSAGES.ORGANISATION_ID,
  ];
  it('returns message for all allowed error codes', () => {
    allowed.forEach((msg) => {
      expect(payIdLookupErrorMessage(msg)).toBe(msg);
    });
  });
  it('returns undefined for disallowed message', () => {
    expect(payIdLookupErrorMessage('Some other error')).toBeUndefined();
  });
});
