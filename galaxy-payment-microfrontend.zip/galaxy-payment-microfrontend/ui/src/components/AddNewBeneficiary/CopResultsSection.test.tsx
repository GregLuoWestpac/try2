import { render, screen } from '@testing-library/react';
import React from 'react';
import { CopResultsSection } from './CopResultsSection';

// Mock mv-utils for isStaffPortal
jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  isStaffPortal: jest.fn(() => false),
}));

// Mock mv-cop-accountname-check component
jest.mock('@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check', () => ({
  MVCopAccountNameCheck: ({
    customStatus,
    copCheckResultData,
  }: {
    customStatus?: string;
    copCheckResultData?: { matchedAccountName: string };
  }) => (
    <div data-testid="mv-cop-accountname-check">
      {customStatus && <span data-testid="custom-status">{customStatus}</span>}
      {copCheckResultData && (
        <span data-testid="result-data">
          {copCheckResultData.matchedAccountName}
        </span>
      )}
    </div>
  ),
}));

const defaultProps = {
  isCopLimitExceeded: false,
  shouldShowCopResults: false,
  isCopLoading: false,
  isCopError: false,
  showCheckDetailsAlert: false,
};

describe('CopResultsSection', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    const {
      isStaffPortal,
    } = require('@mesh-tenant-multiverse-ui-common/mv-utils');
    (isStaffPortal as jest.Mock).mockReturnValue(false);
  });

  it('should render nothing when all flags are false', () => {
    const { container } = render(<CopResultsSection {...defaultProps} />);
    expect(
      container.querySelector('[data-testid="mv-cop-accountname-check"]')
    ).not.toBeInTheDocument();
  });

  it('should render nothing for staff portal users', () => {
    const {
      isStaffPortal,
    } = require('@mesh-tenant-multiverse-ui-common/mv-utils');
    (isStaffPortal as jest.Mock).mockReturnValue(true);

    const { container } = render(
      <CopResultsSection
        {...defaultProps}
        shouldShowCopResults={true}
        isCopLimitExceeded={true}
      />
    );
    expect(
      container.querySelector('[data-testid="mv-cop-accountname-check"]')
    ).not.toBeInTheDocument();
  });

  describe('session/daily limit exceeded', () => {
    it('should show limit exceeded message when isCopLimitExceeded and shouldShowCopResults', () => {
      render(
        <CopResultsSection
          {...defaultProps}
          isCopLimitExceeded={true}
          shouldShowCopResults={true}
        />
      );
      expect(screen.getByTestId('custom-status')).toHaveTextContent(
        'SESSION_OR_DAILY_LIMIT_REACHED'
      );
    });

    it('should not show limit exceeded message when loading', () => {
      render(
        <CopResultsSection
          {...defaultProps}
          isCopLimitExceeded={true}
          shouldShowCopResults={true}
          isCopLoading={true}
        />
      );
      expect(screen.queryByTestId('custom-status')).not.toBeInTheDocument();
    });

    it('should not show limit exceeded message when shouldShowCopResults is false', () => {
      render(
        <CopResultsSection
          {...defaultProps}
          isCopLimitExceeded={true}
          shouldShowCopResults={false}
        />
      );
      expect(screen.queryByTestId('custom-status')).not.toBeInTheDocument();
    });
  });

  describe('API errors', () => {
    it('should show API error message when isCopError and shouldShowCopResults', () => {
      render(
        <CopResultsSection
          {...defaultProps}
          isCopError={true}
          shouldShowCopResults={true}
        />
      );
      expect(screen.getByTestId('custom-status')).toHaveTextContent(
        'API_ERROR'
      );
    });

    it('should not show API error when copCheckResultData is present', () => {
      render(
        <CopResultsSection
          {...defaultProps}
          isCopError={true}
          shouldShowCopResults={true}
          copCheckResultData={{
            matchedAccountName: 'Test',
            matchedStatusCOPCode: 'MTCH' as any,
            matchedColor: 'Green' as any,
          }}
        />
      );
      // Should show result data instead of API_ERROR
      expect(screen.getByTestId('result-data')).toHaveTextContent('Test');
      expect(screen.queryByText('API_ERROR')).not.toBeInTheDocument();
    });

    it('should not show API error when limit exceeded', () => {
      render(
        <CopResultsSection
          {...defaultProps}
          isCopError={true}
          shouldShowCopResults={true}
          isCopLimitExceeded={true}
        />
      );
      // Should show limit exceeded instead
      expect(screen.getByTestId('custom-status')).toHaveTextContent(
        'SESSION_OR_DAILY_LIMIT_REACHED'
      );
    });

    it('should not show API error when loading', () => {
      render(
        <CopResultsSection
          {...defaultProps}
          isCopError={true}
          shouldShowCopResults={true}
          isCopLoading={true}
        />
      );
      expect(screen.queryByTestId('custom-status')).not.toBeInTheDocument();
    });
  });

  describe('CoP result data', () => {
    it('should show result data when shouldShowCopResults and copCheckResultData present', () => {
      render(
        <CopResultsSection
          {...defaultProps}
          shouldShowCopResults={true}
          copCheckResultData={{
            matchedAccountName: 'Jane Smith',
            matchedStatusCOPCode: 'MTCH' as any,
            matchedColor: 'Green' as any,
          }}
        />
      );
      expect(screen.getByTestId('result-data')).toHaveTextContent('Jane Smith');
    });

    it('should not show result data when loading', () => {
      render(
        <CopResultsSection
          {...defaultProps}
          shouldShowCopResults={true}
          isCopLoading={true}
          copCheckResultData={{
            matchedAccountName: 'Jane Smith',
            matchedStatusCOPCode: 'MTCH' as any,
            matchedColor: 'Green' as any,
          }}
        />
      );
      expect(screen.queryByTestId('result-data')).not.toBeInTheDocument();
    });

    it('should not show result data when limit exceeded', () => {
      render(
        <CopResultsSection
          {...defaultProps}
          shouldShowCopResults={true}
          isCopLimitExceeded={true}
          copCheckResultData={{
            matchedAccountName: 'Jane Smith',
            matchedStatusCOPCode: 'MTCH' as any,
            matchedColor: 'Green' as any,
          }}
        />
      );
      // Limit exceeded takes precedence
      expect(screen.queryByTestId('result-data')).not.toBeInTheDocument();
      expect(screen.getByTestId('custom-status')).toHaveTextContent(
        'SESSION_OR_DAILY_LIMIT_REACHED'
      );
    });
  });

  describe('check details alert', () => {
    it('should show check details alert when showCheckDetailsAlert is true', () => {
      render(
        <CopResultsSection {...defaultProps} showCheckDetailsAlert={true} />
      );
      expect(screen.getByTestId('custom-status')).toHaveTextContent(
        'USER_DID_NOT_SELECT_CHECK_DETAILS'
      );
    });

    it('should not show check details alert when shouldShowCopResults is true', () => {
      render(
        <CopResultsSection
          {...defaultProps}
          showCheckDetailsAlert={true}
          shouldShowCopResults={true}
        />
      );
      expect(
        screen.queryByText('USER_DID_NOT_SELECT_CHECK_DETAILS')
      ).not.toBeInTheDocument();
    });

    it('should not show check details alert when limit exceeded', () => {
      render(
        <CopResultsSection
          {...defaultProps}
          showCheckDetailsAlert={true}
          isCopLimitExceeded={true}
        />
      );
      expect(
        screen.queryByText('USER_DID_NOT_SELECT_CHECK_DETAILS')
      ).not.toBeInTheDocument();
    });

    it('should not show check details alert when copCheckResultData is present', () => {
      render(
        <CopResultsSection
          {...defaultProps}
          showCheckDetailsAlert={true}
          copCheckResultData={{
            matchedAccountName: 'Test',
            matchedStatusCOPCode: 'MTCH' as any,
            matchedColor: 'Green' as any,
          }}
        />
      );
      expect(
        screen.queryByText('USER_DID_NOT_SELECT_CHECK_DETAILS')
      ).not.toBeInTheDocument();
    });
  });
});
