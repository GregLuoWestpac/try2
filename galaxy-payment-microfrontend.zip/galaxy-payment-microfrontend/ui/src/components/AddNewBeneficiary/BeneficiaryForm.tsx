/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-misused-promises */
import {
  MVButtonGroupController,
  MVCheckboxController,
  MVInputController,
  MVPhoneInputController,
} from '@mesh-tenant-multiverse-ui-common/mv-reacthookform';
import { MVAccountFormatter } from '@mesh-tenant-multiverse-ui-common/mv-accountformatter';
import { isStaffPortal } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { COPCheckResultData } from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
import { Alert, Button, Grid, GridItem, ProgressIndicator } from '@westpac/ui';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { FieldArrayPath, FieldPath, UseFormReturn } from 'react-hook-form';
import { useAccountNameCheck } from '../../hooks';
import {
  BeneTypes,
  MakePaymentFormDataType,
  PAYID_TYPE,
} from '../../common/types';
import {
  AliasType,
  ERROR_MESSAGES,
  INPUT_MAX_LENGTH,
  REGEX_PATTERN,
} from '../../common/constants';
import {
  FriendlyPayIDType,
  nameLikedFieldsValidationRules,
  payIdBSBLookupErrorMessage,
  validateAbnAcn,
  validateEmail,
  validateField,
  validateOrganisationId,
  validatePhone,
} from './Beneficiary.utils';
import {
  GetBSBLookupParamsPayload,
  PostAliasLookupParamsPayload,
} from '../../store/types';
import { PostAliasLookup } from '../../store/types/AliasLookup';
import { Branch } from '../../store/types/BsbLookup';
import { useBsbLookup } from './hooks/useBsbLookup';
import { useAliasLookup } from './hooks/useAliasLookup';
import { CopResultsSection } from './CopResultsSection';

type AddBeneficiaryFormProps = {
  form: UseFormReturn<MakePaymentFormDataType>;
  postAliasLookup?: (params: PostAliasLookupParamsPayload) => void;
  aliasLookupData?: PostAliasLookup[];
  doesAliasIdContainInvalidData?: boolean;
  isPayIdNotValid?: boolean;
  isPayIdLimitExceeded?: boolean;
  isPayIdServiceNotAvailable?: boolean;
  isAliasLookupFetching?: boolean;
  isAliasLookupError?: boolean;
  getBsbLookup?: (params: GetBSBLookupParamsPayload) => void;
  bsbLookupData?: Branch[];
  isBsbLookupFetching?: boolean;
  isBsbLookupError?: boolean;
  bsbLookupErrorStatusCode?: number;
  setIsNewBeneficiaryBsbLookupTriggered?: (value: boolean) => void;
  setIsNewBeneficiaryPayIdLookupTriggered?: (value: boolean) => void;
  resetLookup?: () => void;
  enableSaveBeneficiary?: boolean;
  isBeneficiaryFormOpen?: boolean;
  lookupState?: React.MutableRefObject<{
    triggeredByReview: boolean;
    fieldName: string | null;
  }>;
  isFormSubmitting?: React.MutableRefObject<boolean>;
  onAccountValidationChange?: (isValidated: boolean) => void;
  postAccountNameCheck?: (params: {
    accountName: string;
    accountNumber: string;
    bsb: string;
  }) => void;
  // CoP component props
  isCopLoading?: boolean;
  isCopError?: boolean;
  copCheckResultData?: COPCheckResultData;
  shouldShowCopResults?: boolean;
  onInvalidateCopCheck?: () => void;
  isCopLimitExceeded?: boolean;
};

export function BeneficiaryForm({
  form,
  postAliasLookup,
  aliasLookupData,
  doesAliasIdContainInvalidData,
  isPayIdNotValid,
  isPayIdLimitExceeded,
  isPayIdServiceNotAvailable,
  isAliasLookupFetching,
  isAliasLookupError,
  getBsbLookup,
  bsbLookupData,
  isBsbLookupFetching,
  isBsbLookupError,
  bsbLookupErrorStatusCode,
  setIsNewBeneficiaryBsbLookupTriggered,
  setIsNewBeneficiaryPayIdLookupTriggered,
  resetLookup,
  enableSaveBeneficiary = true,
  isBeneficiaryFormOpen = false,
  lookupState,
  isFormSubmitting,
  onAccountValidationChange,
  postAccountNameCheck,
  isCopLoading = false,
  isCopError = false,
  copCheckResultData,
  shouldShowCopResults: shouldShowCopResultsProp = false,
  onInvalidateCopCheck,
  isCopLimitExceeded = false,
}: AddBeneficiaryFormProps) {
  const {
    trigger,
    control,
    watch,
    getValues,
    setValue,
    clearErrors,
    setError,
    resetField,
    formState: { errors },
  } = form;

  const watchBeneficiaryType = watch('beneficiary.beneficiaryType');
  const watchPayIdType = watch('beneficiary.payIdType');
  const previousBSB = useRef<string>('');
  const watchBankName = watch('beneficiary.bankName');
  const [showPayIDInfo, setShowPayIDInfo] = useState(false);
  const [selectedPayID, setSelectedPayID] = useState('');

  // Use consolidated CoP validation hook
  const {
    copValidationStatus,
    isCheckDetailsClicked,
    isAccountClosed,
    handleCheckDetails,
    resetValidationState,
    notifyCheckRequired,
  } = useAccountNameCheck({
    form,
    fieldPaths: {
      bsb: 'beneficiary.bsb',
      accountNumber: 'beneficiary.accountNumber',
      accountName: 'beneficiary.accountName',
      beneficiaryType: 'beneficiary.beneficiaryType',
    },
    bsbBeneficiaryTypeValue: BeneTypes.BSB_ACCOUNT_NUMBER,
    postAccountNameCheck,
    copCheckResultData,
    isCopLoading,
    onAccountValidationChange,
    onInvalidateCopCheck,
    lookupState,
  });

  // Derive display flags from hook status and container prop
  const shouldShowCopResults =
    copValidationStatus === 'pending' ||
    copValidationStatus === 'validated' ||
    copValidationStatus === 'closed' ||
    shouldShowCopResultsProp;
  const showCheckDetailsAlert = copValidationStatus === 'checkRequired';

  useEffect(
    () => () => {
      resetField('beneficiary');
    },
    [resetField]
  );

  const { triggerAliasLookup, prevPayIdValue } = useAliasLookup({
    isAliasLookupError: isAliasLookupError || false,
    isAliasLookupFetching: isAliasLookupFetching || false,
    isPayIdNotValid: isPayIdNotValid || false,
    isPayIdLimitExceeded: isPayIdLimitExceeded || false,
    doesAliasIdContainInvalidData: doesAliasIdContainInvalidData || false,
    isPayIdServiceNotAvailable: isPayIdServiceNotAvailable || false,
    watchPayIdType,
    postAliasLookup,
    resetLookup,
    setSelectedPayID,
    setIsNewBeneficiaryPayIdLookupTriggered,
    setShowPayIDInfo,
    setError,
    clearErrors,
    validateField,
    setValue,
    getValues,
    aliasLookupData,
    lookupState,
    isFormSubmitting,
  });

  const { triggerBsbLookup, shouldShowBankName } = useBsbLookup({
    isBsbLookupError: isBsbLookupError || false,
    bsbLookupErrorStatusCode,
    setError,
    getValues,
    watchBankName,
    isBsbLookupFetching: isBsbLookupFetching || false,
    clearErrors,
    setValue,
    bsbLookupData,
    getBsbLookup,
    resetLookup,
    setIsNewBeneficiaryBsbLookupTriggered,
    errors,
    lookupState,
    isFormSubmitting,
  });

  const resetNewBeneInfo = useCallback(() => {
    resetLookup?.();
    setShowPayIDInfo(false);
    prevPayIdValue.current = '';
    previousBSB.current = '';
  }, [resetLookup, setShowPayIDInfo]);

  const handleBeneficiaryTypeChange = useCallback(() => {
    const fieldsToReset: (keyof FieldArrayPath<MakePaymentFormDataType>)[] = [
      'beneficiary.phone',
      'beneficiary.email',
      'beneficiary.abnAcn',
      'beneficiary.organisationId',
      'beneficiary.bsb',
      'beneficiary.accountNumber',
      'beneficiary.accountName',
      'beneficiary.beneficiaryNickname',
      'beneficiary.bankName',
      'beneficiary.payIdType',
      'beneficiary.payIdName',
    ];
    fieldsToReset.forEach((field) =>
      setValue(field as FieldPath<MakePaymentFormDataType>, '')
    );
    clearErrors(fieldsToReset as FieldPath<MakePaymentFormDataType>[]);
    resetNewBeneInfo();
    resetValidationState();
  }, [clearErrors, setValue, resetNewBeneInfo, resetValidationState]);

  const handlePayIdTypeChange = useCallback(() => {
    (
      [
        'beneficiary.phone',
        'beneficiary.email',
        'beneficiary.abnAcn',
        'beneficiary.organisationId',
        'beneficiary.beneficiaryNickname',
      ] as (keyof FieldArrayPath<MakePaymentFormDataType>)[]
    ).forEach((field) =>
      setValue(field as FieldPath<MakePaymentFormDataType>, '')
    );
    clearErrors([
      'beneficiary.phone',
      'beneficiary.email',
      'beneficiary.abnAcn',
      'beneficiary.organisationId',
      'beneficiary.beneficiaryNickname',
    ]);
    resetNewBeneInfo();
  }, [clearErrors, setValue, resetNewBeneInfo]);

  const onPayIDChange = (value: string) => {
    // Clear PayID errors and account details when user changes the PayID value
    // This allows re-lookup if they change the PayID
    const payIdFields = ['phone', 'email', 'abnAcn', 'organisationId'];
    payIdFields.forEach((field) => {
      clearErrors(`beneficiary.${field}` as keyof MakePaymentFormDataType);
    });
    setValue('beneficiary.accountName', '');
  };

  const prepopulateBeneficiaryNickname = (name: string) => {
    if (name && !getValues('beneficiary.beneficiaryNickname')) {
      setValue(
        'beneficiary.beneficiaryNickname',
        name.substring(0, INPUT_MAX_LENGTH.BENEFICIARY_NICKNAME)
      );
      clearErrors(['beneficiary.beneficiaryNickname']);
    }
  };
  useEffect(() => {
    prepopulateBeneficiaryNickname(aliasLookupData?.[0]?.name ?? '');
    if (aliasLookupData?.[0]?.name) {
      setValue('beneficiary.payIdName', aliasLookupData?.[0]?.name);
    }
  }, [aliasLookupData]);

  return (
    <div className="-mx-2 px-2" data-testid="beneficiary-form">
      <Alert look="warning" className="w-full mb-2.5">
        <strong> Stay safe from scams.</strong> Scammers pretend to be people
        you trust. Always confirm details by calling the beneficiary using an
        existing number you trust. We may not be able to recover your money if
        it is a scam.
      </Alert>

      <MVButtonGroupController
        id="beneficiaryType"
        label="Beneficiary type"
        fieldName="beneficiary.beneficiaryType"
        control={control}
        trigger={trigger}
        value={watchBeneficiaryType ?? null}
        onChange={handleBeneficiaryTypeChange}
        validationRules={{
          required: isBeneficiaryFormOpen
            ? ERROR_MESSAGES.BENEFICIARY_TYPE_REQUIRED
            : false,
        }}
        buttons={[
          {
            value: BeneTypes.BSB_ACCOUNT_NUMBER,
            label: 'BSB & account number',
          },
          { value: BeneTypes.PAYID, label: 'PayID' },
        ]}
        aria-label="Beneficiary type"
        className="mb-0.5"
      />

      {watchBeneficiaryType === BeneTypes.BSB_ACCOUNT_NUMBER && (
        <>
          <Grid>
            <GridItem span={4}>
              <MVInputController
                className="mb-2.5"
                id="bsb"
                fieldName="beneficiary.bsb"
                label="BSB"
                control={control}
                data-testid="bsb-input"
                hideCounterText
                maximumLength={INPUT_MAX_LENGTH.BSB}
                matchPattern={REGEX_PATTERN.DIGIT}
                validationRules={{
                  required: isBeneficiaryFormOpen ? ERROR_MESSAGES.BSB : false,
                  minLength: {
                    value: 6,
                    message: ERROR_MESSAGES.BSB,
                  },
                  validate: () =>
                    payIdBSBLookupErrorMessage(
                      errors.beneficiary?.bsb?.message
                    ),
                }}
                onChange={() => {
                  // Clear error and bank name when user changes the BSB value
                  // This allows re-lookup if they change the BSB
                  clearErrors('beneficiary.bsb');
                  setValue('beneficiary.bankName', '');
                }}
                onBlur={async (event: React.FocusEvent<HTMLInputElement>) => {
                  // Add a short delay before running the BSB lookup to avoid confusing UX behaviour
                  await new Promise((resolve) => {
                    setTimeout(resolve, 150);
                  });
                  const val = event.target.value;
                  if (val !== previousBSB.current) {
                    // if the BSB value has changed
                    previousBSB.current = val;
                    val.length === 6 &&
                      REGEX_PATTERN.DIGIT.test(val) &&
                      triggerBsbLookup(val);
                  }
                  await trigger('beneficiary.bsb');
                }}
              />
            </GridItem>
          </Grid>
          <Grid>
            {shouldShowBankName && (
              <GridItem span={12}>
                <Alert className="mb-2.5" look="info" iconSize="small">
                  <span className="font-semibold">Bank name: </span>
                  {watchBankName}
                </Alert>
              </GridItem>
            )}
          </Grid>
          <Grid>
            <GridItem span={8}>
              <MVInputController
                className="mb-2.5"
                id="accountNumber"
                fieldName="beneficiary.accountNumber"
                label="Account number"
                control={control}
                data-testid="account-number-input"
                hideCounterText
                maximumLength={INPUT_MAX_LENGTH.ACCOUNT_NUMBER}
                validationRules={{
                  required: isBeneficiaryFormOpen
                    ? ERROR_MESSAGES.ACCOUNT_NUMBER_REQUIRED
                    : false,
                  pattern: {
                    value: REGEX_PATTERN.ACCOUNT_NUMBER,
                    message: ERROR_MESSAGES.ACCOUNT_NUMBER_INVALID,
                  },
                }}
              />
              <div className="flex items-end gap-2.5 mb-2.5">
                <div className="flex-1">
                  <MVInputController
                    id="accountName"
                    className="mb-0 whitespace-pre-wrap"
                    fieldName="beneficiary.accountName"
                    label="Account name"
                    control={control}
                    data-testid="account-name-input"
                    hideCounterText
                    maximumLength={INPUT_MAX_LENGTH.ACCOUNT_NAME}
                    validationRules={{
                      required: isBeneficiaryFormOpen
                        ? ERROR_MESSAGES.ACCOUNT_NAME_REQUIRED
                        : false,
                      ...nameLikedFieldsValidationRules,
                      validate: {
                        ...nameLikedFieldsValidationRules.validate,
                        // ACX: Skip Check Details validation for staff users
                        checkDetailsRequired: () => {
                          if (
                            !isStaffPortal() &&
                            lookupState?.current.triggeredByReview &&
                            !isCheckDetailsClicked &&
                            !isAccountClosed
                          ) {
                            notifyCheckRequired();
                            return false;
                          }
                          return true;
                        },
                      },
                    }}
                    trimOnBlur
                    trimOnPaste
                    onBlur={() => {
                      prepopulateBeneficiaryNickname(
                        getValues('beneficiary.accountName') ?? ''
                      );
                    }}
                  />
                </div>
                {/* ACX: Hide Check Details button for staff users */}
                {!isStaffPortal() && (
                  <div className="flex items-center w-[110px]">
                    {isCopLoading ? (
                      <div className="flex items-center gap-2">
                        <ProgressIndicator size="small" />
                        <span>Verifying</span>
                      </div>
                    ) : (
                      <Button
                        soft
                        look="hero"
                        size="small"
                        type="button"
                        data-testid="check-details-button"
                        onClick={async () => {
                          await handleCheckDetails();
                        }}
                      >
                        Check details
                      </Button>
                    )}
                  </div>
                )}
              </div>
            </GridItem>
          </Grid>
          <CopResultsSection
            isCopLimitExceeded={isCopLimitExceeded}
            shouldShowCopResults={shouldShowCopResults}
            isCopLoading={isCopLoading}
            isCopError={isCopError}
            copCheckResultData={copCheckResultData}
            showCheckDetailsAlert={showCheckDetailsAlert}
          />
        </>
      )}

      {watchBeneficiaryType === BeneTypes.PAYID && (
        <>
          <MVButtonGroupController
            id="payIdType"
            label="PayID type"
            fieldName="beneficiary.payIdType"
            control={control}
            trigger={trigger}
            validationRules={{
              required: isBeneficiaryFormOpen
                ? ERROR_MESSAGES.PAYID_TYPE_REQUIRED
                : false,
            }}
            className="mb-0.5"
            buttons={[
              {
                value: PAYID_TYPE.PHONE,
                label: FriendlyPayIDType[PAYID_TYPE.PHONE],
              },
              {
                value: PAYID_TYPE.EMAIL,
                label: FriendlyPayIDType[PAYID_TYPE.EMAIL],
              },
              {
                value: PAYID_TYPE.ABN_ACN,
                label: FriendlyPayIDType[PAYID_TYPE.ABN_ACN],
              },
              {
                value: PAYID_TYPE.ORGANISATION_ID,
                label: FriendlyPayIDType[PAYID_TYPE.ORGANISATION_ID],
              },
            ]}
            onChange={handlePayIdTypeChange}
            aria-label="PayID type"
          />
          {watchPayIdType === PAYID_TYPE.PHONE && (
            <Grid>
              <GridItem span={6}>
                <MVPhoneInputController
                  id="phone"
                  label={FriendlyPayIDType[PAYID_TYPE.PHONE]}
                  fieldName="beneficiary.phone"
                  control={control}
                  data-testid="phone-input"
                  maximumLength={INPUT_MAX_LENGTH.PHONE}
                  className="mb-2.5"
                  onBlur={() => {
                    const isValid = validatePhone(
                      getValues('beneficiary.phone')
                    );
                    if (isValid === true) {
                      triggerAliasLookup(
                        'beneficiary.phone',
                        AliasType.PHONE,
                        getValues('beneficiary.phone')
                      );
                    }
                  }}
                  onChange={onPayIDChange}
                  matchPattern={REGEX_PATTERN.DIGIT}
                  validationRules={{
                    validate: (value: string) => {
                      if (!isBeneficiaryFormOpen) {
                        return true;
                      }
                      if (validatePhone(value) !== true) {
                        return validatePhone(value);
                      }
                      return payIdBSBLookupErrorMessage(
                        errors.beneficiary?.phone?.message
                      );
                    },
                  }}
                />
              </GridItem>
            </Grid>
          )}
          {watchPayIdType === PAYID_TYPE.EMAIL && (
            <Grid>
              <GridItem span={6}>
                <MVInputController
                  id="email"
                  fieldName="beneficiary.email"
                  label={FriendlyPayIDType[PAYID_TYPE.EMAIL]}
                  control={control}
                  data-testid="email-input"
                  hideCounterText
                  maximumLength={INPUT_MAX_LENGTH.EMAIL_OR_ORG_ID}
                  className="mb-2.5 whitespace-pre-wrap"
                  onBlur={(event: React.FocusEvent<HTMLInputElement>) =>
                    triggerAliasLookup(
                      'beneficiary.email',
                      AliasType.EMAIL,
                      event.target.value
                    )
                  }
                  onChange={onPayIDChange}
                  validationRules={{
                    validate: (value: string) => {
                      if (!isBeneficiaryFormOpen) {
                        return true;
                      }
                      if (validateEmail(value) !== true) {
                        return validateEmail(value);
                      }
                      return payIdBSBLookupErrorMessage(
                        errors.beneficiary?.email?.message
                      );
                    },
                  }}
                  trimOnBlur
                  trimOnPaste
                />
              </GridItem>
            </Grid>
          )}
          {watchPayIdType === PAYID_TYPE.ABN_ACN && (
            <Grid>
              <GridItem span={6}>
                <MVInputController
                  id="abnAcn"
                  fieldName="beneficiary.abnAcn"
                  label={FriendlyPayIDType[PAYID_TYPE.ABN_ACN]}
                  control={control}
                  data-testid="abn-acn-input"
                  hideCounterText
                  maximumLength={INPUT_MAX_LENGTH.ABN_ACN}
                  className="mb-2.5"
                  onBlur={(event: React.FocusEvent<HTMLInputElement>) =>
                    triggerAliasLookup(
                      'beneficiary.abnAcn',
                      AliasType.AUBN,
                      event.target.value
                    )
                  }
                  onChange={onPayIDChange}
                  matchPattern={REGEX_PATTERN.DIGIT}
                  validationRules={{
                    validate: (value: string) => {
                      if (!isBeneficiaryFormOpen) {
                        return true;
                      }
                      if (validateAbnAcn(value) !== true) {
                        return validateAbnAcn(value);
                      }
                      return payIdBSBLookupErrorMessage(
                        errors.beneficiary?.abnAcn?.message
                      );
                    },
                  }}
                />
              </GridItem>
            </Grid>
          )}
          {watchPayIdType === PAYID_TYPE.ORGANISATION_ID && (
            <Grid>
              <GridItem span={6}>
                <MVInputController
                  id="organisationId"
                  fieldName="beneficiary.organisationId"
                  label={FriendlyPayIDType[PAYID_TYPE.ORGANISATION_ID]}
                  control={control}
                  data-testid="organisation-id-input"
                  hideCounterText
                  className="mb-2.5 whitespace-pre-wrap"
                  onBlur={(event: React.FocusEvent<HTMLInputElement>) =>
                    triggerAliasLookup(
                      'beneficiary.organisationId',
                      AliasType.ORGN,
                      event.target.value
                    )
                  }
                  onChange={onPayIDChange}
                  maximumLength={INPUT_MAX_LENGTH.EMAIL_OR_ORG_ID}
                  validationRules={{
                    validate: (value: string) => {
                      if (!isBeneficiaryFormOpen) {
                        return true;
                      }
                      if (validateOrganisationId(value) !== true) {
                        return validateOrganisationId(value);
                      }
                      return payIdBSBLookupErrorMessage(
                        errors.beneficiary?.organisationId?.message
                      );
                    },
                  }}
                  trimOnBlur
                  trimOnPaste
                />
              </GridItem>
            </Grid>
          )}
          {showPayIDInfo && (
            <Grid>
              <GridItem span={12}>
                {isAliasLookupFetching && !isAliasLookupError ? (
                  <div className="flex flex-row items-center pl-0 mb-2.5">
                    <ProgressIndicator size="small" />
                    <div className="pl-1">Verifying PayID</div>
                  </div>
                ) : (
                  <Alert
                    className="mb-2.5 text-info"
                    look="info"
                    iconSize="small"
                  >
                    <MVAccountFormatter
                      details={[
                        {
                          label: 'PayID name:',
                          value: aliasLookupData?.[0]?.name || '',
                          className: 'm-0 whitespace-normal typography-body-11',
                          labelClassName: 'text-info',
                          variant: 'text',
                        },
                        {
                          label: 'PayID:',
                          value: selectedPayID,
                          className:
                            'm-0 overflow-hidden break-words typography-body-11',
                          labelClassName: 'text-info',
                          variant: 'text',
                        },
                        {
                          label: 'PayID type:',
                          value: watchPayIdType
                            ? FriendlyPayIDType[watchPayIdType]
                            : '',
                          className:
                            'm-0 overflow-hidden break-words typography-body-11',
                          labelClassName: 'text-info',
                          variant: 'text',
                        },
                      ]}
                    />
                  </Alert>
                )}
              </GridItem>
            </Grid>
          )}
        </>
      )}

      {watchBeneficiaryType && (
        <Grid>
          <GridItem span={6}>
            <MVInputController
              className="mb-2.5 whitespace-pre-wrap"
              id="beneficiaryNickname"
              fieldName="beneficiary.beneficiaryNickname"
              label="Beneficiary nickname"
              control={control}
              hideCounterText
              maximumLength={INPUT_MAX_LENGTH.BENEFICIARY_NICKNAME}
              validationRules={{
                required: isBeneficiaryFormOpen
                  ? ERROR_MESSAGES.BENEFICIARY_NICKNAME_REQUIRED
                  : false,
                ...nameLikedFieldsValidationRules,
              }}
              trimOnBlur
              trimOnPaste
            />
          </GridItem>
        </Grid>
      )}
      {enableSaveBeneficiary && (
        <div className="[&_span.size-4]:bg-white">
          <MVCheckboxController
            fieldName="beneficiary.saveBeneficiary"
            control={control}
            label="Save beneficiary"
          />
        </div>
      )}
    </div>
  );
}
