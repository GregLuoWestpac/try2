import { fireEvent, render, screen } from '@testing-library/react';
import { AddNewBeneficiaryButton } from './AddNewBeneficiaryButton';

describe('AddNewBeneficiaryButton', () => {
  it('should match snapshot', () => {
    const { container } = render(
      <AddNewBeneficiaryButton onClickNewBeneficiary={() => {}} />
    );
    expect(container).toMatchSnapshot();
  });

  it('should call onClickNewBeneficiary when clicked', () => {
    const onClickNewBeneficiary = jest.fn();
    render(
      <AddNewBeneficiaryButton onClickNewBeneficiary={onClickNewBeneficiary} />
    );
    fireEvent.click(screen.getByText('New beneficiary'));
    expect(onClickNewBeneficiary).toHaveBeenCalled();
  });
});
