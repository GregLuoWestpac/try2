import { RegisterOptions } from 'react-hook-form';
import {
  getFormattedForbiddenCharacters,
  validateWithLibrary,
} from '@mesh-tenant-multiverse-ui-common/mv-injection-checker';
import { PostAliaLookupParamsPayload } from 'ui/src/store/types/Actions';
import { PAYID_TYPE } from '../../common/types';
import {
  AUTHBIC8,
  ERROR_MESSAGES,
  forbiddenCharacterErrorMessage,
  PayID,
  REGEX_PATTERN,
} from '../../common/constants';

/**
 * CoP status codes indicating the account is closed
 * Codes ending in C7 indicate closed/non-existent accounts
 */
export const CLOSED_ACCOUNT_CODES = ['V0C7', 'V1C7', 'V2C7', 'VAC7', 'VTC7', 'VEC7'] as const;

export const FriendlyPayIDType = {
  [PAYID_TYPE.PHONE]: 'Phone number',
  [PAYID_TYPE.EMAIL]: 'Email',
  [PAYID_TYPE.ABN_ACN]: 'ABN / ACN',
  [PAYID_TYPE.ORGANISATION_ID]: 'Organisation ID',
};

export const PayIDTypeForAPI = {
  [PAYID_TYPE.PHONE]: 'phone',
  [PAYID_TYPE.EMAIL]: 'email',
  [PAYID_TYPE.ABN_ACN]: 'aubn',
  [PAYID_TYPE.ORGANISATION_ID]: 'orgn',
};

export const getMappedFormFieldNameWithPayIDType = (
  payIDTypeValue: PAYID_TYPE | undefined
): string => {
  switch (payIDTypeValue) {
    case PAYID_TYPE.PHONE:
      return 'beneficiary.phone';
    case PAYID_TYPE.EMAIL:
      return 'beneficiary.email';
    case PAYID_TYPE.ABN_ACN:
      return 'beneficiary.abnAcn';
    case PAYID_TYPE.ORGANISATION_ID:
      return 'beneficiary.organisationId';
    default:
      return 'Unknown';
  }
};

export const nameLikedFieldsValidationRules: RegisterOptions = {
  validate: (value: string) =>
    !validateWithLibrary(value) ||
    `${forbiddenCharacterErrorMessage} ${getFormattedForbiddenCharacters()}`,
};

export type validationResultType = boolean | string | Promise<boolean | string>;
export type validationFunction = (value: string) => validationResultType;

export function validatePhone(value: string): validationResultType {
  if (!value) {
    return ERROR_MESSAGES.PHONE;
  }
  const [, number] = value.split('-');
  if (number.length < 2) {
    return ERROR_MESSAGES.PHONE;
  }
  return true;
}

export function validateEmail(value: string): validationResultType {
  if (!value || value.length < 5) {
    return ERROR_MESSAGES.EMAIL_REQUIRED;
  }
  const sanitisationResult = (
    nameLikedFieldsValidationRules.validate as validationFunction
  )(value);
  if (typeof sanitisationResult === 'string') {
    return sanitisationResult;
  }
  return (
    REGEX_PATTERN.EMAIL_FORMAT.test(value) ||
    ERROR_MESSAGES.EMAIL_INVALID_FORMAT
  );
}

export function validateAbnAcn(value: string): validationResultType {
  if (!value || value.length < 9 || value.length > 11) {
    return ERROR_MESSAGES.ABN;
  }
  return true;
}

export function validateOrganisationId(value: string): validationResultType {
  if (!value || value.length < 2) {
    return ERROR_MESSAGES.ORGANISATION_REQUIRED;
  }
  return (nameLikedFieldsValidationRules.validate as validationFunction)(value);
}

export function validateField(fieldName: string, value: string) {
  switch (fieldName) {
    case 'phone':
      return validatePhone(value);
    case 'email':
      return validateEmail(value);
    case 'abnAcn':
      return validateAbnAcn(value);
    case 'organisationId':
      return validateOrganisationId(value);
    default:
      return undefined;
  }
}

export function payIdLookupErrorMessage(errorMessage: string | undefined) {
  if (
    errorMessage &&
    [
      ERROR_MESSAGES.PAYID_SERVICE_UNAVAILABLE,
      ERROR_MESSAGES.PAYID_CHECK_LIMIT_EXCEEDED,
      ERROR_MESSAGES.INVALID_PAYID,
      ERROR_MESSAGES.PHONE,
      ERROR_MESSAGES.EMAIL_REQUIRED,
      ERROR_MESSAGES.ABN_ACN,
      ERROR_MESSAGES.ORGANISATION_ID,
    ].includes(errorMessage)
  ) {
    return errorMessage;
  }
  return undefined;
}

export function payIdBSBLookupErrorMessage(errorMessage?: string | boolean) {
  if (
    typeof errorMessage === 'string' &&
    [
      ERROR_MESSAGES.PAYID_SERVICE_UNAVAILABLE,
      ERROR_MESSAGES.PAYID_CHECK_LIMIT_EXCEEDED,
      ERROR_MESSAGES.INVALID_PAYID,
      ERROR_MESSAGES.PHONE,
      ERROR_MESSAGES.EMAIL_REQUIRED,
      ERROR_MESSAGES.EMAIL_INVALID_FORMAT,
      ERROR_MESSAGES.ABN_ACN,
      ERROR_MESSAGES.ORGANISATION_ID,
      ERROR_MESSAGES.BSB_NOT_RECOGNISED,
      ERROR_MESSAGES.BSB_SERVICE_UNAVAILABLE,
    ].includes(errorMessage)
  ) {
    return errorMessage;
  }
  return true;
}
