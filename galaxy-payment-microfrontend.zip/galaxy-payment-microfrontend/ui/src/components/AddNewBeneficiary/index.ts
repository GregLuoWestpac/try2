export { AddNewBeneficiaryButton } from './AddNewBeneficiaryButton';
export { BeneficiaryForm } from './BeneficiaryForm';
