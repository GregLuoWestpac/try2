import {
  MVCopAccountNameCheck,
  COPCheckResultData,
} from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
import { isStaffPortal } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { Grid, GridItem } from '@westpac/ui';
import React from 'react';

export type CopResultsSectionProps = {
  isCopLimitExceeded: boolean;
  shouldShowCopResults: boolean;
  isCopLoading: boolean;
  isCopError: boolean;
  copCheckResultData?: COPCheckResultData;
  showCheckDetailsAlert: boolean;
};

/**
 * Renders CoP (Confirmation of Payee) result messages based on the current validation state.
 * Handles session/daily limit exceeded, API errors, successful results, and
 * "user did not select check details" alerts. Hidden for staff portal users.
 */
export function CopResultsSection({
  isCopLimitExceeded,
  shouldShowCopResults,
  isCopLoading,
  isCopError,
  copCheckResultData,
  showCheckDetailsAlert,
}: CopResultsSectionProps) {
  // ACX: Hide all CoP results for staff users
  if (isStaffPortal()) {
    return null;
  }

  return (
    <>
      {/* AC3: Session/daily limit exceeded error message */}
      {isCopLimitExceeded && shouldShowCopResults && !isCopLoading && (
        <Grid>
          <GridItem span={12}>
            <MVCopAccountNameCheck
              customStatus="SESSION_OR_DAILY_LIMIT_REACHED"
              className="mb-2.5"
            />
          </GridItem>
        </Grid>
      )}
      {/* AC1/AC2 (Error): API 4xx/5xx errors */}
      {isCopError &&
        !copCheckResultData &&
        !isCopLimitExceeded &&
        shouldShowCopResults &&
        !isCopLoading && (
          <Grid>
            <GridItem span={12}>
              <MVCopAccountNameCheck
                customStatus="API_ERROR"
                className="mb-2.5"
              />
            </GridItem>
          </Grid>
        )}
      {/* CoP result data */}
      {shouldShowCopResults &&
        !isCopLoading &&
        !isCopLimitExceeded &&
        copCheckResultData && (
          <Grid>
            <GridItem span={12}>
              <MVCopAccountNameCheck
                copCheckResultData={copCheckResultData}
                className="mb-2.5"
              />
            </GridItem>
          </Grid>
        )}
      {/* Check details alert */}
      {showCheckDetailsAlert &&
        !isCopLimitExceeded &&
        !copCheckResultData &&
        !shouldShowCopResults && (
          <Grid>
            <GridItem span={12}>
              <MVCopAccountNameCheck
                customStatus="USER_DID_NOT_SELECT_CHECK_DETAILS"
                className="mb-2.5"
              />
            </GridItem>
          </Grid>
        )}
    </>
  );
}
