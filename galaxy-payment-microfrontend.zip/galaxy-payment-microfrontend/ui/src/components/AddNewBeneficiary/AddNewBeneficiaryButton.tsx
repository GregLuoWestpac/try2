import { Button } from '@westpac/ui';
import { forwardRef } from 'react';

type Props = {
  onClickNewBeneficiary: () => void;
};
export const AddNewBeneficiaryButton = forwardRef<HTMLDivElement, Props>(
  ({ onClickNewBeneficiary }, ref) => {
    return (
      <div
        className="flex flex-row items-center pl-2 gap-2"
        data-testid="add-benefiary-button"
      >
        <p className="typography-body-10 font-medium">Or</p>
        <div ref={ref}>
          <Button
            size="small"
            look="hero"
            className="text-hero"
            soft
            onClick={onClickNewBeneficiary}
          >
            New beneficiary
          </Button>
        </div>
      </div>
    );
  }
);
