import { ChannelTypeCode } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { NppPaymentMethod } from 'ui/src/common/types';
import {
  ReturnType,
  SolicitedReasonForReturn,
} from '../../containers/InitiateReturnContainer/InitiateReturnContainer.constant';
import { InitiateReturnFormDataType } from '../../containers/InitiateReturnContainer/InitiateReturnContainer.type';
import { mapPostPaymentReturnParams } from './ReturnDetails.utils';

describe('ReturnDetails.utils', () => {
  it('tests the function with mocked formData', () => {
    const mockChannelTypeCode = 'W1C_U_A_CP' as ChannelTypeCode;
    const formData: InitiateReturnFormDataType = {
      transactionId: '123',
      returnType: ReturnType.SolicitedReturn,
      solicitedReasonForReturn: SolicitedReasonForReturn.FOCR,
      fromAccountBsb: '123456',
      fromAccountNumber: '1234567890',
      fromAccountName: 'John Doe=', // Note: '=' is used to test the trimming logic - sanitiseWithLibrary
      debitDesc: 'Test data',
      toAccountBsb: '123456',
      toAccountNumber: '123456',
      toAccountName: 'Test==', // Note: '==' is used to test the trimming logic - sanitiseWithLibrary
      creditDesc: 'Test',
      reference: 'Test',
      anotherAccountFlag: 'No',
      totalAmount: '123.00',
      nppCaseId: 'TEST123456',
      additionalInfo: 'Test',
      internalCaseId: 'TESTss123456',
      payerAccountBsb: '654321',
      payerAccountNumber: '0987654321',
      payerAccountName: 'Jane Doe',
    };

    const expectedResult = {
      clientContext: {
        channelType: mockChannelTypeCode,
      },
      originalMessageIdentification: '123',
      transactionInformation: {
        returnReason: {
          reasonCode: 'FOCR',
          additionalInformation: 'Test',
          returnType: ReturnType.SolicitedReturn,
        },
        debtor: {
          issuer: '123456',
          identification: '1234567890',
          name: 'John Doe',
        },
        debitDescription: 'Test data',
        creditor: {
          issuer: '123456',
          identification: '123456',
          name: 'Test',
        },
        creditDescription: 'Test',
        paymentReference: 'Test',
        toAnotherAccount: 'No',
        returnedInterbankSettlementAmount: {
          currency: 'AUD',
          amount: '123.00',
        },
        supplementaryData: {
          ofiCaseId: 'TEST123456',
          serviceLevel: 'npp.clear.01-sct.04',
          groupCaseId: 'TESTss123456',
          paymentDetailsIdType: 'NPPID',
        },
      },
    };

    const selectedTransactionDetails: any = {
      id: 'fa37b99c-5e32-41b6-8232-724cfee50ecc',
      accountName: 'CCMP Subscription Update',
      accountId: '123456 123456789',
      narrative: 'PMNT.IDDT.PMDD',
      transactionDateTime: '2024-12-10T00:40:21.848Z',
      amount: {
        amount: '11.00',
        currencyCode: 'AUD',
        position: 'CR',
      },
      transactionId: 'NPP1614440030CUSTOMER',
      originalMessageName: 'pacs.008.001.05',
      originalMessageId: 'RSBKAU2SXXX20241210000040192218324',
      originalTransactionId: 'RSBKAU2SXXXN20241210000040192218320',
      payer: {
        name: 'James Smith',
        accountId: '092002 002113404',
      },
      debtorAccountId: ' ',
      debtorFI: 'RSBKAU2SXXX',
      beneficiary: {
        name: 'AUSTRALIAN DESIGN CONSULTANTS PTY LTD',
        accountId: '123456 123456789',
      },
      creditorAccountId: 'd2de2b93-39e4-4125-8833-638bf5fffba0',
      creditorDescription: 'Testing Pay To',
      reference: 'NOTPROVIDED',
      creditorReference: '',
      creditorFI: 'WPACAU3SXXX',
      paymentMethod: {
        code: 'npp.clear.01-sct.04',
        description: NppPaymentMethod.Osko,
      },
      receiptNumber: 'NP43457144030',
      schemeCategoryPurpose: '',
      paymentStatus: 'Processed',
      instructionId: '5edc3dcf-fa84-491e-a3b9-9e10bff4221a',
      mandateId: '2dd54fe0247511ebb074749712726516',
    };

    const result = mapPostPaymentReturnParams(
      formData,
      selectedTransactionDetails.paymentMethod,
      mockChannelTypeCode
    );
    expect(result).toEqual(expectedResult);
  });
});
