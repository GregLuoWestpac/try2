import {
  getFormattedForbiddenCharacters,
  validateWithLibrary,
} from '@mesh-tenant-multiverse-ui-common/mv-injection-checker';
import { RegisterOptions } from 'react-hook-form';
import { forbiddenCharacterErrorMessage } from '../../common/constants';

export const DESCRIPTION_VALIDATION_RULES: RegisterOptions = {
  validate: (value: string) =>
    !validateWithLibrary(value) ||
    `${forbiddenCharacterErrorMessage} ${getFormattedForbiddenCharacters()}`,
};
