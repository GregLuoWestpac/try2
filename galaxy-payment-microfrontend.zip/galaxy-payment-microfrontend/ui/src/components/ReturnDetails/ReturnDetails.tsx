/* eslint-disable import/no-unresolved */
import {
  useClose,
  useIsCompositeDesktop,
  useIsDesktopVersion,
  useIsWebVersion,
} from '@mesh-tenant-multiverse-common/react';
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import {
  ChannelTypeCode,
  useGetChannelTypeCode,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import {
  Alert,
  Button,
  Field,
  Grid,
  GridItem,
  Heading,
  Select,
  Selector,
  SelectorHint,
  SelectorLabel,
  SelectorRadio,
} from '@westpac/ui';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Controller, SubmitHandler, useForm } from 'react-hook-form';
import { v4 as uuid } from 'uuid';
import { SchemeEligibility } from '../../common/types';
import {
  determinePaymentMethodFromServiceLevel,
  updateDefaultFormData,
} from '../../containers/InitiateReturnContainer/InitiateReturnContainer';
import {
  defaultCancellationCodeData,
  defaultReturnTypesData,
  defaultSolicitedReasonForReturnData,
  defaultUnSolicitedReasonForReturnData,
  ReturnType,
  SolicitedReasonForReturn,
} from '../../containers/InitiateReturnContainer/InitiateReturnContainer.constant';
import {
  InitiateReturnFormDataType,
  paymentMethodObject,
  TransactionDetails,
} from '../../containers/InitiateReturnContainer/InitiateReturnContainer.type';
import { defaultPaymentMethodData } from '../../containers/MakePaymentContainer/common';
import {
  fetchSchemeEligibilitiesParams,
  PostPaymentReturnsOptionsPayload,
  PostPaymentReturnsParamsPayload,
} from '../../store/types';
import { OriginalTransaction } from './OriginalTransaction';
import { OtherDetailsSection } from './OtherDetailsSection';
import { PaymentDetailOption } from './OtherDetailsSection/OtherDetailsSection';
import { mapPostPaymentReturnParams } from './ReturnDetails.utils';
import { ToAccountSection } from './ToAccountSection';

export type ReturnDetailsProps = {
  initiateReturnFormData: InitiateReturnFormDataType;
  handleReturnFormDataChange: (formatData: InitiateReturnFormDataType) => void;
  renderInitiateReturnComponents: (navigateTo: string) => void;
  initiateReturn: (
    params: PostPaymentReturnsParamsPayload,
    options: PostPaymentReturnsOptionsPayload
  ) => void;
  clearReturn: () => void;
  isPaymentReturnsFetching: boolean;
  isPaymentReturnsError: boolean;
  paymentReturnApiStatus?: number;
  selectedTransactionDetails: TransactionDetails;
  fetchSchemeEligibilities?: (params: fetchSchemeEligibilitiesParams) => void;
  schemeEligibilities: SchemeEligibility[];
  isSchemeEligibilitiesFetching: boolean;
  isSchemeEligibilitiesError: boolean;
  schemeEligibilitiesStatusCode: number;
  orgCISKey: string;
};

function ReturnDetails({
  initiateReturnFormData,
  handleReturnFormDataChange,
  renderInitiateReturnComponents,
  initiateReturn,
  clearReturn,
  isPaymentReturnsFetching,
  isPaymentReturnsError,
  paymentReturnApiStatus,
  selectedTransactionDetails,
  isSchemeEligibilitiesFetching,
  fetchSchemeEligibilities = () => {},
  isSchemeEligibilitiesError,
  schemeEligibilities,
  schemeEligibilitiesStatusCode,
  orgCISKey, 
}: ReturnDetailsProps) {
  const {
    control,
    handleSubmit,
    trigger,
    formState: { errors },
    formState,
    watch,
    reset,
    clearErrors,
    getValues,
    setError,
    setValue,
  } = useForm<InitiateReturnFormDataType>({
    defaultValues: { ...initiateReturnFormData },
    mode: 'onChange',
  });

  const [idempotencyKey, setIdempotencyKey] = useState('');
  const [isPaymenReturnSubmitted, setPaymentReturnSubmitted] = useState(false);
  const [isDifferentPaymentMethod, setIsDifferentPaymentMethod] =
    useState(false);
  const [isTransferToAnotherAccount, setIsTransferToAnotherAccount] =
    useState(false);
  const [paymentDetailOptions, setPaymentDetailOptions] = useState<
    PaymentDetailOption[]
  >(defaultPaymentMethodData);
  const channelTypeCode: ChannelTypeCode = useGetChannelTypeCode({
    useIsDesktopVersion,
    useIsWebVersion,
    useIsCompositeDesktop,
  });

  useEffect(() => {
    const returnPaymentID = uuid();
    setIdempotencyKey(returnPaymentID);
    // Clear the previous return and errors on load
    clearReturn();
    clearErrors();
  }, []);

  useEffect(() => {
    if (isPaymentReturnsError) {
      window.scrollTo(0, 0);
    }
  }, [isPaymentReturnsError]);

  const updateTransferToAnotherAccountStatus = (status: boolean) => {
    clearErrors();
    setIsTransferToAnotherAccount(status);
  };

  const handleReturnSubmit = (
    formData: InitiateReturnFormDataType,
    paymentMethod: paymentMethodObject = {}
  ) => {
    initiateReturn(
      {
        params: mapPostPaymentReturnParams(
          formData,
          paymentMethod,
          channelTypeCode,
          orgCISKey
        ),
      },
      {
        headers: {
          'x-idempotency-key': idempotencyKey,
        },
      }
    );
    setPaymentReturnSubmitted(true);
  };

  const onSubmit: SubmitHandler<InitiateReturnFormDataType> = (data) => {
    const formattedData: InitiateReturnFormDataType = {
      ...data,
      totalAmount: data.totalAmount && parseFloat(data.totalAmount).toFixed(2),
      anotherAccountFlag: isTransferToAnotherAccount ? 'Yes' : 'No',
      toAccountBsb:
        data.toAccountBsb ||
        selectedTransactionDetails.payer?.accountId.split(' ')[0],
      toAccountNumber:
        data.toAccountNumber ||
        selectedTransactionDetails.payer?.accountId.split(' ')[1],
      toAccountName:
        data.toAccountName || selectedTransactionDetails.payer?.name,
    };
    handleReturnFormDataChange(formattedData);
    handleReturnSubmit(
      formattedData,
      selectedTransactionDetails?.paymentMethod
    );
  };

  useEffect(() => {
    if (
      isPaymenReturnSubmitted &&
      !isPaymentReturnsFetching &&
      paymentReturnApiStatus
    ) {
      renderInitiateReturnComponents('return-confirmation');
    }
  }, [isPaymentReturnsFetching]);

  const watchReturnType = watch('returnType');
  const watchToAccountBSB = watch('toAccountBsb');

  const correctToAccountBsb = useMemo(() => {
    return isTransferToAnotherAccount
      ? getValues('toAccountBsb')
      : getValues('payerAccountBsb') || '';
  }, [
    watchToAccountBSB,
    getValues('payerAccountBsb'),
    isTransferToAnotherAccount,
  ]);

  const isBsbValid = useMemo(() => {
    return correctToAccountBsb.length === 6;
  }, [correctToAccountBsb]);

  useEffect(() => {
    if (!isBsbValid) {
      setPaymentDetailOptions([{ label: 'Select', name: '', id: '' }]);
      setValue('paymentMethod', '');
    }
  }, [isBsbValid]);

  const inferPaymentOptions = () => {
    if (!isBsbValid) return;
    fetchSchemeEligibilities({
      creditorAccount: {
        issuer: correctToAccountBsb,
        schemeName: 'BBAN',
      },
      debtorAccount: {
        issuer: getValues('fromAccountBsb'),
        schemeName: 'BBAN',
      },
      returnAllSchemes: !isTransferToAnotherAccount,
    });
  };

  useEffect(() => {
    if (watchReturnType !== ReturnType.SelectOne && isBsbValid) {
      inferPaymentOptions();
    }
  }, [watchReturnType]);

  useEffect(() => {
    if (!isTransferToAnotherAccount) {
      inferPaymentOptions();
    }
  }, [isTransferToAnotherAccount]);

  useEffect(() => {
    try {
      let paymentOptions: PaymentDetailOption[] = [
        { label: 'Select', name: '', id: '' },
      ];

      if (schemeEligibilities?.length) {
        const originalPaymentMethod = determinePaymentMethodFromServiceLevel(
          selectedTransactionDetails.paymentMethod
        );
        const originalPaymentCode =
          selectedTransactionDetails?.paymentMethod?.code;
        let schemeEligibility:
          | { code: string; description: string }
          | undefined = schemeEligibilities[0].paymentMethod;

        if (!isTransferToAnotherAccount) {
          schemeEligibility = schemeEligibilities.find(
            (scheme: SchemeEligibility) => {
              if (
                scheme.paymentMethod.code === undefined &&
                originalPaymentCode === undefined
              ) {
                return true;
              }
              return (
                scheme.paymentMethod.description === originalPaymentMethod &&
                scheme.paymentMethod.code !== undefined &&
                originalPaymentCode !== undefined
              );
            }
          )?.paymentMethod;
          if (schemeEligibility === undefined) {
            setIsDifferentPaymentMethod(true);
            schemeEligibility = schemeEligibilities[0].paymentMethod;
          }
        }

        paymentOptions = [
          {
            id: '0',
            label: schemeEligibility.description,
            name: schemeEligibility.code,
          },
        ];
      }
      setValue('paymentMethod', paymentOptions[0].name || 'On-Platform');
      setPaymentDetailOptions(paymentOptions);
      clearErrors('paymentMethod');
    } catch (error) {
      setPaymentDetailOptions([
        { label: 'Error loading payment methods', name: '', id: '' },
      ]);
    }
  }, [schemeEligibilities]);

  const returnReasonErrorMessage: string = useMemo(
    () => errors.unSolicitedReasonForReturn?.message ?? '',
    [formState]
  );
  const cancellationCodeErrorMessage: string = useMemo(
    () => errors.cancellationCode?.message ?? '',
    [formState]
  );

  const { closeTab } = useClose();

  const handleClose = useCallback(async () => {
    await closeTab();
  }, [closeTab]);

  return (
    <MVCard title="Return details" template="narrow">
      {isPaymentReturnsError && (
        <Alert iconSize="small" look="danger">
          Something went wrong. Please try again.
        </Alert>
      )}
      <form autoComplete="off" onSubmit={handleSubmit(onSubmit)}>
        <Grid className="flex flex-col !gap-0">
          <GridItem className="pb-5 mb-2.5 grid-item">
            <OriginalTransaction
              transactionDetails={selectedTransactionDetails}
            />
            <Heading tag="h2" size={7} className="mt-2.5 mb-2  text-heading">
              Return details
            </Heading>
            <Controller
              name="returnType"
              control={control}
              rules={{ required: 'Select a return type.' }}
              render={({ field: { value, onChange, ...rest } }) => (
                <div className="grid grid-cols-12">
                  <div className="col-span-7">
                    <Field
                      id="return-type"
                      label="Return type"
                      errorMessage={errors.returnType?.message ?? ''}
                    >
                      <Select
                        value={value}
                        width="full"
                        size="small"
                        onChange={(
                          newValue: React.ChangeEvent<HTMLSelectElement>
                        ) => {
                          const defaultData = updateDefaultFormData(
                            selectedTransactionDetails
                          );
                          reset({
                            ...defaultData,
                            returnType: newValue.target.value as any,
                          });
                          onChange(newValue);
                        }}
                        {...rest}
                      >
                        {defaultReturnTypesData.map((option) => (
                          <option key={option.label} value={option.value}>
                            {option.label}
                          </option>
                        ))}
                      </Select>
                    </Field>
                  </div>
                </div>
              )}
            />
            {watchReturnType === 'Unsolicited return' && (
              <Controller
                name="unSolicitedReasonForReturn"
                control={control}
                rules={{ required: 'Select a reason for return.' }}
                render={({ field: { value, onChange, ...rest } }) => (
                  <div className="grid grid-cols-12">
                    <div className="col-span-7">
                      <Field
                        id="return-reason"
                        label="Return reason"
                        errorMessage={returnReasonErrorMessage}
                        className="mt-5"
                      >
                        <Select
                          value={value}
                          width="full"
                          size="small"
                          invalid={returnReasonErrorMessage !== ''}
                          onChange={(
                            newValue: React.ChangeEvent<HTMLSelectElement>
                          ) => {
                            onChange(newValue);
                          }}
                          {...rest}
                        >
                          {defaultUnSolicitedReasonForReturnData.map(
                            (option) => (
                              <option key={option.label} value={option.value}>
                                {option.label}
                              </option>
                            )
                          )}
                        </Select>
                      </Field>
                    </div>
                  </div>
                )}
              />
            )}
            {watchReturnType === 'Solicited return' && (
              <>
                <Controller
                  name="solicitedReasonForReturn"
                  control={control}
                  rules={{ required: 'Select a reason for return.' }}
                  defaultValue={
                    defaultSolicitedReasonForReturnData.find(
                      (item) => item.value === 'FOCR'
                    )?.value as SolicitedReasonForReturn | undefined
                  }
                  render={({ field: { value, onChange, ...rest } }) => (
                    <div className="grid grid-cols-12">
                      <div className="col-span-7">
                        <Field
                          id="return-reason"
                          label="Return reason"
                          errorMessage={
                            errors.solicitedReasonForReturn?.message ?? ''
                          }
                          className="mt-5"
                        >
                          <Select
                            value={value}
                            width="full"
                            size="small"
                            onChange={(
                              newValue: React.ChangeEvent<HTMLSelectElement>
                            ) => {
                              onChange(newValue);
                            }}
                            {...rest}
                          >
                            {defaultSolicitedReasonForReturnData.map(
                              (option) => (
                                <option key={option.label} value={option.value}>
                                  {option.label}
                                </option>
                              )
                            )}
                          </Select>
                        </Field>
                      </div>
                    </div>
                  )}
                />
                <Controller
                  name="cancellationCode"
                  control={control}
                  rules={{ required: 'Select a cancellation code.' }}
                  render={({ field: { value, onChange, ...rest } }) => (
                    <div className="grid grid-cols-12">
                      <div className="col-span-7">
                        <Field
                          id="cancellation-code"
                          label="Cancellation code"
                          errorMessage={cancellationCodeErrorMessage}
                          className="mt-5"
                        >
                          <Select
                            value={value}
                            width="full"
                            size="small"
                            invalid={cancellationCodeErrorMessage !== ''}
                            onChange={(
                              newValue: React.ChangeEvent<HTMLSelectElement>
                            ) => {
                              onChange(newValue);
                            }}
                            {...rest}
                          >
                            {defaultCancellationCodeData.map((option) => (
                              <option key={option.label} value={option.value}>
                                {option.label}
                              </option>
                            ))}
                          </Select>
                        </Field>
                      </div>
                    </div>
                  )}
                />
              </>
            )}
          </GridItem>
          {watchReturnType !== undefined && watchReturnType && (
            <>
              <GridItem className="mb-2.5 grid-item">
                <Heading tag="h2" size={7} className="text-heading">
                  From
                </Heading>
                <Heading
                  tag="h3"
                  size={9}
                  className="mt-2.5 mb-2  text-heading"
                >
                  Debit account
                </Heading>
                <Selector
                  id="selector_fromSame"
                  type="radio"
                  value="from-account-details"
                  className="w-1/2"
                >
                  <SelectorRadio
                    key="from-account-details"
                    value="from-account-details"
                  >
                    <SelectorLabel>
                      {selectedTransactionDetails.beneficiary.name}
                    </SelectorLabel>
                    <SelectorHint className="max-sm:typography-body-10 sm:typography-body-9">
                      {selectedTransactionDetails.beneficiary.accountId}
                    </SelectorHint>
                  </SelectorRadio>
                </Selector>
              </GridItem>
              <GridItem className="mb-2.5 grid-item">
                <Heading tag="h2" size={7} className=" text-heading">
                  To
                </Heading>
                <Heading tag="h3" size={9} className="mt-2 mb-2 text-heading">
                  Credit account
                </Heading>
                <ToAccountSection
                  watchReturnType={watchReturnType}
                  control={control}
                  errors={errors}
                  payerDetails={selectedTransactionDetails.payer}
                  bsbFieldName="toAccountBsb"
                  onBsbBlur={inferPaymentOptions}
                  accountNumberFieldName="toAccountNumber"
                  accountNameFieldName="toAccountName"
                  updateTransferToAnotherAccountStatus={
                    updateTransferToAnotherAccountStatus
                  }
                  schemeEligibilitiesStatusCode={schemeEligibilitiesStatusCode}
                  isSchemeEligibilitiesFetching={isSchemeEligibilitiesFetching}
                  clearErrors={clearErrors}
                  setError={setError}
                />
              </GridItem>
              <GridItem className="mb-2.5 grid-item">
                <Heading tag="h2" size={7} className="mb-2 text-heading">
                  Other details
                </Heading>
                <OtherDetailsSection
                  watchReturnType={watchReturnType}
                  control={control}
                  errors={errors}
                  transactionDetails={selectedTransactionDetails}
                  isTransferToAnotherAccount={isTransferToAnotherAccount}
                  paymentMethodData={paymentDetailOptions}
                  trigger={trigger}
                  inferPaymentOptions={inferPaymentOptions}
                  isSchemeEligibilitiesFetching={isSchemeEligibilitiesFetching}
                  schemeEligibilitiesStatusCode={schemeEligibilitiesStatusCode}
                  isSchemeEligibilitiesError={isSchemeEligibilitiesError}
                  isDifferentPaymentMethod={isDifferentPaymentMethod}
                />
              </GridItem>
            </>
          )}
          <div className="flex gap-3">
            <Button look="primary">Send for authorisation</Button>
            <Button look="hero" soft type="button" onClick={handleClose}>
              Cancel
            </Button>
          </div>
        </Grid>
      </form>
    </MVCard>
  );
}

export default ReturnDetails;
