import { fireEvent, render, screen } from '@testing-library/react';
import React, { act } from 'react';
import { Simulate } from 'react-dom/test-utils';

import { ChannelTypeCode } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { determinePaymentMethodFromServiceLevel } from '../../containers/InitiateReturnContainer/InitiateReturnContainer';
import {
  NppPaymentMethod,
  TransactionDirection,
} from '../../containers/InitiateReturnContainer/InitiateReturnContainer.constant';
import {
  InitiateReturnFormDataType,
  TransactionDetails,
} from '../../containers/InitiateReturnContainer/InitiateReturnContainer.type';
import ReturnDetails, { type ReturnDetailsProps } from './ReturnDetails';

const mockChannelTypeCode = 'W1C_U_A_CP' as ChannelTypeCode;

const defaultReturnFormData: InitiateReturnFormDataType = {
  transactionId: '',
  returnType: undefined,
  solicitedReasonForReturn: undefined,
  unSolicitedReasonForReturn: undefined,
  fromAccountBsb: '',
  fromAccountNumber: '',
  fromAccountName: '',
  debitDesc: '',
  toAccountBsb: '',
  toAccountNumber: '',
  toAccountName: '',
  reference: '',
  creditDesc: '',
  anotherAccountFlag: 'No',
  totalAmount: '',
  nppCaseId: '',
  additionalInfo: '',
  paymentMethod: undefined,
  internalCaseId: '',
};

const selectedTransaction: TransactionDetails = {
  accountId: '000123 7098112345',
  accountName: 'CCMP Subscription Update',
  amount: {
    amount: '100000.0',
    currencyCode: 'AUD',
    position: 'CR',
  },
  beneficiary: {
    accountId: '000845 7091234',
    name: 'Durga',
  },
  creditorAccountId: ' ',
  creditorDescription: 'NikitaDM',
  creditorFI: 'WPACAU3SXXX',
  creditorReference: '',
  debtorAccountId: ' ',
  debtorFI: 'CTBAAUSNXXX',
  id: '8e7c9d85-8410-4326-833a-e050cb77b404',
  narrative:
    'Deposit-Fast Payment NP33101234567 Orange LTD Tech Like ðŸ¥³ðŸŽ‰æ–°å¹´å¿«ä¹ $1,456.00 OR OTHER CHRS E2EId123456789012345678901234567890',
  originalMessageId: 'CTBAAUSNXXX20240619000001158103279',
  originalMessageName: 'pacs.008.001.05',
  originalTransactionId: 'CTBAAUSNXXXN02406190000011891799329',
  payer: {
    accountId: '000102 3123456',
    name: 'Tania England',
  },
  paymentMethod: {
    code: 'npp.clear.01-x2p1.04',
    description: NppPaymentMethod.Osko,
  },
  paymentStatus: 'Processed',
  reference: 'PAGFISPOC',
  schemeCategoryPurpose: 'OTHR',
  transactionCode: 'PMNT.RRCT.DMCT_FIS_NPP_TRF',
  transactionDateTime: '2024-06-19T08:16:30.041Z',
  transactionId: 'NPP230000124CUSTOMER',
  type: TransactionDirection.Credit,
};

const defaultProps: ReturnDetailsProps = {
  initiateReturnFormData: defaultReturnFormData,
  handleReturnFormDataChange: jest.fn(),
  renderInitiateReturnComponents: jest.fn(),
  initiateReturn: jest.fn(),
  clearReturn: jest.fn(),
  isPaymentReturnsFetching: false,
  isPaymentReturnsError: false,
  apiStatus: 201,
  selectedTransactionDetails: selectedTransaction,
};

const mockGlobalDispatch = jest.fn();

jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: function MockComponent({ children }: { children: React.ReactNode }) {
    return <div>{children}</div>;
  },
}));
jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  useGetChannelTypeCode: jest.fn(() => mockChannelTypeCode),
  ChannelTypeCode: {
    W1C_U_A_CP: 'W1C_U_A_CP',
  },
  isStaffPortal: jest.fn(() => false),
  getFormattedDateTime: jest.fn(() => '19 Jun 2024, 6:16pm AEST  '),
}));

jest.mock('@mep-ui/framework', () => ({
  ssoActions: {
    sso: {
      signout: {
        request: jest.fn(),
      },
    },
  },
  useGlobalDispatch: () => mockGlobalDispatch,
  useGlobalSelector: () => {
    ({
      accountId: '000123 7098112345',
      accountName: 'CCMP Subscription Update',
      amount: {
        amount: '100000.0',
        currencyCode: 'AUD',
        position: 'CR',
      },
      beneficiary: {
        accountId: '000845 7091234',
        name: 'Durga',
      },
      creditorAccountId: ' ',
      creditorDescription: 'NikitaDM',
      creditorFI: 'WPACAU3SXXX',
      creditorReference: '',
      debtorAccountId: ' ',
      debtorFI: 'CTBAAUSNXXX',
      id: '8e7c9d85-8410-4326-833a-e050cb77b404',
      narrative:
        'Deposit-Fast Payment NP33101234567 Orange LTD Tech Like ðŸ¥³ðŸŽ‰æ–°å¹´å¿«ä¹ $1,456.00 OR OTHER CHRS E2EId123456789012345678901234567890',
      originalMessageId: 'CTBAAUSNXXX20240619000001158103279',
      originalMessageName: 'pacs.008.001.05',
      originalTransactionId: 'CTBAAUSNXXXN02406190000011891799329',
      payer: {
        accountId: '000102 3123456',
        name: 'Tania England',
      },
      paymentMethod: {
        code: 'npp.clear.01-x2p1.04',
        description: 'Osko',
      },
      paymentStatus: 'Processed',
      reference: 'PAGFISPOC',
      schemeCategoryPurpose: 'OTHR',
      transactionCode: 'PMNT.RRCT.DMCT_FIS_NPP_TRF',
      transactionDateTime: '2024-06-19T08:16:30.041Z',
      transactionId: 'NPP230000124CUSTOMER',
      type: 'Credit',
    });
  },
}));

jest.mock('../../store/store', () => ({
  __esModule: true,
  default: {
    dispatch: jest.fn(),
  },
}));

const mockCloseTab = jest.fn();

jest.mock('@mesh-tenant-multiverse-common/react', () => {
  return {
    useClose: () => ({
      closeTab: mockCloseTab,
    }),
  };
});

jest.mock(
  '../../containers/InitiateReturnContainer/InitiateReturnContainer',
  () => ({
    determinePaymentMethodFromServiceLevel: jest.fn(() => 'Osko'),
    updateDefaultFormData: jest.fn(),
  })
);

describe('ReturnDetails', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should match snapshot', () => {
    const { container } = render(<ReturnDetails {...defaultProps} />);
    expect(container).toMatchSnapshot();
  });

  it('should render the form correctly for Return to same account scenario', () => {
    const { getByText } = render(<ReturnDetails {...defaultProps} />);
    expect(getByText('Original transaction')).toBeInTheDocument();
    expect(getByText('Transaction ID')).toBeInTheDocument();
    expect(
      getByText('CTBAAUSNXXXN02406190000011891799329')
    ).toBeInTheDocument();
    expect(getByText('Solicited return')).toBeInTheDocument();
    expect(getByText('UnSolicited return')).toBeInTheDocument();
    expect(getByText('Send for authorisation')).toBeInTheDocument();
    expect(getByText('Cancel')).toBeInTheDocument();
  });

  it('should show alert when there is a payment return error', () => {
    Object.defineProperty(window, 'scrollTo', { value: jest.fn() });
    const { getByText } = render(
      <ReturnDetails {...defaultProps} isPaymentReturnsError />
    );
    expect(
      getByText('Something went wrong. Please try again.')
    ).toBeInTheDocument();
  });

  it('return reason options populated based on selected solicited return return type', () => {
    const { container, queryByText, getByLabelText } = render(
      <ReturnDetails {...defaultProps} />
    );
    const selectElement = container.querySelector('select');
    act(() => {
      Simulate.change(selectElement, {
        target: { value: 'Solicited return' },
      });
    });
    const returnReason = getByLabelText('Return reason');
    act(() => {
      Simulate.change(returnReason, {
        target: { value: 'FOCR' },
      });
    });
    expect(queryByText('Select a reason for return.')).not.toBeInTheDocument();
  });

  it('Should return Osko when original transaction is Osko and all schemes are eligible', () => {
    const paymentMethods = [
      {
        paymentMethod: {
          description: 'Fast Payment',
        },
      },
      {
        paymentMethod: {
          description: 'Osko',
          code: 'npp.clear.01-x2p1.04',
        },
      },
      {
        paymentMethod: {
          description: 'Fast Payment',
          code: 'npp.clear.01-sct.04',
        },
      },
    ];

    (determinePaymentMethodFromServiceLevel as jest.Mock).mockReturnValue(
      'Osko'
    );

    const { container, getByLabelText, getByRole } = render(
      <ReturnDetails {...defaultProps} schemeEligibilities={paymentMethods} />
    );
    const selectElement = container.querySelector('select');
    act(() => {
      Simulate.change(selectElement, {
        target: { value: 'Solicited return' },
      });
    });
    const returnReason = getByLabelText('Return reason');
    act(() => {
      Simulate.change(returnReason, {
        target: { value: 'FOCR' },
      });
    });
    expect(determinePaymentMethodFromServiceLevel).toHaveBeenCalled();
    expect(getByRole('combobox', { name: 'Payment method' })).toHaveTextContent(
      'Osko'
    );
  });

  it('Should return On Platform when original transaction is On Platform and all schemes are eligible', () => {
    const paymentMethods = [
      {
        paymentMethod: {
          description: 'Fast Payment',
        },
      },
      {
        paymentMethod: {
          description: 'Osko',
          code: 'npp.clear.01-x2p1.04',
        },
      },
      {
        paymentMethod: {
          description: 'Fast Payment',
          code: 'npp.clear.01-sct.04',
        },
      },
    ];

    (determinePaymentMethodFromServiceLevel as jest.Mock).mockReturnValue(
      'On Platform'
    );

    const { container, getByLabelText, getByRole } = render(
      <ReturnDetails {...defaultProps} schemeEligibilities={paymentMethods} />
    );
    const selectElement = container.querySelector('select');
    act(() => {
      Simulate.change(selectElement, {
        target: { value: 'Solicited return' },
      });
    });
    const returnReason = getByLabelText('Return reason');
    act(() => {
      Simulate.change(returnReason, {
        target: { value: 'FOCR' },
      });
    });
    expect(determinePaymentMethodFromServiceLevel).toHaveBeenCalled();
    expect(getByRole('combobox', { name: 'Payment method' })).toHaveTextContent(
      'On Platform'
    );
  });

  it('Should return On Platform when original transaction is fast payment and all schemes are eligible except for fast payment', () => {
    const paymentMethods = [
      {
        paymentMethod: {
          description: 'Fast Payment',
        },
      },
      {
        paymentMethod: {
          description: 'Osko',
          code: 'npp.clear.01-x2p1.04',
        },
      },
    ];

    (determinePaymentMethodFromServiceLevel as jest.Mock).mockReturnValue(
      'Fast Payment'
    );

    const { container, getByLabelText, getByRole } = render(
      <ReturnDetails {...defaultProps} schemeEligibilities={paymentMethods} />
    );
    const selectElement = container.querySelector('select');
    act(() => {
      Simulate.change(selectElement, {
        target: { value: 'Solicited return' },
      });
    });
    const returnReason = getByLabelText('Return reason');
    act(() => {
      Simulate.change(returnReason, {
        target: { value: 'FOCR' },
      });
    });
    expect(determinePaymentMethodFromServiceLevel).toHaveBeenCalled();
    expect(getByRole('combobox', { name: 'Payment method' })).toHaveTextContent(
      'On Platform'
    );
  });

  it('Should return Osko when original transaction is On Platform and all schemes are eligible except on platform', () => {
    const paymentMethods = [
      {
        paymentMethod: {
          description: 'Osko',
          code: 'npp.clear.01-x2p1.04',
        },
      },
      {
        paymentMethod: {
          description: 'Fast Payment',
          code: 'npp.clear.01-sct.04',
        },
      },
    ];

    (determinePaymentMethodFromServiceLevel as jest.Mock).mockReturnValue(
      'On Platform'
    );

    const { container, getByLabelText, getByRole } = render(
      <ReturnDetails {...defaultProps} schemeEligibilities={paymentMethods} />
    );
    const selectElement = container.querySelector('select');
    act(() => {
      Simulate.change(selectElement, {
        target: { value: 'Solicited return' },
      });
    });
    const returnReason = getByLabelText('Return reason');
    expect(determinePaymentMethodFromServiceLevel).toHaveBeenCalled();
    expect(getByRole('combobox', { name: 'Payment method' })).toHaveTextContent(
      'Osko'
    );
  });

  it('return reason options populated based on selected usolicited return return type', () => {
    const { container, getByText, getByLabelText } = render(
      <ReturnDetails {...defaultProps} />
    );
    const selectElement = container.querySelector('select');
    act(() => {
      Simulate.change(selectElement, {
        target: { value: 'Unsolicited return' },
      });
    });

    const returnReason = getByLabelText('Return reason');
    act(() => {
      Simulate.change(returnReason, {
        target: { value: 'AC04 - Closed Account Number' },
      });
    });
    expect(getByText('AC04 - Closed Account Number')).toBeInTheDocument();
  });

  it('should trigger closeTab when cancel button is clicked', () => {
    render(<ReturnDetails {...defaultProps} />);
    fireEvent.click(screen.getByText('Cancel'));
    expect(mockCloseTab).toHaveBeenCalled();
  });

  it('Should return Osko when Osko is original transaction and availible, should not show alert indicating that an alternative method is used', () => {
    const paymentMethods = [
      {
        paymentMethod: {
          description: 'Fast Payment',
        },
      },
      {
        paymentMethod: {
          description: 'Osko',
          code: 'npp.clear.01-x2p1.04',
        },
      },
    ];
    const originalTransaction = {
      ...selectedTransaction,
      paymentMethod: {
        description: 'Osko',
        code: 'npp.clear.01-x2p1.04',
      },
    };

    (determinePaymentMethodFromServiceLevel as jest.Mock).mockReturnValue(
      'Osko'
    );

    const { container, getByLabelText, getByRole, queryByText } = render(
      <ReturnDetails
        {...defaultProps}
        schemeEligibilities={paymentMethods}
        selectedTransactionDetails={originalTransaction}
      />
    );
    const selectElement = container.querySelector('select');
    act(() => {
      Simulate.change(selectElement, {
        target: { value: 'Solicited return' },
      });
    });
    const returnReason = getByLabelText('Return reason');
    expect(determinePaymentMethodFromServiceLevel).toHaveBeenCalled();
    expect(getByRole('combobox', { name: 'Payment method' })).toHaveTextContent(
      'Osko'
    );
    expect(
      queryByText(
        'This payment method is different from the one used for the original transaction'
      )
    ).not.toBeInTheDocument();
  });
  it('Should return On Platform when Osko is original transaction and not availible, should show alert indicating that an alternative method is used', () => {
    const paymentMethods = [
      {
        paymentMethod: {
          description: 'Fast Payment',
        },
      },
    ];
    const originalTransaction = {
      ...selectedTransaction,
      paymentMethod: {
        description: 'Osko',
        code: 'npp.clear.01-x2p1.04',
      },
    };

    (determinePaymentMethodFromServiceLevel as jest.Mock).mockReturnValue(
      'Osko'
    );

    const { container, getByLabelText, getByRole, queryByText } = render(
      <ReturnDetails
        {...defaultProps}
        schemeEligibilities={paymentMethods}
        selectedTransactionDetails={originalTransaction}
      />
    );
    const selectElement = container.querySelector('select');
    act(() => {
      Simulate.change(selectElement, {
        target: { value: 'Solicited return' },
      });
    });
    const returnReason = getByLabelText('Return reason');
    expect(determinePaymentMethodFromServiceLevel).toHaveBeenCalled();
    expect(getByRole('combobox', { name: 'Payment method' })).toHaveTextContent(
      'On Platform'
    );
    expect(
      queryByText(
        'This payment method is different from the one used for the original transaction'
      )
    ).toBeInTheDocument();
  });

  it('Should return On Platform when Fast Payment is original transaction and not availible, should show alert indicating that an alternative method is used', () => {
    const paymentMethods = [
      {
        paymentMethod: {
          description: 'Fast Payment',
        },
      },
    ];
    const originalTransaction = {
      ...selectedTransaction,
      paymentMethod: {
        description: 'Fast Payment',
        code: 'npp.clear.01-sct.04',
      },
    };

    (determinePaymentMethodFromServiceLevel as jest.Mock).mockReturnValue(
      'On Platform'
    );

    const { container, getByLabelText, getByRole, queryByText } = render(
      <ReturnDetails
        {...defaultProps}
        schemeEligibilities={paymentMethods}
        selectedTransactionDetails={originalTransaction}
      />
    );
    const selectElement = container.querySelector('select');
    act(() => {
      Simulate.change(selectElement, {
        target: { value: 'Solicited return' },
      });
    });
    const returnReason = getByLabelText('Return reason');
    expect(determinePaymentMethodFromServiceLevel).toHaveBeenCalled();
    expect(getByRole('combobox', { name: 'Payment method' })).toHaveTextContent(
      'On Platform'
    );
    expect(
      queryByText(
        'This payment method is different from the one used for the original transaction'
      )
    ).toBeInTheDocument();
  });

  it('Should return Fast Payment when On Platform is original transaction and not availible, should show alert indicating that an alternative method is used', () => {
    const paymentMethods = [
      {
        paymentMethod: {
          description: 'Fast Payment',
          code: 'npp.clear.01-sct.04',
        },
      },
    ];
    const originalTransaction = {
      ...selectedTransaction,
      paymentMethod: {
        description: 'Fast Payment',
      },
    };

    (determinePaymentMethodFromServiceLevel as jest.Mock).mockReturnValue(
      'On Platform'
    );

    const { container, getByLabelText, getByRole, queryByText } = render(
      <ReturnDetails
        {...defaultProps}
        schemeEligibilities={paymentMethods}
        selectedTransactionDetails={originalTransaction}
      />
    );
    const selectElement = container.querySelector('select');
    act(() => {
      Simulate.change(selectElement, {
        target: { value: 'Solicited return' },
      });
    });
    const returnReason = getByLabelText('Return reason');
    expect(determinePaymentMethodFromServiceLevel).toHaveBeenCalled();
    expect(getByRole('combobox', { name: 'Payment method' })).toHaveTextContent(
      'Fast Payment'
    );
    expect(
      queryByText(
        'This payment method is different from the one used for the original transaction'
      )
    ).toBeInTheDocument();
  });
  it('Should return Fast Payment (SCT) when Fast Payment CATSCT is original transaction and not availible, should not show alert indicating that an alternative method is used', () => {
    const paymentMethods = [
      {
        paymentMethod: {
          description: 'Fast Payment',
        },
      },
      {
        paymentMethod: {
          description: 'Fast Payment',
          code: 'npp.clear.01-sct.04',
        },
      },
    ];
    const originalTransaction = {
      ...selectedTransaction,
      paymentMethod: {
        description: 'Fast Payment',
        code: 'npp.clear.01-catsct.01',
      },
    };

    (determinePaymentMethodFromServiceLevel as jest.Mock).mockReturnValue(
      'Fast Payment'
    );

    const { container, getByLabelText, getByRole, queryByText } = render(
      <ReturnDetails
        {...defaultProps}
        schemeEligibilities={paymentMethods}
        selectedTransactionDetails={originalTransaction}
      />
    );
    const selectElement = container.querySelector('select');
    act(() => {
      Simulate.change(selectElement, {
        target: { value: 'Solicited return' },
      });
    });
    const returnReason = getByLabelText('Return reason');
    expect(determinePaymentMethodFromServiceLevel).toHaveBeenCalled();
    expect(getByRole('combobox', { name: 'Payment method' })).toHaveTextContent(
      'Fast Payment'
    );
    expect(
      queryByText(
        'This payment method is different from the one used for the original transaction'
      )
    ).not.toBeInTheDocument();
  });
  it('Should return On Platform when on platform is original transaction and is availible, should not show alert indicating that an alternative method is used', () => {
    const paymentMethods = [
      {
        paymentMethod: {
          description: 'Fast Payment',
        },
      },
    ];
    const originalTransaction = {
      ...selectedTransaction,
      paymentMethod: {
        description: 'Fast Payment',
      },
    };

    (determinePaymentMethodFromServiceLevel as jest.Mock).mockReturnValue(
      'On Platform'
    );

    const { container, getByLabelText, getByRole, queryByText } = render(
      <ReturnDetails
        {...defaultProps}
        schemeEligibilities={paymentMethods}
        selectedTransactionDetails={originalTransaction}
      />
    );
    const selectElement = container.querySelector('select');
    act(() => {
      Simulate.change(selectElement, {
        target: { value: 'Solicited return' },
      });
    });
    const returnReason = getByLabelText('Return reason');
    expect(determinePaymentMethodFromServiceLevel).toHaveBeenCalled();
    expect(getByRole('combobox', { name: 'Payment method' })).toHaveTextContent(
      'On Platform'
    );
    expect(
      queryByText(
        'This payment method is different from the one used for the original transaction'
      )
    ).not.toBeInTheDocument();
  });
});
