import { sanitiseWithLibrary } from '@mesh-tenant-multiverse-ui-common/mv-injection-checker';
import {
  ACCOUNT_NAME_MAX_LENGTH,
  ChannelTypeCode,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';

import {
  Currency,
  ReasonCode,
  paymentDetailsIdType,
} from '../../common/constants';
import { NppPaymentMethod } from '../../common/types';
import { getCreditorServiceLevel } from '../../common/utils';
import {
  InitiateReturnFormDataType,
  paymentMethodObject,
} from '../../containers/InitiateReturnContainer/InitiateReturnContainer.type';
import { PostPaymentReturnsParams } from '../../store/types';

export const mapPostPaymentReturnParams = (
  formData: InitiateReturnFormDataType,
  paymentMethod: paymentMethodObject,
  channelTypeCode: ChannelTypeCode,
  orgCisKey: string
): PostPaymentReturnsParams => {
  const reasonCode = formData.unSolicitedReasonForReturn
    ? formData.unSolicitedReasonForReturn.slice(0, 4)
    : ReasonCode.FOCR;
  return {
    clientContext: {
      channelType: channelTypeCode,
      orgCisKey,
    },
    originalMessageIdentification: formData.transactionId,
    transactionInformation: {
      returnReason: {
        reasonCode,
        additionalInformation: formData.additionalInfo,
        cancellationCode: formData?.cancellationCode,
        returnType: formData.returnType,
      },
      debtor: {
        issuer: formData.fromAccountBsb,
        identification: formData.fromAccountNumber,
        name: sanitiseWithLibrary(
          formData.fromAccountName,
          ACCOUNT_NAME_MAX_LENGTH
        ),
      },
      debitDescription: formData.debitDesc,
      creditor: {
        issuer: formData.toAccountBsb,
        identification: formData.toAccountNumber,
        name: sanitiseWithLibrary(
          formData.toAccountName,
          ACCOUNT_NAME_MAX_LENGTH
        ),
      },
      creditDescription: formData.creditDesc,
      paymentReference: formData.reference,
      toAnotherAccount: formData.anotherAccountFlag,
      returnedInterbankSettlementAmount: {
        currency: Currency.AUD,
        amount: formData.totalAmount,
      },
      supplementaryData: {
        ofiCaseId: formData.nppCaseId,
        paymentDetailsIdType: paymentMethod.code
          ? paymentDetailsIdType.NPPID
          : paymentDetailsIdType.PMTID,
        serviceLevel:
          formData.anotherAccountFlag === 'No'
            ? paymentMethod.code
            : getCreditorServiceLevel(
                formData.paymentMethod as NppPaymentMethod
              ),
        groupCaseId: formData.internalCaseId,
      },
    },
  };
};
