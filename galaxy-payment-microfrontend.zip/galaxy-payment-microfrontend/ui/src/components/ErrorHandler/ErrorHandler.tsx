import { Alert, Link } from '@westpac/ui';

export type ErrorHandlerPropType = {
  onRefresh: () => void;
  errorMessage: string;
  className?: string;
};

export default function ErrorHandler({
  onRefresh,
  errorMessage,
  className = '',
}: ErrorHandlerPropType) {
  return (
    <Alert
      look="danger"
      id="errorMessage"
      iconSize="small"
      className={className}
    >
      {`${errorMessage} Please `}
      <Link type="inline" onPress={onRefresh} className="cursor-pointer">
        try again
      </Link>
      .
    </Alert>
  );
}
