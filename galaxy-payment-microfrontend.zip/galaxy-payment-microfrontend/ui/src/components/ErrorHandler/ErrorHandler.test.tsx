
import { fireEvent, render, screen } from '@testing-library/react';
import { genericErrorMessage } from 'ui/src/common/constants';
import ErrorHandler from './ErrorHandler';

describe('ErrorHandler', () => {
  const mockOnRefresh = jest.fn();
  it('renders the error message', () => {
    const { getByText } = render(
      <ErrorHandler
        onRefresh={mockOnRefresh}
        errorMessage={genericErrorMessage}
      />,
    );
    const errorMessage = getByText((content, element) => {
      return content.includes(genericErrorMessage);
    });
    expect(errorMessage).toBeInTheDocument();
  });

  it('renders the try again link', () => {
    render(
      <ErrorHandler
        onRefresh={mockOnRefresh}
        errorMessage={genericErrorMessage}
      />,
    );
    const linkElement = screen.getByText('try again');
    expect(linkElement).toBeInTheDocument();
    fireEvent.click(linkElement);
    expect(mockOnRefresh).toHaveBeenCalled();
  });
});
