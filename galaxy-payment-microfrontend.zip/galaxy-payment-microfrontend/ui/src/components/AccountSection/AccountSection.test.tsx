import { render, renderHook, screen, fireEvent } from '@testing-library/react';
import React from 'react';
import { useForm } from 'react-hook-form';
import AccountSection from './AccountSection';
import { MakePaymentFormDataType } from '../../common/types';

const { result } = renderHook(() => useForm());
const mockControl = result.current.control;

const defaultProps = {
  title: 'From',
  fieldId: 'fromAccount',
  fieldName: 'fromAccount',
  accountSelectorLabel: 'From account',
  accountSelectorHintText: 'Select an account',
  descriptionLabel: 'Debit description',
  descriptionFieldName: 'debitDescription',
  control: mockControl,
  errors: {},
  autoFocus: true,
  listOptions: [],
  trigger: jest.fn(),
};

jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  MVInputController: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div>{children}</div>;
  },

  MVCurrencyController: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div>{children}</div>;
  },

  MVAutocompleteController: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div>{children}</div>;
  },

  getToday: jest.fn(() => ({
    minus: jest.fn(() => ({
      toFormat: jest.fn(() => '09/03/2025'),
    })),
    toFormat: jest.fn(() => '09/03/2025'),
  })),
  getTodayAtLastYear: jest.fn(() => ({
    toFormat: jest.fn(() => '09/03/2024'),
  })),
}));

describe('Testing AccountSection', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should match snapshot', () => {
    const { container } = render(<AccountSection {...defaultProps} />);
    expect(container).toMatchSnapshot();
  });

  it('should display the copy switch', () => {
    const { container } = render(
      <AccountSection {...defaultProps} copySwitchLabel="same as debit" />
    );
    expect(screen.getByText('same as debit')).toBeInTheDocument;
  });

  it('should display the New beneficiary button', () => {
    const { rerender } = render(
      <AccountSection {...defaultProps} showBeneficiaryForm />
    );
    expect(screen.getByText('New beneficiary')).toBeInTheDocument();
    rerender(<AccountSection {...defaultProps} showBeneficiaryForm={false} />);
    expect(screen.queryByText('New beneficiary')).not.toBeInTheDocument();
  });
});

jest.mock('../AddNewBeneficiary', () => ({
  // Preserve label text used by component
  AddNewBeneficiaryButton: ({
    onClickNewBeneficiary,
  }: {
    onClickNewBeneficiary: () => void;
  }) => (
    <button
      type="button"
      data-testid="add-new-bene"
      onClick={onClickNewBeneficiary}
    >
      New beneficiary
    </button>
  ),
  BeneficiaryForm: () => <div data-testid="beneficiary-form" />,
}));

jest.mock('./components/MVCollapsiblePanel', () => ({
  MVCollapsiblePanel: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="bene-panel">{children}</div>
  ),
}));

jest.mock('./components/VerifyingPayID', () => ({
  VerifyingPayID: () => <div data-testid="verifying-payid">Verifying</div>,
}));

jest.mock('./components/PayIDAlert', () => ({
  PayIDAlert: () => <div data-testid="payid-alert">PayID mismatch</div>,
}));

jest.mock('./components/AdditionalDetailsForBeneficiary', () => ({
  AdditionalDetailsForBeneficiary: ({
    item,
  }: {
    item: { account?: { payIDName?: string }; accountName?: string };
  }) => (
    <div data-testid="additional-details">
      Details {item.account?.payIDName || item.accountName}
    </div>
  ),
}));

describe('AccountSection new behaviours', () => {
  it('opens beneficiary panel when New beneficiary clicked and clears selection', () => {
    const TestComponent = () => {
      const onChangeAccount = jest.fn();
      const form = useForm<MakePaymentFormDataType>({
        defaultValues: { beneficiary: undefined },
      });
      return (
        <AccountSection
          {...defaultProps}
          fieldName="fromAccount"
          descriptionFieldName="fromDescription"
          showBeneficiaryForm
          onChangeAccount={onChangeAccount}
          form={form}
          control={form.control}
          trigger={form.trigger}
        />
      );
    };

    render(<TestComponent />);
    fireEvent.click(screen.getByTestId('add-new-bene'));
    // Panel + form always rendered when enableAddBeneficiary & form supplied
    expect(screen.getByTestId('bene-panel')).toBeInTheDocument();
    expect(screen.getByTestId('beneficiary-form')).toBeInTheDocument();
  });
  it('renders verifying state for PayID when aliasLookupStatus="fetching"', () => {
    const payIDValue = { type: 'PAYID', account: { payIDName: 'Alice' } };
    render(
      <AccountSection
        {...defaultProps}
        fieldValue={payIDValue}
        aliasLookupStatus="fetching"
      />
    );
    expect(screen.getByTestId('verifying-payid')).toBeInTheDocument();
  });

  it('renders PayIDAlert and additional details when aliasLookupStatus="warning" with mismatch', () => {
    const payIDValue = { type: 'PAYID', account: { payIDName: 'Bob' } };
    render(
      <AccountSection
        {...defaultProps}
        fieldValue={payIDValue}
        aliasLookupStatus="warning"
        lookupMismatch={{ beneficiaryName: 'Bob', aliasLookupName: 'Robert' }}
      />
    );
    expect(screen.getByTestId('payid-alert')).toBeInTheDocument();
    expect(screen.getByTestId('additional-details')).toBeInTheDocument();
  });

  it('renders additional details for PayID when aliasLookupStatus="verified"', () => {
    const payIDValue = { type: 'PAYID', account: { payIDName: 'Carol' } };
    render(
      <AccountSection
        {...defaultProps}
        fieldValue={payIDValue}
        aliasLookupStatus="verified"
      />
    );
    expect(screen.getByTestId('additional-details')).toBeInTheDocument();
  });

  it('renders additional details for non-PayID beneficiary (e.g. BSB) without aliasLookupStatus', () => {
    const bsbValue = { type: 'BSB_ACCOUNT_NUMBER', accountName: 'Jane' };
    render(<AccountSection {...defaultProps} fieldValue={bsbValue} />);
    expect(screen.getByTestId('additional-details')).toBeInTheDocument();
  });

  it('displays account balances when an account is selected in the From section', () => {
    const mockAllArrangementDetails =
    {
      // From Arrangement type (all required):
      id: '1',
      accountNumber: '035845 175743115469',
      entityName: 'Test Entity',
      accountName: 'Test Account',
      accountType: 'TRANSACTION',
      currencyCode: 'AUD',
      currentBalance: '5500.00',
      availableBalance: '5000.00',
      overdraftLimit: '0.00',

      // From ArrangementDetails type (all required):
      accountId: '035845 175743115469',
      openedDateTime: '2024-01-01T00:00:00Z',
      closedDateTime: '',
      accountLinks: [],
      debitRateWithinLimit: {
        interestRate: 0.05,
        fixedVariableType: 'VARIABLE',
        calculationMethod: 'FLAT' as const,
      },
      debitRateAboveLimit: {
        interestRate: 0.15,
        fixedVariableType: 'VARIABLE',
        calculationMethod: 'FLAT' as const,
      },
      debitRateAboveLimitOverride: {
        interestRate: 0.10,
        fixedVariableType: 'VARIABLE',
        calculationMethod: 'FLAT' as const,
      },
      creditRate: {
        interestRate: 0.02,
        fixedVariableType: 'VARIABLE',
        calculationMethod: 'FLAT' as const,
      },
    };

    const TestComponent = () => {
      const form = useForm<MakePaymentFormDataType>({
        defaultValues: {
          fromAccount: {
            accountId: '035845 175743115469',
            accountName: 'Test Account',
          }
        },
      });
      return (
        <AccountSection
          {...defaultProps}
          title="From"
          fieldName="fromAccount"
          control={form.control}
          descriptionFieldName='fromDescription'
          allArrangementDetails={mockAllArrangementDetails}
        />
      );
    };

    const { container } = render(<TestComponent />);

    const balanceContainer = container.querySelector('#account-balance-info');
    expect(balanceContainer).toBeInTheDocument();
    expect(screen.getByText(/Available:/)).toBeInTheDocument();
    expect(screen.getByText(/Current:/)).toBeInTheDocument();
    expect(screen.getByText(/AUD 5,000.00/)).toBeInTheDocument();
    expect(screen.getByText(/AUD 5,500.00/)).toBeInTheDocument();
  });

  it('does not display account balances when no account is selected in the From section', () => {
    const TestComponent = () => {
      const form = useForm<MakePaymentFormDataType>({
        defaultValues: {
          fromAccount: null,
        },
      });
      return (
        <AccountSection
          {...defaultProps}
          title="From"
          fieldName="fromAccount"
          descriptionFieldName='fromDescription'
          control={form.control}
        />
      );
    };

    render(<TestComponent />);

    expect(screen.queryByTestId('account-balance-info')).not.toBeInTheDocument();
  });
});
