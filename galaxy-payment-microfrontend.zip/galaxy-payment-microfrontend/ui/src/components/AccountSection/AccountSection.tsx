/* eslint-disable no-use-before-define */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unnecessary-type-assertion */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/ban-ts-comment */
import {
  AutocompleteId,
  AutocompleteWrapperRef,
  MVInputController,
} from '@mesh-tenant-multiverse-ui-common/mv-reacthookform';
import {
  Control,
  FieldValues,
  Path,
  RegisterOptions,
  UseFormReturn,
  UseFormTrigger,
  useWatch,
} from 'react-hook-form';
// eslint-disable-next-line import/no-unresolved
import { COPCheckResultData } from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
import { Grid, GridItem, Heading } from '@westpac/ui';
import cloneDeep from 'lodash/cloneDeep';
import { useCallback, useEffect, useMemo, useRef } from 'react';
import {
  AliasLookupStatus,
  Beneficiary,
  BeneTypes,
  LookupMismatch,
  MakePaymentFormDataType,
} from '../../common/types';
import { formatCurrencyValue } from '../../containers/PaymentTaskDetailsContainer/PaymentTaskDetailsCard/PaymentTaskDetailsCard.utils';
import { ItemDetailsForAccountNumber } from '../../galaxy-common/components/ItemDetailsForAccountNumber';
import {
  filterFnForAccountNumber,
  filterFnForBeneficiary,
  inputValueFnForAccountNumber,
  inputValueFnForBeneficiary,
} from '../../galaxy-common/utils/autocomplete.utils';
import {
  Account,
  ArrangementDetails,
  GetBSBLookupParamsPayload,
  PostAliasLookupParamsPayload,
} from '../../store/types';
import { PostAliasLookup } from '../../store/types/AliasLookup';
import { Branch } from '../../store/types/BsbLookup';
import { AddNewBeneficiaryButton, BeneficiaryForm } from '../AddNewBeneficiary';
import { MVAutocompleteAsyncController } from '../try/MVAutocompleteAsyncController';
import { CopySwitch } from './_';
import { AdditionalDetailsForBeneficiary } from './components/AdditionalDetailsForBeneficiary';
import { ItemDetailsForBeneficiary } from './components/ItemDetailsForBeneficiary';
import { MVCollapsiblePanel } from './components/MVCollapsiblePanel';
import { MVCollapsiblePanelHandle } from './components/MVCollapsiblePanel/MVCollapsiblePanel';
import { PayIDAlert } from './components/PayIDAlert';
import { VerifyingPayID } from './components/VerifyingPayID';

type AccountSectionProps<T extends FieldValues> = {
  title: string;
  fieldId: string;
  fieldName: Path<T>;
  fieldValue?: any;
  accountSelectorLabel: string;
  accountSelectorHintText: string;
  noAccountMessage?: string;
  descriptionLabel: string;
  copySwitchLabel?: string;
  referenceFieldName?: Path<T>;
  referenceLabel?: string;
  referenceHintText?: string;
  referenceValidationRules?: RegisterOptions;
  descriptionFieldName: Path<T>;
  control: Control<T>;
  trigger: UseFormTrigger<T>;
  additionalErr?: string;
  lookupMismatch?: LookupMismatch;
  handleSwitchChange?: (isSelected: boolean) => void;
  sameAsDebit?: boolean;
  descriptionInputType?: string;
  descriptionValidationRules?: RegisterOptions;
  textAreaHintText?: string;
  listOptions: Account[] | Beneficiary[];
  onChangeAccount?: (paymentAccount: any) => void;
  aliasLookupStatus?: AliasLookupStatus;
  aliasLookupName?: string;
  postAliasLookup?: (params: PostAliasLookupParamsPayload) => void;
  aliasLookupData?: PostAliasLookup[];
  doesAliasIdContainInvalidData?: boolean;
  isPayIdNotValid?: boolean;
  isPayIdLimitExceeded?: boolean;
  isPayIdServiceNotAvailable?: boolean;
  isAliasLookupFetching?: boolean;
  isAliasLookupError?: boolean;
  getBsbLookup?: (params: GetBSBLookupParamsPayload) => void;
  bsbLookupData?: Branch[];
  isBsbLookupFetching?: boolean;
  isBsbLookupError?: boolean;
  bsbLookupErrorStatusCode?: number;
  hideAdditionalFields?: boolean;
  showBeneficiaryForm?: boolean;
  form?: UseFormReturn<MakePaymentFormDataType>;
  isBeneficiaryFormOpen?: boolean;
  setIsBeneficiaryFormOpen?: React.Dispatch<React.SetStateAction<boolean>>;
  panelRef?: React.RefObject<MVCollapsiblePanelHandle>;
  setIsNewBeneficiaryBsbLookupTriggered?: (value: boolean) => void;
  setIsNewBeneficiaryPayIdLookupTriggered?: (value: boolean) => void;
  resetLookup?: () => void;
  enableSaveBeneficiary?: boolean;
  lookupState?: React.MutableRefObject<{
    triggeredByReview: boolean;
    fieldName: string | null;
  }>;
  isFormSubmitting?: React.MutableRefObject<boolean>;
  postArrangementDetails?: (params: any) => void;
  allArrangementDetails?: ArrangementDetails;
  onAccountValidationChange?: (isValidated: boolean) => void;
  // CoP component props
  isCopLoading?: boolean;
  isCopError?: boolean;
  copCheckResultData?: COPCheckResultData;
  shouldShowCopResults?: boolean;
  onInvalidateCopCheck?: () => void;
  isCopLimitExceeded?: boolean;
  postAccountNameCheck?: (params: {
    accountName: string;
    accountNumber: string;
    bsb: string;
  }) => void;
  fetchDataFn: (input?: string) => void;
  loadingState: boolean;
  hasErrorWhenFetchingData: boolean;
};

function AccountSection<T extends FieldValues>({
  title,
  fieldId,
  fieldName,
  fieldValue,
  accountSelectorHintText,
  accountSelectorLabel,
  copySwitchLabel,
  sameAsDebit,
  handleSwitchChange,
  noAccountMessage,
  descriptionLabel,
  referenceFieldName,
  referenceLabel = '',
  referenceHintText = '',
  referenceValidationRules,
  descriptionFieldName,
  descriptionValidationRules,
  control,
  trigger,
  additionalErr,
  lookupMismatch,
  listOptions,
  descriptionInputType = '',
  textAreaHintText,
  onChangeAccount,
  aliasLookupStatus,
  aliasLookupName,
  postAliasLookup,
  aliasLookupData,
  doesAliasIdContainInvalidData,
  isPayIdNotValid,
  isPayIdLimitExceeded,
  isPayIdServiceNotAvailable,
  isAliasLookupFetching,
  isAliasLookupError,
  getBsbLookup,
  bsbLookupData,
  isBsbLookupFetching,
  isBsbLookupError,
  bsbLookupErrorStatusCode,
  hideAdditionalFields,
  showBeneficiaryForm = false,
  enableSaveBeneficiary = true,
  form,
  isBeneficiaryFormOpen,
  setIsBeneficiaryFormOpen,
  panelRef,
  setIsNewBeneficiaryBsbLookupTriggered,
  setIsNewBeneficiaryPayIdLookupTriggered,
  resetLookup,
  lookupState,
  isFormSubmitting,
  postArrangementDetails,
  allArrangementDetails,
  onAccountValidationChange,
  isCopLoading,
  isCopError,
  copCheckResultData,
  shouldShowCopResults,
  onInvalidateCopCheck,
  isCopLimitExceeded,
  postAccountNameCheck,
  fetchDataFn,
  loadingState,
  hasErrorWhenFetchingData,
}: AccountSectionProps<T>) {
  const isPayID = fieldValue?.type === BeneTypes.PAYID;

  const noValueMessage = noAccountMessage ?? 'Select an account from the list.';

  const rules = useMemo(
    () => ({
      validate: (value: any) => {
        if (additionalErr) return additionalErr;
        if (!isBeneficiaryFormOpen) {
          return !!value || noValueMessage;
        }
      },
    }),
    [additionalErr, noValueMessage, isBeneficiaryFormOpen]
  );

  let ItemDetails: ({ item }: { item: any }) => React.ReactNode;
  let inputValueFnInner: <K extends AutocompleteId>(item: K) => string;
  let filterFnInner: <K extends AutocompleteId>(
    item: K,
    input: string
  ) => boolean;

  if (title === 'From' || fieldId === 'toAccount-transfer') {
    ItemDetails = ItemDetailsForAccountNumber;
    inputValueFnInner = inputValueFnForAccountNumber;
    filterFnInner = filterFnForAccountNumber;
  } else {
    ItemDetails = ItemDetailsForBeneficiary;
    inputValueFnInner = inputValueFnForBeneficiary;
    filterFnInner = filterFnForBeneficiary;
  }

  const inputValueFn = useCallback(inputValueFnInner, []);
  const filterFn = useCallback(filterFnInner, []);

  const sortedListOptions = useMemo(
    () =>
      [...listOptions].sort((a, b) =>
        (
          ((a as any).accountName || (a as any).nickname || '') as string
        ).localeCompare(
          ((b as any).accountName || (b as any).nickname || '') as string
        )
      ),
    [listOptions]
  );
  const autocompleteRef = useRef<AutocompleteWrapperRef>(null);
  const triggerRef = useRef(null);

  const newFieldValue = cloneDeep(fieldValue);
  if (aliasLookupName && isPayID) {
    newFieldValue.account.payIDName = aliasLookupName;
  }

  // To get balance, get arrangement details from store for fromAccount
  const selectedAccount = useWatch({
    control,
    name: fieldName,
  }) as Account | null;

  useEffect(() => {
    if (title === 'From' && selectedAccount?.accountId) {
      const [bsb = '', accountNumber = ''] =
        selectedAccount.accountId.split(' ');
      const payload = {
        meta: {
          replaceEntities: ['arrangementDetails'],
        },
        params: {
          accountIds: [
            {
              BSB: bsb,
              accountNumber: accountNumber,
            },
          ],
        },
      };
      postArrangementDetails?.(payload);
    }
  }, [selectedAccount?.accountId]);

  const handleOnChange = useCallback(
    (e: any) => {
      if (onChangeAccount) {
        onChangeAccount(e); // Call with null/undefined when clearing
      }
      // Always trigger validation, regardless of whether selecting or clearing
      trigger(fieldName).catch(() => {
        // Ignore validation errors in onChange handler - form will show errors elsewhere
      });
      panelRef?.current?.close();
      form?.reset({
        ...form?.getValues(),
        beneficiary: null,
      });
      setIsBeneficiaryFormOpen?.(false);
    },
    [
      onChangeAccount,
      trigger,
      fieldName,
      panelRef,
      form,
      setIsBeneficiaryFormOpen,
    ]
  );

  return (
    <GridItem className="border-b-solid border-b border-b-border pt-2.5 ">
      <Heading className="text-heading mb-2.5" tag="h2" size={7}>
        {title}
      </Heading>
      <Grid className=" items-end xsl:gap-0 sm:gap-0 gap-y-0 mb-2.5">
        <GridItem span={showBeneficiaryForm ? 8 : 12}>
          {/* <MVAutocompleteController
            ref={autocompleteRef}
            fieldName={fieldName}
            control={control}
            validationRules={rules}
            allItems={sortedListOptions as AutocompleteId[]}
            label={accountSelectorLabel}
            hintMessage={accountSelectorHintText}
            ItemDetails={ItemDetails}
            inputValueFn={inputValueFn}
            filterFn={filterFn}
            onChange={handleOnChange}
          /> */}
          <MVAutocompleteAsyncController
            ref={autocompleteRef}
            fieldName={fieldName}
            control={control as any}
            validationRules={rules}
            allItems={sortedListOptions as AutocompleteId[]}
            label={accountSelectorLabel}
            hintMessage={accountSelectorHintText}
            ItemDetails={ItemDetails}
            inputValueFn={inputValueFn}
            onChange={handleOnChange}
            fetchDataFn={fetchDataFn}
            loadingState={loadingState}
            hasErrorWhenFetchingData={hasErrorWhenFetchingData}
            errorInfoForFetchingData={
              'Unable to retrieve ' +
              (title === 'From' ? 'accounts.' : 'beneficiaries.')
            }
          />
          {/* Render balance details for From account only when an account is selected */}
          {title === 'From' &&
          allArrangementDetails &&
          selectedAccount?.accountId ? (
            <div
              className="col-span-12 -mt-1 mb-2 mt-2 flex gap-2"
              id="account-balance-info"
            >
              <p className="typography-body-11">
                <span className="text-muted">Available:</span>{' '}
                {allArrangementDetails?.currencyCode}{' '}
                {formatCurrencyValue(allArrangementDetails?.availableBalance)}
              </p>
              {' | '}
              <p className="typography-body-11">
                <span className="text-muted">Current:</span>{' '}
                {allArrangementDetails?.currencyCode}{' '}
                {formatCurrencyValue(allArrangementDetails?.currentBalance)}
              </p>
            </div>
          ) : null}
        </GridItem>

        {showBeneficiaryForm && (
          <GridItem span={4}>
            {
              <AddNewBeneficiaryButton
                ref={triggerRef}
                onClickNewBeneficiary={() => {
                  if (isBeneficiaryFormOpen) {
                    return;
                  }
                  panelRef?.current?.open();
                  setIsBeneficiaryFormOpen?.(true);
                  autocompleteRef?.current?.clear();
                  if (onChangeAccount) {
                    onChangeAccount(null); // Call with null/undefined when clearing
                  }
                }}
              />
            }
          </GridItem>
        )}
      </Grid>
      {showBeneficiaryForm && form && (
        <MVCollapsiblePanel
          triggerRef={triggerRef}
          ref={panelRef}
          shouldCloseOnClick={false}
        >
          <BeneficiaryForm
            form={form}
            enableSaveBeneficiary={enableSaveBeneficiary}
            isBeneficiaryFormOpen={isBeneficiaryFormOpen}
            postAliasLookup={postAliasLookup}
            aliasLookupData={aliasLookupData}
            isPayIdNotValid={isPayIdNotValid}
            isPayIdServiceNotAvailable={isPayIdServiceNotAvailable}
            isPayIdLimitExceeded={isPayIdLimitExceeded}
            doesAliasIdContainInvalidData={doesAliasIdContainInvalidData}
            isAliasLookupFetching={isAliasLookupFetching}
            isAliasLookupError={isAliasLookupError}
            getBsbLookup={getBsbLookup}
            bsbLookupData={bsbLookupData}
            isBsbLookupFetching={isBsbLookupFetching}
            isBsbLookupError={isBsbLookupError}
            bsbLookupErrorStatusCode={bsbLookupErrorStatusCode}
            resetLookup={resetLookup}
            setIsNewBeneficiaryBsbLookupTriggered={
              setIsNewBeneficiaryBsbLookupTriggered
            }
            setIsNewBeneficiaryPayIdLookupTriggered={
              setIsNewBeneficiaryPayIdLookupTriggered
            }
            lookupState={lookupState}
            isFormSubmitting={isFormSubmitting}
            onAccountValidationChange={onAccountValidationChange}
            isCopLoading={isCopLoading}
            isCopError={isCopError}
            copCheckResultData={copCheckResultData}
            shouldShowCopResults={shouldShowCopResults}
            onInvalidateCopCheck={onInvalidateCopCheck}
            isCopLimitExceeded={isCopLimitExceeded}
            postAccountNameCheck={postAccountNameCheck}
          />
        </MVCollapsiblePanel>
      )}
      {!isBeneficiaryFormOpen && (
        <div>
          {aliasLookupStatus === 'fetching' && <VerifyingPayID />}

          {fieldValue &&
            isPayID &&
            aliasLookupStatus === 'warning' &&
            lookupMismatch && <PayIDAlert lookupMismatch={lookupMismatch} />}

          {fieldValue &&
            isPayID &&
            aliasLookupStatus &&
            ['warning', 'verified'].includes(aliasLookupStatus) && (
              <AdditionalDetailsForBeneficiary item={newFieldValue} />
            )}

          {fieldValue && !isPayID && (
            <AdditionalDetailsForBeneficiary item={fieldValue} />
          )}

          {!hideAdditionalFields && (
            <div className="w-full !pb-0 mt-2.5">
              {referenceFieldName && (
                <MVInputController
                  hint={referenceHintText}
                  id={`${fieldId}-reference-description`}
                  label={`${referenceLabel} - Optional`}
                  fieldName={referenceFieldName}
                  control={control}
                  validationRules={referenceValidationRules}
                />
              )}
              {descriptionInputType === 'textArea' ? (
                <MVInputController
                  id={`${fieldId}-description`}
                  label={`${descriptionLabel} - Optional`}
                  fieldName={descriptionFieldName}
                  hint={textAreaHintText}
                  control={control}
                  maximumLength={280}
                  validationRules={descriptionValidationRules}
                  multiLines
                  className="mb-2.5"
                  trimOnBlur
                  trimOnPaste
                />
              ) : (
                <MVInputController
                  id={`${fieldId}-description`}
                  label={`${descriptionLabel} - Optional`}
                  fieldName={descriptionFieldName}
                  hint={referenceHintText}
                  maximumLength={35}
                  control={control}
                  className="mb-2.5"
                  validationRules={descriptionValidationRules}
                  trimOnBlur
                  trimOnPaste
                />
              )}
              <CopySwitch
                enableCopy={!!sameAsDebit}
                copySwitchLabel={copySwitchLabel}
                handleSwitchChange={handleSwitchChange}
              />
            </div>
          )}
        </div>
      )}
    </GridItem>
  );
}

export default AccountSection;
