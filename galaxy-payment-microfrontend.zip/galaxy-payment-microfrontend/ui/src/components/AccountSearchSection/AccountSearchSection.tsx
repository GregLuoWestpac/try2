/* eslint-disable @typescript-eslint/no-floating-promises */
import {
  MVAutocompleteController,
  MVDateRangePickerController,
  MVButtonGroupController,
  MVAmountRangeInputController,
} from '@mesh-tenant-multiverse-ui-common/mv-reacthookform';
import { Button, GridItem, Alert, Link } from '@westpac/ui';
import React, { SyntheticEvent } from 'react';
import {
  Control,
  FieldValues,
  Path,
  UseFormClearErrors,
  UseFormSetError,
  UseFormTrigger,
  FieldErrors,
} from 'react-hook-form';
import { SearchPaymentAccountDataType, DivisionOptionType } from '../../common/types';
import { ItemDetailsForAccountNumber } from '../../galaxy-common/components/ItemDetailsForAccountNumber';
import {
  filterFnForAccountNumber,
  inputValueFnForAccountNumber,
} from '../../galaxy-common/utils/autocomplete.utils';
import { Account } from '../../store/types';
import { MVAccordion } from '@mesh-tenant-multiverse-ui-common/mv-accordion';
import { MVSelectController } from '@mesh-tenant-multiverse-ui-common/mv-selectcontroller';
import { paymentTabValues } from '../../common/constants';
import ErrorHandler from '../ErrorHandler/ErrorHandler';

type AccountSearchSectionProps<T extends FieldValues> = {
  noAccountMessage?: string;
  control: Control<T>;
  onChangeAccount: (value: Account | null) => void;
  listOptions: Account[];
  handleSubmit: (event: SyntheticEvent<HTMLButtonElement>) => Promise<void>;
  setError: UseFormSetError<SearchPaymentAccountDataType>;
  clearErrors: UseFormClearErrors<SearchPaymentAccountDataType>;
  trigger: UseFormTrigger<T>;
  errors?: FieldErrors<T>;
  divisions: DivisionOptionType[];
  showDivisionField: boolean;
  isDivisionListFetching: boolean;
  isDivisionListError: boolean;
  onDivisionChange?: (selectedOption?: DivisionOptionType) => void;
  handleRetryDivisionList?: () => void;
  hasAccountListError?: boolean;
  handleRetryAccountList?: () => void;
};
function AccountSearchSection<T extends FieldValues>({
  noAccountMessage,
  control,
  listOptions,
  onChangeAccount,
  handleSubmit,
  setError,
  clearErrors,
  trigger,
  errors,
  divisions,
  showDivisionField,
  onDivisionChange,
  handleRetryDivisionList,
  isDivisionListError,
  hasAccountListError,
  handleRetryAccountList,
}: AccountSearchSectionProps<T>) {

  const sortedListOptions = listOptions.sort((a, b) =>
    a.accountName?.localeCompare(b.accountName)
  );
  const handleDivisionChange = (selectedOption?: DivisionOptionType) => {

    onDivisionChange?.(selectedOption);
  };

  return (
    <MVAccordion
      defaultExpanded
      onButtonClick={handleSubmit}>
      {isDivisionListError && (
        <GridItem span={12} className="col-span-12 sm:col-span-8 md:col-span-8 lg:col-span-7 -mb-5">
          <ErrorHandler
            onRefresh={handleRetryDivisionList ?? (() => { })}
            errorMessage="Unable to load filter options."
          />
        </GridItem>
      )}
      {showDivisionField && (
        <GridItem span={12} className="col-span-12 sm:col-span-8 md:col-span-8 lg:col-span-7 -mb-5">
          <MVSelectController
            control={control}
            fieldName={'division' as Path<T>}
            id="division"
            width="full"
            label="Division"
            errors={errors ?? {}}
            options={divisions}
            onChange={handleDivisionChange}
          />

        </GridItem>
      )}
      <GridItem span={12} className="col-span-12 sm:col-span-8 md:col-span-8 lg:col-span-7">
        <MVAutocompleteController
          fieldName={'fromAccount' as Path<T>}
          control={control}
          allItems={sortedListOptions}
          label="Account"
          ItemDetails={ItemDetailsForAccountNumber}
          filterFn={filterFnForAccountNumber}
          inputValueFn={inputValueFnForAccountNumber}
          placeholder='All accounts'
          hintMessage="Search for an account or leave blank to search for all."
          onChange={(e) => {
            if (onChangeAccount) {
              onChangeAccount(e);
            }
            trigger('fromAccount' as Path<T>);
          }}
        />
        {hasAccountListError && (<Alert
          iconSize='xsmall'
          look="warning" mode='text' className='-mb-4 pb-3'>
          Unable to retrieve accounts. You can select 'All accounts' or <Link type="inline" onPress={handleRetryAccountList} className="cursor-pointer">
            try again
          </Link>
        </Alert>)}
      </GridItem>
      <GridItem span={12}>
        <MVDateRangePickerController
          fieldName="dateRange"
          control={control as unknown as Control<FieldValues>}
          setError={setError}
          clearErrors={clearErrors}
          durationInDays={7}
          durationInvalidMessage="Select a date range up to 7 days."
          earliestYear={3}
          earliestInvalidMessage="Select a date range within the last 3 years."
        />
      </GridItem>
      <GridItem span={12} className="w-fit -mb-2">
        <MVButtonGroupController
          fieldName={'paymentType' as Path<T>}
          label="Payment status"
          buttons={paymentTabValues}
          control={control}
          trigger={trigger}
        />
      </GridItem>
      <GridItem span={12} className="w-fit">
        <MVAmountRangeInputController
          fieldName="amountRange"
          control={control as unknown as Control<FieldValues>}
          setError={setError}
          clearErrors={clearErrors}
        />
      </GridItem>
    </MVAccordion>
  );
}

export default AccountSearchSection;
