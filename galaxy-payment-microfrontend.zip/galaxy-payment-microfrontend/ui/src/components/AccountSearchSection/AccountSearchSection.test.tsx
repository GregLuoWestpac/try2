import { fireEvent, render, renderHook, waitFor } from '@testing-library/react';
import { useForm } from 'react-hook-form';
import AccountSearchSection from './AccountSearchSection';

const { result } = renderHook(() => useForm());
const mockControl = result.current.control;

const defaultProps = {
  fieldName: 'fromAccount',
  accountSelectorLabel: 'Account',
  noAccountMessage: '',
  control: mockControl,
  errors: {},
  autoFocus: true,
  listOptions: [],
  onChangeAccount: jest.fn(),
  handleSubmit: jest.fn().mockResolvedValue({}),
  setError: jest.fn(),
  clearErrors: jest.fn(),
  trigger: jest.fn(),
  divisions: [],
  showDivisionField: false,
  isDivisionListFetching: false,
  isDivisionListError: false,
  onDivisionChange: jest.fn(),

};

jest.mock('@mesh-tenant-multiverse-ui-common/mv-accordion', () => ({
  MVAccordion: function MockComponent({
    children,
    onButtonClick,
    defaultExpanded = true,
    loading = false,
  }: {
    children: React.ReactNode;
    onButtonClick: () => void;
    defaultExpanded?: boolean;
    loading?: boolean;
  }) {
    return (
      <div
        data-testid="mv-accordion"
        data-expanded={defaultExpanded.toString()}
        data-loading={loading.toString()}
      >
        <button
          data-testid="apply-button"
          onClick={onButtonClick}
          disabled={loading}
        >
          Apply
        </button>
        <div data-testid="accordion-content">{children}</div>
      </div>
    );
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-selectcontroller', () => ({
  MVSelectController: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div data-testid="mv-select-controller">{children}</div>;
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  MVAutocompleteController: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div data-testid="mv-autocomplete-controller">{children}</div>;
  },
  MVDateRangePickerController: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div data-testid="mv-date-range-picker-controller">{children}</div>;
  },
  MVButtonGroupController: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div data-testid="mv-button-group-controller">{children}</div>;
  },
  MVAmountRangeInputController: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div data-testid="mv-amount-range-input-controller">{children}</div>;
  },
  getToday: jest.fn(() => ({
    minus: jest.fn(() => ({
      toFormat: jest.fn(() => '09/03/2025'),
    })),
    toFormat: jest.fn(() => '09/03/2025'),
  })),
  getTodayAtLastYear: jest.fn(() => ({
    toFormat: jest.fn(() => '09/03/2024'),
  })),
}));

describe('Testing AccountSection', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  it('should call handleSubmit when button is clicked', async () => {
    const { getByText } = render(<AccountSearchSection {...defaultProps} />);
    const button = getByText('Apply');
    fireEvent.click(button);
    await waitFor(() => {
      expect(defaultProps.handleSubmit).toHaveBeenCalled();
    });
  });

  it('should match snapshot', () => {
    const { container } = render(<AccountSearchSection {...defaultProps} />);
    expect(container).toMatchSnapshot();
  });
  it('should render division field when showDivisionField is true', () => {
    const propsWithDivision = {
      ...defaultProps,
      showDivisionField: true,
      divisions: [
        { id: '1', name: 'Division 1', label: 'Division 1' },
        { id: '2', name: 'Division 2', label: 'Division 2' }
      ]
    };

    const { getByTestId } = render(<AccountSearchSection {...propsWithDivision} />);

    expect(getByTestId('mv-select-controller')).toBeInTheDocument();
  });

  it('should not render division field when showDivisionField is false', () => {
    const { queryByTestId } = render(<AccountSearchSection {...defaultProps} />);

    expect(queryByTestId('mv-select-controller')).not.toBeInTheDocument();
  });

  it('should call onDivisionChange when division selection changes', () => {
    const mockOnDivisionChange = jest.fn();
    const propsWithDivision = {
      ...defaultProps,
      showDivisionField: true,
      divisions: [
        { id: '1', name: 'Division 1', label: 'Division 1' },
        { id: '2', name: 'Division 2', label: 'Division 2' }
      ],
      onDivisionChange: mockOnDivisionChange
    };

    render(<AccountSearchSection {...propsWithDivision} />);

    // The onDivisionChange should be passed to the MVSelectController
    expect(mockOnDivisionChange).toBeDefined();
  });

  it('should render date range picker with 7 days duration validation', () => {
    const { getByTestId } = render(<AccountSearchSection {...defaultProps} />);

    expect(getByTestId('mv-date-range-picker-controller')).toBeInTheDocument();
  });

  it('should render payment status button group controller', () => {
    const { getByTestId } = render(<AccountSearchSection {...defaultProps} />);

    expect(getByTestId('mv-button-group-controller')).toBeInTheDocument();
  });

  it('should render amount range input controller', () => {
    const { getByTestId } = render(<AccountSearchSection {...defaultProps} />);

    expect(getByTestId('mv-amount-range-input-controller')).toBeInTheDocument();
  });
});
