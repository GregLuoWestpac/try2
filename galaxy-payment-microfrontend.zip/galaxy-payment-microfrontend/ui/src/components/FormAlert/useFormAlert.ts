import { useEffect, useRef } from 'react';
import { UseFormSetFocus } from 'react-hook-form';

export interface AlertContent {
  key: string;
  message: React.ReactNode;
}

export type FromAccountAndToAccountType = 'fromAccount' | 'toAccount';

export function useFormAlert(alertContent: AlertContent[]) {
  const firstAlertButtonRef = useRef<HTMLButtonElement | null>(null);
  useEffect(() => {
    if (alertContent.length > 0 && firstAlertButtonRef.current) {
      firstAlertButtonRef.current.focus();
    }
  }, [alertContent]);

  // Below is a workaround for the GEL-Next Autocomplete issue https://github.com/WestpacGEL/GEL-next/issues/1053
  // TODO: below can be removed when the above issue has been fixed
  function handleClickToSetFocus<T extends FromAccountAndToAccountType>(
    key: T,
    setFocus: UseFormSetFocus<any>
  ): void {
    setFocus(key);
  }

  function handleKeyDownToSetFocus<T extends FromAccountAndToAccountType>(
    event: React.KeyboardEvent<HTMLButtonElement>,
    key: T,
    setFocus: UseFormSetFocus<any>
  ) {
    if (event.key === 'Enter') {
      event.preventDefault();
      handleClickToSetFocus(key, setFocus);
    }
  }
  return {
    firstAlertButtonRef,
    handleKeyDownToSetFocus,
    handleClickToSetFocus,
  };
}
