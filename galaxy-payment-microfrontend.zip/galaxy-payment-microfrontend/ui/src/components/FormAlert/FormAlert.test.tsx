import { render, screen, fireEvent } from '@testing-library/react';
import { FormAlert } from './FormAlert';
import { AlertContent } from './useFormAlert';

describe('FormAlert', () => {
  const mockSetFocus = jest.fn();

  const mockAlertContent: AlertContent[] = [
    { key: 'field1', message: 'Error in field 1' },
    { key: 'field2', message: 'Error in field 2' },
  ];

  it('should render the alert with the correct number of errors', () => {
    render(<FormAlert alertContent={mockAlertContent} setFocus={mockSetFocus} />);

    expect(screen.getByText(/Please fix the 2 errors listed below/i)).toBeInTheDocument();
    expect(screen.getByText('Error in field 1')).toBeInTheDocument();
    expect(screen.getByText('Error in field 2')).toBeInTheDocument();
  });

  it('should not render anything if alertContent is empty', () => {
    render(<FormAlert alertContent={[]} setFocus={mockSetFocus} />);

    expect(screen.queryByText(/Please fix the/i)).not.toBeInTheDocument();
  });

  it('should call setFocus when a button is clicked', () => {
    render(<FormAlert alertContent={mockAlertContent} setFocus={mockSetFocus} />);

    const button = screen.getByText('Error in field 1');
    fireEvent.click(button);

    expect(mockSetFocus).toHaveBeenCalledWith('field1');
  });

  it('should call setFocus when a button is focused and keydown event occurs', () => {
    render(<FormAlert alertContent={mockAlertContent} setFocus={mockSetFocus} />);

    const button = screen.getByText('Error in field 1');
    fireEvent.keyDown(button, { key: 'Enter', code: 'Enter' });

    expect(mockSetFocus).toHaveBeenCalledWith('field1');
  });

  it('should set the first button as the ref', () => {
    const { container } = render(<FormAlert alertContent={mockAlertContent} setFocus={mockSetFocus} />);

    const firstButton = container.querySelector('button');
    expect(firstButton).toHaveFocus();
  });
});
