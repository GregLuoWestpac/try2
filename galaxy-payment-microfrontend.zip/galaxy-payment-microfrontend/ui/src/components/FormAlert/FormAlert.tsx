import { Alert } from '@westpac/ui';
import { UseFormSetFocus } from 'react-hook-form';
import {
  AlertContent,
  FromAccountAndToAccountType,
  useFormAlert,
} from './useFormAlert';

type Props = {
  alertContent: AlertContent[];
  setFocus: UseFormSetFocus<any>;
};

export function FormAlert({ alertContent, setFocus }: Props) {
  const {
    firstAlertButtonRef,
    handleKeyDownToSetFocus,
    handleClickToSetFocus,
  } = useFormAlert(alertContent);

  if (!alertContent.length) return null;

  return (
    <Alert iconSize="small" look="danger" className="mb-0">
      <strong className="mx-0.5">
        {`Please fix the ${alertContent.length} ${
          alertContent.length > 1 ? 'errors' : 'error'
        } listed below`}
      </strong>
      <ul className="mx-0.5">
        {alertContent.map(({ key, message }, index) => (
          <li key={key}>
            <button
              key={key}
              ref={index === 0 ? firstAlertButtonRef : undefined}
              className="my-1 cursor-pointer bg-transparent border-none text-left p-0 focus:focus-border-blue focus-visible:focus-visible-border-blue"
              onClick={() => {
                handleClickToSetFocus(
                  key as FromAccountAndToAccountType,
                  setFocus
                );
              }}
              onKeyDown={(event) => {
                handleKeyDownToSetFocus(
                  event,
                  key as FromAccountAndToAccountType,
                  setFocus
                );
              }}
              type="button"
            >
              {message}
            </button>
          </li>
        ))}
      </ul>
    </Alert>
  );
}
