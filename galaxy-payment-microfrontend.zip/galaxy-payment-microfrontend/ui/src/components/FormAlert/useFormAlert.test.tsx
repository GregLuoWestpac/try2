/* eslint-disable @typescript-eslint/no-unsafe-argument */
import { renderHook, act } from '@testing-library/react';
import { useFormAlert } from './useFormAlert';

describe('useFormAlert', () => {
  const mockAlertContent = [
    { key: 'field1', message: 'Error in field 1' },
    { key: 'field2', message: 'Error in field 2' },
  ];

  it('should return the correct initial values', () => {
    const { result } = renderHook(() => useFormAlert(mockAlertContent));

    expect(result.current.firstAlertButtonRef).toBeDefined();
    expect(typeof result.current.handleKeyDownToSetFocus).toBe('function');
    expect(typeof result.current.handleClickToSetFocus).toBe('function');
  });

  it('should call setFocus when handleClickToSetFocus is invoked', () => {
    const mockSetFocus = jest.fn();
    const { result } = renderHook(() => useFormAlert(mockAlertContent));

    act(() => {
      result.current.handleClickToSetFocus('field1', mockSetFocus);
    });

    expect(mockSetFocus).toHaveBeenCalledWith('field1');
  });

  it('should call setFocus when Enter key is pressed in handleKeyDownToSetFocus', () => {
    const mockSetFocus = jest.fn();
    const mockEvent = { key: 'Enter', preventDefault: jest.fn() };
    const { result } = renderHook(() => useFormAlert(mockAlertContent));

    act(() => {
      result.current.handleKeyDownToSetFocus(mockEvent as any, 'field1', mockSetFocus);
    });

    expect(mockSetFocus).toHaveBeenCalledWith('field1');
    expect(mockEvent.preventDefault).toHaveBeenCalled();
  });

  it('should not call setFocus for other keys in handleKeyDownToSetFocus', () => {
    const mockSetFocus = jest.fn();
    const mockEvent = { key: 'Tab', preventDefault: jest.fn() };
    const { result } = renderHook(() => useFormAlert(mockAlertContent));

    act(() => {
      result.current.handleKeyDownToSetFocus(mockEvent as any, 'field1', mockSetFocus);
    });

    expect(mockSetFocus).not.toHaveBeenCalled();
    expect(mockEvent.preventDefault).not.toHaveBeenCalled();
  });
});
