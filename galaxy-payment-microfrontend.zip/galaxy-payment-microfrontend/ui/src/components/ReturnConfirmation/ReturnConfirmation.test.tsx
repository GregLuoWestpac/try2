import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import {
  formatCurrencyString,
  getFormattedDateTime,
  useHandleRaiseIntent,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { useGlobalDispatch } from '@mep-ui/framework';
import { useNavigate } from '@mep-ui/framework-router-addon';
import ReturnConfirmation, { ReturnConfirmationProps } from './ReturnConfirmation';
import {
  INTENT_NAMES,
  INTENTS_CONTEXT_NAME,
  PAGE_NAVIGATION,
  BannerStyle,
  StatusCode,
  RejectReason,
  SENT_FOR_AUTHORISATION_STATUS_CODE,
  UNAUTHORISED_STATUS_CODE,
  ServiceLevel,
} from '../../common/constants';
import {
  InitiateReturnFormDataType,
  TransactionDetails,
} from '../../containers/InitiateReturnContainer/InitiateReturnContainer.type';
import { TransactionDirection } from '../../containers/InitiateReturnContainer/InitiateReturnContainer.constant';
import { PaymentReturnResponse } from '../../store/types/PaymentReturn';

const mockHandleRaiseIntent = jest.fn();
const mockDispatch = jest.fn();
const mockNavigate = jest.fn();

jest.mock('@mep-ui/framework', () => ({
  useGlobalDispatch: jest.fn(),
  useGlobalSelector: jest.fn(), 
}));

jest.mock('@mep-ui/framework-router-addon', () => ({
  useNavigate: jest.fn(),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-utils'),
  formatCurrencyString: jest.fn(),
  getFormattedDateTime: jest.fn(),
  useHandleRaiseIntent: jest.fn(),
  isStaffPortal: jest.fn(() => true), 
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div data-testid="mv-card">
      <h1>{title}</h1>
      {children}
    </div>
  ),
}));

jest.mock('../../galaxy-common/BannerAlertBox/BannerAlertBox', () => {
  return function MockBannerAlertBox({
    styling,
    children,
    id,
  }: {
    styling: string;
    children: React.ReactNode;
    id: string;
  }) {
    return (
      <div data-testid="banner-alert" data-styling={styling} id={id}>
        {children}
      </div>
    );
  };
});

jest.mock('../ReturnDetails/OriginalTransaction', () => ({
  OriginalTransaction: ({ transactionDetails }: { transactionDetails: any }) => (
    <div data-testid="original-transaction">
      Original Transaction for {transactionDetails.id}
    </div>
  ),
}));

jest.mock('./ReturnConfirmation.util', () => ({
  displayPaymentMethod: jest.fn((method: string) => `Payment Method: ${method}`),
}));

jest.mock('../../hooks/useViewOptions', () => ({
  __esModule: true,
  default: jest.fn(() => ({
    windowTabKey: 'test-window-tab-key',
    windowTabTitle: 'Test Window Title',
    containerTabTitle: 'Test Container Title',
  })),
}));

describe('ReturnConfirmation', () => {
  const defaultInitiateReturnFormData: InitiateReturnFormDataType = {
    transactionId: 'TXN123',
    fromAccountBsb: '032000',
    fromAccountNumber: '123456789',
    fromAccountName: 'Test Account',
    debitDesc: 'Test debit',
    toAccountBsb: '032001',
    toAccountNumber: '987654321',
    toAccountName: 'Recipient Account',
    payerAccountBsb: '032000',
    payerAccountNumber: '123456789',
    payerAccountName: 'Payer Account',
    creditDesc: 'Test credit',
    reference: 'REF123',
    anotherAccountFlag: 'No',
    totalAmount: '100.00',
    nppCaseId: 'NPP123',
    additionalInfo: 'Additional information',
    paymentMethod: ServiceLevel.Osko,
    internalCaseId: 'INTERNAL123',
  };

  const defaultTransactionDetails: TransactionDetails = {
    id: 'TXN123',
    accountName: 'Test Account',
    accountId: '123456789',
    narrative: 'Test transaction',
    transactionDateTime: '2023-12-09T10:00:00Z',
    amount: {
      amount: '100.00',
      currencyCode: 'AUD',
      position: 'DEBIT',
    },
    type: TransactionDirection.Debit,
    payer: {
      name: 'Payer Name',
      accountId: '123456789',
    },
    beneficiary: {
      name: 'Beneficiary Name',
      accountId: '987654321',
    },
    originalTransactionId: 'ORIG123',
  };

  const defaultPaymentReturn: PaymentReturnResponse = [
    {
      id: 'PR123',
      groupInformation: {
        originalCreationDateTime: '2023-12-09T10:30:00Z',
        groupStatus: 'COMPLETED',
      },
      paymentInformation: {
        paymentInformationStatus: StatusCode.ACSC,
      },
      supplementaryData: {
        id: 'RECEIPT123',
      },
    },
  ];

  const defaultProps: ReturnConfirmationProps = {
    initiateReturnFormData: defaultInitiateReturnFormData,
    paymentReturn: defaultPaymentReturn,
    selectedTransactionDetails: defaultTransactionDetails,
    paymentReturnApiStatus: 201,
  };

  beforeEach(() => {
    jest.clearAllMocks();
    (useGlobalDispatch as jest.Mock).mockReturnValue(mockDispatch);
    (useNavigate as jest.Mock).mockReturnValue(mockNavigate);
    (useHandleRaiseIntent as jest.Mock).mockReturnValue(mockHandleRaiseIntent);
    (formatCurrencyString as jest.Mock).mockImplementation((amount) => amount);
    (getFormattedDateTime as jest.Mock).mockImplementation(
      () => '9 Dec 2023, 10:30:00am (AEDT)'
    );
    
    const { useGlobalSelector } = require('@mep-ui/framework');
    (useGlobalSelector as jest.Mock).mockImplementation((selector) => {
      const mockState = {
        global: {
          galaxy: {
            context: {
              selectedCustomer: {
                cisKey: 'test-cis-key',
                customerId: 'test-customer-id',
              },
            },
          },
        },
      };
      return selector(mockState);
    });
  });

  describe('Component Rendering', () => {
    it('should render the component with correct title', () => {
      render(<ReturnConfirmation {...defaultProps} />);

      expect(screen.getByText('Return confirmation')).toBeInTheDocument();
      expect(screen.getByTestId('mv-card')).toBeInTheDocument();
      expect(screen.getByTestId('original-transaction')).toBeInTheDocument();
      expect(screen.getByText('Original Transaction for TXN123')).toBeInTheDocument();
      expect(screen.getByText('Submitted date')).toBeInTheDocument();
      expect(screen.getByText('9 Dec 2023, 10:30:00am (AEDT)')).toBeInTheDocument();
      expect(screen.getByText('Payment method')).toBeInTheDocument();
      expect(screen.getByText(`Payment Method: ${ServiceLevel.Osko}`)).toBeInTheDocument();
    });
    
    it('should match snapshot', () => {
      const { container } = render(<ReturnConfirmation {...defaultProps} />);
      expect(container).toMatchSnapshot();
    });
  });

  describe('Success Scenarios', () => {
    it('should show success banner for ACSC status with 201 response', () => {
      render(<ReturnConfirmation {...defaultProps} />);

      const banner = screen.getByTestId('banner-alert');
      expect(banner).toHaveAttribute('data-styling', BannerStyle.SUCCESS);
      expect(screen.getByText(/Your return of/)).toBeInTheDocument();
      expect(screen.getByText(/has been submitted/)).toBeInTheDocument();
    });

    it('should show success banner for 202 response code', () => {
      const props = {
        ...defaultProps,
        paymentReturnApiStatus: 202,
      };

      render(<ReturnConfirmation {...props} />);

      const banner = screen.getByTestId('banner-alert');
      expect(banner).toHaveAttribute('data-styling', BannerStyle.SUCCESS);
      expect(screen.getByText(/Your return of/)).toBeInTheDocument();
      expect(screen.getByText(/has been submitted/)).toBeInTheDocument();
    });

    it('should show sent for authorisation message', () => {
      const props = {
        ...defaultProps,
        paymentReturnApiStatus: UNAUTHORISED_STATUS_CODE,
        channelRequestId: 'AUTH123',
        paymentReturnsError: {
          code: SENT_FOR_AUTHORISATION_STATUS_CODE,
          message: 'Sent for authorisation',
          detail: '',
        },
      };

      render(<ReturnConfirmation {...props} />);

      const banner = screen.getByTestId('banner-alert');
      expect(banner).toHaveAttribute('data-styling', BannerStyle.SUCCESS);
      expect(screen.getByText(/has been sent for authorisation/)).toBeInTheDocument();
      expect(screen.getByText('Authorisation ID: AUTH123')).toBeInTheDocument();
    });
  });

  describe('Error Scenarios', () => {
    it('should show insufficient funds rejection message', () => {
      const rejectedPaymentReturn: PaymentReturnResponse = [
        {
          id: 'PR123',
          groupInformation: {
            originalCreationDateTime: '2023-12-09T10:30:00Z',
            groupStatus: 'REJECTED',
          },
          paymentInformation: {
            paymentInformationStatus: StatusCode.RJCT,
          },
          transactionStatusInformation: {
            statusReasonInformation: {
              reason: RejectReason.InsufficientAccountBalance,
            },
          },
          supplementaryData: {
            id: 'RECEIPT123',
          },
        },
      ];

      const props = {
        ...defaultProps,
        paymentReturn: rejectedPaymentReturn,
        paymentReturnApiStatus: 201,
      };

      render(<ReturnConfirmation {...props} />);

      const banner = screen.getByTestId('banner-alert');
      expect(banner).toHaveAttribute('data-styling', BannerStyle.DANGER);
      expect(screen.getByText(/Return rejected due to insufficient funds/)).toBeInTheDocument();
    });

    it('should show generic rejection message for other rejection reasons', () => {
      const rejectedPaymentReturn: PaymentReturnResponse = [
        {
          id: 'PR123',
          groupInformation: {
            originalCreationDateTime: '2023-12-09T10:30:00Z',
            groupStatus: 'REJECTED',
          },
          paymentInformation: {
            paymentInformationStatus: StatusCode.RJCT,
          },
          transactionStatusInformation: {
            statusReasonInformation: {
              reason: 'OTHER_REASON',
            },
          },
          supplementaryData: {
            id: 'RECEIPT123',
          },
        },
      ];

      const props = {
        ...defaultProps,
        paymentReturn: rejectedPaymentReturn,
        paymentReturnApiStatus: 201,
      };

      render(<ReturnConfirmation {...props} />);

      const banner = screen.getByTestId('banner-alert');
      expect(banner).toHaveAttribute('data-styling', BannerStyle.DANGER);
      expect(screen.getByText('Return could not be processed at this time.')).toBeInTheDocument();
    });

    it('should show generic error message for other status codes', () => {
      const props = {
        ...defaultProps,
        paymentReturnApiStatus: 500,
      };

      render(<ReturnConfirmation {...props} />);

      const banner = screen.getByTestId('banner-alert');
      expect(banner).toHaveAttribute('data-styling', BannerStyle.DANGER);
      expect(screen.getByText('Something went wrong. Please try again later.')).toBeInTheDocument();
    });

    it('should show generic error for 401 without sent for authorisation code', () => {
      const props = {
        ...defaultProps,
        paymentReturnApiStatus: UNAUTHORISED_STATUS_CODE,
        paymentReturnsError: {
          code: 1234, // Different error code (not SENT_FOR_AUTHORISATION_STATUS_CODE)
          message: 'Unauthorized',
          detail: '',
        },
      };

      render(<ReturnConfirmation {...props} />);

      const banner = screen.getByTestId('banner-alert');
      expect(banner).toHaveAttribute('data-styling', BannerStyle.DANGER);
      expect(screen.getByText('Something went wrong. Please try again later.')).toBeInTheDocument();
    });
  });

  describe('Receipt Links', () => {
    it('should render receipt link with correct receipt number', () => {
      render(<ReturnConfirmation {...defaultProps} />);

      expect(screen.getByText('Receipt number:')).toBeInTheDocument();
      expect(screen.getByText('RECEIPT123')).toBeInTheDocument();
    });

    it('should handle click on receipt link for account activity', async () => {
      render(<ReturnConfirmation {...defaultProps} />);

      const receiptLink = screen.getByText('RECEIPT123');
      fireEvent.click(receiptLink);

      expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
        intentName: INTENT_NAMES.VIEW_ACCOUNT_ACTIVITY_WORKFLOW,
        intentContextName: INTENTS_CONTEXT_NAME.ACCOUNT,
        data: { selectedAccount: { accountNumber: '123456789' } },
        contextKey: '123456789',
        targetPath: PAGE_NAVIGATION.ACCOUNT_ACTIVITY_WORKFLOW,
        viewOptions: {
          windowTabKey: 'test-window-tab-key',
          windowTabTitle: 'Test Window Title',
          containerTabTitle: 'Test Container Title',
        },
      });
    });

    it('should handle click on authorisations link', async () => {
      const props = {
        ...defaultProps,
        paymentReturnApiStatus: UNAUTHORISED_STATUS_CODE,
        channelRequestId: 'AUTH123',
        paymentReturnsError: {
          code: SENT_FOR_AUTHORISATION_STATUS_CODE,
          message: 'Sent for authorisation',
          detail: '',
        },
      };

      render(<ReturnConfirmation {...props} />);

      const authorisationsLink = screen.getByText('Authorisations');
      fireEvent.click(authorisationsLink);

      expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
        intentName: INTENT_NAMES.VIEW_AUTHORISATION_REQUEST_LIST,
        intentContextName: INTENTS_CONTEXT_NAME.WORKFLOW_AUTHORISATION,
        targetPath: PAGE_NAVIGATION.AUTHORISATION_REQUEST_LIST,
      });
    });
  });

  describe('Date and Time Formatting', () => {
    it('should use original creation date time when available', () => {
      (getFormattedDateTime as jest.Mock).mockReturnValue('Custom Date Time');

      render(<ReturnConfirmation {...defaultProps} />);

      expect(getFormattedDateTime).toHaveBeenCalledWith(
        '2023-12-09T10:30:00Z',
        'h:mm:ssa'
      );
      expect(screen.getByText('Custom Date Time')).toBeInTheDocument();
    });

    it('should use default date time when original creation date is not available', () => {
      const paymentReturnWithoutDate: PaymentReturnResponse = [
        {
          ...defaultPaymentReturn[0],
          groupInformation: {
            groupStatus: 'COMPLETED',
          },
        },
      ];

      const props = {
        ...defaultProps,
        paymentReturn: paymentReturnWithoutDate,
      };

      render(<ReturnConfirmation {...props} />);

      expect(getFormattedDateTime).toHaveBeenCalledWith(undefined, 'h:mm:ssa');
    });
  });

  describe('Edge Cases', () => {
    it('should handle empty receipt number', () => {
      const paymentReturnWithoutReceipt: PaymentReturnResponse = [
        {
          ...defaultPaymentReturn[0],
          supplementaryData: {
            id: '',
          },
        },
      ];

      const props = {
        ...defaultProps,
        paymentReturn: paymentReturnWithoutReceipt,
      };

      render(<ReturnConfirmation {...props} />);

      expect(screen.getByText('Receipt number:')).toBeInTheDocument();
    });
    it('should use actual receipt id when not null', () => {
      const paymentReturnWithValidId: PaymentReturnResponse = [
        {
          ...defaultPaymentReturn[0],
          supplementaryData: {
            id: 'VALID_RECEIPT_123',
          },
        },
      ];

      const props = {
        ...defaultProps,
        paymentReturn: paymentReturnWithValidId,
      };

      render(<ReturnConfirmation {...props} />);

      expect(screen.getByText('Receipt number:')).toBeInTheDocument();
      expect(screen.getByText('VALID_RECEIPT_123')).toBeInTheDocument();
      // Should use the actual value when id is not null/undefined (nullish coalescing left side)
    });
    it('should format currency amount correctly', () => {
      (formatCurrencyString as jest.Mock).mockReturnValue('1,000.00');

      render(<ReturnConfirmation {...defaultProps} />);

      expect(formatCurrencyString).toHaveBeenCalledWith('100.00');
      expect(screen.getByText(/\$1,000\.00/)).toBeInTheDocument();
    });
  });
});
