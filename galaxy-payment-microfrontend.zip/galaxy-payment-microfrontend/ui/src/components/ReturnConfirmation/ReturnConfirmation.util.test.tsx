import { render } from '@testing-library/react';
import { ServiceLevel } from 'ui/src/common/constants';
import { displayPaymentMethod } from 'ui/src/components/ReturnConfirmation/ReturnConfirmation.util';

describe('displayPaymentMethod', () => {
  it('renders Osko icon for ServiceLevel.Osko', () => {
    const { getByAltText } = render(displayPaymentMethod(ServiceLevel.Osko));
    expect(getByAltText('Osko')).toBeInTheDocument();
  });

  it('renders Fast Payment for ServiceLevel.FastPayment', () => {
    const { getByText } = render(
      displayPaymentMethod(ServiceLevel.FastPayment)
    );
    expect(getByText('Fast Payment')).toBeInTheDocument();
  });

  it('renders Fast Payment for ServiceLevel.CatSct', () => {
    const { getByText } = render(displayPaymentMethod(ServiceLevel.CatSct));
    expect(getByText('Fast Payment')).toBeInTheDocument();
  });

  it('renders On Platform for unknown ServiceLevel', () => {
    const { getByText } = render(
      displayPaymentMethod('Unknown' as ServiceLevel)
    );
    expect(getByText('On Platform')).toBeInTheDocument();
  });
});
