import {
  formatCurrencyString,
  getFormattedDateTime,
  getURLParams,
  LuxonSettings,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import '@testing-library/jest-dom';
import { fireEvent, render, screen } from '@testing-library/react';
import React from 'react';
import {
  INTENT_NAMES,
  INTENTS_CONTEXT_NAME,
  PAGE_NAVIGATION,
  SENT_FOR_AUTHORISATION_STATUS_CODE,
  UNAUTHORISED_STATUS_CODE,
} from '../../common/constants';
import {
  NppPaymentMethod,
  TransactionDirection,
} from '../../containers/InitiateReturnContainer/InitiateReturnContainer.constant';
import {
  InitiateReturnFormDataType,
  TransactionDetails,
} from '../../containers/InitiateReturnContainer/InitiateReturnContainer.type';
import type { PaymentReturn } from '../../store/types';
import ReturnConfirmation, {
  ReturnConfirmationProps,
} from './ReturnConfirmation_old';
jest.mock('@mesh-tenant-multiverse-common/react', () => {
  return {
    useRaiseIntent: () => jest.fn(),
  };
});
const mockHandleRaiseIntent = jest.fn();

jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => {
  return {
    MVCard: function MockComponent({
      title,
      children,
    }: {
      title: string;
      children: React.ReactNode;
    }) {
      return (
        <div>
          <p>{title}</p>
          {children}
        </div>
      );
    },
  };
});

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => {
  return {
    ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-utils'),
    formatCurrencyString: jest.fn(),
    getFormattedDateTime: jest.fn(),
    getURLParams: jest.fn(),
    isStaffUrl: jest.fn(),
    useHandleRaiseIntent: () => mockHandleRaiseIntent,
  };
});

jest.mock('@mesh-tenant-multiverse-ui-common/mv-icons', () => {
  return {
    MVIcons: function MockComponent() {
      return <div data-testid="mv-icon">Osko Icon</div>;
    },
  };
});

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalDispatch: jest.fn(),
}));
jest.mock('../../store/store', () => ({
  __esModule: true,
  default: {
    dispatch: jest.fn(),
  },
}));

jest.mock('@mep-ui/framework-router-addon', () => {
  const mockNavigate = jest.fn();
  return {
    ...jest.requireActual('@mep-ui/framework-router-addon'),
    useNavigate: () => mockNavigate,
  };
});

const mockPaymentReturn: PaymentReturn = [
  {
    id: '1',
    creationDateTime: '2024-07-08T12:00:00Z',
    groupInformation: {
      originalCreationDateTime: '2024-07-08T12:00:00Z',
      groupStatus: 'Success',
    },
    groupStatusReasonInformation: [
      {
        reason: 'Success',
        additionalInformation: 'Success',
      },
    ],
    transactionStatusInformation: [
      {
        transactionStatus: 'ACSC',
        statusReasonInformation: [
          {
            reason: 'ValidationSucceeded',
            additionalInformation: 'Success',
          },
        ],
        supplementaryData: {
          id: 'WS4211157046112',
        },
      },
    ],
  },
];

const defaultFormData: InitiateReturnFormDataType = {
  transactionId: '',
  returnType: undefined,
  solicitedReasonForReturn: undefined,
  unSolicitedReasonForReturn: undefined,
  fromAccountBsb: '',
  fromAccountNumber: '',
  fromAccountName: '',
  debitDesc: '',
  toAccountBsb: '',
  toAccountNumber: '',
  toAccountName: '',
  reference: '',
  creditDesc: '',
  anotherAccountFlag: 'No',
  totalAmount: '100,000.00',
  nppCaseId: '',
  additionalInfo: '',
  paymentMethod: undefined,
  internalCaseId: '',
  payerAccountBsb: '',
  payerAccountNumber: '',
  payerAccountName: '',
};

const selectedTransaction: TransactionDetails = {
  accountId: '000123 7098112345',
  accountName: 'CCMP Subscription Update',
  amount: {
    amount: '100000.0',
    currencyCode: 'AUD',
    position: 'CR',
  },
  beneficiary: {
    accountId: '000845 7091234',
    name: 'Durga',
  },
  creditorAccountId: ' ',
  creditorDescription: 'NikitaDM',
  creditorFI: 'WPACAU3SXXX',
  creditorReference: '',
  debtorAccountId: ' ',
  debtorFI: 'CTBAAUSNXXX',
  id: '8e7c9d85-8410-4326-833a-e050cb77b404',
  narrative:
    'Deposit-Fast Payment NP33101234567 Orange LTD Tech Like ðŸ¥³ðŸŽ‰æ–°å¹´å¿«ä¹ $1,456.00 OR OTHER CHRS E2EId123456789012345678901234567890',
  originalMessageId: 'CTBAAUSNXXX20240619000001158103279',
  originalMessageName: 'pacs.008.001.05',
  originalTransactionId: 'CTBAAUSNXXXN02406190000011891799329',
  payer: {
    accountId: '000102 3123456',
    name: 'Tania England',
  },
  paymentMethod: {
    code: 'npp.clear.01-x2p1.04',
    description: NppPaymentMethod.Osko,
  },
  paymentStatus: 'Processed',
  reference: 'PAGFISPOC',
  schemeCategoryPurpose: 'OTHR',
  transactionCode: 'PMNT.RRCT.DMCT_FIS_NPP_TRF',
  transactionDateTime: '2024-06-19T08:16:30.041Z',
  transactionId: 'NPP230000124CUSTOMER',
  type: TransactionDirection.Credit,
};

const defaultProps: ReturnConfirmationProps = {
  initiateReturnFormData: defaultFormData,
  paymentReturnApiStatus: 201,
  paymentReturn: mockPaymentReturn,
  selectedTransactionDetails: selectedTransaction,
};

describe('Testing ReturnConfirmation', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    LuxonSettings.resetCaches();
    LuxonSettings.now = () => new Date().valueOf();
  });

  it('should match snapshot', () => {
    LuxonSettings.now = () => new Date('08 July 2024 12:00').valueOf();
    (getFormattedDateTime as jest.Mock).mockReturnValue(
      '8 Jul 2024, 10:00:00pm (AEST)'
    );
    (formatCurrencyString as jest.Mock).mockReturnValue('100,000.00');
    (getURLParams as jest.Mock).mockReturnValue('');
    const { container } = render(<ReturnConfirmation {...defaultProps} />);
    expect(container).toMatchSnapshot();
  });

  it('Should show the heading in the page', () => {
    const { getAllByText } = render(<ReturnConfirmation {...defaultProps} />);
    const returnConfirmationTitle = getAllByText('Return confirmation');
    expect(returnConfirmationTitle).toHaveLength(1);
  });

  it('Success scenario - Should show original tx details and payment details', () => {
    const { getByText } = render(<ReturnConfirmation {...defaultProps} />);
    expect(getByText('$100,000.00').tagName).toBe('STRONG');
    expect(getByText('Original transaction')).toBeInTheDocument();
    expect(getByText('Transaction ID')).toBeInTheDocument();
    expect(
      getByText('CTBAAUSNXXXN02406190000011891799329')
    ).toBeInTheDocument();
    expect(getByText('Submitted date')).toBeInTheDocument();
    expect(getByText('8 Jul 2024, 10:00:00pm (AEST)')).toBeInTheDocument();
  });

  it('Error scenario - Should show original tx details and error message', () => {
    const mockPaymentReturn: PaymentReturn = [
      {
        id: '1',
        creationDateTime: '2024-07-08T12:00:00Z',
        groupInformation: {
          originalCreationDateTime: '2024-07-08T12:00:00Z',
          groupStatus: 'Success',
        },
        groupStatusReasonInformation: [
          {
            reason: 'Success',
            additionalInformation: 'Success',
          },
        ],
        transactionStatusInformation: [
          {
            transactionStatus: 'RJCT',
            statusReasonInformation: [
              {
                reason: 'ValidationFailed',
                additionalInformation: 'Failure',
              },
            ],
            supplementaryData: {
              id: 'WS4211157046112',
            },
          },
        ],
      },
    ];

    const defaultProps: ReturnConfirmationProps = {
      initiateReturnFormData: defaultFormData,
      paymentReturnApiStatus: 201,
      paymentReturn: mockPaymentReturn,
      selectedTransactionDetails: selectedTransaction,
    };

    const { getByText } = render(<ReturnConfirmation {...defaultProps} />);
    expect(
      getByText('Return could not be processed at this time.')
    ).toBeInTheDocument();
    expect(getByText('Original transaction')).toBeInTheDocument();
    expect(getByText('Transaction ID')).toBeInTheDocument();
    expect(
      getByText('CTBAAUSNXXXN02406190000011891799329')
    ).toBeInTheDocument();
    expect(getByText('Submitted date')).toBeInTheDocument();
    expect(getByText('8 Jul 2024, 10:00:00pm (AEST)')).toBeInTheDocument();
  });

  it('It should display the osko icon on the page when the payment method is osko', () => {
    const props = {
      ...defaultProps,
      initiateReturnFormData: {
        ...defaultFormData,
        paymentMethod: NppPaymentMethod.Osko,
      },
    };
    render(<ReturnConfirmation {...props} />);
    const oskoIcon = screen.getAllByTestId('mv-icon');
    expect(oskoIcon.length).toBeGreaterThan(0);
  });

  it('It should display the receipt number and goes to /account/account-activity on click', () => {
    const { getByText } = render(<ReturnConfirmation {...defaultProps} />);
    const receiptNumberLink = getByText('WS4211157046112');
    fireEvent.click(receiptNumberLink);
    expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
      intentName: INTENT_NAMES.VIEW_ACCOUNT_ACTIVITY_WORKFLOW,
      intentContextName: INTENTS_CONTEXT_NAME.ACCOUNT,
      data: {
        selectedAccount: { accountNumber: selectedTransaction.accountId },
      },
      contextKey: selectedTransaction.accountId,
      targetPath: PAGE_NAVIGATION.ACCOUNT_ACTIVITY_WORKFLOW,
    });
  });

  it('should show success banner and call handleRaiseIntent when clicking on "Authorisations" link', () => {
    (formatCurrencyString as jest.Mock).mockReturnValue('100,000.00');
    (getFormattedDateTime as jest.Mock).mockReturnValue(
      '8 Jul 2024, 10:00:00pm (AEST)'
    );
    (getURLParams as jest.Mock).mockReturnValue('');

    const propsWithAdditionalFields: ReturnConfirmationProps = {
      ...defaultProps,
      channelRequestId: 'WS-PMT-RTN-123598765432100',
      paymentReturnApiStatus: UNAUTHORISED_STATUS_CODE,
      paymentReturnsError: {
        code: SENT_FOR_AUTHORISATION_STATUS_CODE,
        message: 'Authoriser Approval Required',
        details: 'The request is pending approval <workflowId>',
      },
    };

    render(<ReturnConfirmation {...propsWithAdditionalFields} />);

    const authorisationsLink = screen.getByText('Authorisations');
    fireEvent.click(authorisationsLink);

    expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
      intentName: INTENT_NAMES.VIEW_AUTHORISATION_REQUEST_LIST,
      intentContextName: INTENTS_CONTEXT_NAME.WORKFLOW_AUTHORISATION,
      targetPath: PAGE_NAVIGATION.AUTHORISATION_REQUEST_LIST,
    });
    expect(
      screen.getByText((content) =>
        content.includes('has been sent for authorisation')
      )
    ).toBeInTheDocument();
  });
});
