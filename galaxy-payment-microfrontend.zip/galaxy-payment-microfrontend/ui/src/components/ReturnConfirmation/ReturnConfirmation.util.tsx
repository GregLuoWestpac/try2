import { MVIcons } from '@mesh-tenant-multiverse-ui-common/mv-icons';
import { ServiceLevel } from 'ui/src/common/constants';

const PaymentMethod = ({ displayName }: { displayName: string }) => (
  <p className="m-0">{displayName}</p>
);

export const displayPaymentMethod = (code: ServiceLevel) => {
  switch (code) {
    case ServiceLevel.Osko:
      return <MVIcons name="Osko" />;
    case ServiceLevel.FastPayment:
    case ServiceLevel.CatSct:
      return <PaymentMethod displayName="Fast Payment" />;
    default:
      return <PaymentMethod displayName="On Platform" />;
  }
};
