/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { useGlobalDispatch } from '@mep-ui/framework';
import { useNavigate } from '@mep-ui/framework-router-addon';
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';

import {
  formatCurrencyString,
  getFormattedDateTime,
  useHandleRaiseIntent,
  isStaffPortal,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { Grid, GridItem, Heading, Link } from '@westpac/ui';
import { useCallback, useMemo } from 'react';
import { displayPaymentMethod } from 'ui/src/components/ReturnConfirmation/ReturnConfirmation.util';
import {
  apiGenericErrorTryAgainLater,
  BannerStyle,
  CONTAINERTAB_TITLES,
  INTENT_NAMES,
  INTENTS_CONTEXT_NAME,
  PAGE_NAVIGATION,
  RejectReason,
  SENT_FOR_AUTHORISATION_STATUS_CODE,
  ServiceLevel,
  StatusCode,
  UNAUTHORISED_STATUS_CODE,
} from '../../common/constants';
import { ErrorResponse } from '../../common/types';
import {
  InitiateReturnFormDataType,
  TransactionDetails,
} from '../../containers/InitiateReturnContainer/InitiateReturnContainer.type';
import BannerAlertBox from '../../galaxy-common/BannerAlertBox/BannerAlertBox';
import { OriginalTransaction } from '../ReturnDetails/OriginalTransaction';
import { PaymentReturnResponse } from '../../store/types/PaymentReturn';
import useViewOptions from '../../hooks/useViewOptions';

const ReceiptLink = ({
  receiptNumber,
  accountNumber,
}: {
  receiptNumber: string;
  accountNumber: string;
}) => {
  const handleRaiseIntent = useHandleRaiseIntent(
    useGlobalDispatch,
    useNavigate
  );
  const viewOptionsAccountActivity = useViewOptions(CONTAINERTAB_TITLES.ACCOUNT_ACTIVITY);
  const navigateToAccountActivity = useCallback(async () => {
    await handleRaiseIntent({
      intentName: INTENT_NAMES.VIEW_ACCOUNT_ACTIVITY_WORKFLOW,
      intentContextName: INTENTS_CONTEXT_NAME.ACCOUNT,
      data: { selectedAccount: { accountNumber } },
      contextKey: accountNumber,
      targetPath: PAGE_NAVIGATION.ACCOUNT_ACTIVITY_WORKFLOW,
      ...(isStaffPortal() && { viewOptions: viewOptionsAccountActivity }),
    });
  }, [
    INTENT_NAMES.VIEW_ACCOUNT_ACTIVITY_WORKFLOW,
    INTENTS_CONTEXT_NAME.ACCOUNT,
    PAGE_NAVIGATION.ACCOUNT_ACTIVITY_WORKFLOW,
    accountNumber,
    viewOptionsAccountActivity,
  ]);
  return (
    <GridItem>
      <span>
        Receipt number:{' '}
        <Link
          className="w-fit cursor-pointer"
          type="inline"
          onClick={navigateToAccountActivity}
        >
          <span className="text-success underline decoration-success">
            {receiptNumber}
          </span>
        </Link>
      </span>
    </GridItem>
  );
};

export type ReturnConfirmationProps = {
  initiateReturnFormData: InitiateReturnFormDataType;
  channelRequestId?: string;
  paymentReturnsError?: ErrorResponse;
  paymentReturnApiStatus?: number;
  paymentReturn: PaymentReturnResponse;
  selectedTransactionDetails: TransactionDetails;
};

function ReturnConfirmation({
  initiateReturnFormData,
  channelRequestId,
  paymentReturnsError,
  paymentReturnApiStatus,
  paymentReturn,
  selectedTransactionDetails,
}: ReturnConfirmationProps) {

  const { paymentMethod, totalAmount, anotherAccountFlag } =
    initiateReturnFormData;
  const receiptNumber = paymentReturn[0]?.supplementaryData?.id ?? '';

  const getBannerText = () => {
    const messageForInsufficientAccountBalance = (
      <Grid className="flex flex-col">
        <GridItem>
          <span>
            Return rejected due to insufficient funds in the payer account.
          </span>
        </GridItem>
        <ReceiptLink
          receiptNumber={receiptNumber}
          accountNumber={selectedTransactionDetails.accountId}
        />
      </Grid>
    );

    const messgeForGenericPaymentReturnsStatusReason = (
      <Grid className="flex flex-col">
        <GridItem>
          <span>Return could not be processed at this time.</span>
        </GridItem>
        <ReceiptLink
          receiptNumber={receiptNumber}
          accountNumber={selectedTransactionDetails.accountId}
        />
      </Grid>
    );

    const errorMessage = (
      <Grid className="flex flex-col">
        <GridItem>{apiGenericErrorTryAgainLater}</GridItem>
      </Grid>
    );

    const successMessageForACSC = (
      <Grid className="flex flex-col">
        <GridItem>
          <span>
            Your return of <strong>${formatCurrencyString(totalAmount)}</strong>{' '}
            has been submitted.
          </span>
        </GridItem>
        <ReceiptLink
          receiptNumber={receiptNumber}
          accountNumber={selectedTransactionDetails.accountId}
        />
      </Grid>
    );

    const handleRaiseIntent = useHandleRaiseIntent(
      useGlobalDispatch,
      useNavigate
    );
    const navigateToAuthorisationList = async () => {
      await handleRaiseIntent({
        intentName: INTENT_NAMES.VIEW_AUTHORISATION_REQUEST_LIST,
        intentContextName: INTENTS_CONTEXT_NAME.WORKFLOW_AUTHORISATION,
        targetPath: PAGE_NAVIGATION.AUTHORISATION_REQUEST_LIST,
      });
    };
    const sentForAuthorisationSuccessMessage = (
      <Grid className="flex flex-col">
        <GridItem>
          <div>
            Your return of <strong>${formatCurrencyString(totalAmount)}</strong>{' '}
            has been sent for authorisation.
          </div>
          <div>Authorisation ID: {channelRequestId}</div>
          You can track the status from the{' '}
          <Link
            className="w-fit cursor-pointer"
            type="inline"
            onClick={navigateToAuthorisationList}
          >
            <span className="text-success underline decoration-success">
              Authorisations
            </span>
          </Link>{' '}
          page.
        </GridItem>
      </Grid>
    );

    let message = errorMessage;
    let bannerStyling: BannerStyle.SUCCESS | BannerStyle.DANGER =
      BannerStyle.DANGER;

    if (paymentReturnApiStatus === 201) {
      const status = paymentReturn[0]?.paymentInformation?.paymentInformationStatus;

      if (status === StatusCode.ACSC) {
        bannerStyling = BannerStyle.SUCCESS;
        message = successMessageForACSC;
      }
      if (status === StatusCode.RJCT) {
        const reason = paymentReturn[0]?.transactionStatusInformation?.statusReasonInformation?.reason === RejectReason.InsufficientAccountBalance
        ? RejectReason.InsufficientAccountBalance : '';
        if (
          reason === RejectReason.InsufficientAccountBalance
        ) {
          message = messageForInsufficientAccountBalance;
        } else {
          message = messgeForGenericPaymentReturnsStatusReason;
        }
      }
    } else if (paymentReturnApiStatus === 202) {
      bannerStyling = BannerStyle.SUCCESS;
      message = successMessageForACSC;
    } else if (paymentReturnApiStatus === UNAUTHORISED_STATUS_CODE) {
      if (paymentReturnsError?.code === SENT_FOR_AUTHORISATION_STATUS_CODE) {
        bannerStyling = BannerStyle.SUCCESS;
        message = sentForAuthorisationSuccessMessage;
      }
    }

    return (
      <BannerAlertBox id="transfer-status-banner" styling={bannerStyling}>
        {message}
      </BannerAlertBox>
    );
  };

  const submittedDateTime = useMemo(() => {
    const originalCreationDateTime =
      paymentReturn[0]?.groupInformation?.originalCreationDateTime;
    return originalCreationDateTime
      ? getFormattedDateTime(originalCreationDateTime, 'h:mm:ssa')
      : getFormattedDateTime(undefined, 'h:mm:ssa');
  }, [paymentReturn[0]?.groupInformation?.originalCreationDateTime]);

  return (
    <MVCard title="Return confirmation" template="narrow">
      <Grid className="flex flex-col">
        <GridItem className="mb-3">{getBannerText()}</GridItem>
        <GridItem>
          <OriginalTransaction
            transactionDetails={selectedTransactionDetails}
          />
        </GridItem>
        <GridItem>
          <Grid className="flex flex-col">
            <GridItem>
              <Grid className="flex flex-row">
                <GridItem className="shrink-0 w-20">
                  <Heading size={10} tag="h5" className="m-0">
                    Submitted date
                  </Heading>
                </GridItem>
                <GridItem className="flex justify-center">
                  <p className="m-0">{submittedDateTime}</p>
                </GridItem>
              </Grid>
            </GridItem>
            <GridItem>
              <Grid className="flex flex-row">
                <GridItem className="shrink-0 w-20">
                  <Heading size={10} tag="h5" className="m-0">
                    Payment method
                  </Heading>
                </GridItem>
                <GridItem className="flex justify-center">
                  {displayPaymentMethod(paymentMethod as ServiceLevel)}
                </GridItem>
              </Grid>
            </GridItem>
          </Grid>
        </GridItem>
      </Grid>
    </MVCard>
  );
}

export default ReturnConfirmation;
