import { ChannelTypeCodeCustomer } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { TransferFormDataType } from '../../containers/TransferFundsContainer/common';
import { mapPostPaymentParams, parseAccountId } from './TransferReview.utils';

const mockFormData: TransferFormDataType = {
  fromAccount: {
    id: '123456 1234567890',
    accountId: '123456 1234567890',
    accountName: 'from account name',
    accountType: 'from account type',
    currencyCode: 'AUD',
    status: '',
  },
  debitDescription: 'debit description',
  creditDescription: 'credit description',
  toAccount: {
    id: '123456 1234567899',
    accountId: '123456 1234567899',
    accountName: 'to account name',
    accountType: 'to account type',
    currencyCode: 'AUD',
    status: '',
  },
  totalAmount: '123',
};

const mockChannelTypeCode = ChannelTypeCodeCustomer.W1C_O_A_D_CP;
const mockGetPaymentId = jest.fn().mockReturnValue('WP123456');

describe('Testing Payment Review utils', () => {
  describe('Testing mapPostPaymentParams', () => {
    beforeAll(() => {
      const fixedDate = {
        toISOString: jest.fn().mockReturnValue('2024-03-21T06:10:44.537Z'),
      };
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      global.Date = jest.fn().mockReturnValue(fixedDate);
    });
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('should return correct post payment params', () => {
      const expectedResult = {
        clientContext: {
          channelType: mockChannelTypeCode,
        },
        creditTransferTransactionInformation: [
          {
            creditor: {
              name: '',
            },
            creditorAccount: {
              identification: '1234561234567899',
              issuer: '123456',
              schemeName: 'BBAN',
              name: 'to account name',
            },
            creditorAgent: {
              BICFI: 'WPACAU2SONE',
            },
            instructedAmount: {
              amount: '123',
              currency: 'AUD',
            },
            instructionForDebtorAgent: 'On-Me',
            remittanceInformation: {
              unstructured: ['credit description'],
            },
          },
        ],
        debtor: {
          issuer: 'WPAC',
          name: '',
        },
        debtorAccount: {
          identification: '1234561234567890',
          issuer: '123456',
          schemeName: 'BBAN',
          name: 'from account name',
        },
        debtorAgent: {
          BICFI: 'WPACAU2SONE',
        },
        initiatingParty: {
          name: '',
        },
        paymentInformation: {
          numberOfTransactions: '1',
        },
        paymentMethod: 'TRF',
        supplementaryData: {
          debitDescription: 'debit description',
          instructionTraceIdentification: '',
        },
      };

      const result = mapPostPaymentParams(mockFormData, mockChannelTypeCode);
      expect(result).toMatchObject(expectedResult);
    });
  });

  it('should correctly construct headers in mapPostPaymentParams', () => {
    const params = mapPostPaymentParams(mockFormData, mockChannelTypeCode);
    // If your util now returns headers, check them:
    expect(params).toHaveProperty('clientContext');
    // If headers are part of the returned object, check them:
    // expect(params.headers).toEqual(expect.objectContaining({ ... }));
  });

  describe('Testing parseAccountId', () => {
    it('should return correct BSB and account number from account id', () => {
      const mockAccountId = '123456 1234567890';
      const { BSB, accountNumber } = parseAccountId(mockAccountId);
      expect(BSB).toBe('123456');
      expect(accountNumber).toBe('1234567890');
    });
  });
});
