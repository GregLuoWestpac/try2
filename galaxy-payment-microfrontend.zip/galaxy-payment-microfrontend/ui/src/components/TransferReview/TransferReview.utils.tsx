import { sanitiseWithLibrary } from '@mesh-tenant-multiverse-ui-common/mv-injection-checker';
import {
  ACCOUNT_NAME_MAX_LENGTH,
  ChannelTypeCode,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { buildTransferEntitlement } from 'ui/src/common/utils';
import {
  BICFI,
  Currency,
  InstructionForDebtorAgent,
  Issuer,
  PaymentMethod,
  SchemeName,
} from '../../common/constants';
import type { TransferFormDataType } from '../../containers/TransferFundsContainer/common';
import type { PostPaymentsParams } from '../../store/types';

export const parseAccountId = (accountId: string) => {
  const BSB = accountId.slice(0, 6);
  const accountNumber = accountId.slice(7);

  return {
    BSB,
    accountNumber,
  };
};

export const mapPostPaymentParams = (
  formData: TransferFormDataType,
  channelTypeCode: ChannelTypeCode,
  arrangementDetailsData?: any,
  instructionTraceIdentification?: string,
  paymentId?: string
): PostPaymentsParams => {
  const { toAccount } = formData;
  const { fromAccount } = formData;
  const { totalAmount, debitDescription, creditDescription, division } =
    formData;

  const { BSB: fromBSB, accountNumber: fromAccountNumber } = parseAccountId(
    fromAccount?.accountId ?? ''
  );
  const { BSB: toBSB, accountNumber: toAccountNumber } = parseAccountId(
    toAccount?.accountId ?? ''
  );

  return {
    clientContext: {
      channelType: channelTypeCode,
    },
    creditTransferTransactionInformation: [
      {
        creditor: {
          name: sanitiseWithLibrary(
            arrangementDetailsData?.creditorEntityName ?? ''
          ),
        },
        creditorAccount: {
          identification: `${toBSB}${toAccountNumber}`,
          issuer: toBSB,
          schemeName: SchemeName.BBAN,
          name: sanitiseWithLibrary(
            toAccount?.accountName ?? '',
            ACCOUNT_NAME_MAX_LENGTH
          ),
        },
        creditorAgent: {
          BICFI: BICFI.WPACAU2SONE,
        },
        instructionForDebtorAgent: InstructionForDebtorAgent.OnMe,
        instructedAmount: {
          amount: totalAmount,
          currency: Currency.AUD,
        },
        ...(creditDescription && {
          remittanceInformation: { unstructured: [creditDescription] },
        }),
      },
    ],
    debtor: {
      issuer: Issuer.WPAC,
      name: sanitiseWithLibrary(arrangementDetailsData?.debtorEntityName ?? ''),
    },
    debtorAccount: {
      identification: `${fromBSB}${fromAccountNumber}`,
      issuer: fromBSB,
      schemeName: SchemeName.BBAN,
      name: sanitiseWithLibrary(
        fromAccount?.accountName ?? '',
        ACCOUNT_NAME_MAX_LENGTH
      ),
    },
    debtorAgent: {
      BICFI: BICFI.WPACAU2SONE,
    },
    initiatingParty: {
      name: sanitiseWithLibrary(arrangementDetailsData?.debtorEntityName ?? ''),
    },
    paymentMethod: PaymentMethod.TRF,
    paymentInformation: {
      numberOfTransactions: '1',
    },
    supplementaryData: {
      debitDescription: debitDescription ?? '',
      instructionTraceIdentification: instructionTraceIdentification ?? '',
      ...(division?.id && { divisionId: division?.id }),
      paymentProductId: 'PP000016',
    },
    entitlementData: buildTransferEntitlement(formData, paymentId ?? ''),
  };
};
