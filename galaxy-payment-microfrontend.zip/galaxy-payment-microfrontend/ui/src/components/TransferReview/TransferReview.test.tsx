/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import {
  useIsDesktopVersion,
  usePlatformState,
} from '@mesh-tenant-multiverse-common/react';
import {
  formatCurrencyString,
  getAppUrlWithParams,
  getFormattedDate,
  LuxonSettings,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { fireEvent, render, screen } from '@testing-library/react';
import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { transferConfirmationPage } from 'ui/src/containers/TransferFundsContainer/constants';
import store from '../../store/store';
import TransferReview from './TransferReview';

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useClose: jest.fn(),
  useConfirmClose: jest.fn(),
  useCancelModal: jest.fn(),
  useIsDesktopVersion: jest.fn(),
  usePlatformState: jest.fn(),
}));

(useIsDesktopVersion as jest.Mock).mockReturnValue(true);
(usePlatformState as jest.Mock).mockReturnValue([
  { orgId: { organisationId: 'ORG123' } },
  jest.fn(),
]);

const mockCloseTab = jest.fn();
jest.mock('@mesh-tenant-multiverse-ui-common/mv-openfin', () => ({
  useUnifyClose: jest.fn(() => ({ closeTab: mockCloseTab })),
}));

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalSelector: () => {},
}));

jest.mock('../../store/store', () => ({
  useSelector: jest.fn(),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: function MockComponent({
    title,
    children,
  }: {
    title: string;
    children: React.ReactNode;
  }) {
    return (
      <div>
        <h1>{title}</h1>
        {children}
      </div>
    );
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-detailsection', () => ({
  MVDetailSection: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div>{children}</div>;
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-utils'),
  getFormattedDate: jest.fn(),
  formatCurrencyString: jest.fn(),
  getAppUrlWithParams: jest.fn(),
  useGetChannelTypeCode: jest.fn(() => 'WEB'),
  isStaffPortal: jest.fn(),
}));

jest.mock(
  '@mesh-tenant-user-authorisation-policy-decision-engine/components',
  () => ({
    EntitlementsStepUp: ({ children }: { children: React.ReactNode }) => (
      <div data-testid="entitlements-stepup-mock">{children}</div>
    ),
    useEntitlementsSafi: jest.fn(() => ({
      populateHeader: jest.fn((headers: Record<string, unknown>) => headers),
    })),
  })
);

const idempotencyKey = 'idempotency-key-123';
jest.mock('uuid', () => ({
  v4: jest.fn(() => idempotencyKey),
}));

const defaultFormData = {
  fromAccount: {
    id: '',
    name: '',
    entityName: '',
    accountType: '',
    currencyCode: '',
    currentBalance: '',
    availableBalance: '',
    overdraftLimit: '',
    accountId: '',
    accountName: '',
    status: 'ACTIVE',
  },
  debitDescription: '',
  creditDescription: '',
  toAccount: {
    id: '',
    name: '',
    entityName: '',
    accountType: '',
    currencyCode: '',
    currentBalance: '',
    availableBalance: '',
    overdraftLimit: '',
    accountId: '',
    accountName: '',
    status: 'ACTIVE',
  },
  totalAmount: '',
};

const mockSubmitTransfer = jest.fn();
const mockGetPaymentId = jest.fn<string, []>().mockReturnValue('WP123456');

const defaultProps = {
  renderTransferFundsComponents: jest.fn(),
  transferFundFormData: defaultFormData,
  handleCancelTransfer: jest.fn(),
  submitTransfer: mockSubmitTransfer,
  isTransfersFetching: false,
  isTransfersError: false,
  getPaymentId: mockGetPaymentId,
  isPaymentIdentifierFetching: false,
  isArrangementDetailsFetching: false,
  isArrangementDetailsError: false,
  allArrangementDetails: [],
  paymentId: mockGetPaymentId(),
};

describe('Testing ReviewTransfer', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    LuxonSettings.resetCaches();
    LuxonSettings.now = () => Date.now();
    const appCorrelationId = 'test-id';
    // eslint-disable-next-line @typescript-eslint/no-unsafe-call
    store.useSelector.mockReturnValue(appCorrelationId);
    const {
      isStaffPortal,
    } = require('@mesh-tenant-multiverse-ui-common/mv-utils');
    (isStaffPortal as jest.Mock).mockReturnValue(false);
  });
  it('Should show the ProgressIndicator when isTransfersFetching is true', () => {
    const { getByLabelText } = render(
      <Router>
        <TransferReview {...defaultProps} isTransfersFetching />,
      </Router>
    );

    const progressIndicator = getByLabelText('Loading');
    expect(progressIndicator).toBeInTheDocument();
  });

  it('should match snapshot', () => {
    LuxonSettings.now = () => new Date('01 July 2023 12:00').valueOf();
    const {
      isStaffPortal,
      getFormattedDate,
      formatCurrencyString,
      getAppUrlWithParams,
    } = require('@mesh-tenant-multiverse-ui-common/mv-utils');
    (isStaffPortal as jest.Mock).mockReturnValue(false);
    (getFormattedDate as jest.Mock).mockReturnValue('01 July 2023 12:00');
    (formatCurrencyString as jest.Mock).mockReturnValue('AUD -150.55');
    (getAppUrlWithParams as jest.Mock).mockReturnValue('http://localhost/');
    const { container } = render(
      <Router>
        <TransferReview {...defaultProps} />,
      </Router>
    );
    expect(container).toMatchSnapshot();
  });

  it('Should show the heading in the page', () => {
    const { getAllByText } = render(
      <Router>
        <TransferReview {...defaultProps} />,
      </Router>
    );
    const transferDetailsTitle = getAllByText('Review transfer');
    expect(transferDetailsTitle).toHaveLength(1);
  });

  it('calls closeTab when the Cancel button is clicked', () => {
    render(
      <Router>
        <TransferReview {...defaultProps} />,
      </Router>
    );

    const cancelButton = screen.getByText('Cancel');
    fireEvent.click(cancelButton);

    expect(mockCloseTab).toHaveBeenCalledTimes(1);
  });

  it('Should call the submitTransfer after click submit button', () => {
    const { getByText } = render(
      <Router>
        <TransferReview {...defaultProps} />,
      </Router>
    );
    const submitTransferButton = getByText('Submit transfer');
    expect(submitTransferButton).toBeInTheDocument();
    // test cases added by copilot to increase coverage
    // Click the submit button
    submitTransferButton.click();
    expect(mockSubmitTransfer).toHaveBeenCalled();
  });

  it('should NOT render entitlements section', () => {
    const { queryByTestId } = render(
      <Router>
        <TransferReview {...defaultProps} />
      </Router>
    );
    expect(queryByTestId('entitlements-stepup-mock')).not.toBeInTheDocument();
  });

  it('should pass extra headers to submitTransfer', async () => {
    const submitTransferMock = jest.fn();
    const paymentId = 'WP123456';

    render(
      <Router>
        <TransferReview
          {...defaultProps}
          submitTransfer={submitTransferMock}
          paymentId={paymentId}
        />
      </Router>
    );

    // Wait for the idempotency key to be set in state and button to be enabled
    const submitButton = await screen.findByRole('button', {
      name: /submit transfer/i,
    });
    expect(submitButton).toBeEnabled();

    fireEvent.click(submitButton);

    expect(submitTransferMock).toHaveBeenCalledWith(
      expect.objectContaining({
        params: expect.any(Object),
      }),
      expect.objectContaining({
        headers: expect.objectContaining({
          'x-channelRequestId': paymentId,
        }),
      })
    );
  });

  xit('should call renderTransferFundsComponents if isTransfersFetching is false and apiStatus is true', () => {
    render(
      <Router>
        <TransferReview
          {...defaultProps}
          isTransfersFetching={false}
          apiStatus={200}
        />
        ,
      </Router>
    );
    expect(defaultProps.renderTransferFundsComponents).toHaveBeenCalled();
  });

  it('should call renderTransferFundsComponents with transferConfirmationPage and not call getPaymentId when arrangement details error', () => {
    const renderTransferFundsComponentsMock = jest.fn();
    const getPaymentIdMock = jest.fn();
    render(
      <Router>
        <TransferReview
          {...defaultProps}
          renderTransferFundsComponents={renderTransferFundsComponentsMock}
          getPaymentId={getPaymentIdMock}
          isArrangementDetailsError
        />
      </Router>
    );
    fireEvent.click(screen.getByRole('button', { name: /submit transfer/i }));
    expect(renderTransferFundsComponentsMock).toHaveBeenCalledWith(
      transferConfirmationPage
    );
    expect(getPaymentIdMock).not.toHaveBeenCalled();
  });

  it('should call getPaymentId and not call renderTransferFundsComponents when no arrangement details error', () => {
    const renderTransferFundsComponentsMock = jest.fn();
    const getPaymentIdMock = jest.fn();
    render(
      <Router>
        <TransferReview
          {...defaultProps}
          renderTransferFundsComponents={renderTransferFundsComponentsMock}
          getPaymentId={getPaymentIdMock}
        />
      </Router>
    );
    fireEvent.click(screen.getByRole('button', { name: /submit transfer/i }));
    expect(getPaymentIdMock).toHaveBeenCalledTimes(1);
    expect(renderTransferFundsComponentsMock).not.toHaveBeenCalledWith(
      transferConfirmationPage
    );
  });

  it('should display division when division prop is provided and not in staff portal', () => {
    const {
      isStaffPortal,
    } = require('@mesh-tenant-multiverse-ui-common/mv-utils');
    (isStaffPortal as jest.Mock).mockReturnValue(false);
    const propsWithDivision = {
      ...defaultProps,
      transferFundFormData: {
        ...defaultFormData,
        division: { label: 'Engineering Division', value: 'eng-001' },
      },
    };

    const { getByText } = render(
      <Router>
        <TransferReview {...propsWithDivision} />
      </Router>
    );

    expect(getByText('Division')).toBeInTheDocument();
    expect(getByText('Engineering Division')).toBeInTheDocument();
  });

  it('should not display division when in staff portal even if division prop is provided', () => {
    const {
      isStaffPortal,
    } = require('@mesh-tenant-multiverse-ui-common/mv-utils');
    (isStaffPortal as jest.Mock).mockReturnValue(true);
    const propsWithDivision = {
      ...defaultProps,
      transferFundFormData: {
        ...defaultFormData,
        division: { label: 'Engineering Division', value: 'eng-001' },
      },
    };

    const { queryByText } = render(
      <Router>
        <TransferReview {...propsWithDivision} />
      </Router>
    );

    expect(queryByText('Division')).not.toBeInTheDocument();
    expect(queryByText('Engineering Division')).not.toBeInTheDocument();
  });

  it('should not display division when division prop is not provided', () => {
    const {
      isStaffPortal,
    } = require('@mesh-tenant-multiverse-ui-common/mv-utils');
    (isStaffPortal as jest.Mock).mockReturnValue(false);

    const { queryByText } = render(
      <Router>
        <TransferReview {...defaultProps} />
      </Router>
    );

    expect(queryByText('Division')).not.toBeInTheDocument();
  });
});
