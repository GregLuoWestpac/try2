/* eslint-disable jsx-a11y/label-has-associated-control */
import {
  useIsCompositeDesktop,
  useIsDesktopVersion,
  useIsWebVersion,
} from '@mesh-tenant-multiverse-common/react';
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import { MVDetailSection } from '@mesh-tenant-multiverse-ui-common/mv-detailsection';
import { useUnifyClose } from '@mesh-tenant-multiverse-ui-common/mv-openfin';
import {
  ChannelTypeCode,
  formatCurrencyString,
  getFormattedDate,
  useGetChannelTypeCode,
  isStaffPortal,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { Alert, Button, Grid, GridItem, ProgressIndicator } from '@westpac/ui';
import isArray from 'lodash/isArray';
import { useCallback, useEffect, useState } from 'react';
import { v4 as uuid } from 'uuid';
import { useEntitlementsSafi } from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import { ErrorResponse } from '../../common/types';
import { useOrganizationId } from '../../hooks/useOrganizationId';
import {
  apiGenericErrorTryAgainLater,
  channelId,
  genericErrorMessage,
} from '../../common/constants';
import { isStepUpRequired } from '../../common/utils';
import { TransferFormDataType } from '../../containers/TransferFundsContainer/common';
import {
  transferConfirmationPage,
  transferDetailsPage,
} from '../../containers/TransferFundsContainer/constants';
import { scrollToTop } from '../../galaxy-common/utils/DOMUtils';
import { useEntitlementsStepUp } from '../../hooks/useEntitlementsStepUp';
import type {
  PostGeneratePaymentIdParams,
  PostPaymentsOptionsPayload,
  PostPaymentsParamsPayload,
} from '../../store/types';
import { PingmfaWidgetApp } from '../../widgets/pingmfa';
import { AccountDetailSection } from '../AccountDetailSection';
import { mapPostPaymentParams } from './TransferReview.utils';
import { DivisionAndPaymentTo } from '../DivisionAndPaymentTo';

type TransferReviewProps = {
  renderTransferFundsComponents: (navigateTo: string) => void;
  transferFundFormData: TransferFormDataType;
  submitTransfer: (
    payload: PostPaymentsParamsPayload,
    options: PostPaymentsOptionsPayload
  ) => void;
  getPaymentId: (params: PostGeneratePaymentIdParams) => void;
  isTransfersFetching: boolean;
  isTransfersError: boolean;
  apiStatus?: number;
  paymentId: string;
  postPaymentErrors?: ErrorResponse[];
  hasEditClicked?: boolean;
  setHasEditClicked?: (value: boolean) => void;
  isPaymentIdentifierError?: boolean;
  isPaymentIdentifierFetching: boolean;
  paymentIdentifierApiStatus?: number;
  paymentIdentifierErrors?: ErrorResponse[];
  isArrangementDetailsFetching: boolean;
  isArrangementDetailsError: boolean;
  allArrangementDetails: any;
};

function TransferReview({
  renderTransferFundsComponents,
  transferFundFormData,
  submitTransfer,
  paymentId,
  getPaymentId,
  isTransfersFetching,
  isTransfersError,
  apiStatus,
  postPaymentErrors,
  hasEditClicked,
  setHasEditClicked,
  isPaymentIdentifierError,
  isPaymentIdentifierFetching,
  paymentIdentifierApiStatus,
  paymentIdentifierErrors,
  isArrangementDetailsFetching,
  isArrangementDetailsError,
  allArrangementDetails,
}: TransferReviewProps) {
  const { closeTab } = useUnifyClose(true);
  const [idempotencyKey, setIdempotencyKey] = useState('');
  const [transferReviewDate, setTransferReviewDate] = useState('');
  const [isTransferSubmitted, setTransferSubmitted] = useState(false);
  const [instructionTraceId, setInstructionTraceId] = useState<string>('');

  const stepUpRequired = isStepUpRequired(apiStatus, postPaymentErrors);
  const [isNonOtpMFAError, setIsNonOtpMFAError] = useState<boolean>(false);
  const [isStepUpModalVisible, setIsStepUpModalVisible] =
    useState<boolean>(false);

  const channelTypeCode: ChannelTypeCode = useGetChannelTypeCode({
    useIsCompositeDesktop,
    useIsDesktopVersion,
    useIsWebVersion,
  });

  const orgId = useOrganizationId();
  const { populateHeader } = useEntitlementsSafi();

  const getEntityNameByAccountNumber = (
    fromAccountNumber: string,
    toAccountNumber: string
  ) => {
    if (allArrangementDetails && isArray(allArrangementDetails)) {
      const debtor = allArrangementDetails.find(
        (acc) => acc.accountNumber === fromAccountNumber
      );
      const creditor = allArrangementDetails.find(
        (acc) => acc.accountNumber === toAccountNumber
      );
      const debtorNCreditorNames = {
        debtorEntityName: debtor ? debtor.entityName : '',
        creditorEntityName: creditor ? creditor.entityName : '',
      };
      return debtorNCreditorNames;
    }
  };

  const submitTransferWithExtraHeaders = (
    payload: PostPaymentsParamsPayload,
    options: PostPaymentsOptionsPayload
  ) => {
    const extraHeaders = {
      ...(options || {}),
      headers: {
        ...(options?.headers || {}),
        ...(window.encode_deviceprint
          ? populateHeader({}, window.encode_deviceprint)
          : {}),
        ...(orgId && { 'protected-orgId': orgId }),
        'x-idempotency-key': idempotencyKey,
        'x-channelRequestId': paymentId,
      } as Record<string, any>,
    };

    submitTransfer(payload, extraHeaders);
  };

  const {
    toAccount,
    fromAccount,
    debitDescription,
    creditDescription,
    totalAmount,
    division,
  } = transferFundFormData;

  const { renderEntitlementsStepUp } = useEntitlementsStepUp({
    pingMfaWidget: <PingmfaWidgetApp />,
    propType: 'mfa',
    apiStatus,
    errors: postPaymentErrors,
    dispatchFn: submitTransferWithExtraHeaders,
    isStepUpModalVisible,
    setIsStepUpModalVisible,
    dispatchFnParams: mapPostPaymentParams(
      transferFundFormData,
      channelTypeCode,
      getEntityNameByAccountNumber(
        fromAccount?.accountId ?? '',
        toAccount?.accountId ?? ''
      ),
      instructionTraceId,
      paymentId
    ),

    setIsNonOtpMFAError,
  });
  useEffect(() => {
    setIdempotencyKey(uuid());
    setInstructionTraceId(uuid());
    setTransferReviewDate(getFormattedDate());
  }, []);

  useEffect(() => {
    if (isTransfersError) {
      scrollToTop();
    }
  }, [isTransfersError]);

  useEffect(() => {
    if (paymentId && !hasEditClicked) {
      submitTransferWithExtraHeaders(
        {
          params: mapPostPaymentParams(
            transferFundFormData,
            channelTypeCode,
            getEntityNameByAccountNumber(
              fromAccount?.accountId ?? '',
              toAccount?.accountId ?? ''
            ),
            instructionTraceId,
            paymentId
          ),
        },
        {
          headers: {},
        }
      );
      setTransferSubmitted(true);
    }
  }, [paymentId, hasEditClicked]);

  const handleSubmitTransfer = () => {
    if (isArrangementDetailsError && !isArrangementDetailsFetching) {
      renderTransferFundsComponents(transferConfirmationPage);
      return;
    }
    getPaymentId({
      channelId,
    });
    setIsStepUpModalVisible(true);
    setIsNonOtpMFAError(false);
    setHasEditClicked?.(false);
  };

  const handleEditButtonClick = () => {
    setHasEditClicked?.(true);
    renderTransferFundsComponents(transferDetailsPage);
  };
  const isPaymentIdentifierPermissionError =
    !!isPaymentIdentifierError &&
    paymentIdentifierApiStatus === 403 &&
    paymentIdentifierErrors?.some(({ code }) => code === 8210);

  // Check for maker-checker approval required (8125)
  const isMakerCheckerApprovalRequired =
    apiStatus === 401 && postPaymentErrors?.some(({ code }) => code === 8125);

  useEffect(() => {
    if (
      (isTransferSubmitted &&
        !isTransfersFetching &&
        apiStatus &&
        !stepUpRequired) ||
      isNonOtpMFAError ||
      isPaymentIdentifierPermissionError ||
      isMakerCheckerApprovalRequired
    ) {
      renderTransferFundsComponents(transferConfirmationPage);
    }
  }, [
    isTransfersFetching,
    isTransferSubmitted,
    apiStatus,
    stepUpRequired,
    isNonOtpMFAError,
    isPaymentIdentifierPermissionError,
    isMakerCheckerApprovalRequired,
    postPaymentErrors,
  ]);

  const handleClose = useCallback(async () => {
    await closeTab();
  }, []);

  const FromData = [
    {
      label: 'From account',
      value: fromAccount && <AccountDetailSection account={fromAccount} />,
    },
    { label: 'Debit description', value: debitDescription || '' },
  ];

  const ToData = [
    {
      label: 'To account',
      value: toAccount && (
        <AccountDetailSection account={toAccount} showBalance={false} />
      ),
    },
    { label: 'Credit description', value: creditDescription || '' },
  ];

  const TransferDetailsData = [
    {
      label: 'Amount',
      value: (
        <p className="font-bold">AUD {formatCurrencyString(totalAmount)}</p>
      ),
    },
    { label: 'Date', value: transferReviewDate?.split(' (')[0] },
  ];

  const getErrorMessage = (): React.ReactNode => {
    if (isTransfersError && !apiStatus) return genericErrorMessage;
    else return null;
  };

  const renderBanner = () => {
    if (!isTransfersError) return null;
    if (stepUpRequired) return null;
    const message = getErrorMessage();
    if (!message) return null;
    return (
      <GridItem className="w-full" span={12}>
        <Alert
          iconSize="small"
          id="payment-status-banner"
          look="danger"
          className="mt-2.5 mb-0"
        >
          {message}
        </Alert>
      </GridItem>
    );
  };

  const getDivisionProps = () => {
    const divisionLabel = division?.label;
    if (isStaffPortal() || !divisionLabel) return {};
    return { division: divisionLabel };
  };

  return (
    <>
      {(isTransfersFetching ||
        isArrangementDetailsFetching ||
        isPaymentIdentifierFetching) && (
        <div className="fixed inset-0 flex justify-center items-center bg-border bg-opacity-75 z-50">
          <ProgressIndicator size="medium" />
        </div>
      )}
      {renderEntitlementsStepUp()}
      <MVCard title="Review transfer" template="narrow">
        <Grid className="xsl:gap-0 sm:gap-0 !gap-0">
          {renderBanner()}

          <DivisionAndPaymentTo {...getDivisionProps()} />

          <MVDetailSection
            heading="From"
            data={FromData}
            linkAction={{
              text: 'Edit',
              action: () => handleEditButtonClick(),
            }}
          />

          <MVDetailSection
            heading="To"
            data={ToData}
            withTopBorder
            linkAction={{
              text: 'Edit',
              action: () => handleEditButtonClick(),
            }}
          />

          <MVDetailSection
            heading="Transfer details"
            data={TransferDetailsData}
            withTopBorder
            linkAction={{
              text: 'Edit',
              action: () => handleEditButtonClick(),
            }}
          />

          <GridItem
            className="w-full border-t border-border pt-2.5 mt-0"
            span={12}
          >
            <Button
              id="submit-transfer-button"
              name="submitTransfer"
              className="mr-1.5"
              look="primary"
              size="small"
              onClick={handleSubmitTransfer}
            >
              Submit transfer
            </Button>
            <Button
              id="cancel-button-transfer-review"
              name="cancel"
              size="small"
              look="hero"
              soft
              // eslint-disable-next-line @typescript-eslint/no-misused-promises
              onClick={handleClose}
            >
              Cancel
            </Button>
          </GridItem>
        </Grid>
      </MVCard>
    </>
  );
}

export default TransferReview;
