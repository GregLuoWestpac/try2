/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import {
  formatCurrencyString,
  getAppUrlWithParams,
  getFormattedDateTime,
  getURLParams,
  isStaffPortal,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';

import { usePlatformState } from '@mesh-tenant-multiverse-common/react';

import { queryByText, render, screen } from '@testing-library/react';
import { BrowserRouter as Router } from 'react-router-dom';
import { MakePaymentFormDataType } from '../../common/types';
import { Payment } from '../../store/types';
import PaymentConfirmation from './PaymentConfirmation';

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  usePlatformState: jest.fn(),
  useRaiseIntent: jest.fn(),
  useClose: () => ({
    closeTab: jest.fn(),
  }),
}));

jest.mock('@mep-ui/framework', () => ({
  useGlobalDispatch: jest.fn(),
}));

jest.mock('@mep-ui/framework-router-addon', () => ({
  useNavigate: jest.fn(),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-detailsection', () => ({
  MVDetailSection: ({ heading, data }: { heading: string; data: any[] }) => (
    <div>
      <h2>{heading}</h2>
      {data.map(({ label, value }) => (
        <div key={label}>
          <strong>{label}</strong>
          {value}
        </div>
      ))}
    </div>
  ),
}));
jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: function MockComponent({
    title,
    children,
  }: {
    title: string;
    children: React.ReactNode;
  }) {
    return (
      <div>
        <h1>{title}</h1>
        {children}
      </div>
    );
  },
}));
jest.mock('@mesh-tenant-multiverse-ui-common/mv-accountformatter', () => ({
  MVAccountFormatter: function MockComponent({ account }: { account: string }) {
    return <div>Formatted Account: {account}</div>;
  },
}));
jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-utils'),
  getFormattedDateTime: jest.fn(),
  formatCurrencyString: jest.fn(),
  getURLParams: jest.fn(),
  getAppUrlWithParams: jest.fn(),
  useHandleRaiseIntent: jest.fn(),
  isStaffPortal: jest.fn(),
}));
jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  isStaffUrl: jest.fn(),
  useGlobalSelector: () => ({}),
}));

jest.mock('../DivisionAndPaymentTo', () => ({
  DivisionAndPaymentTo: function MockComponent({
    division,
    isNewBeneficiary,
  }: {
    division?: string;
    isNewBeneficiary: boolean;
  }) {
    return (
      <div data-testid="division-and-payment-to">
        {division && <div data-testid="division-label">{division}</div>}
        <div data-testid="is-new-beneficiary">{String(isNewBeneficiary)}</div>
      </div>
    );
  },
}));

(usePlatformState as jest.Mock).mockReturnValue([
  { orgId: { organisationId: 'ORG123' } },
  jest.fn(),
]);

const defaultFormData: MakePaymentFormDataType = {
  fromAccount: {
    id: '',
    // @ts-expect-error
    name: '',
    entityName: '',
    accountType: 'Corporate investment account',
    currencyCode: '',
    currentBalance: '',
    availableBalance: '',
    overdraftLimit: '',
  },
  toDescription: '',
  fromDescription: '',
  toReference: '',

  paymentMethod: {
    id: 'npp.clear.01-sct.04',
    name: 'Fast Payment',
    label: 'Fast Payment',
  },
  toAccount: {
    id: 'd0868661-b955-4e76-9f15-d97626f7d78b',
    externalId: 'd0868661-b955-4e76-9f15-d97626f7d78b',
    nickname: 'Bayer, Miller and MacGyver (BSB/active)',
    currency: 'AUD',
    org: 'office',
    status: 'ACTIVE',
    type: 'BSB_ACCOUNT_NUMBER',
    account: {
      accountId: {
        BSB: '062948',
        accountNumber: '22222123',
      },
      bankName: 'Westpac Banking Corporation',
      accountName: 'Westpac Joint',
    },
  },
  totalAmount: '123',
};

const mockPayment: Payment = {
  id: 'string',
  creationDateTime: '2024-02-12T03:24:18.680Z',
  groupInformation: {
    groupStatus: 'string',
    originalControlSum: 'string',
    originalCreationDateTime: '2024-02-12T03:24:18.680Z',
    originalNumberOfTransactions: 'string',
  },
  groupStatusReasonInformation: [
    {
      reason: 'string',
      additionalInformation: 'string',
    },
  ],
  paymentInformation: {
    paymentInformationStatus: 'string',
    paymentId: 'string',
  },
  paymentStatusReasonInformation: [
    {
      reason: 'string',
      additionalInformation: 'string',
    },
  ],
  transactionInformation: [
    {
      transactionStatus: 'string',
      statusReasonInformation: [
        {
          reason: 'string',
          additionalInformation: 'string',
        },
      ],
    },
  ],
};

const defaultProps = {
  makePaymentFormData: defaultFormData,
  payment: mockPayment,
  apiStatus: 201,
};

const defaultLookupMismatch = {
  beneficiaryName: '',
  aliasLookupName: '',
};

describe('Testing PaymentConfirmation', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should match snapshot', () => {
    (getFormattedDateTime as jest.Mock).mockReturnValue(
      '12 Feb 2024, 2:24pm (AEDT)'
    );
    (formatCurrencyString as jest.Mock).mockReturnValue('123.00');
    (getURLParams as jest.Mock).mockReturnValue('1');
    (getAppUrlWithParams as jest.Mock).mockReturnValue('http://localhost/');
    (isStaffPortal as jest.Mock).mockReturnValue(false);

    const snapshotProps = {
      ...defaultProps,
      makePaymentFormData: {
        ...defaultFormData,
        fromAccount: {
          ...defaultFormData.fromAccount,
          id: 'ACC-123456',
          name: 'Business Operating Account',
          accountType: 'Corporate investment account',
          currencyCode: 'AUD',
        },
        totalAmount: '123.00',
        toReference: 'Invoice Payment',
        toDescription: 'Payment for services',
        fromDescription: 'Business expenses',
      },
      payment: {
        ...mockPayment,
        paymentInformation: {
          ...mockPayment.paymentInformation,
          paymentInformationStatus: 'ACSC',
          paymentId: 'PAY-123456',
        },
      },
      apiStatus: 201,
    };

    const { container } = render(
      <Router>
        <PaymentConfirmation
          lookupMismatch={defaultLookupMismatch}
          {...snapshotProps}
        />
      </Router>
    );
    expect(container).toMatchSnapshot();
  });

  it('Should show the heading in the page', () => {
    const { getAllByText } = render(
      <Router>
        <PaymentConfirmation
          lookupMismatch={defaultLookupMismatch}
          {...defaultProps}
        />
      </Router>
    );
    const transferDetailsTitle = getAllByText('Payment confirmation');
    expect(transferDetailsTitle).toHaveLength(1);
  });

  // create a test for paymentInformationStatus ACSC
  describe('should show correct banner message for paymentInformationStatus ACSC', () => {
    const acscResponseProps = {
      ...defaultProps,
      payment: {
        ...mockPayment,
        paymentInformation: {
          ...mockPayment.paymentInformation,
          paymentInformationStatus: 'ACSC',
        },
      },
    };

    // create a test for payment was processed for on platform payment
    it('Should show payment was processed for on platform payment', () => {
      const props = {
        ...acscResponseProps,
        makePaymentFormData: {
          ...defaultFormData,
          paymentMethod: {
            id: undefined,
            name: 'Fast Payment',
            label: 'Fast Payment',
          },
        },
      };
      const { getByText } = render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const bannerMessage = getByText(/processed/);
      expect(bannerMessage).toBeInTheDocument();
    });
    it('Should show payment was processed and beneficiary added', () => {
      const props = {
        ...acscResponseProps,
        makePaymentFormData: {
          ...defaultFormData,
          paymentMethod: {
            id: undefined,
            name: 'Fast Payment',
            label: 'Fast Payment',
          },
          toAccount: {
            ...defaultFormData.toAccount,
            id: undefined,
            externalId: undefined,
          },
          beneficiary: {
            beneficiaryType: 'BSB_ACCOUNT_NUMBER',
            beneficiaryNickname: 'John Doe',
            saveBeneficiary: true,
          },
        },
        postAddBeneficiaryStatusCode: 201,
      };
      const { getByText } = render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const bannerMessage = getByText(/processed/);
      expect(bannerMessage).toBeInTheDocument();
      const beneNickname = getByText(/John Doe/);
      expect(beneNickname).toBeInTheDocument();
    });

    it('Should show payment was not processed and hide beneficiary banner', () => {
      const props = {
        ...acscResponseProps,
        makePaymentFormData: {
          ...defaultFormData,
          paymentMethod: {
            id: undefined,
            name: 'Fast Payment',
            label: 'Fast Payment',
          },
          beneficiary: {
            beneficiaryNickname: 'John Doe',
            saveBeneficiary: true,
          },
        },
        apiStatus: 400,
        postAddBeneficiaryStatusCode: 201,
      };
      const { getByText, queryByText } = render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const beneNickname = queryByText(/John Doe/);
      expect(beneNickname).not.toBeInTheDocument();
    });
  });

  // below test cases are added using copilot

  // create a test for paymentStatusReasonInformation reason InsufficientAccountBalance
  describe('should show correct banner message for paymentInformationStatus RJCT', () => {
    const rjctResponseProps = {
      ...defaultProps,
      payment: {
        ...mockPayment,
        paymentInformation: {
          ...mockPayment.paymentInformation,
          paymentInformationStatus: 'RJCT',
        },
      },
    };
    it('Should show generic payment status reason message', () => {
      const { getByText } = render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...rjctResponseProps}
          />
        </Router>
      );
      const bannerMessage = getByText(/Payment could not be processed/);
      expect(bannerMessage).toBeInTheDocument();
    });

    // test case to show message sent for authorisation if apis status is 202
    it('should show message submitted if apis status is 202', () => {
      const props = {
        ...rjctResponseProps,
        apiStatus: 202,
      };
      const { getByText } = render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const bannerMessage = getByText(/submitted/);
      expect(bannerMessage).toBeInTheDocument();
    });

    it('should show message sent for authorisation if apis status is 401 with error code 8125', () => {
      const props = {
        ...rjctResponseProps,
        apiStatus: 401,
      };
      const { getByText } = render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
            errors={[
              {
                code: 8125,
                message: 'Authoriser Approval Required',
                details: 'The request is pending approval <workflowId>',
              },
            ]}
          />
        </Router>
      );
      const bannerMessage = getByText(/sent for authorisation/);
      expect(bannerMessage).toBeInTheDocument();
    });
  });

  describe('should show appropriate banner error message for payID payments if downstream returns errors in response ', () => {
    const payIDFormData: MakePaymentFormDataType = {
      fromAccount: {
        id: '',
        name: '',
        entityName: '',
        accountType: 'Corporate investment account',
        currencyCode: '',
        currentBalance: '',
        availableBalance: '',
        overdraftLimit: '',
      },
      toDescription: '',
      fromDescription: '',
      toReference: '',

      paymentMethod: {
        id: 'npp.clear.01-sct.04',
        name: 'Fast Payment',
        label: 'Fast Payment',
      },
      toAccount: {
        id: 'd0868661-b955-4e76-9f15-d97626f7df6b',
        externalId: 'd0868661-b955-4e76-9f15-d97626f7df6b',
        nickname: 'ABC MacGyver (PayID/archived)',
        currency: 'AUD',
        org: 'office',
        type: 'PAYID',
        status: 'ARCHIVED',
        account: {
          payIDType: 'TELI',
          payIDValue: '+61-407123456',
          payIDName: 'ABC Corp',
        },
      },
      totalAmount: '123',
    };
    it('should show appropriate error message if api status is 400  with error code 2000', () => {
      const props = {
        makePaymentFormData: payIDFormData,
        payment: undefined,
        apiStatus: 400,
        errors: [
          {
            code: 2000,
            details: 'Invalid PayID',
            message: 'Invalid Input Parameter',
          },
        ],
      };
      const { getByText } = render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const bannerMessage = getByText(
        /Something went wrong. Please try again later./
      );
      expect(bannerMessage).toBeInTheDocument();
    });
    it('should show appropriate error message if api status is 400  with error code 2001', () => {
      const props = {
        makePaymentFormData: payIDFormData,
        payment: undefined,
        apiStatus: 400,
        errors: [
          {
            code: 2001,
            details: 'Downstream Error',
            message: '[{Error message from downstream}]',
          },
        ],
      };
      render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const bannerMessage = screen.getByTestId('error-banner').textContent;
      expect(bannerMessage).toBe(
        'Something went wrong. Please try again later.'
      );
    });

    it('should show appropriate error message if api status is 500  with error code 2001', () => {
      const props = {
        makePaymentFormData: payIDFormData,
        payment: undefined,
        apiStatus: 500,
        errors: [
          {
            code: 2001,
            details: 'Downstream Error',
            message: '[{Error message from downstream}]',
          },
        ],
      };
      render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const bannerMessage = screen.getByTestId('error-banner').textContent;
      expect(bannerMessage).toBe(
        'Something went wrong. Please try again later.'
      );
    });
    it('should show appropriate error message if api status is 500  with error code 10004', () => {
      const props = {
        makePaymentFormData: payIDFormData,
        payment: undefined,
        apiStatus: 500,
        errors: [
          {
            code: 10004,
            message: 'Downstream System Error',
            details: '[{Error message from downstream}]',
          },
        ],
      };
      render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const bannerMessage = screen.getByTestId('error-banner').textContent;
      expect(bannerMessage).toBe(
        'Something went wrong. Please try again later.'
      );
    });
    it('should show appropriate error message if api status is 400  with error code 2000', () => {
      const props = {
        makePaymentFormData: payIDFormData,
        payment: undefined,
        apiStatus: 500,
        errors: [
          {
            code: 2000,
            message: 'Invalid Input Parameter',
            details: 'The given {parameterName} has missing/invalid value',
          },
        ],
      };
      render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const bannerMessage = screen.getByTestId('error-banner').textContent;
      expect(bannerMessage).toBe(
        'Something went wrong. Please try again later.'
      );
    });
    it('should show appropriate error message if api status is 400 with error code 2003', () => {
      const props = {
        makePaymentFormData: payIDFormData,
        payment: undefined,
        apiStatus: 400,
        errors: [
          {
            code: 2003,
            message: 'Record Not Found.',
            details: 'No records retrieved for this request.',
          },
        ],
      };
      const { getByText } = render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const bannerMessage = getByText(
        /Something went wrong. Please try again later./
      );
      expect(bannerMessage).toBeInTheDocument();
    });
    it('should show appropriate error message if api status is 400  with error code 2004', () => {
      const props = {
        makePaymentFormData: payIDFormData,
        payment: undefined,
        apiStatus: 400,
        errors: [
          {
            code: 2004,
            message: 'Creditor Name Mismatch',
            details:
              'PayId Name and Creditor Name is not matching for this request.',
          },
        ],
      };
      const { getByText } = render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const bannerMessage = getByText(
        /PayID details for this beneficiary are not valid. Check PayID details are correct/
      );
      expect(bannerMessage).toBeInTheDocument();
    });

    it('should show entitlements error message if api status is 403 with error code 8210', () => {
      const props = {
        ...defaultProps,
        errors: [
          {
            code: 8210,
            message: 'Permission Denied',
            details: 'User not authorised to perform the action',
          },
        ],
        apiStatus: 403,
      };
      const { getByText } = render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const errorMessage = getByText(
        /You do not have permission to make this payment/
      );
      expect(errorMessage).toBeInTheDocument();
    });

    it('should not show entitlements error but other error message if api status is 403 and error code is not 8210', () => {
      const props = {
        ...defaultProps,
        errors: [
          {
            code: 1000,
            message: 'Permission Denied',
            details: 'User not authorised to perform the action',
          },
        ],
        apiStatus: 403,
      };
      render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const errorMessage = screen.queryByTestId('entitlements-error-banner');
      expect(errorMessage).not.toBeInTheDocument();
    });
  });

  describe('Division label display', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('should pass division prop when not staff portal and division label exists', () => {
      (isStaffPortal as jest.Mock).mockReturnValue(false);
      const props = {
        ...defaultProps,
        makePaymentFormData: {
          ...defaultFormData,
          division: {
            label: 'Finance Division',
            value: 'finance-001',
          },
        },
      };
      render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const divisionLabel = screen.getByTestId('division-label');
      expect(divisionLabel).toBeInTheDocument();
      expect(divisionLabel).toHaveTextContent('Finance Division');
    });

    it('should not pass division prop when staff portal is true', () => {
      (isStaffPortal as jest.Mock).mockReturnValue(true);
      const props = {
        ...defaultProps,
        makePaymentFormData: {
          ...defaultFormData,
          division: {
            label: 'Finance Division',
            value: 'finance-001',
          },
        },
      };
      render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const divisionLabel = screen.queryByTestId('division-label');
      expect(divisionLabel).not.toBeInTheDocument();
    });

    it('should not pass division prop when division label is undefined', () => {
      (isStaffPortal as jest.Mock).mockReturnValue(false);
      const props = {
        ...defaultProps,
        makePaymentFormData: {
          ...defaultFormData,
          division: undefined,
        },
      };
      render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const divisionLabel = screen.queryByTestId('division-label');
      expect(divisionLabel).not.toBeInTheDocument();
    });

    it('should not pass division prop when division has no label', () => {
      (isStaffPortal as jest.Mock).mockReturnValue(false);
      const props = {
        ...defaultProps,
        makePaymentFormData: {
          ...defaultFormData,
          division: {
            value: 'finance-001',
          },
        },
      };
      render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const divisionLabel = screen.queryByTestId('division-label');
      expect(divisionLabel).not.toBeInTheDocument();
    });

    it('should not pass division prop when division label is empty string', () => {
      (isStaffPortal as jest.Mock).mockReturnValue(false);
      const props = {
        ...defaultProps,
        makePaymentFormData: {
          ...defaultFormData,
          division: {
            label: '',
            value: 'finance-001',
          },
        },
      };
      render(
        <Router>
          <PaymentConfirmation
            lookupMismatch={defaultLookupMismatch}
            {...props}
          />
        </Router>
      );
      const divisionLabel = screen.queryByTestId('division-label');
      expect(divisionLabel).not.toBeInTheDocument();
    });
  });
});
