import { useClose } from '@mesh-tenant-multiverse-common/react';
import { MVAccountFormatter } from '@mesh-tenant-multiverse-ui-common/mv-accountformatter';
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import { MVDetailSection } from '@mesh-tenant-multiverse-ui-common/mv-detailsection';
import {
  formatBSB,
  formatCurrencyString,
  getFormattedDateTime,
  isStaffPortal,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { Button, Grid, GridItem } from '@westpac/ui';
import { useMemo } from 'react';
import { HTTP_STATUS_CODES } from '@mesh-tenant-multiverse-ui-common/mv-constants';
import {
  AccountOfBSBAndACC,
  AccountOfPayId,
  BeneTypes,
  ErrorResponse,
  LookupMismatch,
  MakePaymentFormDataType,
  NppPaymentMethod,
} from '../../common/types';
import {
  checkIsNewBeneficiary,
  checkShouldSaveNewBeneficiary,
} from '../../common/utils';
import { NppPaymentMethodMap } from '../../containers/MakePaymentContainer/common';
import { Payment } from '../../store/types';
import { AccountDetailSection } from '../AccountDetailSection';
import { NewBeneficiaryBanner } from './NewBeneficiaryBanner/NewBeneficiaryBanner';
import { PaymentBanner } from './PaymentBanner/PaymentBanner';
import { DivisionAndPaymentTo } from '../DivisionAndPaymentTo';

type PaymentConfirmationProps = {
  makePaymentFormData: MakePaymentFormDataType;
  payment?: Payment;
  apiStatus?: number;
  errors?: ErrorResponse[];
  postAddBeneficiaryStatusCode?: number;
  postAddBeneficiaryErrors?: ErrorResponse[];
  lookupMismatch: LookupMismatch;
  paymentIdentifierApiStatus?: number;
  paymentIdentifierErrors?: ErrorResponse[];
  makerCheckerPaymentId?: string;
};

function PaymentConfirmation({
  makePaymentFormData,
  payment,
  apiStatus,
  errors,
  postAddBeneficiaryStatusCode,
  postAddBeneficiaryErrors,
  lookupMismatch,
  paymentIdentifierApiStatus,
  paymentIdentifierErrors,
  makerCheckerPaymentId,
}: PaymentConfirmationProps) {
  const {
    fromAccount,
    fromDescription,
    toAccount,
    totalAmount,
    toReference,
    toDescription,
    paymentMethod,
    division,
  } = makePaymentFormData;

  const isPayID = toAccount?.type === BeneTypes.PAYID;
  const payIdAccount = toAccount?.account as AccountOfPayId;
  const bsbAccount = toAccount?.account as AccountOfBSBAndACC;

  const shouldDisplayBeneficiaryBanner =
    checkShouldSaveNewBeneficiary(makePaymentFormData) &&
    ((apiStatus && apiStatus < HTTP_STATUS_CODES.BAD_REQUEST) ||
      (apiStatus === HTTP_STATUS_CODES.UNAUTHORIZED &&
        errors?.some((err: ErrorResponse) => err.code === 8125)));

  const submittedDateTime = useMemo(
    () => getFormattedDateTime(undefined, 'h:mma'),
    []
  );

  const FromData = [
    {
      label: 'From account',
      value: fromAccount && (
        <AccountDetailSection account={fromAccount} showBalance={false} />
      ),
    },
    { label: 'Debit description', value: fromDescription || '' },
  ];

  const ToData = [
    {
      label: 'Beneficiary',
      value: toAccount && (
        <MVAccountFormatter
          details={[
            {
              label: 'Name:',
              value: toAccount?.nickname || '',
              className:
                'm-0 overflow-hidden break-words text-hero font-semibold typography-body-11',
              variant: 'text',
            },
            {
              label: isPayID ? 'PayID name:' : 'Account name:',
              value: isPayID
                ? lookupMismatch?.aliasLookupName ||
                  payIdAccount?.payIDName ||
                  ''
                : bsbAccount?.accountName,
              className: 'm-0 whitespace-normal typography-body-11 text-muted',
              variant: 'text',
            },
            {
              label: isPayID ? 'PayID:' : 'Account:',
              value:
                (isPayID
                  ? payIdAccount?.payIDValue
                  : `${formatBSB(bsbAccount?.accountId?.BSB, 3)} ${
                      bsbAccount?.accountId?.accountNumber
                    }`) ?? '',
              className: 'm-0 overflow-hidden break-words typography-body-11',
              variant: 'text',
            },
          ]}
        />
      ),
    },
  ];

  const PaymentDetailsData = [
    {
      label: 'Payment method',
      value: NppPaymentMethodMap(paymentMethod?.label),
    },
    { label: 'Amount', value: `AUD ${formatCurrencyString(totalAmount)}` },
    { label: 'Created date', value: submittedDateTime },
    { label: 'Reference', value: toReference },
    ...(paymentMethod?.label !== NppPaymentMethod.DE
      ? [{ label: 'Credit description', value: toDescription }]
      : []),
  ];

  const { closeTab } = useClose();

  const handleClose = async () => {
    await closeTab();
  };

  const getDivisionProps = () => {
    const divisionLabel = division?.label;
    if (isStaffPortal() || !divisionLabel) return {};
    return { division: divisionLabel };
  };

  return (
    <MVCard title="Payment confirmation" template="narrow">
      <Grid className="xsl:gap-0 sm:gap-0 !gap-0">
        <GridItem className="w-full" span={12}>
          <PaymentBanner
            apiStatus={apiStatus}
            errors={errors}
            makePaymentFormData={makePaymentFormData}
            payment={payment}
            makerCheckerPaymentId={makerCheckerPaymentId}
            paymentIdentifierApiStatus={paymentIdentifierApiStatus}
            paymentIdentifierErrors={paymentIdentifierErrors}
          />
        </GridItem>
        {shouldDisplayBeneficiaryBanner && (
          <NewBeneficiaryBanner
            apiStatus={postAddBeneficiaryStatusCode}
            errors={postAddBeneficiaryErrors}
            beneficiaryNickname={
              makePaymentFormData.beneficiary?.beneficiaryNickname ?? ''
            }
          />
        )}

        <DivisionAndPaymentTo
          {...getDivisionProps()}
          isNewBeneficiary={checkIsNewBeneficiary(makePaymentFormData)}
        />

        <MVDetailSection heading="From" data={FromData} />

        <MVDetailSection heading="To" data={ToData} withTopBorder />

        <MVDetailSection
          heading="Payment details"
          data={PaymentDetailsData}
          withTopBorder
        />

        <GridItem className="w-full border-t border-border pt-2.5" span={12}>
          <Button size="small" look="hero" soft onClick={handleClose}>
            Close
          </Button>
        </GridItem>
      </Grid>
    </MVCard>
  );
}

export default PaymentConfirmation;
