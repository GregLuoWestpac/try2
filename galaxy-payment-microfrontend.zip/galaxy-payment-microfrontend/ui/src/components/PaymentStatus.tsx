import { Badge, type BadgeProps } from '@westpac/ui';
import { WorkFlowStatusMap } from '../common/constants';

type PaymentStatusProps = {
  value: string;
};

type BadgeType = {
  color: BadgeProps['color'];
  noSoft?: boolean;
};

const BadgeStyle: Record<string, BadgeType> = {
  Submitted: { color: 'info' },
  Processing: { color: 'info', noSoft: true },
  Processed: { color: 'success' },
  Failed: { color: 'danger' },
  [WorkFlowStatusMap.ApprovalPending]: { color: 'info' },
  [WorkFlowStatusMap.Rejected]: { color: 'danger' },
};

function PaymentStatus({ value }: PaymentStatusProps) {
  const badgeStyle = BadgeStyle[value] || { color: 'faint' };

  return (
    <Badge
      className="break-words whitespace-normal h-auto py-0.5"
      soft={!badgeStyle.noSoft}
      color={badgeStyle.color}
    >
      {value}
    </Badge>
  );
}

export default PaymentStatus;
