/* eslint-disable jsx-a11y/label-has-associated-control */
import { useGlobalDispatch } from '@mep-ui/framework';
import { useNavigate } from '@mep-ui/framework-router-addon';
import { useClose } from '@mesh-tenant-multiverse-common/react';
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import { MVDetailSection } from '@mesh-tenant-multiverse-ui-common/mv-detailsection';
import {
  formatCurrencyString,
  getFormattedDateTime,
  isStaffPortal,
  useHandleRaiseIntent,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { DivisionAndPaymentTo } from '../DivisionAndPaymentTo';
import { Alert, Button, Grid, GridItem } from '@westpac/ui';
import { useMemo } from 'react';
import {
  CONTAINERTAB_TITLES,
  INTENT_NAMES,
  INTENTS_CONTEXT_NAME,
  PAGE_NAVIGATION,
} from '../../common/constants';
import { ErrorResponse } from '../../common/types';
import { TransferFormDataType } from '../../containers/TransferFundsContainer/common';
import { Payment } from '../../store/types';
import { AccountDetailSection } from '../AccountDetailSection';
import { useOrganizationId, useSelectedCustomer } from '../../hooks';
import {
  EntitlementsErrorMessage,
  genericErrorMessage,
  PaymentMessage,
  TransferSuccessMessage,
} from './TransferConfirmation.utils';
import useViewOptions from '../../hooks/useViewOptions';

type TransferConfirmationProps = {
  transferFundFormData: TransferFormDataType;
  transfer: Payment;
  apiStatus?: number;
  errors?: ErrorResponse[];
  paymentId: string;
  paymentIdentifierApiStatus?: number;
  paymentIdentifierErrors?: ErrorResponse[];
};

function TransferConfirmation({
  transferFundFormData,
  transfer,
  apiStatus,
  errors,
  paymentId,
  paymentIdentifierApiStatus,
  paymentIdentifierErrors,
}: TransferConfirmationProps) {
  const {
    fromAccount,
    toAccount,
    totalAmount,
    creditDescription,
    debitDescription,
    division,
  } = transferFundFormData;

  const orgId = useOrganizationId();
  const selectedCustomer = useSelectedCustomer();
  const viewOptionsPayments = useViewOptions(CONTAINERTAB_TITLES.PAYMENT);

  const handleRaiseIntent = useHandleRaiseIntent(
    useGlobalDispatch,
    useNavigate
  );

  const getDivisionProps = () => {
    const divisionLabel = division?.label;
    if (isStaffPortal() || !divisionLabel) return {};
    return { division: divisionLabel };
  };

  const viewGalaxyPayments = async () => {
    await handleRaiseIntent({
      intentName: INTENT_NAMES.VIEW_GALAXY_PAYMENTS,
      intentContextName: INTENTS_CONTEXT_NAME.PAYMENT,
      targetPath: PAGE_NAVIGATION.PAYMENT_PAGE,
      ...(isStaffPortal() && {
        contextKey: orgId ?? '',
        data: selectedCustomer ?? {},
      }),
      ...(isStaffPortal() && { viewOptions: viewOptionsPayments }),
    });
  };

  const getBannerText = () => {
    let message = genericErrorMessage;

    let bannerStyling: 'success' | 'danger' = 'danger';

    const commonTransferProps = {
      totalAmount,
      paymentId,
      onClick: viewGalaxyPayments,
    };

    if (apiStatus === 201) {
      if (transfer?.paymentInformation?.paymentInformationStatus === 'ACSC') {
        bannerStyling = 'success';
        message = (
          <TransferSuccessMessage
            {...commonTransferProps}
            action="processed"
            onClick={viewGalaxyPayments}
          />
        );
      } else if (
        transfer?.paymentInformation?.paymentInformationStatus === 'RJCT'
      ) {
        const hasInsufficientBalance =
          transfer?.paymentStatusReasonInformation.find(
            (status) => status.reason === 'InsufficientAccountBalance'
          );

        message = hasInsufficientBalance ? (
          <PaymentMessage
            message="Unable to make this transfer due to insufficient funds."
            paymentId={paymentId}
            onClick={viewGalaxyPayments}
          />
        ) : (
          <PaymentMessage
            message="Transfer could not be processed at this time."
            paymentId={paymentId}
            onClick={viewGalaxyPayments}
          />
        );
      }
    } else if (apiStatus === 202) {
      bannerStyling = 'success';
      message = (
        <TransferSuccessMessage {...commonTransferProps} action="submitted" />
      );
    } else if (
      apiStatus === 401 &&
      errors?.some((err: ErrorResponse) => err.code === 8125)
    ) {
      bannerStyling = 'success';
      message = (
        <TransferSuccessMessage
          {...commonTransferProps}
          action="sent for authorisation"
        />
      );
    } else if (
      (apiStatus === 403 &&
        errors?.some((err: ErrorResponse) => err.code === 8210)) ||
      (paymentIdentifierApiStatus === 403 &&
        paymentIdentifierErrors?.some(
          (err: ErrorResponse) => err.code === 8210
        ))
    ) {
      message = <EntitlementsErrorMessage />;
    }

    return (
      <Alert
        iconSize="small"
        id="transfer-confirmation-banner"
        look={bannerStyling}
        className="mt-2.5 mb-0 items-center"
      >
        {message}
      </Alert>
    );
  };

  const submittedDateTime = useMemo(() => {
    const originalCreationDateTime =
      transfer?.groupInformation?.originalCreationDateTime;
    return originalCreationDateTime
      ? getFormattedDateTime(originalCreationDateTime, 'h:mma')
      : getFormattedDateTime(undefined, 'h:mma');
  }, [transfer?.groupInformation?.originalCreationDateTime]);

  const FromData = [
    {
      label: 'From account',
      value: fromAccount && (
        <AccountDetailSection account={fromAccount} showBalance={false} />
      ),
    },
    { label: 'Debit description', value: debitDescription || '' },
  ];

  const ToData = [
    {
      label: 'To account',
      value: toAccount && (
        <AccountDetailSection account={toAccount} showBalance={false} />
      ),
    },
    { label: 'Credit description', value: creditDescription || '' },
  ];

  const PaymentDetailsData = [
    {
      label: 'Amount',
      value: (
        <p className="font-bold">AUD {formatCurrencyString(totalAmount)}</p>
      ),
    },
    { label: 'Submitted date', value: submittedDateTime },
  ];

  const { closeTab } = useClose();

  const handleClose = async () => {
    await closeTab();
  };

  return (
    <MVCard title="Transfer confirmation" template="narrow">
      <Grid className="xsl:gap-0 sm:gap-0 !gap-0">
        <GridItem className="w-full" span={12}>
          {getBannerText()}
        </GridItem>
        <GridItem className="w-full" span={12}>
          <DivisionAndPaymentTo {...getDivisionProps()} />
        </GridItem>

        <MVDetailSection heading="From" data={FromData} />

        <MVDetailSection heading="To" data={ToData} withTopBorder />

        <MVDetailSection
          heading="Payment details"
          data={PaymentDetailsData}
          withTopBorder
        />

        <GridItem
          className="w-full border-t border-border pt-2.5 mt-0"
          span={12}
        >
          <Button size="small" look="hero" soft onClick={handleClose}>
            Close
          </Button>
        </GridItem>
      </Grid>
    </MVCard>
  );
}

export default TransferConfirmation;
