// github copilot is used to fix errors ,modify and add new code to the existing code
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import {
  formatCurrencyString,
  getAppUrlWithParams,
  getFormattedDateTime,
  getURLParams,
  LuxonSettings,
  isStaffPortal,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { render } from '@testing-library/react';
import { usePlatformState } from '@mesh-tenant-multiverse-common/react';
import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { Payment } from '../../store/types';
import TransferConfirmation from './TransferConfirmation';

jest.mock('@mep-ui/framework', () => ({
  useGlobalDispatch: jest.fn(),
  useGlobalSelector: () => ({}),

  isLocalUrl: jest.fn(() => false),
}));

jest.mock('@mep-ui/framework-router-addon', () => ({
  useNavigate: jest.fn(),
}));

jest.mock('../DivisionAndPaymentTo', () => ({
  DivisionAndPaymentTo: ({ division }: { division?: string }) => (
    <div>{division && <span>{division}</span>}</div>
  ),
}));

(usePlatformState as jest.Mock).mockReturnValue([
  { orgId: { organisationId: 'ORG123' } },
  jest.fn(),
]);

// create a default form data
const defaultFormData = {
  fromAccount: {
    id: '',
    name: '',
    entityName: '',
    accountType: '',
    currencyCode: '',
    currentBalance: '',
    availableBalance: '',
    overdraftLimit: '',
  },
  debitDescription: '',
  creditDescription: '',
  toAccount: {
    id: '',
    name: '',
    entityName: '',
    accountType: '',
    currencyCode: '',
    currentBalance: '',
    availableBalance: '',
    overdraftLimit: '',
  },
  totalAmount: '',
};

const defaultProps = {
  transferFundFormData: defaultFormData,
  apiStatus: 201,
  paymentId: '12345678-1234-1234-1234-123456789abc',
};

const defaultTransfer = {
  creationDateTime: '',
  groupInformation: {
    groupStatus: '',
    originalControlSum: '',
    originalCreationDateTime: '',
    originalNumberOfTransactions: '',
  },
  groupStatusReasonInformation: [
    {
      reason: '',
      additionalInformation: '',
    },
  ],
  id: '',
  paymentInformation: {
    paymentInformationStatus: '',
    paymentId: '',
  },
  paymentStatusReasonInformation: [
    {
      reason: '',
      additionalInformation: '',
    },
  ],
  transactionInformation: [
    {
      transactionStatus: '',
      statusReasonInformation: [
        {
          reason: '',
          additionalInformation: '',
        },
      ],
    },
  ],
};

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  usePlatformState: jest.fn(),
  useRaiseIntent: jest.fn(),
  useClose: () => ({
    closeTab: jest.fn(),
  }),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: function MockComponent({
    title,
    children,
  }: {
    title: string;
    children: React.ReactNode;
  }) {
    return (
      <div>
        <h1>{title}</h1>
        {children}
      </div>
    );
  },
}));
jest.mock('@mesh-tenant-multiverse-ui-common/mv-detailsection', () => ({
  MVDetailSection: ({ heading, data }: { heading: string; data: any[] }) => (
    <div>
      <h2>{heading}</h2>
      {data.map(({ label, value }) => (
        <div key={label}>
          <strong>{label}</strong>
          {value}
        </div>
      ))}
    </div>
  ),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-utils'),
  useHandleRaiseIntent: jest.fn(),
  getFormattedDateTime: jest.fn(),
  formatCurrencyString: jest.fn(),
  getURLParams: jest.fn(),
  getAppUrlWithParams: jest.fn(),
  isStaffPortal: jest.fn(),
}));

describe('TransferConfirmation', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    LuxonSettings.resetCaches();
    LuxonSettings.now = () => new Date().valueOf();
    (isStaffPortal as jest.Mock).mockReturnValue(false);
  });

  it('should match snapshot', () => {
    LuxonSettings.now = () => new Date('2024-02-12T03:24:18.680Z').valueOf();
    (getFormattedDateTime as jest.Mock).mockReturnValue(
      '12 Feb 2024, 2:24pm (AEDT)'
    );
    (formatCurrencyString as jest.Mock).mockReturnValue('1,000.00');
    (getURLParams as jest.Mock).mockReturnValue('');
    (getAppUrlWithParams as jest.Mock).mockReturnValue('http://localhost/');
    const { container } = render(
      <Router>
        <TransferConfirmation
          transfer={defaultTransfer as Payment}
          {...defaultProps}
        />
      </Router>
    );
    expect(container).toMatchSnapshot();
  });

  it('Should show the heading in the page', () => {
    const { getAllByText } = render(
      <Router>
        <TransferConfirmation
          transfer={defaultTransfer as Payment}
          {...defaultProps}
        />
      </Router>
    );
    const transferDetailsTitle = getAllByText('Transfer confirmation');
    expect(transferDetailsTitle).toHaveLength(1);
  });
});

describe('Testing TransferConfirmation for apiStatus', () => {
  it('should show the success message for apiStatus 201 and paymentInformationStatus ACSC', () => {
    const { getByText } = render(
      <Router>
        <TransferConfirmation
          transfer={
            {
              ...defaultTransfer,
              paymentInformation: {
                ...defaultTransfer.paymentInformation,
                paymentInformationStatus: 'ACSC',
              },
            } as Payment
          }
          {...defaultProps}
        />
      </Router>
    );
    const successMessage = getByText(/processed/);
    expect(successMessage).toBeInTheDocument();
  });

  it('should show the generic message for apiStatus 201 and paymentInformationStatus RJCT', () => {
    const { getByText } = render(
      <Router>
        <TransferConfirmation
          transfer={
            {
              ...defaultTransfer,
              paymentInformation: {
                ...defaultTransfer.paymentInformation,
                paymentInformationStatus: 'RJCT',
              },
            } as Payment
          }
          {...defaultProps}
        />
      </Router>
    );
    expect(
      getByText('Transfer could not be processed at this time.')
    ).toBeInTheDocument();
  });

  it('should show the success message for apiStatus 202', () => {
    const { getByText } = render(
      <Router>
        <TransferConfirmation
          transfer={defaultTransfer as Payment}
          {...defaultProps}
          apiStatus={202}
        />
      </Router>
    );
    const successMessage = getByText(/submitted./);
    expect(successMessage).toBeInTheDocument();
  });

  it("should show the 'sent for authorisation' message for apiStatus 401 with error code 8125", () => {
    const { getByText } = render(
      <Router>
        <TransferConfirmation
          transfer={defaultTransfer as Payment}
          {...defaultProps}
          apiStatus={401}
          errors={[
            {
              code: 8125,
              message: 'Authoriser Approval Required',
              details: 'The request is pending approval <workflowId>',
            },
          ]}
        />
      </Router>
    );
    const successMessage = getByText(/sent for authorisation./);
    expect(successMessage).toBeInTheDocument();
  });

  it('should show the entitlements error message when apiStatus is 403 with error code 8210', () => {
    const { getByText } = render(
      <Router>
        <TransferConfirmation
          transfer={defaultTransfer as Payment}
          {...defaultProps}
          apiStatus={403}
          errors={[
            {
              code: 8210,
              message: 'Permission Denied',
              details: 'User not authorised to perform the action',
            },
          ]}
        />
      </Router>
    );
    const errorMessage = getByText(
      /You do not have permission to make this transfer./
    );
    expect(errorMessage).toBeInTheDocument();
  });

  it('should not show the entitlements error message when apiStatus is 403 but error code is not 8210', () => {
    const { queryByTestId } = render(
      <Router>
        <TransferConfirmation
          transfer={defaultTransfer as Payment}
          {...defaultProps}
          apiStatus={403}
          errors={[
            {
              code: 1110,
              message: 'Permission Denied',
              details: 'User not authorised to perform the action',
            },
          ]}
        />
      </Router>
    );
    const errorMessage = queryByTestId('entitlements-error-banner');
    expect(errorMessage).not.toBeInTheDocument();
  });
});

describe('TransferConfirmation', () => {
  it('Should show the heading in the page', () => {
    const { getByText } = render(
      <Router>
        <TransferConfirmation
          transfer={defaultTransfer as Payment}
          {...defaultProps}
        />
      </Router>
    );
    expect(getByText('Transfer confirmation')).toBeInTheDocument();
  });
});

describe('DivisionAndPaymentTo rendering', () => {
  it('should render DivisionAndPaymentTo component when division is provided and not staff portal', () => {
    const mockFormDataWithDivision = {
      ...defaultFormData,
      division: { label: 'Business Division', value: 'business-div' },
    };

    (isStaffPortal as jest.Mock).mockReturnValue(false);

    const { container, getByText } = render(
      <Router>
        <TransferConfirmation
          transfer={defaultTransfer as Payment}
          {...defaultProps}
          transferFundFormData={mockFormDataWithDivision}
        />
      </Router>
    );

    // Test by text content
    expect(getByText('Business Division')).toBeInTheDocument();
  });

  it('should not render division when division is not provided', () => {
    const mockFormDataWithoutDivision = {
      ...defaultFormData,
      division: undefined,
    };
    (isStaffPortal as jest.Mock).mockReturnValue(false);

    const { container, queryByText } = render(
      <Router>
        <TransferConfirmation
          transfer={defaultTransfer as Payment}
          {...defaultProps}
          transferFundFormData={mockFormDataWithoutDivision}
        />
      </Router>
    );

    // Test that division text is not present
    expect(queryByText('Business Division')).not.toBeInTheDocument();
  });
});
