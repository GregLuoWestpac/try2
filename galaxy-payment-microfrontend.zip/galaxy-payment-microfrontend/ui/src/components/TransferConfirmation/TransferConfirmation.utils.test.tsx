import { render, screen, fireEvent } from '@testing-library/react';
import {
  PaymentMessage,
  TransferSuccessMessage,
  EntitlementsErrorMessage,
  genericErrorMessage,
} from './TransferConfirmation.utils';

describe('PaymentMessage', () => {
  it('renders the message and payment ID correctly', () => {
    render(
      <PaymentMessage
        message="Test Message"
        paymentId="12345"
        onClick={jest.fn()}
      />
    );

    expect(screen.getByText('Test Message')).toBeInTheDocument();
    expect(screen.getByText('Payment ID:')).toBeInTheDocument();
    expect(screen.getByText('12345')).toBeInTheDocument();
  });

  it('calls onClick when the payment ID link is clicked', () => {
    const handleClick = jest.fn();
    render(
      <PaymentMessage
        message="Test Message"
        paymentId="12345"
        onClick={handleClick}
      />
    );

    const paymentLink = screen.getByText('12345');
    fireEvent.click(paymentLink);

    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it('renders the payment ID link with the correct class', () => {
    render(
      <PaymentMessage
        message="Test Message"
        paymentId="12345"
        onClick={jest.fn()}
      />
    );

    const paymentLink = screen.getByText('12345');
    expect(paymentLink).toHaveClass('cursor-pointer');
  });
});
describe('TransferSuccessMessage', () => {
  it('renders the transfer success message with the correct action and amount', () => {
    render(
      <TransferSuccessMessage
        action="processed"
        totalAmount={100}
        paymentId="67890"
        onClick={jest.fn()}
      />
    );

    expect(screen.getByText(/Your transfer of/)).toBeInTheDocument();
    expect(screen.getByText('$100.00')).toBeInTheDocument();
    expect(screen.getByText(/has been processed./)).toBeInTheDocument();
    expect(screen.getByText(/Payment ID:/)).toBeInTheDocument();
    expect(screen.getByText('67890')).toBeInTheDocument();
  });

  it('calls onClick when the payment ID link is clicked', () => {
    const handleClick = jest.fn();
    render(
      <TransferSuccessMessage
        action="completed"
        totalAmount={100}
        paymentId="67890"
        onClick={handleClick}
      />
    );

    const paymentLink = screen.getByText('67890');
    fireEvent.click(paymentLink);

    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it('renders the Payment status link when action is "sent for authorisation"', () => {
    render(
      <TransferSuccessMessage
        action="sent for authorisation"
        totalAmount={200}
        paymentId="12345"
        onClick={jest.fn()}
      />
    );

    expect(
      screen.getByText(/You can track the status from the/)
    ).toBeInTheDocument();
    expect(screen.getByText('Payment status')).toBeInTheDocument();
  });
});

describe('EntitlementsErrorMessage', () => {
  it('renders the entitlements error message', () => {
    render(<EntitlementsErrorMessage />);

    const errorBanner = screen.getByTestId('entitlements-error-banner');
    expect(errorBanner).toBeInTheDocument();
    expect(
      screen.getByText(
        'You do not have permission to make this transfer. Contact your administrator for more information.'
      )
    ).toBeInTheDocument();
  });
});

describe('genericErrorMessage', () => {
  it('renders the generic error message', () => {
    render(genericErrorMessage);

    expect(
      screen.getByText('Something went wrong. Please try again later.')
    ).toBeInTheDocument();
  });
});
