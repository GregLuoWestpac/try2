/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/anchor-is-valid */
import { formatCurrencyString } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { memo } from 'react';

type PaymentMessageProps = {
  message: string;
  paymentId: string;
  onClick: () => void;
};

type TransferSuccessMessageProps = {
  action: string;
  totalAmount: number | string;
  paymentId: string;
  onClick: () => Promise<void>;
};

const handleKeyDown = (event: React.KeyboardEvent, onClick: () => void | Promise<void>) => {
  if (event.key === 'Enter' || event.key === ' ') {
    event.preventDefault();
    onClick();
  }
};

export const PaymentMessage = ({
  message,
  paymentId,
  onClick,
}: PaymentMessageProps) => (
  <>
    <div>
      <span>{message}</span>
    </div>
    <div>
      <span>
        {'Payment ID: '}
        <a className="cursor-pointer" onClick={onClick}>
          {`${paymentId} `}
        </a>
      </span>
    </div>
  </>
);

export const TransferSuccessMessage = ({
  action,
  totalAmount,
  paymentId,
  onClick,
}: TransferSuccessMessageProps) => (
  <>
    <div>
      <span>
        Your transfer of{' '}
        <strong>${formatCurrencyString(totalAmount.toString())}</strong>
        {` has been ${action}.`}
        <br />
        {'Payment ID: '}
        <a 
          className="!decoration-success cursor-pointer" 
          onClick={onClick} 
          tabIndex={0}
          role='button'
          onKeyDown={(event) => handleKeyDown(event, onClick)}
        >
          <span className="text-success">{paymentId}</span>
        </a>
      </span>
    </div>
    {['sent for authorisation', 'submitted'].includes(action) && (
      <div>
        <span>
          {`You can track the status from the `}
          <a 
            className="!decoration-success cursor-pointer" 
            onClick={onClick}
            tabIndex={0}
            role='button'
            onKeyDown={(event) => handleKeyDown(event, onClick)}
          >
            <span className="text-success">Payment status</span>
          </a>
          {' page.'}
        </span>
      </div>
    )}
  </>
);

export const EntitlementsErrorMessage = memo(() => (
  <div data-testid="entitlements-error-banner">
    <span>
      You do not have permission to make this transfer. Contact your
      administrator for more information.
    </span>
  </div>
));

export const genericErrorMessage = (
  <div>
    <span>Something went wrong. Please try again later.</span>
  </div>
);
