import { MVInputController } from '@mesh-tenant-multiverse-ui-common/mv-reacthookform';
import { Heading } from '@westpac/ui';
import { Control, FieldErrors, FieldValues, Path } from 'react-hook-form';

type ReturnFundProps<T extends FieldValues> = {
  title: string;
  fieldId: string;
  accountType: string;
  control: Control<T>;
  errors: FieldErrors<T>;
  bsbFieldName: Path<T>;
  accountNumberFieldName: Path<T>;
  accountNameFieldName: Path<T>;
};

function ReturnFundAccountDetails<T extends FieldValues>({
  title,
  fieldId,
  accountType,
  errors,
  control,
  bsbFieldName,
  accountNumberFieldName,
  accountNameFieldName,
}: ReturnFundProps<T>) {
  return (
    <>
      <Heading tag="h2" size={7} className="mb-1">
        {title}
      </Heading>
      <Heading tag="h5" size={10} className="my-2 font-semibold">
        {accountType}
      </Heading>
      <div className="bg-light w-1/2 h-auto flex justify-between flex-col p-2.5">
        <MVInputController
          id={`${fieldId}-bsb`}
          label="BSB"
          fieldName={bsbFieldName}
          control={control}
          maximumLength={6}
          validationRules={{ required: 'Enter a valid 6-digit BSB' }}
        />
        <MVInputController
          id={`${fieldId}-acc-number`}
          label="Account number"
          fieldName={accountNumberFieldName}
          control={control}
          maximumLength={9}
          validationRules={{
            required: 'Enter an account number up to 9 digits',
          }}
        />
        <MVInputController
          id={`${fieldId}-acc-name`}
          label="Account name"
          fieldName={accountNameFieldName}
          control={control}
          maximumLength={400}
          validationRules={{ required: 'Enter the account name' }}
        />
      </div>
    </>
  );
}

export default ReturnFundAccountDetails;
