import { render, renderHook } from '@testing-library/react';
import { useForm } from 'react-hook-form';
import ReturnFundAccountDetails from './ReturnFundAccountDetails';

const { result } = renderHook(() => useForm());
const mockControl = result.current.control;

const defaultProps = {
  title: 'Return Fund Account Details',
  fieldId: 'returnFundAccount',
  accountType: 'Savings Account',
  errors: {},
  control: mockControl,
  bsbFieldName: 'bsb',
  accountNumberFieldName: 'accountNumber',
  accountNameFieldName: 'accountName',
};
jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  MVInputController: function MockComponent({
    children,
    label,
  }: {
    children: React.ReactNode;
    label: string;
  }) {
    return (
      <div>
        <div>{label}</div>
        {children}
      </div>
    );
  },
}));

describe('ReturnFundAccountDetails', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should match snapshot', () => {
    const { container } = render(
      <ReturnFundAccountDetails {...defaultProps} />
    );
    expect(container).toMatchSnapshot();
  });

  it('Should show the account labels', () => {
    const { getByText } = render(
      <ReturnFundAccountDetails {...defaultProps} />
    );
    expect(getByText('BSB')).toBeInTheDocument();
    expect(getByText('Account name')).toBeInTheDocument();
    expect(getByText('Account number')).toBeInTheDocument();
  });
});
