/* eslint-disable no-console */
import { useCallback, useEffect, useReducer } from 'react';
import {
  UseFormClearErrors,
  UseFormSetError,
  UseFormSetValue,
} from 'react-hook-form';
import {
  AccountOfBSBAndACC,
  AccountOfPayId,
  AddBeneficiaryFormDataType,
  Beneficiary,
  BeneTypes,
  ErrorResponse,
  MakePaymentFormDataType,
  PAYID_TYPE,
  PaymentMethodType,
  SchemeEligibility,
} from '../../common/types';
import { defaultPaymentMethodData } from '../../containers/MakePaymentContainer/common';
import { Account, fetchSchemeEligibilitiesParams } from '../../store/types';
import { FIELDS } from './PaymentDetails.constants';
import {
  isBsbNotRecognisedError,
  mapSchemeEligibilitiesToPaymentOptions,
} from './PaymentDetails.utils';
import { SchemeName, AUTHBIC8 } from '../../common/constants';

type PaymentMethodState = {
  paymentOptions: PaymentMethodType[];
  isLoading: boolean;
  hasError: boolean;
  hasUserChangedAccounts: boolean;
};

type PaymentMethodAction =
  | { type: 'ACCOUNTS_CHANGED' }
  | { type: 'ACCOUNTS_CLEARED' }
  | { type: 'ELIGIBILITIES_LOADING' }
  | {
      type: 'ELIGIBILITIES_SUCCESS';
      payload: {
        schemeEligibilities: SchemeEligibility[];
        toAccountType?: string;
      };
    }
  | { type: 'ELIGIBILITIES_ERROR'; payload: ErrorResponse[] }
  | { type: 'RESET' };

const initialState: PaymentMethodState = {
  paymentOptions: defaultPaymentMethodData,
  isLoading: false,
  hasError: false,
  hasUserChangedAccounts: false,
};

function paymentMethodReducer(
  state: PaymentMethodState,
  action: PaymentMethodAction
): PaymentMethodState {
  switch (action.type) {
    case 'ACCOUNTS_CHANGED':
      return {
        ...state,
        paymentOptions: defaultPaymentMethodData,
        isLoading: true,
        hasError: false,
        hasUserChangedAccounts: true,
      };

    case 'ACCOUNTS_CLEARED':
      return {
        ...state,
        paymentOptions: defaultPaymentMethodData,
        isLoading: false,
        hasError: false,
        hasUserChangedAccounts: true,
      };

    case 'ELIGIBILITIES_LOADING':
      return {
        ...state,
        isLoading: true,
        hasError: false,
      };

    case 'ELIGIBILITIES_SUCCESS':
      return {
        ...state,
        paymentOptions: mapSchemeEligibilitiesToPaymentOptions(
          action.payload.schemeEligibilities,
          action.payload.toAccountType
        ),
        isLoading: false,
        hasError: false,
      };

    case 'ELIGIBILITIES_ERROR':
      return {
        ...state,
        paymentOptions: defaultPaymentMethodData,
        isLoading: false,
        hasError: !isBsbNotRecognisedError(action.payload),
      };

    case 'RESET':
      return initialState;

    default:
      return state;
  }
}

type UsePaymentMethodSelectionProps = {
  fromAccount?: Account;
  toAccount?: Beneficiary;
  makePaymentFormData: MakePaymentFormDataType;
  schemeEligibilities: SchemeEligibility[];
  schemeEligibilityErrors?: ErrorResponse[];
  isSchemeEligibilitiesFetching: boolean;
  isSchemeEligibilitiesError: boolean;
  isAliasLookupFetching: boolean;
  doesAliasIdContainInvalidData: boolean;
  isPayIdNotValid: boolean;
  isPayIdServiceNotAvailable?: boolean;
  fetchSchemeEligibilities: (params: fetchSchemeEligibilitiesParams) => void;
  setValue: UseFormSetValue<MakePaymentFormDataType>;
  clearErrors: UseFormClearErrors<MakePaymentFormDataType>;
  setError: UseFormSetError<MakePaymentFormDataType>;
  isBsbLookupError: boolean;
  isBsbLookupFetching?: boolean;
  isNewBeneficiaryBsbLookupTriggered: boolean;
  isNewBeneficiaryPayIdLookupTriggered: boolean;
  isBeneficiaryFormOpen: boolean;
  beneficiary: AddBeneficiaryFormDataType;
};

const getPayAliasId = (beneficiary: AddBeneficiaryFormDataType) => {
  if (beneficiary.beneficiaryType === BeneTypes.PAYID) {
    const { payIdType } = beneficiary;
    switch (payIdType) {
      case PAYID_TYPE.EMAIL:
        return beneficiary.email;
      case PAYID_TYPE.PHONE:
        return beneficiary.phone;
      case PAYID_TYPE.ABN_ACN:
        return beneficiary.abnAcn;
      default:
        return beneficiary.organisationId;
    }
  }
  return undefined;
};

const isCreditorAccountValid = (
  creditorAccount: fetchSchemeEligibilitiesParams['creditorAccount']
): boolean => {
  if (!creditorAccount) return false;

  if ('payAlias' in creditorAccount) {
    return !!(
      creditorAccount.payAlias?.id &&
      creditorAccount.payAlias?.type &&
      creditorAccount.payAlias?.authBIC8
    );
  }

  if ('issuer' in creditorAccount) {
    return !!(creditorAccount.issuer && creditorAccount.schemeName);
  }

  return false;
};

export function usePaymentMethodSelection({
  fromAccount,
  toAccount,
  makePaymentFormData,
  schemeEligibilities,
  schemeEligibilityErrors,
  isSchemeEligibilitiesFetching,
  isSchemeEligibilitiesError,
  isAliasLookupFetching,
  doesAliasIdContainInvalidData,
  isPayIdNotValid,
  isPayIdServiceNotAvailable,
  fetchSchemeEligibilities,
  setValue,
  clearErrors,
  isBsbLookupFetching,
  isBsbLookupError,
  isNewBeneficiaryBsbLookupTriggered,
  isNewBeneficiaryPayIdLookupTriggered,
  isBeneficiaryFormOpen,
  beneficiary,
}: UsePaymentMethodSelectionProps) {
  const [state, dispatch] = useReducer(paymentMethodReducer, initialState);

  const isAliasLookupError =
    doesAliasIdContainInvalidData ||
    isPayIdNotValid ||
    !!isPayIdServiceNotAvailable;

  const hasLookupError = isAliasLookupError || isBsbLookupError;

  const isNewBeneficiaryPayIdLookupFetching =
    isNewBeneficiaryPayIdLookupTriggered && isAliasLookupFetching;

  const isNewBeneficiaryBsbLookupFetching =
    isNewBeneficiaryBsbLookupTriggered && isBsbLookupFetching;

  const hasSchemeEligibilitiesCreditorAccount =
    !!toAccount ||
    isNewBeneficiaryBsbLookupTriggered ||
    isNewBeneficiaryPayIdLookupTriggered;
  const hasSchemeEligibilitiesDebtorAccount = !!fromAccount;

  const isExistingBeneficiaryPayIdLookupFetching =
    toAccount?.type === BeneTypes.PAYID && isAliasLookupFetching;

  const handlePaymentFormChange = useCallback(() => {
    // Clear previously selected payment method and its errors
    clearErrors(FIELDS[2].key);
    setValue(FIELDS[2].key, undefined);

    // If either account is missing, clear accounts without showing a loading spinner
    if (
      !hasSchemeEligibilitiesDebtorAccount ||
      !hasSchemeEligibilitiesCreditorAccount ||
      hasLookupError ||
      isExistingBeneficiaryPayIdLookupFetching ||
      isNewBeneficiaryBsbLookupFetching ||
      isNewBeneficiaryPayIdLookupFetching
    ) {
      dispatch({ type: 'ACCOUNTS_CLEARED' });
      return;
    }

    // All inputs valid and available, show loading spinner and fetch eligibilities
    dispatch({ type: 'ACCOUNTS_CHANGED' });

    let creditorAccount: fetchSchemeEligibilitiesParams['creditorAccount'];

    if (isBeneficiaryFormOpen) {
      if (beneficiary?.beneficiaryType === BeneTypes.PAYID) {
        creditorAccount = {
          payAlias: {
            id: getPayAliasId(beneficiary),
            type: beneficiary?.payIdType,
            authBIC8: AUTHBIC8,
          },
        };
      } else {
        creditorAccount = {
          issuer: beneficiary?.bsb,
          schemeName: SchemeName.BBAN,
        };
      }
    } else {
      if (!toAccount) return;
      if (toAccount.type === BeneTypes.PAYID) {
        const account = toAccount.account as AccountOfPayId;
        creditorAccount = {
          payAlias: {
            id: account.payIDValue,
            type: account.payIDType,
            authBIC8: AUTHBIC8,
          },
        };
      } else {
        const account = toAccount.account as AccountOfBSBAndACC;
        const toAccountBSB = account?.accountId?.BSB;
        creditorAccount = {
          issuer: toAccountBSB,
          schemeName: SchemeName.BBAN,
        };
      }
    }

    // Validate creditor account before proceeding
    if (!isCreditorAccountValid(creditorAccount)) {
      dispatch({ type: 'ACCOUNTS_CLEARED' });
      return;
    }

    const fromAccountBSB = fromAccount.accountId?.split(' ')[0] ?? '';
    const params: fetchSchemeEligibilitiesParams = {
      debtorAccount: {
        issuer: fromAccountBSB,
        schemeName: SchemeName.BBAN,
      },
      creditorAccount,
    };

    fetchSchemeEligibilities(params);
  }, [
    fromAccount,
    toAccount,
    isAliasLookupError,
    isAliasLookupFetching,
    fetchSchemeEligibilities,
    setValue,
    clearErrors,
    isNewBeneficiaryBsbLookupTriggered,
    isNewBeneficiaryPayIdLookupTriggered,
    isBsbLookupFetching,
    isBsbLookupError,
  ]);

  // Handle loading state
  useEffect(() => {
    if (isSchemeEligibilitiesFetching && state.hasUserChangedAccounts) {
      dispatch({ type: 'ELIGIBILITIES_LOADING' });
    }
  }, [isSchemeEligibilitiesFetching, state.hasUserChangedAccounts]);

  // Handle successful eligibilities fetch
  useEffect(() => {
    if (schemeEligibilities?.length > 0 && !isSchemeEligibilitiesFetching) {
      const toAccountType = isBeneficiaryFormOpen
        ? beneficiary?.beneficiaryType
        : toAccount?.type;

      dispatch({
        type: 'ELIGIBILITIES_SUCCESS',
        payload: { schemeEligibilities, toAccountType },
      });

      // Auto-select payment method
      const updatedOptions = mapSchemeEligibilitiesToPaymentOptions(
        schemeEligibilities,
        toAccountType
      );
      if (!makePaymentFormData.paymentMethod || state.hasUserChangedAccounts) {
        setValue(FIELDS[2].key, updatedOptions[0]);
      } else {
        setValue(FIELDS[2].key, makePaymentFormData.paymentMethod);
      }
    }
  }, [
    schemeEligibilities,
    isSchemeEligibilitiesFetching,
    makePaymentFormData.paymentMethod,
    state.hasUserChangedAccounts,
    setValue,
    toAccount,
    isBeneficiaryFormOpen,
    beneficiary,
  ]);

  // Handle eligibilities error - only when accounts are still selected
  useEffect(() => {
    if (isSchemeEligibilitiesError && fromAccount && toAccount) {
      if (schemeEligibilityErrors) {
        dispatch({
          type: 'ELIGIBILITIES_ERROR',
          payload: schemeEligibilityErrors,
        });
      } else {
        dispatch({ type: 'ELIGIBILITIES_ERROR', payload: [] });
      }
    }
  }, [
    isSchemeEligibilitiesError,
    schemeEligibilityErrors,
    fromAccount,
    toAccount,
  ]);

  // Clear payment method error when accounts are cleared
  useEffect(() => {
    if (!fromAccount || !toAccount) {
      if (state.hasError) {
        dispatch({ type: 'ACCOUNTS_CLEARED' });
      }
    }
  }, [fromAccount, toAccount, state.hasError]);

  // Trigger when to/from accounts or PayID loading states change
  useEffect(() => {
    handlePaymentFormChange();
  }, [handlePaymentFormChange]);

  return {
    paymentOptions: state.paymentOptions,
    isPaymentMethodLoading: state.isLoading || isSchemeEligibilitiesFetching,
    hasPaymentMethodError: state.hasError,
    retryPaymentOptions: handlePaymentFormChange,
    hasSchemeEligibilitiesDebtorAccount,
    hasSchemeEligibilitiesCreditorAccount,
  };
}
