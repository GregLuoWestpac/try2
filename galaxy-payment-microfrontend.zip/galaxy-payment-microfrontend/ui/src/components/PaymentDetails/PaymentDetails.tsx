/* eslint-disable no-param-reassign */
/* eslint-disable @typescript-eslint/no-unnecessary-type-assertion */
/* eslint-disable @typescript-eslint/no-non-null-assertion */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable no-use-before-define */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import { type COPCheckResultData } from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
import { useUnifyClose } from '@mesh-tenant-multiverse-ui-common/mv-openfin';
import {
  MVCurrencyController,
  MVInputController,
} from '@mesh-tenant-multiverse-ui-common/mv-reacthookform';
import { MVSelectController } from '@mesh-tenant-multiverse-ui-common/mv-selectcontroller';
import {
  formatToTwoDecimals,
  isStaffPortal,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import {
  Actions,
  Resources,
  useAuthoriser,
} from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import {
  Alert,
  Button,
  Grid,
  GridItem,
  Heading,
  Link,
  Well,
} from '@westpac/ui';
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type MouseEvent,
} from 'react';
import {
  Control,
  FieldValues,
  SubmitErrorHandler,
  SubmitHandler,
  useForm,
  UseFormTrigger,
} from 'react-hook-form';
import { defaultDivisionData } from 'ui/src/containers/MakePaymentContainer/common';
import {
  BSB_LOOKUP_IN_PROGRESS_MESSAGE,
  Currency,
  INVALID_PAYID,
  MAKE_PAYMENT_PAYMENT_METHOD_HINT_TEXT,
  NoBeneficiarySelectedErrorMessage,
  PAYID_ALIAS_LOOKUP_IN_PROGRESS_MESSAGE,
  PAYID_SERVICE_UNAVAILABLE,
} from '../../common/constants';
import {
  AddBeneficiaryFormDataType,
  AliasLookupStatus,
  Beneficiary,
  BeneStatus,
  BeneTypes,
  defaultFormData,
  DivisionOptionType,
  ErrorResponse,
  LookupMismatch,
  MakePaymentFormDataType,
  NppPaymentMethod,
  SchemeEligibility,
} from '../../common/types';
import { checkIsNewBeneficiary } from '../../common/utils';
import { reviewPaymentPage } from '../../containers/MakePaymentContainer/constants';
import {
  Account,
  ArrangementDetails,
  fetchSchemeEligibilitiesParams,
  GetBSBLookupParamsPayload,
  PostAliasLookupParamsPayload,
} from '../../store/types';
import { PostAliasLookup } from '../../store/types/AliasLookup';
import { Branch } from '../../store/types/BsbLookup';
import { AccountSection } from '../AccountSection';
import { CopySwitch } from '../AccountSection/_';
import { MVCollapsiblePanelHandle } from '../AccountSection/components/MVCollapsiblePanel/MVCollapsiblePanel';
import PageLoader from '../PageLoader';
import { DESCRIPTION_VALIDATION_RULES } from '../TransferDetails/TransferDetails.constants';
import { ErrorCard } from './ErrorCard';
import { FIELDS } from './PaymentDetails.constants';
import { usePaymentMethodSelection } from './PaymentDetails.hooks';
import { getToAccountAdditionalErr } from './PaymentDetails.utils';

export type PaymentDetailsProps = {
  toBeneficiaryOptions?: Beneficiary[];
  fromAccountOptions: Account[];
  makePaymentFormData: MakePaymentFormDataType;
  handlePaymentFormDataChange: (formatData: MakePaymentFormDataType) => void;
  renderPaymentComponents: (navigateTo: string) => void;
  isBeneficiariesFetching: boolean;
  isAccountListFetching: boolean;
  aliasLookupStatus: AliasLookupStatus;
  aliasLookupName?: string;
  postAliasLookup?: (params: PostAliasLookupParamsPayload) => void;
  aliasLookupData?: PostAliasLookup[];
  isAliasLookupFetching?: boolean;
  isAliasLookupError?: boolean;
  getBsbLookup?: (payload: GetBSBLookupParamsPayload) => void;
  bsbLookupData?: Branch[];
  isBsbLookupFetching?: boolean;
  isBsbLookupError: boolean;
  bsbLookupErrorStatusCode?: number;
  isBeneficiariesError: boolean;
  isAccountListError: boolean;
  lookUpErr: string;
  lookupMismatch?: LookupMismatch;
  selectBeneficiary: (paymentAccount?: Beneficiary) => void;
  onRefresh: () => void;
  fetchSchemeEligibilities?: (params: fetchSchemeEligibilitiesParams) => void;
  schemeEligibilities: SchemeEligibility[];
  schemeEligibilityErrors?: ErrorResponse[];
  isSchemeEligibilitiesFetching: boolean;
  isSchemeEligibilitiesError: boolean;
  postArrangementDetails: (params: any) => void;
  doesAliasIdContainInvalidData: boolean;
  isPayIdNotValid: boolean;
  isPayIdLimitExceeded?: boolean;
  isPayIdServiceNotAvailable: boolean;
  isNewBeneficiaryBsbLookupTriggered: boolean;
  setIsNewBeneficiaryBsbLookupTriggered: (value: boolean) => void;
  isNewBeneficiaryPayIdLookupTriggered: boolean;
  setIsNewBeneficiaryPayIdLookupTriggered: (value: boolean) => void;
  resetLookup: () => void;
  divisions: DivisionOptionType[];
  onDivisionChange?: (selectedOption?: DivisionOptionType) => void;
  onDivisionRefresh: () => void;
  showDivisionField: boolean;
  isDivisionListFetching: boolean;
  isDivisionListError: boolean;
  allArrangementDetails?: ArrangementDetails;
  // Account Name Check (CoP) props
  postAccountNameCheck?: (params: {
    accountName: string;
    accountNumber: string;
    bsb: string;
  }) => void;
  copCheckResultData?: COPCheckResultData;
  isCopLoading?: boolean;
  isCopError?: boolean;
  shouldShowCopResults?: boolean;
  onInvalidateCopCheck?: () => void;
  isCopLimitExceeded?: boolean;
  isOrgIdFetching: boolean;
  getAccountListFn: (input?: string) => void;
  getActiveBeneficiariesFn: (input?: string) => void;
};

function PaymentDetails({
  toBeneficiaryOptions = [],
  fromAccountOptions = [],
  handlePaymentFormDataChange,
  renderPaymentComponents,
  makePaymentFormData,
  isOrgIdFetching,
  isBeneficiariesFetching,
  isAccountListFetching,
  aliasLookupStatus,
  aliasLookupName,
  postAliasLookup,
  aliasLookupData,
  isAliasLookupFetching = false,
  isAliasLookupError,
  getBsbLookup,
  bsbLookupData,
  isBsbLookupFetching = false,
  isBsbLookupError,
  bsbLookupErrorStatusCode,
  isBeneficiariesError,
  isAccountListError,
  lookUpErr,
  lookupMismatch,
  selectBeneficiary,
  onRefresh,
  fetchSchemeEligibilities = () => {},
  schemeEligibilities,
  schemeEligibilityErrors,
  isSchemeEligibilitiesFetching = false,
  isSchemeEligibilitiesError = false,
  postArrangementDetails,
  doesAliasIdContainInvalidData,
  isPayIdNotValid,
  isPayIdServiceNotAvailable,
  isPayIdLimitExceeded,
  isNewBeneficiaryBsbLookupTriggered,
  setIsNewBeneficiaryBsbLookupTriggered,
  isNewBeneficiaryPayIdLookupTriggered,
  setIsNewBeneficiaryPayIdLookupTriggered,
  resetLookup,
  divisions,
  onDivisionChange,
  onDivisionRefresh,
  showDivisionField,
  isDivisionListFetching,
  isDivisionListError,
  allArrangementDetails,
  // Account Name Check (CoP) props from container
  postAccountNameCheck,
  copCheckResultData,
  isCopLoading = false,
  isCopError = false,
  shouldShowCopResults = false,
  onInvalidateCopCheck,
  isCopLimitExceeded = false,
  getActiveBeneficiariesFn,
  getAccountListFn,
}: PaymentDetailsProps) {
  const [sameAsDebit, setSameAsDebit] = useState(false);
  const [isBeneficiaryFormOpen, setIsBeneficiaryFormOpen] = useState(false);
  const [showLookupMessage, setShowLookupMessage] = useState<
    'bsb' | 'payid' | null
  >(null);
  const [
    isNewBeneficiaryAccountValidated,
    setIsNewBeneficiaryAccountValidated,
  ] = useState(false);

  const loaderState = isOrgIdFetching;

  // initial source of toAccountId is makePaymentFormData, sample scenario is user back from payment review
  const lastSelectedToAccountIdRef = useRef<string>(
    makePaymentFormData.toAccount?.id ?? ''
  );

  const { authorised: isAuthorizedToCreateBeneficiary } = useAuthoriser(
    Resources.ACCOUNTS,
    Actions.CREATE_BENEFICIARY
  );

  // display/hide save beneficiary checkbox based on whether user is staff
  const { authorised: isUserAuthorizedToCreateBeneficiaries } = useAuthoriser(
    Resources.BENEFICIARY,
    Actions.CREATE_BENEFICIARY
  );

  const hasFormSubmitted = useRef(false);
  const lastFocusedFieldRef = useRef<HTMLElement | null>(null);

  // Track previous fetching state to detect when lookups complete
  const prevFetchingState = useRef({ bsb: false, alias: false });

  // Track lookup state for conditional auto-scroll behavior
  const lookupState = useRef<{
    triggeredByReview: boolean; // True when Review button triggered the blur
    fieldName: string | null; // Name of the field that triggered lookup
  }>({
    triggeredByReview: false,
    fieldName: null,
  });

  // Track form submission to prevent hooks from stealing focus during form validation
  const isFormSubmitting = useRef(false);

  const form = useForm<MakePaymentFormDataType>({
    mode: 'onBlur',
    reValidateMode: 'onBlur',
    defaultValues: { ...makePaymentFormData },
    shouldFocusError: false, // We handle focus manually in onError to support nested beneficiary fields
  });

  // Track the currently focused field
  useEffect(() => {
    const handleFocusChange = () => {
      const activeElement = document.activeElement as HTMLElement;
      if (activeElement && activeElement.tagName === 'INPUT') {
        lastFocusedFieldRef.current = activeElement;
      }
    };

    const handleBlur = () => {
      // Clear the ref when any field loses focus
      // This ensures we don't check stale focused fields
      setTimeout(() => {
        if (document.activeElement?.tagName !== 'INPUT') {
          lastFocusedFieldRef.current = null;
        }
      }, 0);
    };

    // Listen for focus changes
    document.addEventListener('focusin', handleFocusChange);
    document.addEventListener('focusout', handleBlur);
    return () => {
      document.removeEventListener('focusin', handleFocusChange);
      document.removeEventListener('focusout', handleBlur);
    };
  }, []);

  const {
    control,
    watch,
    setFocus,
    getFieldState,
    handleSubmit,
    trigger,
    setError,
    clearErrors,
    formState: { errors },
    getValues,
    setValue,
    reset,
  } = form;
  const watchedFormValues = watch();
  const fromAccount = getValues('fromAccount');
  const toAccount = getValues('toAccount');
  const beneficiary = getValues('beneficiary') as AddBeneficiaryFormDataType;

  const hasSchemeEligibilitiesCreditorAccount =
    !!toAccount ||
    isNewBeneficiaryBsbLookupTriggered ||
    isNewBeneficiaryPayIdLookupTriggered;

  // Determine if scheme eligibilities should be used based on conditions
  // Only use scheme eligibilities data when:
  // 1. Data has been fetched (not currently fetching)
  // 2. There are no scheme eligibility errors
  // 3. Not currently fetching scheme eligibilities
  // 4. Both fromAccount and toAccount are selected
  const shouldUseSchemeEligibilities = useMemo(
    () =>
      !isSchemeEligibilitiesFetching &&
      !isSchemeEligibilitiesError &&
      (!schemeEligibilityErrors || schemeEligibilityErrors.length === 0) &&
      schemeEligibilities.length > 0 &&
      Boolean(fromAccount) &&
      hasSchemeEligibilitiesCreditorAccount,
    [
      isSchemeEligibilitiesFetching,
      isSchemeEligibilitiesError,
      schemeEligibilityErrors,
      schemeEligibilities.length,
      fromAccount,
      hasSchemeEligibilitiesCreditorAccount,
    ]
  );

  // Determine if PayID lookup data should be used based on conditions
  // Only use PayID lookup data when:
  // 1. Data has been successfully fetched (verified or warning status)
  // 2. There are no PayID lookup errors
  // 3. To account is selected (PayID is tied to beneficiary, not from account)
  // Note: We don't require fromAccount for PayID lookup since it's beneficiary-specific
  const shouldUsePayIdLookup = useMemo(
    () =>
      ['verified', 'warning'].includes(aliasLookupStatus) &&
      !doesAliasIdContainInvalidData &&
      !isPayIdNotValid &&
      !isPayIdServiceNotAvailable &&
      Boolean(aliasLookupName) &&
      Boolean(toAccount),
    [
      aliasLookupStatus,
      doesAliasIdContainInvalidData,
      isPayIdNotValid,
      isPayIdServiceNotAvailable,
      aliasLookupName,
      toAccount,
    ]
  );

  // Determine if PayID lookup has errors that should prevent scheme eligibilities fetching
  const hasPayIdLookupErrors = useMemo(
    () =>
      Boolean(lookUpErr) ||
      doesAliasIdContainInvalidData ||
      isPayIdNotValid ||
      Boolean(isPayIdServiceNotAvailable) ||
      aliasLookupStatus === 'error',
    [
      lookUpErr,
      doesAliasIdContainInvalidData,
      isPayIdNotValid,
      isPayIdServiceNotAvailable,
      aliasLookupStatus,
    ]
  );

  const {
    paymentOptions,
    isPaymentMethodLoading,
    hasPaymentMethodError,
    retryPaymentOptions,
  } = usePaymentMethodSelection({
    fromAccount: fromAccount || undefined,
    toAccount: toAccount || undefined,
    makePaymentFormData,
    schemeEligibilities: shouldUseSchemeEligibilities
      ? schemeEligibilities
      : [],
    schemeEligibilityErrors: shouldUseSchemeEligibilities
      ? schemeEligibilityErrors
      : undefined,
    isSchemeEligibilitiesFetching,
    isSchemeEligibilitiesError,
    // Prevent scheme eligibilities fetching when PayID lookup is in progress OR has errors
    isAliasLookupFetching:
      aliasLookupStatus === 'fetching' || hasPayIdLookupErrors,
    doesAliasIdContainInvalidData: shouldUsePayIdLookup
      ? doesAliasIdContainInvalidData
      : false,
    isPayIdNotValid: shouldUsePayIdLookup ? isPayIdNotValid : false,
    isPayIdServiceNotAvailable: shouldUsePayIdLookup
      ? isPayIdServiceNotAvailable
      : false,
    fetchSchemeEligibilities,
    setValue,
    clearErrors,
    setError,
    isBsbLookupFetching,
    isBsbLookupError,
    isNewBeneficiaryBsbLookupTriggered,
    isNewBeneficiaryPayIdLookupTriggered,
    beneficiary,
    isBeneficiaryFormOpen,
  });

  const getFormHasChanged = (formData: MakePaymentFormDataType) =>
    Object.keys(formData).some(
      (key) =>
        formData[key as keyof MakePaymentFormDataType] !==
        defaultFormData[key as keyof MakePaymentFormDataType]
    );

  const formHasChanged = useMemo(
    () => getFormHasChanged(watchedFormValues),
    [watchedFormValues]
  );

  const debitDescription = watch('fromDescription');
  const creditDescription = watch('toDescription');
  const selectedPaymentMethod = watch('paymentMethod')?.label;
  const selectedDivisionLabel = watch('division')?.label;

  const shouldShowReferenceField =
    selectedPaymentMethod === NppPaymentMethod.DE;
  const shouldShowAllFields =
    selectedPaymentMethod && selectedPaymentMethod !== NppPaymentMethod.DE;
  const referenceFieldMaxLength = shouldShowReferenceField ? 18 : 35;

  // Determine when to show payment form fields based on division selection
  const showPaymentFieldsWithDivision =
    showDivisionField &&
    loaderState === false &&
    selectedDivisionLabel &&
    selectedDivisionLabel !== defaultDivisionData[0].label;

  const showDivisionLoaderForPaymentFields =
    !showPaymentFieldsWithDivision && loaderState;

  const shouldShowBottomDivider = !(isDivisionListFetching && loaderState);

  const isAccountListOrBeneficiaryListError =
    (isAccountListError &&
      selectedDivisionLabel !== defaultDivisionData[0].label) ||
    (isBeneficiariesError &&
      selectedDivisionLabel !== defaultDivisionData[0].label);

  // show loader on page :
  // For StaffPortal : when account list or beneficiary list is loading
  // For Customer Portal : if division api return empty list, division field wont be shown hence show loader when account list or beneficiary list is loading
  // For Customer Portal : if division api return non-empty list, show loader based on showDivisionLoaderForPaymentFields
  const shouldShowLoader =
    isStaffPortal() || !showDivisionField
      ? loaderState
      : showDivisionLoaderForPaymentFields;

  // show payment form fields on page :
  // For StaffPortal : when account list and beneficiary list is not loaded
  // for Customer Portal: if division api return empty list, division field wont be shown hence show payment form fields when account list and beneficiary list is not loading
  // for Customer Portal: if division api return non-empty list, show payment form fields based on showPaymentFieldsWithDivision
  const shouldShowFormFields =
    isStaffPortal() || !showDivisionField
      ? !loaderState
      : showPaymentFieldsWithDivision;

  //  Dont show buttons when loader is showing
  const shouldShowButtons = !shouldShowLoader;

  // Determine when to show the payment method spinner
  const shouldShowPaymentMethodSpinner =
    isPaymentMethodLoading &&
    (shouldUseSchemeEligibilities ||
      (isSchemeEligibilitiesFetching &&
        Boolean(fromAccount) &&
        hasSchemeEligibilitiesCreditorAccount));

  // Ensure payment method validation reflects async-loaded defaults
  // When payment options finish loading and a valid option is auto-selected,
  // re-run validation to clear any stale "required" errors shown during loading
  useEffect(() => {
    if (!isPaymentMethodLoading && fromAccount && toAccount) {
      const hasValidOptions =
        paymentOptions.length > 0 && paymentOptions[0].id !== 'select';
      const hasSelection = Boolean(selectedPaymentMethod);

      if (hasValidOptions && hasSelection && errors?.paymentMethod) {
        trigger('paymentMethod');
      }
    }
  }, [
    isPaymentMethodLoading,
    paymentOptions,
    selectedPaymentMethod,
    fromAccount,
    toAccount,
    errors?.paymentMethod,
    trigger,
  ]);

  // Initialize form with makePaymentFormData
  useEffect(() => {
    if (
      makePaymentFormData[FIELDS[0].key] &&
      !watchedFormValues[FIELDS[0].key]
    ) {
      setValue(FIELDS[0].key, makePaymentFormData[FIELDS[0].key]);
    }
  }, [makePaymentFormData, watchedFormValues, setValue]);

  // Handle lookup errors
  useEffect(() => {
    let timeoutId: NodeJS.Timeout | undefined;

    if (lookUpErr && toAccount) {
      // Only set PayID lookup errors when toAccount is still selected
      setError('toAccount', { message: lookUpErr, type: 'manual' });
      setFocus('toAccount');

      // Small delay to ensure DOM is rendered
      timeoutId = setTimeout(() => {
        const targetElement: HTMLElement | null =
          document.querySelector('.autocomplete-wrapper-toAccount input') ||
          document.querySelector('#toAccount-payment') ||
          document.querySelector('[name="toAccount"]');

        if (targetElement) {
          targetElement.focus();
          targetElement.scrollIntoView({
            behavior: 'smooth',
            block: 'center',
            inline: 'nearest',
          });
        }
      }, 100);
    } else if (
      // Only clear specific PayID errors when there's no current lookup error
      // Don't clear required field validation, and don't clear current errors
      !lookUpErr &&
      (errors.toAccount?.message === PAYID_SERVICE_UNAVAILABLE ||
        errors.toAccount?.message === INVALID_PAYID)
    ) {
      clearErrors('toAccount');
    }

    return () => {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
    };
  }, [
    lookUpErr,
    toAccount,
    errors.toAccount?.message,
    setError,
    clearErrors,
    setFocus,
  ]);

  // Clear lookup in progress message when lookups complete (transition from fetching to not fetching)
  useEffect(() => {
    const wasBsbFetching = prevFetchingState.current.bsb;
    const wasAliasFetching = prevFetchingState.current.alias;

    // Update previous state
    prevFetchingState.current = {
      bsb: isBsbLookupFetching,
      alias: isAliasLookupFetching,
    };

    // Clear message only when a lookup transitions from fetching to not fetching
    const bsbJustCompleted = wasBsbFetching && !isBsbLookupFetching;
    const aliasJustCompleted = wasAliasFetching && !isAliasLookupFetching;

    if (bsbJustCompleted || aliasJustCompleted) {
      // Clear the message if it's showing
      if (showLookupMessage !== null) {
        setShowLookupMessage(null);
      }

      // Clear the lookup state flags when lookup completes
      lookupState.current = {
        triggeredByReview: false,
        fieldName: null,
      };
    }
  }, [isAliasLookupFetching, isBsbLookupFetching, showLookupMessage]);

  // Helper function to check if an error is PayID-related
  const isPayIdError = (errorMessage?: string) => {
    if (!errorMessage || typeof errorMessage !== 'string') return false;

    // Be very specific about PayID errors to avoid clearing valid required field errors
    return (
      errorMessage === PAYID_SERVICE_UNAVAILABLE ||
      errorMessage === INVALID_PAYID ||
      (lookUpErr && errorMessage === lookUpErr) ||
      (errorMessage.includes('PayID') &&
        !errorMessage.includes('Select a beneficiary')) ||
      (errorMessage.includes('payid') &&
        !errorMessage.includes('Select a beneficiary'))
    );
  };

  // Clear PayID-related errors when toAccount is cleared, but be very careful not to interfere with validation
  useEffect(() => {
    if (
      !toAccount &&
      watchedFormValues.beneficiary?.beneficiaryType === BeneTypes.PAYID
    ) {
      // Only clear the lookup message if no lookup is currently in progress
      if (!isAliasLookupFetching && !isBsbLookupFetching) {
        setShowLookupMessage(null);
      }

      // Only clear if we have a specific PayID error, and do it only once when toAccount changes to null
      const currentError = errors.toAccount?.message;
      if (currentError && isPayIdError(currentError)) {
        clearErrors('toAccount');
        // Trigger validation after clearing PayID errors to show required field validation
        setTimeout(() => {
          trigger('toAccount');
        }, 0);
      }
    }
  }, [
    toAccount,
    clearErrors,
    trigger,
    isPayIdError,
    errors.toAccount?.message,
    watchedFormValues.beneficiary?.beneficiaryType,
    isAliasLookupFetching,
    isBsbLookupFetching,
  ]);

  // Consolidate description sync logic into single effect
  useEffect(() => {
    const fieldState = getFieldState('toDescription');

    // If credit description was manually changed and differs from debit, turn off switch
    if (fieldState.isDirty && debitDescription !== creditDescription) {
      setSameAsDebit(false);
      return;
    }

    if (sameAsDebit) {
      setValue('toDescription', debitDescription);
    }
  }, [
    debitDescription,
    creditDescription,
    sameAsDebit,
    getFieldState,
    setValue,
  ]);

  // Handle lookup mismatch scroll
  useEffect(() => {
    if (showLookupMessage === 'payid') {
      return;
    }

    if (lookupMismatch && !errors?.fromAccount && !errors?.toAccount) {
      document
        .getElementById('lookup-mismatch-banner')
        ?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [
    showLookupMessage,
    lookupMismatch,
    errors?.fromAccount,
    errors?.toAccount,
  ]);

  // Simplified payment method validation
  const paymentMethodValidationRules = {
    validate: () => {
      const hasValidPaymentMethod =
        selectedPaymentMethod && paymentOptions[0].id !== 'select';
      const hasRequiredAccounts =
        fromAccount && hasSchemeEligibilitiesCreditorAccount;

      if (!hasValidPaymentMethod || !hasRequiredAccounts) {
        return 'Select a payment method.';
      }
      return true;
    },
  };

  const divisionValidationRules = {
    validate: () => {
      const hasValidDivision =
        selectedDivisionLabel &&
        selectedDivisionLabel !== defaultDivisionData[0].label;

      if (!hasValidDivision) {
        return 'Select a division.';
      }
      return true;
    },
  };

  const onSubmit: SubmitHandler<MakePaymentFormDataType> = (data) => {
    if (!data.toAccount && data.beneficiary?.beneficiaryType) {
      const bene = data.beneficiary;
      const newToAccount: any = {
        nickname: bene.beneficiaryNickname,
        type: bene.beneficiaryType!,
        status: BeneStatus.ACTIVE,
        currency: Currency.AUD,
        externalId: '',
        id: '',
        org: '',
        account: null,
      };
      if (bene.beneficiaryType === BeneTypes.PAYID) {
        newToAccount.account = {
          payIDName: bene.payIdName ?? '', // TODO: Set payIDName after alias look up
          payIDType: bene.payIdType!,
          payIDValue:
            bene.phone || bene.email || bene.abnAcn || bene.organisationId,
        };
      } else {
        newToAccount.account = {
          accountId: {
            BSB: bene.bsb,
            accountNumber: bene.accountNumber,
          },
          accountName: bene.accountName,
          bankName: bene.bankName,
        };
      }
      data.toAccount = newToAccount;
    }
    const formattedData = {
      ...data,
      totalAmount: formatToTwoDecimals(data.totalAmount),
    };

    handlePaymentFormDataChange(formattedData);
    renderPaymentComponents(reviewPaymentPage);
  };

  const onError: SubmitErrorHandler<MakePaymentFormDataType> = (data, e) => {
    // Reset form submission flag
    isFormSubmitting.current = false;

    // Define field priority order - the order fields should be focused when errors occur
    const fieldOrder: string[] = [
      'fromAccount',
      'toAccount',
      'beneficiary.beneficiaryType',
      'beneficiary.bsb',
      'beneficiary.accountNumber',
      'beneficiary.accountName',
      'beneficiary.payIdType',
      'beneficiary.phone',
      'beneficiary.email',
      'beneficiary.abnAcn',
      'beneficiary.organisationId',
      'beneficiary.beneficiaryNickname',
      'paymentMethod',
      'totalAmount',
      'fromDescription',
      'toDescription',
      'toReference',
    ];

    // Helper function to check if a nested field has an error
    const hasError = (fieldPath: string): boolean => {
      const keys = fieldPath.split('.');

      // Use reduce to traverse nested object path
      const errorValue = keys.reduce((current: unknown, key: string) => {
        if (current && typeof current === 'object' && key in current) {
          return (current as Record<string, unknown>)[key];
        }
        return undefined;
      }, data as unknown);

      return errorValue !== undefined && errorValue !== null;
    };

    // Find the first field with an error in our defined order
    const firstErrorField = fieldOrder.find(hasError);

    if (firstErrorField) {
      // For nested fields, focus and scroll to the element
      const fieldElement = document.querySelector(
        `[name="${firstErrorField}"]`
      ) as HTMLElement;

      if (fieldElement) {
        fieldElement.focus();
        fieldElement.scrollIntoView({
          behavior: 'smooth',
          block: 'center',
          inline: 'nearest',
        });
      } else {
        // Fallback to React Hook Form's setFocus if element not found
        setFocus(firstErrorField as keyof MakePaymentFormDataType);
      }
    }
  };

  const handleSwitchChange = (isSelected: boolean) => {
    if (isSelected) {
      setValue('toDescription', watch('fromDescription'));
    }
    setSameAsDebit(isSelected);
  };

  const handleFromAccountChange = useCallback(
    (paymentAccount: Account) => {
      setValue('fromAccount', paymentAccount);
      trigger('fromAccount');
    },
    [setValue, trigger]
  );

  // Helper function to determine if PayID errors should be shown
  const getPayIdErrorForDisplay = () => {
    // Don't show PayID errors when the field is empty - let required validation take priority
    if (!toAccount) {
      return undefined;
    }

    // Don't show PayID errors if there isn't an actual lookup error
    if (!lookUpErr) {
      return undefined;
    }

    // Don't show if the form already has a required field error
    const currentFormError = errors.toAccount?.message;
    if (currentFormError === NoBeneficiarySelectedErrorMessage) {
      return undefined;
    }

    // Always show PayID errors in additionalErr to ensure visibility
    // Even if it's also set as a form error, additionalErr provides more prominent display
    // The AccountSection component will handle not showing duplicate errors in the UI
    return lookUpErr;
  };

  const handleBeneficiaryChange = useCallback(
    (paymentAccount: Beneficiary | null) => {
      // Only clear errors when selecting a new account, not when clearing
      if (paymentAccount) {
        clearErrors('toAccount');
      } else {
        clearErrors('toAccount');
        setValue('toAccount', null);
      }
      selectBeneficiary(paymentAccount || undefined);

      // Clear PayID state when clearing field, but don't touch form errors
      // Let the useEffect handle PayID error clearing, and let validation handle required errors
      if (!paymentAccount) {
        setShowLookupMessage(null);
      }
    },
    [clearErrors, setShowLookupMessage, selectBeneficiary, setValue]
  );

  const handleDivisionChange = (selectedOption?: DivisionOptionType) => {
    const resetFormData = {
      ...defaultFormData,
      division: divisions.find((d) => d.label === selectedOption?.label),
    };

    reset(resetFormData);
    // Update parent component's state with reset form data
    handlePaymentFormDataChange(resetFormData);

    // Clear any additional state
    setSameAsDebit(false);
    setShowLookupMessage(null);

    // Reset beneficiary selection
    selectBeneficiary(undefined);

    onDivisionChange?.(selectedOption);
  };

  const handlePaymentDetailsSubmit = async (
    event: MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();

    // If a lookup is currently in progress (from any trigger), wait for it
    if (isBsbLookupFetching || isAliasLookupFetching) {
      const lookupType = isBsbLookupFetching ? 'bsb' : 'payid';

      let fieldName = 'beneficiary.bsb';
      if (isAliasLookupFetching) {
        // Determine which PayID field is being used based on form values
        const formValues = getValues();
        if (formValues.beneficiary?.phone) {
          fieldName = 'beneficiary.phone';
        } else if (formValues.beneficiary?.email) {
          fieldName = 'beneficiary.email';
        } else if (formValues.beneficiary?.abnAcn) {
          fieldName = 'beneficiary.abnAcn';
        } else if (formValues.beneficiary?.organisationId) {
          fieldName = 'beneficiary.organisationId';
        }
      }

      // Set lookupState flags so auto-scroll will work when error appears
      lookupState.current = {
        triggeredByReview: true,
        fieldName,
      };

      setShowLookupMessage(lookupType);
      return;
    }

    // Only wait for lookup if we just triggered it from Review button
    // Check lookupState to see if onMouseDown set the triggeredByReview flag
    const justTriggeredLookup = lookupState.current.triggeredByReview;

    if (justTriggeredLookup) {
      // Lookup was just triggered by Review button, show message and wait
      const lookupType = lookupState.current.fieldName?.includes('bsb')
        ? 'bsb'
        : 'payid';
      setShowLookupMessage(lookupType);
      return;
    }

    // Clear any stale lookup message from previous Review click (RC-3)
    setShowLookupMessage(null);

    // Clear lookup state flags since we're proceeding with form validation
    lookupState.current = {
      triggeredByReview: false,
      fieldName: null,
    };

    hasFormSubmitted.current = true;
    isFormSubmitting.current = true;
    const fromAccountBSB = fromAccount?.accountId?.split(' ')[0] ?? '';
    const payload = {
      meta: {
        replaceEntities: ['arrangementDetails'],
      },
      params: {
        accountIds: [
          {
            BSB: fromAccountBSB,
            accountNumber: fromAccount?.accountId?.split(' ')[1] ?? '',
          },
        ],
      },
    };
    postArrangementDetails(payload);
    await handleSubmit(onSubmit, onError)();
  };

  const { closeTab } = useUnifyClose(formHasChanged);
  const handleClose = async () => {
    await closeTab();
  };

  const referenceValue = watch('toReference') || '';
  const isReferenceSliced = referenceValue.length > referenceFieldMaxLength;
  // Handle reference field length management
  useEffect(() => {
    const referenceFieldValue = getValues('toReference');
    if (referenceFieldValue.length > referenceFieldMaxLength) {
      setValue(
        'toReference',
        referenceFieldValue.slice(0, referenceFieldMaxLength)
      );
    }
  }, [selectedPaymentMethod, fromAccount, toAccount]);

  // pre-populate/sync fields based on toAccount,
  // note that "New beneficiary" button logic also resets toAccount value to null when clicked
  useEffect(() => {
    // only updates the reference and amount with bene template if it is a different toAccount
    if (lastSelectedToAccountIdRef.current !== (toAccount?.id ?? '')) {
      // no need to check and trim here because reference from bene template is already capped at lowest valid max length by design
      setValue('toReference', toAccount?.reference ?? '');
      setValue('totalAmount', toAccount?.currencyAmount?.amount ?? '');
      lastSelectedToAccountIdRef.current = toAccount?.id ?? '';
    }
  }, [toAccount, setValue]);

  const panelRef = useRef<MVCollapsiblePanelHandle>(null);

  // unhide form fields when new beneficiary fields are filled
  useEffect(() => {
    if (checkIsNewBeneficiary(makePaymentFormData)) {
      panelRef?.current?.open();
      setIsBeneficiaryFormOpen(true);

      makePaymentFormData.toAccount = null;
      setValue(FIELDS[1].key, null);
    }
  }, [makePaymentFormData]);

  const renderDivision = () => (
    <Well className="!p-2.5 w-full mt-2.5 mb-2.5 bg-light border-light">
      <MVSelectController
        control={control}
        fieldName={FIELDS[4].key}
        label={FIELDS[4].label}
        errors={errors}
        options={divisions}
        validationRules={divisionValidationRules}
        onChange={handleDivisionChange}
        width="full"
      />
    </Well>
  );

  return (
    <MVCard
      title="Make a payment"
      template="narrow"
      bottomDivider={shouldShowBottomDivider}
    >
      {isDivisionListFetching && <PageLoader iconSize="medium" />}

      {!isDivisionListFetching && (
        <form autoComplete="off" onSubmit={(event) => event.preventDefault()}>
          {isDivisionListError && (
            <ErrorCard
              onRefresh={onDivisionRefresh}
              onClickCancel={handleClose}
            />
          )}
          {/* {isAccountListOrBeneficiaryListError && !loaderState && (
            <>
              {showDivisionField && renderDivision()}
              <ErrorCard onRefresh={onRefresh} onClickCancel={handleClose} />
            </>
          )} */}

          {!isDivisionListError && (
            <>
              {showDivisionField && renderDivision()}
              {shouldShowLoader && <PageLoader iconSize="medium" />}
              {shouldShowFormFields && (
                <>
                  <AccountSection
                    title="From"
                    fieldId="fromAccount-payment"
                    fieldName={FIELDS[0].key}
                    accountSelectorLabel={FIELDS[0].label}
                    accountSelectorHintText="Search for an account."
                    descriptionLabel="Debit description"
                    descriptionFieldName="fromDescription"
                    descriptionValidationRules={DESCRIPTION_VALIDATION_RULES}
                    referenceHintText="Displays on your statement."
                    control={control as unknown as Control<FieldValues>}
                    trigger={trigger as unknown as UseFormTrigger<FieldValues>}
                    listOptions={fromAccountOptions}
                    onChangeAccount={handleFromAccountChange}
                    postArrangementDetails={postArrangementDetails}
                    allArrangementDetails={allArrangementDetails}
                    fetchDataFn={getAccountListFn}
                    loadingState={isAccountListFetching}
                    hasErrorWhenFetchingData={isAccountListError}
                  />
                  <AccountSection
                    title="To"
                    fieldId="toAccount-payment"
                    fieldName={FIELDS[1].key}
                    fieldValue={toAccount}
                    accountSelectorLabel={FIELDS[1].label}
                    accountSelectorHintText="Search for a beneficiary."
                    noAccountMessage={NoBeneficiarySelectedErrorMessage}
                    descriptionLabel="Credit description"
                    descriptionFieldName="toDescription"
                    sameAsDebit={sameAsDebit}
                    copySwitchLabel="Same as 'Debit description'"
                    postAliasLookup={postAliasLookup}
                    aliasLookupData={aliasLookupData}
                    isPayIdServiceNotAvailable={isPayIdServiceNotAvailable}
                    isPayIdLimitExceeded={isPayIdLimitExceeded}
                    isPayIdNotValid={isPayIdNotValid}
                    doesAliasIdContainInvalidData={
                      doesAliasIdContainInvalidData
                    }
                    isAliasLookupFetching={isAliasLookupFetching}
                    isAliasLookupError={isAliasLookupError}
                    getBsbLookup={getBsbLookup}
                    bsbLookupData={bsbLookupData}
                    isBsbLookupFetching={isBsbLookupFetching}
                    isBsbLookupError={isBsbLookupError}
                    bsbLookupErrorStatusCode={bsbLookupErrorStatusCode}
                    handleSwitchChange={handleSwitchChange}
                    control={control}
                    trigger={trigger}
                    additionalErr={getToAccountAdditionalErr(
                      // Use the helper function to determine PayID error display
                      getPayIdErrorForDisplay(),
                      shouldUseSchemeEligibilities
                        ? schemeEligibilityErrors
                        : undefined
                    )}
                    lookupMismatch={lookupMismatch}
                    listOptions={toBeneficiaryOptions}
                    descriptionInputType="textArea"
                    textAreaHintText="Displays on their statement."
                    onChangeAccount={handleBeneficiaryChange}
                    aliasLookupStatus={
                      // Only show PayID lookup status (including fetching) when to account is selected
                      // PayID lookup is beneficiary-specific, so from account changes don't affect it
                      // Also ensure we don't show lookup status if toAccount is cleared
                      Boolean(toAccount) &&
                      ((aliasLookupStatus === 'fetching' &&
                        Boolean(toAccount)) ||
                        shouldUsePayIdLookup)
                        ? aliasLookupStatus
                        : undefined
                    }
                    aliasLookupName={
                      shouldUsePayIdLookup ? aliasLookupName : undefined
                    }
                    hideAdditionalFields
                    showBeneficiaryForm
                    enableSaveBeneficiary={
                      isUserAuthorizedToCreateBeneficiaries
                    }
                    form={form}
                    isBeneficiaryFormOpen={isBeneficiaryFormOpen}
                    setIsBeneficiaryFormOpen={setIsBeneficiaryFormOpen}
                    panelRef={panelRef}
                    setIsNewBeneficiaryBsbLookupTriggered={
                      setIsNewBeneficiaryBsbLookupTriggered
                    }
                    setIsNewBeneficiaryPayIdLookupTriggered={
                      setIsNewBeneficiaryPayIdLookupTriggered
                    }
                    resetLookup={resetLookup}
                    lookupState={lookupState}
                    isFormSubmitting={isFormSubmitting}
                    onAccountValidationChange={
                      setIsNewBeneficiaryAccountValidated
                    }
                    isCopLoading={isCopLoading}
                    isCopError={isCopError}
                    copCheckResultData={
                      copCheckResultData as COPCheckResultData | undefined
                    }
                    shouldShowCopResults={shouldShowCopResults}
                    onInvalidateCopCheck={onInvalidateCopCheck}
                    isCopLimitExceeded={isCopLimitExceeded}
                    postAccountNameCheck={postAccountNameCheck}
                    fetchDataFn={getActiveBeneficiariesFn}
                    loadingState={isBeneficiariesFetching}
                    hasErrorWhenFetchingData={isBeneficiariesError}
                  />
                  <GridItem
                    span={12}
                    className="pt-2.5 border-b-solid border-b border-b-border"
                  >
                    <Heading className="mb-2.5" size={7} tag="h2">
                      Payment details
                    </Heading>

                    <div className="flex items-center">
                      <MVSelectController
                        control={control}
                        fieldName={FIELDS[2].key}
                        label={FIELDS[2].label}
                        errors={errors}
                        options={paymentOptions}
                        validationRules={paymentMethodValidationRules}
                        hintText={MAKE_PAYMENT_PAYMENT_METHOD_HINT_TEXT}
                        width={20}
                        className="mb-2.5"
                        supportingText={
                          !isPaymentMethodLoading &&
                          hasPaymentMethodError &&
                          fromAccount &&
                          toAccount && (
                            <Alert
                              iconSize="small"
                              look="danger"
                              className="mb-0"
                            >
                              Unable to retrieve payment method.
                              <br />
                              Please{' '}
                              <Link
                                type="inline"
                                className="cursor-pointer"
                                onPress={retryPaymentOptions}
                              >
                                try again
                              </Link>
                              .
                            </Alert>
                          )
                        }
                        showSpinner={shouldShowPaymentMethodSpinner}
                      />
                    </div>

                    <div className="mb-2.5">
                      <MVCurrencyController
                        id="total-amount-payment-details"
                        control={control as unknown as Control<FieldValues>}
                        fieldName={FIELDS[3].key}
                        errors={errors}
                        trigger={trigger}
                        className="mb-2.5"
                      />
                    </div>

                    {(shouldShowReferenceField || shouldShowAllFields) && (
                      <div className="grid grid-cols-11 !pb-0">
                        <div className="col-span-8">
                          <MVInputController
                            hint="For you and the beneficiary."
                            id="toAccount-payment-reference-description"
                            label="Reference - Optional"
                            fieldName="toReference"
                            control={control}
                            maximumLength={referenceFieldMaxLength}
                            validationRules={DESCRIPTION_VALIDATION_RULES}
                            className={isReferenceSliced ? 'mb-2' : 'mb-2.5'}
                            trimOnBlur
                            trimOnPaste
                          />

                          {isReferenceSliced && (
                            <Alert look="warning" iconSize="xsmall" mode="text">
                              Characters have been removed as 'Reference' can
                              only be up to {referenceFieldMaxLength} characters
                            </Alert>
                          )}

                          {shouldShowAllFields && (
                            <>
                              <MVInputController
                                id="toAccount-payment-description"
                                label="Credit description - Optional"
                                fieldName="toDescription"
                                hint="Displays on their statement."
                                control={control}
                                maximumLength={280}
                                multiLines
                                className="mb-2.5"
                                validationRules={DESCRIPTION_VALIDATION_RULES}
                                trimOnBlur
                                trimOnPaste
                              />

                              <CopySwitch
                                enableCopy={!!sameAsDebit}
                                copySwitchLabel="Same as 'Debit description'"
                                handleSwitchChange={handleSwitchChange}
                              />
                            </>
                          )}
                        </div>
                      </div>
                    )}
                    {showLookupMessage === 'bsb' && (
                      <Alert
                        className="mb-2.5"
                        mode="text"
                        look="danger"
                        iconSize="xsmall"
                      >
                        {BSB_LOOKUP_IN_PROGRESS_MESSAGE}
                      </Alert>
                    )}
                    {showLookupMessage === 'payid' && (
                      <Alert
                        className="mb-2.5"
                        mode="text"
                        look="danger"
                        iconSize="xsmall"
                      >
                        {PAYID_ALIAS_LOOKUP_IN_PROGRESS_MESSAGE}
                      </Alert>
                    )}
                  </GridItem>
                </>
              )}

              {shouldShowButtons && (
                <Grid>
                  <GridItem span={12}>
                    <div className="flex gap-1.5 p-0 pt-2.5">
                      <Button
                        id="review-button-payment-details"
                        name="review"
                        look="hero"
                        size="small"
                        aria-label="review button"
                        role="button"
                        type="button"
                        onMouseDown={() => {
                          // Capture the focused element BEFORE the click changes focus
                          // onMouseDown fires before focus changes, unlike onClick
                          const currentlyFocusedElement =
                            document.activeElement as HTMLInputElement;

                          if (
                            currentlyFocusedElement &&
                            currentlyFocusedElement.name
                          ) {
                            const lookupFieldsMap: Record<
                              string,
                              'bsb' | 'payid'
                            > = {
                              'beneficiary.bsb': 'bsb',
                              'beneficiary.phone': 'payid',
                              'beneficiary.email': 'payid',
                              'beneficiary.abnAcn': 'payid',
                              'beneficiary.organisationId': 'payid',
                            };

                            const lookupType =
                              lookupFieldsMap[currentlyFocusedElement.name];

                            if (lookupType) {
                              const fieldValue = currentlyFocusedElement.value;

                              // Check if lookup has already been completed successfully
                              const formValues = getValues();
                              let lookupAlreadyComplete = false;

                              if (lookupType === 'bsb') {
                                lookupAlreadyComplete =
                                  !!formValues.beneficiary?.bankName;
                              } else if (lookupType === 'payid') {
                                lookupAlreadyComplete =
                                  !!formValues.beneficiary?.accountName;
                              }

                              // Check if field has an error from a previous lookup attempt
                              const fullFieldName =
                                currentlyFocusedElement.name;
                              const fieldNameParts = fullFieldName.split('.');
                              const actualFieldName =
                                fieldNameParts.length > 1
                                  ? fieldNameParts[1]
                                  : fullFieldName;
                              const fieldError =
                                errors.beneficiary?.[
                                  actualFieldName as keyof typeof errors.beneficiary
                                ];
                              const hasFieldError =
                                fieldError &&
                                typeof fieldError === 'object' &&
                                'message' in fieldError;

                              // Trigger lookup ONLY if:
                              // 1. Lookup hasn't completed successfully (no bank name / account name)
                              // 2. Field doesn't have an error from a previous lookup attempt
                              // 3. Field value would trigger a lookup (6 digits for BSB, non-empty for PayID)
                              let shouldTriggerLookup = false;

                              if (!lookupAlreadyComplete && !hasFieldError) {
                                if (lookupType === 'bsb') {
                                  shouldTriggerLookup =
                                    fieldValue.length === 6 &&
                                    /^\d+$/.test(fieldValue);
                                } else if (lookupType === 'payid') {
                                  shouldTriggerLookup =
                                    fieldValue.trim().length > 0;
                                }
                              }

                              if (shouldTriggerLookup) {
                                // Mark that this blur was triggered by Review button
                                lookupState.current = {
                                  triggeredByReview: true,
                                  fieldName: currentlyFocusedElement.name,
                                };

                                // Show the lookup message immediately
                                setShowLookupMessage(lookupType);

                                // Mark that form is NOT being submitted yet - we're just triggering lookup
                                // The hooks will check this to decide whether to auto-scroll
                                isFormSubmitting.current = false;

                                // Trigger the blur to start the lookup
                                currentlyFocusedElement.blur();

                                // Prevent default and stop propagation to prevent onClick from running
                                return;
                              }
                            }
                          }

                          // If we get here, no lookup was triggered, so clear any stale flags
                          lookupState.current = {
                            triggeredByReview: false,
                            fieldName: null,
                          };
                        }}
                        onClick={async (e) => {
                          // Check if adding new BSB/Account beneficiary without validation
                          const formValues = getValues();
                          const isAddingNewBeneficiary =
                            isBeneficiaryFormOpen &&
                            formValues.beneficiary?.beneficiaryType ===
                              'BSB_ACCOUNT_NUMBER';

                          if (
                            isAddingNewBeneficiary &&
                            !isNewBeneficiaryAccountValidated
                          ) {
                            // Set the flag so the accountName checkDetailsRequired validator
                            // shows the "Check details" alert
                            lookupState.current = {
                              triggeredByReview: true,
                              fieldName: 'beneficiary.accountName',
                            };

                            // Run full form validation directly
                            isFormSubmitting.current = true;
                            await trigger();
                            isFormSubmitting.current = false;
                            return;
                          }

                          await handlePaymentDetailsSubmit(
                            e as React.MouseEvent<HTMLButtonElement>
                          );
                        }}
                      >
                        Review
                      </Button>
                      <Button
                        id="cancel-button-payment-details"
                        name="cancel"
                        look="hero"
                        size="small"
                        soft
                        aria-label="cancel button"
                        role="button"
                        type="button"
                        onClick={handleClose}
                      >
                        Cancel
                      </Button>
                    </div>
                  </GridItem>
                </Grid>
              )}
            </>
          )}
        </form>
      )}
    </MVCard>
  );
}

export default PaymentDetails;
