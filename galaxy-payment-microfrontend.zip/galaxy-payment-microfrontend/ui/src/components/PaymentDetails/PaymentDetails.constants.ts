import {
  getFormattedForbiddenCharacters,
  validateWithLibrary,
} from '@mesh-tenant-multiverse-ui-common/mv-injection-checker';
import { RegisterOptions } from 'react-hook-form';
import { forbiddenCharacterErrorMessage } from '../../common/constants';
import { MakePaymentFormDataType } from '../../common/types';

export const FIELDS: { key: keyof MakePaymentFormDataType; label: string }[] = [
  {
    key: 'fromAccount',
    label: 'From account',
  },
  {
    key: 'toAccount',
    label: 'Beneficiary',
  },
  {
    key: 'paymentMethod',
    label: 'Payment method',
  },
  {
    key: 'totalAmount',
    label: 'Amount',
  },
  {
    key: 'division',
    label: 'Division',
  },
];

export const DESCRIPTION_VALIDATION_RULES: RegisterOptions = {
  validate: (value: string) =>
    !validateWithLibrary(value) ||
    `${forbiddenCharacterErrorMessage} ${getFormattedForbiddenCharacters()}`,
};
