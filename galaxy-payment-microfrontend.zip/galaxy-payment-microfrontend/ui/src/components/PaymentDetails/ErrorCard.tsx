import { Button, Grid, GridItem } from '@westpac/ui';
import { FC } from 'react';
import { genericErrorMessage } from '../../common/constants';
import ErrorHandler from '../ErrorHandler/ErrorHandler';

type Props = {
  onRefresh: () => void;
  onClickCancel: () => void;
};

// eslint-disable-next-line arrow-body-style
export const ErrorCard: FC<Props> = ({ onRefresh, onClickCancel }) => (
  <Grid className="mt-2.5 !gap-0">
    <GridItem
      span={12}
      className="!pb-0 mb-2.5 border-b-solid border-b border-b-border"
    >
      <ErrorHandler
        onRefresh={onRefresh}
        errorMessage={genericErrorMessage}
        className="mb-2.5"
      />
    </GridItem>
    <GridItem span={12} className="mt-0">
      <Button
        id="cancel-button-payment-error"
        name="cancel"
        look="hero"
        size="small"
        soft
        onClick={onClickCancel}
      >
        Cancel
      </Button>
    </GridItem>
  </Grid>
);
