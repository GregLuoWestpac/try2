import { schemeEligibilitiesBsbNotRecognisedErrorMessage } from '../../common/constants';
import {
  BeneTypes,
  ErrorResponse,
  NppPaymentMethod,
  PaymentMethodType,
  SchemeEligibility,
} from '../../common/types';

export function isBsbNotRecognisedError(errors?: ErrorResponse[]) {
  if (errors) {
    const error = errors[0];
    return error && [1001, 2001].includes(error.code);
  }
  return false;
}

export function getToAccountAdditionalErr(
  lookUpErr?: string,
  schemeEligibilityErrors?: ErrorResponse[]
): string | undefined {
  let result: string | undefined;
  if (lookUpErr) {
    result = lookUpErr;
  } else if (isBsbNotRecognisedError(schemeEligibilityErrors)) {
    result = schemeEligibilitiesBsbNotRecognisedErrorMessage;
  }
  return result;
}

export function mapSchemeEligibilitiesToPaymentOptions(
  schemeEligibilities: SchemeEligibility[],
  toAccountType?: string
): PaymentMethodType[] {
  const paymentOptions = schemeEligibilities.map((eligibility) => ({
    id: eligibility?.paymentMethod?.code ?? undefined,
    name: eligibility?.paymentMethod?.description ?? '',
    label: eligibility?.paymentMethod?.description ?? '',
  }));

  // Filter out 'Pay Anyone' when toAccount type is PAYID
  if (toAccountType === BeneTypes.PAYID) {
    return paymentOptions.filter(
      (option) => option.label !== NppPaymentMethod.DE
    );
  }

  return paymentOptions;
}
