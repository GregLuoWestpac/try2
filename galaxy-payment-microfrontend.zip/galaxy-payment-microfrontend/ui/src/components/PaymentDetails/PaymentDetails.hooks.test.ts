/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { renderHook, act, waitFor } from '@testing-library/react';
import * as PaymentDetailsUtils from './PaymentDetails.utils';
import { usePaymentMethodSelection } from './PaymentDetails.hooks';
import {
  BeneTypes,
  ErrorResponse,
  SchemeEligibility,
  MakePaymentFormDataType,
  PAYID_TYPE,
} from '../../common/types';
import { Account } from '../../store/types';
import { defaultPaymentMethodData } from '../../containers/MakePaymentContainer/common';

// Mock the utility functions using factory functions to avoid hoisting issues
jest.mock('./PaymentDetails.utils', () => ({
  isBsbNotRecognisedError: jest.fn(),
  mapSchemeEligibilitiesToPaymentOptions: jest.fn(),
}));

// Import the mocked functions with proper typing

const mockIsBsbNotRecognisedError = jest.mocked(
  PaymentDetailsUtils.isBsbNotRecognisedError
);
const mockMapSchemeEligibilitiesToPaymentOptions = jest.mocked(
  PaymentDetailsUtils.mapSchemeEligibilitiesToPaymentOptions
);

describe('usePaymentMethodSelection', () => {
  const mockFetchSchemeEligibilities = jest.fn();

  const mockFromAccount: Account = {
    id: '1',
    accountId: '123456 789012',
    accountName: 'Test Account',
    accountType: 'Savings',
    currencyCode: 'AUD',
    status: 'ACTIVE',
  };

  const mockToAccountBSB = {
    id: '2',
    externalId: '2',
    nickname: 'Test BSB Account',
    currency: 'AUD',
    org: 'Test Org',
    status: 'ACTIVE' as const,
    type: BeneTypes.BSB_ACCOUNT_NUMBER,
    isDuplicated: false,
    account: {
      accountId: {
        BSB: '123456',
        accountNumber: '789012',
      },
      bankName: 'Test Bank',
      accountName: 'Test Account Name',
    },
  };

  const mockToAccountPayID = {
    id: '3',
    externalId: '3',
    nickname: 'Test PayID Account',
    currency: 'AUD',
    org: 'Test Org',
    status: 'ACTIVE' as const,
    type: BeneTypes.PAYID,
    isDuplicated: false,
    account: {
      payIDValue: 'test@example.com',
      payIDType: 'EMAL' as const,
      payIDName: 'Test PayID',
    },
  };

  const mockSchemeEligibilities: SchemeEligibility[] = [
    {
      paymentMethod: {
        code: 'npp.clear.01-x2p1.04',
        description: 'Osko',
      },
    },
    {
      paymentMethod: {
        code: 'NURG',
        description: 'Pay Anyone',
      },
    },
  ];

  const mockPaymentOptions = [
    { id: 'npp.clear.01-x2p1.04', name: 'Osko', label: 'Osko' },
    { id: 'NURG', name: 'Pay Anyone', label: 'Pay Anyone' },
  ];

  const defaultProps = {
    fromAccount: mockFromAccount,
    toAccount: mockToAccountBSB,
    makePaymentFormData: {} as MakePaymentFormDataType,
    schemeEligibilities: [],
    schemeEligibilityErrors: undefined as ErrorResponse[] | undefined,
    isSchemeEligibilitiesFetching: false,
    isSchemeEligibilitiesError: false,
    isAliasLookupFetching: false,
    doesAliasIdContainInvalidData: false,
    isPayIdNotValid: false,
    isPayIdServiceNotAvailable: false,
    fetchSchemeEligibilities: mockFetchSchemeEligibilities,
    setValue: jest.fn(),
    clearErrors: jest.fn(),
    setError: jest.fn(),
  };

  beforeEach(() => {
    jest.clearAllMocks();
    mockMapSchemeEligibilitiesToPaymentOptions.mockReturnValue(
      mockPaymentOptions
    );
    mockIsBsbNotRecognisedError.mockReturnValue(false);
    mockFetchSchemeEligibilities.mockClear();
  });

  describe('Initial state', () => {
    it('should return initial state with default payment options', () => {
      // Test with no accounts to avoid triggering handleAccountChange on mount
      const propsWithoutAccounts = {
        ...defaultProps,
        fromAccount: undefined,
        toAccount: undefined,
      };

      const { result } = renderHook(() =>
        usePaymentMethodSelection(propsWithoutAccounts)
      );

      expect(result.current.paymentOptions).toEqual(defaultPaymentMethodData);
      expect(result.current.isPaymentMethodLoading).toBe(false);
      expect(result.current.hasPaymentMethodError).toBe(false);
    });
  });

  describe('Account changes', () => {
    it('should fetch scheme eligibilities when both accounts are present', () => {
      const { result } = renderHook(() =>
        usePaymentMethodSelection(defaultProps)
      );

      act(() => {
        result.current.retryPaymentOptions();
      });

      expect(mockFetchSchemeEligibilities).toHaveBeenCalledWith({
        debtorAccount: {
          issuer: '123456',
          schemeName: 'BBAN',
        },
        creditorAccount: {
          issuer: '123456',
          schemeName: 'BBAN',
        },
      });
    });

    it('should handle PayID account type correctly', () => {
      const propsWithPayID = {
        ...defaultProps,
        toAccount: mockToAccountPayID,
      };

      const { result } = renderHook(() =>
        usePaymentMethodSelection(propsWithPayID)
      );

      act(() => {
        result.current.retryPaymentOptions();
      });

      expect(mockFetchSchemeEligibilities).toHaveBeenCalledWith({
        debtorAccount: {
          issuer: '123456',
          schemeName: 'BBAN',
        },
        creditorAccount: {
          payAlias: {
            id: 'test@example.com',
            type: 'EMAL',
            authBIC8: 'WPACAU3S',
          },
        },
      });
    });

    it('should not fetch eligibilities when accounts are missing', () => {
      const propsWithoutAccounts = {
        ...defaultProps,
        fromAccount: undefined,
        toAccount: undefined,
      };

      renderHook(() => usePaymentMethodSelection(propsWithoutAccounts));

      expect(mockFetchSchemeEligibilities).not.toHaveBeenCalled();
    });

    it('should not fetch eligibilities when isAliasLookupError is true', () => {
      const propsWithAliasLookupError = {
        ...defaultProps,
        doesAliasIdContainInvalidData: true,
      };

      renderHook(() => usePaymentMethodSelection(propsWithAliasLookupError));

      expect(mockFetchSchemeEligibilities).not.toHaveBeenCalled();
    });

    it('should not fetch eligibilities when isAliasLookupError changes to true', () => {
      const { rerender } = renderHook(
        (props) => usePaymentMethodSelection(props),
        { initialProps: defaultProps }
      );

      // Clear previous calls
      mockFetchSchemeEligibilities.mockClear();

      // Change doesAliasIdContainInvalidData to true (makes isAliasLookupError true)
      rerender({
        ...defaultProps,
        doesAliasIdContainInvalidData: true,
      });

      expect(mockFetchSchemeEligibilities).not.toHaveBeenCalled();
    });

    it('should not fetch eligibilities when alias lookup completes with error', () => {
      const { rerender } = renderHook(
        (props) => usePaymentMethodSelection(props),
        {
          initialProps: {
            ...defaultProps,
            isAliasLookupFetching: true,
          },
        }
      );

      // Clear previous calls to focus on the transition
      mockFetchSchemeEligibilities.mockClear();

      // Simulate alias lookup completing with error (isAliasLookupFetching: true -> false, doesAliasIdContainInvalidData: false -> true)
      rerender({
        ...defaultProps,
        isAliasLookupFetching: false,
        doesAliasIdContainInvalidData: true, // This makes isAliasLookupError true
      });

      // Should not fetch when lookup completes with error
      expect(mockFetchSchemeEligibilities).not.toHaveBeenCalled();
    });

    it('should clear pending fetch when isAliasLookupError becomes true even if fetching is still true', () => {
      const { rerender } = renderHook(
        (props) => usePaymentMethodSelection(props),
        {
          initialProps: {
            ...defaultProps,
            isAliasLookupFetching: true,
          },
        }
      );

      // Clear previous calls to focus on the transition
      mockFetchSchemeEligibilities.mockClear();

      // Simulate error occurring while still fetching (race condition scenario)
      rerender({
        ...defaultProps,
        isAliasLookupFetching: true, // Still fetching
        doesAliasIdContainInvalidData: true, // But error occurred
      });

      // Now simulate fetching completing
      rerender({
        ...defaultProps,
        isAliasLookupFetching: false,
        doesAliasIdContainInvalidData: true, // Error persists
      });

      // Should not fetch because error occurred and pending fetch was cleared
      expect(mockFetchSchemeEligibilities).not.toHaveBeenCalled();
    });

    it('should not fetch eligibilities when isAliasLookupFetching is true', () => {
      const propsWithAliasLookupFetching = {
        ...defaultProps,
        toAccount: mockToAccountPayID, // Use PayID account for this test
        isAliasLookupFetching: true,
      };

      renderHook(() => usePaymentMethodSelection(propsWithAliasLookupFetching));

      expect(mockFetchSchemeEligibilities).not.toHaveBeenCalled();
    });

    it('should not fetch eligibilities when isAliasLookupError is true', () => {
      const propsWithAliasLookupError = {
        ...defaultProps,
        doesAliasIdContainInvalidData: true,
      };

      renderHook(() => usePaymentMethodSelection(propsWithAliasLookupError));

      expect(mockFetchSchemeEligibilities).not.toHaveBeenCalled();
    });

    it('should fetch eligibilities when isAliasLookupFetching is false', () => {
      const propsWithAliasLookupComplete = {
        ...defaultProps,
        isAliasLookupFetching: false,
      };

      const { result } = renderHook(() =>
        usePaymentMethodSelection(propsWithAliasLookupComplete)
      );

      act(() => {
        result.current.retryPaymentOptions();
      });

      expect(mockFetchSchemeEligibilities).toHaveBeenCalledWith({
        debtorAccount: {
          issuer: '123456',
          schemeName: 'BBAN',
        },
        creditorAccount: {
          issuer: '123456',
          schemeName: 'BBAN',
        },
      });
    });

    it('should not retry payment options when isAliasLookupFetching becomes true', () => {
      const { result, rerender } = renderHook(
        (props) => usePaymentMethodSelection(props),
        {
          initialProps: {
            ...defaultProps,
            toAccount: mockToAccountPayID, // Use PayID account for this test
          },
        }
      );

      // Clear previous calls
      mockFetchSchemeEligibilities.mockClear();

      // Change isAliasLookupFetching to true
      rerender({
        ...defaultProps,
        toAccount: mockToAccountPayID,
        isAliasLookupFetching: true,
      });

      act(() => {
        result.current.retryPaymentOptions();
      });

      expect(mockFetchSchemeEligibilities).not.toHaveBeenCalled();
    });

    it('should not retry payment options when isAliasLookupError becomes true', () => {
      const { result, rerender } = renderHook(
        (props) => usePaymentMethodSelection(props),
        { initialProps: defaultProps }
      );

      // Clear previous calls
      mockFetchSchemeEligibilities.mockClear();

      // Change isAliasLookupError to true
      rerender({
        ...defaultProps,
        doesAliasIdContainInvalidData: true,
      });

      act(() => {
        result.current.retryPaymentOptions();
      });

      expect(mockFetchSchemeEligibilities).not.toHaveBeenCalled();
    });

    it('should never call fetchSchemeEligibilities when isAliasLookupError is true (simple test)', () => {
      const mockFetch = jest.fn();
      const simpleProps = {
        ...defaultProps,
        doesAliasIdContainInvalidData: true,
        fetchSchemeEligibilities: mockFetch,
      };

      const { result } = renderHook(() =>
        usePaymentMethodSelection(simpleProps)
      );

      // Try triggering in multiple ways
      act(() => {
        result.current.retryPaymentOptions();
      });

      // Rerender to trigger effects
      const { rerender } = renderHook(() =>
        usePaymentMethodSelection(simpleProps)
      );
      rerender(simpleProps);

      // Should never be called
      expect(mockFetch).not.toHaveBeenCalled();
    });

    it('should not fetch eligibilities when retryPaymentOptions is called with alias lookup error', () => {
      const propsWithAliasLookupError = {
        ...defaultProps,
        doesAliasIdContainInvalidData: true,
      };

      const { result } = renderHook(() =>
        usePaymentMethodSelection(propsWithAliasLookupError)
      );

      act(() => {
        result.current.retryPaymentOptions();
      });

      expect(mockFetchSchemeEligibilities).not.toHaveBeenCalled();
    });

    it('should not fetch eligibilities for PayID accounts when alias lookup error exists', () => {
      const propsWithPayIDError = {
        ...defaultProps,
        toAccount: mockToAccountPayID,
        doesAliasIdContainInvalidData: true,
      };

      const { result } = renderHook(() =>
        usePaymentMethodSelection(propsWithPayIDError)
      );

      act(() => {
        result.current.retryPaymentOptions();
      });

      expect(mockFetchSchemeEligibilities).not.toHaveBeenCalled();
    });

    it('should fetch eligibilities for PayID accounts when lookup completes successfully', () => {
      const { rerender } = renderHook(
        (props) => usePaymentMethodSelection(props),
        {
          initialProps: {
            ...defaultProps,
            toAccount: mockToAccountPayID,
            isAliasLookupFetching: true,
          },
        }
      );

      // Clear any initial calls
      mockFetchSchemeEligibilities.mockClear();

      // Simulate the lookup completing successfully (fetching stops, no error)
      rerender({
        ...defaultProps,
        toAccount: mockToAccountPayID,
        isAliasLookupFetching: false,
        doesAliasIdContainInvalidData: false, // No error
      });

      // Should fetch when lookup completes successfully
      expect(mockFetchSchemeEligibilities).toHaveBeenCalled();
    });

    it('should reset payment options when accounts change', () => {
      const { result, rerender } = renderHook(
        (props) => usePaymentMethodSelection(props),
        { initialProps: defaultProps }
      );

      // Change accounts to trigger reset
      const newFromAccount = { ...mockFromAccount, id: 'new-from-id' };

      rerender({
        ...defaultProps,
        fromAccount: newFromAccount,
      });

      // Should reset to default payment options initially
      expect(result.current.paymentOptions).toEqual(defaultPaymentMethodData);
    });
  });

  describe('Loading states', () => {
    it('should show loading when scheme eligibilities are fetching', () => {
      const propsWithLoading = {
        ...defaultProps,
        isSchemeEligibilitiesFetching: true,
      };

      const { result } = renderHook(() =>
        usePaymentMethodSelection(propsWithLoading)
      );

      expect(result.current.isPaymentMethodLoading).toBe(true);
    });

    it('should show loading during internal loading state', () => {
      const { result } = renderHook(() =>
        usePaymentMethodSelection(defaultProps)
      );

      act(() => {
        result.current.retryPaymentOptions();
      });

      expect(result.current.isPaymentMethodLoading).toBe(true);
    });
  });

  describe('Successful eligibilities fetch', () => {
    it('should update payment options when eligibilities are successful and not fetching', async () => {
      // Set up the mock to return the expected results
      mockMapSchemeEligibilitiesToPaymentOptions.mockReturnValue(
        mockPaymentOptions
      );

      const testProps = {
        ...defaultProps,
        fromAccount: undefined, // Remove accounts to prevent account change logic
        toAccount: undefined,
        schemeEligibilities: mockSchemeEligibilities,
        isSchemeEligibilitiesFetching: false, // Ensure not fetching
      };

      const { result } = renderHook(() => usePaymentMethodSelection(testProps));

      await waitFor(() => {
        expect(result.current.paymentOptions).toEqual(mockPaymentOptions);
      });
    });

    it('should provide payment options for new payments', async () => {
      mockMapSchemeEligibilitiesToPaymentOptions.mockReturnValue(
        mockPaymentOptions
      );

      const testProps = {
        ...defaultProps,
        fromAccount: undefined,
        toAccount: undefined,
        schemeEligibilities: mockSchemeEligibilities,
        isSchemeEligibilitiesFetching: false,
        hasExistingPaymentMethod: false,
      };

      const { result } = renderHook(() => usePaymentMethodSelection(testProps));

      await waitFor(() => {
        expect(result.current.paymentOptions).toEqual(mockPaymentOptions);
      });
    });
  });

  describe('Error handling', () => {
    it('should correctly identify BSB not recognised errors', () => {
      // Temporarily restore the real function to test its actual behavior
      const realFunction = jest.requireActual(
        './PaymentDetails.utils'
      ).isBsbNotRecognisedError;

      const bsbErrors1001: ErrorResponse[] = [
        { code: 1001, message: 'BSB not recognised' },
      ];
      const bsbErrors2001: ErrorResponse[] = [
        { code: 2001, message: 'BSB not recognised' },
      ];
      const nonBsbErrors: ErrorResponse[] = [
        { code: 500, message: 'Server error' },
      ];

      expect(realFunction(bsbErrors1001)).toBe(true);
      expect(realFunction(bsbErrors2001)).toBe(true);
      expect(realFunction(nonBsbErrors)).toBe(false);
      expect(realFunction(undefined)).toBe(false);
      // Empty array returns undefined because errors[0] is undefined
      expect(realFunction([])).toBeUndefined();
    });

    it('should correctly identify BSB not recognised errors', () => {
      // Temporarily restore the real function to test its actual behavior
      const realFunction = jest.requireActual(
        './PaymentDetails.utils'
      ).isBsbNotRecognisedError;

      const bsbErrors1001: ErrorResponse[] = [
        { code: 1001, message: 'BSB not recognised' },
      ];
      const bsbErrors2001: ErrorResponse[] = [
        { code: 2001, message: 'BSB not recognised' },
      ];
      const nonBsbErrors: ErrorResponse[] = [
        { code: 500, message: 'Server error' },
      ];

      expect(realFunction(bsbErrors1001)).toBe(true);
      expect(realFunction(bsbErrors2001)).toBe(true);
      expect(realFunction(nonBsbErrors)).toBe(false);
      expect(realFunction(undefined)).toBe(false);
      // Empty array returns undefined because errors[0] is undefined
      expect(realFunction([])).toBeUndefined();
    });

    it('should not show error when BSB not recognised error occurs', () => {
      mockIsBsbNotRecognisedError.mockReturnValue(true);

      const mockErrors: ErrorResponse[] = [
        { code: 456, message: 'BSB not recognised' },
      ];

      const propsWithBSBError = {
        ...defaultProps,
        isSchemeEligibilitiesError: true,
        schemeEligibilityErrors: mockErrors,
      };

      const { result } = renderHook(() =>
        usePaymentMethodSelection(propsWithBSBError)
      );

      expect(result.current.hasPaymentMethodError).toBe(false);
    });

    it('should not show error when BSB not recognised error occurs', () => {
      mockIsBsbNotRecognisedError.mockReturnValue(true);

      const mockErrors: ErrorResponse[] = [
        { code: 456, message: 'BSB not recognised' },
      ];

      const propsWithBSBError = {
        ...defaultProps,
        isSchemeEligibilitiesError: true,
        schemeEligibilityErrors: mockErrors,
      };

      const { result } = renderHook(() =>
        usePaymentMethodSelection(propsWithBSBError)
      );

      expect(result.current.hasPaymentMethodError).toBe(false);
    });
  });

  describe('Retry functionality', () => {
    it('should allow retrying payment options', () => {
      const { result } = renderHook(() =>
        usePaymentMethodSelection(defaultProps)
      );

      act(() => {
        result.current.retryPaymentOptions();
      });

      expect(mockFetchSchemeEligibilities).toHaveBeenCalled();
      // Should reset payment options and trigger loading state
      expect(result.current.paymentOptions).toEqual(defaultPaymentMethodData);
      expect(result.current.isPaymentMethodLoading).toBe(true);
    });
  });

  describe('Account ID changes', () => {
    it('should trigger account change when fromAccount ID changes', () => {
      const { rerender } = renderHook(
        (props) => usePaymentMethodSelection(props),
        { initialProps: defaultProps }
      );

      const newFromAccount = { ...mockFromAccount, id: 'new-from-id' };

      rerender({
        ...defaultProps,
        fromAccount: newFromAccount,
      });

      expect(mockFetchSchemeEligibilities).toHaveBeenCalled();
    });

    it('should trigger account change when toAccount ID changes', () => {
      const { rerender } = renderHook(
        (props) => usePaymentMethodSelection(props),
        { initialProps: defaultProps }
      );

      const newToAccount = { ...mockToAccountBSB, id: 'new-to-id' };

      rerender({
        ...defaultProps,
        toAccount: newToAccount,
      });

      expect(mockFetchSchemeEligibilities).toHaveBeenCalled();
    });
  });

  describe('Edge cases', () => {
    it('should handle undefined account numbers gracefully', () => {
      const accountWithoutNumber = {
        ...mockFromAccount,
        accountId: '',
      } as Account;

      const propsWithUndefinedNumber = {
        ...defaultProps,
        fromAccount: accountWithoutNumber,
      };

      const { result } = renderHook(() =>
        usePaymentMethodSelection(propsWithUndefinedNumber)
      );

      act(() => {
        result.current.retryPaymentOptions();
      });

      expect(mockFetchSchemeEligibilities).toHaveBeenCalledWith({
        debtorAccount: {
          issuer: '',
          schemeName: 'BBAN',
        },
        creditorAccount: {
          issuer: '123456',
          schemeName: 'BBAN',
        },
      });
    });

    it('should handle empty scheme eligibilities array', () => {
      const propsWithEmptyEligibilities = {
        ...defaultProps,
        schemeEligibilities: [],
      };

      const { result } = renderHook(() =>
        usePaymentMethodSelection(propsWithEmptyEligibilities)
      );

      expect(result.current.paymentOptions).toEqual(defaultPaymentMethodData);
    });
  });

  describe('Error handling when accounts are cleared', () => {
    it('should not set error when scheme eligibilities error occurs but fromAccount is cleared', async () => {
      mockIsBsbNotRecognisedError.mockReturnValue(false);

      const mockErrors: ErrorResponse[] = [
        { code: 500, message: 'Server error' },
      ];

      const { result } = renderHook(() =>
        usePaymentMethodSelection({
          ...defaultProps,
          fromAccount: undefined, // Account cleared
          toAccount: mockToAccountBSB, // Account still selected
          isSchemeEligibilitiesError: true,
          schemeEligibilityErrors: mockErrors,
        })
      );

      await waitFor(() => {
        // Error should not be set because fromAccount is cleared
        expect(result.current.hasPaymentMethodError).toBe(false);
      });
    });

    it('should not set error when scheme eligibilities error occurs but toAccount is cleared', async () => {
      mockIsBsbNotRecognisedError.mockReturnValue(false);

      const mockErrors: ErrorResponse[] = [
        { code: 500, message: 'Server error' },
      ];

      const { result } = renderHook(() =>
        usePaymentMethodSelection({
          ...defaultProps,
          fromAccount: mockFromAccount, // Account still selected
          toAccount: undefined, // Account cleared
          isSchemeEligibilitiesError: true,
          schemeEligibilityErrors: mockErrors,
        })
      );

      await waitFor(() => {
        // Error should not be set because toAccount is cleared
        expect(result.current.hasPaymentMethodError).toBe(false);
      });
    });
  });

  describe('Lookup success flows & auto-selection', () => {
    const mockSetValue = jest.fn();
    const mockClearErrors = jest.fn();
    const baseProps = {
      ...defaultProps,
      setValue: mockSetValue,
      clearErrors: mockClearErrors,
    };

    beforeEach(() => {
      mockSetValue.mockClear();
      mockClearErrors.mockClear();
    });

    it('fetches eligibilities for new beneficiary BSB form when BSB valid and lookup triggered', () => {
      renderHook(() =>
        usePaymentMethodSelection({
          ...baseProps,
          toAccount: undefined,
          fromAccount: mockFromAccount,
          isNewBeneficiaryBsbLookupTriggered: true,
          isBsbLookupFetching: false,
          isBsbLookupError: false,
          isNewBeneficiaryPayIdLookupTriggered: false,
          isBeneficiaryFormOpen: true,
          beneficiary: {
            beneficiaryType: BeneTypes.BSB_ACCOUNT_NUMBER,
            bsb: '654321',
            accountNumber: '12345678',
            accountName: 'Test',
            beneficiaryNickname: 'Nick',
            payIdType: PAYID_TYPE.EMAIL,
            email: '',
            phone: '',
            abnAcn: '',
            organisationId: '',
            saveBeneficiary: false,
          },
        })
      );

      expect(mockFetchSchemeEligibilities).toHaveBeenCalledTimes(1);
      expect(
        mockFetchSchemeEligibilities.mock.calls[0][0].creditorAccount
      ).toEqual({
        issuer: '654321',
        schemeName: 'BBAN',
      });
    });

    it('does not fetch eligibilities when PayID value missing for new beneficiary', () => {
      mockFetchSchemeEligibilities.mockClear();
      renderHook(() =>
        usePaymentMethodSelection({
          ...baseProps,
          toAccount: undefined,
          fromAccount: mockFromAccount,
          isNewBeneficiaryPayIdLookupTriggered: true,
          isNewBeneficiaryBsbLookupTriggered: false,
          isAliasLookupFetching: false,
          doesAliasIdContainInvalidData: false,
          isPayIdNotValid: false,
          isPayIdServiceNotAvailable: false,
          isBeneficiaryFormOpen: true,
          beneficiary: {
            beneficiaryType: BeneTypes.PAYID,
            payIdType: PAYID_TYPE.EMAIL,
            email: '',
            phone: '',
            abnAcn: '',
            organisationId: '',
            bsb: '',
            accountNumber: '',
            accountName: '',
            beneficiaryNickname: 'Nick',
            saveBeneficiary: false,
          },
          isBsbLookupFetching: false,
          isBsbLookupError: false,
        })
      );
      expect(mockFetchSchemeEligibilities).not.toHaveBeenCalled();
    });

    it('auto-selects first payment method when eligibilities succeed and no existing selection', async () => {
      mockMapSchemeEligibilitiesToPaymentOptions.mockReturnValue(
        mockPaymentOptions
      );
      const schemeEligibilitiesProps = {
        ...baseProps,
        schemeEligibilities: mockSchemeEligibilities,
        isSchemeEligibilitiesFetching: false,
        makePaymentFormData: {} as MakePaymentFormDataType,
        fromAccount: undefined,
        toAccount: undefined,
      };

      renderHook(() => usePaymentMethodSelection(schemeEligibilitiesProps));

      await waitFor(() => {
        expect(mockSetValue).toHaveBeenCalledWith(
          expect.any(String),
          mockPaymentOptions[0]
        );
      });
    });

    it('preserves existing payment method when eligibilities succeed and user has not changed accounts', async () => {
      mockMapSchemeEligibilitiesToPaymentOptions.mockReturnValue(
        mockPaymentOptions
      );
      const existingMethod = mockPaymentOptions[1];
      const schemeEligibilitiesProps = {
        ...baseProps,
        schemeEligibilities: mockSchemeEligibilities,
        isSchemeEligibilitiesFetching: false,
        makePaymentFormData: {
          paymentMethod: existingMethod,
        } as MakePaymentFormDataType,
        fromAccount: undefined,
        toAccount: undefined,
      };

      renderHook(() => usePaymentMethodSelection(schemeEligibilitiesProps));

      await waitFor(() => {
        // Called with existing method
        expect(mockSetValue).toHaveBeenCalledWith(
          expect.any(String),
          existingMethod
        );
      });
    });

    it('clears previously selected payment method on account change', async () => {
      const { rerender } = renderHook(
        (props) => usePaymentMethodSelection(props),
        {
          initialProps: {
            ...baseProps,
            fromAccount: mockFromAccount,
            toAccount: mockToAccountBSB,
            makePaymentFormData: {
              paymentMethod: mockPaymentOptions[0],
            } as MakePaymentFormDataType,
          },
        }
      );

      // Clear previous calls
      mockSetValue.mockClear();

      // Change toAccount to trigger handlePaymentFormChange
      const newTo = { ...mockToAccountBSB, id: 'changed-id' };
      rerender({
        ...baseProps,
        fromAccount: mockFromAccount,
        toAccount: newTo,
        makePaymentFormData: {
          paymentMethod: mockPaymentOptions[0],
        } as MakePaymentFormDataType,
      });

      await waitFor(() => {
        expect(mockSetValue).toHaveBeenCalledWith(
          expect.any(String),
          undefined
        );
      });
    });

    it('does not fetch while new beneficiary BSB lookup fetching', () => {
      mockFetchSchemeEligibilities.mockClear();
      renderHook(() =>
        usePaymentMethodSelection({
          ...baseProps,
          fromAccount: mockFromAccount,
          toAccount: undefined,
          isBeneficiaryFormOpen: true,
          isNewBeneficiaryBsbLookupTriggered: true,
          isBsbLookupFetching: true,
          isBsbLookupError: false,
          beneficiary: {
            beneficiaryType: BeneTypes.BSB_ACCOUNT_NUMBER,
            bsb: '123456',
            accountNumber: '999999',
            accountName: 'Test',
            beneficiaryNickname: 'Nick',
            payIdType: PAYID_TYPE.EMAIL,
            email: '',
            phone: '',
            abnAcn: '',
            organisationId: '',
            saveBeneficiary: false,
          },
          isNewBeneficiaryPayIdLookupTriggered: false,
        })
      );
      expect(mockFetchSchemeEligibilities).not.toHaveBeenCalled();
    });

    it('does not fetch when alias lookup error flags set individually for new PayID beneficiary', () => {
      const errorFlagCombos = [
        { doesAliasIdContainInvalidData: true },
        { isPayIdNotValid: true },
        { isPayIdServiceNotAvailable: true },
      ];

      errorFlagCombos.forEach((flags) => {
        mockFetchSchemeEligibilities.mockClear();
        renderHook(() =>
          usePaymentMethodSelection({
            ...baseProps,
            fromAccount: mockFromAccount,
            toAccount: undefined,
            isBeneficiaryFormOpen: true,
            isNewBeneficiaryPayIdLookupTriggered: true,
            isNewBeneficiaryBsbLookupTriggered: false,
            beneficiary: {
              beneficiaryType: BeneTypes.PAYID,
              payIdType: PAYID_TYPE.EMAIL,
              email: 'user@example.com',
              phone: '',
              abnAcn: '',
              organisationId: '',
              bsb: '',
              accountNumber: '',
              accountName: '',
              beneficiaryNickname: 'Nick',
              saveBeneficiary: false,
            },
            isBsbLookupFetching: false,
            isBsbLookupError: false,
            ...flags,
          })
        );
        expect(mockFetchSchemeEligibilities).not.toHaveBeenCalled();
      });
    });
  });
});
