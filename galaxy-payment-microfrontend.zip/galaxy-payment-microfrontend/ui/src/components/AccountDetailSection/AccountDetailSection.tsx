import { formatBSBFromAccNo } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { Account } from '../../store/types';

type AccountDetailSectionProps = {
  account: Account;
  showBalance?: boolean;
};

export function AccountDetailSection({
  account,
  showBalance = true,
}: AccountDetailSectionProps) {
  const { accountName, accountId } = account;

  return (
    <>
      <p className="text-hero font-bold break-words whitespace-normal overflow-hidden">
        {accountName}
      </p>
      <div className="text-text">{formatBSBFromAccNo(accountId)}</div>
    </>
  );
}

export default AccountDetailSection;
