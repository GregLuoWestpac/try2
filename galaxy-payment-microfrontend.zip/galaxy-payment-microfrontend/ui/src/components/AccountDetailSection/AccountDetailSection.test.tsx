/* eslint-disable prettier/prettier */

import { currencyFormatter } from '@mesh-tenant-multiverse-ui-common/mv-utils';

import { render } from '@testing-library/react';
import { Account } from '../../store/types';
import { AccountDetailSection as FromAcc } from './AccountDetailSection';

const fromDefaultProps: { account: Account } = {
  account: {
    id: '035845 103784254',
    accountId: '035845 103784254',
    accountName: 'Dividend',
    accountType: 'Corporate Investment Account',
    currencyCode: 'AUD',
    status: '',
  },
};

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-utils'),
  currencyFormatter: jest.fn(),
}));

describe('Testing AccountDetailSection', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should match snapshot', () => {
    (currencyFormatter as jest.Mock).mockReturnValue('-150.55');
    const { container } = render(<FromAcc {...fromDefaultProps} />);
    expect(container).toMatchSnapshot();
  });

  it('Should show the account text', () => {
    const { getByText } = render(<FromAcc {...fromDefaultProps} />);
    const nameText = getByText('Dividend');
    expect(nameText).toBeInTheDocument();
  });
});
