import { BICFI, Currency, SchemeName } from '../../common/constants';
import { BeneTypes, Beneficiary, PAYID_TYPE } from '../../common/types';
import {
  getBeneficiaryType,
  getReviewDetailsMessage,
  mapPostPaymentParams,
  mapBeneficiaries,
  getEntityNameByAccountNumber,
} from './PaymentReview.utils';

import { buildPaymentEntitlement } from '../../common/utils';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-injection-checker', () => ({
  sanitiseWithLibrary: (val: string) => val,
}));
jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  ACCOUNT_NAME_MAX_LENGTH: 140,
  ChannelTypeCode: { ONLINE: 'ONLINE' },
  convertSydneyLocalTimeToUtc: jest.fn((date: string) =>
    date ? `${date}T00:00:00.000Z` : ''
  ),
  getToday: jest.fn(() => ({
    minus: jest.fn(() => ({
      toFormat: jest.fn(() => '09/03/2025'),
    })),
    toFormat: jest.fn(() => '09/03/2025'),
  })),
}));

jest.mock('../../common/utils', () => ({
  breakDescription: (desc: string) => desc,
  getCreditorAgentBICFI: () => 'BICFI_CODE',
  getCreditorServiceLevel: () => 'SEPA',
  getInstructionPriorityForDE: () => 'HIGH',
  getSystemIdentificationDE: () => 'AUBSB',
  buildPaymentEntitlement: jest.fn(() => ({ entitlement: 'mock' })),
  checkIsNewBeneficiary: jest.fn(() => false),
}));

describe('mapPostPaymentParams', () => {
  const baseFormData = {
    toAccount: {
      type: BeneTypes.PAYID,
      id: '12345',
      nickname: 'Payee Nick',
      account: {
        payIDName: 'Payee Name',
        payIDType: 'EMAIL',
        payIDValue: 'payee@email.com',
      },
    },
    fromAccount: {
      accountName: 'Account Name',
      accountId: '123456789',
    },
    totalAmount: '100.00',
    paymentMethod: { id: 'npp.clear.01-x2p1.04', name: 'Osko', label: 'Osko' },
    toReference: 'REF123',
    toDescription: 'desc',
    fromDescription: 'from desc',
  };

  it('should map PAYID beneficiary correctly', () => {
    const result = mapPostPaymentParams(
      baseFormData as any,
      'ONLINE',
      'Debtor Entity',
      undefined,
      'payment-id-1'
    );
    expect(result.creditTransferTransactionInformation[0].creditor.name).toBe(
      'Payee Name'
    );
    expect(
      result.creditTransferTransactionInformation[0].creditorAccount
    ).toEqual({ name: 'Payee Nick' });
    expect(
      result.creditTransferTransactionInformation[0].supplementaryData
    ).toEqual({
      isNewPayee: false,
      beneficiaryId: '12345',
      aliasId: 'payee@email.com',
      aliasType: 'EMAIL',
    });
    expect(result.debtorAccount.identification).toBe('123456789');
    expect(result.debtorAccount.issuer).toBe('123456');
    expect(result.debtorAccount.schemeName).toBe(SchemeName.BBAN);
    expect(result.debtorAgent.BICFI).toBe(BICFI.WPACAU3SXXX);
    expect(result.paymentMethod).toBe('TRF');
    expect(result.supplementaryData.debitDescription).toBe('from desc');
    expect(result.supplementaryData.instructionTraceIdentification).toBe('');
  });

  it('should map BSB_AND_ACC beneficiary correctly', () => {
    const formData = {
      ...baseFormData,
      toAccount: {
        type: BeneTypes.BSB_ACCOUNT_NUMBER,
        nickname: 'Nick2',
        account: {
          accountId: {
            BSB: '123456',
            accountNumber: '987654321',
          },
          accountName: 'Acc Name',
          accountNumber: '987654321',
        },
      },
    };
    const result = mapPostPaymentParams(
      formData as any,
      'ONLINE',
      'Debtor Entity',
      undefined,
      'payment-id-2'
    );
    expect(result.creditTransferTransactionInformation[0].creditor.name).toBe(
      'Acc Name'
    );
    expect(
      result.creditTransferTransactionInformation[0].creditorAccount
    ).toEqual({
      identification: '123456987654321',
      issuer: '123456',
      schemeName: SchemeName.BBAN,
      name: 'Nick2',
    });
    expect(
      result.creditTransferTransactionInformation[0].supplementaryData
    ).toEqual({
      isNewPayee: false,
    });
  });

  it('should include matchedCOPAccountName in supplementaryData when provided', () => {
    const result = mapPostPaymentParams(
      baseFormData as any,
      'ONLINE',
      'Debtor Entity',
      undefined,
      'payment-id-3',
      'John Doe'
    );
    expect(result.supplementaryData.matchedCOPAccountName).toBe('John Doe');
  });

  it('should not include matchedCOPAccountName in supplementaryData when not provided', () => {
    const result = mapPostPaymentParams(
      baseFormData as any,
      'ONLINE',
      'Debtor Entity',
      undefined,
      'payment-id-4'
    );
    expect(result.supplementaryData.matchedCOPAccountName).toBeUndefined();
  });

  it('should include matchedCOPStatusCode in supplementaryData when provided', () => {
    const result = mapPostPaymentParams(
      baseFormData as any,
      'ONLINE',
      'Debtor Entity',
      undefined,
      'payment-id-5',
      undefined,
      'MTCH'
    );
    expect(result.supplementaryData.matchedCOPStatusCode).toBe('MTCH');
  });

  it('should not include matchedCOPStatusCode in supplementaryData when not provided', () => {
    const result = mapPostPaymentParams(
      baseFormData as any,
      'ONLINE',
      'Debtor Entity',
      undefined,
      'payment-id-6'
    );
    expect(result.supplementaryData.matchedCOPStatusCode).toBeUndefined();
  });

  it('should include both matchedCOPAccountName and matchedCOPStatusCode when provided', () => {
    const result = mapPostPaymentParams(
      baseFormData as any,
      'ONLINE',
      'Debtor Entity',
      undefined,
      'payment-id-7',
      'Jane Smith',
      'MTCH'
    );
    expect(result.supplementaryData.matchedCOPAccountName).toBe('Jane Smith');
    expect(result.supplementaryData.matchedCOPStatusCode).toBe('MTCH');
  });

  it('should call buildPaymentEntitlement with matchedCOPColour when provided', () => {
    mapPostPaymentParams(
      baseFormData as any,
      'ONLINE',
      'Debtor Entity',
      undefined,
      'payment-id-8',
      'Test Name',
      'MTCH',
      'GREEN'
    );
    expect(buildPaymentEntitlement).toHaveBeenCalledWith(
      baseFormData,
      'payment-id-8',
      'GREEN'
    );
  });

  it('should call buildPaymentEntitlement without matchedCOPColour when not provided', () => {
    mapPostPaymentParams(
      baseFormData as any,
      'ONLINE',
      'Debtor Entity',
      undefined,
      'payment-id-9'
    );
    expect(buildPaymentEntitlement).toHaveBeenCalledWith(
      baseFormData,
      'payment-id-9',
      undefined
    );
  });
});

describe('getBeneficiaryType', () => {
  it('should return payID for PAYID type', () => {
    const beneficiary = { type: BeneTypes.PAYID } as Beneficiary;
    expect(getBeneficiaryType(beneficiary)).toBe('pay-id');
  });

  it('should return other for BSB_AND_ACC type', () => {
    const beneficiary = { type: BeneTypes.BSB_ACCOUNT_NUMBER } as Beneficiary;
    expect(getBeneficiaryType(beneficiary)).toBe('other');
  });

  it('should return other for null or undefined', () => {
    expect(getBeneficiaryType(null)).toBe('other');
    expect(getBeneficiaryType(undefined)).toBe('other');
  });
});

describe('messages', () => {
  it('correct message is shown given the payment details type', () => {
    expect(getReviewDetailsMessage('pay-id')).toEqual(
      `Before sending for authorisation, check the PayID details. Incorrect details may mean the wrong account is paid and it may not be possible to recover the funds.`
    );
    expect(getReviewDetailsMessage('other')).toEqual(
      `Before sending for authorisation, check the BSB and account number. Account names
              are not used to process payments, so an incorrect BSB or account
              number may mean the wrong account is paid and it may not be
              possible to recover the funds.`
    );
  });
});

describe('mapBeneficiaries', () => {
  it('should map PayID beneficiary correctly', () => {
    const formData = {
      totalAmount: '100.00',
      beneficiary: {
        beneficiaryType: 'PAYID' as any,
        beneficiaryNickname: 'Test PayID',
        payIdType: PAYID_TYPE.EMAIL,
        email: 'test@example.com',
        payIdName: 'Test Corp',
        phone: '',
        abnAcn: '',
        organisationId: '',
      },
    } as any;

    const result = mapBeneficiaries(formData);

    expect(result).toHaveLength(1);
    expect(result[0].nickname).toBe('Test PayID');
    expect(result[0].currencyAmount.currencyCode).toBe(Currency.AUD);
    expect(result[0].type).toBe('PAYID');
    expect(result[0].account).toEqual({
      payIDName: 'Test Corp',
      payIDType: PAYID_TYPE.EMAIL,
      payIDValue: 'test@example.com',
    });
  });

  it('should map BSB/Account beneficiary correctly', () => {
    const formData = {
      totalAmount: '250.50',
      beneficiary: {
        beneficiaryType: 'BSB_ACCOUNT_NUMBER' as any,
        beneficiaryNickname: 'Test BSB Account',
        bsb: '123456',
        accountNumber: '987654321',
        accountName: 'My Account',
        bankName: 'Test Bank',
      },
    } as any;

    const result = mapBeneficiaries(formData);

    expect(result).toHaveLength(1);
    expect(result[0].nickname).toBe('Test BSB Account');
    expect(result[0].type).toBe('BSB_ACCOUNT_NUMBER');
    expect(result[0].account).toEqual({
      accountId: {
        BSB: '123456',
        accountNumber: '987654321',
      },
      accountName: 'My Account',
      bankName: 'Test Bank',
    });
  });

  it('should handle phone PayID type with formatting', () => {
    const formData = {
      totalAmount: '75.00',
      beneficiary: {
        beneficiaryType: 'PAYID' as any,
        beneficiaryNickname: 'Phone PayID',
        payIdType: PAYID_TYPE.PHONE,
        phone: '+61 407 123 456',
        email: '',
        abnAcn: '',
        organisationId: '',
      },
    } as any;

    const result = mapBeneficiaries(formData);

    expect(result[0].account).toEqual({
      payIDName: '',
      payIDType: PAYID_TYPE.PHONE,
      payIDValue: '+61407123456', // Spaces removed
    });
  });

  it('should handle ABN/ACN PayID type', () => {
    const formData = {
      totalAmount: '150.00',
      beneficiary: {
        beneficiaryType: 'PAYID' as any,
        beneficiaryNickname: 'ABN PayID',
        payIdType: PAYID_TYPE.ABN_ACN,
        abnAcn: '12345678901',
        phone: '',
        email: '',
        organisationId: '',
      },
    } as any;

    const result = mapBeneficiaries(formData);

    expect(result[0].account).toMatchObject({
      payIDType: PAYID_TYPE.ABN_ACN,
      payIDValue: '12345678901',
    });
  });

  it('should handle Organisation ID PayID type', () => {
    const formData = {
      totalAmount: '300.00',
      beneficiary: {
        beneficiaryType: 'PAYID' as any,
        beneficiaryNickname: 'Org PayID',
        payIdType: 'OTHER' as any,
        organisationId: 'ORG123456',
        phone: '',
        email: '',
        abnAcn: '',
      },
    } as any;

    const result = mapBeneficiaries(formData);

    expect(result[0].account).toMatchObject({
      payIDType: 'OTHER',
      payIDValue: 'ORG123456',
    });
  });
});

describe('getEntityNameByAccountNumber', () => {
  it('should return entity name for matching account number', () => {
    const arrangementDetails = [
      {
        accountNumber: '123456789',
        entityName: 'Test Entity 1',
      },
      {
        accountNumber: '987654321',
        entityName: 'Test Entity 2',
      },
    ] as any;

    const result = getEntityNameByAccountNumber(
      '987654321',
      arrangementDetails
    );
    expect(result).toBe('Test Entity 2');
  });

  it('should return empty string when account not found', () => {
    const arrangementDetails = [
      {
        accountNumber: '123456789',
        entityName: 'Test Entity 1',
      },
    ] as any;

    const result = getEntityNameByAccountNumber(
      '000000000',
      arrangementDetails
    );
    expect(result).toBe('');
  });

  it('should return empty string when arrangementDetails is undefined', () => {
    const result = getEntityNameByAccountNumber('123456789', undefined);
    expect(result).toBe('');
  });

  it('should return empty string when arrangementDetails is empty array', () => {
    const result = getEntityNameByAccountNumber('123456789', []);
    expect(result).toBe('');
  });

  it('should return empty string when arrangementDetails is not an array', () => {
    const result = getEntityNameByAccountNumber('123456789', null as any);
    expect(result).toBe('');
  });

  it('should handle account number with BSB format', () => {
    const arrangementDetails = [
      {
        accountNumber: '035845 123456789',
        entityName: 'BSB Format Entity',
      },
    ] as any;

    const result = getEntityNameByAccountNumber(
      '035845 123456789',
      arrangementDetails
    );
    expect(result).toBe('BSB Format Entity');
  });
});
