/**
 * TODO: this naming conflicts with the Beneficiary type in common
 */
export const BeneficiaryConst = {
  payID: 'pay-id',
  other: 'other',
} as const;

export type BeneficiaryConstType =
  (typeof BeneficiaryConst)[keyof typeof BeneficiaryConst];
