/* eslint-disable spaced-comment */
/* eslint-disable @typescript-eslint/ban-ts-comment */
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import { MVDetailSection } from '@mesh-tenant-multiverse-ui-common/mv-detailsection';
import {
  ChannelTypeCode,
  formatCurrencyString,
  getFormattedDate,
  useGetChannelTypeCode,
  isStaffPortal,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { HTTP_STATUS_CODES } from '@mesh-tenant-multiverse-ui-common/mv-constants';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { v4 as uuid } from 'uuid';

import {
  useIsCompositeDesktop,
  useIsDesktopVersion,
  useIsWebVersion,
} from '@mesh-tenant-multiverse-common/react';
import { useUnifyClose } from '@mesh-tenant-multiverse-ui-common/mv-openfin';
import { Alert, Button, Grid, GridItem, ProgressIndicator } from '@westpac/ui';
import isArray from 'lodash/isArray';
import { useEntitlementsSafi } from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import {
  COP_COLOR_CODE,
  CoPApiStatus,
} from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
import { useOrganizationId } from '../../hooks/useOrganizationId';
import {
  apiGenericErrorTryAgainLater,
  genericErrorMessage,
} from '../../common/constants';
import {
  ErrorResponse,
  LookupMismatch,
  MakePaymentFormDataType,
  NppPaymentMethod,
} from '../../common/types';
import {
  checkIsNewBeneficiary,
  checkShouldSaveNewBeneficiary,
  isStepUpRequired,
} from '../../common/utils';
import { NppPaymentMethodMap } from '../../containers/MakePaymentContainer/common';
import {
  type PostGeneratePaymentIdParams,
  type PostPaymentsOptionsPayload,
  type PostPaymentsParamsPayload,
  BeneficiaryOptionsPayload,
  PostBeneficiaryParamsPayload,
  ArrangementDetails,
} from '../../store/types';
import { AccountDetailSection } from '../AccountDetailSection';
import { BeneficiaryDetailSection } from '../BeneficiaryDetailSection';
import {
  paymentConfirmationPage,
  paymentDetailsPage,
} from '../../containers/MakePaymentContainer/constants';
import { scrollToTop } from '../../galaxy-common/utils/DOMUtils';
import { useEntitlementsStepUp } from '../../hooks/useEntitlementsStepUp';
import { PingmfaWidgetApp } from '../../widgets/pingmfa';
import {
  getBeneficiaryType,
  getReviewDetailsMessage,
  mapPostPaymentParams,
} from './PaymentReview.utils';
import { DivisionAndPaymentTo } from '../DivisionAndPaymentTo';
import { useHandleSentForAuthorisation } from './hooks/useHandleSentForAuthorisation';

export type PaymentReviewProps = {
  renderPaymentComponents: (navigateTo: string) => void;
  makePaymentFormData: MakePaymentFormDataType;
  submitPayment: (
    payload: PostPaymentsParamsPayload,
    options: PostPaymentsOptionsPayload
  ) => void;
  addBeneficiary: (
    payload: PostBeneficiaryParamsPayload,
    options: BeneficiaryOptionsPayload
  ) => void;
  getPaymentId: (params: PostGeneratePaymentIdParams) => void;
  isPaymentCreateFetching: boolean;
  isPaymentCreateError: boolean;
  lookupMismatch?: LookupMismatch;
  apiStatus?: number;
  paymentId: string;
  isPaymentIdentifierError?: boolean;
  paymentIdentifierApiStatus?: number;
  paymentIdentifierErrors?: ErrorResponse[];
  isPaymentIdentifierFetching: boolean;
  postPaymentErrors?: ErrorResponse[];
  clearPaymentCreate: () => void;
  clearPaymentIdentifier: () => void;
  clearPaymentCreateForNewBeneficiary: () => void;
  allArrangementDetails: ArrangementDetails[];
  isArrangementDetailsFetching?: boolean;
  isArrangementDetailsError: boolean;
  isBeneficiaryCreateFetching: boolean;
  isBeneficiaryCreateError: boolean;
  postAddBeneficiaryStatusCode?: number;
  matchedCOPStatusCode?: CoPApiStatus;
  matchedCOPAccountName?: string;
  matchedCOPColour?: COP_COLOR_CODE;
};

function PaymentReview({
  renderPaymentComponents,
  makePaymentFormData,
  submitPayment,
  addBeneficiary,
  paymentId,
  getPaymentId,
  isPaymentCreateFetching,
  isPaymentCreateError,
  lookupMismatch,
  apiStatus,
  isPaymentIdentifierError,
  paymentIdentifierApiStatus,
  paymentIdentifierErrors,
  isPaymentIdentifierFetching,
  postPaymentErrors,
  clearPaymentCreate,
  clearPaymentCreateForNewBeneficiary,
  clearPaymentIdentifier,
  allArrangementDetails,
  isArrangementDetailsFetching,
  isArrangementDetailsError,
  isBeneficiaryCreateFetching,
  isBeneficiaryCreateError,
  postAddBeneficiaryStatusCode,
  matchedCOPAccountName,
  matchedCOPStatusCode,
  matchedCOPColour,
}: PaymentReviewProps) {
  const [idempotencyKey, setIdempotencyKey] = useState<string>('');
  const [paymentReviewDate, setPaymentReviewDate] = useState<string>('');
  const [isPaymentSubmitted, setPaymentSubmitted] = useState<boolean>(false);
  const [instructionTraceId, setInstructionTraceId] = useState<string>('');

  const stepUpRequired = isStepUpRequired(apiStatus, postPaymentErrors);
  const [isNonOtpMFAError, setIsNonOtpMFAError] = useState<boolean>(false);
  const [isStepUpModalVisible, setIsStepUpModalVisible] =
    useState<boolean>(false);

  const channelTypeCode: ChannelTypeCode = useGetChannelTypeCode({
    useIsDesktopVersion,
    useIsWebVersion,
    useIsCompositeDesktop,
  });

  const resetApiStates = () => {
    clearPaymentCreate();
    clearPaymentIdentifier();
    clearPaymentCreateForNewBeneficiary();
  };

  const orgId = useOrganizationId();
  const { populateHeader } = useEntitlementsSafi();

  const getEntityNameByAccountNumber = (targetAccountNumber: string) => {
    if (allArrangementDetails && isArray(allArrangementDetails)) {
      const account = allArrangementDetails.find(
        (acc) => acc.accountNumber === targetAccountNumber
      );
      // eslint-disable-next-line @typescript-eslint/no-unsafe-return
      return account ? account.entityName : '';
    }
    return '';
  };

  const submitPaymentWithExtraHeaders = (
    payload: PostPaymentsParamsPayload,
    options: PostPaymentsOptionsPayload
  ) => {
    const extraHeaders = {
      ...(options || {}),
      headers: {
        ...(options?.headers || {}),
        ...(window.encode_deviceprint
          ? populateHeader({}, window.encode_deviceprint)
          : {}),
        ...(orgId && { 'protected-orgId': orgId }),
        'x-idempotency-key': idempotencyKey,
        'x-channelRequestId': paymentId,
      } as Record<string, any>,
    };

    submitPayment(payload, extraHeaders);
  };

  const {
    toAccount,
    fromAccount,
    fromDescription,
    toDescription,
    toReference,
    totalAmount,
    paymentMethod,
    division,
  } = makePaymentFormData;

  const { renderEntitlementsStepUp } = useEntitlementsStepUp({
    pingMfaWidget: <PingmfaWidgetApp />,
    propType: 'mfa',
    apiStatus,
    errors: postPaymentErrors,
    dispatchFn: submitPaymentWithExtraHeaders,
    isStepUpModalVisible,
    setIsStepUpModalVisible,
    dispatchFnParams: mapPostPaymentParams(
      makePaymentFormData,
      channelTypeCode,
      getEntityNameByAccountNumber(fromAccount?.accountId ?? ''),
      instructionTraceId,
      paymentId,
      matchedCOPAccountName,
      matchedCOPStatusCode,
      matchedCOPColour
    ),
    setIsNonOtpMFAError,
  });

  const { closeTab } = useUnifyClose(true);

  const isPaymentIdentifierPermissionError =
    !!isPaymentIdentifierError &&
    paymentIdentifierApiStatus === 403 &&
    paymentIdentifierErrors?.some(({ code }) => code === 8210);

  useEffect(() => {
    const paymentID = uuid();
    const traceID = uuid();
    setIdempotencyKey(paymentID);
    setInstructionTraceId(traceID);
    setPaymentReviewDate(getFormattedDate());
  }, []);

  useEffect(() => {
    if (isPaymentCreateError) {
      scrollToTop();
    }
  }, [isPaymentCreateError]);

  const { handleSubmitPayment } = useHandleSentForAuthorisation({
    renderPaymentComponents,
    makePaymentFormData,
    lookupMismatch,
    allArrangementDetails,
    instructionTraceId,
    submitPaymentWithExtraHeaders,
    setPaymentSubmitted,
    isArrangementDetailsError,
    isArrangementDetailsFetching,
    getPaymentId,
    paymentId,
    setIsStepUpModalVisible,
    setIsNonOtpMFAError,
    isPaymentIdentifierFetching,
    isPaymentIdentifierError,
    isPaymentCreateFetching,
    isPaymentCreateError,
    addBeneficiary,
    resetApiStates,
    channelTypeCode,
    apiStatus,
    postPaymentErrors,
    matchedCOPAccountName,
    matchedCOPStatusCode,
    matchedCOPColour,
  });

  const handleEditButtonClick = () => {
    resetApiStates();
    renderPaymentComponents(paymentDetailsPage);
  };

  const shouldSaveNewBeneficiary = useMemo(
    () => checkShouldSaveNewBeneficiary(makePaymentFormData),
    [makePaymentFormData]
  );

  // 401 with error code 8125 means "sent for authorisation" - treat as success
  const isSentForAuthorisationSuccess =
    apiStatus === HTTP_STATUS_CODES.UNAUTHORIZED &&
    postPaymentErrors?.some((err: ErrorResponse) => err.code === 8125);

  useEffect(() => {
    // Beneficiary creation is complete when not fetching AND has response (success or error)
    const isBeneficiaryCreateDone =
      !isBeneficiaryCreateFetching &&
      (!!postAddBeneficiaryStatusCode || isBeneficiaryCreateError);

    // Should wait for beneficiary API when saving new beneficiary and it's not done yet
    const shouldWaitForBeneficiary =
      shouldSaveNewBeneficiary && !isBeneficiaryCreateDone;

    // Real payment error (not 401/8125 which is treated as success)
    const isRealPaymentError =
      isPaymentCreateError && !isSentForAuthorisationSuccess;

    // Main condition: payment submitted, not fetching, has status, no step-up required
    // AND either: no need to wait for beneficiary OR it's a real payment error
    const canNavigateForPaymentResult =
      isPaymentSubmitted &&
      !isPaymentCreateFetching &&
      apiStatus &&
      !stepUpRequired &&
      (!shouldWaitForBeneficiary || isRealPaymentError);

    // Navigate if main conditions met OR independent error conditions
    if (
      canNavigateForPaymentResult ||
      isNonOtpMFAError ||
      isPaymentIdentifierPermissionError
    ) {
      renderPaymentComponents(paymentConfirmationPage);
    }
  }, [
    isPaymentSubmitted,
    apiStatus,
    shouldSaveNewBeneficiary,
    postAddBeneficiaryStatusCode,
    isPaymentCreateFetching,
    stepUpRequired,
    isNonOtpMFAError,
    isPaymentIdentifierPermissionError,
    isPaymentCreateError,
    isBeneficiaryCreateFetching,
    isBeneficiaryCreateError,
    isSentForAuthorisationSuccess,
  ]);

  const handleClose = useCallback(async () => {
    await closeTab();
  }, []);

  const FromData = [
    {
      label: 'From account',
      value: fromAccount && <AccountDetailSection account={fromAccount} />,
    },
    { label: 'Debit description', value: fromDescription || '' },
  ];

  const ToData = [
    {
      label: 'Beneficiary',
      value: toAccount && (
        <BeneficiaryDetailSection
          lookupMismatch={lookupMismatch}
          beneficiary={toAccount}
        />
      ),
    },
  ];

  const PaymentDetailsData = [
    {
      label: 'Payment method',
      value: NppPaymentMethodMap(paymentMethod?.label),
    },
    {
      label: 'Amount',
      value: (
        <p className="text-text font-semibold">
          AUD {formatCurrencyString(totalAmount)}
        </p>
      ),
    },
    { label: 'Date', value: paymentReviewDate?.split(' (')[0] },
    { label: 'Reference', value: toReference || '' },
    ...(paymentMethod?.label !== NppPaymentMethod.DE
      ? [{ label: 'Credit description', value: toDescription || '' }]
      : []),
  ];

  const renderBanner = () => {
    if (stepUpRequired) return null;
    let message: React.ReactNode | null = null;
    const bannerStyling: 'success' | 'danger' = 'danger';
    // 1. Payment identifier API error - show generic error message
    if (isPaymentIdentifierError) {
      message = apiGenericErrorTryAgainLater;
    }
    // 2. Payment create error with undefined status (client-side timeout/network issue)
    else if (isPaymentCreateError && !apiStatus) {
      message = genericErrorMessage;
    }
    if (!message) return null;
    return (
      <GridItem className="w-full" span={12}>
        <Alert
          iconSize="small"
          id="payment-review-banner"
          look={bannerStyling}
          className="mt-2.5 mb-0"
        >
          {message}
        </Alert>
      </GridItem>
    );
  };
  const getDivisionProps = () => {
    const divisionLabel = division?.label;
    if (isStaffPortal() || !divisionLabel) return {};
    return { division: divisionLabel };
  };

  return (
    <>
      {(isPaymentCreateFetching ||
        isArrangementDetailsFetching ||
        isPaymentIdentifierFetching ||
        isBeneficiaryCreateFetching) && (
        <div className="fixed inset-0 flex justify-center items-center bg-border bg-opacity-75 z-50">
          <ProgressIndicator size="medium" />
        </div>
      )}
      {renderEntitlementsStepUp()}

      <MVCard title="Review payment" template="narrow">
        <Grid className="xsl:gap-0 sm:gap-0 !gap-0">
          {renderBanner()}

          <DivisionAndPaymentTo
            {...getDivisionProps()}
            isNewBeneficiary={checkIsNewBeneficiary(makePaymentFormData)}
          />

          <MVDetailSection
            heading="From"
            data={FromData}
            linkAction={{
              text: 'Edit',
              action: () => handleEditButtonClick(),
            }}
          />
          <MVDetailSection
            heading="To"
            data={ToData}
            withTopBorder
            linkAction={{
              text: 'Edit',
              action: () => handleEditButtonClick(),
            }}
          />
          {/* Not required at the moment. Keep it for future use */}
          {/* {isNewBeneficiary(makePaymentFormData) && (
            <>
              <GridItem className="pb-2.5" span={3} />
              <GridItem className="pb-2.5 break-words" span={9}>
                <FirstTimePayment />
              </GridItem>
            </>
          )} */}
          <MVDetailSection
            heading="Payment details"
            data={PaymentDetailsData}
            withTopBorder
            linkAction={{
              text: 'Edit',
              action: () => handleEditButtonClick(),
            }}
          />
          <GridItem className="w-full m-0.5 mt-0 mb-0" span={12}>
            <Alert
              iconSize="small"
              look="info"
              id="info-banner"
              className="mb-0"
            >
              {getReviewDetailsMessage(
                getBeneficiaryType(makePaymentFormData.toAccount)
              )}
            </Alert>
          </GridItem>
          <GridItem className="w-full border-t border-border pt-2.5" span={12}>
            <Button
              id="submit-payment-button"
              name="submitPayment"
              className="mr-1.5"
              look="primary"
              size="small"
              onClick={handleSubmitPayment}
            >
              Send for authorisation
            </Button>
            <Button
              id="cancel-button-payment-review"
              name="cancel"
              size="small"
              look="hero"
              soft
              // eslint-disable-next-line @typescript-eslint/no-misused-promises
              onClick={handleClose}
            >
              Cancel
            </Button>
          </GridItem>
        </Grid>
      </MVCard>
    </>
  );
}

export default PaymentReview;
