/* eslint-disable @typescript-eslint/no-unsafe-argument */
import { sanitiseWithLibrary } from '@mesh-tenant-multiverse-ui-common/mv-injection-checker';
import {
  ACCOUNT_NAME_MAX_LENGTH,
  ChannelTypeCode,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import {
  BENEFICIARY_TYPE,
  PAYID_TYPE,
} from '@mesh-tenant-multiverse-ui-common/mv-constants';
import { v4 as uuid } from 'uuid';
import isArray from 'lodash/isArray';
import {
  COP_COLOR_CODE,
  CoPApiStatus,
} from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
import {
  BICFI,
  Currency,
  Issuer,
  PaymentMethod,
  SchemeName,
} from '../../common/constants';
import {
  type MakePaymentFormDataType,
  AccountOfBSBAndACC,
  AccountOfPayId,
  Beneficiary,
  BeneTypes,
  NppPaymentMethod,
  paymentProductMap,
  defaultPaymentProductId,
} from '../../common/types';
import {
  breakDescription,
  getCreditorAgentBICFI,
  getInstructionPriorityForDE,
  getSystemIdentificationDE,
  checkIsNewBeneficiary,
  buildPaymentEntitlement,
} from '../../common/utils';
import type {
  PostPaymentsParams,
  AddBeneficiaryObject,
  ArrangementDetails,
} from '../../store/types';
import { BeneficiaryConst, BeneficiaryConstType } from './PaymentReview.type';

const getPaymentProductId = (
  creditorServiceLevel?: string,
  label?: string
): string => {
  if (label === 'Fast Payment' && creditorServiceLevel === undefined) {
    return paymentProductMap.TRANSFER; // PP000016
  }

  // Check for DE payment first (starts with NURG)
  if (creditorServiceLevel?.startsWith('NURG')) {
    return paymentProductMap.DE; // PP000020
  }

  // Check NPP payment patterns using includes
  const nppPatterns = [
    { pattern: 'npp.clear.01-catsct', productId: paymentProductMap.CAT_SCT }, // PP000012 - Fast Payment CAT SCT (check before sct)
    { pattern: 'npp.clear.01-sct', productId: paymentProductMap.SCT }, // PP000005 - Fast Payment SCT
    { pattern: 'npp.clear.01-x2p1', productId: paymentProductMap.OSKO }, // PP000004 - Osko
  ];

  const match = nppPatterns.find(({ pattern }) =>
    creditorServiceLevel?.includes(pattern)
  );

  return match?.productId || defaultPaymentProductId;
};

export const mapPostPaymentParams = (
  formData: MakePaymentFormDataType,
  channelTypeCode: ChannelTypeCode,
  debtorEntityName?: any,
  instructionTraceIdentification?: string,
  paymentId?: string,
  matchedCOPAccountName?: string,
  matchedCOPStatusCode?: CoPApiStatus,
  matchedCOPColour?: COP_COLOR_CODE
): PostPaymentsParams => {
  const {
    toAccount,
    fromAccount,
    totalAmount,
    paymentMethod: nppPaymentMethod,
    division,
  } = formData;
  const creditorServiceLevel = nppPaymentMethod?.id ?? undefined;
  const instructionPriorityforDE = nppPaymentMethod
    ? getInstructionPriorityForDE(nppPaymentMethod.label as NppPaymentMethod)
    : undefined;

  const isPayID = toAccount?.type === BeneTypes.PAYID;
  const payIdAccount = toAccount?.account as AccountOfPayId;
  const bsbAccount = toAccount?.account as AccountOfBSBAndACC;

  const clearingSystemIdentificationCode = getSystemIdentificationDE(
    nppPaymentMethod?.label as NppPaymentMethod
  );

  const isNewPayee = checkIsNewBeneficiary(formData);

  const requestPayload: PostPaymentsParams = {
    clientContext: {
      channelType: channelTypeCode,
    },
    creditTransferTransactionInformation: [
      {
        creditor: {
          name: isPayID
            ? payIdAccount.payIDName ?? ''
            : sanitiseWithLibrary(bsbAccount.accountName ?? ''),
        },
        ...(!isPayID && {
          creditorAccount: {
            identification: `${bsbAccount?.accountId?.BSB}${bsbAccount?.accountId?.accountNumber}`,
            issuer: bsbAccount?.accountId?.BSB ?? '',
            schemeName: SchemeName.BBAN,
            name: sanitiseWithLibrary(toAccount?.nickname ?? ''),
          },
        }),
        ...(isPayID && {
          creditorAccount: {
            name: sanitiseWithLibrary(toAccount?.nickname ?? ''),
          },
        }),
        creditorAgent: {
          BICFI: getCreditorAgentBICFI(
            nppPaymentMethod?.label as NppPaymentMethod
          ),
          ...(clearingSystemIdentificationCode && {
            financialInstitutionIdentification: {
              clearingSystemMemberIdentification: {
                clearingSystemIdentification: {
                  code: clearingSystemIdentificationCode,
                },
              },
            },
          }),
        },
        ...(formData.toReference && {
          endToEndIdentification: formData.toReference,
        }),
        instructedAmount: {
          amount: totalAmount,
          currency: Currency.AUD,
        },
        paymentTypeInformation: {
          ...(creditorServiceLevel && { serviceLevel: creditorServiceLevel }),
          ...(instructionPriorityforDE && {
            instructionPriority: instructionPriorityforDE,
          }),
        },
        ...(formData.toDescription && {
          remittanceInformation: {
            unstructured: breakDescription(formData.toDescription ?? ''),
          },
        }),
        supplementaryData: {
          isNewPayee,
          ...(isPayID && {
            ...(toAccount.id && !isNewPayee && { beneficiaryId: toAccount.id }),
            aliasId: payIdAccount?.payIDValue,
            aliasType: payIdAccount?.payIDType,
          }),
        },
      },
    ],
    debtor: {
      issuer: Issuer.WPAC,
      name: sanitiseWithLibrary(debtorEntityName ?? ''),
    },
    debtorAccount: {
      identification: fromAccount?.accountId?.replace(/\s+/g, '') ?? '',
      issuer: fromAccount?.accountId?.slice(0, 6) ?? '',
      schemeName: SchemeName.BBAN,
      name: sanitiseWithLibrary(
        fromAccount?.accountName ?? '',
        ACCOUNT_NAME_MAX_LENGTH
      ),
    },
    debtorAgent: {
      BICFI: BICFI.WPACAU3SXXX,
      ...(clearingSystemIdentificationCode && {
        financialInstitutionIdentification: {
          clearingSystemMemberIdentification: {
            clearingSystemIdentification: {
              code: clearingSystemIdentificationCode,
            },
          },
        },
      }),
    },
    initiatingParty: {
      name: sanitiseWithLibrary(debtorEntityName ?? ''),
    },
    paymentMethod: PaymentMethod.TRF,
    paymentInformation: {
      numberOfTransactions: '1',
    },
    supplementaryData: {
      debitDescription: formData.fromDescription ?? '',
      instructionTraceIdentification: instructionTraceIdentification ?? '',
      ...(division?.id && { divisionId: division?.id }),
      paymentProductId: getPaymentProductId(
        creditorServiceLevel,
        nppPaymentMethod?.label
      ),
      ...(matchedCOPAccountName && { matchedCOPAccountName }),
      ...(matchedCOPStatusCode && { matchedCOPStatusCode }),
    },
    entitlementData: buildPaymentEntitlement(
      formData,
      paymentId ?? '',
      matchedCOPColour
    ),
  };

  return requestPayload;
};

export const getBeneficiaryType = (
  args?: Beneficiary | null
): BeneficiaryConstType => {
  if (!args) return BeneficiaryConst.other;
  if (args?.type === BeneTypes.PAYID) return BeneficiaryConst.payID;
  return BeneficiaryConst.other;
};

const messages = {
  [BeneficiaryConst.payID]:
    'Before sending for authorisation, check the PayID details. Incorrect details may mean the wrong account is paid and it may not be possible to recover the funds.',
  [BeneficiaryConst.other]: `Before sending for authorisation, check the BSB and account number. Account names
              are not used to process payments, so an incorrect BSB or account
              number may mean the wrong account is paid and it may not be
              possible to recover the funds.`,
};

export const getReviewDetailsMessage = (
  beneficiary: BeneficiaryConstType
): string => messages[beneficiary];

export const mapBeneficiaries = (formData: MakePaymentFormDataType) => {
  const bene = formData.beneficiary;
  if (!bene) return [];

  const resolvePayIdValue = () => {
    if (bene?.payIdType === PAYID_TYPE.PHONE) {
      return (bene?.phone ?? '').replace(/\s/g, '');
    }
    if (bene?.payIdType === PAYID_TYPE.EMAIL) {
      return bene?.email ?? '';
    }
    if (bene?.payIdType === PAYID_TYPE.ABN_ACN) {
      return bene?.abnAcn ?? '';
    }
    return bene?.organisationId ?? '';
  };

  const beneficiary: AddBeneficiaryObject = {
    id: uuid(),
    nickname: bene?.beneficiaryNickname,
    currencyAmount: {
      currencyCode: Currency.AUD,
    },
    type: bene?.beneficiaryType as BENEFICIARY_TYPE,
    account:
      bene?.beneficiaryType === BENEFICIARY_TYPE.PAYID
        ? {
            payIDName: bene?.payIdName ?? '',
            payIDType: bene?.payIdType,
            payIDValue: resolvePayIdValue(),
          }
        : {
            accountId: {
              BSB: bene?.bsb,
              accountNumber: bene?.accountNumber,
            },
            accountName: bene?.accountName,
            bankName: bene?.bankName,
          },
  };
  return [beneficiary];
};

export const getEntityNameByAccountNumber = (
  targetAccountNumber: string,
  allArrangementDetails?: ArrangementDetails[]
) => {
  // eslint-disable-next-line @typescript-eslint/no-unsafe-call
  if (allArrangementDetails && isArray(allArrangementDetails)) {
    const account = allArrangementDetails.find(
      (acc) => acc.accountNumber === targetAccountNumber
    );
    return account ? account.entityName : '';
  }
  return '';
};
