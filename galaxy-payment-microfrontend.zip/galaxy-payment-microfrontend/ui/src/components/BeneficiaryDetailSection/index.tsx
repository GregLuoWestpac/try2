export { default as BeneficiaryDetailSection } from './BeneficiaryDetailSection';
