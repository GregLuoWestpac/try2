/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { act } from 'react';

import { Beneficiary } from '../../common/types';
import BeneficiaryDetailSection, {
  BeneficiaryDetailSectionProps,
  FormatPayIDDetails,
} from './BeneficiaryDetailSection';

const mockBeneficiary: Beneficiary = {
  id: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
  externalId: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
  nickname: 'John (unhappy path)',
  currency: 'AUD',
  org: 'Apple Tree Inc',
  status: 'ARCHIVED',
  type: 'BSB_ACCOUNT_NUMBER',
  account: {
    accountId: {
      BSB: '035845',
      accountNumber: '01235674897',
    },
    bankName: 'Westpac Banking Corporation',
    accountName: 'Apple Tree',
  },
};

const defaultProps: BeneficiaryDetailSectionProps = {
  beneficiary: mockBeneficiary,
};

const mockBeneficiaryWithPayId: Beneficiary = {
  id: 'd0868661-b955-4e76-9f15-d97626f7df6b',
  externalId: 'd0868661-b955-4e76-9f15-d97626f7df6b',
  nickname: 'ABC MacGyver (PayID/archived)',
  currency: 'AUD',
  org: 'office',
  type: 'PAYID',
  status: 'ARCHIVED',
  account: {
    payIDType: 'TELI',
    payIDValue: '+61-407123456',
    payIDName: 'ABC Corp',
  },
};

const defaultPropsWithPayId: BeneficiaryDetailSectionProps = {
  beneficiary: mockBeneficiaryWithPayId,
};

describe('Testing BeneficiaryDetailSection', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should match snapshot', () => {
    const { container } = render(
      <BeneficiaryDetailSection {...defaultProps} />
    );
    expect(container).toMatchSnapshot();
  });

  it('should show the correct content', () => {
    const { getByText } = render(
      <BeneficiaryDetailSection {...defaultProps} />
    );
    const beneficiaryName = getByText('John (unhappy path)');
    expect(beneficiaryName).toBeInTheDocument();

    const beneficiaryAccountName = getByText('Apple Tree');
    expect(beneficiaryAccountName).toBeInTheDocument();

    const beneficiaryAccountNumber = getByText('035-845 01235674897');
    expect(beneficiaryAccountNumber).toBeInTheDocument();
  });

  it('should match snapshot for payId payments', () => {
    const { container } = render(
      <BeneficiaryDetailSection {...defaultPropsWithPayId} />
    );
    expect(container).toMatchSnapshot();
  });

  it('Should show the correct content for payID payments', () => {
    const { getByText } = render(
      <BeneficiaryDetailSection {...defaultPropsWithPayId} />
    );

    expect(getByText('Name:')).toBeInTheDocument();
    expect(getByText('PayID name:')).toBeInTheDocument();
    expect(getByText('PayID:')).toBeInTheDocument();

    const beneficiaryName = getByText('ABC Corp');
    expect(beneficiaryName).toBeInTheDocument();

    const beneficiaryAccountNumber = getByText('+61-407123456');
    expect(beneficiaryAccountNumber).toBeInTheDocument();
  });
});

describe('formatters', () => {
  it('check if payID details are properly formatted', () => {
    const accountDetails = {
      payIdName: 'Tay Tay',
      nickName: 'Taylor Alison Swift',
      identification: 'taylor.swift@era.com',
    };
    render(<FormatPayIDDetails {...accountDetails} />);

    expect(screen.getByText('Name:')).toBeInTheDocument();
    expect(screen.getByText('PayID name:')).toBeInTheDocument();
    expect(screen.getByText('PayID:')).toBeInTheDocument();

    expect(screen.getByText('Tay Tay')).toBeInTheDocument();
    expect(screen.getByText('Taylor Alison Swift')).toBeInTheDocument();
    expect(screen.getByText('taylor.swift@era.com')).toBeInTheDocument();
  });

  it('display the hint message when there is a lookup error', async () => {
    const accountDetails = {
      payIdName: 'Tay Tay',
      nickName: 'Taylor Alison Swift',
      identification: 'taylor.swift@era.com',
      isLookupError: true,
      hint: 'PayID name has changed from Taylor Swift to Taylor Alison Swift.',
    };

    await act(async () => {
      render(<FormatPayIDDetails {...accountDetails} />);
    });

    const toolTipIcon = screen.getByTestId('tool-tip-icon');
    expect(toolTipIcon).toBeInTheDocument();

    await userEvent.click(toolTipIcon);

    expect(
      screen.getByText(
        'PayID name has changed from Taylor Swift to Taylor Alison Swift.'
      )
    ).toBeInTheDocument();
  });

  it(`tooltip is not displayed when there is not any error`, async () => {
    const accountDetails = {
      payIdName: 'Tay Tay',
      nickName: 'Taylor Alison Swift',
      identification: 'taylor.swift@era.com',
      isLookupError: false,
    };

    render(<FormatPayIDDetails {...accountDetails} />);
    const toolTipIcon = screen.queryByTestId('tool-tip-icon');
    expect(toolTipIcon).not.toBeInTheDocument();
  });
});
