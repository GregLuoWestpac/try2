import { MVAccountFormatter } from '@mesh-tenant-multiverse-ui-common/mv-accountformatter';
import { formatBSB } from '@mesh-tenant-multiverse-ui-common/mv-utils';
// eslint-disable-next-line import/no-unresolved
import { WarningIcon } from '@westpac/ui/icon';
import {
  AccountOfBSBAndACC,
  AccountOfPayId,
  Beneficiary,
  BeneTypes,
  LookupMismatch,
} from '../../common/types';

export type BeneficiaryDetailSectionProps = {
  beneficiary: Beneficiary;
  lookupMismatch?: LookupMismatch;
};

type AccountDetails = {
  payIdName: string;
  nickName: string;
  identification: string;
  hint?: string;
};

export function FormatPayIDDetails({
  payIdName,
  nickName,
  hint,
  identification,
}: Partial<AccountDetails>) {
  return (
    <MVAccountFormatter
      details={[
        {
          label: 'Name:',
          value: nickName ?? '',
          className:
            'm-0 overflow-hidden break-words text-hero font-semibold typography-body-10',
          variant: 'text',
        },
        {
          label: 'PayID name:',
          value: payIdName ?? '',
          className:
            'm-0 overflow-hidden break-words font-normal text-muted typography-body-10',
          ...(hint && hint !== ''
            ? {
                variant: 'accessory-icon',
                hint: hint || '',
                accessory: (
                  <WarningIcon
                    data-testid="tool-tip-icon"
                    look="outlined"
                    size="small"
                    color="warning"
                  />
                ),
              }
            : {
                variant: 'text',
              }),
        },
        {
          label: 'PayID:',
          value: identification ?? '',
          className:
            'm-0 overflow-hidden break-words font-normal text-text typography-body-10',
          variant: 'text',
        },
      ]}
    />
  );
}

function BeneficiaryDetailSection({
  beneficiary,
  lookupMismatch,
}: BeneficiaryDetailSectionProps) {
  const isPayID = beneficiary?.type === BeneTypes.PAYID;
  const payIdAccount = beneficiary?.account as AccountOfPayId;
  const bsbAccount = beneficiary?.account as AccountOfBSBAndACC;

  const beneficiaryAccountName =
    payIdAccount?.payIDName || bsbAccount?.accountName;
  const beneficiaryIdentification = isPayID
    ? payIdAccount.payIDValue
    : `${formatBSB(bsbAccount?.accountId?.BSB, 3)} ${
        bsbAccount?.accountId?.accountNumber
      }`;

  const hint =
    lookupMismatch?.beneficiaryName && lookupMismatch?.aliasLookupName
      ? `PayID name has changed from ${lookupMismatch.beneficiaryName} to ${lookupMismatch.aliasLookupName}.`
      : '';

  if (isPayID) {
    return (
      <FormatPayIDDetails
        payIdName={lookupMismatch?.aliasLookupName || beneficiaryAccountName}
        nickName={beneficiary.nickname}
        identification={beneficiaryIdentification}
        hint={hint}
      />
    );
  }
  return (
    <MVAccountFormatter
      details={[
        {
          label: 'Name:',
          value: beneficiary.nickname ?? '',
          className:
            'm-0 text-hero font-bold break-words whitespace-normal overflow-hidden typography-body-10',
          variant: 'text',
        },
        {
          label: 'Account name:',
          value: beneficiaryAccountName ?? '',
          className:
            'm-0 overflow-hidden text-muted break-words whitespace-normal typography-body-10',
          variant: 'text',
        },
        {
          label: 'Account:',
          value: beneficiaryIdentification ?? '',
          className:
            'm-0 overflow-hidden break-words font-normal whitespace-normal typography-body-10',
          variant: 'text',
        },
      ]}
    />
  );
}

export default BeneficiaryDetailSection;
