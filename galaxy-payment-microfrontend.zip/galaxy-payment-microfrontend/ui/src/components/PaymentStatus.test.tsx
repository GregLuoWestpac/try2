import { render, screen } from '@testing-library/react';
import PaymentStatus from './PaymentStatus';
import { WorkFlowStatusMap } from '../common/constants';

describe('PaymentStatus', () => {
  describe('Badge styling consistency (ART-85263)', () => {
    it('should not use font-semibold class to maintain consistency with account list badges', () => {
      const { container } = render(<PaymentStatus value="Processed" />);
      const badge = container.querySelector('[class*="bg-white"]');
      
      expect(badge).toBeInTheDocument();
      expect(badge?.className).not.toContain('font-semibold');
      expect(badge?.className).toContain('break-words');
      expect(badge?.className).toContain('whitespace-normal');
      expect(badge?.className).toContain('h-auto');
      expect(badge?.className).toContain('py-0.5');
    });

    it('should render with correct base styling classes', () => {
      const { container } = render(<PaymentStatus value="Processing" />);
      const badge = container.querySelector('[class*="bg-info"]');
      
      expect(badge).toBeInTheDocument();
      expect(badge?.className).toContain('break-words whitespace-normal h-auto py-0.5');
    });
  });

  describe('Badge color and behavior', () => {
    it('should render Submitted with info color', () => {
      render(<PaymentStatus value="Submitted" />);
      const badge = screen.getByText('Submitted');
      expect(badge).toBeInTheDocument();
    });

    it('should render Processing with info color and no soft style', () => {
      render(<PaymentStatus value="Processing" />);
      const badge = screen.getByText('Processing');
      expect(badge).toBeInTheDocument();
    });

    it('should render Processed with success color', () => {
      render(<PaymentStatus value="Processed" />);
      const badge = screen.getByText('Processed');
      expect(badge).toBeInTheDocument();
    });

    it('should render Failed with danger color', () => {
      render(<PaymentStatus value="Failed" />);
      const badge = screen.getByText('Failed');
      expect(badge).toBeInTheDocument();
    });

    it('should render ApprovalPending with info color', () => {
      render(<PaymentStatus value={WorkFlowStatusMap.ApprovalPending} />);
      const badge = screen.getByText(WorkFlowStatusMap.ApprovalPending);
      expect(badge).toBeInTheDocument();
    });

    it('should render Rejected with danger color', () => {
      render(<PaymentStatus value={WorkFlowStatusMap.Rejected} />);
      const badge = screen.getByText(WorkFlowStatusMap.Rejected);
      expect(badge).toBeInTheDocument();
    });

    it('should render unknown status with faint color', () => {
      const unknownStatus = 'UnknownStatus';
      render(<PaymentStatus value={unknownStatus} />);
      const badge = screen.getByText(unknownStatus);
      expect(badge).toBeInTheDocument();
    });
  });

  describe('Component structure', () => {
    it('should render the status value as text content', () => {
      const statusValue = 'Custom Status';
      render(<PaymentStatus value={statusValue} />);
      expect(screen.getByText(statusValue)).toBeInTheDocument();
    });

    it('should render as a badge element', () => {
      const { container } = render(<PaymentStatus value="Processed" />);
      const badge = container.querySelector('[class*="inline-block"]');
      expect(badge).toBeInTheDocument();
    });
  });
});