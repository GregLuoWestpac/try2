
import { ProgressIndicator } from '@westpac/ui';
import PropTypes from 'prop-types';


function PageLoader({ iconSize = 'medium', placement = 'normal' }) {
  const containerClass = placement === 'middle'
    ? 'flex min-h-screen h-full justify-center items-center'
    : 'flex flex-1 justify-center items-center';
  return (
    <div className={containerClass} data-testid="page-loader">
      {/* <ScreenReaderOnly id="page-loading">Loading</ScreenReaderOnly> */}
      <ProgressIndicator size={iconSize} />
    </div>
  );
}

PageLoader.propTypes = {
  /**
   * The size of the loading icon
   */
  iconSize: PropTypes.oneOf(['xsmall', 'small', 'medium', 'large', 'xlarge']),
  placement: PropTypes.oneOd(['middle', 'normal']),
};

export default PageLoader;
