
import { Grid, GridItem, Heading } from '@westpac/ui';

type PageTitleProps = {
  title: string;
  setBorder?: boolean;
};

function PageTitle({ title, setBorder = true }: PageTitleProps) {
  return (
      <Grid>
        <GridItem
          span={12}
          className={`${setBorder ? 'border-b border-border' : ''}`}
        >
          <Heading className="mt-0 mb-2.5" size={6} tag="h1">{title}</Heading>
        </GridItem>
      </Grid>
  );
}

export default PageTitle;
