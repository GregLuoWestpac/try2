

import { render } from '@testing-library/react';

import PageTitle from './PageTitle';

const defaultProps = {
  title: 'Transfer details',
};

describe('Testing PageTitle', () => {
  it('should match snapshot', () => {
    const { container } = render(<PageTitle {...defaultProps} />);
    expect(container).toMatchSnapshot();
  });

  it('Should show the title', () => {
    const { getByText } = render(<PageTitle {...defaultProps} />);
    const title = getByText('Transfer details');
    expect(title).toBeInTheDocument();
  });
});
