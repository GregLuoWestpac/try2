/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import { useUnifyClose } from '@mesh-tenant-multiverse-ui-common/mv-openfin';
import { MVCurrencyController } from '@mesh-tenant-multiverse-ui-common/mv-reacthookform';
import { MVSelectController } from '@mesh-tenant-multiverse-ui-common/mv-selectcontroller';
import {
  formatToTwoDecimals,
  isStaffPortal,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { Button, Grid, GridItem, Heading, Well } from '@westpac/ui';
import { useEffect, useMemo, useRef, useState, type MouseEvent } from 'react';
import {
  Control,
  FieldValues,
  SubmitErrorHandler,
  SubmitHandler,
  useForm,
  UseFormTrigger,
} from 'react-hook-form';
import { DivisionOptionType } from '../../common/types';
import {
  defaultDivisionData,
  defaultFormData,
  TransferFormDataType,
} from '../../containers/TransferFundsContainer/common';
import { reviewTransferPage } from '../../containers/TransferFundsContainer/constants';
import { Account } from '../../store/types';
import { AccountSection } from '../AccountSection';
import PageLoader from '../PageLoader';
import { ErrorCard } from '../PaymentDetails/ErrorCard';
import {
  DESCRIPTION_VALIDATION_RULES,
  FIELDS,
} from './TransferDetails.constants';

type TransferDetailsProps = {
  handleTransferFundFormDataChange: (formatData: TransferFormDataType) => void;
  renderTransferFundsComponents: (navigateTo: string) => void;
  transferFundFormData: TransferFormDataType;
  isAccountListFetching: boolean;
  isAccountListError: boolean;
  fromAccountOptions: Account[];
  onRefresh: () => void;
  postArrangementDetails: any;
  divisions: DivisionOptionType[];
  onDivisionChange?: (selectedOption?: DivisionOptionType) => void;
  onDivisionRefresh: () => void;
  showDivisionField: boolean;
  isDivisionListFetching: boolean;
  isDivisionListError: boolean;
  getAccountListFn: (input?: string) => void;
};

function TransferDetails({
  handleTransferFundFormDataChange,
  renderTransferFundsComponents,
  transferFundFormData,
  isAccountListFetching,
  isAccountListError,
  fromAccountOptions,
  onRefresh,
  postArrangementDetails,
  divisions,
  onDivisionChange,
  onDivisionRefresh,
  showDivisionField,
  isDivisionListFetching,
  isDivisionListError,
  getAccountListFn,
}: TransferDetailsProps) {
  const [sameAsDebit, setSameAsDebit] = useState(false);
  const [fromAccounts, setFromAccounts] = useState<Account[]>([]);
  const [toAccounts, setToAccounts] = useState<Account[]>([]);

  const hasFormSubmitted = useRef(false);

  const loaderState = useMemo(
    () => isAccountListFetching,
    [isAccountListFetching]
  );

  const {
    watch,
    setFocus,
    setValue,
    control,
    handleSubmit,
    trigger,
    getFieldState,
    formState: { errors },
    reset,
  } = useForm<TransferFormDataType>({
    mode: 'onBlur',
    reValidateMode: 'onBlur',
    defaultValues: { ...transferFundFormData },
    shouldFocusError: true,
  });
  const watchedFormValues = watch();
  const getFormHasChanged = (formData: TransferFormDataType) =>
    Object.keys(formData).some(
      (key) =>
        formData[key as keyof TransferFormDataType] !==
        defaultFormData[key as keyof TransferFormDataType]
    );

  useEffect(() => {
    if (
      transferFundFormData[FIELDS[0].key] &&
      !watchedFormValues[FIELDS[0].key]
    ) {
      setValue(FIELDS[0].key, transferFundFormData[FIELDS[0].key]);
    }
  }, [transferFundFormData]);

  const formHasChanged = useMemo(
    () => getFormHasChanged(watchedFormValues),
    [watchedFormValues, defaultFormData]
  );
  const { closeTab } = useUnifyClose(formHasChanged);

  const debitDescription = watch('debitDescription');
  const creditDescription = watch('creditDescription');
  const fromAccount = watch('fromAccount');
  const toAccount = watch('toAccount');
  const selectedDivisionLabel = watch('division')?.label;
  // Determine when to show payment form fields based on division selection
  const showTransferFundsFieldsWithDivision =
    showDivisionField &&
    loaderState === false &&
    selectedDivisionLabel &&
    selectedDivisionLabel !== defaultDivisionData[0].label;

  const showDivisionLoaderForTransferFundsFields =
    !showTransferFundsFieldsWithDivision && loaderState;

  const shouldShowBottomDivider = !(isDivisionListFetching && loaderState);

  // show loader on page :
  // For StaffPortal : when account list or beneficiary list is loading
  // For Customer Portal : if division api return empty list, division field wont be shown hence show loader when account list or beneficiary list is loading
  // For Customer Portal : if division api return non-empty list, show loader based on showDivisionLoaderForTransferFundsFields
  const shouldShowLoader =
    isStaffPortal() || !showDivisionField
      ? loaderState
      : showDivisionLoaderForTransferFundsFields;

  // show payment form fields on page :
  // For StaffPortal : when account list and beneficiary list is not loaded
  // for Customer Portal: if division api return empty list, division field wont be shown hence show payment form fields when account list and beneficiary list is not loading
  // for Customer Portal: if division api return non-empty list, show payment form fields based on showTransferFundsFieldsWithDivision
  const shouldShowFormFields =
    isStaffPortal() || !showDivisionField
      ? !loaderState
      : showTransferFundsFieldsWithDivision;

  //  Dont show buttons when loader is showing
  const shouldShowButtons = !shouldShowLoader;

  const isAccountListingError =
    isAccountListError &&
    selectedDivisionLabel !== defaultDivisionData[0].label;

  const divisionValidationRules = {
    validate: () => {
      const hasValidDivision =
        selectedDivisionLabel &&
        selectedDivisionLabel !== defaultDivisionData[0].label;

      if (!hasValidDivision) {
        return 'Select a division.';
      }
      return true;
    },
  };
  const onSubmit: SubmitHandler<TransferFormDataType> = (data) => {
    const formattedData = {
      ...data,
      totalAmount: formatToTwoDecimals(data.totalAmount),
      fromAccount: data.fromAccount,
      toAccount: data.toAccount,
    };
    handleTransferFundFormDataChange(formattedData);
    renderTransferFundsComponents(reviewTransferPage);
  };

  const onError: SubmitErrorHandler<TransferFormDataType> = (data, e) => {
    const errorKeys = Object.keys(data);
    if (errorKeys.length > 0) {
      setFocus(errorKeys[0] as keyof TransferFormDataType);
    }
  };

  const handleSwitchChange = (isSelected: boolean) => {
    if (isSelected) {
      setValue('creditDescription', watch('debitDescription'));
    }
    setSameAsDebit(isSelected);
  };

  useEffect(() => {
    const fieldState = getFieldState('creditDescription');
    if (fieldState.isDirty && debitDescription !== creditDescription) {
      setSameAsDebit(false);
    }
  }, [creditDescription]);

  useEffect(() => {
    if (sameAsDebit) {
      setValue('creditDescription', watch('debitDescription'));
    }
  }, [debitDescription]);

  useEffect(() => {
    if (fromAccountOptions.length === 0) return;
    setToAccounts(
      fromAccountOptions.filter((option) => option.id !== fromAccount?.id)
    );
  }, [fromAccount, fromAccountOptions]);

  useEffect(() => {
    if (fromAccountOptions.length === 0) return;
    setFromAccounts(
      fromAccountOptions.filter((option) => option.id !== toAccount?.id)
    );
  }, [toAccount, fromAccountOptions]);

  const handleTransferFundDetailsSubmit = async (
    event: MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
    hasFormSubmitted.current = true;
    const payload = {
      meta: {
        replaceEntities: ['arrangementDetails'],
      },
      params: {
        accountIds: [
          {
            BSB: fromAccount?.accountId?.split(' ')[0] ?? '',
            accountNumber: fromAccount?.accountId?.split(' ')[1] ?? '',
          },
          {
            BSB: toAccount?.accountId?.split(' ')[0] ?? '',
            accountNumber: toAccount?.accountId?.split(' ')[1] ?? '',
          },
        ],
      },
    };
    postArrangementDetails(payload);
    await handleSubmit(onSubmit, onError)();
  };
  const handleDivisionChange = (selectedOption?: DivisionOptionType) => {
    const resetFormData = {
      ...defaultFormData,
      division: divisions.find((d) => d.label === selectedOption?.label),
    };

    reset(resetFormData);
    // Update parent component's state with reset form data
    handleTransferFundFormDataChange(resetFormData);

    // Clear any additional state
    setSameAsDebit(false);
    onDivisionChange?.(selectedOption);
  };
  const handleClose = async () => {
    await closeTab();
  };
  const renderDivision = () => (
    <Well className="!p-2.5 w-full mt-2.5 mb-2.5 bg-light border-light">
      <MVSelectController
        control={control}
        fieldName={FIELDS[3].key}
        label={FIELDS[3].label}
        errors={errors}
        options={divisions}
        validationRules={divisionValidationRules}
        onChange={handleDivisionChange}
        width="full"
      />
    </Well>
  );

  return (
    <MVCard
      title="Transfer funds"
      template="narrow"
      bottomDivider={shouldShowBottomDivider}
    >
      {isDivisionListFetching && <PageLoader iconSize="medium" />}
      {!isDivisionListFetching && (
        <form autoComplete="off" onSubmit={(event) => event.preventDefault()}>
          {isDivisionListError && (
            <ErrorCard
              onRefresh={onDivisionRefresh}
              onClickCancel={handleClose}
            />
          )}
          {isAccountListingError && !loaderState && (
            <>
              {showDivisionField && renderDivision()}

              <ErrorCard onRefresh={onRefresh} onClickCancel={handleClose} />
            </>
          )}
          {!isAccountListingError && !isDivisionListError && (
            <>
              {showDivisionField && renderDivision()}
              {shouldShowLoader && <PageLoader iconSize="medium" />}

              {shouldShowFormFields && (
                <>
                  <AccountSection
                    title="From"
                    fieldId="fromAccount-transfer"
                    fieldName={FIELDS[0].key}
                    accountSelectorLabel={FIELDS[0].label}
                    accountSelectorHintText="Search for an account."
                    descriptionLabel="Debit description"
                    descriptionValidationRules={DESCRIPTION_VALIDATION_RULES}
                    descriptionFieldName="debitDescription"
                    control={control as unknown as Control<FieldValues>}
                    trigger={trigger as unknown as UseFormTrigger<FieldValues>}
                    listOptions={fromAccounts}
                    fetchDataFn={getAccountListFn}
                    loadingState={isAccountListFetching}
                    hasErrorWhenFetchingData={isAccountListError}
                  />
                  <AccountSection
                    title="To"
                    fieldId="toAccount-transfer"
                    fieldName={FIELDS[1].key}
                    accountSelectorLabel={FIELDS[1].label}
                    accountSelectorHintText="Search for an account."
                    descriptionLabel="Credit description"
                    descriptionValidationRules={DESCRIPTION_VALIDATION_RULES}
                    copySwitchLabel="Same as debit description"
                    handleSwitchChange={handleSwitchChange}
                    sameAsDebit={sameAsDebit}
                    descriptionFieldName="creditDescription"
                    control={control as unknown as Control<FieldValues>}
                    trigger={trigger as unknown as UseFormTrigger<FieldValues>}
                    listOptions={toAccounts}
                    fetchDataFn={getAccountListFn}
                    loadingState={isAccountListFetching}
                    hasErrorWhenFetchingData={isAccountListError}
                  />
                  <GridItem
                    span={12}
                    className="py-2.5 !pb-0 border-b-solid border-b border-b-border"
                  >
                    <Heading tag="h2" size={7} className="mb-2.5">
                      Transfer details
                    </Heading>
                    <div className="mb-2.5">
                      <MVCurrencyController
                        id="total-amount-transfer-details"
                        control={control as unknown as Control<FieldValues>}
                        fieldName={FIELDS[2].key}
                        errors={errors}
                        trigger={trigger}
                      />
                    </div>
                  </GridItem>
                </>
              )}
              {shouldShowButtons && (
                <Grid>
                  <GridItem span={12}>
                    <div className="flex gap-1.5 pt-2.5">
                      <Button
                        id="review-button-transfer-details"
                        name="review"
                        look="hero"
                        size="small"
                        onClick={handleTransferFundDetailsSubmit}
                        aria-label="review button"
                        role="button"
                        type="button"
                      >
                        Review
                      </Button>
                      <Button
                        id="cancel-button-transfer-details"
                        name="cancel"
                        look="hero"
                        size="small"
                        soft
                        onClick={handleClose}
                        aria-label="cancel button"
                        role="button"
                        type="button"
                      >
                        Cancel
                      </Button>
                    </div>
                  </GridItem>
                </Grid>
              )}
            </>
          )}
        </form>
      )}
    </MVCard>
  );
}

export default TransferDetails;
