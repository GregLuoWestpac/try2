import { Account } from 'ui/src/store/types';
import { TransferFormDataType } from '../../containers/TransferFundsContainer/common';

export type TransferDetailsProps = {
  handleTransferFundFormDataChange: (formatData: TransferFormDataType) => void;
  renderTransferFundsComponents: (navigateTo: string) => void;
  transferFundFormData: TransferFormDataType;
  isAccountListFetching: boolean;
  isAccountListError: boolean;
  allAccountList: Account[];
  onRefresh: () => void;
};
