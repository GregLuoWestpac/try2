import {
  getFormattedForbiddenCharacters,
  validateWithLibrary,
} from '@mesh-tenant-multiverse-ui-common/mv-injection-checker';
import { RegisterOptions } from 'react-hook-form';
import { forbiddenCharacterErrorMessage } from '../../common/constants';
import { TransferFormDataType } from '../../containers/TransferFundsContainer/common';

export const FIELDS: { key: keyof TransferFormDataType; label: string }[] = [
  {
    key: 'fromAccount',
    label: 'From account',
  },
  {
    key: 'toAccount',
    label: 'To account',
  },
  {
    key: 'totalAmount',
    label: 'Amount',
  },
  {
    key: 'division',
    label: 'Division',
  },
];

export const DESCRIPTION_VALIDATION_RULES: RegisterOptions = {
  validate: (value: string) =>
    !validateWithLibrary(value) ||
    `${forbiddenCharacterErrorMessage} ${getFormattedForbiddenCharacters()}`,
};
