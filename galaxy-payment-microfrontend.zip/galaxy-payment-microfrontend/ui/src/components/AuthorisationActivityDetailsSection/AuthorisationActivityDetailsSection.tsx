/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { MVDetailSection } from '@mesh-tenant-multiverse-ui-common/mv-detailsection';
import { getFormattedDateTime } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { WorkFlowStatusMap } from '../../common/constants';
import {
  PaymentTaskDetail,
  WorkflowAuditDetails,
} from '../../containers/PaymentTaskDetailsContainer/PaymentTaskDetailsContainer.type';

export type AuthorisationActivityDetailsSectionProps = {
  paymentDetail: PaymentTaskDetail;
};

const renderAuditDetails = (details: WorkflowAuditDetails) => (
  <>
    <div>
      {details.actionedDateTime
        ? getFormattedDateTime(details.actionedDateTime, 'h:mma')
        : ''}
    </div>
    <div>{details.actionedBy || ''}</div>
  </>
);

function AuthorisationActivityDetailsSection({
  paymentDetail,
}: AuthorisationActivityDetailsSectionProps) {
  const detailItems = [
    {
      label: 'Sent for authorisation',
      value: renderAuditDetails(paymentDetail.sentForAuthWorkflowAuditDetails),
    },
  ];

  if (paymentDetail.status === WorkFlowStatusMap.Rejected) {
    detailItems.push({
      label: 'Rejected',
      value: renderAuditDetails(paymentDetail.rejectedWorkflowAuditDetails),
    });
  }

  return (
    <MVDetailSection
      heading="Authorisation activity"
      data={detailItems}
      withTopBorder
    />
  );
}

export default AuthorisationActivityDetailsSection;
