/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/no-array-index-key */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { render, screen } from '@testing-library/react';
import AuthorisationActivityDetailsSection from './AuthorisationActivityDetailsSection';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-detailsection', () => ({
  MVDetailSection: ({ heading, data }: any) => (
    <div>
      <h2>{heading}</h2>
      {data.map((item: any, idx: number) => (
        <div key={idx}>
          <span>{item.label}</span>
          <span>{item.value}</span>
        </div>
      ))}
    </div>
  ),
}));
jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  getFormattedDateTime: (date: string) => `formatted-${date}`,
}));

describe('AuthorisationActivityDetailsSection', () => {
  it('renders sent for authorisation details', () => {
    render(
      <AuthorisationActivityDetailsSection
        paymentDetail={{
          id: '123456',
          amount: { amount: '', currency: '' },
          beneficiary: { name: '', nickName: '', accountId: '' },
          creationDateTime: '2025-04-13T01:49:50Z',
          creditorDescription: '',
          debitAccount: { nickName: '', accountId: '' },
          debitDescription: '',
          paymentMethod: { description: '' },
          receiptNumber: '123456',
          reference: 'string',
          status: 'Pending authorisation',
          supplementaryData: { aliasId: '', aliasType: '' },
          sentForAuthWorkflowAuditDetails: {
            actionedBy: 'Joe Diszoua',
            actionedDateTime: '2025-05-18T10:49:57.566Z',
          },
          rejectedWorkflowAuditDetails: {
            actionedBy: '',
            actionedDateTime: '',
          },
        }}
      />
    );
    expect(screen.getByText('Authorisation activity')).toBeInTheDocument();
    expect(screen.getByText('Sent for authorisation')).toBeInTheDocument();
    expect(
      screen.getByText('formatted-2025-05-18T10:49:57.566Z')
    ).toBeInTheDocument();
    expect(screen.getByText('Joe Diszoua')).toBeInTheDocument();
  });

  it('renders rejected details if status is Rejected', () => {
    render(
      <AuthorisationActivityDetailsSection
        paymentDetail={{
          id: '123456',
          amount: { amount: '', currency: '' },
          beneficiary: { name: '', nickName: '', accountId: '' },
          creationDateTime: '2025-04-13T01:49:50Z',
          creditorDescription: '',
          debitAccount: { nickName: '', accountId: '' },
          debitDescription: '',
          paymentMethod: { description: '' },
          receiptNumber: '123456',
          reference: 'string',
          status: 'Rejected by authoriser',
          supplementaryData: { aliasId: '', aliasType: '' },
          rejectedWorkflowAuditDetails: {
            actionedBy: 'Joe Diszoua',
            actionedDateTime: '2025-05-18T10:49:57.566Z',
          },
          sentForAuthWorkflowAuditDetails: {
            actionedBy: 'John Doe',
            actionedDateTime: '2025-05-13T08:49:57.566Z',
          },
        }}
      />
    );
    expect(screen.getByText('Rejected')).toBeInTheDocument();
    expect(
      screen.getByText('formatted-2025-05-18T10:49:57.566Z')
    ).toBeInTheDocument();
    expect(screen.getByText('Joe Diszoua')).toBeInTheDocument();
    expect(screen.getByText('Sent for authorisation')).toBeInTheDocument();
    expect(
      screen.getByText('formatted-2025-05-13T08:49:57.566Z')
    ).toBeInTheDocument();
    expect(screen.getByText('John Doe')).toBeInTheDocument();
  });
});
