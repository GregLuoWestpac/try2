import { MVAccountSummary } from '@mesh-tenant-multiverse-ui-common/mv-accountsummary';
import { GridItem } from '@westpac/ui';
import React from 'react';

type DivisionAndPaymentToItem = {
  title: string;
  content: React.ReactNode | string;
};

type Props = {
  division?: string;
  isNewBeneficiary?: boolean;
  gridClassName?: string;
  isFundTransfer?: boolean;
};

export function DivisionAndPaymentTo({
  division = '',
  isNewBeneficiary,
  gridClassName,
  isFundTransfer,
}: Props) {
  const items: DivisionAndPaymentToItem[] = [
    ...(division ? [{ title: 'Division', content: division }] : []),
    ...(isNewBeneficiary !== undefined && !isFundTransfer
      ? [
          {
            title: 'Payment to',
            content: isNewBeneficiary
              ? 'New Beneficiary'
              : 'Existing Beneficiary',
          },
        ]
      : []),
  ];
  if (items.length === 0) {
    return null;
  }
  return (
    <GridItem className={`w-full ${gridClassName}`} span={12}>
      <MVAccountSummary items={items} gridClassName="mt-0" />
    </GridItem>
  );
}
