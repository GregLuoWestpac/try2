import { render, screen } from '@testing-library/react';
import { DivisionAndPaymentTo } from './DivisionAndPaymentTo';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-accountsummary', () => ({
  MVAccountSummary: ({ items }: any) => (
    <div data-testid="mv-account-summary">
      {items.map((item: any, idx: number) => (
        <div key={idx}>
          <span>{item.title}</span>: <span>{item.content}</span>
        </div>
      ))}
    </div>
  ),
}));

jest.mock('@westpac/ui', () => ({
  GridItem: ({ children, className, span }: any) => (
    <div data-testid="grid-item" className={className} data-span={span}>
      {children}
    </div>
  ),
}));

describe('DivisionAndPaymentTo', () => {
  it.skip('renders nothing when no props are provided', () => {
    render(<DivisionAndPaymentTo />);
    expect(screen.getByTestId('mv-account-summary').textContent).toBe('');
  });

  it('renders division when division prop is provided', () => {
    render(<DivisionAndPaymentTo division="Retail" />);
    expect(screen.getByText('Division')).toBeInTheDocument();
    expect(screen.getByText('Retail')).toBeInTheDocument();
  });

  it('renders "Payment to" with "New Beneficiary" when isNewBeneficiary is true', () => {
    render(<DivisionAndPaymentTo isNewBeneficiary={true} />);
    expect(screen.getByText('Payment to')).toBeInTheDocument();
    expect(screen.getByText('New Beneficiary')).toBeInTheDocument();
  });

  it('renders "Payment to" with "Existing Beneficiary" when isNewBeneficiary is false', () => {
    render(<DivisionAndPaymentTo isNewBeneficiary={false} />);
    expect(screen.getByText('Payment to')).toBeInTheDocument();
    expect(screen.getByText('Existing Beneficiary')).toBeInTheDocument();
  });

  it('renders both division and payment to when both props are provided', () => {
    render(
      <DivisionAndPaymentTo division="Corporate" isNewBeneficiary={true} />
    );
    expect(screen.getByText('Division')).toBeInTheDocument();
    expect(screen.getByText('Corporate')).toBeInTheDocument();
    expect(screen.getByText('Payment to')).toBeInTheDocument();
    expect(screen.getByText('New Beneficiary')).toBeInTheDocument();
  });

  it.skip('applies gridClassName to GridItem', () => {
    render(<DivisionAndPaymentTo gridClassName="custom-class" />);
    const gridItem = screen.getByTestId('grid-item');
    expect(gridItem).toHaveClass('w-full');
    expect(gridItem).toHaveClass('custom-class');
    expect(gridItem).toHaveAttribute('data-span', '12');
  });
});
