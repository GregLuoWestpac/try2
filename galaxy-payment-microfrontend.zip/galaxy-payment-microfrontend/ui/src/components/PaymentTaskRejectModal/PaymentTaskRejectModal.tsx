import React, { useCallback, useEffect, useState } from 'react';
import { Button, Modal, ModalBody, InputGroup, Textarea } from '@westpac/ui';
import { OverlayTriggerState } from 'react-stately';
import { REGEX_PATTERN } from 'ui/src/common/constants';

type PaymentTaskRejectModalProps = {
  state: OverlayTriggerState;
  rejectRequest: (isApprove: boolean, comment: string) => void;
};

type CommentValidationResult = {
  isValid: boolean;
  errorMessage?: string;
};

function PaymentTaskRejectModal({
  state,
  rejectRequest,
}: PaymentTaskRejectModalProps) {
  const MAX_COMMENT_LENGTH = 300;
  const [comment, setComment] = useState<string>('');
  const [validationResult, setValidationResult] =
    useState<CommentValidationResult>({ isValid: true });
  const counterText = `${MAX_COMMENT_LENGTH - comment.length} remaining`;
  const invalidErrorMsg = String.raw`Use only letters, numbers, spaces, or the following special characters  -  !  ,  .  :  \  ;  ?  _  @`;
  const handleModalRejectClick = useCallback(() => {
    if (!validationResult.isValid) {
      return;
    }
    rejectRequest(false, comment);
    state.setOpen(false);
  }, [state, rejectRequest, comment, validationResult]);

  useEffect(() => {
    if (!state.isOpen) {
      setComment('');
      setValidationResult({ isValid: true, errorMessage: '' });
    }
  }, [state.isOpen]);

  return (
    <Modal size="md" title="Reject request?" state={state} isDismissable>
      <ModalBody>
        <InputGroup
          label="Comments"
          className="mb-2.5"
          hint="You can provide a reason for your decision. The initiator will be able
          to view your comments."
          supportingText={counterText}
          errorMessage={validationResult.errorMessage}
        >
          <Textarea
            aria-label="Comments"
            className="w-full h-24"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            maxLength={MAX_COMMENT_LENGTH}
            onBlur={() => {
              const regex = REGEX_PATTERN.REJECT_COMMENT;
              if (comment && !regex.test(comment)) {
                setValidationResult({
                  isValid: false,
                  errorMessage: invalidErrorMsg,
                });
              } else {
                setValidationResult({ isValid: true, errorMessage: '' });
              }
            }}
          />
        </InputGroup>
        <div>
          <Button
            look="primary"
            type="submit"
            className="mr-2"
            size="small"
            onClick={handleModalRejectClick}
          >
            Reject
          </Button>
          <Button soft look="hero" onClick={() => state.close()} size="small">
            Cancel
          </Button>
        </div>
      </ModalBody>
    </Modal>
  );
}

export default PaymentTaskRejectModal;
