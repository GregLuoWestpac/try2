import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { OverlayTriggerState } from 'react-stately';
import PaymentTaskRejectModal from './PaymentTaskRejectModal';

describe('PaymentTaskRejectModal', () => {
  const mockRejectRequest = jest.fn();

  function TestHarness({
    isOpenByDefault = true,
  }: {
    isOpenByDefault?: boolean;
  }) {
    const [isOpen, setIsOpen] = React.useState(isOpenByDefault);

    const overlayState: OverlayTriggerState = {
      isOpen,
      setOpen: setIsOpen,
      open: () => setIsOpen(true),
      close: () => setIsOpen(false),
      toggle: () => setIsOpen((prev) => !prev),
    };

    return (
      <div>
        <button type="button" onClick={() => overlayState.open()}>
          Open modal
        </button>
        <PaymentTaskRejectModal
          state={overlayState}
          rejectRequest={mockRejectRequest}
        />
      </div>
    );
  }

  it('renders title and comments field', () => {
    render(<TestHarness />);

    expect(screen.getByText('Reject request?')).toBeInTheDocument();
    expect(screen.getByText('Comments')).toBeInTheDocument();
    expect(
      screen.getByText(/You can provide a reason for your decision\./i)
    ).toBeInTheDocument();
    expect(screen.getByText('300 remaining')).toBeInTheDocument();

    const textarea = screen.getByLabelText('Comments');
    expect(textarea).toHaveAttribute('maxLength', '300');
  });

  it('updates remaining counter as the user types', async () => {
    const user = userEvent.setup();

    render(<TestHarness />);

    await user.type(screen.getByLabelText('Comments'), 'Hello');

    expect(screen.getByText('295 remaining')).toBeInTheDocument();
  });

  it('closes when Cancel is clicked', async () => {
    const user = userEvent.setup();

    render(<TestHarness />);

    await user.click(screen.getByRole('button', { name: 'Cancel' }));
  });

  it('does not disable the Reject button', () => {
    render(<TestHarness />);

    expect(screen.getByRole('button', { name: 'Reject' })).toBeEnabled();
  });

  it('clears the comment when the modal is closed', async () => {
    const user = userEvent.setup();
    render(<TestHarness />);

    await user.type(screen.getByLabelText('Comments'), 'Not compliant');
    expect(screen.getByText('287 remaining')).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Cancel' }));
    await user.click(screen.getByRole('button', { name: 'Open modal' }));

    expect(screen.getByLabelText('Comments')).toHaveValue('');
    expect(screen.getByText('300 remaining')).toBeInTheDocument();
  });

  it('calls mockRejectRequest with the comment and closes when Reject is clicked', async () => {
    const user = userEvent.setup();

    render(<TestHarness />);

    await user.type(screen.getByLabelText('Comments'), 'Not compliant');
    await user.click(screen.getByRole('button', { name: 'Reject' }));

    expect(mockRejectRequest).toHaveBeenCalledWith(false, 'Not compliant');
  });

  it('shows validation error when invalid characters are entered', async () => {
    const user = userEvent.setup();

    render(<TestHarness />);

    const textarea = screen.getByLabelText('Comments');
    await user.type(textarea, 'Invalid <script>');
    await user.tab(); // trigger blur

    expect(
      screen.getByText(/Use only letters, numbers, spaces/i)
    ).toBeInTheDocument();
  });

  it('does not call rejectRequest when validation fails', async () => {
    const user = userEvent.setup();
    mockRejectRequest.mockClear();

    render(<TestHarness />);

    const textarea = screen.getByLabelText('Comments');
    await user.type(textarea, 'Invalid <script>');
    await user.tab(); // trigger blur to set validation error

    await user.click(screen.getByRole('button', { name: 'Reject' }));

    expect(mockRejectRequest).not.toHaveBeenCalled();
  });

  it('clears validation error when the modal is closed and reopened', async () => {
    const user = userEvent.setup();

    render(<TestHarness />);

    const textarea = screen.getByLabelText('Comments');
    await user.type(textarea, 'Invalid <script>');
    await user.tab(); // trigger blur

    expect(
      screen.getByText(/Use only letters, numbers, spaces/i)
    ).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Cancel' }));
    await user.click(screen.getByRole('button', { name: 'Open modal' }));

    expect(
      screen.queryByText(/Use only letters, numbers, spaces/i)
    ).not.toBeInTheDocument();
  });

  it('allows valid special characters in comments', async () => {
    const user = userEvent.setup();
    mockRejectRequest.mockClear();

    render(<TestHarness />);

    const textarea = screen.getByLabelText('Comments');
    await user.type(textarea, 'Valid comment: test-123, ok!');
    await user.tab(); // trigger blur

    expect(
      screen.queryByText(/Use only letters, numbers, spaces/i)
    ).not.toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Reject' }));
    expect(mockRejectRequest).toHaveBeenCalledWith(
      false,
      'Valid comment: test-123, ok!'
    );
  });
});
