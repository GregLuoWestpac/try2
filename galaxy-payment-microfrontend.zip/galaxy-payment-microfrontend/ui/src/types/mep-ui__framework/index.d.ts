/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable max-classes-per-file */

/* This file polyfill the type declaraion for the follow module as mep-ui has not yet provided */
declare module '@mep-ui/framework' {
  import { Provider as ReactProvider } from 'react';
  import { Connect } from 'react-redux';
  import { AnyFunc } from '../common';
  import { Selector } from '../../Interfaces';

  const injectAuthorizationHeaders: AnyFunc; // no type declaration in @mep-ui/framework-api-client
  const isStaffUrl: AnyFunc; // no type declaration in @mep-ui/framework-utilities
  const compose: AnyFunc; // no type declaration in @mep-ui/framework-utilities
  const useMFEConfig: AnyFunc; // no type declaration in @mep-ui/framework-microfrontend
  const useGlobalSelector: AnyFunc; // no type declaration in @mep-ui/framework-store
  const getBrand: AnyFunc; // no type declaration in @mep-ui/framework-app-instance
  const connect: Connect; // no type declaration in @mep-ui/framework-store
  const withProps: AnyFunc; // no type declaration in @mep-ui/framework-utilities
  const Provider: ReactProvider; // no type declaration in @mep-ui/framework-store
  const registerRoutes: AnyFunc; // no type declaration in @mep-ui/framework-microfrontend
  const ssoActions: AnyFunc; // no type declaration in @mep-ui/framework-microfrontend
  const getRouteByFragment: AnyFunc; // no type declaration in @mep-ui/framework-microfrontend
  const useGlobalDispatch: AnyFunc; // no type declaration in @mep-ui/framework-microfrontend
  const watchAppConfig: AnyFunc;
  const createSelector: AnyFunc<Selector<unknown>, any>;
  const branch: AnyFunc;
  const caasGet: AnyFunc;
  const getConfig: AnyFunc;
  const withErrorBoundary: AnyFunc;
  const getBasepath: AnyFunc<string, string, string>;
  const getSsoToken: AnyFunc;
  const useCommunicationContext: AnyFunc;
  const WidgetBoundary: AnyFunc;
  const useManifest: AnyFunc;
  const isLocalUrl: AnyFunc;

  // eslint-disable-next-line react/prefer-stateless-function
  export class ErrorBoundary extends React.Component<
    ErrorBoundaryProps,
    ErrorBoundaryState
  > {
    render(): JSX.Element;
  }

  export class ID {
    static generateUUID(): string;
  }
}
