import { ReactNode } from 'react';
import { BaseIconProps as OriBaseIconProps } from '@mep-ui/component-symbols';

declare module '@mep-ui/component-symbols' {
  interface BaseIconProps extends Omit<OriBaseIconProps, 'svgSource'> {
    svgSource?: string;
  }
}

// Extend Window type to include encode_deviceprint
declare global {
  interface Window {
    encode_deviceprint?: () => string;
  }
}
