/* This file polyfill the type declaraion for the follow module as mep-ui has not yet provided */
declare module '@mep-ui/framework-router-addon' {
  import { NavigateFunction, URLSearchParams } from 'react-router-dom';
  import { AnyComp } from '../common';

  export type AnyComp<P = any> = React.FC<P>;
  // const Link: AnyComp;
  export function useNavigate(): NavigateFunction;
  export function useSearchParams(): [URLSearchParams];
}
