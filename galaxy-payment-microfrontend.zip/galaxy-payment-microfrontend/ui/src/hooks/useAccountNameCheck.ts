import { useCallback, useEffect, useRef, useState } from 'react';
import { FieldValues, Path, UseFormReturn } from 'react-hook-form';
import {
  CoPApiStatus,
  COPCheckResultData,
} from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
import { CLOSED_ACCOUNT_CODES } from '../components/AddNewBeneficiary/Beneficiary.utils';

/**
 * Semantic status of the CoP (Confirmation of Payee) validation flow.
 * The hook returns this status so the UI can derive what to render.
 *
 * - `idle`: No validation in progress; initial state or fields changed after validation.
 * - `pending`: Validation triggered, waiting for API result.
 * - `validated`: API returned a non-closed result (green/amber).
 * - `closed`: API returned a closed/red result.
 * - `checkRequired`: Review was triggered but user hasn't clicked "Check Details".
 */
export type CopValidationStatus =
  | 'idle'
  | 'pending'
  | 'validated'
  | 'closed'
  | 'checkRequired';

/** Field path configuration so the hook is not coupled to any specific form shape. */
export interface AccountNameCheckFieldPaths<T extends FieldValues> {
  bsb: Path<T>;
  accountNumber: Path<T>;
  accountName: Path<T>;
  beneficiaryType: Path<T>;
}

export interface UseAccountNameCheckParams<T extends FieldValues> {
  form: UseFormReturn<T>;
  fieldPaths: AccountNameCheckFieldPaths<T>;
  /** The beneficiary-type value that represents BSB/Account Number (e.g. `BeneTypes.BSB_ACCOUNT_NUMBER`). */
  bsbBeneficiaryTypeValue: string;
  postAccountNameCheck?: (params: {
    accountName: string;
    accountNumber: string;
    bsb: string;
  }) => void;
  copCheckResultData?: COPCheckResultData;
  isCopLoading?: boolean;
  onAccountValidationChange?: (isValidated: boolean) => void;
  onInvalidateCopCheck?: () => void;
  lookupState?: React.MutableRefObject<{
    triggeredByReview: boolean;
    fieldName: string | null;
  }>;
}

export interface UseAccountNameCheckReturn {
  copValidationStatus: CopValidationStatus;
  isCheckDetailsClicked: boolean;
  isAccountClosed: boolean;
  validatedFieldValues: React.MutableRefObject<{
    bsb: string;
    accountNumber: string;
    accountName: string;
  }>;
  handleCheckDetails: () => Promise<void>;
  resetValidationState: () => void;
  /** Call from a form validator to signal that "Check Details" is required before review. */
  notifyCheckRequired: () => void;
}

/**
 * Custom hook for managing CoP (Confirmation of Payee) account name check state.
 * Generic over the form type so it can be reused across MFEs with different form shapes.
 */
export function useAccountNameCheck<T extends FieldValues>({
  form,
  fieldPaths,
  bsbBeneficiaryTypeValue,
  postAccountNameCheck,
  copCheckResultData,
  isCopLoading = false,
  onAccountValidationChange,
  onInvalidateCopCheck,
  lookupState,
}: UseAccountNameCheckParams<T>): UseAccountNameCheckReturn {
  const [isCheckDetailsClicked, setIsCheckDetailsClicked] = useState(false);
  const [isAccountClosed, setIsAccountClosed] = useState(false);
  const [copValidationStatus, setCopValidationStatus] =
    useState<CopValidationStatus>('idle');

  const validatedFieldValues = useRef({
    bsb: '',
    accountNumber: '',
    accountName: '',
  });

  const { trigger, watch, getValues, clearErrors } = form;

  // Watch fields for change detection
  const watchBsb = watch(fieldPaths.bsb);
  const watchAccountNumber = watch(fieldPaths.accountNumber);
  const watchAccountName = watch(fieldPaths.accountName);
  const watchBeneficiaryType = watch(fieldPaths.beneficiaryType);

  // Notify parent when validation status changes
  useEffect(() => {
    onAccountValidationChange?.(isCheckDetailsClicked);
  }, [isCheckDetailsClicked, onAccountValidationChange]);

  // Monitor field changes after "Check Details" is clicked
  useEffect(() => {
    if (
      isCheckDetailsClicked &&
      watchBeneficiaryType === bsbBeneficiaryTypeValue
    ) {
      const hasChanged =
        watchBsb !== validatedFieldValues.current.bsb ||
        watchAccountNumber !== validatedFieldValues.current.accountNumber ||
        watchAccountName !== validatedFieldValues.current.accountName;

      if (hasChanged) {
        setIsCheckDetailsClicked(false);
        setIsAccountClosed(false);
        setCopValidationStatus('idle');
        onAccountValidationChange?.(false);
        onInvalidateCopCheck?.();
      }
    }
  }, [
    watchBsb,
    watchAccountNumber,
    watchAccountName,
    isCheckDetailsClicked,
    watchBeneficiaryType,
    bsbBeneficiaryTypeValue,
    onAccountValidationChange,
    onInvalidateCopCheck,
  ]);

  // Handle CoP result when it arrives
  useEffect(() => {
    if (
      copCheckResultData &&
      copValidationStatus === 'pending' &&
      !isCopLoading
    ) {
      const statusCode =
        copCheckResultData.matchedCOPStatusCode as CoPApiStatus;
      const isClosed = statusCode
        ? CLOSED_ACCOUNT_CODES.includes(
            statusCode as (typeof CLOSED_ACCOUNT_CODES)[number]
          )
        : false;

      // Also check for Red color (closed/not found accounts)
      const isRedStatus = copCheckResultData.matchedCOPColour === 'Red';

      if (isClosed || isRedStatus) {
        setIsAccountClosed(true);
        setIsCheckDetailsClicked(false);
        setCopValidationStatus('closed');
        onAccountValidationChange?.(false);
      } else {
        // Store validated values
        const currentBsb = String(getValues(fieldPaths.bsb) ?? '');
        const currentAccountNumber = String(
          getValues(fieldPaths.accountNumber) ?? ''
        );
        const currentAccountName = String(
          getValues(fieldPaths.accountName) ?? ''
        );

        validatedFieldValues.current = {
          bsb: currentBsb,
          accountNumber: currentAccountNumber,
          accountName: currentAccountName,
        };
        setIsCheckDetailsClicked(true);
        setIsAccountClosed(false);
        setCopValidationStatus('validated');
        onAccountValidationChange?.(true);
      }
    }
  }, [
    copCheckResultData,
    copValidationStatus,
    isCopLoading,
    onAccountValidationChange,
    getValues,
    fieldPaths,
  ]);

  // Show alert when review is triggered without Check Details being clicked
  useEffect(() => {
    if (
      lookupState?.current.triggeredByReview &&
      !isCheckDetailsClicked &&
      watchBeneficiaryType === bsbBeneficiaryTypeValue
    ) {
      setCopValidationStatus('checkRequired');
    } else if (copValidationStatus === 'checkRequired') {
      setCopValidationStatus('idle');
    }
  }, [
    lookupState,
    isCheckDetailsClicked,
    watchBeneficiaryType,
    bsbBeneficiaryTypeValue,
  ]);

  const handleCheckDetails = useCallback(async () => {
    // Reset validation state before checking
    setIsCheckDetailsClicked(false);
    setIsAccountClosed(false);
    setCopValidationStatus('idle');
    onAccountValidationChange?.(false);
    clearErrors(fieldPaths.accountName);

    if (lookupState?.current) {
      lookupState.current.triggeredByReview = false;
    }

    // Validate BSB, account number, and account name fields
    const isValid = await trigger([
      fieldPaths.bsb,
      fieldPaths.accountNumber,
      fieldPaths.accountName,
    ] as Path<T>[]);

    if (isValid && postAccountNameCheck) {
      const bsb = String(getValues(fieldPaths.bsb) ?? '');
      const accountNumber = String(getValues(fieldPaths.accountNumber) ?? '');
      const accountName = String(getValues(fieldPaths.accountName) ?? '');

      // Store values for change detection
      validatedFieldValues.current = {
        bsb,
        accountNumber,
        accountName,
      };

      setCopValidationStatus('pending');
      postAccountNameCheck({
        accountName,
        accountNumber,
        bsb,
      });
    } else if (isValid && !postAccountNameCheck) {
      // Fallback if no API provided (for testing)
      const bsb = String(getValues(fieldPaths.bsb) ?? '');
      const accountNumber = String(getValues(fieldPaths.accountNumber) ?? '');
      const accountName = String(getValues(fieldPaths.accountName) ?? '');

      validatedFieldValues.current = {
        bsb,
        accountNumber,
        accountName,
      };
      setIsCheckDetailsClicked(true);
      onAccountValidationChange?.(true);
    }
  }, [
    trigger,
    getValues,
    clearErrors,
    fieldPaths,
    postAccountNameCheck,
    lookupState,
    onAccountValidationChange,
  ]);

  const resetValidationState = useCallback(() => {
    setIsCheckDetailsClicked(false);
    setIsAccountClosed(false);
    setCopValidationStatus('idle');
    validatedFieldValues.current = {
      bsb: '',
      accountNumber: '',
      accountName: '',
    };
    onAccountValidationChange?.(false);
  }, [onAccountValidationChange]);

  const notifyCheckRequired = useCallback(() => {
    setCopValidationStatus('checkRequired');
  }, []);

  return {
    copValidationStatus,
    isCheckDetailsClicked,
    isAccountClosed,
    validatedFieldValues,
    handleCheckDetails,
    resetValidationState,
    notifyCheckRequired,
  };
}
