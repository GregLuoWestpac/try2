import { useMemo } from 'react';
import { usePlatformState } from '@mesh-tenant-multiverse-common/react';
import { useOrganizationId } from './useOrganizationId';
import { CustomerDetails } from '../common/types';
import { CONTAINERTAB_TITLES } from '../common/constants';
import { useSelectedCustomer } from './useSelectedCustomer';

type ViewOptions = {
  windowTabKey: string;
  windowTabTitle: string;
  containerTabTitle: string;
};

export default function useViewOptions(
  containerTabTitle: string
): ViewOptions {
  const orgId = useOrganizationId();
  const selectedCustomer = useSelectedCustomer();
  const [selectedCustomerDetails] = usePlatformState<Record<string, CustomerDetails[]>>(
    'w1c/customerDetails',
    {}
  );

  const customerData = useMemo(() => {
    if (!selectedCustomerDetails || !orgId) {
      return { fullName: '' };
    }
    const customer = selectedCustomerDetails[orgId]?.[0];
    return {
      fullName: customer?.fullName || '',
    };
  }, [selectedCustomerDetails, orgId]);

  const viewOptions = useMemo<ViewOptions>(
    () => ({
      containerTabTitle,
      windowTabKey: selectedCustomer?.cisKey ?? '',
      windowTabTitle: customerData?.fullName ?? '',
    }),
    [containerTabTitle, customerData?.fullName, selectedCustomer?.cisKey]
  );

  return viewOptions;
}