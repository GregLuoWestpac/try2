import { renderHook } from '@testing-library/react';
import { usePlatformState } from '@mesh-tenant-multiverse-common/react';
import useViewOptions from './useViewOptions';
import { useOrganizationId } from './useOrganizationId';
import { useSelectedCustomer } from './useSelectedCustomer';
import { CONTAINERTAB_TITLES } from '../common/constants';

jest.mock('@mesh-tenant-multiverse-common/react');
jest.mock('./useOrganizationId');
jest.mock('./useSelectedCustomer');

describe('useViewOptions', () => {
  const mockUsePlatformState = usePlatformState as jest.MockedFunction<typeof usePlatformState>;
  const mockUseOrganizationId = useOrganizationId as jest.MockedFunction<typeof useOrganizationId>;
  const mockUseSelectedCustomer = useSelectedCustomer as jest.MockedFunction<typeof useSelectedCustomer>;

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should return view options with correct values', () => {
    const mockOrgId = 'org123';
    const mockCustomer = { cisKey: 'customer456' };
    const mockCustomerDetails = {
      org123: [{ fullName: 'John Doe' }],
    };

    mockUseOrganizationId.mockReturnValue(mockOrgId);
    mockUseSelectedCustomer.mockReturnValue(mockCustomer);
    mockUsePlatformState.mockReturnValue([mockCustomerDetails, jest.fn()]);

    const { result } = renderHook(() => useViewOptions(CONTAINERTAB_TITLES.PAYMENT_STATUS));

    expect(result.current).toEqual({
      windowTabKey: 'customer456',
      windowTabTitle: 'John Doe',
      containerTabTitle: CONTAINERTAB_TITLES.PAYMENT_STATUS,
    });
  });

  it('should return empty strings when no customer details available', () => {
    mockUseSelectedCustomer.mockReturnValue(null);
    mockUsePlatformState.mockReturnValue([{}, jest.fn()]);

    const { result } = renderHook(() => useViewOptions(CONTAINERTAB_TITLES.PAYMENT_STATUS));

    expect(result.current).toEqual({
      windowTabKey: '',
      windowTabTitle: '',
      containerTabTitle: CONTAINERTAB_TITLES.PAYMENT_STATUS,
    });
  });

  it('should use different containerTabTitle when provided', () => {
    const mockOrgId = 'org123';
    const mockCustomer = { cisKey: 'customer456' };
    const mockCustomerDetails = {
      org123: [{ fullName: 'Jane Smith' }],
    };

    mockUseOrganizationId.mockReturnValue(mockOrgId);
    mockUseSelectedCustomer.mockReturnValue(mockCustomer);
    mockUsePlatformState.mockReturnValue([mockCustomerDetails, jest.fn()]);

    const { result } = renderHook(() => useViewOptions(CONTAINERTAB_TITLES.ACCOUNT_ACTIVITY));

    expect(result.current.containerTabTitle).toBe(CONTAINERTAB_TITLES.ACCOUNT_ACTIVITY);
  });

  it('should handle missing fullName in customer details', () => {
    const mockOrgId = 'org123';
    const mockCustomer = { cisKey: 'customer456' };
    const mockCustomerDetails = {
      org123: [{}], 
    };

    mockUseOrganizationId.mockReturnValue(mockOrgId);
    mockUseSelectedCustomer.mockReturnValue(mockCustomer);
    mockUsePlatformState.mockReturnValue([mockCustomerDetails, jest.fn()]);

    const { result } = renderHook(() => useViewOptions(CONTAINERTAB_TITLES.PAYMENT_STATUS));

    expect(result.current.windowTabTitle).toBe('');
  });
});