/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { renderHook } from '@testing-library/react';
import { useGlobalSelector } from '@mep-ui/framework';
import { usePlatformState } from '@mesh-tenant-multiverse-common/react';
import { isStaffPortal } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { useOrganizationId } from './useOrganizationId';

// Mock the dependencies
jest.mock('@mep-ui/framework', () => ({
  useGlobalSelector: jest.fn(),
  // ensure local URL check is stubbed for tests using useOrganizationId
  isLocalUrl: jest.fn(() => false),
}));

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  usePlatformState: jest.fn(),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  isStaffPortal: jest.fn(),
}));

const mockUseGlobalSelector = useGlobalSelector as jest.MockedFunction<
  typeof useGlobalSelector
>;
const mockUsePlatformState = usePlatformState as jest.MockedFunction<
  typeof usePlatformState
>;
const mockIsStaffPortal = isStaffPortal as jest.MockedFunction<
  typeof isStaffPortal
>;

describe('useOrganizationId', () => {
  const mockSetPlatformState = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    // Reset the mock implementations
    mockUseGlobalSelector.mockImplementation(() => null);
  });

  describe('when not in staff portal', () => {
    beforeEach(() => {
      mockIsStaffPortal.mockReturnValue(false);
    });

    it('should return organisationSSOData.orgId.organisationId when available', () => {
      const mockOrganisationSSOData = {
        orgId: {
          organisationId: 'ORG_SSO_123',
        },
      };

      // Mock usePlatformState for both calls: organisationSSOData and selectedOrgCisKey
      mockUsePlatformState
        .mockReturnValueOnce([mockOrganisationSSOData, mockSetPlatformState])
        .mockReturnValueOnce([undefined, mockSetPlatformState]); // selectedOrgCisKey
      mockUseGlobalSelector.mockReturnValue(null);

      const { result } = renderHook(() => useOrganizationId());

      expect(result.current).toBe('ORG_SSO_123');
      expect(mockIsStaffPortal).toHaveBeenCalled();
    });

    it('should return undefined when organisationSSOData.orgId.organisationId is not available', () => {
      const mockOrganisationSSOData = {}; // no orgId property

      // Mock usePlatformState for both calls: organisationSSOData and selectedOrgCisKey
      mockUsePlatformState
        .mockReturnValueOnce([mockOrganisationSSOData, mockSetPlatformState])
        .mockReturnValueOnce([undefined, mockSetPlatformState]); // selectedOrgCisKey
      mockUseGlobalSelector.mockReturnValue(null);

      const { result } = renderHook(() => useOrganizationId());

      expect(result.current).toBeUndefined();
    });

    it('should return undefined when organisationSSOData is empty', () => {
      // Mock usePlatformState for both calls: organisationSSOData and selectedOrgCisKey
      mockUsePlatformState
        .mockReturnValueOnce([{}, mockSetPlatformState])
        .mockReturnValueOnce([undefined, mockSetPlatformState]); // selectedOrgCisKey
      mockUseGlobalSelector.mockReturnValue(null);

      const { result } = renderHook(() => useOrganizationId());

      expect(result.current).toBeUndefined();
    });
  });

  describe('when in staff portal', () => {
    beforeEach(() => {
      mockIsStaffPortal.mockReturnValue(true);
    });

    it('should return orgIdFromContext when available', () => {
      const mockOrganisationSSOData = {
        orgId: {
          organisationId: 'ORG_SSO_123',
        },
      };

      // Mock usePlatformState for both calls: organisationSSOData and selectedOrgCisKey
      mockUsePlatformState
        .mockReturnValueOnce([mockOrganisationSSOData, mockSetPlatformState])
        .mockReturnValueOnce([undefined, mockSetPlatformState]); // selectedOrgCisKey

      // Mock the selector calls - first call returns selectedCustomer, second returns orgIdFromContext
      mockUseGlobalSelector
        .mockReturnValueOnce({ cisKey: 'CUSTOMER_456' }) // selectedCustomer
        .mockReturnValueOnce('ORG_CONTEXT_789'); // orgIdFromContext

      const { result } = renderHook(() => useOrganizationId());

      expect(result.current).toBe('ORG_CONTEXT_789');
      expect(mockIsStaffPortal).toHaveBeenCalled();
    });

    it('should return selectedCustomer.cisKey when orgIdFromContext is not available', () => {
      const mockOrganisationSSOData = {
        orgId: {
          organisationId: 'ORG_SSO_123',
        },
      };

      // Mock usePlatformState for both calls: organisationSSOData and selectedOrgCisKey
      mockUsePlatformState
        .mockReturnValueOnce([mockOrganisationSSOData, mockSetPlatformState])
        .mockReturnValueOnce([undefined, mockSetPlatformState]); // selectedOrgCisKey

      // Mock the selector calls - first call returns selectedCustomer, second returns undefined
      mockUseGlobalSelector
        .mockReturnValueOnce({ cisKey: 'CUSTOMER_456' }) // selectedCustomer
        .mockReturnValueOnce(undefined); // orgIdFromContext

      const { result } = renderHook(() => useOrganizationId());

      expect(result.current).toBe('CUSTOMER_456');
      expect(mockIsStaffPortal).toHaveBeenCalled();
    });

    it('should return undefined when neither orgIdFromContext nor selectedCustomer.cisKey are available', () => {
      const mockOrganisationSSOData = {
        orgId: {
          organisationId: 'ORG_SSO_123',
        },
      };

      // Mock usePlatformState for both calls: organisationSSOData and selectedOrgCisKey
      mockUsePlatformState
        .mockReturnValueOnce([mockOrganisationSSOData, mockSetPlatformState])
        .mockReturnValueOnce([undefined, mockSetPlatformState]); // selectedOrgCisKey

      // Mock the selector calls to return no useful data
      mockUseGlobalSelector
        .mockReturnValueOnce({}) // selectedCustomer with no cisKey
        .mockReturnValueOnce(undefined); // orgIdFromContext

      const { result } = renderHook(() => useOrganizationId());

      expect(result.current).toBeUndefined();
    });

    it('should return undefined when selectedCustomer is null and orgIdFromContext is undefined', () => {
      const mockOrganisationSSOData = {
        orgId: {
          organisationId: 'ORG_SSO_123',
        },
      };

      // Mock usePlatformState for both calls: organisationSSOData and selectedOrgCisKey
      mockUsePlatformState
        .mockReturnValueOnce([mockOrganisationSSOData, mockSetPlatformState])
        .mockReturnValueOnce([undefined, mockSetPlatformState]); // selectedOrgCisKey

      mockUseGlobalSelector
        .mockReturnValueOnce(null) // selectedCustomer
        .mockReturnValueOnce(undefined); // orgIdFromContext

      const { result } = renderHook(() => useOrganizationId());

      expect(result.current).toBeUndefined();
    });
  });

  describe('edge cases', () => {
    it('should handle empty strings correctly in non-staff portal', () => {
      mockIsStaffPortal.mockReturnValue(false);
      const mockOrganisationSSOData = {
        orgId: {
          organisationId: '',
        },
      }; // empty string

      // Mock usePlatformState for both calls: organisationSSOData and selectedOrgCisKey
      mockUsePlatformState
        .mockReturnValueOnce([mockOrganisationSSOData, mockSetPlatformState])
        .mockReturnValueOnce([undefined, mockSetPlatformState]); // selectedOrgCisKey
      mockUseGlobalSelector.mockReturnValue(null);

      const { result } = renderHook(() => useOrganizationId());

      expect(result.current).toBe('');
    });

    it('should handle empty strings correctly in staff portal', () => {
      mockIsStaffPortal.mockReturnValue(true);
      const mockOrganisationSSOData = {
        orgId: {
          organisationId: 'ORG_SSO_123',
        },
      };

      // Mock usePlatformState for both calls: organisationSSOData and selectedOrgCisKey
      mockUsePlatformState
        .mockReturnValueOnce([mockOrganisationSSOData, mockSetPlatformState])
        .mockReturnValueOnce([undefined, mockSetPlatformState]); // selectedOrgCisKey

      mockUseGlobalSelector
        .mockReturnValueOnce({ cisKey: '' }) // selectedCustomer with empty cisKey
        .mockReturnValueOnce(''); // orgIdFromContext with empty string

      const { result } = renderHook(() => useOrganizationId());

      expect(result.current).toBe(''); // Should return empty string from orgIdFromContext
    });

    it('should prefer orgIdFromContext over selectedCustomer.cisKey when both are available', () => {
      mockIsStaffPortal.mockReturnValue(true);
      const mockOrganisationSSOData = {
        orgId: {
          organisationId: 'ORG_SSO_123',
        },
      };

      // Mock usePlatformState for both calls: organisationSSOData and selectedOrgCisKey
      mockUsePlatformState
        .mockReturnValueOnce([mockOrganisationSSOData, mockSetPlatformState])
        .mockReturnValueOnce([undefined, mockSetPlatformState]); // selectedOrgCisKey

      mockUseGlobalSelector
        .mockReturnValueOnce({ cisKey: 'CUSTOMER_456' }) // selectedCustomer
        .mockReturnValueOnce('ORG_CONTEXT_789'); // orgIdFromContext

      const { result } = renderHook(() => useOrganizationId());

      expect(result.current).toBe('ORG_CONTEXT_789'); // Should prefer orgIdFromContext
    });
  });

  describe('hook dependencies', () => {
    it('should call usePlatformState with correct parameters', () => {
      mockIsStaffPortal.mockReturnValue(false);
      // Mock usePlatformState for both calls: organisationSSOData and selectedOrgCisKey
      mockUsePlatformState
        .mockReturnValueOnce([{}, mockSetPlatformState])
        .mockReturnValueOnce([undefined, mockSetPlatformState]); // selectedOrgCisKey
      mockUseGlobalSelector.mockReturnValue(null);

      renderHook(() => useOrganizationId());

      expect(mockUsePlatformState).toHaveBeenCalledWith('w1/organisationSso', {
        orgId: {
          organisationId: '',
        },
      });
    });

    it('should call useGlobalSelector twice in staff portal', () => {
      mockIsStaffPortal.mockReturnValue(true);
      // Mock usePlatformState for both calls: organisationSSOData and selectedOrgCisKey
      mockUsePlatformState
        .mockReturnValueOnce([{}, mockSetPlatformState])
        .mockReturnValueOnce([undefined, mockSetPlatformState]); // selectedOrgCisKey
      mockUseGlobalSelector.mockReturnValue(null);

      renderHook(() => useOrganizationId());

      expect(mockUseGlobalSelector).toHaveBeenCalledTimes(2);
      expect(mockUseGlobalSelector).toHaveBeenNthCalledWith(
        1,
        expect.any(Function)
      );
      expect(mockUseGlobalSelector).toHaveBeenNthCalledWith(
        2,
        expect.any(Function)
      );
    });

    it('should call useGlobalSelector twice in non-staff portal', () => {
      mockIsStaffPortal.mockReturnValue(false);
      // Mock usePlatformState for both calls: organisationSSOData and selectedOrgCisKey
      mockUsePlatformState
        .mockReturnValueOnce([{}, mockSetPlatformState])
        .mockReturnValueOnce([undefined, mockSetPlatformState]); // selectedOrgCisKey
      mockUseGlobalSelector.mockReturnValue(null);

      renderHook(() => useOrganizationId());

      expect(mockUseGlobalSelector).toHaveBeenCalledTimes(2);
    });
  });
});
