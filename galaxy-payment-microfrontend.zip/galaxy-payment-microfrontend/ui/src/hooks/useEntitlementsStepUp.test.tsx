/* eslint-disable react/destructuring-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/react-in-jsx-scope */
import { useGlobalSelector } from '@mep-ui/framework';
import { render, act } from '@testing-library/react';
import {
  EntitlementMakerCheckerProps,
  EntitlementMFAProps,
  useEntitlementsStepUp,
} from './useEntitlementsStepUp';
import { ERROR_CODES, MFA_CODE } from '../common/constants';
import { PingmfaWidgetApp } from '../widgets/pingmfa';

jest.mock('@mep-ui/framework', () => ({
  __esModule: true,
  useGlobalSelector: jest.fn(),
  useGlobalDispatch: jest.fn(() => jest.fn()),
}));

// Capture callbackFromEntitlementsLib for test
let lastCallbackFromEntitlementsLib: any;
jest.mock(
  '@mesh-tenant-user-authorisation-policy-decision-engine/components',
  () => ({
    EntitlementsStepUp: (props: any) => {
      lastCallbackFromEntitlementsLib = props.callbackFromEntitlementsLib;
      return <div data-testid="entitlements-stepup-mock">{props.children}</div>;
    },
  })
);

jest.mock('../widgets/pingmfa', () => ({
  PingmfaWidgetApp: () => <div data-testid="widget-app-mock">WidgetApp</div>,
}));

const mockSetIsStepUpModalVisible = jest.fn();
const dispatchFn = jest.fn();
const mockAppCorrelationId = 'test-correlation-id';

const getError = (code = ERROR_CODES.STEP_UP_REQUIRED) => ({
  code,
  message: 'Step up required',
});

describe('useEntitlementsStepUp', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    (useGlobalSelector as jest.Mock).mockImplementation((cb) =>
      // eslint-disable-next-line @typescript-eslint/no-unsafe-return
      cb({ global: { instance: { appCorrelationId: mockAppCorrelationId } } })
    );
  });

  function TestComponent(
    props: EntitlementMFAProps | EntitlementMakerCheckerProps
  ) {
    const { renderEntitlementsStepUp } = useEntitlementsStepUp(props);
    return renderEntitlementsStepUp();
  }

  it('should render EntitlementsStepUp when step up is required and modal is visible', () => {
    const beneficiaryError = {
      status: 401,
      data: { errors: [getError()] },
    };
    const { container } = render(
      <TestComponent
        pingMfaWidget={<PingmfaWidgetApp />}
        propType="mfa"
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        dispatchFn={dispatchFn}
        dispatchFnParams={{ foo: 'bar' }}
        isStepUpModalVisible
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should not render EntitlementsStepUp if step up is not required', () => {
    const beneficiaryError = {
      status: 400,
      data: { errors: [getError()] },
    };
    const { container } = render(
      <TestComponent
        pingMfaWidget={<PingmfaWidgetApp />}
        propType="mfa"
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        dispatchFn={dispatchFn}
        dispatchFnParams={{}}
        isStepUpModalVisible
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
      />
    );
    expect(container.innerHTML).toBe('');
  });
  it('should render EntitlementsStepUp for makerChecker type when step up is required and modal is visible', () => {
    const beneficiaryError = {
      status: 401,
      data: { errors: [getError()] },
    };

    const mockUpdateTrigger = jest.fn();

    const { container, getByTestId } = render(
      <TestComponent
        pingMfaWidget={<PingmfaWidgetApp />}
        propType="makerChecker"
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        updateTrigger={mockUpdateTrigger}
        isStepUpModalVisible
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
      />
    );

    expect(container).toBeTruthy();
    expect(getByTestId('entitlements-stepup-mock')).toBeInTheDocument();
  });
  it('should close modal on Escape keydown', () => {
    const beneficiaryError = {
      status: 401,
      data: { errors: [getError()] },
    };
    render(
      <TestComponent
        pingMfaWidget={<PingmfaWidgetApp />}
        propType="mfa"
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        dispatchFn={dispatchFn}
        dispatchFnParams={{}}
        isStepUpModalVisible
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
      />
    );
    const event = new KeyboardEvent('keydown', { key: 'Escape' });
    act(() => {
      document.dispatchEvent(event);
    });
    expect(mockSetIsStepUpModalVisible).toHaveBeenCalledWith(false);
  });

  it('should close modal if callbackFromEntitlementsLib is called with MFA_CANCEL', () => {
    const beneficiaryError = {
      status: 401,
      data: { errors: [getError()] },
    };
    // Reset the callback before the test
    lastCallbackFromEntitlementsLib = undefined;
    function TestCallbackComponent(props: any) {
      const { renderEntitlementsStepUp } = useEntitlementsStepUp(props);
      return renderEntitlementsStepUp();
    }
    render(
      <TestCallbackComponent
        propType="mfa"
        errors={beneficiaryError.data.errors}
        apiStatus={beneficiaryError.status}
        dispatchFn={dispatchFn}
        dispatchFnParams={{}}
        isStepUpModalVisible
        setIsStepUpModalVisible={mockSetIsStepUpModalVisible}
      />
    );
    expect(typeof lastCallbackFromEntitlementsLib).toBe('function');
    act(() => {
      lastCallbackFromEntitlementsLib(false, mockAppCorrelationId, {
        code: MFA_CODE.MFA_CANCELLED,
        message: 'cancelled',
      });
    });
    expect(mockSetIsStepUpModalVisible).toHaveBeenCalledWith(false);
  });
});
