import React from 'react';
import { renderHook, act } from '@testing-library/react';
import { useSelectedCustomer } from '../useSelectedCustomer';
import type { GlobalState, CustomerData } from '../../store/types/RootStates';

// Mock the @mep-ui/framework module and its hook useGlobalSelector
jest.mock('@mep-ui/framework', () => ({
  useGlobalSelector: (selector: (state: GlobalState) => any) => {
    // Delegate to a mutable mock state so tests can manipulate it.
    return selector((globalThis as any).__MOCK_GLOBAL_STATE__);
  },
}));

/**
 * Utility to set the mock global state for each test scenario.
 */
function setMockState(state: Partial<GlobalState>) {
  (globalThis as any).__MOCK_GLOBAL_STATE__ = state as GlobalState;
}

describe('useSelectedCustomer', () => {
  beforeEach(() => {
    // Reset mock state before every test
    setMockState({} as GlobalState);
  });

  it('returns null when global state is empty', () => {
    const { result } = renderHook(() => useSelectedCustomer());
    expect(result.current).toBeNull();
  });

  it('returns null when context exists but selectedCustomer is undefined', () => {
    setMockState({
      global: {
        galaxy: { context: {} },
      },
    } as unknown as GlobalState);
    const { result } = renderHook(() => useSelectedCustomer());
    expect(result.current).toBeNull();
  });

  it('returns the selectedCustomer when present', () => {
    const customer: CustomerData = {
      cisKey: 'ABC123',
      tenXPartyKey: 'TENX999',
    };
    setMockState({
      global: {
        galaxy: { context: { selectedCustomer: customer } },
      },
    } as unknown as GlobalState);
    const { result } = renderHook(() => useSelectedCustomer());
    expect(result.current).toEqual(customer);
  });

  it('reacts to changes in selectedCustomer between renders', () => {
    const first: CustomerData = { cisKey: 'FIRST', tenXPartyKey: 'TENX1' };
    const second: CustomerData = { cisKey: 'SECOND', tenXPartyKey: 'TENX2' };
    setMockState({
      global: {
        galaxy: { context: { selectedCustomer: first } },
      },
    } as unknown as GlobalState);

    const { result, rerender } = renderHook(() => useSelectedCustomer());
    expect(result.current).toEqual(first);

    // Update mock state and rerender
    act(() => {
      setMockState({
        global: {
          galaxy: { context: { selectedCustomer: second } },
        },
      } as unknown as GlobalState);
    });
    rerender();
    expect(result.current).toEqual(second);
  });

  it('returns object with only defined keys (cisKey / tenXPartyKey optional)', () => {
    const customer: CustomerData = { cisKey: 'ONLYCIS' }; // tenXPartyKey omitted
    setMockState({
      global: {
        galaxy: { context: { selectedCustomer: customer } },
      },
    } as unknown as GlobalState);
    const { result } = renderHook(() => useSelectedCustomer());
    expect(result.current).toEqual(customer);
    expect(result.current?.tenXPartyKey).toBeUndefined();
  });
});
