/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import React from 'react';
import { useGlobalSelector } from '@mep-ui/framework';
import { usePlatformState } from '@mesh-tenant-multiverse-common/react';
import { CustomerData, GlobalState } from '../store/types';

/**
 * Custom hook that retrieves the currently selected customer from the global state.
 *
 * @returns {CustomerData | null} The selected customer data object if one is selected,
 * or null if no customer is currently selected.
 *
 * @example
 * ```tsx
 * const selectedCustomer = useSelectedCustomer();
 *
 * if (selectedCustomer) {
 *   console.log('Customer selected:', selectedCustomer.cisKey);
 * } else {
 *   console.log('No customer selected');
 * }
 * ```
 */

export function useSelectedCustomer() {
  const selectedCustomer: CustomerData | null = useGlobalSelector(
    (state: GlobalState) =>
      state?.global?.galaxy?.context?.selectedCustomer || null
  );

  const [selectedCustomerFromPlatformState] = usePlatformState<
    CustomerData | undefined
  >('w1c.selectedCustomer', undefined);

  return selectedCustomerFromPlatformState ?? selectedCustomer;
}
