/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import { useMemo } from 'react';
import { useGlobalSelector, isLocalUrl } from '@mep-ui/framework';
import { usePlatformState } from '@mesh-tenant-multiverse-common/react';
import { isStaffPortal } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { W1_ORGANIZATION_SSO } from '../common/constants';
import type { CustomerData, GlobalState } from '../store/types';

interface OrganizationSSOData {
  orgId: {
    organisationId: '';
  };
}

/**
 * Custom hook to get the organization ID based on the current portal context.
 *
 * @returns {string | undefined} The organization ID:
 *   - For non-staff portals: Returns organisationSSOData.id
 *   - For staff portals: Returns orgId from context, or falls back to selectedCustomer.cisKey
 *   - Returns undefined if the respective data is not available
 */
export function useOrganizationId(): string | undefined {
  const [organisationSSOData] = usePlatformState<OrganizationSSOData>(
    W1_ORGANIZATION_SSO,
    {
      orgId: {
        organisationId: '',
      },
    }
  );

  const selectedCustomer: CustomerData | null = useGlobalSelector(
    (state: GlobalState) =>
      state?.global?.galaxy?.context?.selectedCustomer || null
  );

  const orgIdFromContext: string | undefined = useGlobalSelector(
    (state: GlobalState) => state?.global?.galaxy?.context?.orgId
  );

  const [selectedOrgCisKey] = usePlatformState<string | undefined>(
    'w1c.selectedOrgCisKey',
    undefined
  );

  const orgIdForCustomerPortal = organisationSSOData?.orgId?.organisationId;

  const orgId = useMemo<string | undefined>(
    () =>
      !isStaffPortal()
        ? orgIdForCustomerPortal
        : orgIdFromContext ?? selectedOrgCisKey ?? selectedCustomer?.cisKey,
    [
      orgIdForCustomerPortal,
      orgIdFromContext,
      selectedOrgCisKey,
      selectedCustomer?.cisKey,
    ]
  );

  // Local dev requires an 11-digit orgId to satisfy request validator
  return isLocalUrl() ? '12345678910' : orgId;
}
