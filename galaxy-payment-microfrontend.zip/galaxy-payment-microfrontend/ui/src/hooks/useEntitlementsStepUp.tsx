/* eslint-disable consistent-return */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-use-before-define */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-enum-comparison */
/* eslint-disable react/jsx-no-bind */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { useGlobalDispatch, useGlobalSelector } from '@mep-ui/framework';
import {
  EntitlementsStepUp,
  EntitlementStepUpMakerCheckerProps,
  EntitlementStepUpMFAProps,
  ErrorResponse,
} from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import React, { useEffect } from 'react';
import { ERROR_CODES, MFA_CODE } from '../common/constants';
import { GlobalState } from '../store/types';

export type EntitlementBaseProps = {
  pingMfaWidget: React.ReactElement;
  apiStatus: number | undefined;
  errors: ErrorResponse[] | undefined;
  isStepUpModalVisible: boolean;
  setIsStepUpModalVisible: (value: boolean) => void;
  setIsNonOtpMFAError?: React.Dispatch<React.SetStateAction<boolean>>;
  /** if not passed, only x-appcorrelationid is added to header */
  extraHeaders?: { [key: string]: any };
  /**  dispatchFn accepts payload properties other than params although not defined in type from library, this is to pass those extra payloads */
  extraDispatchFnPayloads?: { [key: string]: any };
};
export interface EntitlementMFAProps extends EntitlementBaseProps {
  propType: 'mfa';
  dispatchFn: EntitlementStepUpMFAProps['dispatchFn'];
  dispatchFnParams: EntitlementStepUpMFAProps['payload']['params'];
}

export interface EntitlementMakerCheckerProps extends EntitlementBaseProps {
  propType: 'makerChecker';
  updateTrigger: EntitlementStepUpMakerCheckerProps['updateTrigger'];
}

export function useEntitlementsStepUp({
  pingMfaWidget,
  apiStatus,
  errors,
  isStepUpModalVisible,
  setIsStepUpModalVisible,
  propType,
  setIsNonOtpMFAError,
  extraHeaders = {},
  ...restProps
}: EntitlementMFAProps | EntitlementMakerCheckerProps) {
  const stepUpRequired = isStepUpRequired(apiStatus, errors);

  const appCorrelationId: string = useGlobalSelector(
    (state: GlobalState) => state.global?.instance?.appCorrelationId ?? ''
  );

  function isStepUpRequired(status?: number, errs?: ErrorResponse[]) {
    if (status === 401) {
      return !!errs?.some(
        (err) => err.code === (ERROR_CODES.STEP_UP_REQUIRED as number)
      );
    }
    return false;
  }

  useEffect(() => {
    // effect to handle when Escape key is use to close the modal
    if (!isStepUpModalVisible) return;
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && !event.defaultPrevented) {
        setIsStepUpModalVisible(false);
      }
    };
    document.addEventListener('keydown', handleEsc, true);
    return () => {
      document.removeEventListener('keydown', handleEsc, true);
    };
  }, [isStepUpModalVisible]);

  const callbackFromEntitlementsLib: EntitlementStepUpMakerCheckerProps['callbackFromEntitlementsLib'] =
    (...props) => {
      const [stepUpResult, , error] = props;
      if (!stepUpResult) {
        if (
          error?.code === MFA_CODE.MFA_CANCELLED ||
          error?.code === MFA_CODE.MFA_LOCKED
        ) {
          setIsStepUpModalVisible(false);
        }
      } else {
        setIsStepUpModalVisible(false);
      }

      setIsNonOtpMFAError?.(
        error?.code === MFA_CODE.MFA_ERROR &&
          error?.message !== MFA_CODE.INVALID_OTP
      );
    };

  function renderEntitlementsStepUp() {
    if (!stepUpRequired || !isStepUpModalVisible) {
      return null;
    }

    if (propType === 'mfa') {
      const {
        dispatchFn,
        dispatchFnParams,
        extraDispatchFnPayloads = {},
      } = restProps as EntitlementMFAProps;
      return (
        <EntitlementsStepUp
          propsType="mfa"
          dispatchFn={dispatchFn}
          payload={{ params: dispatchFnParams, ...extraDispatchFnPayloads }}
          headers={{
            headers: {
              'x-appcorrelationid': appCorrelationId,
              ...extraHeaders,
            },
          }}
          callbackFromEntitlementsLib={callbackFromEntitlementsLib}
          useGlobalDispatch={useGlobalDispatch}
          errors={errors}
        >
          {pingMfaWidget}
        </EntitlementsStepUp>
      );
    }
    const { updateTrigger } = restProps as EntitlementMakerCheckerProps;
    return (
      <EntitlementsStepUp
        propsType="makerChecker"
        updateTrigger={updateTrigger}
        headers={{
          headers: {
            'x-appcorrelationid': appCorrelationId,
            ...extraHeaders,
          },
        }}
        callbackFromEntitlementsLib={callbackFromEntitlementsLib}
        useGlobalDispatch={useGlobalDispatch}
        errors={errors}
      >
        {pingMfaWidget}
      </EntitlementsStepUp>
    );
  }

  return { renderEntitlementsStepUp };
}
