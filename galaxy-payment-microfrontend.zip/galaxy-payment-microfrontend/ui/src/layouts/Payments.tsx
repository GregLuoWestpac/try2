import { useGlobalDispatch } from '@mep-ui/framework';
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import { withIntent } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { INTENT_NAMES } from '../common/constants';
import { PaymentListContainer } from '../containers/PaymentListContainer';

export function Payment() {
  return (
    <MVCard title="Payment status" bottomDivider={false}>
      <PaymentListContainer role="main" />
    </MVCard>
  );
}

export default withIntent(
  useGlobalDispatch,
  INTENT_NAMES.VIEW_GALAXY_PAYMENTS
)(Payment);
