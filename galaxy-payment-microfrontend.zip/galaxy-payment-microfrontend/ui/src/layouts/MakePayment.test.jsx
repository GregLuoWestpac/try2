
import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import {MakePayment} from './MakePayment';

jest.mock('../containers/MakePaymentContainer', () => {
  return {
    MakePaymentContainer: function MockComponent() {
      return <div>Mock MakePaymentContainer</div>;
    },
  };
});

describe('MakePayment', () => {
  it('should render with Grid component', () => {
    const { container } = render(<MakePayment />, {
      wrapper: MemoryRouter,
    });
    expect(container).toMatchSnapshot();
  });
});
