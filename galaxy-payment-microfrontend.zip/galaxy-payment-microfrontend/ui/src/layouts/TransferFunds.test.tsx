import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { TransferFunds } from './TransferFunds';

jest.mock('../containers/TransferFundsContainer', () => {
  return {
    TransferFundsContainer: function MockComponent() {
      return <div>Mock TransferFundsContainer</div>;
    },
  };
});

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useIntentListener: () => jest.fn(),
}));

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalSelector: () => 'key',
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  withIntent: () => jest.fn(),
}));

describe('TransferFunds', () => {
  it('should match snapshot', () => {
    const { container } = render(<TransferFunds />, {
      wrapper: MemoryRouter,
    });
    expect(container).toMatchSnapshot();
  });
});
