import { useGlobalDispatch } from '@mep-ui/framework';
import { withIntent } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { INTENT_NAMES } from '../common/constants';
import { InitiateReturnContainer } from '../containers/InitiateReturnContainer';

export function InitiateReturn() {
  return <InitiateReturnContainer />;
}

export default withIntent(
  useGlobalDispatch,
  INTENT_NAMES.CREATE_PAYMENT_RETURN_WORKFLOW
)(InitiateReturn);
