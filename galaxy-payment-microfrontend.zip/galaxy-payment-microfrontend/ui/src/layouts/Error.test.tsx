// Note: the test case is generated from the template of @wdpui/create-react-library
// Please modify as per you needs

import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';

import Error from './Error';

describe('Error', () => {
  it('should render with Grid component', () => {
    const { container } = render(<Error />, {
      wrapper: MemoryRouter,
    });
    expect(container).toMatchSnapshot();
  });
});
