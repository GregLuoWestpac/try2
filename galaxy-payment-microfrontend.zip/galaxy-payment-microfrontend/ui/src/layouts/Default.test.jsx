/* eslint-disable import/no-named-as-default */

// Please modify as per you needs

import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';

import { Default } from './Default';

jest.mock('../store/store', () => ({}));

describe('Default', () => {
  it('should render with Route, Switch component', () => {
    const { container } = render(<Default />, {
      wrapper: MemoryRouter,
    });

    expect(container).toMatchSnapshot();
  });
});
