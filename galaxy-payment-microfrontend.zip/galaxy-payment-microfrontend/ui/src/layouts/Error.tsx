/* eslint-disable */
import { Grid, GridItem, Heading } from '@westpac/ui';
import { AlertIcon } from '@westpac/ui/icon';

type Props = {
  error?: string;
  location?: { state: { error: string } };
};

export default function Error({
  error,
  location: { state: { error: redirectionError } } = { state: { error: '' } },
}: Props) {
  return (
    <Grid className="flex m-0 flex-col auto col-span-2 justify-items-center min-w-[768px]">
      <GridItem className="border border-border border-solid rounded-sm bg-white px-6 pb-7 mb-9 shadow-md">
        <Heading
          className="m-0 leading-6 pt-6 mb-5 font-light color-heading text-4xl"
          tag="h2"
          size={6}
        >
          <AlertIcon
            className="align-top"
            size="large"
            color="danger"
            look="outlined"
          />
          Oops...
        </Heading>
        <Heading className="text-xl" size={3}>
          {error ||
            redirectionError ||
            `Either the page doesn't exist or you don't have access to the page`}
        </Heading>
      </GridItem>
    </Grid>
  );
}
