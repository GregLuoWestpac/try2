/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable import/extensions */
/* eslint-disable import/no-unresolved */
import { useGlobalDispatch, useGlobalSelector } from '@mep-ui/framework';
import { useNavigate } from '@mep-ui/framework-router-addon';
import {
  getURLParams,
  withIntent,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { useEffect } from 'react';
import { INTENT_NAMES } from '../common/constants';
import { PaymentDetailsContainer } from '../containers/PaymentDetailsContainer';
import { Account } from '../store/types';
import { GlobalState } from '../store/types/RootStates';

export function PaymentDetails() {
  const navigate = useNavigate();
  const selectedPayment: Account = useGlobalSelector(
    (state: GlobalState) => state?.global?.galaxy?.context?.selectedPayment
  );

  useEffect(() => {
    if (!selectedPayment) {
      navigate(`/payment${getURLParams()}`);
    }
  }, []);

  return <PaymentDetailsContainer />;
}
export default withIntent(
  useGlobalDispatch,
  INTENT_NAMES.VIEW_GALAXY_PAYMENT_DETAILS
)(PaymentDetails);
