
import { compose } from '@mep-ui/framework';
import { Outlet, Route, Routes } from '@mep-ui/framework-router-addon';
import PropTypes from 'prop-types';
import withMFE from '../hoc/withMFE';

// eslint-disable-next-line no-unused-vars
export function Default({ routes, ...rest }) {
  // permissibles routes
  return (
    <>
      <Outlet />
      <Routes>
        {routes &&
          routes.map(({ path, id, element, index }) => {
            return (
              <Route index={index} path={path} key={id} element={element} />
            );
          })}
      </Routes>
    </>
  );
}

Default.propTypes = {
  routes: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
};

const EnhancedRoutes = compose(withMFE)(Default);

export default EnhancedRoutes;
