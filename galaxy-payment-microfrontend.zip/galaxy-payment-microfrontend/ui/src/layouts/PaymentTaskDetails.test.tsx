/* eslint-disable @typescript-eslint/no-unsafe-return */

import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { PaymentTaskDetails } from './PaymentTaskDetails';

jest.mock('../containers/PaymentTaskDetailsContainer', () => ({
  PaymentTaskDetailsContainer: function MockComponent() {
    return <div>Mock PaymentTaskDetailsContainer</div>;
  },
}));

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useIntentListener: () => jest.fn(),
}));

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalSelector: () => 'key',
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  withIntent: () => jest.fn(),
}));

describe('PaymentDetails', () => {
  it('should render with Grid component', () => {
    const { container } = render(<PaymentTaskDetails />, {
      wrapper: MemoryRouter,
    });
    expect(container).toMatchSnapshot();
  });
});
