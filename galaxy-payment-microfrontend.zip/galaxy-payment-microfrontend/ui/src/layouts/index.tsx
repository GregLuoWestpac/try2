import React from 'react';
import withPageLoader from '../hoc/withPageLoader';

const Default = React.lazy(() => import('./Default'));
const MakePayment = React.lazy(() => import('./MakePayment'));
const TransferFunds = React.lazy(() => import('./TransferFunds'));
const PaymentDetails = React.lazy(() => import('./PaymentDetails'));
const PaymentTaskDetails = React.lazy(() => import('./PaymentTaskDetails'));
const Error = React.lazy(() => import('./Error'));
const InitiateReturn = React.lazy(() => import('./InitiateReturn'));
const Payments = React.lazy(() => import('./Payments'));

export const AsyncDefault = withPageLoader(Default);
export const AsyncMakePayment = withPageLoader(MakePayment);
export const AsyncTransferFunds = withPageLoader(TransferFunds);
export const AsyncPaymentDetails = withPageLoader(PaymentDetails);
export const AsyncPaymentTaskDetails = withPageLoader(PaymentTaskDetails);
export const AsyncError = withPageLoader(Error);
export const AsyncInitiateReturn = withPageLoader(InitiateReturn);
export const AsyncHome = withPageLoader(Payments);
