/* eslint-disable @typescript-eslint/no-unsafe-return */

import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { PaymentDetails } from './PaymentDetails';

jest.mock('../containers/PaymentDetailsContainer', () => ({
  PaymentDetailsContainer: function MockComponent() {
    return <div>Mock PaymentDetailsContainer</div>;
  },
}));

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useIntentListener: () => jest.fn(),
}));

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalSelector: () => 'key',
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  useHandleRaiseIntent: jest.fn(),
  withIntent: () => jest.fn(),
  convertSydneyLocalTimeToUtc: jest.fn((date: string) => date ? `${date}T00:00:00.000Z` : ''),
}));

describe('PaymentDetails', () => {
  it('should render with Grid component', () => {
    const { container } = render(<PaymentDetails />, {
      wrapper: MemoryRouter,
    });
    expect(container).toMatchSnapshot();
  });
});
