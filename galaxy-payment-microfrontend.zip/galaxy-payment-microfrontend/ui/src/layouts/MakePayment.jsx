import { useGlobalDispatch } from '@mep-ui/framework';
import { withIntent } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { INTENT_NAMES } from '../common/constants';
import { MakePaymentContainer } from '../containers/MakePaymentContainer';

export function MakePayment() {
  return <MakePaymentContainer />;
}

export default withIntent(
  useGlobalDispatch,
  INTENT_NAMES.CREATE_GALAXY_PAYMENT
)(MakePayment);
