import { useGlobalDispatch } from '@mep-ui/framework';
import { withIntent } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { INTENT_NAMES } from '../common/constants';
import { TransferFundsContainer } from '../containers/TransferFundsContainer';

export function TransferFunds() {
  return <TransferFundsContainer />;
}
export default withIntent(
  useGlobalDispatch,
  INTENT_NAMES.CREATE_GALAXY_TRANSFER
)(TransferFunds);
