import { useGlobalDispatch } from '@mep-ui/framework';
import { withIntent } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { INTENT_NAMES } from '../common/constants';
import { PaymentTaskDetailsContainer } from '../containers/PaymentTaskDetailsContainer';

export function PaymentTaskDetails() {
  return <PaymentTaskDetailsContainer />;
}

export default withIntent(
  useGlobalDispatch,
  INTENT_NAMES.VIEW_GALAXY_PAYMENT_TASK_DETAILS
)(PaymentTaskDetails);
