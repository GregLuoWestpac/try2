import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { InitiateReturn } from './InitiateReturn';

jest.mock('../containers/InitiateReturnContainer', () => {
  return {
    InitiateReturnContainer: function MockComponent() {
      return <div>Mock InitiateReturnContainer</div>;
    },
  };
});
jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => {
  return {
    withIntent: () => jest.fn(),
  };
});
jest.mock('@mesh-tenant-multiverse-common/react', () => {
  return {
    useIntentListener: () => jest.fn(),
  };
});
describe('InitiateReturn', () => {
  it('should render without crashing', () => {
    const { container } = render(<InitiateReturn />, {
      wrapper: MemoryRouter,
    });
    expect(container).toMatchSnapshot();
  });
});
