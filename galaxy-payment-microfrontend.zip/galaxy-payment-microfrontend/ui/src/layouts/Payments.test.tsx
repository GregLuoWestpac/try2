/* eslint-disable react/prop-types */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable react/react-in-jsx-scope */

import { render } from '@testing-library/react';
import { Payment } from './Payments';

jest.mock('../containers/PaymentListContainer', () => ({
  PaymentListContainer: function MockComponent() {
    return <div>Mock PaymentListContainer</div>;
  },
}));

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useIntentListener: () => jest.fn(),
}));

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalSelector: () => 'key',
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: function MockComponent({
    title,
    children,
  }: {
    title: string;
    children: React.ReactNode;
  }) {
    return (
      <div>
        <h1>{title}</h1>
        {children}
      </div>
    );
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  withIntent: jest.fn((component) => component),
}));

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useIntentListener: () => jest.fn(),
}));

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalDispatch: jest.fn(),
}));

describe('Testing the Payments', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  it('should match snapshot', () => {
    const { asFragment } = render(<Payment />);
    expect(asFragment()).toMatchSnapshot();
  });

  it('should show the Account Activity title', () => {
    const { getByText } = render(<Payment />);
    const accountHeading = getByText('Payment status');
    expect(accountHeading).toBeInTheDocument();
  });
});
