import { compose, connect, useGlobalSelector } from '@mep-ui/framework';
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import {
  Actions,
  Resources,
  useAuthoriser,
} from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import { useCallback, useState } from 'react';
import { ErrorResponse, SchemeEligibility } from 'ui/src/common/types';
import { getPostSchemeEligibilityStatusCode } from 'ui/src/store/selectors/schemeEligibilitiesStatusCode';
import {
  ServiceLevel,
  ToAnotherAccount,
  apiGenericErrorTryAgainLater,
  genericUnathorisedMessage,
  returnConfirmationPageTitle,
  returnDetailsPageTitle,
} from '../../common/constants';
import { ReturnConfirmation } from '../../components/ReturnConfirmation';
import { ReturnDetails } from '../../components/ReturnDetails';
import BannerAlertBox from '../../galaxy-common/BannerAlertBox/BannerAlertBox';
import { scrollToTop } from '../../galaxy-common/utils/DOMUtils';
import {
  getAllPaymentreturns,
  getAllSchemeEligibilities,
  isPaymentreturnsError as isPaymentreturnsErrorSelector,
  isPaymentreturnsFetching as isPaymentreturnsFetchingSelector,
  isSchemeEligibilitiesError as isSchemeEligibilitiesErrorSelector,
  isSchemeEligibilitiesFetching as isSchemeEligibilitiesFetchingSelector,
  paymentreturnsActions,
  paymentreturnsEntityActions,
  schemeEligibilitiesActions,
} from '../../store/generated';
import {
  getPostPaymentReturnErrorResponse,
  getPostPaymentReturnStatusCode,
} from '../../store/selectors/paymentReturns';
import store from '../../store/store';
import type {
  PaymentReturnResponse,
  RootState,
  fetchSchemeEligibilitiesParams,
  fetchSchemeEligibilitiesPayload,
} from '../../store/types';
import {
  GlobalState,
  PostPaymentReturnsOptionsPayload,
  PostPaymentReturnsParamsPayload,
} from '../../store/types';
import GalaxyMakerCheckerWrapper from '../../widgets/galaxymakerchecker-v1';
import { PostAuthorisationIdCreateData } from '../../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types';
import {
  NppPaymentMethod,
  defaultFormData,
  defaultPaymentReturnDescText,
  returnConfirmationPage,
  returnDetailsPage,
} from './InitiateReturnContainer.constant';
import {
  InitiateReturnFormDataType,
  TransactionDetails,
  paymentMethodObject,
} from './InitiateReturnContainer.type';
import {
  APPROVAL_WORKFLOW_SUB_TYPE,
  APPROVAL_WORKFLOW_TYPE,
} from '@mesh-tenant-multiverse-ui-common/mv-constants';
import { useOrganizationId } from 'ui/src/hooks';

export type InitiateReturnContainerProps = {
  isPaymentReturnsFetching: boolean;
  isPaymentReturnsError: boolean;
  submitReturn: (
    params: PostPaymentReturnsParamsPayload,
    options: PostPaymentReturnsOptionsPayload
  ) => void;
  clearReturn: () => void;
  fetchSchemeEligibilities?: (payload: fetchSchemeEligibilitiesPayload) => void;
  paymentReturnApiStatus?: number;
  paymentReturn: PaymentReturnResponse;
  paymentReturnsError?: ErrorResponse;
  isSchemeEligibilitiesError: boolean;
  isSchemeEligibilitiesFetching: boolean;
  schemeEligibilities: SchemeEligibility[];
  schemeEligibilitiesStatusCode: number;
};

export function determinePaymentMethodFromServiceLevel(
  paymentMethod?: paymentMethodObject
) {
  return paymentMethod?.code === ServiceLevel.Osko
    ? NppPaymentMethod.Osko
    : paymentMethod?.code === ServiceLevel.FastPayment ||
      paymentMethod?.code === ServiceLevel.CatSct
    ? NppPaymentMethod.FastPayment
    : NppPaymentMethod.OnPlatform;
}

export function updateDefaultFormData(
  selectedTransactionDetails: TransactionDetails
): InitiateReturnFormDataType {
  const originalPaymentMethod = determinePaymentMethodFromServiceLevel(
    selectedTransactionDetails.paymentMethod
  );
  return {
    transactionId:
      originalPaymentMethod === NppPaymentMethod.OnPlatform
        ? (selectedTransactionDetails.receiptNumber as string)
        : selectedTransactionDetails.originalTransactionId,
    returnType: undefined,
    solicitedReasonForReturn: undefined,
    unSolicitedReasonForReturn: undefined,
    fromAccountBsb:
      selectedTransactionDetails.beneficiary.accountId.split(' ')[0],
    fromAccountNumber:
      selectedTransactionDetails.beneficiary.accountId.split(' ')[1],
    fromAccountName: selectedTransactionDetails.beneficiary.name,
    debitDesc: defaultPaymentReturnDescText,
    toAccountBsb: '',
    toAccountNumber: '',
    toAccountName: '',
    payerAccountBsb: selectedTransactionDetails.payer?.accountId.split(' ')[0],
    payerAccountNumber:
      selectedTransactionDetails.payer?.accountId.split(' ')[1],
    payerAccountName: selectedTransactionDetails.payer?.name,
    reference: '',
    creditDesc: defaultPaymentReturnDescText,
    anotherAccountFlag: ToAnotherAccount.No,
    totalAmount: selectedTransactionDetails.amount.amount,
    nppCaseId: '',
    additionalInfo: '',
    paymentMethod: '',
    internalCaseId: '',
  };
}
export function InitiateReturnContainer({
  isPaymentReturnsFetching,
  isPaymentReturnsError,
  submitReturn,
  clearReturn,
  paymentReturnApiStatus,
  paymentReturn,
  paymentReturnsError,
  isSchemeEligibilitiesError,
  isSchemeEligibilitiesFetching,
  schemeEligibilities,
  fetchSchemeEligibilities = () => {},
  schemeEligibilitiesStatusCode,
}: InitiateReturnContainerProps) {
  const [navigateTo, setNavigationTo] = useState(returnDetailsPage);
  const [channelRequestId, setChannelRequestId] = useState('');
  const [initiateReturnFormData, setinitiateReturnFormData] =
    useState<InitiateReturnFormDataType>({ ...defaultFormData });

  const selectedTransactionDetails: TransactionDetails = useGlobalSelector(
    (state: GlobalState) =>
      state?.global?.galaxy?.context?.selectedTransactionDetails
  );
  const orgCISKey = useOrganizationId() || '';

  const handleReturnFormDataChange = (
    updatedReturnFundFormData: InitiateReturnFormDataType
  ) => {
    setinitiateReturnFormData(updatedReturnFundFormData);
  };

  const renderInitiateReturnComponents = (newNavigateTo: string) => {
    setNavigationTo(newNavigateTo);
    scrollToTop();
  };

  const initiateReturn = (
    params: PostPaymentReturnsParamsPayload,
    options: PostPaymentReturnsOptionsPayload
  ) => {
    clearReturn();
    options.headers = {
      ...options.headers,
      'x-channelRequestId': channelRequestId,
    };
    submitReturn(params, options);
  };

  const fetchSchemes = useCallback((params: fetchSchemeEligibilitiesParams) => {
    const payload: fetchSchemeEligibilitiesPayload = {
      params,
      meta: {
        replaceEntities: ['schemeEligibilities'],
      },
    };
    fetchSchemeEligibilities(payload);
  }, []);

  const renderCurrentPage = () => {
    switch (navigateTo) {
      case returnDetailsPage: {
        document.title = returnDetailsPageTitle;
        return (
          <>
            <GalaxyMakerCheckerWrapper
              apiName="postAuthorisationIdCreate"
              enableVerboseUpdate
              params={{
                body: {
                  payload: {
                    authorisationType: APPROVAL_WORKFLOW_TYPE.PAYMENTS,
                    authorisationSubtype:
                      APPROVAL_WORKFLOW_SUB_TYPE.PAYMENT_RETURNS,
                  },
                },
              }}
              trigger={1}
              onApiResponse={(data: {
                data: PostAuthorisationIdCreateData;
              }) => {
                const channelRequestId =
                  data.data.entities.authorisationIdCreate[0].authorisationId ||
                  '';
                setChannelRequestId(channelRequestId);
              }}
              onApiError={(err: any) => {
                console.error('API Error:', err);
                setChannelRequestId('');
              }}
            />
            <ReturnDetails
              initiateReturnFormData={initiateReturnFormData}
              handleReturnFormDataChange={handleReturnFormDataChange}
              renderInitiateReturnComponents={renderInitiateReturnComponents}
              initiateReturn={initiateReturn}
              clearReturn={clearReturn}
              isPaymentReturnsFetching={isPaymentReturnsFetching}
              isPaymentReturnsError={isPaymentReturnsError}
              paymentReturnApiStatus={paymentReturnApiStatus}
              selectedTransactionDetails={selectedTransactionDetails}
              fetchSchemeEligibilities={fetchSchemes}
              schemeEligibilities={schemeEligibilities}
              isSchemeEligibilitiesFetching={isSchemeEligibilitiesFetching}
              isSchemeEligibilitiesError={isSchemeEligibilitiesError}
              schemeEligibilitiesStatusCode={schemeEligibilitiesStatusCode}
              orgCISKey={orgCISKey}
            />
          </>
        );
      }
      case returnConfirmationPage: {
        document.title = returnConfirmationPageTitle;
        return (
          <ReturnConfirmation
            initiateReturnFormData={initiateReturnFormData}
            paymentReturnApiStatus={paymentReturnApiStatus}
            paymentReturnsError={paymentReturnsError}
            channelRequestId={channelRequestId}
            paymentReturn={paymentReturn}
            selectedTransactionDetails={selectedTransactionDetails}
          />
        );
      }
      default: {
        return null;
      }
    }
  };

  const { authorised } = useAuthoriser(
    Resources.ACCOUNTS,
    Actions.INITIATE_PAYMENT_RETURN
  );

  return authorised ? (
    selectedTransactionDetails ? (
      <>{renderCurrentPage()}</>
    ) : (
      <MVCard template="narrow">
        <BannerAlertBox id="payment-status-banner" styling="danger">
          {apiGenericErrorTryAgainLater}
        </BannerAlertBox>
      </MVCard>
    )
  ) : (
    <MVCard template="narrow">
      <BannerAlertBox id="payment-status-banner" styling="danger">
        {genericUnathorisedMessage}
      </BannerAlertBox>
    </MVCard>
  );
}

const mapStateToProps = (state: RootState) => ({
  isPaymentReturnsFetching: isPaymentreturnsFetchingSelector(state),
  isPaymentReturnsError: isPaymentreturnsErrorSelector(state),
  paymentReturnsError: getPostPaymentReturnErrorResponse(state),
  paymentReturnApiStatus: getPostPaymentReturnStatusCode(state),
  paymentReturn: getAllPaymentreturns(state),
  isSchemeEligibilitiesError: isSchemeEligibilitiesErrorSelector(state),
  isSchemeEligibilitiesFetching: isSchemeEligibilitiesFetchingSelector(state),
  schemeEligibilities: getAllSchemeEligibilities(state),
  schemeEligibilitiesStatusCode: getPostSchemeEligibilityStatusCode(state),
});

const mapDispatchToProps = {
  submitReturn:
    paymentreturnsActions.api.expGalaxyPaymentV2.paymentreturns.post.request,
  clearReturn:
    paymentreturnsEntityActions.api.expGalaxyPaymentV2.paymentreturns.clear
      .request,
  fetchSchemeEligibilities:
    schemeEligibilitiesActions.api.expGalaxyPaymentV2.schemeEligibilities.post
      .request,
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps, null, {
    context: store.contextRef,
  })
)(InitiateReturnContainer);
