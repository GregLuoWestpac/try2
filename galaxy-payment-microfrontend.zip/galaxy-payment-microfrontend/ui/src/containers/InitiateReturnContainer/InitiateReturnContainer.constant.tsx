import { ToAnotherAccount } from '../../common/constants';

export const returnDetailsPage = 'return-details';
export const returnConfirmationPage = 'return-confirmation';
export const defaultPaymentReturnDescText = 'Payment return';

export const defaultFormData = {
  transactionId: '',
  returnType: undefined,
  solicitedReasonForReturn: undefined,
  unSolicitedReasonForReturn: undefined,
  fromAccountBsb: '',
  fromAccountNumber: '',
  fromAccountName: '',
  debitDesc: '',
  toAccountBsb: '',
  toAccountNumber: '',
  toAccountName: '',
  payerAccountBsb: '',
  payerAccountNumber: '',
  payerAccountName: '',
  reference: '',
  creditDesc: '',
  anotherAccountFlag: ToAnotherAccount.No,
  totalAmount: '',
  nppCaseId: '',
  additionalInfo: '',
  paymentMethod: '',
  internalCaseId: '',
};

export const defaultReturnTypesData = [
  { label: 'Select one', value: '' },
  { label: 'Solicited return', value: 'Solicited return' },
  { label: 'UnSolicited return', value: 'Unsolicited return' },
];

export const defaultSolicitedReasonForReturnData = [
  { label: 'Select One', value: '' },
  { label: 'FOCR', value: 'FOCR' },
];

export const defaultUnSolicitedReasonForReturnData = [
  { label: 'Select One', value: '' },
  {
    label: 'AC04 - Closed Account Number',
    value: 'AC04 - Closed Account Number',
  },
  { label: 'AC06 - Blocked Account', value: 'AC06 - Blocked Account' },
  {
    label: 'AM03 - Not Allowed Currency',
    value: 'AM03 - Not Allowed Currency',
  },
  { label: 'AM05 - Duplication', value: 'AM05 - Duplicate' },
  { label: 'AM09 - Wrong Amount', value: 'AM09 - Wrong Amount' },
  {
    label: 'BE05 - Unrecognised Initiating Party',
    value: 'BE05 - Unrecognised Initiating Party',
  },
  { label: 'FR01 - Fraud', value: 'FR01 - Fraud' },
  {
    label: 'MD06 - Refund Request By End Customer',
    value: 'MD06 - Refund Request By End Customer',
  },
  { label: 'NARR - Narrative', value: 'NARR - Narrative' },
  { label: 'RR04 - Regulatory Reason', value: 'RR04 - Regulatory Reason' },
  { label: 'UPAY - Undue Payment', value: 'UPAY - Undue Payment' },
];

export const defaultCancellationCodeData = [
  { label: 'Select One', value: '' },
  { label: 'AGNT (Incorrect Agent)', value: 'AGNT' },
  { label: 'CURR (Incorrect Currency)', value: 'CURR' },
  { label: 'CUST (Requested By Customer)', value: 'CUST' },
  { label: 'DUPL (Duplicate Payment)', value: 'DUPL' },
  { label: 'FRAD (Fraud)', value: 'FRAD' },
  { label: 'TECH (Technical Problem)', value: 'TECH' },
  { label: 'UPAY (Undue Payment)', value: 'UPAY' },
];

export enum NppPaymentMethod {
  SelectOne = 'Select One',
  FastPayment = 'Fast Payment',
  Osko = 'Osko',
  OnPlatform = 'On-Platform',
  PayTo = 'PayTo',
}

export const defaultPaymentMethodData = [
  { label: 'Select', value: '' },
  { label: 'Fast Payment', value: NppPaymentMethod.FastPayment },
  { label: 'Osko', value: NppPaymentMethod.Osko },
  { label: 'On-Platform', value: NppPaymentMethod.OnPlatform },
];

export enum ReturnType {
  SelectOne = 'Select One',
  SolicitedReturn = 'Solicited return',
  UnsolicitedReturn = 'Unsolicited return',
}

export enum SolicitedReasonForReturn {
  SelectOne = 'Select One',
  FOCR = 'FOCR',
}

export enum UnSolicitedReasonForReturn {
  SelectOne = 'Select One',
  closedAccount = 'AC04 - Closed Account Number',
  blockedAccount = 'AC06 - Blocked Account',
  currencyNotAllowed = 'AM03 - Not Allowed Currency',
  duplicate = 'AM05 - Duplication',
  wrongAmount = 'AM09 - Wrong Amount',
  unReconisedParty = 'BE05 - Unrecognised Initiating Party',
  fraud = 'FR01 - Fraud',
  requestByEndCustomer = 'MD06 - Refund Request by End Customer',
  narrative = 'NARR - Narrative',
  regulatoryReason = 'RRO04 - Regulatory Reason',
  uPay = 'UPAY - Undue Payment',
}

export enum CancellationCode {
  SelectOne = 'Select One',
  AGNT = 'AGNT',
  CURR = 'CURR',
  CUST = 'CUST',
  DUPL = 'DUPL',
  FRAD = 'FRAD',
  TECH = 'TECH',
  UPAY = 'UPAY',
}

export enum TransactionDirection {
  Debit = 'Debit',
  Credit = 'Credit',
}
