/* eslint-disable @typescript-eslint/no-unsafe-return */
import { useAuthoriser } from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import '@testing-library/jest-dom';
import { render } from '@testing-library/react';
import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { ServiceLevel } from 'ui/src/common/constants';
import type { PaymentReturn } from '../../store/types';
import { MakerCheckerApiClientProps } from '../../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types';
import {
  determinePaymentMethodFromServiceLevel,
  InitiateReturnContainer,
  updateDefaultFormData,
  type InitiateReturnContainerProps,
} from './InitiateReturnContainer';
import { NppPaymentMethod } from './InitiateReturnContainer.constant';
import { TransactionDetails } from './InitiateReturnContainer.type';

jest.mock('@mesh-tenant-multiverse-common/react', () => {
  return {
    useRaiseIntent: () => jest.fn(),
    useClose: () => ({ closeTab: jest.fn() }),
    usePlatformState: jest.fn().mockReturnValue([
      {
        WPAC: [
          {
            cisKey: '03844900037',
          },
        ],
      },
    ]),
  };
});
jest.mock(
  '@mesh-tenant-user-authorisation-policy-decision-engine/components',
  () => ({
    useAuthoriser: jest.fn().mockReturnValue({ isAuthorised: true }),
    Resources: {
      ACCOUNTS: 'ACCOUNTS',
    },
    Actions: {
      VIEW_ACCOUNTS: 'VIEW_ACCOUNTS',
    },
  })
);
jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-ui-common/mv-utils'),
  getFormattedDate: jest.fn(),
  formatCurrencyString: jest.fn(),
  getAppUrlWithParams: jest.fn(),
  useGetChannelTypeCode: jest.fn(),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: function MockComponent({ children }: { children: React.ReactNode }) {
    return <div>{children}</div>;
  },
}));

const mockPaymentReturn: PaymentReturn = [
  {
    id: '',
    creationDateTime: '',
    groupInformation: {
      originalCreationDateTime: '',
      groupStatus: '',
    },
    groupStatusReasonInformation: [
      {
        reason: '',
        additionalInformation: '',
      },
    ],
    transactionStatusInformation: [
      {
        transactionStatus: 'ACSC',
        statusReasonInformation: [
          {
            reason: '',
            additionalInformation: '',
          },
        ],
        supplementaryData: {
          id: 'WS4219142864756',
        },
      },
    ],
  },
];

const defaultProps: InitiateReturnContainerProps = {
  isPaymentReturnsFetching: false,
  isPaymentReturnsError: false,
  submitReturn: jest.fn(),
  clearReturn: jest.fn(),
  paymentReturn: mockPaymentReturn,
  isSchemeEligibilitiesError: false,
  isSchemeEligibilitiesFetching: false,
  schemeEligibilities: [],
  schemeEligibilitiesStatusCode: 200,
};

const mockGlobalDispatch = jest.fn();

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  ssoActions: {
    sso: {
      signout: {
        request: jest.fn(),
      },
    },
  },
  useGlobalDispatch: () => mockGlobalDispatch,
  useGlobalSelector: () => ({
    accountId: '000123 7098112345',
    accountName: 'CCMP Subscription Update',
    amount: {
      amount: '100000.0',
      currencyCode: 'AUD',
      position: 'CR',
    },
    beneficiary: {
      accountId: '000845 7091234',
      name: 'Durga',
    },
    creditorAccountId: ' ',
    creditorDescription: 'NikitaDM',
    creditorFI: 'WPACAU3SXXX',
    creditorReference: '',
    debtorAccountId: ' ',
    debtorFI: 'CTBAAUSNXXX',
    id: '8e7c9d85-8410-4326-833a-e050cb77b404',
    narrative:
      'Deposit-Fast Payment NP33101234567 Orange LTD Tech Like ðŸ¥³ðŸŽ‰æ–°å¹´å¿«ä¹ $1,456.00 OR OTHER CHRS E2EId123456789012345678901234567890',
    originalMessageId: 'CTBAAUSNXXX20240619000001158103279',
    originalMessageName: 'pacs.008.001.05',
    originalTransactionId: 'CTBAAUSNXXXN02406190000011891799329',
    payer: {
      accountId: '000102 3123456',
      name: 'Tania England',
    },
    paymentMethod: {
      code: 'npp.clear.01-x2p1.04',
      description: 'Osko',
    },
    paymentStatus: 'Processed',
    reference: 'PAGFISPOC',
    schemeCategoryPurpose: 'OTHR',
    transactionCode: 'PMNT.RRCT.DMCT_FIS_NPP_TRF',
    transactionDateTime: '2024-06-19T08:16:30.041Z',
    transactionId: 'NPP230000124CUSTOMER',
    type: 'Credit',
  }),
}));

jest.mock('../../store/store', () => ({
  __esModule: true,
  default: {
    dispatch: jest.fn(),
  },
}));

let mockApiError = false;
jest.mock('../../widgets/galaxymakerchecker-v1', () => ({
  __esModule: true,
  default: (props: MakerCheckerApiClientProps) => {
    // Use a Promise.resolve to ensure it runs in the next tick
    Promise.resolve()
      .then(() => {
        if (mockApiError) {
          props.onApiError?.('mock-error');
        } else {
          props.onApiResponse?.({
            data: {
              entities: {
                approvalWorkflowDetails: [
                  {
                    id: 'mock-id',
                    amount: { amount: '1.00', currency: 'AUD' },
                    beneficiary: {
                      name: 'Test',
                      nickName: 'Test',
                      accountId: '000111',
                    },
                    debitAccount: {
                      nickName: 'Debit',
                      accountId: '000222',
                    },
                    creationDateTime: '2024-01-01T00:00:00Z',
                    creditorDescription: 'desc',
                    debitDescription: 'debit',
                    paymentMethod: { description: 'Fast Payment' },
                    receiptNumber: 'RCPT123',
                    reference: 'REF123',
                    status: 'Pending authorisation',
                    supplementaryData: {
                      aliasId: 'test@example.com',
                      aliasType: 'EMAL',
                    },
                  },
                ],
              },
            },
          });
        }
      })
      .catch(() => {
        // Handle any promise rejection
      });
    return <div data-testid="mock-widget">GalaxyWidget</div>;
  },
}));

describe('InitiateReturnContainer', () => {
  beforeEach(() => {
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: true });

    jest.resetModules();
    jest.clearAllMocks();
    mockApiError = false;
  });
  it('should render the component correctly and match snapshot', () => {
    const { container } = render(
      <Router>
        <InitiateReturnContainer {...defaultProps} />
      </Router>
    );
    expect(container).toMatchSnapshot();
  });

  it('Should show the heading in the page', () => {
    const { getAllByText } = render(
      <Router>
        <InitiateReturnContainer {...defaultProps} />
      </Router>
    );
    const returntTitle = getAllByText('Return details');
    expect(returntTitle).toHaveLength(1);
  });
});

describe('Testing error scenario', () => {
  beforeEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
    mockApiError = false;
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: false });
  });

  it('Should show the error in the page', () => {
    const { getByText } = render(<InitiateReturnContainer {...defaultProps} />);

    expect(
      getByText(
        'You do not have permission to access this page. Contact your Administrator for more information.'
      )
    ).toBeInTheDocument();
  });
});

describe('InitiateReturnContainer fetchSchemeEligibilities', () => {
  it('should call fetchSchemeEligibilities method with correct payload', () => {
    const fetchSchemeEligibilitiesMock = jest.fn();
    const props = {
      ...defaultProps,
      fetchSchemeEligibilities: fetchSchemeEligibilitiesMock,
    };

    const container = render(<InitiateReturnContainer {...props} />);
    const params = { someParam: 'value' };
    const payload = {
      params,
      meta: {
        replaceEntities: ['schemes'],
      },
    };

    props.fetchSchemeEligibilities(payload);
    expect(fetchSchemeEligibilitiesMock).toHaveBeenCalledWith(payload);
  });
});
describe('determinePaymentMethodFromServiceLevel', () => {
  it('should return Osko for Osko service level', () => {
    const paymentMethod = { code: ServiceLevel.Osko };
    const result = determinePaymentMethodFromServiceLevel(paymentMethod);
    expect(result).toBe(NppPaymentMethod.Osko);
  });

  it('should return FastPayment for FastPayment service level', () => {
    const paymentMethod = { code: ServiceLevel.FastPayment };
    const result = determinePaymentMethodFromServiceLevel(paymentMethod);
    expect(result).toBe(NppPaymentMethod.FastPayment);
  });

  it('should return OnPlatform for other service levels', () => {
    const paymentMethod = { code: 'Other' };
    const result = determinePaymentMethodFromServiceLevel(paymentMethod);
    expect(result).toBe(NppPaymentMethod.OnPlatform);
  });

  it('should return OnPlatform if paymentMethod is undefined', () => {
    const result = determinePaymentMethodFromServiceLevel(undefined);
    expect(result).toBe(NppPaymentMethod.OnPlatform);
  });
});

describe('updateDefaultFormData', () => {
  it('should update form data with OnPlatform payment method', () => {
    const selectedTransactionDetails = {
      paymentMethod: { code: 'Other' },
      receiptNumber: '12345',
      originalTransactionId: '67890',
      beneficiary: { accountId: '000123 456789', name: 'John Doe' },
      amount: { amount: '1000.00' },
      payer: { accountId: '000102 3123456', name: 'Tania England' },
    } as TransactionDetails;

    const result = updateDefaultFormData(selectedTransactionDetails);
    expect(result.transactionId).toBe('12345');
    expect(result.fromAccountBsb).toBe('000123');
    expect(result.fromAccountNumber).toBe('456789');
    expect(result.fromAccountName).toBe('John Doe');
    expect(result.totalAmount).toBe('1000.00');
  });
});
