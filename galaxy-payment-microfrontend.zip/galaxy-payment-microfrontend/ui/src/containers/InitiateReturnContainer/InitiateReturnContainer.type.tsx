import {
  ReturnType,
  SolicitedReasonForReturn,
  UnSolicitedReasonForReturn,
  CancellationCode,
  NppPaymentMethod,
  TransactionDirection,
} from './InitiateReturnContainer.constant';

export type PaymentMethodType = {
  id: string;
  name: string;
  label: string;
};

export type InitiateReturnFormDataType = {
  transactionId: string;
  returnType?: ReturnType;
  solicitedReasonForReturn?: SolicitedReasonForReturn;
  unSolicitedReasonForReturn?: UnSolicitedReasonForReturn;
  cancellationCode?: CancellationCode;
  fromAccountBsb: string;
  fromAccountNumber: string;
  fromAccountName: string;
  debitDesc: string;
  toAccountBsb: string;
  toAccountNumber: string;
  toAccountName: string;
  payerAccountBsb: string;
  payerAccountNumber: string;
  payerAccountName: string;
  creditDesc: string;
  reference: string;
  anotherAccountFlag: string;
  totalAmount: string;
  nppCaseId: string;
  additionalInfo: string;
  paymentMethod?: string;
  internalCaseId: string;
};

export type AmountObject = {
  amount: string;
  currencyCode: string;
  position: string;
};

export type TransactionType =
  (typeof TransactionDirection)[keyof typeof TransactionDirection];

export type AccountObject = {
  name: string;
  nickName?: string;
  accountId: string;
};

export type paymentMethodObject = {
  code?: string;
  description?: NppPaymentMethod;
};

export type TransactionDetails = {
  id: string;
  accountName: string;
  accountId: string;
  narrative: string;
  transactionDateTime: string;
  amount: AmountObject;
  type: TransactionType;
  payer: AccountObject;
  debitAccount?: AccountObject;
  debtorAccountId?: string;
  debitDescription?: string;
  debtorFI?: string;
  beneficiary: AccountObject;
  creditAccount?: AccountObject;
  creditorAccountId?: string;
  creditorDescription?: string;
  reference?: string;
  creditorReference?: string;
  creditorFI?: string;
  paymentMethod?: paymentMethodObject;
  receiptNumber?: string;
  schemeCategoryPurpose?: string;
  paymentStatus?: string;
  transactionId?: string;
  transactionCode?: string;
  originalMessageName?: string;
  originalMessageId?: string;
  originalTransactionId: string;
  mandateId?: string;
  instructionId?: string;
};
