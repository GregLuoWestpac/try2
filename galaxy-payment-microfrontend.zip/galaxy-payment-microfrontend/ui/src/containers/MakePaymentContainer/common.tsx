import { MVIcons } from '@mesh-tenant-multiverse-ui-common/mv-icons';

/* eslint-disable no-shadow */
export const defaultPaymentMethodData = [
  { id: 'select', name: 'Select', label: 'Select payment method' },
];

export const NppPaymentMethodMap = (paymentMethod: string | undefined) => {
  switch (paymentMethod) {
    case 'Fast Payment':
      return 'Fast Payment';
    case 'Osko':
      return <MVIcons name="Osko" />;
    case 'On-Platform':
      return 'Fast Payment';
    case 'Pay Anyone':
      return 'Pay Anyone';
    default:
      return undefined;
  }
};

export const defaultDivisionData = [
  {
    id: 'select',
    name: 'Select',
    label: 'Select a division',
  },
];

export enum BeneficiaryStatus {
  ACTIVE = 'ACTIVE',
  ON_HOLD = 'ON-HOLD',
  ARCHIVED = 'ARCHIVED',
}