/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import { compose, connect } from '@mep-ui/framework';
import { useIsCompositeDesktop } from '@mesh-tenant-multiverse-common/react';
import { COPCheckResultData } from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
import { isStaffPortal } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import {
  Actions,
  Resources,
  useAuthoriser,
} from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  INVALID_PAYID,
  PAYID_SERVICE_UNAVAILABLE,
  PDP_QUERY_ACTIONS,
  PayIdTypes,
  genericUnathorisedMessage,
  paymentConfirmationPageTitle,
  paymentDetailsPageTitle,
  reviewPaymentPageTitle,
} from '../../common/constants';
import {
  AccountOfPayId,
  AliasLookupStatus,
  BeneTypes,
  Beneficiary,
  DivisionOptionType,
  DivisionType,
  ErrorResponse,
  LookupMismatch,
  MakePaymentFormDataType,
  SchemeEligibility,
  defaultFormData,
} from '../../common/types';
import { useGetFromAccountOptions } from '../../common/useGetFromAccountOptions';
import { checkIsNewBeneficiary } from '../../common/utils';
import { PaymentConfirmation } from '../../components/PaymentConfirmation';
import { PaymentDetails } from '../../components/PaymentDetails';
import { PaymentReview } from '../../components/PaymentReview';
import BannerAlertBox from '../../galaxy-common/BannerAlertBox/BannerAlertBox';
import { scrollToTop } from '../../galaxy-common/utils/DOMUtils';
import { useOrganizationId } from '../../hooks/useOrganizationId';
import {
  accountListActions,
  accountNameCheckActions,
  accountNameCheckEntityActions,
  aliasLookupActions,
  aliasLookupByBeneIdActions,
  aliasLookupByBeneIdEntityActions,
  aliasLookupEntityActions,
  arrangementDetailsActions,
  beneficiaryCreateActions,
  beneficiaryListActions,
  bsbLookupActions,
  bsbLookupEntityActions,
  divisionListActions,
  getAllAccountList,
  getAllAccountNameCheck,
  getAllAliasLookup,
  getAllAliasLookupByBeneId,
  getAllArrangementDetails,
  getAllBeneficiaryList,
  getAllBsbLookup,
  getAllDivisionList,
  getAllPaymentCreate,
  getAllPaymentCreateForNewBeneficiary,
  getAllPaymentIdentifier,
  getAllSchemeEligibilities,
  isAccountListError as isAccountListErrorSelector,
  isAccountListFetching as isAccountListFetchingSelector,
  isAccountNameCheckError as isAccountNameCheckErrorSelector,
  isAccountNameCheckFetching as isAccountNameCheckFetchingSelector,
  isAliasLookupByBeneIdError as isAliasLookupByBeneIdErrorSelector,
  isAliasLookupByBeneIdFetching as isAliasLookupByBeneIdFetchingSelector,
  isAliasLookupError as isAliasLookupErrorSelector,
  isAliasLookupFetching as isAliasLookupFetchingSelector,
  isArrangementDetailsError as isArrangementDetailsErrorSelector,
  isArrangementDetailsFetching as isArrangementDetailsFetchingSelector,
  isBeneficiaryCreateError as isBeneficiaryCreateErrorSelector,
  isBeneficiaryCreateFetching as isBeneficiaryCreateFetchingSelector,
  isBeneficiaryListError,
  isBeneficiaryListFetching,
  isBsbLookupError as isBsbLookupErrorSelector,
  isBsbLookupFetching as isBsbLookupFetchingSelector,
  isDivisionListError as isDivisionListErrorSelector,
  isDivisionListFetching as isDivisionListFetchingSelector,
  isPaymentCreateError as isPaymentCreateErrorSelector,
  isPaymentCreateFetching as isPaymentCreateFetchingSelector,
  isPaymentCreateForNewBeneficiaryError as isPaymentCreateForNewBeneficiaryErrorSelector,
  isPaymentCreateForNewBeneficiaryFetching as isPaymentCreateForNewBeneficiaryFetchingSelector,
  isPaymentIdentifierError as isPaymentIdentifierErrorSelector,
  isPaymentIdentifierFetching as isPaymentIdentifierFetchingSelector,
  isSchemeEligibilitiesError as isSchemeEligibilitiesErrorSelector,
  isSchemeEligibilitiesFetching as isSchemeEligibilitiesFetchingSelector,
  paymentCreateActions,
  paymentCreateEntityActions,
  paymentCreateForNewBeneficiaryActions,
  paymentCreateForNewBeneficiaryEntityActions,
  paymentIdentifierActions,
  paymentIdentifierEntityActions,
  schemeEligibilitiesActions,
} from '../../store/generated';
import {
  isCopLimitExceededSelector,
  isCopServiceNotAvailableSelector,
} from '../../store/selectors/accountNameCheck';
import {
  getPostAddBeneficiaryErrors,
  getPostAddBeneficiaryStatusCode,
} from '../../store/selectors/addBeneficiary';
import {
  doesAliasIdContainInvalidDataSelector,
  isPayIdLimitExceededSelector,
  isPayIdNotValidSelector,
  isPayIdServiceNotAvailableSelector,
} from '../../store/selectors/aliasLookup';
import { getBsbLookupErrorStatusCode } from '../../store/selectors/bsbLookup';
import { getAllSchemeEligibilityErrors } from '../../store/selectors/getAllSchemeEligibilityErrors';
import {
  getPostPaymentCreateErrors,
  getPostPaymentCreateStatusCode,
} from '../../store/selectors/paymentCreate';
import {
  getPostPaymentCreateForNewBeneficiaryErrors,
  getPostPaymentCreateForNewBeneficiaryStatusCode,
} from '../../store/selectors/paymentCreateForNewBeneficiary';
import {
  getPostPaymentIdentifierErrors,
  getPostPaymentIdentifierStatusCode,
} from '../../store/selectors/paymentIdentifier';
import store from '../../store/store';
import type {
  Account,
  ArrangementDetails,
  ArrangementDetailsParamsPayload,
  BeneficiaryOptionsPayload,
  GetAccountListParamsPayload,
  GetBSBLookupParamsPayload,
  Payment,
  PostAliasLookupByBeneIdParamsPayload,
  PostAliasLookupParamsPayload,
  PostBeneficiaryListParamsPayload,
  PostBeneficiaryParamsPayload,
  PostGeneratePaymentIdParams,
  PostPaymentsOptionsPayload,
  PostPaymentsParamsPayload,
  RequestOptionsPayload,
  RootState,
  fetchSchemeEligibilitiesParams,
  fetchSchemeEligibilitiesPayload,
  getDivisionListParamsPayload,
} from '../../store/types';
import { PostAccountNameCheckParams } from '../../store/types/AccountNameCheck';
import { PostAliasLookup } from '../../store/types/AliasLookup';
import { Branch } from '../../store/types/BsbLookup';
import { BeneficiaryStatus, defaultDivisionData } from './common';
import {
  paymentConfirmationPage,
  paymentDetailsPage,
  reviewPaymentPage,
} from './constants';

const initLookupMismatch: LookupMismatch = {
  beneficiaryName: '',
  aliasLookupName: '',
};

export type MakePaymentContainerProps = {
  paymentCreate: (
    params: PostPaymentsParamsPayload,
    options: PostPaymentsOptionsPayload
  ) => void;
  paymentCreateForNewBeneficiary: (
    params: PostPaymentsParamsPayload,
    options: PostPaymentsOptionsPayload
  ) => void;
  addBeneficiary: (
    params: PostBeneficiaryParamsPayload,
    options: BeneficiaryOptionsPayload
  ) => void;
  clearPaymentCreate: () => void;
  clearPaymentCreateForNewBeneficiary: () => void;
  getPaymentId: (params: PostGeneratePaymentIdParams) => void;
  postArrangementDetails: (params: ArrangementDetailsParamsPayload) => void;
  paymentId: string;
  isPaymentCreateFetching: boolean;
  isPaymentCreateForNewBeneficiaryFetching: boolean;
  isPaymentCreateForNewBeneficiaryError: boolean;
  isArrangementDetailsFetching: boolean;
  isArrangementDetailsError: boolean;
  isPaymentCreateError: boolean;
  payment: Payment;
  paymentForNewBeneficiary: Payment;
  apiStatus?: number;
  beneficiaries?: Beneficiary[];
  allAccountList: Account[];
  isBeneficiariesFetching: boolean;
  isAccountListFetching: boolean;
  postAliasLookup: (params: PostAliasLookupParamsPayload) => void;
  aliasLookupData: PostAliasLookup[];
  isAliasLookupFetching: boolean;
  isAliasLookupError: boolean;
  postAliasLookupByBeneId: (
    params: PostAliasLookupByBeneIdParamsPayload
  ) => void;
  aliasLookupByBeneIdData: PostAliasLookup[];
  isAliasLookupByBeneIdFetching: boolean;
  isAliasLookupByBeneIdError: boolean;
  getBsbLookup: (params: GetBSBLookupParamsPayload) => void;
  bsbLookupData: Branch[];
  isBsbLookupFetching: boolean;
  isBsbLookupError: boolean;
  bsbLookupErrorStatusCode?: number;
  isBeneficiariesError: boolean;
  isAccountListError: boolean;
  doesAliasIdContainInvalidData: boolean;
  isPayIdNotValid: boolean;
  isPayIdLimitExceeded: boolean;
  isPayIdServiceNotAvailable: boolean;
  clearPostAliasLookup: () => void;
  clearPostAliasLookupByBeneId: () => void;
  clearBsbLookup: () => void;
  getAccountListByStatus: (
    params: GetAccountListParamsPayload,
    options: RequestOptionsPayload
  ) => void;
  retrieveBeneficiaries: (
    params: PostBeneficiaryListParamsPayload,
    options: RequestOptionsPayload
  ) => void;
  postPaymentErrors?: ErrorResponse[];
  postNewBeneficiaryPaymentCreateStatusCode?: number;
  postPaymentCreateForNewBeneficiaryErrors?: ErrorResponse[];
  postAddBeneficiaryStatusCode?: number;
  postAddBeneficiaryErrors?: ErrorResponse[];
  fetchSchemeEligibilities?: (params: fetchSchemeEligibilitiesPayload) => void;
  allSchemeEligibilities: SchemeEligibility[];
  isSchemeEligibilitiesFetching: boolean;
  isSchemeEligibilitiesError: boolean;
  allSchemeEligibilityErrors?: ErrorResponse[];
  isPaymentIdentifierFetching: boolean;
  isPaymentIdentifierError?: boolean;
  paymentIdentifierApiStatus?: number;
  paymentIdentifierErrors?: ErrorResponse[];
  allArrangementDetails: ArrangementDetails[];
  clearPaymentIdentifier: () => void;
  isBeneficiaryCreateFetching: boolean;
  isBeneficiaryCreateError: boolean;
  getDivisionList: (
    params: getDivisionListParamsPayload,
    options: RequestOptionsPayload
  ) => void;
  isDivisionListFetching: boolean;
  isDivisionListError: boolean;
  allDivisionList: DivisionType[];
  postAccountNameCheck: (params: PostAccountNameCheckParams) => void;
  accountNameCheckData: COPCheckResultData[];
  isAccountNameCheckFetching: boolean;
  isAccountNameCheckError: boolean;
  clearAccountNameCheck: () => void;
  isCopLimitExceeded: boolean;
  isCopServiceNotAvailable: boolean;
};

export function MakePaymentContainer({
  paymentCreate,
  paymentCreateForNewBeneficiary,
  addBeneficiary,
  clearPaymentCreate,
  clearPaymentCreateForNewBeneficiary,
  getPaymentId,
  paymentId,
  isPaymentCreateFetching,
  isPaymentCreateForNewBeneficiaryFetching,
  isPaymentCreateForNewBeneficiaryError,
  isArrangementDetailsFetching,
  isArrangementDetailsError,
  postArrangementDetails,
  isPaymentCreateError,
  payment,
  paymentForNewBeneficiary,
  apiStatus,
  beneficiaries = [],
  postAliasLookup,
  aliasLookupData,
  isAliasLookupFetching,
  isAliasLookupError,
  postAliasLookupByBeneId,
  aliasLookupByBeneIdData,
  isAliasLookupByBeneIdFetching,
  isAliasLookupByBeneIdError,
  getBsbLookup,
  bsbLookupData,
  isBsbLookupFetching,
  isBsbLookupError,
  bsbLookupErrorStatusCode,
  isBeneficiariesFetching,
  isAccountListFetching,
  isBeneficiariesError,
  isAccountListError,
  doesAliasIdContainInvalidData,
  isPayIdNotValid,
  isPayIdServiceNotAvailable,
  isPayIdLimitExceeded,
  allAccountList,
  clearPostAliasLookup,
  clearPostAliasLookupByBeneId,
  clearBsbLookup,
  getAccountListByStatus,
  retrieveBeneficiaries,
  postPaymentErrors,
  postNewBeneficiaryPaymentCreateStatusCode,
  postPaymentCreateForNewBeneficiaryErrors,
  postAddBeneficiaryStatusCode,
  postAddBeneficiaryErrors,
  fetchSchemeEligibilities = () => {},
  allSchemeEligibilities,
  isSchemeEligibilitiesFetching,
  isSchemeEligibilitiesError,
  allSchemeEligibilityErrors,
  isPaymentIdentifierFetching,
  isPaymentIdentifierError,
  paymentIdentifierApiStatus,
  paymentIdentifierErrors,
  allArrangementDetails,
  clearPaymentIdentifier,
  isBeneficiaryCreateFetching,
  isBeneficiaryCreateError,
  getDivisionList,
  isDivisionListFetching,
  isDivisionListError,
  allDivisionList,
  postAccountNameCheck,
  accountNameCheckData,
  isAccountNameCheckFetching,
  isAccountNameCheckError,
  clearAccountNameCheck,
  isCopLimitExceeded,
  isCopServiceNotAvailable,
}: MakePaymentContainerProps) {
  const toBeneficiaryOptions: Beneficiary[] = beneficiaries;

  const { defaultFromAccount, fromAccountOptions } =
    useGetFromAccountOptions(allAccountList);

  const [makePaymentFormData, setMakePaymentFormData] =
    useState<MakePaymentFormDataType>(defaultFormData);

  const [
    isNewBeneficiaryBsbLookupTriggered,
    setIsNewBeneficiaryBsbLookupTriggered,
  ] = useState<boolean>(false);
  const [
    isNewBeneficiaryPayIdLookupTriggered,
    setIsNewBeneficiaryPayIdLookupTriggered,
  ] = useState<boolean>(false);

  // Track whether to show CoP check results
  const [shouldShowCopResults, setShouldShowCopResults] = useState(false);

  const resetLookup = () => {
    setIsNewBeneficiaryBsbLookupTriggered(false);
    setIsNewBeneficiaryPayIdLookupTriggered(false);
    clearPostAliasLookup();
    clearPostAliasLookupByBeneId();
    clearBsbLookup();
  };

  const [divisions, setDivisions] =
    useState<DivisionOptionType[]>(defaultDivisionData);
  const [selectedDivision, setSelectedDivision] =
    useState<DivisionOptionType | null>(null);

  // Track if division list has been fetched to avoid calling other APIs prematurely
  const [hasDivisionListBeenFetched, setHasDivisionListBeenFetched] = useState(
    !isStaffPortal()
  );

  const showDivisionField =
    !isStaffPortal() &&
    !isDivisionListFetching &&
    !isDivisionListError &&
    allDivisionList.length > 0;

  // Track if initial auto-population has occurred to prevent re-population on division change
  const hasAutoPopulatedFromAccount = useRef(false);

  useEffect(() => {
    // Only auto-populate fromAccount on initial load, not when division changes
    // Once a division is selected, user should manually select the account
    if (
      defaultFromAccount &&
      !makePaymentFormData.fromAccount &&
      !hasAutoPopulatedFromAccount.current
    ) {
      setMakePaymentFormData((prev) => ({
        ...prev,
        fromAccount: defaultFromAccount,
      }));
      hasAutoPopulatedFromAccount.current = true;
    }
  }, [defaultFromAccount]);

  const [lookupMismatch, setLookupMismatch] =
    useState<LookupMismatch>(initLookupMismatch);
  const [navigateTo, setNavigationTo] = useState(paymentDetailsPage);

  const [selectedBeneficiary, setSelectedBeneficiary] =
    useState<Beneficiary | null>(null);

  const [lookUpErr, setLookUpErr] = useState<string>('');

  const handlePaymentFormDataChange = (
    newTransferFundFormData: MakePaymentFormDataType
  ) => {
    setMakePaymentFormData(newTransferFundFormData);
  };

  const isCompositeDesktop = useIsCompositeDesktop();

  const orgId = useOrganizationId();

  const [isOrgIdFetching, setIsOrgIdFetching] = useState<boolean>(true);

  // Helper function to determine if data should be fetched based on composite desktop and orgId conditions
  const getShouldFetchData = useCallback(() => {
    const isNonCompositeDesktop = !isCompositeDesktop;
    const hasOrgId = !!orgId;

    return isNonCompositeDesktop || (isCompositeDesktop && hasOrgId);
  }, [isCompositeDesktop, orgId]);

  const initiatePayment = (
    params: PostPaymentsParamsPayload,
    option: PostPaymentsOptionsPayload
  ) => {
    const isNewBeneficiaryFlag = checkIsNewBeneficiary(makePaymentFormData);
    if (isNewBeneficiaryFlag) {
      paymentCreateForNewBeneficiary(params, option);
    } else {
      paymentCreate(params, option);
    }
  };

  // Wrapper function to transform simple params to Redux action shape for Account Name Check
  const handlePostAccountNameCheck = useCallback(
    (params: { accountName: string; accountNumber: string; bsb: string }) => {
      // Clear previous result before making new call
      clearAccountNameCheck();
      // Show CoP results when check is triggered
      setShouldShowCopResults(true);
      postAccountNameCheck({
        params: {
          payee: {
            accountName: params.accountName,
            accountId: {
              accountNumber: params.accountNumber,
              BSB: params.bsb,
            },
          },
        },
      });
    },
    [postAccountNameCheck, clearAccountNameCheck]
  );

  const getAccountList = useCallback(
    (
      divisionId?: string,
      accountStatus: 'ACTIVE' | 'ACTIVE_AND_INACTIVE' = 'ACTIVE'
    ) => {
      if (!isAccountListFetching) {
        const params: GetAccountListParamsPayload = {
          pdpQueryAction: PDP_QUERY_ACTIONS.INITIATE_PAYMENT,
          accountStatus,
          ...(divisionId && { divisionId }),
          meta: {
            replaceEntities: ['accountList'],
          },
        };

        getAccountListByStatus(params, {
          headers: {
            ...(orgId && {
              'protected-orgId': orgId,
            }),
          },
        });
      }
    },
    [isAccountListFetching, orgId]
  );

  const getAccountListFn = (input?: string) =>
    getAccountList(selectedDivision?.id);
  const getActiveBeneficiariesFn = (input?: string) =>
    getActiveBeneficiaries(selectedDivision?.id);

  const getActiveBeneficiaries = useCallback(
    (divisionId?: string) => {
      if (!isBeneficiariesFetching) {
        retrieveBeneficiaries(
          {
            params: {
              statuses: [BeneficiaryStatus.ACTIVE],
              ...(divisionId && { divisionId }),
            },
          },
          {
            headers: {
              ...(orgId && {
                'protected-orgId': orgId,
              }),
            },
          }
        );
      }
    },
    [isBeneficiariesFetching, orgId]
  );

  const fetchDivisionList = useCallback(() => {
    const params: getDivisionListParamsPayload = {
      pdpQueryAction: PDP_QUERY_ACTIONS.INITIATE_PAYMENT,
      meta: {
        replaceEntities: ['divisionList'],
      },
    };

    if (!isDivisionListFetching) {
      getDivisionList(params, {
        headers: {
          ...(orgId && {
            'protected-orgId': orgId,
          }),
        },
      });
    }
  }, [isDivisionListFetching, orgId]);

  const postSchemeEligibilities = useCallback(
    (params: fetchSchemeEligibilitiesParams) => {
      const schemeEligibilityParams: fetchSchemeEligibilitiesPayload = {
        params,
        meta: {
          replaceEntities: ['schemeEligibilities'],
        },
      };
      fetchSchemeEligibilities(schemeEligibilityParams);
    },
    [fetchSchemeEligibilities]
  );

  // Initial data fetch on page load - always fetch division list first
  useEffect(() => {
    const shouldFetchData = getShouldFetchData();

    if (
      shouldFetchData &&
      !isDivisionListFetching &&
      hasDivisionListBeenFetched
    ) {
      fetchDivisionList();
      resetLookup();
      setIsOrgIdFetching(false);
      setHasDivisionListBeenFetched(false);
    }
  }, [getShouldFetchData, isDivisionListFetching]);

  // Track when division list fetch completes and conditionally fetch other data
  useEffect(() => {
    if (
      !isDivisionListFetching &&
      !hasDivisionListBeenFetched &&
      getShouldFetchData()
    ) {
      // Only call these APIs if division list is empty of if it is staff portal
      if (
        (!isDivisionListError && allDivisionList.length === 0) ||
        isStaffPortal()
      ) {
        setIsOrgIdFetching(false);
        // getActiveBeneficiaries();
        // getAccountList();
        resetLookup();
      }
    }
  }, [
    isDivisionListFetching,
    allDivisionList,
    hasDivisionListBeenFetched,
    getShouldFetchData,
  ]);

  useEffect(() => {
    const transformedDivisionList = allDivisionList.map((division) => ({
      id: division.divisionId,
      name: division.divisionName,
      label: division.divisionName,
    }));

    setDivisions([...defaultDivisionData, ...(transformedDivisionList ?? [])]);
  }, [allDivisionList]);

  const clearLookupInfo = () => {
    setLookUpErr('');
    setLookupMismatch(initLookupMismatch);
  };

  useEffect(() => {
    if (selectedBeneficiary?.type === BeneTypes.BSB_ACCOUNT_NUMBER) {
      clearLookupInfo();
      return;
    }
    const aliasLookupName = aliasLookupData?.[0]?.name || '';
    const beneficiaryName =
      (selectedBeneficiary?.account as AccountOfPayId)?.payIDName || '';
    if (isPayIdServiceNotAvailable || isAliasLookupByBeneIdError) {
      setLookUpErr(PAYID_SERVICE_UNAVAILABLE);
    } else if (doesAliasIdContainInvalidData || isPayIdNotValid) {
      setLookUpErr(INVALID_PAYID);
    } else if (
      selectedBeneficiary &&
      aliasLookupName &&
      beneficiaryName !== aliasLookupName
    ) {
      setLookupMismatch({
        beneficiaryName,
        aliasLookupName,
      });
    } else {
      clearLookupInfo();
    }
  }, [
    doesAliasIdContainInvalidData,
    isPayIdNotValid,
    isPayIdServiceNotAvailable,
    aliasLookupData,
    selectedBeneficiary,
    isAliasLookupByBeneIdError,
  ]);

  let aliasLookupStatus: AliasLookupStatus = 'not-verified';
  if (selectedBeneficiary?.type === BeneTypes.BSB_ACCOUNT_NUMBER) {
    aliasLookupStatus = 'not-verified';
  }
  if (isAliasLookupFetching || isAliasLookupByBeneIdFetching) {
    aliasLookupStatus = 'fetching';
  } else if (lookUpErr || isAliasLookupByBeneIdError) {
    aliasLookupStatus = 'error';
  } else if (lookupMismatch.aliasLookupName && lookupMismatch.beneficiaryName) {
    aliasLookupStatus = 'warning';
  } else if (aliasLookupData.length || aliasLookupByBeneIdData.length) {
    aliasLookupStatus = 'verified';
  } else {
    aliasLookupStatus = 'not-verified';
  }

  const selectBeneficiary = (beneficiary?: Beneficiary) => {
    resetLookup();
    clearLookupInfo();
    if (beneficiary && beneficiary.type === BeneTypes.PAYID) {
      const account = beneficiary.account as AccountOfPayId;
      if (account?.payIDType && PayIdTypes.includes(account.payIDType)) {
        const createPostTransactionParams: PostAliasLookupByBeneIdParamsPayload =
          {
            params: {
              id: beneficiary.id,
            },
            meta: {
              replaceEntities: ['aliasLookupByBeneId'],
            },
          };
        postAliasLookupByBeneId(createPostTransactionParams);
      }
    }
    setSelectedBeneficiary(beneficiary || null);
  };

  const renderPaymentComponents = (newNavigateTo: string) => {
    setNavigationTo(newNavigateTo);
    scrollToTop();
  };

  const onRefresh = () => {
    // getActiveBeneficiaries(selectedDivision?.id);
    // getAccountList(selectedDivision?.id);
  };

  const onDivisionRefresh = () => {
    fetchDivisionList();
  };

  let isPaymentCreateFetchingFinal = isPaymentCreateFetching;
  let apiStatusFinal = apiStatus;
  let postPaymentCreateErrorsFinal = postPaymentErrors;
  let isPaymentCreateErrorFinal = isPaymentCreateError;
  let paymentFinal = payment;
  if (checkIsNewBeneficiary(makePaymentFormData)) {
    isPaymentCreateFetchingFinal = isPaymentCreateForNewBeneficiaryFetching;
    apiStatusFinal = postNewBeneficiaryPaymentCreateStatusCode;
    postPaymentCreateErrorsFinal = postPaymentCreateForNewBeneficiaryErrors;
    isPaymentCreateErrorFinal = isPaymentCreateForNewBeneficiaryError;
    paymentFinal = paymentForNewBeneficiary;
  }

  const onSelectDivision = (division?: DivisionOptionType) => {
    if (division?.id && division?.label !== defaultDivisionData[0].label) {
      // getAccountList(division?.id);
      // getActiveBeneficiaries(division?.id);

      setSelectedDivision(division);
    }
  };

  const { authorised } = useAuthoriser(
    Resources.ACCOUNTS,
    Actions.INITIATE_PAYMENT
  );

  const renderCurrentPage = () => {
    switch (navigateTo) {
      case paymentDetailsPage: {
        document.title = paymentDetailsPageTitle;
        return (
          <PaymentDetails
            makePaymentFormData={makePaymentFormData}
            handlePaymentFormDataChange={handlePaymentFormDataChange}
            renderPaymentComponents={renderPaymentComponents}
            toBeneficiaryOptions={toBeneficiaryOptions}
            fromAccountOptions={fromAccountOptions}
            isAccountListFetching={isAccountListFetching}
            isBeneficiariesFetching={isBeneficiariesFetching}
            isOrgIdFetching={isOrgIdFetching}
            aliasLookupStatus={aliasLookupStatus}
            aliasLookupName={
              aliasLookupData?.[0]?.name ||
              aliasLookupByBeneIdData?.[0]?.name ||
              ''
            }
            postAliasLookup={postAliasLookup}
            aliasLookupData={{ ...aliasLookupData, ...aliasLookupByBeneIdData }}
            isAliasLookupFetching={
              isAliasLookupFetching || isAliasLookupByBeneIdFetching
            }
            isAliasLookupError={
              isAliasLookupError || isAliasLookupByBeneIdError
            }
            getBsbLookup={getBsbLookup}
            bsbLookupData={bsbLookupData}
            isBsbLookupFetching={isBsbLookupFetching}
            isBsbLookupError={isBsbLookupError}
            bsbLookupErrorStatusCode={bsbLookupErrorStatusCode}
            isAccountListError={isAccountListError}
            isBeneficiariesError={isBeneficiariesError}
            lookUpErr={lookUpErr}
            lookupMismatch={lookupMismatch}
            selectBeneficiary={selectBeneficiary}
            onRefresh={onRefresh}
            fetchSchemeEligibilities={postSchemeEligibilities}
            schemeEligibilities={allSchemeEligibilities}
            isSchemeEligibilitiesFetching={isSchemeEligibilitiesFetching}
            isSchemeEligibilitiesError={isSchemeEligibilitiesError}
            schemeEligibilityErrors={allSchemeEligibilityErrors}
            postArrangementDetails={postArrangementDetails}
            // Redux state for robust PayID error detection
            doesAliasIdContainInvalidData={doesAliasIdContainInvalidData}
            isPayIdNotValid={isPayIdNotValid}
            isPayIdServiceNotAvailable={isPayIdServiceNotAvailable}
            isPayIdLimitExceeded={isPayIdLimitExceeded}
            isNewBeneficiaryBsbLookupTriggered={
              isNewBeneficiaryBsbLookupTriggered
            }
            setIsNewBeneficiaryBsbLookupTriggered={
              setIsNewBeneficiaryBsbLookupTriggered
            }
            isNewBeneficiaryPayIdLookupTriggered={
              isNewBeneficiaryPayIdLookupTriggered
            }
            setIsNewBeneficiaryPayIdLookupTriggered={
              setIsNewBeneficiaryPayIdLookupTriggered
            }
            resetLookup={resetLookup}
            divisions={divisions}
            onDivisionChange={onSelectDivision}
            onDivisionRefresh={onDivisionRefresh}
            showDivisionField={showDivisionField}
            isDivisionListFetching={!isStaffPortal() && isDivisionListFetching}
            isDivisionListError={isDivisionListError}
            allArrangementDetails={allArrangementDetails[0]}
            postAccountNameCheck={handlePostAccountNameCheck}
            copCheckResultData={accountNameCheckData?.[0]}
            isCopLoading={isAccountNameCheckFetching}
            isCopError={isAccountNameCheckError || isCopServiceNotAvailable}
            shouldShowCopResults={shouldShowCopResults}
            isCopLimitExceeded={isCopLimitExceeded}
            onInvalidateCopCheck={() => {
              setShouldShowCopResults(false);
              clearAccountNameCheck();
            }}
            getAccountListFn={getAccountListFn}
            getActiveBeneficiariesFn={getActiveBeneficiariesFn}
          />
        );
      }
      case reviewPaymentPage: {
        document.title = reviewPaymentPageTitle;
        return (
          <PaymentReview
            makePaymentFormData={makePaymentFormData}
            renderPaymentComponents={renderPaymentComponents}
            submitPayment={initiatePayment}
            addBeneficiary={addBeneficiary}
            isPaymentCreateFetching={isPaymentCreateFetchingFinal}
            isArrangementDetailsFetching={isArrangementDetailsFetching}
            isPaymentCreateError={isPaymentCreateErrorFinal}
            lookupMismatch={lookupMismatch}
            paymentId={paymentId}
            getPaymentId={getPaymentId}
            apiStatus={apiStatusFinal}
            isPaymentIdentifierFetching={isPaymentIdentifierFetching}
            isPaymentIdentifierError={isPaymentIdentifierError}
            paymentIdentifierApiStatus={paymentIdentifierApiStatus}
            paymentIdentifierErrors={paymentIdentifierErrors}
            postPaymentErrors={postPaymentCreateErrorsFinal}
            clearPaymentCreate={clearPaymentCreate}
            clearPaymentCreateForNewBeneficiary={
              clearPaymentCreateForNewBeneficiary
            }
            clearPaymentIdentifier={clearPaymentIdentifier}
            allArrangementDetails={allArrangementDetails}
            isArrangementDetailsError={isArrangementDetailsError}
            isBeneficiaryCreateFetching={isBeneficiaryCreateFetching}
            isBeneficiaryCreateError={isBeneficiaryCreateError}
            postAddBeneficiaryStatusCode={postAddBeneficiaryStatusCode}
            matchedCOPAccountName={
              accountNameCheckData?.[0]?.matchedCOPAccountName
            }
            matchedCOPStatusCode={
              accountNameCheckData?.[0]?.matchedCOPStatusCode
            }
            matchedCOPColour={accountNameCheckData?.[0]?.matchedCOPColour}
          />
        );
      }
      case paymentConfirmationPage: {
        document.title = paymentConfirmationPageTitle;
        return (
          <PaymentConfirmation
            makePaymentFormData={makePaymentFormData}
            payment={paymentFinal}
            lookupMismatch={lookupMismatch}
            apiStatus={apiStatusFinal}
            errors={postPaymentCreateErrorsFinal}
            paymentIdentifierApiStatus={paymentIdentifierApiStatus}
            paymentIdentifierErrors={paymentIdentifierErrors}
            makerCheckerPaymentId={paymentId}
            postAddBeneficiaryStatusCode={postAddBeneficiaryStatusCode}
            postAddBeneficiaryErrors={postAddBeneficiaryErrors}
          />
        );
      }
      default: {
        return null;
      }
    }
  };

  return authorised ? (
    renderCurrentPage()
  ) : (
    <BannerAlertBox id="payment-status-banner" styling="danger">
      {genericUnathorisedMessage}
    </BannerAlertBox>
  );
}

const mapStateToProps = (state: RootState) => ({
  isPaymentCreateFetching: isPaymentCreateFetchingSelector(state),
  isPaymentCreateForNewBeneficiaryFetching:
    isPaymentCreateForNewBeneficiaryFetchingSelector(state),
  isPaymentCreateForNewBeneficiaryError:
    isPaymentCreateForNewBeneficiaryErrorSelector(state),
  isArrangementDetailsFetching: isArrangementDetailsFetchingSelector(state),
  isArrangementDetailsError: isArrangementDetailsErrorSelector(state),
  isPaymentCreateError: isPaymentCreateErrorSelector(state),
  payment: getAllPaymentCreate(state)[0],
  paymentForNewBeneficiary: getAllPaymentCreateForNewBeneficiary(state)[0],
  apiStatus: getPostPaymentCreateStatusCode(state),
  postNewBeneficiaryPaymentCreateStatusCode:
    getPostPaymentCreateForNewBeneficiaryStatusCode(state),
  postPaymentErrors: getPostPaymentCreateErrors(state),
  postPaymentCreateForNewBeneficiaryErrors:
    getPostPaymentCreateForNewBeneficiaryErrors(state),
  postAddBeneficiaryErrors: getPostAddBeneficiaryErrors(state),
  postAddBeneficiaryStatusCode: getPostAddBeneficiaryStatusCode(state),
  beneficiaries: getAllBeneficiaryList(state) as Beneficiary[],
  allAccountList: getAllAccountList(state),
  aliasLookupData: getAllAliasLookup(state),
  isAliasLookupFetching: isAliasLookupFetchingSelector(state),
  isAliasLookupError: isAliasLookupErrorSelector(state),
  aliasLookupByBeneIdData: getAllAliasLookupByBeneId(state),
  isAliasLookupByBeneIdFetching: isAliasLookupByBeneIdFetchingSelector(state),
  isAliasLookupByBeneIdError: isAliasLookupByBeneIdErrorSelector(state),
  bsbLookupData: getAllBsbLookup(state),
  isBsbLookupFetching: isBsbLookupFetchingSelector(state),
  isBsbLookupError: isBsbLookupErrorSelector(state),
  doesAliasIdContainInvalidData: doesAliasIdContainInvalidDataSelector(state),
  isPayIdNotValid: isPayIdNotValidSelector(state),
  isPayIdServiceNotAvailable: isPayIdServiceNotAvailableSelector(state),
  isPayIdLimitExceeded: isPayIdLimitExceededSelector(state),
  isAccountListError: isAccountListErrorSelector(state),
  isAccountListFetching: isAccountListFetchingSelector(state),
  isBeneficiariesError: isBeneficiaryListError(state),
  isBeneficiariesFetching: isBeneficiaryListFetching(state),
  allSchemeEligibilities: getAllSchemeEligibilities(state),
  isSchemeEligibilitiesFetching: isSchemeEligibilitiesFetchingSelector(state),
  isSchemeEligibilitiesError: isSchemeEligibilitiesErrorSelector(state),
  allSchemeEligibilityErrors: getAllSchemeEligibilityErrors(state),
  paymentId: getAllPaymentIdentifier(state)[0]?.paymentId,
  isPaymentIdentifierFetching: isPaymentIdentifierFetchingSelector(state),
  isPaymentIdentifierError: isPaymentIdentifierErrorSelector(state),
  paymentIdentifierApiStatus: getPostPaymentIdentifierStatusCode(state),
  paymentIdentifierErrors: getPostPaymentIdentifierErrors(state),
  allArrangementDetails: getAllArrangementDetails(state),
  bsbLookupErrorStatusCode: getBsbLookupErrorStatusCode(state),
  isBeneficiaryCreateFetching: isBeneficiaryCreateFetchingSelector(state),
  isBeneficiaryCreateError: isBeneficiaryCreateErrorSelector(state),
  isDivisionListFetching: isDivisionListFetchingSelector(state),
  isDivisionListError: isDivisionListErrorSelector(state),
  allDivisionList: getAllDivisionList(state),
  accountNameCheckData: getAllAccountNameCheck(state),
  isAccountNameCheckFetching: isAccountNameCheckFetchingSelector(state),
  isAccountNameCheckError: isAccountNameCheckErrorSelector(state),
  isCopLimitExceeded: isCopLimitExceededSelector(state),
  isCopServiceNotAvailable: isCopServiceNotAvailableSelector(state),
});

const mapDispatchToProps = {
  paymentCreate:
    paymentCreateActions.api.expGalaxyPaymentV2.paymentCreate.post.request,
  paymentCreateForNewBeneficiary:
    paymentCreateForNewBeneficiaryActions.api.expGalaxyPaymentV2
      .paymentCreateForNewBeneficiary.post.request,
  addBeneficiary:
    beneficiaryCreateActions.api.expGalaxyPaymentV2.beneficiaryCreate.post
      .request,
  clearPaymentCreate:
    paymentCreateEntityActions.api.expGalaxyPaymentV2.paymentCreate.clear
      .request,
  clearPaymentCreateForNewBeneficiary:
    paymentCreateForNewBeneficiaryEntityActions.api.expGalaxyPaymentV2
      .paymentCreateForNewBeneficiary.clear.request,
  postAliasLookup:
    aliasLookupActions.api.expGalaxyPaymentV2.aliasLookup.post.request,
  postAliasLookupByBeneId:
    aliasLookupByBeneIdActions.api.expGalaxyPaymentV2.aliasLookupByBeneId.post
      .request,
  clearPostAliasLookupByBeneId:
    aliasLookupByBeneIdEntityActions.api.expGalaxyPaymentV2.aliasLookupByBeneId
      .clear.request,
  clearPostAliasLookup:
    aliasLookupEntityActions.api.expGalaxyPaymentV2.aliasLookup.clear.request,
  clearBsbLookup:
    bsbLookupEntityActions.api.expGalaxyPaymentV2.bsbLookup.clear.request,
  getBsbLookup: bsbLookupActions.api.expGalaxyPaymentV2.bsbLookup.get.request,
  getAccountListByStatus:
    accountListActions.api.expGalaxyPaymentV2.accountList.get.request,
  retrieveBeneficiaries:
    beneficiaryListActions.api.expGalaxyPaymentV2.beneficiaryList.post.request,
  fetchSchemeEligibilities:
    schemeEligibilitiesActions.api.expGalaxyPaymentV2.schemeEligibilities.post
      .request,
  getPaymentId:
    paymentIdentifierActions.api.expGalaxyPaymentV2.paymentIdentifier.get
      .request,
  clearPaymentIdentifier:
    paymentIdentifierEntityActions.api.expGalaxyPaymentV2.paymentIdentifier
      .clear.request,
  postArrangementDetails:
    arrangementDetailsActions.api.expGalaxyPaymentV2.arrangementDetails.post
      .request,
  getDivisionList:
    divisionListActions.api.expGalaxyPaymentV2.divisionList.get.request,
  postAccountNameCheck:
    accountNameCheckActions.api.expGalaxyPaymentV2.accountNameCheck.post
      .request,
  clearAccountNameCheck:
    accountNameCheckEntityActions.api.expGalaxyPaymentV2.accountNameCheck.clear
      .request,
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps, null, {
    context: store.contextRef,
  })
)(MakePaymentContainer);
