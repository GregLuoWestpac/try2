export const paymentDetailsPage = 'payment-details';
export const reviewPaymentPage = 'review-payment';
export const paymentConfirmationPage = 'payment-confirmation';
