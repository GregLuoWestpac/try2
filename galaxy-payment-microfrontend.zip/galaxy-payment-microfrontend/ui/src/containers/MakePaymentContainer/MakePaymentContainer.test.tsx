/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { useAuthoriser } from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import '@testing-library/jest-dom';
import { render } from '@testing-library/react';
import React from 'react';
import {
  useIsCompositeDesktop,
  usePlatformState,
} from '@mesh-tenant-multiverse-common/react';
import { useGetFromAccountOptions } from '../../common/useGetFromAccountOptions';
import { useOrganizationId } from '../../hooks/useOrganizationId';
import { Payment } from '../../store/types';
import {
  MakePaymentContainer,
  type MakePaymentContainerProps,
} from './MakePaymentContainer';

jest.mock('../../store/generated', () => ({
  isAliasLookupError: jest.fn(() => false),
  getSchemeEligibilitiesSlice: jest.fn(() => ({})),
  // Newly added BSB lookup actions
  bsbLookupEntityActions: {
    api: {
      expGalaxyPaymentV2: {
        bsbLookup: {
          clear: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  bsbLookupActions: {
    api: {
      expGalaxyPaymentV2: {
        bsbLookup: {
          get: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  paymentCreateActions: {
    api: {
      expGalaxyPaymentV2: {
        paymentCreate: {
          post: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  paymentCreateForNewBeneficiaryActions: {
    api: {
      expGalaxyPaymentV2: {
        paymentCreateForNewBeneficiary: {
          post: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  paymentCreateForNewBeneficiaryEntityActions: {
    api: {
      expGalaxyPaymentV2: {
        paymentCreateForNewBeneficiary: {
          clear: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  paymentGeneratePaymentIdActions: {
    api: {
      expGalaxyPaymentV2: {
        paymentGeneratePaymentId: {
          post: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  addBeneficiaryActions: {
    api: {
      expGalaxyPaymentV2: {
        addBeneficiary: {
          post: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  beneficiaryCreateActions: {
    api: {
      expGalaxyPaymentV2: {
        beneficiaryCreate: {
          post: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  paymentCreateEntityActions: {
    api: {
      expGalaxyPaymentV2: {
        paymentCreate: {
          clear: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  aliasLookupEntityActions: {
    api: {
      expGalaxyPaymentV2: {
        aliasLookup: {
          clear: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  aliasLookupByBeneIdEntityActions: {
    api: {
      expGalaxyPaymentV2: {
        aliasLookupByBeneId: {
          clear: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  paymentIdentifierActions: {
    api: {
      expGalaxyPaymentV2: {
        paymentIdentifier: {
          get: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  paymentIdentifierEntityActions: {
    api: {
      expGalaxyPaymentV2: {
        paymentIdentifier: {
          clear: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  schemeEligibilitiesActions: {
    api: {
      expGalaxyPaymentV2: {
        schemeEligibilities: {
          post: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  aliasLookupActions: {
    api: {
      expGalaxyPaymentV2: {
        aliasLookup: {
          post: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  aliasLookupByBeneIdActions: {
    api: {
      expGalaxyPaymentV2: {
        aliasLookupByBeneId: {
          post: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  accountListActions: {
    api: {
      expGalaxyPaymentV2: {
        accountList: {
          get: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  beneficiaryListActions: {
    api: {
      expGalaxyPaymentV2: {
        beneficiaryList: {
          post: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  arrangementDetailsActions: {
    api: {
      expGalaxyPaymentV2: {
        arrangementDetails: {
          post: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  divisionListActions: {
    api: {
      expGalaxyPaymentV2: {
        divisionList: {
          get: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  accountNameCheckActions: {
    api: {
      expGalaxyPaymentV2: {
        accountNameCheck: {
          post: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  accountNameCheckEntityActions: {
    api: {
      expGalaxyPaymentV2: {
        accountNameCheck: {
          clear: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  isBeneficiaryListFetching: jest.fn(() => false),
  isPaymentCreateForNewBeneficiaryFetching: jest.fn(() => false),
  isPaymentCreateForNewBeneficiaryError: jest.fn(() => false),
  isBeneficiaryCreateFetching: jest.fn(() => false),
  isAliasLookupFetching: jest.fn(() => false),
  isBsbLookupFetching: jest.fn(() => false),
  isPaymentIdentifierError: jest.fn(() => false),
  isPaymentIdentifierFetching: jest.fn(() => false),
  isPaymentCreateError: jest.fn(() => false),
  isPaymentCreateFetching: jest.fn(() => false),
  isArrangementDetailsError: jest.fn(() => false),
  isArrangementDetailsFetching: jest.fn(() => false),
  isSchemeEligibilitiesError: jest.fn(() => false),
  isSchemeEligibilitiesFetching: jest.fn(() => false),
  isBsbLookupError: jest.fn(() => false),
  isDivisionListFetching: jest.fn(() => false),
  isDivisionListError: jest.fn(() => false),
  getAllDivisionList: jest.fn(() => []),
  isAccountNameCheckFetching: jest.fn(() => false),
  isAccountNameCheckError: jest.fn(() => false),
  getAllAccountNameCheck: jest.fn(() => []),
}));

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalSelector: () => {},
}));

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useClose: () => ({
    closeTab: jest.fn(),
  }),
  usePlatformState: jest.fn(),
  useIsCompositeDesktop: jest.fn(),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  isStaffPortal: jest.fn(() => false),
  convertSydneyLocalTimeToUtc: jest.fn((date: string) =>
    date ? `${date}T00:00:00.000Z` : ''
  ),
  getToday: jest.fn(() => ({
    minus: jest.fn(() => ({
      toFormat: jest.fn(() => '2024-01-01'),
    })),
    toFormat: jest.fn(() => '2024-01-01'),
  })),
}));

// PaymentDetails mock moved below - captures props for callback testing

jest.mock('../../components/PaymentReview', () => ({
  PaymentReview: function MockComponent() {
    return <div data-testid="payment-review">Payment Review</div>;
  },
}));

jest.mock('../../components/PaymentConfirmation', () => ({
  PaymentConfirmation: function MockComponent() {
    return <div data-testid="payment-confirmation">Payment Confirmation</div>;
  },
}));

jest.mock('../../galaxy-common/BannerAlertBox/BannerAlertBox', () => ({
  __esModule: true,
  default: function MockComponent({ children }: { children: React.ReactNode }) {
    return <div data-testid="banner-alert-box">{children}</div>;
  },
}));

jest.mock('../../galaxy-common/utils/DOMUtils', () => ({
  scrollToTop: jest.fn(),
}));

jest.mock('../../common/useGetFromAccountOptions', () => ({
  useGetFromAccountOptions: jest.fn(),
}));

jest.mock('../../hooks/useOrganizationId', () => ({
  useOrganizationId: jest.fn(),
}));

jest.mock('../../store/store', () => ({
  __esModule: true,
  default: {
    dispatch: jest.fn(),
  },
}));

jest.mock('../../components/AccountSection', () => ({
  AccountSection: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div>{children}</div>;
  },
}));

jest.mock('../../components/AccountSection', () => ({
  AccountSection: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div>{children}</div>;
  },
}));

// Capture PaymentDetails props for testing callbacks
let capturedPaymentDetailsProps: any = null;

jest.mock('../../components/PaymentDetails', () => ({
  PaymentDetails: function MockComponent(props: any) {
    capturedPaymentDetailsProps = props;
    return <div data-testid="payment-details">{props.children}</div>;
  },
}));
jest.mock(
  '@mesh-tenant-user-authorisation-policy-decision-engine/components',
  () => ({
    MVDetailSection: function MockComponent({
      children,
    }: {
      children: React.ReactNode;
    }) {
      return <div>{children}</div>;
    },
    MVCard: function MockComponent({
      title,
      children,
    }: {
      title: string;
      children: React.ReactNode;
    }) {
      return (
        <div>
          <h1>{title}</h1>
          {children}
        </div>
      );
    },
    useAuthoriser: jest.fn(),
    Resources: {
      ACCOUNTS: 'ACCOUNTS',
    },
    Actions: {
      INITIATE_PAYMENT: 'INITIATE_PAYMENT',
    },
  })
);

const mockGlobalDispatch = jest.fn();
jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalSelector: () => {},
  useGlobalDispatch: () => mockGlobalDispatch,
  // useOrganizationId relies on isLocalUrl; stub it for tests
  isLocalUrl: jest.fn(() => false),
}));

(usePlatformState as jest.Mock).mockReturnValue([
  { id: '12345678977' },
  jest.fn(),
]);
(useIsCompositeDesktop as jest.Mock).mockReturnValue(true);

const mockPayment: Payment = {
  id: 'string',
  creationDateTime: '2024-02-12T03:24:18.680Z',
  groupInformation: {
    groupStatus: 'string',
    originalControlSum: 'string',
    originalCreationDateTime: '2024-02-12T03:24:18.680Z',
    originalNumberOfTransactions: 'string',
  },
  groupStatusReasonInformation: [
    {
      reason: 'string',
      additionalInformation: 'string',
    },
  ],
  paymentInformation: {
    paymentInformationStatus: 'string',
    paymentId: 'string',
  },
  paymentStatusReasonInformation: [
    {
      reason: 'string',
      additionalInformation: 'string',
    },
  ],
  transactionInformation: [
    {
      transactionStatus: 'string',
      statusReasonInformation: [
        {
          reason: 'string',
          additionalInformation: 'string',
        },
      ],
    },
  ],
};

const mockGetPaymentId = jest.fn().mockReturnValue('WP123456');

const defaultProps: MakePaymentContainerProps = {
  paymentCreate: jest.fn(),
  paymentCreateForNewBeneficiary: jest.fn(),
  clearPaymentCreate: jest.fn(),
  clearPaymentCreateForNewBeneficiary: jest.fn(),
  isPaymentCreateFetching: false,
  isPaymentCreateError: false,
  payment: mockPayment,
  apiStatus: undefined,
  beneficiaries: [],
  retrieveBeneficiaries: jest.fn(),
  getAccountListByStatus: jest.fn(),
  allAccountList: [],
  isBeneficiariesFetching: false,
  isAccountListFetching: false,
  isAliasLookupFetching: false,
  isBeneficiariesError: false,
  isAccountListError: false,
  aliasLookupData: [],
  aliasLookupByBeneIdData: [],
  doesAliasIdContainInvalidData: false,
  isPayIdNotValid: false,
  postAliasLookup: jest.fn(),
  postAliasLookupByBeneId: jest.fn(),
  clearPostAliasLookup: jest.fn(),
  clearPostAliasLookupByBeneId: jest.fn(),
  // BSB lookup related props added for new beneficiary flows
  getBsbLookup: jest.fn(),
  clearBsbLookup: jest.fn(),
  bsbLookupData: [],
  isBsbLookupFetching: false,
  isBsbLookupError: false,
  bsbLookupErrorStatusCode: undefined,
  getPaymentId: jest.fn(),
  paymentId: mockGetPaymentId(),
  allSchemeEligibilities: [],
  isSchemeEligibilitiesFetching: false,
  isSchemeEligibilitiesError: false,
  postArrangementDetails: jest.fn(),
  isArrangementDetailsFetching: false,
  allArrangementDetails: [],
  addBeneficiary: jest.fn(),
  isPaymentCreateForNewBeneficiaryFetching: false,
  isPaymentCreateForNewBeneficiaryError: false,
  isAliasLookupError: false,
  isArrangementDetailsError: false,
  getDivisionList: jest.fn(),
  isDivisionListFetching: false,
  isDivisionListError: false,
  allDivisionList: [],
  clearPaymentIdentifier: jest.fn(),
  isPaymentIdentifierFetching: false,
  isPaymentIdentifierError: false,
  paymentIdentifierApiStatus: undefined,
  paymentIdentifierErrors: undefined,
  isBeneficiaryCreateFetching: false,
  isPayIdLimitExceeded: false,
  isPayIdServiceNotAvailable: false,
  postPaymentErrors: undefined,
  postNewBeneficiaryPaymentCreateStatusCode: undefined,
  postPaymentCreateForNewBeneficiaryErrors: undefined,
  postAddBeneficiaryStatusCode: undefined,
  postAddBeneficiaryErrors: undefined,
  allSchemeEligibilityErrors: undefined,
  fetchSchemeEligibilities: jest.fn(),
  // CoP (Check Details) props
  postAccountNameCheck: jest.fn(),
  accountNameCheckData: [],
  isAccountNameCheckFetching: false,
  isAccountNameCheckError: false,
  clearAccountNameCheck: jest.fn(),
  isCopLimitExceeded: false,
  isCopServiceNotAvailable: false,
  paymentForNewBeneficiary: mockPayment,
  isBeneficiaryCreateError: false,
};

describe('Testing MakePaymentContainer', () => {
  beforeEach(() => {
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: true });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      defaultFromAccount: null,
      fromAccountOptions: [],
    });
    (useOrganizationId as jest.Mock).mockReturnValue('ORG123');
  });
  it('should match snapshot', () => {
    const { container } = render(<MakePaymentContainer {...defaultProps} />);
    expect(container).toMatchSnapshot();
  });
});

describe('Testing error scenario', () => {
  beforeEach(() => {
    jest.resetAllMocks();
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: false });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      defaultFromAccount: null,
      fromAccountOptions: [],
    });
    (useOrganizationId as jest.Mock).mockReturnValue('ORG123');
    (usePlatformState as jest.Mock).mockReturnValue([
      { id: '12345678977' },
      jest.fn(),
    ]);
  });

  it('Should show the error in the page', () => {
    const { getByText } = render(<MakePaymentContainer {...defaultProps} />);

    expect(
      getByText(
        'You do not have permission to access this page. Contact your Administrator for more information.'
      )
    ).toBeInTheDocument();
  });
});
describe('getAccountList', () => {
  beforeEach(() => {
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: true });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      defaultFromAccount: null,
      fromAccountOptions: [],
    });
  });

  it('should call getAccountListByStatus with correct params and headers including protected-orgId', () => {
    const mockGetAccountListByStatus = jest.fn();

    // Mock useOrganizationId to return orgId
    (useOrganizationId as jest.Mock).mockReturnValue('ORG123');

    render(
      <MakePaymentContainer
        {...defaultProps}
        getAccountListByStatus={mockGetAccountListByStatus}
        isAccountListFetching={false} // Ensure not fetching so API call is made
      />
    );

    // getAccountList is called on mount (useEffect)
    expect(mockGetAccountListByStatus).toHaveBeenCalledTimes(1);
    const [params, options] = mockGetAccountListByStatus.mock.calls[0];

    expect(params).toMatchObject({
      pdpQueryAction: expect.any(String),
      accountStatus: 'ACTIVE',
      meta: { replaceEntities: ['accountList'] },
    });
    expect(options).toMatchObject({
      headers: { 'protected-orgId': 'ORG123' },
    });
  });
});
describe('getActiveBeneficiaries', () => {
  beforeEach(() => {
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: true });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      defaultFromAccount: null,
      fromAccountOptions: [],
    });
  });

  it('should call retrieveBeneficiaries with correct params and headers including protected-orgId', () => {
    const mockRetrieveBeneficiaries = jest.fn();

    // Mock useOrganizationId to return orgId
    (useOrganizationId as jest.Mock).mockReturnValue('ORG123');

    render(
      <MakePaymentContainer
        {...defaultProps}
        retrieveBeneficiaries={mockRetrieveBeneficiaries}
        isBeneficiariesFetching={false} // Ensure not fetching so API call is made
      />
    );

    // getActiveBeneficiaries is called on mount (useEffect)
    expect(mockRetrieveBeneficiaries).toHaveBeenCalledTimes(1);
    const [params, options] = mockRetrieveBeneficiaries.mock.calls[0];
    expect(params).toMatchObject({ params: { statuses: ['ACTIVE'] } });
    expect(options).toMatchObject({
      headers: { 'protected-orgId': 'ORG123' },
    });
  });
});

describe('protected-orgId header logic', () => {
  beforeEach(() => {
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: true });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      defaultFromAccount: null,
      fromAccountOptions: [],
    });
  });

  describe('when useOrganizationId returns a value', () => {
    beforeEach(() => {
      (useOrganizationId as jest.Mock).mockReturnValue('12345678910');
    });

    describe('getAccountListByStatus', () => {
      it('should use orgId for protected-orgId header', () => {
        const mockGetArrangementsByStatus = jest.fn();

        render(
          <MakePaymentContainer
            {...defaultProps}
            getAccountListByStatus={mockGetArrangementsByStatus}
            isAccountListFetching={false}
          />
        );

        expect(mockGetArrangementsByStatus).toHaveBeenCalledTimes(1);
        const [, options] = mockGetArrangementsByStatus.mock.calls[0];
        expect(options).toMatchObject({
          headers: { 'protected-orgId': '12345678910' },
        });
      });
    });

    describe('retrieveBeneficiaries', () => {
      it('should use orgId for protected-orgId header', () => {
        const mockRetrieveBeneficiaries = jest.fn();

        render(
          <MakePaymentContainer
            {...defaultProps}
            retrieveBeneficiaries={mockRetrieveBeneficiaries}
            isBeneficiariesFetching={false}
          />
        );

        expect(mockRetrieveBeneficiaries).toHaveBeenCalledTimes(1);
        const [, options] = mockRetrieveBeneficiaries.mock.calls[0];
        expect(options).toMatchObject({
          headers: { 'protected-orgId': '12345678910' },
        });
      });
    });
  });
});

describe('Division List Functionality', () => {
  const mockIsStaffPortal =
    require('@mesh-tenant-multiverse-ui-common/mv-utils').isStaffPortal;

  beforeEach(() => {
    jest.clearAllMocks();
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: true });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      defaultFromAccount: null,
      fromAccountOptions: [],
    });
    (useOrganizationId as jest.Mock).mockReturnValue('12345678910');
    (useIsCompositeDesktop as jest.Mock).mockReturnValue(false);
    mockIsStaffPortal.mockReturnValue(false);
  });

  describe('fetchDivisionList', () => {
    it('should call getDivisionList with correct params and headers including protected-orgId', () => {
      const mockGetDivisionList = jest.fn();
      (useOrganizationId as jest.Mock).mockReturnValue('12345678910');

      render(
        <MakePaymentContainer
          {...defaultProps}
          getDivisionList={mockGetDivisionList}
          isDivisionListFetching={false}
        />
      );

      // getDivisionList is called on mount (useEffect)
      expect(mockGetDivisionList).toHaveBeenCalledTimes(1);
      const [params, options] = mockGetDivisionList.mock.calls[0];

      expect(params).toMatchObject({
        pdpQueryAction: expect.any(String),
        meta: { replaceEntities: ['divisionList'] },
      });
      expect(options).toMatchObject({
        headers: { 'protected-orgId': '12345678910' },
      });
    });

    it('should not call getDivisionList when already fetching', () => {
      const mockGetDivisionList = jest.fn();

      render(
        <MakePaymentContainer
          {...defaultProps}
          getDivisionList={mockGetDivisionList}
          isDivisionListFetching={true}
        />
      );

      expect(mockGetDivisionList).not.toHaveBeenCalled();
    });
  });

  describe('isStaffPortal behavior', () => {
    it('should not call fetchDivisionList when isStaffPortal returns true and directly call account/beneficiary APIs', () => {
      mockIsStaffPortal.mockReturnValue(true);
      const mockGetDivisionList = jest.fn();
      const mockGetAccountListByStatus = jest.fn();
      const mockRetrieveBeneficiaries = jest.fn();

      render(
        <MakePaymentContainer
          {...defaultProps}
          getDivisionList={mockGetDivisionList}
          getAccountListByStatus={mockGetAccountListByStatus}
          retrieveBeneficiaries={mockRetrieveBeneficiaries}
          isDivisionListFetching={false}
          isAccountListFetching={false}
          isBeneficiariesFetching={false}
        />
      );

      // When isStaffPortal is true, hasDivisionListBeenFetched is initialized to false
      // so division list won't be fetched in the first useEffect
      expect(mockGetDivisionList).not.toHaveBeenCalled();

      // Account list and beneficiaries should still be called
      // This happens because hasDivisionListBeenFetched is false initially
      expect(mockGetAccountListByStatus).toHaveBeenCalled();
      expect(mockRetrieveBeneficiaries).toHaveBeenCalled();
    });

    it('should call fetchDivisionList when isStaffPortal returns false', () => {
      mockIsStaffPortal.mockReturnValue(false);
      const mockGetDivisionList = jest.fn();

      render(
        <MakePaymentContainer
          {...defaultProps}
          getDivisionList={mockGetDivisionList}
          isDivisionListFetching={false}
        />
      );

      expect(mockGetDivisionList).toHaveBeenCalledTimes(1);
    });
  });

  describe('when division list is empty', () => {
    it('should call getAccountList and getActiveBeneficiaries after division list fetch completes with empty result', () => {
      const mockGetAccountListByStatus = jest.fn();
      const mockRetrieveBeneficiaries = jest.fn();
      const mockGetDivisionList = jest.fn();

      render(
        <MakePaymentContainer
          {...defaultProps}
          getDivisionList={mockGetDivisionList}
          getAccountListByStatus={mockGetAccountListByStatus}
          retrieveBeneficiaries={mockRetrieveBeneficiaries}
          isDivisionListFetching={false}
          isAccountListFetching={false}
          isBeneficiariesFetching={false}
          allDivisionList={[]}
        />
      );

      expect(mockGetDivisionList).toHaveBeenCalled();
      expect(mockGetAccountListByStatus).toHaveBeenCalled();
      expect(mockRetrieveBeneficiaries).toHaveBeenCalled();
    });
  });

  describe('when division list has items', () => {
    it('should not call getAccountList and getActiveBeneficiaries automatically when divisions exist', () => {
      const mockGetAccountListByStatus = jest.fn();
      const mockRetrieveBeneficiaries = jest.fn();
      const mockGetDivisionList = jest.fn();

      const divisionList = [
        { divisionId: 'DIV1', divisionName: 'Division 1' },
        { divisionId: 'DIV2', divisionName: 'Division 2' },
      ];

      render(
        <MakePaymentContainer
          {...defaultProps}
          getDivisionList={mockGetDivisionList}
          getAccountListByStatus={mockGetAccountListByStatus}
          retrieveBeneficiaries={mockRetrieveBeneficiaries}
          isDivisionListFetching={false}
          isAccountListFetching={false}
          isBeneficiariesFetching={false}
          allDivisionList={divisionList}
        />
      );

      expect(mockGetDivisionList).toHaveBeenCalled();
      // Should not automatically call these when divisions exist
      // They should only be called when a division is selected
    });
  });
});

describe('Division Selection', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: true });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      defaultFromAccount: null,
      fromAccountOptions: [],
    });
    (useOrganizationId as jest.Mock).mockReturnValue('ORG123');
  });

  it('should call getAccountList and getActiveBeneficiaries with divisionId when division is selected', () => {
    const mockGetAccountListByStatus = jest.fn();
    const mockRetrieveBeneficiaries = jest.fn();

    render(
      <MakePaymentContainer
        {...defaultProps}
        getAccountListByStatus={mockGetAccountListByStatus}
        retrieveBeneficiaries={mockRetrieveBeneficiaries}
        isDivisionListFetching={false}
        isAccountListFetching={false}
        isBeneficiariesFetching={false}
      />
    );

    // Note: Testing division selection would require triggering the onSelectDivision callback
    // which is passed to the PaymentDetails component. This is tested indirectly through
    // integration tests or by mocking the PaymentDetails component to expose the callback.
    expect(mockGetAccountListByStatus).toHaveBeenCalled();
  });
});

describe('getShouldFetchData logic', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: true });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      defaultFromAccount: null,
      fromAccountOptions: [],
    });
  });

  it('should fetch data when not in composite desktop', () => {
    (useIsCompositeDesktop as jest.Mock).mockReturnValue(false);
    (useOrganizationId as jest.Mock).mockReturnValue(undefined);
    const mockGetDivisionList = jest.fn();

    render(
      <MakePaymentContainer
        {...defaultProps}
        getDivisionList={mockGetDivisionList}
        isDivisionListFetching={false}
      />
    );

    expect(mockGetDivisionList).toHaveBeenCalled();
  });

  it('should fetch data when in composite desktop and orgId is available', () => {
    (useIsCompositeDesktop as jest.Mock).mockReturnValue(true);
    (useOrganizationId as jest.Mock).mockReturnValue('12345678910');
    const mockGetDivisionList = jest.fn();

    render(
      <MakePaymentContainer
        {...defaultProps}
        getDivisionList={mockGetDivisionList}
        isDivisionListFetching={false}
      />
    );

    expect(mockGetDivisionList).toHaveBeenCalled();
  });
});

describe('hasDivisionListBeenFetched initialization', () => {
  const mockIsStaffPortal =
    require('@mesh-tenant-multiverse-ui-common/mv-utils').isStaffPortal;

  beforeEach(() => {
    jest.clearAllMocks();
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: true });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      defaultFromAccount: null,
      fromAccountOptions: [],
    });
    (useOrganizationId as jest.Mock).mockReturnValue('12345678910');
    (useIsCompositeDesktop as jest.Mock).mockReturnValue(false);
  });

  it('should initialize hasDivisionListBeenFetched to false when isStaffPortal is true', () => {
    mockIsStaffPortal.mockReturnValue(true);
    const mockGetDivisionList = jest.fn();

    render(
      <MakePaymentContainer
        {...defaultProps}
        getDivisionList={mockGetDivisionList}
        isDivisionListFetching={false}
      />
    );

    // When isStaffPortal is true, hasDivisionListBeenFetched is initialized to false (!isStaffPortal())
    // So division list fetch will NOT be triggered in the first useEffect
    expect(mockGetDivisionList).not.toHaveBeenCalled();
  });

  it('should fetch division list when isStaffPortal is false', () => {
    mockIsStaffPortal.mockReturnValue(false);
    const mockGetDivisionList = jest.fn();

    render(
      <MakePaymentContainer
        {...defaultProps}
        getDivisionList={mockGetDivisionList}
        isDivisionListFetching={false}
      />
    );

    expect(mockGetDivisionList).toHaveBeenCalled();
  });
});

describe('showDivisionField logic', () => {
  const mockIsStaffPortal =
    require('@mesh-tenant-multiverse-ui-common/mv-utils').isStaffPortal;

  beforeEach(() => {
    jest.clearAllMocks();
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: true });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      defaultFromAccount: null,
      fromAccountOptions: [],
    });
    (useOrganizationId as jest.Mock).mockReturnValue('12345678910');
  });

  it('should not show division field when isStaffPortal is true', () => {
    mockIsStaffPortal.mockReturnValue(true);

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isDivisionListFetching={false}
        allDivisionList={[{ divisionId: 'DIV1', divisionName: 'Division 1' }]}
      />
    );

    // The component passes showDivisionField to PaymentDetails
    // which should be false when isStaffPortal is true
    expect(container).toBeTruthy();
  });

  it('should not show division field when division list is empty', () => {
    mockIsStaffPortal.mockReturnValue(false);

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isDivisionListFetching={false}
        allDivisionList={[]}
      />
    );

    expect(container).toBeTruthy();
  });

  it('should not show division field when division list is fetching', () => {
    mockIsStaffPortal.mockReturnValue(false);

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isDivisionListFetching={true}
        allDivisionList={[{ divisionId: 'DIV1', divisionName: 'Division 1' }]}
      />
    );

    expect(container).toBeTruthy();
  });

  it('should show division field when not staff portal, not fetching, and has divisions', () => {
    mockIsStaffPortal.mockReturnValue(false);

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isDivisionListFetching={false}
        allDivisionList={[{ divisionId: 'DIV1', divisionName: 'Division 1' }]}
      />
    );

    expect(container).toBeTruthy();
  });
});

describe('Check Details (CoP) functionality', () => {
  const mockIsStaffPortal =
    require('@mesh-tenant-multiverse-ui-common/mv-utils').isStaffPortal;

  beforeEach(() => {
    jest.clearAllMocks();
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: true });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      defaultFromAccount: null,
      fromAccountOptions: [],
    });
    (useOrganizationId as jest.Mock).mockReturnValue('ORG123');
    (usePlatformState as jest.Mock).mockReturnValue([
      { id: '12345678977' },
      jest.fn(),
    ]);
    (useIsCompositeDesktop as jest.Mock).mockReturnValue(true);
    mockIsStaffPortal.mockReturnValue(false);
  });

  it('should render with CoP props when not fetching and no errors', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={[]}
        isCopLimitExceeded={false}
        isCopServiceNotAvailable={false}
      />
    );

    expect(container).toBeTruthy();
  });

  it('should render with CoP loading state', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={true}
        isAccountNameCheckError={false}
        accountNameCheckData={[]}
      />
    );

    expect(container).toBeTruthy();
  });

  it('should render with CoP error state', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={true}
        accountNameCheckData={[]}
      />
    );

    expect(container).toBeTruthy();
  });

  it('should render with CoP limit exceeded state', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        isCopLimitExceeded={true}
        accountNameCheckData={[]}
      />
    );

    expect(container).toBeTruthy();
  });

  it('should render with CoP service not available state', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        isCopServiceNotAvailable={true}
        accountNameCheckData={[]}
      />
    );

    expect(container).toBeTruthy();
  });

  it('should render with successful CoP match result (Blue)', () => {
    const mockAccountNameCheckData = [
      {
        id: '1',
        matchedAccountName: 'John Smith',
        matchedStatusCOPCode: 'MTCH',
        matchedColor: 'Blue' as const,
      },
    ];

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={mockAccountNameCheckData}
      />
    );

    expect(container).toBeTruthy();
  });

  it('should render with CoP close match result (Amber)', () => {
    const mockAccountNameCheckData = [
      {
        id: '1',
        matchedAccountName: 'J Smith',
        matchedStatusCOPCode: 'MBAM',
        matchedColor: 'Amber' as const,
      },
    ];

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={mockAccountNameCheckData}
      />
    );

    expect(container).toBeTruthy();
  });

  it('should render with CoP no match result (Red)', () => {
    const mockAccountNameCheckData = [
      {
        id: '1',
        matchedAccountName: 'Different Name',
        matchedStatusCOPCode: 'NMTC',
        matchedColor: 'Red' as const,
      },
    ];

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={mockAccountNameCheckData}
      />
    );

    expect(container).toBeTruthy();
  });

  it('should not show CoP features for staff portal users', () => {
    mockIsStaffPortal.mockReturnValue(true);

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={[]}
      />
    );

    expect(container).toBeTruthy();
  });

  it('should handle accountNameCheckData with missing matchedColor (copCheckResultData is undefined)', () => {
    const mockAccountNameCheckData = [
      {
        id: '1',
        matchedAccountName: 'John Smith',
        matchedStatusCOPCode: 'MTCH',
        // matchedColor is intentionally omitted — copCheckResultData should be undefined
      },
    ];

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={mockAccountNameCheckData}
      />
    );

    expect(container).toBeTruthy();
  });

  it('should handle accountNameCheckData with missing matchedAccountName (fallback to empty string)', () => {
    const mockAccountNameCheckData = [
      {
        id: '1',
        // matchedAccountName is intentionally omitted to test fallback
        matchedStatusCOPCode: 'MTCH',
        matchedColor: 'Blue' as const,
      },
    ];

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={mockAccountNameCheckData}
      />
    );

    expect(container).toBeTruthy();
  });

  it('should handle accountNameCheckData with missing matchedStatusCOPCode (fallback to empty string)', () => {
    const mockAccountNameCheckData = [
      {
        id: '1',
        matchedAccountName: 'John Smith',
        // matchedStatusCOPCode is intentionally omitted to test fallback
        matchedColor: 'Blue' as const,
      },
    ];

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={mockAccountNameCheckData}
      />
    );

    expect(container).toBeTruthy();
  });

  it('should handle accountNameCheckData with all fields missing (all fallbacks)', () => {
    const mockAccountNameCheckData = [
      {
        id: '1',
        // All optional fields intentionally omitted to test all fallbacks
      },
    ];

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={mockAccountNameCheckData}
      />
    );

    expect(container).toBeTruthy();
  });
});

// Tests for aliasLookupStatus states
describe('MakePaymentContainer aliasLookupStatus states', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    (useAuthoriser as jest.Mock).mockReturnValue({
      isAuthorised: () => true,
    });
    (useOrganizationId as jest.Mock).mockReturnValue('org-123');
    (useIsCompositeDesktop as jest.Mock).mockReturnValue(false);
    (usePlatformState as jest.Mock).mockReturnValue({
      activeAppId: 'app-123',
    });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      options: [],
      selectedOption: null,
    });
  });

  it('should set aliasLookupStatus to fetching when isAliasLookupFetching is true', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAliasLookupFetching={true}
        isAliasLookupError={false}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should set aliasLookupStatus to fetching when isAliasLookupByBeneIdFetching is true', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAliasLookupByBeneIdFetching={true}
        isAliasLookupByBeneIdError={false}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should set aliasLookupStatus to error when isAliasLookupByBeneIdError is true', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAliasLookupByBeneIdFetching={false}
        isAliasLookupByBeneIdError={true}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should set aliasLookupStatus to verified when aliasLookupData has data', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        aliasLookupData={[{ name: 'Test Name' }]}
        isAliasLookupFetching={false}
        isAliasLookupError={false}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should set aliasLookupStatus to verified when aliasLookupByBeneIdData has data', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        aliasLookupByBeneIdData={[{ name: 'Test Name' }]}
        isAliasLookupByBeneIdFetching={false}
        isAliasLookupByBeneIdError={false}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should set aliasLookupStatus to not-verified when no data and not fetching', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        aliasLookupData={[]}
        aliasLookupByBeneIdData={[]}
        isAliasLookupFetching={false}
        isAliasLookupError={false}
        isAliasLookupByBeneIdFetching={false}
        isAliasLookupByBeneIdError={false}
      />
    );
    expect(container).toBeTruthy();
  });
});

// Tests for composite desktop scenarios
describe('MakePaymentContainer composite desktop', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    (useAuthoriser as jest.Mock).mockReturnValue({
      isAuthorised: () => true,
    });
    (usePlatformState as jest.Mock).mockReturnValue({
      activeAppId: 'app-123',
    });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      options: [],
      selectedOption: null,
    });
  });

  it('should handle composite desktop with orgId', () => {
    (useIsCompositeDesktop as jest.Mock).mockReturnValue(true);
    (useOrganizationId as jest.Mock).mockReturnValue('org-123');

    const { container } = render(<MakePaymentContainer {...defaultProps} />);
    expect(container).toBeTruthy();
  });

  it('should handle composite desktop without orgId', () => {
    (useIsCompositeDesktop as jest.Mock).mockReturnValue(true);
    (useOrganizationId as jest.Mock).mockReturnValue(undefined);

    const { container } = render(<MakePaymentContainer {...defaultProps} />);
    expect(container).toBeTruthy();
  });

  it('should handle non-composite desktop', () => {
    (useIsCompositeDesktop as jest.Mock).mockReturnValue(false);
    (useOrganizationId as jest.Mock).mockReturnValue(undefined);

    const { container } = render(<MakePaymentContainer {...defaultProps} />);
    expect(container).toBeTruthy();
  });
});

// Tests for payment create flow
describe('MakePaymentContainer payment create flow', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    (useAuthoriser as jest.Mock).mockReturnValue({
      isAuthorised: () => true,
    });
    (useOrganizationId as jest.Mock).mockReturnValue('org-123');
    (useIsCompositeDesktop as jest.Mock).mockReturnValue(false);
    (usePlatformState as jest.Mock).mockReturnValue({
      activeAppId: 'app-123',
    });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      options: [],
      selectedOption: null,
    });
  });

  it('should handle payment create for new beneficiary fetching state', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isPaymentCreateForNewBeneficiaryFetching={true}
        isPaymentCreateForNewBeneficiaryError={false}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should handle payment create for new beneficiary error state', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isPaymentCreateForNewBeneficiaryFetching={false}
        isPaymentCreateForNewBeneficiaryError={true}
        postPaymentCreateForNewBeneficiaryErrors={['Error creating payment']}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should handle payment create with status code', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        postNewBeneficiaryPaymentCreateStatusCode={201}
        isPaymentCreateForNewBeneficiaryFetching={false}
        isPaymentCreateForNewBeneficiaryError={false}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should handle payment for new beneficiary data', () => {
    const mockPayment: Payment = {
      id: 'payment-123',
      status: 'completed',
    };
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        paymentForNewBeneficiary={mockPayment}
        isPaymentCreateForNewBeneficiaryFetching={false}
        isPaymentCreateForNewBeneficiaryError={false}
      />
    );
    expect(container).toBeTruthy();
  });
});

// Tests for Account Name Check (CoP) API integration
describe('MakePaymentContainer Account Name Check API', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    (useAuthoriser as jest.Mock).mockReturnValue({
      isAuthorised: () => true,
    });
    (useOrganizationId as jest.Mock).mockReturnValue('org-123');
    (useIsCompositeDesktop as jest.Mock).mockReturnValue(false);
    (usePlatformState as jest.Mock).mockReturnValue({
      activeAppId: 'app-123',
    });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      options: [],
      selectedOption: null,
    });
  });

  it('should render with CoP loading state', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={true}
        isAccountNameCheckError={false}
        accountNameCheckData={[]}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should render with CoP error state', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={true}
        accountNameCheckData={[]}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should render with CoP limit exceeded', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        isCopLimitExceeded={true}
        accountNameCheckData={[]}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should render with CoP service not available', () => {
    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        isCopServiceNotAvailable={true}
        accountNameCheckData={[]}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should render with successful Blue CoP result', () => {
    const mockAccountNameCheckData = [
      {
        id: '1',
        matchedAccountName: 'John Smith',
        matchedStatusCOPCode: 'V0C1',
        matchedColor: 'Blue' as const,
      },
    ];

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={mockAccountNameCheckData}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should render with Amber CoP result (close match)', () => {
    const mockAccountNameCheckData = [
      {
        id: '1',
        matchedAccountName: 'J Smith',
        matchedStatusCOPCode: 'V1C3',
        matchedColor: 'Amber' as const,
      },
    ];

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={mockAccountNameCheckData}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should render with Red CoP result (closed account)', () => {
    const mockAccountNameCheckData = [
      {
        id: '1',
        matchedAccountName: 'Closed Account',
        matchedStatusCOPCode: 'V0C7',
        matchedColor: 'Red' as const,
      },
    ];

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={mockAccountNameCheckData}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should call postAccountNameCheck when provided', () => {
    const mockPostAccountNameCheck = jest.fn();
    const mockClearAccountNameCheck = jest.fn();

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        postAccountNameCheck={mockPostAccountNameCheck}
        clearAccountNameCheck={mockClearAccountNameCheck}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={[]}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should handle transition from loading to successful result', () => {
    const { rerender, container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={true}
        isAccountNameCheckError={false}
        accountNameCheckData={[]}
      />
    );

    // Simulate result arriving
    const mockResult = [
      {
        id: '1',
        matchedAccountName: 'John Smith',
        matchedStatusCOPCode: 'V0C1',
        matchedColor: 'Blue' as const,
      },
    ];

    rerender(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={mockResult}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should handle transition from loading to error', () => {
    const { rerender, container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={true}
        isAccountNameCheckError={false}
        accountNameCheckData={[]}
      />
    );

    rerender(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={true}
        accountNameCheckData={[]}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should handle all closed account status codes (V1C7)', () => {
    const mockAccountNameCheckData = [
      {
        id: '1',
        matchedAccountName: 'Closed',
        matchedStatusCOPCode: 'V1C7',
        matchedColor: 'Red' as const,
      },
    ];

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={mockAccountNameCheckData}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should handle all closed account status codes (V2C7)', () => {
    const mockAccountNameCheckData = [
      {
        id: '1',
        matchedAccountName: 'Closed',
        matchedStatusCOPCode: 'V2C7',
        matchedColor: 'Red' as const,
      },
    ];

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={mockAccountNameCheckData}
      />
    );
    expect(container).toBeTruthy();
  });

  it('should handle all closed account status codes (VAC7)', () => {
    const mockAccountNameCheckData = [
      {
        id: '1',
        matchedAccountName: 'Closed',
        matchedStatusCOPCode: 'VAC7',
        matchedColor: 'Red' as const,
      },
    ];

    const { container } = render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        accountNameCheckData={mockAccountNameCheckData}
      />
    );
    expect(container).toBeTruthy();
  });
});

// Tests for handlePostAccountNameCheck callback execution
describe('MakePaymentContainer handlePostAccountNameCheck callback', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    capturedPaymentDetailsProps = null;
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: true });
    (useOrganizationId as jest.Mock).mockReturnValue('org-123');
    (useIsCompositeDesktop as jest.Mock).mockReturnValue(false);
    (usePlatformState as jest.Mock).mockReturnValue({
      activeAppId: 'app-123',
    });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      defaultFromAccount: null,
      fromAccountOptions: [],
    });
  });

  it('should pass postAccountNameCheck callback to PaymentDetails', () => {
    render(<MakePaymentContainer {...defaultProps} />);

    expect(capturedPaymentDetailsProps).toBeTruthy();
    expect(capturedPaymentDetailsProps.postAccountNameCheck).toBeDefined();
    expect(typeof capturedPaymentDetailsProps.postAccountNameCheck).toBe(
      'function'
    );
  });

  it('should invoke postAccountNameCheck when callback is called', () => {
    const mockPostAccountNameCheck = jest.fn();
    const mockClearAccountNameCheck = jest.fn();

    render(
      <MakePaymentContainer
        {...defaultProps}
        postAccountNameCheck={mockPostAccountNameCheck}
        clearAccountNameCheck={mockClearAccountNameCheck}
      />
    );

    expect(capturedPaymentDetailsProps).toBeTruthy();
    expect(capturedPaymentDetailsProps.postAccountNameCheck).toBeDefined();

    // Invoke the callback
    capturedPaymentDetailsProps.postAccountNameCheck({
      accountName: 'John Smith',
      accountNumber: '12345678',
      bsb: '123456',
    });

    // Verify clearAccountNameCheck was called first
    expect(mockClearAccountNameCheck).toHaveBeenCalledTimes(1);

    // Verify postAccountNameCheck was called with transformed params
    expect(mockPostAccountNameCheck).toHaveBeenCalledTimes(1);
    expect(mockPostAccountNameCheck).toHaveBeenCalledWith({
      params: {
        payee: {
          accountName: 'John Smith',
          accountId: {
            accountNumber: '12345678',
            BSB: '123456',
          },
        },
      },
    });
  });

  it('should set shouldShowCopResults to true when callback is invoked', () => {
    const mockPostAccountNameCheck = jest.fn();
    const mockClearAccountNameCheck = jest.fn();

    render(
      <MakePaymentContainer
        {...defaultProps}
        postAccountNameCheck={mockPostAccountNameCheck}
        clearAccountNameCheck={mockClearAccountNameCheck}
      />
    );

    // Initially shouldShowCopResults should be passed as false (or component's initial state)
    const initialShouldShowCopResults =
      capturedPaymentDetailsProps.shouldShowCopResults;

    // Invoke the callback
    capturedPaymentDetailsProps.postAccountNameCheck({
      accountName: 'Jane Doe',
      accountNumber: '87654321',
      bsb: '654321',
    });

    // Re-render would show shouldShowCopResults as true, but we can verify the callback was invoked
    expect(mockClearAccountNameCheck).toHaveBeenCalled();
    expect(mockPostAccountNameCheck).toHaveBeenCalled();
  });

  it('should pass copCheckResultData to PaymentDetails when accountNameCheckData is available', () => {
    const mockAccountNameCheckData = [
      {
        id: '1',
        matchedAccountName: 'John Smith',
        matchedStatusCOPCode: 'V0C1',
        matchedColor: 'Blue' as const,
      },
    ];

    render(
      <MakePaymentContainer
        {...defaultProps}
        accountNameCheckData={mockAccountNameCheckData}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
      />
    );

    expect(capturedPaymentDetailsProps.copCheckResultData).toBeDefined();
    expect(
      capturedPaymentDetailsProps.copCheckResultData.matchedAccountName
    ).toBe('John Smith');
    expect(
      capturedPaymentDetailsProps.copCheckResultData.matchedStatusCOPCode
    ).toBe('V0C1');
    expect(capturedPaymentDetailsProps.copCheckResultData.matchedColor).toBe(
      'Blue'
    );
  });

  it('should pass undefined copCheckResultData when accountNameCheckData is empty', () => {
    render(
      <MakePaymentContainer
        {...defaultProps}
        accountNameCheckData={[]}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
      />
    );

    expect(capturedPaymentDetailsProps.copCheckResultData).toBeUndefined();
  });

  it('should pass isCopLoading true when isAccountNameCheckFetching is true', () => {
    render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={true}
        isAccountNameCheckError={false}
      />
    );

    expect(capturedPaymentDetailsProps.isCopLoading).toBe(true);
  });

  it('should pass isCopError true when isAccountNameCheckError is true', () => {
    render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={true}
      />
    );

    expect(capturedPaymentDetailsProps.isCopError).toBe(true);
  });

  it('should pass isCopError true when isCopServiceNotAvailable is true', () => {
    render(
      <MakePaymentContainer
        {...defaultProps}
        isAccountNameCheckFetching={false}
        isAccountNameCheckError={false}
        isCopServiceNotAvailable={true}
      />
    );

    expect(capturedPaymentDetailsProps.isCopError).toBe(true);
  });

  it('should pass isCopLimitExceeded to PaymentDetails', () => {
    render(
      <MakePaymentContainer {...defaultProps} isCopLimitExceeded={true} />
    );

    expect(capturedPaymentDetailsProps.isCopLimitExceeded).toBe(true);
  });
});
