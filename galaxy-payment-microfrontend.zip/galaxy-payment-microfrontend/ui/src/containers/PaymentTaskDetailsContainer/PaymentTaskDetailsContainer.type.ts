// for UI purpose
import { WorkFlowStatusMap } from '../../common/constants';
import { PaymentMethodDescription } from '../../common/types';

export type WorkflowAuditDetails = {
  actionedBy: string;
  actionedDateTime: string;
};

/**
 * UI type for payment task details
 */
export type PaymentTaskDetail = {
  id: string;
  amount: {
    amount: string;
    currency: string;
  };
  beneficiary?: {
    name: string;
    nickName: string;
    accountId: string;
  };
  creditAccount?: {
    name: string;
    nickName: string;
    accountId: string;
  };
  creationDateTime: string; // ISO timestamp
  creditorDescription: string | undefined;
  debitAccount: {
    nickName: string;
    accountId: string;
  };
  debitDescription: string;
  paymentMethod: {
    description: PaymentMethodDescription;
  };
  receiptNumber: string;
  reference?: string;
  status: (typeof WorkFlowStatusMap)[keyof typeof WorkFlowStatusMap] | '';
  supplementaryData: {
    isNewPayee?: boolean;
    aliasId: string;
    aliasType: 'TELI' | 'EMAL' | 'AUBN' | 'ORGN' | string;
    instructionTraceIdentification: string;
    divisionId?: string;
    divisionName?: string;
  };
  sentForAuthWorkflowAuditDetails: WorkflowAuditDetails;
  rejectedWorkflowAuditDetails: WorkflowAuditDetails;
};

export type ApprovalAction = 'APPROVED' | 'REJECTED';
