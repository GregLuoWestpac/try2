/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import { compose, connect, useGlobalSelector } from '@mep-ui/framework';
import { MVPageLoader as PageLoader } from '@mesh-tenant-multiverse-ui-common/mv-pageloader';
import { isStaffPortal } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { useClose } from '@mesh-tenant-multiverse-common/react';
import isEmpty from 'lodash/isEmpty';
import uniqueId from 'lodash/uniqueId';
import { FC, useEffect, useState } from 'react';
import {
  ErrorResponse,
  PaymentLimits,
  validatePaymentLimitsResult,
} from '../../common/types';
import { transformApprovalWorkflowToPaymentTaskDetail } from '../../common/utils';
import {
  getAllPaymentLimits,
  getAllValidatePaymentLimits,
  isPaymentLimitsError as isPaymentLimitsErrorSelector,
  isPaymentLimitsFetching as isPaymentLimitsFetchingSelector,
  isValidatePaymentLimitsError as isValidatePaymentLimitsErrorSelector,
  isValidatePaymentLimitsFetching as isValidatePaymentLimitsFetchingSelector,
  paymentLimitsActions,
  paymentLimitsEntityActions,
  validatePaymentLimitsActions,
  validatePaymentLimitsEntityActions,
} from '../../store/generated';
import {
  getPaymentLimitsErrors,
  getPaymentLimitsStatusCode,
} from '../../store/selectors/paymentLimits';
import {
  getValidatePaymentLimitsErrors,
  getValidatePaymentLimitsStatusCode,
} from '../../store/selectors/validatePaymentLimits';
import store from '../../store/store';
import type {
  PostValidatePaymentsLimitOptionsPayload,
  PostValidatePaymentsLimitParamsPayload,
  RootState,
} from '../../store/types';
import { GlobalState, SearchByType } from '../../store/types/RootStates';
import { GalaxyMakerCheckerWrapper } from '../../widgets/galaxymakerchecker-v1';
import { GetApprovalWorkflowDetailsData } from '../../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types';
import { PaymentDetailsErrorCard } from './PaymentDetailsErrorCard';
import { PaymentTaskDetailsCard } from './PaymentTaskDetailsCard';
import { PaymentTaskDetail } from './PaymentTaskDetailsContainer.type';
import { useOrganizationId } from '../../hooks/useOrganizationId';

/**
 * this page is only used for payment task details, it will be used in the payment list container
 * it expects the selected approvalWorkflow's id to be passed in the global state
 */

export type PaymentTaskDetailsContainerProps = {
  validatePaymentLimit: (
    payload: PostValidatePaymentsLimitParamsPayload,
    options: PostValidatePaymentsLimitOptionsPayload
  ) => void;

  clearValidatePaymentLimit: () => void;
  isValidatePaymentLimitsError?: boolean;
  isValidatePaymentLimitsFetching?: boolean;
  validatePaymentLimitApiStatus?: number;
  validatePaymentLimitErrors?: ErrorResponse[];
  validatePaymentLimitsResults?: validatePaymentLimitsResult[];
  getPaymentLimit: (
    payload?: unknown,
    options?: { headers?: Record<string, string> }
  ) => void;
  paymentLimits?: PaymentLimits[];
  isPaymentLimitsError?: boolean;
  isPaymentLimitsFetching?: boolean;
};

export const PaymentTaskDetailsContainer: FC<
  PaymentTaskDetailsContainerProps
> = ({
  validatePaymentLimit,
  clearValidatePaymentLimit,
  isValidatePaymentLimitsError,
  isValidatePaymentLimitsFetching,
  validatePaymentLimitApiStatus,
  validatePaymentLimitErrors,
  validatePaymentLimitsResults,
  getPaymentLimit,
  paymentLimits,
  isPaymentLimitsError,
  isPaymentLimitsFetching,
}) => {
    const orgId = useOrganizationId();
    const { closeTab } = useClose();
    const approvalWorkflowId: string = useGlobalSelector(
      (state: GlobalState) => state?.global?.galaxy?.context?.approvalWorkflowId
    );
    const searchBy: SearchByType = useGlobalSelector(
      (state: GlobalState) => state?.global?.galaxy?.context?.searchBy
    );
    const [trigger, setTrigger] = useState<string>(approvalWorkflowId || '');
    const [cardData, setCardData] = useState<{
      paymentDetail: PaymentTaskDetail;
      entitlementsPayload: string;
    } | null>(null);
    const [isWorkflowFetching, setIsWorkflowFetching] = useState<boolean>(true);
    const [error, setError] = useState<unknown>(null);

    const [isLoadingWidget, setIsLoadingWidget] = useState(true);
    const [showLoader, setShowLoader] = useState(true);

    useEffect(() => {
      // skips the initial render, only update trigger when approvalWorkflowId has changed and is not empty
      if (!isEmpty(approvalWorkflowId) && approvalWorkflowId !== trigger) {
        setError(null);
        setIsWorkflowFetching(true);
        setCardData(null);
        setTrigger(approvalWorkflowId);
      }
    }, [approvalWorkflowId]);

    /** clears error and update trigger to invoke api call again, without changing approvalWorkflowId */
    const retry = () => {
      setError(null);
      setIsWorkflowFetching(true);
      setTrigger(`${approvalWorkflowId}-${uniqueId()}`);
    };

    const handleClose = async () => {
      await closeTab();
    };

    useEffect(() => {
      const paymentDetail = cardData?.paymentDetail;
      const isFundTransfer =
        paymentDetail?.paymentMethod?.description === 'Fund transfer';
      if (paymentDetail && !isFundTransfer && !isStaffPortal()) {
        getPaymentLimit(undefined, {
          headers: { ...(orgId && { 'protected-orgId': orgId }) },
        });
      }
    }, [cardData, orgId]);

    const onApiResponse = (
      res: { data?: GetApprovalWorkflowDetailsData } = {}
    ) => {
      setIsWorkflowFetching(false);
      const approvalWorkflowDetail =
        res?.data?.entities?.approvalWorkflowDetails?.[0];
      if (approvalWorkflowDetail) {
        const paymentDetail = transformApprovalWorkflowToPaymentTaskDetail(
          approvalWorkflowDetail
        );
        // Add division data to paymentDetail
        const divisionIdMatch =
          approvalWorkflowDetail?.entitlementsPayload?.match(
            /divisionId":"(.*?)"/
          );

        paymentDetail.supplementaryData = {
          ...paymentDetail.supplementaryData,
          divisionId: divisionIdMatch ? divisionIdMatch[1] : '',
        };
        setCardData({
          paymentDetail,
          entitlementsPayload: approvalWorkflowDetail.entitlementsPayload ?? '',
        });
      } else {
        setError('error fetching payment details');
      }
    };

    const onApiError = (err: unknown) => {
      setIsWorkflowFetching(false);
      setError(err);
    };

    useEffect(() => {
      if (!isLoadingWidget) return;
      const widget = document.getElementById('maker-checker-api-client');
      if (widget) {
        setIsLoadingWidget(false);
        return;
      }
      const observer = new MutationObserver(() => {
        const found = document.getElementById('maker-checker-api-client');
        if (found) {
          setIsLoadingWidget(false);
          observer.disconnect();
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
      // eslint-disable-next-line consistent-return
      return () => observer.disconnect();
    }, [isLoadingWidget]);

    // eslint-disable-next-line consistent-return
    useEffect(() => {
      if (isWorkflowFetching || isPaymentLimitsFetching || isLoadingWidget) {
        setShowLoader(true);
      } else {
        // Show loader for at least 200ms to avoid flicker
        const timer = setTimeout(() => setShowLoader(false), 200);
        return () => clearTimeout(timer);
      }
    }, [isWorkflowFetching, isPaymentLimitsFetching, isLoadingWidget]);

    const renderComponent = () => {
      // either loading or waiting for approvalWorkflowId
      if (showLoader || isEmpty(approvalWorkflowId)) {
        return <PageLoader iconSize="medium" />;
      }
      // if not loading and id is avaialble, paymentDetail should be available
      if (error !== null || isEmpty(cardData)) {
        return <PaymentDetailsErrorCard retry={retry} onClose={handleClose} />;
      }
      const { paymentDetail, entitlementsPayload } = cardData;
      return (
        <PaymentTaskDetailsCard
          paymentDetail={paymentDetail}
          entitlementsPayload={entitlementsPayload}
          approvalWorkflowId={approvalWorkflowId}
          isValidatePaymentLimitsFetching={isValidatePaymentLimitsFetching}
          isValidatePaymentLimitsError={isValidatePaymentLimitsError}
          validatePaymentLimitErrors={validatePaymentLimitErrors}
          validatePaymentLimit={validatePaymentLimit}
          validatePaymentLimitApiStatus={validatePaymentLimitApiStatus}
          validatePaymentLimitsResults={validatePaymentLimitsResults}
          clearValidatePaymentLimit={clearValidatePaymentLimit}
          paymentLimits={paymentLimits}
          isPaymentLimitsError={isPaymentLimitsError}
          searchBy={searchBy}
        />
      );
    };

    return (
      <>
        {/* always have GalaxyMakerCheckerWrapper on top when approvalWorkflowId is available */}
        {approvalWorkflowId && (
          <GalaxyMakerCheckerWrapper
            key={approvalWorkflowId}
            apiName="getApprovalWorkflowDetails"
            trigger={trigger}
            params={{ query: { approvalWorkflowId } }}
            options={{ headers: { ...(orgId && { 'protected-orgId': orgId }) } }}
            onApiResponse={onApiResponse}
            onApiError={onApiError}
          />
        )}
        {renderComponent()}
      </>
    );
  };

const mapStateToProps = (state: RootState) => ({
  isValidatePaymentLimitsFetching:
    isValidatePaymentLimitsFetchingSelector(state),
  isValidatePaymentLimitsError: isValidatePaymentLimitsErrorSelector(state),
  validatePaymentLimitApiStatus: getValidatePaymentLimitsStatusCode(state),
  validatePaymentLimitErrors: getValidatePaymentLimitsErrors(state),
  validatePaymentLimitsResults: getAllValidatePaymentLimits(state),
  isPaymentLimitsFetching: isPaymentLimitsFetchingSelector(state),
  isPaymentLimitsError: isPaymentLimitsErrorSelector(state),
  paymentLimits: getAllPaymentLimits(state),
  paymentLimitApiStatus: getPaymentLimitsStatusCode(state),
  paymentLimitErrors: getPaymentLimitsErrors(state),
});

const mapDispatchToProps = {
  getPaymentLimit:
    paymentLimitsActions.api.expGalaxyPaymentV2.paymentLimits.get.request,
  clearPaymentLimit:
    paymentLimitsEntityActions.api.expGalaxyPaymentV2.paymentLimits.clear
      .request,
  validatePaymentLimit:
    validatePaymentLimitsActions.api.expGalaxyPaymentV2.validatePaymentLimits
      .post.request,
  clearValidatePaymentLimit:
    validatePaymentLimitsEntityActions.api.expGalaxyPaymentV2
      .validatePaymentLimits.clear.request,
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps, null, {
    context: store.contextRef,
  })
)(PaymentTaskDetailsContainer);
