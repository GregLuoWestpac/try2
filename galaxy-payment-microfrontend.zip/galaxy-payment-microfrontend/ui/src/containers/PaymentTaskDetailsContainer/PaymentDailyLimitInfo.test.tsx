import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import PaymentDailyLimitsInfo from './PaymentDailyLimitInfo';

// Mock the Westpac UI Alert component
jest.mock('@westpac/ui', () => ({
  Alert: function MockAlert({
    children,
    look,
    className,
    id,
    iconSize,
  }: {
    children: React.ReactNode;
    look: string;
    className: string;
    id: string;
    iconSize: string;
  }) {
    return (
      <div
        data-testid="alert"
        data-look={look}
        className={className}
        id={id}
        data-icon-size={iconSize}
      >
        {children}
      </div>
    );
  },
}));

describe('PaymentDailyLimitsInfo', () => {
  const defaultProps = {
    remainingOrgDailyLimit: '$10,000.00',
    remainingUserAuthDailyLimit: '$5,000.00',
  };

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should display the main info message', () => {
    render(<PaymentDailyLimitsInfo {...defaultProps} />);

    expect(
      screen.getByText(
        'Before proceeding, ensure the following limits are sufficient, otherwise the payment cannot be authorised.'
      )
    ).toBeInTheDocument();
  });

  it('should display organisation daily limit label and value', () => {
    render(<PaymentDailyLimitsInfo {...defaultProps} />);

    expect(
      screen.getByText('Remaining organisation daily limit:')
    ).toBeInTheDocument();
    expect(screen.getByText('$10,000.00')).toBeInTheDocument();
  });

  it('should display user daily authorisation limit label and value', () => {
    render(<PaymentDailyLimitsInfo {...defaultProps} />);

    expect(
      screen.getByText('Your remaining daily authorisation limit:')
    ).toBeInTheDocument();
    expect(screen.getByText('$5,000.00')).toBeInTheDocument();
  });

  it('should render Alert component with correct props', () => {
    render(<PaymentDailyLimitsInfo {...defaultProps} />);

    const alert = screen.getByTestId('alert');
    expect(alert).toHaveAttribute('data-look', 'info');
    expect(alert).toHaveAttribute('id', 'payment-list-info-banner');
    expect(alert).toHaveAttribute('data-icon-size', 'small');
    expect(alert).toHaveClass('flex', 'justify-center', 'mb-0');
  });

  it('should have correct section wrapper classes', () => {
    const { container } = render(<PaymentDailyLimitsInfo {...defaultProps} />);

    const section = container.querySelector('section');
    expect(section).toHaveClass('mt-0', 'flex', 'justify-left');
  });

  it('should display different limit values correctly', () => {
    const customProps = {
      remainingOrgDailyLimit: '$25,500.75',
      remainingUserAuthDailyLimit: '$1,200.50',
    };

    render(<PaymentDailyLimitsInfo {...customProps} />);

    expect(screen.getByText('$25,500.75')).toBeInTheDocument();
    expect(screen.getByText('$1,200.50')).toBeInTheDocument();
  });

  it('should handle zero values', () => {
    const zeroProps = {
      remainingOrgDailyLimit: '$0.00',
      remainingUserAuthDailyLimit: '$0.00',
    };

    render(<PaymentDailyLimitsInfo {...zeroProps} />);

    const zeroValues = screen.getAllByText('$0.00');
    expect(zeroValues).toHaveLength(2);
  });

  describe('when isLimitsError is true', () => {
    it('should not display the limits section when isLimitsError is true', () => {
      render(<PaymentDailyLimitsInfo {...defaultProps} isLimitsError={true} />);

      expect(
        screen.queryByText('Remaining organisation daily limit:')
      ).not.toBeInTheDocument();
      expect(
        screen.queryByText('Your remaining daily authorisation limit:')
      ).not.toBeInTheDocument();
      expect(screen.queryByText('$10,000.00')).not.toBeInTheDocument();
      expect(screen.queryByText('$5,000.00')).not.toBeInTheDocument();
    });

    it('should render Alert component with correct props when isLimitsError is true', () => {
      render(<PaymentDailyLimitsInfo {...defaultProps} isLimitsError={true} />);

      const alert = screen.getByTestId('alert');
      expect(alert).toHaveAttribute('data-look', 'info');
      expect(alert).toHaveAttribute('id', 'payment-list-info-banner');
      expect(alert).toHaveAttribute('data-icon-size', 'small');
      expect(alert).toHaveClass('flex', 'justify-center', 'mb-0');
    });

    it('should have bold styling for key phrases when isLimitsError is true', () => {
      render(<PaymentDailyLimitsInfo {...defaultProps} isLimitsError={true} />);

      const boldElements = screen.getAllByText((content, element) => {
        return element?.classList.contains('font-semibold') === true;
      });

      expect(boldElements).toHaveLength(2);
      expect(boldElements[0]).toHaveTextContent(
        'remaining organisation daily limit'
      );
      expect(boldElements[1]).toHaveTextContent(
        'your remaining daily authorisation limit'
      );
    });

    it('should not display the flex layout dividers when isLimitsError is true', () => {
      const { container } = render(
        <PaymentDailyLimitsInfo {...defaultProps} isLimitsError={true} />
      );

      const dividers = container.querySelectorAll('.border-l');
      expect(dividers).toHaveLength(0);
    });

    it('should still maintain section wrapper structure when isLimitsError is true', () => {
      const { container } = render(
        <PaymentDailyLimitsInfo {...defaultProps} isLimitsError={true} />
      );

      const section = container.querySelector('section');
      expect(section).toHaveClass('mt-0', 'flex', 'justify-left');
    });
  });

  describe('when isLimitsError is false (default)', () => {
    it('should display the standard info message', () => {
      render(
        <PaymentDailyLimitsInfo {...defaultProps} isLimitsError={false} />
      );

      expect(
        screen.getByText(
          'Before proceeding, ensure the following limits are sufficient, otherwise the payment cannot be authorised.'
        )
      ).toBeInTheDocument();
    });

    it('should display the limits section when isLimitsError is false', () => {
      render(
        <PaymentDailyLimitsInfo {...defaultProps} isLimitsError={false} />
      );

      expect(
        screen.getByText('Remaining organisation daily limit:')
      ).toBeInTheDocument();
      expect(
        screen.getByText('Your remaining daily authorisation limit:')
      ).toBeInTheDocument();
      expect(screen.getByText('$10,000.00')).toBeInTheDocument();
      expect(screen.getByText('$5,000.00')).toBeInTheDocument();
    });

    it('should display the flex layout with dividers when isLimitsError is false', () => {
      const { container } = render(
        <PaymentDailyLimitsInfo {...defaultProps} isLimitsError={false} />
      );

      const flexContainer = container.querySelector(
        '.flex.flex-row.items-stretch.gap-0'
      );
      expect(flexContainer).toBeInTheDocument();

      const dividers = container.querySelectorAll('.border-l');
      expect(dividers).toHaveLength(1);
    });
  });

  describe('when isLimitsError is undefined (default behavior)', () => {
    it('should behave the same as isLimitsError false', () => {
      render(<PaymentDailyLimitsInfo {...defaultProps} />);

      expect(
        screen.getByText(
          'Before proceeding, ensure the following limits are sufficient, otherwise the payment cannot be authorised.'
        )
      ).toBeInTheDocument();
      expect(
        screen.getByText('Remaining organisation daily limit:')
      ).toBeInTheDocument();
      expect(screen.getByText('$10,000.00')).toBeInTheDocument();
    });
  });
});
