/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-var-requires */
/* eslint-disable global-require */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/prop-types */
/* eslint-disable @typescript-eslint/no-floating-promises */
import { render, screen } from '@testing-library/react';
import React from 'react';
import { MakerCheckerApiClientProps } from '../../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types';
import { PaymentTaskDetailsContainer } from './PaymentTaskDetailsContainer';

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalSelector: jest.fn(),
  combineReducers: jest.fn(() => jest.fn()),
  createSelector: jest.fn(() => jest.fn()),
  connect: jest.fn(() => jest.fn()),
  compose: jest.fn(() => jest.fn()),
  createStore: jest.fn(() => ({
    dispatch: jest.fn(),
    getState: jest.fn(),
    subscribe: jest.fn(),
  })),
}));

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useClose: () => ({ closeTab: jest.fn() }),
  usePlatformState: jest.fn(() => [{ orgId: { organisationId: 'mock-org-id' } }]),
}));

jest.mock('../../hooks/useOrganizationId', () => ({
  useOrganizationId: jest.fn(() => '12345678901'),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  isStaffPortal: jest.fn(() => false),
}));

jest.mock('../../common/constants', () => ({
  W1_ORGANIZATION_SSO: 'mock-w1-org-sso',
}));

jest.mock('../../store/store', () => ({
  __esModule: true,
  default: { dispatch: jest.fn() },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: function MockComponent({ children }: { children: React.ReactNode }) {
    return <div>{children}</div>;
  },
}));
jest.mock('@mesh-tenant-multiverse-ui-common/mv-pageloader', () => ({
  MVPageLoader: function MockComponent() {
    return <div data-testid="page-loader">Loading spinner</div>;
  },
}));
jest.mock('./PaymentDetailsErrorCard', () => ({
  PaymentDetailsErrorCard: ({ retry }: { retry: () => void }) => (
    <div>
      Error Card
      <button onClick={retry}>Retry</button>
    </div>
  ),
}));

jest.mock('./PaymentTaskDetailsCard', () => ({
  PaymentTaskDetailsCard: ({ paymentDetail }: { paymentDetail: any }) => (
    <div>Card with ID: {paymentDetail.id}</div>
  ),
}));

jest.mock('../../common/utils', () => ({
  transformApprovalWorkflowToPaymentTaskDetail: (data: any) => ({ ...data }),
}));

let mockApiError = false;

jest.mock('../../widgets/galaxymakerchecker-v1', () => ({
  __esModule: true,
  default: (props: MakerCheckerApiClientProps) => {
    // Use a Promise.resolve to ensure it runs in the next tick
    Promise.resolve()
      .then(() => {
        if (mockApiError) {
          props.onApiError?.('mock-error');
        } else {
          props.onApiResponse?.({
            data: {
              entities: {
                approvalWorkflowDetails: [
                  {
                    id: 'mock-id',
                    amount: { amount: '1.00', currency: 'AUD' },
                    beneficiary: {
                      name: 'Test',
                      nickName: 'Test',
                      accountId: '000111',
                    },
                    debitAccount: {
                      nickName: 'Debit',
                      accountId: '000222',
                    },
                    creationDateTime: '2024-01-01T00:00:00Z',
                    creditorDescription: 'desc',
                    debitDescription: 'debit',
                    paymentMethod: { description: 'Fast Payment' },
                    receiptNumber: 'RCPT123',
                    reference: 'REF123',
                    status: 'Pending authorisation',
                    supplementaryData: {
                      aliasId: 'test@example.com',
                      aliasType: 'EMAL',
                    },
                  },
                ],
              },
            },
          });
        }
      })
      .catch(() => {
        // Handle any promise rejection
      });
    return <div data-testid="mock-widget">GalaxyWidget</div>;
  },
}));

describe('PaymentTaskDetailsContainer', () => {
  beforeEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
    mockApiError = false;
  });

  // it('initially shows PageLoader then renders PaymentTaskDetailsCard on success (matches snapshot)', async () => {
  //   // Simulate a non-empty approvalWorkflowId from global state
  //   (useGlobalSelector as jest.Mock).mockReturnValue('test-payment-id');

  //   const { asFragment } = render(<PaymentTaskDetailsContainer />);
  //   // At first render, isLoading === true, so PageLoader should appear
  //   expect(screen.getByText('Loading spinner')).toBeInTheDocument();
  //   expect(asFragment()).toMatchSnapshot('loader-state');

  //   // Wait for the mock MFE to call onApiResponse
  //   const card = await screen.findByText(/Card with ID: mock-id/);
  //   expect(card).toBeInTheDocument();

  //   // After success, snapshot the "success" state
  //   expect(asFragment()).toMatchSnapshot('success-state');
  // });

  // it('should render ErrorCard when API fails', async () => {
  //   mockApiError = true;
  //   (require('@mep-ui/framework').useGlobalSelector as jest.Mock).mockReturnValue('test-payment-id');
  //   const { asFragment } = render(
  //     <PaymentTaskDetailsContainer
  //       getPaymentLimit={jest.fn()}
  //       validatePaymentLimit={jest.fn()}
  //       clearValidatePaymentLimit={jest.fn()}
  //     />
  //   );
  //   expect(screen.getByText('Loading spinner')).toBeInTheDocument();
  //   expect(asFragment()).toMatchSnapshot('loader-before-error');
  //   // Wait for the widget to mount before searching for the error card
  //   await screen.findByTestId('mock-widget');
  //   const errorCard = await screen.findByText((content) => content.includes('Error Card'));
  //   expect(errorCard).toBeInTheDocument();
  //   expect(asFragment()).toMatchSnapshot('error-state');
  // });

  // it('should always mount GalaxyMakerCheckerWrapper', async () => {
  //   (require('@mep-ui/framework').useGlobalSelector as jest.Mock).mockReturnValue('abc123');
  //   const { asFragment } = render(
  //     <PaymentTaskDetailsContainer
  //       getPaymentLimit={jest.fn()}
  //       validatePaymentLimit={jest.fn()}
  //       clearValidatePaymentLimit={jest.fn()}
  //     />
  //   );
  //   const widget = await screen.findByTestId('mock-widget');
  //   expect(widget).toBeInTheDocument();
  //   expect(asFragment()).toMatchSnapshot('widget-mounted-loading');
  // });

  // it('should retry API call when retry button is clicked', async () => {
  //   (require('@mep-ui/framework').useGlobalSelector as jest.Mock).mockReturnValue('retry-id');
  //   mockApiError = true;
  //   const { asFragment } = render(
  //     <PaymentTaskDetailsContainer
  //       getPaymentLimit={jest.fn()}
  //       validatePaymentLimit={jest.fn()}
  //       clearValidatePaymentLimit={jest.fn()}
  //     />
  //   );
  //   await screen.findByText('Error Card');
  //   expect(asFragment()).toMatchSnapshot('first-error-state');
  //   mockApiError = false;
  //   fireEvent.click(screen.getByText('Retry'));
  //   expect(screen.getByText('Loading spinner')).toBeInTheDocument();
  //   expect(asFragment()).toMatchSnapshot('loader-after-retry');
  //   const card = await screen.findByText(/Card with ID: mock-id/);
  //   expect(card).toBeInTheDocument();
  //   expect(asFragment()).toMatchSnapshot('retry-success-state');
  // });

  it('should show loader when approvalWorkflowId is empty', () => {
    (
      require('@mep-ui/framework').useGlobalSelector as jest.Mock
    ).mockReturnValue('');
    const { asFragment } = render(
      <PaymentTaskDetailsContainer
        getPaymentLimit={jest.fn()}
        validatePaymentLimit={jest.fn()}
        clearValidatePaymentLimit={jest.fn()}
      />
    );
    expect(screen.getByText('Loading spinner')).toBeInTheDocument();
    expect(asFragment()).toMatchSnapshot('loader-no-id');
  });
});
