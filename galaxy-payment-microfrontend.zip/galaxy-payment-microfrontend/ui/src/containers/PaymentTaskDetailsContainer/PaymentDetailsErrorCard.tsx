import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import { Alert, Button } from '@westpac/ui';

import { FC } from 'react';
import { genericErrorMessage } from '../../common/constants';

type Props = {
  retry: () => void;
  onClose: () => void;
};

export const PaymentDetailsErrorCard: FC<Props> = ({ retry, onClose }) => (
  <MVCard title="Payment details" template="narrow" bottomDivider={false}>
    <Alert look="danger" id="payment-details-error-banner" iconSize="small">
      {genericErrorMessage} Please{' '}
      <Button
        className="bg-danger-5 p-0 typography-body-11 h-0"
        look="link"
        soft
        onClick={retry}
      >
        try again
      </Button>
      .
    </Alert>
    <div className="border-t-solid border-t border-t-border pt-2.5">
      <Button size="small" look="hero" soft onClick={onClose}>
        Close
      </Button>
    </div>
  </MVCard>
);
export default PaymentDetailsErrorCard;
