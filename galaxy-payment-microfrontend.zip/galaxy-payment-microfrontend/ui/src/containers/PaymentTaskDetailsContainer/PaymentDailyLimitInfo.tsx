import { Alert } from '@westpac/ui';
import React from 'react';

type Props = {
  remainingOrgDailyLimit: string;
  remainingUserAuthDailyLimit: string;
  isLimitsError?: boolean;
};

const DAILY_LIMIT_INFO =
  'Before proceeding, ensure the following limits are sufficient, otherwise the payment cannot be authorised.';
const ALT_DAILY_LIMIT_INFO = (
  <>
    Before proceeding, ensure the{' '}
    <span className="font-semibold">remaining organisation daily limit</span>{' '}
    and{' '}
    <span className="font-semibold">
      your remaining daily authorisation limit
    </span>{' '}
    are sufficient, otherwise the payment cannot be authorised.
  </>
);
const ORG_DAILY_LIMIT_MESSAGE = 'Remaining organisation daily limit:';
const USER_AUTH_DAILY_LIMIT_MESSAGE =
  'Your remaining daily authorisation limit:';

const PaymentDailyLimitsInfo = ({
  remainingOrgDailyLimit,
  remainingUserAuthDailyLimit,
  isLimitsError,
}: Props) => {
  const dailyLimitAlert = isLimitsError
    ? ALT_DAILY_LIMIT_INFO
    : DAILY_LIMIT_INFO;

  return (
    <section className="mt-0 flex justify-left">
      <Alert
        look="info"
        className="flex justify-center mb-0"
        id="payment-list-info-banner"
        iconSize="small"
      >
        <div className="w-full">
          <div className="block w-full  text-gray-700 mb-1">
            {dailyLimitAlert}
          </div>
          {!isLimitsError && (
            <div className="flex flex-row items-stretch gap-0">
              <div className="flex flex-col items-start justify-center basis-[35%] max-w-[35%] flex-shrink-0">
                <span>{ORG_DAILY_LIMIT_MESSAGE}</span>
                <span className="font-semibold">{remainingOrgDailyLimit}</span>
              </div>
              <div className="flex items-stretch ">
                <span className="border-l  h-full ml-2.5 mr-2.5" />
              </div>
              <div className="flex flex-col items-start justify-center basis-[65%] max-w-[65%]">
                <span>{USER_AUTH_DAILY_LIMIT_MESSAGE}</span>
                <span className="font-semibold">
                  {remainingUserAuthDailyLimit}
                </span>
              </div>
            </div>
          )}
        </div>
      </Alert>
    </section>
  );
};

export default PaymentDailyLimitsInfo;
