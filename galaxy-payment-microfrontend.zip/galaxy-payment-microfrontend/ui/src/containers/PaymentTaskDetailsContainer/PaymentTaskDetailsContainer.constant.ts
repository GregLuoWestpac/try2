/**
 * Payment Task Details Container specific alert constants
 * These are used for displaying banners on the payment details page
 */
export const PaymentTaskDetailsContainerAlerts = {
  FAILED_PAYMENT_LIMIT_MARKET_SCHEME_DE: 'FAILED - PAYMENT LIMIT - MARKET SCHEME - DE',
  FAILED_PAYMENT_LIMIT_MARKET_SCHEME_NPP: 'FAILED - PAYMENT LIMIT - MARKET SCHEME - NPP',
} as const;
