/* eslint-disable react/display-name */
import { MVMoreResultsAlert } from '@mesh-tenant-multiverse-ui-common/mv-more-results-alert';
import { MVPageLoader as PageLoader } from '@mesh-tenant-multiverse-ui-common/mv-pageloader';
import { TableDataV2 } from '@mesh-tenant-multiverse-ui-common/mv-table-v2';
import { Alert, Button } from '@westpac/ui';
import { forwardRef, memo, SyntheticEvent } from 'react';
import {
  genericErrorMessage,
  MAX_TRANSACTIONS_LOAD,
} from '../../common/constants';
import { Paging, PaymentListing } from '../../store/types';
import PaymentMemoMVTable from './PaymentMemoMVTable';

type Props = {
  isPaymentListingFetching: boolean;
  hasPaymentListingError: boolean;
  handleSearchPaymentAccountSubmit: (
    event: SyntheticEvent<HTMLButtonElement> | undefined
  ) => Promise<void>;
  sortedList: PaymentListing[];
  exportCsvHandler: () => void;
  selectPayment: (selectedPayment: TableDataV2) => Promise<void>;
  allPaging?: Paging[];
};

export const PaymentListSection = forwardRef<HTMLInputElement, Props>(
  (props, ref) => {
    const {
      isPaymentListingFetching,
      hasPaymentListingError,
      handleSearchPaymentAccountSubmit,
      sortedList,
      exportCsvHandler,
      selectPayment,
      allPaging,
    } = props;

    const count = Number(allPaging?.[0]?.count);
    const showMaxLoadInfoMessage =
      (!Number.isNaN(count) ? count : 0) > MAX_TRANSACTIONS_LOAD;


    if (isPaymentListingFetching) {
      return (
        <div className="mt-4">
          <PageLoader iconSize="medium" />
        </div>
      );
    }

    if (hasPaymentListingError) {
      return (
        <div className="mt-4 flex justify-center">
          <Alert
            look="danger"
            id="payment-list-error-banner"
            iconSize="small"
            className="mb-0"
          >
            {`${genericErrorMessage} Please `}
            <Button
              className="bg-danger-5 p-0 typography-body-11 h-0"
              look="link"
              soft
              onClick={(event) => {
                // eslint-disable-next-line @typescript-eslint/no-floating-promises
                handleSearchPaymentAccountSubmit(
                  event as React.MouseEvent<HTMLButtonElement, MouseEvent>
                );
              }}
            >
              try again
            </Button>
            .
          </Alert>
        </div>
      );
    }

    return (
      <>
        <Button
          data-testid="export-transactions-button"
          soft
          className="font-semibold mt-2.5 mb-2.5"
          look="hero"
          size="small"
          type="submit"
          onClick={exportCsvHandler}
        >
          Export payments
        </Button>
        <MVMoreResultsAlert shouldShow={showMaxLoadInfoMessage} />
        <PaymentMemoMVTable
          sortedList={sortedList}
          selectPayment={selectPayment}
          ref={ref}
        />
      </>
    );
  }
);

export default PaymentListSection;
