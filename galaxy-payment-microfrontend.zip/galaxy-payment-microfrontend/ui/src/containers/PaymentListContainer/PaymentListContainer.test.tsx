/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */

import { ssoActions } from '@mep-ui/framework';
import { useGlobalSelector } from '@mep-ui/framework';
import {
  useIsCompositeDesktop,
  usePlatformState,
} from '@mesh-tenant-multiverse-common/react';
import { isStaffPortal } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { fireEvent, render, screen, act } from '@testing-library/react';
import { usePageContext } from '@mesh-tenant-multiverse-common/react';
import {
  AuthorisationTab,
  genericErrorMessage,
  StatusTab,
} from '../../common/constants';
import { PaymentListing } from '../../store/types';
import {
  PaymentListContainer,
  PaymentListContainerProps,
} from './PaymentListContainer';

// Global type declarations
declare global {
  // eslint-disable-next-line no-var
  var mockSpy: jest.Mock;
}

// Mock the custom hook
jest.mock('../../hooks/useOrganizationId', () => ({
  useOrganizationId: jest.fn(),
}));

const mockOrgId = 'CIS12345';
jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  ...jest.requireActual('@mesh-tenant-multiverse-common/react'),
  usePageContext: jest.fn(() => ({
    context: { contextKey: mockOrgId, cisKey: mockOrgId },
  })),
  useRaiseIntent: jest.fn(),
  usePlatformState: jest.fn(() => [{ id: '06089457589' }]),
  useIsCompositeDesktop: jest.fn(() => true),
}));

jest.mock('../../store/store', () => ({
  __esModule: true,
  default: {
    dispatch: jest.fn(),
  },
}));

jest.mock('../../components/AccountSearchSection', () => ({
  AccountSearchSection: function MockAccountSearchSection() {
    return <div>Mock AccountSearchSection</div>;
  },
}));

// Global spy for GalaxyMakerCheckerWrapper
global.mockSpy = jest.fn();
jest.mock('../../widgets/galaxymakerchecker-v1', () => ({
  __esModule: true,
  default: () => null,
  GalaxyMakerCheckerWrapper: (props: any) => {
    global.mockSpy(props);
    return null;
  },
}));

jest.mock(
  '../../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types',
  () => ({
    ApprovalWorkflowType: {
      PAYMENTS: 'w1cpayments',
    },
  })
);

jest.mock('@mesh-tenant-multiverse-ui-common/mv-accordion', () => ({
  MVAccordion: function MockMVAccordion({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div>{children}</div>;
  },
  MVAccordionItem: function MockMVAccordionItem({
    title,
    children,
  }: {
    title: string;
    children: React.ReactNode;
  }) {
    return (
      <div>
        <div>{title}</div>
        <div>{children}</div>
      </div>
    );
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-refresh', () => ({
  MVRefresh: function MockComponent({ onRefresh }: { onRefresh: () => void }) {
    return <div onClick={onRefresh}>Mock MVRefresh</div>;
  },
  MVRefreshHandle: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div>{children}</div>;
  },
}));
jest.mock('@mesh-tenant-multiverse-ui-common/mv-pageloader', () => ({
  MVPageLoader: function MockComponent() {
    return <div>Mock MVPageLoader</div>;
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-table-v2', () => ({
  MVTableV2: function MockComponent() {
    return <div>Mock MVTable</div>;
  },
  COMMON_COLUMN_DEFS: {
    submittedDate: jest.fn(),
    valueDate: jest.fn(),
    paymentId: jest.fn(),
    fromAccount: jest.fn(),
    toAccount: jest.fn(),
    amount: jest.fn(),
    currency: jest.fn(),
    debitDescription: jest.fn(),
    paymentMethod: jest.fn(),
    status: jest.fn(),
    actions: jest.fn(),
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  useHandleRaiseIntent: jest.fn(),
  isStaffPortal: jest.fn(),
  convertSydneyLocalTimeToUtc: jest.fn(),
  getFormattedDate: jest.fn(),
  getFormattedDateTime: jest.fn(),
  formatToTwoDecimals: jest.fn(),
}));
jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  MVAutocompleteController: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div>{children}</div>;
  },
  MVDateRangePickerController: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div>{children}</div>;
  },
  getToday: jest.fn(() => ({
    minus: jest.fn(() => ({
      toFormat: jest.fn(() => '09/03/2025'),
    })),
    toFormat: jest.fn(() => '09/03/2025'),
  })),
  getTodayAtLastYear: jest.fn(() => ({
    toFormat: jest.fn(() => '09/03/2024'),
  })),
  useHandleRaiseIntent: jest.fn(),
}));

jest.mock('@mep-ui/framework-router-addon', () => {
  const mockNavigate = jest.fn();
  return {
    ...jest.requireActual('@mep-ui/framework-router-addon'),
    useNavigate: () => mockNavigate,
  };
});

jest.mock('../../components', () => ({
  PageLoader: function MockComponent() {
    return <div>Mock PageLoader</div>;
  },
}));

// Default mock for react-hook-form
const mockHandleSubmit = jest.fn((onValid, onError) => () => {
  try {
    onValid();
  } catch (error) {
    onError(error);
  }
});

const createMockFormReturn = () => ({
  handleSubmit: mockHandleSubmit,
  control: {},
  register: jest.fn(),
  setValue: jest.fn(),
  getValues: jest.fn(() => ({
    fromAccount: { accountName: '', accountNumber: '' },
    dateRange: { startDate: '', endDate: '' },
    authorisationTab: 'requiresYourApproval',
    statusTab: 'pending',
  })),
  watch: jest.fn(),
  trigger: jest.fn().mockResolvedValue(true),
  formState: { errors: {} },
  setError: jest.fn(),
  clearErrors: jest.fn(),
});

jest.mock('react-hook-form', () => {
  const actual = jest.requireActual('react-hook-form');
  return {
    ...actual,
    useForm: jest.fn(),
    Controller: ({ render: renderProp }: any) =>
      renderProp({
        field: {
          onChange: jest.fn(),
          onBlur: jest.fn(),
          value: '',
          name: 'test',
          ref: jest.fn(),
        },
        fieldState: {
          invalid: false,
          isTouched: false,
          isDirty: false,
          error: undefined,
        },
        formState: {
          errors: {},
          isDirty: false,
          isSubmitting: false,
          isSubmitted: false,
          isValid: true,
        },
      }),
  };
});

const mockGlobalDispatch = jest.fn();

const mockedUseManifestValue = jest.fn().mockImplementation(() => ({
  isLoading: true,
  isError: false,
  manifest: undefined,
}));

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  ssoActions: {
    sso: {
      signout: {
        request: jest.fn(),
      },
    },
  },
  useGlobalDispatch: () => mockGlobalDispatch,
  useGlobalSelector: jest.fn(),
  useManifest: () => mockedUseManifestValue(),
}));

jest.mock('@westpac/ui', () => ({
  ...jest.requireActual('@westpac/ui'),
  Tabs: function MockTabs({
    children,
    onSelectionChange = () => { },
  }: {
    children: React.ReactNode;
    onSelectionChange?: (key: string) => void;
  }) {
    return (
      <div>
        <div onClick={() => onSelectionChange('authorisations')}>
          Authorisations
        </div>
        <div onClick={() => onSelectionChange('processing')}>
          Sent for processing
        </div>
        {children}
      </div>
    );
  },
  TabsPanel: function MockTabsPanel({
    key,
    title,
    children,
  }: {
    key: string;
    title: string;
    children: React.ReactNode;
  }) {
    return (
      <div key={key} title={title}>
        {children}
      </div>
    );
  },
}));


const mockPostPayments: PaymentListing[] = [
  {
    id: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
    status: 'Processed',
    creationDateTime: '2024-08-12T01:00:05.378Z',
    amount: '2500.15',
    currency: 'AUD',
    debitAccountName: 'Debtor Account Nick Name 1',
    debitAccountIdentification: '111111000001',
    debitDescription: 'PaymentInformationId',
    creditAccountName: 'Creditor Account Nick Name 1',
    creditAccountIdentification: '222222000001',
    paymentMethod: 'Funds transfer',
    receiptNumber: 'ReceiptId_1',
    instructionTraceIdentification: 'InstructionTraceIdentification_1',
    beneficiaryName: '',
  },
  {
    id: 'b811e8d8-cf6d-4a49-86c3-38ee27e1d4f8',
    status: 'Failed',
    creationDateTime: '2024-08-12T01:00:05.378Z',
    amount: '2570.15',
    currency: 'AUD',
    debitAccountName: 'Debtor Account Nick Name 1',
    debitAccountIdentification: '111111000001',
    debitDescription: 'PaymentInformationId',
    creditAccountName: 'Creditor Account Nick Name 2',
    creditAccountIdentification: '222222000001',
    paymentMethod: 'Funds transfer',
    receiptNumber: 'ReceiptId_2',
    instructionTraceIdentification: 'InstructionTraceIdentification_2',
    beneficiaryName: '',
  },
  {
    id: 'b811e8d8-cf6d-4a99-86c3-38dd27e1d4f8',
    status: 'Submitted',
    creationDateTime: '2024-08-12T01:00:05.378Z',
    amount: '2520.15',
    currency: 'AUD',
    debitAccountName: 'Debtor Account Nick Name 3',
    debitAccountIdentification: '111111000001',
    debitDescription: 'PaymentInformationId',
    creditAccountName: 'Creditor Account Nick Name 3',
    creditAccountIdentification: '222222000001',
    paymentMethod: 'Funds transfer',
    receiptNumber: 'ReceiptId_3',
    instructionTraceIdentification: 'InstructionTraceIdentification_3',
    beneficiaryName: '',
  },
];

const defaultProps: PaymentListContainerProps = {
  allPostPaymentListing: mockPostPayments,
  isPaymentListingFetching: false,
  allAccountList: [],
  getPaymentListing: jest.fn(),
  isPaymentListingError: false,
  isAccountListError: false,
  isAccountListFetching: false,
  accountListRequest: jest.fn(),
  clearPaymentListing: jest.fn(),
  clearAccountList: jest.fn(),
  allPaging: [],
  getDivisionList: jest.fn(),
  isDivisionListFetching: false,
  isDivisionListError: false,
  allDivisionList: [],
};

Date.now = jest.fn(() => new Date(Date.UTC(2017, 7, 9, 8)).valueOf());

describe('Testing the PaymentListContainer', () => {
  beforeEach(() => {
    jest.clearAllMocks();

    // Configure react-hook-form mock
    const { useForm } = require('react-hook-form');
    (useForm as jest.Mock).mockImplementation(() => createMockFormReturn());

    // Mock the custom hook to return the default mockOrgId
    const useOrganizationIdMock = jest.requireMock(
      '../../hooks/useOrganizationId'
    ).useOrganizationId;
    useOrganizationIdMock.mockReturnValue(mockOrgId);

    (usePlatformState as jest.Mock).mockReturnValue([
      { orgId: { organisationId: '06089457589' } },
    ]);
    (useIsCompositeDesktop as jest.Mock).mockReturnValue(true);

    const useGlobalSelector = require('@mep-ui/framework').useGlobalSelector;
    useGlobalSelector.mockImplementation((fn: any) =>
      fn({
        global: {
          galaxy: {
            context: {
              orgId: mockOrgId,
              selectedCustomer: { cisKey: mockOrgId },
            },
          },
        },
      })
    );
    (usePageContext as jest.Mock).mockReturnValue({
      context: { contextKey: mockOrgId, cisKey: mockOrgId },
    });

    // Mock the DOM element that ApprovalWorkflowPanel looks for
    const mockElement = document.createElement('div');
    mockElement.id = 'maker-checker-api-client';
    document.body.appendChild(mockElement);
  });

  afterEach(() => {
    // Clean up the mock element
    const mockElement = document.getElementById('maker-checker-api-client');
    if (mockElement) {
      document.body.removeChild(mockElement);
    }
  });

  it('renders without crashing', () => {
    const { asFragment } = render(<PaymentListContainer {...defaultProps} />);
    expect(asFragment()).toMatchSnapshot();
  });

  let mockSpy: jest.Mock;

  it('should pass correct postApprovalWorkflowListParams to GalaxyMakerCheckerWrapper for both tabs', () => {
    // Mock isStaffPortal to return true for this test since the expectation is for staff portal
    (isStaffPortal as jest.Mock).mockReturnValue(true);

    global.mockSpy.mockClear();
    render(<PaymentListContainer {...defaultProps} />);
    // Find the props for the first render
    const firstCall = global.mockSpy.mock.calls[0][0];
    expect(firstCall.params.body).toEqual({
      searchBy: 'ApproverAndCreatedOnDateRange',
      approverStatus: ['ApprovalPending', 'Rejected'],
      workflowStatus: ['ApprovalPending', 'Rejected'],
      types: ['w1cpayments'],
      subTypes: ['payments', 'transfers'],
      approvalChannel: 'W1C-Staff',
      createdOnDateRange: {
        fromDate: undefined,
        toDate: undefined,
      },
    });

    // Simulate tab change to PaymentsYouInitiated
    const { getAllByText } = render(<PaymentListContainer {...defaultProps} />);
    const paymentsYouInitiatedTabs = getAllByText('Payments you initiated');
    act(() => {
      fireEvent.click(paymentsYouInitiatedTabs[0]);
    });
    // Find the props for the second render (last call)
    const lastCallIndex = global.mockSpy.mock.calls.length - 1;
    const secondCall = global.mockSpy.mock.calls[lastCallIndex][0];
    expect(secondCall.params.body).toEqual({
      searchBy: 'CreatedBy',
      workflowStatus: ['ApprovalPending', 'Rejected'],
      types: ['w1cpayments'],
      subTypes: ['payments', 'transfers'],
      approvalChannel: 'W1C-Staff',
    });
  });

  describe('The account list error message should show correctly', () => {

    it('should not show the error message, if there is not an error and fetching is finished', () => {
      const { queryByText } = render(
        <PaymentListContainer
          {...defaultProps}
          isAccountListError={false}
          isAccountListFetching={false}
        />
      );

      const errorMessageEl = queryByText(genericErrorMessage);
      expect(errorMessageEl).not.toBeInTheDocument();
    });

    it('should not show the error message, if fetching is not finished', () => {
      const { queryByText } = render(
        <PaymentListContainer
          {...defaultProps}
          isAccountListError
          isAccountListFetching
        />
      );

      const errorMessageEl = queryByText(genericErrorMessage);
      expect(errorMessageEl).not.toBeInTheDocument();
    });
  });

  describe('should show the account activity from the response', () => {
    beforeEach(() => {
      jest.resetAllMocks();

      // Reconfigure react-hook-form mock after reset
      const { useForm } = require('react-hook-form');
      (useForm as jest.Mock).mockImplementation(() => createMockFormReturn());
    });

    it('should dispatch global sign out action, if got authentication error', () => {
      (usePageContext as jest.Mock).mockReturnValue({
        context: { contextKey: mockOrgId, cisKey: mockOrgId },
      });

      // Ensure usePlatformState returns a valid array

      (usePlatformState as jest.Mock).mockReturnValue([
        { orgId: { organisationId: '06089457589' } },
      ]);

      render(
        <PaymentListContainer
          {...defaultProps}
          isPaymentListingError={false}
          isPaymentListingFetching={false}
          allPostPaymentListing={mockPostPayments}
          isAuthenticatedError
        />
      );

      expect(mockGlobalDispatch).toHaveBeenCalledTimes(1);

      // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
      const signoutRequest = ssoActions.sso.signout.request;
      expect(signoutRequest).toHaveBeenCalledTimes(1);
    });
  });

  it('should show spinner when fetching account list', () => {
    const { getAllByText } = render(
      <PaymentListContainer {...defaultProps} isAccountListFetching />
    );
    const loaders = getAllByText('Mock MVPageLoader');
    expect(loaders.length).toBeGreaterThan(0);
  });

  it('should show spinner when fetching payment list', () => {
    const { getAllByText } = render(
      <PaymentListContainer {...defaultProps} isPaymentListingFetching />
    );
    const loaders = getAllByText('Mock MVPageLoader');
    expect(loaders.length).toBeGreaterThan(0);
  });

  it('should call handleSubmit when MVRefresh is clicked', async () => {
    mockHandleSubmit.mockClear();

    const { getByText } = render(
      <PaymentListContainer
        {...defaultProps}
        isPaymentListingFetching={false}
        isAuthenticatedError={false}
      />
    );

    fireEvent.click(getByText(/sent for processing/i));

    // Clear the mock again after tab switch (which might call handleSubmit)
    mockHandleSubmit.mockClear();

    // Now test the refresh functionality
    const refreshButton = getByText('Mock MVRefresh');
    fireEvent.click(refreshButton);

    expect(mockHandleSubmit).toHaveBeenCalledWith(
      expect.any(Function),
      expect.any(Function)
    );
    expect(mockHandleSubmit).toHaveBeenCalledTimes(1);
  });

  it('should call accountListRequest with protected-orgId header from organisationSSOData for non-staff portal', () => {
    const accountListRequest = jest.fn();
    const expectedOrgId = '06089457589'; // This comes from usePlatformState mock

    // Mock useOrganizationId to return the expected organization ID for this test
    jest
      .requireMock('../../hooks/useOrganizationId')
      .useOrganizationId.mockReturnValue(expectedOrgId);

    // Mock useGlobalSelector to return some context (but orgId will come from usePlatformState for non-staff)

    (useGlobalSelector as jest.Mock).mockImplementation((fn: any) =>
      fn({
        global: {
          galaxy: {
            context: {
              orgId: mockOrgId,
              selectedCustomer: { cisKey: mockOrgId },
            },
          },
        },
      })
    );

    (isStaffPortal as jest.Mock).mockReturnValue(false);
    (usePlatformState as jest.Mock).mockReturnValue([
      { orgId: { organisationId: expectedOrgId } },
    ]);

    // Render the component
    render(
      <PaymentListContainer
        {...defaultProps}
        accountListRequest={accountListRequest}
      />
    );

    // Verify arrangementsRequest was called with the correct parameters and headers
    // For non-staff portal, it should use organisationSSOData.id (06089457589)
    expect(accountListRequest).toHaveBeenCalledWith(
      expect.objectContaining({
        pdpQueryAction: 'VIEW_PAYMENT',
        meta: {
          replaceEntities: ['accountList'],
        },
      }),
      expect.objectContaining({
        headers: expect.objectContaining({
          'protected-orgId': expectedOrgId,
        }),
      })
    );
  });

  it('should call accountListRequest with protected-orgId header from selectedCustomer for staff portal', () => {
    const accountListRequest = jest.fn();
    const staffOrgId = 'STAFF12345';

    // Mock useOrganizationId to return the staff organization ID for this test
    jest
      .requireMock('../../hooks/useOrganizationId')
      .useOrganizationId.mockReturnValue(staffOrgId);

    // Mock isStaffPortal to return true (staff portal)

    (isStaffPortal as jest.Mock).mockReturnValue(true);

    // Mock useGlobalSelector to return the staff organization context

    (useGlobalSelector as jest.Mock).mockImplementation((fn: any) =>
      fn({
        global: {
          galaxy: {
            context: {
              orgId: staffOrgId,
              selectedCustomer: { cisKey: staffOrgId },
            },
          },
        },
      })
    );

    // Render the component
    render(
      <PaymentListContainer
        {...defaultProps}
        accountListRequest={accountListRequest}
      />
    );

    // Verify accountListRequest was called with the correct parameters and headers
    // For staff portal, it should use organisationCisKey from global selector
    expect(accountListRequest).toHaveBeenCalledWith(
      expect.objectContaining({
        pdpQueryAction: 'VIEW_PAYMENT',
        meta: {
          replaceEntities: ['accountList'],
        },
      }),
      expect.objectContaining({
        headers: expect.objectContaining({
          'protected-orgId': staffOrgId,
        }),
      })
    );

    // Reset mock for other tests
    (isStaffPortal as jest.Mock).mockReturnValue(false);
  });

  describe('Date Range Conversion and Form Data Tests', () => {
    it('should convert date range correctly in postApprovalWorkflowListParams', async () => {
      (isStaffPortal as jest.Mock).mockReturnValue(false);

      // Create a test component to access the internal logic
      const TestComponent = () => {
        const testFormData = {
          dateRange: {
            startDate: '2024-01-15',
            endDate: '2024-03-30',
          },
          authorisationTab: AuthorisationTab.ForYouToAuthorise,
          statusTab: StatusTab.Pending,
        };

        // Test the conversion logic directly
        const convertedDateRange = testFormData?.dateRange
          ? {
            fromDate: testFormData.dateRange.startDate
              ? new Date(testFormData.dateRange.startDate).toISOString()
              : undefined,
            toDate: testFormData.dateRange.endDate
              ? new Date(testFormData.dateRange.endDate).toISOString()
              : undefined,
          }
          : undefined;

        expect(convertedDateRange).toEqual({
          fromDate: '2024-01-15T00:00:00.000Z',
          toDate: '2024-03-30T00:00:00.000Z',
        });

        return <div>Test Complete</div>;
      };

      render(<TestComponent />);
    });

    it('should handle undefined date range in authorisationSearchFormData', () => {
      (isStaffPortal as jest.Mock).mockReturnValue(false);

      const testFormData: {
        authorisationTab: string;
        statusTab: string;
        dateRange?: { startDate: string; endDate: string };
      } = {
        authorisationTab: AuthorisationTab.ForYouToAuthorise,
        statusTab: StatusTab.Pending,
      };

      const convertedDateRange = testFormData?.dateRange
        ? {
          fromDate: testFormData.dateRange.startDate
            ? new Date(testFormData.dateRange.startDate).toISOString()
            : undefined,
          toDate: testFormData.dateRange.endDate
            ? new Date(testFormData.dateRange.endDate).toISOString()
            : undefined,
        }
        : undefined;

      expect(convertedDateRange).toBeUndefined();
    });
  });

  describe('Tab switching validation', () => {
    it('should render tabs for switching between authorisations and processing', () => {
      const { getAllByText } = render(
        <PaymentListContainer {...defaultProps} />
      );

      const authorisationsTab = getAllByText('Authorisations')[0];
      const processingTab = getAllByText('Sent for processing')[0];

      expect(authorisationsTab).toBeInTheDocument();
      expect(processingTab).toBeInTheDocument();
    });
  });

  describe('onRefresh functionality', () => {
    it('should render MVRefresh component', () => {
      const { getByText } = render(<PaymentListContainer {...defaultProps} />);

      const refreshButton = getByText('Mock MVRefresh');
      expect(refreshButton).toBeInTheDocument();
    });

    it('should render onRefresh prop in MVRefresh component', () => {
      const { getByText } = render(<PaymentListContainer {...defaultProps} />);

      const refreshButton = getByText('Mock MVRefresh');

      // Refresh button should be rendered
      expect(refreshButton).toBeInTheDocument();
    });
  });

  describe('DateTime update logic', () => {
    it('should render component with DateTime functionality', () => {
      const { getByText } = render(<PaymentListContainer {...defaultProps} />);

      const refreshButton = getByText('Mock MVRefresh');
      expect(refreshButton).toBeInTheDocument();
    });

    it('should handle API success state changes', () => {
      const { rerender } = render(
        <PaymentListContainer {...defaultProps} isPaymentListingFetching />
      );

      // Simulate successful API response
      rerender(
        <PaymentListContainer
          {...defaultProps}
          isPaymentListingFetching={false}
          isPaymentListingError={false}
        />
      );

      // Component should render without errors
      expect(true).toBe(true);
    });
  });
});
