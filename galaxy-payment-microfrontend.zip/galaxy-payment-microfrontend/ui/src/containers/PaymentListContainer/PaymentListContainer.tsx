/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import {
  compose,
  connect,
  ssoActions,
  useGlobalDispatch,
  useGlobalSelector,
} from '@mep-ui/framework';
import { useNavigate } from '@mep-ui/framework-router-addon';
import {
  MVRefresh,
  MVRefreshHandle,
} from '@mesh-tenant-multiverse-ui-common/mv-refresh';
import { MVPageLoader as PageLoader } from '@mesh-tenant-multiverse-ui-common/mv-pageloader';
import {
  MVTableExportCSV,
  TableDataV2 as TableData,
} from '@mesh-tenant-multiverse-ui-common/mv-table-v2';
import {
  convertSydneyLocalTimeToUtc,
  getFormattedDate,
  getFormattedDateTime,
  isStaffPortal,
  useHandleRaiseIntent,
  formatToTwoDecimals,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';

import { useIsCompositeDesktop } from '@mesh-tenant-multiverse-common/react';
import { Tabs, TabsPanel } from '@westpac/ui';
import { DateTime } from 'luxon';
import {
  FC,
  Key,
  LegacyRef,
  SyntheticEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { SubmitErrorHandler, useForm } from 'react-hook-form';
import {
  AuthorisationTab,
  CONTAINERTAB_TITLES,
  INTENT_NAMES,
  INTENTS_CONTEXT_NAME,
  PAGE_NAVIGATION,
  PaymentStatusTab,
  PDP_QUERY_ACTIONS,
  StatusTab,
  defaultDivisionData
} from '../../common/constants';
import {
  AuthorisationSearchFormType,
  AuthorisationTabValues,
  defaultAuthorisationSearchFormData,
  defaultSearchPaymentAccountFormData,
  SearchPaymentAccountDataType,
  StatusTabValues,
  DivisionType,
  DivisionOptionType,
} from '../../common/types';
import { useOrganizationId } from '../../hooks/useOrganizationId';
import {
  accountListActions,
  accountListEntityActions,
  getAllAccountList,
  getAllPaging,
  getAllPaymentListing,
  isAccountListError as isAccountListErrorSelector,
  isAccountListFetching as isAccountListFetchingSelector,
  isPaymentListingFetching as isPaymentListingFetchingSelector,
  isPaymentListingError as isPaymentCreateErrorSelector,
  paymentListingActions,
  paymentListingEntityActions,
  divisionListActions,
  isDivisionListFetching as isDivisionListFetchingSelector,
  isDivisionListError as isDivisionListErrorSelector,
  getAllDivisionList,
} from '../../store/generated';
import { isAuthenticatedError as isAuthenticatedErrorSelector } from '../../store/selectors/paymentCreate';
import store from '../../store/store';
import {
  Account,
  ApprovalWorkflowListing,
  Paging,
  PaymentListing,
  PostAccountListParamsPayload,
  PostPaymentListingParams,
  PostPaymentListingParamsPayload,
  PostPaymentListingQueryParams,
  RequestOptionsPayload,
  getDivisionListParamsPayload
} from '../../store/types';
import {
  CustomerData,
  GlobalState,
  RootState,
} from '../../store/types/RootStates';
import { GalaxyMakerCheckerWrapper } from '../../widgets/galaxymakerchecker-v1';
import {
  ApprovalWorkflowType,
  PostApprovalWorkflowListData,
} from '../../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types';
import ApprovalWorkflowPanel from './ApprovalWorkflowPanel';
import PaymentListAccountSearchSection from './PaymentListAccountSearchSection';
import { PaymentListAlert, PaymentListAlertProps } from './PaymentListAlert';
import {
  authorisationTabValues,
  mapApprovalWorkflowList,
  statusTabValues,
} from './PaymentListContainer.utils';
import PaymentListSection from './PaymentListSection';
import AuthorisationsSearchSection from './AuthorisationsSearchSection';
import useViewOptions from '../../hooks/useViewOptions';


export type PaymentListContainerProps = {
  allPostPaymentListing: PaymentListing[];
  isPaymentListingFetching: boolean;
  isPaymentListingError: boolean;
  isAuthenticatedError?: boolean;
  allAccountList: Account[];
  isAccountListError: boolean;
  isAccountListFetching: boolean;
  getPaymentListing: (
    params: PostPaymentListingParamsPayload,
    options: RequestOptionsPayload
  ) => void;
  accountListRequest: (
    params: PostAccountListParamsPayload,
    options: RequestOptionsPayload
  ) => void;
  // eslint-disable-next-line react/no-unused-prop-types
  clearAccountList: () => void;
  clearPaymentListing: () => void;
  allPaging: Paging[];
  getDivisionList: (
    params: getDivisionListParamsPayload,
    options: RequestOptionsPayload
  ) => void;
  isDivisionListFetching: boolean;
  isDivisionListError: boolean;
  allDivisionList: DivisionType[];
};

export const PaymentListContainer: FC<PaymentListContainerProps> = ({
  allPostPaymentListing,
  isPaymentListingFetching,
  isPaymentListingError,
  isAuthenticatedError,
  allAccountList,
  getPaymentListing,
  accountListRequest,
  isAccountListError,
  isAccountListFetching,
  clearPaymentListing,
  allPaging,
  getDivisionList,
  isDivisionListFetching,
  isDivisionListError,
  allDivisionList,
}) => {
  const globalDispatch = useGlobalDispatch();
  const mvTableRef = useRef<MVTableExportCSV>(null);
  const [selectedAccount, setSelectedAccount] = useState<Account | undefined>();
  const [formValues, setFormValues] = useState<SearchPaymentAccountDataType>();
  const [dateTimeAfterApiSuccess, setDateTimeAfterApiSuccess] =
    useState<string>(getFormattedDateTime);
  const [currentTabKey, setCurrentTabKey] = useState<string>(
    PaymentStatusTab.Authorisations
  );
  const [allPostApprovalWorkflowListing, setAllPostApprovalWorkflowListing] =
    useState<ApprovalWorkflowListing[]>([]);
  const [
    isApprovalWorkflowListingFetching,
    setIsApprovalWorkflowListingFetching,
  ] = useState<boolean>(true);
  const [hasApprovalWorkflowListingError, setHasApprovalWorkflowListingError] =
    useState<boolean>(false);

  const [isInit, setIsInit] = useState(true);

  const isCompositeDesktop = useIsCompositeDesktop();
  const orgId = window.location.hostname === 'localhost' ? useOrganizationId() || '12345678910'
    : useOrganizationId();
  const [authorisationActiveTab, setAuthorisationActiveTab] =
    useState<AuthorisationTabValues>(AuthorisationTab.ForYouToAuthorise);
  const [isPaymentsYouInitiatedTabSelected, setIsPaymentsYouInitiatedTabSelected] =
    useState<boolean>(authorisationActiveTab === AuthorisationTab.PaymentsYouInitiated);
  const [statusActiveTab, setStatusActiveTab] = useState<StatusTabValues>(
    StatusTab.Pending
  );
  const [divisions, setDivisions] = useState<DivisionOptionType[]>(defaultDivisionData);
  const [selectedDivision, setSelectedDivision] = useState<DivisionOptionType | null>(null);
  const [approvalWorkflowTrigger, setApprovalWorkflowTrigger] = useState(0);
  const [authorisationSearchFormData, setAuthorisationSearchFormData] =
    useState<AuthorisationSearchFormType>({
      ...defaultAuthorisationSearchFormData,
      authorisationTab: AuthorisationTab.ForYouToAuthorise,
      statusTab: StatusTab.Pending,
    });
  const {
    control: authorisationControl,
    setError: authorisationSetError,
    clearErrors: authorisationClearErrors,
    getValues: authorisationGetValues,
    handleSubmit: authorisationHandleSubmit,
    trigger: authorisationTrigger,
  } = useForm<AuthorisationSearchFormType>({
    mode: 'onBlur',
    reValidateMode: 'onBlur',
    defaultValues: {
      ...defaultAuthorisationSearchFormData,
    },
  });

  // last rejected or approved workflow from payment task details page
  const updatedApprovalWorkflowId: CustomerData = useGlobalSelector(
    (state: GlobalState) =>
      state?.global?.galaxy?.context?.approvalWorkflowId || null
  );
  // alertMessages carried from other pages, possible to have multiple alerts
  const alertMessages: PaymentListAlertProps[] =
    useGlobalSelector(
      (state: GlobalState) => state?.global?.galaxy?.context?.alertMessages
    ) ?? [];

  const selectedPaymentFormValues: SearchPaymentAccountDataType =
    useGlobalSelector(
      (state: GlobalState) =>
        state?.global?.galaxy?.context?.selectedPaymentFormValues
    );

  const [isOrgIdFetching, setIsOrgIdFetching] = useState<boolean>(true);
  const showDivisionField =
    !isStaffPortal() &&
    !isDivisionListFetching &&
    !isDivisionListError &&
    allDivisionList.length > 0;
  const viewOptionsPaymentDetails = useViewOptions(CONTAINERTAB_TITLES.PAYMENT_DETAILS);

  const signout = () => {
    globalDispatch(ssoActions.sso.signout.request());
  };

  useEffect(
    () => () => {
      if (clearPaymentListing) clearPaymentListing();
    },
    []
  );

  useEffect(() => {
    const isNonCompositeDesktop = !isCompositeDesktop;
    const hasOrgId = !!orgId;

    const shouldFetchData =
      isNonCompositeDesktop || (isCompositeDesktop && hasOrgId);

    if (shouldFetchData) {
      setIsOrgIdFetching(false);
      fetchDivisionList();
      handleFetchAccountList(orgId);
    }
  }, [orgId]);

  useEffect(() => {
    const transformedDivisionList = allDivisionList.map((division) => ({
      id: division.divisionId,
      name: division.divisionName,
      label: division.divisionName,
    }));

    setDivisions([...defaultDivisionData, ...(transformedDivisionList ?? [])]);
  }, [allDivisionList]);

  useEffect(() => {
    if (isInit) {
      setIsInit(false);
      setFormValues(selectedPaymentFormValues);
    }
  }, [selectedPaymentFormValues]);

  useEffect(() => {
    if (isAuthenticatedError) {
      signout();
    }
  }, [isAuthenticatedError]);

  // refresh payments only after refreshing accounts
  useEffect(() => {
    if (!isInit && selectedAccount && allAccountList?.length) {
      if (
        !allAccountList.find(
          (account) => account.accountId === selectedAccount.id
        )
      ) {
        // previously selected account is not there in refreshed accounts list!
        setSelectedAccount(undefined);
      }
      // refresh payments
      // eslint-disable-next-line no-use-before-define
      handleSearchPaymentAccountSubmit(undefined);
    }
  }, [allAccountList]);

  const fromAccountOptions = useMemo(
    () =>
      allAccountList
        .slice()
        .sort((a, b) => a.accountName.localeCompare(b.accountName))
        .map((account) => ({
          id: account.id,
          accountName: account.accountName,
          accountId: account.accountId,
          currencyCode: account.currencyCode,
          accountType: account.accountType,
          status: account.status,
        })),
    [allAccountList]
  );

  const {
    control,
    handleSubmit,
    setError,
    clearErrors,
    formState: { errors },
    trigger,
    getValues,
  } = useForm<SearchPaymentAccountDataType>({
    mode: 'onBlur',
    reValidateMode: 'onBlur',
    defaultValues: {
      ...defaultSearchPaymentAccountFormData,
      fromAccount: formValues?.fromAccount,
    },
  });

  const refreshWidgetRef = useRef<MVRefreshHandle>(null);

  const hasPaymentListingError =
    isPaymentListingError && !isPaymentListingFetching;
  const hasAccountListError = isAccountListError && !isAccountListFetching;

  const handleFetchAccountList = (
    organisationid: string | undefined,
    divisionId?: string
  ) => {
    const params: PostAccountListParamsPayload = {
      pdpQueryAction: PDP_QUERY_ACTIONS.VIEW_PAYMENT,
      ...(divisionId && { divisionId }),
      meta: {
        replaceEntities: ['accountList'],
      },
    };

    accountListRequest(params, {
      headers: {
        ...(organisationid && {
          'protected-orgId': organisationid,
        }),
      },
    });
  };

  const handleRetryAccountList = () => {
    handleFetchAccountList(orgId, selectedDivision?.id);
  };
  const onSelectDivision = (division?: DivisionOptionType) => {
    const isDefaultDivision = division?.id === defaultDivisionData[0].id;
    const divisionId = (division?.id && !isDefaultDivision) ? division.id : undefined;
    handleFetchAccountList(orgId, divisionId);
    division?.id && setSelectedDivision(division);
  };
  const handleRetryDivisionList = () => {
    fetchDivisionList();
  }

  const handleRaiseIntent = useHandleRaiseIntent(
    useGlobalDispatch,
    useNavigate
  );

  const selectPayment = useCallback(async (selectedPayment: TableData) => {
    const paymentId = selectedPayment?.id as string;
    if (!paymentId) return;
    await handleRaiseIntent({
      intentName: INTENT_NAMES.VIEW_GALAXY_PAYMENT_DETAILS,
      intentContextName: INTENTS_CONTEXT_NAME.PAYMENT,
      targetPath: PAGE_NAVIGATION.PAYMENT_DETAILS,
      data: { selectedPayment },
      contextKey: selectedPayment.receiptNumber as string,
      ...(isStaffPortal() && { viewOptions: viewOptionsPaymentDetails }),
    });
  }, []);

  const fetchPaymentsList = (data: SearchPaymentAccountDataType) => {
    if (data.dateRange) {
      const accountIds = selectedAccount?.accountId?.split(' ');
      const { fromAmount, toAmount } = data?.amountRange ?? {};
      const fromAmountFormatted = fromAmount ? formatToTwoDecimals(fromAmount) : "";
      const toAmountFormatted = toAmount ? formatToTwoDecimals(toAmount) : "";
      const postPaymentListingParams: PostPaymentListingParams = {
        ...(accountIds && accountIds.length > 1 && {
          accountId: {
            accountNumber: accountIds[1],
            BSB: accountIds[0],
          }
        }),
        paymentDirection: 'O',
        hasDivisions: showDivisionField,
        ...(fromAmountFormatted && toAmountFormatted && { amountRange: `btn:${fromAmountFormatted},${toAmountFormatted}` }),
        ...(data.paymentType !== 'All' && { paymentStatus: data?.paymentType }),
        ...(showDivisionField && selectedDivision?.id !== 'All' && { divisionId: selectedDivision?.id }),
      };

      const { startDate, endDate } = data.dateRange;
      const startDateUTC =
        startDate !== null ? convertSydneyLocalTimeToUtc(startDate) : '';
      const endDateUTC =
        endDate !== null ? convertSydneyLocalTimeToUtc(endDate, 'end') : '';
      const postPaymentQueryParams: PostPaymentListingQueryParams = {
        paymentDateTime: `btn:${startDateUTC},${endDateUTC}`,
      };

      const params: PostPaymentListingParamsPayload = {
        params: postPaymentListingParams,
        query: postPaymentQueryParams,
        meta: {
          replaceEntities: ['paymentListing'],
        },
      };
      getPaymentListing(params, {
        headers: {
          ...(orgId && {
            'protected-orgId': orgId,
          }),
        },
      });
    }
  };

  const fetchDivisionList = useCallback(() => {
    const params: getDivisionListParamsPayload = {
      pdpQueryAction: PDP_QUERY_ACTIONS.VIEW_PAYMENT,
      meta: {
        replaceEntities: ['divisionList'],
      },
    };

    if (!isDivisionListFetching) {
      getDivisionList(params, {
        headers: {
          ...(orgId && {
            'protected-orgId': orgId,
          }),
        },
      });
    }
  }, [isDivisionListFetching, orgId]);

  const onError: SubmitErrorHandler<SearchPaymentAccountDataType> = (
    data,
    e
  ) => {
    // TODO: ART-5122 Need to be removed in the future jira issue
    console.error('error: ', data, e);
  };

  const onAuthorisationError: SubmitErrorHandler<
    AuthorisationSearchFormType
  > = (data, e) => {
    console.error('error: ', data, e);
  };

  const onSubmit = (data: AuthorisationSearchFormType) => {
    // To set latest date picker values in OpenFin
    const dateRangeValues = authorisationGetValues('dateRange');

    const formData: AuthorisationSearchFormType = {
      ...data,
      authorisationTab: authorisationActiveTab,
      statusTab: statusActiveTab,
      dateRange: dateRangeValues,
    };
    setAuthorisationSearchFormData(formData);
    setApprovalWorkflowTrigger(Date.now());
  };

  const onRefresh = async () => {
    try {
      if (currentTabKey === PaymentStatusTab.Authorisations) {
        await authorisationHandleSubmit(onSubmit, onAuthorisationError)();
      } else if (currentTabKey === PaymentStatusTab.Processing) {
        await handleSubmit(fetchPaymentsList, onError)();
      }
    } catch (error) {
      console.error('Error during refresh:', error);
    }
  };

  const handleTabSelectionChange = async (key: string | Key) => {
    if (key !== currentTabKey) {
      setCurrentTabKey(key.toString());

      if (key === PaymentStatusTab.Processing) {
        try {
          await handleSubmit(fetchPaymentsList, onError)();
        } catch (error) {
          console.error('Error switching to processing tab:', error);
        }
      }

      if (key === PaymentStatusTab.Authorisations) {
        // on switching to authorisations tab, if item from typeahead component is selected and click on close icon,
        //  fromAccount will be null but selectedAccount will still have selected value
        const fromAccount = getValues('fromAccount');
        setSelectedAccount(fromAccount);
        await authorisationTrigger([
          'dateRange.startDate',
          'dateRange.endDate',
        ]);
        await authorisationHandleSubmit(onSubmit, onAuthorisationError)();
      }
    }
  };
  const onChangeAccount = (value: Account | null) => {
    setSelectedAccount(value ?? undefined);
    if (value) {
      setFormValues({ fromAccount: { ...value } });
      globalDispatch({
        type: 'galaxy/context/update',
        data: {
          selectedPaymentFormValues: { fromAccount: { ...value } },
        },
      });
    } else {
      setFormValues({ fromAccount: undefined });
      globalDispatch({
        type: 'galaxy/context/update',
        data: {
          selectedPaymentFormValues: { fromAccount: null },
        },
      });
    }
  };

  const handleSearchPaymentAccountSubmit = async (
    event: SyntheticEvent<HTMLButtonElement> | undefined
  ) => {
    event?.preventDefault();
    await handleSubmit(fetchPaymentsList, onError)();
  };

  const exportCsvHandler = () => {
    const currentDate = getFormattedDate(
      DateTime.now().toISO(),
      'yyyyLLdd',
      'date-time'
    );
    const fileName = `Payments-${currentDate}.csv`;
    mvTableRef.current?.exportCsv(fileName, true);
  };

  const handleAuthorisationButtonGroupChange = (
    val: AuthorisationTabValues
  ) => {
    setAuthorisationActiveTab(val);
    setIsPaymentsYouInitiatedTabSelected(val === AuthorisationTab.PaymentsYouInitiated);
  };

  const handleStatusButtonGroupChange = (val: StatusTabValues) => {
    setStatusActiveTab(val);
  };

  // Handle UI filters when apply button is clicked (search/submit)
  const handleAuthorisationAccordionSearch = async (
    event: React.MouseEvent
  ) => {
    event.preventDefault();
    await authorisationHandleSubmit(onSubmit, onAuthorisationError)();
  };

  const sortedList: PaymentListing[] = allPostPaymentListing.sort(
    (a: PaymentListing, b: PaymentListing) =>
      new Date(b.creationDateTime).getTime() -
      new Date(a.creationDateTime).getTime()
  );

  const memoisedSortedList = useMemo(() => sortedList, [allPostPaymentListing]);

  // reference: https://confluence.srv.westpac.com.au/display/ARTC/galaxy-maker-checker-widget-exp-v1#galaxymakercheckerwidgetexpv1-3.1.Request
  const postApprovalWorkflowListParams = useMemo(() => {
    const convertedDateRange = authorisationSearchFormData?.dateRange
      ? {
        fromDate: authorisationSearchFormData.dateRange.startDate
          ? convertSydneyLocalTimeToUtc(
            authorisationSearchFormData.dateRange.startDate
          )
          : undefined,
        toDate: authorisationSearchFormData.dateRange.endDate
          ? convertSydneyLocalTimeToUtc(
            authorisationSearchFormData.dateRange.endDate,
            'end'
          )
          : undefined,
      }
      : undefined;

    const baseParams = {
      types: [ApprovalWorkflowType.PAYMENTS],
      subTypes: ['payments', 'transfers'],
      requestGroup: 'Customer',
      approvalChannel: 'W1C-Customer',
    };
    const workflowStatus =
      authorisationSearchFormData?.statusTab === StatusTab.Pending
        ? ['ApprovalPending']
        : authorisationSearchFormData?.statusTab === StatusTab.Rejected
          ? ['Rejected']
          : ['ApprovalPending', 'Rejected'];

    return authorisationSearchFormData?.authorisationTab ===
      AuthorisationTab.ForYouToAuthorise
      ? {
        ...baseParams,
        workflowStatus,
        searchBy: 'ApproverAndCreatedOnDateRange',
        approverStatus: workflowStatus,
        createdOnDateRange: convertedDateRange,
      }
      : {
        ...baseParams,
        workflowStatus,
        searchBy: 'CreatedBy',
      };
  }, [authorisationSearchFormData]);

  const postStafApprovalWorkflowListParams = useMemo(() => {
    if (authorisationActiveTab === AuthorisationTab.ForYouToAuthorise) {
      return {
        searchBy: 'ApproverAndCreatedOnDateRange',
        createdOnDateRange: authorisationSearchFormData?.dateRange
          ? {
            fromDate: authorisationSearchFormData.dateRange.startDate
              ? convertSydneyLocalTimeToUtc(
                authorisationSearchFormData.dateRange.startDate
              )
              : undefined,
            toDate: authorisationSearchFormData.dateRange.endDate
              ? convertSydneyLocalTimeToUtc(
                authorisationSearchFormData.dateRange.endDate,
                'end'
              )
              : undefined,
          }
          : undefined,
        approverStatus: ['ApprovalPending', 'Rejected'],
        workflowStatus: ['ApprovalPending', 'Rejected'],
        types: ['w1cpayments'],
        subTypes: ['payments', 'transfers'],
        approvalChannel: 'W1C-Staff',
      };
    }
    if (authorisationActiveTab === AuthorisationTab.PaymentsYouInitiated) {
      return {
        searchBy: 'CreatedBy',
        workflowStatus: ['ApprovalPending', 'Rejected'],
        types: ['w1cpayments'],
        subTypes: ['payments', 'transfers'],
        approvalChannel: 'W1C-Staff',
      };
    }
    return undefined;
  }, [authorisationActiveTab]);

  const apiTrigger = useMemo(() => {
    return `${JSON.stringify(
      postApprovalWorkflowListParams
    )}-${approvalWorkflowTrigger}`;
  }, [postApprovalWorkflowListParams, approvalWorkflowTrigger]);

  const intentTimestamp: string = useGlobalSelector(
    // eslint-disable-next-line @typescript-eslint/no-unsafe-return
    (state: GlobalState) => state?.global?.galaxy?.context?.intentTimestamp
  );

  useEffect(() => {
    if (intentTimestamp) {
      handleTabSelectionChange(PaymentStatusTab.Authorisations);
    }
    // if updatedApprovalWorkflowId is set, user has just approved or rejected a workflow, need refresh table
    if (updatedApprovalWorkflowId) {
      // eslint-disable-next-line @typescript-eslint/no-floating-promises
      onRefresh();
    }
  }, [intentTimestamp, updatedApprovalWorkflowId]);

  useEffect(() => {
    if (
      isApprovalWorkflowListingFetching === false &&
      hasApprovalWorkflowListingError === false
    ) {
      setDateTimeAfterApiSuccess(getFormattedDateTime());
    }
  }, [isApprovalWorkflowListingFetching, hasApprovalWorkflowListingError]);

  useEffect(() => {
    if (isPaymentListingFetching === false && isPaymentListingError === false) {
      setDateTimeAfterApiSuccess(getFormattedDateTime());
    }
  }, [isPaymentListingFetching, isPaymentListingError]);

  useEffect(() => {
    if (isAccountListFetching === false && isAccountListError === false) {
      setDateTimeAfterApiSuccess(getFormattedDateTime());
    }
  }, [isAccountListFetching, isAccountListError]);

  useEffect(() => {
    if (isDivisionListFetching === false && isDivisionListError === false) {
      setDateTimeAfterApiSuccess(getFormattedDateTime());
    }
  }, [isDivisionListFetching, isDivisionListError]);


  return (
    <>
      <MVRefresh
        onRefresh={onRefresh}
        ref={refreshWidgetRef}
        lastSuccessfulDateTime={dateTimeAfterApiSuccess}
      />
      {alertMessages.map((alertMessage) => (
        <PaymentListAlert
          key={alertMessage.id}
          id={alertMessage.id}
          alertKeys={alertMessage.alertKeys}
          data={alertMessage.data}
        />
      ))}
      <GalaxyMakerCheckerWrapper
        apiName="postApprovalWorkflowList"
        params={{
          path: undefined,
          query: {
            pageSize: 100,
          },
          body: isStaffPortal()
            ? postStafApprovalWorkflowListParams
            : postApprovalWorkflowListParams,
        }}
        trigger={apiTrigger}
        onApiCallUpdate={(data) => {
          const { isLoading } = data;
          setIsApprovalWorkflowListingFetching(isLoading);
        }}
        onApiResponse={(res) => {
          const approvalWorkflowList = (
            res?.data as PostApprovalWorkflowListData
          )?.entities?.approvalWorkflowList;

          if (approvalWorkflowList) {
            const updatedData = mapApprovalWorkflowList(approvalWorkflowList);
            setAllPostApprovalWorkflowListing(updatedData);
            setHasApprovalWorkflowListingError(false);
          } else {
            setHasApprovalWorkflowListingError(true);
            console.error('API Error: error fetching approval workflow list');
          }
        }}
        onApiError={(err: any) => {
          setHasApprovalWorkflowListingError(true);
          console.error('API Error:', err);
        }}
      />
      <Tabs
        aria-label="Payment status"
        look="default"
        orientation="horizontal"
        className="border-b-0 pt-2.5"
        selectedKey={currentTabKey}
        onSelectionChange={handleTabSelectionChange}
      >
        <TabsPanel key="authorisations" title="Authorisations">
          {isInit ? (
            <PageLoader iconSize="medium" />
          ) : (
            <>
              <AuthorisationsSearchSection
                hasApprovalWorkflowListingError={
                  hasApprovalWorkflowListingError
                }
                isApprovalWorkflowListingFetching={
                  isApprovalWorkflowListingFetching
                }
                allPostApprovalWorkflowListing={allPostApprovalWorkflowListing}
                authorisationActiveTab={authorisationActiveTab}
                authorisationTabValues={authorisationTabValues}
                statusActiveTab={statusActiveTab}
                statusTabValues={statusTabValues}
                onAuthorisationChange={handleAuthorisationButtonGroupChange}
                onStatusChange={handleStatusButtonGroupChange}
                control={authorisationControl}
                setError={authorisationSetError}
                clearErrors={authorisationClearErrors}
                onAccordionSearch={handleAuthorisationAccordionSearch}
                isPaymentsYouInitiatedTabSelected={isPaymentsYouInitiatedTabSelected}
              />
              <div className="pt-2.5">
                <ApprovalWorkflowPanel
                  hasApprovalWorkflowListingError={
                    hasApprovalWorkflowListingError
                  }
                  isApprovalWorkflowListingFetching={
                    isApprovalWorkflowListingFetching
                  }
                  activeTab={
                    authorisationSearchFormData.authorisationTab ||
                    AuthorisationTab.ForYouToAuthorise
                  }
                  allPostApprovalWorkflowListing={
                    allPostApprovalWorkflowListing
                  }
                  handleRetryApprovalWorkflow={onRefresh}
                />
              </div>
            </>
          )}
        </TabsPanel>
        <TabsPanel key="processing" title="Sent for processing">
          <PaymentListAccountSearchSection
            hasAccountListError={hasAccountListError}
            isAccountListFetching={isAccountListFetching || isOrgIdFetching}
            handleRetryAccountList={handleRetryAccountList}
            control={control}
            trigger={trigger}
            setError={setError}
            clearErrors={clearErrors}
            fromAccountOptions={fromAccountOptions}
            handleSearchPaymentAccountSubmit={handleSearchPaymentAccountSubmit}
            onChangeAccount={onChangeAccount}
            divisions={divisions}
            showDivisionField={showDivisionField}
            isDivisionListFetching={!isStaffPortal() && isDivisionListFetching}
            isDivisionListError={isDivisionListError}
            onDivisionChange={onSelectDivision}
            handleRetryDivisionList={handleRetryDivisionList}
          />
          <PaymentListSection
            exportCsvHandler={exportCsvHandler}
            sortedList={memoisedSortedList}
            isPaymentListingFetching={isPaymentListingFetching}
            hasPaymentListingError={hasPaymentListingError}
            handleSearchPaymentAccountSubmit={handleSearchPaymentAccountSubmit}
            selectPayment={selectPayment}
            ref={mvTableRef as unknown as LegacyRef<HTMLInputElement>}
            allPaging={allPaging}
          />
        </TabsPanel>
      </Tabs>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  isAuthenticatedError: isAuthenticatedErrorSelector(state),
  allAccountList: getAllAccountList(state),
  isPaymentListingFetching: isPaymentListingFetchingSelector(state),
  allPostPaymentListing: getAllPaymentListing(state),
  isPaymentListingError: isPaymentCreateErrorSelector(state),
  isAccountListError: isAccountListErrorSelector(state),
  isAccountListFetching: isAccountListFetchingSelector(state),
  allPaging: getAllPaging(state),
  isDivisionListFetching: isDivisionListFetchingSelector(state),
  isDivisionListError: isDivisionListErrorSelector(state),
  allDivisionList: getAllDivisionList(state),
});

const mapDispatchToProps = {
  clearAccountList:
    accountListEntityActions.galaxyPayment.accountList.clear.request,
  accountListRequest:
    accountListActions.api.expGalaxyPaymentV2.accountList.get.request,
  getPaymentListing:
    paymentListingActions.api.expGalaxyPaymentV2.paymentListing.post.request,
  clearPaymentListing:
    paymentListingEntityActions.galaxyPayment.paymentListing.clear.error
      .request,
  getDivisionList:
    divisionListActions.api.expGalaxyPaymentV2.divisionList.get.request,
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps, null, {
    context: store.contextRef,
  })
)(PaymentListContainer);
