/* eslint-disable @typescript-eslint/no-unsafe-return */
import React from 'react';
import { render, screen } from '@testing-library/react';
import { PaymentListSection } from './PaymentListSection';
import { PaymentListing, Paging } from '../../store/types';
import { MAX_TRANSACTIONS_LOAD } from '../../common/constants';

const defaultProps = {
  isPaymentListingFetching: false,
  hasPaymentListingError: false,
  handleSearchPaymentAccountSubmit: jest.fn(),
  tableVisible: true,
  sortedList: [] as PaymentListing[],
  exportCsvHandler: jest.fn(),
  selectPayment: jest.fn(),
};

global.ResizeObserver = class {
  observe() { }
  unobserve() { }
  disconnect() { }
};

jest.mock('@mep-ui/framework-router-addon', () => {
  const mockNavigate = jest.fn();
  return {
    ...jest.requireActual('@mep-ui/framework-router-addon'),
    useNavigate: () => mockNavigate,
  };
});

const mockGlobalDispatch = jest.fn();
const mockGlobalSelector = jest.fn();

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  ssoActions: {
    sso: {
      signout: {
        request: jest.fn(),
      },
    },
  },
  useGlobalDispatch: () => mockGlobalDispatch,
  useGlobalSelector: () => mockGlobalSelector,
}));

jest.mock('../../store/store', () => ({
  __esModule: true,
  default: {
    dispatch: jest.fn(),
  },
}));

describe('PaymentListSection - showMaxLoadInfoMessage', () => {
  it('shows info Alert when showMaxLoadInfoMessage is true (count > MAX_TRANSACTIONS_LOAD)', () => {
    const allPaging: Paging[] = [
      {
        count: MAX_TRANSACTIONS_LOAD + 1,
        id: '',
        pageSize: 0,
        previousPageKey: '',
        nextPageKey: '',
      },
    ];
    render(<PaymentListSection {...defaultProps} allPaging={allPaging} />);
    expect(screen.getByText(/more results available/i)).toBeInTheDocument();
  });

  it('does not show info Alert when showMaxLoadInfoMessage is false (count < MAX_TRANSACTIONS_LOAD)', () => {
    const allPaging: Paging[] = [
      {
        count: MAX_TRANSACTIONS_LOAD - 1,
        id: '',
        pageSize: 0,
        previousPageKey: '',
        nextPageKey: '',
      },
    ];
    render(<PaymentListSection {...defaultProps} allPaging={allPaging} />);
    expect(
      screen.queryByText(/more results available/i)
    ).not.toBeInTheDocument();
  });

  it('does not show info Alert when showMaxLoadInfoMessage is false (count = MAX_TRANSACTIONS_LOAD)', () => {
    const allPaging: Paging[] = [
      {
        count: MAX_TRANSACTIONS_LOAD,
        id: '',
        pageSize: 0,
        previousPageKey: '',
        nextPageKey: '',
      },
    ];
    render(<PaymentListSection {...defaultProps} allPaging={allPaging} />);
    expect(
      screen.queryByText(/more results available/i)
    ).not.toBeInTheDocument();
  });

  it('does not show info Alert when allPaging is undefined', () => {
    render(<PaymentListSection {...defaultProps} allPaging={undefined} />);
    expect(
      screen.queryByText(/more results available/i)
    ).not.toBeInTheDocument();
  });
});
