import { MVAccordion } from '@mesh-tenant-multiverse-ui-common/mv-accordion';
import { MVDateRangePickerController } from '@mesh-tenant-multiverse-ui-common/mv-reacthookform';
import { GridItem, ButtonGroup } from '@westpac/ui';
import React from 'react';
import {
  AuthorisationSearchFormType,
  AuthorisationTabOption,
  AuthorisationTabValues,
  StatusTabOption,
  StatusTabValues,
} from 'ui/src/common/types';
import { ApprovalWorkflowListing } from 'ui/src/store/types/ApprovalWorkflowListing';

import { Control, UseFormSetError, UseFormClearErrors } from 'react-hook-form';

type Props = {
  hasApprovalWorkflowListingError?: boolean;
  isApprovalWorkflowListingFetching: boolean;
  allPostApprovalWorkflowListing?: ApprovalWorkflowListing[];
  authorisationActiveTab: AuthorisationTabValues;
  authorisationTabValues: AuthorisationTabOption[];
  statusActiveTab: StatusTabValues;
  statusTabValues: StatusTabOption[];
  onAuthorisationChange?: (value: AuthorisationTabValues) => void;
  onStatusChange?: (value: StatusTabValues) => void;
  control: Control<AuthorisationSearchFormType>;
  setError: UseFormSetError<AuthorisationSearchFormType>;
  clearErrors: UseFormClearErrors<AuthorisationSearchFormType>;
  onAccordionSearch: (event: React.MouseEvent) => void;
  isPaymentsYouInitiatedTabSelected?: boolean;
};

function AuthorisationsSearchSection({
  isApprovalWorkflowListingFetching,
  authorisationActiveTab,
  authorisationTabValues,
  statusActiveTab,
  statusTabValues,
  onAuthorisationChange,
  onStatusChange,
  control,
  setError,
  clearErrors,
  onAccordionSearch,
  isPaymentsYouInitiatedTabSelected
}: Props) {
  return (
    <MVAccordion
      defaultExpanded
      onButtonClick={onAccordionSearch}
      loading={isApprovalWorkflowListingFetching}
    >
      <GridItem span={12}>
        <ButtonGroup
          className="-mb-2"
          look="hero"
          size="small"
          label="Authorisation"
          value={authorisationActiveTab}
          buttons={authorisationTabValues}
          onChange={(value: string) =>
            onAuthorisationChange?.(value as AuthorisationTabValues)
          }
        />
      </GridItem>
      <GridItem span={12} className="w-fit">
        <ButtonGroup
          className="-mb-2 whitespace-nowrap"
          look="hero"
          size="small"
          label="Status"
          value={statusActiveTab}
          buttons={statusTabValues}
          onChange={(value: string) =>
            onStatusChange?.(value as StatusTabValues)
          }
        />
      </GridItem>
      {/* ART-97614 - hide date picker if on Payments You Selected tab */}
      {!isPaymentsYouInitiatedTabSelected && (
        <GridItem span={12} className="w-fit">
          <MVDateRangePickerController
            data-testid='date-range-picker'
            fieldName="dateRange"
            control={control}
            setError={setError}
            clearErrors={clearErrors}
            earliestYear={3}
            earliestInvalidMessage="Select a date range within the last 3 years."
          />
        </GridItem>
      )}
    </MVAccordion>
  );
}

export default AuthorisationsSearchSection;
