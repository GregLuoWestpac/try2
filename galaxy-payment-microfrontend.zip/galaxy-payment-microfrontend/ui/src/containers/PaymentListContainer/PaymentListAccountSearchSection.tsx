import { MVPageLoader as PageLoader } from '@mesh-tenant-multiverse-ui-common/mv-pageloader';
import { Alert, Button } from '@westpac/ui';
import { FC, SyntheticEvent } from 'react';
import {
  Control,
  FieldValues,
  UseFormClearErrors,
  UseFormSetError,
  UseFormTrigger,
} from 'react-hook-form';
import { genericErrorMessage } from '../../common/constants';
import { SearchPaymentAccountDataType, DivisionOptionType } from '../../common/types';
import { AccountSearchSection } from '../../components/AccountSearchSection';
import { Account } from '../../store/types';

type Props = {
  hasAccountListError: boolean;
  isAccountListFetching: boolean;
  handleRetryAccountList: () => void;
  control: Control<SearchPaymentAccountDataType, any>;
  trigger: UseFormTrigger<SearchPaymentAccountDataType>;
  setError: UseFormSetError<SearchPaymentAccountDataType>;
  clearErrors: UseFormClearErrors<SearchPaymentAccountDataType>;
  fromAccountOptions: Account[];
  handleSearchPaymentAccountSubmit: (
    event: SyntheticEvent<HTMLButtonElement> | undefined
  ) => Promise<void>;
  onChangeAccount: (value: Account | null) => void;
  divisions: DivisionOptionType[];
  showDivisionField: boolean;
  isDivisionListFetching: boolean;
  isDivisionListError: boolean;
  onDivisionChange?: (selectedOption?: DivisionOptionType) => void;
  handleRetryDivisionList: () => void;
};

export const PaymentListAccountSearchSection: FC<Props> = ({
  hasAccountListError,
  isAccountListFetching,
  handleRetryAccountList,
  control,
  trigger,
  setError,
  clearErrors,
  fromAccountOptions,
  handleSearchPaymentAccountSubmit,
  onChangeAccount,
  divisions,
  showDivisionField,
  isDivisionListFetching,
  isDivisionListError,
  onDivisionChange,
  handleRetryDivisionList,
}) => {

  if (isAccountListFetching || isDivisionListFetching) {
    return (
      <div className="mt-2.5">
        <PageLoader iconSize="medium" />
      </div>
    );
  }

  return (
    <form autoComplete="off">
      <AccountSearchSection
        control={control as unknown as Control<FieldValues>}
        trigger={trigger}
        listOptions={fromAccountOptions}
        handleSubmit={handleSearchPaymentAccountSubmit}
        onChangeAccount={onChangeAccount}
        setError={setError}
        clearErrors={clearErrors}
        divisions={divisions}
        showDivisionField={showDivisionField}
        isDivisionListFetching={isDivisionListFetching}
        isDivisionListError={isDivisionListError}
        onDivisionChange={onDivisionChange}
        handleRetryDivisionList={handleRetryDivisionList}
        hasAccountListError={hasAccountListError}
        handleRetryAccountList={handleRetryAccountList}
      />
    </form>
  );
};

export default PaymentListAccountSearchSection;
