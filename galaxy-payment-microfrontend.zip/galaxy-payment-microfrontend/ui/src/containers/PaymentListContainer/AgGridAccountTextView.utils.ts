import { formatBSBFromAccNo } from '@mesh-tenant-multiverse-ui-common/mv-utils';

export const getAccountNumber = (accountId: string) => {
  const accountNumber = formatBSBFromAccNo(accountId);
  return `${accountNumber}`;
};
