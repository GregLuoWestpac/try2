/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import '@testing-library/jest-dom';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ApprovalWorkflowListing } from '../../store/types';
import {
  ApprovalWorkflowTable,
  type ApprovalWorkflowTableProps,
} from './ApprovalWorkflowTable';

const mockHandleRaiseIntent = jest.fn();
const mockUseGlobalDispatch = jest.fn();
const mockUseNavigate = jest.fn();

jest.mock('@mep-ui/framework', () => ({
  useGlobalDispatch: () => mockUseGlobalDispatch,
}));

jest.mock('@mep-ui/framework-router-addon', () => ({
  useNavigate: () => mockUseNavigate,
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-table-v2', () => ({
  CellClickedEventV2: jest.fn(),
  CellKeyDownEventV2: jest.fn(),
  ColDefV2: jest.fn(),
  GetContextMenuItemsParamsV2: jest.fn(),
  MVTableV2: ({
    onCellClicked,
    onCellKeyDown,
    getContextMenuItems,
    rowData,
    ...props
  }: any) => {
    const handleCellClick = () => {
      if (rowData && rowData.length > 0) {
        onCellClicked({ data: rowData[0] });
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (rowData && rowData.length > 0) {
        onCellKeyDown({ data: rowData[0], event });
      }
    };

    const handleContextMenu = () => {
      if (rowData && rowData.length > 0) {
        const menuItems = getContextMenuItems({ node: { data: rowData[0] } });
        // Simulate clicking the first menu item action
        if (menuItems && menuItems.length > 0 && menuItems[0].action) {
          menuItems[0].action();
        }
        return menuItems;
      }
    };

    return (
      <div>
        <button data-testid="cell-click" onClick={handleCellClick}>
          Click Cell
        </button>
        <button
          data-testid="cell-keydown"
          onKeyDown={(e) => handleKeyDown(e.nativeEvent)}
        >
          Key Down Cell
        </button>
        <button data-testid="context-menu" onClick={handleContextMenu}>
          Context Menu
        </button>
        Mock MVTable
      </div>
    );
  },
  TableDataV2: jest.fn(),
  suppressHeaderKeyboardEventV2: jest.fn(),
  suppressKeyboardEventV2: jest.fn(),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  useHandleRaiseIntent: () => mockHandleRaiseIntent,
}));

jest.mock('./PaymentListContainer.utils', () => ({
  buildAuthTabColumnDefs: jest.fn(() => []),
}));

jest.mock('../../common/constants', () => ({
  AuthorisationTab: {
    ForYouToAuthorise: 'ForYouToAuthorise',
    PaymentsYouInitiated: 'PaymentsYouInitiated',
  },
  INTENT_NAMES: {
    VIEW_GALAXY_PAYMENT_TASK_DETAILS: 'ViewGalaxyPaymentTaskDetails',
  },
  INTENTS_CONTEXT_NAME: {
    PAYMENT: 'fdc3.nothing',
  },
  PAGE_NAVIGATION: {
    PAYMENT_TASK_DETAILS: '/payment/payment-task-details',
  },
  WorkFlowStatusMap: {
    ApprovalPending: 'Pending authorisation',
    ApprovalApproved: 'Approved',
    ApprovalRejected: 'Rejected',
  },
  noPaymentsRowMessage: 'No payments found',
}));

jest.mock('../../store/types/RootStates', () => ({
  SearchBy: {
    ApproverAndCreatedOnDateRange: 'ApproverAndCreatedOnDateRange',
    CreatedBy: 'CreatedBy',
  },
}));

const mockPostApprovalWorkflowListing: ApprovalWorkflowListing[] = [
  {
    id: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
    status: 'Pending authorisation',
    creationDateTime: '2024-08-12T01:00:05.378Z',
    amount: '2500.15',
    currency: 'AUD',
    debitAccountName: 'Debtor Account Nick Name 1',
    debitAccountIdentification: '111111000001',
    debitDescription: 'PaymentInformationId',
    creditAccountName: 'Creditor Account Nick Name 1',
    creditAccountIdentification: '222222000001',
    paymentMethod: 'Funds transfer',
    receiptNumber: 'ReceiptId_1',
    instructionTraceIdentification: 'InstructionTraceIdentification_1',
    beneficiaryName: '',
    approvers: [
      {
        userId: 'string',
      },
    ],
  },
];

const defaultProps: ApprovalWorkflowTableProps = {
  allPostApprovalWorkflowListing: mockPostApprovalWorkflowListing,
  makerCheckerActionToggle: 'ForYouToAuthorise',
};

describe('ApprovalWorkflowTable', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockHandleRaiseIntent.mockResolvedValue(undefined);
  });

  it('renders without crashing', () => {
    const { asFragment } = render(<ApprovalWorkflowTable {...defaultProps} />);
    expect(asFragment()).toMatchSnapshot();
  });

  it('displays MVTable with correct props', () => {
    render(<ApprovalWorkflowTable {...defaultProps} />);
    expect(screen.getByText('Mock MVTable')).toBeInTheDocument();
  });

  it('calls raiseIntentForAction when cell is clicked with ForYouToAuthorise tab', async () => {
    const user = userEvent.setup();
    render(<ApprovalWorkflowTable {...defaultProps} />);

    const cellClickButton = screen.getByTestId('cell-click');
    await user.click(cellClickButton);

    expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
      intentName: 'ViewGalaxyPaymentTaskDetails',
      intentContextName: 'fdc3.nothing',
      targetPath: '/payment/payment-task-details',
      data: {
        approvalWorkflowId: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
        searchBy: 'ApproverAndCreatedOnDateRange',
      },
      contextKey: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
    });
  });

  it('calls raiseIntentForAction when cell is clicked with PaymentsYouInitiated tab', async () => {
    const user = userEvent.setup();
    render(
      <ApprovalWorkflowTable
        {...defaultProps}
        makerCheckerActionToggle="PaymentsYouInitiated"
      />
    );

    const cellClickButton = screen.getByTestId('cell-click');
    await user.click(cellClickButton);

    expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
      intentName: 'ViewGalaxyPaymentTaskDetails',
      intentContextName: 'fdc3.nothing',
      targetPath: '/payment/payment-task-details',
      data: {
        approvalWorkflowId: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
        searchBy: 'CreatedBy',
      },
      contextKey: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
    });
  });

  it('calls raiseIntentForAction when Enter key is pressed on cell', async () => {
    const user = userEvent.setup();
    render(<ApprovalWorkflowTable {...defaultProps} />);

    const cellKeydownButton = screen.getByTestId('cell-keydown');
    await user.type(cellKeydownButton, '{Enter}');

    expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
      intentName: 'ViewGalaxyPaymentTaskDetails',
      intentContextName: 'fdc3.nothing',
      targetPath: '/payment/payment-task-details',
      data: {
        approvalWorkflowId: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
        searchBy: 'ApproverAndCreatedOnDateRange',
      },
      contextKey: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
    });
  });

  it('provides context menu with "View payment details" action for ForYouToAuthorise tab', async () => {
    const user = userEvent.setup();
    render(<ApprovalWorkflowTable {...defaultProps} />);

    const contextMenuButton = screen.getByTestId('context-menu');
    await user.click(contextMenuButton);

    expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
      intentName: 'ViewGalaxyPaymentTaskDetails',
      intentContextName: 'fdc3.nothing',
      targetPath: '/payment/payment-task-details',
      data: {
        approvalWorkflowId: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
        searchBy: 'ApproverAndCreatedOnDateRange',
      },
      contextKey: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
    });
  });

  it('provides context menu with "View payment details" action for PaymentsYouInitiated tab', async () => {
    const user = userEvent.setup();
    // Use a mock item with status 'Approved' so the context menu item is present
    const approvedItem = {
      ...mockPostApprovalWorkflowListing[0],
      status: 'Approved',
    };
    render(
      <ApprovalWorkflowTable
        allPostApprovalWorkflowListing={[approvedItem]}
        makerCheckerActionToggle="PaymentsYouInitiated"
      />
    );

    const contextMenuButton = screen.getByTestId('context-menu');
    await user.click(contextMenuButton);

    expect(mockHandleRaiseIntent).toHaveBeenCalledWith({
      intentName: 'ViewGalaxyPaymentTaskDetails',
      intentContextName: 'fdc3.nothing',
      targetPath: '/payment/payment-task-details',
      data: {
        approvalWorkflowId: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
        searchBy: 'CreatedBy',
      },
      contextKey: 'b811e8d8-cf6d-4a49-86c3-38dd27e1d4f8',
    });
  });

  it('does not call raiseIntentForAction when workflow has no id', async () => {
    const workflowWithoutId: ApprovalWorkflowListing[] = [
      {
        ...mockPostApprovalWorkflowListing[0],
        id: undefined as any,
      },
    ];

    const user = userEvent.setup();
    render(
      <ApprovalWorkflowTable
        {...defaultProps}
        allPostApprovalWorkflowListing={workflowWithoutId}
      />
    );

    const cellClickButton = screen.getByTestId('cell-click');
    await user.click(cellClickButton);

    expect(mockHandleRaiseIntent).not.toHaveBeenCalled();
  });

  it('handles empty workflow listing', () => {
    render(
      <ApprovalWorkflowTable
        {...defaultProps}
        allPostApprovalWorkflowListing={[]}
      />
    );
    expect(screen.getByText('Mock MVTable')).toBeInTheDocument();
  });

  it('uses correct searchBy value based on authorisation tab', () => {
    const { rerender } = render(<ApprovalWorkflowTable {...defaultProps} />);

    // Test ForYouToAuthorise tab uses Approver searchBy
    expect(defaultProps.makerCheckerActionToggle).toBe('ForYouToAuthorise');

    // Test PaymentsYouInitiated tab uses CreatedBy searchBy
    rerender(
      <ApprovalWorkflowTable
        {...defaultProps}
        makerCheckerActionToggle="PaymentsYouInitiated"
      />
    );
    expect(screen.getByText('Mock MVTable')).toBeInTheDocument();
  });

  it('renders table with correct column definitions', () => {
    render(<ApprovalWorkflowTable {...defaultProps} />);
    expect(screen.getByText('Mock MVTable')).toBeInTheDocument();
    // The buildAuthTabColumnDefs mock should be called
    const { buildAuthTabColumnDefs } = require('./PaymentListContainer.utils');
    expect(buildAuthTabColumnDefs).toHaveBeenCalled();
  });
});
