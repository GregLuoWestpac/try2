/* eslint-disable react/no-unescaped-entities */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { ReactNode } from 'react';
import {
  ColDefV2 as ColDef,
  COMMON_COLUMN_DEFS,
  CustomColDef,
} from '@mesh-tenant-multiverse-ui-common/mv-table-v2';
import { getFormattedDate } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { BannerAlertBoxProps } from '../../galaxy-common/BannerAlertBox/BannerAlertBox';
import {
  alertMessageMapperForLimits,
  getAlertMessageKeyForLimit,
} from '../PaymentTaskDetailsContainer/PaymentTaskDetailsCard/PaymentTaskDetailsCard.utils';
import { PaymentListContainerAlerts } from './PaymentListContainer.constant';

/* eslint-disable @typescript-eslint/no-explicit-any */
import { apiGenericErrorTryAgainLater, AuthorisationTab, StatusTab } from '../../common/constants';
import {
  AuthorisationTabOption,
  validatePaymentLimitsResult,
  PaymentPayload,
  SupplementaryDataType,
  StatusTabOption,
} from '../../common/types';
import {
  convertWorkflowStatusToDisplay,
  getPaymentMethodDescription,
  parseIdFromEntitlements,
} from '../../common/utils';
import PaymentStatus from '../../components/PaymentStatus';
import { ApprovalWorkflow } from '../../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types';
import AgGridAccountTextView from './AgGridAccountTextView';
import { getAccountNumber } from './AgGridAccountTextView.utils';

const CUSTOM_COMMON_DEFS: { [key: string]: (params?: any) => CustomColDef } =
  Object.fromEntries(
    Object.entries(COMMON_COLUMN_DEFS).map(([key, fn]) => [
      key,
      (params?: any) => ({ ...fn(params) }),
    ])
  ) as { [key: string]: (params?: any) => CustomColDef };

const commonTextFilterParams = {
  filterParams: {
    filterOptions: ['contains'],
  },
  sortable: true,
};

export const buildColumnDefs = (): ColDef[] => {
  const {
    valueDate,
    fromAccount,
    toAccount,
    amount,
    currency,
    debitDescription,
    paymentMethod,
    status,
    paymentId,
  } = CUSTOM_COMMON_DEFS;

  return [
    valueDate({
      minWidth: 96,
      maxWidth: 96,
      width: 96,
      filterValueGetter: (params: {
        data: { creationDateTime: string | undefined };
      }) =>
        new Date(
          getFormattedDate(
            params.data.creationDateTime,
            'd LLL yyyy',
            'date-time',
            true
          )
        ),
    }),
    status({
      cellRenderer: PaymentStatus,
      minWidth: 51,
      filter: 'agSetColumnFilter',
      filterParams: {
        suppressSelectAll: true,
      },
      sortable: true,
      suppressColumnsToolPanel: false,
    }),
    fromAccount({
      cellRenderer: (params: {
        value: string;
        data: {
          creditAccountIdentification: string;
          debitAccountIdentification: string;
          beneficiaryName: string;
          supplementaryData?: SupplementaryDataType;
        };
      }) =>
        AgGridAccountTextView(
          { value: params.value, data: params.data },
          'From account'
        ),
      minWidth: 140,
      width: 140,
      flex: 1,
      sortable: true,
      resizable: true,
      filterParams: {
        filterOptions: ['contains'],
      },
      excludeFromExport: true,
    }),
    toAccount({
      cellRenderer: (params: {
        value: string;
        data: {
          creditAccountIdentification: string;
          debitAccountIdentification: string;
          beneficiaryName: string;
          supplementaryData?: SupplementaryDataType;
        };
      }) =>
        AgGridAccountTextView(
          { value: params.value, data: params.data },
          'To account'
        ),
      minWidth: 140,
      width: 140,
      sortable: true,
      resizable: true,
      filterParams: {
        filterOptions: ['contains'],
      },
      excludeFromExport: true,
    }),
    {
      headerName: 'From account - Name',
      field: 'debitAccountName',
      hide: true,
    },
    {
      headerName: 'From account - Account number',
      field: 'debitAccountIdentification',
      valueGetter: (params: {
        data: {
          debitAccountIdentification: string;
        };
      }) => {
        if (params?.data?.debitAccountIdentification) {
          return getAccountNumber(params.data.debitAccountIdentification);
        }
        return '';
      },
      hide: true,
    },
    {
      headerName: 'To account - Name',
      field: 'creditAccountName',
      hide: true,
    },
    {
      headerName: 'To account - Account details',
      field: 'creditAccountIdentification',
      valueGetter: (params: {
        data: {
          creditAccountIdentification: string;
          supplementaryData?: SupplementaryDataType;
        };
      }) => {
        if (params?.data?.creditAccountIdentification) {
          return getAccountNumber(params.data.creditAccountIdentification);
        }
        if (params?.data?.supplementaryData?.aliasId) {
          return params.data.supplementaryData.aliasId;
        }
        return '';
      },
      hide: true,
    },
    currency({
      minWidth: 56,
      maxWidth: 56,
      width: 56,
      sortable: true,
      resizable: false,
      filterParams: {
        filterOptions: ['contains'],
      },
    }),
    amount({
      minWidth: 70,
      filter: 'agNumberColumnFilter',
      filterParams: {
        filterOptions: [
          'equals',
          'lessThan',
          'lessThanOrEqual',
          'greaterThan',
          'greaterThanOrEqual',
        ],
      },
      sortable: true,
    }),
    paymentMethod({
      minWidth: 90,
      width: 90,
      filter: 'agSetColumnFilter',
      filterParams: {
        suppressSelectAll: true,
      },
      sortable: true,
    }),
    debitDescription({
      minWidth: 110,
      width: 110,
      filterParams: {
        filterOptions: ['contains'],
      },
      sortable: true,
    }),
    paymentId({
      minWidth: 57,
      width: 140,
      filterParams: {
        filterOptions: ['contains'],
      },
      sortable: true,
    }),
  ];
};

export const authorisationTabValues: AuthorisationTabOption[] = [
  { value: AuthorisationTab.ForYouToAuthorise, label: 'For you to authorise' },
  {
    value: AuthorisationTab.PaymentsYouInitiated,
    label: 'Payments you initiated',
  },
] as const;

export const statusTabValues: StatusTabOption[] = [
  { value: StatusTab.All, label: 'All' },
  { value: StatusTab.Pending, label: 'Pending authorisation' },
  { value: StatusTab.Rejected, label: 'Rejected by authoriser' },
];
export const buildAuthTabColumnDefs = (): ColDef[] => {
  const {
    fromAccount,
    toAccount,
    amount,
    currency,
    debitDescription,
    paymentMethod,
    status,
    submittedDate: createdDate,
    paymentId,
    actions,
  } = COMMON_COLUMN_DEFS;

  return [
    createdDate({
      headerName: 'Created date',
      filterValueGetter: (params: {
        data: { creationDateTime: string | undefined };
      }) =>
        new Date(
          getFormattedDate(
            params.data.creationDateTime,
            'd LLL yyyy',
            'date-time',
            true
          )
        ),
      minWidth: 96,
      maxWidth: 96,
      width: 96,
    }),
    status({
      cellRenderer: PaymentStatus,
      filter: 'agSetColumnFilter',
      filterParams: {
        suppressSelectAll: true,
      },
      sortable: true,
      suppressColumnsToolPanel: false,
      minWidth: 96,
      maxWidth: 110,
    }),
    fromAccount({
      cellRenderer: (params: {
        value: string;
        data: {
          creditAccountIdentification: string;
          debitAccountIdentification: string;
          beneficiaryName: string;
          supplementaryData?: SupplementaryDataType;
        };
      }) =>
        AgGridAccountTextView(
          { value: params.value, data: params.data },
          'From account'
        ),
      flex: 1,
      ...commonTextFilterParams,
      resizable: true,
      minWidth: 140,
      width: 140,
    }),
    toAccount({
      cellRenderer: (params: {
        value: string;
        data: {
          creditAccountIdentification: string;
          debitAccountIdentification: string;
          beneficiaryName: string;
          supplementaryData?: SupplementaryDataType;
        };
      }) =>
        AgGridAccountTextView(
          { value: params.value, data: params.data },
          'To account'
        ),
      ...commonTextFilterParams,
      minWidth: 140,
      width: 140,
      resizable: true,
    }),
    currency({
      ...commonTextFilterParams,
      resizable: false,
      minWidth: 56,
      maxWidth: 56,
      width: 56,
    }),
    amount({
      filter: 'agNumberColumnFilter',
      filterParams: {
        filterOptions: [
          'equals',
          'lessThan',
          'lessThanOrEqual',
          'greaterThan',
          'greaterThanOrEqual',
        ],
      },
      sortable: true,
      minWidth: 100,
    }),
    paymentMethod({
      filter: 'agSetColumnFilter',
      filterParams: {
        suppressSelectAll: true,
      },
      sortable: true,
      minWidth: 90,
      width: 90,
    }),
    debitDescription({
      ...commonTextFilterParams,
      minWidth: 110,
      width: 110,
    }),
    paymentId({
      ...commonTextFilterParams,
      minWidth: 57,
      width: 140,
    }),
    actions({
      minWidth: 64,
      width: 64,
    }),
  ];
};

// reference: https://confluence.srv.westpac.com.au/display/ARTC/Authorisations+UI+-+Exp+API+Mapping+for+Payments
export const mapApprovalWorkflowList = (
  approvalWorkflowList: ApprovalWorkflow[]
): any[] => {
  if (!Array.isArray(approvalWorkflowList)) return [];
  return approvalWorkflowList.map((workflow) => {
    const payloadObject = workflow?.payloadObject as PaymentPayload | undefined;
    const creditTransferTransactionInformation =
      payloadObject?.creditTransferTransactionInformation?.[0];
    const debtorAccount = payloadObject?.debtorAccount;
    const supplementaryData = payloadObject?.supplementaryData;
    const paymentMethodDescription = getPaymentMethodDescription(payloadObject);

    const { instructedAmount, creditor, creditorAccount } =
      creditTransferTransactionInformation ?? {};
    const workflowStatus = convertWorkflowStatusToDisplay(
      workflow?.workflowStatus
    );

    return {
      id: workflow?.approvalWorkflowId ?? '',
      status: workflowStatus ?? '',
      creationDateTime: workflow?.createdDateTime ?? '',
      amount: Number(instructedAmount?.amount) ?? '',
      currency: instructedAmount?.currency ?? '',
      debitAccountName: debtorAccount?.name ?? '',
      debitAccountIdentification: debtorAccount?.identification ?? '',
      debitDescription: supplementaryData?.debitDescription ?? '',
      beneficiaryName: creditor?.name ?? '',
      creditAccountName: creditorAccount?.name ?? '',
      creditAccountIdentification: creditorAccount?.identification ?? '',
      paymentMethod: paymentMethodDescription ?? '',
      receiptNumber:
        parseIdFromEntitlements(workflow?.entitlementsPayload) ?? '',
      instructionTraceIdentification: '',
      supplementaryData: {
        aliasId:
          creditTransferTransactionInformation?.supplementaryData?.aliasId ??
          '',
        aliasType:
          creditTransferTransactionInformation?.supplementaryData?.aliasType ??
          '',
      },
      approvers: workflow?.approvers ?? [],
    };
  });
};

export type AlertMessageProps = {
  renderMessage: (props?: {
    amountStr?: string;
    paymentId?: string;
    errors?: validatePaymentLimitsResult[];
  }) => ReactNode;
  styling: BannerAlertBoxProps['styling'];
}

/**
 * reference: https://confluence.srv.westpac.com.au/display/ARTC/W1+Copy+Register+-+Customer+Portal#186417993484cd215429b44f5ea2ba7d56c6105a18
 * for keys, please refer to alertKeyMap
 * */
export const alertMessageMapper = {
  SUCCESS_PAYMENT_AUTHORISE_PARTIALLY_AUTHORISED: {
    styling: 'success',
    renderMessage: ({ amountStr }: { amountStr?: string } = {}) => (
      <span>
        You have authorised the payment of <b>${amountStr}</b>. This payment is
        now <b>partially authorised</b>.
      </span>
    ),
  },
  SUCCESS_PAYMENT_AUTHORISE_AUTHORISED: {
    styling: 'success',
    renderMessage: ({ amountStr }: { amountStr?: string } = {}) => (
      <span>
        You have authorised the payment of <b>${amountStr}</b>. This payment is
        now <b>fully authorised</b> and has been <b>submitted for processing</b>
        .
      </span>
    ),
  },
  FAILED_PAYMENT_AUTHORISE_API_ERROR: {
    styling: 'danger',
    renderMessage: ({ amountStr }: { amountStr?: string } = {}) => (
      <span>
        Unable to authorise the payment of <b>${amountStr}</b>. Please try again
        later.
      </span>
    ),
  },
  SUCCESS_PAYMENT_AUTHORISE_PDP_DSR_FAIL: {
    styling: 'success',
    renderMessage: ({ amountStr }: { amountStr?: string } = {}) => (
      <span>
        You have authorised the payment of <b>${amountStr}</b> and it has been <b>submitted for processing</b>.
        <br />
        <b>Note:</b> The request will continue to display as 'Pending authorisation' until it expires. No action is required.
      </span>
    ),
  },


  SUCCESS_PAYMENT_REJECT: {
    styling: 'success',
    renderMessage: ({ amountStr }: { amountStr?: string } = {}) => (
      <span>
        You have rejected the payment of <b>${amountStr}</b>.
      </span>
    ),
  },
  FAILED_PAYMENT_REJECT_API_ERROR: {
    styling: 'danger',
    renderMessage: ({ amountStr }: { amountStr?: string } = {}) => (
      <span>
        Unable to reject the payment of <b>${amountStr}</b>. Please try again
        later.
      </span>
    ),
  },
  FAILED_PAYMENT_AUTHORISE_TASK_IS_NO_LONGER_AVAILABLE: {
    styling: 'danger',
    renderMessage: ({ amountStr }: { amountStr?: string } = {}) => (
      <span>
        Unable to authorise the payment of <b>${amountStr}</b>. This payment is
        already authorised or rejected.
      </span>
    ),
  },
  FAILED_PAYMENT_REJECT_TASK_IS_NO_LONGER_AVAILABLE: {
    styling: 'danger',
    renderMessage: ({ amountStr }: { amountStr?: string } = {}) => (
      <span>
        Unable to reject the payment of <b>${amountStr}</b>. This payment is
        already authorised or rejected.
      </span>
    ),
  },
  FAILED_TRANSFER_AUTHORISE_TASK_IS_NO_LONGER_AVAILABLE: {
    styling: 'danger',
    renderMessage: ({ amountStr }: { amountStr?: string } = {}) => (
      <span>
        Unable to authorise the transfer of <b>${amountStr}</b>. This transfer
        is already authorised or rejected.
      </span>
    ),
  },
  FAILED_TRANSFER_REJECT_TASK_IS_NO_LONGER_AVAILABLE: {
    styling: 'danger',
    renderMessage: ({ amountStr }: { amountStr?: string } = {}) => (
      <span>
        Unable to reject the transfer of <b>${amountStr}</b>. This transfer is
        already authorised or rejected.
      </span>
    ),
  },
  SUCCESS_TRANSFER_AUTHORISE_PARTIALLY_AUTHORISED: {
    styling: 'success',
    renderMessage: ({ amountStr }: { amountStr?: string } = {}) => (
      <span>
        You have authorised the transfer of <b>${amountStr}</b>. This payment is
        now <b>partially authorised</b>.
      </span>
    ),
  },
  SUCCESS_TRANSFER_AUTHORISE_AUTHORISED: {
    styling: 'success',
    renderMessage: ({ amountStr }: { amountStr?: string } = {}) => (
      <span>
        You have authorised the transfer of <b>${amountStr}</b>. This transfer
        is now <b>fully authorised</b> and has been{' '}
        <b>submitted for processing</b>.
      </span>
    ),
  },
  SUCCESS_TRANSFER_AUTHORISE_PDP_DSR_FAIL: {
    styling: 'success',
    renderMessage: ({ amountStr }: { amountStr?: string } = {}) => (
      <span>
        You have authorised the transfer of <b>${amountStr}</b> and it has been <b>submitted for processing</b>.
        <br />
        <b>Note:</b> The request will continue to display as 'Pending authorisation' until it expires. No action is required.
      </span>
    ),
  },
  FAILED_TRANSFER_AUTHORISE_API_ERROR: {
    styling: 'danger',
    renderMessage: ({ amountStr }: { amountStr?: string } = {}) => (
      <span>
        Unable to authorise the transfer of <b>${amountStr}</b>. Please try
        again later.
      </span>
    ),
  },
  SUCCESS_TRANSFER_REJECT: {
    styling: 'success',
    renderMessage: ({ amountStr }: { amountStr?: string } = {}) => (
      <span>
        You have rejected the transfer of <b>${amountStr}</b>.
      </span>
    ),
  },
  FAILED_TRANSFER_REJECT_API_ERROR: {
    styling: 'danger',
    renderMessage: ({ amountStr }: { amountStr?: string } = {}) => (
      <span>
        Unable to reject the transfer of <b>${amountStr}</b>. Please try again
        later.
      </span>
    ),
  },
  FAILED_TRANSFER_AUTHORISE_PERMISSION_ERROR: {
    styling: 'danger',
    renderMessage: () => (
      <span>
        You do not have permission to authorise or reject transfers. Contact
        your administrator for more information.
      </span>
    ),
  },
  FAILED_TRANSFER_AUTHORISE_TRANSFER_IS_AUTHORISED_BUT_UNABLE_TO_PROCESS: {
    styling: 'danger',
    renderMessage: ({
      paymentId,
      amountStr,
    }: { paymentId?: string; amountStr?: string } = {}) => (
      <span>
        Funds transfer {paymentId} for ${amountStr} could not be processed.
      </span>
    ),
  },
  FAILED_PAYMENT_AUTHORISE_PERMISSION_ERROR: {
    styling: 'danger',
    renderMessage: () => (
      <span>
        You do not have permission to authorise or reject payments. Contact your
        administrator for more information.
      </span>
    ),
  },
  FAILED_PAYMENT_LIMIT_USER_TRANSACTION_LIMIT: {
    styling: 'danger',
    renderMessage: () => (
      <span>
        This payment exceeds the maximum amount you can authorise per
        transaction.
      </span>
    ),
  },
  FAILED_PAYMENT_LIMIT_USER_DAILY_LIMIT: {
    styling: 'danger',
    renderMessage: () => (
      <span>
        You cannot authorise this payment as it exceeds your daily authorisation
        limit.
      </span>
    ),
  },
  FAILED_PAYMENT_LIMIT_ORG_DAILY_LIMIT: {
    styling: 'danger',
    renderMessage: () => (
      <span>
        You cannot authorise this payment as it exceeds the organisation daily
        limit. Try again tomorrow.
      </span>
    ),
  },
  FAILED_PAYMENT_AUTHORISE_PAYMENT_IS_AUTHORISED_BUT_UNABLE_TO_PROCESS: {
    styling: 'danger',
    renderMessage: ({
      paymentId,
      amountStr,
    }: { paymentId?: string; amountStr?: string } = {}) => (
      <span>
        Payment {paymentId} for ${amountStr} could not be processed.
      </span>
    ),
  },
  GENERIC_ERROR_TRY_LATER: {
    styling: 'danger',
    renderMessage: () => (
      <span>
        {apiGenericErrorTryAgainLater}
      </span>
    ),
  },
} satisfies Partial<
  Record<
    keyof typeof PaymentListContainerAlerts,
    AlertMessageProps
  >
>;

export const renderLimitErrorsBanner = (
  errors: validatePaymentLimitsResult[]
): ReactNode => {
  if (!errors || errors.length === 0) return null;

  return (
    <span>
      <b>Please review the following errors:</b>
      <br />
      {errors.map((error) => {
        const alertKey = getAlertMessageKeyForLimit({ code: error.code }) as
          | keyof typeof alertMessageMapper
          | keyof typeof alertMessageMapperForLimits;
        if (alertKey && alertKey in alertMessageMapper) {
          return (
            <span key={`${alertKey}`}>
              •{' '}
              {alertMessageMapper[
                alertKey as keyof typeof alertMessageMapper
              ].renderMessage()}
              <br />
            </span>
          );
        }
        return null;
      })}
    </span>
  );
};
