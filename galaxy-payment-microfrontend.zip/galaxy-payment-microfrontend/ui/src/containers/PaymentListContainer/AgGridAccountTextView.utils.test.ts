import { getAccountNumber } from './AgGridAccountTextView.utils';

describe('Test AgGridAccountTextView Utils', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  describe('getAccountNumber', () => {
    it('should format account number correctly with spaces', () => {
      const accountId = '111111000001';
      const result = getAccountNumber(accountId);
      expect(result).toBe('111-111 000001');
    });

    it('should handle account number with less than 6 characters', () => {
      const accountId = '72466';
      const result = getAccountNumber(accountId);
      expect(result).toBe('724-66');
    });

    it('should handle account number with exactly 6 characters', () => {
      const accountId = '222222';
      const result = getAccountNumber(accountId);
      expect(result).toBe('222-222');
    });

    it('should handle empty account number', () => {
      const accountId = '';
      const result = getAccountNumber(accountId);
      expect(result).toBe('');
    });
  });
})


