/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable react/display-name */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import {
  CellClickedEventV2 as CellClickedEvent,
  CellKeyDownEventV2 as CellKeyDownEvent,
  ColDefV2 as ColDef,
  MVTableV2 as MVTable,
  onColumnPinnedV2 as onColumnPinned,
  onFilterChangedV2 as onFilterChanged,
  suppressHeaderKeyboardEventV2 as suppressHeaderKeyboardEvent,
  suppressKeyboardEventV2 as suppressKeyboardEvent,
  TableDataV2 as TableData,
} from '@mesh-tenant-multiverse-ui-common/mv-table-v2';
import { forwardRef, memo, useMemo, useRef } from 'react';
import { PaymentListing } from '../../store/types';
import { buildColumnDefs } from './PaymentListContainer.utils';

//TODO: Tactical Solution for ART-54000 - This may need to move into MV in later tickets
type MemoMVTableProps = {
  sortedList: PaymentListing[];
  selectPayment: (selectedPayment: TableData) => Promise<void>;
};

const MyMVTable = forwardRef<HTMLInputElement, MemoMVTableProps>(
  (props, ref) => {
    const { sortedList, selectPayment } = props;
    const noRowMessage = 'There are no payments found.';
    const tableContainerRef = useRef<HTMLDivElement>(null);

    const columnDefs = useMemo(() => buildColumnDefs(), []);
    const defaultColumnDef: ColDef = {
      menuTabs: ['generalMenuTab', 'filterMenuTab', 'columnsMenuTab'],
      filter: 'agTextColumnFilter',
      filterParams: {
        buttons: ['reset'],
      },
      minWidth: 119.5,
      suppressKeyboardEvent,
      suppressHeaderKeyboardEvent,
      suppressHeaderFilterButton: false,
      suppressHeaderMenuButton: false,
    };

    const onCellClicked = async (params: CellClickedEvent<TableData>) => {
      if (params.data) {
        await selectPayment(params.data);
      }
    };

    const onCellKeyDown = async (params: CellKeyDownEvent<TableData>) => {
      const keyboardEvent = params.event as KeyboardEvent;
      if (keyboardEvent.key === 'Enter') {
        if (params.data) {
          // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
          await selectPayment(params.data);
        }
      }
    };

    return (
      <div ref={tableContainerRef}>
        <MVTable
          rowData={sortedList}
          // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
          defaultColumnDef={defaultColumnDef}
          columnDefs={columnDefs}
          enableCellTextSelection
          onCellClicked={onCellClicked}
          onCellKeyDown={onCellKeyDown}
          onColumnPinned={onColumnPinned}
          onFilterChanged={onFilterChanged}
          noRowMessage={noRowMessage}
          autoSizeStrategy={{
            type: 'fitCellContents',
            skipHeader: true,
            colIds: ['amount', 'status'],
          }}
          ref={ref as any}
          columnMenu="legacy"
          containerRef={tableContainerRef}
          minHeight={153}
        />
      </div>
    );
  }
);

export const MemoMVTable = memo(
  MyMVTable,
  (prevProps, nextProps) => prevProps.sortedList === nextProps.sortedList
);

export default MemoMVTable;
