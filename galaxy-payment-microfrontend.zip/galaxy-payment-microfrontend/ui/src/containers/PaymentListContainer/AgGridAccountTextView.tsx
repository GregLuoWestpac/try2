/* eslint-disable @typescript-eslint/restrict-template-expressions */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { MVAccountFormatter } from '@mesh-tenant-multiverse-ui-common/mv-accountformatter';
import { formatWithEllipsis } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import {
  calledFromType,
  MAX_PAY_ID_EMAIL_ORGANISATION_ID_LENGTH,
} from '../../common/constants';
import { SupplementaryDataType } from '../../common/types';
import { getAccountNumber } from './AgGridAccountTextView.utils';

interface AgGridTextViewProps {
  value: string;
  data: {
    creditAccountIdentification: string;
    debitAccountIdentification: string;
    beneficiaryName: string;
    supplementaryData?: SupplementaryDataType;
  };
}

function AgGridAccountTextView(
  props: AgGridTextViewProps,
  calledFrom?: string
) {
  const { value, data } = props;

  const renderAccountNumber = () => {
    if (calledFrom === calledFromType.TO_ACCOUNT) {
      if (data?.supplementaryData && data?.supplementaryData?.aliasId) {
        return formatWithEllipsis(
          data.supplementaryData.aliasId,
          MAX_PAY_ID_EMAIL_ORGANISATION_ID_LENGTH
        );
      }
      if (data?.creditAccountIdentification) {
        return getAccountNumber(data?.creditAccountIdentification);
      }
    }
    if (calledFrom === calledFromType.FROM_ACCOUNT) {
      return getAccountNumber(data?.debitAccountIdentification);
    }
    return '';
  };

  return (
    <MVAccountFormatter
      details={[
        {
          value: value || '',
          className:
            'm-0 overflow-hidden truncate break-words typography-body-10 font-semibold text-hero',
          variant: 'text',
        },
        {
          value: renderAccountNumber() || '',
          className:
            'm-0 overflow-hidden break-words typography-body-10 font-normal',
          variant: 'text',
        },
      ]}
    />
  );
}

export default AgGridAccountTextView;
