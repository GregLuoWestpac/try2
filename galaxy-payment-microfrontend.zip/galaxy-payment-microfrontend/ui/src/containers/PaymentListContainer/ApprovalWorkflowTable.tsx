/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { useGlobalDispatch } from '@mep-ui/framework';
import { useNavigate } from '@mep-ui/framework-router-addon';
import {
  CellClickedEventV2 as CellClickedEvent,
  CellKeyDownEventV2 as CellKeyDownEvent,
  ColDefV2 as ColDef,
  GetContextMenuItemsParamsV2 as GetContextMenuItemsParams,
  MVTableV2 as MVTable,
  suppressHeaderKeyboardEventV2 as suppressHeaderKeyboardEvent,
  suppressKeyboardEventV2 as suppressKeyboardEvent,
  TableDataV2 as TableData,
} from '@mesh-tenant-multiverse-ui-common/mv-table-v2';
import { useHandleRaiseIntent } from '@mesh-tenant-multiverse-ui-common/mv-utils';

import { FC, memo, useMemo, useRef } from 'react';
import {
  AuthorisationTab,
  INTENT_NAMES,
  INTENTS_CONTEXT_NAME,
  noPaymentsRowMessage,
  PAGE_NAVIGATION,
  WorkFlowStatusMap,
} from 'ui/src/common/constants';
import { ActionItem, AuthorisationTabValues } from 'ui/src/common/types';
import { ApprovalWorkflowListing } from 'ui/src/store/types/ApprovalWorkflowListing';
import { SearchBy } from 'ui/src/store/types/RootStates';
import { buildAuthTabColumnDefs } from './PaymentListContainer.utils';

export type ApprovalWorkflowTableProps = {
  allPostApprovalWorkflowListing: ApprovalWorkflowListing[];
  makerCheckerActionToggle: AuthorisationTabValues | string;
};

export const ApprovalWorkflowTable: FC<ApprovalWorkflowTableProps> = memo(
  ({ allPostApprovalWorkflowListing, makerCheckerActionToggle }) => {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-return
    const columnDefsMaker = useMemo(() => buildAuthTabColumnDefs(), []);

    const handleRaiseIntent = useHandleRaiseIntent(
      useGlobalDispatch,
      useNavigate
    );

    const tableContainerRef = useRef<HTMLDivElement>(null);

    const searchBy = useMemo(() => {
      return makerCheckerActionToggle === AuthorisationTab.ForYouToAuthorise
        ? SearchBy.ApproverAndCreatedOnDateRange
        : SearchBy.CreatedBy;
    }, [makerCheckerActionToggle]);

    const raiseIntentForAction = async (
      approvalWorkflowId: string,
      intentName: string,
      targetPath: string
    ) => {
      await handleRaiseIntent({
        intentName,
        intentContextName: INTENTS_CONTEXT_NAME.PAYMENT,
        targetPath,
        data: { approvalWorkflowId, searchBy },
        contextKey: approvalWorkflowId,
      });
    };

    const selectWorkflow = async (
      selectedWorkflow: ApprovalWorkflowListing
    ) => {
      const workflowId = selectedWorkflow?.id;
      if (!workflowId) return;
      await raiseIntentForAction(
        workflowId,
        INTENT_NAMES.VIEW_GALAXY_PAYMENT_TASK_DETAILS,
        PAGE_NAVIGATION.PAYMENT_TASK_DETAILS
      );
    };

    const getContextMenuItems = (
      params: GetContextMenuItemsParams<TableData>
    ) => {
      const status = params.node?.data?.status;
      const formattedWorkflow = params.node?.data as ApprovalWorkflowListing;

      const actionItemsArray: ActionItem[] = [];

      if (status !== WorkFlowStatusMap.ApprovalPending) {
        actionItemsArray.push({
          name: 'View payment details',
          cssClasses: ['action-button', 'cursor-pointer'],
          action: async () => {
            await selectWorkflow(formattedWorkflow);
          },
        });
      }

      // only show 'Authorise or reject payment' option for ForYouToAuthorise toggle
      if (
        makerCheckerActionToggle === AuthorisationTab.ForYouToAuthorise &&
        status === WorkFlowStatusMap.ApprovalPending
      ) {
        actionItemsArray.push({
          name: 'Authorise or reject payment',
          cssClasses: ['action-button', 'cursor-pointer'],
          action: async () => {
            await selectWorkflow(formattedWorkflow);
          },
        });
      }

      return actionItemsArray;
    };

    const defaultColumnDef: ColDef = {
      menuTabs: ['generalMenuTab', 'filterMenuTab', 'columnsMenuTab'],
      filter: 'agTextColumnFilter',
      filterParams: {
        buttons: ['reset'],
      },
      minWidth: 119.5,
      suppressKeyboardEvent,
      suppressHeaderKeyboardEvent,
      suppressHeaderFilterButton: false,
      suppressHeaderMenuButton: false,
    };

    const onCellClicked = (params: CellClickedEvent<TableData>) => {
      if (params.data) {
        selectWorkflow(params.data as any);
      }
    };

    const onCellKeyDown = (params: CellKeyDownEvent<TableData>) => {
      const keyboardEvent = params.event as KeyboardEvent;
      if (keyboardEvent.key === 'Enter') {
        if (params.data) {
          selectWorkflow(params.data as any);
        }
      }
    };

    return (
      <div ref={tableContainerRef}>
        <MVTable
          rowData={allPostApprovalWorkflowListing}
          // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
          defaultColumnDef={defaultColumnDef}
          columnDefs={columnDefsMaker}
          enableCellTextSelection
          onCellClicked={onCellClicked}
          onCellKeyDown={onCellKeyDown}
          noRowMessage={noPaymentsRowMessage}
          getContextMenuItems={getContextMenuItems as any}
          autoSizeStrategy={{
            type: 'fitCellContents',
            skipHeader: true,
            colIds: ['amount', 'status'],
          }}
          columnMenu="legacy"
          containerRef={tableContainerRef}
          minHeight={153}
        />
      </div>
    );
  }
);
