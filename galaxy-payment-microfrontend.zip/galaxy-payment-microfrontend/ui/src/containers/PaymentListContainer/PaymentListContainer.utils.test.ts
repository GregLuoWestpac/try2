/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { render } from '@testing-library/react';
import { ApprovalWorkflow } from '../../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types';
import {
  buildColumnDefs,
  buildAuthTabColumnDefs,
  mapApprovalWorkflowList,
  alertMessageMapper,
  authorisationTabValues,
  statusTabValues,
  renderLimitErrorsBanner,
} from './PaymentListContainer.utils';

describe('Test Payment List Container Utils', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  describe('buildColumnDefs', () => {
    it('should match snapshot', () => {
      const result = buildColumnDefs();
      expect(result).toMatchSnapshot();
    });

    it('should return an array of column definitions', () => {
      const result = buildColumnDefs();
      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBeGreaterThan(0);
    });

    it('should include expected column fields', () => {
      const result = buildColumnDefs();
      const fields = result.map((col: any) => col.field || col.headerName);
      expect(result.some((col: any) => col.field || col.headerName)).toBe(true);
    });

    it('should have filterValueGetter for value date column', () => {
      const result = buildColumnDefs();
      const valueDateCol = result[0] as any;
      expect(valueDateCol.filterValueGetter).toBeDefined();
      const dateResult = valueDateCol.filterValueGetter({
        data: { creationDateTime: '2024-01-15T10:00:00Z' },
      });
      expect(dateResult).toBeInstanceOf(Date);
    });

    it('should have cellRenderer for fromAccount column', () => {
      const result = buildColumnDefs();
      const fromAccountCol = result.find(
        (col: any) => col.excludeFromExport === true && col.flex === 1
      ) as any;
      expect(fromAccountCol).toBeDefined();
      expect(fromAccountCol.cellRenderer).toBeDefined();
      const rendered = fromAccountCol.cellRenderer({
        value: 'test',
        data: {
          creditAccountIdentification: 'CR-001',
          debitAccountIdentification: 'DR-001',
          beneficiaryName: 'Test',
        },
      });
      expect(rendered).toBeDefined();
    });

    it('should have cellRenderer for toAccount column', () => {
      const result = buildColumnDefs();
      // toAccount is the second excludeFromExport column (no flex)
      const toAccountCols = result.filter(
        (col: any) => col.excludeFromExport === true
      );
      expect(toAccountCols.length).toBeGreaterThan(1);
      const toAccountCol = toAccountCols[1] as any;
      expect(toAccountCol.cellRenderer).toBeDefined();
      const rendered = toAccountCol.cellRenderer({
        value: 'test',
        data: {
          creditAccountIdentification: 'CR-002',
          debitAccountIdentification: 'DR-002',
          beneficiaryName: 'Test2',
        },
      });
      expect(rendered).toBeDefined();
    });

    it('should have valueGetter for debitAccountIdentification column', () => {
      const result = buildColumnDefs();
      const debitAccCol = result.find(
        (col: any) => col.field === 'debitAccountIdentification'
      ) as any;
      expect(debitAccCol).toBeDefined();
      expect(debitAccCol.valueGetter).toBeDefined();
      const val = debitAccCol.valueGetter({
        data: { debitAccountIdentification: 'ACC-123' },
      });
      expect(val).toBeDefined();
      const emptyVal = debitAccCol.valueGetter({ data: {} });
      expect(emptyVal).toBe('');
    });

    it('should have valueGetter for creditAccountIdentification column', () => {
      const result = buildColumnDefs();
      const creditAccCol = result.find(
        (col: any) => col.field === 'creditAccountIdentification'
      ) as any;
      expect(creditAccCol).toBeDefined();
      expect(creditAccCol.valueGetter).toBeDefined();
      // With creditAccountIdentification
      const val = creditAccCol.valueGetter({
        data: { creditAccountIdentification: 'CR-456' },
      });
      expect(val).toBeDefined();
      // With aliasId fallback
      const aliasVal = creditAccCol.valueGetter({
        data: { supplementaryData: { aliasId: 'ALIAS-123' } },
      });
      expect(aliasVal).toBe('ALIAS-123');
      // Empty fallback
      const emptyVal = creditAccCol.valueGetter({ data: {} });
      expect(emptyVal).toBe('');
    });
  });

  describe('buildAuthTabColumnDefs', () => {
    it('should return an array of column definitions', () => {
      const result = buildAuthTabColumnDefs();
      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBeGreaterThan(0);
    });

    it('should include actions column', () => {
      const result = buildAuthTabColumnDefs();
      expect(result.length).toBeGreaterThan(0);
    });

    it('should have filterValueGetter for created date column', () => {
      const result = buildAuthTabColumnDefs();
      const createdDateCol = result[0] as any;
      expect(createdDateCol.filterValueGetter).toBeDefined();
      const dateResult = createdDateCol.filterValueGetter({
        data: { creationDateTime: '2024-02-20T15:00:00Z' },
      });
      expect(dateResult).toBeInstanceOf(Date);
    });

    it('should have cellRenderer for fromAccount in auth tab', () => {
      const result = buildAuthTabColumnDefs();
      // Find a column with cellRenderer
      const colWithRenderer = result.find(
        (col: any) => typeof col.cellRenderer === 'function' && col.resizable
      ) as any;
      expect(colWithRenderer).toBeDefined();
      expect(colWithRenderer.cellRenderer).toBeDefined();
      const rendered = colWithRenderer.cellRenderer({
        value: 'test-from',
        data: {
          creditAccountIdentification: 'CR-010',
          debitAccountIdentification: 'DR-010',
          beneficiaryName: 'Auth Test',
        },
      });
      expect(rendered).toBeDefined();
    });

    it('should have cellRenderer for toAccount in auth tab', () => {
      const result = buildAuthTabColumnDefs();
      const colsWithRenderer = result.filter(
        (col: any) => typeof col.cellRenderer === 'function' && col.resizable
      );
      expect(colsWithRenderer.length).toBeGreaterThan(1);
      const toAccountCol = colsWithRenderer[1] as any;
      expect(toAccountCol.cellRenderer).toBeDefined();
      const rendered = toAccountCol.cellRenderer({
        value: 'test-to',
        data: {
          creditAccountIdentification: 'CR-011',
          debitAccountIdentification: 'DR-011',
          beneficiaryName: 'Auth Test 2',
        },
      });
      expect(rendered).toBeDefined();
    });
  });

  describe('authorisationTabValues', () => {
    it('should contain ForYouToAuthorise tab', () => {
      expect(authorisationTabValues).toEqual(
        expect.arrayContaining([
          expect.objectContaining({ label: 'For you to authorise' }),
        ])
      );
    });

    it('should contain PaymentsYouInitiated tab', () => {
      expect(authorisationTabValues).toEqual(
        expect.arrayContaining([
          expect.objectContaining({ label: 'Payments you initiated' }),
        ])
      );
    });

    it('should have exactly 2 tabs', () => {
      expect(authorisationTabValues).toHaveLength(2);
    });
  });

  describe('statusTabValues', () => {
    it('should contain All, Pending, and Rejected tabs', () => {
      expect(statusTabValues).toHaveLength(3);
      expect(statusTabValues.map((t) => t.label)).toEqual([
        'All',
        'Pending authorisation',
        'Rejected by authoriser',
      ]);
    });
  });

  describe('mapApprovalWorkflowList', () => {
    it('should return empty array for non-array input', () => {
      expect(mapApprovalWorkflowList(null as any)).toEqual([]);
      expect(mapApprovalWorkflowList(undefined as any)).toEqual([]);
    });

    it('should return empty array for empty array input', () => {
      expect(mapApprovalWorkflowList([])).toEqual([]);
    });

    it('should map workflow with full data', () => {
      const workflows: ApprovalWorkflow[] = [
        {
          approvalWorkflowId: 'WF-001',
          createdDateTime: '2024-01-15T10:00:00Z',
          workflowStatus: 'APPROVED',
          approvers: [{ name: 'John' }],
          entitlementsPayload: 'ENT-123',
          payloadObject: {
            debtorAccount: {
              name: 'Savings Account',
              identification: 'ACC-001',
            },
            supplementaryData: {
              debitDescription: 'Test payment',
            },
            creditTransferTransactionInformation: [
              {
                instructedAmount: {
                  amount: '1000.00',
                  currency: 'AUD',
                },
                creditor: {
                  name: 'Jane Doe',
                },
                creditorAccount: {
                  name: 'Checking',
                  identification: 'ACC-002',
                },
                supplementaryData: {
                  aliasId: 'ALIAS-001',
                  aliasType: 'EMAIL',
                },
              },
            ],
          },
        } as any,
      ];

      const result = mapApprovalWorkflowList(workflows);
      expect(result).toHaveLength(1);
      expect(result[0].id).toBe('WF-001');
      expect(result[0].amount).toBe(1000);
      expect(result[0].currency).toBe('AUD');
      expect(result[0].debitAccountName).toBe('Savings Account');
      expect(result[0].debitAccountIdentification).toBe('ACC-001');
      expect(result[0].debitDescription).toBe('Test payment');
      expect(result[0].beneficiaryName).toBe('Jane Doe');
      expect(result[0].creditAccountName).toBe('Checking');
      expect(result[0].creditAccountIdentification).toBe('ACC-002');
      expect(result[0].supplementaryData.aliasId).toBe('ALIAS-001');
      expect(result[0].supplementaryData.aliasType).toBe('EMAIL');
    });

    it('should handle workflow with missing payloadObject', () => {
      const workflows: ApprovalWorkflow[] = [
        {
          approvalWorkflowId: 'WF-002',
          createdDateTime: '2024-01-15T10:00:00Z',
          workflowStatus: 'PENDING',
        } as any,
      ];

      const result = mapApprovalWorkflowList(workflows);
      expect(result).toHaveLength(1);
      expect(result[0].id).toBe('WF-002');
      expect(result[0].debitAccountName).toBe('');
      expect(result[0].debitAccountIdentification).toBe('');
      expect(result[0].beneficiaryName).toBe('');
    });

    it('should handle workflow with empty creditTransferTransactionInformation', () => {
      const workflows: ApprovalWorkflow[] = [
        {
          approvalWorkflowId: 'WF-003',
          payloadObject: {
            debtorAccount: { name: 'Acc', identification: '123' },
            creditTransferTransactionInformation: [],
          },
        } as any,
      ];

      const result = mapApprovalWorkflowList(workflows);
      expect(result).toHaveLength(1);
      expect(result[0].currency).toBe('');
    });

    it('should map multiple workflows', () => {
      const workflows: ApprovalWorkflow[] = [
        { approvalWorkflowId: 'WF-A' } as any,
        { approvalWorkflowId: 'WF-B' } as any,
      ];

      const result = mapApprovalWorkflowList(workflows);
      expect(result).toHaveLength(2);
      expect(result[0].id).toBe('WF-A');
      expect(result[1].id).toBe('WF-B');
    });
  });

  describe('alertMessageMapper', () => {
    describe('SUCCESS_PAYMENT_AUTHORISE_PARTIALLY_AUTHORISED', () => {
      it('should have success styling', () => {
        expect(alertMessageMapper.SUCCESS_PAYMENT_AUTHORISE_PARTIALLY_AUTHORISED.styling).toBe('success');
      });

      it('should render partial authorisation message', () => {
        const { getByText } = render(
          alertMessageMapper.SUCCESS_PAYMENT_AUTHORISE_PARTIALLY_AUTHORISED.renderMessage({ amountStr: '100.00' }) as any
        );
        expect(getByText(/partially authorised/i)).toBeTruthy();
      });
    });

    describe('SUCCESS_PAYMENT_AUTHORISE_AUTHORISED', () => {
      it('should have success styling', () => {
        expect(alertMessageMapper.SUCCESS_PAYMENT_AUTHORISE_AUTHORISED.styling).toBe('success');
      });

      it('should render full authorisation message', () => {
        const { getByText } = render(
          alertMessageMapper.SUCCESS_PAYMENT_AUTHORISE_AUTHORISED.renderMessage({ amountStr: '200.00' }) as any
        );
        expect(getByText(/fully authorised/i)).toBeTruthy();
        expect(getByText(/submitted for processing/i)).toBeTruthy();
      });
    });

    describe('FAILED_PAYMENT_AUTHORISE_API_ERROR', () => {
      it('should have danger styling', () => {
        expect(alertMessageMapper.FAILED_PAYMENT_AUTHORISE_API_ERROR.styling).toBe('danger');
      });

      it('should render api error message', () => {
        const { getByText } = render(
          alertMessageMapper.FAILED_PAYMENT_AUTHORISE_API_ERROR.renderMessage({ amountStr: '300.00' }) as any
        );
        expect(getByText(/unable to authorise/i)).toBeTruthy();
        expect(getByText(/try again later/i)).toBeTruthy();
      });
    });

    describe('SUCCESS_PAYMENT_AUTHORISE_PDP_DSR_FAIL', () => {
      it('should have success styling', () => {
        expect(alertMessageMapper.SUCCESS_PAYMENT_AUTHORISE_PDP_DSR_FAIL.styling).toBe('success');
      });

      it('should render correct message with amount', () => {
        const { getByText } = render(
          alertMessageMapper.SUCCESS_PAYMENT_AUTHORISE_PDP_DSR_FAIL.renderMessage({ amountStr: '100.00' }) as any
        );
        expect(getByText(/authorised the payment/i)).toBeTruthy();
        expect(getByText(/submitted for processing/i)).toBeTruthy();
        expect(getByText(/No action is required/i)).toBeTruthy();
      });
    });

    describe('SUCCESS_PAYMENT_REJECT', () => {
      it('should have success styling', () => {
        expect(alertMessageMapper.SUCCESS_PAYMENT_REJECT.styling).toBe('success');
      });

      it('should render rejection message', () => {
        const { getByText } = render(
          alertMessageMapper.SUCCESS_PAYMENT_REJECT.renderMessage({ amountStr: '50.00' }) as any
        );
        expect(getByText(/rejected the payment/i)).toBeTruthy();
      });
    });

    describe('FAILED_PAYMENT_REJECT_API_ERROR', () => {
      it('should have danger styling', () => {
        expect(alertMessageMapper.FAILED_PAYMENT_REJECT_API_ERROR.styling).toBe('danger');
      });

      it('should render rejection error message', () => {
        const { getByText } = render(
          alertMessageMapper.FAILED_PAYMENT_REJECT_API_ERROR.renderMessage({ amountStr: '50.00' }) as any
        );
        expect(getByText(/unable to reject the payment/i)).toBeTruthy();
      });
    });

    describe('FAILED_PAYMENT_AUTHORISE_TASK_IS_NO_LONGER_AVAILABLE', () => {
      it('should have danger styling', () => {
        expect(alertMessageMapper.FAILED_PAYMENT_AUTHORISE_TASK_IS_NO_LONGER_AVAILABLE.styling).toBe('danger');
      });

      it('should render task unavailable message', () => {
        const { getByText } = render(
          alertMessageMapper.FAILED_PAYMENT_AUTHORISE_TASK_IS_NO_LONGER_AVAILABLE.renderMessage({ amountStr: '100.00' }) as any
        );
        expect(getByText(/already authorised or rejected/i)).toBeTruthy();
      });
    });

    describe('FAILED_PAYMENT_REJECT_TASK_IS_NO_LONGER_AVAILABLE', () => {
      it('should have danger styling', () => {
        expect(alertMessageMapper.FAILED_PAYMENT_REJECT_TASK_IS_NO_LONGER_AVAILABLE.styling).toBe('danger');
      });

      it('should render reject task unavailable message', () => {
        const { getByText } = render(
          alertMessageMapper.FAILED_PAYMENT_REJECT_TASK_IS_NO_LONGER_AVAILABLE.renderMessage({ amountStr: '75.00' }) as any
        );
        expect(getByText(/unable to reject/i)).toBeTruthy();
        expect(getByText(/already authorised or rejected/i)).toBeTruthy();
      });
    });

    describe('FAILED_TRANSFER_AUTHORISE_TASK_IS_NO_LONGER_AVAILABLE', () => {
      it('should have danger styling', () => {
        expect(alertMessageMapper.FAILED_TRANSFER_AUTHORISE_TASK_IS_NO_LONGER_AVAILABLE.styling).toBe('danger');
      });

      it('should render transfer task unavailable message', () => {
        const { getByText } = render(
          alertMessageMapper.FAILED_TRANSFER_AUTHORISE_TASK_IS_NO_LONGER_AVAILABLE.renderMessage({ amountStr: '250.00' }) as any
        );
        expect(getByText(/unable to authorise the transfer/i)).toBeTruthy();
        expect(getByText(/already authorised or rejected/i)).toBeTruthy();
      });
    });

    describe('FAILED_TRANSFER_REJECT_TASK_IS_NO_LONGER_AVAILABLE', () => {
      it('should have danger styling', () => {
        expect(alertMessageMapper.FAILED_TRANSFER_REJECT_TASK_IS_NO_LONGER_AVAILABLE.styling).toBe('danger');
      });

      it('should render transfer reject unavailable message', () => {
        const { getByText } = render(
          alertMessageMapper.FAILED_TRANSFER_REJECT_TASK_IS_NO_LONGER_AVAILABLE.renderMessage({ amountStr: '150.00' }) as any
        );
        expect(getByText(/unable to reject the transfer/i)).toBeTruthy();
      });
    });

    describe('SUCCESS_TRANSFER_AUTHORISE_PARTIALLY_AUTHORISED', () => {
      it('should have success styling', () => {
        expect(alertMessageMapper.SUCCESS_TRANSFER_AUTHORISE_PARTIALLY_AUTHORISED.styling).toBe('success');
      });

      it('should render partial authorisation message for transfer', () => {
        const { getByText } = render(
          alertMessageMapper.SUCCESS_TRANSFER_AUTHORISE_PARTIALLY_AUTHORISED.renderMessage({ amountStr: '500.00' }) as any
        );
        expect(getByText(/partially authorised/i)).toBeTruthy();
      });
    });

    describe('SUCCESS_TRANSFER_AUTHORISE_AUTHORISED', () => {
      it('should have success styling', () => {
        expect(alertMessageMapper.SUCCESS_TRANSFER_AUTHORISE_AUTHORISED.styling).toBe('success');
      });

      it('should render full authorisation message for transfer', () => {
        const { getByText } = render(
          alertMessageMapper.SUCCESS_TRANSFER_AUTHORISE_AUTHORISED.renderMessage({ amountStr: '600.00' }) as any
        );
        expect(getByText(/fully authorised/i)).toBeTruthy();
        expect(getByText(/submitted for processing/i)).toBeTruthy();
      });
    });

    describe('SUCCESS_TRANSFER_AUTHORISE_PDP_DSR_FAIL', () => {
      it('should have success styling', () => {
        expect(alertMessageMapper.SUCCESS_TRANSFER_AUTHORISE_PDP_DSR_FAIL.styling).toBe('success');
      });

      it('should render correct message with amount', () => {
        const { getByText } = render(
          alertMessageMapper.SUCCESS_TRANSFER_AUTHORISE_PDP_DSR_FAIL.renderMessage({ amountStr: '200.00' }) as any
        );
        expect(getByText(/authorised the transfer/i)).toBeTruthy();
        expect(getByText(/submitted for processing/i)).toBeTruthy();
        expect(getByText(/No action is required/i)).toBeTruthy();
      });
    });

    describe('FAILED_TRANSFER_AUTHORISE_API_ERROR', () => {
      it('should have danger styling', () => {
        expect(alertMessageMapper.FAILED_TRANSFER_AUTHORISE_API_ERROR.styling).toBe('danger');
      });

      it('should render transfer api error message', () => {
        const { getByText } = render(
          alertMessageMapper.FAILED_TRANSFER_AUTHORISE_API_ERROR.renderMessage({ amountStr: '400.00' }) as any
        );
        expect(getByText(/unable to authorise the transfer/i)).toBeTruthy();
      });
    });

    describe('SUCCESS_TRANSFER_REJECT', () => {
      it('should have success styling', () => {
        expect(alertMessageMapper.SUCCESS_TRANSFER_REJECT.styling).toBe('success');
      });

      it('should render transfer rejection message', () => {
        const { getByText } = render(
          alertMessageMapper.SUCCESS_TRANSFER_REJECT.renderMessage({ amountStr: '350.00' }) as any
        );
        expect(getByText(/rejected the transfer/i)).toBeTruthy();
      });
    });

    describe('FAILED_TRANSFER_REJECT_API_ERROR', () => {
      it('should have danger styling', () => {
        expect(alertMessageMapper.FAILED_TRANSFER_REJECT_API_ERROR.styling).toBe('danger');
      });

      it('should render transfer rejection error message', () => {
        const { getByText } = render(
          alertMessageMapper.FAILED_TRANSFER_REJECT_API_ERROR.renderMessage({ amountStr: '350.00' }) as any
        );
        expect(getByText(/unable to reject the transfer/i)).toBeTruthy();
      });
    });

    describe('GENERIC_ERROR_TRY_LATER', () => {
      it('should have danger styling', () => {
        expect(alertMessageMapper.GENERIC_ERROR_TRY_LATER.styling).toBe('danger');
      });

      it('should render the generic error message', () => {
        const { container } = render(
          alertMessageMapper.GENERIC_ERROR_TRY_LATER.renderMessage() as any
        );
        expect(container.textContent).toBeTruthy();
        expect(container.textContent!.length).toBeGreaterThan(0);
      });
    });

    describe('FAILED_PAYMENT_AUTHORISE_PAYMENT_IS_AUTHORISED_BUT_UNABLE_TO_PROCESS', () => {
      it('should have danger styling', () => {
        expect(
          alertMessageMapper.FAILED_PAYMENT_AUTHORISE_PAYMENT_IS_AUTHORISED_BUT_UNABLE_TO_PROCESS.styling
        ).toBe('danger');
      });

      it('should render message with paymentId and amount', () => {
        const { getByText } = render(
          alertMessageMapper.FAILED_PAYMENT_AUTHORISE_PAYMENT_IS_AUTHORISED_BUT_UNABLE_TO_PROCESS.renderMessage({
            paymentId: 'PAY-001',
            amountStr: '500.00',
          }) as any
        );
        expect(getByText(/could not be processed/i)).toBeTruthy();
      });

      it('should render without "Contact the initiator" text', () => {
        const { container } = render(
          alertMessageMapper.FAILED_PAYMENT_AUTHORISE_PAYMENT_IS_AUTHORISED_BUT_UNABLE_TO_PROCESS.renderMessage({
            paymentId: 'PAY-001',
            amountStr: '500.00',
          }) as any
        );
        expect(container.textContent).not.toContain('Contact the initiator');
      });
    });

    describe('FAILED_TRANSFER_AUTHORISE_TRANSFER_IS_AUTHORISED_BUT_UNABLE_TO_PROCESS', () => {
      it('should have danger styling', () => {
        expect(
          alertMessageMapper.FAILED_TRANSFER_AUTHORISE_TRANSFER_IS_AUTHORISED_BUT_UNABLE_TO_PROCESS.styling
        ).toBe('danger');
      });

      it('should render message without "Contact the initiator" text', () => {
        const { container } = render(
          alertMessageMapper.FAILED_TRANSFER_AUTHORISE_TRANSFER_IS_AUTHORISED_BUT_UNABLE_TO_PROCESS.renderMessage({
            paymentId: 'TRF-001',
            amountStr: '300.00',
          }) as any
        );
        expect(container.textContent).toContain('could not be processed');
        expect(container.textContent).not.toContain('Contact the initiator');
      });
    });

    describe('Permission error messages', () => {
      it('should use "authorise" spelling in payment permission error', () => {
        const { getByText } = render(
          alertMessageMapper.FAILED_PAYMENT_AUTHORISE_PERMISSION_ERROR.renderMessage() as any
        );
        expect(getByText(/authorise or reject payments/i)).toBeTruthy();
      });

      it('should use "authorise" spelling in transfer permission error', () => {
        const { getByText } = render(
          alertMessageMapper.FAILED_TRANSFER_AUTHORISE_PERMISSION_ERROR.renderMessage() as any
        );
        expect(getByText(/authorise or reject transfers/i)).toBeTruthy();
      });
    });

    describe('Limit error messages', () => {
      it('FAILED_PAYMENT_LIMIT_USER_TRANSACTION_LIMIT should have danger styling', () => {
        expect(alertMessageMapper.FAILED_PAYMENT_LIMIT_USER_TRANSACTION_LIMIT.styling).toBe('danger');
      });

      it('FAILED_PAYMENT_LIMIT_USER_TRANSACTION_LIMIT should render correct message', () => {
        const { getByText } = render(
          alertMessageMapper.FAILED_PAYMENT_LIMIT_USER_TRANSACTION_LIMIT.renderMessage() as any
        );
        expect(getByText(/exceeds the maximum amount/i)).toBeTruthy();
      });

      it('FAILED_PAYMENT_LIMIT_USER_DAILY_LIMIT should have danger styling', () => {
        expect(alertMessageMapper.FAILED_PAYMENT_LIMIT_USER_DAILY_LIMIT.styling).toBe('danger');
      });

      it('FAILED_PAYMENT_LIMIT_USER_DAILY_LIMIT should render correct message', () => {
        const { getByText } = render(
          alertMessageMapper.FAILED_PAYMENT_LIMIT_USER_DAILY_LIMIT.renderMessage() as any
        );
        expect(getByText(/exceeds your daily authorisation limit/i)).toBeTruthy();
      });

      it('FAILED_PAYMENT_LIMIT_ORG_DAILY_LIMIT should have danger styling', () => {
        expect(alertMessageMapper.FAILED_PAYMENT_LIMIT_ORG_DAILY_LIMIT.styling).toBe('danger');
      });

      it('FAILED_PAYMENT_LIMIT_ORG_DAILY_LIMIT should render correct message', () => {
        const { getByText } = render(
          alertMessageMapper.FAILED_PAYMENT_LIMIT_ORG_DAILY_LIMIT.renderMessage() as any
        );
        expect(getByText(/exceeds the organisation daily limit/i)).toBeTruthy();
      });
    });
  });

  describe('renderLimitErrorsBanner', () => {
    it('should return null for empty errors array', () => {
      expect(renderLimitErrorsBanner([])).toBeNull();
    });

    it('should return null for null input', () => {
      expect(renderLimitErrorsBanner(null as any)).toBeNull();
    });

    it('should return null for undefined input', () => {
      expect(renderLimitErrorsBanner(undefined as any)).toBeNull();
    });

    it('should render error banner with known limit error code 2302', () => {
      const errors = [{ code: 2302 }] as any;
      const result = renderLimitErrorsBanner(errors);
      const { getByText } = render(result as any);
      expect(getByText(/Please review the following errors/i)).toBeTruthy();
      expect(getByText(/exceeds the maximum amount/i)).toBeTruthy();
    });

    it('should render error banner with multiple known limit error codes', () => {
      const errors = [{ code: 2302 }, { code: 2303 }] as any;
      const result = renderLimitErrorsBanner(errors);
      const { getByText } = render(result as any);
      expect(getByText(/exceeds the maximum amount/i)).toBeTruthy();
      expect(getByText(/exceeds your daily authorisation limit/i)).toBeTruthy();
    });

    it('should handle errors with unknown codes gracefully', () => {
      const errors = [{ code: 9999 }] as any;
      const result = renderLimitErrorsBanner(errors);
      const { getByText } = render(result as any);
      expect(getByText(/Please review the following errors/i)).toBeTruthy();
    });
  });
});
