import { MVPageLoader as PageLoader } from '@mesh-tenant-multiverse-ui-common/mv-pageloader';
import { Alert, Button } from '@westpac/ui';
import { FC, useEffect, useState } from 'react';
import { genericErrorMessage } from '../../common/constants';
import { ApprovalWorkflowTable } from './ApprovalWorkflowTable';

type ApprovalWorkflowPanelProps = {
  hasApprovalWorkflowListingError: boolean;
  isApprovalWorkflowListingFetching: boolean;
  activeTab: string;
  allPostApprovalWorkflowListing: any[];
  handleRetryApprovalWorkflow: () => void;
};

export const ApprovalWorkflowPanel: FC<ApprovalWorkflowPanelProps> = ({
  hasApprovalWorkflowListingError,
  isApprovalWorkflowListingFetching,
  activeTab,
  allPostApprovalWorkflowListing,
  handleRetryApprovalWorkflow,
}) => {
  const [isLoadingWidget, setIsLoadingWidget] = useState(true);

  useEffect(() => {
    if (!isLoadingWidget) return;
    const widget = document.getElementById('maker-checker-api-client');
    if (widget) {
      setIsLoadingWidget(false);
      return;
    }
    const observer = new MutationObserver(() => {
      const found = document.getElementById('maker-checker-api-client');
      if (found) {
        setIsLoadingWidget(false);
        observer.disconnect();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    return () => observer.disconnect();
  }, [isLoadingWidget]);

  if (isApprovalWorkflowListingFetching || isLoadingWidget) {
    return <PageLoader iconSize="medium" />;
  }

  if (hasApprovalWorkflowListingError) {
    return (
      <div className="flex justify-center">
        <Alert
          look="danger"
          id="account-list-error-banner h-0"
          iconSize="small"
          className="mb-0"
        >
          {`${genericErrorMessage} Please `}
          <Button
            className="bg-danger-5 p-0 typography-body-11 h-0"
            look="link"
            soft
            onClick={handleRetryApprovalWorkflow}
          >
            try again
          </Button>
          .
        </Alert>
      </div>
    );
  }

  if (!hasApprovalWorkflowListingError && !isApprovalWorkflowListingFetching) {
    return (
      <ApprovalWorkflowTable
        allPostApprovalWorkflowListing={allPostApprovalWorkflowListing}
        makerCheckerActionToggle={activeTab}
      />
    );
  }
};

export default ApprovalWorkflowPanel;
