import { render } from '@testing-library/react';
import { calledFromType } from '../../common/constants';
import { AliasType } from '../../common/types';
import AgGridAccountTextView from './AgGridAccountTextView';

jest.mock('@mesh-tenant-multiverse-ui-common/mv-accountformatter', () => ({
  MVAccountFormatter: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div>{children}</div>;
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  formatWithEllipsis: jest
    .fn()
    .mockReturnValue(
      'Services-12567890abcdefgklmnotuvwyzABCDEFGHIJKLMNOPQRSTUVWYZ-0876521'
    ),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  formatWithEllipsis: jest
    .fn()
    .mockReturnValue(
      'Services-12567890abcdefgklmnotuvwyzABCDEFGHIJKLMNOPQRSTUVWYZ-0876521'
    ),
}));
jest.mock('./AgGridAccountTextView.utils', () => ({
  getAccountNumber: jest.fn((str) => str),
}));

describe('AgGridAccountTextView', () => {
  const defaultProps = {
    value: 'testValue',
    data: {
      creditAccountIdentification: '222222000004',
      debitAccountIdentification: '111111000004',
      supplementaryData: {
        aliasType: 'ORGN' as AliasType,
        aliasId:
          'Services-12567890abcdefgklmnotuvwyzABCDEFGHIJKLMNOPQRSTUVWYZ-0876521',
      },
    },
    calledFrom: calledFromType.TO_ACCOUNT,
  };

  it('should render without crashing', () => {
    const { container } = render(<AgGridAccountTextView {...defaultProps} />);
    expect(container).toMatchSnapshot();
  });
});
