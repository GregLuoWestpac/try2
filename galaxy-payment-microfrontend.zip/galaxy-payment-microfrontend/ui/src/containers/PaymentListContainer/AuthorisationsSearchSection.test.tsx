import { fireEvent, render, renderHook, waitFor } from '@testing-library/react';
import { useForm } from 'react-hook-form';
import AuthorisationsSearchSection from './AuthorisationsSearchSection';
import { AuthorisationSearchFormType } from 'ui/src/common/types';

const { result } = renderHook(() => useForm<AuthorisationSearchFormType>());
const mockControl = result.current.control;

const defaultProps = {
  hasApprovalWorkflowListingError: false,
  isApprovalWorkflowListingFetching: false,
  allPostApprovalWorkflowListing: [],
  authorisationActiveTab: 'ForYouToAuthorise' as any,
  authorisationTabValues: [
    { label: 'For you to authorise', value: 'ForYouToAuthorise' as any },
    { label: 'Payments you initiated', value: 'PaymentsYouInitiated' as any },
  ],
  statusActiveTab: 'Pending' as any,
  statusTabValues: [
    { label: 'Pending', value: 'Pending' as any },
    { label: 'Rejected', value: 'Rejected' as any },
  ],
  onAuthorisationChange: jest.fn(),
  onStatusChange: jest.fn(),
  control: mockControl,
  setError: jest.fn(),
  clearErrors: jest.fn(),
  onAccordionSearch: jest.fn(),
};

jest.mock('@mesh-tenant-multiverse-ui-common/mv-accordion', () => ({
  MVAccordion: function MockComponent({
    children,
    onButtonClick,
    defaultExpanded = true,
    loading = false,
  }: {
    children: React.ReactNode;
    onButtonClick: () => void;
    defaultExpanded?: boolean;
    loading?: boolean;
  }) {
    return (
      <div
        data-testid="mv-accordion"
        data-expanded={defaultExpanded.toString()}
        data-loading={loading.toString()}
      >
        <button
          data-testid="apply-button"
          onClick={onButtonClick}
          disabled={loading}
        >
          Apply
        </button>
        <div data-testid="accordion-content">{children}</div>
      </div>
    );
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => ({
  MVDateRangePickerController: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div>{children}</div>;
  },
  getToday: jest.fn(() => ({
    minus: jest.fn(() => ({
      toFormat: jest.fn(() => '09/03/2025'),
    })),
    toFormat: jest.fn(() => '09/03/2025'),
  })),
  getTodayAtLastYear: jest.fn(() => ({
    toFormat: jest.fn(() => '09/03/2024'),
  })),
}));

jest.mock('@westpac/ui', () => ({
  ButtonGroup: function MockComponent({
    onChange,
    label,
  }: {
    onChange?: (value: string) => void;
    label?: string;
  }) {
    return (
      <button
        data-testid={`button-group-${label?.toLowerCase()}`}
        onClick={() => onChange?.('TestValue')}
      >
        {label} Button Group
      </button>
    );
  },
  GridItem: function MockComponent({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return <div>{children}</div>;
  },
}));

describe('Testing AuthorisationsSearchSection', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should call onAccordionSearch when Apply button is clicked', async () => {
    const { getByText } = render(
      <AuthorisationsSearchSection {...defaultProps} />
    );
    const button = getByText('Apply');
    fireEvent.click(button);
    await waitFor(() => {
      expect(defaultProps.onAccordionSearch).toHaveBeenCalled();
    });
  });

  it('should expand accordion upon page load', () => {
    const { getByTestId } = render(
      <AuthorisationsSearchSection {...defaultProps} />
    );
    expect(getByTestId('mv-accordion')).toHaveAttribute(
      'data-expanded',
      'true'
    );
  });

  it('should keep accordion expanded after clicking Apply button', async () => {
    const { getByText, getByTestId } = render(
      <AuthorisationsSearchSection {...defaultProps} />
    );

    const button = getByText('Apply');
    fireEvent.click(button);

    await waitFor(() => {
      expect(getByTestId('mv-accordion')).toHaveAttribute(
        'data-expanded',
        'true'
      );
    });
  });

  it('should match snapshot', () => {
    const { container } = render(
      <AuthorisationsSearchSection {...defaultProps} />
    );
    expect(container).toMatchSnapshot();
  });

  it('should not display the date range picker when on Payments You Initiated tab', () => {
    const { container } = render(
      <AuthorisationsSearchSection {...defaultProps} isPaymentsYouInitiatedTabSelected={true} />
    );
    expect(container.querySelector('[data-testid="date-range-picker"]')).not.toBeInTheDocument();
  })

});

describe('useEffect loading state management', () => {
  it('should set loading state to false when fetching completes', async () => {
    const propsWithFetching = {
      ...defaultProps,
      isApprovalWorkflowListingFetching: true,
    };
    const { rerender, getByTestId } = render(
      <AuthorisationsSearchSection {...propsWithFetching} />
    );

    // Click apply to set loading state
    const button = getByTestId('apply-button');
    fireEvent.click(button);

    await waitFor(() => {
      expect(getByTestId('mv-accordion')).toHaveAttribute(
        'data-loading',
        'true'
      );
    });

    // Simulate fetching completion
    rerender(
      <AuthorisationsSearchSection
        {...defaultProps}
        isApprovalWorkflowListingFetching={false}
      />
    );

    await waitFor(() => {
      expect(getByTestId('mv-accordion')).toHaveAttribute(
        'data-loading',
        'false'
      );
      expect(button).not.toBeDisabled();
    });
  });

  it('should set loading state to true when still fetching', async () => {
    const propsStillFetching = {
      ...defaultProps,
      isApprovalWorkflowListingFetching: true,
    };
    const { getByTestId } = render(
      <AuthorisationsSearchSection {...propsStillFetching} />
    );

    // Click apply to set loading state
    const button = getByTestId('apply-button');
    fireEvent.click(button);

    await waitFor(() => {
      // Loading state should remain true since fetching is still in progress
      expect(getByTestId('mv-accordion')).toHaveAttribute(
        'data-loading',
        'true'
      );
      expect(button).toBeDisabled();
    });
  });

  describe('AuthorisationsSearchSection Component', () => {
    it('should call onAuthorisationChange when Authorisation tab is changed', () => {
      const { getByTestId } = render(
        <AuthorisationsSearchSection {...defaultProps} />
      );
      const buttonGroup = getByTestId('button-group-authorisation');
      fireEvent.click(buttonGroup);
      expect(defaultProps.onAuthorisationChange).toHaveBeenCalledWith(
        'TestValue'
      );
    });

    it('should call onStatusChange when Status tab is changed', () => {
      const { getByTestId } = render(
        <AuthorisationsSearchSection {...defaultProps} />
      );
      const buttonGroup = getByTestId('button-group-status');
      fireEvent.click(buttonGroup);
      expect(defaultProps.onStatusChange).toHaveBeenCalledWith('TestValue');
    });

    it('should render MVDateRangePickerController with correct props', () => {
      const { container } = render(
        <AuthorisationsSearchSection {...defaultProps} />
      );
      expect(container).toBeTruthy();
      // MVDateRangePickerController is mocked, so we just verify the component renders
    });

    it('should render with correct authorisation tab values', () => {
      const customProps = {
        ...defaultProps,
        authorisationActiveTab: 'PaymentsYouInitiated' as any,
      };
      const { getByTestId } = render(
        <AuthorisationsSearchSection {...customProps} />
      );
      expect(getByTestId('button-group-authorisation')).toBeInTheDocument();
    });

    it('should render with correct status tab values', () => {
      const customProps = {
        ...defaultProps,
        statusActiveTab: 'Rejected' as any,
      };
      const { getByTestId } = render(
        <AuthorisationsSearchSection {...customProps} />
      );
      expect(getByTestId('button-group-status')).toBeInTheDocument();
    });

    it('should handle optional onAuthorisationChange callback', () => {
      const propsWithoutCallback = {
        ...defaultProps,
        onAuthorisationChange: undefined,
      };
      const { getByTestId } = render(
        <AuthorisationsSearchSection {...propsWithoutCallback} />
      );
      const buttonGroup = getByTestId('button-group-authorisation');
      // Should not throw error when callback is undefined
      expect(() => fireEvent.click(buttonGroup)).not.toThrow();
    });

    it('should handle optional onStatusChange callback', () => {
      const propsWithoutCallback = {
        ...defaultProps,
        onStatusChange: undefined,
      };
      const { getByTestId } = render(
        <AuthorisationsSearchSection {...propsWithoutCallback} />
      );
      const buttonGroup = getByTestId('button-group-status');
      // Should not throw error when callback is undefined
      expect(() => fireEvent.click(buttonGroup)).not.toThrow();
    });

    it('should pass control prop to MVDateRangePickerController', () => {
      const customControl = renderHook(() =>
        useForm<AuthorisationSearchFormType>()
      ).result.current.control;
      const customProps = {
        ...defaultProps,
        control: customControl,
      };
      const { container } = render(
        <AuthorisationsSearchSection {...customProps} />
      );
      expect(container).toBeTruthy();
    });

    it('should render accordion content correctly', () => {
      const { getByTestId } = render(
        <AuthorisationsSearchSection {...defaultProps} />
      );
      const accordionContent = getByTestId('accordion-content');
      expect(accordionContent).toBeInTheDocument();
      expect(accordionContent.children.length).toBeGreaterThan(0);
    });
  });

  describe('Props validation', () => {
    it('should render with minimal required props', () => {
      const minimalProps = {
        isApprovalWorkflowListingFetching: false,
        authorisationActiveTab: 'ForYouToAuthorise' as any,
        authorisationTabValues: defaultProps.authorisationTabValues,
        statusActiveTab: 'Pending' as any,
        statusTabValues: defaultProps.statusTabValues,
        control: mockControl,
        setError: jest.fn(),
        clearErrors: jest.fn(),
        onAccordionSearch: jest.fn(),
      };
      const { getByTestId } = render(
        <AuthorisationsSearchSection {...minimalProps} />
      );
      expect(getByTestId('mv-accordion')).toBeInTheDocument();
    });

    it('should handle hasApprovalWorkflowListingError prop', () => {
      const propsWithError = {
        ...defaultProps,
        hasApprovalWorkflowListingError: true,
      };
      const { getByTestId } = render(
        <AuthorisationsSearchSection {...propsWithError} />
      );
      expect(getByTestId('mv-accordion')).toBeInTheDocument();
    });

    it('should handle allPostApprovalWorkflowListing prop', () => {
      const propsWithData = {
        ...defaultProps,
        allPostApprovalWorkflowListing: [
          { id: '1', name: 'Test Workflow' } as any,
        ],
      };
      const { getByTestId } = render(
        <AuthorisationsSearchSection {...propsWithData} />
      );
      expect(getByTestId('mv-accordion')).toBeInTheDocument();
    });
  });

  describe('Button interactions', () => {
    it('should not trigger onAccordionSearch when button is disabled due to loading', () => {
      const onAccordionSearchMock = jest.fn();
      const loadingProps = {
        ...defaultProps,
        isApprovalWorkflowListingFetching: true,
        onAccordionSearch: onAccordionSearchMock,
      };
      const { getByTestId } = render(
        <AuthorisationsSearchSection {...loadingProps} />
      );
      const button = getByTestId('apply-button');
      expect(button).toBeDisabled();
      fireEvent.click(button);
      // Button click should not trigger callback when disabled
      expect(onAccordionSearchMock).not.toHaveBeenCalled();
    });

    it('should enable button when not fetching', () => {
      const { getByTestId } = render(
        <AuthorisationsSearchSection {...defaultProps} />
      );
      const button = getByTestId('apply-button');
      expect(button).not.toBeDisabled();
    });
  });
});
