/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { compose, connect } from '@mep-ui/framework';
import { useIsCompositeDesktop } from '@mesh-tenant-multiverse-common/react';
import { isStaffPortal } from '@mesh-tenant-multiverse-ui-common/mv-utils';
import {
  Actions,
  Resources,
  useAuthoriser,
} from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import { useCallback, useEffect, useState } from 'react';
import {
  genericUnathorisedMessage,
  PDP_QUERY_ACTIONS,
  reviewTransferPageTitle,
  transferConfirmationPageTitle,
  transferDetailsPageTitle,
} from '../../common/constants';
import {
  DivisionOptionType,
  DivisionType,
  ErrorResponse,
} from '../../common/types';
import { useGetFromAccountOptions } from '../../common/useGetFromAccountOptions';
import { TransferConfirmation } from '../../components/TransferConfirmation';
import { TransferDetails } from '../../components/TransferDetails';
import { TransferReview } from '../../components/TransferReview';
import BannerAlertBox from '../../galaxy-common/BannerAlertBox/BannerAlertBox';
import { scrollToTop } from '../../galaxy-common/utils/DOMUtils';
import { useOrganizationId } from '../../hooks/useOrganizationId';
import {
  accountListActions,
  arrangementDetailsActions,
  divisionListActions,
  getAllAccountList,
  getAllArrangementDetails,
  getAllDivisionList,
  getAllPaymentIdentifier,
  getAllTransferCreate,
  isAccountListError as isAccountListErrorSelector,
  isAccountListFetching as isAccountListFetchingSelector,
  isArrangementDetailsError as isArrangementDetailsErrorSelector,
  isArrangementDetailsFetching as isArrangementDetailsFetchingSelector,
  isDivisionListError as isDivisionListErrorSelector,
  isDivisionListFetching as isDivisionListFetchingSelector,
  isPaymentIdentifierError as isPaymentIdentifierErrorSelector,
  isPaymentIdentifierFetching as isPaymentIdentifierFetchingSelector,
  isTransferCreateError as isTransferCreateErrorSelector,
  isTransferCreateFetching as isTransferCreateFetchingSelector,
  paymentIdentifierActions,
  paymentIdentifierEntityActions,
  transferCreateActions,
  transferCreateEntityActions,
} from '../../store/generated';
import {
  getPostPaymentIdentifierErrors,
  getPostPaymentIdentifierStatusCode,
} from '../../store/selectors/paymentIdentifier';
import {
  getPostTransferCreateErrors,
  getPostTransferCreateStatusCode,
} from '../../store/selectors/transferCreate';
import store from '../../store/store';
import type {
  Account,
  ArrangementDetailsParamsPayload,
  GetAccountListParamsPayload,
  getDivisionListParamsPayload,
  Payment,
  PostGeneratePaymentIdParams,
  PostPaymentsOptionsPayload,
  PostPaymentsParamsPayload,
  RequestOptionsPayload,
  RootState,
} from '../../store/types';
import {
  defaultDivisionData,
  defaultFormData,
  TransferFormDataType,
} from './common';
import {
  reviewTransferPage,
  transferConfirmationPage,
  transferDetailsPage,
} from './constants';

export type TransferFundsContainerProps = {
  submitTransfer: (
    params: PostPaymentsParamsPayload,
    options: PostPaymentsOptionsPayload
  ) => void;
  getPaymentId: (params: PostGeneratePaymentIdParams) => void;
  paymentId: string;
  clearTransfer: () => void;
  isTransfersFetching: boolean;
  transfer: Payment;
  allAccountList: Account[];
  apiStatus?: number;
  errors?: ErrorResponse[];
  isTransfersError: boolean;
  isAccountListFetching: boolean;
  isAccountListError: boolean;
  getAccountListByStatus: (
    params: GetAccountListParamsPayload,
    options: RequestOptionsPayload
  ) => void;
  isPaymentIdentifierError?: boolean;
  isPaymentIdentifierFetching: boolean;
  paymentIdentifierApiStatus?: number;
  paymentIdentifierErrors?: ErrorResponse[];
  isArrangementDetailsFetching: boolean;
  isArrangementDetailsError: boolean;
  postArrangementDetails: (params: ArrangementDetailsParamsPayload) => void;
  allArrangementDetails: any;
  getDivisionList: (
    params: getDivisionListParamsPayload,
    options: RequestOptionsPayload
  ) => void;
  isDivisionListFetching: boolean;
  isDivisionListError: boolean;
  allDivisionList: DivisionType[];
};

export function TransferFundsContainer({
  submitTransfer,
  clearTransfer,
  paymentId,
  getPaymentId,
  isTransfersFetching,
  transfer,
  apiStatus,
  errors,
  isTransfersError,
  isAccountListFetching,
  isAccountListError,
  allAccountList,
  getAccountListByStatus,
  isPaymentIdentifierError,
  isPaymentIdentifierFetching,
  paymentIdentifierApiStatus,
  paymentIdentifierErrors,
  isArrangementDetailsFetching,
  isArrangementDetailsError,
  postArrangementDetails,
  allArrangementDetails,
  getDivisionList,
  isDivisionListFetching,
  isDivisionListError,
  allDivisionList,
}: TransferFundsContainerProps) {
  const { defaultFromAccount, fromAccountOptions } =
    useGetFromAccountOptions(allAccountList);

  const [transferFundFormData, setTransferFundFormData] =
    useState<TransferFormDataType>(defaultFormData);

  const [hasEditClicked, setHasEditClicked] = useState<boolean>(false);

  const isCompositeDesktop = useIsCompositeDesktop();
  const orgId = useOrganizationId();

  useEffect(() => {
    if (defaultFromAccount && !transferFundFormData.fromAccount) {
      setTransferFundFormData((prev) => ({
        ...prev,
        fromAccount: defaultFromAccount,
      }));
    }
  }, [defaultFromAccount]);

  const [navigateTo, setNavigationTo] = useState(transferDetailsPage);

  const handleTransferFundFormDataChange = (
    newTransferFundFormData: TransferFormDataType
  ) => {
    setTransferFundFormData(newTransferFundFormData);
  };

  const initiateTransfer = (
    params: PostPaymentsParamsPayload,
    options: PostPaymentsOptionsPayload
  ) => {
    clearTransfer();
    submitTransfer(params, options);
  };

  const renderTransferFundsComponents = (newNavigateTo: string) => {
    setNavigationTo(newNavigateTo);
    scrollToTop();
  };

  const [isOrgIdFetching, setIsOrgIdFetching] = useState<boolean>(true);

  const [divisions, setDivisions] =
    useState<DivisionOptionType[]>(defaultDivisionData);
  const [selectedDivision, setSelectedDivision] =
    useState<DivisionOptionType | null>(null);

  // Track if division list has been fetched to avoid calling other APIs prematurely
  const [hasDivisionListBeenFetched, setHasDivisionListBeenFetched] = useState(
    !isStaffPortal()
  );

  const showDivisionField =
    !isStaffPortal() &&
    !isDivisionListFetching &&
    !isDivisionListError &&
    allDivisionList.length > 0;

  // Helper function to determine if data should be fetched based on composite desktop and orgId conditions
  const getShouldFetchData = useCallback(() => {
    const isNonCompositeDesktop = !isCompositeDesktop;
    const hasOrgId = !!orgId;

    return isNonCompositeDesktop || (isCompositeDesktop && hasOrgId);
  }, [isCompositeDesktop, orgId]);

  const getAccountList = useCallback(
    (
      accountStatus: 'ACTIVE' | 'ACTIVE_AND_INACTIVE' = 'ACTIVE',
      divisionId?: string
    ) => {
      const params: GetAccountListParamsPayload = {
        pdpQueryAction: PDP_QUERY_ACTIONS.INITIATE_TRANSFER,
        accountStatus,
        ...(divisionId && { divisionId }),
        meta: {
          replaceEntities: ['accountList'],
        },
      };
      getAccountListByStatus(params, {
        headers: {
          ...(orgId && {
            'protected-orgId': orgId,
          }),
        },
      });
    },
    [isAccountListFetching, orgId]
  );

  const fetchDivisionList = useCallback(() => {
    const params: getDivisionListParamsPayload = {
      pdpQueryAction: PDP_QUERY_ACTIONS.INITIATE_TRANSFER,
      meta: {
        replaceEntities: ['divisionList'],
      },
    };

    if (!isDivisionListFetching) {
      getDivisionList(params, {
        headers: {
          ...(orgId && {
            'protected-orgId': orgId,
          }),
        },
      });
    }
  }, [isDivisionListFetching, orgId]);

  const onRefresh = () => {
    getAccountList('ACTIVE', selectedDivision?.id);
  };

  const getAccountListFn = (input?: string) =>
    getAccountList('ACTIVE', selectedDivision?.id);

  const onDivisionRefresh = () => {
    fetchDivisionList();
  };

  const renderCurrentPage = () => {
    switch (navigateTo) {
      case transferDetailsPage: {
        document.title = transferDetailsPageTitle;
        return (
          <TransferDetails
            transferFundFormData={transferFundFormData}
            handleTransferFundFormDataChange={handleTransferFundFormDataChange}
            renderTransferFundsComponents={renderTransferFundsComponents}
            isAccountListFetching={isAccountListFetching || isOrgIdFetching}
            isAccountListError={isAccountListError}
            fromAccountOptions={fromAccountOptions}
            onRefresh={onRefresh}
            postArrangementDetails={postArrangementDetails}
            divisions={divisions}
            onDivisionChange={onSelectDivision}
            onDivisionRefresh={onDivisionRefresh}
            showDivisionField={showDivisionField}
            isDivisionListFetching={!isStaffPortal() && isDivisionListFetching}
            isDivisionListError={isDivisionListError}
            getAccountListFn={getAccountListFn}
          />
        );
      }
      case reviewTransferPage:
        document.title = reviewTransferPageTitle;
        return (
          <TransferReview
            transferFundFormData={transferFundFormData}
            renderTransferFundsComponents={renderTransferFundsComponents}
            isTransfersFetching={isTransfersFetching}
            submitTransfer={initiateTransfer}
            isTransfersError={isTransfersError}
            apiStatus={apiStatus}
            paymentId={paymentId}
            getPaymentId={getPaymentId}
            postPaymentErrors={errors}
            hasEditClicked={hasEditClicked}
            setHasEditClicked={setHasEditClicked}
            isPaymentIdentifierFetching={isPaymentIdentifierFetching}
            isPaymentIdentifierError={isPaymentIdentifierError}
            paymentIdentifierApiStatus={paymentIdentifierApiStatus}
            paymentIdentifierErrors={paymentIdentifierErrors}
            isArrangementDetailsFetching={isArrangementDetailsFetching}
            isArrangementDetailsError={isArrangementDetailsError}
            allArrangementDetails={allArrangementDetails}
          />
        );

      case transferConfirmationPage:
        document.title = transferConfirmationPageTitle;
        return (
          <TransferConfirmation
            apiStatus={apiStatus}
            errors={errors}
            transferFundFormData={transferFundFormData}
            transfer={transfer}
            paymentId={paymentId}
            paymentIdentifierApiStatus={paymentIdentifierApiStatus}
            paymentIdentifierErrors={paymentIdentifierErrors}
          />
        );
      default:
        return null;
    }
  };

  const { authorised } = useAuthoriser(
    Resources.ACCOUNTS,
    Actions.INITIATE_PAYMENT
  );

  useEffect(() => {
    const shouldFetchData = getShouldFetchData();

    if (
      shouldFetchData &&
      !isDivisionListFetching &&
      hasDivisionListBeenFetched
    ) {
      fetchDivisionList();
      setIsOrgIdFetching(false);
      setHasDivisionListBeenFetched(false);
    }
  }, [getShouldFetchData, isDivisionListFetching]);

  // Track when division list fetch completes and conditionally fetch other data
  useEffect(() => {
    if (
      !isDivisionListFetching &&
      !hasDivisionListBeenFetched &&
      getShouldFetchData()
    ) {
      // Only call these APIs if division list is empty of if it is staff portal
      if (
        (!isDivisionListError && allDivisionList.length === 0) ||
        isStaffPortal()
      ) {
        getAccountList();
        setIsOrgIdFetching(false);
      }
    }
  }, [
    isDivisionListFetching,
    allDivisionList,
    hasDivisionListBeenFetched,
    getShouldFetchData,
  ]);

  useEffect(() => {
    const transformedDivisionList = allDivisionList.map((division) => ({
      id: division.divisionId,
      name: division.divisionName,
      label: division.divisionName,
    }));

    setDivisions([...defaultDivisionData, ...(transformedDivisionList ?? [])]);
  }, [allDivisionList]);

  const onSelectDivision = (division?: DivisionOptionType) => {
    if (division?.id && division?.label !== defaultDivisionData[0].label) {
      getAccountList('ACTIVE', division.id);
      setSelectedDivision(division);
    }
  };

  return authorised ? (
    <>{renderCurrentPage()}</>
  ) : (
    <BannerAlertBox id="payment-status-banner" styling="danger">
      {genericUnathorisedMessage}
    </BannerAlertBox>
  );
}

const mapStateToProps = (state: RootState) => ({
  isTransfersFetching: isTransferCreateFetchingSelector(state),
  transfer: getAllTransferCreate(state)[0],
  apiStatus: getPostTransferCreateStatusCode(state),
  errors: getPostTransferCreateErrors(state),
  isTransfersError: isTransferCreateErrorSelector(state),
  allAccountList: getAllAccountList(state),
  isAccountListError: isAccountListErrorSelector(state),
  isAccountListFetching: isAccountListFetchingSelector(state),
  paymentId: getAllPaymentIdentifier(state)[0]?.paymentId,
  isPaymentIdentifierError: isPaymentIdentifierErrorSelector(state),
  isPaymentIdentifierFetching: isPaymentIdentifierFetchingSelector(state),
  paymentIdentifierApiStatus: getPostPaymentIdentifierStatusCode(state),
  paymentIdentifierErrors: getPostPaymentIdentifierErrors(state),
  isArrangementDetailsFetching: isArrangementDetailsFetchingSelector(state),
  isArrangementDetailsError: isArrangementDetailsErrorSelector(state),
  allArrangementDetails: getAllArrangementDetails(state),
  isDivisionListFetching: isDivisionListFetchingSelector(state),
  isDivisionListError: isDivisionListErrorSelector(state),
  allDivisionList: getAllDivisionList(state),
});

const mapDispatchToProps = {
  submitTransfer:
    transferCreateActions.api.expGalaxyPaymentV2.transferCreate.post.request,
  clearTransfer:
    transferCreateEntityActions.api.expGalaxyPaymentV2.transferCreate.clear
      .request,
  getAccountListByStatus:
    accountListActions.api.expGalaxyPaymentV2.accountList.get.request,
  getPaymentId:
    paymentIdentifierActions.api.expGalaxyPaymentV2.paymentIdentifier.get
      .request,
  clearPaymentId:
    paymentIdentifierEntityActions.api.expGalaxyPaymentV2.paymentIdentifier
      .clear.request,
  postArrangementDetails:
    arrangementDetailsActions.api.expGalaxyPaymentV2.arrangementDetails.post
      .request,
  getDivisionList:
    divisionListActions.api.expGalaxyPaymentV2.divisionList.get.request,
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps, null, {
    context: store.contextRef,
  })
)(TransferFundsContainer);
