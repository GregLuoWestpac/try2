import { DivisionOptionType } from '../../common/types';
import { Account } from '../../store/types';

export type TransferFormDataType = {
  fromAccount: Account | null;
  toAccount: Account | null;
  debitDescription: string;
  creditDescription: string;
  totalAmount: string;
  division?: DivisionOptionType;
};

export const defaultDivisionData = [
  {
    id: 'select',
    name: 'Select',
    label: 'Select a division',
  },
];


export const defaultFormData: TransferFormDataType = {
  fromAccount: null,
  debitDescription: '',
  creditDescription: '',
  toAccount: null,
  totalAmount: '',
  division: undefined,
};

