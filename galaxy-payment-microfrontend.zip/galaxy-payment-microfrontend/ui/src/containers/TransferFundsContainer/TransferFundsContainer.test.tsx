import React from 'react';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';
import { useAuthoriser } from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import { useIsCompositeDesktop } from '@mesh-tenant-multiverse-common/react';
import { useOrganizationId } from '../../hooks/useOrganizationId';
import { useGetFromAccountOptions } from '../../common/useGetFromAccountOptions';
import { Payment } from '../../store/types';
import {
  TransferFundsContainer,
  type TransferFundsContainerProps,
} from './TransferFundsContainer';

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useClose: () => ({
    closeTab: jest.fn(),
  }),
  useIsCompositeDesktop: jest.fn(),
}));

jest.mock('../../hooks/useOrganizationId', () => ({
  useOrganizationId: jest.fn(),
}));

jest.mock('../../store/store', () => ({
  __esModule: true,
  default: {
    dispatch: jest.fn(),
  },
}));

jest.mock(
  '@mesh-tenant-user-authorisation-policy-decision-engine/components',
  () => ({
    MVCard: function MockComponent({
      children,
    }: {
      children: React.ReactNode;
    }) {
      return <div>{children}</div>;
    },

    MVDetailSection: function MockComponent({
      children,
    }: {
      children: React.ReactNode;
    }) {
      return <div>{children}</div>;
    },
    useAuthoriser: jest.fn(),
    Resources: {
      ACCOUNTS: 'ACCOUNTS',
    },
    Actions: {
      VIEW_ACCOUNTS: 'VIEW_ACCOUNTS',
    },
  })
);

jest.mock('../../components/TransferDetails', () => ({
  TransferDetails: function MockComponent() {
    return <div>Mock TransferDetails</div>;
  },
}));

jest.mock('../../common/useGetFromAccountOptions', () => ({
  useGetFromAccountOptions: jest.fn(),
}));

jest.mock('../../galaxy-common/utils/DOMUtils', () => ({
  scrollToTop: jest.fn(),
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-utils', () => ({
  isStaffPortal: jest.fn(),
  convertSydneyLocalTimeToUtc: jest.fn((date: string) =>
    date ? `${date}T00:00:00.000Z` : ''
  ),
}));

const mockTransfer: Payment = {
  id: 'string',
  creationDateTime: '2024-02-12T03:24:18.680Z',
  groupInformation: {
    groupStatus: 'string',
    originalControlSum: 'string',
    originalCreationDateTime: '2024-02-12T03:24:18.680Z',
    originalNumberOfTransactions: 'string',
  },
  groupStatusReasonInformation: [
    {
      reason: 'string',
      additionalInformation: 'string',
    },
  ],
  paymentInformation: {
    paymentInformationStatus: 'string',
    paymentId: 'string',
  },
  paymentStatusReasonInformation: [
    {
      reason: 'string',
      additionalInformation: 'string',
    },
  ],
  transactionInformation: [
    {
      transactionStatus: 'string',
      statusReasonInformation: [
        {
          reason: 'string',
          additionalInformation: 'string',
        },
      ],
    },
  ],
};

const defaultProps: TransferFundsContainerProps = {
  transfer: mockTransfer,
  isTransfersFetching: false,
  submitTransfer: jest.fn(),
  getAccountListByStatus: jest.fn(),
  allAccountList: [],
  isAccountListFetching: false,
  isTransfersError: false,
  clearTransfer: jest.fn(),
  isAccountListError: false,
  getPaymentId: jest.fn(),
  paymentId: 'test-payment-id',
  isPaymentIdentifierFetching: false,
  isArrangementDetailsFetching: false,
  postArrangementDetails: jest.fn(),
  allArrangementDetails: {},
  isArrangementDetailsError: false,
  getDivisionList: jest.fn(),
  isDivisionListFetching: false,
  isDivisionListError: false,
  allDivisionList: [],
};

describe('Testing TransferFundsContainer', () => {
  const mockOrgId = '06089457589';

  beforeEach(() => {
    jest.clearAllMocks();

    // Setup default mocks
    (useOrganizationId as jest.Mock).mockReturnValue(mockOrgId);
    (useIsCompositeDesktop as jest.Mock).mockReturnValue(true);
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: true });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      defaultFromAccount: null,
      fromAccountOptions: [],
    });
  });

  it('should match snapshot', () => {
    const { container } = render(<TransferFundsContainer {...defaultProps} />);
    expect(container).toMatchSnapshot();
  });

  it('Should show the transfer details screen by default', () => {
    const { getByText } = render(<TransferFundsContainer {...defaultProps} />);
    const transferDetailsComponent = getByText('Mock TransferDetails');
    expect(transferDetailsComponent).toBeInTheDocument();
  });

  it('should not call getAccountListByStatus when no orgId is available and isCompositeDesktop is true', () => {
    // Mock no orgId available
    (useOrganizationId as jest.Mock).mockReturnValue('');
    (useIsCompositeDesktop as jest.Mock).mockReturnValue(true);

    const getAccountListByStatus = jest.fn();
    render(
      <TransferFundsContainer
        {...defaultProps}
        getAccountListByStatus={getAccountListByStatus}
      />
    );
    expect(getAccountListByStatus).not.toHaveBeenCalled();
  });
});

describe('Testing error scenario', () => {
  beforeEach(() => {
    jest.resetAllMocks();

    // Setup authoriser mock to return false
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: false });

    // Setup other required mocks
    (useOrganizationId as jest.Mock).mockReturnValue('06089457589');
    (useIsCompositeDesktop as jest.Mock).mockReturnValue(true);
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      defaultFromAccount: null,
      fromAccountOptions: [],
    });
  });

  it('Should show the error in the page', () => {
    const { getByText } = render(<TransferFundsContainer {...defaultProps} />);

    expect(
      getByText(
        'You do not have permission to access this page. Contact your Administrator for more information.'
      )
    ).toBeInTheDocument();
  });
});

describe('showDivisionField logic', () => {
  const mockIsStaffPortal =
    require('@mesh-tenant-multiverse-ui-common/mv-utils').isStaffPortal;

  beforeEach(() => {
    jest.clearAllMocks();
    (useAuthoriser as jest.Mock).mockReturnValue({ authorised: true });
    (useGetFromAccountOptions as jest.Mock).mockReturnValue({
      defaultFromAccount: null,
      fromAccountOptions: [],
    });
    (useOrganizationId as jest.Mock).mockReturnValue('ORG123');
  });

  it('should not show division field when isStaffPortal is true', () => {
    mockIsStaffPortal.mockReturnValue(true);

    const { container } = render(
      <TransferFundsContainer
        {...defaultProps}
        isDivisionListFetching={false}
        allDivisionList={[
          {
            divisionId: 'DIV1',
            divisionName: 'Division 1',
            id: '123',
          },
        ]}
      />
    );

    // The component passes showDivisionField to PaymentDetails
    // which should be false when isStaffPortal is true
    expect(container).toBeTruthy();
  });

  it('should not show division field when division list is empty', () => {
    mockIsStaffPortal.mockReturnValue(false);

    const { container } = render(
      <TransferFundsContainer
        {...defaultProps}
        isDivisionListFetching={false}
        allDivisionList={[]}
      />
    );

    expect(container).toBeTruthy();
  });

  it('should not show division field when division list is fetching', () => {
    mockIsStaffPortal.mockReturnValue(false);

    const { container } = render(
      <TransferFundsContainer
        {...defaultProps}
        isDivisionListFetching={true}
        allDivisionList={[
          {
            divisionId: 'DIV1',
            divisionName: 'Division 1',
            id: '555',
          },
        ]}
      />
    );

    expect(container).toBeTruthy();
  });

  it('should show division field when not staff portal, not fetching, and has divisions', () => {
    mockIsStaffPortal.mockReturnValue(false);

    const { container } = render(
      <TransferFundsContainer
        {...defaultProps}
        isDivisionListFetching={false}
        allDivisionList={[
          {
            divisionId: 'DIV1',
            divisionName: 'Division 1',
            id: '2222',
          },
        ]}
      />
    );

    expect(container).toBeTruthy();
  });
});
