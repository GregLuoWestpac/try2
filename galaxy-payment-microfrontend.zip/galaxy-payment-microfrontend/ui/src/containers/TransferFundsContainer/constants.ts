export const transferDetailsPage = 'transfer-details';
export const reviewTransferPage = 'review-transfer';
export const transferConfirmationPage = 'transfer-confirmation';
