/* eslint-disable @typescript-eslint/no-unsafe-return */
import { useClose } from '@mesh-tenant-multiverse-common/react';
import {
  act,
  fireEvent,
  render,
  screen,
  waitFor,
} from '@testing-library/react';
import { genericErrorMessage } from '../../common/constants';
import { PaymentDetailsContainer } from './PaymentDetailsContainer';
import {
  MakerCheckerApiClientProps,
  GetActivitySummaryData,
} from '../../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types';

import { useMakerCheckerLoader } from '../../widgets/galaxymakerchecker-v1';
jest.mock('../../store/store', () => ({
  __esModule: true,
  default: {
    dispatch: jest.fn(),
  },
}));
const mockGlobalDispatch = jest.fn();

jest.mock('@mep-ui/framework', () => ({
  ...jest.requireActual('@mep-ui/framework'),
  useGlobalSelector: jest.fn((selector: any) => {
    const mockState = {
      global: {
        galaxy: {
          context: {
            selectedPayment: {
              id: 'test-payment-id',
              receiptNumber: 'WP4123972326104',
              instructionTraceIdentification: 'trace-123',
              debitAccountIdentification: 'debit-456',
            },
            intentTimestamp: null,
          },
        },
      },
    };
    return selector ? selector(mockState) : mockState;
  }),
  useGlobalDispatch: () => mockGlobalDispatch,
}));

jest.mock('../../components', () => ({
  PageLoader: function MockComponent() {
    return <div>Mock PageLoader</div>;
  },
}));

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  useClose: jest.fn(),
}));

jest.mock('../../components/DetailSections/SummarySection', () => ({
  SummarySection: jest.fn(() => <div>SummarySection</div>),
}));

jest.mock('../../components/DetailSections/FromSection', () => ({
  FromSection: jest.fn(() => <div>FromSection</div>),
}));

jest.mock('../../components/DetailSections/ToSection', () => ({
  ToSection: jest.fn(() => <div>ToSection</div>),
}));

jest.mock('../../components/DetailSections/DetailsSection', () => ({
  DetailsSection: jest.fn(() => <div>DetailsSection</div>),
}));

jest.mock(
  '../../components/DetailSections/PaymentActivity/PaymentActivitySection',
  () => ({
    __esModule: true,
    default: jest.fn(() => <div>PaymentActivitySection</div>),
  })
);

jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: function MockComponent({ children }: { children: React.ReactNode }) {
    return <div>{children}</div>;
  },
}));
jest.mock('@mesh-tenant-multiverse-ui-common/mv-pageloader', () => ({
  MVPageLoader: function MockComponent(props: any) {
    return <div data-testid="page-loader">Loading</div>;
  },
}));

// Mock useMakerCheckerLoader hook
jest.mock('../../widgets/galaxymakerchecker-v1', () => ({
  __esModule: true,
  default: jest.fn((props: MakerCheckerApiClientProps) => {
    // Use queueMicrotask instead of setTimeout for immediate async execution
    queueMicrotask(() => {
      props.onApiResponse?.({
        data: {
          entities: {
            activitySummary: [
              {
                id: 'mock-id',
                createdAt: '2024-01-01T00:00:00Z',
                createdBy: 'John',
                authorisedAt: '2024-01-02T00:00:00Z',
                authorisedBy: 'May',
              },
            ],
          },
        },
      });
    });
    return <div data-testid="mock-widget">GalaxyWidget</div>;
  }),
  useMakerCheckerLoader: jest.fn(() => ({
    isLoadingWidget: false,
  })),
}));

jest.mock('../../store/generated', () => ({
  getAllPaymentDetails: jest.fn(() => [
    {
      id: 'test-payment-detail-id',
      amount: '1000.00',
      currencyCode: 'AUD',
    },
  ]),
  isPaymentCreateFetching: jest.fn(() => false),
  isPaymentCreateError: jest.fn(() => false),
  paymentDetailsActions: {
    api: {
      expGalaxyPaymentV2: {
        paymentDetails: {
          post: {
            request: jest.fn(),
          },
        },
      },
    },
  },
  paymentDetailsEntityActions: {
    api: {
      expGalaxyPaymentV2: {
        paymentDetails: {
          clear: {
            request: jest.fn(),
          },
        },
      },
    },
  },
}));

const defaultProps = {
  allPaymentDetails: [
    {
      id: 'f343cd55-3e0e-423c-afa9-03612c4cd380',
      status: undefined,
      creationDateTime: '2024-07-02T04:22:08.143Z',
      amount: {
        amount: '0.01',
        currency: 'AUD',
      },
      debitAccount: {
        nickName: 'Bartoletti, Bergstrom and Kuhn',
        accountId: '035845350238948',
      },
      debitDescription: 'Performing NPP payment',
      beneficiary: {
        name: 'Creditor Name',
        nickName: 'Creditor Name',
        accountId: '062001062001456789',
      },
      creditAccount: {
        nickName: 'Creditor Name',
        accountId: '062001062001456789',
      },
      creditorDescription: 'Performing an NPP payment',
      reference: 'INV-123456790',
      paymentMethod: {},
      receiptNumber: 'WP4123972326104',
    },
  ],
  isPaymentDetailsFetching: false,
  isPaymentDetailsError: false,
  getPaymentDetails: jest.fn(),
  clearPaymentDetails: jest.fn(),
};

describe('Testing PaymentDetailsContainer from the response', () => {
  const mockCloseTab = jest.fn();
  beforeEach(() => {
    jest.clearAllMocks();
    (useClose as jest.Mock).mockReturnValue({ closeTab: mockCloseTab });
    (useMakerCheckerLoader as jest.Mock).mockReturnValue({
      isLoadingWidget: false,
    });
  });

  it('should match snapshot', async () => {
    const { asFragment } = render(
      <>{<PaymentDetailsContainer {...defaultProps} />}</>
    );

    // Wait for loading to complete
    await waitFor(() => {
      expect(screen.queryByText('Loading')).not.toBeInTheDocument();
    });

    expect(asFragment()).toMatchSnapshot();
  });

  it('should display payment activity summary', async () => {
    const PaymentActivitySectionMock =
      require('../../components/DetailSections/PaymentActivity/PaymentActivitySection').default;

    render(<PaymentDetailsContainer {...defaultProps} />);

    await waitFor(() => {
      expect(PaymentActivitySectionMock).toHaveBeenCalledWith(
        expect.objectContaining({
          paymentActivity: expect.objectContaining({
            created: expect.objectContaining({
              name: 'John',
              timestamp: '2024-01-01T00:00:00Z',
            }),
            authorised: expect.objectContaining({
              name: 'May',
              timestamp: '2024-01-02T00:00:00Z',
            }),
          }),
        }),
        expect.anything()
      );
    });
  });

  it('should show alert box when there is an error and not fetching', () => {
    const { getByText } = render(
      <PaymentDetailsContainer {...defaultProps} isPaymentDetailsError />
    );
    expect(getByText(new RegExp(genericErrorMessage, 'i'))).toBeInTheDocument();
  });

  it('Should show spinner when page is loading', () => {
    // Mock useMakerCheckerLoader to return isLoadingWidget: true
    (useMakerCheckerLoader as jest.Mock).mockReturnValue({
      isLoadingWidget: true,
    });

    const { getByText } = render(<PaymentDetailsContainer {...defaultProps} />);
    expect(getByText('Loading')).toBeInTheDocument();

    // Reset mock to default
    (useMakerCheckerLoader as jest.Mock).mockReturnValue({
      isLoadingWidget: false,
    });
  });

  it('Should call mockCloseTab when close button is clicked', async () => {
    const { getByText } = render(<PaymentDetailsContainer {...defaultProps} />);

    // Wait for content to load
    await waitFor(() => {
      expect(getByText('Close')).toBeInTheDocument();
    });

    const closeButton = getByText('Close');
    fireEvent.click(closeButton);
    expect(mockCloseTab).toHaveBeenCalled();
  });

  it('should call getPaymentDetails when try again button is clicked in error state', () => {
    const { getByText } = render(
      <PaymentDetailsContainer {...defaultProps} isPaymentDetailsError />
    );
    const tryAgainButton = getByText('try again');
    fireEvent.click(tryAgainButton);
    expect(defaultProps.getPaymentDetails).toHaveBeenCalled();
  });

  it('should show PageLoader when allPaymentDetails is empty', () => {
    // Mock useMakerCheckerLoader to return isLoadingWidget: true to show loader
    (useMakerCheckerLoader as jest.Mock).mockReturnValue({
      isLoadingWidget: true,
    });

    const { getByText } = render(
      <PaymentDetailsContainer {...defaultProps} allPaymentDetails={[]} />
    );
    expect(getByText('Loading')).toBeInTheDocument();

    // Reset mock to default
    (useMakerCheckerLoader as jest.Mock).mockReturnValue({
      isLoadingWidget: false,
    });
  });

  it('should call clearPaymentDetails on unmount', () => {
    const { unmount } = render(<PaymentDetailsContainer {...defaultProps} />);
    unmount();
    expect(defaultProps.clearPaymentDetails).toHaveBeenCalled();
  });

  it('should show PageLoader when widget is loading', () => {
    // Mock useMakerCheckerLoader to return isLoadingWidget: true

    (useMakerCheckerLoader as jest.Mock).mockReturnValue({
      isLoadingWidget: true,
    });

    const { getByText } = render(<PaymentDetailsContainer {...defaultProps} />);
    expect(getByText('Loading')).toBeInTheDocument();
    // Reset mock to default
    (useMakerCheckerLoader as jest.Mock).mockReturnValue({
      isLoadingWidget: false,
    });
  });

  it('should render content when widget is loaded', async () => {
    // Ensure useMakerCheckerLoader returns isLoadingWidget: false
    (useMakerCheckerLoader as jest.Mock).mockReturnValue({
      isLoadingWidget: false,
    });

    const { getByText, queryByText } = render(
      <PaymentDetailsContainer {...defaultProps} />
    );
    await waitFor(() => {
      // Should not show loading
      expect(queryByText('Loading')).not.toBeInTheDocument();

      // Should show close button (content is rendered)
      expect(getByText('Close')).toBeInTheDocument();
    });
  });

  it('should render PaymentActivitySection with retry function', async () => {
    const PaymentActivitySectionMock =
      require('../../components/DetailSections/PaymentActivity/PaymentActivitySection').default;

    render(<PaymentDetailsContainer {...defaultProps} />);

    await waitFor(() => {
      expect(PaymentActivitySectionMock).toHaveBeenCalledWith(
        expect.objectContaining({
          retryPaymentActivity: expect.any(Function),
        }),
        expect.anything()
      );
    });
  });

  it('should handle onApiError and show error state', async () => {
    const PaymentActivitySectionMock =
      require('../../components/DetailSections/PaymentActivity/PaymentActivitySection').default;

    const mockWithError = jest.fn((props: MakerCheckerApiClientProps) => {
      queueMicrotask(() => {
        props.onApiError?.(new Error('API Error'));
      });
      return <div data-testid="mock-widget-error">GalaxyWidget</div>;
    });

    jest
      .spyOn(require('../../widgets/galaxymakerchecker-v1'), 'default')
      // @ts-expect-error
      .mockImplementation(mockWithError);

    render(<PaymentDetailsContainer {...defaultProps} />);

    // PaymentActivitySection should be called with error state
    await waitFor(() => {
      expect(PaymentActivitySectionMock).toHaveBeenCalledWith(
        expect.objectContaining({
          isPaymentActivityError: true,
          paymentActivity: undefined,
          retryPaymentActivity: expect.any(Function),
        }),
        expect.anything()
      );
    });
  });

  it('should handle onApiResponse with empty data', async () => {
    const PaymentActivitySectionMock =
      require('../../components/DetailSections/PaymentActivity/PaymentActivitySection').default;

    const mockWithEmptyData = jest.fn((props: MakerCheckerApiClientProps) => {
      queueMicrotask(() => {
        props.onApiResponse?.({});
      });
      return <div data-testid="mock-widget-empty">GalaxyWidget</div>;
    });

    jest
      .spyOn(require('../../widgets/galaxymakerchecker-v1'), 'default')
      // @ts-expect-error
      .mockImplementation(mockWithEmptyData);

    render(<PaymentDetailsContainer {...defaultProps} />);

    // PaymentActivitySection should be rendered but with no paymentActivity data
    await waitFor(() => {
      expect(PaymentActivitySectionMock).toHaveBeenCalledWith(
        expect.objectContaining({
          paymentActivity: undefined,
          isPaymentActivityError: false,
        }),
        expect.anything()
      );
    });
  });

  it('should handle onApiResponse with partial activity summary data', async () => {
    const PaymentActivitySectionMock =
      require('../../components/DetailSections/PaymentActivity/PaymentActivitySection').default;

    const mockWithPartialData = jest.fn((props: MakerCheckerApiClientProps) => {
      queueMicrotask(() => {
        props.onApiResponse?.({
          data: {
            entities: {
              activitySummary: [
                {
                  id: 'partial-id',
                  createdAt: '2024-01-01T00:00:00Z',
                  createdBy: 'John',
                  // Missing authorisedAt and authorisedBy
                },
              ],
            },
          },
        });
      });
      return <div data-testid="mock-widget-partial">GalaxyWidget</div>;
    });

    jest
      .spyOn(require('../../widgets/galaxymakerchecker-v1'), 'default')
      // @ts-expect-error
      .mockImplementation(mockWithPartialData);

    render(<PaymentDetailsContainer {...defaultProps} />);

    await waitFor(() => {
      expect(PaymentActivitySectionMock).toHaveBeenCalledWith(
        expect.objectContaining({
          paymentActivity: expect.objectContaining({
            created: expect.objectContaining({
              name: 'John',
              timestamp: '2024-01-01T00:00:00Z',
            }),
          }),
        }),
        expect.anything()
      );
    });
  });

  it('should pass isLoading=false to PaymentActivitySection on initial load', async () => {
    const PaymentActivitySectionMock =
      require('../../components/DetailSections/PaymentActivity/PaymentActivitySection').default;

    render(<PaymentDetailsContainer {...defaultProps} />);

    // On initial load, even though isPaymentActivityFetching is true,
    // isLoading should be false because hasPaymentActivityDataLoaded is false
    await waitFor(() => {
      expect(PaymentActivitySectionMock).toHaveBeenCalledWith(
        expect.objectContaining({
          isLoading: false,
        }),
        expect.anything()
      );
    });
  });

  it('should pass isLoading=true to PaymentActivitySection when refetching after initial load', async () => {
    const PaymentActivitySectionMock =
      require('../../components/DetailSections/PaymentActivity/PaymentActivitySection').default;

    let capturedOnApiResponse: ((data: any) => void) | undefined;
    let capturedRetryPaymentActivity: (() => void) | undefined;
    let renderCount = 0;

    const mockWithCapture = jest.fn((props: MakerCheckerApiClientProps) => {
      renderCount++;
      capturedOnApiResponse = props.onApiResponse;

      // Only call onApiResponse for the first render (initial load)
      if (renderCount === 1) {
        queueMicrotask(() => {
          props.onApiResponse?.({
            data: {
              entities: {
                activitySummary: [
                  {
                    id: 'mock-id',
                    createdAt: '2024-01-01T00:00:00Z',
                    createdBy: 'John',
                    authorisedAt: '2024-01-02T00:00:00Z',
                    authorisedBy: 'May',
                  },
                ],
              },
            },
          });
        });
      }

      return <div data-testid="mock-widget">GalaxyWidget</div>;
    });

    jest
      .spyOn(require('../../widgets/galaxymakerchecker-v1'), 'default')
      // @ts-expect-error
      .mockImplementation(mockWithCapture);

    const { getByText } = render(<PaymentDetailsContainer {...defaultProps} />);

    // Wait for initial load to complete
    await waitFor(() => {
      expect(getByText('Close')).toBeInTheDocument();
    });

    // Capture the retry function from the PaymentActivitySection props
    await waitFor(() => {
      const calls = PaymentActivitySectionMock.mock.calls;
      const lastCall = calls[calls.length - 1];
      capturedRetryPaymentActivity = lastCall[0].retryPaymentActivity;
      expect(capturedRetryPaymentActivity).toBeDefined();
    });

    // Clear previous calls
    PaymentActivitySectionMock.mockClear();

    // Trigger a retry/refetch
    act(() => {
      capturedRetryPaymentActivity?.();
    });

    // Now isLoading should be true because hasPaymentActivityDataLoaded is true
    // and isPaymentActivityFetching is true
    await waitFor(() => {
      const calls = PaymentActivitySectionMock.mock.calls;
      expect(calls.length).toBeGreaterThan(0);
      const latestCall = calls[calls.length - 1];
      expect(latestCall[0]).toMatchObject({
        isLoading: true,
      });
    });
  });
});
