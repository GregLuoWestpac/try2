import type {
  PostPaymentDetailsParams,
  PostPaymentDetailsParamsPayload,
} from '../../store/types';
import { paymentDetailsKeyType } from '../../common/constants';

export const generateGetPaymentDetailsParams = (
  instructionTraceIdentification: string,
  debitAccountIdentification: string
): PostPaymentDetailsParamsPayload => {
  const postTransactionDetailsParams: PostPaymentDetailsParams = {
    keyIdentifier: instructionTraceIdentification,
    keyType: paymentDetailsKeyType.ITRID,
    accountId: {
      BSB: debitAccountIdentification?.slice(0, 6),
      accountNumber: debitAccountIdentification?.slice(6),
    },
  };
  const params: PostPaymentDetailsParamsPayload = {
    params: postTransactionDetailsParams,
    meta: {
      replaceEntities: ['transactionDetails'],
    },
  };
  return params;
};
