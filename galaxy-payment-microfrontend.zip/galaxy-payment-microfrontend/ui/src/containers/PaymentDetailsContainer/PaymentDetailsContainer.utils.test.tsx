import { generateGetPaymentDetailsParams } from './PaymentDetailsContainer.utils';
import type { PostPaymentDetailsParamsPayload } from '../../store/types';

describe('generateGetPaymentDetailsParams', () => {
  it('should generate correct payment details params payload', () => {
    const instructionTraceIdentification = 'test-id';
    const debitAccountIdentification = '1112223456789';
    const expectedParams: PostPaymentDetailsParamsPayload = {
      params: {
        keyIdentifier: instructionTraceIdentification,
        keyType: 'ITRID',
        accountId: {
          BSB: '111222',
          accountNumber: '3456789',
        },
      },
      meta: {
        replaceEntities: ['transactionDetails'],
      },
    };

    const result = generateGetPaymentDetailsParams(
      instructionTraceIdentification,
      debitAccountIdentification
    );

    expect(result).toEqual(expectedParams);
  });
});
