/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import {
  compose,
  connect,
  useGlobalDispatch,
  useGlobalSelector,
} from '@mep-ui/framework';
import { useClose } from '@mesh-tenant-multiverse-common/react';
import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card';
import { MVPageLoader as PageLoader } from '@mesh-tenant-multiverse-ui-common/mv-pageloader';
import { Alert, Button, Grid, GridItem } from '@westpac/ui';
import { useCallback, useEffect, useRef, useState } from 'react';
import { genericErrorMessage } from '../../common/constants';
import { DetailsSection } from '../../components/DetailSections/DetailsSection';
import { FromSection } from '../../components/DetailSections/FromSection';
import { SummarySection } from '../../components/DetailSections/SummarySection';
import { ToSection } from '../../components/DetailSections/ToSection';
import {
  getAllPaymentDetails,
  isPaymentDetailsError as isPaymentDetailsErrorSelector,
  isPaymentDetailsFetching as isPaymentDetailsFetchingSelector,
  paymentDetailsActions,
  paymentDetailsEntityActions,
} from '../../store/generated';
import { isAuthenticatedError as isAuthenticatedErrorSelector } from '../../store/selectors/paymentCreate';
import store from '../../store/store';
import {
  PaymentListing,
  PostPaymentDetail,
  PostPaymentDetailsParamsPayload,
} from '../../store/types';
import { GlobalState, RootState } from '../../store/types/RootStates';
import { generateGetPaymentDetailsParams } from './PaymentDetailsContainer.utils';
import PaymentActivitySection, {
  PaymentActivitySectionProps,
} from 'ui/src/components/DetailSections/PaymentActivity/PaymentActivitySection';
import GalaxyMakerCheckerWrapper, {
  useMakerCheckerLoader,
} from '../../widgets/galaxymakerchecker-v1';
import { GetActivitySummaryData } from '../../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types';

export type PaymentDetailsContainerProps = {
  allPaymentDetails: PostPaymentDetail[];
  isPaymentDetailsFetching: boolean;
  isPaymentDetailsError: boolean;
  getPaymentDetails: (params: PostPaymentDetailsParamsPayload) => void;
  clearPaymentDetails: () => void;
};

export function PaymentDetailsContainer({
  allPaymentDetails,
  isPaymentDetailsFetching,
  isPaymentDetailsError,
  getPaymentDetails,
  clearPaymentDetails,
}: PaymentDetailsContainerProps) {
  const { closeTab } = useClose();
  const globalDispatch = useGlobalDispatch();
  const selectedPayment: PaymentListing = useGlobalSelector(
    (state: GlobalState) => state?.global?.galaxy?.context?.selectedPayment
  );

  const initialTsRef = useRef(Date.now());
  const hasPaymentActivityDataLoaded = useRef(false);
  const [refreshTrigger, setRefreshTrigger] = useState(initialTsRef.current);

  const { isLoadingWidget } = useMakerCheckerLoader('maker-checker-api-client');
  const [paymentActivityResult, setPaymentActivityResult] =
    useState<PaymentActivitySectionProps | null>(null);

  const [isPaymentActivityFetching, setIsPaymentActivityFetching] =
    useState(true);
  const [isPaymentActivityError, setIsPaymentActivityError] = useState(false);

  /* directly compute loading state instead of useEffect and useState
   so that it is not one render behind if refetch is triggered. */
  const isLoading =
    isLoadingWidget || isPaymentDetailsFetching || !allPaymentDetails.length;

  // Track when payment activity data has been loaded at least once
  useEffect(() => {
    if (!isPaymentActivityFetching && !isPaymentActivityError) {
      hasPaymentActivityDataLoaded.current = true;
    }
  }, [isPaymentActivityFetching, isPaymentActivityError]);

  const intentTimestamp: string | null = useGlobalSelector(
    (state: GlobalState) =>
      state?.global?.galaxy?.context?.intentTimestamp ?? null
  );

  const refreshPaymentActivityWidget = useCallback(() => {
    setIsPaymentActivityFetching(true);
    // Don't clear error immediately - keep error state visible while retrying
    // Error will be cleared in onApiResponse if successful
    setRefreshTrigger(Date.now());
  }, [setRefreshTrigger]);

  const getPaymentDetailsBySelectPayment = useCallback(() => {
    if (selectedPayment?.id) {
      const params = generateGetPaymentDetailsParams(
        selectedPayment?.instructionTraceIdentification,
        selectedPayment?.debitAccountIdentification
      );
      getPaymentDetails(params);
      refreshPaymentActivityWidget();
    }
  }, [selectedPayment?.id, refreshPaymentActivityWidget]);

  const onApiResponse = (res: { data?: GetActivitySummaryData } = {}) => {
    setIsPaymentActivityFetching(false);
    setIsPaymentActivityError(false);
    if (res.data) {
      const activitySummary = res.data.entities?.activitySummary?.[0];
      setPaymentActivityResult({
        paymentActivity: {
          created: {
            name: activitySummary?.createdBy || '',
            timestamp: activitySummary?.createdAt || '',
          },
          ...(activitySummary?.authorisedBy &&
            activitySummary?.authorisedAt && {
              authorised: {
                name: activitySummary?.authorisedBy || '',
                timestamp: activitySummary?.authorisedAt || '',
              },
            }),
        },
      });
    }
  };

  const onApiError = (err: unknown) => {
    setPaymentActivityResult(null);
    setIsPaymentActivityError(true);
    setIsPaymentActivityFetching(false);
  };

  // Reload behavior for OpenFin + browser tab return/back navigation
  useEffect(() => {
    getPaymentDetailsBySelectPayment();

    return () => {
      clearPaymentDetails();
    };
  }, [selectedPayment?.id, intentTimestamp, getPaymentDetailsBySelectPayment]);

  const handleClose = async () => {
    await closeTab();
  };

  const hasPaymentDetailsError =
    isPaymentDetailsError && !isPaymentDetailsFetching;

  if (hasPaymentDetailsError) {
    return (
      <MVCard title="Payment details" template="narrow" bottomDivider={false}>
        <Alert look="danger" id="payment-details-error-banner" iconSize="small">
          {genericErrorMessage} Please&nbsp;
          <Button
            className="bg-danger-5 p-0 typography-body-11 h-0"
            look="link"
            soft
            onClick={getPaymentDetailsBySelectPayment}
          >
            try again
          </Button>
          .
        </Alert>
        <GridItem className="w-full border-t border-border pt-2.5" span={12}>
          <Button size="small" look="hero" soft onClick={handleClose}>
            Close
          </Button>
        </GridItem>
      </MVCard>
    );
  }

  const paymentDetail = allPaymentDetails[0];

  return (
    <>
      {refreshTrigger && (
        <GalaxyMakerCheckerWrapper
          apiName="getActivitySummary"
          trigger={refreshTrigger}
          options={{
            headers: {
              ...(selectedPayment.receiptNumber && {
                'x-channelRequestId': selectedPayment.receiptNumber,
              }),
            },
          }}
          params={{}}
          onApiResponse={onApiResponse}
          onApiError={onApiError}
        />
      )}
      <MVCard
        title="Payment details"
        template="narrow"
        bottomDivider={!isLoading}
      >
        {isLoading ? (
          <PageLoader iconSize="medium" />
        ) : (
          <Grid className="xsl:gap-0 sm:gap-0 !gap-0">
            <SummarySection paymentDetail={paymentDetail} shouldShowValueDate />
            <FromSection paymentDetail={paymentDetail} />
            <ToSection paymentDetail={paymentDetail} />
            <DetailsSection paymentDetail={paymentDetail} />
            <PaymentActivitySection
              isLoading={isPaymentActivityFetching}
              paymentActivity={paymentActivityResult?.paymentActivity}
              isPaymentActivityError={isPaymentActivityError}
              retryPaymentActivity={refreshPaymentActivityWidget}
            />
            <GridItem
              className="w-full border-t border-border pt-2.5"
              span={12}
            >
              <Button size="small" look="hero" soft onClick={handleClose}>
                Close
              </Button>
            </GridItem>
          </Grid>
        )}
      </MVCard>
    </>
  );
}

const mapStateToProps = (state: RootState) => ({
  allPaymentDetails: getAllPaymentDetails(state),
  isPaymentDetailsFetching: isPaymentDetailsFetchingSelector(state),
  isPaymentDetailsError: isPaymentDetailsErrorSelector(state),
  isAuthenticatedError: isAuthenticatedErrorSelector(state),
});

const mapDispatchToProps = {
  getPaymentDetails:
    paymentDetailsActions.api.expGalaxyPaymentV2.paymentDetails.post.request,
  clearPaymentDetails:
    paymentDetailsEntityActions.api.expGalaxyPaymentV2.paymentDetails.clear
      .request,
};

export default compose(
  connect(mapStateToProps, mapDispatchToProps, null, {
    context: store.contextRef,
  })
)(PaymentDetailsContainer);
