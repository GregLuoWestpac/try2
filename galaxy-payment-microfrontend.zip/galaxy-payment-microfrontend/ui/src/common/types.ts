/* eslint-disable no-shadow */
import {
  DATE_FORMAT_YYYYMMDD,
  DateRange,
  getToday,
  getTodayAtLastYear,
  AmountRange,
} from '@mesh-tenant-multiverse-ui-common/mv-reacthookform';
import type { Account } from '../store/types';
import { PostApprovalWorkflowListData } from '../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types';
import {
  AuthorisationTab,
  Currency,
  defaultDivisionData,
  PayIdTypes,
  StatusTab,
  WorkFlowStatusMap,
} from './constants';

export type PayIdType = (typeof PayIdTypes)[number];
export enum BeneTypes {
  'PAYID' = 'PAYID',
  'BSB_ACCOUNT_NUMBER' = 'BSB_ACCOUNT_NUMBER',
}
export enum PAYID_TYPE {
  PHONE = 'TELI',
  EMAIL = 'EMAL',
  ABN_ACN = 'AUBN',
  ORGANISATION_ID = 'ORGN',
}
export type BeneType = keyof typeof BeneTypes;

export enum BeneStatus {
  ACTIVE = 'ACTIVE',
  ARCHIVED = 'ARCHIVED',
}
export type BeneStatusType = keyof typeof BeneStatus;

export type AccountOfBSBAndACC = {
  accountId: {
    BSB: string;
    accountNumber: string;
  };
  bankName: string;
  accountName: string;
};
export type AccountOfPayId = {
  payIDName: string;
  payIDType?: PayIdType;
  payIDValue: string;
};
export type Beneficiary = {
  id: string;
  externalId: string;
  nickname: string;
  currencyAmount: {
    amount?: string;
    currencyCode: Currency;
  };
  reference?: string;
  org: string;
  status: BeneStatusType;
  type: BeneType;
  account: AccountOfBSBAndACC | AccountOfPayId;
};

export type PaymentMethodType = {
  id: string;
  name: string;
  label: string;
};

export enum NppPaymentMethod {
  FastPayment = 'Fast Payment',
  Osko = 'Osko',
  OnPlatform = 'On-Platform',
  DE = 'Pay Anyone',
}

export const paymentProductMap = {
  DE: 'PP000020',
  OSKO: 'PP000004',
  SCT: 'PP000005',
  CAT_SCT: 'PP000012',
  TRANSFER: 'PP000016',
} as const;

export const defaultPaymentProductId = 'PP000004' as const;

export type SchemeEligibility = {
  paymentMethod: {
    code: string;
    description: string;
  };
};

export type SearchPaymentAccountDataType = {
  fromAccount?: Account;
  dateRange?: DateRange;
  amountRange?: AmountRange;
  division?: DivisionOptionType;
  paymentType?: string;
};

export type DivisionType = {
  id: string;
  divisionName: string;
  divisionId: string;
};

export type DivisionOptionType = {
  id: string;
  name: string;
  label: string;
};

export const defaultDateRange = {
  startDate: getToday().minus({ days: 7 }).toFormat(DATE_FORMAT_YYYYMMDD),
  endDate: getToday().toFormat(DATE_FORMAT_YYYYMMDD),
};

export const defaultSearchPaymentAccountFormData: SearchPaymentAccountDataType =
{
  fromAccount: undefined,
  amountRange: undefined,
  dateRange: defaultDateRange,
  paymentType: "All",
  division: defaultDivisionData[0],
};

export type AuthorisationSearchFormType = {
  authorisationTab: AuthorisationTabValues;
  statusTab: StatusTabValues;
  dateRange: DateRange;
};

export const defaultAuthorisationSearchFormData: AuthorisationSearchFormType = {
  authorisationTab: AuthorisationTab.ForYouToAuthorise,
  statusTab: StatusTab.Pending,
  dateRange: {
    startDate: getTodayAtLastYear().toFormat(DATE_FORMAT_YYYYMMDD) ?? '',
    endDate: getToday().toFormat(DATE_FORMAT_YYYYMMDD) ?? '',
  },
};

export type AddBeneficiaryFormDataType = {
  beneficiaryType?: BeneType;
  payIdType?: PAYID_TYPE;
  payIdName?: string;
  bsb: string;
  bankName: string;
  accountNumber: string;
  accountName: string;
  beneficiaryNickname: string;
  phone: string;
  email: string;
  abnAcn: string;
  organisationId: string;
  account?: AccountOfBSBAndACC | AccountOfPayId;
  saveBeneficiary: boolean;
};

export type MakePaymentFormDataType = {
  fromAccount: Account | null;
  toAccount: Beneficiary | null;
  toDescription: string;
  fromDescription: string;
  toReference: string;
  totalAmount: string;
  paymentMethod?: PaymentMethodType;
  beneficiary?: AddBeneficiaryFormDataType | null;
  division?: DivisionOptionType;
};

export const defaultFormData: MakePaymentFormDataType = {
  fromAccount: null,
  fromDescription: '',
  toDescription: '',
  toReference: '',
  toAccount: null,
  totalAmount: '',
  paymentMethod: undefined,
  beneficiary: {
    saveBeneficiary: false,
    beneficiaryType: undefined,
    payIdType: undefined,
    payIdName: '',
    bsb: '',
    bankName: '',
    accountNumber: '',
    accountName: '',
    beneficiaryNickname: '',
    phone: '',
    email: '',
    abnAcn: '',
    organisationId: '',
    account: undefined,
  },
  division: undefined,
};

export type AliasType = 'TELI' | 'EMAL' | 'AUBN' | 'ORGN';

export interface SupplementaryDataType {
  aliasId: string;
  aliasType: AliasType;
}

export enum ARRANGEMENT_STATUS_QUERY {
  ACTIVE = 'ACTIVE',
  ACTIVE_AND_INACTIVE = 'ACTIVE_AND_INACTIVE',
}

export type ErrorResponse = {
  code: number;
  /** Error Message */
  message: string;
  /** Detailed information about the error */
  details?: string;
};

export type AliasLookupStatus =
  | 'fetching'
  | 'verified'
  | 'not-verified'
  | 'error'
  | 'warning';

export type AccountObject = {
  name?: string;
  nickName?: string;
  accountId?: string;
};

export type ActionItem = {
  name: string;
  cssClasses: string[];
  action: unknown;
};

export type validatePaymentLimitsResult = {
  id: string;
  isSuccess: boolean;
  code?: number;
  message?: string;
  details?: string;
};

export type PaymentLimitAmount = {
  currencyCode: string;
  value: string;
};

export type PaymentLimits = {
  id?: string;
  level?: string;
  channelId?: string;
  scheme?: string;
  recordedTs?: string;
  transactionLimit?: {
    amount?: PaymentLimitAmount;
  };
  dailyLimit?: {
    amount?: PaymentLimitAmount;
    remainingAmount?: PaymentLimitAmount;
  };
};

export type AuthorisationTabValues =
  (typeof AuthorisationTab)[keyof typeof AuthorisationTab];

export type AuthorisationTabOption = {
  value: AuthorisationTabValues;
  label: string;
};

export type StatusTabValues = (typeof StatusTab)[keyof typeof StatusTab];

export type StatusTabOption = {
  value: StatusTabValues;
  label: string;
};

export type LookupMismatch = {
  beneficiaryName: string;
  aliasLookupName: string;
};

export type StatusMapKey = keyof typeof WorkFlowStatusMap;

export type PaymentPayload = Extract<
  NonNullable<
    NonNullable<
      PostApprovalWorkflowListData['entities']
    >['approvalWorkflowList']
  >[number]['payloadObject'],
  { creditTransferTransactionInformation: unknown }
>;

/**
 * UI display values for payment method description
 */
export type PaymentMethodDescription =
  | ''
  | 'Fund transfer'
  | 'Osko'
  | 'Fast Payment'
  | 'Pay Anyone';

export type EntitlementSupplementaryDataItem = {
  name: string;
  value: string;
  datatype: 'STRING' | 'BOOLEAN';
};

export type Entitlement = {
  supplementaryData: EntitlementSupplementaryDataItem[];
};

export type CustomerDetails = {
  fullName?: string;
};
