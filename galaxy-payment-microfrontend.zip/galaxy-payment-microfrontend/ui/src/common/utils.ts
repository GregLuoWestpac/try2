/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */

import {
  ACCOUNT_NAME_MAX_LENGTH,
  formatBSBFromAccNo,
  formatCurrencyString,
  isStaffPortal,
} from '@mesh-tenant-multiverse-ui-common/mv-utils';
import { sanitiseWithLibrary } from '@mesh-tenant-multiverse-ui-common/mv-injection-checker';
import { COP_COLOR_CODE } from '@mesh-tenant-multiverse-ui-common/mv-cop-accountname-check';
import { PaymentTaskDetail } from '../containers/PaymentTaskDetailsContainer/PaymentTaskDetailsContainer.type';
import {
  ApprovalWorkflow,
  ApprovalWorkflowDetail,
} from '../widgets/galaxymakerchecker-v1/galaxymakerchecker-v1.types';
import {
  APPROVAL_WORKFLOW_AUDIT_EVENT_NAME,
  BICFI,
  ERROR_CODES,
  InstructionPriority,
  ServiceLevel,
  SYSTEM_IDENTIFICATION,
  WorkFlowStatusMap,
  Currency,
  SafiDataType,
} from './constants';
import {
  AccountObject,
  ErrorResponse,
  MakePaymentFormDataType,
  NppPaymentMethod,
  PaymentMethodDescription,
  PaymentPayload,
  type Entitlement,
  type EntitlementSupplementaryDataItem,
  type AccountOfBSBAndACC,
  type AccountOfPayId,
  BeneTypes,
  PAYID_TYPE,
} from './types';
import type { TransferFormDataType } from '../containers/TransferFundsContainer/common';

export const breakDescription = (description: string) => {
  if (description.length <= 140) return [description];
  return [description.slice(0, 140), description.slice(140)];
};

export const getCreditorAgentBICFI = (
  nppPaymentMethod: NppPaymentMethod
): BICFI => {
  if (
    nppPaymentMethod === NppPaymentMethod.Osko ||
    nppPaymentMethod === NppPaymentMethod.FastPayment ||
    nppPaymentMethod === NppPaymentMethod.DE
  ) {
    return BICFI.XXXXXXXXXXX;
  }
  // On-Platform
  return BICFI.WPACAU3SXXX;
};

export const getCreditorServiceLevel = (nppPaymentMethod: NppPaymentMethod) => {
  if (nppPaymentMethod === NppPaymentMethod.OnPlatform) return undefined;

  return nppPaymentMethod === NppPaymentMethod.Osko
    ? ServiceLevel.Osko
    : ServiceLevel.FastPayment;
};

export const getInstructionPriorityForDE = (
  nppPaymentMethod: NppPaymentMethod
) => {
  if (nppPaymentMethod === NppPaymentMethod.DE) return InstructionPriority.DE;
  return undefined;
};

export const defaultSelectedToAccountValue = () => 'toSameAccount';

export function createDetailsFromAccountObject(
  account?: AccountObject
): string[] {
  const { name, nickName, accountId } = account ?? {};
  let formattedAccId = accountId ?? '';
  const bsbAccountPattern = /^\d{6} [\d.a-zA-Z]+$/;
  if (bsbAccountPattern.test(formattedAccId)) {
    formattedAccId = formatBSBFromAccNo(formattedAccId.replace(' ', ''));
  }
  return [nickName, name, formattedAccId].map((detail) =>
    detail !== undefined ? detail : ' '
  );
}

export const accountBaseUrl = isStaffPortal() ? 'accountworkflow' : 'account';

export const convertWorkflowStatusToDisplay = (
  rawStatus: ApprovalWorkflow['workflowStatus']
): PaymentTaskDetail['status'] => {
  if (!rawStatus) return '';
  return WorkFlowStatusMap[rawStatus as keyof typeof WorkFlowStatusMap] ?? '';
};
export const getWorkflowAuditDetails = (
  workflow: ApprovalWorkflowDetail,
  status: APPROVAL_WORKFLOW_AUDIT_EVENT_NAME
) => {
  const audit = workflow?.approvalWorkflowsAudit?.find(
    (a) => a.eventName === status
  );
  const firstName = audit?.actionedBy?.firstName || '';
  const lastName = audit?.actionedBy?.lastName || '';
  return audit
    ? {
        actionedBy:
          firstName && lastName
            ? `${firstName} ${lastName}`
            : firstName || lastName,
        actionedDateTime: audit.action?.dateTime ?? '',
      }
    : { actionedBy: '', actionedDateTime: '' };
};

export const parseIdFromEntitlements = (
  entitlementsPayload?: string
): string => {
  if (!entitlementsPayload) return '';
  try {
    const parsed = JSON.parse(entitlementsPayload);
    const id = parsed?.makerRequest?.id ?? '';
    return typeof id === 'string' ? id : '';
  } catch {
    return '';
  }
};

/**
 * takes in PaymentPayload and checks values from txInfo to determine payment method description.
 * valid for
 * - "For you to authorise" LIST VIEW
 * - "Payments you initiated" LIST VIEW
 * - Authorisations - Payment Details VIEW
 * SD reference: https://confluence.srv.westpac.com.au/display/ARTC/Authorisations+UI+-+Exp+API+Mapping+for+Payments
 */
export const getPaymentMethodDescription = (
  payload?: PaymentPayload
): PaymentMethodDescription => {
  const txInfo = payload?.creditTransferTransactionInformation?.[0];
  const { instructionForDebtorAgent, paymentTypeInformation } = txInfo ?? {};
  const serviceLevel = paymentTypeInformation?.serviceLevel ?? '';

  if (instructionForDebtorAgent === 'On-Me') return 'Fund transfer';

  if (serviceLevel.includes('npp.clear.01-x2p1')) {
    return 'Osko';
  }
  if (serviceLevel.includes('npp.clear.01-sct') || !serviceLevel) {
    return 'Fast Payment';
  }
  if (serviceLevel === 'NURG') {
    return 'Pay Anyone';
  }
  return '';
};

// reference: https://confluence.srv.westpac.com.au/display/ARTC/Authorisations+UI+-+Exp+API+Mapping+for+Payments
export const transformApprovalWorkflowToPaymentTaskDetail = (
  workflow: ApprovalWorkflowDetail
): PaymentTaskDetail => {
  const payload = workflow?.payloadObject as PaymentPayload | undefined;
  const txInfo = payload?.creditTransferTransactionInformation?.[0];

  const debtorAccount = payload?.debtorAccount;
  const supplementaryData = payload?.supplementaryData;
  const status = convertWorkflowStatusToDisplay(workflow?.workflowStatus);
  const sentForAuthWorkflowAuditDetails = getWorkflowAuditDetails(
    workflow,
    APPROVAL_WORKFLOW_AUDIT_EVENT_NAME.SEND_FOR_AUTHORISATION
  );
  const rejectedWorkflowAuditDetails = getWorkflowAuditDetails(
    workflow,
    APPROVAL_WORKFLOW_AUDIT_EVENT_NAME.REJECTED
  );
  const remittanceInformation =
    payload?.creditTransferTransactionInformation?.[0]?.remittanceInformation
      ?.unstructured;

  const paymentMethodDescription = getPaymentMethodDescription(payload);

  const creditorDescription =
    paymentMethodDescription === 'Pay Anyone'
      ? undefined
      : remittanceInformation?.join('') ?? '';

  const formatAccountIdWithBSB = (accountId: string | undefined): string => {
    if (!accountId || accountId.length <= 6) return accountId ?? '';
    return `${accountId.slice(0, 6)} ${accountId.slice(6)}`;
  };

  const {
    aliasId = '',
    aliasType = '',
    isNewPayee = false,
  } = txInfo?.supplementaryData ?? {};
  const beneficiaryAccountId =
    aliasId && aliasType
      ? aliasId
      : formatAccountIdWithBSB(txInfo?.creditorAccount?.identification) ?? '';
  const accountData = {
    name: txInfo?.creditor?.name ?? '',
    nickName: txInfo?.creditorAccount?.name ?? '',
    accountId: beneficiaryAccountId,
  };

  const isFundTransfer = paymentMethodDescription === 'Fund transfer';

  return {
    id: workflow?.approvalWorkflowId ?? '',
    amount: {
      amount: formatCurrencyString(txInfo?.instructedAmount?.amount ?? ''),
      currency: txInfo?.instructedAmount?.currency ?? '',
    },
    ...(isFundTransfer
      ? { creditAccount: accountData }
      : { beneficiary: accountData }),

    creationDateTime: workflow?.requestedDateTime ?? '',
    creditorDescription,
    debitAccount: {
      nickName: debtorAccount?.name ?? '',
      accountId: formatAccountIdWithBSB(debtorAccount?.identification) ?? '',
    },
    debitDescription: supplementaryData?.debitDescription ?? '',
    paymentMethod: {
      description: paymentMethodDescription ?? '',
    },
    receiptNumber: parseIdFromEntitlements(workflow?.entitlementsPayload) ?? '',
    ...(!isFundTransfer && {
      reference: txInfo?.endToEndIdentification ?? '',
    }),
    status,
    supplementaryData: {
      isNewPayee,
      aliasId,
      aliasType,
      instructionTraceIdentification:
        supplementaryData?.instructionTraceIdentification ?? '',
      ...(supplementaryData &&
        'divisionName' in supplementaryData && {
          divisionName: (supplementaryData as { divisionName?: string })
            .divisionName,
        }),
    },
    sentForAuthWorkflowAuditDetails,
    rejectedWorkflowAuditDetails,
  };
};

/**
 * Returns the system identification code for a given NPP payment method.
 * Easily extensible for future mappings.
 */
export const getSystemIdentificationDE = (
  nppPaymentMethod: NppPaymentMethod
): SYSTEM_IDENTIFICATION | undefined => {
  const mapping: Partial<Record<NppPaymentMethod, SYSTEM_IDENTIFICATION>> = {
    [NppPaymentMethod.DE]: SYSTEM_IDENTIFICATION.AUBSB,
    // Add more mappings here as needed
  };
  return mapping[nppPaymentMethod];
};

/**
 * Determines if step-up authentication is required based on API status and error codes.
 * @param apiStatus - The API status code.
 * @param errors - An array of error responses.
 * @returns `true` if step-up is required, `false` otherwise.
 */
export const isStepUpRequired = (
  apiStatus?: number,
  errors?: ErrorResponse[]
): boolean => {
  if (apiStatus === 401) {
    return !!errors?.some(
      (error) => error.code === ERROR_CODES.STEP_UP_REQUIRED
    );
  }
  return false;
};

export function checkIsNewBeneficiary(
  makePaymentFormData: MakePaymentFormDataType
): boolean {
  return (
    !!makePaymentFormData.beneficiary?.beneficiaryType &&
    !!makePaymentFormData.beneficiary?.beneficiaryNickname &&
    !!makePaymentFormData.toAccount &&
    !makePaymentFormData.toAccount.id &&
    !makePaymentFormData.toAccount.externalId
  );
}

export function checkShouldSaveNewBeneficiary(
  makePaymentFormData: MakePaymentFormDataType
): boolean {
  return (
    !!makePaymentFormData.beneficiary?.saveBeneficiary &&
    checkIsNewBeneficiary(makePaymentFormData)
  );
}

const mapPayIdTypeToSafiFormat = (payIdType?: string): string => {
  switch (payIdType) {
    case PAYID_TYPE.PHONE:
      return 'MOBILE';
    case PAYID_TYPE.EMAIL:
      return 'EMAIL';
    case PAYID_TYPE.ABN_ACN:
      return 'ABN';
    case PAYID_TYPE.ORGANISATION_ID:
      return 'FREEFORM';
    // LANDLINE TYPE currently not part of payIDType enum, but if added in future, can map it here after adding the enum value
    default:
      return 'FREEFORM';
  }
};

const stringDatatype = SafiDataType.STRING;
const booleanDatatype = SafiDataType.BOOLEAN;

export const buildTransferEntitlement = (
  formData: TransferFormDataType,
  paymentId: string
): Entitlement => {
  const { toAccount } = formData;

  const toBSB = toAccount?.accountId?.slice(0, 6) ?? '';
  const toAccountNumber = toAccount?.accountId?.slice(7) ?? '';
  const payeeDestAccount = `${toBSB} ${toAccountNumber}`;

  const currency = Currency.AUD;

  return {
    supplementaryData: [
      {
        name: 'W1_2FADEVICETYPE',
        value: 'SOFT TOKEN',
        datatype: stringDatatype,
      },
      { name: 'TENANT', value: 'TREASURY', datatype: stringDatatype },
      { name: 'W1C_CURRENCY', value: currency, datatype: stringDatatype },
      {
        name: 'PAYEEDESTINATIONACCOUNT',
        value: payeeDestAccount,
        datatype: stringDatatype,
      },
      {
        name: 'PAYEENICKNAME',
        value: sanitiseWithLibrary(
          toAccount?.accountName ?? '',
          ACCOUNT_NAME_MAX_LENGTH
        ),
        datatype: stringDatatype,
      },
      {
        name: 'PAYMENT_REFNO',
        value: paymentId,
        datatype: stringDatatype,
      },
    ],
  };
};

export const buildPaymentEntitlement = (
  formData: MakePaymentFormDataType,
  paymentId: string,
  matchedCOPColour?: COP_COLOR_CODE
): Entitlement => {
  const { toAccount } = formData;

  const isPayID = toAccount?.type === BeneTypes.PAYID;
  const isNewPayee = checkIsNewBeneficiary(formData);

  const fromCurrency = 'AUD';
  const toCurrency = 'AUD';
  const isCrossCurrency = fromCurrency !== toCurrency; // can also set to false for now as only AUD payments are supported

  const supplementaryData: EntitlementSupplementaryDataItem[] = [
    { name: 'W1_2FADEVICETYPE', value: 'SOFT TOKEN', datatype: stringDatatype },
    { name: 'TENANT', value: 'TREASURY', datatype: stringDatatype },
    { name: 'W1C_CURRENCY', value: toCurrency, datatype: stringDatatype },
    {
      name: 'CROSS_CURRENCY_PAYMENT',
      value: isCrossCurrency ? 'TRUE' : 'FALSE',
      datatype: booleanDatatype,
    },
    { name: 'CURRENCY_FROM', value: fromCurrency, datatype: stringDatatype },
    {
      name: 'NEWPAYEE',
      value: isNewPayee ? 'TRUE' : 'FALSE',
      datatype: booleanDatatype,
    },
    {
      name: 'PAYMENT_REFNO',
      value: paymentId,
      datatype: stringDatatype,
    },
  ];

  if (isPayID) {
    const payIdAccount = toAccount?.account as AccountOfPayId;
    supplementaryData.push(
      {
        name: 'PAYEEPAYIDTYPE',
        value: mapPayIdTypeToSafiFormat(payIdAccount?.payIDType),
        datatype: stringDatatype,
      },
      {
        name: 'PAYEEPAYIDVALUE',
        value: payIdAccount?.payIDValue ?? '',
        datatype: stringDatatype,
      },
      {
        name: 'PAYEEPAYIDSHORTNAME',
        value: payIdAccount?.payIDName ?? '',
        datatype: stringDatatype,
      }
    );
  } else {
    const bsbAccount = toAccount?.account as AccountOfBSBAndACC;
    const toBSB = bsbAccount?.accountId?.BSB ?? '';
    const toAccountNumber = bsbAccount?.accountId?.accountNumber ?? '';
    const payeeDestAccount = `${toBSB} ${toAccountNumber}`;

    supplementaryData.push(
      {
        name: 'PAYEEDESTINATIONACCOUNT',
        value: payeeDestAccount,
        datatype: stringDatatype,
      },
      { name: 'PAYEEPAYIDACCOUNTTYPE', value: toBSB, datatype: stringDatatype }
    );

    if (matchedCOPColour) {
      supplementaryData.push({
        name: 'PAYEE_NAME_CHECK_COLOUR',
        value: matchedCOPColour,
        datatype: stringDatatype,
      });
    }
  }

  return { supplementaryData };
};
