import { ReactNode } from 'react';
import {
  genericErrorMessage,
  apiGenericErrorTryAgainLater,
  apiGenericErrorTryAgain,
} from './constants';
import { BannerAlertBoxProps } from '../galaxy-common/BannerAlertBox/BannerAlertBox';

export const GenericApiErrorAlerts = {
  GENERIC_API_ERROR: 'GENERIC_API_ERROR',
  REQUEST_TIMEOUT_ERROR: 'REQUEST_TIMEOUT_ERROR',
  CLIENT_REQUEST_TIMEOUT_ERROR: 'CLIENT_REQUEST_TIMEOUT_ERROR',
} as const;

export type AlertKeyForGenericApiError = keyof typeof GenericApiErrorAlerts;

export const genericApiErrorAlerts: Record<string, AlertKeyForGenericApiError> =
  {
    GENERIC_API_ERROR: 'GENERIC_API_ERROR',
    REQUEST_TIMEOUT_ERROR: 'REQUEST_TIMEOUT_ERROR',
    CLIENT_REQUEST_TIMEOUT_ERROR: 'CLIENT_REQUEST_TIMEOUT_ERROR',
  };

export const genericApiErrorAlertMapper = {
  /**
   ** For generic api error, we cannot immediately try again.
   */
  GENERIC_API_ERROR: {
    styling: 'danger',
    renderMessage: () => <span>{apiGenericErrorTryAgainLater}</span>,
  },
  /**
   * For timeout issues, we do not redirect user, user can send request again immediately on the same page.
   * */
  REQUEST_TIMEOUT_ERROR: {
    styling: 'danger',
    renderMessage: () => <span>{apiGenericErrorTryAgain}</span>,
  },
  CLIENT_REQUEST_TIMEOUT_ERROR: {
    styling: 'danger',
    renderMessage: () => <span>{genericErrorMessage}</span>,
  },
} satisfies Partial<
  Record<
    keyof typeof GenericApiErrorAlerts,
    {
      renderMessage: () => ReactNode;
      styling: BannerAlertBoxProps['styling'];
    }
  >
>;
