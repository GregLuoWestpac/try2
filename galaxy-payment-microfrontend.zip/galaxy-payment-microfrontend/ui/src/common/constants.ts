/* eslint-disable no-shadow */
export const largePageMaxWidth = 1260;
export const mediumPageMaxWidth = 720;
export const pageMinWidth = 528;
export const paymentStatusPageTitle = 'Payment status | Westpac One';
export const paymentDetailsPageTitle = 'Payment details | Westpac One';
export const reviewPaymentPageTitle = 'Review payment | Westpac One';
export const paymentConfirmationPageTitle =
  'Payment confirmation | Westpac One';
export const transferDetailsPageTitle = 'Transfer details | Westpac One';
export const reviewTransferPageTitle = 'Review transfer | Westpac One';
export const transferConfirmationPageTitle =
  'Transfer confirmation | Westpac One';
export const apiGenericErrorTryAgain =
  'Something went wrong. Please try again.';
export const apiGenericErrorTryAgainLater =
  'Something went wrong. Please try again later.';
export const genericErrorMessage = 'Something went wrong.';
export const genericUnathorisedMessage =
  'You do not have permission to access this page. Contact your Administrator for more information.';
export const returnDetailsPageTitle = 'Return details | Westpac One';
export const returnConfirmationPageTitle = 'Return confirmation | Westpac One';
export const PAYID_SERVICE_UNAVAILABLE =
  'PayID service is currently not available. You can pay to a BSB and account number, or try again.';
export const NoBeneficiarySelectedErrorMessage =
  'Select a beneficiary from the list.';
export const INVALID_PAYID =
  'The PayID is not valid. Contact the beneficiary or pay to a BSB and account number.';
export const schemeEligibilitiesBsbNotRecognisedErrorMessage =
  'BSB is not recognised. Contact the beneficiary or select another from the list.';
export const specialCharacterMissingErrorMessage =
  'Use only letters, numbers, spaces, or the following special characters  -  _   ,  .  :  ;  ?  ! ';
export const forbiddenCharacterErrorMessage =
  'You cannot use the following special characters';
export const MAKE_PAYMENT_PAYMENT_METHOD_HINT_TEXT =
  "Available payment methods depend on 'From account' and 'Beneficiary'.";
export const ACCESS_DENIED_TO_ADD_OR_UPDATE_BENEFICIARIES =
  'You do not have permission to add or update beneficiaries. Contact your administrator for more information.';
export const BSB_LOOKUP_IN_PROGRESS_MESSAGE =
  'BSB verification is in progress. You can continue when verification is complete.';
export const PAYID_ALIAS_LOOKUP_IN_PROGRESS_MESSAGE =
  'PayID verification is in progress. You can continue when verification is complete.';

export enum ChannelIds {
  WP = 'WP',
  QV = 'QV',
  SW = 'SW',
  OB = 'OB',
  WS = 'WS',
}
export const channelId = ChannelIds.WP;
export enum Currency {
  AUD = 'AUD',
}

export enum SafiDataType {
  STRING = 'STRING',
  BOOLEAN = 'BOOLEAN',
}

export const PayIdTypes = ['TELI', 'EMAL', 'AUBN', 'ORGN'] as const;
export const noPaymentsRowMessage = 'There are no payments found.';

export const PAYMENT_CREATE_ERROR_ACTION =
  'api/expGalaxyPaymentV2/paymentCreate/post/ERROR';

export const PAYMENT_NEW_BENEFICIARY_ERROR_ACTION =
  'api/expGalaxyPaymentV2/paymentCreateForNewBeneficiary/post/ERROR';

export const TRANSFER_CREATE_ERROR_ACTION =
  'api/expGalaxyPaymentV2/transferCreate/post/ERROR';

export const PAYMENT_IDENTIFIER_ERROR_ACTION =
  'api/expGalaxyPaymentV2/paymentIdentifier/post/ERROR';

export const CREATE_BENEFICIARY_ERROR_ACTION =
  'api/expGalaxyPaymentV2/beneficiaryCreate/post/ERROR';

export enum BICFI {
  WPACAU2SONE = 'WPACAU2SONE',
  WPACAU2SXXX = 'WPACAU2SXXX',
  WPACAU3SXXX = 'WPACAU3SXXX',
  XXXXXXXXXXX = 'XXXXXXXXXXX',
}

export enum PaymentMethod {
  TRF = 'TRF',
  CHK = 'CHK',
  TRA = 'TRA',
}
export enum SchemeName {
  BBAN = 'BBAN',
}
export enum Issuer {
  WPAC = 'WPAC',
}

export enum PAYMENT_METHODS_ICONS {
  Osko = 'Osko',
  PayTo = 'PayTo',
}

export enum ServiceLevel {
  Osko = 'npp.clear.01-x2p1.04',
  FastPayment = 'npp.clear.01-sct.04',
  CatSct = 'npp.clear.01-catsct.01',
  DE = 'NURG',
}

export enum InstructionPriority {
  DE = 'NORM',
}

export enum LocalInstrument {
  DE = 'DE',
}

export enum paymentDetailsIdType {
  PMTID = 'PMTID',
  NPPID = 'NPPID',
}

export enum InstructionForDebtorAgent {
  OnMe = 'On-Me',
}

export enum ReasonCode {
  FOCR = 'FOCR',
}

export enum StatusCode {
  ACSC = 'ACSC',
  RJCT = 'RJCT',
}

export enum ToAnotherAccount {
  No = 'No',
  Yes = 'Yes',
}

export enum BannerStyle {
  SUCCESS = 'success',
  DANGER = 'danger',
}

export enum RejectReason {
  InsufficientAccountBalance = 'InsufficientAccountBalance',
}

export const paymentDetailsKeyType = {
  ITRID: 'ITRID',
} as const;

export const calledFromType = {
  TO_ACCOUNT: 'To account',
  FROM_ACCOUNT: 'From account',
} as const;

export const MAX_PAY_ID_EMAIL_ORGANISATION_ID_LENGTH = 37;
export const AUTHBIC8 = 'WPACAU3S';

export enum ERROR_CODES {
  NAME_MISMATCH = 2004,
  STEP_UP_REQUIRED = 8200,
  SAFI_DENIED = 8211,
}

export const statusMessages = {
  PAYID_INVALID:
    'PayID details for this beneficiary are not valid. Check PayID details are correct and ',
  PAYID_SERVICE_UNAVAILABLE: 'PayID service is currently unavailable.',
};

export enum PDP_QUERY_ACTIONS {
  VIEW_PAYMENT = 'VIEW_PAYMENT',
  INITIATE_PAYMENT = 'INITIATE_PAYMENT',
  INITIATE_TRANSFER = 'INITIATE_TRANSFER',
}

export enum MFA_CODE {
  MFA_CANCELLED = 'MFA_CANCELLED',
  MFA_LOCKED = 'MFA_LOCKED',
  MFA_ERROR = 'MFA_ERROR',
  INVALID_OTP = 'INVALID_OTP',
}
export enum BranchStatus {
  OPERATIONAL = 'OPERATIONAL',
  CLOSED = 'CLOSED',
}

export enum BranchBrand {
  WBC = 'WBC',
  SGB = 'SGB',
  BOM = 'BOM',
  BSA = 'BSA',
}

export const INTENT_NAMES = {
  VIEW_GALAXY_PAYMENTS: 'ViewGalaxyPayments',
  VIEW_GALAXY_PAYMENT_DETAILS: 'ViewGalaxyPaymentDetails',
  VIEW_GALAXY_PAYMENT_TASK_DETAILS: 'ViewGalaxyPaymentTaskDetails',
  VIEW_ACCOUNT_ACTIVITY_WORKFLOW: 'ViewGalaxyAccountActivityWorkflow',
  VIEW_AUTHORISATION_REQUEST_LIST: 'ViewGalaxyAuthorisationsWorkflow',
  CREATE_PAYMENT_RETURN_WORKFLOW: 'CreateGalaxyPaymentReturnWorkflow',
  CREATE_GALAXY_TRANSFER: 'CreateGalaxyTransferFunds',
  CREATE_GALAXY_PAYMENT: 'CreateGalaxyPayment',
  BENEFICIARY_LISTS: 'ViewGalaxyBeneficiaries',
} as const;

export const INTENTS_CONTEXT_NAME = {
  PAYMENT: 'fdc3.nothing',
  ACCOUNT: 'fdc3.nothing',
  WORKFLOW_AUTHORISATION: 'fdc3.nothing',
  BENEFICIARY: 'fdc3.nothing',
};

export const CONTAINERTAB_TITLES = {
  PAYMENT_STATUS: 'Payment status | Westpac One',
  ACCOUNT_ACTIVITY: 'Account activity | Westpac One',
  AUTHORISATION: 'Authorisation | Westpac One',
  PAYMENT: 'Payment status | Westpac One',
  PAYMENT_DETAILS: 'Payment details | Westpac One',
} as const;

export const PAGE_NAVIGATION = {
  PAYMENT_PAGE: '/payment',
  PAYMENT_DETAILS: '/payment/payment-details',
  ACCOUNT_ACTIVITY_WORKFLOW: '/accountworkflow/account-activity',
  PAYMENT_TASK_DETAILS: '/payment/payment-task-details',
  AUTHORISATION_REQUEST_LIST: '/workflowauthorisation',
  BENEFICIARY_LISTS: '/beneficiary',
} as const;

export const AuthorisationTab = {
  ForYouToAuthorise: 'ForYouToAuthorise',
  PaymentsYouInitiated: 'PaymentsYouInitiated',
} as const;

export const StatusTab = {
  All: 'All',
  Pending: 'Pending authorisation',
  Rejected: 'Rejected by authoriser',
} as const;

/**
 * Mapping of workflow status to the constants used in the UI.
 * Note: This may not cover all workflow statuses, only supported ones.
 */
export const WorkFlowStatusMap = {
  ApprovalPending: 'Pending authorisation',
  Rejected: 'Rejected by authoriser',
} as const;

export enum SYSTEM_IDENTIFICATION {
  AUBSB = 'AUBSB',
}

export const MAX_TRANSACTIONS_LOAD = 8000;

export const UNAUTHORISED_STATUS_CODE = 401;
export const SENT_FOR_AUTHORISATION_STATUS_CODE = 8125;

export enum APPROVAL_WORKFLOW_AUDIT_EVENT_NAME {
  SEND_FOR_AUTHORISATION = 'ServiceRequestAuthorisationRequested',
  REJECTED = 'ServiceRequestAuthorisationRequestRejected',
}

export enum AliasType {
  PHONE = 'phone',
  EMAIL = 'email',
  AUBN = 'aubn',
  ORGN = 'orgn',
}

export type PayID = {
  aliasId: string;
  aliasType: AliasType;
};

export const INPUT_MAX_LENGTH = {
  BSB: 6,
  ABN_ACN: 11,
  ACCOUNT_NUMBER: 28,
  PHONE: 30,
  BENEFICIARY_NICKNAME: 70,
  ACCOUNT_NAME: 140,
  EMAIL_OR_ORG_ID: 256,
};

export const REGEX_PATTERN = {
  DIGIT: /^[\d]+$/,
  BSB: /^[\d]{6}$/,
  ACCOUNT_NUMBER: /^[a-zA-Z0-9.]+$/,
  EMAIL_FORMAT: /^[A-Za-z0-9\-!,:;?_.]+@[A-Za-z0-9\-!,:;?_.]+$/,
  REJECT_COMMENT: /^[a-zA-Z0-9\s\-!,.:\\;?_@]*$/,
};

export const ERROR_MESSAGES = {
  BSB: 'Enter a valid 6-digit BSB.',
  ACCOUNT_NUMBER_REQUIRED: 'Enter an account number.',
  ACCOUNT_NUMBER_INVALID: 'Use only letters, numbers or full stops.',
  ACCOUNT_NAME_REQUIRED: 'Enter an account name up to 140 characters.',
  BENEFICIARY_NICKNAME_REQUIRED:
    'Enter the beneficiary nickname up to 70 characters.',
  BENEFICIARY_TYPE_REQUIRED: 'Select a beneficiary type.',
  BSB_NOT_RECOGNISED: 'BSB is not recognised.',
  BSB_SERVICE_UNAVAILABLE:
    'BSB service is currently not available. Please try again.',
  PAYID_TYPE_REQUIRED: 'Select a PayID type.',
  PHONE: 'Enter a valid phone number.',
  EMAIL_REQUIRED: 'Enter a valid email address.',
  EMAIL_INVALID_FORMAT: 'Enter a valid email address.',
  ABN: 'Enter a valid ABN or ACN number between 9 and 11 digits.',
  ABN_ACN: 'Enter a valid ABN/ACN.',
  ORGANISATION_ID: 'Enter a valid Organisation ID.',
  ORGANISATION_REQUIRED:
    'Enter a valid organisation ID between 2 and 256 characters.',
  PAYID_SERVICE_UNAVAILABLE:
    'PayID service is currently not available. Please try again.',
  INVALID_PAYID:
    'This PayID is not valid. Contact the beneficiary to confirm their payment details.',
  PAYID_CHECK_LIMIT_EXCEEDED:
    'PayID verification cannot be completed. Please try again later.',
  BENEFICIARY_CHANGE_DISCLAIMER:
    'Any changes to beneficiaries will only affect new payments. Payments already created and submitted will not be updated with these changes.',
};
export const W1_ORGANIZATION_SSO = 'w1/organisationSso';

export const PaymentStatusTab = {
  Authorisations: 'authorisations',
  Processing: 'processing',
} as const;

export const PaymentTab = {
  All: 'All',
  Processing: 'Processing',
  Processed: 'Processed',
  Failed: 'Failed',
};
export const paymentTabValues = [
  { value: PaymentTab.All, label: 'All' },
  { value: PaymentTab.Processing, label: 'Processing' },
  { value: PaymentTab.Processed, label: 'Processed' },
  { value: PaymentTab.Failed, label: 'Failed' },
];

export const defaultDivisionData = [
  {
    id: 'All',
    name: 'All divisions',
    label: 'All divisions',
  },
];
