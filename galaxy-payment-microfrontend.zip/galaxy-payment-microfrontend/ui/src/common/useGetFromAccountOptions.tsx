import { useGlobalDispatch, useGlobalSelector } from '@mep-ui/framework';
import { useEffect, useMemo } from 'react';
import { Account, Arrangement, GlobalState } from '../store/types';
/**
 * @description
 * - generates fromAccount options
 * - gets default fromAccount option from global context (eg. context updated from Account MFE)
 * - clears the stored default account value from global context on unmount
 *
 * technical notes:
 * - MVAutocomplete syncs input value with default option value only when options list has been updated and default option is not empty
 * - please ensure the property name is synced across all MFEs if any changes is made.
 * */
export const useGetFromAccountOptions = (
  allAccountList: Account[]
): {
  defaultFromAccount: Account | undefined;
  fromAccountOptions: Account[];
} => {
  // eslint-disable-next-line
  const globalDispatch = useGlobalDispatch();
  // eslint-disable-next-line
  const selectedAccount: Arrangement | undefined =
    // eslint-disable-next-line @typescript-eslint/no-unsafe-call
    useGlobalSelector(
      (state: GlobalState) =>
        // eslint-disable-next-line
        (state?.global?.galaxy?.context as any)?.selectedAccount
    );

  // clear context selectedAccount on unmount
  // eslint-disable-next-line arrow-body-style
  useEffect(() => {
    return () => {
      // eslint-disable-next-line @typescript-eslint/no-unsafe-call
      globalDispatch({
        type: 'galaxy/context/update',
        data: { selectedAccount: undefined },
      });
    };
  }, []);

  // use memo to memoize the defaultFromAccount and fromAccountOptions, so that reference does not change in every render
  const accountOptionsData = useMemo(() => {
    const fromAccountOptions = allAccountList;

    const defaultFromAccount = fromAccountOptions.find((account) =>
      selectedAccount
        ? account.accountId === selectedAccount.accountNumber
        : false
    );

    return { defaultFromAccount, fromAccountOptions };
  }, [allAccountList, selectedAccount]);

  return accountOptionsData;
};
