/* eslint-disable react/jsx-props-no-spreading */
import { Provider, useMFEConfig, useManifest } from '@mep-ui/framework';
import { CancelModalProvider } from '@mesh-tenant-multiverse-common/react';
import { MVPageLoader as PageLoader } from '@mesh-tenant-multiverse-ui-common/mv-pageloader';
import { useSetAgGridLicV2 as useSetAgGridLic } from '@mesh-tenant-multiverse-ui-common/mv-table-v2';
import isEmpty from 'lodash/isEmpty';
import PropTypes from 'prop-types';
import store from '../store/store';

function Config({ children }) {
  const isSetGalaxyTableKey = useSetAgGridLic();
  const { isLoading, manifest } = useManifest('galaxy-payment');
  const { config, isFetching } = useMFEConfig({
    name: 'galaxy-payment',
    store,
  });

  if (
    isEmpty(config) ||
    isFetching ||
    isLoading ||
    isEmpty(manifest) ||
    !isSetGalaxyTableKey
  ) {
    return <PageLoader iconSize="medium" placement="middle" />;
  }
  return children;
}

Config.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.element,
    PropTypes.arrayOf(PropTypes.element),
  ]).isRequired,
};

export default function withMFE(WrapperComponent) {
  return function WithMFE(props) {
    return (
      <Provider store={store}>
        <Config>
          <CancelModalProvider>
            <WrapperComponent {...props} />
          </CancelModalProvider>
        </Config>
      </Provider>
    );
  };
}
