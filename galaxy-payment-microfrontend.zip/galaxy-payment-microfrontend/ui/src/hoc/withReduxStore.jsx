/* eslint-disable react/prop-types, react/jsx-props-no-spreading */


const withReduxStore = (WrapperComponent) => {
  function WithReduxStore({ store, ...props }) {
    return <WrapperComponent {...props} />;
  }
  return WithReduxStore;
};

export default withReduxStore;
