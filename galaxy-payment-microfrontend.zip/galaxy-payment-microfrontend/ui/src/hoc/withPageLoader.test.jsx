import { Navigate, useLocation } from '@mep-ui/framework-router-addon';
import { isUserAuthorised } from '@mesh-tenant-user-authorisation-policy-decision-engine/components';
import '@testing-library/jest-dom';
import { render, screen } from '@testing-library/react';
import withPageLoader from './withPageLoader';

jest.mock('@mep-ui/framework-router-addon', () => ({
  Navigate: jest.fn(() => (
    <div data-testid="navigate-error">Redirected to Error</div>
  )),
  useLocation: jest.fn(),
}));

jest.mock(
  '@mesh-tenant-user-authorisation-policy-decision-engine/components',
  () => ({
    isUserAuthorised: jest.fn(),
  })
);

jest.mock('../fineGrainedEntitlementMap', () => ({
  entitlementToPathMap: {
    '/test-path': { resource: 'test-resource', action: 'test-action' },
  },
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-pageloader', () => ({
  MVPageLoader: jest.fn(() => <div>Loading...</div>),
}));

jest.mock('@mesh-tenant-multiverse-common/react', () => ({
  CancelModalProvider: ({ children }) => <div>{children}</div>,
}));

jest.mock('@mesh-tenant-multiverse-ui-common/mv-card', () => ({
  MVCard: function MockComponent({ children }) {
    return <div>{children}</div>;
  },
}));

describe('Test withPageLoader', () => {
  const WrappedComponent = jest.fn(() => <div>Wrapped Component</div>);
  const WithPageLoader = withPageLoader(WrappedComponent);

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders the wrapped component if user is authorised', () => {
    useLocation.mockReturnValue({ pathname: '/test-path' });
    isUserAuthorised.mockReturnValue({ authorised: true });

    const { getByText } = render(<WithPageLoader />);

    expect(getByText('Wrapped Component')).toBeInTheDocument();
    expect(Navigate).not.toHaveBeenCalled();
  });

  it('redirects to /error if user is not authorised', () => {
    useLocation.mockReturnValue({ pathname: '/test-path' });
    isUserAuthorised.mockReturnValue({ authorised: false });

    render(<WithPageLoader />);

    expect(Navigate).toHaveBeenCalledWith({ to: '/error', replace: true }, {});
    expect(screen.getByTestId('navigate-error')).toBeInTheDocument();
  });
});
