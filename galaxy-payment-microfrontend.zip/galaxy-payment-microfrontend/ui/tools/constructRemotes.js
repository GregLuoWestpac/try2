const fetchPromise = (name, source, enableSwimlane) => {
  const moduleName = name.replace('-', '_');
  return `new Promise((resolve, reject) => {
          let remoteUrlWithVersion = "${source}";
          const searchParams = new URLSearchParams(window.location.search);
          const swimlaneName = searchParams.get("swimlane");
          if (${enableSwimlane} && swimlaneName) {
            remoteUrlWithVersion = remoteUrlWithVersion.replace(
              '/default',
              '/' + swimlaneName
            );
          }
          const script = document.createElement('script');
          script.src = remoteUrlWithVersion;
          script.defer = true;
          script.onload = () => {
            // the injected script has loaded and is available on window
            // we can now resolve this Promise
            try {
              const proxy = {
                get: request => window["${moduleName}"].get(request),
                init: arg => {
                  try {
                    return window["${moduleName}"].init(arg);
                  } catch (e) {
                    console.log('remote container already initialized');
                    throw e; // re-throw the error so that it can be caught below
                  }
                },
              };
              resolve(proxy);
            } catch (e) {
              console.log('error initializing remote module:', e);
              reject(e); // reject the Promise with the error
            }
          };
          script.onerror = () => {
            // handle network errors or other issues loading the script
            console.log('error loading remote entry:', remoteUrlWithVersion);
            reject(new Error('Error loading remote entry: ' + remoteUrlWithVersion));
          };
          // inject this script with the src set to the versioned remoteEntry.js
          document.head.appendChild(script);
        })`;
};

/**
 * constructRemotes
 *
 * Creates a map of remotes for the given manifest.
 *
 * @param {{widgets: [{name: string, source: string, enableSwimlane: boolean}]}} manifest Manifest.json object from ./public/manifest.json
 *
 * @returns {object} A map of remotes.
 *
 * @example
 * const remotes = constructRemotes({
 *   widgets: [
 *     {
 *       name: 'reference-v1',
 *       source: 'https://example.com/widget/reference-v1/default/remoteEntry.js',
 *     },
 *   ],
 * });
 *
 * console.log(remotes); // { my-widget: 'promise new Promise(...)' }
 */
const constructRemotes = (manifest) => {
  const { widgets = [] } = manifest;
  const dependencies = [...widgets];
  const remotes = dependencies.reduce((result, dependency) => {
    const { name, source, enableSwimlane } = dependency;
    return {
      ...result,
      [name]: `promise ${fetchPromise(name, source, enableSwimlane)}`,
    };
  }, {});

  return remotes;
};

module.exports = constructRemotes;
