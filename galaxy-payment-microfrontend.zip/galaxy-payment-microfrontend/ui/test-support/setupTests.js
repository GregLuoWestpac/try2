import 'regenerator-runtime/runtime';
import '@testing-library/jest-dom';
import { TextDecoder, TextEncoder } from 'util';

global.TextEncoder = TextEncoder;
global.TextDecoder = TextDecoder;

// Mock luxon-like date object for mv-reacthookform
const createMockDateTime = (dateStr = '2026-02-06') => ({
  minus: jest.fn(() => createMockDateTime('2025-11-09')),
  plus: jest.fn(() => createMockDateTime('2026-05-07')),
  toFormat: jest.fn(() => dateStr),
  toISO: jest.fn(() => `${dateStr}T00:00:00.000Z`),
  toJSDate: jest.fn(() => new Date(dateStr)),
});

// Mock for @mesh-tenant-multiverse-ui-common/mv-reacthookform to avoid ESM issues with @westpac/ui
jest.mock('@mesh-tenant-multiverse-ui-common/mv-reacthookform', () => {
  const React = require('react');
  
  // Helper to create mock form controller components
  const createMockController = (displayName) => {
    const MockController = ({ fieldName, name, label, children, control, 'aria-label': ariaLabel, ...props }) => {
      const fieldId = fieldName || name;
      const labelText = label || ariaLabel;
      return React.createElement('div', { 'data-testid': `mock-${displayName}` },
        labelText && React.createElement('label', { htmlFor: fieldId }, labelText),
        React.createElement('input', { name: fieldId, id: fieldId, 'aria-label': labelText, ...props }),
        children
      );
    };
    MockController.displayName = displayName;
    return MockController;
  };

  return {
    DATE_FORMAT_YYYYMMDD: 'yyyy-MM-dd',
    DateRange: {
      TODAY: 'TODAY',
      LAST_7_DAYS: 'LAST_7_DAYS',
      LAST_30_DAYS: 'LAST_30_DAYS',
      LAST_90_DAYS: 'LAST_90_DAYS',
      CUSTOM: 'CUSTOM',
    },
    getToday: jest.fn(() => createMockDateTime('2026-02-06')),
    getTodayAtLastYear: jest.fn(() => createMockDateTime('2025-02-06')),
    MVInputController: createMockController('MVInputController'),
    MVSelectController: createMockController('MVSelectController'),
    MVDatePickerController: createMockController('MVDatePickerController'),
    MVTextAreaController: createMockController('MVTextAreaController'),
    MVCheckboxController: ({ fieldName, name, label, children, control, 'aria-label': ariaLabel, ...props }) => {
      const fieldId = fieldName || name;
      const labelText = label || ariaLabel;
      return React.createElement('div', { 'data-testid': 'mock-MVCheckboxController' },
        React.createElement('input', { type: 'checkbox', name: fieldId, id: fieldId, role: 'checkbox', 'aria-label': labelText, ...props }),
        labelText && React.createElement('label', { htmlFor: fieldId }, labelText),
        children
      );
    },
    MVRadioController: createMockController('MVRadioController'),
    MVButtonGroupController: ({ fieldName, name, label, buttons = [], options = [], children, control, 'aria-label': ariaLabel, ...props }) => {
      const fieldId = fieldName || name;
      const labelText = label || ariaLabel || 'beneficiary type';
      const buttonOptions = buttons.length > 0 ? buttons : options;
      return React.createElement('fieldset', { 'aria-label': labelText },
        labelText && React.createElement('legend', null, labelText),
        buttonOptions.map((opt, idx) =>
          React.createElement('label', { key: idx },
            React.createElement('input', { type: 'radio', name: fieldId, value: opt.value }),
            opt.label
          )
        ),
        children
      );
    },
    MVPhoneInputController: createMockController('MVPhoneInputController'),
    MVAutocompleteController: createMockController('MVAutocompleteController'),
    MVCurrencyController: createMockController('MVCurrencyController'),
    AutocompleteId: {},
    AutocompleteWrapperRef: {},
    AutocompleteItemDetailsTemplate: ({ children }) => React.createElement('div', null, children),
    MVFormProvider: ({ children }) => React.createElement('div', null, children),
    useFormContext: jest.fn(() => ({
      control: {},
      handleSubmit: jest.fn(),
      formState: { errors: {} },
      watch: jest.fn(),
      setValue: jest.fn(),
      getValues: jest.fn(),
      reset: jest.fn(),
      trigger: jest.fn(),
    })),
    useWatch: jest.fn(),
    useController: jest.fn(() => ({
      field: { value: '', onChange: jest.fn(), onBlur: jest.fn(), ref: jest.fn() },
      fieldState: { error: null },
    })),
  };
});

Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation((query) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(), // deprecated
    removeListener: jest.fn(), // deprecated
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn(),
  })),
});
