import { withGEL } from '@westpac/ui/tailwind';
const { join } = require('path');

/** @type {import('tailwindcss').Config} */
const config = withGEL({
  content: [
    join(__dirname, './src/**/*.{js,ts,jsx,tsx,mdx}'),
    join(__dirname, './node_modules/@westpac/ui/src/**/*.{js,ts,jsx,tsx,mdx}'),
    join(
      __dirname,
      './node_modules/@mesh-tenant-multiverse-ui-common/mv-account-additional-details/dist/mv-account-additional-details.js'
    ),
    join(
      __dirname,
      '../node_modules/@mesh-tenant-multiverse-ui-common/mv-utils/dist/mv-utils.js'
    ),
    join(
      __dirname,
      '../node_modules/@mesh-tenant-multiverse-ui-common/mv-pageloader/dist/mv-pageloader.js'
    ),
    join(
      __dirname,
      '../node_modules/@mesh-tenant-multiverse-ui-common/mv-card/dist/mv-card.js'
    ),
    join(
      __dirname,
      '../node_modules/@mesh-tenant-multiverse-ui-common/mv-reacthookform/dist/mv-reacthookform.js'
    ),
    join(
      __dirname,
      '../node_modules/@mesh-tenant-multiverse-ui-common/mv-table-v2/dist/mv-table.js'
    ),
    join(
      __dirname,
      '../node_modules/@mesh-tenant-multiverse-ui-common/mv-detailsection/dist/mv-detailsection.js'
    ),
    join(
      __dirname,
      '../node_modules/@mesh-tenant-multiverse-ui-common/mv-accountsummary/dist/mv-accountsummary.js'
    ),
    join(
      __dirname,
      '../node_modules/@mesh-tenant-multiverse-ui-common/mv-icons/dist/mv-icons.js'
    ),
    join(
      __dirname,
      '../node_modules/@mesh-tenant-multiverse-ui-common/mv-accountformatter/dist/mv-accountformatter.js'
    ),
    join(
      __dirname,
      '../node_modules/@mesh-tenant-multiverse-ui-common/mv-refresh/dist/mv-refresh.js'
    ),
    join(
      __dirname,
      '../node_modules/@mesh-tenant-multiverse-ui-common/mv-injection-checker/dist/mv-injection-checker.js'
    ),
    join(
      __dirname,
      '../node_modules/@mesh-tenant-multiverse-ui-common/mv-more-results-alert/dist/mv-more-results-alert.js'
    ),
    join(
      __dirname,
      '../node_modules/@mesh-tenant-multiverse-ui-common/mv-accordion/dist/mv-accordion.js'
    ),
  ],
  options: {
    brandFonts: {
      src: '/fonts',
      /** takes a single brand string e.g. 'wbc' or an array of brands.
      If no brands are specified will import all brands by default */
      brands: ['wbc'],
    },
  },
  theme: {
    extend: {
      colors: {
        'dark-azure': '#002F6C',
      },
    },
  },
  plugins: [
    function ({ addUtilities }) {
      addUtilities(
        {
          '.focus-border-blue': {
            outline: '2px solid rgb(var(--colors-focus))',
            'outline-offset': '1px',
            'border-radius': '2px',
          },
          '.focus-visible-border-blue:focus-visible': {
            outline: '2px solid rgb(var(--colors-focus))',
            'outline-offset': '1px',
            'border-radius': '2px',
          },
        },
        ['focus', 'focus-visible']
      ); // enable pseudo variants for all kind of focus
    },
  ],
});

export default config;
