const fs = require('fs');
const path = require('path');
const {
  transformForCopilot,
  transformForAmp,
  yamlQuote,
  validateSlug,
  buildCopilotAgentFrontmatter,
  buildCopilotSkillFrontmatter,
  buildAmpFrontmatter
} = require('./build');

// ---------------------------------------------------------------------------
// yamlQuote
// ---------------------------------------------------------------------------

describe('yamlQuote', () => {
  test('returns plain string unchanged', () => {
    expect(yamlQuote('hello world')).toBe('hello world');
  });

  test('quotes strings with colons', () => {
    expect(yamlQuote('key: value')).toBe('"key: value"');
  });

  test('quotes strings with hash', () => {
    expect(yamlQuote('before # comment')).toBe('"before # comment"');
  });

  test('leaves em dash unquoted (valid YAML)', () => {
    expect(yamlQuote('first — second')).toBe('first — second');
  });

  test('escapes double quotes inside', () => {
    expect(yamlQuote('say "hello"')).toBe('"say \\"hello\\""');
  });

  test('leaves plain backslash unquoted (valid YAML)', () => {
    expect(yamlQuote('path\\to')).toBe('path\\to');
  });

  test('quotes strings with curly braces', () => {
    expect(yamlQuote('use {var}')).toBe('"use {var}"');
  });

  test('quotes strings with leading/trailing whitespace', () => {
    expect(yamlQuote(' padded ')).toBe('" padded "');
  });

  test('handles non-string input', () => {
    expect(yamlQuote(42)).toBe('42');
  });
});

// ---------------------------------------------------------------------------
// validateSlug
// ---------------------------------------------------------------------------

describe('validateSlug', () => {
  test('accepts valid slug', () => {
    expect(() => validateSlug('my-agent', 'test')).not.toThrow();
  });

  test('accepts slug with dots in filename', () => {
    expect(() => validateSlug('my-agent.v2', 'test')).not.toThrow();
  });

  test('rejects empty string', () => {
    expect(() => validateSlug('', 'test')).toThrow(/non-empty/);
  });

  test('rejects path traversal with ..', () => {
    expect(() => validateSlug('../etc/passwd', 'test')).toThrow(/must not contain/);
  });

  test('rejects absolute path', () => {
    expect(() => validateSlug('/etc/passwd', 'test')).toThrow(/must not contain/);
  });

  test('rejects backslash absolute path', () => {
    expect(() => validateSlug('\\windows\\system32', 'test')).toThrow(/must not contain/);
  });

  test('rejects non-string', () => {
    expect(() => validateSlug(null, 'test')).toThrow(/non-empty/);
  });
});

// ---------------------------------------------------------------------------
// transformForCopilot
// ---------------------------------------------------------------------------

describe('transformForCopilot', () => {
  test('replaces project .env reference', () => {
    expect(transformForCopilot('Read the project `.env` file')).toBe('Read `.github/.env`');
  });

  test('strips DELEGATE markers', () => {
    expect(transformForCopilot('Do something <!-- DELEGATE --> here')).toBe('Do something here');
  });

  test('strips NEW_SESSION markers', () => {
    expect(transformForCopilot('Start <!-- NEW_SESSION --> fresh')).toBe('Start fresh');
  });

  test('preserves content without markers', () => {
    const input = 'Plain markdown content\n\nWith paragraphs.';
    expect(transformForCopilot(input)).toBe(input);
  });
});

// ---------------------------------------------------------------------------
// transformForAmp
// ---------------------------------------------------------------------------

describe('transformForAmp', () => {
  test('replaces DELEGATE marker with Task tool text', () => {
    const result = transformForAmp('Assign work <!-- DELEGATE --> to others');
    expect(result).toContain('`Task` tool');
  });

  test('replaces NEW_SESSION marker with handoff text', () => {
    const result = transformForAmp('Continue <!-- NEW_SESSION --> later');
    expect(result).toContain('`handoff` tool');
  });

  test('replaces subagent with sub-skill', () => {
    expect(transformForAmp('Deploy the subagent')).toBe('Deploy the sub-skill');
  });

  test('replaces sub-agent with sub-skill', () => {
    expect(transformForAmp('Use a sub-agent here')).toBe('Use a sub-skill here');
  });

  test('replaces subagents (plural) with sub-skills', () => {
    expect(transformForAmp('Multiple subagents running')).toBe('Multiple sub-skills running');
  });

  test('replaces Sub-Agents (capitalized) with Sub-Skills', () => {
    expect(transformForAmp('The Sub-Agents are ready')).toBe('The Sub-Skills are ready');
  });

  test('replaces specialist agents with specialist skills', () => {
    expect(transformForAmp('Use specialist agents for this')).toBe('Use specialist skills for this');
  });

  test('replaces specialized agents with specialized skills', () => {
    expect(transformForAmp('The specialized agents handle')).toBe('The specialized skills handle');
  });

  test('replaces Agent heading with Skill', () => {
    expect(transformForAmp('# My Agent')).toBe('# My Skill');
  });

  test('replaces ## Agent heading with Skill', () => {
    expect(transformForAmp('## Config Agent')).toBe('## Config Skill');
  });

  test('replaces "You are a ... agent that" pattern', () => {
    expect(transformForAmp('You are a testing agent that runs tests')).toBe('You are a testing skill that runs tests');
  });

  test('replaces "This agent" with "This skill"', () => {
    expect(transformForAmp('This agent handles requests')).toBe('This skill handles requests');
  });

  test('replaces "this agent" with "this skill"', () => {
    expect(transformForAmp('Pass to this agent')).toBe('Pass to this skill');
  });

  test('replaces "This Agent" with "This Skill"', () => {
    expect(transformForAmp('This Agent is responsible')).toBe('This Skill is responsible');
  });

  test('replaces .github/instructions/ with .agents/instructions/', () => {
    expect(transformForAmp('See .github/instructions/foo.md')).toBe('See .agents/instructions/foo.md');
  });

  test('replaces .github/.env references', () => {
    expect(transformForAmp('Set in `.github/.env` file')).toBe('Set in the project `.env` file file');
  });

  test('strips "via Copilot chat"', () => {
    expect(transformForAmp('Ask via Copilot chat')).toBe('Ask');
  });

  test('replaces | Agent | with | Skill |', () => {
    expect(transformForAmp('| Agent | Description |')).toBe('| Skill | Description |');
  });

  test('preserves plain content', () => {
    const input = 'Just some regular markdown content.';
    expect(transformForAmp(input)).toBe(input);
  });
});

// ---------------------------------------------------------------------------
// buildCopilotAgentFrontmatter
// ---------------------------------------------------------------------------

describe('buildCopilotAgentFrontmatter', () => {
  test('builds basic agent frontmatter', () => {
    const fm = buildCopilotAgentFrontmatter({ name: 'Test', description: 'A test agent' });
    expect(fm).toMatch(/^---\n/);
    expect(fm).toMatch(/---\n$/);
    expect(fm).toContain('name: Test');
    expect(fm).toContain('description: A test agent');
  });

  test('includes tools array', () => {
    const fm = buildCopilotAgentFrontmatter({ name: 'T', description: 'D', tools: ['read', 'edit'] });
    expect(fm).toContain("tools: ['read', 'edit']");
  });

  test('includes model', () => {
    const fm = buildCopilotAgentFrontmatter({ name: 'T', description: 'D', model: 'gpt-4' });
    expect(fm).toContain('model: gpt-4');
  });

  test('quotes description with colons', () => {
    const fm = buildCopilotAgentFrontmatter({ name: 'T', description: 'Role: analysis' });
    expect(fm).toContain('description: "Role: analysis"');
  });
});

// ---------------------------------------------------------------------------
// buildCopilotSkillFrontmatter
// ---------------------------------------------------------------------------

describe('buildCopilotSkillFrontmatter', () => {
  test('builds basic skill frontmatter', () => {
    const fm = buildCopilotSkillFrontmatter({ description: 'Fetches data from APIs' });
    expect(fm).toMatch(/^---\n/);
    expect(fm).toMatch(/---\n$/);
    expect(fm).toContain('description: Fetches data from APIs');
  });

  test('quotes description with special chars', () => {
    const fm = buildCopilotSkillFrontmatter({ description: 'Role: fetch & parse' });
    expect(fm).toContain('description: "Role: fetch & parse"');
  });

  test('contains only description field', () => {
    const fm = buildCopilotSkillFrontmatter({ description: 'simple' });
    expect(fm).toBe('---\ndescription: simple\n---\n');
  });
});

// ---------------------------------------------------------------------------
// buildAmpFrontmatter
// ---------------------------------------------------------------------------

describe('buildAmpFrontmatter', () => {
  test('builds basic amp frontmatter', () => {
    const fm = buildAmpFrontmatter({ name: 'test-skill', description: 'A test skill' });
    expect(fm).toMatch(/^---\n/);
    expect(fm).toMatch(/---\n$/);
    expect(fm).toContain('name: test-skill');
    expect(fm).toContain('description: A test skill');
  });

  test('quotes name with special chars', () => {
    const fm = buildAmpFrontmatter({ name: 'test: skill', description: 'desc' });
    expect(fm).toContain('name: "test: skill"');
  });
});

// ---------------------------------------------------------------------------
// Generated installer config (ai-common-config.json)
// ---------------------------------------------------------------------------

describe('Generated installer config', () => {
  const configPath = path.join(__dirname, 'install-agents', 'ai-common-config.json');
  const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

  test('instruction files have protected flag', () => {
    const foundation = config.agents.foundation;
    expect(foundation).toBeTruthy();
    const instructionFiles = foundation.files.filter(f =>
      f.destination.includes('/instructions/')
    );
    expect(instructionFiles.length).toBeGreaterThan(0);
    for (const f of instructionFiles) {
      expect(f.protected).toBe(true);
    }
  });

  test('agent files do not have protected flag', () => {
    for (const [, pkg] of Object.entries(config.agents)) {
      const agentFiles = pkg.files.filter(f =>
        (f.destination.includes('/agents/') || f.destination.includes('/skills/')) &&
        !f.destination.includes('/instructions/')
      );
      for (const f of agentFiles) {
        expect(f.protected).toBeFalsy();
      }
    }
  });

  test('prompt files do not have protected flag', () => {
    for (const [, pkg] of Object.entries(config.agents)) {
      const promptFiles = pkg.files.filter(f =>
        f.destination.includes('/prompts/')
      );
      for (const f of promptFiles) {
        expect(f.protected).toBeFalsy();
      }
    }
  });
});
