#!/usr/bin/env node
/**
 * All-in-one Agent Installer
 * Downloads files, executes actions, validates tokens.
 * Configuration-driven: update ai-common-config.json to add agents, files, or actions.
 */

// ============================================
// SECTION 1: Dependencies & Configuration
// ============================================
const https = require("node:https");
const fs = require("node:fs");
const path = require("node:path");
const readline = require("node:readline");
const { execSync, execFileSync } = require("node:child_process");

const BITBUCKET_BASE_URL =
  process.env.AI_COMMON_BITBUCKET_URL || "bitbucket.srv.westpac.com.au";
const AI_COMMON_PROJECT = process.env.AI_COMMON_PROJECT || "A014A6";
const AI_COMMON_REPO = process.env.AI_COMMON_REPO || "ai-common";
const PROJECT_ROOT = process.cwd();
const CONFIG_PATH = path.join(__dirname, "ai-common-config.json");

// When false (default), existing files with user modifications are skipped.
// Set via --force flag to overwrite all files unconditionally.
let FORCE_OVERWRITE = false;

// ============================================
// SECTION 2: Utility Functions
// ============================================

function loadConfig() {
  if (!fs.existsSync(CONFIG_PATH)) {
    // eslint-disable-next-line no-console
    console.error("\n❌ Config not found. Run: node sync-ai-common.js\n");
    process.exit(1);
  }
  try {
    return JSON.parse(fs.readFileSync(CONFIG_PATH, "utf8"));
  } catch (parseError) {
    // eslint-disable-next-line no-console
    console.error(
      `\n❌ Invalid config file (${CONFIG_PATH}): ${parseError.message}\n`,
    );
    process.exit(1);
  }
}

function validateToken() {
  if (!process.env.BITBUCKET_PAT) {
    // eslint-disable-next-line no-console
    console.error("\n❌ BITBUCKET_PAT not set\n");
    process.exit(1);
  }
  return process.env.BITBUCKET_PAT;
}

function ensureDirectoryExists(directoryPath) {
  if (!fs.existsSync(directoryPath))
    fs.mkdirSync(directoryPath, { recursive: true });
}

function isGitRepo() {
  try {
    execSync("git rev-parse --git-dir", { stdio: "pipe" });
    return true;
  } catch (error) {
    // Expected: git command fails in non-git directories
    console.debug(`isGitRepo check failed: ${error.message}`);
    return false;
  }
}

function isFileTrackedInGit(filePath) {
  if (!isGitRepo()) return false;
  try {
    execFileSync("git", ["ls-files", "--error-unmatch", filePath], {
      stdio: "pipe",
    });
    return true;
  } catch (error) {
    // Expected: file is not tracked in git
    console.debug(`File not tracked: ${error.message}`);
    return false;
  }
}

function restoreFileIfUnchangedFromHead(filePath) {
  if (!isGitRepo() || !isFileTrackedInGit(filePath)) return;
  try {
    execFileSync("git", ["diff", "--quiet", "HEAD", "--", filePath], {
      stdio: "pipe",
    });
  } catch (diffError) {
    console.debug(`Diff check triggered restore attempt: ${diffError.message}`);
    try {
      const headContent = execFileSync(
        "git",
        ["show", `HEAD:${filePath}`],
        { encoding: "utf8", stdio: "pipe" },
      );
      const currentContent = fs.readFileSync(filePath, "utf8");
      if (headContent === currentContent) {
        execFileSync("git", ["checkout", "HEAD", "--", filePath], {
          stdio: "pipe",
        });
      }
    } catch (compareError) {
      // Couldn't compare, leave as is
      console.debug(`Restore comparison failed: ${compareError.message}`);
    }
  }
}

function getTemplateVariables() {
  const variables = {
    PROJECT_ROOT,
    USER: process.env.USER || "user",
    OS: process.platform,
  };
  try {
    const remoteUrl = execSync("git config --get remote.origin.url", {
      encoding: "utf8",
      stdio: ["pipe", "pipe", "pipe"],
    }).trim();
    const repoNameMatch = remoteUrl.match(/\/([^/]+?)(\.git)?$/);
    if (repoNameMatch) {
      const [, repoName] = repoNameMatch;
      variables.GIT_REPO_NAME = repoName;
    }
  } catch (error) {
    // No git remote available
    console.debug(`Git remote not available: ${error.message}`);
  }
  return variables;
}

function escapeRegExp(string) {
  return string.replaceAll(/[.*+?^${}()|[\]\\]/g, String.raw`\$&`);
}

function substituteVariables(templateString, variables) {
  let result = templateString;
  Object.entries(variables).forEach(([variableName, variableValue]) => {
    result = result.replaceAll(`\${${variableName}}`, variableValue);
  });
  return result;
}

/**
 * Checks whether an item's target array matches the active target filter.
 * - If the item's target includes "generic" or "all" (backward compat), it always matches (wildcard).
 * - If no activeTarget is provided (no --target flag), defaults to "generic",
 *   matching items with "generic" or "all" targets.
 * - Otherwise, the item matches if its target includes the activeTarget value (case-insensitive).
 */
function isTargetMatch(itemTargets, activeTarget = "generic") {
  const normalizedTargets = new Set(
    (itemTargets || ["generic"]).map((target) => target.toLowerCase()),
  );
  // Support both "generic" (new) and "all" (backward compatibility) as wildcards
  if (normalizedTargets.has("generic") || normalizedTargets.has("all"))
    return true;
  return normalizedTargets.has(activeTarget.toLowerCase());
}

/**
 * Checks whether a file mapping's tool field matches the active tool filter.
 * - "both" in either the item or the filter means it always matches.
 * - If the item has no tool field, defaults to "copilot" for backward compatibility.
 */
function isToolMatch(itemTool, activeTool) {
  const tool = (itemTool || "copilot").toLowerCase();
  if (activeTool === "both") return true;
  if (tool === "both") return true;
  return tool === activeTool.toLowerCase();
}

/**
 * Checks whether a file should be treated as protected based on the parent
 * mapping's explicit `protected` flag or its `protectedPaths` prefixes.
 */
function isFileProtected(fileMapping, relativePath) {
  if (fileMapping.protected) return true;
  return (fileMapping.protectedPaths || []).some((prefix) =>
    relativePath.startsWith(prefix));
}

/**
 * Determines whether a file should be written or skipped.
 * - If the file does not exist → always write it.
 * - If the file is protected (e.g., instructions with user content) and exists
 *   → skip unless FORCE_OVERWRITE is set.
 * - All other existing files → overwrite (agents, skills, prompts are always
 *   updated to the latest version).
 */
function shouldWriteFile(destinationPath, incomingContent, isProtected) {
  if (!fs.existsSync(destinationPath)) {
    return { skip: false };
  }
  if (!isProtected) {
    return { skip: false };
  }
  if (FORCE_OVERWRITE) {
    return { skip: false };
  }
  const existingContent = fs.readFileSync(destinationPath, "utf8");
  if (existingContent === incomingContent) {
    return { skip: true, reason: "· (up-to-date)" };
  }
  return { skip: true, reason: "⊘ (protected, use --force to overwrite)" };
}

/**
 * Merges ai-common AGENTS.md content into an existing AGENTS.md file.
 * Uses HTML comment markers for idempotent updates:
 * - If no existing file: writes the content wrapped in markers.
 * - If markers exist: replaces the marked block.
 * - If file exists without markers: appends the marked block.
 */
function mergeAgentsMd(existingContent, incomingContent) {
  const start = "<!-- AI-COMMON:START -->";
  const end = "<!-- AI-COMMON:END -->";
  const incomingBlock = `${start}\n${incomingContent.trim()}\n${end}\n`;

  if (!existingContent) return incomingBlock;

  if (existingContent.includes(start) && existingContent.includes(end)) {
    const re = new RegExp(
      String.raw`${escapeRegExp(start)}[\s\S]*?${escapeRegExp(end)}\n?`,
      "m",
    );
    return existingContent.replace(re, incomingBlock);
  }

  return `${existingContent.trimEnd()}\n\n${incomingBlock}`;
}

// ============================================
// SECTION 3: Download Functions
// ============================================

/**
 * Makes an HTTPS GET request to Bitbucket with redirect support.
 * SSL verification uses Node.js defaults — configure corporate CAs via
 * the NODE_EXTRA_CA_CERTS environment variable rather than disabling verification.
 */
function makeBitbucketRequest(requestPath, bitbucketToken) {
  return new Promise((resolve, reject) => {
    function collectBody(res) {
      let data = "";
      res.on("data", (chunk) => {
        data += chunk;
      });
      res.on("end", () => {
        resolve(data);
      });
    }

    https
      .request(
        {
          hostname: BITBUCKET_BASE_URL,
          path: requestPath,
          headers: { Authorization: `Bearer ${bitbucketToken}` },
        },
        (response) => {
          if (response.statusCode === 301 || response.statusCode === 302) {
            https
              .get(
                response.headers.location,
                {
                  headers: { Authorization: `Bearer ${bitbucketToken}` },
                },
                (redirectResponse) => {
                  if (redirectResponse.statusCode !== 200) {
                    reject(new Error(`HTTP ${redirectResponse.statusCode}`));
                    return;
                  }
                  collectBody(redirectResponse);
                },
              )
              .on("error", reject);
            return;
          }
          if (response.statusCode !== 200) {
            reject(new Error(`HTTP ${response.statusCode}`));
            return;
          }
          collectBody(response);
        },
      )
      .on("error", reject)
      .end();
  });
}

function downloadFileFromBitbucket(sourcePath, bitbucketToken, branchName) {
  const requestPath = `/rest/api/1.0/projects/${AI_COMMON_PROJECT}/repos/${AI_COMMON_REPO}/raw/${sourcePath}?at=refs/heads/${branchName}`;
  return makeBitbucketRequest(requestPath, bitbucketToken);
}

function listDirectoryFiles(directoryPath, bitbucketToken, branchName) {
  const requestPath = `/rest/api/1.0/projects/${AI_COMMON_PROJECT}/repos/${AI_COMMON_REPO}/files/${directoryPath}?at=refs/heads/${branchName}&limit=1000`;
  return makeBitbucketRequest(requestPath, bitbucketToken).then(
    (data) => JSON.parse(data).values || [],
  );
}

async function downloadSingleFile(fileMapping, bitbucketToken, branchName) {
  try {
    process.stdout.write(
      `  ${fileMapping.description || fileMapping.source}... `,
    );
    const fileContent = await downloadFileFromBitbucket(
      fileMapping.source,
      bitbucketToken,
      branchName,
    );
    const destinationPath = path.join(PROJECT_ROOT, fileMapping.destination);
    const wasTracked = isFileTrackedInGit(destinationPath);

    ensureDirectoryExists(path.dirname(destinationPath));

    // Handle AGENTS.md merge for Amp installs
    if (fileMapping.merge === "agents-md") {
      let existingContent = null;
      if (fs.existsSync(destinationPath)) {
        existingContent = fs.readFileSync(destinationPath, "utf8");
      }
      const mergedContent = mergeAgentsMd(existingContent, fileContent);
      fs.writeFileSync(destinationPath, mergedContent);
    } else {
      const writeDecision = shouldWriteFile(destinationPath, fileContent, fileMapping.protected);
      if (writeDecision.skip) {
        // eslint-disable-next-line no-console
        console.log(writeDecision.reason);
        return { success: true, skipped: true };
      }
      fs.writeFileSync(destinationPath, fileContent);
    }

    if (
      !wasTracked &&
      (fileMapping.destination.endsWith(".js") ||
        fileMapping.destination.endsWith(".sh"))
    ) {
      try {
        fs.chmodSync(destinationPath, 0o755);
      } catch (chmodError) {
        /* chmod may fail on Windows */
        console.debug(`chmod failed (expected on Windows): ${chmodError.message}`);
      }
    }

    if (wasTracked) {
      restoreFileIfUnchangedFromHead(destinationPath);
    }

    // eslint-disable-next-line no-console
    console.log("✓");
    return { success: true };
  } catch (downloadError) {
    // eslint-disable-next-line no-console
    console.log(`✗ (${downloadError.message})`);
    return { success: false, error: downloadError.message };
  }
}

async function downloadDirectoryFiles(fileMapping, bitbucketToken, branchName) {
  // eslint-disable-next-line no-console
  console.log(`\n  Dir: ${fileMapping.description || fileMapping.source}`);
  const results = [];
  try {
    const fileList = await listDirectoryFiles(
      fileMapping.source,
      bitbucketToken,
      branchName,
    );
    // Sequential downloads required to maintain order and avoid overwhelming the server
    // eslint-disable-next-line no-restricted-syntax
    for (const fileName of fileList) {
      const fullSourcePath = `${fileMapping.source}/${fileName}`;
      const relativePath = fileName.replace(`${fileMapping.source}/`, "");
      const destinationRelative = path.join(
        fileMapping.destination,
        relativePath,
      );
      const resolvedDest = path.resolve(PROJECT_ROOT, destinationRelative);
      if (!resolvedDest.startsWith(path.resolve(PROJECT_ROOT))) {
        // eslint-disable-next-line no-console
        console.log(`  ⚠️  Skipped (path traversal): ${fileName}`);
        // eslint-disable-next-line no-continue
        continue;
      }
      const isProtected = isFileProtected(fileMapping, relativePath);

      // eslint-disable-next-line no-await-in-loop
      results.push(
        await downloadSingleFile(
          {
            source: fullSourcePath,
            destination: destinationRelative,
            description: fileName,
            protected: isProtected || undefined,
          },
          bitbucketToken,
          branchName,
        ),
      );
    }
  } catch (listError) {
    console.debug(`Directory listing failed: ${listError.message}`);
    results.push({ success: false });
  }
  return results;
}

async function downloadAgentFiles(
  agent,
  bitbucketToken,
  branchName,
  targetFilter,
  toolFilter,
) {
  // eslint-disable-next-line no-console
  console.log(`\n📦 ${agent.name}`);
  const results = [];
  // Sequential processing required for ordered output and server load management
  // eslint-disable-next-line no-restricted-syntax
  for (const fileMapping of agent.files) {
    if (!isToolMatch(fileMapping.tool, toolFilter || "copilot")) {
      // eslint-disable-next-line no-console
      console.log(
        `  ⊘ Skipped (tool): ${fileMapping.description || fileMapping.source}`,
      );
    } else if (!isTargetMatch(fileMapping.target, targetFilter)) {
      // eslint-disable-next-line no-console
      console.log(
        `  ⊘ Skipped (target): ${fileMapping.description || fileMapping.source}`,
      );
    } else if (fileMapping.type === "directory") {
      // eslint-disable-next-line no-await-in-loop
      results.push(
        ...(await downloadDirectoryFiles(
          fileMapping,
          bitbucketToken,
          branchName,
        )),
      );
    } else {
      // eslint-disable-next-line no-await-in-loop
      results.push(
        await downloadSingleFile(fileMapping, bitbucketToken, branchName),
      );
    }
  }
  return results;
}

// ============================================
// SECTION 4: Action Executors
// ============================================

function executeNpmInstall(action) {
  const packagePath = path.join(PROJECT_ROOT, action.path);
  if (!fs.existsSync(path.join(packagePath, "package.json"))) {
    throw new Error("No package.json");
  }
  execSync("npm install", { cwd: packagePath, stdio: "inherit" });
  // eslint-disable-next-line no-console
  console.log("    ✓");
  return { success: true };
}

function executeCreateConfig(action, templateVariables) {
  const destinationPath = path.join(PROJECT_ROOT, action.destination);

  let content = "";
  if (action.content) {
    content = action.content;
  } else if (action.template) {
    const templatePath = path.join(PROJECT_ROOT, action.template);
    if (fs.existsSync(templatePath))
      content = fs.readFileSync(templatePath, "utf8");
  }
  content = substituteVariables(content, {
    ...templateVariables,
    ...action.variables,
  });

  const isAutoGenerated = content.includes("AUTO-GENERATED");

  if (isAutoGenerated && fs.existsSync(destinationPath)) {
    fs.unlinkSync(destinationPath);
  }

  if (!isAutoGenerated && fs.existsSync(destinationPath)) {
    // eslint-disable-next-line no-console
    console.log("    Exists (user file)");
    return { success: true, skipped: true };
  }

  ensureDirectoryExists(path.dirname(destinationPath));
  fs.writeFileSync(destinationPath, content);
  // eslint-disable-next-line no-console
  console.log("    ✓");
  return { success: true };
}

function executeEnsureGitignore(action) {
  const gitignorePath = path.join(PROJECT_ROOT, ".gitignore");

  let lines = [];
  if (fs.existsSync(gitignorePath)) {
    lines = fs.readFileSync(gitignorePath, "utf8").split("\n");
  }

  let insertIndex = -1;
  const commentLine = action.entries.find((entry) => entry.startsWith("#"));
  if (commentLine) {
    insertIndex = lines.findIndex((line) => line.trim() === commentLine.trim());
  }

  const missingEntries = action.entries.filter((entry) => {
    if (entry === "" || entry.startsWith("#")) return false;
    return !lines.some((line) => line.trim() === entry.trim());
  });

  if (missingEntries.length > 0) {
    if (insertIndex === -1) {
      if (lines[lines.length - 1] !== "") lines.push("");
      lines.push(...action.entries);
    } else {
      lines.splice(insertIndex + 1, 0, ...missingEntries);
    }

    fs.writeFileSync(gitignorePath, lines.join("\n"));
    restoreFileIfUnchangedFromHead(gitignorePath);
  }

  // eslint-disable-next-line no-console
  console.log("    ✓");
  return { success: true };
}

function executeCopyFile(action) {
  const sourcePath = path.join(PROJECT_ROOT, action.source);
  const destinationPath = path.join(PROJECT_ROOT, action.destination);

  if (!fs.existsSync(sourcePath)) {
    throw new Error("Source not found");
  }

  if (fs.existsSync(destinationPath)) {
    // eslint-disable-next-line no-console
    console.log("    Exists");
    return { success: true, skipped: true };
  }

  ensureDirectoryExists(path.dirname(destinationPath));
  fs.copyFileSync(sourcePath, destinationPath);
  // eslint-disable-next-line no-console
  console.log("    ✓");
  return { success: true };
}

function executeMakeExecutable(action) {
  const filePath = path.join(PROJECT_ROOT, action.path);

  if (!fs.existsSync(filePath)) {
    throw new Error("File not found");
  }

  try {
    fs.chmodSync(filePath, 0o755);
  } catch (chmodError) {
    if (process.platform !== "win32") throw chmodError;
  }

  // eslint-disable-next-line no-console
  console.log("    ✓");
  return { success: true };
}

function executeRunScript(action) {
  const scriptPath = path.join(PROJECT_ROOT, action.script);

  if (!fs.existsSync(scriptPath)) {
    throw new Error("Script not found");
  }

  execFileSync("node", [scriptPath, ...(action.args || [])], {
    cwd: PROJECT_ROOT,
    stdio: "inherit",
  });

  // eslint-disable-next-line no-console
  console.log("    ✓");
  return { success: true };
}

function executeAction(action, templateVariables) {
  // eslint-disable-next-line no-console
  console.log(`\n  ▸ ${action.description || action.type}`);
  try {
    switch (action.type) {
      case "npm-install":
        return executeNpmInstall(action);
      case "create-config":
        return executeCreateConfig(action, templateVariables);
      case "ensure-gitignore":
        return executeEnsureGitignore(action);
      case "copy-file":
        return executeCopyFile(action);
      case "make-executable":
        return executeMakeExecutable(action);
      case "run-script":
        return executeRunScript(action);
      default:
        throw new Error(`Unknown action type: ${action.type}`);
    }
  } catch (actionError) {
    // eslint-disable-next-line no-console
    console.log(`    ✗ ${actionError.message}`);
    return { success: false };
  }
}

// ============================================
// SECTION 5: Main Orchestration
// ============================================

function executeAllActions(agent, templateVariables, targetFilter, toolFilter) {
  // eslint-disable-next-line no-console
  console.log(`\n⚙️  ${agent.name}`);
  if (!agent.actions || !agent.actions.length) {
    // eslint-disable-next-line no-console
    console.log("  (none)");
    return { ok: 0, fail: 0 };
  }
  const results = [];
  let shouldStop = false;
  agent.actions.forEach((action) => {
    if (shouldStop) return;
    if (!isTargetMatch(action.target, targetFilter)) {
      // eslint-disable-next-line no-console
      console.log(
        `\n  ⊘ Skipped (target): ${action.description || action.type}`,
      );
      return;
    }
    if (toolFilter && !isToolMatch(action.tool, toolFilter)) {
      // eslint-disable-next-line no-console
      console.log(
        `\n  ⊘ Skipped (tool): ${action.description || action.type}`,
      );
      return;
    }
    const result = executeAction(action, templateVariables);
    results.push(result);
    if (!result.success && !result.skipped) {
      shouldStop = true;
    }
  });
  return {
    ok: results.filter((result) => result.success).length,
    fail: results.filter((result) => !result.success).length,
  };
}

function validateRequiredTokens(agent) {
  if (!agent.requiredTokens || !agent.requiredTokens.length) return true;
  // eslint-disable-next-line no-console
  console.log("\n🔑 Tokens");
  const validatorScriptPath = path.join(
    PROJECT_ROOT,
    ".github/skills/check-pat/scripts/validate-token.js",
  );
  if (!fs.existsSync(validatorScriptPath)) {
    // eslint-disable-next-line no-console
    console.log("  (validator missing)");
    return true;
  }
  let allTokensValid = true;
  agent.requiredTokens.forEach((tokenName) => {
    try {
      execFileSync("node", [validatorScriptPath, tokenName], {
        cwd: PROJECT_ROOT,
        stdio: "inherit",
      });
      // eslint-disable-next-line no-console
      console.log(`  ✓ ${tokenName}`);
    } catch (validationError) {
      // eslint-disable-next-line no-console
      console.log(`  ✗ ${tokenName}: ${validationError.message}`);
      allTokensValid = false;
    }
  });
  return allTokensValid;
}

function listAgents(config) {
  // eslint-disable-next-line no-console
  console.log("\n📋 Agents:\n");
  Object.entries(config.agents).forEach(([agentKey, agent]) => {
    const targetLabel = (agent.target || ["generic"]).join(", ");
    // eslint-disable-next-line no-console
    console.log(
      `${agent.enabled ? "✓" : "✗"} ${agentKey} - ${agent.description} [target: ${targetLabel}]`,
    );
  });
  // eslint-disable-next-line no-console
  console.log("");
}

async function installAgent(agentName, config, targetFilter, toolFilter) {
  const agent = config.agents[agentName];
  if (!agent) {
    // eslint-disable-next-line no-console
    console.error(`\n❌ Not found: ${agentName}\n`);
    process.exit(1);
  }
  if (!agent.enabled) {
    // eslint-disable-next-line no-console
    console.error(`\n❌ Disabled: ${agentName}\n`);
    process.exit(1);
  }

  // eslint-disable-next-line no-console
  console.log(`\n🚀 ${agent.name}\n`);

  const bitbucketToken = validateToken();
  const branchName = config.repository?.branch || "master";
  const templateVariables = getTemplateVariables();

  const downloadResults = await downloadAgentFiles(
    agent,
    bitbucketToken,
    branchName,
    targetFilter,
    toolFilter,
  );
  const successfulDownloadCount = downloadResults.filter(
    (result) => result.success,
  ).length;
  // eslint-disable-next-line no-console
  console.log(`\n  ✅ ${successfulDownloadCount} files`);
  if (downloadResults.some((result) => !result.success)) return false;

  const { ok: successfulActionCount, fail: failedActionCount } =
    executeAllActions(agent, templateVariables, targetFilter, toolFilter);
  // eslint-disable-next-line no-console
  console.log(`\n  ✅ ${successfulActionCount} actions`);
  if (failedActionCount > 0) return false;

  const allTokensValid = validateRequiredTokens(agent);

  // eslint-disable-next-line no-console
  console.log("\n✅ Done!\n");
  // eslint-disable-next-line no-console
  if (!allTokensValid) console.log("⚠️  Some tokens missing\n");

  return true;
}

async function installAllMatchingAgents(config, targetFilter, toolFilter) {
  const enabledAgents = Object.entries(config.agents).filter(
    ([, agent]) => agent.enabled && isTargetMatch(agent.target, targetFilter),
  );
  if (!enabledAgents.length) {
    // eslint-disable-next-line no-console
    console.log("\n⚠️  No matching enabled agents\n");
    return;
  }

  // eslint-disable-next-line no-console
  console.log(`\n🚀 ${enabledAgents.length} agents (tool: ${toolFilter})\n`);
  let successCount = 0;
  let failureCount = 0;
  // Sequential agent installation required for ordered output
  // eslint-disable-next-line no-restricted-syntax
  for (const [agentKey] of enabledAgents) {
    // eslint-disable-next-line no-console
    console.log("─".repeat(50));
    // eslint-disable-next-line no-await-in-loop
    const installResult = await installAgent(
      agentKey,
      config,
      targetFilter,
      toolFilter,
    );
    if (installResult) {
      successCount += 1;
    } else {
      failureCount += 1;
    }
  }
  // eslint-disable-next-line no-console
  console.log(`\n📊 ${successCount} ok, ${failureCount} failed\n`);
  if (failureCount) process.exit(1);
}

/**
 * Interactive package selection and installation.
 * Presents available packages, lets the user pick, and installs them.
 *
 * @param {Object} config - The loaded ai-common-config.json
 * @param {string|null} explicitToolFilter - Tool filter if --tool was explicitly provided, null otherwise
 * @param {string} targetFilter - Target filter from --target flag
 */
async function interactiveInstall(config, explicitToolFilter, targetFilter) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  const ask = (question) =>
    new Promise((resolve) => rl.question(question, resolve));

  const packages = Object.entries(config.agents)
    .filter(([, agent]) => agent.enabled)
    .map(([key, agent]) => ({ key, ...agent }));

  /* eslint-disable no-console */
  console.log("\n🚀 AI Common Installer — Interactive Mode");
  console.log("═".repeat(50));
  console.log("\nAvailable packages:\n");

  packages.forEach((pkg, index) => {
    const marker = pkg.key === "foundation" ? " (always included)" : "";
    console.log(`  ${index + 1}. ${pkg.name}${marker}`);
    console.log(`     ${pkg.description}\n`);
  });

  console.log(
    'Enter "all" to install everything, or package numbers (e.g. 1,3,5).',
  );
  console.log('Enter "q" to quit.\n');
  /* eslint-enable no-console */

  const selection = await ask("Selection: ");

  if (selection.trim().toLowerCase() === "q") {
    // eslint-disable-next-line no-console
    console.log("\nCancelled.\n");
    rl.close();
    return;
  }

  let selectedKeys;
  if (selection.trim().toLowerCase() === "all") {
    selectedKeys = packages.map((p) => p.key);
  } else {
    const indices = selection
      .split(/[,\s]+/)
      .map((s) => Number.parseInt(s.trim(), 10) - 1)
      .filter((i) => !Number.isNaN(i) && i >= 0 && i < packages.length);
    selectedKeys = indices.map((i) => packages[i].key);
  }

  if (!selectedKeys.length) {
    // eslint-disable-next-line no-console
    console.log("\n⚠️  No valid packages selected.\n");
    rl.close();
    return;
  }

  // Ask for tool if not explicitly provided via --tool flag
  let effectiveTool = explicitToolFilter;
  if (!effectiveTool) {
    /* eslint-disable no-console */
    console.log("\nSelect AI tool:");
    console.log("  1. Copilot (default)");
    console.log("  2. Amp");
    console.log("  3. Both\n");
    /* eslint-enable no-console */
    const toolChoice = await ask("Tool [1]: ");
    const toolMap = { "": "copilot", "1": "copilot", "2": "amp", "3": "both" };
    effectiveTool = toolMap[toolChoice.trim()] || "copilot";
  }

  // Always include foundation if not already selected
  if (!selectedKeys.includes("foundation")) {
    selectedKeys.unshift("foundation");
  }

  /* eslint-disable no-console */
  console.log("\n📦 Will install:");
  selectedKeys.forEach((key) => {
    const pkg = packages.find((p) => p.key === key);
    console.log(`  • ${pkg ? pkg.name : key}`);
  });
  console.log(`\n  Tool: ${effectiveTool}`);
  /* eslint-enable no-console */

  const confirm = await ask("\nProceed? [Y/n]: ");
  rl.close();

  if (confirm.trim().toLowerCase() === "n") {
    // eslint-disable-next-line no-console
    console.log("\nCancelled.\n");
    return;
  }

  // Install selected packages sequentially
  let successCount = 0;
  let failureCount = 0;
  // eslint-disable-next-line no-restricted-syntax
  for (const key of selectedKeys) {
    // eslint-disable-next-line no-console
    console.log("─".repeat(50));
    // eslint-disable-next-line no-await-in-loop
    const result = await installAgent(key, config, targetFilter, effectiveTool);
    if (result) {
      successCount += 1;
    } else {
      failureCount += 1;
    }
  }
  // eslint-disable-next-line no-console
  console.log(`\n📊 ${successCount} ok, ${failureCount} failed\n`);
  if (failureCount) process.exit(1);
}

/**
 * Parses the --target=<value> flag from CLI arguments.
 * Returns the target value or 'generic' if not specified (default).
 */
function parseTargetFlag(cliArgs) {
  const targetArg = cliArgs.find((arg) => arg.startsWith("--target="));
  if (!targetArg) return "generic";
  return targetArg.split("=")[1] || "generic";
}

/**
 * Parses the --tool=<value> flag from CLI arguments.
 * Returns 'copilot' (default), 'amp', or 'both'.
 */
function parseToolFlag(cliArgs) {
  const toolArg = cliArgs.find((arg) => arg.startsWith("--tool="));
  const tool = ((toolArg ? toolArg.split("=")[1] : "copilot") || "copilot").toLowerCase();
  if (!["copilot", "amp", "both"].includes(tool)) {
    // eslint-disable-next-line no-console
    console.error(
      `\n❌ Invalid --tool value: "${tool}". Use: copilot, amp, or both\n`,
    );
    process.exit(1);
  }
  return tool;
}

/**
 * Parses the --example=<name> flag from CLI arguments.
 * Returns the example name or null if not specified.
 */
function parseExampleFlag(cliArgs) {
  const exampleArg = cliArgs.find((arg) => arg.startsWith("--example="));
  if (!exampleArg) return null;
  return exampleArg.split("=")[1] || null;
}

/**
 * Installs example content as an overlay on top of the standard agent install.
 * Downloads example-specific files from examples/<name>/copilot/ or examples/<name>/amp/
 * based on the active tool filter.
 */
async function installExample(exampleName, toolFilter, bitbucketToken, branchName) {
  // eslint-disable-next-line no-console
  console.log(`\n📦 Example: ${exampleName}\n`);

  const results = [];

  if (toolFilter === "copilot" || toolFilter === "both") {
    // Download copilot example files
    const copilotMapping = {
      source: `examples/${exampleName}/copilot`,
      destination: ".github",
      type: "directory",
      protectedPaths: ["instructions/"],
      description: `Example (${exampleName}) — Copilot files`,
    };
    try {
      const dirResults = await downloadDirectoryFiles(
        copilotMapping,
        bitbucketToken,
        branchName,
      );
      results.push(...dirResults);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(`  ⚠️  Copilot example files not found for ${exampleName}: ${error.message}`);
    }
  }

  if (toolFilter === "amp" || toolFilter === "both") {
    // Download amp AGENTS.md (with merge)
    try {
      process.stdout.write(
        `  Example (${exampleName}) — Amp AGENTS.md... `,
      );
      const agentsMdContent = await downloadFileFromBitbucket(
        `examples/${exampleName}/amp/AGENTS.md`,
        bitbucketToken,
        branchName,
      );
      const destinationPath = path.join(PROJECT_ROOT, "AGENTS.md");
      let existingContent = null;
      if (fs.existsSync(destinationPath)) {
        existingContent = fs.readFileSync(destinationPath, "utf8");
      }
      const mergedContent = mergeAgentsMd(existingContent, agentsMdContent);
      fs.writeFileSync(destinationPath, mergedContent);
      // eslint-disable-next-line no-console
      console.log("✓");
      results.push({ success: true });
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(`✗ (${error.message})`);
    }

    // Download amp .agents/ directory
    const ampAgentsMapping = {
      source: `examples/${exampleName}/amp/.agents`,
      destination: ".agents",
      type: "directory",
      protectedPaths: ["instructions/"],
      description: `Example (${exampleName}) — Amp .agents`,
    };
    try {
      const dirResults = await downloadDirectoryFiles(
        ampAgentsMapping,
        bitbucketToken,
        branchName,
      );
      results.push(...dirResults);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(`  ⚠️  Amp example files not found for ${exampleName}: ${error.message}`);
    }
  }

  const successCount = results.filter((r) => r.success).length;
  // eslint-disable-next-line no-console
  console.log(`\n  ✅ ${successCount} example files`);
}

async function installExampleIfNeeded(exampleName, toolFilter, config) {
  if (!exampleName) return;
  const bitbucketToken = validateToken();
  const branchName = config.repository?.branch || "master";
  await installExample(exampleName, toolFilter, bitbucketToken, branchName);
}

async function main() {
  const cliArgs = process.argv.slice(2);

  if (cliArgs[0] === "--help") {
    /* eslint-disable no-console */
    console.log("\nUsage: node install-agent.js [options] [agent-name]\n");
    console.log("Description:");
    console.log(
      "  Downloads and installs AI agents from the ai-common repository.",
    );
    console.log("  Configuration is read from ai-common-config.json.\n");
    console.log("Arguments:");
    console.log(
      "  <agent-name>               Name of a specific agent to install\n",
    );
    console.log("Options:");
    console.log("  --help                     Show this help message and exit");
    console.log(
      "  --list                     List all available agents with their status and targets",
    );
    console.log(
      "  --interactive, -i          Interactive mode — choose packages from a menu",
    );
    console.log(
      "  --tool=<value>             Select AI tool: copilot (default), amp, or both",
    );
    console.log(
      "                             Filters file deployments by tool type",
    );
    console.log(
      "  --target=<value>           Filter agents/files/actions by target platform",
    );
    console.log(
      '                             Defaults to "generic" if not specified',
    );
    console.log(
      "                             Common values: generic, mfe, spa, widget, api",
    );
    console.log(
      "  --force                    Overwrite existing files even if modified",
    );
    console.log(
      "                             Without this flag, modified files are skipped",
    );
    console.log(
      "  --example=<name>           Deploy example content (e.g., test-ets-restassured)",
    );
    console.log(
      "                             Overlays example files on top of standard install\n",
    );
    console.log("Examples:");
    console.log(
      "  node install-agent.js                        Install all for Copilot (default)",
    );
    console.log(
      "  node install-agent.js --interactive           Interactive package selection",
    );
    console.log(
      "  node install-agent.js -i --tool=amp           Interactive, pre-select Amp",
    );
    console.log(
      "  node install-agent.js --tool=amp              Install all for Amp",
    );
    console.log(
      "  node install-agent.js --tool=both             Install for both Copilot and Amp",
    );
    console.log(
      "  node install-agent.js code-review-westpac --tool=amp  Install code-review-westpac for Amp",
    );
    console.log(
      "  node install-agent.js --tool=amp --example=test-ets-restassured",
    );
    console.log(
      "                                               Install with example overlay",
    );
    console.log("  node install-agent.js code-review-westpac --target=mfe");
    console.log(
      '                                               Install with target "mfe"',
    );
    console.log(
      "  node install-agent.js --list                 List available agents\n",
    );
    console.log("Environment:");
    console.log(
      "  BITBUCKET_PAT              Required. Personal access token for Bitbucket.",
    );
    console.log(
      "  NODE_EXTRA_CA_CERTS        Path to corporate CA bundle for SSL verification.",
    );
    console.log(
      "  AI_COMMON_BITBUCKET_URL    Override Bitbucket hostname (default: bitbucket.srv.westpac.com.au)",
    );
    console.log(
      "  AI_COMMON_PROJECT          Override Bitbucket project key (default: A014A6)",
    );
    console.log(
      "  AI_COMMON_REPO             Override Bitbucket repo slug (default: ai-common)\n",
    );
    /* eslint-enable no-console */
    process.exit(0);
  }

  const config = loadConfig();
  const targetFilter = parseTargetFlag(cliArgs);
  const toolFilter = parseToolFlag(cliArgs);
  const toolExplicit = cliArgs.some((arg) => arg.startsWith("--tool="));
  const exampleName = parseExampleFlag(cliArgs);
  FORCE_OVERWRITE = cliArgs.includes("--force");
  const isInteractive = cliArgs.some(
    (arg) => arg === "--interactive" || arg === "-i",
  );
  const positionalArgs = cliArgs.filter(
    (arg) =>
      !arg.startsWith("--target=") &&
      !arg.startsWith("--tool=") &&
      !arg.startsWith("--example=") &&
      arg !== "--interactive" &&
      arg !== "-i" &&
      arg !== "--force",
  );

  if (positionalArgs[0] === "--list") {
    listAgents(config);
  } else if (isInteractive) {
    await interactiveInstall(
      config,
      toolExplicit ? toolFilter : null,
      targetFilter,
    );
    await installExampleIfNeeded(exampleName, toolFilter, config);
  } else if (positionalArgs.length === 0 || positionalArgs[0] === undefined) {
    await installAllMatchingAgents(config, targetFilter, toolFilter);
    await installExampleIfNeeded(exampleName, toolFilter, config);
  } else {
    const installSuccess = await installAgent(
      positionalArgs[0],
      config,
      targetFilter,
      toolFilter,
    );
    await installExampleIfNeeded(exampleName, toolFilter, config);
    process.exit(installSuccess ? 0 : 1);
  }
}

if (require.main === module) {
  process.on("unhandledRejection", (error) => {
    // eslint-disable-next-line no-console
    console.error(`\n❌ ${error.message}\n`);
    process.exit(1);
  });
  // eslint-disable-next-line unicorn/prefer-top-level-await -- CJS module cannot use top-level await
  main();
}

// Backward-compatible aliases for old function names (used by tests during migration)
const ensureDir = ensureDirectoryExists;
const getVars = getTemplateVariables;
const sub = substituteVariables;
const dl = downloadFileFromBitbucket;
const ls = listDirectoryFiles;
const dlSingle = downloadSingleFile;
const dlDir = downloadDirectoryFiles;
const dlAgent = downloadAgentFiles;
const exec = executeAction;
const execAll = executeAllActions;
const valTok = validateRequiredTokens;
const list = listAgents;
const install = installAgent;
const installAll = installAllMatchingAgents;

module.exports = {
  // New descriptive names
  loadConfig,
  validateToken,
  ensureDirectoryExists,
  isGitRepo,
  isFileTrackedInGit,
  restoreFileIfUnchangedFromHead,
  getTemplateVariables,
  substituteVariables,
  isTargetMatch,
  isToolMatch,
  isFileProtected,
  shouldWriteFile,
  mergeAgentsMd,
  escapeRegExp,
  makeBitbucketRequest,
  downloadFileFromBitbucket,
  listDirectoryFiles,
  downloadSingleFile,
  downloadDirectoryFiles,
  downloadAgentFiles,
  executeAction,
  executeNpmInstall,
  executeCreateConfig,
  executeEnsureGitignore,
  executeCopyFile,
  executeMakeExecutable,
  executeRunScript,
  executeAllActions,
  validateRequiredTokens,
  listAgents,
  installAgent,
  installAllMatchingAgents,
  interactiveInstall,
  installExample,
  installExampleIfNeeded,
  parseTargetFlag,
  parseToolFlag,
  parseExampleFlag,
  main,
  // Backward-compatible aliases
  ensureDir,
  getVars,
  sub,
  dl,
  ls,
  dlSingle,
  dlDir,
  dlAgent,
  exec,
  execAll,
  valTok,
  list,
  install,
  installAll,
  // Constants
  BITBUCKET_BASE_URL,
  AI_COMMON_PROJECT,
  AI_COMMON_REPO,
  PROJECT_ROOT,
  CONFIG_PATH,
  // Mutable flags (for testing)
  get FORCE_OVERWRITE() { return FORCE_OVERWRITE; },
  set FORCE_OVERWRITE(v) { FORCE_OVERWRITE = v; },
};
