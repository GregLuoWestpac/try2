const fs = require("fs");
const os = require("os");
const path = require("path");
const mod = require("./install-agent");
const {
  escapeRegExp,
  substituteVariables,
  isTargetMatch,
  isToolMatch,
  shouldWriteFile,
  isFileProtected,
  mergeAgentsMd,
  parseTargetFlag,
  parseToolFlag,
  parseExampleFlag,
  executeAllActions,
} = mod;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function makeTempFile(content) {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "install-agent-test-"));
  const filePath = path.join(tmpDir, "test-file.md");
  fs.writeFileSync(filePath, content);
  return { filePath, tmpDir };
}

function cleanupTempDir(tmpDir) {
  fs.rmSync(tmpDir, { recursive: true, force: true });
}

// ---------------------------------------------------------------------------
// escapeRegExp
// ---------------------------------------------------------------------------

describe("escapeRegExp", () => {
  test("returns plain string unchanged", () => {
    expect(escapeRegExp("hello")).toBe("hello");
  });

  test("escapes dots", () => {
    expect(escapeRegExp("a.b")).toBe("a\\.b");
  });

  test("escapes all special characters", () => {
    expect(escapeRegExp(".*+?^${}()|[]\\")).toBe(
      "\\.\\*\\+\\?\\^\\$\\{\\}\\(\\)\\|\\[\\]\\\\",
    );
  });

  test("works correctly in a RegExp", () => {
    const pattern = escapeRegExp("price: $10.00 (USD)");
    const re = new RegExp(pattern);
    expect(re.test("price: $10.00 (USD)")).toBe(true);
    expect(re.test("price: X10X00 (USD)")).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// substituteVariables
// ---------------------------------------------------------------------------

describe("substituteVariables", () => {
  test("replaces a single variable", () => {
    expect(substituteVariables("Hello ${NAME}!", { NAME: "World" })).toBe(
      "Hello World!",
    );
  });

  test("replaces multiple occurrences", () => {
    expect(substituteVariables("${X} and ${X}", { X: "A" })).toBe("A and A");
  });

  test("replaces multiple different variables", () => {
    expect(substituteVariables("${A}-${B}", { A: "1", B: "2" })).toBe("1-2");
  });

  test("leaves unknown variables untouched", () => {
    expect(
      substituteVariables("${KNOWN} ${UNKNOWN}", { KNOWN: "yes" }),
    ).toBe("yes ${UNKNOWN}");
  });

  test("handles variable names with regex-special chars", () => {
    expect(substituteVariables("${MY.VAR}", { "MY.VAR": "value" })).toBe(
      "value",
    );
  });

  test("handles empty variables object", () => {
    expect(substituteVariables("${X}", {})).toBe("${X}");
  });
});

// ---------------------------------------------------------------------------
// isTargetMatch
// ---------------------------------------------------------------------------

describe("isTargetMatch", () => {
  test("generic target always matches", () => {
    expect(isTargetMatch(["generic"], "mfe")).toBe(true);
  });

  test("'all' target always matches (backward compat)", () => {
    expect(isTargetMatch(["all"], "spa")).toBe(true);
  });

  test("null targets default to generic (matches anything)", () => {
    expect(isTargetMatch(null, "api")).toBe(true);
  });

  test("undefined targets default to generic", () => {
    expect(isTargetMatch(undefined, "mfe")).toBe(true);
  });

  test("null activeTarget defaults to generic", () => {
    expect(isTargetMatch(["generic"], null)).toBe(true);
  });

  test("specific target matches same target", () => {
    expect(isTargetMatch(["mfe"], "mfe")).toBe(true);
  });

  test("specific target does not match different target", () => {
    expect(isTargetMatch(["mfe"], "api")).toBe(false);
  });

  test("matching is case-insensitive", () => {
    expect(isTargetMatch(["MFE"], "mfe")).toBe(true);
  });

  test("multi-target matches if any match", () => {
    expect(isTargetMatch(["mfe", "spa"], "spa")).toBe(true);
  });

  test("multi-target does not match if none match", () => {
    expect(isTargetMatch(["mfe", "spa"], "api")).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// isToolMatch
// ---------------------------------------------------------------------------

describe("isToolMatch", () => {
  test("'both' filter matches any tool", () => {
    expect(isToolMatch("copilot", "both")).toBe(true);
    expect(isToolMatch("amp", "both")).toBe(true);
  });

  test("item tool 'both' matches any filter", () => {
    expect(isToolMatch("both", "copilot")).toBe(true);
    expect(isToolMatch("both", "amp")).toBe(true);
  });

  test("exact match returns true", () => {
    expect(isToolMatch("copilot", "copilot")).toBe(true);
    expect(isToolMatch("amp", "amp")).toBe(true);
  });

  test("mismatch returns false", () => {
    expect(isToolMatch("copilot", "amp")).toBe(false);
    expect(isToolMatch("amp", "copilot")).toBe(false);
  });

  test("null item tool defaults to copilot", () => {
    expect(isToolMatch(null, "copilot")).toBe(true);
    expect(isToolMatch(null, "amp")).toBe(false);
  });

  test("matching is case-insensitive", () => {
    expect(isToolMatch("Copilot", "copilot")).toBe(true);
  });
});

// ---------------------------------------------------------------------------
// mergeAgentsMd
// ---------------------------------------------------------------------------

describe("mergeAgentsMd", () => {
  test("wraps content when no existing file", () => {
    const result = mergeAgentsMd(null, "new content");
    expect(result).toContain("<!-- AI-COMMON:START -->");
    expect(result).toContain("new content");
    expect(result).toContain("<!-- AI-COMMON:END -->");
  });

  test("replaces existing marked block", () => {
    const existing =
      "# My AGENTS.md\n\n<!-- AI-COMMON:START -->\nold stuff\n<!-- AI-COMMON:END -->\n";
    const result = mergeAgentsMd(existing, "updated");
    expect(result).toContain("# My AGENTS.md");
    expect(result).toContain("updated");
    expect(result).not.toContain("old stuff");
  });

  test("appends when file exists without markers", () => {
    const existing = "# Existing content";
    const result = mergeAgentsMd(existing, "new block");
    expect(result).toMatch(/^# Existing content/);
    expect(result).toContain("<!-- AI-COMMON:START -->");
    expect(result).toContain("new block");
  });

  test("is idempotent — running twice produces same result", () => {
    const first = mergeAgentsMd(null, "content A");
    const second = mergeAgentsMd(first, "content A");
    expect(first).toBe(second);
  });

  test("preserves content outside markers on update", () => {
    const existing =
      "# Header\n\nCustom text\n\n<!-- AI-COMMON:START -->\nold\n<!-- AI-COMMON:END -->\n\nFooter";
    const result = mergeAgentsMd(existing, "new");
    expect(result).toContain("# Header");
    expect(result).toContain("Custom text");
    expect(result).toContain("Footer");
    expect(result).toContain("new");
    expect(result).not.toContain("old");
  });
});

// ---------------------------------------------------------------------------
// parseTargetFlag
// ---------------------------------------------------------------------------

describe("parseTargetFlag", () => {
  test("returns generic when no flag", () => {
    expect(parseTargetFlag(["--tool=amp"])).toBe("generic");
  });

  test("returns value from flag", () => {
    expect(parseTargetFlag(["--target=mfe"])).toBe("mfe");
  });

  test("returns generic for empty value", () => {
    expect(parseTargetFlag(["--target="])).toBe("generic");
  });
});

// ---------------------------------------------------------------------------
// parseToolFlag
// ---------------------------------------------------------------------------

describe("parseToolFlag", () => {
  test("returns copilot when no flag", () => {
    expect(parseToolFlag([])).toBe("copilot");
  });

  test("returns amp from flag", () => {
    expect(parseToolFlag(["--tool=amp"])).toBe("amp");
  });

  test("returns both from flag", () => {
    expect(parseToolFlag(["--tool=both"])).toBe("both");
  });

  test("normalizes capitalized Amp to lowercase", () => {
    expect(parseToolFlag(["--tool=Amp"])).toBe("amp");
  });

  test("normalizes uppercase BOTH to lowercase", () => {
    expect(parseToolFlag(["--tool=BOTH"])).toBe("both");
  });

  test("normalizes Copilot to lowercase", () => {
    expect(parseToolFlag(["--tool=Copilot"])).toBe("copilot");
  });
});

// ---------------------------------------------------------------------------
// parseExampleFlag
// ---------------------------------------------------------------------------

describe("parseExampleFlag", () => {
  test("returns null when no flag", () => {
    expect(parseExampleFlag([])).toBeNull();
  });

  test("returns example name from flag", () => {
    expect(parseExampleFlag(["--example=test-ets-restassured"])).toBe(
      "test-ets-restassured",
    );
  });

  test("returns null for empty value", () => {
    expect(parseExampleFlag(["--example="])).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// shouldWriteFile
// ---------------------------------------------------------------------------

describe("shouldWriteFile", () => {
  test("writes when file does not exist", () => {
    const tmpDir = fs.mkdtempSync(
      path.join(os.tmpdir(), "install-agent-test-"),
    );
    const filePath = path.join(tmpDir, "nonexistent.md");
    const result = shouldWriteFile(filePath, "new content", false);
    expect(result.skip).toBe(false);
    cleanupTempDir(tmpDir);
  });

  test("writes when file does not exist even if protected", () => {
    const tmpDir = fs.mkdtempSync(
      path.join(os.tmpdir(), "install-agent-test-"),
    );
    const filePath = path.join(tmpDir, "nonexistent.md");
    const result = shouldWriteFile(filePath, "new content", true);
    expect(result.skip).toBe(false);
    cleanupTempDir(tmpDir);
  });

  test("overwrites non-protected files even if content differs", () => {
    const { filePath, tmpDir } = makeTempFile("original content");
    mod.FORCE_OVERWRITE = false;
    const result = shouldWriteFile(filePath, "updated content", false);
    expect(result.skip).toBe(false);
    cleanupTempDir(tmpDir);
  });

  test("skips protected file with up-to-date when content identical", () => {
    const { filePath, tmpDir } = makeTempFile("same content");
    mod.FORCE_OVERWRITE = false;
    const result = shouldWriteFile(filePath, "same content", true);
    expect(result.skip).toBe(true);
    expect(result.reason).toContain("up-to-date");
    cleanupTempDir(tmpDir);
  });

  test("skips protected file with modified content", () => {
    const { filePath, tmpDir } = makeTempFile("user edited content");
    mod.FORCE_OVERWRITE = false;
    const result = shouldWriteFile(filePath, "original template", true);
    expect(result.skip).toBe(true);
    expect(result.reason).toContain("protected");
    expect(result.reason).toContain("--force");
    cleanupTempDir(tmpDir);
  });

  test("--force overwrites protected file with modified content", () => {
    const { filePath, tmpDir } = makeTempFile("user edited content");
    mod.FORCE_OVERWRITE = true;
    const result = shouldWriteFile(filePath, "original template", true);
    expect(result.skip).toBe(false);
    mod.FORCE_OVERWRITE = false;
    cleanupTempDir(tmpDir);
  });
});

// ---------------------------------------------------------------------------
// FORCE_OVERWRITE flag
// ---------------------------------------------------------------------------

describe("FORCE_OVERWRITE flag", () => {
  afterEach(() => {
    mod.FORCE_OVERWRITE = false;
  });

  test("defaults to false", () => {
    mod.FORCE_OVERWRITE = false;
    expect(mod.FORCE_OVERWRITE).toBe(false);
  });

  test("can be toggled via setter", () => {
    mod.FORCE_OVERWRITE = true;
    expect(mod.FORCE_OVERWRITE).toBe(true);
    mod.FORCE_OVERWRITE = false;
    expect(mod.FORCE_OVERWRITE).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// executeAllActions — tool filtering
// ---------------------------------------------------------------------------

describe("executeAllActions tool filtering", () => {
  // Build a minimal agent whose actions use ensure-gitignore (low side-effects
  // when the entries already exist) with different tool annotations.
  const makeAgent = (actions) => ({ name: "test-agent", actions });

  // Spy on console.log to capture skip messages
  let logSpy;
  beforeEach(() => {
    logSpy = jest.spyOn(console, "log").mockImplementation(() => {});
  });
  afterEach(() => {
    logSpy.mockRestore();
  });

  test("skips action when tool does not match filter", () => {
    const agent = makeAgent([
      {
        type: "ensure-gitignore",
        entries: ["# test-tool-filter"],
        description: "copilot-only action",
        tool: "copilot",
        target: ["generic"],
      },
    ]);
    const result = executeAllActions(agent, {}, "generic", "amp");
    expect(result.ok).toBe(0);
    expect(result.fail).toBe(0);
    const skipMessages = logSpy.mock.calls
      .map((c) => c[0])
      .filter((msg) => typeof msg === "string" && msg.includes("Skipped (tool)"));
    expect(skipMessages.length).toBe(1);
    expect(skipMessages[0]).toContain("copilot-only action");
  });

  test("runs action when tool matches filter", () => {
    const agent = makeAgent([
      {
        type: "ensure-gitignore",
        entries: ["# test-tool-match"],
        description: "copilot action",
        tool: "copilot",
        target: ["generic"],
      },
    ]);
    const result = executeAllActions(agent, {}, "generic", "copilot");
    expect(result.ok).toBe(1);
    expect(result.fail).toBe(0);
  });

  test("runs action with tool 'both' regardless of filter", () => {
    const agent = makeAgent([
      {
        type: "ensure-gitignore",
        entries: ["# test-both-tool"],
        description: "both-tool action",
        tool: "both",
        target: ["generic"],
      },
    ]);
    const result = executeAllActions(agent, {}, "generic", "amp");
    expect(result.ok).toBe(1);
    expect(result.fail).toBe(0);
  });

  test("runs all actions when toolFilter is null (backward compat)", () => {
    const agent = makeAgent([
      {
        type: "ensure-gitignore",
        entries: ["# test-null-filter"],
        description: "copilot action",
        tool: "copilot",
        target: ["generic"],
      },
    ]);
    const result = executeAllActions(agent, {}, "generic", null);
    expect(result.ok).toBe(1);
    expect(result.fail).toBe(0);
  });

  test("runs all actions when toolFilter is undefined (backward compat)", () => {
    const agent = makeAgent([
      {
        type: "ensure-gitignore",
        entries: ["# test-undef-filter"],
        description: "copilot action",
        tool: "copilot",
        target: ["generic"],
      },
    ]);
    const result = executeAllActions(agent, {}, "generic", undefined);
    expect(result.ok).toBe(1);
    expect(result.fail).toBe(0);
  });

  test("filters by both target and tool together", () => {
    const agent = makeAgent([
      {
        type: "ensure-gitignore",
        entries: ["# test-both-filters-1"],
        description: "mfe copilot action",
        tool: "copilot",
        target: ["mfe"],
      },
      {
        type: "ensure-gitignore",
        entries: ["# test-both-filters-2"],
        description: "generic amp action",
        tool: "amp",
        target: ["generic"],
      },
      {
        type: "ensure-gitignore",
        entries: ["# test-both-filters-3"],
        description: "generic copilot action",
        tool: "copilot",
        target: ["generic"],
      },
    ]);
    // target=api, tool=copilot → only #3 matches (generic target, copilot tool)
    const result = executeAllActions(agent, {}, "api", "copilot");
    expect(result.ok).toBe(1);
    expect(result.fail).toBe(0);
    const skipMessages = logSpy.mock.calls
      .map((c) => c[0])
      .filter((msg) => typeof msg === "string" && msg.includes("Skipped"));
    expect(skipMessages.length).toBe(2);
  });

  test("returns zero counts when no actions", () => {
    const agent = makeAgent([]);
    const result = executeAllActions(agent, {}, "generic", "copilot");
    expect(result.ok).toBe(0);
    expect(result.fail).toBe(0);
  });

  test("returns zero counts when actions is undefined", () => {
    const agent = { name: "empty-agent" };
    const result = executeAllActions(agent, {}, "generic", "copilot");
    expect(result.ok).toBe(0);
    expect(result.fail).toBe(0);
  });
});

// ---------------------------------------------------------------------------
// Config: .env.example action has tool scoping
// ---------------------------------------------------------------------------

describe("Config: .env.example tool scoping", () => {
  const configPath = path.join(__dirname, "ai-common-config.json");
  const config = JSON.parse(fs.readFileSync(configPath, "utf8"));
  const foundation = config.agents.foundation;

  test("foundation .env.example action has tool set to copilot", () => {
    const envAction = foundation.actions.find(
      (a) => a.destination === ".github/.env.example",
    );
    expect(envAction).toBeTruthy();
    expect(envAction.tool).toBe("copilot");
  });

  test(".env.example action would be skipped for amp-only install", () => {
    const envAction = foundation.actions.find(
      (a) => a.destination === ".github/.env.example",
    );
    expect(isToolMatch(envAction.tool, "amp")).toBe(false);
  });

  test(".env.example action matches copilot install", () => {
    const envAction = foundation.actions.find(
      (a) => a.destination === ".github/.env.example",
    );
    expect(isToolMatch(envAction.tool, "copilot")).toBe(true);
  });

  test(".env.example action matches 'both' install", () => {
    const envAction = foundation.actions.find(
      (a) => a.destination === ".github/.env.example",
    );
    expect(isToolMatch(envAction.tool, "both")).toBe(true);
  });
});

// ---------------------------------------------------------------------------
// isFileProtected
// ---------------------------------------------------------------------------

describe("isFileProtected", () => {
  test("returns false when no protected flag and no protectedPaths", () => {
    const mapping = { source: "src", destination: "dest" };
    expect(isFileProtected(mapping, "skills/some-skill.md")).toBe(false);
  });

  test("returns true when mapping has protected: true", () => {
    const mapping = { source: "src", destination: "dest", protected: true };
    expect(isFileProtected(mapping, "skills/some-skill.md")).toBe(true);
  });

  test("returns true when relativePath matches a protectedPaths prefix", () => {
    const mapping = {
      source: "examples/test/copilot",
      destination: ".github",
      protectedPaths: ["instructions/"],
    };
    expect(
      isFileProtected(mapping, "instructions/repo_overview.instructions.md"),
    ).toBe(true);
  });

  test("returns false when relativePath does not match protectedPaths", () => {
    const mapping = {
      source: "examples/test/copilot",
      destination: ".github",
      protectedPaths: ["instructions/"],
    };
    expect(
      isFileProtected(mapping, "skills/ui-test-planning.md"),
    ).toBe(false);
  });

  test("supports multiple protectedPaths prefixes", () => {
    const mapping = {
      source: "src",
      destination: "dest",
      protectedPaths: ["instructions/", "config/"],
    };
    expect(isFileProtected(mapping, "config/settings.json")).toBe(true);
    expect(isFileProtected(mapping, "skills/something.md")).toBe(false);
  });

  test("protected flag takes precedence over protectedPaths", () => {
    const mapping = {
      source: "src",
      destination: "dest",
      protected: true,
      protectedPaths: [],
    };
    expect(isFileProtected(mapping, "anything.md")).toBe(true);
  });
});
