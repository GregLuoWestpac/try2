# NodeMCP - Model Context Protocol Server Framework

A modular MCP (Model Context Protocol) server framework for Node.js with a pluggable provider architecture. Compatible with GitHub Copilot, Claude Code, and any MCP-compliant client.

## Features

- **MCP 2025-06-18 Protocol Compliant** — Full support for the latest MCP specification
- **Multiple Transports** — STDIO (for local use) and Streamable HTTP (for remote use)
- **Provider Architecture** — Modular provider system; each provider is a self-contained package under `tools/mcps/`
- **Session Management** — Stateful and stateless provider support
- **Authentication** — Bearer tokens, API keys, OAuth 2.1 support for HTTP transport
- **Tool Discovery** — Dynamic tool listing and capability negotiation

### Available Providers

| Provider | Description | Docs |
|----------|-------------|------|
| **docsearch** | Reverse HyDE document search | [README](../mcps/docsearch/README.md) |
| **splunk** | Splunk search, monitoring, and log analysis | [README](../mcps/splunk/README.md) |
| **browser-automation** | Browser automation via Edge/Chrome | [README](../mcps/browser-automation/README.md) |

## Installation

```bash
cd tools/nodemcp
npm install
```

Providers manage their own dependencies — install each provider you need:

```bash
cd tools/mcps/docsearch && npm install
cd tools/mcps/splunk && npm install         # only if using Splunk
```

## Usage

### Run with all providers

```bash
# STDIO transport (default, for local AI clients)
node cli.js --all

# Or simply (defaults to --all)
node cli.js
```

### Run with specific providers

```bash
# Single provider by name (looks up from tools/mcps/)
node cli.js --layers splunk

# Multiple providers
node cli.js --layers splunk,docsearch

# Load a provider by path
node cli.js --provider ../mcps/docsearch
```

### Transport options

```bash
# STDIO transport (default) — for GitHub Copilot, Claude Code
node cli.js --transport stdio

# HTTP transport — for remote connections
node cli.js --transport http --port 3100

# HTTP with authentication required
node cli.js --transport http --port 3100 --require-auth
```

### CLI Options

| Option | Description |
|--------|-------------|
| `--all` | Load all available providers (default if no `--layers` or `--provider` specified) |
| `--layers <providers>` | Comma-separated list of provider names to load (e.g. `splunk,docsearch`) |
| `--provider <path>`, `-p` | Load a provider from a specific path (can be repeated) |
| `--transport <type>` | Transport type: `stdio` or `http` (default: `stdio`) |
| `--port <number>` | HTTP port (default: `3100`) |
| `--host <address>` | HTTP host (default: `127.0.0.1`) |
| `--require-auth` | Require Bearer token authentication for HTTP transport |
| `--verbose`, `-v` | Enable verbose logging |
| `--help`, `-h` | Show help message |

## Configuration for AI Clients

### GitHub Copilot (VS Code)

Add to your VS Code `settings.json` (or workspace `.vscode/settings.json`):

```json
{
  "github.copilot.chat.mcpServers": {
    "nodemcp": {
      "command": "node",
      "args": ["path/to/ai-common/tools/nodemcp/cli.js", "--layers", "docsearch"]
    }
  }
}
```

### Amp

Add to `~/.config/amp/settings.json`:

```json
{
  "amp.mcpServers": {
    "nodemcp": {
      "command": "node",
      "args": ["path/to/ai-common/tools/nodemcp/cli.js", "--all"]
    }
  }
}
```

If you are behind a corporate proxy, also add:

```json
{
  "amp.proxy": "http://your-proxy-host:port"
}
```

### Claude Code

Add to your Claude configuration:

```json
{
  "mcpServers": {
    "nodemcp": {
      "command": "node",
      "args": ["path/to/ai-common/tools/nodemcp/cli.js", "--all"]
    }
  }
}
```

### Remote HTTP Server

Start the server with HTTP transport, then point any MCP client at the URL:

```bash
node cli.js --transport http --port 3100 --require-auth
# → http://127.0.0.1:3100/mcp
```

## Provider Development

Providers live under `tools/mcps/<name>/` and extend `BaseProvider` from the NodeMCP core.

### Provider Structure

```
tools/mcps/<provider-name>/
  index.js          # Provider entry point — extends BaseProvider
  package.json      # Provider metadata and dependencies
  README.md         # Provider-specific documentation
```

### Creating a Provider

1. Create a directory under `tools/mcps/` with an `index.js` and `package.json`.
2. Extend `BaseProvider` and register tools in `initialize()`:

```javascript
const BaseProvider = require('../../nodemcp/core/BaseProvider');

class MyProvider extends BaseProvider {
  async initialize() {
    this.registerTool({
      name: 'my_tool',
      description: 'Does something useful',
      inputSchema: {
        type: 'object',
        properties: {
          query: this.stringProp('The search query', { required: true }),
        },
      },
      handler: async (params, context) => {
        return { content: [{ type: 'text', text: `Result for: ${params.query}` }] };
      },
    });
  }
}

module.exports = MyProvider;
```

3. Run it: `node cli.js --provider ../mcps/my-provider -v`

### BaseProvider Helpers

| Method | Description |
|--------|-------------|
| `registerTool(tool)` | Register an MCP tool with name, description, inputSchema, handler |
| `registerResource(resource)` | Register an MCP resource (uri/uriTemplate, handler) |
| `registerPrompt(prompt)` | Register an MCP prompt template |
| `setStateful(bool)` | Mark provider as stateful (maintains session state) |
| `stringProp(desc)` | Helper to create a string property schema |
| `numberProp(desc)` | Helper to create a number property schema |
| `booleanProp(desc)` | Helper to create a boolean property schema |
| `arrayProp(desc, items)` | Helper to create an array property schema |
| `enumProp(desc, values)` | Helper to create an enum property schema |

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                    AI Client                         │
│        (GitHub Copilot, Claude Code, etc.)          │
└─────────────────────┬───────────────────────────────┘
                      │ MCP Protocol (JSON-RPC 2.0)
                      │ STDIO or HTTP
┌─────────────────────▼───────────────────────────────┐
│                  NodeMCP Core                        │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  │
│  │  Transport  │  │   Session   │  │   Router    │  │
│  │   Layer     │  │  Manager    │  │             │  │
│  └─────────────┘  └─────────────┘  └─────────────┘  │
│  ┌─────────────────────────────────────────────────┐│
│  │              Provider Manager                    ││
│  └─────────────────────────────────────────────────┘│
└─────────────────────┬───────────────────────────────┘
                      │
    ┌─────────────────┼─────────────────┐
    │                 │                 │
┌───▼────┐      ┌────▼────┐      ┌────▼────┐
│DocSearch│     │ Splunk  │     │Browser  │
│Provider │     │Provider │     │Auto     │
└────────┘      └─────────┘     └─────────┘
```

## License

MIT
