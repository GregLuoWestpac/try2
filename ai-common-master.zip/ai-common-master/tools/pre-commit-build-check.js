#!/usr/bin/env node
// Pre-commit hook: ensures committed copilot/, amp/, and ai-common-config.json
// match what build.js would generate. Prevents stale generated output.
//
// Install: copy or symlink to .git/hooks/pre-commit
//   node tools/pre-commit-build-check.js

const { execSync } = require('child_process');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

// Only check if staged files include src/, manifest.yaml, or build.js
const staged = execSync('git diff --cached --name-only', { cwd: ROOT, encoding: 'utf8' });
const needsCheck = staged.split('\n').some(f =>
  f.startsWith('src/') ||
  f === 'manifest.yaml' ||
  f === 'tools/build.js'
);

if (!needsCheck) {
  process.exit(0);
}

// Run the build
console.log('pre-commit: source files changed, verifying build output...');
execSync('node tools/build.js', { cwd: ROOT, stdio: 'inherit' });

// Check if build produced unstaged changes in generated outputs
const dirty = execSync(
  'git diff --name-only -- copilot/ amp/ tools/install-agents/ai-common-config.json',
  { cwd: ROOT, encoding: 'utf8' }
).trim();

if (dirty) {
  console.error('\n❌ Build output is stale. These files changed after rebuild:');
  console.error(dirty.split('\n').map(f => '  ' + f).join('\n'));
  console.error('\nRun: node tools/build.js');
  console.error('Then stage the updated files and commit again.\n');
  process.exit(1);
}

console.log('pre-commit: build output is up to date ✓');
