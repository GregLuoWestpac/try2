const assert = require('assert');
const fs = require('fs');
const path = require('path');
const {
  transformForCopilot,
  transformForAmp,
  yamlQuote,
  validateSlug,
  buildCopilotAgentFrontmatter,
  buildCopilotSkillFrontmatter,
  buildAmpFrontmatter
} = require('./build');

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (e) {
    failed++;
    console.log(`  ✗ ${name}`);
    console.log(`    ${e.message}`);
  }
}

// ---------------------------------------------------------------------------
// yamlQuote
// ---------------------------------------------------------------------------

console.log('\nyamlQuote:');

test('returns plain string unchanged', () => {
  assert.strictEqual(yamlQuote('hello world'), 'hello world');
});

test('quotes strings with colons', () => {
  assert.strictEqual(yamlQuote('key: value'), '"key: value"');
});

test('quotes strings with hash', () => {
  assert.strictEqual(yamlQuote('before # comment'), '"before # comment"');
});

test('leaves em dash unquoted (valid YAML)', () => {
  assert.strictEqual(yamlQuote('first — second'), 'first — second');
});

test('escapes double quotes inside', () => {
  assert.strictEqual(yamlQuote('say "hello"'), '"say \\"hello\\""');
});

test('leaves plain backslash unquoted (valid YAML)', () => {
  assert.strictEqual(yamlQuote('path\\to'), 'path\\to');
});

test('quotes strings with curly braces', () => {
  assert.strictEqual(yamlQuote('use {var}'), '"use {var}"');
});

test('quotes strings with leading/trailing whitespace', () => {
  assert.strictEqual(yamlQuote(' padded '), '" padded "');
});

test('handles non-string input', () => {
  assert.strictEqual(yamlQuote(42), '42');
});

// ---------------------------------------------------------------------------
// validateSlug
// ---------------------------------------------------------------------------

console.log('\nvalidateSlug:');

test('accepts valid slug', () => {
  validateSlug('my-agent', 'test');
});

test('accepts slug with dots in filename', () => {
  validateSlug('my-agent.v2', 'test');
});

test('rejects empty string', () => {
  assert.throws(() => validateSlug('', 'test'), /non-empty/);
});

test('rejects path traversal with ..', () => {
  assert.throws(() => validateSlug('../etc/passwd', 'test'), /must not contain/);
});

test('rejects absolute path', () => {
  assert.throws(() => validateSlug('/etc/passwd', 'test'), /must not contain/);
});

test('rejects backslash absolute path', () => {
  assert.throws(() => validateSlug('\\windows\\system32', 'test'), /must not contain/);
});

test('rejects non-string', () => {
  assert.throws(() => validateSlug(null, 'test'), /non-empty/);
});

// ---------------------------------------------------------------------------
// transformForCopilot
// ---------------------------------------------------------------------------

console.log('\ntransformForCopilot:');

test('replaces project .env reference', () => {
  const result = transformForCopilot('Read the project `.env` file');
  assert.strictEqual(result, 'Read `.github/.env`');
});

test('strips DELEGATE markers', () => {
  const result = transformForCopilot('Do something <!-- DELEGATE --> here');
  assert.strictEqual(result, 'Do something here');
});

test('strips NEW_SESSION markers', () => {
  const result = transformForCopilot('Start <!-- NEW_SESSION --> fresh');
  assert.strictEqual(result, 'Start fresh');
});

test('preserves content without markers', () => {
  const input = 'Plain markdown content\n\nWith paragraphs.';
  assert.strictEqual(transformForCopilot(input), input);
});

// ---------------------------------------------------------------------------
// transformForAmp
// ---------------------------------------------------------------------------

console.log('\ntransformForAmp:');

test('replaces DELEGATE marker with Task tool text', () => {
  const result = transformForAmp('Assign work <!-- DELEGATE --> to others');
  assert.ok(result.includes('`Task` tool'), `Expected Task tool mention, got: ${result}`);
});

test('replaces NEW_SESSION marker with handoff text', () => {
  const result = transformForAmp('Continue <!-- NEW_SESSION --> later');
  assert.ok(result.includes('`handoff` tool'), `Expected handoff mention, got: ${result}`);
});

test('replaces subagent with sub-skill', () => {
  const result = transformForAmp('Deploy the subagent');
  assert.strictEqual(result, 'Deploy the sub-skill');
});

test('replaces sub-agent with sub-skill', () => {
  const result = transformForAmp('Use a sub-agent here');
  assert.strictEqual(result, 'Use a sub-skill here');
});

test('replaces subagents (plural) with sub-skills', () => {
  const result = transformForAmp('Multiple subagents running');
  assert.strictEqual(result, 'Multiple sub-skills running');
});

test('replaces Sub-Agents (capitalized) with Sub-Skills', () => {
  const result = transformForAmp('The Sub-Agents are ready');
  assert.strictEqual(result, 'The Sub-Skills are ready');
});

test('replaces specialist agents with specialist skills', () => {
  const result = transformForAmp('Use specialist agents for this');
  assert.strictEqual(result, 'Use specialist skills for this');
});

test('replaces specialized agents with specialized skills', () => {
  const result = transformForAmp('The specialized agents handle');
  assert.strictEqual(result, 'The specialized skills handle');
});

test('replaces Agent heading with Skill', () => {
  const result = transformForAmp('# My Agent');
  assert.strictEqual(result, '# My Skill');
});

test('replaces ## Agent heading with Skill', () => {
  const result = transformForAmp('## Config Agent');
  assert.strictEqual(result, '## Config Skill');
});

test('replaces "You are a ... agent that" pattern', () => {
  const result = transformForAmp('You are a testing agent that runs tests');
  assert.strictEqual(result, 'You are a testing skill that runs tests');
});

test('replaces "This agent" with "This skill"', () => {
  const result = transformForAmp('This agent handles requests');
  assert.strictEqual(result, 'This skill handles requests');
});

test('replaces "this agent" with "this skill"', () => {
  const result = transformForAmp('Pass to this agent');
  assert.strictEqual(result, 'Pass to this skill');
});

test('replaces "This Agent" with "This Skill"', () => {
  const result = transformForAmp('This Agent is responsible');
  assert.strictEqual(result, 'This Skill is responsible');
});

test('replaces .github/instructions/ with .agents/instructions/', () => {
  const result = transformForAmp('See .github/instructions/foo.md');
  assert.strictEqual(result, 'See .agents/instructions/foo.md');
});

test('replaces .github/.env references', () => {
  const result = transformForAmp('Set in `.github/.env` file');
  assert.strictEqual(result, 'Set in the project `.env` file file');
});

test('strips "via Copilot chat"', () => {
  const result = transformForAmp('Ask via Copilot chat');
  assert.strictEqual(result, 'Ask');
});

test('replaces | Agent | with | Skill |', () => {
  const result = transformForAmp('| Agent | Description |');
  assert.strictEqual(result, '| Skill | Description |');
});

test('preserves plain content', () => {
  const input = 'Just some regular markdown content.';
  assert.strictEqual(transformForAmp(input), input);
});

// ---------------------------------------------------------------------------
// buildCopilotAgentFrontmatter
// ---------------------------------------------------------------------------

console.log('\nbuildCopilotAgentFrontmatter:');

test('builds basic agent frontmatter', () => {
  const fm = buildCopilotAgentFrontmatter({ name: 'Test', description: 'A test agent' });
  assert.ok(fm.startsWith('---\n'));
  assert.ok(fm.endsWith('---\n'));
  assert.ok(fm.includes('name: Test'));
  assert.ok(fm.includes('description: A test agent'));
});

test('includes tools array', () => {
  const fm = buildCopilotAgentFrontmatter({ name: 'T', description: 'D', tools: ['read', 'edit'] });
  assert.ok(fm.includes("tools: ['read', 'edit']"));
});

test('includes model', () => {
  const fm = buildCopilotAgentFrontmatter({ name: 'T', description: 'D', model: 'gpt-4' });
  assert.ok(fm.includes('model: gpt-4'));
});

test('quotes description with colons', () => {
  const fm = buildCopilotAgentFrontmatter({ name: 'T', description: 'Role: analysis' });
  assert.ok(fm.includes('description: "Role: analysis"'));
});

// ---------------------------------------------------------------------------
// buildCopilotSkillFrontmatter
// ---------------------------------------------------------------------------

console.log('\nbuildCopilotSkillFrontmatter:');

test('builds basic skill frontmatter', () => {
  const fm = buildCopilotSkillFrontmatter({ description: 'Fetches data from APIs' });
  assert.ok(fm.startsWith('---\n'));
  assert.ok(fm.endsWith('---\n'));
  assert.ok(fm.includes('description: Fetches data from APIs'));
});

test('quotes description with special chars', () => {
  const fm = buildCopilotSkillFrontmatter({ description: 'Role: fetch & parse' });
  assert.ok(fm.includes('description: "Role: fetch & parse"'));
});

test('contains only description field', () => {
  const fm = buildCopilotSkillFrontmatter({ description: 'simple' });
  assert.strictEqual(fm, '---\ndescription: simple\n---\n');
});

// ---------------------------------------------------------------------------
// buildAmpFrontmatter
// ---------------------------------------------------------------------------

console.log('\nbuildAmpFrontmatter:');

test('builds basic amp frontmatter', () => {
  const fm = buildAmpFrontmatter({ name: 'test-skill', description: 'A test skill' });
  assert.ok(fm.startsWith('---\n'));
  assert.ok(fm.endsWith('---\n'));
  assert.ok(fm.includes('name: test-skill'));
  assert.ok(fm.includes('description: A test skill'));
});

test('quotes name with special chars', () => {
  const fm = buildAmpFrontmatter({ name: 'test: skill', description: 'desc' });
  assert.ok(fm.includes('name: "test: skill"'));
});

// ---------------------------------------------------------------------------
// Generated installer config (ai-common-config.json)
// ---------------------------------------------------------------------------

console.log('\nGenerated installer config:');

const configPath = path.join(__dirname, 'install-agents', 'ai-common-config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

test('instruction files have protected flag', () => {
  const foundation = config.agents.foundation;
  assert.ok(foundation, 'foundation package must exist');
  const instructionFiles = foundation.files.filter(f =>
    f.destination.includes('/instructions/')
  );
  assert.ok(instructionFiles.length > 0, 'must have instruction files');
  for (const f of instructionFiles) {
    assert.strictEqual(f.protected, true,
      `${f.destination} should be protected`);
  }
});

test('agent files do not have protected flag', () => {
  for (const [, pkg] of Object.entries(config.agents)) {
    const agentFiles = pkg.files.filter(f =>
      (f.destination.includes('/agents/') || f.destination.includes('/skills/')) &&
      !f.destination.includes('/instructions/')
    );
    for (const f of agentFiles) {
      assert.ok(!f.protected,
        `${f.destination} should not be protected`);
    }
  }
});

test('prompt files do not have protected flag', () => {
  for (const [, pkg] of Object.entries(config.agents)) {
    const promptFiles = pkg.files.filter(f =>
      f.destination.includes('/prompts/')
    );
    for (const f of promptFiles) {
      assert.ok(!f.protected,
        `${f.destination} should not be protected`);
    }
  }
});

// ---------------------------------------------------------------------------
// yamlQuote — additional edge cases
// ---------------------------------------------------------------------------

console.log('\nyamlQuote (edge cases):');

test('quotes empty string', () => {
  assert.strictEqual(yamlQuote(''), '');
});

test('quotes string with ampersand', () => {
  assert.strictEqual(yamlQuote('A & B'), '"A & B"');
});

test('quotes string with square brackets', () => {
  assert.strictEqual(yamlQuote('[item]'), '"[item]"');
});

test('quotes string with exclamation mark', () => {
  assert.strictEqual(yamlQuote('alert!'), '"alert!"');
});

test('handles string with both colon and quotes', () => {
  const result = yamlQuote('key: "value"');
  assert.ok(result.startsWith('"'));
  assert.ok(result.endsWith('"'));
  assert.ok(result.includes('\\"value\\"'));
});

test('handles string with at sign', () => {
  assert.strictEqual(yamlQuote('@mention'), '"@mention"');
});

test('handles string with backtick', () => {
  assert.strictEqual(yamlQuote('use `code`'), '"use `code`"');
});

// ---------------------------------------------------------------------------
// validateSlug — additional edge cases
// ---------------------------------------------------------------------------

console.log('\nvalidateSlug (edge cases):');

test('accepts slug with hyphens and numbers', () => {
  validateSlug('agent-v2-test', 'test');
});

test('rejects slug with .. in middle', () => {
  assert.throws(() => validateSlug('a/../b', 'test'), /must not contain/);
});

test('rejects slug starting with forward slash', () => {
  assert.throws(() => validateSlug('/start', 'test'), /must not contain/);
});

test('rejects number input', () => {
  assert.throws(() => validateSlug(123, 'test'), /non-empty/);
});

test('rejects undefined slug', () => {
  assert.throws(() => validateSlug(undefined, 'test'), /non-empty/);
});

// ---------------------------------------------------------------------------
// buildCopilotAgentFrontmatter — handoffs branch
// ---------------------------------------------------------------------------

console.log('\nbuildCopilotAgentFrontmatter (handoffs):');

test('includes handoffs array', () => {
  const fm = buildCopilotAgentFrontmatter({
    name: 'T', description: 'D',
    handoffs: [{ label: 'Go', agent: 'other-agent', prompt: 'Help', send: 'context' }]
  });
  assert.ok(fm.includes('handoffs:'));
  assert.ok(fm.includes('  - label: Go'));
  assert.ok(fm.includes('    agent: other-agent'));
  assert.ok(fm.includes('    prompt: Help'));
  assert.ok(fm.includes('    send: context'));
});

test('handoffs with special chars are quoted', () => {
  const fm = buildCopilotAgentFrontmatter({
    name: 'T', description: 'D',
    handoffs: [{ label: 'Go: now', agent: 'a', prompt: 'p', send: 's' }]
  });
  assert.ok(fm.includes('label: "Go: now"'));
});

test('multiple handoffs produce multiple entries', () => {
  const fm = buildCopilotAgentFrontmatter({
    name: 'T', description: 'D',
    handoffs: [
      { label: 'A', agent: 'a1', prompt: 'p1', send: 's1' },
      { label: 'B', agent: 'a2', prompt: 'p2', send: 's2' }
    ]
  });
  assert.ok(fm.includes('  - label: A'));
  assert.ok(fm.includes('  - label: B'));
});

test('empty tools array is included', () => {
  const fm = buildCopilotAgentFrontmatter({ name: 'T', description: 'D', tools: [] });
  assert.ok(fm.includes('tools: []'));
});

// ---------------------------------------------------------------------------
// transformForAmp — additional edge cases
// ---------------------------------------------------------------------------

console.log('\ntransformForAmp (edge cases):');

test('replaces downstream agents with downstream skills', () => {
  assert.strictEqual(transformForAmp('downstream agents'), 'downstream skills');
});

test('replaces the calling agent with the calling skill', () => {
  assert.strictEqual(transformForAmp('the calling agent'), 'the calling skill');
});

test('replaces in agent mode with in skill mode', () => {
  assert.strictEqual(transformForAmp('in agent mode'), 'in skill mode');
});

test('replaces appropriate agent with appropriate skill', () => {
  assert.strictEqual(transformForAmp('appropriate agent'), 'appropriate skill');
});

test('replaces vision capabilities text', () => {
  const input = 'Claude Opus 4.5 in GitHub Copilot does not have vision capabilities. Images are downloaded for manual review only.';
  const result = transformForAmp(input);
  assert.strictEqual(result, 'Images are downloaded for manual review only.');
});

test('replaces DELEGATE marker with delegation text', () => {
  const result = transformForAmp('before <!-- DELEGATE --> after');
  assert.ok(result.includes('`Task` tool'));
  assert.ok(result.includes('`handoff` tool'));
  assert.ok(result.includes('before'));
  assert.ok(result.includes('after'));
});

test('replaces the planning agent (case-insensitive)', () => {
  assert.ok(transformForAmp('The Planning Agent').includes('planning skill'));
  assert.ok(transformForAmp('the planning agent').includes('planning skill'));
});

test('replaces each agent with each skill', () => {
  assert.strictEqual(transformForAmp('Each agent does'), 'Each skill does');
  assert.strictEqual(transformForAmp('each agent, then'), 'each skill, then');
});

// ---------------------------------------------------------------------------
// transformForCopilot — additional edge cases
// ---------------------------------------------------------------------------

console.log('\ntransformForCopilot (edge cases):');

test('strips multiple DELEGATE markers', () => {
  const result = transformForCopilot('a <!-- DELEGATE --> b <!-- DELEGATE --> c');
  assert.strictEqual(result, 'a b c');
});

test('strips multiple NEW_SESSION markers', () => {
  const result = transformForCopilot('a <!-- NEW_SESSION --> b <!-- NEW_SESSION --> c');
  assert.strictEqual(result, 'a b c');
});

test('replaces .env reference mid-sentence', () => {
  const result = transformForCopilot('Set up the project `.env` file first');
  assert.strictEqual(result, 'Set up `.github/.env` first');
});

// ---------------------------------------------------------------------------
// Summary
// ---------------------------------------------------------------------------

console.log(`\n${passed + failed} tests: ${passed} passed, ${failed} failed`);
process.exit(failed > 0 ? 1 : 0);
