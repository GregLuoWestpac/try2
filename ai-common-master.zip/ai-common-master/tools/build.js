const fs = require('node:fs');
const path = require('node:path');

const DRY_RUN = process.argv.includes('--dry-run');

let yaml;
try {
  yaml = require('js-yaml');
} catch {
  console.error('Missing dependency: js-yaml');
  console.error('Run: npm install js-yaml');
  process.exit(1);
}

// ---------------------------------------------------------------------------
// Paths
// ---------------------------------------------------------------------------

const ROOT = path.resolve(__dirname, '..');
const SRC = path.join(ROOT, 'src');
const COPILOT_OUT = path.join(ROOT, 'copilot');
const AMP_OUT = path.join(ROOT, 'amp');
const MANIFEST_PATH = path.join(ROOT, 'manifest.yaml');

// ---------------------------------------------------------------------------
// Read manifest
// ---------------------------------------------------------------------------

const manifest = yaml.load(fs.readFileSync(MANIFEST_PATH, 'utf8'));

if (!manifest || typeof manifest !== 'object') {
  console.error('Error: manifest.yaml must be a YAML object');
  process.exit(1);
}

// Validate top-level sections are objects (not arrays or scalars)
for (const section of ['agents', 'skills', 'prompts', 'checks', 'instructions']) {
  if (manifest[section] && typeof manifest[section] !== 'object') {
    console.error(`Error: manifest.yaml "${section}" must be an object mapping slugs to configs`);
    process.exit(1);
  }
}

if (manifest.installer && typeof manifest.installer !== 'object') {
  console.error('Error: manifest.yaml "installer" must be an object');
  process.exit(1);
}

// Validate that each entry has a required `src` field
for (const section of ['agents', 'skills', 'prompts', 'checks', 'instructions']) {
  if (!manifest[section]) continue;
  for (const [slug, entry] of Object.entries(manifest[section])) {
    if (!entry || typeof entry !== 'object') {
      console.error(`Error: ${section}.${slug} must be an object`);
      process.exit(1);
    }
    if (!entry.src || typeof entry.src !== 'string') {
      console.error(`Error: ${section}.${slug} is missing required "src" field`);
      process.exit(1);
    }
  }
}

// ---------------------------------------------------------------------------
// Slug validation (prevent path traversal)
// ---------------------------------------------------------------------------

function validateSlug(slug, context) {
  if (typeof slug !== 'string' || slug.length === 0) {
    throw new Error(`Invalid ${context}: slug must be a non-empty string`);
  }
  if (/(?:^[/\\])|(?:\.\.)/.test(slug)) {
    throw new Error(String.raw`Invalid ${context} slug "${slug}": must not contain ".." or start with "/" or "\"`);
  }
}

// ---------------------------------------------------------------------------
// Name → slug lookup maps
// ---------------------------------------------------------------------------

// copilotNameToSlug: maps Copilot display names to slugs for agents AND skills
const copilotNameToSlug = {};

if (manifest.agents) {
  for (const [slug, agent] of Object.entries(manifest.agents)) {
    validateSlug(slug, 'agent');
    const name = (agent.copilot && agent.copilot.name) || agent.displayName;
    if (name) {
      if (copilotNameToSlug[name]) {
        console.warn(`  ⚠ duplicate display name "${name}": slug "${slug}" overwrites "${copilotNameToSlug[name]}"`);
      }
      copilotNameToSlug[name] = slug;
    }
  }
}

if (manifest.skills) {
  for (const [slug, skill] of Object.entries(manifest.skills)) {
    validateSlug(slug, 'skill');
    if (skill.displayName) {
      if (copilotNameToSlug[skill.displayName]) {
        console.warn(`  ⚠ duplicate display name "${skill.displayName}": slug "${slug}" overwrites "${copilotNameToSlug[skill.displayName]}"`);
      }
      copilotNameToSlug[skill.displayName] = slug;
    }
  }
}

// ---------------------------------------------------------------------------
// Frontmatter builders
// ---------------------------------------------------------------------------

// Quote a YAML scalar value if it contains characters that need quoting
function yamlQuote(value) {
  if (typeof value !== 'string') return String(value);
  if (/[:#{}[\],&*?|>!'"%@`]/.test(value) || /(?:^\s)|(?:\s$)/.test(value)) {
    const escaped = value.replaceAll('\\', String.raw`\\`).replaceAll('"', String.raw`\"`);
    return '"' + escaped + '"';
  }
  return value;
}

function buildCopilotAgentFrontmatter(config) {
  let fm = '---\n';
  fm += `name: ${yamlQuote(config.name)}\n`;
  fm += `description: ${yamlQuote(config.description)}\n`;
  if (config.tools) {
    const toolsList = config.tools.map(t => "'" + t + "'").join(', ');
    fm += `tools: [${toolsList}]\n`;
  }
  if (config.handoffs) {
    fm += 'handoffs:\n';
    for (const h of config.handoffs) {
      fm += `  - label: ${yamlQuote(h.label)}\n`;
      fm += `    agent: ${yamlQuote(h.agent)}\n`;
      fm += `    prompt: ${yamlQuote(h.prompt)}\n`;
      fm += `    send: ${yamlQuote(h.send)}\n`;
    }
  }
  if (config.model) {
    fm += `model: ${yamlQuote(config.model)}\n`;
  }
  fm += '---\n';
  return fm;
}

function buildCopilotSkillFrontmatter(config) {
  let fm = '---\n';
  fm += `description: ${yamlQuote(config.description)}\n`;
  fm += '---\n';
  return fm;
}

function buildCopilotPromptFrontmatter(config) {
  let fm = '---\n';
  fm += `description: ${yamlQuote(config.description)}\n`;
  fm += `agent: ${yamlQuote(config.agent || config.mode)}\n`;
  fm += '---\n';
  return fm;
}

function buildCopilotInstructionFrontmatter() {
  let fm = '---\n';
  fm += "applyTo: '**'\n";
  fm += '---\n';
  return fm;
}

function buildAmpFrontmatter(config) {
  let fm = '---\n';
  fm += `name: ${yamlQuote(config.name)}\n`;
  fm += `description: ${yamlQuote(config.description)}\n`;
  fm += '---\n';
  return fm;
}

// ---------------------------------------------------------------------------
// Content transforms
// ---------------------------------------------------------------------------

function transformForCopilot(content) {
  // 1. Skill/agent path references — append (see .github/skills/<slug>/SKILL.md)
  //    Match patterns like: the **Name** skill, **Name** skill, invoke the Name Skill
  //    But only if not already followed by "(see"
  for (const [name, slug] of Object.entries(copilotNameToSlug)) {
    // Pattern: the **Name** skill (or agent) — not already followed by (see
    const escapedName = name.replaceAll(/[.*+?^${}()|[\]\\]/g, String.raw`\$&`);

    // Match: **Name** skill/Skill — NOT agent (Copilot agents are referenced by name, no path needed)
    // Don't match if already has "(see" after
    const re = new RegExp(
      String.raw`(\*\*${escapedName}\*\*\s+(?:skill|Skill))(?!\s*\(see)`,
      'g'
    );
    content = content.replaceAll(re, `$1 (see .github/skills/${slug}/SKILL.md)`);

    // Match: invoke the Name Skill — not already followed by (see
    const re2 = new RegExp(
      String.raw`(invoke the ${escapedName} Skill)(?!\s*\(see)`,
      'g'
    );
    content = content.replaceAll(re2, `$1 (see .github/skills/${slug}/SKILL.md)`);
  }

  // 2. Env file paths: "the project `.env` file" → "`.github/.env`"
  content = content.replaceAll('the project `.env` file', '`.github/.env`');

  // 3. Strip build markers (invisible in Copilot output)
  content = content.replaceAll(/ ?<!-- DELEGATE -->/g, '');
  content = content.replaceAll(/ ?<!-- NEW_SESSION -->/g, '');

  return content;
}

function transformForAmp(content) {
  const DELEGATION_TEXT = 'Use the `Task` tool or `handoff` tool for delegation.';

  // Sort names longest-first so "Task Analysis" is matched before "Task",
  // preventing partial-match false replacements.
  const sortedEntries = Object.entries(copilotNameToSlug)
    .sort((a, b) => b[0].length - a[0].length);

  // 1. Agent→skill renaming: "the **Name** agent" → "the **Name** skill (see ...)"
  for (const [name, slug] of sortedEntries) {
    const esc = name.replaceAll(/[.*+?^${}()|[\]\\]/g, String.raw`\$&`);
    content = content.replaceAll(
      new RegExp(String.raw`([Tt]he \*\*${esc}\*\*) agent`, 'g'),
      `$1 skill (see .agents/skills/${slug}/SKILL.md)`
    );
  }

  // 2. Skill path references — append (see .agents/skills/<slug>/SKILL.md)
  for (const [name, slug] of sortedEntries) {
    const esc = name.replaceAll(/[.*+?^${}()|[\]\\]/g, String.raw`\$&`);

    // **Name** skill — not already followed by (see or — see
    content = content.replaceAll(
      new RegExp(String.raw`(\*\*${esc}\*\*\s+(?:skill|Skill))(?!\s*(?:\(see|— see))`, 'g'),
      `$1 (see .agents/skills/${slug}/SKILL.md)`
    );

    // **Name** (`slug`) — add (see ...) after the backtick-slug pattern
    content = content.replaceAll(
      new RegExp(String.raw`(\*\*${esc}\*\*\s+\(\`${slug}\`\))(?!\s*\(see)`, 'g'),
      `$1 (see .agents/skills/${slug}/SKILL.md)`
    );

    // invoke the Name Skill — not already followed by (see
    content = content.replaceAll(
      new RegExp(String.raw`(invoke the ${esc} Skill)(?!\s*\(see)`, 'g'),
      `$1 (see .agents/skills/${slug}/SKILL.md)`
    );
  }

  // 3. Subagent/sub-agent → sub-skill (single regex, no ordering dependency)
  content = content.replaceAll(/\b(sub-?agents?)\b/gi, (match) => {
    const plural = /s$/i.test(match);
    const upper = match[0] === match[0].toUpperCase();
    const base = upper ? 'Sub-Skill' : 'sub-skill';
    return plural ? base + 's' : base;
  });

  // 4. agents→skills in various contexts
  content = content.replaceAll(' specialist agents', ' specialist skills');
  content = content.replaceAll(' specialized agents', ' specialized skills');

  // 4b. Headings: "# ... Agent" → "# ... Skill" (any heading level)
  content = content.replaceAll(/^(#{1,6} .+) Agent$/gm, '$1 Skill');

  // 4c. Self-descriptions: "You are a ... agent that" → "You are a ... skill that"
  content = content.replaceAll(/^(You are an? .+?) agent (that )/gm, '$1 skill $2');

  // 4d. "This agent" / "this agent" / "This Agent" → "This skill" / "this skill" / "This Skill"
  content = content.replaceAll(/\bThis Agent\b/g, 'This Skill');
  content = content.replaceAll(/\bThis agent\b/g, 'This skill');
  content = content.replaceAll(/\bthis agent\b/g, 'this skill');

  // 4e. Remaining agent→skill in common phrases
  content = content.replaceAll('downstream agents', 'downstream skills');
  content = content.replaceAll('the calling agent', 'the calling skill');
  content = content.replaceAll("the agent's", "the skill's");
  content = content.replaceAll('The agent should', 'The skill should');
  content = content.replaceAll('in agent mode', 'in skill mode');
  content = content.replaceAll('next agent', 'next skill');
  content = content.replaceAll('appropriate agent', 'appropriate skill');

  // 5. Delegation markers — explicit <!-- DELEGATE --> in src content
  content = content.replaceAll('<!-- DELEGATE -->', DELEGATION_TEXT);

  // 6. Session markers — explicit <!-- NEW_SESSION --> in src content
  content = content.replaceAll(
    '<!-- NEW_SESSION -->',
    '(or use the `handoff` tool to continue in a new thread)'
  );

  // 7. Instruction paths
  content = content.replaceAll('.github/instructions/', '.agents/instructions/');

  // 8. Env file paths (reverse): specific contexts first, then catch-all
  content = content.replaceAll('your `.github/.env` file', 'your project `.env` file');
  content = content.replaceAll('from `.github/.env`', 'from the project `.env` file');
  content = content.replaceAll('in `.github/.env`', 'in the project `.env` file');
  content = content.replaceAll('Create `.github/.env`', 'Create the project `.env` file');
  content = content.replaceAll('`.github/.env`', 'the project `.env` file');

  // 9. Copilot-specific text removal
  content = content.replaceAll(' via Copilot chat', '');
  content = content.replaceAll(
    'Claude Opus 4.5 in GitHub Copilot does not have vision capabilities. Images are downloaded for manual review only.',
    'Images are downloaded for manual review only.'
  );

  // 10. Generic "agent" → "skill" in remaining contexts
  const genericReplacements = [
    ['| Agent |', '| Skill |'],
    ['the sub-agent', 'the sub-skill'],
    ['Wait for the sub-agent', 'Wait for the sub-skill'],
    ['each agent,', 'each skill,'],
    ['Each agent', 'Each skill'],
    ['each agent ', 'each skill '],
  ];
  for (const [pattern, replacement] of genericReplacements) {
    content = content.replaceAll(pattern, replacement);
  }

  // Case-insensitive replacements (must use regex)
  content = content.replaceAll(/the planning agent/gi, 'the planning skill');
  content = content.replaceAll('the appropriate agent', 'the appropriate skill');

  return content;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function readSrc(relativePath) {
  return fs.readFileSync(path.join(SRC, relativePath), 'utf8');
}

function writeFile(filePath, content) {
  if (DRY_RUN) return;
  const dir = path.dirname(filePath);
  fs.mkdirSync(dir, { recursive: true });
  if (Buffer.isBuffer(content)) {
    fs.writeFileSync(filePath, content);
  } else {
    fs.writeFileSync(filePath, content, 'utf8');
  }
}

function copyDir(src, dest, relativeRoot) {
  if (!fs.existsSync(src)) return;
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const e of entries) {
    const srcEntry = path.join(src, e.name);
    const destEntry = path.join(dest, e.name);
    if (e.isDirectory()) {
      copyDir(srcEntry, destEntry, relativeRoot);
    } else {
      writeFile(destEntry, fs.readFileSync(srcEntry));
      console.log('  \u2713 ' + path.relative(relativeRoot, destEntry).replaceAll('\\', '/'));
    }
  }
}

// ---------------------------------------------------------------------------
// Exports for testing (must be before main execution guard)
// ---------------------------------------------------------------------------

if (typeof module !== 'undefined') {
  module.exports = {
    transformForCopilot,
    transformForAmp,
    yamlQuote,
    validateSlug,
    buildCopilotAgentFrontmatter,
    buildCopilotSkillFrontmatter,
    buildAmpFrontmatter
  };
}

// When required as a module (e.g. tests), skip build execution
if (require.main === module) {

// ---------------------------------------------------------------------------
// Prompt merge map: promptSlug → { mergeInto: targetSlug, body: content }
// Prompts with amp.mergeInto are appended to the target agent/skill's AMP output
// ---------------------------------------------------------------------------

const promptMergeMap = {};
if (manifest.prompts) {
  for (const [slug, prompt] of Object.entries(manifest.prompts)) {
    validateSlug(slug, 'prompt');
    if (prompt.amp && prompt.amp.mergeInto) {
      const body = readSrc(prompt.src);
      const transformed = transformForAmp(body);
      if (!promptMergeMap[prompt.amp.mergeInto]) {
        promptMergeMap[prompt.amp.mergeInto] = [];
      }
      promptMergeMap[prompt.amp.mergeInto].push({ slug, body: transformed });
    }
  }
}

function buildAmpOutput(slug, body, ampConfig, outDir) {
  const fm = buildAmpFrontmatter(ampConfig);
  const transformed = transformForAmp(body);
  let content = fm + '\n' + transformed;

  if (promptMergeMap[slug]) {
    for (const merged of promptMergeMap[slug]) {
      content += '\n\n---\n\n' + merged.body;
      console.log('    \u2713 merged prompt "' + merged.slug + '" into "' + slug + '"');
    }
  }

  const outPath = path.join(outDir, '.agents', 'skills', slug, 'SKILL.md');
  writeFile(outPath, content);
  console.log('  \u2713 amp/.agents/skills/' + slug + '/SKILL.md');
}

// ---------------------------------------------------------------------------
// Clean output directories
// ---------------------------------------------------------------------------

function safeRmSync(dir) {
  if (DRY_RUN) return;
  const resolved = path.resolve(dir);
  if (!resolved.startsWith(ROOT + path.sep) && resolved !== ROOT) {
    throw new Error(`Refusing to delete "${resolved}": not inside project root "${ROOT}"`);
  }
  fs.rmSync(resolved, { recursive: true, force: true });
}

if (DRY_RUN) console.log('(dry-run mode — no files will be written)\n');
console.log('Building ai-common output...');

safeRmSync(COPILOT_OUT);
safeRmSync(AMP_OUT);
if (!DRY_RUN) {
  fs.mkdirSync(COPILOT_OUT, { recursive: true });
  fs.mkdirSync(AMP_OUT, { recursive: true });
}

let copilotCount = 0;
let ampCount = 0;

// ---------------------------------------------------------------------------
// Generate agent files
// ---------------------------------------------------------------------------

if (manifest.agents) {
  for (const [slug, agent] of Object.entries(manifest.agents)) {
    const body = readSrc(agent.src);

    // Copilot
    if (agent.copilot) {
      const copilotConfig = { name: agent.displayName, ...agent.copilot, description: agent.copilot.description || agent.description };
      const fm = buildCopilotAgentFrontmatter(copilotConfig);
      const transformed = transformForCopilot(body);
      const outPath = path.join(COPILOT_OUT, 'agents', slug + '.agent.md');
      writeFile(outPath, fm + '\n' + transformed);
      console.log('  \u2713 copilot/agents/' + slug + '.agent.md');
      copilotCount++;
    }

    // Amp (default: on — set amp: false to skip)
    if (agent.amp !== false) {
      if (agent.amp && agent.amp.foldInto && agent.amp.referenceAs) {
        // Fold into parent skill as a reference doc (no frontmatter)
        const transformed = transformForAmp(body);
        const outPath = path.join(AMP_OUT, '.agents', 'skills', agent.amp.foldInto, 'reference', agent.amp.referenceAs);
        writeFile(outPath, transformed);
        console.log('  \u2713 amp/.agents/skills/' + agent.amp.foldInto + '/reference/' + agent.amp.referenceAs);
      } else {
        const ampConfig = { name: slug, ...agent.amp, description: (agent.amp && agent.amp.description) || agent.description };
        buildAmpOutput(slug, body, ampConfig, AMP_OUT);
      }
      ampCount++;
    }
  }
}

// ---------------------------------------------------------------------------
// Generate skill files
// ---------------------------------------------------------------------------

if (manifest.skills) {
  for (const [slug, skill] of Object.entries(manifest.skills)) {
    const body = readSrc(skill.src);

    // Copilot (default: on — set copilot: false to skip)
    if (skill.copilot !== false) {
      const copilotConfig = { ...skill.copilot, description: (skill.copilot && skill.copilot.description) || skill.description };
      const fm = buildCopilotSkillFrontmatter(copilotConfig);
      const transformed = transformForCopilot(body);
      const outPath = path.join(COPILOT_OUT, 'skills', slug, 'SKILL.md');
      writeFile(outPath, fm + transformed);
      console.log('  \u2713 copilot/skills/' + slug + '/SKILL.md');
      copilotCount++;
    }

    // Amp (default: on — set amp: false to skip)
    if (skill.amp !== false) {
      const ampConfig = { name: slug, ...skill.amp, description: (skill.amp && skill.amp.description) || skill.description };
      buildAmpOutput(slug, body, ampConfig, AMP_OUT);
      ampCount++;
    }
  }
}

// ---------------------------------------------------------------------------
// Generate prompt files (Copilot only)
// ---------------------------------------------------------------------------

if (manifest.prompts) {
  for (const [slug, prompt] of Object.entries(manifest.prompts)) {
    const body = readSrc(prompt.src);

    if (prompt.copilot) {
      const copilotConfig = { ...prompt.copilot, description: prompt.copilot.description || prompt.description };
      const fm = buildCopilotPromptFrontmatter(copilotConfig);
      const transformed = transformForCopilot(body);
      const outPath = path.join(COPILOT_OUT, 'prompts', slug + '.prompt.md');
      writeFile(outPath, fm + transformed);
      console.log('  \u2713 copilot/prompts/' + slug + '.prompt.md');
      copilotCount++;
    }
  }
}

// ---------------------------------------------------------------------------
// Generate check files (Amp only)
// ---------------------------------------------------------------------------

if (manifest.checks) {
  for (const [slug, check] of Object.entries(manifest.checks)) {
    validateSlug(slug, 'check');
    const body = readSrc(check.src);

    // Checks are AMP-only — used by `amp review`
    const outPath = path.join(AMP_OUT, '.agents', 'checks', slug + '.md');
    writeFile(outPath, body);
    console.log('  \u2713 amp/.agents/checks/' + slug + '.md');
    ampCount++;
  }
}

// ---------------------------------------------------------------------------
// Generate instruction files
// ---------------------------------------------------------------------------

if (manifest.instructions) {
  for (const [slug, instruction] of Object.entries(manifest.instructions)) {
    validateSlug(slug, 'instruction');
    const body = readSrc(instruction.src);

    // Copilot: add applyTo frontmatter
    const copilotFm = buildCopilotInstructionFrontmatter();
    const copilotPath = path.join(COPILOT_OUT, 'instructions', slug + '.instructions.md');
    writeFile(copilotPath, copilotFm + body);
    console.log('  \u2713 copilot/instructions/' + slug + '.instructions.md');
    copilotCount++;

    // Amp: copy as-is (no frontmatter)
    const ampPath = path.join(AMP_OUT, '.agents', 'instructions', slug + '.md');
    writeFile(ampPath, body);
    console.log('  \u2713 amp/.agents/instructions/' + slug + '.md');
    ampCount++;
  }
}

// ---------------------------------------------------------------------------
// Generate copilot-instructions.md
// ---------------------------------------------------------------------------

{
  let principles = readSrc('principles.md');

  // Apply Copilot path transforms to the project documentation table
  const instructionFiles = [
    'repo_overview', 'project_context', 'development_standards',
    'testing_approach', 'workflows', 'usage_patterns'
  ];
  for (const name of instructionFiles) {
    principles = principles.replaceAll(
      new RegExp('\\| `' + name + '\\.md`', 'g'),
      '| `.github/instructions/' + name + '.instructions.md`'
    );
  }

  const outPath = path.join(COPILOT_OUT, 'copilot-instructions.md');
  writeFile(outPath, principles);
  console.log('  \u2713 copilot/copilot-instructions.md');
  copilotCount++;
}

// ---------------------------------------------------------------------------
// Generate AGENTS.md
// ---------------------------------------------------------------------------

{
  let principles = readSrc('principles.md');

  // Apply Amp path transforms to the project documentation table
  const instructionFiles = [
    'repo_overview', 'project_context', 'development_standards',
    'testing_approach', 'workflows', 'usage_patterns'
  ];
  for (const name of instructionFiles) {
    principles = principles.replaceAll(
      new RegExp('\\| `' + name + '\\.md`', 'g'),
      '| @`.agents/instructions/' + name + '.md`'
    );
  }

  // Change heading for Amp
  principles = principles.replace(/^# AI Assistant Principles$/m, '# Project Instructions');

  const outPath = path.join(AMP_OUT, 'AGENTS.md');
  writeFile(outPath, principles);
  console.log('  \u2713 amp/AGENTS.md');
  ampCount++;
}

// ---------------------------------------------------------------------------
// Generate installer config (ai-common-config.json)
// ---------------------------------------------------------------------------

if (manifest.installer) {
  const installerConfig = {
    version: manifest.installer.version,
    repository: manifest.installer.repository,
    agents: {}
  };

  for (const [pkgSlug, pkg] of Object.entries(manifest.installer.packages)) {
    const entry = {
      name: pkg.name,
      description: pkg.description,
      enabled: true,
      target: pkg.target || ['generic'],
      files: [],
      actions: pkg.actions || []
    };

    const inc = pkg.include || {};
    const pkgTarget = entry.target;

    // Foundation: principles files
    if (inc.principles) {
      entry.files.push({
        source: 'copilot/copilot-instructions.md',
        destination: '.github/copilot-instructions.md',
        type: 'file',
        tool: 'copilot',
        description: 'Copilot instructions (principles)',
        target: pkgTarget
      }, {
        source: 'amp/AGENTS.md',
        destination: 'AGENTS.md',
        type: 'file',
        tool: 'amp',
        merge: 'agents-md',
        description: 'Amp AGENTS.md (principles)',
        target: pkgTarget
      });
    }

    // Foundation: all instructions (protected — user fills in placeholders)
    if (inc.instructions === 'all' && manifest.instructions) {
      for (const slug of Object.keys(manifest.instructions)) {
        entry.files.push({
          source: `copilot/instructions/${slug}.instructions.md`,
          destination: `.github/instructions/${slug}.instructions.md`,
          type: 'file',
          tool: 'copilot',
          protected: true,
          target: pkgTarget
        }, {
          source: `amp/.agents/instructions/${slug}.md`,
          destination: `.agents/instructions/${slug}.md`,
          type: 'file',
          tool: 'amp',
          protected: true,
          target: pkgTarget
        });
      }
    }

    // Foundation: all checks (Amp only)
    if (inc.checks === 'all' && manifest.checks) {
      for (const slug of Object.keys(manifest.checks)) {
        entry.files.push({
          source: `amp/.agents/checks/${slug}.md`,
          destination: `.agents/checks/${slug}.md`,
          type: 'file',
          tool: 'amp',
          target: pkgTarget
        });
      }
    }

    // Agents
    if (inc.agents) {
      for (const agentSlug of inc.agents) {
        const agent = manifest.agents[agentSlug];
        if (!agent) { console.warn(`  ⚠ installer: unknown agent "${agentSlug}"`); continue; }
        if (agent.copilot) {
          entry.files.push({
            source: `copilot/agents/${agentSlug}.agent.md`,
            destination: `.github/agents/${agentSlug}.agent.md`,
            type: 'file',
            tool: 'copilot',
            target: pkgTarget
          });
        }
        if (agent.amp !== false) {
          if (agent.amp && agent.amp.foldInto && agent.amp.referenceAs) {
            // Folded into parent skill as reference doc
            entry.files.push({
              source: `amp/.agents/skills/${agent.amp.foldInto}/reference/${agent.amp.referenceAs}`,
              destination: `.agents/skills/${agent.amp.foldInto}/reference/${agent.amp.referenceAs}`,
              type: 'file',
              tool: 'amp',
              target: pkgTarget
            });
          } else {
            entry.files.push({
              source: `amp/.agents/skills/${agentSlug}/SKILL.md`,
              destination: `.agents/skills/${agentSlug}/SKILL.md`,
              type: 'file',
              tool: 'amp',
              target: pkgTarget
            });
          }
        }
      }
    }

    // Skills
    if (inc.skills) {
      for (const skillSlug of inc.skills) {
        const skill = manifest.skills[skillSlug];
        if (!skill) { console.warn(`  ⚠ installer: unknown skill "${skillSlug}"`); continue; }
        if (skill.copilot !== false) {
          const deployAs = (skill.copilot && skill.copilot.deployAs) || 'file';
          if (deployAs === 'directory') {
            entry.files.push({
              source: `copilot/skills/${skillSlug}`,
              destination: `.github/skills/${skillSlug}`,
              type: 'directory',
              tool: 'copilot',
              description: `${skill.displayName || skillSlug} skill`,
              target: pkgTarget
            });
          } else {
            entry.files.push({
              source: `copilot/skills/${skillSlug}/SKILL.md`,
              destination: `.github/skills/${skillSlug}/SKILL.md`,
              type: 'file',
              tool: 'copilot',
              target: pkgTarget
            });
          }
        }
        if (skill.amp !== false) {
          entry.files.push({
            source: `amp/.agents/skills/${skillSlug}/SKILL.md`,
            destination: `.agents/skills/${skillSlug}/SKILL.md`,
            type: 'file',
            tool: 'amp',
            target: pkgTarget
          });
        }
      }
    }

    // Prompts (Copilot only)
    if (inc.prompts) {
      for (const promptSlug of inc.prompts) {
        const prompt = manifest.prompts[promptSlug];
        if (!prompt) { console.warn(`  ⚠ installer: unknown prompt "${promptSlug}"`); continue; }
        if (prompt.copilot) {
          entry.files.push({
            source: `copilot/prompts/${promptSlug}.prompt.md`,
            destination: `.github/prompts/${promptSlug}.prompt.md`,
            type: 'file',
            tool: 'copilot',
            target: pkgTarget
          });
        }
      }
    }

    // Extra files (tools directories, etc.)
    if (pkg.extra) {
      for (const extra of pkg.extra) {
        const fileEntry = {
          source: extra.source,
          destination: extra.destination,
          type: extra.type || 'file',
          tool: extra.tool || 'both',
          target: extra.target || pkgTarget
        };
        if (extra.description) fileEntry.description = extra.description;
        entry.files.push(fileEntry);
      }
    }

    // Optional fields
    if (pkg.requiredTokens) entry.requiredTokens = pkg.requiredTokens;
    if (pkg.documentation) entry.documentation = pkg.documentation;

    installerConfig.agents[pkgSlug] = entry;
  }

  const configPath = path.join(ROOT, 'tools', 'install-agents', 'ai-common-config.json');
  writeFile(configPath, JSON.stringify(installerConfig, null, 2) + '\n');
  console.log('  ✓ tools/install-agents/ai-common-config.json');
}

// ---------------------------------------------------------------------------
// Generate example output
// ---------------------------------------------------------------------------

const EXAMPLES_DIR = path.join(ROOT, 'examples');

if (fs.existsSync(EXAMPLES_DIR)) {
  const exampleDirs = fs.readdirSync(EXAMPLES_DIR, { withFileTypes: true })
    .filter(d => d.isDirectory())
    .filter(d => fs.existsSync(path.join(EXAMPLES_DIR, d.name, 'manifest.yaml')));

  for (const dir of exampleDirs) {
    const exampleRoot = path.join(EXAMPLES_DIR, dir.name);
    const exampleManifest = yaml.load(fs.readFileSync(path.join(exampleRoot, 'manifest.yaml'), 'utf8'));
    const exampleSrc = path.join(exampleRoot, 'src');
    const exampleCopilotOut = path.join(exampleRoot, 'copilot');
    const exampleAmpOut = path.join(exampleRoot, 'amp');

    console.log(`\nBuilding example: ${dir.name}...`);

    // Clean output directories
    safeRmSync(exampleCopilotOut);
    safeRmSync(exampleAmpOut);
    if (!DRY_RUN) {
      fs.mkdirSync(exampleCopilotOut, { recursive: true });
      fs.mkdirSync(exampleAmpOut, { recursive: true });
    }

    let exCopilotCount = 0;
    let exAmpCount = 0;

    // Skills
    if (exampleManifest.skills) {
      for (const [slug, skill] of Object.entries(exampleManifest.skills)) {
        const body = fs.readFileSync(path.join(exampleSrc, skill.src), 'utf8');

        // Copilot (default: on)
        if (skill.copilot !== false) {
          const copilotConfig = { ...skill.copilot, description: (skill.copilot && skill.copilot.description) || skill.description };
          const transformed = transformForCopilot(body);
          let content;
          if (copilotConfig.description) {
            content = buildCopilotSkillFrontmatter(copilotConfig) + transformed;
          } else {
            content = transformed;
          }
          const outPath = path.join(exampleCopilotOut, 'skills', slug, 'SKILL.md');
          writeFile(outPath, content);
          console.log('  \u2713 copilot/skills/' + slug + '/SKILL.md');
          exCopilotCount++;
        }

        // Amp (default: on)
        if (skill.amp !== false) {
          const ampConfig = { name: slug, ...skill.amp, description: (skill.amp && skill.amp.description) || skill.description };
          buildAmpOutput(slug, body, ampConfig, exampleAmpOut);
          exAmpCount++;
        }
      }
    }

    // Instructions
    if (exampleManifest.instructions) {
      for (const [slug, instruction] of Object.entries(exampleManifest.instructions)) {
        const body = fs.readFileSync(path.join(exampleSrc, instruction.src), 'utf8');

        // Copilot: add applyTo frontmatter
        if (instruction.copilot) {
          const applyTo = instruction.copilot.applyTo || '**';
          let fm = '---\n';
          fm += `applyTo: '${applyTo}'\n`;
          fm += '---\n';
          const outPath = path.join(exampleCopilotOut, 'instructions', slug + '.instructions.md');
          writeFile(outPath, fm + body);
          console.log('  \u2713 copilot/instructions/' + slug + '.instructions.md');
          exCopilotCount++;
        }

        // Amp: copy as-is (no frontmatter)
        const ampPath = path.join(exampleAmpOut, '.agents', 'instructions', slug + '.md');
        writeFile(ampPath, body);
        console.log('  \u2713 amp/.agents/instructions/' + slug + '.md');
        exAmpCount++;
      }
    }

    // Shared files (direct copy, no transformation)
    if (exampleManifest.shared) {
      for (const entry of exampleManifest.shared) {
        const srcPath = path.join(exampleSrc, entry.src);

        if (entry.copilot) {
          copyDir(srcPath, path.join(exampleCopilotOut, entry.copilot), exampleRoot);
          exCopilotCount++;
        }
        if (entry.amp) {
          copyDir(srcPath, path.join(exampleAmpOut, entry.amp), exampleRoot);
          exAmpCount++;
        }
      }
    }

    console.log(`  ${dir.name}: ${exCopilotCount} Copilot, ${exAmpCount} Amp outputs`);
    copilotCount += exCopilotCount;
    ampCount += exAmpCount;
  }
}

// ---------------------------------------------------------------------------
// Summary
// ---------------------------------------------------------------------------

console.log(`\nDone! Generated ${copilotCount} files for Copilot, ${ampCount} files for Amp.`);

}