#!/usr/bin/env node
/* eslint-disable no-console */

/**
 * AI Common Bootstrap Script
 *
 * This is the ONLY file that needs to be committed to MFE repositories.
 * It downloads everything else from the ai-common repository.
 *
 * What it downloads:
 * 1. Agent configuration (agent-config.json) → .github/ai-common-config.json
 * 2. Tooling scripts → tools/install-agents/:
 *    - download-agent-files.js
 *    - execute-agent-actions.js
 *    - install-agent.js
 *
 * Usage:
 *   node sync-ai-common.js [--branch=<branch-name>]
 *   node sync-ai-common.js [--branch <branch-name>]
 *
 * Requirements:
 *   - BITBUCKET_PAT environment variable must be set
 *   - Node.js v14+ (uses only built-in modules)
 *
 * Optional environment variables:
 *   - NODE_EXTRA_CA_CERTS        Path to corporate CA bundle for SSL verification
 *   - AI_COMMON_BITBUCKET_URL    Override Bitbucket hostname
 *   - AI_COMMON_PROJECT          Override Bitbucket project key
 *   - AI_COMMON_REPO             Override Bitbucket repo slug
 */

const https = require("https");
const fs = require("fs");
const path = require("path");
const os = require("os");

// Configuration (overridable via environment variables)
const BITBUCKET_BASE_URL =
  process.env.AI_COMMON_BITBUCKET_URL || "bitbucket.srv.westpac.com.au";
const AI_COMMON_PROJECT = process.env.AI_COMMON_PROJECT || "A014A6";
const AI_COMMON_REPO = process.env.AI_COMMON_REPO || "ai-common";
const DEFAULT_BRANCH = "master";

// Parse command line arguments
const args = process.argv.slice(2);
let BRANCH = DEFAULT_BRANCH;

// Support both --branch=<name> and --branch <name>
const branchArgIndex = args.findIndex(
  (arg) => arg === "--branch" || arg.startsWith("--branch="),
);
if (branchArgIndex !== -1) {
  const branchArg = args[branchArgIndex];
  if (branchArg.startsWith("--branch=")) {
    [, BRANCH] = branchArg.split("=");
  } else if (branchArgIndex + 1 < args.length) {
    BRANCH = args[branchArgIndex + 1];
  }
}

// Source folder to download recursively
const SOURCE_FOLDER = "tools/install-agents";
const DESTINATION_FOLDER = "tools/install-agents";

// Get project root (where this script is located)
const PROJECT_ROOT = __dirname;

/**
 * Validate that BITBUCKET_PAT token is available
 */
function validateToken() {
  const token = process.env.BITBUCKET_PAT;

  if (!token) {
    console.error(
      "\n❌ ERROR: BITBUCKET_PAT environment variable is not set\n",
    );
    console.error(
      "The BITBUCKET_PAT token is required to download files from the private ai-common repository.\n",
    );

    const platform = os.platform();

    if (platform === "darwin" || platform === "linux") {
      console.error("To set up your token on macOS/Linux:");
      console.error(
        "1. Add this line to your shell profile (~/.zshrc, ~/.bashrc, or ~/.bash_profile):",
      );
      console.error('   export BITBUCKET_PAT="your-token-here"');
      console.error(
        "2. Reload your shell: source ~/.zshrc (or your profile file)",
      );
      console.error("3. Run this script again\n");
    } else if (platform === "win32") {
      console.error("To set up your token on Windows:");
      console.error("\nFor PowerShell:");
      console.error("1. Add to your PowerShell profile ($PROFILE):");
      console.error('   $env:BITBUCKET_PAT="your-token-here"');
      console.error(
        "2. Or set it system-wide in System Properties > Environment Variables",
      );
      console.error("\nFor Git Bash:");
      console.error("1. Add to ~/.bashrc:");
      console.error('   export BITBUCKET_PAT="your-token-here"');
      console.error("2. Reload: source ~/.bashrc\n");
    }

    console.error("To create a BITBUCKET_PAT:");
    console.error("1. Go to https://bitbucket.srv.westpac.com.au");
    console.error(
      "2. Click your profile → Manage account → Personal access tokens",
    );
    console.error(
      '3. Create a token with "Read" permissions for repositories\n',
    );

    process.exit(1);
  }

  console.log("✓ BITBUCKET_PAT token found");
  return token;
}

/**
 * Makes an HTTPS GET request to Bitbucket with redirect support.
 * SSL verification uses Node.js defaults — configure corporate CAs via
 * the NODE_EXTRA_CA_CERTS environment variable rather than disabling verification.
 */
function makeBitbucketRequest(requestPath, token) {
  return new Promise((resolve, reject) => {
    function collectBody(res) {
      let data = "";
      res.on("data", (chunk) => {
        data += chunk;
      });
      res.on("end", () => {
        resolve(data);
      });
    }

    const options = {
      hostname: BITBUCKET_BASE_URL,
      path: requestPath,
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
    };

    const req = https.request(options, (res) => {
      if (res.statusCode === 301 || res.statusCode === 302) {
        https
          .get(
            res.headers.location,
            { headers: options.headers },
            (redirectRes) => {
              if (redirectRes.statusCode !== 200) {
                reject(new Error(`HTTP ${redirectRes.statusCode}`));
                return;
              }
              collectBody(redirectRes);
            },
          )
          .on("error", reject);
        return;
      }

      if (res.statusCode !== 200) {
        reject(
          new Error(
            `HTTP ${res.statusCode}: ${res.statusMessage} for ${requestPath}`,
          ),
        );
        return;
      }

      collectBody(res);
    });

    req.on("error", reject);
    req.end();
  });
}

/**
 * List directory contents from Bitbucket using the browse API
 */
function listDirectory(directoryPath, token) {
  const apiPath = `/rest/api/1.0/projects/${AI_COMMON_PROJECT}/repos/${AI_COMMON_REPO}/browse/${directoryPath}?at=refs/heads/${BRANCH}&limit=1000`;
  return makeBitbucketRequest(apiPath, token).then((data) => {
    try {
      const parsed = JSON.parse(data);
      // Bitbucket API returns values in children.values for directories
      return parsed.children ? parsed.children.values : parsed.values || [];
    } catch (err) {
      throw new Error(`Failed to parse directory listing: ${err.message}`);
    }
  });
}

/**
 * Download a file from Bitbucket using the REST API
 */
function downloadFile(sourcePath, token) {
  const apiPath = `/rest/api/1.0/projects/${AI_COMMON_PROJECT}/repos/${AI_COMMON_REPO}/raw/${sourcePath}?at=refs/heads/${BRANCH}`;
  return makeBitbucketRequest(apiPath, token);
}

/**
 * Ensure directory exists
 */
function ensureDirectoryExists(filePath) {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

/**
 * Recursively download a folder and all its contents
 */
async function downloadFolderRecursively(sourcePath, destinationPath, token) {
  const items = await listDirectory(sourcePath, token);
  const results = { files: [], errors: [] };

  // Process items sequentially to avoid race conditions
  // eslint-disable-next-line no-restricted-syntax
  for (const item of items) {
    // Handle both path structures from Bitbucket API
    const itemName = item.path.name || item.path.toString();
    const itemSourcePath = sourcePath ? `${sourcePath}/${itemName}` : itemName;
    const itemDestPath = path.join(destinationPath, itemName);

    // Guard against path traversal from API-supplied names
    const resolvedDest = path.resolve(PROJECT_ROOT, itemDestPath);
    if (!resolvedDest.startsWith(path.resolve(PROJECT_ROOT))) {
      console.log(`  ⚠️  Skipped (path traversal): ${itemName}`);
      // eslint-disable-next-line no-continue
      continue;
    }

    if (item.type === "FILE") {
      try {
        // eslint-disable-next-line no-await-in-loop
        const content = await downloadFile(itemSourcePath, token);
        const fullDestPath = path.join(PROJECT_ROOT, itemDestPath);
        ensureDirectoryExists(fullDestPath);
        fs.writeFileSync(fullDestPath, content, "utf8");

        // Make .js files executable
        if (itemName.endsWith(".js")) {
          try {
            fs.chmodSync(fullDestPath, 0o755);
          } catch (err) {
            // chmod might fail on Windows, that's okay
          }
        }

        results.files.push(itemDestPath);
      } catch (error) {
        results.errors.push({ path: itemSourcePath, error: error.message });
      }
    } else if (item.type === "DIRECTORY") {
      // Recursively download subdirectory
      // eslint-disable-next-line no-await-in-loop
      const subResults = await downloadFolderRecursively(
        itemSourcePath,
        itemDestPath,
        token,
      );
      results.files.push(...subResults.files);
      results.errors.push(...subResults.errors);
    }
  }

  return results;
}

/**
 * Main execution
 */
async function main() {
  console.log("\n🚀 AI Common Bootstrap Script");
  console.log("================================\n");
  console.log(`Downloading from: ${AI_COMMON_REPO} (branch: ${BRANCH})`);
  console.log(`Source: ${SOURCE_FOLDER}`);
  console.log(`Destination: ${DESTINATION_FOLDER}\n`);

  // Step 1: Validate token
  const token = validateToken();

  // Step 2: Ensure tools folder exists
  const toolsPath = path.join(PROJECT_ROOT, "tools");
  if (!fs.existsSync(toolsPath)) {
    fs.mkdirSync(toolsPath, { recursive: true });
    console.log(`✓ Created tools directory\n`);
  }

  // Step 3: Download folder recursively
  console.log("📥 Downloading install-agents folder recursively...\n");

  let results;
  try {
    results = await downloadFolderRecursively(
      SOURCE_FOLDER,
      DESTINATION_FOLDER,
      token,
    );
  } catch (error) {
    console.error(`\n❌ Failed to download folder: ${error.message}`);
    process.exit(1);
  }

  // Step 4: Report results
  const separator = "=".repeat(50);
  console.log(`\n${separator}`);
  console.log(
    `\n✅ Download complete: ${results.files.length} files downloaded, ${results.errors.length} errors\n`,
  );

  if (results.files.length > 0) {
    console.log("Downloaded files:");
    results.files.forEach((file) => {
      console.log(`  ✓ ${file}`);
    });
  }

  if (results.errors.length > 0) {
    console.log("\n⚠️  Errors occurred:");
    results.errors.forEach((err) => {
      console.log(`  ✗ ${err.path}: ${err.error}`);
    });
    process.exit(1);
  }

  // Step 5: Next steps
  console.log("\n📖 Next Steps:");
  console.log(
    "  Run install-agent.js to download and install AI agents:\n",
  );
  console.log("  Common Usage:");
  console.log(
    "    node tools/install-agents/install-agent.js              # Install all for Copilot (default)",
  );
  console.log(
    "    node tools/install-agents/install-agent.js --tool=amp   # Install all for Amp",
  );
  console.log(
    "    node tools/install-agents/install-agent.js --tool=both  # Install for both tools",
  );
  console.log(
    "    node tools/install-agents/install-agent.js <agent-name> # Install specific agent",
  );
  console.log(
    "    node tools/install-agents/install-agent.js --list       # List all available agents",
  );
  console.log(
    "    node tools/install-agents/install-agent.js --help       # Show detailed help\n",
  );
  console.log("  Tool & Target Filtering:");
  console.log(
    "    node tools/install-agents/install-agent.js --tool=amp --target=mfe",
  );
  console.log(
    "                                                            # Install for Amp, MFE target\n",
  );
  console.log(
    "  Common tools: copilot, amp, both",
  );
  console.log(
    "  Common targets: generic, mfe, spa, widget, api\n",
  );
}

// Run the script
main().catch((error) => {
  console.error("\n❌ Fatal error:", error.message);
  process.exit(1);
});
