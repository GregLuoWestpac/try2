# Mockoon Generator CLI Skill

This skill provides instructions for invoking the `tools/mockoon-gen/cli.js` command-line tool.

## Commands

### Fetch Swagger

```bash
node tools/mockoon-gen/cli.js fetch <api-name-or-url>
```

### Generate Mockoon Data

```bash
node tools/mockoon-gen/cli.js generate <swagger-path> [options]
```

### Fetch + Generate (one step)

```bash
node tools/mockoon-gen/cli.js fetch-and-generate <api-name> [options]
```

### Validate

```bash
node tools/mockoon-gen/cli.js validate [mockoon-path]
```

## Options

| Option                 | Default                              | Description                      |
| ---------------------- | ------------------------------------ | -------------------------------- |
| `-o, --output <path>`  | `api/env/dev-w1c2/mockoon-data.json` | Output file path                 |
| `--merge`              | `true`                               | Merge into existing file         |
| `--replace`            | `false`                              | Replace routes for same endpoint |
| `--swagger-dir <path>` | `swagger-output/`                    | Directory for fetched specs      |
| `--endpoint=<name>`    | (all)                                | Generate only matching endpoint  |
| `--dry-run`            | `false`                              | Preview without writing          |
| `-v, --verbose`        | `false`                              | Verbose logging                  |

## Invocation from Copilot

When Copilot Chat invokes this tool, use `run_in_terminal`:

```
command: node tools/mockoon-gen/cli.js <command> <args>
explanation: "Generating Mockoon mock data from CAP API swagger"
isBackground: false
timeout: 30000
```

## Output Format

The CLI outputs structured information to stdout:

- Route count and response count
- Trigger fields and test values
- Validation results
- Error details if failed

## Error Handling

| Error                               | Solution                                       |
| ----------------------------------- | ---------------------------------------------- |
| `js-yaml not found`                 | Run: `cd tools/mockoon-gen && npm install`     |
| `Swagger file not found`            | First fetch it: `node cli.js fetch <api-name>` |
| `Could not find swagger`            | Try the full swagger viewer URL instead        |
| `Invalid JSON in mockoon-data.json` | Delete and regenerate, or fix manually         |
