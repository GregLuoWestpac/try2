# Multiverse UI Common Library Fetch Skill

Fetches multiverse-ui-common-library component definitions from Bitbucket to provide Copilot context.

## Usage

This skill is invoked by the **Multiverse UI Scanner** agent to fetch component type definitions and populate `.github/instructions/multiverse-ui.instructions.md`.

## Prerequisites

- `BITBUCKET_PAT` must be defined in the project `.env` file
- Network access to `bitbucket.srv.westpac.com.au`

## Source Repository

- **Repository**: https://bitbucket.srv.westpac.com.au/projects/WDP/repos/multiverse-ui-common-library
- **Branch**: `master`
- **Base URL**: `https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library`
- **Package Name**: `@mesh-tenant-multiverse-ui-common/library`
- **Type**: Monorepo with Lerna (packages in `packages/` directory)

## Repository Structure

```
multiverse-ui-common-library/
├── packages/
│   ├── library/           # Main library package (exports all components)
│   │   └── src/index.ts   # Re-exports from all component packages
│   ├── mv-accordion/      # Individual component package
│   ├── mv-alert/
│   ├── mv-card/
│   ├── mv-table-v2/
│   └── ... (other component packages)
├── package.json           # Root workspace package.json
└── lerna.json
```

## Instructions

### Step 1: Read Bitbucket PAT

Read the `BITBUCKET_PAT` value from the project `.env` file. Strip any surrounding quotes.

**PowerShell (Windows):**
```powershell
$envContent = Get-Content ".github/.env" -Raw
$pat = ($envContent | Select-String -Pattern 'BITBUCKET_PAT=["'']?([^"''\r\n]+)["'']?').Matches.Groups[1].Value
```

**Bash (macOS/Linux):**
```bash
pat=$(grep -E '^BITBUCKET_PAT=' .github/.env | sed -E 's/^BITBUCKET_PAT=["'\'']*([^"'\'']*)["'\'']*$/\1/')
```

### Step 2: Discover Components Used in Current Project

Search the current project for imports from the multiverse-ui-common-library:

**PowerShell (Windows):**
```powershell
# Find all imports from multiverse-ui-common-library packages
Get-ChildItem -Recurse -Include *.ts,*.tsx,*.js,*.jsx | Select-String -Pattern "from ['\`"]@mesh-tenant-multiverse-ui-common" | ForEach-Object { $_.Line }
```

**Bash (macOS/Linux):**
```bash
# Find all imports from multiverse-ui-common-library packages
grep -r --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" "from ['\"]@mesh-tenant-multiverse-ui-common" . | awk -F: '{print $2}'
```

Extract component names from import statements:
- `import { MVAlert } from '@mesh-tenant-multiverse-ui-common/mv-alert'` → `['MVAlert']`
- `import { MVCard } from '@mesh-tenant-multiverse-ui-common/mv-card'` → `['MVCard']`
- `import { MVTable } from '@mesh-tenant-multiverse-ui-common/library'` → `['MVTable']`

**Output**: List of component names used in the project.

### Step 3: Fetch Default Branch

Determine the default branch of the repository:

**PowerShell (Windows):**
```powershell
$pat = "<BITBUCKET_PAT>"
$headers = @{
    "Authorization" = "Bearer $pat"
    "Content-Type" = "application/json"
}
$repoUrl = "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library"
$repo = Invoke-RestMethod -Uri $repoUrl -Headers $headers
# Default branch info may be in repo metadata or use 'main'/'master'
```

**Bash (macOS/Linux):**
```bash
pat="<BITBUCKET_PAT>"
repoUrl="https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library"
repo=$(curl -s -H "Authorization: Bearer $pat" -H "Content-Type: application/json" "$repoUrl")
echo "$repo" | jq '.' 
# Default branch info may be in repo metadata or use 'main'/'master'
```

### Step 4: Fetch Package Version

Fetch the current version from package.json:

**PowerShell (Windows):**
```powershell
$pat = "<BITBUCKET_PAT>"
$headers = @{
    "Authorization" = "Bearer $pat"
    "Content-Type" = "application/json"
}
$url = "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/raw/package.json?at=refs/heads/master"
$packageJson = Invoke-RestMethod -Uri $url -Headers $headers
$version = $packageJson.version
Write-Host "Version: $version"
```

**Bash (macOS/Linux):**
```bash
pat="<BITBUCKET_PAT>"
url="https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/raw/package.json?at=refs/heads/master"
version=$(curl -s -H "Authorization: Bearer $pat" -H "Content-Type: application/json" "$url" | jq -r '.version')
echo "Version: $version"
```

### Step 5: Fetch Available Packages

Use Bitbucket API to list all component packages in the monorepo:

**PowerShell (Windows):**
```powershell
$pat = "<BITBUCKET_PAT>"
$headers = @{
    "Authorization" = "Bearer $pat"
    "Content-Type" = "application/json"
}

# List files in packages/ directory
$url = "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/files/packages?at=refs/heads/master&limit=100"
$response = Invoke-RestMethod -Uri $url -Headers $headers
$response.values
```

**Bash (macOS/Linux):**
```bash
pat="<BITBUCKET_PAT>"
url="https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/files/packages?at=refs/heads/master&limit=100"
curl -s -H "Authorization: Bearer $pat" -H "Content-Type: application/json" "$url" | jq -r '.values[]'
```

**Fetch the library index to get all exported components:**

**PowerShell (Windows):**
```powershell
$url = "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/raw/packages/library/src/index.ts?at=refs/heads/master"
$libraryIndex = Invoke-RestMethod -Uri $url -Headers $headers
Write-Host $libraryIndex
```

**Bash (macOS/Linux):**
```bash
url="https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/raw/packages/library/src/index.ts?at=refs/heads/master"
libraryIndex=$(curl -s -H "Authorization: Bearer $pat" -H "Content-Type: application/json" "$url")
echo "$libraryIndex"
```

This returns all re-exported packages like:
```typescript
export * from '@mesh-tenant-multiverse-ui-common/mv-alert';
export * from '@mesh-tenant-multiverse-ui-common/mv-card';
// etc.
```

### Step 6: Fetch Component Source Files

For each component discovered in Step 2, fetch its source files from the corresponding package:

**Package naming convention:**
- Component `MVAlert` → Package `mv-alert`
- Component `MVCard` → Package `mv-card`
- Component `MVTable` → Package `mv-table-v2`

**URL Pattern for packages:**
```
https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/raw/packages/{package-name}/src/{ComponentName}.tsx?at=refs/heads/master
```

**Example - Fetch MVAlert component:**

**PowerShell (Windows):**
```powershell
$pat = "<BITBUCKET_PAT>"
$headers = @{
    "Authorization" = "Bearer $pat"
    "Content-Type" = "application/json"
}

# Fetch the main component file
$url = "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/raw/packages/mv-alert/src/MVAlert.tsx?at=refs/heads/master"
$component = Invoke-RestMethod -Uri $url -Headers $headers
Write-Host $component
```

**Bash (macOS/Linux):**
```bash
pat="<BITBUCKET_PAT>"
url="https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/raw/packages/mv-alert/src/MVAlert.tsx?at=refs/heads/master"
component=$(curl -s -H "Authorization: Bearer $pat" -H "Content-Type: application/json" "$url")
echo "$component"
```

**Example - Fetch package index to see exports:**

**PowerShell (Windows):**
```powershell
$url = "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/raw/packages/mv-alert/src/index.ts?at=refs/heads/master"
$index = Invoke-RestMethod -Uri $url -Headers $headers
Write-Host $index
```

**Bash (macOS/Linux):**
```bash
url="https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/raw/packages/mv-alert/src/index.ts?at=refs/heads/master"
index=$(curl -s -H "Authorization: Bearer $pat" -H "Content-Type: application/json" "$url")
echo "$index"
```

**Example - Fetch package.json for component metadata:**

**PowerShell (Windows):**
```powershell
$url = "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/raw/packages/mv-alert/package.json?at=refs/heads/master"
$packageJson = Invoke-RestMethod -Uri $url -Headers $headers
$packageJson | ConvertTo-Json
```

**Bash (macOS/Linux):**
```bash
url="https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/raw/packages/mv-alert/package.json?at=refs/heads/master"
curl -s -H "Authorization: Bearer $pat" -H "Content-Type: application/json" "$url" | jq '.'
```

**Files to look for per package:**

| File Pattern | Purpose |
|--------------|---------|
| `packages/{pkg}/src/{Component}.tsx` | Main component with props interface |
| `packages/{pkg}/src/index.ts` | Exports from the package |
| `packages/{pkg}/package.json` | Package metadata and version |

### Step 7: Parse TypeScript Props

Extract props from fetched TypeScript files:

| Pattern | Extract |
|---------|---------|
| `export interface {Component}Props` | Main props interface |
| `export type {Component}Props =` | Type alias props |
| `size?: 'small' \| 'medium' \| 'large'` | Variant options |
| `variant?: 'primary' \| 'secondary'` | Variant options |
| `= 'defaultValue'` | Default values |

**Props to capture:**
- Prop name
- Type (string, boolean, ReactNode, etc.)
- Optional (`?`) or required
- Default value (if specified in component file)
- Description (from JSDoc comments if present)

### Step 8: Fetch Library Index (All Exports)

Fetch the main library index to get all exported components:

**PowerShell (Windows):**
```powershell
$pat = "<BITBUCKET_PAT>"
$headers = @{
    "Authorization" = "Bearer $pat"
    "Content-Type" = "application/json"
}

# Fetch the library package index (re-exports all components)
$url = "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/raw/packages/library/src/index.ts?at=refs/heads/master"
$libraryIndex = Invoke-RestMethod -Uri $url -Headers $headers
Write-Host $libraryIndex
```

**Bash (macOS/Linux):**
```bash
pat="<BITBUCKET_PAT>"
url="https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/raw/packages/library/src/index.ts?at=refs/heads/master"
libraryIndex=$(curl -s -H "Authorization: Bearer $pat" -H "Content-Type: application/json" "$url")
echo "$libraryIndex"
```

Extract package names from exports:
- `export * from '@mesh-tenant-multiverse-ui-common/mv-alert'` → Package `mv-alert`
- `export * from '@mesh-tenant-multiverse-ui-common/mv-card'` → Package `mv-card`

**List all available packages:**

**PowerShell (Windows):**
```powershell
# Get all package directories
$url = "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/files/packages?at=refs/heads/master&limit=200"
$files = Invoke-RestMethod -Uri $url -Headers $headers

# Extract unique package names (directories starting with 'mv-')
$packages = $files.values | ForEach-Object { ($_ -split '/')[0] } | Where-Object { $_ -like 'mv-*' } | Select-Object -Unique
$packages
```

**Bash (macOS/Linux):**
```bash
url="https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/files/packages?at=refs/heads/master&limit=200"
packages=$(curl -s -H "Authorization: Bearer $pat" -H "Content-Type: application/json" "$url" | \
  jq -r '.values[]' | cut -d'/' -f1 | grep '^mv-' | sort -u)
echo "$packages"
```

### Step 9: Build Component Reference

For each component, compile:

```markdown
### MVAlert

**Import:** 
```tsx
// From individual package
import { MVAlert } from '@mesh-tenant-multiverse-ui-common/mv-alert';

// Or from library bundle
import { MVAlert } from '@mesh-tenant-multiverse-ui-common/library';
```

**Props:**
| Prop | Type | Required | Default | Description |
|------|------|----------|---------|-------------|
| type | 'info' \| 'warning' \| 'error' \| 'success' | No | 'info' | Alert type |
| children | ReactNode | Yes | - | Alert content |

**Variants:**
- **type**: info, warning, error, success
```

### Step 10: Output Results

Save compiled data to `.github/instructions/multiverse-ui-components.json` as an **intermediate working file**. This file is consumed by the agent to generate the `.instructions.md` and must be deleted after documentation is written.

```typescript
{
  version: string;
  fetchedAt: string;
  components: {
    name: string;
    importPath: string;
    props: {
      name: string;
      type: string;
      required: boolean;
      default?: string;
      description?: string;
    }[];
    variants: Record<string, string[]>;
  }[];
  usedInProject: {
    component: string;
    files: string[];
  }[];
}
```

### Step 11: Cleanup

After the agent has generated `.github/instructions/multiverse-ui.instructions.md`, **delete** the intermediate JSON file:

**PowerShell (Windows):**
```powershell
Remove-Item -Path ".github/instructions/multiverse-ui-components.json" -ErrorAction SilentlyContinue
```

**Bash (macOS/Linux):**
```bash
rm -f .github/instructions/multiverse-ui-components.json
```

## Error Handling

| Error | Cause | Resolution |
|-------|-------|------------|
| 401 Unauthorized | Invalid or expired BITBUCKET_PAT | Verify PAT in the project `.env` file and regenerate if needed |
| 404 Not Found | Component doesn't exist or path incorrect | Check repository structure, adjust paths |
| 403 Forbidden | No access to repository | Verify PAT has read access to WDP/multiverse-ui-common-library |
| Network Error | No network or firewall | Check VPN connection and network access |
| Parse Error | TypeScript syntax changed | Update parsing logic for new patterns |

## Fallback Behavior

If a component's types cannot be fetched:
1. Log a warning
2. Include component in output with `props: []` and note "Types unavailable"
3. Continue with other components

## Component Name Mapping

Some components may have different directory names:

| Import Name | Directory Name |
|-------------|----------------|
| `Button` | `Button` or `button` |

**Rule**: Check both PascalCase and lowercase directory names.

## Authentication Notes

- All Bitbucket API requests require the `Authorization: Bearer <PAT>` header
- The PAT must have read access to the WDP project
- If using basic auth instead: `Authorization: Basic <base64(username:PAT)>`

## Notes

- Only fetch components actually used in the current project (discovered in Step 2)
- Bitbucket raw file URLs require authentication (unlike public GitHub)
- Cache results in instruction file to avoid repeated fetches
- The intermediate JSON file (`multiverse-ui-components.json`) must always be deleted after the `.instructions.md` is finalized
- Re-run when upgrading multiverse-ui-common-library or adding new component usage
- Repository structure may differ - adapt paths based on actual file layout
