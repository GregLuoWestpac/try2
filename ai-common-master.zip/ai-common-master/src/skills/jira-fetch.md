# JIRA Ticket Fetch Skill

Fetches a JIRA ticket and saves its details to a structured markdown file.

## Usage

This skill is invoked by agents (e.g., the **Task Analysis** agent) to retrieve JIRA ticket details and save them to `.docs/agentic-logs/<JIRA-ISSUE>/ticket.md`.

## Prerequisites

- `JIRA_PAT` must be defined in the project `.env` file
- `CONFLUENCE_PAT` must be defined in the project `.env` file (separate PAT — JIRA and Confluence use different auth tokens)
- Network access to `jira.srv.westpac.com.au` and `confluence.srv.westpac.com.au`

## Instructions

### Step 1: Read JIRA PAT

Read the `JIRA_PAT` value from the project `.env` file. Strip any surrounding quotes.

### Step 2: Create Output Directory

**IMPORTANT:** Create the output directory structure before any file operations. PowerShell's `Out-File` and other file commands do not automatically create parent directories.

**PowerShell (Windows):**
```powershell
$outputDir = ".docs/agentic-logs/<TICKET_ID>"
New-Item -ItemType Directory -Force -Path "$outputDir/ticket-images" | Out-Null
```

**Bash (macOS/Linux):**
```bash
outputDir=".docs/agentic-logs/<TICKET_ID>"
mkdir -p "$outputDir/ticket-images"
```

### Step 3: Fetch Ticket Data

Execute the command to fetch the ticket (replace `<JIRA_PAT>` and `<TICKET_ID>`):

**PowerShell (Windows):**
```powershell
$pat = "<JIRA_PAT>"
$response = Invoke-RestMethod -Uri "https://jira.srv.westpac.com.au/rest/api/2/issue/<TICKET_ID>?fields=summary,status,issuetype,priority,assignee,reporter,description,created,updated,labels,components,customfield_10201,comment,attachment&expand=renderedFields" -Headers @{ Authorization = "Bearer $pat"; "Content-Type" = "application/json" }
$response | ConvertTo-Json -Depth 15
```

**Bash (macOS/Linux):**
```bash
pat="<JIRA_PAT>"
curl -s -H "Authorization: Bearer $pat" -H "Content-Type: application/json" \
  "https://jira.srv.westpac.com.au/rest/api/2/issue/<TICKET_ID>?fields=summary,status,issuetype,priority,assignee,reporter,description,created,updated,labels,components,customfield_10201,comment,attachment&expand=renderedFields" | jq '.' 
```

### Step 5: Parse and Extract Fields

Extract the following from the JSON response:

| Field | JSON Path | Description |
|-------|-----------|-------------|
| Key | `key` | Ticket ID (e.g., ART-87809) |
| Summary | `fields.summary` | Ticket title |
| Status | `fields.status.name` | Current status |
| Type | `fields.issuetype.name` | Issue type (Bug, Story, etc.) |
| Priority | `fields.priority.name` | Priority level |
| Assignee | `fields.assignee.displayName` | Person assigned (may be null) |
| Reporter | `fields.reporter.displayName` | Person who created it |
| Created | `fields.created` | Creation timestamp |
| Updated | `fields.updated` | Last update timestamp |
| Labels | `fields.labels` | Array of labels |
| Components | `fields.components[].name` | Component names |
| Description | `fields.description` | Full description (JIRA wiki markup) |
| Acceptance Criteria | `fields.customfield_10201` | Full acceptance criteria (JIRA wiki markup) |
| Comments | `fields.comment.comments[]` | Array of comments |
| Attachments | `fields.attachment[]` | Array of file attachments |

### Step 5: Convert JIRA Wiki Markup to Markdown

Apply these transformations to description, acceptance criteria, and comments:

| JIRA Markup | Markdown |
|-------------|----------|
| `*bold*` | `**bold**` |
| `_italic_` | `*italic*` |
| `+underline+` | `**underline**` (use bold) |
| `-strikethrough-` | `~~strikethrough~~` |
| `{{monospace}}` | `` `monospace` `` |
| `{code}...{code}` | ` ```...``` ` |
| `{code:language}...{code}` | ` ```language...``` ` |
| `{quote}...{quote}` | `> ...` (blockquote) |
| `{panel}...{panel}` | Preserve as block (use `> ` prefix) |
| `{panel:title=X}...{panel}` | `**X**` followed by blockquoted content |
| `{color:red}text{color}` | `text` (remove color tags) |
| `{noformat}...{noformat}` | ` ```...``` ` |
| `h1. Heading` | `# Heading` |
| `h2. Heading` | `## Heading` |
| `h3. Heading` | `### Heading` |
| `h4. Heading` | `#### Heading` |
| `h5. Heading` | `##### Heading` |
| `h6. Heading` | `###### Heading` |
| `* item` | `- item` (unordered list) |
| `# item` | `1. item` (ordered list) |
| `[text\|url]` | `[text](url)` |
| `[url]` | `<url>` |
| `!image.png!` | `![image](ticket-images/image.png)` |
| `!image.png\|thumbnail!` | `![image](ticket-images/image.png)` |
| `[~username]` | `@username` |
| `\|\|header\|\|header\|\|` | `\| header \| header \|` + separator row |
| `\|cell\|cell\|` | `\| cell \| cell \|` |
| `\r\n` | `\n` (normalize line endings) |
| `\\` | `<br>` (line break) |
| `----` | `---` (horizontal rule) |

**CRITICAL: Do NOT redact, summarize, or truncate any content. Preserve ALL text verbatim.**

### Step 6: Format Comments

For each comment in `fields.comment.comments[]`, extract:
- `author.displayName` - Comment author
- `created` - Timestamp (format as `YYYY-MM-DD HH:mm`)
- `body` - Comment body (convert JIRA markup to Markdown)

Format each comment as:

```markdown
#### [Author Name] — YYYY-MM-DD HH:mm

Comment body converted to markdown...
```

### Step 7: Download Attachments

Download all attachments to `.docs/agentic-logs/<TICKET_ID>/ticket-images/` (directory was created in Step 2):

**PowerShell (Windows):**
```powershell
$pat = "<JIRA_PAT>"
$outputDir = ".docs/agentic-logs/<TICKET_ID>/ticket-images"

$response.fields.attachment | ForEach-Object {
    $filename = $_.filename
    $url = $_.content
    $outPath = Join-Path $outputDir $filename
    Invoke-WebRequest -Uri $url -Headers @{ Authorization = "Bearer $pat" } -OutFile $outPath
    Write-Host "Downloaded: $filename"
}
```

**Bash (macOS/Linux):**
```bash
pat="<JIRA_PAT>"
outputDir=".docs/agentic-logs/<TICKET_ID>/ticket-images"

# Assuming $response contains the JSON from Step 3
echo "$response" | jq -r '.fields.attachment[] | "\(.content) \(.filename)"' | while read url filename; do
    curl -s -H "Authorization: Bearer $pat" -o "$outputDir/$filename" "$url"
    echo "Downloaded: $filename"
done
```

For each attachment:
- `filename` - Original filename
- `content` - Download URL (requires Bearer auth)
- `mimeType` - File type (e.g., `image/png`)
- `created` - Upload timestamp

**Update all image references in the markdown** to use relative paths:
- `!image.png!` → `![image](ticket-images/image.png)`
- `!Screenshot 2026-02-12.png|thumbnail!` → `![Screenshot 2026-02-12.png](ticket-images/Screenshot%202026-02-12.png)`

**URL-encode filenames** with spaces or special characters in the path.

### Step 7b: Download Embedded Confluence Images

JIRA tickets often embed images hosted on Confluence rather than attaching them directly. These appear in the description, acceptance criteria, or comments as:
- JIRA markup: `!https://confluence.srv.westpac.com.au/download/attachments/...!`
- Rendered HTML: `<img src="https://confluence.srv.westpac.com.au/download/attachments/..." />`

**After parsing the description, acceptance criteria, and comments**, scan for Confluence image URLs matching the pattern:
```
https://confluence.srv.westpac.com.au/download/attachments/<pageId>/<filename>?api=v2
```

**IMPORTANT:** JIRA and Confluence use **separate PATs**. The JIRA PAT will NOT authenticate against Confluence (it returns an HTML login page instead of the image). Read `CONFLUENCE_PAT` from the project `.env` file for these downloads.

**Download each embedded Confluence image** to the same `ticket-images/` directory using the Confluence PAT:

**PowerShell (Windows):**
```powershell
$cpat = "<CONFLUENCE_PAT>"
$outputDir = ".docs/agentic-logs/<TICKET_ID>/ticket-images"

# Extract Confluence image URLs from raw description + acceptance criteria
$allText = $response.fields.description + " " + $response.fields.customfield_10201
$confluenceImageUrls = [regex]::Matches($allText, 'https://confluence\.srv\.westpac\.com\.au/download/attachments/\d+/[^|!\s]+') | ForEach-Object { $_.Value }

$confluenceImageUrls | Select-Object -Unique | ForEach-Object {
    $url = $_
    $filename = [System.Uri]::UnescapeDataString(($url -split '/')[-1] -replace '\?.*$', '')
    $outPath = Join-Path $outputDir $filename
    Invoke-WebRequest -Uri $url -Headers @{ Authorization = "Bearer $cpat" } -OutFile $outPath
    Write-Host "Downloaded Confluence image: $filename"
}

# Verify downloads are actual images, not HTML login pages
Get-ChildItem $outputDir -Filter *.png | ForEach-Object {
    $firstLine = Get-Content $_.FullName -TotalCount 1 -ErrorAction SilentlyContinue
    if ($firstLine -match '<!DOCTYPE') {
        Write-Warning "$($_.Name) is an HTML page, not an image — Confluence PAT may be invalid"
    }
}
```

**Bash (macOS/Linux):**
```bash
cpat="<CONFLUENCE_PAT>"
outputDir=".docs/agentic-logs/<TICKET_ID>/ticket-images"

# Extract Confluence image URLs from raw fields
allText="$description $acceptanceCriteria"
echo "$allText" | grep -oP 'https://confluence\.srv\.westpac\.com\.au/download/attachments/\d+/[^\s|!]+' | sort -u | while read url; do
    filename=$(echo "$url" | sed 's|.*/||; s|?.*||' | python3 -c "import sys, urllib.parse; print(urllib.parse.unquote(sys.stdin.read().strip()))")
    curl -s -H "Authorization: Bearer $cpat" -o "$outputDir/$filename" "$url"
    echo "Downloaded Confluence image: $filename"
done
```

**Update all Confluence image references in the markdown** to use relative paths:
- `![alt](https://confluence.srv.westpac.com.au/download/attachments/.../image.png?api=v2)` → `![alt](ticket-images/image.png)`

> **Note:** Image analysis is not supported. Claude Opus 4.5 in GitHub Copilot does not have vision capabilities. Images are downloaded for manual review only.

### Step 8: Create Output File

Create `.docs/agentic-logs/<TICKET_ID>/ticket.md` with this structure:

```markdown
# <KEY>: <SUMMARY>

> **Source:** https://jira.srv.westpac.com.au/browse/<KEY>
> **Retrieved:** <current datetime>

## Overview

| Field | Value |
|-------|-------|
| **Status** | <status> |
| **Type** | <issuetype> |
| **Priority** | <priority> |
| **Assignee** | <assignee or "Unassigned"> |
| **Reporter** | <reporter> |
| **Created** | <formatted date> |
| **Updated** | <formatted date> |
| **Labels** | <comma-separated labels or "None"> |
| **Components** | <comma-separated components or "None"> |

---

## Description

<Full description converted to Markdown - NO REDACTION>

---

## Acceptance Criteria

<Full acceptance criteria converted to Markdown - NO REDACTION>

---

## Comments

<All comments in reverse chronological order (newest first) - NO REDACTION>

---

*Document generated by JIRA Fetch Skill*
```

### Step 9: Return Result

After creating the file and downloading attachments, return:
- `.docs/agentic-logs/<TICKET_ID>/ticket.md` - Main ticket document
- `.docs/agentic-logs/<TICKET_ID>/ticket-images/` - Downloaded attachments folder

## Error Handling

| Error | Cause | Resolution |
|-------|-------|------------|
| 401 Unauthorized | PAT invalid or expired | Regenerate PAT in JIRA profile settings |
| 404 Not Found | Ticket doesn't exist or no access | Verify ticket ID and permissions |
| Connection Failed | Network/VPN issue | Ensure VPN is connected to access `jira.srv.westpac.com.au` |
| Missing `.env` file | No PAT configured | Create the project `.env` file with `JIRA_PAT="<your-pat>"` |

## Notes

- JIRA Server uses Bearer token authentication (not Basic Auth like JIRA Cloud)
- The `customfield_10201` field contains Acceptance Criteria
- Comments are returned with `expand=renderedFields` for proper formatting
- All content must be preserved in full - never truncate or summarize
