# Task Development Workflow

A composable Copilot agent workflow for multi-phase feature development with explicit session boundaries: analyse → plan → implement.

## Overview

This workflow enforces a disciplined development process where each phase runs in its own session, producing a document artifact that the next phase consumes. A recovery agent handles scope changes, blockers, and rollbacks.

```
┌────────────────────┐     ┌────────────────────┐     ┌────────────────────┐
│  TASK ANALYSIS     │     │  TASK PLANNING      │     │  TASK               │
│                    │ ──▶ │                     │ ──▶ │  IMPLEMENTATION     │
└────────────────────┘     └────────────────────┘     └────────────────────┘
        │                          │                          │
        ▼                          ▼                          ▼
  analysis.md              implementation-plan.md      Working code changes
  - Problem definition     - Phased steps              - Tests pass
  - Affected components    - Testing strategy           - Quality gates met
  - Risks & edge cases     - Rollback procedures        - Progress tracked
                                                              │
                                                    ┌─────────┴──────────┐
                                                    │  TASK RECOVERY     │
                                                    │  (on error/scope   │
                                                    │   change/blocker)  │
                                                    └────────────────────┘
```

### Key Design Principles

- **Session Boundaries** — Each phase stops and prompts the user to start a new session, preventing context overflow.
- **Questions First** — No files are created until all clarifying questions are answered.
- **Confidence Checkpoints** — Agents assess and report confidence at every major decision point.
- **Recovery Path** — Dedicated agent handles errors, scope changes, and rollbacks with structured handoffs.

## Agents

| Agent | Purpose |
|-------|--------|
| **Task Analysis** | Investigates WHAT needs to change — problem, components, risks. Produces `analysis.md` |
| **Task Planning** | Transforms analysis into HOW — phased steps, testing strategy, rollback. Produces `implementation-plan.md` |
| **Task Implementation** | Executes the approved plan phase by phase with quality gates |
| **Task Recovery** | Handles errors, scope changes, blockers — routes back to analysis, planning, or implementation |

### Agent Handoff Graph

```
task-analysis
  └──▶ task-planning
         ├──▶ task-implementation
         │      ├──▶ task-recovery ──▶ (analysis | planning | implementation)
         │      └──▶ task-planning  (plan revision)
         └──▶ task-analysis  (analysis revision)
```

## Skills & Prompts

| Type | Name | Purpose |
|------|------|---------|
| **Skill** | jira-fetch | Fetches JIRA ticket details via REST API |
| **Prompt** | `jira-ticket` | User-invokable prompt to fetch and display a JIRA ticket |

## Usage

### Recommended Flow (Session per Phase)

**Session 1 — Analysis:**
```
[Agent: Task Analysis]
You: Implement JIRA-123: Add payment retry logic
Agent: [investigates codebase, asks clarifying questions]
Agent: Here's my analysis. Please review and start a new session for planning.
```

**Session 2 — Planning:**
```
[Agent: Task Planning]
You: Create the implementation plan from analysis
Agent: [reads analysis.md, designs phased plan]
Agent: Here's the plan. Please review and start a new session for implementation.
```

**Session 3 — Implementation:**
```
[Agent: Task Implementation]
You: Execute the implementation plan
Agent: [follows plan phase by phase, runs tests, reports progress]
```

### Direct Phase Invocation

Select any agent independently from the agents dropdown:

| Agent | When to Use |
|-------|------------|
| **Task Analysis** | Analyse a new task |
| **Task Planning** | Plan from an existing `analysis.md` |
| **Task Implementation** | Execute from an existing `implementation-plan.md` |
| **Task Recovery** | Handle an error or scope change |

### Via Copilot CLI

```bash
# Interactive — select agent from list
copilot
> /agent            # pick "Task Analysis", "Task Planning", etc.

# Programmatic
copilot --agent=task-analysis -p "Analyse JIRA-123: Add payment retry logic"
copilot --agent=task-planning -p "Create implementation plan from analysis"
copilot --agent=task-implementation -p "Execute the implementation plan"
```

### JIRA Integration

Fetch ticket details before starting:

```
/jira-ticket ticketId=PROJ-123
```

Requires `JIRA_PAT` in `.github/.env`.

## Workflow Phases

### Phase 1: Analysis

The **task-analysis** agent investigates the task:

1. Gathers requirements and context from user
2. Scans codebase for affected components
3. Maps dependencies and impact
4. Identifies risks and edge cases
5. Writes `analysis.md` with findings

**Output:** `.docs/agentic-logs/<JIRA-ISSUE>/analysis.md`

### Phase 2: Planning

The **task-planning** agent creates an actionable plan:

1. Reviews `analysis.md`
2. Breaks work into ordered phases
3. Specifies testing strategy per phase
4. Documents rollback procedures
5. Writes `implementation-plan.md`

**Output:** `.docs/agentic-logs/<JIRA-ISSUE>/implementation-plan.md`

### Phase 3: Implementation

The **task-implementation** agent executes the plan:

1. Verifies plan exists and is approved
2. Follows phases in order — no deviation without approval
3. Runs tests after each change
4. Updates progress in the plan document
5. Hands off to recovery agent if issues arise

### Recovery

The **task-recovery** agent handles exceptional situations:

- Incomplete or incorrect analysis → routes back to analysis
- Scope changes mid-implementation → routes back to planning
- Test failures revealing design flaws → revises plan
- Blocked tasks → documents blockers, suggests alternatives

## Project Structure

```
src/agents/task-development/
├── task-analysis.md                   # Phase 1: Investigation source
├── task-planning.md                   # Phase 2: Plan creation source
├── task-implementation.md             # Phase 3: Code execution source
└── task-recovery.md                   # Error/scope recovery source

src/skills/
└── jira-fetch.md                      # JIRA REST API skill source

src/prompts/
└── jira-ticket.md                     # Fetch JIRA ticket prompt source

# Generated output (via build.js):
copilot/agents/task-analysis.agent.md
copilot/agents/task-planning.agent.md
copilot/agents/task-implementation.agent.md
copilot/agents/task-recovery.agent.md
copilot/skills/jira-fetch/SKILL.md
copilot/prompts/jira-ticket.prompt.md
amp/.agents/skills/task-analysis/SKILL.md
amp/.agents/skills/task-planning/SKILL.md
amp/.agents/skills/task-implementation/SKILL.md
amp/.agents/skills/task-recovery/SKILL.md
amp/.agents/skills/jira-fetch/SKILL.md
```

### Artifacts (created at runtime)

```
.docs/agentic-logs/<JIRA-ISSUE>/
├── ticket.md                # JIRA ticket details (fetched by jira-fetch skill)
├── analysis.md              # Task investigation (Phase 1)
└── implementation-plan.md   # Phased implementation plan (Phase 2)
```

## Installing into a Target Repo

```bash
# Install foundation first (one-time)
node tools/install-agents/install-agent.js foundation --tool=copilot

# Install task-development
node tools/install-agents/install-agent.js task-development --tool=copilot

# Install for Amp
node tools/install-agents/install-agent.js task-development --tool=amp

# Install for both
node tools/install-agents/install-agent.js task-development --tool=both
```

See [compose.md](../compose.md) for full installation instructions.
