# Repo Scanner Workflow

A composable Copilot agent workflow that scans a repository and auto-populates `.github/instructions/` files with discovered project context.

## Overview

This workflow orchestrates a suite of specialised sub-agents that each analyse a different aspect of the codebase. Each sub-agent writes its findings into the corresponding instruction file created by repo-init.

```
┌──────────────────────────────────────────────────────────┐
│                   REPO SCANNER (orchestrator)            │
│                                                          │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐   │
│  │ Structure│ │  Build   │ │ Testing  │ │ Patterns │   │
│  │ Scanner  │ │ Scanner  │ │ Scanner  │ │ Scanner  │   │
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘   │
│       │             │            │             │         │
│  ┌────┴─────┐ ┌────┴─────┐ ┌────┴─────┐ ┌────┴─────┐   │
│  │ Domain  │ │Workflows│ │Westpac UI│ │Multiverse│   │
│  │ Scanner │ │ Scanner │ │ Scanner  │ │UI Scanner│   │
│  └─────────┘ └─────────┘ └─────────┘ └─────────┘   │
└──────────────────────────────────────────────────────────┘
                          │
                          ▼
              .github/instructions/ (populated)
```

### Key Design Principles

- **Sub-Agent Delegation** — Each scanner focuses on a single concern, preventing context overflow.
- **Idempotent** — Can be re-run safely; sub-agents overwrite their sections in instruction files.
- **Conditional Scanners** — UI-specific scanners (Westpac UI, Multiverse UI) only run when relevant dependencies are detected.
- **Extensible** — Additional library-specific scanners (e.g. Mesh) can be added following the same pattern as the Westpac UI and Multiverse UI scanners: create a `repo-scanner-<library>.agent.md` sub-agent and a corresponding fetch skill.

## Agents

| Agent | Purpose |
|-------|---------|
| **Repository Scanner** | Top-level orchestrator — delegates to all sub-agents |
| **Structure Scanner** | Analyses repo layout → `repo_overview.instructions.md` |
| **Build & Dependencies** | Analyses build system → `development_standards.instructions.md` |
| **Testing Scanner** | Analyses test setup → `testing_approach.instructions.md` |
| **Patterns Scanner** | Analyses code conventions → `development_standards.instructions.md` |
| **Domain Scanner** | Analyses domain context → `project_context.instructions.md` + `usage_patterns.instructions.md` |
| **Workflows Scanner** | Analyses CI/CD → `workflows.instructions.md` |
| **Westpac UI Scanner** | *(conditional)* Analyses `@westpac/ui` usage → `westpac-ui.instructions.md` |
| **Multiverse UI Scanner** | *(conditional)* Analyses `multiverse-ui-common-library` usage → `multiverse-ui.instructions.md` |

## Skills

| Skill | Purpose |
|-------|---------|
| **westpac-ui-fetch** | Fetches Westpac UI component documentation |
| **multiverse-ui-fetch** | Fetches Multiverse UI component documentation |

## Usage

### Full Scan

1. Open the Chat view (`Ctrl+Alt+I`)
2. Select **Repository Scanner** from the agents dropdown
3. Type your prompt (e.g., "Scan this repository")

The orchestrator runs all applicable sub-agents sequentially. Conditional scanners are skipped if their dependencies aren't detected.

### Individual Sub-Agents

The orchestrator provides handoff buttons for individual scans:

- **Run Structure Scan** — Repo layout and organisation
- **Run Build Scan** — Dependencies and build system
- **Run Testing Scan** — Test framework and patterns
- **Run Patterns Scan** — Code conventions and style
- **Run Domain Scan** — Business context and usage
- **Run Workflows Scan** — CI/CD and release process

### Example Flow

```
[Agent: Repository Scanner]
You: Scan this repository
Agent: [assesses confidence, begins scanning]
  → Structure Scanner: analyses folder layout
  → Build Scanner: reads package.json / pom.xml / build.gradle
  → Testing Scanner: discovers test config and patterns
  → Patterns Scanner: identifies naming conventions
  → Domain Scanner: extracts business terminology
  → Workflows Scanner: reads CI/CD pipeline configs
Agent: Scan complete. All instruction files have been populated.
```

## Prerequisites

- The target repo must have the **foundation** package installed first (provides the template instruction files)
- The workspace must be open in VS Code with the target repo

### Via Copilot CLI

```bash
# Interactive — select agent from list
copilot
> /agent            # pick "Repository Scanner"

# Programmatic
copilot --agent=repo-scanner -p "Scan this repository"
```

## Project Structure

```
src/agents/repo-scanner/
├── repo-scanner.md                    # Orchestrator source
├── scanner-structure.md               # Repo layout
├── scanner-build.md                   # Build & dependencies
├── scanner-testing.md                 # Test framework
├── scanner-patterns.md                # Code conventions
├── scanner-domain.md                  # Business domain
├── scanner-workflows.md               # CI/CD pipelines
├── scanner-westpac-ui.md              # Westpac UI (conditional)
└── scanner-multiverse-ui.md           # Multiverse UI (conditional)

src/skills/
├── westpac-ui-fetch.md                # Westpac UI docs fetcher
└── multiverse-ui-fetch.md             # Multiverse UI docs fetcher

# Generated output (via build.js):
copilot/agents/repo-scanner.agent.md
copilot/agents/repo-scanner-structure.agent.md
copilot/agents/repo-scanner-build.agent.md
copilot/agents/repo-scanner-testing.agent.md
copilot/agents/repo-scanner-patterns.agent.md
copilot/agents/repo-scanner-domain.agent.md
copilot/agents/repo-scanner-workflows.agent.md
copilot/agents/repo-scanner-westpac-ui.agent.md
copilot/agents/repo-scanner-multiverse-ui.agent.md
copilot/skills/westpac-ui-fetch/SKILL.md
copilot/skills/multiverse-ui-fetch/SKILL.md
amp/.agents/skills/repo-scanner/SKILL.md
amp/.agents/skills/repo-scanner-build/SKILL.md
...etc
```

### Artifacts (created at runtime)

```
.github/instructions/                          (Copilot)
├── repo_overview.instructions.md          # ← Structure Scanner
├── development_standards.instructions.md  # ← Build + Patterns Scanners
├── testing_approach.instructions.md       # ← Testing Scanner
├── project_context.instructions.md        # ← Domain Scanner
├── usage_patterns.instructions.md         # ← Domain Scanner
├── workflows.instructions.md             # ← Workflows Scanner
├── westpac-ui.instructions.md            # ← Westpac UI Scanner (if applicable)
└── multiverse-ui.instructions.md         # ← Multiverse UI Scanner (if applicable)
```

## Installing into a Target Repo

Requires the **foundation** package first:

```bash
# Install foundation + repo-scanner for Copilot
node tools/install-agents/install-agent.js repo-scanner --tool=copilot

# Install for Amp
node tools/install-agents/install-agent.js repo-scanner --tool=amp

# Install for both
node tools/install-agents/install-agent.js repo-scanner --tool=both
```

See [compose.md](../compose.md) for full installation instructions.
