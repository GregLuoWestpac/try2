# Code Review Workflow

A composable Copilot agent workflow that runs the AI-powered `pr-review` pipeline against your current branch and presents findings interactively.

## Overview

This workflow wraps the `tools/pr-review` CLI, providing a conversational interface for automated code review. It supports three review depths and can optionally post results to Bitbucket.

```
┌────────────────────┐     ┌────────────────────┐     ┌────────────────────┐
│  DETERMINE         │     │  RUN PR-REVIEW     │     │  PRESENT           │
│  PARAMETERS        │ ──▶ │  CLI PIPELINE      │ ──▶ │  FINDINGS          │
└────────────────────┘     └────────────────────┘     └────────────────────┘
        │                          │                          │
        ▼                          ▼                          ▼
  Review depth            JSON results from          Executive summary
  Cache / Bitbucket       multi-stage pipeline       + prioritised issues
```

### Key Design Principles

- **Three Review Depths** — Quick, standard, and deep modes to match change complexity.
- **Interactive Presentation** — Findings are prioritised and the agent offers to fix issues.
- **CLI-Backed** — All analysis is performed by the `pr-review` pipeline; the agent is the interface.

## Agents

| Agent | Purpose |
|-------|--------|
| **Code Review** | Runs the pr-review CLI, interprets results, presents findings interactively |

## Skills

| Skill | Purpose |
|-------|---------|
| **pr-review-cli** | Handles CLI invocation, JSON parsing, and structured output |

## Usage

### Via Agent (Chat View)

1. Open the Chat view (`Ctrl+Alt+I`)
2. Select **Code Review** from the agents dropdown
3. Type your prompt

The agent determines review depth from your request:

| User Intent | CLI Flags | When to Use |
|-------------|-----------|-------------|
| Quick / fast / glance | `--simple` | Small changes, typo fixes |
| Standard / default | _(none)_ | Normal feature work, most PRs |
| Deep / thorough | `--complex` | Architecture changes, large PRs |

### Via Copilot CLI

Custom agents are fully supported in Copilot CLI (the `copilot` command):

```bash
# Interactive — select from available agents
copilot
> /agent            # pick "Code Review" from the list

# Natural language — CLI auto-infers the agent
copilot
> Use the code-review-westpac agent to review my changes

# Programmatic — specify agent and prompt directly
copilot --agent=code-review-westpac -p "Review my changes"
```

The CLI reads agent files from `.github/agents/` in your repo.

### Example Flows

**Quick review:**
```
[Agent: Code Review]
You: Quick review of my changes
Agent: [runs --simple, presents summary]
```
**Post to Bitbucket:**
```
[Agent: Code Review]
You: Review and post to Bitbucket
Agent: [runs review, posts comments to PR]
```

## Prerequisites

- The workspace must be a **git repository** with changes relative to a base branch
- `tools/pr-review` must be installed (`cd tools/pr-review && npm install`)

### Bitbucket Integration (Optional)

To post reviews to Bitbucket PRs:

1. Add `BITBUCKET_PAT="<your-token>"` to `.github/.env`
2. Configure `pr_review_bot.yaml.local` in repo root or `~/.pr_review_bot.yaml.local`:
   ```yaml
   bitbucket:
     enabled: true
     baseUrl: 'https://bitbucket.example.com'
     project: 'PROJECT_KEY'
     repo: 'repository-slug'
   ```

## Project Structure

```
src/agents/code-review-westpac/
└── code-review-westpac.md                   # Agent source (tool-agnostic)

src/skills/
└── pr-review-cli.md                 # CLI invocation skill source

src/prompts/
└── code-review.md                   # Prompt source

# Generated output (via build.js):
copilot/agents/code-review-westpac.agent.md
copilot/skills/pr-review-cli/SKILL.md
copilot/prompts/code-review.prompt.md
amp/.agents/skills/code-review-westpac/SKILL.md
amp/.agents/skills/pr-review-cli/SKILL.md
```

## Installing into a Target Repo

```bash
# Install for Copilot
node tools/install-agents/install-agent.js code-review-westpac --tool=copilot

# Install for Amp
node tools/install-agents/install-agent.js code-review-westpac --tool=amp

# Install for both
node tools/install-agents/install-agent.js code-review-westpac --tool=both
```

See [compose.md](../compose.md) for full installation instructions.
