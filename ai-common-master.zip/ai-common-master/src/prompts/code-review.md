# Code Review

Review the code changes on my current branch.

## Instructions

1. Determine the review depth based on the user's request:
   - If they said "quick", "fast", or "glance" → use `--simple`
   - If they said "deep", "thorough", or "detailed" → use `--complex`
   - Otherwise → use default (standard depth)

2. Run the **PR Review CLI** skill with:
   - `--output json` (always)
   - `--no-bitbucket` (always, unless user asks to post)
   - The appropriate depth flag

3. Present the results clearly:
   - Start with an executive summary (status, file count, issue counts)
   - Show high-priority issues first with full details
   - Summarise medium and low issues
   - Highlight positive observations
   - Offer to help fix any issues found
