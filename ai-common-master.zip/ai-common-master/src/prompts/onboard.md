# Onboard

Add or refresh ai-common agents and skills in this repository.

## Security — Token Handling

**CRITICAL:** The `BITBUCKET_PAT` token is a secret. You must **never** reveal, repeat, display, log, or include the actual token value in **any** output — this includes terminal commands, chat responses, **and your internal thinking/reasoning**. Always reference it exclusively via the environment variable name (`$env:BITBUCKET_PAT` or `$BITBUCKET_PAT`). If a tool call returns output containing a token value, do **not** echo it back. When writing the token to a file (e.g. Amp settings), use a single write operation and do **not** include the value in your reasoning.

## Instructions

1. Check that `tools/install-agents/install-agent.js` exists.
   - If missing, bootstrap automatically:
     a. Verify the `BITBUCKET_PAT` environment variable is set by running `node .github/skills/check-pat/scripts/check-pat.js BITBUCKET_PAT`. **Never** echo, print, or reveal the token value anywhere — not in terminal output, chat messages, or thinking. If not set, explain how to create a Bitbucket Personal Access Token with **Read** repository permissions at https://bitbucket.srv.westpac.com.au and set the env var, then stop.
     b. Download `sync-ai-common.js` from Bitbucket into the repo root:
        - **Windows (PowerShell):**
          ```
          Invoke-WebRequest -Uri "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/A014A6/repos/ai-common/raw/tools/sync-ai-common.js?at=refs/heads/master" -Headers @{Authorization="Bearer $env:BITBUCKET_PAT"} -OutFile "sync-ai-common.js"
          ```
        - **macOS / Linux:**
          ```
          curl -fSL -H "Authorization: Bearer $BITBUCKET_PAT" "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/A014A6/repos/ai-common/raw/tools/sync-ai-common.js?at=refs/heads/master" -o sync-ai-common.js
          ```
     c. Run `node sync-ai-common.js` to download the installer tooling.
     d. Confirm `tools/install-agents/install-agent.js` now exists before continuing.

2. Run `node tools/install-agents/install-agent.js --list` to get the available packages and show them to the user.

3. Ask the user ALL of the following questions and **wait for their answers before proceeding to step 4**:
   - **Install everything** or **choose specific packages** from the list?
   - Which tool: **Copilot**, **Amp**, or **Both**?
   - What type of project: **generic** (default), **mfe**, **spa**, **widget**, or **api**?
     - `mfe` / `spa` / `widget` — Node.js frontend apps (enables pre-push hook, npm actions)
     - `api` — Java/backend APIs (skips npm-specific actions)
     - `generic` — framework-agnostic (safe default)

   > **⚠️ Do NOT proceed to step 4 until the user has explicitly answered ALL three questions above.**

4. Run the install commands based on their choices:
   - Everything: `node tools/install-agents/install-agent.js --tool=<tool> --target=<target>`
   - Specific packages: `node tools/install-agents/install-agent.js <package-name> --tool=<tool> --target=<target>` for each selected package
   - **Re-running is safe:** agents, skills, and prompts are always updated to the latest version. Instruction files (project context with user content) are protected and skipped if they already exist. Use `--force` to overwrite everything including instructions.

5. Clean up installer artifacts that are no longer needed:
   - Delete `sync-ai-common.js` from the repo root
   - Delete the `tools/install-agents/` directory

6. If the user chose **Amp** or **Both**, configure Amp settings:
   a. Determine the settings file path:
      - **All platforms:** `~/.config/amp/settings.json` (e.g. `C:\Users\<user>\.config\amp\settings.json` on Windows)
   b. Read the file if it exists. If it doesn't exist, create it with `{}`.
   c. Merge in the following keys (preserve any existing settings):
      - `amp.mcpServers.nodemcp` — set `command` to `"node"` and `args` to the absolute path of `tools/nodemcp/cli.js` in the current repo, plus `"--all"`.
   d. If `amp.bitbucketToken` is not already set, ask the user for their Bitbucket Personal Access Token and set `amp.bitbucketToken`. (They may already have `BITBUCKET_PAT` from step 1 — offer to reuse it.) **Never** include the token value in your thinking or response — write it directly to the file without repeating it.
   e. Ask the user if they are behind a corporate proxy. If yes, ask for the proxy URL and set `amp.proxy`.
   f. Write the updated JSON back to the settings file.

7. After installation, remind the user to:
   - Run **Repository Scanner** to fill in `<!-- TODO -->` placeholders in project context files
   - If Copilot was installed: copy `.github/.env.example` → `.github/.env` and fill in tokens (if code-review-westpac or defect-triage was installed)
