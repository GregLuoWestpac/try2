# Foundation (Repo Init)

The foundation layer for all agent workflows. Provides universal principles and template instruction files that other workflows depend on.

## Overview

This package is **always installed first** when setting up agents in a target repository. It establishes the universal agent behaviour (confidence assessment, principles) and creates placeholder instruction files that are later populated by repo-scanner or manually.

```
┌────────────────────┐     ┌────────────────────┐
│  INSTALL           │     │  POPULATE          │
│  FOUNDATION        │ ──▶ │  INSTRUCTION FILES │
└────────────────────┘     └────────────────────┘
        │                          │
        ▼                          ▼
  principles +               Run repo-scanner or
  instruction templates      fill manually
```

### What It Provides

| File | Purpose |
|------|---------|
| `principles` | Universal principles — confidence assessment protocol, investigation-first approach |
| `instruction templates` | Template files with `<!-- TODO -->` placeholders for project-specific content |

### Instruction File Templates

| Template | Content |
|----------|---------|
| `repo_overview` | Repository structure and organisation |
| `project_context` | Domain, terminology, business context |
| `development_standards` | Conventions, build system, dependencies |
| `testing_approach` | Testing framework and patterns |
| `usage_patterns` | Consumer integration and usage |
| `workflows` | CI/CD and release process |

## Project Structure

```
src/
├── principles.md                              # Universal agent principles source
└── project-context/
    ├── repo_overview.md                       # Repository structure template
    ├── project_context.md                     # Domain context template
    ├── development_standards.md               # Conventions & build template
    ├── testing_approach.md                    # Testing patterns template
    ├── usage_patterns.md                      # Consumer integration template
    └── workflows.md                           # CI/CD & release template

# Generated output (via install-agent.js):
copilot/
├── copilot-instructions.md                    # Universal principles (Copilot)
└── instructions/
    ├── repo_overview.instructions.md
    ├── project_context.instructions.md
    ├── development_standards.instructions.md
    ├── testing_approach.instructions.md
    ├── usage_patterns.instructions.md
    └── workflows.instructions.md

amp/
├── AGENTS.md                                  # Universal principles (Amp)
└── .agents/instructions/
    ├── repo_overview.md
    ├── project_context.md
    ├── development_standards.md
    ├── testing_approach.md
    ├── usage_patterns.md
    └── workflows.md
```

## Usage

```bash
# Install foundation for Copilot
node tools/install-agents/install-agent.js foundation --tool=copilot

# Install foundation for Amp
node tools/install-agents/install-agent.js foundation --tool=amp

# Install foundation for both
node tools/install-agents/install-agent.js foundation --tool=both
```

Then populate instruction files — choose one:
- **Automated:** Install repo-scanner and run it to auto-populate
- **Manual:** Replace `<!-- TODO -->` placeholders in each instruction file

This is the **first** package installed into any target repo. All other packages assume these files exist. See [compose.md](../compose.md) for full installation instructions.
