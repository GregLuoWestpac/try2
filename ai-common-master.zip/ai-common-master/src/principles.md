# AI Assistant Principles

## Purpose

<!-- TODO: Describe this repository's purpose and how AI assistants are used. Example:
"This repository is a [type] application that [does what]. AI assistants are used for
task development, code review, and test automation workflows." -->

## Confidence Assessment

Before making any changes, assess your understanding on a scale of 0-10:

| Score | Action |
|-------|--------|
| **0-5** | Stop. Ask clarifying questions before proceeding. |
| **6-8** | Pause. Ask targeted questions to fill knowledge gaps. |
| **9-10** | Proceed with implementation. |

At every required checkpoint, output exactly this block:

```text
🧭 Confidence Assessment [Checkpoint Name] - [Phase if applicable]
- Confidence Level: High/Medium/Low (N/10)
- Areas of uncertainty: [list any]
- Questions for user: [if any]
```

**Do NOT make edits until confidence >= 8.**

Confidence checks are required at all phase checkpoints defined by the active workflow.

**Factors to consider:**
- Is the scope clearly defined?
- Do I understand the expected outcome?
- Are there ambiguous requirements?
- Do I have sufficient context?

## CLI-First Execution

- Use shell commands for deterministic verification.
- Read files before editing them.
- Keep edits minimal and aligned to approved plan scope.
- Report command results succinctly with pass/fail status.

## Verification Gates

Before marking implementation complete, run:
<!-- TODO: Add project-specific verification commands, e.g.:
- `npm run test`
- `npm run build`
- `npm run test:jest` (for targeted Jest runs during intermediate steps)
-->

If any required script is missing or fails unexpectedly, stop and ask for guidance.

## Principles

1. **Ask before assuming** — When in doubt, ask.
2. **Investigate before acting** — Read files before making changes.
3. **Incremental progress** — Small, verifiable steps over large sweeping changes.
4. **Update documentation** — Keep project context files current with codebase changes.
5. **Reuse over create** — Prefer existing components, utilities, and patterns over creating new ones.

## Implementation Discipline

- Follow plan-first execution for non-trivial tasks.
- Capture baseline commit (`git rev-parse HEAD`) before substantial edits.
- Run verification after each significant change.
- Use halt-and-ask behavior for ambiguity, repeated failures, or security concerns.

## Halt Conditions

Halt and request user guidance when:
- confidence drops below 8/10,
- 3 consecutive failures occur for the same problem,
- tests fail with non-obvious fix,
- scope expands beyond approved plan,
- required external dependency/tool access is unavailable.

## Completion Report Format

Use this structure in final responses:

1. Summary of what changed.
2. Files changed.
3. Verification commands run and outcomes.
4. Residual risks/assumptions.
5. Next options (if applicable).

## Project Documentation

**IMPORTANT: ALWAYS READ THESE FILES BEFORE STARTING ANY WORK.**

Read the project context files for full project context:

| File | Content |
|------|---------|
| `repo_overview.md` | Repository structure |
| `project_context.md` | Domain and terminology |
| `development_standards.md` | Conventions and build system |
| `testing_approach.md` | Testing patterns |
| `workflows.md` | CI/CD and release process |
| `usage_patterns.md` | Consumer integration |
