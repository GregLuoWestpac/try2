# Development Standards

## Build System

### Gradle Configuration

| Property | Value |
|----------|-------|
| **Gradle Version** | 5.5 |
| **Wrapper Distribution** | `artifactory.srv.westpac.com.au/artifactory/gradle-distributions/gradle-5.5-bin.zip` |
| **Java Source Compatibility** | Java 9 |
| **Java Target Compatibility** | Java 9 |

### Key Plugins

| Plugin | Version | Purpose |
|--------|---------|---------|
| `java` | built-in | Java compilation |
| `checkstyle` | 8.20 | Code style enforcement |
| `net.researchgate.release` | 2.8.0 | Release management |
| `net.serenity-bdd.aggregator` | 2.0.43 | Report aggregation |
| `com.jfrog.artifactory` | 4.13.0 | Artifact publishing |
| `org.sonarqube` | 3.1.1 | Code quality analysis |

### Common Gradle Tasks

| Task | Description |
|------|-------------|
| `clean test` | Run all tests |
| `aggregate` | Generate Serenity reports |
| `checkstyleTest` | Run code style checks |
| `publishToJira` | Publish results to Jira |
| `publishToAlm` | Publish results to ALM |
| `artifactoryPublish` | Publish to Artifactory |

---

## File Naming Conventions

### Java Classes

| Component Type | Pattern | Examples |
|---------------|---------|----------|
| **Test Runners** | `<Feature>Runner.java` | `GCMRunner.java`, `VaultRunner.java` |
| **Page Objects** | `<Feature>Page.java` | `GCMDashboardPage.java`, `ChannelsAccountsPage.java` |
| **Step Definitions** | `<Feature>Steps.java` | `GCMDashboardSteps.java`, `VaultSteps.java` |
| **Glue Classes** | `<Feature>Glue.java` | `GCMDashboardGlue.java`, `VaultGlue.java` |
| **Model/POJO** | `<EntityName>.java` | `PaymentRequest.java`, `AccountDetails.java` |
| **Utility Classes** | `<Feature>Util.java` | `CommonUtil.java`, `DateUtil.java` |
| **Constants** | `<Feature>Constants.java` | `PayToConstants.java`, `ApiConstants.java` |

### Feature Files

| Category | Pattern | Examples |
|----------|---------|----------|
| **API Features** | `<FeatureName>.feature` | `Vault.feature`, `Insights.feature` |
| **E2E Features** | `<Application>.feature` | `ChannelsE2E.feature`, `GCM.feature` |
| **Portal Features** | `<Portal>_<Role>.feature` | `TLMPortal_Supervisor.feature` |

### Test Data Files

| Type | Pattern | Examples |
|------|---------|----------|
| **CSV Data** | `<Feature>.csv` | `Vault.csv`, `PaymentTest.csv` |
| **JSON Data** | `<feature>_<type>.json` | `payment_request.json` |
| **XML Input** | `emu_<type>_<scenario>.xml` | `emu_x2p1_008_TC1_x2p1.xml` |

---

## Code Naming Conventions

### Package Structure

```
au.com.westpac.dvs.<domain>.<component>
```

| Package | Purpose |
|---------|---------|
| `au.com.westpac.dvs.api.glue` | API step definition bindings |
| `au.com.westpac.dvs.api.model` | API data models/POJOs |
| `au.com.westpac.dvs.api.runners` | API test runners |
| `au.com.westpac.dvs.api.steps` | API step implementations |
| `au.com.westpac.dvs.ui.glue` | UI step definition bindings |
| `au.com.westpac.dvs.ui.pages` | Page Object classes |
| `au.com.westpac.dvs.ui.steps` | UI step implementations |
| `au.com.westpac.dvs.e2e.runners` | E2E test runners |
| `au.com.westpac.dvs.npp` | NPP payment testing |

### Method Naming

- **Style**: `camelCase`
- **Pattern**: Verb + descriptive action

```java
// Step methods
public void launchGCMApplication() throws Exception { }
public void provideCISkeyAndSearch(String ciskey) throws Exception { }
public void validateAccountDetailsBeforeAliasNameChange(String scenarioType) throws Exception { }

// Getter methods
public static Logger getLogger() { }
public static Map<String, String> initializeLocatorDataFile(String locatorFile) { }
```

### Variable Naming

| Type | Convention | Examples |
|------|------------|----------|
| Instance variables | `camelCase` | `configReader`, `webDriver` |
| Static variables | `camelCase` | `logger`, `environmentVariables` |
| Constants | `UPPER_SNAKE_CASE` | `FEATURE_NAME`, `CSV_TEST_DATA_FILE` |
| Final String constants | `UPPER_SNAKE_CASE` | `IDENTIFIER_PARTY_KEY`, `RESPONSE_MISSING` |

---

## Component Patterns

### Page Object Pattern

```java
public class GCMDashboardPage extends PageObject {
    
    private static Logger logger = null;
    ConfigReader configReader;
    private static EnvironmentVariables environmentVariables;
    public static WebDriver driver;
    
    // Action methods
    public void launchGCMApplication() throws Exception { }
    public void provideAccountNumber(String subscriptionKey) throws Exception { }
}
```

### Glue Class Pattern (Step Definitions)

```java
public class GCMDashboardGlue {
    
    @Steps()
    GCMDashboardSteps gcmDashboardSteps;
    
    @Before()
    public static void init() { }
    
    @Then(value = "GCM user is logged in successfully into GCM application$")
    public void launchGCMApplication() throws Exception {
        gcmDashboardSteps.launchGCMApplication();
    }
    
    @And(value = "I provide the (.*?) in the Financial Account section$")
    public void provideAccountNumber(String subscriptionKey) throws Exception {
        gcmDashboardSteps.provideAccountNumber(subscriptionKey);
    }
}
```

### Steps Implementation Pattern

```java
public class GCMDashboardSteps {
    
    GCMDashboardPage gcmDashboardPage;  // Page object composition
    ConfigReader configReader;
    
    @Step
    public void launchGCMApplication() throws Exception {
        gcmDashboardPage.launchGCMApplication();
    }
}
```

### Test Runner Pattern

```java
@RunWith(value = CucumberWithSerenity.class)
@CucumberOptions(
    features = {"src/test/resources/e2e/features/GCM-CCMP"},
    glue = {"au.com.westpac.dvs.api.glue", "au.com.westpac.dvs.ui.glue"})
public class GCMRunner {
}
```

### API Test Pattern

```java
public class VaultGlue extends AbstractCCMPGlue {
    
    private static final String FEATURE_NAME = "Vault";
    private static final String CSV_TEST_DATA_FILE = "Vault.csv";
    private String scenarioName;
    
    @Steps()
    private final VaultSteps vault = new VaultSteps(FEATURE_NAME, CSV_TEST_DATA_FILE);
    
    @Before()
    public void before(final Scenario scenario) throws IOException {
        scenarioName = scenario.getName();
    }
    
    @Given(value = "^I retrieve Baas application specific secrets from Vault (.*?)$")
    public void retrieveBaaSApplicationSecrets(final String profileScenario) {
        // implementation
    }
}
```

---

## Code Style Rules (Checkstyle)

### Import Order

1. `java.*` packages
2. `javax.*` packages
3. `org.*` packages
4. `com.*` packages

- Static imports come first
- Separate groups with blank lines
- Alphabetically sorted within groups
- No star imports (`AvoidStarImport`)
- No unused imports (`UnusedImports`)

### Size Limits

| Rule | Limit |
|------|-------|
| Line Length | 250 characters max |
| Method Length | 120 lines max |
| Method NCSS | 120 statements max |
| Executable Statements | 60 per method/constructor |
| Cyclomatic Complexity | 30 max |
| Throws Count | 2 max |

### Formatting Rules

| Rule | Configuration |
|------|---------------|
| Tab Width | 4 spaces |
| File Tab Character | Not allowed (use spaces) |
| Trailing Spaces | Not allowed |
| Empty Lines | One empty line between members |
| Left Curly | Same line as declaration |
| Right Curly | Same line for else/catch/finally |
| Need Braces | Required for all control structures |

---

## Locator File Format

UI element locators are stored in `.txt` files in `src/test/resources/ui/data/`. 

### File Format

Each line contains a locator definition in the format:
```
ElementName=locator_value
```

### Example Locator File (`w1cChannelsCustomerObjectLocator.txt`)

```properties
# Header Elements
Header_Logo=//img[@alt='Westpac Logo']
Header_Search_Icon=//button[@aria-label='Search']
Header_Notifications=//button[@data-testid='notifications-btn']

# Dashboard Elements  
Dashboard_Accounts_Tile=//div[@data-testid='accounts-tile']
Dashboard_View_Accounts_Btn=//button[contains(text(),'View accounts')]
Dashboard_Balance_Text=//span[@class='balance-amount']

# Form Elements
Input_Account_Number=//input[@id='accountNumber']
Input_BSB=//input[@name='bsb']
Dropdown_Account_Type=//select[@id='accountType']
Button_Submit=//button[@type='submit']
Button_Cancel=//button[text()='Cancel']

# Table Elements
Table_Accounts=//table[@data-testid='accounts-table']
Table_First_Row=//table[@data-testid='accounts-table']//tbody/tr[1]
Table_Row_Checkbox=//input[@type='checkbox' and @name='selectRow']

# Modal Elements
Modal_Confirmation=//div[@role='dialog']
Modal_Close_Btn=//button[@aria-label='Close modal']
Modal_Confirm_Btn=//div[@role='dialog']//button[text()='Confirm']
```

### Locator Naming Conventions

| Element Type | Prefix | Example |
|--------------|--------|---------|
| Buttons | `Button_`, `Btn_` | `Button_Submit`, `Btn_Cancel` |
| Input fields | `Input_`, `Txt_` | `Input_Username`, `Txt_Password` |
| Dropdowns | `Dropdown_`, `Select_` | `Dropdown_Country` |
| Tables | `Table_` | `Table_Accounts` |
| Modals | `Modal_` | `Modal_Confirmation` |
| Headers | `Header_` | `Header_Logo` |
| Links | `Link_` | `Link_ForgotPassword` |
| Labels | `Label_`, `Lbl_` | `Label_ErrorMessage` |

### Using Locators in Page Objects

```java
public void clickSubmitButton() throws Exception {
    String locator = "Button_Submit";
    String locatorValue = UIGenericHelper.getOneCorePageObjectLocatorValue(locator);
    UIGenericHelper.waitForElementToBeClickable(locator, locatorValue);
    UIGenericHelper.clickElement(locator, "xpath", locatorValue);
}
```

---

## UIGenericHelper API Reference

The `UIGenericHelper` class provides standardized methods for Selenium interactions. Located in `au.com.westpac.dvs.ui.util`.

### Element Interaction Methods

| Method | Purpose | Parameters |
|--------|---------|------------|
| `clickElement(locator, type, value)` | Click an element | locator name, locator type ("xpath"/"id"/"css"), locator value |
| `sendKeys(locator, type, value, text)` | Enter text into field | locator name, type, value, text to enter |
| `clearAndSendKeys(locator, type, value, text)` | Clear field then enter text | Same as sendKeys |
| `getText(locator, type, value)` | Get element text | locator name, type, value → returns String |
| `getAttribute(locator, type, value, attr)` | Get element attribute | locator name, type, value, attribute name |
| `selectByVisibleText(locator, type, value, text)` | Select dropdown option | locator name, type, value, visible text |
| `selectByValue(locator, type, value, optionValue)` | Select dropdown by value | locator name, type, value, option value |

### Wait Methods

| Method | Purpose | When to Use |
|--------|---------|-------------|
| `waitForElementToBeVisible(locator, value)` | Wait for element to be displayed | Before reading text, verifying element exists |
| `waitForElementToBeClickable(locator, value)` | Wait for element to be clickable | Before clicking buttons, links |
| `waitForElementToBeInvisible(locator, value)` | Wait for element to disappear | After closing modals, loading spinners |
| `performExplicitWait(milliseconds)` | Static wait (use sparingly) | When no better alternative exists |

### Locator Resolution

```java
// Get locator value from .txt file
String locatorValue = UIGenericHelper.getOneCorePageObjectLocatorValue("Button_Submit");

// Get locator from staff portal file
String staffLocatorValue = UIGenericHelper.getStaffPageObjectLocatorValue("Staff_Search_Btn");
```

### Example Usage

```java
public class ChannelsAccountsPage extends PageObject {

    // Click a button
    public void clickViewAccountsButton() throws Exception {
        String locator = "Dashboard_View_Accounts_Btn";
        String locatorValue = UIGenericHelper.getOneCorePageObjectLocatorValue(locator);
        UIGenericHelper.waitForElementToBeClickable(locator, locatorValue);
        UIGenericHelper.clickElement(locator, "xpath", locatorValue);
    }
    
    // Enter text into a field
    public void enterAccountNumber(String accountNum) throws Exception {
        String locator = "Input_Account_Number";
        String locatorValue = UIGenericHelper.getOneCorePageObjectLocatorValue(locator);
        UIGenericHelper.waitForElementToBeVisible(locator, locatorValue);
        UIGenericHelper.clearAndSendKeys(locator, "xpath", locatorValue, accountNum);
    }
    
    // Verify element text
    public void verifyAccountBalance(String expectedBalance) throws Exception {
        String locator = "Dashboard_Balance_Text";
        String locatorValue = UIGenericHelper.getOneCorePageObjectLocatorValue(locator);
        UIGenericHelper.waitForElementToBeVisible(locator, locatorValue);
        String actualBalance = UIGenericHelper.getText(locator, "xpath", locatorValue);
        assertThat(actualBalance).contains(expectedBalance);
    }
    
    // Select from dropdown
    public void selectAccountType(String accountType) throws Exception {
        String locator = "Dropdown_Account_Type";
        String locatorValue = UIGenericHelper.getOneCorePageObjectLocatorValue(locator);
        UIGenericHelper.waitForElementToBeClickable(locator, locatorValue);
        UIGenericHelper.selectByVisibleText(locator, "xpath", locatorValue, accountType);
    }
}
```

---

## Wait Strategy Guide

### When to Use Each Wait Type

| Scenario | Wait Method | Reason |
|----------|-------------|--------|
| **Before clicking buttons** | `waitForElementToBeClickable` | Ensures element is enabled and interactable |
| **Before reading text** | `waitForElementToBeVisible` | Ensures element is rendered with content |
| **Before entering text** | `waitForElementToBeVisible` | Ensures input field is ready |
| **After closing modals** | `waitForElementToBeInvisible` | Ensures overlay is removed |
| **After page navigation** | `waitForElementToBeVisible` on key element | Ensures new page is loaded |
| **Loading spinners** | `waitForElementToBeInvisible` | Wait for spinner to disappear |

### Wait Configuration

Waits are configured with:
- **Default timeout**: 10 seconds
- **Polling interval**: 2 seconds  
- **Retry on StaleElementReference**: 3 attempts

### Anti-Pattern: Avoid performExplicitWait()

```java
// ❌ BAD - Static wait, slows tests
UIGenericHelper.performExplicitWait(5000);
UIGenericHelper.clickElement(locator, "xpath", value);

// ✅ GOOD - Dynamic wait, faster and more reliable
UIGenericHelper.waitForElementToBeClickable(locator, value);
UIGenericHelper.clickElement(locator, "xpath", value);
```

---

## Error Handling Patterns

### Standard Try-Catch Pattern in Page Objects

```java
public void clickSubmitButton() throws Exception {
    String locator = "Button_Submit";
    try {
        String locatorValue = UIGenericHelper.getOneCorePageObjectLocatorValue(locator);
        UIGenericHelper.waitForElementToBeClickable(locator, locatorValue);
        UIGenericHelper.clickElement(locator, "xpath", locatorValue);
        UIGenericHelper.snap("Clicked submit button");
    } catch (Exception e) {
        UIGenericHelper.snap("Failed to click submit button");
        throw new Exception("Failed to click submit button: " + e.getMessage(), e);
    }
}
```

### Retry Pattern for Flaky Elements

```java
public void clickElementWithRetry(String locator) throws Exception {
    int maxRetries = 3;
    Exception lastException = null;
    
    for (int attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            String locatorValue = UIGenericHelper.getOneCorePageObjectLocatorValue(locator);
            UIGenericHelper.waitForElementToBeClickable(locator, locatorValue);
            UIGenericHelper.clickElement(locator, "xpath", locatorValue);
            return; // Success
        } catch (StaleElementReferenceException e) {
            lastException = e;
            if (attempt < maxRetries) {
                UIGenericHelper.performExplicitWait(1000);
            }
        }
    }
    throw new Exception("Failed after " + maxRetries + " attempts: " + lastException.getMessage());
}
```

### Validation with Graceful Failure

```java
public boolean isElementDisplayed(String locator) {
    try {
        String locatorValue = UIGenericHelper.getOneCorePageObjectLocatorValue(locator);
        UIGenericHelper.waitForElementToBeVisible(locator, locatorValue);
        return true;
    } catch (Exception e) {
        return false;
    }
}
```

---

## @Steps Injection Pattern

### Complete Glue Class Example

```java
package au.com.westpac.dvs.ui.glue;

import au.com.westpac.dvs.ui.steps.ChannelsDashboardSteps;
import au.com.westpac.dvs.ui.steps.ChannelsAccountsSteps;
import au.com.westpac.dvs.ui.util.UIGenericHelper;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.util.EnvironmentVariables;

public class ChannelsAccountsGlue {

    // Step class injections - Serenity creates instances automatically
    @Steps()
    ChannelsDashboardSteps channelsDashboardSteps;

    @Steps()
    ChannelsAccountsSteps channelsAccountsSteps;

    // Environment variables injection
    private static EnvironmentVariables environmentVariables;

    // Initialization hook - runs before each scenario
    @Before()
    public static void init() {
        UIGenericHelper.initializeLocatorDataFile("w1cChannelsCustomerObjectLocator.txt");
    }

    // Step definitions delegate to step classes
    @Given(value = "^User logs in from login page of W1C portal (.*)$")
    public void loginToPortal(String scenarioName) throws Exception {
        channelsDashboardSteps.login();
    }

    @Then(value = "^User verifies the View Accounts button on the accounts tile$")
    public void verifyViewAccountsButton() throws Exception {
        channelsDashboardSteps.verifyViewAccounts();
    }

    @And(value = "^User clicks header logo to redirect to dashboard$")
    public void clickHeaderLogo() throws Exception {
        channelsDashboardSteps.clickHeaderLogo();
    }

    @And(value = "^User selects account type filter (.*)$")
    public void selectAccountTypeFilter(String accountType) throws Exception {
        channelsAccountsSteps.selectAccountTypeFilter(accountType);
    }
}
```

### Steps Class with Page Object Composition

```java
package au.com.westpac.dvs.ui.steps;

import au.com.westpac.dvs.ui.pages.ChannelsDashboardPage;
import au.com.westpac.dvs.ui.pages.ChannelsAccountsPage;
import net.thucydides.core.annotations.Step;

public class ChannelsAccountsSteps {

    // Page objects are auto-instantiated by Serenity
    ChannelsDashboardPage channelsDashboardPage;
    ChannelsAccountsPage channelsAccountsPage;

    @Step
    public void login() throws Exception {
        channelsDashboardPage.sendUsername();
        channelsDashboardPage.sendPassword();
        channelsDashboardPage.clickSignOn();
    }

    @Step
    public void selectAccountTypeFilter(String accountType) throws Exception {
        channelsAccountsPage.clickAccountTypeDropdown();
        channelsAccountsPage.selectAccountType(accountType);
    }

    @Step
    public void verifyAccountsDisplayed() throws Exception {
        channelsAccountsPage.verifyAccountsTableLoaded();
    }
}
```

---

## Cucumber/Gherkin Conventions

### Feature File Structure

```gherkin
@tagLevel1 @tagLevel2
Feature: Feature Name Description

  @scenarioTag @jiraId
  Scenario Outline: Descriptive scenario name
    Given I retrieve Customer specific secrets from Vault <VaultScenario> for <User>
    And User logs in from login page of W1C portal <ScenarioName>
    When action step with <Parameter>
    Then verification step with <ExpectedResult>
    
    Examples:
      | VaultScenario                        | User       | ScenarioName       | Parameter | ExpectedResult |
      | Get W1C Application Specific Secrets | TestUser04 | DescriptiveTestName | value1    | result1        |
```

### Tag Conventions

| Tag Pattern | Purpose | Examples |
|-------------|---------|----------|
| `@PARSIFAL-xxxx` | JIRA issue reference | `@PARSIFAL-1702` |
| `@ART-xxxxx` | Artifact/test case ID | `@ART-61556` |
| `@issue:*` | Issue link | `@issue:PARSIFAL-1429` |
| `@Regression` | Regression test suite | |
| `@HealthCheck` | Health check tests | |
| `@E2E*` | End-to-end category | `@E2ENPPInward` |
| `@APIRegression` | API regression suite | |
| `@inward`/`@outward` | Payment direction | |

### Step Definition Patterns

```java
// Given steps - setup/preconditions
@Given(value = "^I retrieve Customer specific secrets from Vault (.*?) for (.*?)$")

// When steps - actions
@When(value = "^user clicks on the (.*?) icon$")

// Then steps - verifications
@Then(value = "^I validate the (.*?) transaction details$")

// And steps - continuation
@And(value = "^I provide the (.*?) in the (.*?) section$")
```

---

## Vault Secrets Steps Reference

### MANDATORY: Customer Portal Tests

All W1C Customer Portal test scenarios **MUST** begin with the Vault secrets retrieval step:

```gherkin
Given I retrieve Customer specific secrets from Vault <VaultScenario> for <User>
And User logs in from login page of W1C portal <ScenarioName>
```

### Required Examples Table Columns

When using the Vault step, include these columns in your Examples table:

| Column | Value | Description |
|--------|-------|-------------|
| `VaultScenario` | `Get W1C Application Specific Secrets` | Standard vault configuration |
| `User` | `TestUser04` (or other test user) | Test user credentials to retrieve |
| `ScenarioName` | Descriptive test name | Passed to login step |

### Complete Example

```gherkin
@ART-12345 @Regression
Scenario Outline: User validates payment activity on details page
  Given I retrieve Customer specific secrets from Vault <VaultScenario> for <User>
  And User logs in from login page of W1C portal <ScenarioName>
  When User navigates to the Payment Details page
  Then the Payment activity section is displayed

  Examples:
    | VaultScenario                        | User       | ScenarioName                    |
    | Get W1C Application Specific Secrets | TestUser04 | Payment_Activity_Validation_TC1 |
```

### API-Specific Secrets (Optional)

When tests require API validation after UI actions, add the API secrets step:

```gherkin
Given I retrieve W1C API specific secrets from Vault <APIVaultScenario>
```

**Example with both UI and API:**
```gherkin
Scenario Outline: User makes payment and validates via API
  Given I retrieve Customer specific secrets from Vault <VaultScenario> for <User>
  And User logs in from login page of W1C portal <ScenarioName>
  When User submits a payment
  Then user validates the success response on UI
  # API validation follows
  Given I retrieve W1C API specific secrets from Vault <APIVaultScenario>
  And I validate the transaction in 10x Insights

  Examples:
    | VaultScenario                        | User       | ScenarioName   | APIVaultScenario             |
    | Get W1C Application Specific Secrets | TestUser04 | Payment_Test_1 | Get W1C API Specific Secrets |
```

### ⚠️ Common Mistakes to Avoid

| ❌ Wrong | ✅ Correct |
|----------|-----------|
| `Given I retrieve W1C application specific secrets from Vault <VaultScenario>` | `Given I retrieve Customer specific secrets from Vault <VaultScenario> for <User>` |
| Missing `for <User>` parameter | Always include `for <User>` to specify test credentials |
| Missing `User` column in Examples | Include `User` column with test user value |
