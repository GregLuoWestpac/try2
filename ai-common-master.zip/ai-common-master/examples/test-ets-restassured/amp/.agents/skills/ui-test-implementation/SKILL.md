---
name: ui-test-implementation
description: Project-specific implementation patterns for UI BDD tests
---

# UI Test Implementation Skill

Project-specific patterns, paths, and sub-skill prompts for implementing UI BDD tests in this repository.

## When to Apply

- Implementing UI BDD test features or fixes
- Following an implementation plan
- Making UI test code changes of any scope

## Prerequisites

For complex tasks, ensure planning documents exist in `.docs/agentic-logs/<JIRA-ISSUE>/`:
- `test-cases.md` — Context, affected components, risks
- `implementation-plan.md` — Step-by-step plan with acceptance criteria

If these don't exist for a complex task, use `ui-test-planning` agent first.

## Workflow

### Step 1: Load Planning Context

If planning documents exist:
1. Read `.docs/agentic-logs/<JIRA-ISSUE>/implementation-plan.md`
2. Review acceptance criteria
3. Identify current phase/step to work on
4. Reference `.docs/agentic-logs/<JIRA-ISSUE>/test-cases.md` for risks and context

### Step 2: Pre-Implementation Checks

Before writing code:
- [ ] Confirm understanding of requirements (confidence > 8)
- [ ] Identify files to be modified (from implementation plan if available)
- [ ] Review existing patterns in affected areas
- [ ] Check Testing Strategy section for test requirements

### Step 3: Incremental Implementation

- Make one logical change at a time
- Commit progress incrementally
- Verify each change works before proceeding
- Update implementation plan progress as phases complete

### Step 4: Testing

After each significant change, run the test command (see Test Execution Command section below).

- Follow Testing Strategy from implementation plan
- Add tests for new functionality
- Ensure existing tests still pass
- Update tests if behavior intentionally changed

### Step 5: Linting & Formatting

- Fix any linting errors before completing
- Follow existing code style patterns

---

## Project Context

**Framework**: Selenium WebDriver + Cucumber BDD + Serenity
**Language**: Java 17+
**Build Tool**: Gradle
**Test Runner**: Cucumber JUnit

### Instruction Files
Load these for domain context:
- The project's **project_context** instruction file — Domain glossary, business context
- The project's **repo_overview** instruction file — Directory structure, project layout

## Implementation File Locations

| Artifact | Path |
|----------|------|
| Feature | `src/test/resources/e2e/features/<App>/<Feature>.feature` |
| **Locators** | `src/test/resources/ui/data/<portal>ObjectLocator.txt` |
| Page | `src/test/java/au/com/westpac/dvs/ui/pages/<Feature>Page.java` |
| Glue | `src/test/java/au/com/westpac/dvs/ui/glue/<Feature>Glue.java` |
| Steps | `src/test/java/au/com/westpac/dvs/ui/steps/<Feature>Steps.java` |
| Runner | `src/test/java/au/com/westpac/dvs/e2e/runners/<Feature>Runner.java` |
| Test Data | `src/test/resources/testData/<feature>.csv` |

## Layer Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Feature Files (.feature)                 │
│                    src/test/resources/e2e/features/         │
├─────────────────────────────────────────────────────────────┤
│                    Glue Classes (*Glue.java)                │
│                    au.com.westpac.dvs.ui.glue               │
├─────────────────────────────────────────────────────────────┤
│                    Step Classes (*Steps.java)               │
│                    au.com.westpac.dvs.ui.steps              │
├─────────────────────────────────────────────────────────────┤
│                    Page Objects (*Page.java)                │
│                    au.com.westpac.dvs.ui.pages              │
├─────────────────────────────────────────────────────────────┤
│                    Locator Files (*.txt)                    │
│                    src/test/resources/ui/data/              │
└─────────────────────────────────────────────────────────────┘
```

| Layer | Responsibility | Assertions? |
|-------|----------------|-------------|
| **Feature** | What to test (Gherkin scenarios) | No |
| **Glue** | Bind Cucumber steps to code | No |
| **Steps** | Business logic + assertions (Serenity Steps) | **Yes** |
| **Page** | UI interactions only (Page Objects) | No |

> **Rule**: Assertions belong in Steps layer only, never in Page Objects.

---

## Sub-Skill Prompts

Use these project-specific prompts when invoking sub-skills.

### Phase 1: Feature File

```
runSubagent:
  description: "Create feature file"
  prompt: |
    TASK: Create a Gherkin feature file for UI tests.
    
    1. READ the template: shared/templates/feature-template.gherkin
    2. READ the implementation plan: .docs/agentic-logs/<JIRA>/implementation-plan.md (Phase 1 section)
    3. USE the create_file tool to CREATE the file at: src/test/resources/e2e/features/<App>/<Feature>.feature
    4. Include tags: @<SuiteTag> @<JIRA>
    
    TAG REQUIREMENTS:
    - Suite Tag (MANDATORY): @Regression, @HealthCheck, @Smoke, or @Shakedown
    - JIRA Tag (optional): @<JIRA-KEY> for traceability
    
    IMPORTANT: You MUST use the create_file tool to write the file. Do NOT just output the code.
    
    Return: Confirm the file path created and scenario count.
```

### Phase 2: Locators

**Locator Storage Directory:** `src/test/resources/ui/data/`

```
runSubagent:
  description: "Add locators"
  prompt: |
    TASK: Add locators to the object locator file.
    
    LOCATOR DIRECTORY: src/test/resources/ui/data/
    
    1. READ the implementation plan: .docs/agentic-logs/<JIRA>/implementation-plan.md (Phase 2 section)
    2. READ the existing locator file: src/test/resources/ui/data/<portal>ObjectLocator.txt
       Files: w1cChannelsCustomerObjectLocator.txt, GCMObjectsLocator.txt, TLMObjectsLocator.txt
    3. USE the replace_string_in_file tool to APPEND the new locators to the file
    
    LOCATOR FORMAT: LocatorName=locatorType:locatorValue
    
    IMPORTANT: You MUST use file editing tools to modify the file. Do NOT just output the code.
    
    Return: Confirm count of locators added and target file path.
```

### Phase 3: Page Object

```
runSubagent:
  description: "Create Page Object"
  prompt: |
    TASK: Create a Page Object Java class.
    
    1. READ the template: shared/templates/pageobject-template.java
    2. READ the implementation plan: .docs/agentic-logs/<JIRA>/implementation-plan.md (Phase 3 section)
    3. READ one existing Page file for pattern reference:
       src/test/java/au/com/westpac/dvs/ui/pages/
    4. USE the create_file tool to CREATE: src/test/java/au/com/westpac/dvs/ui/pages/<Feature>Page.java
    
    REQUIREMENTS:
    - Extend PageObject
    - Use UIGenericHelper for element interactions
    - Use locator keys from Phase 2
    - NO assertions in Page Objects
    
    IMPORTANT: You MUST use the create_file tool to write the file. Do NOT just output the code.
    
    Return: Confirm file path and method count.
```

### Phase 4: Glue Class

```
runSubagent:
  description: "Create Glue class"
  prompt: |
    TASK: Create a Glue (step definitions) Java class.
    
    1. READ the template: shared/templates/glue-template.java
    2. READ the implementation plan: .docs/agentic-logs/<JIRA>/implementation-plan.md (Phase 4 section)
    3. READ one existing Glue file for pattern reference:
       src/test/java/au/com/westpac/dvs/ui/glue/
    4. USE the create_file tool to CREATE: src/test/java/au/com/westpac/dvs/ui/glue/<Feature>Glue.java
    
    REQUIREMENTS:
    - Package: au.com.westpac.dvs.ui.glue
    - Use @Steps to inject Steps class
    - Use Cucumber annotations (@Given, @When, @Then)
    - Delegate all logic to Steps class
    
    IMPORTANT: You MUST use the create_file tool to write the file. Do NOT just output the code.
    
    Return: Confirm file path and step count.
```

### Phase 5: Steps Class

```
runSubagent:
  description: "Create Steps class"
  prompt: |
    TASK: Create a Steps Java class.
    
    1. READ the template: shared/templates/steps-template.java
    2. READ the implementation plan: .docs/agentic-logs/<JIRA>/implementation-plan.md (Phase 5 section)
    3. READ one existing Steps file for pattern reference:
       src/test/java/au/com/westpac/dvs/ui/steps/
    4. USE the create_file tool to CREATE: src/test/java/au/com/westpac/dvs/ui/steps/<Feature>Steps.java
    
    REQUIREMENTS:
    - Package: au.com.westpac.dvs.ui.steps
    - Use @Step annotations for Serenity reporting
    - Inject Page Object
    - Place assertions HERE (not in Page Objects)
    
    IMPORTANT: You MUST use the create_file tool to write the file. Do NOT just output the code.
    
    Return: Confirm file path and method count.
```

### Phase 6: Runner

```
runSubagent:
  description: "Create Runner"
  prompt: |
    TASK: Create a Cucumber Runner Java class.
    
    1. READ the template: shared/templates/runner-template.java
    2. READ the implementation plan: .docs/agentic-logs/<JIRA>/implementation-plan.md (Phase 6 section)
    3. READ one existing Runner file for pattern reference:
       src/test/java/au/com/westpac/dvs/e2e/runners/
    4. USE the create_file tool to CREATE: src/test/java/au/com/westpac/dvs/e2e/runners/<Feature>Runner.java
    
    REQUIREMENTS:
    - Package: au.com.westpac.dvs.e2e.runners
    - Use @RunWith(CucumberWithSerenity.class)
    - Configure features path and glue packages
    
    IMPORTANT: You MUST use the create_file tool to write the file. Do NOT just output the code.
    
    Return: Confirm file path created.
```

---

## Test Execution Command

```bash
./gradlew clean aggregate test \
  --tests "au.com.westpac.dvs.e2e.runners.<RunnerClass>" \
  -Dcucumber.options="--tags @<TagName>" \
  -Denvironment=<environment> \
  --info
```

### Environment Options
- `sit1`, `sit2` — System Integration Testing
- `uat` — User Acceptance Testing
- `preprod` — Pre-production
- `e2eTenant2` — E2E test tenant

---

## Application Folders

| Application | Feature Folder | Locator File |
|-------------|----------------|---------------|
| Customer Portal | `W1C-ChannelsCustomerPortal/` | `w1cChannelsCustomerObjectLocator.txt` |
| Staff Portal | `W1C-ChannelsStaffPortal/` | `w1cChannelsStaffObjectLocator.txt` |
| GCM | `GCM-CCMP/` | `GCMObjectsLocator.txt` |
| TLM | `W1C-TLM-Portal/` | `TLMObjectsLocator.txt` |
| NPP Payment | `NPPPayment/` | varies |

---

## Tag Conventions

| Tag Type | Required | Purpose | Triggers Pipeline |
|----------|----------|---------|-------------------|
| **Suite Tag** | ✅ **MANDATORY** | Pipeline categorization | ✅ Yes |
| **JIRA Tag** | Optional | Traceability & local debugging | ❌ No |

**Suite Tags (choose one — REQUIRED):**
- `@Regression` — Full regression suite (most common)
- `@HealthCheck` — Critical path smoke tests
- `@Smoke` — Quick validation tests
- `@Shakedown` — Environment validation

### Locator Format

**Location:** `src/test/resources/ui/data/<app>ObjectLocator.txt`

**Format:** `LocatorName=locatorType:locatorValue`

```
Dashboard_Link=xpath://a[@data-testid='dashboard-link']
Welcome_message=xpath://h1[contains(text(),'Welcome')]
Accounts_Tile=css:.accounts-tile
Submit_Button=id:submit-btn
```

**Existing locator files:**
- `w1cChannelsCustomerObjectLocator.txt`
- `w1cChannelsStaffObjectLocator.txt`
- `GCMObjectsLocator.txt`
- `TLMObjectsLocator.txt`
- `AppianObjectsLocator.txt`
- `FISOVAObjectsLocator.txt`
- `OpenfinObjectsLocator.txt`
- `BankManagerObjectsLocator.txt`

---

## Best Practices

### Wait Strategy: Use Implicit Waits

**DO:** Configure implicit waits globally in Serenity configuration
```properties
# serenity.properties
serenity.timeout=60
webdriver.timeouts.implicitlywait=10000
```

**DON'T:** Use explicit waits like `Thread.sleep()` or `WebDriverWait` in test code
```java
// ❌ AVOID - Explicit waits make tests brittle and slow
Thread.sleep(5000);
new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(element));

// ✅ PREFERRED - Use UIGenericHelper which handles waits implicitly
UIGenericHelper.waitForElementToBeVisible(locator, locatorValue);
UIGenericHelper.clickElement(locator, "xpath", locatorValue);
```

### Element Locator Priority

| Priority | Locator Type | When to Use | Example |
|----------|--------------|-------------|---------|
| 1 | `id` | Always prefer if available | `id:submit-btn` |
| 2 | `data-testid` | When id not available | `xpath://*[@data-testid='login-btn']` |
| 3 | `name` | For form elements | `name:username` |
| 4 | `css` | For class-based selection | `css:.btn-primary` |
| 5 | `xpath` | Last resort, complex DOM | `xpath://div[@class='container']//button` |

**Guidelines:**
- **Avoid positional XPath** — `//div[3]/button[1]` breaks when DOM changes
- **Avoid text-based locators** — `//button[text()='Submit']` breaks with i18n
- **Avoid style-based locators** — `//div[@style='...']` breaks with CSS changes
- **Request `data-testid` attributes** — Collaborate with developers to add stable test hooks

### Page Object Pattern

```java
public class LoginPage extends PageObject {

    // ✅ Use constants for locator keys
    private static final String USERNAME_FIELD = "Username_Field";
    private static final String PASSWORD_FIELD = "Password_Field";
    private static final String LOGIN_BUTTON = "Login_Button";

    // ✅ Single responsibility - one action per method
    public void enterUsername(String username) throws Exception {
        UIGenericHelper.enterText(USERNAME_FIELD,
            UIGenericHelper.getOneCorePageObjectLocatorValue(USERNAME_FIELD), username);
    }

    // ✅ Combine atomic actions into meaningful workflows
    public void loginAs(String username, String password) throws Exception {
        enterUsername(username);
        enterPassword(password);
        clickLoginButton();
    }

    // ❌ AVOID - Methods that contain assertions
    // Page objects should interact, not verify
}
```

---

## Quality Checklist

### Implementation Checklist
- [ ] Feature file created with proper tags and Scenario Outline structure
- [ ] Glue class created with `@Steps` injection and step definition annotations
- [ ] Step class created with `@Step` annotations for reporting
- [ ] Page object class extends `PageObject` and uses `UIGenericHelper`
- [ ] Element locators added to appropriate locator file
- [ ] Locators use stable identifiers (id, data-testid) over fragile XPath
- [ ] No explicit waits (Thread.sleep, WebDriverWait) in test code
- [ ] Runner class created/updated with correct feature path and glue packages
- [ ] Test executes successfully

### Code Quality
- [ ] Changes are minimal and focused on the request
- [ ] Follows existing patterns in the codebase
- [ ] No dead code or commented-out blocks
- [ ] No hardcoded secrets or credentials

---

## Post-Implementation

1. **Update implementation plan**: Mark completed phases in `.docs/agentic-logs/<JIRA-ISSUE>/implementation-plan.md`
2. **Run tests to verify**:

```bash
./gradlew clean aggregate test \
  --tests "au.com.westpac.dvs.e2e.runners.<RunnerClass>" \
  -Dcucumber.options="--tags @<JIRA-ISSUE>" \
  -Denvironment=<environment> --info
```

3. **Cleanup**: Once tests pass, offer to delete planning documents in `.docs/agentic-logs/<JIRA-ISSUE>/`
