# Project Example: test-ets-restassured

Pre-generated instructions and skills for a **Selenium + RestAssured** test automation repository (W1C Test Automation).

## What Is This?

This folder contains a complete, ready-to-use set of AI assistant customisation files for a real test repo, organized in a three-layer architecture:

| Layer | Directory | Purpose |
|-------|-----------|---------|
| **Source** | `src/` | Tool-agnostic content — the single source of truth |
| **Copilot** | `copilot/` | Ready-to-copy into `.github/` for GitHub Copilot |
| **Amp** | `amp/` | Ready-to-copy into project root for Amp |

### What's in each layer

| Content | `src/` | `copilot/` | `amp/` |
|---------|--------|------------|--------|
| **Instructions** (6 files) | Generic `.md` files, no frontmatter | `.instructions.md` with `applyTo` frontmatter | — (use AGENTS.md or similar) |
| **Skills** (3 files) | Generic `.md`, no tool paths | `SKILL.md` with `.github/` paths | `SKILL.md` with `.agents/` paths |
| **Templates** (5 files) | Java/Gherkin templates | Copy of templates | — (reference from skills) |

## Directory Structure

```
examples/test-ets-restassured/
├── src/                              # Tool-agnostic content (source of truth)
│   ├── instructions/                 # Pre-populated project context
│   │   ├── project_context.md
│   │   ├── development_standards.md
│   │   ├── repo_overview.md
│   │   ├── workflows.md
│   │   ├── usage_patterns.md
│   │   └── testing_approach.md
│   ├── skills/                       # Project-specific skills
│   │   ├── ui-test-case-generation.md
│   │   ├── ui-test-planning.md
│   │   └── ui-test-implementation.md
│   └── shared/                       # Templates (Java/Gherkin)
│       └── templates/
│           ├── feature-template.gherkin
│           ├── pageobject-template.java
│           ├── runner-template.java
│           ├── glue-template.java
│           └── steps-template.java
├── copilot/                          # Ready-to-copy .github/ content
│   ├── instructions/                 # With applyTo frontmatter
│   │   ├── project_context.instructions.md
│   │   ├── development_standards.instructions.md
│   │   ├── repo_overview.instructions.md
│   │   ├── workflows.instructions.md
│   │   ├── usage_patterns.instructions.md
│   │   └── testing_approach.instructions.md
│   └── skills/                       # With .github/ paths
│       ├── ui-test-case-generation/SKILL.md
│       ├── ui-test-planning/SKILL.md
│       ├── ui-test-implementation/SKILL.md
│       └── shared/templates/         # Copy of templates
├── amp/                              # Ready-to-copy .agents/ content
│   └── .agents/
│       └── skills/
│           ├── ui-test-case-generation/SKILL.md
│           ├── ui-test-planning/SKILL.md
│           └── ui-test-implementation/SKILL.md
├── instructions/                     # (Legacy) Original Copilot-format files
├── skills/                           # (Legacy) Original Copilot-format skills
└── README.md
```

## How to Use

### For GitHub Copilot

Copy the `copilot/` contents into the target repo's `.github/` folder, then add the e2e-test-automation workflow agents:

**PowerShell:**
```powershell
$target = "<your-test-repo>"

# Copy instructions and skills
Copy-Item -Recurse -Force "examples/test-ets-restassured/copilot/instructions/*" "$target/.github/instructions/"
Copy-Item -Recurse -Force "examples/test-ets-restassured/copilot/skills/*" "$target/.github/skills/"

# Add agents from the e2e-test-automation workflow
Copy-Item -Recurse -Force "workflows/e2e-test-automation/.github/*" "$target/.github/"
```

**Bash:**
```bash
target="<your-test-repo>"

# Copy instructions and skills
cp -r examples/test-ets-restassured/copilot/instructions/* "$target/.github/instructions/"
cp -r examples/test-ets-restassured/copilot/skills/* "$target/.github/skills/"

# Add agents from the e2e-test-automation workflow
cp -r workflows/e2e-test-automation/.github/* "$target/.github/"
```

### For Amp

Copy the `amp/` contents into the target repo root:

**PowerShell:**
```powershell
$target = "<your-test-repo>"

# Copy Amp skills
Copy-Item -Recurse -Force "examples/test-ets-restassured/amp/.agents" "$target/"
```

**Bash:**
```bash
target="<your-test-repo>"

# Copy Amp skills
cp -r examples/test-ets-restassured/amp/.agents "$target/"
```

## How the Normal Flow Works

```
┌───────────────┐      ┌───────────────┐      ┌──────────────────────────┐
│  repo-init    │ ──▶  │ repo-scanner  │ ──▶ │ instructions/ populated  │
│  (templates)  │      │  (agents)     │      │ with repo-specific info  │
└───────────────┘      └───────────────┘      └──────────────────────────┘
```

1. **repo-init** — Copy `workflows/repo-init/.github/` into the target repo. This gives you `copilot-instructions.md` and `instructions/` templates with `<!-- TODO -->` placeholders.
2. **repo-scanner** — Run `@repo-scanner` in Copilot Chat. It scans the codebase and auto-populates the instruction files with discovered structure, patterns, domain context, etc.
3. **Add workflow agents** — Copy the workflow you need (e.g. `workflows/e2e-test-automation/.github/`) to get the agents.

This project example **skips steps 1–2** by providing the already-populated instruction files and skills.

## Agents

When combined with the e2e-test-automation workflow, you get these agents:

| Agent | Purpose |
|-------|---------|
| `ui-test-workflow` | Orchestrates the full workflow end-to-end *(see note below)* |
| `ui-test-case-generation` | Analyses requirements → produces BDD test cases (`test-cases.md`) |
| `ui-test-planning` | Plans implementation → produces `implementation-plan.md` |
| `ui-test-planning-locators` | Sub-agent for Phase 2 — element locator identification |
| `ui-test-planning-code` | Sub-agent for Phases 3–6 — Page/Glue/Steps/Runner design |
| `ui-test-implementation` | Implements the planned test code into actual files |

> **⚠️ Note on `ui-test-workflow`:** While this orchestration agent exists for convenience, it is **not recommended** for direct use. Because it coordinates all three phases in a single conversation, it consumes a very large amount of context — which can degrade output quality and hit token limits on complex test scenarios. Instead, run the agents individually in sequence: `@ui-test-case-generation` → `@ui-test-planning` → `@ui-test-implementation`.

## The Workflow

```
┌────────────────────┐      ┌────────────────────┐      ┌────────────────────┐
│  @ui-test-case-    │      │  @ui-test-          │      │  @ui-test-         │
│  generation        │ ──▶  │  planning           │ ──▶  │  implementation    │
└────────────────────┘      └────────────────────┘      └────────────────────┘
        │                           │                           │
        ▼                           ▼                           ▼
  test-cases.md            implementation-plan.md        Working test files
  (BDD scenarios)          (file paths, locators,        (.feature, Page Objects,
                            code signatures)              Glue, Steps, Runner)
```

### Artifact Output Location

All planning and design artifacts are written to:

```
.docs/agentic-logs/<JIRA-ISSUE>/
```

## What's in `src/instructions/`

| File | Content |
|------|---------|
| `project_context.md` | Domain glossary (NPP, PayTo, ISO 20022), business capabilities, terminology |
| `repo_overview.md` | Directory structure, build system (Gradle), package layout |
| `development_standards.md` | Coding conventions, dependency management, configuration patterns |
| `testing_approach.md` | Test architecture, frameworks (Cucumber BDD, RestAssured, Selenium) |
| `usage_patterns.md` | Consumer integration patterns, API usage |
| `workflows.md` | CI/CD pipelines, release process |

## What's in `src/skills/`

| Skill | Description |
|-------|-------------|
| `ui-test-case-generation.md` | Project-specific paths for feature files, step reuse search patterns, output format |
| `ui-test-planning.md` | 4-layer architecture (Feature → Glue → Steps → Page), locator storage, implementation file locations |
| `ui-test-implementation.md` | Implementation patterns, test execution commands, code templates per layer |

## Pre-requisites

Before running the workflow, you need **requirements ready as context** for the test-case-generation agent. The test scenarios are derived directly from acceptance criteria and functional requirements — so the quality of your input directly determines the quality of your generated test cases.

Choose one of the following options to prepare your requirements:

### Option 1: JIRA XML Export (Manual)

Export JIRA tickets as XML and use Copilot to produce a structured requirements file.

1. In JIRA, use the **Issue Navigator** to filter the relevant tickets (e.g. all tickets in an epic, a sprint, or a custom JQL filter). You can export any number of tickets — or an entire epic — in one go.
2. Export the results as **XML** (click `Export` → `XML`)
3. Place the downloaded `.xml` file in your repo (e.g. `.docs/requirements/export.xml`)
4. Ask Copilot to split the bulk export into individual ticket XMLs:

```
Split the JIRA XML export at .docs/requirements/export.xml into individual
ticket XML files. Save each ticket as .docs/requirements/tmp/<TICKET-ID>.xml
```

5. Then ask Copilot to process the individual tickets in batches and generate a consolidated requirements markdown:

```
Analyse the JIRA ticket XMLs in .docs/requirements/tmp/.
Extract all user stories, acceptance criteria, and functional requirements.
Process no more than 10 tickets at a time.
Output a structured markdown file at .docs/requirements/requirements.md
```

The generated `requirements.md` becomes the input context for `@ui-test-case-generation`.

### Option 2: JIRA Fetch Skill (Automated)

Use the `jira-fetch` skill from the **task-development** workflow to pull tickets directly via the JIRA REST API.

> **📖 Setup & usage:** See [`workflows/task-development/`](../../workflows/task-development/) for configuration (JIRA PAT, `.env` setup) and skill details.

### Option 3: Browser Automation MCP (Confluence / Swagger)

Use the **browser-automation** MCP tool to navigate to Confluence pages or Swagger UI, extract content from the browser, and generate a requirements markdown file.

> **📖 Setup & usage:** See [`tools/mcps/browser-automation/`](../../tools/mcps/browser-automation/) and [`tools/mcps/docsearch/`](../../tools/mcps/docsearch/) for configuration and available MCP tools.
