---
description: Project-specific patterns for UI test planning (W1C Selenium/Cucumber)
---
# UI Test Planning - Project Skill

Project-specific patterns, paths, and conventions for BDD test planning in this repository.

## Project Context

**Framework**: Selenium WebDriver + Cucumber BDD + Serenity
**Language**: Java 17+
**Build Tool**: Gradle
**Test Runner**: Cucumber JUnit

### Instruction Files
Load these for domain context:
- The project's **project_context** instruction file — Domain glossary, business context
- The project's **repo_overview** instruction file — Directory structure, project layout

## Planning Artifacts

| Artifact | Path |
|----------|------|
| Test Cases | `.docs/agentic-logs/<JIRA-ISSUE>/test-cases.md` |
| Implementation Plan | `.docs/agentic-logs/<JIRA-ISSUE>/implementation-plan.md` |

## Implementation File Locations

| Artifact | Path |
|----------|------|
| Feature | `src/test/resources/e2e/features/<App>/<Feature>.feature` |
| **Locators** | `src/test/resources/ui/data/<portal>ObjectLocator.txt` **(ALL locators stored here)** |
| Page | `src/test/java/au/com/westpac/dvs/ui/pages/<Feature>Page.java` |
| Glue | `src/test/java/au/com/westpac/dvs/ui/glue/<Feature>Glue.java` |
| Steps | `src/test/java/au/com/westpac/dvs/ui/steps/<Feature>Steps.java` |
| Runner | `src/test/java/au/com/westpac/dvs/e2e/runners/<Feature>Runner.java` |
| Test Data | `src/test/resources/testData/<feature>.csv` |

### Locator Storage

**Directory**: `src/test/resources/ui/data/`
**File Pattern**: `<Portal>ObjectLocator.txt` or `<Portal>ObjectsLocator.txt`

Examples:
- `w1cChannelsCustomerObjectLocator.txt` — Customer Portal
- `GCMObjectsLocator.txt` — GCM application
- `TLMObjectsLocator.txt` — TLM Portal

> **Note:** This directory is the single source of truth for all UI element locators.

## Layer Pattern

This project uses a 4-layer architecture:

```
Feature → Glue → Steps → Page
```

| Layer | Responsibility | Assertions? |
|-------|----------------|-------------|
| **Feature** | What to test (Gherkin scenarios) | No |
| **Glue** | Bind Cucumber steps to code | No |
| **Steps** | Business logic + assertions (Serenity Steps) | **Yes** |
| **Page** | UI interactions only (Page Objects) | No |

> **Rule**: Assertions belong in Steps layer only, never in Page Objects.

## Code Design Output Format (Phases 3-6)

When planning code structure, use this format in implementation-plan.md:

### Phase 3: Page Object
```markdown
## Phase 3: Page Object
**File**: `src/test/java/au/com/westpac/dvs/ui/pages/<Feature>Page.java`
| Method | Purpose |
|--------|----------|
| navigateTo() | Load page URL |
| click<Element>() | Click specific element |
| enter<Field>(String value) | Enter text in field |
| get<Element>Text() | Retrieve element text |
```

### Phase 4: Glue
```markdown
## Phase 4: Glue
**File**: `src/test/java/au/com/westpac/dvs/ui/glue/<Feature>Glue.java`
| Step | Delegates To |
|------|-------------|
| @Given("user is on login page") | steps.navigateToLogin() |
| @When("user clicks {string}") | steps.clickElement(element) |
| @Then("user should see {string}") | steps.verifyElementVisible(element) |
```

### Phase 5: Steps
```markdown
## Phase 5: Steps
**File**: `src/test/java/au/com/westpac/dvs/ui/steps/<Feature>Steps.java`
| Method | Page Calls | Assertion |
|--------|------------|----------|
| navigateToLogin() | page.navigateTo() | - |
| clickElement(el) | page.clickElement(el) | - |
| verifyElementVisible(el) | page.getElement(el) | assertThat(element).isDisplayed() |
```

### Phase 6: Runner
```markdown
## Phase 6: Runner
**File**: `src/test/java/au/com/westpac/dvs/e2e/runners/<Feature>Runner.java`
Tags: @Regression @<JIRA-ISSUE>
Feature path: src/test/resources/e2e/features/<App>/<Feature>.feature
```

## Suite Tags (MANDATORY)

- `@Regression` — Full suite
- `@HealthCheck` — Critical smoke
- `@Smoke` — Quick validation
- `@Shakedown` — Environment check

## Test Execution Command

```bash
./gradlew clean aggregate test --tests "au.com.westpac.dvs.e2e.runners.<Feature>Runner" "-Dcucumber.options=--tags @<TAG>" -Denvironment=<env> --info
```

### Environment Options
- `sit1`, `sit2` — System Integration Testing
- `uat` — User Acceptance Testing
- `preprod` — Pre-production

## Templates

Load from `shared/templates/` only when needed:
- `feature-template.gherkin` — Feature file structure
- `pageobject-template.java` — Page Object class
- `glue-template.java` — Glue class (Cucumber step definitions)
- `steps-template.java` — Serenity Steps class
- `runner-template.java` — Cucumber test runner

> **Note**: Templates are in the shared folder for cross-skill reuse.

## Application Folders

| Application | Feature Folder | Locator File |
|-------------|----------------|---------------|
| Customer Portal | `W1C-ChannelsCustomerPortal/` | `w1cChannelsCustomerObjectLocator.txt` |
| Staff Portal | `W1C-ChannelsStaffPortal/` | `w1cChannelsStaffObjectLocator.txt` |
| GCM | `GCM-CCMP/` | `GCMObjectsLocator.txt` |
| TLM | `W1C-TLM-Portal/` | `TLMObjectsLocator.txt` |
| NPP Payment | `NPPPayment/` | varies |

## Quality Checklist

- [ ] Suite tag present
- [ ] Critical paths only (1-3 scenarios)
- [ ] Stable locators (id/data-testid)
- [ ] Clean layer separation
- [ ] Atomic Page methods
- [ ] Assertions in Steps only
