---
applyTo: '**'
---
# Testing Approach & Framework

## Overview

This document describes the testing framework, patterns, organization, and best practices used in the W1C Test Automation repository.

---

## 1. Test Framework Stack

### Core Frameworks

| Component | Technology | Version | Purpose |
|-----------|------------|---------|---------|
| **BDD Framework** | Serenity BDD | 2.0.43+ | Test reporting, living documentation, screenplay pattern |
| **Test Runner** | Cucumber | 1.9.33 (serenity-cucumber) | Gherkin-based test specifications |
| **API Testing** | Rest-Assured | 3.3.0 | HTTP API testing and validation |
| **UI Testing** | Selenium WebDriver | Via Serenity | Browser automation |
| **Unit Testing** | JUnit 4 | Via CucumberWithSerenity | Test execution runtime |
| **Assertions** | AssertJ | 3.24.2 | Fluent assertion library |
| **JSON Processing** | JsonPath | 2.4.0 | JSON parsing and extraction |

### Key Dependencies (from build.gradle)
```groovy
testImplementation 'net.serenity-bdd:serenity-core:2.0.43'
testImplementation 'net.serenity-bdd:serenity-cucumber:1.9.33'
testCompile 'net.serenity-bdd:serenity-rest-assured:2.1.5'
testCompile 'io.rest-assured:rest-assured:3.3.0'
testImplementation 'org.assertj:assertj-core:3.24.2'
```

---

## 2. Test Runners

### Runner Class Pattern

All runners use `CucumberWithSerenity` and `@CucumberOptions`:

```java
package au.com.westpac.dvs.e2e.runners;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

@RunWith(value = CucumberWithSerenity.class)
@CucumberOptions(
    features = {"src/test/resources/e2e/features/<FeatureFolder>"},
    glue = {"au.com.westpac.dvs.ui.glue", "au.com.westpac.dvs.api.glue"})
public class <Application>Runner {
}
```

### Available Runners

| Runner | Feature Location | Glue Packages |
|--------|------------------|---------------|
| `W1CChannelsCustomerPortal` | `e2e/features/W1C-ChannelsCustomerPortal` | `ui.glue`, `api.glue` |
| `W1CChannelsStaffPortal` | `e2e/features/W1C-ChannelsStaffPortal` | `ui.glue`, `api.glue` |
| `W1COpenFinRunner` | `e2e/features/OpenFin` | `ui.glue`, `api.glue` |
| `W1CAppianRunner` | `e2e/features/Appian` | `ui.glue`, `api.glue` |
| `W1CTLMPortal` | `e2e/features/W1C-TLM-Portal` | `ui.glue`, `api.glue` |
| `W1CFISOVARunner` | `e2e/features/W1C-ChannelsStaffPortal` | `ui.glue`, `api.glue` |
| `TestRunnerShakedown` | `e2e/features/NPPPayment` | `npp.glue`, `api.glue`, `ui.glue` |
| `SalesforceCCMPRunner` | `e2e/features/SalesforceCCMP` | `api.glue`, `ui.glue` |
| `GCMRunner` | `e2e/features/GCM-CCMP` | `ui.glue`, `api.glue` |

### Running Tests

```bash
# Basic test execution
./gradlew clean aggregate test \
    --tests "au.com.westpac.dvs.e2e.runners.<RunnerClass>" \
    -Dcucumber.options="--tags @<TagName>" \
    -Denvironment=<environment> --info

# Example: Run W1C Customer Portal tests with specific tag
./gradlew clean aggregate test \
    --tests "au.com.westpac.dvs.e2e.runners.W1CChannelsCustomerPortal" \
    -Dcucumber.options="--tags @PARSIFAL-1495" \
    -Denvironment=e2eTenant2 --info
```

---

## 3. Feature File Standards

### Scenario Structure

```gherkin
@PARSIFAL-1495 @ART-4770
Scenario Outline: ART-4770 TC01 User validates account navigation
  Given I retrieve Customer specific secrets from Vault <VaultScenario> for <User>
  And User logs in from login page of W1C portal <TestDescription>
  Then User verifies the View Accounts button on the accounts tile
  And User clicks header logo to redirect to dashboard

  Examples:
    | VaultScenario                        | User       | TestDescription           |
    | Get W1C Application Specific Secrets | TestUser04 | Account navigation test   |
```

### Best Practice: Data-Driven Tests

Use Scenario Outlines with Examples tables for parameterized testing:

```gherkin
Scenario Outline: Validate NPP payment from <OFIorWBC> to W1C account
  Given I retrieve Customer specific secrets from Vault <VaultScenario> for <User>
  Then I Push messages to Swift
    | TCID   | FILENAME   | Type | Category | INSTITUTION | NPPScheme |
    | <TCID> | <Filename> | MX   | <Cat>    | WBC         | <Scheme>  |

  Examples:
    | VaultScenario                        | User       | TCID       | Filename                 | Cat | Scheme | OFIorWBC |
    | Get W1C Application Specific Secrets | TestUser04 | TC01_X2P1  | emu_x2p1_008_TC1_x2p1.xml| X2P | x2p1   | OFI      |
    | Get W1C Application Specific Secrets | TestUser04 | TC02_SCT   | emu_x2p1_008_TC2_sct.xml | SCT | sct    | OFI      |
```

> **Note:** For tag conventions and naming standards, see [development_standards.instructions.md](development_standards.instructions.md).

---

## 4. Test Architecture Patterns

### Layered Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Feature Files (.feature)                 │
│                    (Gherkin specifications)                 │
├─────────────────────────────────────────────────────────────┤
│                    Glue Classes (*Glue.java)                │
│                    (Cucumber step definitions)              │
├─────────────────────────────────────────────────────────────┤
│                    Step Classes (*Steps.java)               │
│                    (Orchestration layer)                    │
├─────────────────────────────────────────────────────────────┤
│                    Page Objects (*Page.java)                │
│                    (UI interaction layer)                   │
├─────────────────────────────────────────────────────────────┤
│                    Utility Classes (utils/)                 │
│                    (WebDriver, helpers, parsers)            │
└─────────────────────────────────────────────────────────────┘
```

### Page Object Model (POM)

Page objects extend `net.serenitybdd.core.pages.PageObject`:

```java
public class ChannelsDashboardPage extends PageObject {
    
    public void verifyAccountsTile() throws Exception {
        String locator = "Accounts_Tile";
        UIGenericHelper.waitForElementToBeVisible(locator,
            UIGenericHelper.getOneCorePageObjectLocatorValue(locator));
    }
    
    public void clickHeaderLogo() throws Exception {
        String locator = "Header_Logo";
        UIGenericHelper.clickElement(locator, "xpath",
            UIGenericHelper.getOneCorePageObjectLocatorValue(locator));
    }
}
```

### Step Classes with @Steps Injection

```java
public class ChannelsAccountsGlue {

    @Steps()
    ChannelsDashboardSteps channelsDashboardSteps;

    @Steps()
    ChannelsAccountsSteps channelsAccountsSteps;

    @And(value = "^User clicks header logo to redirect to dashboard$")
    public void headerLogo() throws Exception {
        channelsDashboardSteps.clickHeaderLogo();
    }
}
```

### API Step Base Class

`CCMPRestScenarioSteps` provides REST API testing infrastructure:

```java
public class CCMPRestScenarioSteps extends ScenarioSteps {
    private Response response;
    private RequestSpecification requestSpecs;
    
    // Response handling
    public Response getResponse() { return response; }
    public JsonPath getJsonPath() { return response.body().jsonPath(); }
    
    // Request building
    public CCMPRequest createUserLoginRequest(...) { ... }
}
```

---

## 7. Configuration

### Serenity Configuration Files

#### serenity.properties (Root Level)
```properties
serenity.project.name=W1C Test Automation
webdriver.driver=chrome
serenity.outputDirectory=build/site/serenity
serenity.take.screenshots=AFTER_EACH_STEP
serenity.timeout=60
serenity.logging=VERBOSE
restart.browser.each.scenario=true
jira.url=https://jira.srv.westpac.com.au
jira.project=ART
```

#### serenity.conf (Environment Configuration)
```hocon
webdriver {
    driver = chrome
    autodownload = true
}

headless.mode = false
use.remote.driver = true

chrome {
    switches = """--windows.size=1024,800, --start-maximized..."""
}

environments {
    default { ... }
    IntTenant2 { ... }
    e2eTenant2 { ... }
}
```

> **Note:** For environment-specific URLs and secrets management, see [workflows.instructions.md](workflows.instructions.md).

---

## 8. Test Data Management

### Data Sources

| Type | Location | Format | Usage |
|------|----------|--------|-------|
| **CSV Test Data** | `src/test/resources/api/testdata/` | `.csv` | API test data with scenario mapping |
| **JSON Test Data** | `src/test/resources/testData/` | `.json` | Static test data by environment |
| **XML Input Files** | `input/npp/MX/` | `.xml` | NPP message payloads |
| **API Payloads** | `src/test/resources/api/apiInputData/` | Various | Request body templates |
| **Expected Results** | `src/test/resources/api/apiExpectedResult/` | Various | Expected API responses |
| **UI Locators** | `src/test/resources/ui/data/` | `.txt` | XPath/CSS locators for UI elements |

### Test Data JSON Structure

Test data JSON files are organized by environment under `src/test/resources/testData/`:

```
testData/
├── E2E/
│   ├── w1c-ChannelsCustomerPortalData.json
│   ├── w1c-ChannelsStaffPortalData.json
│   └── pods/
├── INT/
│   ├── w1c-ChannelsCustomerPortalData.json
│   └── w1c-ChannelsStaffPortalData.json
└── common-testdata.json
```

**Example JSON Structure (`w1c-ChannelsCustomerPortalData.json`):**

```json
{
  "ART-4770 TC01 User validates account navigation": {
    "accountNumber": "123456789",
    "bsb": "032-000",
    "accountType": "Current Account",
    "expectedBalance": "1,500.00",
    "beneficiaryName": "Test Beneficiary"
  },
  "ART-4771 TC01 User makes NPP payment": {
    "fromAccount": "123456789",
    "toAccount": "987654321",
    "toBsb": "062-000",
    "amount": "100.00",
    "paymentMethod": "OSKO",
    "reference": "Test Payment"
  },
  "commonData": {
    "defaultWaitTime": "10",
    "portalUrl": "https://portal.test.com"
  }
}
```

**Key Conventions:**
- Scenario name is the JSON key (matches feature file scenario name)
- Use `commonData` for shared values across scenarios
- Environment-specific files override common data

### ConfigReader Usage

The `ConfigReader` class reads test data from JSON files:

```java
import au.com.westpac.dvs.ui.util.ConfigReader;

public class ChannelsAccountsPage extends PageObject {
    
    ConfigReader configReader;
    
    // Initialize ConfigReader with scenario name
    public void initializeTestData(String scenarioName) {
        configReader = new ConfigReader();
        configReader.setScenarioName(scenarioName);
    }
    
    // Get value from JSON test data
    public String getAccountNumber() {
        return configReader.getPropertyValue("accountNumber");
    }
    
    // Get value with default fallback
    public String getPaymentAmount() {
        String amount = configReader.getPropertyValue("amount");
        return (amount != null) ? amount : "0.00";
    }
    
    // Get nested property
    public String getExpectedBalance() {
        return configReader.getPropertyValue("expectedBalance");
    }
}
```

**Usage in Steps:**

```java
public class ChannelsAccountsSteps {
    
    ChannelsAccountsPage channelsAccountsPage;
    ConfigReader configReader;
    
    @Step
    public void enterAccountDetails(String scenarioName) throws Exception {
        configReader = new ConfigReader();
        configReader.setScenarioName(scenarioName);
        
        String accountNumber = configReader.getPropertyValue("accountNumber");
        String bsb = configReader.getPropertyValue("bsb");
        
        channelsAccountsPage.enterAccountNumber(accountNumber);
        channelsAccountsPage.enterBsb(bsb);
    }
}
```

### Session Management (Extended)

The `SessionManager` class stores test data that needs to be shared across steps within a scenario:

```java
import au.com.westpac.dvs.SessionManager;
import au.com.westpac.dvs.CCMPSessionData;

// === STORING DATA IN SESSION ===

// Get or create session for scenario
CCMPSessionData session = SessionManager.getSession(scenarioName);
if (session == null) {
    session = new CCMPSessionData();
}

// Store credentials (from Vault)
session.setChannelsUsername(username);
session.setChannelsPassword(password);
session.setGCMUserName(gcmUser);
session.setGCMPasswordLogin(gcmPassword);

// Store transaction references
session.setTransactionId(transactionId);
session.setPaymentReference(paymentRef);

// Store account details
session.setAccountNumber(accountNumber);
session.setBsb(bsb);

// Save session
SessionManager.putSession(scenarioName, session);


// === RETRIEVING DATA FROM SESSION ===

// In a different step/page within same scenario
CCMPSessionData session = SessionManager.getSession(scenarioName);

// Get credentials
String username = session.getChannelsUsername();
String password = session.getChannelsPassword();

// Get transaction data
String txnId = session.getTransactionId();
String paymentRef = session.getPaymentReference();


// === COMMON SESSION FIELDS ===
/*
 * Credentials:
 *   - getChannelsUsername() / setChannelsUsername()
 *   - getChannelsPassword() / setChannelsPassword()
 *   - getGCMUserName() / setGCMUserName()
 *   - getGCMPasswordLogin() / setGCMPasswordLogin()
 *   - getNPPUserName() / setNPPUserName()
 *   - getNPPPassword() / setNPPPassword()
 *
 * Transaction Data:
 *   - getTransactionId() / setTransactionId()
 *   - getPaymentReference() / setPaymentReference()
 *   - getAccountNumber() / setAccountNumber()
 *   - getBsb() / setBsb()
 */
```

### Secrets Management

Test credentials are retrieved from Vault:

```gherkin
Given I retrieve Customer specific secrets from Vault <VaultScenario> for <User>
```

The Vault step stores credentials in SessionManager for later use:

```java
// In VaultSteps.java
public void retrieveW1CVaultSecretsResponse() {
    CCMPSessionData session = SessionManager.getSession(scenarioName);
    
    // Extract from Vault response and store in session
    session.setChannelsUsername(vaultResponse.get("ChannelsUserName"));
    session.setChannelsPassword(vaultResponse.get("ChannelsPassword"));
    session.setGCMUserName(vaultResponse.get("GCMUserName"));
    session.setGCMPasswordLogin(vaultResponse.get("GCMPasswordLogin"));
    
    SessionManager.putSession(scenarioName, session);
}
```

---

## 9. WebDriver Initialization

### InitializeWebdriver Class

The `InitializeWebdriver` class handles browser setup and configuration:

```java
import au.com.westpac.dvs.ui.util.InitializeWebdriver;

// Launch browser (local or remote based on serenity.conf)
InitializeWebdriver.launchBrowserInLocalOrRemote("Chrome");

// Available browsers
InitializeWebdriver.launchBrowserInLocalOrRemote("Chrome");
InitializeWebdriver.launchBrowserInLocalOrRemote("Firefox");
InitializeWebdriver.launchBrowserInLocalOrRemote("Edge");
```

### serenity.conf WebDriver Configuration

```hocon
webdriver {
    driver = chrome
    autodownload = true
}

# Headless mode (for CI/CD)
headless.mode = false

# Remote WebDriver (Selenium Grid)
use.remote.driver = true

# Chrome options
chrome {
    switches = """--start-maximized,
                  --disable-popup-blocking,
                  --disable-default-apps,
                  --disable-extensions,
                  --disable-infobars,
                  --no-sandbox,
                  --disable-dev-shm-usage"""
}

# Environment-specific Selenium Grid URLs
environments {
    IntTenant2 {
        selenium.grid.url = "https://seleniumgrid.tst.srv.westpac.com.au/wd/hub"
    }
    e2eTenant2 {
        selenium.grid.url = "https://seleniumgrid.tst.srv.westpac.com.au/wd/hub"
    }
}
```

### Browser Launch in Glue Class

```java
@Given(value = "^User logs in from login page of W1C portal (.*)$")
public void loginToPortal(String scenarioName) throws Exception {
    // Initialize browser
    InitializeWebdriver.launchBrowserInLocalOrRemote("Chrome");
    
    // Get portal URL from environment config
    String portalUrl = EnvironmentSpecificConfiguration
        .from(environmentVariables)
        .getProperty("loginWestpacOneCore");
    
    // Navigate to URL
    getWebDriver().get(portalUrl);
    
    // Setup screenshot folder
    UIGenericHelper.setFolderName(scenarioName);
    createScreenshotFolder();
    UIGenericHelper.snap("Begin");
    
    // Perform login
    channelsDashboardSteps.login();
}
```

---

## 10. Best Practices

### Writing Tests

1. **Use descriptive scenario names** that include JIRA ticket and test case ID:
   ```gherkin
   Scenario: ART-4770 TC01 User validates account page navigation
   ```

2. **Tag tests appropriately** for selective execution:
   ```gherkin
   @PARSIFAL-1495 @ART-4770 @Regression @HealthCheck
   ```

3. **Use Scenario Outlines** for data-driven tests to reduce duplication

4. **Keep step definitions reusable** - prefer generic steps over scenario-specific ones

### Code Organization

1. **One Page Object per page/component** - avoid monolithic page objects
2. **Keep glue classes thin** - delegate to step classes
3. **Use `@Steps` annotation** for dependency injection of step classes
4. **Store locators externally** in `*ObjectsLocator.txt` files

### Test Independence

1. **Each scenario should be independent** - no shared state between scenarios
2. **Use `@Before` hooks** for setup, not for test logic
3. **Use `SessionManager`** for within-scenario state management

### API Testing

1. **Extend `CCMPRestScenarioSteps`** for API step classes
2. **Use CSV files** for API test data mapping
3. **Validate responses** using JsonPath assertions

---

## 11. Key Utility Classes

| Class | Location | Purpose |
|-------|----------|---------|
| `UIGenericHelper` | `ui/util/` | Selenium interactions (click, wait, type) |
| `ConfigReader` | `ui/util/` | JSON/XML file reading and manipulation |
| `InitializeWebdriver` | `ui/util/` | WebDriver setup and configuration |
| `SessionManager` | Root package | Test session state management |
| `CCMPRestScenarioSteps` | Root package | Base class for REST API testing |

---

## Related Documentation

- **Test Execution Commands**: See [usage_patterns.instructions.md](usage_patterns.instructions.md)
- **CI/CD, Reporting & Publishing**: See [workflows.instructions.md](workflows.instructions.md)
- **Naming Conventions & Tags**: See [development_standards.instructions.md](development_standards.instructions.md)
- **Directory Structure**: See [repo_overview.instructions.md](repo_overview.instructions.md)
