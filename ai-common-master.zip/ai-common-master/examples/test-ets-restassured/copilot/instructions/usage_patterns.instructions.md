---
applyTo: '**'
---
# Usage Patterns & Workflows

## 1. Key Testing Workflows

### 1.1 NPP Inward Payment Testing

**Purpose**: Validate payments received from other financial institutions (OFI) into Westpac accounts.

**Test Flow**:
```
1. Retrieve secrets from Vault
2. Push NPP message via PAG Emulator
3. Validate in Customer Portal (OpenFin)
4. Validate in 10x Insights API
5. Validate in FIS OVA Portal
6. Report results to Jira
```

**Example Feature Scenario**:
```gherkin
@NPPInbound @Regression @inward
Scenario Outline: Validate the NPP OSKO Inward payment from OFI to W1C 10x account
  Given I retrieve Customer specific secrets from Vault <VaultScenario> for <User>
  Given I retrieve W1C API specific secrets from Vault <APIKeyVault>
  Then I Push messages to Swift
    | TCID | FILENAME | Type | Category | INSTITUTION | ScopePath | SCNType | NPPScheme | OFIorWBC |
    | TC01 | emu_x2p1_008_TC1_x2p1.xml | MX | X2P | WBC | npp | Inward | x2p1 | OFI |
  And I launch openFin for customer user NPPInward OSKO Payment
  And I validate the NPPInward transaction in 10x Insights
  And User logged on to FIS OVA portal via SSO
```

**Input Files Location**: `input/npp/MX/X2P/` and `input/npp/MX/SCT/`

---

### 1.2 NPP Outward Payment Testing

**Purpose**: Validate payments sent from Westpac accounts to other financial institutions.

**Test Flow**:
```
1. Log in to Customer/Staff Portal
2. Navigate to Make Payment
3. Select From Account and To Account
4. Enter amount and payment method (Osko/Fast Payment)
5. Submit payment
6. Validate confirmation details
7. Validate in FIS OVA
```

**Example Feature Scenario**:
```gherkin
@NPPOutward
Scenario Outline: Validate the NPP Fast Payment (Outward SCT) is successful
  Given Staff User logged on to W1C Staff portal via SSO
  And User select Make Payment button from dashboard page
  And User selects the <From Account> account value as Westpac Account
  And User selects the <To Account> values as OFI Account
  And User enters <Amount> value into the input field
  And User select <paymentMethod> from the dropDownList
  Then User hits the Review button
  And User hits the submit button
  Then User verifies the payment confirmation details
```

---

### 1.3 PayTo Mandate Payment Testing

**Purpose**: Validate mandate-based payment initiation via PayTo service.

**Test Flow**:
```
1. Create/validate mandate exists
2. Push pain.001 or pain.013 message
3. Validate mandate processing
4. Validate account debit (pacs.008)
5. Validate in portals
```

**Input Files Location**: 
- `input/payto/PAIN1/` - Pain.001 messages
- `input/payto/PAIN13/` - Pain.013 messages
- `input/payto/ONUS/` - On-us scenarios
- `input/payto/OFFUS/` - Off-us scenarios

---

### 1.4 Payment Return Testing

**Purpose**: Validate solicited and unsolicited return flows (pacs.004).

**Test Flow**:
```
1. Identify original payment transaction
2. Navigate to Initiate Return page (Staff Portal)
3. Select return type (Solicited/Unsolicited)
4. Enter return reason and amount
5. Submit return
6. Validate return processing in FIS OVA
```

**Example Feature Scenario**:
```gherkin
@InitiateReturn
Scenario Outline: Validate Solicited Return processing
  Given Staff User logged on to W1C Staff portal via SSO
  And User navigates to Initiate Return page
  And User enters the <NppTxnID> in search field
  And User selects <ReturnType> return
  And User enters <RtrAmount> and reason <ReasonCode>
  Then User submits the return request
```

---

### 1.5 Exception Handling Testing

**Purpose**: Validate handling of invalid/suspended/closed accounts.

**Scenarios Covered**:
| Scenario | Expected Result |
|----------|-----------------|
| Invalid Account | Rejected with AC03 |
| Suspended Account | Rejected with AC03 |
| Closed Account | Rejected with AC06 |
| Suspense Posting | Posted to suspense account |

**Input Files**: Files with suffix `_SUSP.xml`, `_Closed.xml`, `_Invalid.xml`

---

## 2. Running Tests

### 2.1 Basic Test Execution

```bash
# Run specific test with tags and environment
./gradlew clean aggregate test \
  --tests "au.com.westpac.dvs.e2e.runners.<RunnerClass>" \
  -Dcucumber.options="--tags @TagName" \
  -Denvironment=<environment> \
  --info
```

### 2.2 Common Execution Patterns

**Run NPP Inward Tests**:
```bash
./gradlew clean aggregate test \
  --tests "au.com.westpac.dvs.npp.runners.NPPRunner" \
  -Dcucumber.options="--tags @NPPInbound" \
  -Denvironment=IntTenant2 --info
```

**Run Customer Portal Tests**:
```bash
./gradlew clean aggregate test \
  --tests "au.com.westpac.dvs.e2e.runners.W1CChannelsCustomerPortal" \
  -Dcucumber.options="--tags @Regression" \
  -Denvironment=e2eTenant2 --info
```

**Run Staff Portal Tests**:
```bash
./gradlew clean aggregate test \
  --tests "au.com.westpac.dvs.e2e.runners.W1CChannelsStaffPortal" \
  -Dcucumber.options="--tags @Regression" \
  -Denvironment=IntTenant2 --info
```

**Run Health Check**:
```bash
./gradlew clean aggregate test \
  --tests "au.com.westpac.dvs.e2e.runners.E2ERunner" \
  -Dcucumber.options="--tags @HealthCheck" \
  -Denvironment=IntTenant2 --info
```

### 2.3 Environment Selection

| Environment | Use Case |
|-------------|----------|
| `IntTenant2` | Integration/SIT testing |
| `e2eTenant2` | End-to-end testing |
| `default` | Local development |

---

> **Note:** For a complete list of tag conventions and naming standards, see [development_standards.instructions.md](development_standards.instructions.md).

---

## 3. Test Data Patterns

### 3.1 NPP Message Input Files

**Naming Convention**: `emu_<type>_<testcase>.xml`

**Location Structure**:
```
input/
├── npp/MX/
│   ├── SCT/           # Single Credit Transfer messages
│   │   ├── emu_wcs8.xml
│   │   ├── emu_x2p1_008_TC2_sct.xml
│   │   └── wbc_sct_exception.xml
│   └── X2P/           # X2P1 payment messages
│       ├── emu_x2p1_008_TC1_x2p1.xml
│       ├── emu_x2p1_008_TC01_x2p1_SUSP.xml
│       └── emu_x2p1_008_TC01_x2p1_Closed.xml
├── payto/
│   ├── PAIN1/         # Pain.001 initiation
│   ├── PAIN13/        # Pain.013 activation
│   ├── ONUS/          # On-us scenarios
│   └── OFFUS/         # Off-us scenarios
└── XBorder/           # Cross-border payments
```

### 3.2 Test Data JSON Files

**Location**: `src/test/resources/testData/`

**Structure**:
```
testData/
├── E2E/               # E2E environment data
│   ├── pods/
│   └── ...
├── INT/               # INT environment data
└── *.json             # Shared test data
```

### 3.3 Environment-Specific Data

Data is loaded based on environment parameter:
- Account numbers
- Beneficiary details
- Expected values
- API credentials (via Vault)

---

## 4. Validation Patterns

### 4.1 Multi-Layer Validation

Tests typically validate across multiple systems:

```gherkin
# Layer 1: Customer Portal
And I launch openFin for customer user
Then customer user verifies the NPP inward transaction details

# Layer 2: 10x Insights API
And I validate the NPPInward transaction in 10x Insights

# Layer 3: FIS OVA Portal
And User logged on to FIS OVA portal via SSO
Then Validate the payments status
And Validate the Amount for Inward Payments
And Validate the Instruction Trace Id
```

### 4.2 FIS OVA Validation Steps

Common validation pattern in FIS OVA:
```gherkin
And Navigate to Dashboard screen and select the payments menu
Then User Selects the transactions
And Enters the date in the from date field
And Enter the <TransactionReferenceId> in the transaction reference field
And User click on Search button
And Select the first transaction from the list
And Clicks on expand option
Then Validate the payments status
And Validate the Amount
Then Navigate to History Tab
Then Navigate to LinkedItems Tab
```

### 4.3 Jira Integration

Results can be automatically published to Jira:
```gherkin
Then For <JiraId> validate result and check status <FinalRunToAddCommentToJira> and <AddComments> to jira

Examples:
  | JiraId    | FinalRunToAddCommentToJira | AddComments          |
  | ART-55608 | Yes                        | Add comments to jira |
```

---

## 5. Common Gherkin Step Patterns

### 5.1 Vault Secrets Retrieval

**IMPORTANT**: Always use the correct Vault step pattern based on scenario type.

| Step Pattern | When to Use |
|--------------|-------------|
| `Given I retrieve Customer specific secrets from Vault <VaultScenario> for <User>` | **Customer Portal tests** - Use this for W1C Customer Portal scenarios. Requires `User` column in Examples table. |
| `Given I retrieve W1C API specific secrets from Vault <APIVaultScenario>` | API-only validation steps (e.g., 10x Insights validation) |
| `Given Staff User logged on to W1C Staff portal via SSO` | Staff Portal tests (uses SSO, no Vault step needed) |

**Correct Usage for Customer Portal**:
```gherkin
Background:
  Given I retrieve Customer specific secrets from Vault <VaultScenario> for <User>
  And User logs in from login page of W1C portal <ScenarioName>

Examples:
  | VaultScenario                        | User           | ScenarioName              |
  | Get W1C Application Specific Secrets | TestUser04     | ART-XXXXX_TC01_Scenario   |
```

**Common Vault Scenarios**:
| VaultScenario Value | Purpose |
|---------------------|---------|
| `Get W1C Application Specific Secrets` | Standard W1C application secrets |
| `Get W1C API Specific Secrets` | API-specific credentials |

### 5.2 Navigation Steps

```gherkin
# Dashboard to Payments
And User clicks on the View Payments from the payments tile

# Dashboard to Accounts
And User clicks on the View Accounts button

# Select Account in dropdown
And User selects the required <Account> from the account dropdown and clicks on Search

# Select specific payment
And Customer user selects the required payment with <Receipt_Number> and <Date>
# OR
And Select the first entry from the payment list
```

### 5.3 Jira Integration Steps

```gherkin
# Always at end of scenario
Then For <JiraId> validate result and check status <FinalRunToAddCommentToJira> and <AddComments> to jira

# Examples table must include:
| JiraId    | FinalRunToAddCommentToJira | AddComments          |
| ART-69827 | Yes                        | Add comments to jira |
```

---

## 6. Reporting & Publishing

### 5.1 Generate Reports
```bash
./gradlew aggregate
```
Reports generated at: `build/site/serenity/`

### 5.2 Publish to Jira
```bash
./gradlew publishToJira
```

### 5.3 Publish to ALM
```bash
./gradlew publishToAlm
```

### 5.4 Generate CSV Report
```bash
./gradlew generateCsvFromSerenityReport
```

---

## 6. Common Tasks

### 6.1 Adding a New NPP Test Case

1. Create input XML file in `input/npp/MX/<Category>/`
2. Add scenario to feature file in `src/test/resources/e2e/features/NPPPayment/`
3. Reference the XML file in the data table
4. Define expected values in test data JSON

### 6.2 Adding a New Portal Test

1. Add scenario to appropriate feature file
2. Implement step definitions in glue package if needed
3. Add page objects for new UI elements
4. Add locators to locator file

### 6.3 Updating Test Data

1. For static data: Update JSON files in `src/test/resources/testData/`
2. For credentials: Update Vault secrets
3. For XML templates: Update files in `input/` directory

---

## 7. Debugging Tips

### 7.1 Enable Detailed Logging
```bash
./gradlew test --info
```

### 7.2 Run Single Scenario
Use a unique tag:
```gherkin
@OnMe
Scenario: My test scenario
```
Then:
```bash
-Dcucumber.options="--tags @OnMe"
```

### 7.3 Check Serenity Reports
After test run, open: `build/site/serenity/index.html`

### 7.4 Network Capture for Debugging
Enable network capture in tests:
```gherkin
And I start monitoring network traffic
# ... perform actions ...
Then I verify API "/api/endpoint" was called
And I print header "Authorization" from request
And I stop monitoring network traffic
```

---

## 8. Best Practices

1. **Tag Management**: Use appropriate tags for test categorization
2. **Data Isolation**: Use unique identifiers to avoid test data conflicts
3. **Clean Up**: Ensure tests clean up any created data
4. **Parallel Execution**: Design tests to run independently
5. **Vault Secrets**: Always retrieve credentials from Vault, never hardcode
6. **Multi-Layer Validation**: Validate across portal, API, and operations systems
7. **Jira Linking**: Link test results to Jira tickets for traceability
