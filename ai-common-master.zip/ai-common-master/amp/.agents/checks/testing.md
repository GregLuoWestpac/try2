# Testing Review

Check test quality and coverage for changed code:

- New functionality has corresponding unit tests
- Modified code has updated tests if behavior changed
- Tests follow existing test patterns and naming conventions
- Tests cover both positive and negative scenarios
- No flaky patterns — no hardcoded timeouts, no reliance on execution order
- Test assertions are specific and meaningful — no empty test bodies
- Mock/stub usage follows project conventions
- Test file locations match project structure (`*.test.ts` co-located or in `__tests__/`)
