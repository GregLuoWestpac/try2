# Code Standards Review

Check that changed code follows project conventions:

- Naming conventions match existing codebase patterns (camelCase for variables/functions, PascalCase for classes/components)
- No dead code, unused imports, or commented-out code blocks
- Code follows established project patterns and idioms
- No code duplication — reuses existing utilities and components
- Files are in the correct directory per project structure conventions
- TypeScript types are used correctly — no unnecessary `any` types
- Error handling follows project patterns
- No TODO/FIXME comments without linked JIRA tickets
