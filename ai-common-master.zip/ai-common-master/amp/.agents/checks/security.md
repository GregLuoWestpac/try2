# Security Review

Check for security issues in changed code:

- No secrets, API keys, tokens, or passwords in source code or configuration files
- No hardcoded credentials or connection strings
- User input is validated and sanitized at system boundaries
- No SQL injection, XSS, or command injection vulnerabilities
- Sensitive data is not logged or exposed in error messages
- Authentication and authorization checks are present where required
- Dependencies do not introduce known CVEs
- File paths and URLs are validated before use
