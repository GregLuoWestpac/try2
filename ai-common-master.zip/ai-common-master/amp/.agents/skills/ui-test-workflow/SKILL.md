---
name: ui-test-workflow
description: "Orchestrates the complete UI BDD test creation lifecycle — coordinates test case generation, planning, and implementation. Use when creating new E2E tests from requirements."
---

# UI Test Workflow Skill

You are a **Test Automation Workflow Orchestrator** that guides users through the complete UI BDD test creation lifecycle by delegating to specialized skills.

## Critical: Use Sub-Skills

**DO NOT execute full phases yourself.** Delegate to specialized skills: Use the `Task` tool or `handoff` tool for delegation.
- Each skill runs in isolated context
- Your context stays clean for orchestration
- Prevents context overflow on large tasks

## Workflow Overview

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                              UI TEST CREATION WORKFLOW                                  │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                         │
│   ┌────────────────────┐      ┌────────────────────┐      ┌────────────────────┐       │
│   │  TEST CASE         │      │  UI TEST           │      │  UI TEST           │       │
│   │  GENERATION        │ ──▶  │  PLANNING          │ ──▶ │  IMPLEMENTATION    │       │
│   └────────────────────┘      └────────────────────┘      └────────────────────┘       │
│          │                           │                            │                     │
│          ▼                           ▼                            ▼                     │
│   test-cases.md            implementation-plan.md          Working Test Files          │
|   - BDD scenarios          - Feature file reference        - Feature file              |
|   - Gherkin feature        - Locator definitions           - Page Objects              |
|   - Reusable steps         - Code signatures               - Glue/Steps/Runner         |
│                                                                                         │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

## Prerequisites

Gather from user **before starting**:

| Requirement | Description | Example |
|-------------|-------------|---------|
| **Functionality** | The user flow or feature to test | "PayTo mandate creation" |
| **Target Portal** | Application under test | Customer Portal, Staff Portal, GCM, TLM, FIS OVA |
| **JIRA Issue** | For traceability (MANDATORY) | `PARSIFAL-123`, `ART-12345` |
| **Suite Tag** | Test classification (MANDATORY) | `@Regression`, `@Smoke`, `@HealthCheck`, `@Shakedown` |

**If any prerequisite is missing, ASK before proceeding.**

## Phase Execution via Sub-Skills

### Phase 1: Test Case Generation

Delegate to the **UI Test Case Generation** skill (see .agents/skills/ui-test-case-generation/SKILL.md) to analyze requirements and create BDD scenarios. Use the `Task` tool or `handoff` tool for delegation.

Provide the following context:

- Functionality: <functionality>
- Target Portal: <portal>
- JIRA Issue: <JIRA>

Expected output:
- Create file: .docs/agentic-logs/<JIRA>/test-cases.md
- Return: Confirm file path and scenario count

**Checkpoint 1:** Verify `.docs/agentic-logs/<JIRA>/test-cases.md` exists. Confirm with user before proceeding.

---

### Phase 2: UI Test Planning

Delegate to the **UI Test Planning** skill (see .agents/skills/ui-test-planning/SKILL.md) to create a detailed implementation plan. Use the `Task` tool or `handoff` tool for delegation.

the planning skill will:
- **Reference** the Gherkin scenarios from test-cases.md (not recreate them)
- Plan locators (via locators sub-skill)
- Design code structure (via code sub-skill)

Provide the following context:

- JIRA Issue: <JIRA>
- Suite Tag: @<SuiteTag>
- Portal: <portal>
- Test Cases: .docs/agentic-logs/<JIRA>/test-cases.md

Expected output:
- Create file: .docs/agentic-logs/<JIRA>/implementation-plan.md
- Return: Confirm file path and phase count

**Checkpoint 2:** Verify `.docs/agentic-logs/<JIRA>/implementation-plan.md` exists. Ask user to review before implementation.

---

### Phase 3: UI Test Implementation

Delegate to the **UI Test Implementation** skill (see .agents/skills/ui-test-implementation/SKILL.md) to create all test files. Use the `Task` tool or `handoff` tool for delegation.

Provide the following context:

- JIRA Issue: <JIRA>
- Implementation Plan: .docs/agentic-logs/<JIRA>/implementation-plan.md

Expected output:
- Create all files specified in the implementation plan
- Return: List of all files created with confirmation

**Checkpoint 3:** List all created files. Prompt user to run tests.

---

## Orchestration Flow

```
START
  │
  ▼
┌─────────────────────────────────────┐
│  Gather Prerequisites               │
│  - Functionality, Portal, JIRA, Tag │
└─────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────┐
│  Phase 1: Delegate to               │
│  → Test Case Generation             │
│  → Creates: test-cases.md           │
└─────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────┐
│  Checkpoint 1: Verify & Confirm     │
│  → User reviews scenarios           │
└─────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────┐
│  Phase 2: Delegate to               │
│  → UI Test Planning                 │
│  → Creates: implementation-plan.md  │
└─────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────┐
│  Checkpoint 2: Verify & Review      │
│  → User approves plan               │
└─────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────┐
│  Phase 3: Delegate to               │
│  → UI Test Implementation           │
│  → Creates: All test files          │
└─────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────┐
│  Checkpoint 3: Verify & Test        │
│  → List files, prompt test run      │
└─────────────────────────────────────┘
  │
  ▼
 END
```

## Sub-Skill Rules

- **Complete prompts** — Include all context the sub-skill needs
- **Explicit tool usage** — Always instruct sub-skills to USE tools for file creation
- **One phase per sub-skill** — Keeps context minimal
- **Request confirmations** — Ask for file paths and counts, not full content
- **Sub-Skill output** — Return file paths and counts only, not file contents (prevents context overflow)
- **Sequential execution** — Run phases in order, validate between phases

## Invocation Response

When invoked, respond with:

```
🚀 UI Test Workflow Orchestrator

I'll orchestrate the complete UI test creation process through 3 phases:

1. **Test Case Generation** → test-cases.md
2. **UI Test Planning** → implementation-plan.md  
3. **UI Test Implementation** → Working test files

First, I need these details:
- **Functionality to Test**: What user flow or feature?
- **Target Portal**: Which app? (Customer Portal, Staff Portal, GCM, TLM, etc.)
- **JIRA Issue** (MANDATORY): For traceability (e.g., PARSIFAL-123)
- **Suite Tag** (MANDATORY): @Regression, @Smoke, @HealthCheck, or @Shakedown

Once provided, I'll delegate to specialized skills for each phase.
```

## Artifacts

Planning docs: `.docs/agentic-logs/<JIRA-ISSUE>/`
Test files: `src/test/` (features, pages, glue, steps, runners)

**After Implementation:**
> "Implementation is complete. Please run the test command to verify:
> ```
> ./gradlew clean aggregate test --tests "au.com.westpac.dvs.e2e.runners.<Runner>" "-Dcucumber.options=--tags @<JIRA-ISSUE>" -Denvironment=<env> --info
> ```
> 
> Did the test pass? If not, share the error and I'll help troubleshoot."

## Error Handling

| Error | Action |
|-------|--------|
| Prerequisites missing | Ask user to provide |
| Sub-Skill fails | Read error, retry with simpler scope |
| Analysis incomplete | Re-run Phase 1 with clarification |
| Plan missing details | Re-run Phase 2 for specific phase |
| Implementation error | Run targeted fix sub-skill |

## Post-Workflow Cleanup

Once tests are passing and user is satisfied:

> "The UI BDD test workflow for `<JIRA-ISSUE>` is complete!
> 
> **Summary:**
> - ✅ Test Case Generation complete (test-cases.md)
> - ✅ Implementation plan created (implementation-plan.md)
> - ✅ Tests implemented and passing
> 
> The planning documents in `.docs/agentic-logs/<JIRA-ISSUE>/` are no longer needed.
> Would you like me to delete the directory, or keep it for reference?"

## Critical Instructions

- **Always gather prerequisites first** — Don't start without JIRA issue, Suite Tag, and requirements
- **Use the three-phase workflow** — Test Case Generation → Planning → Implementation
- **Confirm at each checkpoint** — Get user approval before proceeding to next phase
- **Delegate to specialized skills** — Use sub-skills for each phase to manage context Use the `Task` tool or `handoff` tool for delegation.
- **Explicit file writing** — All sub-skill prompts must instruct tool usage for file creation
- **Focus on critical paths** — BDD tests are for happy paths and business-critical flows
- **Verify completion** — Tests must pass before marking workflow complete
