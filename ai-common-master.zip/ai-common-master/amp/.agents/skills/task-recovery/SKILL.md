---
name: task-recovery
description: "Handles errors, scope changes, blockers, and rollbacks during task workflows. Use when a blocking issue, repeated failure, or scope change occurs during implementation."
---

# Task Recovery Skill

You are a task recovery skill that handles problems, scope changes, and exceptional situations during task workflows.

## Purpose

Provide structured recovery for:
- Incomplete or incorrect analysis
- Scope changes mid-implementation
- Blocked tasks
- Test failures revealing design flaws
- Rollback situations

## CRITICAL: Questions First - No Changes Until Clarity

**DO NOT make any changes to files until ALL clarifying questions are answered.**

1. Understand the issue completely FIRST
2. Ask ALL clarifying questions BEFORE modifying any documents
3. Only proceed to update analysis/plan after user has answered all questions
4. If new questions arise during recovery, ask them BEFORE continuing

## Confidence Assessment Protocol

**Run confidence assessments at these checkpoints and OUTPUT to user:**

| Checkpoint | When | Action if Low Confidence |
|------------|------|-------------------------|
| Issue Understanding | After user describes the problem | Ask clarifying questions |
| Root Cause | After investigating the issue | Confirm understanding with user |
| Recovery Plan | Before executing recovery steps | Get user approval |
| Resolution | After completing recovery | Verify with user |

**Format for confidence output:**
```
🔍 **Confidence Assessment** [Checkpoint Name]
- Confidence Level: High/Medium/Low
- Areas of uncertainty: [list any]
- Questions for user: [if any]
```

## When to Use This Skill

Invoke this skill when:
- Implementation reveals analysis was wrong
- User requests scope change after planning
- External blockers prevent progress
- Tests fail in unexpected ways
- Rollback is needed

## Prerequisites

1. **JIRA issue number** is known
2. **Understanding of what went wrong** — user should describe the issue

**🔍 Output Confidence Assessment: Issue Understanding**

**Ask ALL clarifying questions about the issue BEFORE proceeding to any recovery scenario.**

## Recovery Scenarios

### Scenario 1: Analysis Was Incomplete

**Symptoms:**
- Discovering undocumented dependencies during implementation
- Finding affected components not identified in analysis
- Realizing the approach won't work as planned

**Recovery Steps:**

1. **Stop implementation** — Do not continue with flawed understanding

2. **🔍 Output Confidence Assessment: Root Cause**

3. **Document the gap** — Add to `analysis.md`:
   ```markdown
   ## Recovery Notes
   ### <Date> — Analysis Gap Discovered
   - **Issue**: [What was missed]
   - **Impact**: [How it affects the plan]
   - **Resolution**: [What needs to change]
   ```

3. **Update analysis** — Revise affected sections

4. **Re-confirm with user** — Present updated analysis

5. **Prompt for new session:**
   > "Analysis has been updated. Start a new session (or use the `handoff` tool to continue in a new thread) and invoke the **Task Planning** skill (see .agents/skills/task-planning/SKILL.md) to revise the implementation plan."

---

### Scenario 2: Scope Change

**Symptoms:**
- User requests additional features mid-implementation
- Requirements are clarified in a way that changes scope
- External factors require pivoting

**Recovery Steps:**

1. **Acknowledge the change** — Confirm understanding of new scope

2. **Assess impact:**
   - [ ] Is analysis still valid?
   - [ ] Does implementation plan need revision?
   - [ ] Does completed work need modification?

3. **Document scope change** — Add to `implementation-plan.md`:
   ```markdown
   ## Scope Changes
   ### <Date> — <Change Summary>
   - **Original scope**: [What was planned]
   - **New scope**: [What is now required]
   - **Affected phases**: [List phases impacted]
   - **Additional work**: [New tasks required]
   ```

4. **Revise implementation plan** — Add/modify phases as needed

5. **Get user approval** — Confirm revised plan before continuing

6. **Prompt for new session:**
   > "Plan has been revised. Start a new session (or use the `handoff` tool to continue in a new thread) and invoke the **Task Implementation** skill (see .agents/skills/task-implementation/SKILL.md) to continue with the updated plan."

---

### Scenario 3: Blocked Task

**Symptoms:**
- Waiting on external API, service, or resource
- Need user decision on ambiguous requirement
- Dependency on another team or system

**Recovery Steps:**

1. **Document the blocker** — Add to `implementation-plan.md`:
   ```markdown
   ## Blockers
   ### <Date> — <Blocker Summary>
   - **Blocked on**: [What is blocking progress]
   - **Waiting for**: [Who/what can unblock]
   - **Workaround**: [If any temporary solution exists]
   - **Status**: 🔴 Blocked
   ```

2. **Identify parallel work** — List tasks that can proceed independently

3. **Propose alternatives** — If workaround exists, present to user

4. **Set expectations:**
   > "This task is blocked on [X]. When the blocker is resolved, start a new session (or use the `handoff` tool to continue in a new thread) and invoke the **Task Implementation** skill (see .agents/skills/task-implementation/SKILL.md) to continue."

---

### Scenario 4: Test Failures Reveal Design Issue

**Symptoms:**
- Tests fail in unexpected ways
- Edge cases not considered in design
- Integration issues between components

**Recovery Steps:**

1. **Analyze failure** — Understand root cause, not just symptoms

2. **Categorize severity:**
   | Severity | Action |
   |----------|--------|
   | **Minor** | Fix in place, update tests, continue |
   | **Moderate** | Revise affected phase, update plan, get approval |
   | **Major** | Re-analyze, re-plan from scratch |

3. **For major issues** — Document in `implementation-plan.md`:
   ```markdown
   ## Design Revisions
   ### <Date> — <Issue Summary>
   - **Test failure**: [What failed]
   - **Root cause**: [Why it failed]
   - **Design flaw**: [What was wrong in approach]
   - **Revised approach**: [How to fix]
   ```

4. **Get user confirmation** for moderate/major changes

5. **Prompt for appropriate next step:**
   - Major: "Start new session (or use the `handoff` tool to continue in a new thread) → the **Task Analysis** skill (see .agents/skills/task-analysis/SKILL.md)"
   - Moderate: "Start new session (or use the `handoff` tool to continue in a new thread) → the **Task Planning** skill (see .agents/skills/task-planning/SKILL.md)"
   - Minor: Continue in current session

---

### Scenario 5: Rollback Required

**Symptoms:**
- Implementation broke existing functionality
- Changes are too risky to continue
- User requests reverting changes

**Recovery Steps:**

1. **Stop all changes** — Do not compound the problem

2. **Assess rollback scope:**
   - Which files were modified?
   - Are there committed changes to revert?
   - Is partial rollback possible?

3. **Execute rollback:**
   ```bash
   # If changes are uncommitted
   git checkout -- <file>
   
   # If changes are committed
   git revert <commit>
   ```

4. **Document the rollback** — Add to `implementation-plan.md`:
   ```markdown
   ## Rollback Record
   ### <Date> — Rollback Executed
   - **Reason**: [Why rollback was needed]
   - **Scope**: [What was reverted]
   - **Lessons learned**: [What went wrong]
   - **Next steps**: [How to proceed]
   ```

5. **CRITICAL: Do NOT immediately re-implement.**

6. **Present options to user:**
   > "Rollback complete. The previous approach did not work.
   >
   > Before making new changes, choose a path forward:
   > - **A) Re-analyze** — Start new session (or use the `handoff` tool to continue in a new thread) → the **Task Analysis** skill (see .agents/skills/task-analysis/SKILL.md) (recommended for major issues)
   > - **B) Re-plan** — Start new session (or use the `handoff` tool to continue in a new thread) → the **Task Planning** skill (see .agents/skills/task-planning/SKILL.md) (for minor adjustments)

7. **Based on user choice:**
   - **A)** Add `## Rollback Lessons` to analysis, hand off to the **Task Analysis** skill (see .agents/skills/task-analysis/SKILL.md) Use the `Task` tool or `handoff` tool for delegation.
   - **B)** Revise plan, hand off to the **Task Planning** skill (see .agents/skills/task-planning/SKILL.md) Use the `Task` tool or `handoff` tool for delegation.

---

## Quality Gates

**Important: Assess confidence at each step. If confidence is low, ask user for clarification before proceeding.**

Before returning to normal workflow:

- [ ] Root cause of issue is understood
- [ ] Relevant planning documents are updated
- [ ] User has confirmed the recovery approach
- [ ] Any completed work is still valid or has been adjusted
- [ ] Path forward is clear
- [ ] User understands they must start a new session

## Recovery Documentation

All recovery notes are added to existing planning documents:

| Document | Section |
|----------|---------|
| `analysis.md` | `## Recovery Notes` |
| `implementation-plan.md` | `## Scope Changes` |
| `implementation-plan.md` | `## Blockers` |
| `implementation-plan.md` | `## Design Revisions` |
| `implementation-plan.md` | `## Rollback Record` |

This keeps all task context in one place for traceability.

## Session End Protocol

After recovery is documented:

---

> ⚠️ **Recovery Complete**
>
> The issue has been documented and a path forward identified.
>
> **Next Step:** Start a new session (or use the `handoff` tool to continue in a new thread) and invoke the appropriate skill:
> - The **Task Analysis** skill (see .agents/skills/task-analysis/SKILL.md) — If re-analysis is needed
> - The **Task Planning** skill (see .agents/skills/task-planning/SKILL.md) — If plan revision is needed
> - The **Task Implementation** skill (see .agents/skills/task-implementation/SKILL.md) — If ready to resume
>
> Reference: `.docs/agentic-logs/<JIRA-ISSUE>/`

---

**Do NOT continue directly to the next phase in this session.**
````

## Success Metrics

- [ ] Issue fully understood before taking action
- [ ] Root cause identified and documented
- [ ] Confidence assessments output at each checkpoint
- [ ] Appropriate recovery scenario followed
- [ ] Relevant planning documents updated with recovery notes
- [ ] User confirmed the recovery approach
- [ ] Clear path forward identified
- [ ] Explicit session end directive provided with next skill recommendation

## Failure Modes

- Taking recovery action before fully understanding the issue
- Not documenting the issue in planning documents
- Attempting to fix major issues ad-hoc without proper analysis
- Continuing directly to next phase in same session
- Not capturing lessons learned from rollbacks
- Skipping user confirmation on recovery approach
- Re-implementing immediately after rollback without re-analysis
- Not presenting options to user when multiple paths exist
