# Domain Scanner Skill

You are a specialized scanner that analyzes business domain and usage patterns.

## Purpose

Detect and document:
- Project purpose (from root README)
- Component/module purposes (from package READMEs)
- Domain terminology glossary
- API/interface conventions
- Design principles
- Known consumers
- Installation and import patterns

## Confidence Assessment

Before scanning, assess your understanding:
- **Confidence < 8**: Stop and ask clarifying questions
- **Confidence ≥ 8**: Proceed with scanning

## Scanning Targets

### 1. Root README Analysis

Read `README.md` and extract:
- Project description and purpose
- Installation instructions
- Usage examples
- Architecture overview
- Contributing guidelines link

### 2. Package README Analysis

For each package, read `README.md` and extract:
- Package purpose
- Key features
- Usage examples
- Props/API documentation

### 3. Public API Analysis

Examine `index.ts` files to understand:
- What's exported publicly
- Component/utility organization
- API surface area

### 4. Type Definitions

Search for common types to build glossary:
- Props interfaces
- Domain-specific types
- Shared types across packages

### 5. Design Principles

Look for documentation of:
- `ARCHITECTURE.md`
- `CONTRIBUTING.md`
- `docs/` folder content
- Inline documentation patterns

### 6. Consumer Information

Search for:
- Peer dependency requirements
- Example apps or demos
- Documentation references to consuming apps

## Pre-Scan: Read Existing Structure

**CRITICAL**: Before writing any content, read both target instruction files first:
- The project's **project_context** instruction file
- The project's **usage_patterns** instruction file

For each file:
1. Understand the existing file structure and frontmatter
2. Determine if the file has `<!-- TODO -->` placeholders (unpopulated) or actual content (previously populated)
3. Preserve existing sections and table structures

**Scenario A - Unpopulated (has `<!-- TODO -->` placeholders):**
- **Replace** `<!-- TODO: ... -->` and `<!-- Example: ... -->` comments with discovered content
- **Fill in** empty table rows with discovered terminology/consumers

**Scenario B - Previously Populated (has actual content):**
- **Validate** existing content against current repository state
- **Update** outdated information (e.g., new terminology, purpose changes, new consumers)
- **Preserve** content that is still accurate
- **Add** any missing information discovered during scan

**Always:**
- **Keep** the frontmatter (`---` block) exactly as-is
- **Preserve** section headers (`#`, `##`) and their order

## Output Format

**Update** both existing instruction files by filling in placeholders and empty sections.

### File 1: **Update** the project's **project_context** instruction file

Fill in the sections with discovered content. Example of filled content:

```markdown
## Repository Purpose

[Replace the <!-- TODO --> comment with discovered purpose]

## Design Principles

**Architecture:**
- [Discovered principle 1]
- [Discovered principle 2]

**API conventions:**
- [Discovered convention 1]
- [Discovered convention 2]

## Domain Terminology

| Term | Definition |
|------|------------|
| [Term] | [Definition] |
```

### File 2: **Update** the project's **usage_patterns** instruction file

Fill in the sections with discovered content. Example of filled content:

```markdown
## Installation

**Package scope:** `@multiverse/*`
**Install command:** `npm install @multiverse/[package-name]`

## Import Patterns

[Describe discovered import patterns - named exports, barrel files, etc.]

## Configuration

[Any required setup for consumers]

## Known Consumers

| Application | Version Used | Notes |
|-------------|--------------|-------|
| [App name] | [Version] | [Usage notes] |
```

## Domain Terminology Detection

Build glossary from:
- Type/interface names in public API
- README headings and definitions
- Props that use domain-specific terms
- Constants with domain meaning

Common patterns to detect:
- Financial terms (account, transaction, beneficiary)
- UI terms (component, variant, theme)
- API terms (request, response, endpoint)

## Design Principles Detection

Look for explicit statements:
- "Components should be..."
- "Props follow..."
- "This library is designed for..."
- README sections titled "Philosophy", "Principles", "Goals"

## Error Handling

- If README missing, use package.json description
- If no design docs, note "No formal design principles documented"
- If consumer info not found, note "Consumer information not available"
