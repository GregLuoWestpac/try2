# Multiverse UI Scanner Skill

You are a specialized scanner that analyzes multiverse-ui-common-library component usage in the current project and generates contextual documentation.

## Purpose

Detect and document:
- Which multiverse-ui-common-library components are used in this project
- Props interfaces for each used component
- Available variants (size, variant, etc.)
- Usage locations within the codebase
- All available components in the library

## Confidence Assessment

Before scanning, assess your understanding:
- **Confidence < 8**: Stop and ask clarifying questions
- **Confidence ≥ 8**: Proceed with scanning

## Prerequisites

- `BITBUCKET_PAT` must be defined in the project `.env` file
- Network access to `bitbucket.srv.westpac.com.au`

## Skill Reference

Use the **Multiverse UI Fetch** skill (see .agents/skills/multiverse-ui-fetch/SKILL.md) for detailed fetch instructions.

## Scanning Workflow

### Phase 1: Setup Authentication

Read the `BITBUCKET_PAT` from the project `.env` file:

**PowerShell (Windows):**
```powershell
$envContent = Get-Content ".github/.env" -Raw
$pat = ($envContent | Select-String -Pattern 'BITBUCKET_PAT=["'']?([^"''\r\n]+)["'']?').Matches.Groups[1].Value
$headers = @{
    "Authorization" = "Bearer $pat"
    "Content-Type" = "application/json"
}
```

**Bash (macOS/Linux):**
```bash
pat=$(grep -E '^BITBUCKET_PAT=' .github/.env | sed -E 's/^BITBUCKET_PAT=["'\'']*([^"'\'']*)["'\'']*$/\1/')
# Use pat in curl headers: -H "Authorization: Bearer $pat" -H "Content-Type: application/json"
```

### Phase 2: Discover Local Usage

Search the current project for multiverse-ui-common-library imports:

1. **Find component imports:**
   ```
   grep: from ['"]@wdp/multiverse-ui-common['"]
   ```
   Also try variations:
   ```
   grep: from ['"]multiverse-ui-common-library['"]
   ```
   Extract: `import { Button, Card, Modal } from '@wdp/multiverse-ui-common'`

2. **Record usage locations:**
   - Which files import each component
   - How components are used (common prop patterns)

### Phase 3: Fetch Remote Definitions

Following the skill instructions:

1. **Fetch package version** from Bitbucket repository

   **PowerShell (Windows):**
   ```powershell
   $url = "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/raw/package.json?at=refs/heads/master"
   $packageJson = Invoke-RestMethod -Uri $url -Headers $headers
   ```

   **Bash (macOS/Linux):**
   ```bash
   url="https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/raw/package.json?at=refs/heads/master"
   packageJson=$(curl -s -H "Authorization: Bearer $pat" -H "Content-Type: application/json" "$url")
   ```

2. **Explore repository structure**

   **PowerShell (Windows):**
   ```powershell
   $url = "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/files/src?at=refs/heads/master"
   $files = Invoke-RestMethod -Uri $url -Headers $headers
   ```

   **Bash (macOS/Linux):**
   ```bash
   url="https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/WDP/repos/multiverse-ui-common-library/files/src?at=refs/heads/master"
   files=$(curl -s -H "Authorization: Bearer $pat" -H "Content-Type: application/json" "$url")
   ```

3. **For each discovered component**, fetch:
   - Type definition files (`.types.ts` or similar)
   - Component implementation (for default values)

4. **Fetch main index** for full component catalog

### Phase 4: Parse and Extract

From fetched TypeScript files, extract:

| Data | Source | Example |
|------|--------|---------|
| Props interface | `.types.ts` | `ButtonProps` |
| Prop names | Interface members | `size`, `variant`, `disabled` |
| Prop types | Type annotations | `'small' \| 'medium' \| 'large'` |
| Required/optional | `?` modifier | `size?` = optional |
| Defaults | Component file | `size = 'medium'` |
| Variants | Union types | `variant: 'primary' \| 'secondary'` |

### Phase 5: Save Intermediate Data

Write raw fetched data to `.agents/instructions/multiverse-ui-components.json` as an intermediate working file. This file is used only during the scan and **must be deleted** in the cleanup phase.

### Phase 6: Generate Documentation

Update the project's **multiverse-ui** instruction file with:

1. **Version and metadata**
2. **Components used in this project** (focused props — see Output Sizing below)
3. **Full component catalog** (collapsed)
4. **Common patterns** observed in codebase

### Phase 7: Cleanup

Delete the intermediate JSON file:

```powershell
Remove-Item -Path ".agents/instructions/multiverse-ui-components.json" -ErrorAction SilentlyContinue
```

```bash
rm -f .agents/instructions/multiverse-ui-components.json
```

If the scan fails partway through, still attempt cleanup.

## Pre-Scan: Read Existing Structure

**CRITICAL**: Before writing any content, read the project's **multiverse-ui** instruction file first to:
1. Understand the existing file structure and frontmatter
2. Determine if the file has placeholders (unpopulated) or actual content (previously populated)
3. Preserve existing sections

**Scenario A - Unpopulated/Missing:**
- Create or fill in all sections with discovered content

**Scenario B - Previously Populated:**
- Compare version - if library version changed, refresh all data
- Update component list if new imports discovered
- Preserve manually added notes/examples

**Always:**
- Keep the frontmatter exactly as-is
- Preserve section headers and their order

## Output Sizing

The instruction file should capture **enough information to guide implementation** — no less, no more.

**Guidelines:**
- For each component, include only **props that affect visual output or behavior** (variants, size, state). Omit inherited HTML/React props (className, style, children, onClick, ref, etc.) unless the component handles them in a notable way.
- Collapse rarely-used or self-explanatory props into a single line note (e.g., "Also accepts standard HTML div attributes").
- Keep the **Variants** list — these are the most useful for implementation guidance.
- The full component catalog stays in a collapsed `<details>` block.
- Target: the file length should be proportional to the number of components used. A typical project using 5-8 components should produce roughly 150-300 lines.

## Output Format

Update the project's **multiverse-ui** instruction file:

```markdown
---
applyTo: "**"
description: "Multiverse UI Common Library component reference and usage patterns"
---

# Multiverse UI Common Library Reference

> **Version**: x.x.x
> **Last Updated**: YYYY-MM-DD
>
> Auto-generated by the Multiverse UI Scanner. Regenerate when upgrading the library or adding new component usage.

## Overview

This project uses `multiverse-ui-common-library` - the WDP shared UI component library.

**Repository**: https://bitbucket.srv.westpac.com.au/projects/WDP/repos/multiverse-ui-common-library

## Components Used in This Project

### MVAlert

**Import:** `import { MVAlert } from '@mesh-tenant-multiverse-ui-common/mv-alert'`

**Used in:** `src/components/Notifications.tsx`

**Key Props:**
| Prop | Type | Default | Notes |
|------|------|---------|-------|
| type | 'info' \| 'warning' \| 'error' \| 'success' | 'info' | Alert severity |
| dismissible | boolean | false | Show close button |

Also accepts standard HTML div attributes.

**Variants:**
- **type**: info, warning, error, success

[Repeat for each component...]

## All Available Components

<details>
<summary>Full component list (X components)</summary>

mv-accordion, mv-alert, mv-card, ...

</details>

## Usage Patterns in This Project

### Common Prop Combinations

```tsx
// Info alert
<MVAlert type="info">Information message</MVAlert>

// Dismissible error
<MVAlert type="error" dismissible>Something went wrong</MVAlert>
```

## Related Documentation

- [Bitbucket Repository](https://bitbucket.srv.westpac.com.au/projects/WDP/repos/multiverse-ui-common-library)
```

## Error Handling

| Error | Action |
|-------|--------|
| 401 Unauthorized | Check BITBUCKET_PAT in the project `.env` file, may need regeneration |
| 403 Forbidden | PAT lacks read access to WDP project |
| 404 Not Found | Component or path doesn't exist, check repository structure |
| Network error | Check VPN connection, retry once, then report failure |
| No imports found | Report "No multiverse-ui-common-library usage detected" |
| Parse error | Include raw type definition for manual review |

## Validation

After updating the instruction file:

1. Verify all discovered components have documentation
2. Confirm props tables are properly formatted
3. Check that usage locations are accurate
4. Ensure version matches current library version in project

## Integration

This scanner is invoked by the main **Repository Scanner** during Phase 3 (Conditional Scanners) when `@wdp/multiverse-ui-common` or `multiverse-ui-common-library` is detected in project dependencies or imports. It runs in parallel with other conditional scanners (e.g., the **Westpac UI Scanner**).

**Trigger when:**
- Setting up a new project using multiverse-ui-common-library
- Upgrading the library version
- Adding new component imports
- Onboarding developers unfamiliar with the library
