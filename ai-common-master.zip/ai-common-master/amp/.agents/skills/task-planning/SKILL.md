---
name: task-planning
description: Creates detailed implementation plans from analysis documents — produces plan.md artifact. Use after task analysis is complete and ready for implementation planning.
---

# Task Planning Skill

You are a senior software engineer that creates detailed implementation plans from analysis documents.

## Purpose

Transform analysis into actionable plans:
- Break work into phases/steps
- Specify testing strategy
- Document rollback procedures

## CRITICAL: Session Boundary

**This skill ONLY performs planning.** When planning is complete:

1. Save the implementation plan
2. Present plan to user
3. Get user approval
4. **STOP and prompt user to start a new session** for implementation

Do NOT proceed to implementation within this session.

## CRITICAL: Questions First - No Files Until Clarity

**DO NOT create implementation-plan.md until ALL clarifying questions are answered.**

1. Review analysis and identify any gaps or questions FIRST
2. Ask ALL clarifying questions BEFORE creating the plan file
3. Only proceed to create implementation-plan.md after user has answered all questions
4. If questions arise during planning, ask them BEFORE writing to files

## Confidence Assessment Protocol

**Run confidence assessments at these checkpoints and OUTPUT to user:**

| Checkpoint | When | Action if Low Confidence |
|------------|------|-------------------------|
| Analysis Review | After reviewing analysis.md | Ask user about unclear areas |
| Phase Design | After designing each phase | Confirm approach with user |
| Reuse Validation | After identifying components to reuse | Confirm selections with user |
| Plan Completion | Before finalizing plan | Present full plan for approval |

**Format for confidence output:**
```
🔍 **Confidence Assessment** [Checkpoint Name]
- Confidence Level: High/Medium/Low
- Areas of uncertainty: [list any]
- Questions for user: [if any]
```

## Prerequisites

Before planning, verify:

1. **JIRA issue number** is known
2. **Analysis document exists:** `.docs/agentic-logs/<JIRA-ISSUE>/analysis.md`
3. **Analysis is confirmed** by user

If analysis doesn't exist or needs revision, hand off to the **Task Analysis** skill (see .agents/skills/task-analysis/SKILL.md). Use the `Task` tool or `handoff` tool for delegation.

## Workflow

### Step 1: Load Analysis

Read `.docs/agentic-logs/<JIRA-ISSUE>/analysis.md` and review:
- Current state of the codebase in relevant areas
- Affected components and their impact
- Proposed approach
- Risks and considerations
- Any constraints identified
- **Reusable components identified** (from analysis)

If analysis is incomplete or outdated, **STOP** and recommend returning to analysis.

**🔍 Output Confidence Assessment: Analysis Review**

**Ask any clarifying questions NOW before creating the plan.**

**📝 Capture User Clarifications:**
As users answer questions during planning, record each Q&A pair to include in the implementation plan. This ensures planning decisions and context are preserved.

### Step 2: Create Implementation Plan

**ONLY create this file after ALL questions are answered.**

**CRITICAL: Reuse-First Principle**
- Each phase MUST prioritize using existing components/libraries identified in analysis
- If a phase requires creating something new, it must reference that user approved this in analysis
- DO NOT plan to create new utilities/components if existing ones can be reused or extended

Create `.docs/agentic-logs/<JIRA-ISSUE>/implementation-plan.md` with this structure:

```markdown
# Implementation Plan: <JIRA-ISSUE>

## JIRA Issue
- Issue: <JIRA-ISSUE>
- Link: <!-- Add JIRA URL -->

## Analysis Reference
See [analysis.md] for full context.

## Acceptance Criteria
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3

## Implementation Phases

### Phase 1: <Name>
**Goal:** What this phase achieves

**Reuse:** Components/libraries to use from existing codebase

**Steps:**
1. Step description
   - File: `path/to/file.ts`
   - Changes: What will be modified
2. Step description

**Verification:** How to verify this phase is complete

**🔍 Output Confidence Assessment: Phase Design (after each phase)**

---

### Phase 2: <Name>
**Goal:** What this phase achieves

**Steps:**
1. Step description

**Verification:** How to verify this phase is complete

---

## Testing Strategy

### Unit Tests
- Test file: `path/to/file.test.ts`
- Test cases to add:
  - [ ] Test case 1
  - [ ] Test case 2

### Integration Tests
- Integration points to verify

### Manual Verification
- Steps to manually verify the change works

## Rollback Plan

If issues arise:
1. Revert step description
2. Commands to execute

## User Clarifications Log
Document all clarifications received from the user during planning.

| Question | User Response | Date |
|----------|---------------|------|
| [Question asked] | [User's answer] | [Date] |

## Progress Tracking

| Phase | Status | Notes |
|-------|--------|-------|
| Phase 1 | ⬜ Not Started | |
| Phase 2 | ⬜ Not Started | |
| Testing | ⬜ Not Started | |

Status: ⬜ Not Started | 🔄 In Progress | ✅ Complete | ❌ Blocked
```

### Step 3: Review Plan with User

**🔍 Output Confidence Assessment: Plan Completion**

Present the implementation plan and confirm:
- Acceptance criteria are complete and testable
- Phases are appropriately scoped
- **Reuse of existing components is maximized**
- Testing strategy is adequate
- User approves the plan

## Quality Gates

Before completing planning, verify:
- [ ] Analysis document has been reviewed
- [ ] Implementation plan has clear acceptance criteria
- [ ] Phases are broken into verifiable steps
- [ ] Each phase has verification criteria
- [ ] Testing strategy is defined
- [ ] Rollback plan is documented
- [ ] User has approved the plan

## Session End Protocol

Once plan is approved, present this message:

---

> ✅ **Planning Complete**
>
> The implementation plan has been saved to:
> `.docs/agentic-logs/<JIRA-ISSUE>/implementation-plan.md`
>
> **⚠️ REQUIRED: Start a new chat session before implementation.** (or use the `handoff` tool to continue in a new thread)
>
> In your new session, invoke the **Task Implementation** skill (see .agents/skills/task-implementation/SKILL.md) and reference:
> - JIRA Issue: `<JIRA-ISSUE>`
> - Plan: `.docs/agentic-logs/<JIRA-ISSUE>/implementation-plan.md`
>
> This ensures a fresh context window for the implementation phase.

---

**Do NOT continue to implementation in this session.**

## Success Metrics

- [ ] Analysis document reviewed and understood
- [ ] All clarifying questions asked BEFORE plan creation
- [ ] Implementation plan created with all required sections
- [ ] Acceptance criteria are clear and testable
- [ ] Phases are appropriately scoped with verification criteria
- [ ] Reuse of existing components is maximized
- [ ] Testing strategy defined
- [ ] Rollback plan documented
- [ ] User has approved the plan
- [ ] Explicit session end directive provided

## Failure Modes

- Creating implementation-plan.md before all questions are answered
- Proceeding to implementation within the same session
- Phases too large or not independently verifiable
- Missing testing strategy or rollback plan
- Not referencing reusable components from analysis
- Planning to create new components when existing ones could be reused
- Acceptance criteria that are vague or untestable
- Not getting user approval before session end
