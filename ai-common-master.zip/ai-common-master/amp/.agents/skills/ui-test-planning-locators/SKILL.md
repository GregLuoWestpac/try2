---
name: ui-test-planning-locators
description: Plans element locator identification strategy for UI tests. Use as a sub-skill during UI test planning to identify page element selectors.
---

# UI Test Planning - Locators Skill

Plan **Phase 2 only**: Element locator identification.

> **Framework Agnostic**: Locator strategies apply across frameworks. Project-specific paths are in SKILL.md.

## Skill File (REQUIRED)

**Read the project-specific skill file:**
the **UI Test Planning** skill (see .agents/skills/ui-test-planning/SKILL.md)

## Context Strategy: Use Sub-Skills

Delegate element extraction to a sub-skill:

Invoke a sub-skill with the following context:
- Read implementation-plan.md (path from SKILL.md) Phase 1 section only.
- Extract all UI elements mentioned in Gherkin steps.
- Return as JSON array: [{element, action, suggestedStrategy}]
- Example: [{element: "loginButton", action: "click", suggestedStrategy: "id"}]

## Locator Priority (Universal)

`id` → `data-testid` → `name` → `role` → `css` → `xpath` (last resort)

> **Note**: Prefer semantic selectors. Avoid position-based or text-based locators.

## Process

1. **Read SKILL.md** for locator storage path and conventions
2. **Use sub-skill** to extract UI elements from Phase 1
3. **Build locator table** from extracted data
4. **Append Phase 2** to implementation-plan.md (path from SKILL.md)

## Output Format

Append to implementation-plan.md (path from SKILL.md):

```markdown
## Phase 2: Locators

**Directory**: `[locator directory from SKILL.md]`
**File**: `[locator file pattern from SKILL.md]`

| Element | Strategy | Value | Notes |
|---------|----------|-------|-------|
| <elem> | id | <val> | Stable |

### Checklist
- [ ] Stable locators (id/data-testid preferred)
- [ ] No position-based XPath
- [ ] Locators stored per SKILL.md conventions
```

## Rules

- **Locators only** — Don't plan Page Objects
- **Flag unstable** — Document XPath risk
- **Use sub-skill** for reading if file > 50 lines
