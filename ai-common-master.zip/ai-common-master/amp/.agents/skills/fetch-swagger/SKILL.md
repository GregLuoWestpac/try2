---
name: fetch-swagger
description: Fetches a CAP API swagger/OpenAPI spec from the Westpac mesh schema registry and saves it locally as YAML. Use when you need to download a swagger spec before generating mockoon data.
---

# Fetch Swagger Skill

Fetches CAP API swagger specs from the Westpac mesh schema registry and saves them locally for use as context by other agents (e.g., @generate-mockoon).

## What This Skill Does

1. **Parse** the swagger URL — handles both the viewer URL (`swagger.mesh.westpac.com.au/?url=...`) and direct schema URLs
2. **Fetch** the OpenAPI YAML from the mesh registry
3. **Save** to `swagger-output/<component-name>/openapi.yaml`
4. **Extract metadata** (title, version, base path, endpoints)

## Input Formats

All of these work:

```
# Full swagger viewer URL (just copy from browser)
https://swagger.mesh.westpac.com.au/?url=https://schema.mesh.westpac.com.au/component/wdp-cap-prodsvcadm-proddealacctadm-instl-arrngmntsvcng-v1-api/master/openapi.yaml

# Direct schema URL
https://schema.mesh.westpac.com.au/component/wdp-cap-.../master/openapi.yaml

# Just the CAP API name (auto-discovers URL)
cap-prodsvcadm-proddealacctadm-instl-arrngmntsvcng-v1
```

## Workflow

### Step 1: Run the Fetch Command

```bash
node tools/mockoon-gen/cli.js fetch <input>
```

Where `<input>` is one of:

- A swagger viewer URL
- A direct schema URL
- A CAP API name

### Step 2: Report Results

Show the user:

- Component name
- Title and version
- Available endpoints
- File saved location
- Next step suggestion

## Auto-Discovery

When given just a CAP API name (e.g., `cap-prodsvcadm-proddealacctadm-instl-arrngmntsvcng-v1`), the script automatically tries multiple URL patterns:

1. `<name>-api/master/openapi.yaml`
2. `<name>-serviceproxy/master/swagger.yaml`
3. `wdp-<name>-api/master/openapi.yaml`
4. `wdp-<name>-serviceproxy/master/swagger.yaml`
5. Shortened name variants

Successfully discovered paths are cached in `swagger-output/swagger-paths.json` for instant re-fetch.

## Output

```
swagger-output/
├── <component-name>/
│   ├── openapi.yaml       ← The swagger spec
│   └── metadata.yaml      ← Component name, title, version, endpoints
└── swagger-paths.json     ← Cache of discovered URL paths
```

## After Fetching

Use the fetched swagger file with the @generate-mockoon agent:

```
Generate mockoon data from swagger-output/<component>/openapi.yaml
```
