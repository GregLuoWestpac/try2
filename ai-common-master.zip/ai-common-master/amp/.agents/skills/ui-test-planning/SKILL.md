---
name: ui-test-planning
description: Creates implementation plans for UI BDD tests — coordinates locator and code planning phases. Use after test cases are approved and ready for implementation planning.
---

# UI Test Planning Skill

You **orchestrate** UI test planning by delegating to specialized sub-skills. This prevents context overflow by executing each phase in a fresh context with focused instructions.

> **Framework Agnostic**: This orchestrator works with any test framework (Selenium, Playwright, Mobile, etc.). Project-specific paths and patterns are defined in the SKILL.md file.

## Skill File (REQUIRED)

**Before proceeding, read the project-specific skill file:**
the **UI Test Planning** skill (see .agents/skills/ui-test-planning/SKILL.md)

The skill file contains:
- Project-specific folder structures and paths
- Output document locations and templates
- Framework-specific conventions (Gradle, Maven, npm, etc.)
- Locator storage patterns

## Critical: Delegate to Sub-Skills

**DO NOT try to do all phases yourself.** Delegate to these dedicated agents: Use the `Task` tool or `handoff` tool for delegation.

| Phase | Skill | Responsibility |
|-------|-------|----------------|
| 1 | *(handled directly)* | Reference Gherkin from test-cases.md |
| 2 | the **UI Test Planning Locators** skill (see .agents/skills/ui-test-planning-locators/SKILL.md) | Element locators |
| 3-6 | the **UI Test Planning Code** skill (see .agents/skills/ui-test-planning-code/SKILL.md) | Page/Glue/Steps/Runner design |

## Workflow

### 1. Validate Prerequisites (Quick Check)

Read only first 30 lines of test cases file to confirm existence. Path defined in SKILL.md.

If missing → direct user to the **UI Test Case Generation** skill (see .agents/skills/ui-test-case-generation/SKILL.md).

### 2. Initialize Plan Document

Create implementation plan document (path defined in SKILL.md):

```markdown
# UI Test Implementation Plan: <ISSUE-ID>

**Created**: <date>
**Test Cases**: [test-cases.md](.docs/agentic-logs/<JIRA-ISSUE>/test-cases.md)
**Suite Tag**: @<SuiteTag>

## Acceptance Criteria
- [ ] Tests pass in target environment
- [ ] Locators use stable selectors
- [ ] Code follows project patterns

---
```

### 3. Execute Phases via Sub-Skills

Invoke each sub-skill sequentially:

#### Phase 1: Feature File (Direct - No Sub-Skill)

The Gherkin scenarios already exist in `test-cases.md` from the **UI Test Case Generation** skill (see .agents/skills/ui-test-case-generation/SKILL.md).

**Do NOT recreate scenarios.** Instead:
1. Read the Gherkin section from test-cases.md
2. Extract: feature name, scenario titles, target file path
3. Append Phase 1 reference to implementation-plan.md:

```markdown
## Phase 1: Feature File

**Source**: [test-cases.md](.docs/agentic-logs/<JIRA-ISSUE>/test-cases.md) (Gherkin Scenarios section)
**Target**: `[feature file path from SKILL.md]`
**Tags**: @<SuiteTag> @<ISSUE-ID>

### Scenarios to Implement
| ID | Scenario Title |
|----|----------------|
| TC01 | [from test-cases.md] |
| TC02 | [from test-cases.md] |

### Checklist
- [ ] Copy Gherkin from test-cases.md
- [ ] Verify suite + issue tags
```

#### Phase 2: Locators

Delegate to the **UI Test Planning Locators** skill (see .agents/skills/ui-test-planning-locators/SKILL.md) with the following context: Use the `Task` tool or `handoff` tool for delegation.

- Issue ID: <ISSUE-ID>
- Input: implementation-plan.md (Phase 1)
- Output: Append Phase 2 to implementation plan
- Skill file: the **UI Test Planning** skill (see .agents/skills/ui-test-planning/SKILL.md)

The skill should execute its workflow completely and return the count of elements and any unstable locator warnings.

#### Phases 3-6: Code Design

Delegate to the **UI Test Planning Code** skill (see .agents/skills/ui-test-planning-code/SKILL.md) with the following context: Use the `Task` tool or `handoff` tool for delegation.

- Issue ID: <ISSUE-ID>
- Input: implementation-plan.md (Phases 1-2)
- Output: Append Phases 3-6 to implementation plan
- Skill file: the **UI Test Planning** skill (see .agents/skills/ui-test-planning/SKILL.md)

The skill should execute its workflow completely and return the file list and method count per layer.

### 4. Finalize & Handoff

After all sub-skills complete:
- Read implementation-plan.md summary section
- Present the complete plan to the user
- **Ask user to review the implementation plan**

**User Review Prompt:**
> "The implementation plan is ready. Please review it and let me know if you'd like any changes. Once you're satisfied, I'll direct you to the **UI Test Implementation** skill (see .agents/skills/ui-test-implementation/SKILL.md) to begin coding."

**On Approval:**
> "Great! To implement this plan, invoke the **UI Test Implementation** skill (see .agents/skills/ui-test-implementation/SKILL.md) with the issue ID." Use the `Task` tool or `handoff` tool for delegation.

## Sub-Skill Invocation Rules

- **Include skill file** — Sub-Skills need project-specific context from SKILL.md
- **Provide full context** — Include issue ID, input/output file paths
- **One phase per sub-skill** — Each sub-skill handles its designated phase(s)
- **Request summaries** — Ask for counts/titles, not full content
- **Sequential execution** — Wait for each phase to complete before starting next

## Error Handling

- **Sub-Skill fails** → Check error, re-invoke with clarified context
- **Analysis incomplete** → Return to the **UI Test Case Generation** skill (see .agents/skills/ui-test-case-generation/SKILL.md)
- **Locators unstable** → Flag in plan, suggest alternatives

## Output

- Creates implementation plan document (path defined in SKILL.md)
- Hands off to: the **UI Test Implementation** skill (see .agents/skills/ui-test-implementation/SKILL.md) Use the `Task` tool or `handoff` tool for delegation.
