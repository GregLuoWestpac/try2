# Onboarding Guide

How to set up AI agents in your repository using ai-common.

## Prerequisites

Before you begin, you need a Bitbucket Personal Access Token set as the `BITBUCKET_PAT` environment variable.

Follow the [AMP Setup Guide](https://confluence.srv.westpac.com.au/pages/viewpage.action?pageId=2295815963) (token setup steps are applicable to any AI tools) for instructions on creating your token, configuring environment variables, and resolving any SSL/certificate issues.

---

## Easy Path: Use the Onboard Prompt

The fastest way to onboard — let the AI do it for you. The onboard prompt lives at `src/prompts/onboard.md` in the ai-common repo.

### Copilot

1. Copy `src/prompts/onboard.md` from ai-common into your target repo at `.github/prompts/onboard.prompt.md`
2. Open Copilot Chat and type `/onboard` to use the prompt

### Amp

1. Copy the contents of `src/prompts/onboard.md` from ai-common into your target repo
2. In Amp, say **"Follow the steps in onboard.md"**
3. Amp will walk through the setup end-to-end

The onboard prompt will:
- Bootstrap the installer if needed
- Ask your project type
- Install all agents for both Copilot and Amp
- Configure Amp settings
- Clean up installer artifacts

**That's it!** Skip to [Step 6: Run Repo Scanner](#step-6-run-repo-scanner) after the prompt completes.

---

## Hard Path: Manual Step-by-Step

If you prefer to run each step yourself, follow the full manual process below.

### Step 1: Download sync-ai-common.js

Download the bootstrap script directly from Bitbucket into your repo root. This is the **only file** you need from ai-common to start.

**Windows (PowerShell):**
```powershell
cd ~/your-repo
Invoke-WebRequest -Uri "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/A014A6/repos/ai-common/raw/tools/sync-ai-common.js?at=refs/heads/master" -Headers @{Authorization="Bearer $env:BITBUCKET_PAT"} -OutFile "sync-ai-common.js"
```

**macOS / Linux:**
```bash
cd ~/your-repo
curl -fSL -H "Authorization: Bearer $BITBUCKET_PAT" \
  "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/A014A6/repos/ai-common/raw/tools/sync-ai-common.js?at=refs/heads/master" \
  -o sync-ai-common.js
```

### Step 2: Run Bootstrap

Run the bootstrap script from your repo root. It downloads the installer + config from Bitbucket.

```bash
node sync-ai-common.js
```

**What happens:**

1. Validates your `BITBUCKET_PAT`
2. Downloads `tools/install-agents/` folder from ai-common on Bitbucket
3. Saves `install-agent.js` + `ai-common-config.json` locally

**Result — new files in your repo:**

```
your-repo/
├── tools/
│   └── install-agents/
│       ├── install-agent.js      ← the installer
│       └── ai-common-config.json ← file mappings
└── sync-ai-common.js             ← you can commit this
```

This is a **one-time step**. Re-run only to update the installer.

### Step 3: Choose Project Type

Before running the installer, decide which **target type** matches your project:

| Target | Use For |
|--------|---------|
| `mfe` / `spa` / `widget` | Node.js frontend apps |
| `api` | Java / backend APIs |
| `generic` | Framework-agnostic (safe default) |

The target determines which technology-specific context is included in the installed agents. If unsure, use `generic`.

### Step 4: Run the Installer

Install all packages for both Copilot and Amp into your repo. Just specify your project target:

```bash
node tools/install-agents/install-agent.js --tool=both --target=<target>
```

Replace `<target>` with the type you chose in Step 3 (e.g. `mfe`, `api`, `generic`).

> **Advanced usage:** You can still install individual packages or use interactive mode if needed:
> ```bash
> # Interactive mode
> node tools/install-agents/install-agent.js --interactive
>
> # Install a single package
> node tools/install-agents/install-agent.js code-review --tool=both
> ```

**What happens:**

1. Reads `ai-common-config.json` for file mappings
2. Downloads each file from `copilot/` or `amp/` on Bitbucket
3. Writes files to `.github/` (Copilot) or `.agents/` (Amp)
4. Runs post-install actions (create configs, git hooks, etc.)
5. For Amp: merges skills list into `AGENTS.md` idempotently

**Flags:**

| Flag | Options | Default |
|------|---------|---------|
| `--tool` | copilot, amp, both | copilot |
| `--target` | generic, mfe, spa, widget, api | generic |
| `--force` | — | off (protect instruction files) |
| `--example` | test-ets-restassured | — |

> **Re-running the installer:** Agents, skills, and prompts are always updated to the latest version. **Instruction files** (project context with user-filled content) are protected and skipped if they already exist. Use `--force` to overwrite everything including instructions.

### Step 5: Configure Amp Settings

The Amp settings file lives at:
- **All platforms:** `~/.config/amp/settings.json` (e.g. `C:\Users\<user>\.config\amp\settings.json` on Windows)

Create the file if it doesn't exist, or merge these keys into your existing settings:

```json
{
  "amp.bitbucketToken": "YOUR_BITBUCKET_PAT",
  "amp.proxy": "http://your-proxy-host:port"
}
```

| Setting | Purpose |
|---------|---------|
| `amp.bitbucketToken` | Bitbucket Enterprise personal access token — enables the Librarian to search internal repos |
| `amp.proxy` | Corporate HTTP proxy — set if behind a proxy, omit if not |

### What gets deployed

**Copilot** → `.github/` directory:

```
.github/
├── copilot-instructions.md
├── agents/
│   ├── task-analysis.agent.md
│   ├── task-planning.agent.md
│   ├── code-review.agent.md
│   └── ...
├── skills/
│   ├── jira-fetch/SKILL.md
│   ├── pr-review-cli/SKILL.md
│   └── ...
├── prompts/
│   ├── code-review.prompt.md
│   └── jira-ticket.prompt.md
├── instructions/
│   ├── repo_overview.instructions.md
│   ├── project_context.instructions.md
│   └── ...
└── .env.example
```

**Amp** → `.agents/` + repo root:

```
AGENTS.md
.agents/
├── skills/
│   ├── task-analysis/SKILL.md
│   ├── task-planning/SKILL.md
│   ├── code-review/SKILL.md
│   ├── jira-fetch/SKILL.md
│   └── ...
└── instructions/
    ├── repo_overview.md
    ├── project_context.md
    └── ...
```

> **AGENTS.md merge:** If you already have an `AGENTS.md`, ai-common content is wrapped in `<!-- AI-COMMON:START/END -->` markers. Your existing content is preserved.

### Post-install (code-review package)

```bash
cd tools/pr-review
```

Configure `pr_review_bot.yaml.local` with your Bitbucket project/repo details.

---

## Step 6: Run Repo Scanner

The project context files have `<!-- TODO -->` placeholders. The repo-scanner agent fills them in automatically by analyzing your codebase.

**In Copilot:**
Open Chat → select **Repository Scanner** agent → ask it to scan.

**In Amp:**
> "Use the repo-scanner skill to scan this repository and populate the instruction files"

**What it scans (8 sub-scanners):**

| Scanner | What it Populates |
|---------|------------------|
| Structure | Directory layout, key files |
| Build & Dependencies | package.json, build tools, frameworks |
| Testing | Test framework, patterns, coverage |
| Patterns | Code conventions, naming, style |
| Domain | Business domain, feature areas |
| Workflows | CI/CD, release process |
| Westpac UI | @westpac/ui component usage |
| Multiverse UI | multiverse-ui-common-library usage |

**Alternative:** Use `--example=test-ets-restassured` during install to get pre-populated context (skips scanning).

---

## Step 7: Use AI Agents

The agents now understand your codebase. Available workflows:

- **Task Development** — Analyse a JIRA ticket → create a plan → implement → recover from errors
- **Code Review** — Automated PR review before push
- **E2E Test Automation** — Generate BDD test cases from requirements
- **Defect Triage** — Investigate bugs using Splunk logs + documentation
- **Mockoon Generator** — Fetch CAP API swagger specs and generate comprehensive mock data

### Environment setup (if using JIRA/Splunk features)

The installer creates `.github/.env.example` with all available tokens. Copy it and fill in your values:

```bash
cp .github/.env.example .github/.env
# Edit .github/.env with your PAT values
```

### Using in Copilot

1. Open Copilot Chat panel in VS Code
2. Click the agent dropdown at the top
3. Select an agent (e.g., **Task Analysis**, **Code Review**)
4. Start chatting — the agent follows its workflow automatically

Agents hand off to each other:
- Task Analysis → "Proceed to Planning" → Task Planning
- Task Planning → "Proceed to Implementation" → Task Implementation
- If errors → Task Recovery

### Using in Amp

**Using skills:**

To use a skill in Amp, ask it to **use** or **load** the skill by name:

> "Use the task-analysis skill to analyse JIRA ticket ABC-123"
> "Load the code-review skill and review my PR"
> "Use the repo-scanner skill to scan this repository"

Or just ask naturally — Amp reads `AGENTS.md` and knows what skills are available:
> "Review my PR"
> "Help me implement the changes from the analysis document"

Skills use the `handoff` tool or `Task` tool to delegate to other skills when needed.
