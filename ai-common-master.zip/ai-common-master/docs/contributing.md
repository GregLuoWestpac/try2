# Contributing to ai-common

This guide covers how to develop, add, and maintain agents and skills in ai-common.

## Quick Start: AI-Assisted Contributing

The fastest way to add or update content is to let your AI coding assistant do the heavy lifting. Open the `ai-common` workspace in your preferred AI tool and use one of the prompts below. The AI will read the manifest, follow the conventions, and generate everything for you.

> **Works with any AI coding tool** — Copilot, Amp, Cursor, Windsurf, or anything that can read your workspace files.

### Add a new agent

Paste this into your AI chat:

```
I want to add a new agent to ai-common.

Name: <your agent name>
Purpose: <what the agent does — 1-2 sentences>
Group: <which folder under src/agents/ — e.g. task-development, repo-scanner, or a new group>
Skills it uses: <list any existing skills it should invoke, or "none">
Delegates to: <list any existing agents it should hand off to, or "none">

Follow the contributing guide in docs/contributing.md. Specifically:
1. Create the agent source file in src/agents/<group>/
2. Add the entry to manifest.yaml with appropriate metadata
3. Add it to the correct installer package in manifest.yaml
4. Run the build (node tools/build.js)
5. Verify the generated output looks correct
```

### Add a new skill

```
I want to add a new skill.

Name: <your skill name>
Purpose: <what the skill does — 1-2 sentences>

Follow the contributing guide in docs/contributing.md. Specifically:
1. Create the skill source file in src/skills/
2. Add the entry to manifest.yaml
3. Add it to the correct installer package in manifest.yaml
4. Run the build (node tools/build.js)
5. Verify the generated output looks correct
```

### Add a new prompt

```
I want to add a new prompt.

Name: <your prompt name>
Purpose: <what the prompt does — 1-2 sentences>
Merge into skill (Amp): <skill name to merge into, or "none">

Follow the contributing guide in docs/contributing.md. Specifically:
1. Create the prompt source file in src/prompts/
2. Add the entry to manifest.yaml
3. Add it to the correct installer package in manifest.yaml
4. Run the build (node tools/build.js)
5. Verify the generated output looks correct
```

### Update existing content

```
I want to update the <agent/skill/prompt/check> called "<name>".

The change I want to make: <describe what to change>

Follow the contributing guide in docs/contributing.md:
1. Edit the source file in src/ (not the generated output)
2. If metadata changed, update manifest.yaml too
3. Run the build (node tools/build.js)
4. Verify the generated output looks correct
```

### Tips for AI-assisted contributing

- **Always point the AI to `docs/contributing.md`** — it contains the conventions the AI needs to follow (bold references, build markers, manifest structure).
- **Let the AI run the build** — it can execute `node tools/build.js` and check the output for you.
- **Review what it generates** — check the `src/` file reads naturally, the manifest entry is correct, and the build output looks right.
- **Commit everything** — `src/` source, `manifest.yaml`, generated output directories, and `tools/install-agents/ai-common-config.json`.

---

The sections below cover the same process in detail if you prefer to work manually or need to understand how things work under the hood.

## How It Works

You write agent and skill instructions as **plain markdown** in `src/`. A build script reads `manifest.yaml` and generates tool-specific output for each supported AI tool (currently Copilot and Amp). An installer deploys that output into target repos.

```
  You write                Build generates           Installer deploys
┌──────────────┐        ┌─────────────────┐        ┌──────────────────┐
│ src/         │        │ copilot/        │        │ target repo      │
│  agents/     │──build─│ amp/            │─install─│  .github/agents/ │
│  skills/     │   ▲    │ (one dir per    │        │  .agents/skills/ │
│  prompts/    │   │    │  supported tool)│        │  etc.            │
│  checks/     │   │    └─────────────────┘        └──────────────────┘
├──────────────┤   │
│ manifest.yaml│───┘    Adds frontmatter, resolves
│ (metadata)   │        paths, renames terminology
└──────────────┘
```

**You never need to write tool-specific files.** The build handles frontmatter, paths, delegation syntax, and naming conventions for each tool. You focus on the workflow logic.

## Adding a New Agent

### Step 1: Write the agent source

Create `src/agents/<group>/<name>.md` with plain markdown — no frontmatter, no tool-specific paths.

Use **bold names** to reference other agents and skills. The build script resolves these to the correct paths for each tool automatically.

```markdown
# My Agent

You are an agent that does something useful.

## Workflow

1. Fetch the JIRA ticket using the **JIRA Fetch** skill
2. Analyse the codebase
3. Delegate to the **Task Planning** agent <!-- DELEGATE -->
```

See [Reference: Writing `src/` Files](#reference-writing-src-files) for the full pattern list.

### Step 2: Add to `manifest.yaml`

Add an entry under `agents:`. The top-level fields (`description`, `displayName`) are shared. Each tool section provides that tool's specific metadata:

```yaml
agents:
  my-agent:
    src: agents/<group>/my-agent.md
    description: Does something useful
    displayName: My Agent
    copilot:
      tools: [vscode, execute, read, edit, search]
      model: Claude Opus 4.6 (copilot)
```

Output is generated for all tools by default — no `amp:` section needed unless you want to override defaults. Set `copilot: false` or `amp: false` to skip a tool.

**Handoffs** (agent-to-agent delegation) are tool-specific features. Add them under the relevant tool section:

```yaml
    copilot:
      handoffs:
        - label: Proceed to Planning
          agent: Task Planning
          prompt: Analysis is complete. Create implementation plan.
          send: true
```

The build script handles the rest — Copilot gets `handoffs:` frontmatter, Amp gets inline text instructions.

### Step 3: Add to an installer package

In `manifest.yaml`, find `installer.packages` and add your agent's slug to the appropriate package:

```yaml
installer:
  packages:
    task-development:
      include:
        agents:
          - task-analysis
          - task-planning
          - my-agent              # ← add here
```

Or create a new package:

```yaml
    my-workflow:
      name: My Workflow
      description: What this package does
      target: [generic]
      include:
        agents: [my-agent]
        skills: [my-skill]
        prompts: [my-prompt]
      documentation: "https://..."
```

The installer config (`ai-common-config.json`) is auto-generated from this — no manual JSON editing needed.

### Step 4: Build, verify, commit

```bash
node tools/build.js
```

Check the generated output for each tool:
- `copilot/agents/my-agent.agent.md` — has Copilot frontmatter, `.github/` skill paths
- `amp/.agents/skills/my-agent/SKILL.md` — has Amp frontmatter, `.agents/` paths

Commit: `src/` source, `manifest.yaml`, `tools/install-agents/ai-common-config.json`, and all generated output directories.

### Step 5: Test in a target repo

The simplest way to test is to copy the generated output directly into a target repo:

```bash
# Copilot — copy the agent file
cp copilot/agents/my-agent.agent.md /path/to/target-repo/.github/agents/

# Amp — copy the skill directory
cp -r amp/.agents/skills/my-agent /path/to/target-repo/.agents/skills/
```

Then open the target repo in your AI tool and invoke the agent. If it needs changes, edit the `src/` file in ai-common, rebuild, and copy again.

> **Note:** The full installer (`install-agent.js`) automates this for production deployments — it downloads files from the repo, runs actions, and sets up config. You don't need it for local testing during development.

## Adding a New Skill

Skills are self-contained procedural instructions invoked by agents. Same process as agents but simpler — no handoffs or delegation.

1. Create `src/skills/<name>.md` (plain markdown, same conventions as agents)
2. Add to `manifest.yaml`:
   ```yaml
   skills:
     my-skill:
       src: skills/my-skill.md
       displayName: My Skill
       description: What this skill does
   ```
3. Add to a package's `include.skills` list
4. Build, verify, commit

## Adding a Prompt

Prompts are user-facing templates. Not all tools support them natively — the build script handles the differences:

- **Copilot**: generates a prompt file. Prompt can be invoked via `/prompt-name` in chat
- **Amp**: no native prompt files, but content can be merged into an existing skill

1. Create `src/prompts/<name>.md`
2. Add to `manifest.yaml`:
   ```yaml
   prompts:
     my-prompt:
       src: prompts/my-prompt.md
       copilot:
         description: What this prompt does
         agent: agent
       amp:
         mergeInto: target-skill    # optional: append to this skill's output
   ```
3. Add to a package's `include.prompts` list
4. Build and commit

When `mergeInto` is set, the prompt content is appended (after a `---` separator) to the target skill's output for that tool.

## Adding a Check

Checks are code review criteria. Not all tools support them — currently only Amp uses checks (via `amp review`).

1. Create `src/checks/<name>.md`
2. Add to `manifest.yaml`:
   ```yaml
   checks:
     my-check:
       src: checks/my-check.md
       description: What this check reviews
   ```
3. Checks are included in the foundation package by default (`checks: all`)
4. Build and commit

## Folding Sub-Agents

When agents form a parent/child group (e.g., repo-scanner and its sub-scanners), some tools support folding sub-agents into the parent's directory as reference documents. Other tools keep them as separate agent files.

Configure folding under the relevant tool section in `manifest.yaml`:

```yaml
agents:
  my-sub-agent:
    src: agents/group/my-sub-agent.md
    description: Does a specific scan
    displayName: My Sub Agent
    amp:
      foldInto: parent-agent
      referenceAs: sub-agent.md
    copilot:
      tools: [...]
```

The build script generates `reference/sub-agent.md` inside the parent's output directory for tools that support folding (Amp), and a standalone agent file for tools that don't (Copilot).

## Adding or Updating Examples

Examples provide pre-built instructions and skills for specific project types (e.g., Selenium + RestAssured). Each example has its own `manifest.yaml` and `src/` directory under `examples/<name>/`.

`build.js` auto-discovers `examples/*/manifest.yaml` and generates output for all supported tools — no flags needed.

### Example manifest structure

```yaml
skills:
  my-skill:
    src: skills/my-skill.md        # relative to examples/<name>/src/
    displayName: My Skill
    copilot:
      description: What this skill does
    amp:
      name: my-skill
      description: What this skill does

instructions:
  repo_overview:
    src: instructions/repo_overview.md
    copilot:
      applyTo: "**"

# Direct file copies (no transformation)
shared:
  - src: shared/templates/
    copilot: skills/shared/templates/
    amp: .agents/skills/shared/templates/
```

Run `node tools/build.js` — example output appears alongside the root build output.

## Updating Existing Content

Edit the source file in `src/`, run `node tools/build.js`, and commit the source change plus generated output. The manifest only changes when you add/remove items or change tool metadata.

## Reference: What Changes When

| Scenario | Files to edit |
|----------|--------------|
| Update agent/skill/check instructions | `src/` file only |
| Add/remove an agent, skill, or check | `src/` + `manifest.yaml` |
| Change tool metadata (tools, model, handoffs) | `manifest.yaml` (under that tool's section) |
| Fold a sub-agent or merge a prompt | `manifest.yaml` (under that tool's section) |
| Add support for a new AI tool | `manifest.yaml` + `tools/build.js` |
| Change installer packages | `manifest.yaml` (`installer.packages`) |

## Reference: Writing `src/` Files

### Generic references

Use **bold names** to reference agents, skills, and instructions. The build script resolves these to tool-specific paths:

| What | How to write it |
|------|----------------|
| Invoke a skill | `the **JIRA Fetch** skill` |
| Delegate to an agent | `delegate to the **Task Planning** agent <!-- DELEGATE -->` |
| Start a new session | `Start a new session <!-- NEW_SESSION --> and invoke...` |

The bold name must match the `displayName` in `manifest.yaml`.

### Build markers

HTML comment markers control per-tool text injection:

| Marker | What the build does |
|--------|---------------------|
| `<!-- DELEGATE -->` | Inserts tool-appropriate delegation instructions (or strips it for tools with native delegation) |
| `<!-- NEW_SESSION -->` | Inserts tool-appropriate session continuation guidance |

Place `<!-- DELEGATE -->` at the end of delegation lines. Place `<!-- NEW_SESSION -->` immediately after "session".

### Automatic terminology

The build script adapts terminology per tool — just write naturally using "agent":

| You write | Tools that use "skill" see |
|-----------|---------------------------|
| `# Task Analysis Agent` | `# Task Analysis Skill` |
| `You are a code review agent` | `You are a code review skill` |
| `downstream agents` | `downstream skills` |

Tools that use "agent" natively are unaffected.
