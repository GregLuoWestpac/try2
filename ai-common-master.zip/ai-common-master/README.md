# ai-common

Shared AI agents, skills, and tools for **Copilot** and **Amp** powered development.

## Quick Start

No need to clone ai-common — just get the onboard prompt into your repo and it handles everything else.

1. Set `BITBUCKET_PAT` env var with a Bitbucket personal access token (read access)
2. Download the onboard prompt into your repo:

   Windows (PowerShell):
   ```powershell
   New-Item -ItemType Directory -Force -Path ".github/prompts"
   Invoke-WebRequest -Uri "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/A014A6/repos/ai-common/raw/copilot/prompts/onboard.prompt.md?at=refs/heads/master" -Headers @{Authorization="Bearer $env:BITBUCKET_PAT"} -OutFile ".github/prompts/onboard.prompt.md"
   ```

   macOS / Linux:
   ```bash
   mkdir -p .github/prompts
   curl -fSL -H "Authorization: Bearer $BITBUCKET_PAT" "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/A014A6/repos/ai-common/raw/copilot/prompts/onboard.prompt.md?at=refs/heads/master" -o .github/prompts/onboard.prompt.md
   ```

3. Open Copilot Chat → run the **Onboard** prompt

The prompt handles bootstrap, installs all packages for both Copilot and Amp, and configures Amp settings automatically. You only need to specify the project type.

> **Full walkthrough:** [docs/onboarding.md](docs/onboarding.md) · **All installer options:** [compose.md](compose.md)

### Tool Dependencies

Each tool manages its own dependencies. Install only what you need:

```bash
cd tools/nodemcp   && npm install   # MCP server framework (required for docsearch/splunk)
cd tools/mcps/docsearch && npm install   # Docsearch provider
cd tools/pr-review && npm install   # PR review pipeline
cd tools/mockoon-gen && npm install   # Mockoon mock data generator
```

### Running Tools

Launcher scripts in `tools/` auto-detect missing dependencies and install them:

| What | Windows | Unix |
|------|---------|------|
| PR review | `tools\review.bat [--simple\|--complex]` | `tools/review.sh` |
| Docsearch MCP | `tools\mcp-docsearch.bat` | `tools/mcp-docsearch.sh` |
| Splunk MCP | `tools\mcp-splunk.bat` | `tools/mcp-splunk.sh` |
| All MCP providers | `tools\nodemcp.bat` | `tools/nodemcp.sh` |

Or run directly with Node:

```bash
node tools/pr-review/cli.js --help
node tools/nodemcp/cli.js --provider tools/mcps/docsearch --verbose
node tools/mcps/docsearch/ingest-dir.js --src examples/docsearch/solution-designs --store ./my-index
```

## What's in the Box

### Agent Packages

Installable via `install-agent.js`. Each package works with both **Copilot** and **Amp**.

| Package | Purpose | Agents |
|---------|---------|--------|
| **foundation** | Core instructions and principles — project context templates with `<!-- TODO -->` placeholders | Always installed automatically |
| **task-development** | Multi-phase feature development: analyse → plan → implement → recover | Task Analysis → Task Planning → Task Implementation → Task Recovery |
| **code-review-westpac** | AI-powered PR review with quick, standard, and deep modes | Code Review Westpac |
| **repo-scanner** | Scans a repo and auto-populates instruction files | Repository Scanner + 8 reference docs |
| **e2e-test-automation** | Three-phase E2E test pipeline: test case generation → planning → implementation | UI Test Workflow + 5 sub-agents |
| **defect-triage** | Autonomous bug triage and root cause analysis using Splunk + DocSearch MCPs | Triage Coordinator → Log Investigator / Doc Researcher → Root Cause Analyzer |
| **mockoon-gen** | Fetch CAP API swagger specs and generate Mockoon mock data | Fetch Swagger + Generate Mockoon |

**Copilot:** Agents appear in the VS Code Chat agents dropdown, or via `/agent` in Copilot CLI.
**Amp:** Agents are installed as skills in `.agents/skills/` and listed in `AGENTS.md`. Code review checks are installed to `.agents/checks/` for use with `amp review`. Prompts are merged into their target skills automatically.

### Tools

Standalone tools and MCP servers. Used by agents via skills, or directly from the command line.

| Tool | Description | Docs |
|------|-------------|------|
| **nodemcp** | MCP server framework — modular provider system, STDIO + HTTP transports, session management | [README](tools/nodemcp/README.md) |
| **docsearch** | Reverse HyDE document search — generates hypothetical queries at index time for better semantic matching | [README](tools/mcps/docsearch/README.md) |
| **splunk** | Splunk MCP provider — search, monitoring, log analysis via authenticated sessions | [README](tools/mcps/splunk/README.md) |
| **browser-automation** | Browser automation MCP provider — navigate, click, extract, screenshot via Edge/Chrome | [README](tools/mcps/browser-automation/README.md) |
| **pr-review** | AI-powered PR review pipeline — multi-stage code review with AST analysis and configurable prompts | [README](tools/pr-review/README.md) |
| **mockoon-gen** | Mockoon mock data generator — fetches CAP API swagger specs and generates comprehensive mock responses with trigger-based routing | [README](tools/mockoon-gen/README.md) |

### Examples

| Path | Description |
|------|-------------|
| `examples/test-ets-restassured/` | Pre-built instructions and skills for Selenium + RestAssured projects — install with `--example=test-ets-restassured` |
| `examples/docsearch/` | Solution design documents + pre-built search index for docsearch | 

See [examples/docsearch/README.md](examples/docsearch/README.md) for docsearch usage.

## Repository Structure

```
src/                                # Source of truth — tool-agnostic content
├── agents/                         # Agent instructions (no frontmatter)
│   ├── task-development/           # Analyse → Plan → Implement → Recover
│   ├── code-review-westpac/          # AI-powered code review
│   ├── repo-scanner/               # Repository scanning sub-agents
│   ├── e2e-test-automation/        # E2E test generation pipeline
│   ├── defect-triage/              # Bug triage & root cause analysis
│   └── mockoon-gen/                # Swagger fetch + Mockoon data generation
├── skills/                         # Self-contained procedural instructions
├── checks/                         # Code review checks (Amp `amp review`)
├── prompts/                        # Prompt body text (Copilot-only feature)
├── project-context/                # Templates for target repos
└── principles.md                   # Universal principles and confidence assessment

manifest.yaml                      # Per-agent frontmatter + path mappings per tool

copilot/                            # GENERATED — build.js output for Copilot
amp/                                # GENERATED — build.js output for Amp

tools/
├── build.js                        # Reads src/ + manifest.yaml → generates copilot/ + amp/
├── build.test.js                   # Unit tests for build transforms and helpers
├── install-agents/                 # Cross-platform installer (install-agent.js + config)
├── sync-ai-common.js               # Bootstrap — downloads installer into target repos
├── nodemcp/                        # MCP server framework
├── mcps/
│   ├── docsearch/                  # Reverse HyDE document search
│   ├── splunk/                     # Splunk search & analytics
│   └── browser-automation/         # Browser automation
├── pr-review/                      # PR review pipeline
├── mockoon-gen/                    # Mockoon mock data generator CLI
└── *.bat / *.sh                    # Launcher scripts

examples/                           # Pre-built content for specific repo types
├── test-ets-restassured/           # Selenium + RestAssured (install with --example flag)
└── docsearch/                      # Example content & pre-built index

compose.md                          # How to install agents into a target repo
```

## Contributing

To add or edit agents, skills, or tools in this repo, see [docs/contributing.md](docs/contributing.md) for the full developer workflow — editing source files, running the build, adding new agents, and testing.
