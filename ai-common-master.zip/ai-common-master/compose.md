# Composing Workflows

This guide explains how to install ai-common agents and skills into a target repository using the automated installer.

## How It Works

Agent content lives in `src/` (tool-agnostic). A build script generates tool-specific output into `copilot/` and `amp/`. The installer (`install-agent.js`) downloads and deploys the generated output into target repos — no manual file copying needed.

```
ai-common (source)                    Target repo
┌─────────────────────┐               ┌─────────────────────┐
│ src/ (content)      │               │                     │
│ manifest.yaml       │  build.js     │ .github/  (Copilot) │
│         ↓           │ ──────────►   │ .agents/  (Amp)     │
│ copilot/ (generated)│  installer    │ AGENTS.md (Amp)     │
│ amp/     (generated)│               │ tools/    (shared)  │
└─────────────────────┘               └─────────────────────┘
```

See [README.md](README.md) for the full repository structure.

## Quick Start

### Prerequisites

1. **Node.js** v14+ installed
2. **`BITBUCKET_PAT`** environment variable set with a Bitbucket personal access token (read access)
3. *(Optional)* **`NODE_EXTRA_CA_CERTS`** set to your corporate CA bundle if you encounter SSL certificate errors
4. *(Optional)* **`AI_COMMON_BITBUCKET_URL`**, **`AI_COMMON_PROJECT`**, **`AI_COMMON_REPO`** to override the default Bitbucket connection (see [README — Environment Variables](README.md#environment-variables))

### Bootstrap (one-time per target repo)

Download the bootstrap script and run it from your target repo:

Windows (PowerShell):
```powershell
Invoke-WebRequest -Uri "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/A014A6/repos/ai-common/raw/tools/sync-ai-common.js?at=refs/heads/master" -Headers @{Authorization="Bearer $env:BITBUCKET_PAT"} -OutFile "sync-ai-common.js"
node sync-ai-common.js
```

macOS / Linux:
```bash
curl -fSL -H "Authorization: Bearer $BITBUCKET_PAT" "https://bitbucket.srv.westpac.com.au/rest/api/1.0/projects/A014A6/repos/ai-common/raw/tools/sync-ai-common.js?at=refs/heads/master" -o sync-ai-common.js
node sync-ai-common.js
```

This downloads `install-agent.js` and its config into `tools/install-agents/`.

### Install Everything

```bash
# Install all agents for Copilot (default)
node tools/install-agents/install-agent.js

# Install all agents for Amp
node tools/install-agents/install-agent.js --tool=amp

# Install all agents for both tools
node tools/install-agents/install-agent.js --tool=both
```

### Interactive Mode (Choose Packages)

```bash
# Interactive package selection — pick what you need from a menu
node tools/install-agents/install-agent.js --interactive

# Interactive with tool pre-selected
node tools/install-agents/install-agent.js -i --tool=amp
```

### Install Specific Packages

```bash
# Install a single package
node tools/install-agents/install-agent.js code-review-westpac
node tools/install-agents/install-agent.js task-development
node tools/install-agents/install-agent.js e2e-test-automation
node tools/install-agents/install-agent.js mockoon-gen

# Install a single package for a specific tool
node tools/install-agents/install-agent.js code-review-westpac --tool=amp

# List available packages
node tools/install-agents/install-agent.js --list
```

## Available Packages

| Package | Description | Includes |
|---------|-------------|----------|
| **foundation** | Core instructions and principles | `copilot-instructions.md` / `AGENTS.md`, project context templates |
| **task-development** | Multi-phase feature development | 4 agents (analysis → planning → implementation → recovery), JIRA skill |
| **code-review-westpac** | AI-powered PR review | Code review agent, pr-review CLI tool and skill |
| **repo-scanner** | Repository analysis | 9 agents (orchestrator + 8 sub-scanners), UI fetch skills |
| **e2e-test-automation** | UI BDD test pipeline | 6 agents (workflow → case generation → planning → implementation) |
| **defect-triage** | Bug investigation | 4 agents (coordinator → log/doc/root-cause), evidence + Splunk skills |
| **mockoon-gen** | Swagger fetch + mock data generation | 2 agents (fetch swagger → generate mockoon), mockoon-gen CLI tool |

The **foundation** package is always installed automatically when you install any other package.

## Tool Flag (`--tool`)

Controls which tool-specific files are deployed:

| Flag | Deploys |
|------|---------|
| `--tool=copilot` | Agents → `.github/agents/`, skills → `.github/skills/`, prompts → `.github/prompts/` |
| `--tool=amp` | Skills → `.agents/skills/`, checks → `.agents/checks/`, principles → `AGENTS.md` |
| `--tool=both` | All of the above |

Default: `--tool=copilot`

### Amp-Specific Behaviour

- **AGENTS.md merge** — The installer uses `<!-- AI-COMMON:START/END -->` markers for idempotent updates. Your existing `AGENTS.md` content is preserved; ai-common content is appended or replaced within the markers.
- **Skills directory** — Amp agents are deployed as skills in `.agents/skills/<name>/SKILL.md`.
- **Folded sub-agents** — Sub-agents (e.g., repo-scanner sub-scanners) are folded into their parent skill's `reference/` subdirectory instead of being deployed as separate skills.
- **Code review checks** — `.agents/checks/` files are deployed for use with `amp review`.
- **Prompt merging** — Prompts with `amp.mergeInto` in the manifest are appended to their target agent/skill's AMP output (e.g., `defect-triage.prompt` → `triage-coordinator` skill).

## Force Flag (`--force`)

The installer is safe to re-run. **Agents, skills, and prompts** are always overwritten with the latest version from ai-common. **Instruction files** (project context templates where users fill in `<!-- TODO -->` placeholders) are protected and skipped if they already exist.

Use `--force` to overwrite everything, including protected instruction files:

```bash
# Safe re-run — instructions preserved, everything else updated
node tools/install-agents/install-agent.js --tool=amp

# Force update — overwrite everything including instructions
node tools/install-agents/install-agent.js --tool=amp --force
```

> **Note:** `AGENTS.md` merge via `<!-- AI-COMMON:START/END -->` markers is always idempotent regardless of `--force`.

## Target Flag (`--target`)

Filters framework-specific files and actions for the target repository type:

```bash
# Node.js SPA — includes npm-specific actions
node tools/install-agents/install-agent.js --tool=copilot --target=spa

# Java API — skips npm-specific actions
node tools/install-agents/install-agent.js --tool=copilot --target=api

# Generic (default) — only framework-agnostic files
node tools/install-agents/install-agent.js
```

Common targets: `generic` (default), `mfe`, `spa`, `widget`, `api`

## Using Project Examples

Pre-built project context and skills for specific repo types. These bypass the repo-scanner step by providing already-populated instruction and skill files.

```bash
# Install with an example overlay
node tools/install-agents/install-agent.js --tool=copilot --example=test-ets-restassured

# Amp variant
node tools/install-agents/install-agent.js --tool=amp --example=test-ets-restassured
```

| Example | Target Project | Provides |
|---------|---------------|----------|
| `test-ets-restassured` | Selenium + RestAssured test repos (W1C) | Pre-populated `instructions/` + `skills/` with templates |
| `docsearch` | Docsearch ingestion | Solution design documents + pre-built index |

> **Note:** The `e2e-test-automation` package ships agents only — it expects project-specific skills and populated instructions to already exist. Use repo-scanner to generate these, or install with `--example=test-ets-restassured`.

## Environment Setup

After installing, configure the `.env` file in the target repo:

**Copilot:** Copy `.github/.env.example` to `.github/.env` and fill in required values.

**Both tools:** Add the env file to `.gitignore` — it contains secrets.

```bash
cp <target-repo>/.github/.env.example <target-repo>/.github/.env
echo '.github/.env' >> <target-repo>/.gitignore
```

### Amp Settings (`~/.config/amp/settings.json`)

Configure MCP servers and proxy in your Amp settings file:

```json
{
  "amp.proxy": "http://your-proxy-host:port",
  "amp.mcpServers": {
    "nodemcp": {
      "command": "node",
      "args": ["<absolute-path-to>/ai-common/tools/nodemcp/cli.js", "--all"]
    }
  }
}
```

| Setting | Purpose |
|---------|---------|
| `amp.proxy` | Corporate HTTP proxy (required if behind a proxy) |
| `amp.mcpServers` | MCP server definitions — `nodemcp` provides docsearch, splunk, and browser-automation tools |

See [tools/nodemcp/README.md](tools/nodemcp/README.md) for provider-specific configuration and `--layers` options.

## For ai-common Developers

### Editing Content

1. Edit source files in `src/agents/`, `src/skills/`, or `src/prompts/`
2. Run `node tools/build.js` to regenerate `copilot/`, `amp/`, and example output
3. Commit `src/` changes AND generated output

Never manually edit files in `copilot/` or `amp/` — they are always regenerated from `src/` + `manifest.yaml`. This includes `examples/*/copilot/` and `examples/*/amp/`, which are built from each example's own `manifest.yaml`.

### Adding a New Agent or Skill

1. Create the source file in `src/agents/<group>/<name>.md` or `src/skills/<name>.md`
2. Add an entry to `manifest.yaml` with per-tool metadata and installer package assignment
3. Run `node tools/build.js` (generates Copilot/Amp output and `ai-common-config.json`)

See [docs/contributing.md](docs/contributing.md) for the full developer workflow.

### Adding a New Tool (Cline, Cursor, etc.)

1. Add a new section per agent/skill in `manifest.yaml` (e.g., `cline:`)
2. Add a new output target in `tools/build.js`


