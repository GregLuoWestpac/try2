---
applyTo: '**'
---
# Usage Patterns

> **Note:** This file is most relevant for libraries and shared packages.

## Installation

<!-- TODO: Document package scope, installation command, and peer dependencies -->

## Import Patterns

<!-- TODO: Document named exports, barrel files, or subpath imports if non-standard -->

## Configuration

<!-- TODO: Document any required setup for consumers -->

## Known Consumers

<!-- TODO: List applications that use this package -->

| Application | Version Used | Notes |
|-------------|--------------|-------|
