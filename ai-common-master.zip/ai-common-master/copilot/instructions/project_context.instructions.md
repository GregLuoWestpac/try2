---
applyTo: '**'
---
# Project Context

## Repository Purpose

<!-- TODO: Describe what this repository does and who uses it -->

## Design Principles

<!-- TODO: Document architecture and API conventions that guide implementation -->

**Architecture:**
<!-- Example: "Components should be composable and follow single-responsibility principle" -->

**API conventions:**
<!-- Example: "Use consistent prop naming: `isDisabled` not `disabled`" -->

## Domain Terminology

<!-- TODO: Define key business terms used in this codebase -->

| Term | Definition |
|------|------------|
