---
applyTo: '**'
---
# Repository Overview

## Repository Type

<!-- TODO: Identify the repository type (e.g., Monorepo, Single package, Microservice) -->

## Directory Structure

<!-- TODO: Document key directories -->

## Package/Module Categories

<!-- TODO: Document code categories -->

| Category | Description |
|----------|-------------|
