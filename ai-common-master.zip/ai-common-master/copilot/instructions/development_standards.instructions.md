---
applyTo: '**'
---
# Development Standards

## Naming Conventions

<!-- TODO: Document naming patterns used in this codebase -->

**Files:**
<!-- Example: "Components use PascalCase: `UserProfile.tsx`" -->
<!-- Example: "Test files use `.test.ts` suffix" -->

**Code:**
<!-- Example: "Hooks are prefixed with `use`: `useAuth`, `useFetch`" -->
<!-- Example: "Constants use SCREAMING_SNAKE_CASE" -->

## Frameworks & Libraries

<!-- TODO: Document the primary frameworks and libraries used -->

| Technology | Purpose |
|------------|---------|

## Build System

<!-- TODO: Document build tools and key commands -->

**Key commands:**
<!-- Example: -->
<!-- - `npm run build` - Production build -->
<!-- - `npm run dev` - Development server -->
<!-- - `npm run test` - Run tests -->
<!-- - `npm run lint` - Run linter -->

## Code Style

<!-- TODO: Document linting and formatting tools -->

**Linting:**
<!-- Example: "ESLint with TypeScript rules" -->

**Formatting:**
<!-- Example: "Prettier with default config" -->
