---
description: Invokes the pr-review CLI tool and returns structured review results. Use when running the automated code review pipeline.
---
# PR Review CLI Skill

Invokes the `pr-review` CLI tool with `--output json`, parses the structured results, and returns them to the calling agent.

## Usage

This skill is invoked by the **Code Review Westpac** agent to run the AI-powered PR review pipeline and return structured findings.

## Prerequisites

- The workspace must be a git repository with changes relative to a base branch
- `tools/pr-review/` must have its dependencies installed (`npm install`)
- The `copilot` CLI command must be available (used internally by the pr-review pipeline to call AI models)

### Bitbucket Integration (optional — only for posting reviews to PRs)

- `BITBUCKET_PAT` must be defined in `.github/.env` (secret — gitignored)
- Bitbucket repo config must be set in `pr_review_bot.yaml.local` at the repo root or `~/.pr_review_bot.yaml.local` in the user's home directory:
  ```yaml
  bitbucket:
    enabled: true
    baseUrl: 'https://bitbucket.example.com'
    project: 'PROJECT_KEY'
    repo: 'repository-slug'
  ```
- These config values are non-secret and team-shared — commit `pr_review_bot.yaml.local` or share the snippet with the team

## Instructions

### Step 1: Locate the CLI

The pr-review CLI lives at `tools/pr-review/cli.js` relative to the `ai-common` repository root. When composed into a target repository, the CLI path must be provided or discoverable.

**Determine the CLI path:**

**PowerShell (Windows):**

```powershell
# If ai-common is a sibling directory or configured via environment
$cliPath = if ($env:PR_REVIEW_CLI) { $env:PR_REVIEW_CLI } else { "tools/pr-review/cli.js" }
Test-Path $cliPath
```

**Bash (macOS/Linux):**

```bash
cliPath="${PR_REVIEW_CLI:-tools/pr-review/cli.js}"
test -f "$cliPath"
```

If the CLI is not found at the default path, check:

1. `$env:PR_REVIEW_CLI` / `$PR_REVIEW_CLI` environment variable
2. A parent or sibling `ai-common` directory
3. Ask the user for the path

### Step 2: Build the Command

Construct the CLI command based on the agent's review parameters:

| Parameter             | CLI Flag         | Default                   |
| --------------------- | ---------------- | ------------------------- |
| Review depth: simple  | `--simple`       | —                         |
| Review depth: complex | `--complex`      | —                         |
| Review depth: default | _(no flag)_      | ✅                        |
| Skip Bitbucket        | `--no-bitbucket` | ✅ (always in agent mode) |
| Skip cache            | `--no-cache`     | —                         |
| Clear cache first     | `--clear-cache`  | —                         |
| JSON output           | `--output json`  | ✅ (always in agent mode) |

**Always include:** `--output json --no-bitbucket`

**Example commands:**

```powershell
# Standard review
node tools/pr-review/cli.js --output json --no-bitbucket

# Quick review
node tools/pr-review/cli.js --output json --no-bitbucket --simple

# Deep review, fresh (no cache)
node tools/pr-review/cli.js --output json --no-bitbucket --complex --no-cache
```

### Step 3: Execute the Command

Run the CLI and capture the full stdout output:

**PowerShell (Windows):**

```powershell
$result = node tools/pr-review/cli.js --output json --no-bitbucket 2>$null
$json = $result | ConvertFrom-Json
```

**Bash (macOS/Linux):**

```bash
result=$(node tools/pr-review/cli.js --output json --no-bitbucket 2>/dev/null)
echo "$result" | jq '.'
```

**Important:** Redirect stderr to null — the CLI may emit progress/debug info to stderr even in JSON mode. Only stdout contains the JSON payload.

### Step 4: Parse the JSON Response

The CLI outputs a JSON object with this structure:

```json
{
  "status": "passed | warning | failed | skipped | error",
  "model": "claude-sonnet-4.5",
  "modelTier": "default",
  "branch": "feature/my-branch",
  "baseBranch": "main",
  "filesChanged": 8,
  "files": ["src/app.js", "src/utils.js"],
  "timestamp": "2026-02-18 14:30:00 +11:00",
  "stages": [
    {
      "id": "1_code_standards",
      "name": "Code Standards Review",
      "status": "completed | skipped | failed | cached",
      "duration": 15700,
      "passed": true,
      "issues": [
        {
          "severity": "high | medium | low",
          "category": "naming-convention",
          "file": "src/app.js",
          "line": 42,
          "issue": "Variable name does not follow camelCase convention",
          "suggestion": "Rename `my_var` to `myVar`",
          "reference": "ESLint: camelcase"
        }
      ],
      "observations": [
        {
          "type": "positive | suggestion | info",
          "description": "Good use of early returns to reduce nesting"
        }
      ],
      "summary": "3 issues found, 2 positive observations",
      "error": null
    }
  ],
  "summary": {
    "errors": 2,
    "warnings": 5,
    "info": 3,
    "passed": 4,
    "failed": 0,
    "skipped": 1,
    "cached": 2,
    "totalDuration": 45200
  }
}
```

### Step 5: Format Results for the Agent

Transform the parsed JSON into a structured report for the calling agent:

#### Status Mapping

| JSON `status` | Display                             |
| ------------- | ----------------------------------- |
| `passed`      | ✅ Review Passed                    |
| `warning`     | ⚠️ Issues Found (has HIGH severity) |
| `failed`      | ❌ Pipeline Failed (stage errors)   |
| `skipped`     | ⏭️ Skipped (no changes or disabled) |
| `error`       | 💥 Error (CLI execution failed)     |

#### Issue Severity Mapping

| JSON `severity` | Icon | Priority                  |
| --------------- | ---- | ------------------------- |
| `high`          | 🔴   | Must address before merge |
| `medium`        | 🟡   | Should address            |
| `low`           | 🟢   | Consider addressing       |

#### Return Structure

Return the following to the calling agent:

1. **Overall status** — passed/warning/failed with counts
2. **High-priority issues** — full details including file, line, issue, suggestion
3. **Medium/low issues** — grouped by stage, summarised
4. **Positive observations** — what was done well
5. **Stage breakdown** — which stages ran, cached, skipped, or failed
6. **Metadata** — model used, files changed, duration

## Error Handling

| Scenario       | Detection                      | Action                                                                           |
| -------------- | ------------------------------ | -------------------------------------------------------------------------------- |
| CLI not found  | `Test-Path` / `test -f` fails  | Return error: "pr-review CLI not found. Run `cd tools/pr-review && npm install`" |
| Not a git repo | Exit code 1 + error in JSON    | Return error from JSON `error` field                                             |
| No changes     | `status: "skipped"`            | Return: "No changes detected relative to base branch"                            |
| Stage failure   | `stages[].status === "failed"` | Return partial results + list failed stages                                      |
| Invalid JSON   | JSON parse fails               | Return raw output as error context                                               |
| Timeout        | No output within 5 minutes     | Return error: "Review timed out — try `--simple` for faster results"             |

## Notes

- The pr-review pipeline reviews only the `git diff` — changed lines relative to the base branch
- Each stage (code standards, architecture, UI, security, testing) runs independently
- Cached results are reused when the diff hasn't changed — use `--no-cache` to force fresh review
- The `--simple` flag uses a faster/cheaper AI model; `--complex` uses the most capable
- Stage results include both issues (problems to fix) and observations (things done well)
