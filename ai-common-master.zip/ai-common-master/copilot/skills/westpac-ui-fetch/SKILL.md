---
description: "Fetches @westpac/ui component definitions and props from the GEL-next design system. Use when you need component API details for Westpac UI development."
---
# Westpac UI Fetch Skill

Fetches @westpac/ui (GEL-next) component definitions from GitHub to provide Copilot context.

## Usage

This skill is invoked by the **Westpac UI Scanner** agent to fetch component type definitions and populate `.github/instructions/westpac-ui.instructions.md`.

## Prerequisites

- Network access to `raw.githubusercontent.com`
- No authentication required (public repository)

## Source Repository

- **Repository**: https://github.com/WestpacGEL/GEL-next
- **Branch**: `main`
- **Base URL**: `https://raw.githubusercontent.com/WestpacGEL/GEL-next/main/`

## Instructions

### Step 1: Discover Components Used in Current Project

Search the current project for imports from `@westpac/ui`:

**PowerShell (Windows):**
```powershell
# Find all imports from @westpac/ui
Get-ChildItem -Recurse -Include *.ts,*.tsx,*.js,*.jsx | Select-String -Pattern "from ['\`"]@westpac/ui['\`"]" | ForEach-Object { $_.Line }
```

**Bash (macOS/Linux):**
```bash
# Find all imports from @westpac/ui
grep -r --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" "from ['\"]@westpac/ui['\"]" . | awk -F: '{print $2}'
```

Extract component names from import statements:
- `import { Button, Alert } from '@westpac/ui'` → `['Button', 'Alert']`
- `import { AddIcon } from '@westpac/ui/icon'` → `['AddIcon']` (icon import)

**Output**: List of component names and icon names used in the project.

### Step 2: Fetch Package Version

Fetch the current version from GEL-next:

**PowerShell (Windows):**
```powershell
$url = "https://raw.githubusercontent.com/WestpacGEL/GEL-next/main/packages/ui/package.json"
$response = Invoke-RestMethod -Uri $url
$version = $response.version
Write-Host "Version: $version"
```

**Bash (macOS/Linux):**
```bash
url="https://raw.githubusercontent.com/WestpacGEL/GEL-next/main/packages/ui/package.json"
version=$(curl -s "$url" | jq -r '.version')
echo "Version: $version"
```

### Step 3: Fetch Component Directory Listing

Use GitHub API to list available components:

**PowerShell (Windows):**
```powershell
$url = "https://api.github.com/repos/WestpacGEL/GEL-next/contents/packages/ui/src/components"
$headers = @{ "User-Agent" = "Copilot-Agent" }
$components = Invoke-RestMethod -Uri $url -Headers $headers
$componentNames = $components | Where-Object { $_.type -eq "dir" } | Select-Object -ExpandProperty name
```

**Bash (macOS/Linux):**
```bash
url="https://api.github.com/repos/WestpacGEL/GEL-next/contents/packages/ui/src/components"
componentNames=$(curl -s -H "User-Agent: Copilot-Agent" "$url" | jq -r '.[] | select(.type == "dir") | .name')
echo "$componentNames"
```

### Step 4: Fetch Component Type Definitions

For each component discovered in Step 1, fetch its type definitions:

**Primary files to fetch per component:**

| File Pattern | Purpose |
|--------------|---------|
| `{component}.types.ts` | Props interface definitions |
| `{component}.tsx` | Default values, variant options |

**URL Pattern:**
```
https://raw.githubusercontent.com/WestpacGEL/GEL-next/main/packages/ui/src/components/{component}/{component}.types.ts
```

**Example for Button:**

**PowerShell (Windows):**
```powershell
$component = "button"
$url = "https://raw.githubusercontent.com/WestpacGEL/GEL-next/main/packages/ui/src/components/$component/$component.types.ts"
$types = Invoke-WebRequest -Uri $url | Select-Object -ExpandProperty Content
```

**Bash (macOS/Linux):**
```bash
component="button"
url="https://raw.githubusercontent.com/WestpacGEL/GEL-next/main/packages/ui/src/components/$component/$component.types.ts"
types=$(curl -s "$url")
echo "$types"
```

### Step 5: Parse TypeScript Props

Extract props from fetched TypeScript files:

| Pattern | Extract |
|---------|---------|
| `export interface {Component}Props` | Main props interface |
| `export type {Component}Props =` | Type alias props |
| `size?: 'small' \| 'medium' \| 'large'` | Variant options |
| `look?: 'primary' \| 'hero' \| 'faint'` | Look options |
| `= 'defaultValue'` | Default values |

**Props to capture:**
- Prop name
- Type (string, boolean, ReactNode, etc.)
- Optional (`?`) or required
- Default value (if specified in component file)
- Description (from JSDoc comments if present)

### Step 6: Fetch Icon Catalog

Fetch the icon index to get all available icons:

**PowerShell (Windows):**
```powershell
$url = "https://raw.githubusercontent.com/WestpacGEL/GEL-next/main/packages/ui/src/components/icon/index.ts"
$iconIndex = Invoke-WebRequest -Uri $url | Select-Object -ExpandProperty Content
```

**Bash (macOS/Linux):**
```bash
url="https://raw.githubusercontent.com/WestpacGEL/GEL-next/main/packages/ui/src/components/icon/index.ts"
iconIndex=$(curl -s "$url")
echo "$iconIndex"
```

Extract icon names from exports:
- `export { AddIcon } from './AddIcon.js'` → `AddIcon`

### Step 7: Build Component Reference

For each component, compile:

```markdown
### ComponentName

**Import:** `import { ComponentName } from '@westpac/ui'`

**Props:**
| Prop | Type | Required | Default | Description |
|------|------|----------|---------|-------------|
| size | 'small' \| 'medium' \| 'large' | No | 'medium' | Component size |

**Variants:**
- **size**: small, medium, large
- **look**: primary, hero, faint, link
```

### Step 8: Output Results

Save compiled data to `.github/instructions/westpac-ui-components.json` as an **intermediate working file**. This file is consumed by the agent to generate the `.instructions.md` and must be deleted after documentation is written.

```typescript
{
  version: string;
  fetchedAt: string;
  components: {
    name: string;
    importPath: string;
    props: {
      name: string;
      type: string;
      required: boolean;
      default?: string;
      description?: string;
    }[];
    variants: Record<string, string[]>;
  }[];
  icons: string[];
  usedInProject: {
    component: string;
    files: string[];
  }[];
}
```

### Step 9: Cleanup

After the agent has generated `.github/instructions/westpac-ui.instructions.md`, **delete** the intermediate JSON file:

**PowerShell (Windows):**
```powershell
Remove-Item -Path ".github/instructions/westpac-ui-components.json" -ErrorAction SilentlyContinue
```

**Bash (macOS/Linux):**
```bash
rm -f .github/instructions/westpac-ui-components.json
```

## Error Handling

| Error | Cause | Resolution |
|-------|-------|------------|
| 404 Not Found | Component doesn't exist or renamed | Check component name spelling, may be nested differently |
| Rate Limited | Too many GitHub API requests | Wait and retry, or use authenticated requests |
| Network Error | No internet or firewall | Check network connectivity |
| Parse Error | TypeScript syntax changed | Update parsing logic for new patterns |

## Fallback Behavior

If a component's types cannot be fetched:
1. Log a warning
2. Include component in output with `props: []` and note "Types unavailable"
3. Continue with other components

## Component Name Mapping

Some components have different directory names:

| Import Name | Directory Name |
|-------------|----------------|
| `Button` | `button` |
| `Alert` | `alert` |
| `Modal` | `modal` |

**Rule**: Convert PascalCase import to lowercase directory name.

## Notes

- Only fetch components actually used in the current project (discovered in Step 1)
- Use GitHub raw URLs for file content (no API rate limits)
- Use GitHub API only for directory listing (Step 3)
- Cache results in instruction file to avoid repeated fetches
- The intermediate JSON file (`westpac-ui-components.json`) must always be deleted after the `.instructions.md` is finalized
- Re-run when upgrading @westpac/ui version or adding new component usage
