---
name: UI Test Planning Code
description: "Plans Page Object, Glue code, Steps, and Runner design for UI tests. Use as a sub-skill during UI test planning to design code structure."
tools: ['vscode', 'read', 'agent', 'search']
model: Claude Opus 4.6 (copilot)
---

# UI Test Planning - Code Agent

Plan **Phases 3-6**: Page Object, Glue, Steps, Runner design.

> **Framework Agnostic**: Layer patterns apply across frameworks. Project-specific paths and class structures are in SKILL.md.

## Skill File (REQUIRED)

**Read the project-specific skill file:**
the **UI Test Planning** skill (see .github/skills/ui-test-planning/SKILL.md)

## Context Strategy: Use Subagents

Delegate extraction to a subagent for large plans:

Invoke a subagent with the following context:
- Read implementation-plan.md (path from SKILL.md) Phases 1-2.
- Extract:
  1. All Gherkin steps (Given/When/Then)
  2. All elements from locator table
- Return as JSON: {steps: [], elements: []}

## Process

1. **Read SKILL.md** for file paths and class naming conventions
2. **Use subagent** to extract Phases 1-2 data
3. **Design method signatures** per layer (no full code)
4. **Append Phases 3-6** to implementation-plan.md (path from SKILL.md)

## Output Format

Append Phases 3-6 to implementation-plan.md. See SKILL.md for:
- File path patterns for each layer
- Method naming conventions
- Example method signatures
- Suite tag conventions

General structure per phase:

```markdown
## Phase N: [Layer Name]
**File**: `[path from SKILL.md]`
| Method | Purpose |
|--------|----------|
| [method signature] | [description] |
```

## Rules

- **Signatures only** — No full code
- **Atomic methods** — One action per method
- **Follow SKILL.md** — Use layer pattern and conventions from skill file
- **Use subagent** for reading if plan > 80 lines
