let currentEnv = "DEV";
let swimlaneSelect;
let envSelect;
let configData = {}; // Initialize configData

function updateSwimlaneOption() {
  // Clear existing options
  swimlaneSelect.innerHTML = "";

  if (!configData[currentEnv]) return;

  // Get available swimlanes for the current environment
  const swimlanes = Object.keys(configData[currentEnv]);

  // Create and append options
  swimlanes.forEach((swimlane, index) => {
    const option = document.createElement("option");
    option.value = swimlane;
    option.textContent = swimlane.toUpperCase();

    // Select the saved swimlane or 'main' by default
    const savedSwimlane = localStorage.getItem("selectedSwimlane");
    if (swimlane === savedSwimlane || (swimlane === "main" && !savedSwimlane)) {
      option.selected = true;
    }

    swimlaneSelect.appendChild(option);
  });
}

function updateLinks() {
  const swimlane = swimlaneSelect.value || "main";
  if (!configData[currentEnv]) return;

  // Save the selected swimlane to localStorage
  localStorage.setItem("selectedSwimlane", swimlane);

  // Use swimlane config; fallback to 'main' if the selected swimlane is not defined
  const envConfig =
    configData[currentEnv][swimlane] || configData[currentEnv]["main"];

  const browserLink = document.getElementById("browser-link");
  const openfinLink = document.getElementById("openfin-link");
  const openfinWebLink = document.getElementById("openfin-web-link");

  if (envConfig) {
    // Update Browser button
    if (envConfig.browser) {
      browserLink.href = envConfig.browser;
      browserLink.style.display = "block";
    } else {
      browserLink.style.display = "none";
    }

    // Update OpenFin button
    if (envConfig.openFin) {
      openfinLink.href = envConfig.openFin;
      openfinLink.style.display = "block";
    } else {
      openfinLink.style.display = "none";
    }

    // Update OpenFin Web button
    if (envConfig.openFinWeb) {
      openfinWebLink.href = envConfig.openFinWeb;
      openfinWebLink.style.display = "block";
    } else {
      openfinWebLink.style.display = "none";
    }
  }
}

function loadConfig() {
  swimlaneSelect = document.getElementById("swimlane-select");
  envSelect = document.getElementById("env-select");

  // Restore the saved environment selection
  const savedEnv = localStorage.getItem("selectedEnv");
  if (
    savedEnv &&
    [...envSelect.options].some((opt) => opt.value === savedEnv)
  ) {
    currentEnv = savedEnv;
    envSelect.value = savedEnv;
  }

  // Check if configData exists in localStorage
  const savedConfig = localStorage.getItem("configData");
  if (savedConfig) {
    // Load configData from localStorage
    configData = JSON.parse(savedConfig);
  } else {
    // Save the default configData from config.js to localStorage
    if (typeof defaultConfigData !== "undefined") {
      configData = defaultConfigData; // Assuming `defaultConfigData` is defined in config.js
      localStorage.setItem("configData", JSON.stringify(configData));
    } else {
      console.error("Default configData is not defined in config.js");
    }
  }

  initializeUI();
}

function initializeUI() {
  updateSwimlaneOption();
  updateLinks();

  // Set up environment change event
  envSelect.addEventListener("change", function () {
    currentEnv = this.value;

    // Save the selected environment to localStorage
    localStorage.setItem("selectedEnv", currentEnv);

    updateSwimlaneOption();
    updateLinks();
  });

  // Set up swimlane change event
  swimlaneSelect.addEventListener("change", updateLinks);

  // Set up drag-and-drop functionality
  setupDragAndDrop();
}

function setupDragAndDrop() {
  const dropArea = document.getElementById("drop-area");

  // Highlight drop area on dragover
  dropArea.addEventListener("dragover", (event) => {
    event.preventDefault();
    dropArea.classList.add("dragover");
  });

  // Remove highlight on dragleave
  dropArea.addEventListener("dragleave", () => {
    dropArea.classList.remove("dragover");
  });

  // Handle file drop
  dropArea.addEventListener(
    "drop",
    (event) => {
      console.log("dropArea.addEventListener");
      event.preventDefault();
      dropArea.classList.remove("dragover");

      const file = event.dataTransfer.files[0];
      if (
        file &&
        file.name.startsWith("config") &&
        file.name.endsWith(".json")
      ) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const fileContent = e.target.result;

          try {
            // Parse the config.js content and save it to localStorage
            configData = JSON.parse(fileContent);
            localStorage.setItem("configData", JSON.stringify(configData));

            // Reinitialize the UI with the new config
            initializeUI();
            alert("config.js file updated successfully!");
          } catch (error) {
            console.log(error);
            alert("Invalid config.js file format.");
          }
        };
        reader.readAsText(file);
      } else {
        alert("Please drop a valid config.js file.");
      }
    },
    { once: true }
  );
}

document.addEventListener("DOMContentLoaded", loadConfig);
