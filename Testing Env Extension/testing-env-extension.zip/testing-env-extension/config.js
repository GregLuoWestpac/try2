const defaultConfigData = {
  DEV: {
    main: {
      browser:
        "https://www.dev1.ui.westpac.com.au/galaxy/account?systemTest=true",
      openFin:
        "fins://one.dev1.ui.westpac.com.au/applications/multiverse/dev/manifest.staff.json",
      openFinWeb: "https://www.dev1.ui.westpac.com.au/multiverse/platform/web",
    },
    w1c1: {
      browser:
        "https://www.dev1.ui.westpac.com.au/galaxy/account?systemTest=true&swimlane=w1c1",
      openFin:
        "fins://www.dev1.ui.westpac.com.au/applications/multiverse/dev/w1c1/manifest.customer.json?swimlane=w1c1",
      openFinWeb: "https://one.dev1.ui.westpac.com.au/multiverse/platform/web",
    },
    w1c2: {
      browser:
        "https://www.dev1.ui.westpac.com.au/galaxy/account?systemTest=true&swimlane=w1c2",
      openFin:
        "fins://www.dev1.ui.westpac.com.au/applications/multiverse/dev/w1c2/manifest.customer.json?swimlane=w1c2",
      openFinWeb:
        "https://one.dev1.ui.westpac.com.au/multiverse/platform/web?swimlane=w1c2",
    },
  },
  SIT: {
    E2E: {
      browser: "https://www.sit1.ui.westpac.com.au/galaxy/account",
      openFin:
        "fins://www.sit1.ui.westpac.com.au/applications/multiverse/sit/manifest.customer.json",
      openFinWeb: "https://www.sit1.ui.westpac.com.au/multiverse/platform/web",
    },
    INT: {
      browser:
        "https://www.sit1.ui.westpac.com.au/galaxy/account?swimlane=w1c1",
      openFin:
        "fins://www.sit1.ui.westpac.com.au/applications/multiverse/sit/w1c1/manifest.customer.json?swimlane=w1c1",
      openFinWeb:
        "https://www.sit1.ui.westpac.com.au/multiverse/platform/web?swimlane=w1c1",
    },
    w1a: {
      browser: "",
      openFin:
        "fins://www.sit1.ui.westpac.com.au/applications/multiverse/sit/w1a/manifest.customer.json",
      openFinWeb: "",
    },
    w1c2: {
      browser:
        "https://www.sit1.ui.westpac.com.au/galaxy/account?swimlane=w1c2&systemTest=true",
      openFin:
        "fins://www.sit1.ui.westpac.com.au/applications/multiverse/sit/w1c2/manifest.customer.json?swimlane=w1c2",
      openFinWeb:
        "https://www.sit1.ui.westpac.com.au/multiverse/platform/web?swimlane=w1c2",
    },
    w1c3: {
      browser:
        "https://www.sit1.ui.westpac.com.au/galaxy/account?swimlane=w1c3",
      openFin: "",
      openFinWeb: "",
    },
  },
  SVP: {
    main: {
      browser: "https://www.svp1.ui.westpac.com.au/galaxy/account",
      openFin:
        "fins://www.svp1.ui.westpac.com.au/applications/multiverse/svp/manifest.customer.json",
      openFinWeb: "https://www.svp1.ui.westpac.com.au/multiverse/platform/web",
    },
  },
};
